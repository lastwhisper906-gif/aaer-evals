# SMCI notes — 0001628280-16-015755


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001628280-16-015755:notes:1]
Prior Period Adjustment Recorded in Current Period

[0001628280-16-015755:notes:2]
In November 2015, the Company identified errors related to revenue which was recognized prior to meeting US GAAP revenue recognition criteria which impacted fiscal years 2013, 2014 and 2015. The Company determined that certain contracts for extended warranties on products were recorded as revenue at the time of sale of the product in prior periods instead of being deferred and amortized over the contractual warranty period. The cumulative impact of this error pertaining to prior periods through June 30, 2015 was to overstate net sales and net income by $9,259,000 and $5,926,000, respectively. To compute the amount of the error, the Company determined a best estimated selling price for the extended warranty contracts based on prices charged to customers for these contracts when sold separately.  This error was corrected in the first quarter ended September 30, 2015 by reducing net sales by $9,259,000 and net income by $5,926,000, respectively.

[0001628280-16-015755:notes:3]
The Company assessed the materiality of these errors on each of the fiscal years ended June 30, 2013, 2014 and 2015, and concluded that the errors were not material to any of these periods. The Company also concluded that recording an out-of-period correction would not be material to the nine months ended March 31, 2016. Consequently, the accompanying condensed consolidated statement of operations for the nine months ended March 31, 2016 have been corrected.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-16-015755:notes:4]
Commitments and Contingencies

[0001628280-16-015755:notes:5]
Litigation and Claims— The Company is involved in various legal proceedings arising from the normal course of business activities. The Company defends itself vigorously against any such claims. In management’s opinion, the resolution of any matters will not have a material adverse effect on the Company’s consolidated financial condition, results of operations or liquidity.

[0001628280-16-015755:notes:6]
Purchase Commitments— The Company has agreements to purchase certain units of inventory and non-inventory items through fiscal year 2017. As of March 31, 2016, these remaining non-cancellable commitments were $341,559,000 compared to $378,341,000 as of June 30, 2015.

[0001628280-16-015755:notes:7]
Included in the above non-cancellable commitments are hard disk drive purchase commitments totaling approximately $116,922,000, which will be paid through December 2016. The Company has entered into purchase agreements with selected suppliers of hard disk drives in order to ensure continuity of supply for these components. The agreements provide for some variation in the amount of units the Company is required to purchase and the suppliers may modify the purchase price for these components due to significant changes in market or component supply conditions. Product mix for these components may be negotiated quarterly and the purchase price for these components will be reviewed quarterly with the suppliers. The Company has been negotiating the purchase price with the suppliers on an ongoing basis based upon market rates.


## us-gaap:ConsolidationPolicyTextBlock

[0001628280-16-015755:notes:8]
[same as prior period, unchanged from 0001628280-16-010768:notes:8]

[0001628280-16-015755:notes:9]
[same as prior period, unchanged from 0001628280-16-010768:notes:9]

[0001628280-16-015755:notes:10]
[same as prior period, unchanged from 0001628280-16-010768:notes:10]

[0001628280-16-015755:notes:11]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The condensed consolidated results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2016.

[0001628280-16-015755:notes:12]
[same as prior period, unchanged from 0001628280-16-010768:notes:12]


## us-gaap:DebtDisclosureTextBlock

[0001628280-16-015755:notes:13]
Short-term and Long-term Obligations

[0001628280-16-015755:notes:14]
Short-term and long-term obligations as of March 31, 2016 and June 30, 2015 consisted of the following (in thousands):

[0001628280-16-015755:notes:15]
|  | March 31, |  | June 30, |
|  | 2016 |  | 2015 |
| Line of credit: |  |  |  |
| Bank of America | $ | 62,199 |  |  | $ | 59,699 |  |
| CTBC Bank | 9,700 |  |  | 9,700 |  |
| Total line of credit | 71,899 |  |  | 69,399 |  |
| Building term loans: |  |  |  |
| Bank of America | 1,633 |  |  | 3,733 |  |
| CTBC Bank | 20,263 |  |  | 21,280 |  |
| Total building term loans | 21,896 |  |  | 25,013 |  |
| Total debt | 93,795 |  |  | 94,412 |  |
| Current portion | (93,795 | ) |  | (93,479 | ) |
| Long-term portion | $ | — |  |  | $ | 933 |  |

[0001628280-16-015755:notes:16]
Activities under Revolving Lines of Credit and Term Loans

[0001628280-16-015755:notes:17]
Bank of America

[0001628280-16-015755:notes:18]
In June 2015, the Company entered into an amendment to the existing credit agreement with Bank of America N.A. ("Bank of America") which provided for (i) a $65,000,000 revolving line of credit facility that would have matured on November 15, 2015 and (ii) a five-year $14,000,000 term loan facility. The term loan is secured by the three buildings located in San Jose, California and the principal and interest are payable monthly through September 30, 2016 with an interest rate at the LIBOR rate plus 1.50% per annum. In April 2016, the Company extended the revolving line of credit to mature on May 31, 2016, and the Company is currently negotiating with Bank of America to renew the revolving line of credit.

[0001628280-16-015755:notes:19]
The line of credit facility provides for borrowings denominated both in U.S. dollars and in Taiwanese dollars. For borrowings denominated in U.S. dollars, the interest rate for the revolving line of credit is at the LIBOR rate plus 1.25% per annum. The LIBOR rate was 0.44% at March 31, 2016. For borrowings denominated in Taiwanese dollars, the interest rate is equal to the lender's established interest rate which is adjusted monthly.

[0001628280-16-015755:notes:20]
As of March 31, 2016 and June 30, 2015, the total outstanding borrowings under the Bank of America term loan were $1,633,000 and $3,733,000, respectively. The total outstanding borrowings under the Bank of America line of credit were $62,199,000 and $59,699,000 as of March 31, 2016 and June 30, 2015, respectively. The interest rates for these loans ranged from 1.00% to 1.94% per annum at March 31, 2016 and from 0.79% to 1.68% per annum at June 30, 2015, respectively. As of March 31, 2016, the unused revolving line of credit with Bank of America was $2,801,000.

[0001628280-16-015755:notes:21]
CTBC Bank

[0001628280-16-015755:notes:22]
In November 2015, the Company entered into an amendment to the existing credit agreement with CTBC Bank Co., Ltd ("CTBC Bank") that provides for (i) a 12-month NT$700,000,000 or $22,017,000 U.S. dollar equivalent term loan secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $17,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at NT$1,000,000,000 or $30,340,000 U.S. dollar equivalent.

[0001628280-16-015755:notes:23]
The total outstanding borrowings under the CTBC Bank term loan are denominated in Taiwanese dollars and were translated into U.S. dollars of $20,263,000 and $21,280,000 at March 31, 2016 and June 30, 2015, respectively. The total outstanding borrowings under the CTBC Bank revolving line of credit were $9,700,000 in U.S. dollars at March 31, 2016 and June 30, 2015. The interest rate for this loan ranged from 0.92% and 1.06% at March 31, 2016 and 0.82% and 1.16% per annum at June 30, 2015.

[0001628280-16-015755:notes:24]
In April 2016, the Company entered into a credit agreement with CTBC Bank Co., Ltd that provides for (i) a 12-month NT700,000,000 or $21,620,000 U.S. dollar equivalent term loan facility secured by the land and building located in Bade, Taiwan with an interest rate equal to the lender's established NTD interest rate plus 0.25% per annum which is adjusted monthly. This term loan facility also includes a 12-month customs bond up to NT100,000,000 or $3,089,000 U.S. dollar equivalent with an annual fee equal to 0.5% per annum, and (ii) a 12-month revolving line of credit up to 80.0% of eligible accounts receivable in an aggregate amount of up to $40,000,000 with an interest rate equal to the lender's established USD interest rate plus 0.30% per annum which is adjusted monthly. The total borrowings allowed under the credit agreement are capped at $40,000,000. The credit agreement matures on March 31, 2017.

[0001628280-16-015755:notes:25]
Covenant Compliance

[0001628280-16-015755:notes:26]
The credit agreement with Bank of America contains customary representations and warranties and customary affirmative and negative covenants applicable to the Company and its subsidiaries. The credit agreement contains certain financial covenants, including the following:

[0001628280-16-015755:notes:27]
|  | • |  | Not to incur on a consolidated basis, a net loss before taxes and extraordinary items in any two consecutive quarterly accounting periods; |

[0001628280-16-015755:notes:28]
|  | • |  | The Company’s funded debt to EBITDA ratio (ratio of all outstanding liabilities for borrowed money and other interest-bearing liabilities, including current and long-term debt, less the non-current portion of subordinated liabilities to EBITDA) shall not be greater than 2.00; |

[0001628280-16-015755:notes:29]
|  | • |  | The Company’s unencumbered liquid assets, as defined in the agreement, held in the United States shall have an aggregate market value of not less than $30,000,000, measured as of the last day of each fiscal quarter and the last day of each fiscal year. |

[0001628280-16-015755:notes:30]
As of March 31, 2016 and June 30, 2015, total assets of $1,137,023,000 and $1,045,408,000, respectively, collateralized the line of credit with Bank of America which represents all of the assets of the Company except for the three buildings purchased in San Jose, California in June 2010 and the land and building located in Bade, Taiwan. As of March 31, 2016 and June 30, 2015, total assets collateralizing the term loan with Bank of America were $17,181,000 and $17,354,000. As of March 31, 2016, the Company was in compliance with all financial covenants associated with the credit agreement with Bank of America.

[0001628280-16-015755:notes:31]
As of March 31, 2016 and June 30, 2015, the land and building located in Bade, Taiwan with a value of  $26,909,000 and $27,047,000, respectively, collateralized the term loan with CTBC Bank. There are no financial covenants associated with the term loan with CTBC Bank at March 31, 2016.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-015755:notes:32]
[same as prior period, unchanged from 0001628280-16-010768:notes:31]

[0001628280-16-015755:notes:33]
[same as prior period, unchanged from 0001628280-16-010768:notes:32]

[0001628280-16-015755:notes:34]
In January 2016, the Board of Directors approved the 2016 Equity Incentive Plan (the "2016 Plan") and reserved for issuance 4,700,000 shares of common stock for the granting of stock options, stock appreciation rights, restricted stock awards, restricted stock units and other equity-based awards. The 2016 Plan was approved by the stockholders of the Company and became effective on March 8, 2016. As of such date, 8,696,444 shares of common stock were reserved for outstanding awards under the Company's 2006 Equity Incentive Plan (the "2006" Plan). Such awards remained outstanding under the 2006 Plan following the adoption of the 2016 Plan. In addition, 1,153,412 shares of common stock originally reserved for issuance under the 2006 Plan were cancelled upon the adoption of the 2016 Plan. Under the 2016 Plan, the exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of the Company at the time of grant cannot be less than 110% of the fair value of the underlying share on grant date. Nonqualified stock options and incentive stock options granted to all other persons shall be granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and restricted stock units vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter. As of March 31, 2016, the Company had 4,678,000 authorized shares available for future issuance under the 2016 Plan.

[0001628280-16-015755:notes:35]
[same as prior period, unchanged from 0001628280-16-010768:notes:34]

[0001628280-16-015755:notes:36]
[same as prior period, unchanged from 0001628280-16-010768:notes:35]

[0001628280-16-015755:notes:37]
[same as prior period, unchanged from 0001628280-16-010768:notes:36]

[0001628280-16-015755:notes:38]
[same as prior period, unchanged from 0001628280-16-010768:notes:37]

[0001628280-16-015755:notes:39]
[same as prior period, unchanged from 0001628280-16-010768:notes:38]

[0001628280-16-015755:notes:40]
[same as prior period, unchanged from 0001628280-16-010768:notes:39]

[0001628280-16-015755:notes:41]
[same as prior period, unchanged from 0001628280-16-010768:notes:40]

[0001628280-16-015755:notes:42]
The fair value of stock option grants for the three and nine months ended March 31, 2016 and 2015 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001628280-16-015755:notes:43]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Risk-free interest rate | 1.38% - 1.48% |  |  | 1.35% - 1.58% |  |  | 1.38% - 1.57% |  |  | 1.35% - 1.76% |  |
| Expected term | 5.31 years |  |  | 5.40 years |  |  | 5.31 - 5.33 years |  |  | 5.40 - 5.44 years |  |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |
| Volatility | 49.09% - 50.89% |  |  | 47.60% - 48.26% |  |  | 47.06% - 50.89% |  |  | 46.93% - 49.31% |  |
| Weighted-average fair value | $ | 12.99 |  |  | $ | 15.92 |  |  | $ | 12.04 |  |  | $ | 12.59 |  |

[0001628280-16-015755:notes:44]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2016 and 2015 (in thousands):

[0001628280-16-015755:notes:45]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of sales | $ | 294 |  |  | $ | 222 |  |  | $ | 792 |  |  | $ | 651 |  |
| Research and development | 2,549 |  |  | 2,255 |  |  | 7,423 |  |  | 6,148 |  |
| Sales and marketing | 491 |  |  | 369 |  |  | 1,330 |  |  | 1,148 |  |
| General and administrative | 552 |  |  | 720 |  |  | 2,223 |  |  | 1,780 |  |
| Stock-based compensation expense before taxes | 3,886 |  |  | 3,566 |  |  | 11,768 |  |  | 9,727 |  |
| Income tax impact | (1,191 | ) |  | (1,355 | ) |  | (3,290 | ) |  | (2,747 | ) |
| Stock-based compensation expense, net | $ | 2,695 |  |  | $ | 2,211 |  |  | $ | 8,478 |  |  | $ | 6,980 |  |

[0001628280-16-015755:notes:46]
The cash flows resulting from the tax benefits for tax deductions resulting from the exercise of stock options in excess of the compensation expense recorded for those options (excess tax benefits) issued or modified since July 1, 2006 are classified as cash provided by financing activities. Excess tax benefits for stock options issued prior to July 1, 2006 are classified as cash provided by operating activities. The Company had $3,548,000 and $10,576,000 of excess tax benefits recorded in additional paid-in capital in the nine months ended March 31, 2016 and 2015, respectively. The Company had excess tax benefits classified as cash provided by financing activities of $2,506,000 and $7,229,000 in the nine months ended March 31, 2016 and 2015, respectively, for options issued since July 1, 2006.

[0001628280-16-015755:notes:47]
As of March 31, 2016, the Company’s total unrecognized compensation cost related to non-vested stock-based awards granted to employees and non-employee directors was $35,590,000, which will be recognized over a weighted-average vesting period of approximately 2.31 years.

[0001628280-16-015755:notes:48]
[same as prior period, unchanged from 0001628280-16-010768:notes:47]

[0001628280-16-015755:notes:49]
The following table summarizes stock option activity during the nine months ended March 31, 2016 under all plans:

[0001628280-16-015755:notes:50]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2015 (7,208,475 shares exercisable at weighted average exercise price of $12.24 per share) |  | 9,702,843 |  |  | $ | 14.21 |  |  |  |  |  |
| Granted (weighted average fair value of $12.04) |  | 279,650 |  |  | $ | 26.61 |  |  |  |  |  |
| Exercised |  | (897,424 | ) |  | $ | 11.88 |  |  |  |  |  |
| Forfeited |  | (35,531 | ) |  | $ | 18.85 |  |  |  |  |  |
| Balance as of March 31, 2016 |  | 9,049,538 |  |  | $ | 14.81 |  |  | 5.43 |  | $ | 174,856 |  |
| Options vested and expected to vest at March 31, 2016 |  | 8,956,079 |  |  | $ | 14.70 |  |  | 5.40 |  | $ | 174,044 |  |
| Options vested and exercisable at March 31, 2016 |  | 7,346,160 |  |  | $ | 13.17 |  |  | 4.78 |  | $ | 153,798 |  |

[0001628280-16-015755:notes:51]
The total pretax intrinsic value of options exercised was $11,637,000 and $16,491,000 during the three and nine months ended March 31, 2016, respectively, and $22,231,000 and $44,301,000 during the three and nine months ended March 31, 2015, respectively.

[0001628280-16-015755:notes:52]
[same as prior period, unchanged from 0001628280-16-010768:notes:51]

[0001628280-16-015755:notes:53]
[same as prior period, unchanged from 0001628280-16-010768:notes:52]

[0001628280-16-015755:notes:54]
The following table summarizes restricted stock unit activity during the nine months ended March 31, 2016 under all plans:

[0001628280-16-015755:notes:55]
|  |  | Restricted Stock UnitsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2015 |  | 303,324 |  |  | $ | 36.02 |  |  |  |
| Granted |  | 614,560 |  |  | $ | 28.35 |  |  |  |
| Vested |  | (102,918 | ) |  | $ | 33.24 |  |  |  |
| Forfeited |  | (33,060 | ) |  | $ | 30.52 |  |  |  |
| Balance as of March 31, 2016 |  | 781,906 |  |  | $ | 30.59 |  |  | $ | 26,647 |  |

[0001628280-16-015755:notes:56]
The total pretax intrinsic value of restricted stock units vested was $1,579,000 and $2,937,000 for the three and nine months ended March 31, 2016, respectively. In the three and nine months ended March 31, 2016, upon vesting, 50,912 and 102,918 shares of restricted stock units were partially net share-settled such that the Company withheld 19,480 and 38,801 shares with value equivalent to the employees' minimum statutory obligation for the applicable income and other employment taxes, and remitted the cash to the appropriate taxing authorities, respectively. The total shares withheld were based on the value of the restricted stock units on their respective vesting dates as determined by the Company's closing stock price. Total payments for the employees' tax obligations to taxing authorities were $604,000 and $1,108,000 during the three and nine months ended March 31, 2016, respectively,  and are reflected as a financing activity within the condensed consolidated statements of cash flows. These net-share settlements had the effect of share repurchases by the Company as they reduced and retired the number of shares that would have otherwise been issued as a result of the vesting and did not represent an expense to the Company. Pursuant to the terms of the 2016 Plan, shares withheld in connection with net-share settlements are returned to the 2016 Plan and are available for future grants under the 2016 Plan.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-16-015755:notes:57]
[same as prior period, unchanged from 0001628280-16-010768:notes:56]

[0001628280-16-015755:notes:58]
[same as prior period, unchanged from 0001628280-16-010768:notes:57]


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-015755:notes:59]
The following table shows the computation of basic and diluted net income per share for the three and nine months ended March 31, 2016 (in thousands, except per share amounts):

[0001628280-16-015755:notes:60]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income | $ | 16,662 |  |  | $ | 23,056 |  |  | $ | 65,050 |  |  | $ | 75,161 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding | 48,047 |  |  | 46,824 |  |  | 47,737 |  |  | 46,138 |  |
| Effect of dilutive securities | 4,191 |  |  | 5,184 |  |  | 3,900 |  |  | 4,964 |  |
| Weighted-average diluted shares | 52,238 |  |  | 52,008 |  |  | 51,637 |  |  | 51,102 |  |
| Basic net income per share | $ | 0.35 |  |  | $ | 0.49 |  |  | $ | 1.36 |  |  | $ | 1.63 |  |
| Diluted net income per share | $ | 0.32 |  |  | $ | 0.44 |  |  | $ | 1.26 |  |  | $ | 1.47 |  |

[0001628280-16-015755:notes:61]
For the three and nine months ended March 31, 2016 and 2015, the Company had stock options and restricted stock units outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 1,287,000 and 1,235,000 for the three and nine months ended March 31, 2016, respectively, and 175,000 and 627,000 for the three and nine months ended March 31, 2015, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-16-015755:notes:62]
The following table sets forth the Company’s cash equivalents and long-term investments as of March 31, 2016 and June 30, 2015 which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001628280-16-015755:notes:63]
| March 31, 2016 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 312 |  |  | $ | — |  |  | $ | — |  |  | $ | 312 |  |
| Auction rate securities | — |  |  | — |  |  | 2,633 |  |  | 2,633 |  |
| Total | $ | 312 |  |  | $ | — |  |  | $ | 2,633 |  |  | $ | 2,945 |  |
| June 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Money market funds | $ | 310 |  |  | $ | — |  |  | $ | — |  |  | $ | 310 |  |
| Auction rate securities | — |  |  | — |  |  | 2,633 |  |  | 2,633 |  |
| Total | $ | 310 |  |  | $ | — |  |  | $ | 2,633 |  |  | $ | 2,943 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-16-015755:notes:64]
The following table provides a reconciliation of the Company’s financial assets measured at fair value on a recurring basis, consisting of long-term auction rate securities, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2016 and 2015 (in thousands):

[0001628280-16-015755:notes:65]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Balance as of beginning of period | $ | 2,633 |  |  | $ | 2,647 |  |  | $ | 2,633 |  |  | $ | 2,647 |  |
| Total realized gains or (losses) included in net income | — |  |  | — |  |  | — |  |  | — |  |
| Total unrealized gains or (losses) included in other comprehensive income | — |  |  | — |  |  | — |  |  | — |  |
| Sales and settlements at par | — |  |  | — |  |  | — |  |  | — |  |
| Transfers in and/or out of Level 3 | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of end of period | $ | 2,633 |  |  | $ | 2,647 |  |  | $ | 2,633 |  |  | $ | 2,647 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-16-015755:notes:66]
[same as prior period, unchanged from 0001628280-16-010768:notes:65]

[0001628280-16-015755:notes:67]
The financial assets of the Company measured at fair value on a recurring basis are included in cash equivalents and long-term investments. The Company’s money market funds are classified within Level 1 of the fair value hierarchy which is based on quoted market prices for the identical underlying securities in active markets. The Company’s long-term auction rate securities investments are classified within Level 3 of the fair value hierarchy which did not have observable inputs for its auction rate securities as of March 31, 2016 and June 30, 2015. Refer to Note 1 for a discussion of the Company’s policies regarding the fair value hierarchy. The Company’s methodology for valuing these investments is the discounted cash flow model and is described in Note 5.

[0001628280-16-015755:notes:68]
The above table excludes $175,873,000 and $94,901,000 of cash and $2,128,000 and $1,130,000 of certificates of deposit held by the Company as of March 31, 2016 and June 30, 2015, respectively. There were no transfers between Level 1, Level 2 or Level 3 securities in the three and nine months ended March 31, 2016 and 2015.

[0001628280-16-015755:notes:69]
The following is a summary of the Company’s long-term investments as of March 31, 2016 and June 30, 2015 (in thousands):

[0001628280-16-015755:notes:70]
|  | March 31, 2016 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (117 | ) |  | $ | 2,633 |  |
|  | June 30, 2015 |
|  | AmortizedCost |  | GrossUnrealizedHoldingGains |  | GrossUnrealizedHoldingLosses |  | Fair Value |
| Auction rate securities | $ | 2,750 |  |  | $ | — |  |  | $ | (117 | ) |  | $ | 2,633 |  |

[0001628280-16-015755:notes:71]
The Company measures the fair value of outstanding debt for disclosure purposes on a recurring basis. As of March 31, 2016 and June 30, 2015, short-term and long-term debt of $93,795,000 and $94,412,000, respectively, are reported at amortized cost. This outstanding debt is classified as Level 2 as it is not actively traded and is valued using a discounted cash flow model that uses observable market inputs. Based on the discounted cash flow model, the fair value of the outstanding debt approximates amortized cost.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-015755:notes:72]
[same as prior period, unchanged from 0001628280-16-010768:notes:71]

[0001628280-16-015755:notes:73]
The Company recorded provisions for income taxes of $7,386,000 and $28,951,000 for the three and nine months ended March 31, 2016, respectively, and $8,136,000 and $30,234,000 for the three and nine months ended March 31, 2015, respectively. The effective tax rate was 30.7% and 30.8% for the three and nine months ended March 31, 2016, respectively, and 26.1% and 28.7% for the three and nine months ended March 31, 2015, respectively. The effective tax rate for the three and nine months ended March 31, 2016 is estimated to be lower than the federal statutory rate primarily due to the reinstatement of the U.S. federal research and development ("R&D") tax credit partially offset by the impact of stock option expenses and additional tax accruals related to foreign operations.

[0001628280-16-015755:notes:74]
On December 18, 2015, the Protecting Americans from Tax Hikes Act of 2015 extended the U.S. federal R&D tax credit permanently from January 1, 2015. As of March 31, 2016, the Company projected a total net tax benefit of $4,384,000 for fiscal year 2016, and $2,770,000 reinstated for fiscal year 2015.

[0001628280-16-015755:notes:75]
As of March 31, 2016, the Company had a liability for gross unrecognized tax benefits of $15,794,000, substantially all of which, if recognized, would affect the Company's effective tax rate. During the three and nine months ended March 31, 2016, there were no material changes in the total amount of the liability for gross unrecognized tax benefits. The Company’s policy is to include interest and penalties related to unrecognized tax benefits within the provision for taxes on the condensed consolidated statements of operations. As of March 31, 2016, the Company had accrued $1,010,000 of interest and penalties relating to unrecognized tax benefits.

[0001628280-16-015755:notes:76]
The Company is subject to U.S. federal income tax as well as income taxes in many state and foreign jurisdictions.  In August 2015, the Company met with the Internal Revenue Service in connection with its examination of the Company's federal income tax returns for tax years 2013 and 2014. The Company is also under audit in Taiwan for tax year ended June 30, 2014. The Company does not expect a resolution to be reached regarding either matter during the next twelve months. While management believes that the Company has adequate reserves for all uncertain tax positions, amounts asserted by tax authorities could be greater or less than the Company's current position. Accordingly, the Company's provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or the underlying matters are settled or otherwise resolved. The federal statute of limitations remain open in general for tax years 2013 through 2015. The  various state statute of limitations remain open in general for tax years 2011 through 2015. The statute of limitations in major foreign jurisdictions remain open for examination in general for tax years 2010 through 2015.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-16-015755:notes:77]
Long-term Investments

[0001628280-16-015755:notes:78]
As of March 31, 2016 and June 30, 2015, the Company held $2,633,000, of auction-rate securities (“auction rate securities”), net of unrealized losses, representing its interest in auction rate preferred shares in a closed end mutual fund invested in municipal securities; such auction rate securities were rated AA2 at March 31, 2016 and AA2 at June 30, 2015. These auction rate preferred shares have no stated maturity date.

[0001628280-16-015755:notes:79]
During February 2008, the auctions for these auction rate securities began to fail to obtain sufficient bids to establish a clearing rate and the securities were not salable in the auction, thereby losing the short-term liquidity previously provided by the auction process. As a result, as of March 31, 2016 and June 30, 2015, $2,633,000 of these auction rate securities have been classified as long-term available-for-sale investments.

[0001628280-16-015755:notes:80]
The Company has used a discounted cash flow model to estimate the fair value of the auction rate securities as of March 31, 2016 and June 30, 2015. The material factors used in preparing the discounted cash flow model are (i) the discount rate utilized to present value the cash flows, (ii) the time period until redemption and (iii) the estimated rate of return. As of March 31, 2016, the discount rate, the time period until redemption and the estimated rate of return were 1.81%, 3 years and 0.41%, respectively. Management derives the estimates by obtaining input from market data on the applicable discount rate, estimated time to redemption and estimated rate of return. The changes in fair value have been primarily due to changes in the estimated rate of return and a change in the estimated redemption period. The fair value of the Company's investment portfolio may change between 1% to 3% by increasing or decreasing the rate of return used by 1% or by increasing or decreasing the term used by 1 year. Changes in these estimates or in the market conditions for these investments are likely in the future based upon the then current market conditions for these investments and may affect the fair value of these investments. On a quarterly basis, the Company reviews the inputs to assess their continued appropriateness and consistency. If any significant differences were to be noted, they would be researched in order to determine the reason. However, historically, no significant differences have been noted. The Company has consistently applied these valuation techniques in all periods presented and believes it has obtained the most accurate information available for the auction rate securities. Movement of these inputs would not significantly impact the fair value of the auction rate securities.

[0001628280-16-015755:notes:81]
Based on this assessment of fair value, the Company determined that there was no changes in fair value of its auction rate securities during the three and nine months ended March 31, 2016 and 2015. There was a cumulative total decline of $117,000 as of March 31, 2016 and June 30, 2015. That amount has been recorded as a component of other comprehensive income. As of March 31, 2016 and June 30, 2015, the Company has recorded an accumulated unrealized loss of $70,000, net of deferred income taxes, on long-term auction rate securities. The Company deems this loss to be temporary as it will not likely be required to sell the securities before their anticipated recovery and the Company has the intent and financial ability to hold these investments until recovery of cost.

[0001628280-16-015755:notes:82]
Although the investment impairment is considered to be temporary, these investments are not currently liquid and in the event the Company needs to access these funds, the Company will not be able to do so without a loss of principal. The Company plans to continue to monitor the liquidity situation in the marketplace and the creditworthiness of its holdings and will perform periodic impairment analysis. In the three and nine months ended March 31, 2016 and 2015, there were no auction rate securities redeemed or sold.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-015755:notes:83]
Recent Accounting Pronouncements

[0001628280-16-015755:notes:84]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued new accounting guidance related to revenue recognition. This new standard replaces all current U.S. GAAP guidance on revenue, eliminates all industry-specific guidance and provides a unified model in determining when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. Further, in March 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - principal versus agent considerations. In April 2016, the FASB issued an amendment to the accounting guidance related to revenue from contracts with customers - identifying performance obligations and licensing. These guidances can be applied either retrospectively or as a cumulative-effect adjustment as of the date of adoption. Early adoption is permitted for annual periods beginning after December 15, 2016. The new standard is effective for the Company on July 1, 2018. The Company is currently evaluating the effect the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:notes:85]
In April 2015, the FASB issued an amendment to the accounting guidance related to presentation of debt issuance costs. The amendment requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. In August 2015, the FASB issued an amendment to the accounting guidance related to presentation and subsequent measurement of debt issuance costs associated with line-of-credit arrangements. The amendment clarified that an entity may defer and present debt issuance costs associated with line-of-credit arrangements as an asset and subsequently amortize the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. The amendment is effective for the Company on July 1, 2016. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:notes:86]
In July 2015, the FASB issued an amendment to the authoritative guidance related to inventory measurement. The amendment requires entities to measure inventory at the lower of cost and net realizable value thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. The amendment is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:notes:87]
In November 2015, the FASB issued an amendment to the accounting guidance related to balance sheet classification of deferred taxes. The amendment requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. Early adoption is permitted as of the beginning of an interim or annual reporting period. The amendment is effective for the Company on July 1, 2017. The Company is currently evaluating the effect the amendment to the guidance will have on the Company's financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:notes:88]
In February 2016, the FASB issued an amendment to the accounting guidance related to leases. The amendment will supersede the existing lease guidance, including on-balance sheet recognition of operating leases for lessees. This amendment should be applied using a modified retrospective approach and is effective for the Company on July 1, 2018. Early adoption is permitted. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.

[0001628280-16-015755:notes:89]
In March 2016, the FASB issued new accounting guidance on the accounting for certain aspects of share-based payment to employees, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements as well as classification in the statement of cash flows. This guidance is effective for us on July 1, 2017. The Company is currently evaluating the effect the guidance will have on its financial statement disclosures, results of operations and financial position.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001628280-16-015755:notes:90]
[same as prior period, unchanged from 0001628280-16-010768:notes:87]

[0001628280-16-015755:notes:91]
[same as prior period, unchanged from 0001628280-16-010768:notes:88]

[0001628280-16-015755:notes:92]
[same as prior period, unchanged from 0001628280-16-010768:notes:89]

[0001628280-16-015755:notes:93]
[same as prior period, unchanged from 0001628280-16-010768:notes:90]

[0001628280-16-015755:notes:94]
[same as prior period, unchanged from 0001628280-16-010768:notes:91]

[0001628280-16-015755:notes:95]
[same as prior period, unchanged from 0001628280-16-010768:notes:92]

[0001628280-16-015755:notes:96]
[same as prior period, unchanged from 0001628280-16-010768:notes:93]

[0001628280-16-015755:notes:97]
[same as prior period, unchanged from 0001628280-16-010768:notes:94]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-16-015755:notes:98]
[same as prior period, unchanged from 0001628280-16-010768:notes:95]

[0001628280-16-015755:notes:99]
|  | March 31, 2016 |  | June 30, 2015 |
| Land | $ | 70,454 |  |  | $ | 63,962 |  |
| Buildings | 71,665 |  |  | 51,959 |  |
| Building and leasehold improvements | 7,586 |  |  | 8,323 |  |
| Buildings and leasehold improvements construction in progress (1) | 10,895 |  |  | 25,572 |  |
| Machinery and equipment | 50,514 |  |  | 40,689 |  |
| Furniture and fixtures | 10,213 |  |  | 7,421 |  |
| Purchased software | 13,464 |  |  | 3,343 |  |
| Purchased software construction in progress (2) | 493 |  |  | 8,567 |  |
|  | 235,284 |  |  | 209,836 |  |
| Accumulated depreciation and amortization | (55,662 | ) |  | (46,798 | ) |
| Property, plant and equipment, net | $ | 179,622 |  |  | $ | 163,038 |  |

[0001628280-16-015755:notes:100]
(1) In connection with the purchase of property located in San Jose, California for the Company's Green Computing Park, the Company continues to engage several contractors for the development and construction of improvements on the property. The first manufacturing building at this location was completed in August 2015. In the nine months ended March 31, 2016, the Company also engaged a contractor for the construction of improvements on leasehold property located in the Netherlands, which was completed in October 2015.

[0001628280-16-015755:notes:101]
(2) The Company completed its implementation of a new enterprise resource planning, or ERP, system for its U.S. headquarters on July 5, 2015 and for its subsidiaries in Taiwan and the Netherlands in January 2016. The Company has capitalized the costs of the new ERP software and certain expenses associated directly with the implementation of the ERP system as of January 2016 and began to depreciate these costs in the nine months ended March 31, 2016.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-16-015755:notes:102]
Related-party and Other Transactions

[0001628280-16-015755:notes:103]
Ablecom Technology Inc.—Ablecom, a Taiwan corporation, together with one of its subsidiaries, Compuware (collectively “Ablecom”), is one of the Company’s major contract manufacturers. Ablecom’s ownership of Compuware is below 50% but Compuware remains a related party as Ablecom still has significant influence over its operations. Ablecom’s chief executive officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board of Directors. Ablecom owns approximately 0.3% of the Company’s common stock. Charles Liang and his wife, also an officer of the Company, collectively own approximately 10.5% of Ablecom, while Steve Liang and other family members own approximately 36.0% of Ablecom at March 31, 2016.

[0001628280-16-015755:notes:104]
The Company has product design and manufacturing services agreements (“product design and manufacturing agreements”) and a distribution agreement (“distribution agreement”) with Ablecom.

[0001628280-16-015755:notes:105]
Under the product design and manufacturing agreements, the Company outsources a portion of its design activities and a significant part of its manufacturing of components such as server chassis to Ablecom. Ablecom agrees to design products according to the Company’s specifications. Additionally, Ablecom agrees to build the tools needed to manufacture the products.  The Company has agreed to pay for Ablecom's cost of chassis and related product tooling and engineering services and will pay for those items when the work has been completed.

[0001628280-16-015755:notes:106]
Under the distribution agreement, Ablecom purchases server products from the Company for distribution in Taiwan. The Company believes that the pricing and terms under the distribution agreement are similar to the pricing and terms of distribution arrangements the Company has with similar, third party distributors.

[0001628280-16-015755:notes:107]
Ablecom’s net sales to the Company and its net sales of the Company’s products to others comprise a substantial majority of Ablecom’s net sales. The Company purchased products from Ablecom totaling $55,133,000 and $185,845,000, and sold products to Ablecom totaling $4,413,000 and $12,125,000 for the three and nine months ended March 31, 2016, respectively. The Company purchased products from Ablecom totaling $58,002,000 and $169,918,000, and sold products to Ablecom totaling $6,067,000 and $43,524,000 for the three and nine months ended March 31, 2015, respectively.

[0001628280-16-015755:notes:108]
Amounts owed to the Company by Ablecom as of March 31, 2016 and June 30, 2015 were $6,034,000 and $13,186,000, respectively. Amounts owed to Ablecom by the Company as of March 31, 2016 and June 30, 2015 were $45,357,000 and $59,015,000, respectively. For the three and nine months ended March 31, 2016, the Company paid Ablecom the majority of invoiced dollars between 34 and 88 days of invoice date. For the three and nine months ended March 31, 2016, the Company paid $3,003,000 and $5,901,000, respectively, for tooling assets and miscellaneous costs to Ablecom. For the three and nine months ended March 31, 2015, the Company paid $231,000 and $4,728,000, respectively, for tooling assets and miscellaneous costs to Ablecom.

[0001628280-16-015755:notes:109]
The Company’s exposure to loss as a result of its involvement with Ablecom is limited to (a) potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products and (b) potential losses on outstanding accounts receivable from Ablecom in the event of an unforeseen deterioration in the financial condition of Ablecom such that Ablecom defaults on its payable to the Company. Outstanding purchase orders with Ablecom were $65,227,000 and $67,261,000 at March 31, 2016 and June 30, 2015, respectively, representing the maximum exposure to loss relating to (a) above. The Company does not have any direct or indirect guarantees of losses of Ablecom.

[0001628280-16-015755:notes:110]
In May 2012, the Company and Ablecom jointly established Super Micro Asia Science and Technology Park, Inc. ("Management Company") in Taiwan to manage the common areas shared by the Company and Ablecom for their separately constructed manufacturing facilities. Each company contributed $168,000 and owns 50% of the Management Company. Although the operations of the Management Company are independent of the Company, through governance rights, the Company has the ability to direct the Management Company's business strategies. Therefore, the Company has concluded that the Management Company is a variable interest entity of the Company as the Company is the primary beneficiary of the Management Company. The accounts of the Management Company are consolidated with the accounts of the Company, and a noncontrolling interest has been recorded for the Ablecom's interests in the net assets and operations of the Management Company. In the three and nine months ended March 31, 2016, $13,000 and $9,000 of net income attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations. In the three and nine months ended March 31, 2015, $4,000 and $(3,000) of net income (loss) attributable to Ablecom's interest was included in the Company's general and administrative expenses in the condensed consolidated statements of operations.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001628280-16-015755:notes:111]
[same as prior period, unchanged from 0001628280-16-010768:notes:108]

[0001628280-16-015755:notes:112]
|  | March 31, 2016 |  | June 30, 2015 |
| Accrued payroll and related expenses | $ | 15,574 |  |  | $ | 15,141 |  |
| Customer deposits | 6,255 |  |  | 6,314 |  |
| Accrued warranty costs | 5,634 |  |  | 7,700 |  |
| Accrued cooperative marketing expenses | 7,782 |  |  | 5,690 |  |
| Deferred service revenue | 10,816 |  |  | 4,085 |  |
| Others | 8,071 |  |  | 7,813 |  |
| Total accrued liabilities | $ | 54,132 |  |  | $ | 46,743 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001628280-16-015755:notes:113]
[same as prior period, unchanged from 0001628280-16-010768:notes:110]

[0001628280-16-015755:notes:114]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |  | Amount |  | Percent ofNet Sales |
| Server systems | $ | 372,404 |  |  | 69.9 | % |  | $ | 301,953 |  |  | 64.1 | % |  | $ | 1,182,362 |  |  | 69.9 | % |  | $ | 859,818 |  |  | 60.7 | % |
| Subsystems and accessories | 160,317 |  |  | 30.1 | % |  | 169,272 |  |  | 35.9 | % |  | 508,941 |  |  | 30.1 | % |  | 557,743 |  |  | 39.3 | % |
| Total | $ | 532,721 |  |  | 100.0 | % |  | $ | 471,225 |  |  | 100.0 | % |  | $ | 1,691,303 |  |  | 100.0 | % |  | $ | 1,417,561 |  |  | 100.0 | % |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-16-015755:notes:115]
[same as prior period, unchanged from 0001628280-16-010768:notes:112]

[0001628280-16-015755:notes:116]
|  | March 31, 2016 |  | June 30, 2015 |
| Finished goods | $ | 356,966 |  |  | $ | 384,647 |  |
| Work in process | 32,281 |  |  | 23,214 |  |
| Purchased parts and raw materials | 90,029 |  |  | 55,632 |  |
| Total inventory | $ | 479,276 |  |  | $ | 463,493 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0001628280-16-015755:notes:117]
[same as prior period, unchanged from 0001628280-16-010768:notes:114]

[0001628280-16-015755:notes:118]
|  | March 31, 2016 |  | June 30, 2015 |
| Long-term deferred service costs | $ | 3,033 |  |  | $ | 1,490 |  |
| Prepaid royalty license | 810 |  |  | 997 |  |
| Investment in a privately held company | 1,411 |  |  | 1,411 |  |
| Restricted cash | 1,848 |  |  | 840 |  |
| Deposits | 924 |  |  | 265 |  |
| Others | 132 |  |  | 223 |  |
| Total other assets | $ | 8,158 |  |  | $ | 5,226 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001628280-16-015755:notes:119]
[same as prior period, unchanged from 0001628280-16-010768:notes:116]

[0001628280-16-015755:notes:120]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Balance, beginning of period | $ | 7,777 |  |  | $ | 6,960 |  |  | $ | 7,700 |  |  | $ | 7,083 |  |
| Provision for warranty | 3,685 |  |  | 3,968 |  |  | 12,229 |  |  | 10,928 |  |
| Costs charged to accrual | (3,872 | ) |  | (3,706 | ) |  | (10,545 | ) |  | (10,476 | ) |
| Change in estimated liability for pre-existing warranties | (460 | ) |  | (13 | ) |  | (2,254 | ) |  | (326 | ) |
| Balance, end of period | 7,130 |  |  | 7,209 |  |  | 7,130 |  |  | 7,209 |  |
| Current portion | (5,634 | ) |  | (7,209 | ) |  | (5,634 | ) |  | (7,209 | ) |
| Long-term portion | $ | 1,496 |  |  | $ | — |  |  | $ | 1,496 |  |  | $ | — |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-015755:notes:121]
The following is a summary for the three and nine months ended March 31, 2016 and 2015, of net sales by geographic region (in thousands):

[0001628280-16-015755:notes:122]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales: |  |  |  |  |  |  |  |
| United States | $ | 326,392 |  |  | $ | 273,631 |  |  | $ | 1,072,126 |  |  | $ | 803,757 |  |
| Europe | 93,279 |  |  | 88,259 |  |  | 294,239 |  |  | 269,404 |  |
| Asia | 78,544 |  |  | 74,772 |  |  | 241,595 |  |  | 241,785 |  |
| Other | 34,506 |  |  | 34,563 |  |  | 83,343 |  |  | 102,615 |  |
|  | $ | 532,721 |  |  | $ | 471,225 |  |  | $ | 1,691,303 |  |  | $ | 1,417,561 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001628280-16-015755:notes:123]
[same as prior period, unchanged from 0001628280-16-010768:notes:120]

[0001628280-16-015755:notes:124]
|  | March 31, |  | June 30, |
|  | 2016 |  | 2015 |
| Long-lived assets: |  |  |  |
| United States | $ | 135,732 |  |  | $ | 124,292 |  |
| Asia | 40,627 |  |  | 37,695 |  |
| Europe | 3,263 |  |  | 1,051 |  |
|  | $ | 179,622 |  |  | $ | 163,038 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-015755:notes:125]
[same as prior period, unchanged from 0001628280-16-010768:notes:122]

[0001628280-16-015755:notes:126]
[same as prior period, unchanged from 0001628280-16-010768:notes:123]

[0001628280-16-015755:notes:127]
International net sales are based on the country and region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2016 and 2015, of net sales by geographic region (in thousands):

[0001628280-16-015755:notes:128]
Subsystems and accessories are comprised of serverboards, chassis and accessories. Server systems constitute an assembly of subsystems and accessories. One customer represented 10.2% and 12.6% of the Company's total net sales in the three and nine months ended March 31, 2016 and one customer represented 13.9% and 12.5% of the Company’s total net sales for the three and nine months ended March 31, 2015, respectively. No country other than the United States represents greater than 10% of the Company’s total net sales in the three and nine months ended March 31, 2016 and 2015. No customer accounted for 10% or more of the Company's accounts receivable as of March 31, 2016 and June 30, 2015.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-16-015755:notes:129]
[same as prior period, unchanged from 0001628280-16-010768:notes:126]

[0001628280-16-015755:notes:130]
[same as prior period, unchanged from 0001628280-16-010768:notes:127]

[0001628280-16-015755:notes:131]
The Company recorded a provision for lower of cost or market and excess and obsolete inventory totaling $2,246,000 and $6,026,000 in the three and nine months ended March 31, 2016, respectively, and $287,000 and $4,462,000 in the three and nine months ended March 31, 2015, respectively.

[0001628280-16-015755:notes:132]
Restricted cash consists primarily of certificates of deposits pledged as security for one irrevocable letter of credit required in connection with a warehouse lease in Fremont, California, two deposits to escrow accounts required by the Company's worker's compensation program, one deposit required for the Company's bonded warehouse set up in Taiwan and bank guarantees in connection with office leases in the Netherlands.
