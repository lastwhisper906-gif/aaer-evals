# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001628280-16-015755:item_4_controls:1]
Item 4.    Controls and Procedures

[0001628280-16-015755:item_4_controls:2]
Evaluation of Effectiveness of Disclosure Controls and Procedures

[0001628280-16-015755:item_4_controls:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and our Chief Financial Officer, we evaluated the effectiveness of our disclosure controls and procedures, as such term is defined in Rule 13a-15(e) and 15d-15(e) promulgated under the Securities Exchange Act of 1934, as amended (the "Exchange Act"). The evaluation considered the procedures designed to ensure that information required to be disclosed by us in the reports filed or submitted by us under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission rules and forms and is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure. Due to the material weakness in internal control over financial reporting described below, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were not effective, and were not operating at the reasonable assurance level as of March 31, 2016.

[0001628280-16-015755:item_4_controls:4]
In November 2015, our management identified an error in accounting treatment of certain contracts with extended warranty provisions. Our management has identified a deficiency in the design of a control that represents a material weakness in internal control over financial reporting as follows:

[0001628280-16-015755:item_4_controls:5]
We did not have a control in place that is designed to review underlying sales contracts to identify additional deliverables provided to customers as part of sales transactions entered into by us. As a result, certain extended warranty revenue recorded in prior periods did not meet the criteria for revenue recognition and should have been deferred and recorded over the contractual period of the extended warranty.

[0001628280-16-015755:item_4_controls:6]
Because of the material weakness identified, our management has concluded that our internal control over financial reporting was not effective as of March 31, 2016.

[0001628280-16-015755:item_4_controls:7]
Changes in Internal Control over Financial Reporting

[0001628280-16-015755:item_4_controls:8]
There were no changes in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the quarter ended March 31, 2016 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. However, as noted below, we have implemented changes to our internal control over financial reporting to address the material weakness described above.

[0001628280-16-015755:item_4_controls:9]
Transition of enterprise resource planning system

[0001628280-16-015755:item_4_controls:10]
We have implemented a new enterprise resource planning, or ERP, system and have commenced using the new system in the U.S. in July 2015 and in Taiwan and the Netherlands in January 2016. The implementation of this ERP system involves changes in our procedures for internal control over financial reporting. We follow a system implementation life cycle process that requires significant pre-implementation planning, design and testing. We also conducted and will continue to conduct extensive post-implementation monitoring and process modifications to ensure that internal controls over financial reporting are designed and operating effectively. We have not experienced any significant difficulties to date in connection with the implementation or the operation of this ERP system.

[0001628280-16-015755:item_4_controls:11]
Remediation

[0001628280-16-015755:item_4_controls:12]
We have put a control in place to ensure that proper extended warranty and any other deliverables in our bill of materials are tracked and related revenue deferrals are recorded. The following steps have been implemented:

[0001628280-16-015755:item_4_controls:13]
| • | Initiation of a review of extended warranty and any other deliverables in our bill of materials for all products |

[0001628280-16-015755:item_4_controls:14]
| • | Increased oversight and monitoring by our management of extended warranty and other deliverables in our bill of materials for any new products |

[0001628280-16-015755:item_4_controls:15]
| • | Documenting and tracking extended warranty and other deliverables in our contract matrix to ensure proper revenue recognition |

[0001628280-16-015755:item_4_controls:16]
Our management believes the foregoing efforts will effectively remediate the material weakness. As we continue to evaluate and work to improve our internal control over financial reporting, our management may execute additional measures to address the material weakness or modify the remediation plan described and will continue to review and make necessary changes to the overall design of our internal controls.

[0001628280-16-015755:item_4_controls:17]
37
