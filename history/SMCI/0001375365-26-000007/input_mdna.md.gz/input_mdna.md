# SMCI MD&A — 0001375365-26-000007


## mdna

[0001375365-26-000007:mdna:1]
[same as prior period, unchanged from 0001375365-25-000030:mdna:1]

[0001375365-26-000007:mdna:2]
[same as prior period, unchanged from 0001375365-25-000030:mdna:2]

[0001375365-26-000007:mdna:3]
[same as prior period, unchanged from 0001375365-25-000030:mdna:3]

[0001375365-26-000007:mdna:4]
[same as prior period, unchanged from 0001375365-25-000030:mdna:4]

[0001375365-26-000007:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. For the three months ended December 31, 2025 and 2024, our net income was $400.6 million and $320.6 million, respectively. For the six months ended December 31, 2025 and 2024, our net income was $568.8 million and $744.9 million, respectively.

[0001375365-26-000007:mdna:6]
In order to increase our sales and profits, we believe that we must continue to develop flexible application optimized server and storage solutions while being among the first to market with new features and products. Our focus is on delivering Total IT Solutions that integrate, validate, and deliver server, storage, networking and software at the rack and cluster (multi-rack) level. Additionally, we will continue to expand our software offerings and enhance customer service and support, particularly as we increase our focus on large enterprise and data center customers. A key component of our strategy is our Data Center Building Block Solutions (“DCBBS”), which significantly reduces data center build time and enables full integration of AI computing, server, storage, networking, rack, cabling, liquid cooling, end-to-end management software, onsite deployment services, and ongoing maintenance. To further expand our market share, we also recognize the need to strengthen our network of sales partners and distribution channels.

[0001375365-26-000007:mdna:7]
[same as prior period, unchanged from 0001375365-25-000030:mdna:7]

[0001375365-26-000007:mdna:8]
SMCI | Q2 2026 Form 10-Q | 37

[0001375365-26-000007:mdna:9]
[same as prior period, unchanged from 0001375365-25-000030:mdna:9]

[0001375365-26-000007:mdna:10]
[same as prior period, unchanged from 0001375365-25-000030:mdna:10]

[0001375365-26-000007:mdna:11]
[same as prior period, unchanged from 0001375365-25-000030:mdna:11]

[0001375365-26-000007:mdna:12]
Macroeconomic factors, including inflation, interest rate changes, capital market volatility, global supply chain constraints, tariffs, and global economic and geopolitical developments, have had and may continue to have direct and indirect impacts on our business and results of operations, particularly demand for our products and net sales. While difficult to isolate and quantify, these macroeconomic factors have also impacted and may continue to impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments. Further, while many of these macroeconomic factors could have a long-term impact, others may have a short-term impact which could lead to our financial results not being comparable on a period-to-period basis.

[0001375365-26-000007:mdna:13]
[same as prior period, unchanged from 0001375365-25-000030:mdna:13]

[0001375365-26-000007:mdna:14]
The following is a summary of our financial highlights for the three months ended December 31, 2025 and 2024:

[0001375365-26-000007:mdna:15]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Net sales |  | $ | 12,682,491 |  |  | $ | 5,677,962 |  |  |  |  |  |
| Gross profit |  | $ | 798,567 |  |  | $ | 670,022 |  |  |  |  |  |
| Total operating expenses |  | $ | 324,269 |  |  | $ | 301,398 |  |  |  |  |  |
| Income from operations |  | $ | 474,298 |  |  | $ | 368,624 |  |  |  |  |  |
| Net income |  | $ | 400,564 |  |  | $ | 320,596 |  |  |  |  |  |
| Net income per diluted share |  | $ | 0.60 |  |  | $ | 0.51 |  |  |  |  |  |

[0001375365-26-000007:mdna:16]
•Net sales increased by 123.4% in the three months ended December 31, 2025 as compared to the three months ended December 31, 2024 primarily driven by fulfillment and shipment of orders to support our customers' datacenter deployment, including a large design win from one customer, during the second quarter, some of which were originally delayed in the previous quarter, due to customer configuration upgrades and data center readiness matters. An increase in our average selling price also contributed  modestly by product mix.

[0001375365-26-000007:mdna:17]
•Gross margin decreased to 6.3% in the three months ended December 31, 2025 from 11.8% in the three months ended December 31, 2024, primarily due to our strategy to offer competitive pricing to gain market share and a change in product and customer mix.

[0001375365-26-000007:mdna:18]
•Operating expenses increased by 7.6% in the three months ended December 31, 2025 as compared to the three months ended December 31, 2024, primarily due to higher headcount and increases in salary and stock-based compensation.

[0001375365-26-000007:mdna:19]
•Net income increased to $400.6 million in the three months ended December 31, 2025 as compared to $320.6 million in the three months ended December 31, 2024, which was primarily due to a higher increase in net sales.

[0001375365-26-000007:mdna:20]
SMCI | Q2 2026 Form 10-Q | 38

[0001375365-26-000007:mdna:21]
[same as prior period, unchanged from 0001375365-25-000030:mdna:21]

[0001375365-26-000007:mdna:22]
[same as prior period, unchanged from 0001375365-25-000030:mdna:22]

[0001375365-26-000007:mdna:23]
[same as prior period, unchanged from 0001375365-25-000030:mdna:23]

[0001375365-26-000007:mdna:24]
There have been no material changes to our critical estimates as compared to those disclosed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.

[0001375365-26-000007:mdna:25]
[same as prior period, unchanged from 0001375365-25-000030:mdna:25]

[0001375365-26-000007:mdna:26]
[same as prior period, unchanged from 0001375365-25-000030:mdna:26]

[0001375365-26-000007:mdna:27]
[same as prior period, unchanged from 0001375365-25-000030:mdna:27]

[0001375365-26-000007:mdna:28]
[same as prior period, unchanged from 0001375365-25-000030:mdna:28]

[0001375365-26-000007:mdna:29]
[same as prior period, unchanged from 0001375365-25-000030:mdna:30]

[0001375365-26-000007:mdna:30]
[same as prior period, unchanged from 0001375365-25-000030:mdna:31]

[0001375365-26-000007:mdna:31]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the region where our products are sold. We work with Ablecom, one of our key contract manufacturers and a related party, for our chassis and certain other components. We also outsource a significant part of the manufacturing of certain components, particularly power supplies, to Compuware, also a related party. We also collaborate on design and development activities with Ablecom and Compuware, where we substantially fund the design costs and retain the intellectual property rights. Our purchases of products from Ablecom and Compuware combined represented 1.6% and 2.1% of cost of sales on our condensed consolidated statements of operations for the three and six months ended December 31, 2025, respectively, and 2.7% and 3.7% of cost of sales on our condensed consolidated statements of operations for the three and six months ended December 31, 2024, respectively. For further details on our dealings with related parties, see Note 10, “Related Party Transactions” in the notes to the condensed consolidated financial statements.

[0001375365-26-000007:mdna:32]
SMCI | Q2 2026 Form 10-Q | 39

[0001375365-26-000007:mdna:33]
[same as prior period, unchanged from 0001375365-25-000030:mdna:33]

[0001375365-26-000007:mdna:34]
[same as prior period, unchanged from 0001375365-25-000030:mdna:34]

[0001375365-26-000007:mdna:35]
[same as prior period, unchanged from 0001375365-25-000030:mdna:35]

[0001375365-26-000007:mdna:36]
[same as prior period, unchanged from 0001375365-25-000030:mdna:36]

[0001375365-26-000007:mdna:37]
[same as prior period, unchanged from 0001375365-25-000030:mdna:37]

[0001375365-26-000007:mdna:38]
[same as prior period, unchanged from 0001375365-25-000030:mdna:38]

[0001375365-26-000007:mdna:39]
Other Income, Net, Interest Income, and Interest Expense

[0001375365-26-000007:mdna:40]
Other income, net, interest income, and interest expense consists primarily of interest earned on our investments and cash balances, interest incurred on our debt, and foreign exchange gains and losses.

[0001375365-26-000007:mdna:41]
[same as prior period, unchanged from 0001375365-25-000030:mdna:41]

[0001375365-26-000007:mdna:42]
[same as prior period, unchanged from 0001375365-25-000030:mdna:42]

[0001375365-26-000007:mdna:43]
SMCI | Q2 2026 Form 10-Q | 40

[0001375365-26-000007:mdna:44]
The following table presents certain items of our condensed consolidated statements of operations for the three and six months ended December 31, 2025 and 2024 (in millions):

[0001375365-26-000007:mdna:45]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 12,682.5 |  |  | $ | 5,678.0 |  |  | $ | 17,700.3 |  |  | $ | 11,615.2 |  |
| Cost of sales | 11,883.9 |  |  | 5,007.9 |  |  | 16,434.3 |  |  | 10,169.6 |  |
| Gross profit | 798.6 |  |  | 670.1 |  |  | 1,266.0 |  |  | 1,445.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 180.8 |  |  | 158.2 |  |  | 354.1 |  |  | 290.5 |  |
| Sales and marketing | 73.1 |  |  | 79.6 |  |  | 121.0 |  |  | 148.4 |  |
| General and administrative | 70.4 |  |  | 63.6 |  |  | 134.3 |  |  | 128.9 |  |
| Total operating expenses | 324.3 |  |  | 301.4 |  |  | 609.4 |  |  | 567.8 |  |
| Income from operations | 474.3 |  |  | 368.7 |  |  | 656.6 |  |  | 877.8 |  |
| Other income, net | 0.2 |  |  | 4.2 |  |  | 0.1 |  |  | 3.4 |  |
| Interest income | 51.0 |  |  | 8.8 |  |  | 102.4 |  |  | 16.8 |  |
| Interest expense | (25.3) |  |  | (6.5) |  |  | (50.3) |  |  | (23.9) |  |
| Income before income tax provision | 500.2 |  |  | 375.2 |  |  | 708.8 |  |  | 874.1 |  |
| Income tax provision | (99.1) |  |  | (57.0) |  |  | (139.3) |  |  | (131.7) |  |
| Share of (loss) income from equity investee, net of taxes | (0.5) |  |  | 2.4 |  |  | (0.7) |  |  | 2.5 |  |
| Net income | $ | 400.6 |  |  | $ | 320.6 |  |  | $ | 568.8 |  |  | $ | 744.9 |  |

[0001375365-26-000007:mdna:46]
The following table presents certain items of our condensed consolidated statements of operations expressed as a percentage of net sales for the three and six months ended December 31, 2025 and 2024:

[0001375365-26-000007:mdna:47]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |  |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |
| Cost of sales | 93.7 | % |  | 88.2 | % |  | 92.8 | % |  | 87.6 | % |  |
| Gross profit | 6.3 | % |  | 11.8 | % |  | 7.2 | % |  | 12.4 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development | 1.4 | % |  | 2.8 | % |  | 2.0 | % |  | 2.5 | % |  |
| Sales and marketing | 0.6 | % |  | 1.4 | % |  | 0.7 | % |  | 1.3 | % |  |
| General and administrative | 0.5 | % |  | 1.1 | % |  | 0.8 | % |  | 1.1 | % |  |
| Total operating expenses | 2.5 | % |  | 5.3 | % |  | 3.5 | % |  | 4.9 | % |  |
| Income from operations | 3.8 | % |  | 6.5 | % |  | 3.7 | % |  | 7.5 | % |  |
| Other income, net | — | % | * | 0.1 | % |  | — | % | * | 0.1 | % |  |
| Interest income | 0.4 | % |  | 0.1 | % |  | 0.6 | % |  | 0.1 | % |  |
| Interest expense | (0.2) | % |  | (0.1) | % |  | (0.3) | % |  | (0.2) | % |  |
| Income before income tax provision | 4.0 | % |  | 6.6 | % |  | 4.0 | % |  | 7.5 | % |  |
| Income tax provision | (0.8) | % |  | (1.0) | % |  | (0.8) | % |  | (1.1) | % |  |
| Share of (loss) income from equity investee, net of taxes | — | % | * | — | % | * | — | % | * | — | % | * |
| Net income | 3.2 | % |  | 5.6 | % |  | 3.2 | % |  | 6.4 | % |  |

[0001375365-26-000007:mdna:48]
[same as prior period, unchanged from 0001375365-25-000030:mdna:48]

[0001375365-26-000007:mdna:49]
SMCI | Q2 2026 Form 10-Q | 41

[0001375365-26-000007:mdna:50]
Net Sales

[0001375365-26-000007:mdna:51]
The following table presents net sales for the three and six months ended December 31, 2025 and 2024 (dollars in millions):

[0001375365-26-000007:mdna:52]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Net sales | $ | 12,682.5 |  |  | $ | 5,678.0 |  |  | $ | 7,004.5 |  |  | 123.4 | % |  | $ | 17,700.3 |  |  | $ | 11,615.2 |  |  | $ | 6,085.1 |  |  | 52.4 | % |

[0001375365-26-000007:mdna:53]
Comparison of the Three Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:54]
The $7,004.5 million or 123.4% increase in net sales was primarily due to fulfillment and shipment of orders to support our customers' datacenters deployment, including a large design win from a customer, during the three months ended December 31, 2025, some of which were originally delayed due to customer configuration upgrades and data center readiness matters. An increase in our average selling price compared to the prior quarter ended December 31, 2024 also contributed modestly by product mix. This was most pronounced in increased billings for AI GPU related products of $7,398.2 million or 169.7% year over year, including liquid-cooled and air-cooled servers that are generally more complex and of higher average selling price. This was partially offset by decreased sales across other product categories by $475.9 million, or 42.5% as we continue to focus on gaining market share from our AI GPU platforms.

[0001375365-26-000007:mdna:55]
Comparison of the Six Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:56]
The $6,085.1 million or 52.4% increase in net sales was primarily due to fulfillment and shipment of orders to support our customers' datacenters deployment, including a large design win from a customer, during the six months ended December 31, 2025. An increase in our average selling price compared to the six months ended December 31, 2024 also contributed modestly by product mix. This was most pronounced in increased billings for AI GPU related products of $6,870.4 million or 77.4% year over year, including liquid-cooled and air-cooled servers that are generally more complex and of higher average selling price. This was partially offset by decreased sales across other product categories by $784.5 million, or 34.3% as we continue to focus on gaining market share from our AI GPU platforms.

[0001375365-26-000007:mdna:57]
[same as prior period, unchanged from 0001375365-25-000030:mdna:61]

[0001375365-26-000007:mdna:58]
Cost of sales and gross margin for the three and six months ended December 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-26-000007:mdna:59]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Cost of sales | $ | 11,883.9 |  | $ | 5,007.9 |  | $ | 6,876.0 |  |  | 137.3 | % |  | $ | 16,434.3 |  | $ | 10,169.6 |  | $ | 6,264.7 |  |  | 61.6 | % |
| Percentage of total net sales | 93.7 | % |  | 88.2 | % |  |  |  |  |  | 92.8 | % |  | 87.6 | % |  |  |  |  |
| Gross profit | $ | 798.6 |  | $ | 670.1 |  | $ | 128.5 |  |  | 19.2 | % |  | $ | 1,266.0 |  | $ | 1,445.6 |  | $ | (179.6) |  |  | (12.4) | % |
| Gross margin | 6.3 | % |  | 11.8 | % |  |  |  | (5.5) | % |  | 7.2 | % |  | 12.4 | % |  |  |  | (5.2) | % |

[0001375365-26-000007:mdna:60]
SMCI | Q2 2026 Form 10-Q | 42

[0001375365-26-000007:mdna:61]
Comparison of the Three Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:62]
The $6,876.0 million or 137.3% increase in cost of sales was primarily driven by an increase of approximately  $6,429.2 million or 119.2% in certain products including GPU servers, HPC systems, and rack-scale solutions, consistent with the higher shipment volume during the three months ended December 31, 2025 as compared to the three months ended December 31, 2024. The remaining increases in cost of sales were driven by a $142.0 million or 2621.0% increase in tariff expenses driven by new trade policies, a $107.3 million or 419.8% increase in inventory write-down adjustments resulting from excess and obsolete inventory with either insufficient demand or reduced realizable value, and a $197.4 million or 47.5% increase due to a decrease in vendor rebates.

[0001375365-26-000007:mdna:63]
The 5.5% decrease in the gross margin was due to a change in product and customer mix, higher production and expedite costs as we began to ship new AI GPU platforms on a large scale and the increases in tariff expense and inventory write-down adjustments described above.

[0001375365-26-000007:mdna:64]
Comparison of the Six Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:65]
The $6,264.7 million or 61.6% increase in cost of sales was primarily driven by an increase of approximately  $5,657.2 million or 52.2% in certain products including GPU servers, HPC systems, and rack-scale solutions, consistent with the higher shipment volume during the six months ended December 31, 2025 as compared to the six months ended December 31, 2024. The remaining increases in cost of sales were driven by a $184.2 million or 1151.3% increase in tariff expenses driven by new trade policies, a $134.7 million or 388.0% increase in inventory write-down adjustments resulting from excess and obsolete inventory with either insufficient demand or reduced realizable value, and a $288.6 million or 40.0% increase due to a decrease in vendor rebates.

[0001375365-26-000007:mdna:66]
The 5.2% decrease in the gross margin was due to a change in product and customer mix, higher production and expedite costs as we began to ship new AI GPU platforms on a large scale  and the increases in tariff expense and inventory write-down adjustments described above.

[0001375365-26-000007:mdna:67]
[same as prior period, unchanged from 0001375365-25-000030:mdna:67]

[0001375365-26-000007:mdna:68]
Operating expenses for the three and six months ended December 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-26-000007:mdna:69]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Research and development | $ | 180.8 |  | $ | 158.2 |  | $ | 22.6 |  |  | 14.3 | % |  | $ | 354.1 |  | $ | 290.5 |  | $ | 63.6 |  |  | 21.9 | % |
| Percentage of total net sales | 1.4 | % |  | 2.8 | % |  |  |  |  |  | 2.0 | % |  | 2.5 | % |  |  |  |  |
| Sales and marketing | $ | 73.1 |  | $ | 79.6 |  | $ | (6.5) |  |  | (8.2) | % |  | $ | 121.0 |  | $ | 148.4 |  | $ | (27.4) |  |  | (18.5) | % |
| Percentage of total net sales | 0.6 | % |  | 1.4 | % |  |  |  |  |  | 0.7 | % |  | 1.3 | % |  |  |  |  |
| General and administrative | $ | 70.4 |  | $ | 63.6 |  | $ | 6.8 |  |  | 10.7 | % |  | $ | 134.3 |  | $ | 128.9 |  | $ | 5.4 |  |  | 4.2 | % |
| Percentage of total net sales | 0.5 | % |  | 1.1 | % |  |  |  |  |  | 0.8 | % |  | 1.1 | % |  |  |  |  |
| Total operating expenses | $ | 324.3 |  | $ | 301.4 |  | $ | 22.9 |  |  | 7.6 | % |  | $ | 609.4 |  | $ | 567.8 |  | $ | 41.6 |  |  | 7.3 | % |

[0001375365-26-000007:mdna:70]
SMCI | Q2 2026 Form 10-Q | 43

[0001375365-26-000007:mdna:71]
Comparison of the Three Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:72]
Research and development expenses. The $22.6 million or 14.3% increase in research and development expenses was primarily driven by an increase in employee-related costs of $20.0 million, or 13.6%, mainly comprised of a $14.4 million, or 17.0%, increase in salaries, and a $8.7 million, or 17.2%, increase in stock-based compensation, as we expanded our workforce and invested in key talent to support our global growth across regions.

[0001375365-26-000007:mdna:73]
Sales and marketing expenses. The $6.5 million or 8.2% decrease in sales and marketing expenses was primarily driven by a $11.6 million, or 240.8%, higher marketing development fund received from certain business partners related to co-marketing and advertising events to promote products, which reduced sales and marketing expense, and $13.1 million, or 48.6%, decrease in standard marketing and advertising activities during the three months ended December 31, 2025 as compared to the three months ended December 31, 2024. These decreases along with other minor cost decreases were partially offset by an increase in employee-related costs, mainly due to a $17.0 million, or 41.2%, increase in salaries and a $0.8 million, or 8.0%, increase in stock-based compensation, similar to our research and development expenses as we expanded our workforce and invested in key talent company-wide.

[0001375365-26-000007:mdna:74]
General and administrative expenses. The $6.8 million or 10.7% increase in general and administrative expenses was primarily attributable to a $6.4 million or 567.4% increase in excise and franchise tax expense directly related to the increase in sales compared to prior-year quarter which increased the related tax expense, and an increase of $3.5 million or 30.3% in indirect facilities costs such as rental costs, utility costs, and depreciation costs. Additionally, there was a $0.8 million or 15.2% increase in consulting fees, driven by greater use of external consultants to support and enhance our financing activities and other initiatives. These increases were partially offset by a $4.6 million or 39.5% reduction in legal fees driven by the absence of litigation fees due to resolved legal matters.

[0001375365-26-000007:mdna:75]
Comparison of the Six Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:76]
Research and development expenses. The $63.6 million or 21.9% increase in research and development expenses was primarily driven by an increase in employee-related costs of $60.1 million, or 22.1%, mainly comprised of a $36.2 million, or 21.8%, increase in salaries, and a $29.6 million, or 33.9%, increase in stock-based compensation, as we expanded our workforce and invested in key talent to support our global growth across regions.

[0001375365-26-000007:mdna:77]
Sales and marketing expenses. The $27.4 million or 18.5% decrease in sales and marketing expenses was primarily driven by a $28.8 million, or 268.3%, higher marketing development fund received from certain business partners related to co-marketing and advertising events to promote products, which reduced sales and marketing expense, and a $15.7 million, or 36.7%, decrease in normal marketing and advertising activities the six months ended December 31, 2025 as compared to the six months ended December 31, 2024. These decreases along with other minor cost decreases were partially offset by an increase in employee-related costs, mainly due to a $12.2 million, or 14.1%, increase in salaries and a $4.1 million, or 23.7%, increase in stock-based compensation, similar to our research and development expenses as we expanded our workforce and invested in key talent company-wide.

[0001375365-26-000007:mdna:78]
General and administrative expenses. The $5.4 million or 4.2% increase in general and administrative expenses was primarily attributable to a $7.1 million or 30.3% increase in indirect facilities costs such as rental costs, utility costs, and depreciation costs, a $4.3 million or 104.7% increase in excise and franchise tax expense directly related to the increase in sales compared to prior-year quarter which increased the related tax expense, a $2.9 million or  27.3% increase in consulting fees, driven by greater use of external consultants to support and enhance our financing activities and other initiatives. Additionally, there was a $1.9 million or 3.2% net increase in employee-related costs including salaries, bonus, and stock-based compensation as we expanded our workforce and invested in key talent. These increases were partially offset by a $6.6 million or 51.3%  reduction in audit and tax fees, driven by an absence of additional costs related to the delayed filing of our fiscal 2024 Form 10-K, and a $5.3 million or 30.0% reduction in legal fees driven by the absence of litigation fees due to resolved matters.

[0001375365-26-000007:mdna:79]
SMCI | Q2 2026 Form 10-Q | 44

[0001375365-26-000007:mdna:80]
Other Income, Net, Interest Income, and Interest Expense

[0001375365-26-000007:mdna:81]
Other income, net, interest income, and interest expense for the three and six months ended December 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-26-000007:mdna:82]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Other income, net | $ | 0.2 |  |  | $ | 4.2 |  |  | $ | (4.0) |  |  | (95.2) | % |  | $ | 0.1 |  |  | $ | 3.4 |  |  | $ | (3.3) |  |  | (97.1) | % |
| Percentage of total net sales | — | % |  | 0.1 | % |  |  |  |  |  | — | % |  | 0.1 | % |  |  |  |  |
| Interest income | 51.0 |  |  | 8.8 |  |  | 42.2 |  |  | 479.5 | % |  | 102.4 |  |  | 16.8 |  |  | 85.6 |  |  | 509.5 | % |
| Percentage of total net sales | 0.4 | % |  | 0.1 | % |  |  |  |  |  | 0.6 | % |  | 0.1 | % |  |  |  |  |
| Interest expense | (25.3) |  |  | (6.5) |  |  | (18.8) |  |  | 289.2 | % |  | (50.3) |  |  | (23.9) |  |  | (26.4) |  |  | 110.5 | % |
| Percentage of total net sales | (0.2) | % |  | (0.1) | % |  |  |  |  |  | (0.3) | % |  | (0.2) | % |  |  |  |  |
| Other income, net and interest expense | $ | 25.9 |  |  | $ | 6.5 |  |  | $ | 19.4 |  |  | 298.5 | % |  | $ | 52.2 |  |  | $ | (3.7) |  |  | $ | 55.9 |  |  | (1,510.8) | % |

[0001375365-26-000007:mdna:83]
Comparison of the Three Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:84]
The $4.0 million or 95.2% decrease in other income, net was primarily driven by unfavorable foreign currency exchange rate fluctuations resulting from a weaker U.S. dollar during the three months ended December 31, 2025.

[0001375365-26-000007:mdna:85]
The $42.2 million or 479.5% increase in interest income, net for the three months ended December 31, 2025 as compared to the three months ended December 31, 2024, was primarily driven by higher interest income as a result of increased cash deposits funded by the proceeds from our convertible notes issuance.

[0001375365-26-000007:mdna:86]
The $18.8 million or 289.2% increase in interest expense was primarily driven by a $22.7 million or 2012.3% increase in interest and amortization related to the amendment of the 2029 Convertible Notes and new issuance of the 2028 Convertible Notes and the 2030 Convertible Notes during the second half of fiscal 2025. This increase was partially offset by a $3.6 million or 70.6% decrease in interest expense associated with our Bank of America line of credit and term loans, which were fully repaid in November 2024.

[0001375365-26-000007:mdna:87]
Comparison of the Six Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:88]
The $3.3 million or 97.1% decrease in other income, net was primarily driven by a $13.7 million impairment loss related to our non-marketable investments during the six months ended December 31, 2025. This decrease along with other minor decreases were partially offset by a $7.9 million or 755.0% gain from mark-to-market adjustments on a marketable equity securities investment for the six months ended December 31, 2025 as compared to the six months ended December 31, 2024.

[0001375365-26-000007:mdna:89]
The $85.6 million or 509.5% increase in interest income was primarily driven by higher interest income. This is mainly comprised of an increase of $85.6 million or 510.1% in interest income for the six months ended December 31, 2025 as compared to the six months ended December 31, 2024, reflecting increased cash deposits funded by the proceeds from our convertible notes issuance.

[0001375365-26-000007:mdna:90]
The $26.4 million or 110.5% increase in interest expense was primarily driven by a $44.5 million or 1500.0% increase in interest and amortization related to the amendment of the 2029 Convertible Notes and new issuance of the 2028 Convertible Notes and the 2030 Convertible Notes during the second half of fiscal 2025. This increase was partially offset by a $17.9 million or 88.3% decrease in interest expense associated with our Bank of America line of credit and term loans, which were fully repaid in November 2024.

[0001375365-26-000007:mdna:91]
SMCI | Q2 2026 Form 10-Q | 45

[0001375365-26-000007:mdna:92]
[same as prior period, unchanged from 0001375365-25-000030:mdna:82]

[0001375365-26-000007:mdna:93]
Income tax provision and effective tax rates for the three months ended December 31, 2025 and 2024 are as follows (dollars in millions):

[0001375365-26-000007:mdna:94]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2025 |  | 2024 |  | $ |  | % |  | 2025 |  | 2024 |  | $ |  | % |
| Income tax provision | $ | (99.1) |  |  | $ | (57.0) |  | $ | (42.1) |  |  | 73.9 | % |  | $ | (139.3) |  | $ | (131.7) |  | $ | (7.6) |  |  | 5.8 | % |
| Percentage of total net sales | (0.8) | % |  | (1.0) | % |  |  |  |  |  | (0.8) | % |  | (1.1) | % |  |  |  |  |
| Effective tax rate | (19.8) | % |  | (15.2) | % |  |  |  |  |  | (19.7) | % |  | (15.1) | % |  |  |  |  |

[0001375365-26-000007:mdna:95]
Comparison of the Three Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:96]
Income tax provision increased by $42.1 million or 73.9% primarily due to an increase in worldwide income before income tax provision that increased tax expense by $26.4 million, and a lower tax benefit from stock-based compensation of approximately $9.2 million, an increase of state tax expense by $11.8 million, and offset by the effects of other immaterial tax items of approximately $5.2 million. The income before income tax provision for the second quarter of fiscal 2026 was $500.2 million, which is an increase of $125.0 million or 33.4%.

[0001375365-26-000007:mdna:97]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended December 31, 2025, is higher than that for the three months ended December 31, 2024, primarily due to a significant decrease in stock-based compensation tax deduction and lower research tax credit because of lower stock vesting price in the three months ended December 31, 2025.

[0001375365-26-000007:mdna:98]
Comparison of the Six Months Ended December 31, 2025 and 2024

[0001375365-26-000007:mdna:99]
Income tax provision increased by $7.6 million or 5.8% primarily due to a decline in worldwide income before income tax provision that reduced tax expense by $33.7 million which was offset by a lower tax benefit from stock-based compensation of approximately $23.7 million, an increase of state tax expense by $10.9 million, and the effects of other immaterial tax items of approximately $6.7 million. The income before income tax provision for the six months ended December 31, 2025 was $708.8 million, which is a decrease of $165.3 million or 18.9%.

[0001375365-26-000007:mdna:100]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the six months ended December 31, 2025, is higher than that for the six months ended December 31, 2024, primarily due to a significant decrease in stock-based compensation tax deduction and lower research tax credit because of lower stock vesting price in the six months ended December 31, 2025.

[0001375365-26-000007:mdna:101]
[same as prior period, unchanged from 0001375365-25-000030:mdna:88]

[0001375365-26-000007:mdna:102]
We have financed our growth primarily with funds generated from operations, as well as utilizing borrowing facilities, selling our common stock, and issuing convertible notes. Recent drivers of liquidity changes included an increase in the need for working capital due to higher levels of inventory required to support future growing revenues, greater requests for longer payment terms from customers due to increasing system costs and to a lesser extent longer supply chain lead times on certain key components. Our cash and cash equivalents were $4.1 billion and $5.2 billion as of December 31, 2025 and June 30, 2025, respectively. Our cash and cash equivalents held in foreign locations was $616.3 million and $607.2 million as of December 31, 2025 and June 30, 2025, respectively.

[0001375365-26-000007:mdna:103]
SMCI | Q2 2026 Form 10-Q | 46

[0001375365-26-000007:mdna:104]
[same as prior period, unchanged from 0001375365-25-000030:mdna:90]

[0001375365-26-000007:mdna:105]
[same as prior period, unchanged from 0001375365-25-000030:mdna:91]

[0001375365-26-000007:mdna:106]
[same as prior period, unchanged from 0001375365-25-000030:mdna:93]

[0001375365-26-000007:mdna:107]
|  | Six Months Ended December 31, |  | Change |  |  |  |
|  | 2025 |  | 2024 |  | $ |  |  |  |
| Net cash (used in) provided by operating activities | $ | (941.4) |  |  | $ | 169.1 |  |  | $ | (1,110.5) |  |  |  |  |
| Net cash used in investing activities | (78.5) |  |  | (71.8) |  |  | (6.7) |  |  |  |  |
| Net cash provided by (used in) financing activities | 47.5 |  |  | (337.4) |  |  | 384.9 |  |  |  |  |
| Effect of exchange rate fluctuations on cash | (6.2) |  |  | 0.8 |  |  | (7.0) |  |  |  |  |
| Net decrease in cash, cash equivalents and restricted cash | $ | (978.6) |  |  | $ | (239.3) |  |  | $ | (739.3) |  |  |  |  |

[0001375365-26-000007:mdna:108]
[same as prior period, unchanged from 0001375365-25-000030:mdna:95]

[0001375365-26-000007:mdna:109]
Net cash used in operating activities during the six months ended December 31, 2025 mostly consisted of $568.8 million net income adjusted for certain non-cash items, such as $179.6 million of stock-based compensation expense, $25.4 million of depreciation and amortization expense, and changes in working capital. The decrease in cash flows from operating activities during the six months ended December 31, 2025 compared to the six months ended December 31, 2024 was due to an increase in inventory purchases, accounts receivables from customers, and other operational spending, partially offset by higher stock-based compensation and an increase in net income.

[0001375365-26-000007:mdna:110]
[same as prior period, unchanged from 0001375365-25-000030:mdna:97]

[0001375365-26-000007:mdna:111]
Net cash used in investing activities during the six months ended December 31, 2025 mostly consisted of $53.5 million of purchases of property, plant, and equipment as we continued to invest in real estate, servers, data centers, and network infrastructure, as well as investments made in equity securities of $25.0 million. The increase in cash used in investing activities during the six months ended December 31, 2025 compared to the six months ended December 31, 2024, was mostly due to increases in purchases of property, plant, and equipment.

[0001375365-26-000007:mdna:112]
[same as prior period, unchanged from 0001375365-25-000030:mdna:99]

[0001375365-26-000007:mdna:113]
Net cash provided by financing activities during the six months ended December 31, 2025 mostly consisted of net proceeds from lines of credit and term loans of $115.4 million, partially offset by payment for withholding taxes related to settlement of equity awards of $71.1 million. The increase in cash provided by financing activities during the six months ended December 31, 2025 compared to the six months ended December 31, 2024, was mostly due to an increase in net proceeds from lines of credits and term loans.

[0001375365-26-000007:mdna:114]
[same as prior period, unchanged from 0001375365-25-000030:mdna:101]

[0001375365-26-000007:mdna:115]
Refer to Note 7, “Lines of Credit, Revolving Credit Facilities, and Term Loans”, in the notes to the condensed consolidated financial statements in this Quarterly Report for further information on our outstanding debt.

[0001375365-26-000007:mdna:116]
SMCI | Q2 2026 Form 10-Q | 47

[0001375365-26-000007:mdna:117]
[same as prior period, unchanged from 0001375365-25-000030:mdna:103]

[0001375365-26-000007:mdna:118]
[same as prior period, unchanged from 0001375365-25-000030:mdna:104]

[0001375365-26-000007:mdna:119]
[same as prior period, unchanged from 0001375365-25-000030:mdna:105]

[0001375365-26-000007:mdna:120]
[same as prior period, unchanged from 0001375365-25-000030:mdna:107]

[0001375365-26-000007:mdna:121]
[same as prior period, unchanged from 0001375365-25-000030:mdna:108]

[0001375365-26-000007:mdna:122]
Our estimated future obligations as of December 31, 2025, include both current and long-term obligations. For our long-term debt, as noted in Note 7, “Lines of Credit, Revolving Credit Facilities, and Term Loans” in the notes to the condensed consolidated financial statements, we have a current obligation of $201.8 million and a long-term obligation of $21.4 million. Additionally, as noted in Note 8, “Convertible Notes” in the notes to the condensed consolidated financial statements, we have a convertible debt obligation of $4,725.0 million. Under our operating leases as noted in Note 9, “Leases” in the notes to the condensed consolidated financial statements, we have a current obligation of $31.8 million and a long-term obligation of $354.1 million. As noted in Note 13, “Commitments and Contingencies” in the notes to the condensed consolidated financial statements, we have current obligations related to non-cancelable purchase commitments of $3.9 billion.

[0001375365-26-000007:mdna:123]
[same as prior period, unchanged from 0001375365-25-000030:mdna:110]

[0001375365-26-000007:mdna:124]
[same as prior period, unchanged from 0001375365-25-000030:mdna:111]

[0001375365-26-000007:mdna:125]
SMCI | Q2 2026 Form 10-Q | 48
