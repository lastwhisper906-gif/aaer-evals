# SMCI notes — 0001375365-26-000007


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-26-000007:notes:1]
[same as prior period, unchanged from 0001375365-25-000030:notes:2]

[0001375365-26-000007:notes:2]
[same as prior period, unchanged from 0001375365-25-000030:notes:3]

[0001375365-26-000007:notes:3]
[same as prior period, unchanged from 0001375365-25-000030:notes:4]

[0001375365-26-000007:notes:4]
[same as prior period, unchanged from 0001375365-25-000030:notes:5]

[0001375365-26-000007:notes:5]
[same as prior period, unchanged from 0001375365-25-000030:notes:6]

[0001375365-26-000007:notes:6]
Revenue Recognition

[0001375365-26-000007:notes:7]
We generate revenues from the sale of server and storage systems, subsystems, accessories and services.

[0001375365-26-000007:notes:8]
Product sales. We recognize revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is required. Determining the point in time that control transfers to the customer requires judgment. Products sold by us are shipped from our facilities or drop shipped from our vendors. We may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-26-000007:notes:9]
We apply judgment in determining the transaction price as our contracts may include forms of variable consideration, including customer rebates, returns, and cash discounts for prompt payment. Variable consideration is estimated using either the expected value or most likely amount method, depending on which method better predicts the amount of consideration to which we expect to be entitled. We include estimated variable consideration in the transaction price only to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Estimates of variable consideration are reassessed each reporting period and recorded as an adjustment to revenue, as applicable.

[0001375365-26-000007:notes:10]
Services sales. Our sale of services mainly consists of extended warranty and on-site services as well as system rack installation and integration services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as we stand ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Revenue related to system rack installation and integration services is recognized when we perform the services and the customer receives and consumes the benefits.

[0001375365-26-000007:notes:11]
Contracts with multiple promised goods and services. Certain of our contracts contain multiple promised goods and services. We assess whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from us, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation.

[0001375365-26-000007:notes:12]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. For contracts that contain multiple performance obligations, we allocate the transaction price for each customer contract to each performance obligation based on the relative Stand-alone Selling Price ("SSP") for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. We determine SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, we apply judgment to estimate the SSP. For all performance obligations, we are able to establish the SSP by maximizing the use of observable inputs. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-26-000007:notes:13]
Our credit terms are predominantly short-term in nature; however, we also grant extended payment terms for certain customers. For the contracts with the extended payment terms in which the financing component is determined to be significant to the contract, the contract transaction price is adjusted for the effect of a financing component.

[0001375365-26-000007:notes:14]
When we receive consideration from a customer prior to transferring goods or services to the customer, we record a contract liability (deferred revenue). We also recognize deferred revenue when we have an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-26-000007:notes:15]
Shipping and handling fees collected from customers are included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. We have elected to account for shipping and handling activities that occur after the customer has obtained control of a good as a fulfillment cost rather than as an additional promised service. Taxes imposed by governmental authorities on our revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

[0001375365-26-000007:notes:16]
For our other significant accounting policies, refer to our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.

[0001375365-26-000007:notes:17]
[same as prior period, unchanged from 0001375365-25-000030:notes:8]

[0001375365-26-000007:notes:18]
[same as prior period, unchanged from 0001375365-25-000030:notes:9]

[0001375365-26-000007:notes:19]
We believe that the concentration of credit risk in our trade receivables is substantially mitigated by our credit evaluation process, relatively short collection terms and the high level of credit worthiness of our customers. For customers including distributors and direct customers, we perform ongoing credit evaluations of their financial conditions and limit the amount of credit extended when deemed necessary based upon payment history and their current credit worthiness, but we generally require no collateral other than the products that we deliver to them, in which we sometimes hold a purchase money security interest under our standard terms. We regularly review the allowance for credit losses by considering factors such as

[0001375365-26-000007:notes:20]
historical experience, credit quality, reasonable and supportable forecasts, age of the accounts receivable balances and current economic conditions that may affect a customer’s ability to pay.

[0001375365-26-000007:notes:21]
[same as prior period, unchanged from 0001375365-25-000030:notes:11]

[0001375365-26-000007:notes:22]
|  | December 31, 2025 |  | June 30, 2025 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 71.6% |  | * |
| Customer B | 12.9% |  | 33.4% |
| Customer C | * |  | 13.6% |

[0001375365-26-000007:notes:23]
^The customer references of A-C above may represent different customers than those reported in a previous period.

[0001375365-26-000007:notes:24]
[same as prior period, unchanged from 0001375365-25-000030:notes:14]

[0001375365-26-000007:notes:25]
[same as prior period, unchanged from 0001375365-25-000030:notes:15]

[0001375365-26-000007:notes:26]
[same as prior period, unchanged from 0001375365-25-000030:notes:16]

[0001375365-26-000007:notes:27]
[same as prior period, unchanged from 0001375365-25-000030:notes:17]

[0001375365-26-000007:notes:28]
[same as prior period, unchanged from 0001375365-25-000030:notes:18]

[0001375365-26-000007:notes:29]
As of December 31, 2025, no receivables have been sold under the agreement.

[0001375365-26-000007:notes:30]
[same as prior period, unchanged from 0001375365-25-000030:notes:20]

[0001375365-26-000007:notes:31]
In March 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2024-02 which removes references to the FASB’s concepts statements from the FASB Accounting Standards Codification. The ASU is part of the FASB’s standing project to make “Codification updates for technical corrections such as conforming amendments, clarifications to guidance, simplifications to wording or the structure of guidance, and other minor improvements.” The amendments in this update are effective for public business entities for fiscal years beginning after December 15, 2024. For all other entities, the amendments are effective for fiscal years beginning after December 15, 2025. We adopted ASU 2024-02 on July 1, 2025, which did not have a material impact on our condensed consolidated financial statements and related disclosures.

[0001375365-26-000007:notes:32]
[same as prior period, unchanged from 0001375365-25-000030:notes:22]

[0001375365-26-000007:notes:33]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending June 30, 2026.

[0001375365-26-000007:notes:34]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements other than additional disclosures.

[0001375365-26-000007:notes:35]
In May 2025, the FASB issued ASU 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810): Determining the Accounting Acquirer in the Acquisition of a Variable Interest Entity, which revises current guidance for determining the accounting acquirer for a transaction effected primarily by exchanging equity interests in which the legal acquiree is a variable interest entity that meets the definition of a business. The amendments require that an entity consider the same factors that are currently required for determining which entity is the accounting acquirer in other acquisition transactions. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-26-000007:notes:36]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments–Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides all entities with a practical expedient and entities other than public business entities with an accounting policy election when applying the guidance in Topic 326, Financial Instruments–Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. The ASU is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2026. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-26-000007:notes:37]
In November 2025, the FASB issued ASU 2025-08, Financial Instruments–Credit Losses (Topic 326): Purchased Loans, which expands the population of acquired financial assets subject to the gross-up approach in Topic 326. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

[0001375365-26-000007:notes:38]
In December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270): Narrow-scope Improvements. This update makes targeted, narrow-scope improvements to the interim reporting guidance in Topic 270 to clarify application and improve consistency in practice. The amendments do not change the underlying principles of interim reporting. The ASU is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for interim reporting periods beginning in our fiscal year beginning July 1, 2028. We are currently evaluating the effects of ASU on our condensed consolidated financial statements and disclosures.

[0001375365-26-000007:notes:39]
In December 2025, the FASB issued ASU 2025-12, Codification Improvements, which includes 33 technical corrections, clarifications, and minor refinements across multiple ASC Topics intended to improve consistency and usability of U.S. GAAP. Transition is applied on an issue-by-issue basis: the EPS clarification (ASC 260, Issue 4) is applied retrospectively to all prior periods presented, while all other amendments may be applied prospectively or retrospectively, with appropriate disclosures about the nature/reason for the change (and additional disclosures if applied retrospectively). The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We are currently evaluating the effects of ASU on our condensed consolidated financial statements and disclosures.

[0001375365-26-000007:notes:40]
[same as prior period, unchanged from 0001375365-25-000030:notes:27]

[0001375365-26-000007:notes:41]
[same as prior period, unchanged from 0001375365-25-000030:notes:28]


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001375365-26-000007:notes:42]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Percentage of total net sales |  |  |  |  |  |  |  |
| Customer A | 62.6% |  | 30.6% |  | 45.1% |  | 21.0% |
| Customer B | * |  | 27.1% |  | * |  | 23.9% |
| Customer C | * |  | * |  | * |  | 14.9% |

[0001375365-26-000007:notes:43]
^The customer references of A-C above may represent different customers than those reported in a previous period.
*Below 10%


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-26-000007:notes:44]
[same as prior period, unchanged from 0001375365-25-000030:notes:31]

[0001375365-26-000007:notes:45]
[same as prior period, unchanged from 0001375365-25-000030:notes:32]

[0001375365-26-000007:notes:46]
[same as prior period, unchanged from 0001375365-25-000030:notes:33]

[0001375365-26-000007:notes:47]
Additionally, the CODM reviews significant segment expenses including the inventory valuation adjustment write-downs, recorded to cost of sales, which is separately disclosed in Note 6, “Balance Sheet Components”, and stock-based compensation, which is separately disclosed in Note 11, “Stock-based Compensation and Stockholders’ Equity” in the notes to the condensed consolidated financial statements.

[0001375365-26-000007:notes:48]
[same as prior period, unchanged from 0001375365-25-000030:notes:35]

[0001375365-26-000007:notes:49]
[same as prior period, unchanged from 0001375365-25-000030:notes:36]

[0001375365-26-000007:notes:50]
Total revenue recognized from all services and software for the three months ended December 31, 2025 and 2024 was $140.4 million and $76.9 million, respectively. Of this, revenue related to services recognized on an over time basis during the contract term was $104.1 million and $54.4 million for the three months ended December 31, 2025 and 2024, respectively.

[0001375365-26-000007:notes:51]
Total revenue recognized from all service and software for the six months ended December 31, 2025 and 2024 was $228.0 million and $172.7 million, respectively. Of this, revenue related to services recognized on an over time basis during the contract term was $176.0 million and $104.6 million for the six months ended December 31, 2025 and 2024, respectively.

[0001375365-26-000007:notes:52]
[same as prior period, unchanged from 0001375365-25-000030:notes:38]

[0001375365-26-000007:notes:53]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | % of Total |  | 2024 |  | % of Total |  | 2025 |  | % of Total |  | 2024 |  | % of Total |
| United States | $ | 10,928,946 |  |  | 86.2 | % |  | $ | 3,846,960 |  |  | 67.8 | % |  | $ | 12,763,423 |  |  | 72.1 | % |  | $ | 8,088,309 |  |  | 69.6 | % |
| Other (1) | 1,753,545 |  |  | 13.8 | % |  | 1,831,002 |  |  | 32.2 | % |  | 4,936,858 |  |  | 27.9 | % |  | 3,526,909 |  |  | 30.4 | % |
| Total | $ | 12,682,491 |  |  | 100.0 | % |  | $ | 5,677,962 |  |  | 100.0 | % |  | $ | 17,700,281 |  |  | 100.0 | % |  | $ | 11,615,218 |  |  | 100.0 | % |

[0001375365-26-000007:notes:54]
[same as prior period, unchanged from 0001375365-25-000030:notes:40]

[0001375365-26-000007:notes:55]
[same as prior period, unchanged from 0001375365-25-000030:notes:41]

[0001375365-26-000007:notes:56]
[same as prior period, unchanged from 0001375365-25-000030:notes:42]

[0001375365-26-000007:notes:57]
Generally, the payment terms of our offerings range from 30 to 60 days, however occasionally we might offer longer payment terms to certain customers. In certain instances, customers may prepay for products and services in advance of delivery. Receivables represent our unconditional right to consideration for performance obligations that are either partially or fully completed.

[0001375365-26-000007:notes:58]
Contract assets are rights to consideration in exchange for goods or services that we have transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets have not been material to our condensed consolidated financial statements.

[0001375365-26-000007:notes:59]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede our satisfaction of the associated performance obligations. Our deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2025, which was included in the opening deferred revenue balance as of June 30, 2025 of $731.4 million, was $63.0 million and $245.8 million, respectively. Revenue recognized during the three and six months ended December 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2024 of $416.4 million, was $47.3 million and $115.5 million, respectively.

[0001375365-26-000007:notes:60]
[same as prior period, unchanged from 0001375365-25-000030:notes:46]

[0001375365-26-000007:notes:61]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. We apply the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, integration services, and extended warranty services, that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to the remaining performance obligations as of December 31, 2025 was approximately $1,302.8 million. We expect to recognize approximately 59% of such value in the next 12 months, and the remainder thereafter.


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-26-000007:notes:62]
[same as prior period, unchanged from 0001375365-25-000030:notes:48]

[0001375365-26-000007:notes:63]
[same as prior period, unchanged from 0001375365-25-000030:notes:49]

[0001375365-26-000007:notes:64]
[same as prior period, unchanged from 0001375365-25-000030:notes:50]

[0001375365-26-000007:notes:65]
[same as prior period, unchanged from 0001375365-25-000030:notes:51]

[0001375365-26-000007:notes:66]
The following table sets forth our financial instruments as of December 31, 2025 and June 30, 2025, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-26-000007:notes:67]
|  | As of December 31, 2025 |  | As of June 30, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Asset at Fair Value |  | Level 1 |  | Level 2 |  | Level 3 |  | Asset at Fair Value |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 42 |  |  | $ | — |  |  | $ | — |  |  | $ | 42 |  |  | $ | 44 |  |  | $ | — |  |  | $ | — |  |  | $ | 44 |  |
| Certificates of deposit | — |  |  | 100,498 |  |  | — |  |  | 100,498 |  |  | — |  |  | 519 |  |  | — |  |  | 519 |  |
| Marketable equity security | 15,192 |  |  | — |  |  | — |  |  | 15,192 |  |  | 6,239 |  |  | — |  |  | — |  |  | 6,239 |  |
| Available-for-Sale Investment: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Auction rate security (2) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,750 |  |  | 1,750 |  |
| Total assets | $ | 15,234 |  |  | $ | 100,498 |  |  | $ | — |  |  | $ | 115,732 |  |  | $ | 6,283 |  |  | $ | 519 |  |  | $ | 1,750 |  |  | $ | 8,552 |  |

[0001375365-26-000007:notes:68]
(1) All of the money market funds are included in cash and cash equivalents in the condensed consolidated balance sheets as of December 31, 2025 and June 30, 2025, respectively.

[0001375365-26-000007:notes:69]
(2) Our fair value of auction rate security was immaterial as of period ended December 31, 2025.

[0001375365-26-000007:notes:70]
The investment in marketable equity security is carried at fair value using values available on a public exchange, is based on a Level 1 input, and is recorded in prepaid expenses and other current assets in the condensed consolidated balance sheets. The unrealized gains and losses of the investment are included in other income, net in our condensed consolidated statements of operations. For the three and six months ended December 31, 2025, an unrealized loss of $0.8 million and an unrealized gain of $7.2 million, respectively, were recorded in other income, net in the condensed consolidated statements of operations. For the three and six months ended December 31, 2024, an unrealized loss of $0.4 million and an unrealized gain of $1.0 million, respectively, were recorded in other income, net in the condensed consolidated statements of operations.

[0001375365-26-000007:notes:71]
On a quarterly basis, we also evaluate the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, current economic conditions, and reasonable economic forecasts that affect collectability. For the three and six months ended December 31, 2025 and 2024, the credit losses related to our investments were not material.

[0001375365-26-000007:notes:72]
There were no transfers between Level 1, Level 2, or Level 3 financial instruments during the three and six months ended December 31, 2025 and 2024.

[0001375365-26-000007:notes:73]
[same as prior period, unchanged from 0001375365-25-000030:notes:59]

[0001375365-26-000007:notes:74]
Accounts receivable, accounts payable, and accrued liabilities are carried at cost, which approximates fair value due to the short maturity of these instruments. We estimate the fair value of outstanding debt, including our 3.50% Convertible Senior Notes due 2029 (“2029 Convertible Notes”), 2.25% Convertible Senior Notes due 2028 (“2028 Convertible Notes”), and 0.00% Convertible Senior Notes due 2030 (“2030 Convertible Notes”), for disclosure purposes on a recurring basis. Non-current accounts receivable, included in other assets in the condensed consolidated balance sheets, are carried at amortized cost, and bear interest at rates that approximate current market rates for similar credit. We believe the carrying amounts approximate fair value because there have been no significant changes in market rates or credit risk.

[0001375365-26-000007:notes:75]
As of December 31, 2025 and June 30, 2025, our total lines of credit and term loans of $223.2 million and $112.5 million, respectively, are reported at amortized cost. The outstanding debt was categorized as Level 2 as it is not actively traded. The carrying value approximates fair value.

[0001375365-26-000007:notes:76]
The estimated fair value as of December 31, 2025 of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes were $1,543.3 million, $667.5 million, and $1,946.7 million, respectively. The estimated fair values as of June 30, 2025 of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes were $1,801.9 million, $818.5 million, and $2,576.6 million. The estimated fair value of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes was determined based on level 2 inputs of quoted market prices.


## smci:NonMarketableEquityInvestmentsTextBlock

[0001375365-26-000007:notes:77]
[same as prior period, unchanged from 0001375365-25-000030:notes:63]

[0001375365-26-000007:notes:78]
[same as prior period, unchanged from 0001375365-25-000030:notes:64]

[0001375365-26-000007:notes:79]
|  | December 31, 2025 |  | June 30, 2025 |
| Non-marketable equity securities: |  |  |  |
| Opening gross investment balance | $ | 122,217 |  |  | $ | 66,217 |  |
| Investment made during the period | 25,000 |  |  | 56,000 |  |
| Cumulative impairment adjustment | (23,600) |  |  | (11,600) |  |
| Total carrying value - before the adjustments under equity method | 123,617 |  |  | 110,617 |  |
| Securities under equity method - cumulative adjustment | (332) |  |  | — |  |
| Total carrying value | $ | 123,285 |  |  | $ | 110,617 |  |

[0001375365-26-000007:notes:80]
Our non-marketable equity securities include $92.5 million invested in an unrelated party (the "Sub-licensee") to which we have subleased the entire space in Vernon, California. The Sub-licensee does not meet the criteria of a related party. Additionally, the Sub-licensee has been a customer of ours, and we concluded that equity investment agreements and sub-licensing agreements are separate from revenue contracts as all transactions have been recorded at the respective fair values. Please refer to Note 9, “Leases” for further discussion.

[0001375365-26-000007:notes:81]
During the three and six months ended December 31, 2025, we recognized an impairment loss of $0.0 million and $12.0 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001375365-26-000007:notes:82]
[same as prior period, unchanged from 0001375365-25-000030:notes:67]

[0001375365-26-000007:notes:83]
The following table shows the computation of basic and diluted net income per common share for the three and six months ended December 31, 2025 and 2024 (in thousands, except per share amounts):

[0001375365-26-000007:notes:84]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator: |  |  |  |  |  |  |  |
| Net income - basic | $ | 400,564 |  |  | $ | 320,596 |  |  | $ | 568,849 |  |  | $ | 744,923 |  |
| Convertible notes interest charge, net of tax | 17,888 |  |  | 1,110 |  |  | 10,986 |  |  | 3,859 |  |
| Net income - diluted | $ | 418,452 |  |  | $ | 321,706 |  |  | $ | 579,835 |  |  | $ | 748,782 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 598,004 |  |  | 592,507 |  |  | 596,814 |  |  | 591,033 |  |
| Effect of dilutive convertible notes | 73,803 |  |  | 12,860 |  |  | 53,130 |  |  | 12,860 |  |
| Effect of dilutive securities | 22,182 |  |  | 30,680 |  |  | 24,124 |  |  | 33,704 |  |
| Weighted-average shares outstanding - diluted | 693,989 |  |  | 636,047 |  |  | 674,068 |  |  | 637,597 |  |
| Net income per common share - basic | $ | 0.67 |  |  | $ | 0.54 |  |  | $ | 0.95 |  |  | $ | 1.26 |  |
| Net income per common share - diluted | $ | 0.60 |  |  | $ | 0.51 |  |  | $ | 0.86 |  |  | $ | 1.17 |  |
| Anti-dilutive shares excluded from diluted net income per share: |  |  |  |  |  |  |  |
| Stock-based awards | 20,443 |  |  | 11,668 |  |  | 17,880 |  |  | 7,627 |  |
| Convertible notes | — |  |  | — |  |  | 20,673 |  |  | — |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-26-000007:notes:85]
[same as prior period, unchanged from 0001375365-25-000030:notes:70]

[0001375365-26-000007:notes:86]
[same as prior period, unchanged from 0001375365-25-000030:notes:71]

[0001375365-26-000007:notes:87]
[same as prior period, unchanged from 0001375365-25-000030:notes:72]

[0001375365-26-000007:notes:88]
|  | December 31, 2025 |  | June 30, 2025 |
| Cash and cash equivalents | $ | 4,091,083 |  |  | $ | 5,169,911 |  |
| Restricted cash included in prepaid expenses and other current assets and other assets | 102,642 |  |  | 2,390 |  |
| Total cash, cash equivalents and restricted cash | $ | 4,193,725 |  |  | $ | 5,172,301 |  |

[0001375365-26-000007:notes:89]
[same as prior period, unchanged from 0001375365-25-000030:notes:74]

[0001375365-26-000007:notes:90]
|  | December 31, 2025 |  | June 30, 2025 |
| Finished goods | $ | 7,510,625 |  |  | $ | 3,465,352 |  |
| Work in process | 2,331,526 |  |  | 674,613 |  |
| Purchased parts and raw materials | 753,297 |  |  | 540,410 |  |
| Total inventories | $ | 10,595,448 |  |  | $ | 4,680,375 |  |

[0001375365-26-000007:notes:91]
During the three months ended December 31, 2025 and 2024, we recorded write down adjustments for excess and obsolete inventory and lower of cost and net realizable value adjustments to cost of sales totaling $132.9 million and $24.9 million, respectively, and recorded adjustments totaling $169.1 million and $34.0 million, respectively, during the six months ended December 31, 2025 and 2024.

[0001375365-26-000007:notes:92]
[same as prior period, unchanged from 0001375365-25-000030:notes:77]

[0001375365-26-000007:notes:93]
|  | December 31, 2025 |  | June 30, 2025 |
| Land | $ | 172,328 |  |  | $ | 162,848 |  |
| Buildings | 186,781 |  |  | 182,466 |  |
| Machinery and equipment | 132,447 |  |  | 111,331 |  |
| Building and leasehold improvements | 129,174 |  |  | 121,665 |  |
| Furniture and fixtures | 41,439 |  |  | 36,268 |  |
| Software | 7,346 |  |  | 7,117 |  |
| Construction in progress | 11,527 |  |  | 1,038 |  |
| Property, plant, and equipment, gross | 681,042 |  |  | 622,733 |  |
| Accumulated depreciation and amortization | (142,458) |  |  | (118,245) |  |
| Property, plant, and equipment, net | $ | 538,584 |  |  | $ | 504,488 |  |

[0001375365-26-000007:notes:94]
Depreciation expense for the three months ended December 31, 2025 and 2024 was $12.8 million and $9.5 million, respectively, and for the six months ended December 31, 2025 and 2024 was $24.9 million and $18.5 million, respectively.

[0001375365-26-000007:notes:95]
[same as prior period, unchanged from 0001375365-25-000030:notes:80]

[0001375365-26-000007:notes:96]
|  | December 31, 2025 |  | June 30, 2025 |
| Non-current accounts receivable | $ | 141,128 |  |  | $ | 166,405 |  |
| Operating lease ROU asset | 370,095 |  |  | 293,692 |  |
| Long-term investments | 123,288 |  |  | 112,367 |  |
| Deferred service costs, non-current | 11,483 |  |  | 10,713 |  |
| Deposits | 3,669 |  |  | 4,980 |  |
| Restricted cash, non-current | 2,642 |  |  | 2,390 |  |
| Other | 30,757 |  |  | 14,324 |  |
| Total other assets | $ | 683,062 |  |  | $ | 604,871 |  |

[0001375365-26-000007:notes:97]
[same as prior period, unchanged from 0001375365-25-000030:notes:82]

[0001375365-26-000007:notes:98]
|  | December 31, 2025 |  | June 30, 2025 |
| Accrued payroll and related expenses | $ | 96,122 |  |  | $ | 82,156 |  |
| Customer deposits | 122,032 |  |  | 260,131 |  |
| Accrued cooperative marketing expenses | 40,418 |  |  | 26,775 |  |
| Accrued warranty costs | 15,191 |  |  | 9,753 |  |
| Operating lease liability | 31,823 |  |  | 21,189 |  |
| Accrued professional fees | 5,189 |  |  | 8,098 |  |
| Accrued interest - convertible notes | 27,388 |  |  | 27,701 |  |
| Customer-related liabilities | 34,523 |  |  | 32,858 |  |
| Input tax payable | 53,249 |  |  | 39,161 |  |
| Accrued tariff | 66,563 |  |  | 18,012 |  |
| Other | 55,681 |  |  | 39,803 |  |
| Total accrued liabilities | $ | 548,179 |  |  | $ | 565,637 |  |

[0001375365-26-000007:notes:99]
[same as prior period, unchanged from 0001375365-25-000030:notes:84]

[0001375365-26-000007:notes:100]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Balance, beginning of the period | $ | 21,264 |  |  | $ | 17,953 |  |  | $ | 16,954 |  |  | $ | 17,815 |  |
| Provision for warranty | 54,313 |  |  | 17,162 |  |  | 71,215 |  |  | 28,695 |  |
| Costs utilized | (52,662) |  |  | (15,855) |  |  | (65,535) |  |  | (26,853) |  |
| Change in estimated liability for pre-existing warranties | 97 |  |  | (972) |  |  | 378 |  |  | (1,369) |  |
| Balance, end of the period | $ | 23,012 |  |  | $ | 18,288 |  |  | $ | 23,012 |  |  | $ | 18,288 |  |

[0001375365-26-000007:notes:101]
[same as prior period, unchanged from 0001375365-25-000030:notes:86]


## us-gaap:DebtDisclosureTextBlock

[0001375365-26-000007:notes:102]
Note 7.                 Lines of Credit, Revolving Credit Facilities, and Term Loans

[0001375365-26-000007:notes:103]
Short-term and long-term loan obligations with respect to lines of credit and term loans as of December 31, 2025 and June 30, 2025 consisted of the following (in thousands):

[0001375365-26-000007:notes:104]
|  | December 31, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 57,389 |  |  | $ | — |  |
| E.SUN Bank Credit Lines | 60,000 |  |  | 30,000 |  |
| Mega Bank Credit Lines | 30,000 |  |  | — |  |
| First Bank Credit Lines | 19,934 |  |  | — |  |
| Total line of credit | 167,323 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 6,642 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 24,140 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 983 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 7,652 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 6,908 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 9,565 |  |  | 17,098 |  |
| Total term loans | 55,890 |  |  | 82,475 |  |
| Total lines of credit and term loans | $ | 223,213 |  |  | $ | 112,475 |  |
| Lines of credit and current portion of term loans | $ | 201,776 |  |  | $ | 75,060 |  |
| Term loans, non-current | $ | 21,437 |  |  | $ | 37,415 |  |

[0001375365-26-000007:notes:105]
Activities under Lines of Credit, Revolving Credit Facilities, and Term Loans

[0001375365-26-000007:notes:106]
Available borrowings and interest rates as of December 31, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):

[0001375365-26-000007:notes:107]
|  | December 31, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 127,611 |  |  | 2.14% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 25,240 |  |  | 1.88% - 4.48% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | — |  |  | 2.02% - 4.56% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 20,000 |  |  | 1.90% - 4.50% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 66 |  |  | 2.03% - 4.49% |  | $ | — |  |  | n/a |
| JP Morgan Revolving Credit Facility | $ | 2,000,000 |  |  | 4.84% - 5.87% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |

[0001375365-26-000007:notes:108]
See Note 7, “Lines of Credit, Revolving Credit Facilities, and Term Loans” of our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 for a more complete description of our credit facilities.

[0001375365-26-000007:notes:109]
Principal payments on lines of credit and term loans are due as follows (in thousands):

[0001375365-26-000007:notes:110]
| Fiscal Year: |  | Principal Payments |
| Remainder of 2026 |  | $ | 188,329 |  |
| 2027 |  | 18,252 |  |
| 2028 |  | 6,156 |  |
| 2029 |  | 5,466 |  |
| 2030 |  | 5,010 |  |
| Total lines of credit and term loans |  | $ | 223,213 |  |

[0001375365-26-000007:notes:111]
As of December 31, 2025, we were in compliance with all the covenants for the revolving lines of credit and term loans on our condensed consolidated balance sheets.

[0001375365-26-000007:notes:112]
We entered into new agreements during the six months ended December 31, 2025 with the following terms:

[0001375365-26-000007:notes:113]
Revolving Credit Facility

[0001375365-26-000007:notes:114]
On December 29, 2025, we entered into a credit agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., (“JP Morgan”) as administrative agent and collateral agent, and a syndicate of lenders, which provides for a revolving credit facility of up to $2,000.0 million (the “Revolving Credit Facility”), including a $200.0 million letter of credit sub-limit and a $150.0 million same-day borrowing sub-limit, with an option to increase total commitments by up to $1,000.0 million subject to certain conditions. Borrowings under the Revolving Credit Facility may be used for working capital and other general corporate purposes. The upfront fees totaling $9.8 million incurred in connection with the credit agreement were capitalized as deferred cost and recorded as a non-current asset included within other assets on the condensed consolidated balance sheet as of December 31, 2025.

[0001375365-26-000007:notes:115]
As of December 31, 2025, we had no borrowings outstanding under the Revolving Credit Facility.

[0001375365-26-000007:notes:116]
Borrowings under the Revolving Credit Facility bear interest, at our option, at either an alternate base rate (“ABR”) or a term rate, in each case plus an applicable margin. The applicable margin varies based on (i) during a non-investment grade period, our leverage ratio (ranging from 1.25% to 2.00% for term rate loans and 0.25% to 1.00% for ABR loans), or (ii) during an investment grade period, our corporate family rating (ranging from 1.13% to 1.38% for term rate loans and 0.13% to 0.38% for ABR loans). We also pay a quarterly commitment fee on unused commitments ranging from 0.15% to 0.30% during a non-investment grade period (or 0.12% to 0.15% during an investment grade period). Investment grade period refers to the period beginning on the date (no earlier than September 30, 2026) when we attain an investment grade corporate family rating from at least two of Moody’s (Baa3 or higher), S&P (BBB- or higher), and Fitch (BBB- or higher), in each case with a stable or better outlook, and delivers an officer’s certificate to the administrative agent confirming such ratings, and continuing until the occurrence of a subsequent non-investment grade trigger event. The Revolving Credit Facility matures on December 29, 2030.

[0001375365-26-000007:notes:117]
During any non-investment grade period, the Revolving Credit Facility is guaranteed by us and certain qualifying domestic subsidiaries (subject to customary exclusions) and is secured by a first-priority lien on substantially all assets of the applicable loan parties (subject to customary exclusions). The Credit Agreement includes customary restrictive covenants (some of which are not applicable during an investment grade period), including limitations on indebtedness, investments, and restricted payments, and a maximum total net leverage ratio covenant of 4.00:1.00 for the first four full fiscal quarters after inception, stepping down to 3.50:1.00 for the next four full fiscal quarters, and 3.00:1.00 thereafter. The Credit Agreement contains customary events of default (including change of control), which upon occurrence may result in the acceleration of amounts outstanding and termination of lender commitments.

[0001375365-26-000007:notes:118]
Chang Hwa Bank

[0001375365-26-000007:notes:119]
Chang Hwa Bank Credit Lines

[0001375365-26-000007:notes:120]
On September 18, 2025 (the “CHB Effective Date”), our Taiwan subsidiary entered into a credit facility (the “2025 Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”) which was substantially similar to the “New Credit Facility” in 2024 to renew a Loan Contract for a general working capital loan (the “General Working Capital Loan”). The credit limit thereunder has been adjusted to a total cap of NTD 1,000.0 million, which includes $20.0 million from the Chang Hwa Bank Credit Facility, a credit limit of NTD 300.0 million (together, the “CHB Credit Lines”), and the remaining balance of “Chang Hwa Bank Term Loan Facility.”

[0001375365-26-000007:notes:121]
Terms for specific drawdown instruments issued under the 2025 Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with the Chang Hwa Bank. Under three Loan Contracts entered into on the CHB Effective Date, our Taiwan subsidiary and the Chang Hwa Bank have agreed to each of the following: (a) our Taiwan subsidiary may choose one of the following, subject to a cap of $20.0 million under the CHB Credit Lines: (i) a Loan Contract providing for the drawdown of up to $20.0 million for an import loan (the “Import Open Account O/A Loan”), with the interest rate thereunder based on Taipei Forex Inc (“TAIFX”) plus a fixed margin; or (ii) a Loan Contract providing for the drawdown of up to $20.0 million for an export loan (the “Export Open Account O/A Loan”), with the interest rate thereunder based on TAIFX plus a fixed margin; and (b) a Loan Contract for a general working capital loan (the “General Working Capital Loan”), subject to a cap of NTD 300.0 million under the CHB Credit Lines, with the interest rate set at a fixed premium to a specified one-year time savings deposit rate, subject to a floor of 1.4%. Only the Loan Contract referred to in (b) is subject to renewal or re-execution, while the other agreements under (a) remain unchanged. As of December 31, 2025, the outstanding borrowings under the Chang Hwa Bank credit line was $6.6 million.

[0001375365-26-000007:notes:122]
First Bank

[0001375365-26-000007:notes:123]
On July 18, 2025, our Taiwan subsidiary renewed the Credit Agreement and the Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”). The credit lines are reduced from $30.0 million to $20.0 million, including a sub-item credit limit of NTD 600.0 million designed for short-term working capital loans. As of December 31, 2025, the outstanding borrowings under the First Bank credit line was $19.9 million.

[0001375365-26-000007:notes:124]
Note 8.                 Convertible Notes

[0001375365-26-000007:notes:125]
The following table summarizes our convertible notes as of December 31, 2025:

[0001375365-26-000007:notes:126]
|  | Issuance Date |  | Principal (in millions) |  | Coupon Interest |  | Maturity |  | Conversion price |  | Carrying Value (in millions) |  | Effective Interest Rate |
| 2028 Convertible Notes | 2/20/2025 |  | $ | 700.0 |  |  | 2.25 | % |  | 7/15/2028 |  | $ | 61.06 |  |  | $ | 687.7 |  |  | 2.97 | % |
| 2029 Convertible Notes | 2/27/2024 |  | $ | 1,725.0 |  |  | 3.50 | % |  | 3/1/2029 |  | $ | 83.44 |  |  | $ | 1,706.4 |  |  | 3.86 | % |
| 2030 Convertible Notes | 6/23/2025 |  | $ | 2,300.0 |  |  | 0.00 | % |  | 6/15/2030 |  | $ | 55.20 |  |  | $ | 2,260.5 |  |  | 0.39 | % |

[0001375365-26-000007:notes:127]
All notes are senior unsecured obligations ranking equally in right of payment with one another and senior to any future subordinated indebtedness. Each series is convertible, at our election, into cash, shares of our common stock, or a combination thereof, and none were eligible for early conversion as of December 31, 2025.

[0001375365-26-000007:notes:128]
2029 Convertible Notes

[0001375365-26-000007:notes:129]
We issued $1,725.0 million of 0.00% Convertible Senior Notes due 2029 (“Original 2029 Notes”) in February 2024. On February 20, 2025, we executed privately negotiated subscription and supplemental indenture agreements to amend the Original 2029 Notes (the “2029 Amendments”). Key changes included (i) establishing a 3.50% annual coupon, payable semi-annually on March 1 and September 1 beginning September 2025, and (ii) adjusting the conversion rate to 11.9842 shares per $1,000 principal amount, equivalent to a conversion price of approximately $83.44 per share. All other material terms remained substantially unchanged.

[0001375365-26-000007:notes:130]
The amendment was accounted for as an extinguishment of the original debt and issuance of new debt under Accounting Standards Codification (“ASC”) 470-50, resulting in a $30.3 million extinguishment loss recorded in other income, net, during the quarter ended March 31, 2025. Debt issuance costs are amortized to interest expense using the effective interest method.

[0001375365-26-000007:notes:131]
Holders may convert their notes upon the occurrence of certain conditions, including: (1) if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) if the trading price of the notes is below 98% of the product of the stock price and conversion rate; (3) upon certain corporate events or distributions; (4) if we call the notes for redemption; or (5) at any time from and after September 1, 2028 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, at our option beginning March 1, 2027 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

[0001375365-26-000007:notes:132]
As of December 31, 2025 and June 30, 2025, unamortized issuance costs are $18.6 million and $21.3 million, respectively. The interest expense for the three months ended December 31, 2025 and 2024 totaled $16.5 million and $1.5 million, respectively, including $1.3 million and $1.5 million, respectively, from the amortization of debt issuance costs. Interest expense for the six months ended December 31, 2025 and 2024 totaled $32.9 million and $3.0 million, including $2.7 million and $3.0 million, respectively, from the amortization of debt issuance costs.

[0001375365-26-000007:notes:133]
In connection with the issuance, we entered into 2029 Capped Call Transactions with certain financial institutions to reduce potential dilution upon conversion or offset cash payments exceeding principal. The capped calls were initially structured with a $134.14 strike price and $195.10 cap price and were amended in February 2025 to reflect the updated conversion rate. The amended cap price is $94.17 per share. These instruments are equity-classified under ASC 815-40, and no incremental value was recorded upon amendment.

[0001375365-26-000007:notes:134]
2028 Convertible Notes

[0001375365-26-000007:notes:135]
On February 20, 2025, we issued $700.0 million aggregate principal amount of 2028 Convertible Notes under an indenture with U.S. Bank Trust Company, N.A., as trustee. The notes were issued concurrently with the amended 2029 Convertible Notes and are convertible, at our election, into cash, shares of common stock, or a combination of both. The initial conversion rate is 16.3784 shares per $1,000 principal amount, equivalent to a conversion price of approximately $61.06 per share.

[0001375365-26-000007:notes:136]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of our common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on our common stock, as described in the 2028 Convertible Notes Indenture; (4) if we call the 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-26-000007:notes:137]
Interest accrues from February 20, 2025, and is payable semi-annually on January 15 and July 15, beginning July 15, 2025. The notes mature on July 15, 2028, unless earlier converted, redeemed, or repurchased. Redemption may occur on or after March 1, 2026, if the stock price exceeds 150% of the conversion price for a specified period.

[0001375365-26-000007:notes:138]
The notes include customary provisions for conversion, redemption, and repurchase following a fundamental change. Upon such an event, holders may require us to repurchase all or part of their notes for cash equal to 100% of principal plus accrued interest, and the conversion rate may be increased for holders converting in connection with a qualifying corporate event or redemption.

[0001375365-26-000007:notes:139]
We accounted for the 2028 Convertible Notes as a single liability measured at amortized cost, as no embedded features required bifurcation as derivatives. As of December 31, 2025 and June 30, 2025, unamortized issuance costs are $12.3 million and $14.6 million, respectively. Interest expense for the three months ended December 31, 2025 totaled $5.1 million, including $1.2 million from the amortization of debt issuance costs. Interest expense for the six months ended December 31, 2025 totaled $10.2 million, including $2.3 million from the amortization of debt issuance costs.

[0001375365-26-000007:notes:140]
2030 Convertible Notes

[0001375365-26-000007:notes:141]
On June 23, 2025, we issued $2,300 million aggregate principal amount of 2030 Convertible Notes, including the $300.0 million overallotment option. Net proceeds were approximately $2,256.0 million after issuance costs.

[0001375365-26-000007:notes:142]
The 2030 Convertible Notes are convertible at an initial rate of 18.1154 shares per $1,000 principal amount, equivalent to a conversion price of approximately $55.20 per share. Conversion prior to December 17, 2029 is permitted only if specified conditions are met (similar to those of the 2028 Convertible Notes and the 2029 Convertible Notes). After that date, the notes become convertible at any time up to two trading days before maturity.

[0001375365-26-000007:notes:143]
Holders may convert their 2030 Convertible Notes upon the occurrence of certain conditions, including: (1) during any calendar quarter commencing after the calendar quarter ending on September 30, 2025, if our stock price exceeds 130% of the conversion price for 20 of 30 consecutive trading days; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon certain corporate events or distributions on our common stock, as described in the Indenture; (4) if we call the notes for redemption; or (5) at any time from and after December 17, 2029 until the second scheduled trading day before maturity. The notes are redeemable, in whole or in part, beginning June 15, 2028 if our stock price exceeds 130% of the conversion price for a specified period, at a price equal to the principal amount plus accrued and unpaid interest.

[0001375365-26-000007:notes:144]
As of December 31, 2025 and June 30, 2025, unamortized issuance costs are $39.5 million and $43.9 million, respectively. Interest expense for the three and six months ended December 31, 2025 totaled $2.2 million and $4.4 million, respectively, all of which are amortization of debt issuance costs.

[0001375365-26-000007:notes:145]
We entered into 2030 Capped Call Transactions with certain counterparties to mitigate dilution or cash outflows above principal upon conversion. The capped calls have an initial cap price of $81.78 per share, representing a 100% premium to the $40.89 share price on the issuance date. These instruments are equity-classified under ASC 815-40.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-26-000007:notes:146]
[same as prior period, unchanged from 0001375365-25-000030:notes:126]

[0001375365-26-000007:notes:147]
We lease offices, warehouses and other premises, vehicles and certain equipment under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and six months ended December 31, 2025 and 2024 were as follows (in thousands):

[0001375365-26-000007:notes:148]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating lease expense (including expense for lease agreements with related parties of $262 and $165 for the three months ended December 31, 2025 and 2024, respectively, and $466 and $330 for the six months ended December 31, 2025, respectively) | $ | 14,989 |  |  | $ | 3,747 |  |  | $ | 28,019 |  |  | $ | 6,973 |  |
| Cash payments for operating leases (including payments to related parties of $271 and $153 for the three months ended December 31, 2025 and 2024, respectively, and $491 and $306 for the six months ended December 31, 2025, respectively) | $ | 13,213 |  |  | $ | 3,716 |  |  | $ | 22,349 |  |  | $ | 6,579 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 3,531 |  |  | $ | 690 |  |  | $ | 94,073 |  |  | $ | 18,472 |  |

[0001375365-26-000007:notes:149]
During the three and six months ended December 31, 2025 and 2024, our costs related to short-term lease arrangements were immaterial. Variable lease payments expensed in the three and six months ended December 31, 2025 and 2024 were immaterial.

[0001375365-26-000007:notes:150]
[same as prior period, unchanged from 0001375365-25-000030:notes:130]

[0001375365-26-000007:notes:151]
|  | December 31, 2025 |  | June 30, 2025 |
| Other assets | $ | 370,095 |  |  | $ | 293,692 |  |
| Accrued liabilities | $ | 31,823 |  |  | $ | 21,189 |  |
| Other long-term liabilities | 354,055 |  |  | 280,368 |  |
| Total lease liabilities | $ | 385,878 |  |  | $ | 301,557 |  |
| Weighted average remaining lease term | 8.9 years |  | 9.1 years |
| Weighted average discount rate (1) | 5.8 | % |  | 5.8 | % |

[0001375365-26-000007:notes:152]
[same as prior period, unchanged from 0001375365-25-000030:notes:132]

[0001375365-26-000007:notes:153]
In June 2024, we entered into a lease agreement for a 21 megawatt (“MW”) data center co-location space located in Vernon, California (the “Data Center Space”) that will expire on September 30, 2035. We do not have an option to extend (or to terminate) the lease. The lease agreement consists of three tranches, with the first tranche of 6 MW having commenced on January 24, 2025, the second tranche of 9 MW commenced on May 12, 2025, and the third tranche of 6 MW commenced on August 15, 2025. As of December 31, 2025, the ROU assets and lease liabilities related to all three tranches totaled $289.6 million and $299.3 million, respectively. Variable lease payments not dependent on a rate or index associated with our leases are recognized when the event, activity, or circumstance in the lease agreement on which those payments are assessed as probable. Variable lease payments are presented as operating expenses in the condensed consolidated statements of operations.

[0001375365-26-000007:notes:154]
[same as prior period, unchanged from 0001375365-25-000030:notes:134]

[0001375365-26-000007:notes:155]
[same as prior period, unchanged from 0001375365-25-000030:notes:135]

[0001375365-26-000007:notes:156]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sublease income | $ | 10,524 |  |  | $ | — |  |  | $ | 18,657 |  |  | $ | — |  |

[0001375365-26-000007:notes:157]
As of December 31, 2025, the future total minimum Sublicense receipts expected to be received are as follows (in thousands):

[0001375365-26-000007:notes:158]
| Fiscal Year: |  | Future minimum Sublicense receipts |
| Remainder of 2026 |  | $ | 18,800 |  |
| 2027 |  | 38,348 |  |
| 2028 |  | 39,499 |  |
| 2029 |  | 40,684 |  |
| 2030 |  | 41,904 |  |
| 2031 and beyond |  | 241,533 |  |
| Total Sublicense receipts - Lessor |  | $ | 420,768 |  |

[0001375365-26-000007:notes:159]
Maturities of operating lease liabilities under non-cancelable operating lease arrangements as of December 31, 2025 were as follows (in thousands):

[0001375365-26-000007:notes:160]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2026 |  | $ | 26,974 |  |
| 2027 |  | 55,880 |  |
| 2028 |  | 55,380 |  |
| 2029 |  | 55,781 |  |
| 2030 |  | 57,320 |  |
| 2031 and beyond |  | 251,800 |  |
| Total future lease payments |  | 503,135 |  |
| Less: Imputed interest |  | (117,257) |  |
| Present value of operating lease liabilities |  | 385,878 |  |
| Less: Current portion |  | 31,823 |  |
| Long-term portion of operating lease liabilities |  | $ | 354,055 |  |

[0001375365-26-000007:notes:161]
Related party leases

[0001375365-26-000007:notes:162]
We have entered into lease agreements with related parties. See Note 10, “Related Party Transactions” for further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-26-000007:notes:163]
Note 10.               Related Party Transactions

[0001375365-26-000007:notes:164]
We have a variety of business relationships with Ablecom Technology Inc (“Ablecom”) and Compuware Technology Inc (“Compuware”), both of which are Taiwan-based corporations. Ablecom is a major contract manufacturer for us and its Chief Executive Officer, Steve Liang, is the brother of Charles Liang, our President, Chief Executive Officer and Chairman of the Board. As of December 31, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director for us, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2025. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a board director, owns approximately 11.7% of Ablecom’s capital stock. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the board of directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s board of directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s board of directors and is an equity holder of Compuware. Compuware is also a major contract manufacturer for us and a distributor of our products in limited geographic regions. Neither Charles Liang nor Sara Liu own any capital stock of Compuware. The same sibling of Yih-Shyan (Wally) Liaw, owns approximately 8.7% of Compuware’s capital stock. We otherwise do not own any of Ablecom or Compuware's capital stock.

[0001375365-26-000007:notes:165]
In October 2018, our Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan was unsecured, had no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of our common stock that he held. The lenders called the loans in October 2018, following the suspension of our common stock from trading on Nasdaq in August 2018 and the decline in the market price of our common stock in October 2018. As of December 31, 2025 and June 30, 2025, the amount due on the unsecured loan (including principal and accrued interest) was $0.0 million and approximately $16.8 million, respectively. On October 9, 2025, the outstanding loan principal and accrued interest through October 8, 2025, totaling $16.9 million was repaid in full.

[0001375365-26-000007:notes:166]
Dealings with Ablecom

[0001375365-26-000007:notes:167]
We have entered into a series of agreements with Ablecom, including, but not limited to, multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-26-000007:notes:168]
Under these agreements, we outsource to Ablecom a portion of our design activities and a significant part of our server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.8% and 96.1% of the chassis purchased by us during the three months ended December 31, 2025 and 2024, respectively, and 96.7% and 96.5% of the chassis purchased by us during the six months ended December 31, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Ablecom for the design and engineering services, and further agree to pay Ablecom for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-26-000007:notes:169]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and we provide certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to us. For the components purchased from us, Ablecom sells the components back to us at a price equal to the price at which we sold the components to Ablecom. There is no revenue recognized by us from these transactions. We and Ablecom frequently review and negotiate the prices of the chassis we purchase from Ablecom. In addition to inventory purchases, we also incur other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-26-000007:notes:170]
Our exposure to financial loss as a result of our involvement with Ablecom is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Ablecom on December 31, 2025 and June 30, 2025 were $69.9 million and $30.6 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that we incorporate into our products, if Ablecom were to suddenly be unable to manufacture chassis for us, our business could suffer if we are unable to quickly qualify substitute suppliers who can supply high-quality chassis to us in volume and at acceptable prices. We have extended a $10.0 million trade credit line with a net 30 days payment term to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-26-000007:notes:171]
Dealings with Compuware

[0001375365-26-000007:notes:172]
We appointed Compuware as a non-exclusive authorized distributor of our products in Taiwan, China, Australia, Malaysia, and U.S. Compuware assumes the responsibility of installing our products at the site of the end customer, if required, and administers customer support in exchange for a discount from our standard price for its purchases. From time to time, Compuware acts as a sales representative for us in exchange for a fee that is based on a percentage of net sales generated from customers introduced to us. The fee structure for Compuware is comparable to the fee structure offered to other sales representatives in the same geographic region.

[0001375365-26-000007:notes:173]
We have entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. We extended a $200.0 million trade credit line on November 19, 2025, with a net 90 days payment term to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-26-000007:notes:174]
Under these agreements, we outsource a portion of our design activities, a significant part of our power supplies manufacturing and an immaterial portion of other components to Compuware. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to our specifications and further agree to build the tools needed to manufacture the products. We pay Compuware for the design and engineering services and further agrees to pay Compuware for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from third parties and uses these materials to manufacture the products and then sell those products to us. We and Compuware frequently review and negotiate the prices of the power supplies we purchase from Compuware.

[0001375365-26-000007:notes:175]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for us. We sell to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to us at a purchase price equal to the price at which we sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by us from these transactions. We and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products we purchase from Compuware. In addition to the inventory purchases, we also incur costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-26-000007:notes:176]
Our exposure to financial loss as a result of our involvement with Compuware is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Compuware on December 31, 2025 and June 30, 2025 were $206.4 million and $118.3 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-26-000007:notes:177]
Dealings with Leadtek Research Inc.

[0001375365-26-000007:notes:178]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). As of December 31, 2025 this interest came down to approximately 29%. Prior to the Leadtek Investment, none of our related parties had direct or indirect material interests in any transactions in which we were a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. We engaged in transactions whereby we sold servers worth $0.5 million and $0.2 million to Leadtek during the three months ended December 31, 2025 and 2024, respectively, and $0.8 million and $0.3 million to Leadtek during the six months ended December 31, 2025 and 2024, respectively. We purchased graphic cards worth $0.0 million and $0.1 million from Leadtek during the three months ended December 31, 2025 and 2024, respectively, and $0.0 million and $0.5 million from Leadtek during the six months ended December 31, 2025 and 2024, respectively.

[0001375365-26-000007:notes:179]
Dealings with Investment in a Corporate Venture

[0001375365-26-000007:notes:180]
In October 2016, we entered into agreements pursuant to which we contributed certain technology rights in connection with an investment in a privately held company (the “Corporate Venture”) located in China to expand our presence in China. The Corporate Venture was 30% owned by us and 70% owned by another company in China. The agreement was signed in the third quarter of the fiscal year ended June 30, 2017, and the investment was accounted for using the equity method of accounting. The Corporate Venture was also a related party.

[0001375365-26-000007:notes:181]
We monitor the investment for events or circumstances indicative of potential impairment and make appropriate reductions in carrying values if we determine that an impairment charge is required. As of June 30, 2025, we concluded the Corporate Venture would be divested in the fiscal year ending June 2026. We performed an impairment analysis on this investment and concluded the remaining carrying value of the equity investment of $6.7 million was impaired as of June 30, 2025. On November 25, 2025, the Equity Transfer Agreement was signed, and the divestiture of our 30% interest was completed on December 23, 2025, and the Corporate Venture ceased to be a related party as of December 23, 2025.

[0001375365-26-000007:notes:182]
We sold products worth $5.3 million and $0.0 million to the Corporate Venture during the three months ended December 31, 2025 and 2024, respectively, and $8.1 million and $4.8 million to the Corporate Venture during the six months ended December 31, 2025 and 2024, respectively. Our share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2025 has been eliminated and have reduced the carrying value of our investment in the Corporate Venture due to prior impairment write-off. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. We had $1.5 million and less than $0.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2025 and June 30, 2025, respectively.

[0001375365-26-000007:notes:183]
Other Transactions

[0001375365-26-000007:notes:184]
For the three months ended December 31, 2025 we had no sales to and immaterial purchases from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with our Chief Executive Officer. For the three months ended December 31, 2024, we had no transactions from Green Earth Liang’s Inc. For the six months ended December 31, 2025, we had no sales to and immaterial purchases from Green Earth Liang’s Inc. For the six months ended December 31, 2024, we had immaterial expense reimbursement from Green Earth Liang's Inc. As of December 31, 2025 and June 30, 2025, there was no amount due to and from Green Earth.

[0001375365-26-000007:notes:185]
We had the following balances related to transactions with our related parties as of December 31, 2025 and June 30, 2025 (in thousands):

[0001375365-26-000007:notes:186]
|  | Accounts receivable |  | Other receivables (1) |  | Other assets |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1 |  |  | $ | 618 |  |  | $ | 97 |  |  | $ | 88,961 |  |  | $ | 841 |  |  | $ | 339 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | — |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 88 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 60,887 |  |  | $ | 778 |  |  | $ | 319 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | — |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1,528 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 347 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1,964 |  |  | $ | 632 |  |  | $ | 97 |  |  | $ | 149,848 |  |  | $ | 1,619 |  |  | $ | 658 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | — |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |

[0001375365-26-000007:notes:187]
(1) Other receivables include receivables from vendors included in prepaid expenses and other current assets.

[0001375365-26-000007:notes:188]
(2) Includes current portion of operating lease liabilities included in other current liabilities.

[0001375365-26-000007:notes:189]
(3) Other long-term liabilities include non-current portion of lease liabilities.

[0001375365-26-000007:notes:190]
Our results from transactions with our related parties for each of the three months ended December 31, 2025 and 2024, are as follows (in thousands):

[0001375365-26-000007:notes:191]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 46 |  |  | $ | 111,921 |  |  | $ | 1,824 |  |  | $ | 1,579 |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | 5 |  |  | $ | 64,773 |  |  | $ | 2,639 |  |  | $ | 1,125 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 4,129 |  |  | $ | 79,873 |  |  | $ | — |  |  | $ | 505 |  |  | $ | 699 |  |  |  |
| Three months ended December 31, 2024 | $ | 11,065 |  |  | $ | 71,230 |  |  | $ | 14 |  |  | $ | 280 |  |  | $ | — |  |  |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 5,379 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | (51) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 556 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | 258 |  |  | $ | 106 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 44 |  |  |  |
| Three months ended December 31, 2024 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 10,110 |  |  | $ | 191,794 |  |  | $ | 1,824 |  |  | $ | 2,084 |  |  | $ | 743 |  |  |  |
| Three months ended December 31, 2024 | $ | 11,277 |  |  | $ | 136,109 |  |  | $ | 2,653 |  |  | $ | 1,405 |  |  | $ | — |  |  |  |

[0001375365-26-000007:notes:192]
Our results from transactions with our related parties for each of the six months ended December 31, 2025 and 2024, are as follows (in thousands):

[0001375365-26-000007:notes:193]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 88 |  |  | $ | 181,762 |  |  | $ | 3,479 |  |  | $ | 2,407 |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 7 |  |  | $ | 202,279 |  |  | $ | 7,131 |  |  | $ | 2,987 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 10,003 |  |  | $ | 165,360 |  |  | $ | 149 |  |  | $ | 693 |  |  | $ | 635 |  |  |  |
| Six months ended December 31, 2024 | $ | 21,040 |  |  | $ | 173,348 |  |  | $ | 371 |  |  | $ | 660 |  |  | $ | — |  |  |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 8,147 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 4,776 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 823 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 329 |  |  | $ | 534 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 46 |  |  |  |
| Six months ended December 31, 2024 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (6) |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 19,061 |  |  | $ | 347,122 |  |  | $ | 3,628 |  |  | $ | 3,100 |  |  | $ | 681 |  |  |  |
| Six months ended December 31, 2024 | $ | 26,152 |  |  | $ | 376,161 |  |  | $ | 7,502 |  |  | $ | 3,647 |  |  | $ | (6) |  |  |  |

[0001375365-26-000007:notes:194]
Our cash flow impact from transactions with our related parties for each of the six months ended December 31, 2025 and 2024, are as follows (in thousands):

[0001375365-26-000007:notes:195]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | — |  |  | $ | 344 |  |  | $ | 33,501 |  |  | $ | 88 |  |  | $ | 225 |  |  | $ | 5,551 |  |  | $ | 1,807 |  |
| Six months ended December 31, 2024 | $ | (1) |  |  | $ | 330 |  |  | $ | (45,875) |  |  | $ | 294 |  |  | $ | 154 |  |  | $ | 6,525 |  |  | $ | 2,946 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 197 |  |  | $ | 12,672 |  |  | $ | (13,405) |  |  | $ | 487 |  |  | $ | (175) |  |  | $ | 149 |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 108 |  |  | $ | (5,741) |  |  | $ | (9,739) |  |  | $ | (146) |  |  | $ | — |  |  | $ | 357 |  |  | $ | 14 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (1,498) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 5,077 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (270) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 842 |  |  | $ | — |  |  | $ | 146 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (1,571) |  |  | $ | 13,016 |  |  | $ | 20,096 |  |  | $ | 575 |  |  | $ | 50 |  |  | $ | 5,700 |  |  | $ | 1,807 |  |
| Six months ended December 31, 2024 | $ | 6,026 |  |  | $ | (5,411) |  |  | $ | (55,468) |  |  | $ | 148 |  |  | $ | 154 |  |  | $ | 6,882 |  |  | $ | 2,960 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-26-000007:notes:196]
[same as prior period, unchanged from 0001375365-25-000030:notes:176]

[0001375365-26-000007:notes:197]
[same as prior period, unchanged from 0001375365-25-000030:notes:177]

[0001375365-26-000007:notes:198]
We have 10,000,000 shares of undesignated preferred stock, $0.001 par value per share, authorized but not issued with rights and preferences determined by our board of directors at the time of issuance of such shares. As of December 31, 2025 and June 30, 2025, there were no shares of preferred stock issued and outstanding.

[0001375365-26-000007:notes:199]
[same as prior period, unchanged from 0001375365-25-000030:notes:179]

[0001375365-26-000007:notes:200]
[same as prior period, unchanged from 0001375365-25-000030:notes:180]

[0001375365-26-000007:notes:201]
[same as prior period, unchanged from 0001375365-25-000030:notes:181]

[0001375365-26-000007:notes:202]
Our 2020 Equity and Incentive Compensation Plan (the “2020 Plan”) was approved by stockholders on June 5, 2020, authorizing 50,000,000 plus 10,450,000 shares carried over from the 2016 Equity Incentive Plan (the “2016 Plan”). No new awards may be granted under the 2016 Plan, though 72,460,000 shares remained reserved for outstanding awards at the time of adoption. Stockholders approved amendments to the 2020 Plan in May 2022, January 2024, and June 2025, increasing the share reserve by 20,000,000, 15,000,000, and 18,000,000 respectively. Awards under the 2020 Plan include stock options, restricted stock units, performance shares, and other equity-based awards. Stock options are granted at a price not less than fair value (110% for 10% stockholders) and generally expire ten years after the date of the grant. Stock options and RSUs generally vest over four years (25% after one year and quarterly thereafter).

[0001375365-26-000007:notes:203]
As of December 31, 2025, we had 11,639,859 authorized shares available for future issuance under the 2020 Plan.

[0001375365-26-000007:notes:204]
[same as prior period, unchanged from 0001375365-25-000030:notes:184]

[0001375365-26-000007:notes:205]
[same as prior period, unchanged from 0001375365-25-000030:notes:185]

[0001375365-26-000007:notes:206]
The weighted-average estimated fair value of employee stock options granted during the three and six months ended December 31, 2025 was $36.16 and $38.01 per share, respectively, and three and six months ended December 31, 2024 was $20.82 and $30.29, respectively using the below assumptions.

[0001375365-26-000007:notes:207]
The fair value of stock option grants for the three and six months ended December 31, 2025 and 2024 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-26-000007:notes:208]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Risk-free interest rate | 3.68% |  | 4.17% - 4.20% |  | 3.68% - 4.00% |  | 3.82% - 4.20% |
| Expected term | 5.95 years |  | 5.98 years |  | 3.44 years - 5.95 years |  | 3.00 years - 5.98 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 77.25% |  | 67.17% |  | 76.16% - 92.16% |  | 63.67% - 69.97% |

[0001375365-26-000007:notes:209]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended December 31, 2025 and 2024 (in thousands):

[0001375365-26-000007:notes:210]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of sales | $ | 6,803 |  |  | $ | 6,694 |  |  | $ | 13,878 |  |  | $ | 10,653 |  |
| Research and development | 59,542 |  |  | 50,809 |  |  | 116,975 |  |  | 87,336 |  |
| Sales and marketing | 10,324 |  |  | 9,559 |  |  | 21,424 |  |  | 17,322 |  |
| General and administrative | 13,816 |  |  | 15,060 |  |  | 27,347 |  |  | 30,825 |  |
| Stock-based compensation expense before taxes | 90,485 |  |  | 82,122 |  |  | 179,624 |  |  | 146,136 |  |
| Income tax impact | (22,459) |  |  | (19,136) |  |  | (41,660) |  |  | (35,009) |  |
| Stock-based compensation expense, net | $ | 68,026 |  |  | $ | 62,986 |  |  | $ | 137,964 |  |  | $ | 111,127 |  |

[0001375365-26-000007:notes:211]
During the three and six months ended December 31, 2025, there was no stock-based compensation expense capitalized to our condensed consolidated balance sheets. During the three and six months ended December 31, 2024, stock-based compensation expense capitalized to our condensed consolidated balance sheets was $0.1 million and $0.3 million, respectively.

[0001375365-26-000007:notes:212]
[same as prior period, unchanged from 0001375365-25-000030:notes:191]

[0001375365-26-000007:notes:213]
[same as prior period, unchanged from 0001375365-25-000030:notes:192]

[0001375365-26-000007:notes:214]
[same as prior period, unchanged from 0001375365-25-000030:notes:193]

[0001375365-26-000007:notes:215]
The achievement status of the operational and stock price milestones as of December 31, 2025 was as follows:

[0001375365-26-000007:notes:216]
| Annualized Revenue Milestone (in billions) (1) |  | Achievement Status |  | Stock Price Milestone (1) |  | Achievement Status |
| $13.0 |  | Achieved (6) |  | $45.00 |  | Achieved (2) |
| $15.0 |  | Achieved (7) |  | $60.00 |  | Achieved (3) |
| $17.0 |  | Achieved (8) |  | $75.00 |  | Achieved (4) |
| $19.0 |  | Achieved (9) |  | $90.00 |  | Achieved (5) |
| $21.0 |  | Achieved (10) |  | $110.00 |  | Not yet achieved |

[0001375365-26-000007:notes:217]
[same as prior period, unchanged from 0001375365-25-000030:notes:196]

[0001375365-26-000007:notes:218]
[same as prior period, unchanged from 0001375365-25-000030:notes:197]

[0001375365-26-000007:notes:219]
[same as prior period, unchanged from 0001375365-25-000030:notes:198]

[0001375365-26-000007:notes:220]
[same as prior period, unchanged from 0001375365-25-000030:notes:199]

[0001375365-26-000007:notes:221]
[same as prior period, unchanged from 0001375365-25-000030:notes:200]

[0001375365-26-000007:notes:222]
[same as prior period, unchanged from 0001375365-25-000030:notes:201]

[0001375365-26-000007:notes:223]
[same as prior period, unchanged from 0001375365-25-000030:notes:202]

[0001375365-26-000007:notes:224]
[same as prior period, unchanged from 0001375365-25-000030:notes:203]

[0001375365-26-000007:notes:225]
[same as prior period, unchanged from 0001375365-25-000030:notes:204]

[0001375365-26-000007:notes:226]
[same as prior period, unchanged from 0001375365-25-000030:notes:205]

[0001375365-26-000007:notes:227]
During the three and six months ended December 31, 2025, we recognized compensation expense related to the 2023 CEO Performance Stock Option of $1.0 million and $1.9 million, respectively. During the three and six months ended December 31, 2024, we recognized compensation expense related to the 2023 CEO Performance Stock Option of $3.8 million and $11.5 million, respectively. As of December 31, 2025, we had $3.6 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of December 31, 2025 is expected to be recognized over a period of 1 year.

[0001375365-26-000007:notes:228]
The following table summarizes stock option activity during the six months ended December 31, 2025 under all plans:

[0001375365-26-000007:notes:229]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageGrant Date Fair Value |  | WeightedAverageRemainingContractualTerm (in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2025 |  | 34,848,133 |  |  | $ | 22.47 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Granted |  | 2,394,317 |  |  | $ | 55.33 |  |  | $ | 38.01 |  |  | — |  |  | $ | — |  |
| Exercised |  | (1,132,758) |  |  | $ | 7.46 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Forfeited/Cancelled |  | (581,829) |  |  | $ | 39.57 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balance as of December 31, 2025 |  | 35,527,863 |  |  | $ | 24.88 |  |  | $ | — |  |  | 6.69 |  | $ | 453,138 |  |
| Options exercisable at December 31, 2025 |  | 24,445,698 |  |  | $ | 16.92 |  |  | $ | — |  |  | 5.83 |  | $ | 421,961 |  |

[0001375365-26-000007:notes:230]
The total pretax intrinsic value of options exercised during the three and six months ended December 31, 2025 was $16.4 million and $39.7 million, respectively. The total pretax intrinsic value of options exercised during the three and six months ended December 31, 2024 was $52.7 million and $115.8 million, respectively.

[0001375365-26-000007:notes:231]
As of December 31, 2025, $250.2 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 2.62 years.

[0001375365-26-000007:notes:232]
[same as prior period, unchanged from 0001375365-25-000030:notes:211]

[0001375365-26-000007:notes:233]
The following table summarizes RSU activity during the six months ended December 31, 2025 under all plans:

[0001375365-26-000007:notes:234]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2025 | 20,428,647 |  |  | $ | 34.22 |  |  |  |  |  |  |
| Granted | 4,644,054 |  |  | $ | 55.41 |  |  |  |  |  |  |
| Released | (5,205,548) |  |  | $ | 28.66 |  |  |  |  |  |  |
| Forfeited | (879,343) |  |  | $ | 40.71 |  |  |  |  |  |  |
| Balance as of December 31, 2025 | 18,987,810 |  |  | $ | 40.63 |  |  |  |  |  |  |

[0001375365-26-000007:notes:235]
As of December 31, 2025, $701.7 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.62 years.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-26-000007:notes:236]
[same as prior period, unchanged from 0001375365-25-000030:notes:215]

[0001375365-26-000007:notes:237]
We recorded a provision for income taxes of $99.2 million and $139.3 million for the three and six months ended December 31, 2025, respectively, and provision of $57.0 million and $131.7 million for the three and six months ended December 31, 2024, respectively. The effective tax rate was 19.8% and 19.7% for the three and six months ended December 31, 2025, respectively, and 15.2% and 15.1% for the three and six months ended December 31, 2024, respectively. The effective tax rate for the three and six months ended December 31, 2025 was higher than that for the three and six months ended December 31, 2024, primarily due to the significant decrease in tax deductions related to stock-based compensation and research tax credit, due to a lower stock vesting price in the three and six months ended December 31, 2025, combined with an increase of state taxes which was attributable to a change in our jurisdictional mix of income. The effective tax rate for the three and six months ended December 31, 2025 were lower than the U.S. federal statutory rate of 21.0%, primarily due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit.

[0001375365-26-000007:notes:238]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law and contains several changes to key U.S. federal income tax laws, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions effective in 2025 and others implemented through 2027.  As of December 31, 2025, we have recognized the tax effects of certain OBBBA provisions. We will continue to evaluate the impact of the OBBBA upon our future effective tax rate, tax liabilities, and cash taxes.

[0001375365-26-000007:notes:239]
[same as prior period, unchanged from 0001375365-25-000030:notes:218]

[0001375365-26-000007:notes:240]
In general, the federal statute of limitations remains open for tax years ended June 30, 2022 through 2025. Various states' statutes of limitations remain open in general for tax years ended June 30, 2021 through 2025. Certain statutes of limitations in major foreign jurisdictions remain open for the tax years ended June 30, 2019 through 2025. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $4.1 million, in the next 12 months, due to the lapse of the statute of limitations in certain jurisdictions. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-26-000007:notes:241]
Note 13.               Commitments and Contingencies

[0001375365-26-000007:notes:242]
Litigation and claims

[0001375365-26-000007:notes:243]
On August 30, 2024, a putative class action complaint was filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147). On October 4, 2024, a putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Court then appointed Universal-Investment-Gesellschaft mbH as the Lead Plaintiff, who thereafter filed a Consolidated Amended Complaint on September 22, 2025. The appointment of Lead Plaintiff has been appealed to the Supreme Court of California. Company filed its Motion to Dismiss on November 21, 2025, with the hearing scheduled for March 12, 2026. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-26-000007:notes:244]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. The Court in the Hollin Action consolidated the five previously stayed Federal Derivative Litigation actions. The Court in the Spatz Action stayed all proceedings and consolidating the three State Court Derivative Litigation actions. On August 29, 2025, certain current and former directors and certain current officers of the Company were named as defendants in another putative derivative lawsuit filed in the Delaware Court of Chancery, captioned Anderson v. Liang, et al., C.A. No. 2025-0986-KSJM. On January 6, 2026, a substantially similar lawsuit was filed in the Delaware Court of Chancery, captioned Mathiyalagan v. Liang, et. al. On January 29, 2026, another substantially similar lawsuit was filed in Northern District of California by plaintiffs Employees’ Retirement System of the State of Rhode Island and Bucks County Employees’ Retirement System. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any

[0001375365-26-000007:notes:245]
On November 19, 2024, the Company received a subpoena from the U.S. Securities and Exchange Commission Enforcement Staff in connection with an investigation entitled In the Matter of Super Micro Computer, Inc. The Company continues to produce documents in response to the subpoena. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-26-000007:notes:246]
Other legal proceedings and indemnifications

[0001375365-26-000007:notes:247]
In the ordinary course of our business, we periodically receive subpoenas, civil investigative demands, and other formal requests for information from various courts, regulatory bodies, and government agencies. These requests typically seek documents or information related to our customers, products, or transactions in connection with matters that do not directly name or involve us as a party or target. Our general policy is to cooperate and respond fully to such requests as required by law. We are not aware of any such matters that, individually or in the aggregate, are expected to have a material adverse effect on the Company’s financial position.

[0001375365-26-000007:notes:248]
We have entered into indemnification agreements with our current and former directors and executive officers. Under these agreements, we have agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments we could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, we maintain directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-26-000007:notes:249]
Purchase Commitments— We have agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2025, these remaining non-cancelable commitments were $3.9 billion, including $276.3 million for related parties. We also review and assess the need for expected loss liabilities on a quarterly basis for all products we do not expect to sell for but have committed purchases from suppliers. There were no loss liabilities recognized as of December 31, 2025 and June 30, 2025.

[0001375365-26-000007:notes:250]
Lease Commitments— See Note 9, “Leases”, for a discussion of our operating lease commitments.


## us-gaap:SubsequentEventsTextBlock

[0001375365-26-000007:notes:251]
Note 14.               Subsequent Events

[0001375365-26-000007:notes:252]
CTBC credit agreement

[0001375365-26-000007:notes:253]
On January 21, 2026, we entered into a credit agreement with a group of lenders led by CTBC Bank Co., Ltd., along with Credit Agricole CIB, Taipei Branch and E.Sun Commercial Bank, Ltd. as lead arrangers. The agreement provides for two revolving credit facilities totaling $710.0 million, with an option to increase total commitments to up to $2.0 billion, subject to certain conditions. On January 30, 2026, we entered into an increased facilities letter under this credit agreement, providing for additional revolving credit facilities in an aggregate amount of $1.1 billion. As a result, the total lender commitments under the credit agreement increased to $1.8 billion.
