# SMCI note change history — 0001375365-25-000030 → 0001375365-26-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0001375365-26-000007:note_history:1]
On August 30, 2024, a putative class action complaint was filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147). On October 4, 2024, a putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Court then appointed Universal-Investment-Gesellschaft mbH as the Lead Plaintiff, who thereafter filed a Consolidated Amended Complaint on September 22, 2025. The appointment of Lead Plaintiff has been appealed to the Supreme Court of California. Company filed its Motion to Dismiss on November 21, 2025, with the hearing scheduled for March 12, 2026. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.
  (was, 2025-11-07, similarity 0.7267):
[0001375365-25-000030:note_history:1]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Spatz and Menditto plaintiffs have voluntarily dismissed their respective complaints without prejudice against all Defendants, ending the suits. The Court finalized the appointment of Universal-Investment-Gesellschaft mbH as the Lead Plaintiff, who thereafter filed a Consolidated Amended Complaint with the Court on September 22, 2025. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

- changed (2026-02-06):
[0001375365-26-000007:note_history:2]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. The Court in the Hollin Action consolidated the five previously stayed Federal Derivative Litigation actions. The Court in the Spatz Action stayed all proceedings and consolidating the three State Court Derivative Litigation actions. On August 29, 2025, certain current and former directors and certain current officers of the Company were named as defendants in another putative derivative lawsuit filed in the Delaware Court of Chancery, captioned Anderson v. Liang, et al., C.A. No. 2025-0986-KSJM. On January 6, 2026, a substantially similar lawsuit was filed in the Delaware Court of Chancery, captioned Mathiyalagan v. Liang, et. al. On January 29, 2026, another substantially similar lawsuit was filed in Northern District of California by plaintiffs Employees’ Retirement System of the State of Rhode Island and Bucks County Employees’ Retirement System. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any
  (was, 2025-11-07, similarity 0.831):
[0001375365-25-000030:note_history:2]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On January 14, 2025, the Court in the Hollin Action granted plaintiffs’ motion to consolidate the five previously stayed Federal Derivative Litigation actions. On March 24, 2025, the Court in the Spatz Action entered a Stipulation and Order staying all proceedings and consolidating the three State Court Derivative Litigation actions. On August 29, 2025, certain current and former directors and certain current officers of the Company were named as defendants in another putative derivative lawsuit filed in the Delaware Court of Chancery. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

- added (2026-02-06):
[0001375365-26-000007:note_history:3]
On November 19, 2024, the Company received a subpoena from the U.S. Securities and Exchange Commission Enforcement Staff in connection with an investigation entitled In the Matter of Super Micro Computer, Inc. The Company continues to produce documents in response to the subpoena. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

- added (2026-02-06):
[0001375365-26-000007:note_history:4]
In the ordinary course of our business, we periodically receive subpoenas, civil investigative demands, and other formal requests for information from various courts, regulatory bodies, and government agencies. These requests typically seek documents or information related to our customers, products, or transactions in connection with matters that do not directly name or involve us as a party or target. Our general policy is to cooperate and respond fully to such requests as required by law. We are not aware of any such matters that, individually or in the aggregate, are expected to have a material adverse effect on the Company’s financial position.

- changed (2026-02-06):
[0001375365-26-000007:note_history:5]
We have entered into indemnification agreements with our current and former directors and executive officers. Under these agreements, we have agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments we could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, we maintain directors and officers liability insurance coverage to reduce its exposure to such obligations.
  (was, 2025-11-07, similarity 0.9961):
[0001375365-25-000030:note_history:5]
We have entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, we have agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments we could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, we maintain directors and officers liability insurance coverage to reduce its exposure to such obligations.

- changed (2026-02-06):
[0001375365-26-000007:note_history:6]
Purchase Commitments— We have agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2025, these remaining non-cancelable commitments were $3.9 billion, including $276.3 million for related parties. We also review and assess the need for expected loss liabilities on a quarterly basis for all products we do not expect to sell for but have committed purchases from suppliers. There were no loss liabilities recognized as of December 31, 2025 and June 30, 2025.
  (was, 2025-11-07, similarity 0.9859):
[0001375365-25-000030:note_history:6]
Purchase Commitments— We have agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of September 30, 2025, these remaining non-cancelable commitments were $11.6 billion, including $206.7 million for related parties. We also review and assess the need for expected loss liabilities on a quarterly basis for all products we do not expect to sell for but have committed purchases from suppliers. There were no loss liabilities recognized as of September 30, 2025 and June 30, 2025.

- removed (2026-02-06):
[0001375365-25-000030:note_history:7]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. The Company filed Motion to Dismiss, and the hearing is scheduled for December 8, 2025. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

- removed (2026-02-06):
[0001375365-25-000030:note_history:8]
In late 2024, we received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication of a short seller report in August 2024. We are cooperating with the government by providing responsive documents.

- removed (2026-02-06):
[0001375365-25-000030:note_history:9]
In addition to the matters described above, from time to time, we have been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters has not had a material impact on our condensed consolidated financial condition, results of operations, or liquidity as of September 30, 2025, and any prior periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-02-06):
[0001375365-26-000007:note_history:10]
Revenue Recognition

- added (2026-02-06):
[0001375365-26-000007:note_history:11]
We generate revenues from the sale of server and storage systems, subsystems, accessories and services.

- added (2026-02-06):
[0001375365-26-000007:note_history:12]
Product sales. We recognize revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is required. Determining the point in time that control transfers to the customer requires judgment. Products sold by us are shipped from our facilities or drop shipped from our vendors. We may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

- added (2026-02-06):
[0001375365-26-000007:note_history:13]
We apply judgment in determining the transaction price as our contracts may include forms of variable consideration, including customer rebates, returns, and cash discounts for prompt payment. Variable consideration is estimated using either the expected value or most likely amount method, depending on which method better predicts the amount of consideration to which we expect to be entitled. We include estimated variable consideration in the transaction price only to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Estimates of variable consideration are reassessed each reporting period and recorded as an adjustment to revenue, as applicable.

- added (2026-02-06):
[0001375365-26-000007:note_history:14]
Services sales. Our sale of services mainly consists of extended warranty and on-site services as well as system rack installation and integration services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as we stand ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Revenue related to system rack installation and integration services is recognized when we perform the services and the customer receives and consumes the benefits.

- added (2026-02-06):
[0001375365-26-000007:note_history:15]
Contracts with multiple promised goods and services. Certain of our contracts contain multiple promised goods and services. We assess whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from us, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation.

- added (2026-02-06):
[0001375365-26-000007:note_history:16]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. For contracts that contain multiple performance obligations, we allocate the transaction price for each customer contract to each performance obligation based on the relative Stand-alone Selling Price ("SSP") for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. We determine SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, we apply judgment to estimate the SSP. For all performance obligations, we are able to establish the SSP by maximizing the use of observable inputs. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

- added (2026-02-06):
[0001375365-26-000007:note_history:17]
Our credit terms are predominantly short-term in nature; however, we also grant extended payment terms for certain customers. For the contracts with the extended payment terms in which the financing component is determined to be significant to the contract, the contract transaction price is adjusted for the effect of a financing component.

- added (2026-02-06):
[0001375365-26-000007:note_history:18]
When we receive consideration from a customer prior to transferring goods or services to the customer, we record a contract liability (deferred revenue). We also recognize deferred revenue when we have an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

- added (2026-02-06):
[0001375365-26-000007:note_history:19]
Shipping and handling fees collected from customers are included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. We have elected to account for shipping and handling activities that occur after the customer has obtained control of a good as a fulfillment cost rather than as an additional promised service. Taxes imposed by governmental authorities on our revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

- changed (2026-02-06):
[0001375365-26-000007:note_history:20]
For our other significant accounting policies, refer to our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.
  (was, 2025-11-07, similarity 0.7823):
[0001375365-25-000030:note_history:20]
There have been no material changes to our significant accounting policies included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2025.

- changed (2026-02-06):
[0001375365-26-000007:note_history:21]
We believe that the concentration of credit risk in our trade receivables is substantially mitigated by our credit evaluation process, relatively short collection terms and the high level of credit worthiness of our customers. For customers including distributors and direct customers, we perform ongoing credit evaluations of their financial conditions and limit the amount of credit extended when deemed necessary based upon payment history and their current credit worthiness, but we generally require no collateral other than the products that we deliver to them, in which we sometimes hold a purchase money security interest under our standard terms. We regularly review the allowance for credit losses by considering factors such as
  (was, 2025-11-07, similarity 0.8838):
[0001375365-25-000030:note_history:21]
We believe that the concentration of credit risk in our trade receivables is substantially mitigated by our credit evaluation process, relatively short collection terms and the high level of credit worthiness of our customers. For customers including distributors and direct customers, we perform ongoing credit evaluations of their financial conditions and limit the amount of credit extended when deemed necessary based upon payment history and their current credit worthiness, but we generally require no collateral other than the products that we deliver to them, in which we sometimes hold a purchase money security interest under our standard terms. We regularly review the allowance for credit losses by considering factors such as historical experience, credit quality, reasonable and supportable forecasts, age of the accounts receivable balances and current economic conditions that may affect a customer’s ability to pay.

- added (2026-02-06):
[0001375365-26-000007:note_history:22]
historical experience, credit quality, reasonable and supportable forecasts, age of the accounts receivable balances and current economic conditions that may affect a customer’s ability to pay.

- changed (2026-02-06):
[0001375365-26-000007:note_history:23]
|  | December 31, 2025 |  | June 30, 2025 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 71.6% |  | * |
| Customer B | 12.9% |  | 33.4% |
| Customer C | * |  | 13.6% |
  (was, 2025-11-07, similarity 0.8896):
[0001375365-25-000030:note_history:23]
|  | September 30, 2025 |  | June 30, 2025 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 29.5% |  | 33.4% |
| Customer B | * |  | 13.6% |
| Customer C | 19.7% |  | * |
| Customer D | 12.5% |  | * |

- changed (2026-02-06):
[0001375365-26-000007:note_history:24]
^The customer references of A-C above may represent different customers than those reported in a previous period.
  (was, 2025-11-07, similarity 0.9912):
[0001375365-25-000030:note_history:24]
^The customer references of A-D above may represent different customers than those reported in a previous period.

- changed (2026-02-06):
[0001375365-26-000007:note_history:25]
As of December 31, 2025, no receivables have been sold under the agreement.
  (was, 2025-11-07, similarity 0.964):
[0001375365-25-000030:note_history:25]
As of September 30, 2025 no receivables have been sold under the agreement.

- changed (2026-02-06):
[0001375365-26-000007:note_history:26]
In March 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2024-02 which removes references to the FASB’s concepts statements from the FASB Accounting Standards Codification. The ASU is part of the FASB’s standing project to make “Codification updates for technical corrections such as conforming amendments, clarifications to guidance, simplifications to wording or the structure of guidance, and other minor improvements.” The amendments in this update are effective for public business entities for fiscal years beginning after December 15, 2024. For all other entities, the amendments are effective for fiscal years beginning after December 15, 2025. We adopted ASU 2024-02 on July 1, 2025, which did not have a material impact on our condensed consolidated financial statements and related disclosures.
  (was, 2025-11-07, similarity 0.9892):
[0001375365-25-000030:note_history:26]
In March 2024, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2024-02 which removes references to the Board’s concepts statements from the FASB Accounting Standards Codification. The ASU is part of the Board’s standing project to make “Codification updates for technical corrections such as conforming amendments, clarifications to guidance, simplifications to wording or the structure of guidance, and other minor improvements.” The amendments in this Update are effective for public business entities for fiscal years beginning after December 15, 2024. For all other entities, the amendments are effective for fiscal years beginning after December 15, 2025. We adopted ASU 2024-02 on July 1, 2025, which did not have a material impact on our condensed consolidated financial statements and related disclosures.

- changed (2026-02-06):
[0001375365-26-000007:note_history:27]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending June 30, 2026.
  (was, 2025-11-07, similarity 0.9565):
[0001375365-25-000030:note_history:27]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We will adopt this standard in our fiscal year 2026 annual report. We are currently assessing the effect of the adoption of this standard on our disclosures that will be included in our Form 10-K for the fiscal year ending June 30, 2026.

- added (2026-02-06):
[0001375365-26-000007:note_history:28]
In November 2025, the FASB issued ASU 2025-08, Financial Instruments–Credit Losses (Topic 326): Purchased Loans, which expands the population of acquired financial assets subject to the gross-up approach in Topic 326. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our condensed consolidated financial statements and disclosures.

- added (2026-02-06):
[0001375365-26-000007:note_history:29]
In December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270): Narrow-scope Improvements. This update makes targeted, narrow-scope improvements to the interim reporting guidance in Topic 270 to clarify application and improve consistency in practice. The amendments do not change the underlying principles of interim reporting. The ASU is effective for interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for interim reporting periods beginning in our fiscal year beginning July 1, 2028. We are currently evaluating the effects of ASU on our condensed consolidated financial statements and disclosures.

- added (2026-02-06):
[0001375365-26-000007:note_history:30]
In December 2025, the FASB issued ASU 2025-12, Codification Improvements, which includes 33 technical corrections, clarifications, and minor refinements across multiple ASC Topics intended to improve consistency and usability of U.S. GAAP. Transition is applied on an issue-by-issue basis: the EPS clarification (ASC 260, Issue 4) is applied retrospectively to all prior periods presented, while all other amendments may be applied prospectively or retrospectively, with appropriate disclosures about the nature/reason for the change (and additional disclosures if applied retrospectively). The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We are currently evaluating the effects of ASU on our condensed consolidated financial statements and disclosures.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0001375365-26-000007:note_history:31]
The following table summarizes our convertible notes as of December 31, 2025:
  (was, 2025-11-07, similarity 0.9655):
[0001375365-25-000030:note_history:31]
The following table summarizes our convertible notes as of September 30, 2025:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0001375365-26-000007:note_history:32]
Note 7.                 Lines of Credit, Revolving Credit Facilities, and Term Loans
  (was, 2025-11-07, similarity 0.7115):
[0001375365-25-000030:note_history:32]
Note 7.                 Lines of Credit and Term Loans

- changed (2026-02-06):
[0001375365-26-000007:note_history:33]
Short-term and long-term loan obligations with respect to lines of credit and term loans as of December 31, 2025 and June 30, 2025 consisted of the following (in thousands):
  (was, 2025-11-07, similarity 0.9555):
[0001375365-25-000030:note_history:33]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands):

- changed (2026-02-06):
[0001375365-26-000007:note_history:34]
|  | December 31, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 57,389 |  |  | $ | — |  |
| E.SUN Bank Credit Lines | 60,000 |  |  | 30,000 |  |
| Mega Bank Credit Lines | 30,000 |  |  | — |  |
| First Bank Credit Lines | 19,934 |  |  | — |  |
| Total line of credit | 167,323 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 6,642 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 24,140 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 983 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 7,652 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 6,908 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 9,565 |  |  | 17,098 |  |
| Total term loans | 55,890 |  |  | 82,475 |  |
| Total lines of credit and term loans | $ | 223,213 |  |  | $ | 112,475 |  |
| Lines of credit and current portion of term loans | $ | 201,776 |  |  | $ | 75,060 |  |
| Term loans, non-current | $ | 21,437 |  |  | $ | 37,415 |  |
  (was, 2025-11-07, similarity 0.6444):
[0001375365-25-000030:note_history:34]
|  | September 30, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 17,705 |  |  | $ | — |  |
| Chang Hwa Bank Credit Lines | 9,836 |  |  | — |  |
| E.SUN Bank Credit Lines | 30,000 |  |  | 30,000 |  |
| First Bank Credit Lines | — |  |  | — |  |
| Total line of credit | 57,541 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 8,880 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,229 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,391 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 10,492 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 8,169 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 13,115 |  |  | 17,098 |  |
| Total term loans | 68,276 |  |  | 82,475 |  |
| Total lines of credit and term loans | 125,817 |  |  | 112,475 |  |
| Lines of credit and current portion of term loans | 100,618 |  |  | 75,060 |  |
| Term loans, non-current | $ | 25,199 |  |  | $ | 37,415 |  |

- changed (2026-02-06):
[0001375365-26-000007:note_history:35]
Activities under Lines of Credit, Revolving Credit Facilities, and Term Loans
  (was, 2025-11-07, similarity 0.7015):
[0001375365-25-000030:note_history:35]
Activities under Revolving Lines of Credit and Term Loans

- changed (2026-02-06):
[0001375365-26-000007:note_history:36]
Available borrowings and interest rates as of December 31, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):
  (was, 2025-11-07, similarity 0.9818):
[0001375365-25-000030:note_history:36]
Available borrowings and interest rates as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):

- changed (2026-02-06):
[0001375365-26-000007:note_history:37]
|  | December 31, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 127,611 |  |  | 2.14% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 25,240 |  |  | 1.88% - 4.48% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | — |  |  | 2.02% - 4.56% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 20,000 |  |  | 1.90% - 4.50% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 66 |  |  | 2.03% - 4.49% |  | $ | — |  |  | n/a |
| JP Morgan Revolving Credit Facility | $ | 2,000,000 |  |  | 4.84% - 5.87% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |
  (was, 2025-11-07, similarity 0.9593):
[0001375365-25-000030:note_history:37]
|  | September 30, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 167,295 |  |  | 2.11% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 14,071 |  |  | 1.88% - 4.74% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | 30,000 |  |  | 2.02% - 5.12% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 20,000 |  |  | 2.03% - 5.26% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |

- changed (2026-02-06):
[0001375365-26-000007:note_history:38]
See Note 7, “Lines of Credit, Revolving Credit Facilities, and Term Loans” of our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 for a more complete description of our credit facilities.
  (was, 2025-11-07, similarity 0.9185):
[0001375365-25-000030:note_history:38]
See Note 7, “Lines of Credit and Term Loans” of our Annual Report on Form 10-K for the fiscal year ended June 30, 2025 for a more complete description of our credit facilities.

- changed (2026-02-06):
[0001375365-26-000007:note_history:39]
As of December 31, 2025, we were in compliance with all the covenants for the revolving lines of credit and term loans on our condensed consolidated balance sheets.
  (was, 2025-11-07, similarity 0.7372):
[0001375365-25-000030:note_history:39]
As of September 30, 2025, we were in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 7, “Lines of Credit and Term Loans”.

- changed (2026-02-06):
[0001375365-26-000007:note_history:40]
We entered into new agreements during the six months ended December 31, 2025 with the following terms:
  (was, 2025-11-07, similarity 0.9192):
[0001375365-25-000030:note_history:40]
We entered into a new agreement during the three months ended September 30, 2025 with the following terms:

- added (2026-02-06):
[0001375365-26-000007:note_history:41]
Revolving Credit Facility

- added (2026-02-06):
[0001375365-26-000007:note_history:42]
On December 29, 2025, we entered into a credit agreement (the “Credit Agreement”) with JPMorgan Chase Bank, N.A., (“JP Morgan”) as administrative agent and collateral agent, and a syndicate of lenders, which provides for a revolving credit facility of up to $2,000.0 million (the “Revolving Credit Facility”), including a $200.0 million letter of credit sub-limit and a $150.0 million same-day borrowing sub-limit, with an option to increase total commitments by up to $1,000.0 million subject to certain conditions. Borrowings under the Revolving Credit Facility may be used for working capital and other general corporate purposes. The upfront fees totaling $9.8 million incurred in connection with the credit agreement were capitalized as deferred cost and recorded as a non-current asset included within other assets on the condensed consolidated balance sheet as of December 31, 2025.

- added (2026-02-06):
[0001375365-26-000007:note_history:43]
As of December 31, 2025, we had no borrowings outstanding under the Revolving Credit Facility.

- added (2026-02-06):
[0001375365-26-000007:note_history:44]
Borrowings under the Revolving Credit Facility bear interest, at our option, at either an alternate base rate (“ABR”) or a term rate, in each case plus an applicable margin. The applicable margin varies based on (i) during a non-investment grade period, our leverage ratio (ranging from 1.25% to 2.00% for term rate loans and 0.25% to 1.00% for ABR loans), or (ii) during an investment grade period, our corporate family rating (ranging from 1.13% to 1.38% for term rate loans and 0.13% to 0.38% for ABR loans). We also pay a quarterly commitment fee on unused commitments ranging from 0.15% to 0.30% during a non-investment grade period (or 0.12% to 0.15% during an investment grade period). Investment grade period refers to the period beginning on the date (no earlier than September 30, 2026) when we attain an investment grade corporate family rating from at least two of Moody’s (Baa3 or higher), S&P (BBB- or higher), and Fitch (BBB- or higher), in each case with a stable or better outlook, and delivers an officer’s certificate to the administrative agent confirming such ratings, and continuing until the occurrence of a subsequent non-investment grade trigger event. The Revolving Credit Facility matures on December 29, 2030.

- added (2026-02-06):
[0001375365-26-000007:note_history:45]
During any non-investment grade period, the Revolving Credit Facility is guaranteed by us and certain qualifying domestic subsidiaries (subject to customary exclusions) and is secured by a first-priority lien on substantially all assets of the applicable loan parties (subject to customary exclusions). The Credit Agreement includes customary restrictive covenants (some of which are not applicable during an investment grade period), including limitations on indebtedness, investments, and restricted payments, and a maximum total net leverage ratio covenant of 4.00:1.00 for the first four full fiscal quarters after inception, stepping down to 3.50:1.00 for the next four full fiscal quarters, and 3.00:1.00 thereafter. The Credit Agreement contains customary events of default (including change of control), which upon occurrence may result in the acceleration of amounts outstanding and termination of lender commitments.

- changed (2026-02-06):
[0001375365-26-000007:note_history:46]
On September 18, 2025 (the “CHB Effective Date”), our Taiwan subsidiary entered into a credit facility (the “2025 Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”) which was substantially similar to the “New Credit Facility” in 2024 to renew a Loan Contract for a general working capital loan (the “General Working Capital Loan”). The credit limit thereunder has been adjusted to a total cap of NTD 1,000.0 million, which includes $20.0 million from the Chang Hwa Bank Credit Facility, a credit limit of NTD 300.0 million (together, the “CHB Credit Lines”), and the remaining balance of “Chang Hwa Bank Term Loan Facility.”
  (was, 2025-11-07, similarity 0.9984):
[0001375365-25-000030:note_history:46]
On September 18, 2025 (the “CHB Effective Date”), our Taiwan subsidiary entered into a credit facility (the “2025 Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”) which was substantially similar to the “New Credit Facility” in 2024 to renew a Loan Contract for a general working capital loan (the “General Working Capital Loan”). The credit limit thereunder has been adjusted to a total cap of NTD 1,000.0 million, which includes $20.0 million from the Chang Hwa Bank Credit Facility, a credit limit of NTD 300.0 million (together, the “CHB Credit Lines”), and the remaining balance of “Chang Hwa Bank Term Loan Facility”.

- changed (2026-02-06):
[0001375365-26-000007:note_history:47]
Terms for specific drawdown instruments issued under the 2025 Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with the Chang Hwa Bank. Under three Loan Contracts entered into on the CHB Effective Date, our Taiwan subsidiary and the Chang Hwa Bank have agreed to each of the following: (a) our Taiwan subsidiary may choose one of the following, subject to a cap of $20.0 million under the CHB Credit Lines: (i) a Loan Contract providing for the drawdown of up to $20.0 million for an import loan (the “Import Open Account O/A Loan”), with the interest rate thereunder based on Taipei Forex Inc (“TAIFX”) plus a fixed margin; or (ii) a Loan Contract providing for the drawdown of up to $20.0 million for an export loan (the “Export Open Account O/A Loan”), with the interest rate thereunder based on TAIFX plus a fixed margin; and (b) a Loan Contract for a general working capital loan (the “General Working Capital Loan”), subject to a cap of NTD 300.0 million under the CHB Credit Lines, with the interest rate set at a fixed premium to a specified one-year time savings deposit rate, subject to a floor of 1.4%. Only the Loan Contract referred to in (b) is subject to renewal or re-execution, while the other agreements under (a) remain unchanged. As of December 31, 2025, the outstanding borrowings under the Chang Hwa Bank credit line was $6.6 million.
  (was, 2025-11-07, similarity 0.9655):
[0001375365-25-000030:note_history:47]
Terms for specific drawdown instruments issued under the 2025 Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with the Chang Hwa Bank. Under three Loan Contracts entered into on the CHB Effective Date, our Taiwan subsidiary and the Chang Hwa Bank have agreed to each of the following: (a) our Taiwan subsidiary may choose one of the following, subject to a cap of $20.0 million under the CHB Credit Lines: (i) a Loan Contract providing for the drawdown of up to $20.0 million for an import loan (the “Import Open Account O/A Loan”), with the interest rate thereunder based on Taipei Forex Inc (“TAIFX”) plus a fixed margin; or (ii) a Loan Contract providing for the drawdown of up to $20.0 million for an export loan (the “Export Open Account O/A Loan”), with the interest rate thereunder based on TAIFX plus a fixed margin; and (b) a Loan Contract for a general working capital loan (the “General Working Capital Loan”), subject to a cap of NTD 300.0 million under the CHB Credit Lines, with the interest rate set at a fixed premium to a specified one-year time savings deposit rate, subject to a floor of 1.4%. Only the Loan Contract referred to in (b) is subject to renewal or re-execution, while the other agreements under (a) remain unchanged.

- changed (2026-02-06):
[0001375365-26-000007:note_history:48]
On July 18, 2025, our Taiwan subsidiary renewed the Credit Agreement and the Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”). The credit lines are reduced from $30.0 million to $20.0 million, including a sub-item credit limit of NTD 600.0 million designed for short-term working capital loans. As of December 31, 2025, the outstanding borrowings under the First Bank credit line was $19.9 million.
  (was, 2025-11-07, similarity 0.9252):
[0001375365-25-000030:note_history:48]
On July 18, 2025, our Taiwan subsidiary renewed the Credit Agreement and the Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”). The credit lines are reduced from $30.0 million to $20.0 million, including a sub-item credit limit of NTD 600.0 million designed for short-term working capital loans. As of September 30, 2025, there were no outstanding borrowings under the First Bank credit line.

- changed (2026-02-06):
[0001375365-26-000007:note_history:49]
The following table summarizes our convertible notes as of December 31, 2025:
  (was, 2025-11-07, similarity 0.9655):
[0001375365-25-000030:note_history:49]
The following table summarizes our convertible notes as of September 30, 2025:

- changed (2026-02-06):
[0001375365-26-000007:note_history:50]
All notes are senior unsecured obligations ranking equally in right of payment with one another and senior to any future subordinated indebtedness. Each series is convertible, at our election, into cash, shares of our common stock, or a combination thereof, and none were eligible for early conversion as of December 31, 2025.
  (was, 2025-11-07, similarity 0.9891):
[0001375365-25-000030:note_history:50]
All notes are senior unsecured obligations ranking equally in right of payment with one another and senior to any future subordinated indebtedness. Each series is convertible, at our election, into cash, shares of our common stock, or a combination thereof, and none were eligible for early conversion as of September 30, 2025.

- added (2026-02-06):
[0001375365-26-000007:note_history:51]
As of December 31, 2025 and June 30, 2025, unamortized issuance costs are $18.6 million and $21.3 million, respectively. The interest expense for the three months ended December 31, 2025 and 2024 totaled $16.5 million and $1.5 million, respectively, including $1.3 million and $1.5 million, respectively, from the amortization of debt issuance costs. Interest expense for the six months ended December 31, 2025 and 2024 totaled $32.9 million and $3.0 million, including $2.7 million and $3.0 million, respectively, from the amortization of debt issuance costs.

- changed (2026-02-06):
[0001375365-26-000007:note_history:52]
We accounted for the 2028 Convertible Notes as a single liability measured at amortized cost, as no embedded features required bifurcation as derivatives. As of December 31, 2025 and June 30, 2025, unamortized issuance costs are $12.3 million and $14.6 million, respectively. Interest expense for the three months ended December 31, 2025 totaled $5.1 million, including $1.2 million from the amortization of debt issuance costs. Interest expense for the six months ended December 31, 2025 totaled $10.2 million, including $2.3 million from the amortization of debt issuance costs.
  (was, 2025-11-07, similarity 0.8344):
[0001375365-25-000030:note_history:52]
We accounted for the 2028 Convertible Notes as a single liability measured at amortized cost, as no embedded features required bifurcation as derivatives. As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $13.5 million and $14.6 million, respectively. Interest expense for the three months ended September 30, 2025 totaled $5.1 million, including $1.1 million from the amortization of debt issuance costs.

- changed (2026-02-06):
[0001375365-26-000007:note_history:53]
As of December 31, 2025 and June 30, 2025, unamortized issuance costs are $39.5 million and $43.9 million, respectively. Interest expense for the three and six months ended December 31, 2025 totaled $2.2 million and $4.4 million, respectively, all of which are amortization of debt issuance costs.
  (was, 2025-11-07, similarity 0.8481):
[0001375365-25-000030:note_history:53]
As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $41.7 million and $43.9 million, respectively. Interest expense for the three months ended September 30, 2025 totaled $2.2 million, all of which are amortization of debt issuance costs.

- changed (2026-02-06):
[0001375365-26-000007:note_history:54]
We entered into 2030 Capped Call Transactions with certain counterparties to mitigate dilution or cash outflows above principal upon conversion. The capped calls have an initial cap price of $81.78 per share, representing a 100% premium to the $40.89 share price on the issuance date. These instruments are equity-classified under ASC 815-40.
  (was, 2025-11-07, similarity 0.9094):
[0001375365-25-000030:note_history:54]
We entered into 2030 Capped Call Transactions with certain counterparties to mitigate dilution or cash outflows above principal upon conversion. The capped calls have an initial cap price of $81.78 per share, representing a 100% premium to the $40.89 share price on the issuance date.

- removed (2026-02-06):
[0001375365-25-000030:note_history:55]
As of September 30, 2025 and June 30, 2025, unamortized issuance costs are $19.9 million and $21.3 million, respectively. The interest expense for the three months ended September 30, 2025 totaled $16.4 million, including $1.4 million from the amortization of debt issuance costs. Interest expense for the three months ended September 30, 2024 totaled $1.5 million, all of which is amortization of issuance costs.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0001375365-26-000007:note_history:56]
Short-term and long-term loan obligations with respect to lines of credit and term loans as of December 31, 2025 and June 30, 2025 consisted of the following (in thousands):
  (was, 2025-11-07, similarity 0.9555):
[0001375365-25-000030:note_history:56]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands):

- changed (2026-02-06):
[0001375365-26-000007:note_history:57]
|  | December 31, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 57,389 |  |  | $ | — |  |
| E.SUN Bank Credit Lines | 60,000 |  |  | 30,000 |  |
| Mega Bank Credit Lines | 30,000 |  |  | — |  |
| First Bank Credit Lines | 19,934 |  |  | — |  |
| Total line of credit | 167,323 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 6,642 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 24,140 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 983 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 7,652 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 6,908 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 9,565 |  |  | 17,098 |  |
| Total term loans | 55,890 |  |  | 82,475 |  |
| Total lines of credit and term loans | $ | 223,213 |  |  | $ | 112,475 |  |
| Lines of credit and current portion of term loans | $ | 201,776 |  |  | $ | 75,060 |  |
| Term loans, non-current | $ | 21,437 |  |  | $ | 37,415 |  |
  (was, 2025-11-07, similarity 0.6444):
[0001375365-25-000030:note_history:57]
|  | September 30, |  | June 30, |
|  | 2025 |  | 2025 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 17,705 |  |  | $ | — |  |
| Chang Hwa Bank Credit Lines | 9,836 |  |  | — |  |
| E.SUN Bank Credit Lines | 30,000 |  |  | 30,000 |  |
| First Bank Credit Lines | — |  |  | — |  |
| Total line of credit | 57,541 |  |  | 30,000 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 8,880 |  |  | 11,399 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 26,229 |  |  | 28,822 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 1,391 |  |  | 1,846 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 10,492 |  |  | 13,678 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 8,169 |  |  | 9,632 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 13,115 |  |  | 17,098 |  |
| Total term loans | 68,276 |  |  | 82,475 |  |
| Total lines of credit and term loans | 125,817 |  |  | 112,475 |  |
| Lines of credit and current portion of term loans | 100,618 |  |  | 75,060 |  |
| Term loans, non-current | $ | 25,199 |  |  | $ | 37,415 |  |

- changed (2026-02-06):
[0001375365-26-000007:note_history:58]
Available borrowings and interest rates as of December 31, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):
  (was, 2025-11-07, similarity 0.9818):
[0001375365-25-000030:note_history:58]
Available borrowings and interest rates as of September 30, 2025 and June 30, 2025 consisted of the following (in thousands except for percentages):

- changed (2026-02-06):
[0001375365-26-000007:note_history:59]
|  | December 31, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 127,611 |  |  | 2.14% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 25,240 |  |  | 1.88% - 4.48% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | — |  |  | 2.02% - 4.56% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 20,000 |  |  | 1.90% - 4.50% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 66 |  |  | 2.03% - 4.49% |  | $ | — |  |  | n/a |
| JP Morgan Revolving Credit Facility | $ | 2,000,000 |  |  | 4.84% - 5.87% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |
  (was, 2025-11-07, similarity 0.9593):
[0001375365-25-000030:note_history:59]
|  | September 30, 2025 |  | June 30, 2025 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| CTBC Credit Lines | $ | 167,295 |  |  | 2.11% - 5.79% |  | $ | 185,000 |  |  | 2.63% - 5.79% |
| Chang Hwa Bank Credit Lines | $ | 14,071 |  |  | 1.88% - 4.74% |  | $ | 30,259 |  |  | 1.88% - 5.16% |
| E.SUN Bank Credit Lines | $ | 30,000 |  |  | 2.02% - 5.12% |  | $ | 30,000 |  |  | 2.02% - 5.12% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | 50,000 |  |  | 1.90% - 5.26% |
| First Bank Credit Lines | $ | 20,000 |  |  | 2.03% - 5.26% |  | $ | — |  |  | n/a |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 2.08% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% - 1.83% |  | $ | — |  |  | 1.33% - 1.83% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 2.03% |  | $ | — |  |  | 1.53% - 2.03% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 2.22% |  | $ | — |  |  | 2.22% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 2.22% |  | $ | — |  |  | 1.92% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 2.02% |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2026-02-06):
[0001375365-26-000007:note_history:60]
We have a variety of business relationships with Ablecom Technology Inc (“Ablecom”) and Compuware Technology Inc (“Compuware”), both of which are Taiwan-based corporations. Ablecom is a major contract manufacturer for us and its Chief Executive Officer, Steve Liang, is the brother of Charles Liang, our President, Chief Executive Officer and Chairman of the Board. As of December 31, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director for us, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2025. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a board director, owns approximately 11.7% of Ablecom’s capital stock. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the board of directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s board of directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s board of directors and is an equity holder of Compuware. Compuware is also a major contract manufacturer for us and a distributor of our products in limited geographic regions. Neither Charles Liang nor Sara Liu own any capital stock of Compuware. The same sibling of Yih-Shyan (Wally) Liaw, owns approximately 8.7% of Compuware’s capital stock. We otherwise do not own any of Ablecom or Compuware's capital stock.

- changed (2026-02-06):
[0001375365-26-000007:note_history:61]
In October 2018, our Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan was unsecured, had no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of our common stock that he held. The lenders called the loans in October 2018, following the suspension of our common stock from trading on Nasdaq in August 2018 and the decline in the market price of our common stock in October 2018. As of December 31, 2025 and June 30, 2025, the amount due on the unsecured loan (including principal and accrued interest) was $0.0 million and approximately $16.8 million, respectively. On October 9, 2025, the outstanding loan principal and accrued interest through October 8, 2025, totaling $16.9 million was repaid in full.
  (was, 2025-11-07, similarity 0.979):
[0001375365-25-000030:note_history:61]
In October 2018, our Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan was unsecured, had no maturity date and bore interest at 0.80% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of our common stock that he held. The lenders called the loans in October 2018, following the suspension of our common stock from trading on Nasdaq in August 2018 and the decline in the market price of our common stock in October 2018. As of September 30, 2025 and June 30, 2025, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.9 million and $16.8 million, respectively. On October 9, 2025, the outstanding loan principal and accrued interest through October 8, 2025, totaling $16.9 million was repaid.

- changed (2026-02-06):
[0001375365-26-000007:note_history:62]
We have entered into a series of agreements with Ablecom, including, but not limited to, multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.
  (was, 2025-11-07, similarity 0.9613):
[0001375365-25-000030:note_history:62]
We have entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

- changed (2026-02-06):
[0001375365-26-000007:note_history:63]
Under these agreements, we outsource to Ablecom a portion of our design activities and a significant part of our server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.8% and 96.1% of the chassis purchased by us during the three months ended December 31, 2025 and 2024, respectively, and 96.7% and 96.5% of the chassis purchased by us during the six months ended December 31, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Ablecom for the design and engineering services, and further agree to pay Ablecom for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2025-11-07, similarity 0.9303):
[0001375365-25-000030:note_history:63]
Under these agreements, we outsource to Ablecom a portion of our design activities and a significant part of our server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.6% and 96.8% of the chassis purchased by us during the three months ended September 30, 2025 and 2024, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Ablecom for the design and engineering services, and further agree to pay Ablecom for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2026-02-06):
[0001375365-26-000007:note_history:64]
Our exposure to financial loss as a result of our involvement with Ablecom is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Ablecom on December 31, 2025 and June 30, 2025 were $69.9 million and $30.6 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that we incorporate into our products, if Ablecom were to suddenly be unable to manufacture chassis for us, our business could suffer if we are unable to quickly qualify substitute suppliers who can supply high-quality chassis to us in volume and at acceptable prices. We have extended a $10.0 million trade credit line with a net 30 days payment term to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.
  (was, 2025-11-07, similarity 0.9969):
[0001375365-25-000030:note_history:64]
Our exposure to financial loss as a result of our involvement with Ablecom is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Ablecom on September 30, 2025 and June 30, 2025 were $50.1 million and $30.6 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that we incorporate into our products, if Ablecom were to suddenly be unable to manufacture chassis for us, our business could suffer if we are unable to quickly qualify substitute suppliers who can supply high-quality chassis to us in volume and at acceptable prices. We have extended a $10.0 million trade credit line with a net 30 days payment term to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

- added (2026-02-06):
[0001375365-26-000007:note_history:65]
We appointed Compuware as a non-exclusive authorized distributor of our products in Taiwan, China, Australia, Malaysia, and U.S. Compuware assumes the responsibility of installing our products at the site of the end customer, if required, and administers customer support in exchange for a discount from our standard price for its purchases. From time to time, Compuware acts as a sales representative for us in exchange for a fee that is based on a percentage of net sales generated from customers introduced to us. The fee structure for Compuware is comparable to the fee structure offered to other sales representatives in the same geographic region.

- changed (2026-02-06):
[0001375365-26-000007:note_history:66]
We have entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. We extended a $200.0 million trade credit line on November 19, 2025, with a net 90 days payment term to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.
  (was, 2025-11-07, similarity 0.6667):
[0001375365-25-000030:note_history:66]
We also have entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. We have extended a $65.0 million trade credit line with a net 60 days payment term to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

- changed (2026-02-06):
[0001375365-26-000007:note_history:67]
Our exposure to financial loss as a result of our involvement with Compuware is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Compuware on December 31, 2025 and June 30, 2025 were $206.4 million and $118.3 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2025-11-07, similarity 0.9942):
[0001375365-25-000030:note_history:67]
Our exposure to financial loss as a result of our involvement with Compuware is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Compuware on September 30, 2025 and June 30, 2025 were $156.6 million and $118.3 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- added (2026-02-06):
[0001375365-26-000007:note_history:68]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). As of December 31, 2025 this interest came down to approximately 29%. Prior to the Leadtek Investment, none of our related parties had direct or indirect material interests in any transactions in which we were a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. We engaged in transactions whereby we sold servers worth $0.5 million and $0.2 million to Leadtek during the three months ended December 31, 2025 and 2024, respectively, and $0.8 million and $0.3 million to Leadtek during the six months ended December 31, 2025 and 2024, respectively. We purchased graphic cards worth $0.0 million and $0.1 million from Leadtek during the three months ended December 31, 2025 and 2024, respectively, and $0.0 million and $0.5 million from Leadtek during the six months ended December 31, 2025 and 2024, respectively.

- changed (2026-02-06):
[0001375365-26-000007:note_history:69]
In October 2016, we entered into agreements pursuant to which we contributed certain technology rights in connection with an investment in a privately held company (the “Corporate Venture”) located in China to expand our presence in China. The Corporate Venture was 30% owned by us and 70% owned by another company in China. The agreement was signed in the third quarter of the fiscal year ended June 30, 2017, and the investment was accounted for using the equity method of accounting. The Corporate Venture was also a related party.
  (was, 2025-11-07, similarity 0.6301):
[0001375365-25-000030:note_history:69]
In October 2016, we entered into agreements pursuant to which we contributed certain technology rights in connection with an investment in a privately held company (the “Corporate Venture”) located in China to expand our presence in China. The Corporate Venture is 30% owned by us and 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

- changed (2026-02-06):
[0001375365-26-000007:note_history:70]
We monitor the investment for events or circumstances indicative of potential impairment and make appropriate reductions in carrying values if we determine that an impairment charge is required. As of June 30, 2025, we concluded the Corporate Venture would be divested in the fiscal year ending June 2026. We performed an impairment analysis on this investment and concluded the remaining carrying value of the equity investment of $6.7 million was impaired as of June 30, 2025. On November 25, 2025, the Equity Transfer Agreement was signed, and the divestiture of our 30% interest was completed on December 23, 2025, and the Corporate Venture ceased to be a related party as of December 23, 2025.
  (was, 2025-11-07, similarity 0.8207):
[0001375365-25-000030:note_history:70]
We monitor the investment for events or circumstances indicative of potential impairment and make appropriate reductions in carrying values if we determine that an impairment charge is required. As of June 30, 2025, we concluded the Corporate Venture would be divested in the fiscal year ending June 2026. We performed an impairment analysis on this investment and concluded the remaining carrying value of the equity investment of $6.7 million was impaired as of June 30, 2025.

- added (2026-02-06):
[0001375365-26-000007:note_history:71]
We sold products worth $5.3 million and $0.0 million to the Corporate Venture during the three months ended December 31, 2025 and 2024, respectively, and $8.1 million and $4.8 million to the Corporate Venture during the six months ended December 31, 2025 and 2024, respectively. Our share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2025 has been eliminated and have reduced the carrying value of our investment in the Corporate Venture due to prior impairment write-off. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. We had $1.5 million and less than $0.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2025 and June 30, 2025, respectively.

- added (2026-02-06):
[0001375365-26-000007:note_history:72]
For the three months ended December 31, 2025 we had no sales to and immaterial purchases from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with our Chief Executive Officer. For the three months ended December 31, 2024, we had no transactions from Green Earth Liang’s Inc. For the six months ended December 31, 2025, we had no sales to and immaterial purchases from Green Earth Liang’s Inc. For the six months ended December 31, 2024, we had immaterial expense reimbursement from Green Earth Liang's Inc. As of December 31, 2025 and June 30, 2025, there was no amount due to and from Green Earth.

- changed (2026-02-06):
[0001375365-26-000007:note_history:73]
We had the following balances related to transactions with our related parties as of December 31, 2025 and June 30, 2025 (in thousands):
  (was, 2025-11-07, similarity 0.9802):
[0001375365-25-000030:note_history:73]
We had the following balances related to transactions with our related parties as of September 30, 2025 and June 30, 2025 (in thousands):

- changed (2026-02-06):
[0001375365-26-000007:note_history:74]
|  | Accounts receivable |  | Other receivables (1) |  | Other assets |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1 |  |  | $ | 618 |  |  | $ | 97 |  |  | $ | 88,961 |  |  | $ | 841 |  |  | $ | 339 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | — |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 88 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 60,887 |  |  | $ | 778 |  |  | $ | 319 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | — |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1,528 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 347 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1,964 |  |  | $ | 632 |  |  | $ | 97 |  |  | $ | 149,848 |  |  | $ | 1,619 |  |  | $ | 658 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | — |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |
  (was, 2025-11-07, similarity 0.8929):
[0001375365-25-000030:note_history:74]
|  | Accounts receivable |  | Other receivables (1) |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2 |  |  | $ | 684 |  |  | $ | 53,062 |  |  | $ | 746 |  |  | $ | 55 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 36 |  |  | $ | 518 |  |  | $ | 52,517 |  |  | $ | 852 |  |  | $ | 402 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 1,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 177 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2,064 |  |  | $ | 1,202 |  |  | $ | 105,579 |  |  | $ | 1,598 |  |  | $ | 457 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |

- changed (2026-02-06):
[0001375365-26-000007:note_history:75]
(1) Other receivables include receivables from vendors included in prepaid expenses and other current assets.
  (was, 2025-11-07, similarity 0.9569):
[0001375365-25-000030:note_history:75]
(1) Other receivables include receivables from vendors included in prepaid and other current assets.

- changed (2026-02-06):
[0001375365-26-000007:note_history:76]
Our results from transactions with our related parties for each of the three months ended December 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-11-07, similarity 0.9821):
[0001375365-25-000030:note_history:76]
Our results from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):

- added (2026-02-06):
[0001375365-26-000007:note_history:77]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 46 |  |  | $ | 111,921 |  |  | $ | 1,824 |  |  | $ | 1,579 |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | 5 |  |  | $ | 64,773 |  |  | $ | 2,639 |  |  | $ | 1,125 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 4,129 |  |  | $ | 79,873 |  |  | $ | — |  |  | $ | 505 |  |  | $ | 699 |  |  |  |
| Three months ended December 31, 2024 | $ | 11,065 |  |  | $ | 71,230 |  |  | $ | 14 |  |  | $ | 280 |  |  | $ | — |  |  |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 5,379 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | (51) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 556 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | 258 |  |  | $ | 106 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 44 |  |  |  |
| Three months ended December 31, 2024 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 10,110 |  |  | $ | 191,794 |  |  | $ | 1,824 |  |  | $ | 2,084 |  |  | $ | 743 |  |  |  |
| Three months ended December 31, 2024 | $ | 11,277 |  |  | $ | 136,109 |  |  | $ | 2,653 |  |  | $ | 1,405 |  |  | $ | — |  |  |  |

- changed (2026-02-06):
[0001375365-26-000007:note_history:78]
Our results from transactions with our related parties for each of the six months ended December 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-11-07, similarity 0.8951):
[0001375365-25-000030:note_history:78]
Our cash flow impact from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):

- added (2026-02-06):
[0001375365-26-000007:note_history:79]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 88 |  |  | $ | 181,762 |  |  | $ | 3,479 |  |  | $ | 2,407 |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 7 |  |  | $ | 202,279 |  |  | $ | 7,131 |  |  | $ | 2,987 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 10,003 |  |  | $ | 165,360 |  |  | $ | 149 |  |  | $ | 693 |  |  | $ | 635 |  |  |  |
| Six months ended December 31, 2024 | $ | 21,040 |  |  | $ | 173,348 |  |  | $ | 371 |  |  | $ | 660 |  |  | $ | — |  |  |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 8,147 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 4,776 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 823 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 329 |  |  | $ | 534 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 46 |  |  |  |
| Six months ended December 31, 2024 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (6) |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 19,061 |  |  | $ | 347,122 |  |  | $ | 3,628 |  |  | $ | 3,100 |  |  | $ | 681 |  |  |  |
| Six months ended December 31, 2024 | $ | 26,152 |  |  | $ | 376,161 |  |  | $ | 7,502 |  |  | $ | 3,647 |  |  | $ | (6) |  |  |  |

- added (2026-02-06):
[0001375365-26-000007:note_history:80]
Our cash flow impact from transactions with our related parties for each of the six months ended December 31, 2025 and 2024, are as follows (in thousands):

- added (2026-02-06):
[0001375365-26-000007:note_history:81]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | — |  |  | $ | 344 |  |  | $ | 33,501 |  |  | $ | 88 |  |  | $ | 225 |  |  | $ | 5,551 |  |  | $ | 1,807 |  |
| Six months ended December 31, 2024 | $ | (1) |  |  | $ | 330 |  |  | $ | (45,875) |  |  | $ | 294 |  |  | $ | 154 |  |  | $ | 6,525 |  |  | $ | 2,946 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 197 |  |  | $ | 12,672 |  |  | $ | (13,405) |  |  | $ | 487 |  |  | $ | (175) |  |  | $ | 149 |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 108 |  |  | $ | (5,741) |  |  | $ | (9,739) |  |  | $ | (146) |  |  | $ | — |  |  | $ | 357 |  |  | $ | 14 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (1,498) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 5,077 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (270) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 842 |  |  | $ | — |  |  | $ | 146 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (1,571) |  |  | $ | 13,016 |  |  | $ | 20,096 |  |  | $ | 575 |  |  | $ | 50 |  |  | $ | 5,700 |  |  | $ | 1,807 |  |
| Six months ended December 31, 2024 | $ | 6,026 |  |  | $ | (5,411) |  |  | $ | (55,468) |  |  | $ | 148 |  |  | $ | 154 |  |  | $ | 6,882 |  |  | $ | 2,960 |  |

- removed (2026-02-06):
[0001375365-25-000030:note_history:82]
We have a variety of business relationships with Ablecom and Compuware, both of which are Taiwan-based corporations. Both Ablecom and Compuware are a major contract manufacturer for us and Compuware is also a distributor of our products. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, our President, Chief Executive Officer and Chairman of the Board. As of September 30, 2025, Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock. Charles Liang and his spouse, Sara Liu, who is also an officer and director for us, collectively owned approximately 10.5% of Ablecom’s capital stock as of September 30, 2025. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu owns any capital stock of Compuware and we do not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director of ours, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

- removed (2026-02-06):
[0001375365-25-000030:note_history:83]
We appointed Compuware as a non-exclusive authorized distributor of our products in Taiwan, China, and Australia. Compuware assumes the responsibility of installing our products at the site of the end customer, if required, and administers customer support in exchange for a discount from our standard price for its purchases. From time to time, Compuware acts as a sales representative for us in exchange for a fee that is based on a percentage of net sales generated from customers introduced to us. The fee structure for Compuware is comparable to the fee structure offered to other sales representatives in the same geographic region.

- removed (2026-02-06):
[0001375365-25-000030:note_history:84]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of our related parties had direct or indirect material interests in any transactions in which we were a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, our authorized reseller. During the three months ended September 30, 2025, we engaged in transactions whereby we sold $0.3 million of servers to Leadtek and did not purchase any graphics cards from Leadtek. During the three months ended September 30, 2024, we engaged in transactions in which it sold $0.1 million of servers to Leadtek and purchased $0.4 million of graphics cards from Leadtek.

- removed (2026-02-06):
[0001375365-25-000030:note_history:85]
We sold products worth $2.8 million and $4.8 million to the Corporate Venture during three months ended September 30, 2025 and 2024, respectively, and our share of intra-entity profits on the products that remained unsold by the Corporate Venture as of September 30, 2025 has been eliminated and have reduced the carrying value of our investment in the Corporate Venture due to prior impairment write-off. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. We had $1.8 million and less than $0.1 million due from the Corporate Venture in accounts receivable, net as of September 30, 2025 and June 30, 2025, respectively.

- removed (2026-02-06):
[0001375365-25-000030:note_history:86]
For the three months ended September 30, 2025, and 2024, we had no and immaterial sales to and purchases from, respectively, Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with our Chief Executive Officer. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Green Earth.

- removed (2026-02-06):
[0001375365-25-000030:note_history:87]
For the three months ended September 30, 2025 and 2024, we had no transactions directly or indirectly to Aeon Lighting Technology Inc. (“Aeon Lighting”). Aeon Lighting is a company which is owned more than 10% by James Liang, a brother of our Chief Executive Officer. James Liang is also a director of Aeon Lighting and serves as the Chief Executive Officer of such entity. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Aeon Lighting.

- removed (2026-02-06):
[0001375365-25-000030:note_history:88]
For the three months ended September 30, 2025, we had no sale or purchases transactions with Ampera, Inc. (“Ampera”). We represent approximately 33% on the board of directors as we have one board of director seat on a board of three. With the combination of our 11% equity interest and board representation, we have the ability to exercise significant influence over the operating and financial policies of Ampera. As of September 30, 2025 and June 30, 2025, there was no amount due to and from Ampera.

- removed (2026-02-06):
[0001375365-25-000030:note_history:89]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |
| Ablecom |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 42 |  |  | $ | 69,841 |  |  | $ | 1,655 |  |  | $ | 828 |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 2 |  |  | $ | 137,507 |  |  | $ | 4,492 |  |  | $ | 1,862 |  |  | $ | — |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 5,874 |  |  | $ | 85,487 |  |  | $ | 149 |  |  | $ | 188 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 9,975 |  |  | $ | 102,117 |  |  | $ | 357 |  |  | $ | 380 |  |  | $ | — |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 2,768 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,827 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 267 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 71 |  |  | $ | 427 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 8,951 |  |  | $ | 155,328 |  |  | $ | 1,804 |  |  | $ | 1,016 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 14,875 |  |  | $ | 240,051 |  |  | $ | 4,849 |  |  | $ | 2,242 |  |  | $ | — |  |

- removed (2026-02-06):
[0001375365-25-000030:note_history:90]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1) |  |  | $ | 375 |  |  | $ | (2,398) |  |  | $ | (7) |  |  | $ | (59) |  |  | $ | 3,879 |  |  | $ | 1,655 |  |
| Three months ended September 30, 2024 | $ | (2) |  |  | $ | (466) |  |  | $ | 29,999 |  |  | $ | 300 |  |  | $ | 237 |  |  | $ | 2,925 |  |  | $ | 3,906 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 249 |  |  | $ | 12,168 |  |  | $ | (21,775) |  |  | $ | 561 |  |  | $ | (92) |  |  | $ | 8 |  |  | $ | 141 |  |
| Three months ended September 30, 2024 | $ | (6,895) |  |  | $ | (2,669) |  |  | $ | 6,784 |  |  | $ | (70) |  |  | $ | — |  |  | $ | 204 |  |  | $ | 153 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,819) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,142 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (100) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 958 |  |  | $ | — |  |  | $ | (59) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,671) |  |  | $ | 12,543 |  |  | $ | (24,173) |  |  | $ | 554 |  |  | $ | (151) |  |  | $ | 3,887 |  |  | $ | 1,796 |  |
| Three months ended September 30, 2024 | $ | (1,797) |  |  | $ | (3,135) |  |  | $ | 36,724 |  |  | $ | 230 |  |  | $ | 237 |  |  | $ | 3,129 |  |  | $ | 4,059 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2026-02-06):
[0001375365-26-000007:note_history:91]
We had the following balances related to transactions with our related parties as of December 31, 2025 and June 30, 2025 (in thousands):
  (was, 2025-11-07, similarity 0.9802):
[0001375365-25-000030:note_history:91]
We had the following balances related to transactions with our related parties as of September 30, 2025 and June 30, 2025 (in thousands):

- changed (2026-02-06):
[0001375365-26-000007:note_history:92]
|  | Accounts receivable |  | Other receivables (1) |  | Other assets |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1 |  |  | $ | 618 |  |  | $ | 97 |  |  | $ | 88,961 |  |  | $ | 841 |  |  | $ | 339 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | — |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 88 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 60,887 |  |  | $ | 778 |  |  | $ | 319 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | — |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1,528 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 347 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| As of December 31, 2025 | $ | 1,964 |  |  | $ | 632 |  |  | $ | 97 |  |  | $ | 149,848 |  |  | $ | 1,619 |  |  | $ | 658 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | — |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |
  (was, 2025-11-07, similarity 0.8929):
[0001375365-25-000030:note_history:92]
|  | Accounts receivable |  | Other receivables (1) |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2 |  |  | $ | 684 |  |  | $ | 53,062 |  |  | $ | 746 |  |  | $ | 55 |  |
| As of June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 36 |  |  | $ | 518 |  |  | $ | 52,517 |  |  | $ | 852 |  |  | $ | 402 |  |
| As of June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 1,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 177 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| As of June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| As of September 30, 2025 | $ | 2,064 |  |  | $ | 1,202 |  |  | $ | 105,579 |  |  | $ | 1,598 |  |  | $ | 457 |  |
| As of June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |

- changed (2026-02-06):
[0001375365-26-000007:note_history:93]
(1) Other receivables include receivables from vendors included in prepaid expenses and other current assets.
  (was, 2025-11-07, similarity 0.9569):
[0001375365-25-000030:note_history:93]
(1) Other receivables include receivables from vendors included in prepaid and other current assets.

- changed (2026-02-06):
[0001375365-26-000007:note_history:94]
Our results from transactions with our related parties for each of the three months ended December 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-11-07, similarity 0.9821):
[0001375365-25-000030:note_history:94]
Our results from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):

- added (2026-02-06):
[0001375365-26-000007:note_history:95]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 46 |  |  | $ | 111,921 |  |  | $ | 1,824 |  |  | $ | 1,579 |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | 5 |  |  | $ | 64,773 |  |  | $ | 2,639 |  |  | $ | 1,125 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 4,129 |  |  | $ | 79,873 |  |  | $ | — |  |  | $ | 505 |  |  | $ | 699 |  |  |  |
| Three months ended December 31, 2024 | $ | 11,065 |  |  | $ | 71,230 |  |  | $ | 14 |  |  | $ | 280 |  |  | $ | — |  |  |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 5,379 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | (51) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 556 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Three months ended December 31, 2024 | $ | 258 |  |  | $ | 106 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 44 |  |  |  |
| Three months ended December 31, 2024 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended December 31, 2025 | $ | 10,110 |  |  | $ | 191,794 |  |  | $ | 1,824 |  |  | $ | 2,084 |  |  | $ | 743 |  |  |  |
| Three months ended December 31, 2024 | $ | 11,277 |  |  | $ | 136,109 |  |  | $ | 2,653 |  |  | $ | 1,405 |  |  | $ | — |  |  |  |

- changed (2026-02-06):
[0001375365-26-000007:note_history:96]
Our results from transactions with our related parties for each of the six months ended December 31, 2025 and 2024, are as follows (in thousands):
  (was, 2025-11-07, similarity 0.8951):
[0001375365-25-000030:note_history:96]
Our cash flow impact from transactions with our related parties for each of the three months ended September 30, 2025 and 2024, are as follows (in thousands):

- added (2026-02-06):
[0001375365-26-000007:note_history:97]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |  |  |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 88 |  |  | $ | 181,762 |  |  | $ | 3,479 |  |  | $ | 2,407 |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 7 |  |  | $ | 202,279 |  |  | $ | 7,131 |  |  | $ | 2,987 |  |  | $ | — |  |  |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 10,003 |  |  | $ | 165,360 |  |  | $ | 149 |  |  | $ | 693 |  |  | $ | 635 |  |  |  |
| Six months ended December 31, 2024 | $ | 21,040 |  |  | $ | 173,348 |  |  | $ | 371 |  |  | $ | 660 |  |  | $ | — |  |  |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 8,147 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 4,776 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 823 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Six months ended December 31, 2024 | $ | 329 |  |  | $ | 534 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |
| Green Earth |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 46 |  |  |  |
| Six months ended December 31, 2024 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (6) |  |  |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 19,061 |  |  | $ | 347,122 |  |  | $ | 3,628 |  |  | $ | 3,100 |  |  | $ | 681 |  |  |  |
| Six months ended December 31, 2024 | $ | 26,152 |  |  | $ | 376,161 |  |  | $ | 7,502 |  |  | $ | 3,647 |  |  | $ | (6) |  |  |  |

- added (2026-02-06):
[0001375365-26-000007:note_history:98]
Our cash flow impact from transactions with our related parties for each of the six months ended December 31, 2025 and 2024, are as follows (in thousands):

- added (2026-02-06):
[0001375365-26-000007:note_history:99]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | — |  |  | $ | 344 |  |  | $ | 33,501 |  |  | $ | 88 |  |  | $ | 225 |  |  | $ | 5,551 |  |  | $ | 1,807 |  |
| Six months ended December 31, 2024 | $ | (1) |  |  | $ | 330 |  |  | $ | (45,875) |  |  | $ | 294 |  |  | $ | 154 |  |  | $ | 6,525 |  |  | $ | 2,946 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | 197 |  |  | $ | 12,672 |  |  | $ | (13,405) |  |  | $ | 487 |  |  | $ | (175) |  |  | $ | 149 |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 108 |  |  | $ | (5,741) |  |  | $ | (9,739) |  |  | $ | (146) |  |  | $ | — |  |  | $ | 357 |  |  | $ | 14 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (1,498) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 5,077 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (270) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Six months ended December 31, 2024 | $ | 842 |  |  | $ | — |  |  | $ | 146 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Six months ended December 31, 2025 | $ | (1,571) |  |  | $ | 13,016 |  |  | $ | 20,096 |  |  | $ | 575 |  |  | $ | 50 |  |  | $ | 5,700 |  |  | $ | 1,807 |  |
| Six months ended December 31, 2024 | $ | 6,026 |  |  | $ | (5,411) |  |  | $ | (55,468) |  |  | $ | 148 |  |  | $ | 154 |  |  | $ | 6,882 |  |  | $ | 2,960 |  |

- removed (2026-02-06):
[0001375365-25-000030:note_history:100]
|  | Net sales |  | Cost of sales |  | Purchase of fixed assets |  | Research and Development |  | Sales and marketing |
| Ablecom |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 42 |  |  | $ | 69,841 |  |  | $ | 1,655 |  |  | $ | 828 |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 2 |  |  | $ | 137,507 |  |  | $ | 4,492 |  |  | $ | 1,862 |  |  | $ | — |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 5,874 |  |  | $ | 85,487 |  |  | $ | 149 |  |  | $ | 188 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 9,975 |  |  | $ | 102,117 |  |  | $ | 357 |  |  | $ | 380 |  |  | $ | — |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 2,768 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,827 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 267 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 71 |  |  | $ | 427 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 8,951 |  |  | $ | 155,328 |  |  | $ | 1,804 |  |  | $ | 1,016 |  |  | $ | (64) |  |
| Three months ended September 30, 2024 | $ | 14,875 |  |  | $ | 240,051 |  |  | $ | 4,849 |  |  | $ | 2,242 |  |  | $ | — |  |

- removed (2026-02-06):
[0001375365-25-000030:note_history:101]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1) |  |  | $ | 375 |  |  | $ | (2,398) |  |  | $ | (7) |  |  | $ | (59) |  |  | $ | 3,879 |  |  | $ | 1,655 |  |
| Three months ended September 30, 2024 | $ | (2) |  |  | $ | (466) |  |  | $ | 29,999 |  |  | $ | 300 |  |  | $ | 237 |  |  | $ | 2,925 |  |  | $ | 3,906 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | 249 |  |  | $ | 12,168 |  |  | $ | (21,775) |  |  | $ | 561 |  |  | $ | (92) |  |  | $ | 8 |  |  | $ | 141 |  |
| Three months ended September 30, 2024 | $ | (6,895) |  |  | $ | (2,669) |  |  | $ | 6,784 |  |  | $ | (70) |  |  | $ | — |  |  | $ | 204 |  |  | $ | 153 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,819) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 4,142 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (100) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Three months ended September 30, 2024 | $ | 958 |  |  | $ | — |  |  | $ | (59) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Three months ended September 30, 2025 | $ | (1,671) |  |  | $ | 12,543 |  |  | $ | (24,173) |  |  | $ | 554 |  |  | $ | (151) |  |  | $ | 3,887 |  |  | $ | 1,796 |  |
| Three months ended September 30, 2024 | $ | (1,797) |  |  | $ | (3,135) |  |  | $ | 36,724 |  |  | $ | 230 |  |  | $ | 237 |  |  | $ | 3,129 |  |  | $ | 4,059 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-02-06):
[0001375365-26-000007:note_history:102]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | % of Total |  | 2024 |  | % of Total |  | 2025 |  | % of Total |  | 2024 |  | % of Total |
| United States | $ | 10,928,946 |  |  | 86.2 | % |  | $ | 3,846,960 |  |  | 67.8 | % |  | $ | 12,763,423 |  |  | 72.1 | % |  | $ | 8,088,309 |  |  | 69.6 | % |
| Other (1) | 1,753,545 |  |  | 13.8 | % |  | 1,831,002 |  |  | 32.2 | % |  | 4,936,858 |  |  | 27.9 | % |  | 3,526,909 |  |  | 30.4 | % |
| Total | $ | 12,682,491 |  |  | 100.0 | % |  | $ | 5,677,962 |  |  | 100.0 | % |  | $ | 17,700,281 |  |  | 100.0 | % |  | $ | 11,615,218 |  |  | 100.0 | % |

- removed (2026-02-06):
[0001375365-25-000030:note_history:103]
|  | Three Months Ended September 30, |  |  |
|  | 2025 |  | % of Total |  | 2024 |  | % of Total |  |  |  |  |
| United States | $ | 1,834,477 |  |  | 36.6 | % |  | $ | 4,241,349 |  |  | 71.4 | % |  |  |  |  |
| Malaysia | 1,115,149 |  |  | 22.2 | % |  | 222,585 |  |  | 3.7 | % |  |  |  |  |
| Indonesia | 578,706 |  |  | 11.5 | % |  | 1,796 |  |  | — | % |  |  |  |  |
| Other (1) | 1,489,458 |  |  | 29.7 | % |  | 1,471,526 |  |  | 24.9 | % |  |  |  |  |
| Total | $ | 5,017,790 |  |  | 100.0 | % |  | $ | 5,937,256 |  |  | 100.0 | % |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2026-02-06):
[0001375365-26-000007:note_history:104]
Revenue Recognition

- added (2026-02-06):
[0001375365-26-000007:note_history:105]
We generate revenues from the sale of server and storage systems, subsystems, accessories and services.

- added (2026-02-06):
[0001375365-26-000007:note_history:106]
Product sales. We recognize revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is required. Determining the point in time that control transfers to the customer requires judgment. Products sold by us are shipped from our facilities or drop shipped from our vendors. We may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

- added (2026-02-06):
[0001375365-26-000007:note_history:107]
We apply judgment in determining the transaction price as our contracts may include forms of variable consideration, including customer rebates, returns, and cash discounts for prompt payment. Variable consideration is estimated using either the expected value or most likely amount method, depending on which method better predicts the amount of consideration to which we expect to be entitled. We include estimated variable consideration in the transaction price only to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Estimates of variable consideration are reassessed each reporting period and recorded as an adjustment to revenue, as applicable.

- added (2026-02-06):
[0001375365-26-000007:note_history:108]
Services sales. Our sale of services mainly consists of extended warranty and on-site services as well as system rack installation and integration services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as we stand ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Revenue related to system rack installation and integration services is recognized when we perform the services and the customer receives and consumes the benefits.

- added (2026-02-06):
[0001375365-26-000007:note_history:109]
Contracts with multiple promised goods and services. Certain of our contracts contain multiple promised goods and services. We assess whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from us, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation.

- added (2026-02-06):
[0001375365-26-000007:note_history:110]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. For contracts that contain multiple performance obligations, we allocate the transaction price for each customer contract to each performance obligation based on the relative Stand-alone Selling Price ("SSP") for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. We determine SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, we apply judgment to estimate the SSP. For all performance obligations, we are able to establish the SSP by maximizing the use of observable inputs. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

- added (2026-02-06):
[0001375365-26-000007:note_history:111]
Our credit terms are predominantly short-term in nature; however, we also grant extended payment terms for certain customers. For the contracts with the extended payment terms in which the financing component is determined to be significant to the contract, the contract transaction price is adjusted for the effect of a financing component.

- added (2026-02-06):
[0001375365-26-000007:note_history:112]
When we receive consideration from a customer prior to transferring goods or services to the customer, we record a contract liability (deferred revenue). We also recognize deferred revenue when we have an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

- added (2026-02-06):
[0001375365-26-000007:note_history:113]
Shipping and handling fees collected from customers are included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. We have elected to account for shipping and handling activities that occur after the customer has obtained control of a good as a fulfillment cost rather than as an additional promised service. Taxes imposed by governmental authorities on our revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2026-02-06):
[0001375365-26-000007:note_history:114]
CTBC credit agreement

- added (2026-02-06):
[0001375365-26-000007:note_history:115]
On January 21, 2026, we entered into a credit agreement with a group of lenders led by CTBC Bank Co., Ltd., along with Credit Agricole CIB, Taipei Branch and E.Sun Commercial Bank, Ltd. as lead arrangers. The agreement provides for two revolving credit facilities totaling $710.0 million, with an option to increase total commitments to up to $2.0 billion, subject to certain conditions. On January 30, 2026, we entered into an increased facilities letter under this credit agreement, providing for additional revolving credit facilities in an aggregate amount of $1.1 billion. As a result, the total lender commitments under the credit agreement increased to $1.8 billion.
