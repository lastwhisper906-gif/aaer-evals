# SMCI 8-K — 0001375365-26-000006 filed 2026-02-03

## item codes, every 8-K on or before 2026-02-06

- 2026-02-03 0001375365-26-000006 — 2.02, 9.01
- 2026-01-29 0001375365-26-000005 — 1.01, 9.01
- 2026-01-26 0001375365-26-000004 — 1.01, 5.08, 8.01, 9.01
- 2026-01-02 0001375365-26-000002 — 5.02, 9.01 — amendment of 0001375365-25-000031
- 2026-01-02 0001375365-26-000001 — 1.01, 9.01
- 2025-12-29 0001375365-25-000031 — 5.02, 9.01
- 2025-11-04 0001375365-25-000029 — 2.02, 9.01
- 2025-10-23 0001628280-25-045989 — 2.02, 9.01
- 2025-08-05 0001375365-25-000023 — 2.02, 9.01
- 2025-07-21 0001375365-25-000022 — 1.01, 2.03, 9.01
- 2025-06-27 0001375365-25-000020 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-06-23 0001375365-25-000018 — 8.01, 9.01
- 2025-06-06 0001375365-25-000016 — 5.02, 5.07, 9.01
- 2025-05-06 0001375365-25-000013 — 2.02, 9.01
- 2025-04-29 0001375365-25-000012 — 2.02, 9.01
- 2025-03-31 0001375365-25-000008 — 5.02, 7.01, 9.01
- 2025-02-26 0001375365-25-000007 — 3.01, 5.08, 8.01, 9.01
- 2025-02-21 0001375365-25-000003 — 1.01, 2.03, 3.02, 9.01
- 2025-02-11 0001375365-25-000001 — 2.02, 8.01, 9.01
- 2024-12-27 0001375365-24-000046 — 1.02, 9.01
- 2024-12-06 0001375365-24-000045 — 3.01, 9.01
- 2024-12-02 0001375365-24-000044 — 5.02, 8.01, 9.01
- 2024-11-26 0001375365-24-000043 — 1.02, 9.01
- 2024-11-20 0001375365-24-000042 — 1.01, 2.03, 3.01, 9.01
- 2024-11-18 0001375365-24-000040 — 4.01, 8.01, 9.01
- 2024-11-05 0001375365-24-000038 — 1.02, 2.02, 9.01
- 2024-11-01 0001375365-24-000037 — 1.01, 2.03, 9.01
- 2024-10-30 0001375365-24-000036 — 4.01, 9.01
- 2024-09-30 0001375365-24-000035 — 1.01, 2.03, 3.03, 5.03, 9.01
- 2024-09-26 0001375365-24-000034 — 8.01, 9.01
- 2024-09-20 0001375365-24-000033 — 3.01, 9.01
- 2024-09-03 0001375365-24-000032 — 7.01, 9.01
- 2024-08-28 0001375365-24-000030 — 8.01, 9.01
- 2024-08-19 0001375365-24-000029 — 5.02, 7.01, 9.01
- 2024-08-06 0001375365-24-000028 — 2.02, 9.01
- 2024-07-22 0001375365-24-000027 — 1.01, 7.01, 9.01
- 2024-06-21 0001375365-24-000026 — 1.01, 2.03, 9.01
- 2024-05-09 0001375365-24-000023 — 3.01, 9.01
- 2024-04-30 0001375365-24-000021 — 2.02, 9.01
- 2024-03-22 0001375365-24-000020 — 1.01, 8.01, 9.01
- 2024-03-15 0001375365-24-000019 — 5.02, 9.01
- 2024-02-28 0001375365-24-000017 — 1.01, 2.03, 3.02, 9.01
- 2024-02-23 0001375365-24-000016 — 8.01, 9.01
- 2024-02-22 0001375365-24-000015 — 1.01, 8.01, 9.01
- 2024-02-20 0001375365-24-000014 — 1.01, 2.03, 9.01
- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2026-02-06

- 2025-02-11 0001375365-25-000002 — NT 10-Q, for the period ended 2024-12-31
- 2024-11-13 0001375365-24-000039 — NT 10-Q, for the period ended 2024-09-30
- 2024-08-30 0001375365-24-000031 — NT 10-K, for the period ended 2024-08-30
- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-26-000006:8k_2_02:1]
EX-99.1
2
exhibit991_20251231.htm
EX-99.1

[0001375365-26-000006:8k_2_02:2]
Document

[0001375365-26-000006:8k_2_02:3]
Exhibit 99.1

[0001375365-26-000006:8k_2_02:4]
Supermicro Announces Second Quarter Fiscal Year 2026 Financial Results

[0001375365-26-000006:8k_2_02:5]
SAN JOSE, Calif. -- February 3, 2026 -- (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ: SMCI) (“Supermicro” or the “Company”), a Total IT Solution Provider for AI, Cloud, Storage, and 5G/Edge, today announced unaudited financial results for its second quarter of fiscal year 2026 ended December 31, 2025.

[0001375365-26-000006:8k_2_02:6]
Second Quarter Fiscal Year 2026 Highlights

[0001375365-26-000006:8k_2_02:7]
•Net sales of $12.7 billion versus $5.0 billion in Q1'26 and $5.7 billion in Q2'25

[0001375365-26-000006:8k_2_02:8]
•Gross margin of 6.3% versus 9.3% in Q1'26 and 11.8% in Q2'25

[0001375365-26-000006:8k_2_02:9]
•Net income of $401 million versus $168 million in Q1'26 and $321 million in Q2'25

[0001375365-26-000006:8k_2_02:10]
•Diluted net income per common share of $0.60 versus $0.26 in Q1'26 and $0.51 in Q2'25

[0001375365-26-000006:8k_2_02:11]
•Non-GAAP gross margin of 6.4% versus 11.9% in Q2'25

[0001375365-26-000006:8k_2_02:12]
•Non-GAAP diluted net income per common share of $0.69 versus $0.59 in Q2'25

[0001375365-26-000006:8k_2_02:13]
•Cash flow used in operations for Q2'26 of $24 million and capital expenditures and investments of $46 million

[0001375365-26-000006:8k_2_02:14]
“With our leading AI server and storage technology foundation, strong customer engagements, and expanding global manufacturing footprint, we are scaling rapidly to support large AI and enterprise deployments while continuing to strengthen our operational and financial execution,” said Charles Liang, Founder, President and CEO of Supermicro. “Our DCBBS, Data Center Building Block Solutions, enable customers to scale faster, greener, and at lower cost, Supermicro is well positioned to capture the next wave of AI and IT infrastructure demand.”

[0001375365-26-000006:8k_2_02:15]
As of December 31, 2025, total cash and cash equivalents was $4.1 billion and total bank debt and convertible notes were $4.9 billion.

[0001375365-26-000006:8k_2_02:16]
Business Outlook

[0001375365-26-000006:8k_2_02:17]
The Company expects net sales of at least $12.3 billion for the third quarter of fiscal year 2026 ending March 31, 2026, GAAP net income per diluted share of at least $0.52 and non-GAAP net income per diluted share of at least $0.60. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 19.6% and 20.2%, respectively, and a fully diluted share count of 684 million shares for GAAP and fully diluted share count of 699 million shares for non-GAAP. The outlook for the third quarter of fiscal year 2026 GAAP net income per diluted share includes approximately $62 million in expected stock-based compensation, net of related tax effects of $19 million that are excluded from non-GAAP net income per diluted share.

[0001375365-26-000006:8k_2_02:18]
For fiscal year 2026, the Company expects net sales of at least $40.0 billion.

[0001375365-26-000006:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-26-000006:8k_2_02:20]
Supermicro will present a live audio webcast of our conference call to review its second quarter of fiscal year 2026 financial results on Tuesday, February 3, 2026, at 5:00 p.m. ET / 2:00 p.m. PT. The webcast will be available at https://ir.supermicro.com.

[0001375365-26-000006:8k_2_02:21]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-26-000006:8k_2_02:22]
Forward Looking Statements and Other Disclosures

[0001375365-26-000006:8k_2_02:23]
About Super Micro Computer, Inc.

[0001375365-26-000006:8k_2_02:24]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. We are a Total IT Solutions manufacturer with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enables our development and production, enabling next-generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-26-000006:8k_2_02:25]
Supermicro, Server Building Block Solution, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-26-000006:8k_2_02:26]
All other brands, names, and trademarks are the property of their respective owners.

[0001375365-26-000006:8k_2_02:27]
Investor Relations Contact:

[0001375365-26-000006:8k_2_02:28]
Nicole Noutsios

[0001375365-26-000006:8k_2_02:29]
Stratos Advisors

[0001375365-26-000006:8k_2_02:30]
email: ir@supermicro.com

[0001375365-26-000006:8k_2_02:31]
Source: Super Micro Computer, Inc.

[0001375365-26-000006:8k_2_02:32]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:33]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-26-000006:8k_2_02:34]
(in thousands)

[0001375365-26-000006:8k_2_02:35]
(unaudited)

[0001375365-26-000006:8k_2_02:36]
|  | December 31, |  | June 30, |
|  | 2025 |  | 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 4,091,083 |  |  | $ | 5,169,911 |  |
| Accounts receivable, net of allowance for credit losses | 11,004,122 |  |  | 2,203,942 |  |
| Inventories | 10,595,448 |  |  | 4,680,375 |  |
| Prepaid expenses and other current assets | 433,944 |  |  | 247,426 |  |
| Total current assets | 26,124,597 |  |  | 12,301,654 |  |
| Property, plant, and equipment, net | 538,584 |  |  | 504,488 |  |
| Deferred income taxes, net | 655,367 |  |  | 607,416 |  |
| Other assets | 683,062 |  |  | 604,871 |  |
| Total assets | $ | 28,001,610 |  |  | $ | 14,018,429 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 13,753,207 |  |  | $ | 1,281,977 |  |
| Accrued liabilities | 548,179 |  |  | 565,637 |  |
| Income taxes payable | 118,700 |  |  | 53,381 |  |
| Lines of credit and current portion of term loans | 201,776 |  |  | 75,060 |  |
| Deferred revenue | 774,846 |  |  | 368,737 |  |
| Total current liabilities | 15,396,708 |  |  | 2,344,792 |  |
| Deferred revenue, non-current | 527,909 |  |  | 362,645 |  |
| Term loans, non-current | 21,437 |  |  | 37,415 |  |
| Convertible notes | 4,654,623 |  |  | 4,645,178 |  |
| Other long-term liabilities | 408,756 |  |  | 326,528 |  |
| Total liabilities | 21,009,433 |  |  | 7,716,558 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 2,987,932 |  |  | 2,866,449 |  |
| Accumulated other comprehensive income | 695 |  |  | 705 |  |
| Retained earnings | 4,003,388 |  |  | 3,434,539 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 6,992,015 |  |  | 6,301,693 |  |
| Non-controlling interest | 162 |  |  | 178 |  |
| Total stockholders’ equity | 6,992,177 |  |  | 6,301,871 |  |
| Total liabilities and stockholders’ equity | $ | 28,001,610 |  |  | $ | 14,018,429 |  |

[0001375365-26-000006:8k_2_02:37]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-26-000006:8k_2_02:39]
(in thousands, except per share amounts)

[0001375365-26-000006:8k_2_02:40]
(unaudited)

[0001375365-26-000006:8k_2_02:41]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 12,682,491 |  |  | $ | 5,677,962 |  |  | $ | 17,700,281 |  |  | $ | 11,615,218 |  |
| Cost of sales | 11,883,924 |  |  | 5,007,940 |  |  | 16,434,341 |  |  | 10,169,616 |  |
| Gross profit | 798,567 |  |  | 670,022 |  |  | 1,265,940 |  |  | 1,445,602 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 180,761 |  |  | 158,229 |  |  | 354,075 |  |  | 290,472 |  |
| Sales and marketing | 73,078 |  |  | 79,568 |  |  | 121,006 |  |  | 148,422 |  |
| General and administrative | 70,430 |  |  | 63,601 |  |  | 134,305 |  |  | 128,885 |  |
| Total operating expenses | 324,269 |  |  | 301,398 |  |  | 609,386 |  |  | 567,779 |  |
| Income from operations | 474,298 |  |  | 368,624 |  |  | 656,554 |  |  | 877,823 |  |
| Other income, net | 225 |  |  | 4,183 |  |  | 96 |  |  | 3,409 |  |
| Interest income | 51,042 |  | 8,776 |  | 102,398 |  | 16,783 |
| Interest expense | (25,358) |  |  | (6,535) |  |  | (50,289) |  |  | (23,889) |  |
| Income before income tax provision | 500,207 |  |  | 375,048 |  |  | 708,759 |  |  | 874,126 |  |
| Income tax provision | (99,151) |  |  | (56,969) |  |  | (139,312) |  |  | (131,701) |  |
| Share of (loss) gain from equity investee, net of taxes | (492) |  |  | 2,517 |  |  | (598) |  |  | 2,498 |  |
| Net income | $ | 400,564 |  |  | $ | 320,596 |  |  | $ | 568,849 |  |  | $ | 744,923 |  |
| Net income per common share (A): |  |  |  |  |  |  |  |
| Basic | $ | 0.67 |  |  | $ | 0.54 |  |  | $ | 0.95 |  |  | $ | 1.26 |  |
| Diluted | $ | 0.60 |  |  | $ | 0.51 |  |  | $ | 0.86 |  |  | $ | 1.17 |  |
| Weighted-average shares used in the calculation of net income per common share (A): |  |  |  |  |  |  |  |
| Basic | 598,004 |  |  | 592,507 |  |  | 596,814 |  |  | 591,033 |  |
| Diluted | 693,989 |  |  | 636,047 |  |  | 674,068 |  |  | 637,597 |  |

[0001375365-26-000006:8k_2_02:42]
(A) Reflects a ten-for-one stock split on September 30, 2024.

[0001375365-26-000006:8k_2_02:43]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-26-000006:8k_2_02:44]
|  |  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |
| Cost of sales |  | $ | 6,803 |  |  | $ | 6,694 |  |  | $ | 13,878 |  |  | $ | 10,653 |  |  |  |
| Research and development |  | 59,542 |  |  | 50,809 |  |  | 116,975 |  |  | 87,336 |  |  |  |
| Sales and marketing |  | 10,324 |  |  | 9,559 |  |  | 21,424 |  |  | 17,322 |  |  |  |
| General and administrative |  | 13,816 |  |  | 15,060 |  |  | 27,347 |  |  | 30,825 |  |  |  |
| Stock-based compensation expense, before taxes |  | $ | 90,485 |  |  | $ | 82,122 |  |  | $ | 179,624 |  |  | $ | 146,136 |  |  |  |

[0001375365-26-000006:8k_2_02:45]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-26-000006:8k_2_02:47]
(in thousands)

[0001375365-26-000006:8k_2_02:48]
(unaudited)

[0001375365-26-000006:8k_2_02:49]
|  | Six Months Ended December 31, |
|  | 2025 |  | 2024 |  |
| OPERATING ACTIVITIES: |  |  |  |  |
| Net income | $ | 568,849 |  |  | $ | 744,923 |  |  |
| Reconciliation of net income to net cash (used in) provided by operating activities: |  |  |  |  |
| Depreciation and amortization | 25,354 |  |  | 18,557 |  |  |
| Amortization of right-of-use (“ROU”) assets | 17,670 |  |  | 5,991 |  |  |
| Amortization of debt discount and issuance costs | 9,506 |  |  | 4,415 |  |  |
| Inventory valuation adjustment write-down | 169,100 |  |  | 34,032 |  |  |
| Stock-based compensation expense | 179,624 |  |  | 146,136 |  |  |
| Impairment loss | 13,747 |  |  | — |  |  |
| Share of loss (gain) from equity investee | 598 |  |  | (2,498) |  |  |
| Unrealized foreign currency exchange loss (gain) | 159 |  |  | (300) |  |  |
| Deferred income taxes, net | (51,875) |  |  | (76,078) |  |  |
| Other non-cash income, net | (8,705) |  |  | (4,125) |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net | (8,792,828) |  |  | (319,374) |  |  |
| Inventories | (6,088,819) |  |  | 699,613 |  |  |
| Prepaid expenses and other assets | (58,855) |  |  | (398,769) |  |  |
| Accounts payable | 12,466,768 |  |  | (906,916) |  |  |
| Accrued liabilities | (39,661) |  |  | (59,654) |  |  |
| Income taxes payable | 68,041 |  |  | 96,845 |  |  |
| Deferred revenue | 571,373 |  |  | 182,276 |  |  |
| Other long-term liabilities | 8,533 |  |  | 4,073 |  |  |
| Net cash (used in) provided by operating activities | (941,421) |  |  | 169,147 |  |  |
| INVESTING ACTIVITIES: |  |  |  |  |
| Purchases of property, plant, and equipment | (53,491) |  |  | (71,836) |  |  |
| Investment in equity securities | (25,000) |  |  | — |  |  |
| Net cash used in investing activities | (78,491) |  |  | (71,836) |  |  |
| FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from lines of credit and term loans | 238,800 |  |  | 1,306,777 |  |  |
| Repayment of lines of credit and term loans | (123,391) |  |  | (1,574,059) |  |  |
| Payment of debt issuance costs | (9,785) |  |  | — |  |  |
| Proceeds from exercise of stock options | 12,925 |  |  | 6,869 |  |  |
| Payment for withholding taxes related to settlement of equity awards | (71,066) |  |  | (77,036) |  |  |
| Other | 14 |  |  | 15 |  |  |
| Net cash provided by (used in) financing activities | 47,497 |  |  | (337,434) |  |  |
| Effect of exchange rate fluctuations on cash | (6,161) |  |  | 837 |  |  |
| Net decrease in cash, cash equivalents and restricted cash | (978,576) |  |  | (239,286) |  |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 5,172,301 |  |  | 1,670,273 |  |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 4,193,725 |  |  | $ | 1,430,987 |  |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |
| Cash paid for interest | $ | 40,470 |  |  | $ | 19,006 |  |  |
| Cash paid for taxes, net of refunds | $ | 90,574 |  |  | $ | 57,029 |  |  |

[0001375365-26-000006:8k_2_02:50]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-26-000006:8k_2_02:52]
(in thousands)

[0001375365-26-000006:8k_2_02:53]
(unaudited)

[0001375365-26-000006:8k_2_02:54]
| Non-cash investing and financing activities: |  |  |  |  |
| Unpaid property, plant, and equipment purchases | $ | 17,131 |  |  | $ | 26,674 |  |  |
| ROU assets obtained in exchange for operating lease commitments | $ | 94,073 |  |  | $ | 18,472 |  |  |
| Transfer of inventory to property, plant, and equipment, net | $ | 4,646 |  |  | $ | 3,238 |  |  |

[0001375365-26-000006:8k_2_02:55]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:56]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000006:8k_2_02:57]
(in thousands, except per share amounts)

[0001375365-26-000006:8k_2_02:58]
(unaudited)

[0001375365-26-000006:8k_2_02:59]
Use of Non-GAAP Financial Measures

[0001375365-26-000006:8k_2_02:60]
To supplement its condensed consolidated financial results presented in accordance with United States Generally Accepted Accounting Principles (“GAAP”), the Company uses non-GAAP measures that are adjusted for certain items from the most directly comparable GAAP measures. The specific non-GAAP measures presented below are: gross profit, gross margin; operating expenses; net income; net income per common share; diluted net income; diluted net income per common share, adjusted earnings before interest, taxes, depreciation, and amortization, (“Adjusted EBITDA”); and effective tax rate. Management believes these non-GAAP measures provide useful information to investors by offering a consistent basis for comparing the Company's performance across periods, excluding items that are not reflective of our core operating results. These non-GAAP measures are not prepared in accordance with GAAP or intended to be a replacement for GAAP financial data; and therefore, should be reviewed together with the GAAP measures and are not intended to serve as a substitute for results under GAAP, and may be different from non-GAAP measures used by other companies.

[0001375365-26-000006:8k_2_02:61]
We exclude the following adjustments from our non-GAAP financial measures:

[0001375365-26-000006:8k_2_02:62]
Non-GAAP Adjustments

[0001375365-26-000006:8k_2_02:63]
•Stock-based compensation: Stock-based compensation relates primarily to our equity incentive awards. Stock-based compensation is a non-cash expense that is dependent on market forces that are difficult to predict. We believe that this adjustment for stock-based compensation provides investors with a basis to measure the company's core performance, including compared with the performance of other companies, without the period-to-period variability created by stock-based compensation.

[0001375365-26-000006:8k_2_02:64]
•Adjusted EBITDA adjustments: When calculating Adjusted EBITDA, in addition to the adjustments described above, we exclude the impact of Interest expense, Income tax (provision) benefit, and Depreciation and amortization during the period.

[0001375365-26-000006:8k_2_02:65]
Pursuant to the requirements of SEC Regulation G, please see the tables below for the reconciliations of GAAP to Non-GAAP measures. These should be read together with the preceding financial statements prepared in accordance with GAAP.

[0001375365-26-000006:8k_2_02:66]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:67]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000006:8k_2_02:68]
(in thousands, except per share amounts)

[0001375365-26-000006:8k_2_02:69]
(unaudited)

[0001375365-26-000006:8k_2_02:70]
Reconciliation of GAAP Net Income to Adjusted EBITDA:

[0001375365-26-000006:8k_2_02:71]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| GAAP Net Income | $ | 400,564 |  |  | $ | 320,596 |  |  | $ | 568,849 |  |  | $ | 744,923 |  |
| Interest expense | 25,358 |  |  | 6,535 |  |  | 50,289 |  |  | 23,889 |  |
| Income tax provision | 99,151 |  |  | 56,969 |  |  | 139,312 |  |  | 131,701 |  |
| Depreciation and amortization | 13,013 |  |  | 9,183 |  |  | 25,354 |  |  | 18,557 |  |
| Stock-based compensation | 90,485 |  |  | 82,122 |  |  | 179,624 |  |  | 146,136 |  |
| Adjusted EBITDA | $ | 628,571 |  |  | $ | 475,405 |  |  | $ | 963,428 |  |  | $ | 1,065,206 |  |
| Adjusted EBITDA % of net sales | 5.0 | % |  | 8.4 | % |  | 5.4 | % |  | 9.2 | % |

[0001375365-26-000006:8k_2_02:72]
Reconciliation of GAAP to Non-GAAP Gross Margin:

[0001375365-26-000006:8k_2_02:73]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| GAAP Gross Profit | $ | 798,567 |  |  | $ | 670,022 |  |  | $ | 1,265,940 |  |  | $ | 1,445,602 |  |
| Stock-based compensation | 6,803 |  |  | 6,694 |  |  | 13,878 |  |  | 10,653 |  |
| Non-GAAP Gross Profit | $ | 805,370 |  |  | $ | 676,716 |  |  | $ | 1,279,818 |  |  | $ | 1,456,255 |  |
| GAAP gross margin (%) | 6.3 | % |  | 11.8 | % |  | 7.2 | % |  | 12.4 | % |
| Stock-based compensation (%) | 0.1 | % |  | 0.1 | % |  | — | % | * | 0.1 | % |
| Non-GAAP gross margin (%) | 6.4 | % |  | 11.9 | % |  | 7.2 | % |  | 12.5 | % |

[0001375365-26-000006:8k_2_02:74]
*Represents an amount less than 0.1%.

[0001375365-26-000006:8k_2_02:75]
Reconciliation of GAAP to Non-GAAP Operating Expenses:

[0001375365-26-000006:8k_2_02:76]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| GAAP Operating Expenses | $ | 324,269 |  |  | $ | 301,398 |  |  | $ | 609,386 |  |  | $ | 567,779 |  |
| Adjustments to operating expenses |  |  |  |  |  |  |  |
| GAAP R&D operating expenses | 180,761 |  |  | 158,229 |  |  | 354,075 |  |  | 290,472 |  |
| Stock-based compensation | (59,542) |  |  | (50,809) |  |  | (116,975) |  |  | (87,336) |  |
| Non-GAAP R&D operating expenses | 121,219 |  |  | 107,420 |  |  | 237,100 |  |  | 203,136 |  |
| GAAP S&M operating expenses | 73,078 |  |  | 79,568 |  |  | 121,006 |  |  | 148,422 |  |
| Stock-based compensation | (10,324) |  |  | (9,559) |  |  | (21,424) |  |  | (17,322) |  |
| Non-GAAP S&M operating expenses | 62,754 |  |  | 70,009 |  |  | 99,582 |  |  | 131,100 |  |
| GAAP G&A operating expenses | 70,430 |  |  | 63,601 |  |  | 134,305 |  |  | 128,885 |  |
| Stock-based compensation | (13,816) |  |  | (15,060) |  |  | (27,347) |  |  | (30,825) |  |
| Non-GAAP G&A operating expenses | 56,614 |  |  | 48,541 |  |  | 106,958 |  |  | 98,060 |  |
| Non-GAAP Operating Expenses | $ | 240,587 |  |  | $ | 225,970 |  |  | $ | 443,640 |  |  | $ | 432,296 |  |

[0001375365-26-000006:8k_2_02:77]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:78]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000006:8k_2_02:79]
(in thousands, except per share amounts)

[0001375365-26-000006:8k_2_02:80]
(unaudited)

[0001375365-26-000006:8k_2_02:81]
Reconciliation of GAAP to Non-GAAP Net Income:

[0001375365-26-000006:8k_2_02:82]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| GAAP Net Income - basic | $ | 400,564 |  |  | $ | 320,596 |  |  | $ | 568,849 |  |  | $ | 744,923 |  |
| Adjustments related to stock-based compensation: |  |  |  |  |  |  |  |
| Cost of sales | 6,803 |  |  | 6,694 |  |  | 13,878 |  |  | 10,653 |  |
| Operating expenses | 83,682 |  |  | 75,428 |  |  | 165,746 |  |  | 135,483 |  |
| Total adjustments to GAAP income before income tax provision | 90,485 |  |  | 82,122 |  |  | 179,624 |  |  | 146,136 |  |
| Income tax effect of non-GAAP adjustments | (22,459) |  |  | (19,136) |  |  | (41,660) |  |  | (35,009) |  |
| Non-GAAP net income - basic | $ | 468,590 |  |  | $ | 383,582 |  |  | $ | 706,813 |  |  | $ | 856,050 |  |
| GAAP net income - basic | $ | 400,564 |  |  | $ | 320,596 |  |  | $ | 568,849 |  |  | $ | 744,923 |  |
| Convertible notes interest charge, net of tax | 17,888 |  |  | 1,110 |  |  | 10,986 |  |  | 3,859 |  |
| GAAP net income - diluted | $ | 418,452 |  |  | $ | 321,706 |  |  | $ | 579,835 |  |  | $ | 748,782 |  |
| Non-GAAP net income - basic | $ | 468,590 |  |  | $ | 383,582 |  |  | $ | 706,813 |  |  | $ | 856,050 |  |
| Convertible notes interest charge, net of tax | 17,888 |  |  | 1,110 |  |  | 10,986 |  |  | 3,859 |  |
| Non-GAAP net income - diluted | $ | 486,478 |  |  | $ | 384,692 |  |  | $ | 717,799 |  |  | $ | 859,909 |  |
| Weighted-average shares used in the calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic - GAAP | 598,004 |  |  | 592,507 |  |  | 596,814 |  |  | 591,033 |  |
| Basic - Non-GAAP | 598,004 |  |  | 592,507 |  |  | 596,814 |  |  | 591,033 |  |
| Diluted - GAAP | 693,989 |  |  | 636,047 |  |  | 674,068 |  |  | 637,597 |  |
| Non-GAAP adjustment | 15,126 |  |  | 10,624 |  |  | 14,259 |  |  | 9,777 |  |
| Diluted - Non-GAAP | 709,115 |  |  | 646,671 |  |  | 688,327 |  |  | 647,374 |  |

[0001375365-26-000006:8k_2_02:83]
Reconciliation of GAAP to Non-GAAP EPS:

[0001375365-26-000006:8k_2_02:84]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| GAAP Net Income per common share - basic | $ | 0.67 |  |  | $ | 0.54 |  |  | $ | 0.95 |  |  | $ | 1.26 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |
| Stock-based compensation | 0.15 |  |  | 0.14 |  |  | 0.30 |  |  | 0.25 |  |
| Income tax | (0.04) |  |  | (0.03) |  |  | (0.07) |  |  | (0.06) |  |
| Non-GAAP Net Income per common share - basic | $ | 0.78 |  |  | $ | 0.65 |  |  | $ | 1.18 |  |  | $ | 1.45 |  |
| GAAP net income per common share - diluted | $ | 0.60 |  |  | $ | 0.51 |  |  | $ | 0.86 |  |  | $ | 1.17 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |
| Stock-based compensation | 0.13 |  |  | 0.12 |  |  | 0.25 |  |  | 0.22 |  |
| Income tax | (0.04) |  |  | (0.04) |  |  | (0.07) |  |  | (0.06) |  |
| Non-GAAP Net Income per common share – diluted | $ | 0.69 |  |  | $ | 0.59 |  |  | $ | 1.04 |  |  | $ | 1.33 |  |

[0001375365-26-000006:8k_2_02:85]
SUPER MICRO COMPUTER, INC.

[0001375365-26-000006:8k_2_02:86]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-26-000006:8k_2_02:87]
(in thousands, except per share amounts)

[0001375365-26-000006:8k_2_02:88]
(unaudited)

[0001375365-26-000006:8k_2_02:89]
GAAP to Non-GAAP Effective Tax Rate:

[0001375365-26-000006:8k_2_02:90]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| GAAP effective tax rate | 19.8 | % |  | 15.2 | % |  | 19.7 | % |  | 15.1 | % |
| Total adjustments to GAAP provision to income tax | 0.8 | % |  | 1.4 | % |  | 0.7 | % |  | 1.2 | % |
| Non-GAAP effective tax rate | 20.6 | % |  | 16.6 | % |  | 20.4 | % |  | 16.3 | % |
