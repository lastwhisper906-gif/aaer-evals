# SMCI MD&A — 0001375365-25-000006


## mdna

[0001375365-25-000006:mdna:1]
[same as prior period, unchanged from 0001375365-25-000005:mdna:1]

[0001375365-25-000006:mdna:2]
[same as prior period, unchanged from 0001375365-25-000005:mdna:2]

[0001375365-25-000006:mdna:3]
[same as prior period, unchanged from 0001375365-25-000005:mdna:3]

[0001375365-25-000006:mdna:4]
[same as prior period, unchanged from 0001375365-25-000005:mdna:4]

[0001375365-25-000006:mdna:5]
We commenced operations in 1993 and have been profitable every year since inception. For the three months ended December 31, 2024 and 2023, our net income was $320.6 million and $296.0 million, respectively. For the six months ended December 31, 2024 and 2023, our net income was $744.9 million and $453.0 million, respectively. In order to increase our sales and profits, we believe that we must continue to develop flexible and application optimized server and storage solutions and be among the first to market with new features and products and deliver Total IT Solutions that combine server, storage, networking and software that is integrated, validated and delivered at the rack and cluster (multi-rack) level. We must also continue to expand our software and customer service and support offerings, particularly as we increasingly focus on larger enterprise and large data center customers. Additionally, we must focus on development of our sales partners and distribution channels to further expand our market share. We measure our financial success based on various indicators, including growth in net sales, gross profit margin, operating margin, and growth in net income per common share. Among the key non-financial indicators of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. In this regard, we work closely with microprocessor and other key component vendors to take advantage of new technologies as they are introduced. Historically, our ability to introduce new products rapidly has allowed us to benefit from technology transitions such as the introduction of new GPUs, microprocessors and storage technologies. As a result, we monitor the product introduction cycles of NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Broadcom Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others closely and carefully. This also impacts our research and development expenditures as we continue to invest more in our current and future product development efforts.

[0001375365-25-000006:mdna:6]
SMCI | Q2 2025 Form 10-Q | 37

[0001375365-25-000006:mdna:7]
[same as prior period, unchanged from 0001375365-25-000005:mdna:6]

[0001375365-25-000006:mdna:8]
The increased use of artificial intelligence ("AI"), which has required increased datacenter capabilities, has substantially increased demand for our products in the recent past. We expect that the AI market, and thus the need for additional datacenter capabilities, will continue to strengthen, and we will therefore continue to enhance our product capabilities and breadth of our service offerings to meet the demand of the AI market and datacenters. We believe that the configuration of certain of our products to meet the unique needs of the AI market and datacenters differentiates us from many of our competitors and will lead us to secure an even greater market share going forward.

[0001375365-25-000006:mdna:9]
[same as prior period, unchanged from 0001375365-25-000005:mdna:10]

[0001375365-25-000006:mdna:10]
[same as prior period, unchanged from 0001375365-25-000005:mdna:11]

[0001375365-25-000006:mdna:11]
[same as prior period, unchanged from 0001375365-25-000005:mdna:12]

[0001375365-25-000006:mdna:12]
The following is a summary of our financial highlights for the three months ended December 31, 2024 and 2023:

[0001375365-25-000006:mdna:13]
•Net sales increased by 54.9% in the three months ended December 31, 2024 as compared to the three months ended December 31, 2023.

[0001375365-25-000006:mdna:14]
•Gross margin decreased to 11.8% in the three months ended December 31, 2024 from 15.4% in the three months ended December 31, 2023.

[0001375365-25-000006:mdna:15]
•Operating expenses increased by 56.2% as compared to the three months ended December 31, 2023 and were equal to 5.3% and 5.3% of net sales in the three months ended December 31, 2024 and 2023, respectively.

[0001375365-25-000006:mdna:16]
•Effective tax rate decreased to 15.2% in the three months ended December 31, 2024 from 17.3% in the three months ended December 31, 2023.

[0001375365-25-000006:mdna:17]
[same as prior period, unchanged from 0001375365-25-000005:mdna:18]

[0001375365-25-000006:mdna:18]
[same as prior period, unchanged from 0001375365-25-000005:mdna:19]

[0001375365-25-000006:mdna:19]
[same as prior period, unchanged from 0001375365-25-000005:mdna:20]

[0001375365-25-000006:mdna:20]
SMCI | Q2 2025 Form 10-Q | 38

[0001375365-25-000006:mdna:21]
[same as prior period, unchanged from 0001375365-25-000005:mdna:22]

[0001375365-25-000006:mdna:22]
[same as prior period, unchanged from 0001375365-25-000005:mdna:23]

[0001375365-25-000006:mdna:23]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |  |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  |
| Cost of sales | 88.2 | % |  | 84.6 | % |  | 87.6 | % |  | 84.1 | % |  |
| Gross profit | 11.8 | % |  | 15.4 | % |  | 12.4 | % |  | 15.9 | % |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development | 2.8 | % |  | 3.0 | % |  | 2.5 | % |  | 3.8 | % |  |
| Sales and marketing | 1.4 | % |  | 1.3 | % |  | 1.3 | % |  | 1.5 | % |  |
| General and administrative | 1.1 | % |  | 1.0 | % |  | 1.1 | % |  | 1.2 | % |  |
| Total operating expenses | 5.3 | % |  | 5.3 | % |  | 4.9 | % |  | 6.5 | % |  |
| Income from operations | 6.5 | % |  | 10.1 | % |  | 7.5 | % |  | 9.4 | % |  |
| Other income (expense), net | 0.2 | % |  | (0.2) | % |  | 0.2 | % |  | 0.0 | % |  |
| Interest expense | (0.1) | % |  | (0.2) | % |  | (0.2) | % |  | (0.2) | % |  |
| Income before income tax provision | 6.6 | % |  | 9.7 | % |  | 7.5 | % |  | 9.2 | % |  |
| Income tax provision | (1.0) | % |  | (1.7) | % |  | (1.1) | % |  | (1.4) | % |  |
| Share of income from equity investee, net of taxes | — | % | * | 0.1 | % |  | — | % | * | — | % | * |
| Net income | 5.6 | % |  | 8.1 | % |  | 6.4 | % |  | 7.8 | % |  |

[0001375365-25-000006:mdna:24]
[same as prior period, unchanged from 0001375365-25-000005:mdna:25]

[0001375365-25-000006:mdna:25]
[same as prior period, unchanged from 0001375365-25-000005:mdna:26]

[0001375365-25-000006:mdna:26]
[same as prior period, unchanged from 0001375365-25-000005:mdna:27]

[0001375365-25-000006:mdna:27]
[same as prior period, unchanged from 0001375365-25-000005:mdna:28]

[0001375365-25-000006:mdna:28]
The following table presents net sales by product type for the three and six months ended December 31, 2024 and 2023 (dollars in millions):

[0001375365-25-000006:mdna:29]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Server and storage systems | $ | 5,487.2 |  |  | $ | 3,435.6 |  |  | $ | 2,051.6 |  |  | 59.7 | % |  | $ | 11,234.9 |  |  | $ | 5,402.2 |  |  | $ | 5,832.7 |  |  | 108.0 | % |
| Percentage of total net sales | 96.6 | % |  | 93.7 | % |  |  |  |  |  | 96.7 | % |  | 93.4 | % |  |  |  |  |
| Subsystems and accessories | $ | 190.8 |  |  | $ | 229.3 |  |  | $ | (38.5) |  |  | (16.8) | % |  | $ | 380.3 |  |  | $ | 382.4 |  |  | $ | (2.1) |  |  | (0.5) | % |
| Percentage of total net sales | 3.4 | % |  | 6.3 | % |  |  |  |  |  | 3.3 | % |  | 6.6 | % |  |  |  |  |
| Total net sales | $ | 5,678.0 |  |  | $ | 3,664.9 |  |  | $ | 2,013.1 |  |  | 54.9 | % |  | $ | 11,615.2 |  |  | $ | 5,784.6 |  |  | $ | 5,830.6 |  |  | 100.8 | % |

[0001375365-25-000006:mdna:30]
SMCI | Q2 2025 Form 10-Q | 39

[0001375365-25-000006:mdna:31]
[same as prior period, unchanged from 0001375365-25-000005:mdna:32]

[0001375365-25-000006:mdna:32]
Comparison of Three Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:33]
[same as prior period, unchanged from 0001375365-25-000005:mdna:33]

[0001375365-25-000006:mdna:34]
The period-over-period decrease in net sales for our subsystems and accessories of 16.8% was primarily due to the focus on allocating certain supply chain constrained components to build and ship server and storage systems rather than selling them as parts of subsystems and accessories.

[0001375365-25-000006:mdna:35]
Comparison of Six Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:36]
The period-over-period increase in net sales of our server and storage systems was primarily driven by an increase in the demand from customers for GPU servers, HPC, and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of ASP.

[0001375365-25-000006:mdna:37]
The period-over-period decrease in net sales for our subsystems and accessories of 0.5% was primarily due to the focus on allocating certain supply chain constrained components to build and ship server and storage systems rather than selling them as parts of subsystems and accessories.

[0001375365-25-000006:mdna:38]
The following table presents net sales by geographic region for the three and six months ended December 31, 2024 and 2023 (dollars in millions):

[0001375365-25-000006:mdna:39]
|  | Three Months Ended December 31, |  | Change |  | Change |  | Six Months Ended December 31, |  | Change |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| United States | $ | 3,847.0 |  |  | $ | 2,605.6 |  |  | $ | 1,241.4 |  |  | 47.6 | % |  | $ | 8,088.3 |  |  | $ | 4,225.1 |  |  | $ | 3,863.2 |  |  | 91.4 | % |
| Percentage of total net sales | 67.8 | % |  | 71.1 | % |  |  |  |  |  | 69.6 | % |  | 73.0 | % |  |  |  |  |
| Asia | $ | 768.2 |  |  | $ | 656.2 |  |  | $ | 112.0 |  |  | 17.1 | % |  | $ | 1,722.8 |  |  | $ | 881.7 |  |  | $ | 841.1 |  |  | 95.4 | % |
| Percentage of total net sales | 13.5 | % |  | 17.9 | % |  |  |  |  |  | 14.8 | % |  | 15.2 | % |  |  |  |  |
| Europe | $ | 933.8 |  |  | $ | 288.4 |  |  | $ | 645.4 |  |  | 223.8 | % |  | $ | 1,579.6 |  |  | $ | 479.3 |  |  | $ | 1,100.3 |  |  | 229.6 | % |
| Percentage of total net sales | 16.4 | % |  | 7.9 | % |  |  |  |  |  | 13.6 | % |  | 8.3 | % |  |  |  |  |
| Others | $ | 129.0 |  |  | $ | 114.7 |  |  | $ | 14.3 |  |  | 12.5 | % |  | $ | 224.5 |  |  | $ | 198.5 |  |  | $ | 26.0 |  |  | 13.1 | % |
| Percentage of total net sales | 2.3 | % |  | 3.1 | % |  |  |  |  |  | 2.0 | % |  | 3.5 | % |  |  |  |  |
| Total net sales | $ | 5,678.0 |  |  | $ | 3,664.9 |  |  |  |  |  |  | $ | 11,615.2 |  |  | $ | 5,784.6 |  |  |  |  |  |

[0001375365-25-000006:mdna:40]
Comparison of Three Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:41]
The period-over-period increase in overall net sales is driven by an increase in demand from customers for GPU servers, HPC, and rack-scale solutions which have higher ASPs, especially for large enterprise and data center customers from the United States and Europe, where they have experienced significant growth. The period-over-period increase of net sales in Europe is mainly due to an increase in net sales in the United Kingdom, Spain and Sweden.

[0001375365-25-000006:mdna:42]
Comparison of Six Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:43]
The period-over-period increase in overall net sales is driven by an increase in demand from customers for GPU servers, HPC, and rack-scale solutions which have higher ASPs, especially for large enterprise and data center customers from the United States, Asia and Europe sales where they have experienced significant growth. The period-over-period increase of net sales in Europe and Asia is mainly due to an increase in net sales in the United Kingdom, Spain, Sweden and Singapore.

[0001375365-25-000006:mdna:44]
SMCI | Q2 2025 Form 10-Q | 40

[0001375365-25-000006:mdna:45]
[same as prior period, unchanged from 0001375365-25-000005:mdna:38]

[0001375365-25-000006:mdna:46]
[same as prior period, unchanged from 0001375365-25-000005:mdna:39]

[0001375365-25-000006:mdna:47]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the region where our products are sold. We work with Ablecom, one of our key contract manufacturers and a related party, for our chassis and certain other components. We also outsource a significant part of the manufacturing of certain components, particularly power supplies, to Compuware, also a related party. We also collaborate on design and development activities with Ablecom and Compuware, where we substantially fund the design costs and retain the intellectual property rights.

[0001375365-25-000006:mdna:48]
Cost of sales and gross margin for the three and six months ended December 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-25-000006:mdna:49]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Cost of sales | $ | 5,007.9 |  |  | $ | 3,100.6 |  |  | $ | 1,907.3 |  |  | 61.5 | % |  | $ | 10,169.6 |  |  | $ | 4,866.6 |  |  | $ | 5,303.0 |  |  | 109.0 | % |
| Gross profit | $ | 670.0 |  |  | $ | 564.3 |  |  | $ | 105.7 |  |  | 18.7 | % |  | $ | 1,445.6 |  |  | $ | 918.0 |  |  | $ | 527.6 |  |  | 57.5 | % |
| Gross margin | 11.8 | % |  | 15.4 | % |  |  |  | (3.6) | % |  | 12.4 | % |  | 15.9 | % |  |  |  | (3.5) | % |

[0001375365-25-000006:mdna:50]
Comparison of Three Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:51]
The period-over-period increase in cost of sales was primarily attributed to an increase of $1,858.7 million in costs of materials and contract manufacturing expenses, a $21.8 million increase in overhead costs, a $17.1 million increase in inventory write-down adjustment and a $9.7 million increase in freight costs primarily related to the increase in net sales volume.

[0001375365-25-000006:mdna:52]
The period-over-period decrease in the gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition and a change in product and customer mix.

[0001375365-25-000006:mdna:53]
Comparison of Six Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:54]
The period-over-period increase in cost of sales was primarily attributed to an increase of $5,206.2 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $41.0 million increase in overhead costs, a $34.0 million increase in freight costs primarily related to the increase in net sales volume, and a $21.8 million increase in inventory write-down adjustment.

[0001375365-25-000006:mdna:55]
The period-over-period decrease in the gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition and a change in product and customer mix.

[0001375365-25-000006:mdna:56]
SMCI | Q2 2025 Form 10-Q | 41

[0001375365-25-000006:mdna:57]
[same as prior period, unchanged from 0001375365-25-000005:mdna:46]

[0001375365-25-000006:mdna:58]
[same as prior period, unchanged from 0001375365-25-000005:mdna:47]

[0001375365-25-000006:mdna:59]
Sales and marketing expenses consist primarily of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, cost for tradeshows, sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses. The timing, magnitude and estimated usage of these programs can result in significant variations in reported sales and marketing expenses from period to period. Spending on cooperative marketing, reimbursed by our suppliers, typically increases in connection with new product releases by our suppliers.

[0001375365-25-000006:mdna:60]
[same as prior period, unchanged from 0001375365-25-000005:mdna:49]

[0001375365-25-000006:mdna:61]
Operating expenses for the three and six months ended December 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-25-000006:mdna:62]
|  | Three Months Ended December 31, |  | Change |  | Six Months Ended December 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Research and development | $ | 158.2 |  |  | $ | 108.8 |  |  | $ | 49.4 |  |  | 45.4 | % |  | $ | 290.5 |  |  | $ | 219.8 |  |  | $ | 70.7 |  |  | 32.2 | % |
| Percentage of total net sales | 2.8 | % |  | 3.0 | % |  |  |  |  |  | 2.5 | % |  | 3.8 | % |  |  |  |  |
| Sales and marketing | $ | 79.6 |  |  | $ | 46.9 |  |  | $ | 32.7 |  |  | 69.7 | % |  | $ | 148.4 |  |  | $ | 84.1 |  |  | $ | 64.3 |  |  | 76.5 | % |
| Percentage of total net sales | 1.4 | % |  | 1.3 | % |  |  |  |  |  | 1.3 | % |  | 1.5 | % |  |  |  |  |
| General and administrative | $ | 63.6 |  |  | $ | 37.2 |  |  | $ | 26.4 |  |  | 71.0 | % |  | $ | 128.9 |  |  | $ | 70.1 |  |  | $ | 58.8 |  |  | 83.9 | % |
| Percentage of total net sales | 1.1 | % |  | 1.0 | % |  |  |  |  |  | 1.1 | % |  | 1.2 | % |  |  |  |  |
| Total operating expenses | $ | 301.4 |  |  | $ | 192.9 |  |  | $ | 108.5 |  |  | 56.2 | % |  | $ | 567.8 |  |  | $ | 374.0 |  |  | $ | 193.8 |  |  | 51.8 | % |
| Percentage of total net sales | 5.3 | % |  | 5.3 | % |  |  |  |  |  | 4.9 | % |  | 6.5 | % |  |  |  |  |

[0001375365-25-000006:mdna:63]
SMCI | Q2 2025 Form 10-Q | 42

[0001375365-25-000006:mdna:64]
Comparison of Three Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:65]
Research and development expenses. The period-over-period increase in research and development expenses was driven by a $39.8 million increase in employee related costs including stock-based compensation expense, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $12.6 million increase in product development costs to support next generation products and technologies, offset by a $3.0 million increase in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-25-000006:mdna:66]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was driven by a $14.9 million increase in employee related costs including stock-based compensation expense, salary increases and higher headcount as we expanded our workforce and invested in key talent, and a $19.6 million increase in advertising and other expenses, which was offset by a $1.8 million increase in marketing development funds received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000006:mdna:67]
General and administrative expenses. The period-over-period increase in general and administrative expenses was driven by a $16.0 million increase in professional and service fees primarily driven by expenses associated with the circumstances discussed in the Explanatory Note, an $8.5 million increase in employee related costs including stock-based compensation expense, salary increases and higher headcount as we expanded our workforce and invested in key talent and an increase of $1.9 million in other expenses which consisted primarily of increased facilities expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000006:mdna:68]
Comparison of Six Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:69]
Research and development expenses. The period-over-period increase in research and development expenses was driven by a $58.7 million increase in employee related costs including stock-based compensation expense, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $17.0 million increase in product development costs to support next generation products and technologies, which was offset by a $5.0 million increase in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-25-000006:mdna:70]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was driven by a $38.7 million increase in employee related costs including stock-based compensation expense, salary increases and higher headcount as we expanded our workforce and invested in key talent, and a $31.0 million increase in advertising and other expenses, which was offset by a $5.4 million increase in marketing development funds received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000006:mdna:71]
General and administrative expenses. The period-over-period increase in general and administrative expenses was driven by a $36.2 million increase in professional and service fees primarily driven by expenses associated with the circumstances discussed in the Explanatory Note, a $16.3 million increase in employee related costs including stock-based compensation expense, salary increases and higher headcount as we expanded our workforce and invested in key talent and an increase of $6.2 million in other expenses which consisted primarily of increased facilities expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000006:mdna:72]
Interest Expense and Other Income (Expense), Net

[0001375365-25-000006:mdna:73]
Other income (expense), net consists primarily of interest earned on our investment, cash balances and foreign exchange gains and losses.

[0001375365-25-000006:mdna:74]
Interest expense represents interest expense on our term loans and lines of credit and amortization of the 2029 Convertible Notes issuance costs.

[0001375365-25-000006:mdna:75]
SMCI | Q2 2025 Form 10-Q | 43

[0001375365-25-000006:mdna:76]
Other income (expense), net and Interest expense for the three and six months ended December 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-25-000006:mdna:77]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Other income (expense), net | $ | 13.0 |  |  | $ | (7.9) |  |  | $ | 20.9 |  |  | (265) | % |  | $ | 20.2 |  |  | $ | (1.3) |  |  | $ | 21.5 |  |  | (1,653.8) | % |
| Interest expense | (6.5) |  |  | (8.1) |  |  | 1.6 |  |  | (19.8) | % |  | (23.9) |  |  | (10.0) |  |  | (13.9) |  |  | 139.0 | % |
| Other income (expense), net and interest expense | $ | 6.5 |  |  | $ | (16.0) |  |  | $ | 22.5 |  |  | (140.6) | % |  | $ | (3.7) |  |  | $ | (11.3) |  |  | $ | 7.6 |  |  | (67.3) | % |

[0001375365-25-000006:mdna:78]
Comparison of Three Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:79]
The $22.5 million increase in other income (expense), net and interest expense was primarily attributable to a $20.9 million increase in other income, driven by a foreign exchange gain of $14.1 million due to a strengthening US dollar and a $6.9 million increase in interest income. The decrease in interest expense of $1.6 million was driven by overall lower term loan balances creating savings of $2.7 million, partially offset by additional interest charges on the 2029 Convertible Notes of $1.1 million.

[0001375365-25-000006:mdna:80]
Comparison of Six Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:81]
The $7.6 million increase in other income (expense), net and interest expense was primarily attributable to a $21.5 million increase in other income, driven by an $13.2 million increase in interest income and a foreign exchange gain of $6.3 million due to a strengthening US dollar. The increase in interest expense of $13.9 million was driven by overall higher loan balances and $3.0 million in 2029 Convertible Note charges.

[0001375365-25-000006:mdna:82]
[same as prior period, unchanged from 0001375365-25-000005:mdna:62]

[0001375365-25-000006:mdna:83]
[same as prior period, unchanged from 0001375365-25-000005:mdna:63]

[0001375365-25-000006:mdna:84]
Income tax provision for income taxes and effective tax rates for the three and six months ended December 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-25-000006:mdna:85]
|  | Three Months EndedDecember 31, |  | Change |  | Six Months EndedDecember 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Income tax provision | $ | 57.0 |  |  | $ | 61.5 |  |  | $ | (4.5) |  |  | (7.3) | % |  | $ | 131.7 |  |  | $ | 81.7 |  |  | $ | 50.0 |  |  | 61.2 | % |
| Percentage of total net sales | 1.0 | % |  | 1.7 | % |  |  |  |  |  | 1.0 | % |  | 1.4 | % |  |  |  |  |
| Effective tax rate | 15.2 | % |  | 17.3 | % |  |  |  |  |  | 15.1 | % |  | 15.3 | % |  |  |  |  |

[0001375365-25-000006:mdna:86]
Comparison of Three Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:87]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended December 31, 2024, was lower than that for the three months ended December 31, 2023, primarily due to the increase in the stock compensation tax deduction and research tax credit in the three months ended December 31, 2024.

[0001375365-25-000006:mdna:88]
Comparison of Six Months Ended December 31, 2024 and 2023

[0001375365-25-000006:mdna:89]
The income tax provision for the six months ended December 31, 2024 was higher than that for the six months ended December 31, 2023, primarily due to a significant increase in annual forecasted taxable income for the six months ended December 31, 2024. However, the effective tax rate for the six months ended December 31, 2024, remained nearly unchanged compared to the six months ended December 31, 2023, as the stock compensation deduction remained relatively consistent year over year.

[0001375365-25-000006:mdna:90]
SMCI | Q2 2025 Form 10-Q | 44

[0001375365-25-000006:mdna:91]
[same as prior period, unchanged from 0001375365-25-000005:mdna:68]

[0001375365-25-000006:mdna:92]
We have financed our growth primarily with funds generated from operations, utilizing borrowing facilities and selling our common stock, and issuing convertible notes. Our recent drivers of liquidity changes have included an increase in the need for working capital due to higher levels of inventory required to support our growing revenues and to a lesser extent, longer supply chain lead times on certain key components. Our cash and cash equivalents were $1.4 billion and $1.7 billion as of December 31, 2024 and June 30, 2024, respectively. Our cash and cash equivalents in foreign locations were $325.8 million and $337.3 million as of December 31, 2024 and June 30, 2024, respectively.

[0001375365-25-000006:mdna:93]
[same as prior period, unchanged from 0001375365-25-000005:mdna:70]

[0001375365-25-000006:mdna:94]
[same as prior period, unchanged from 0001375365-25-000005:mdna:71]

[0001375365-25-000006:mdna:95]
[same as prior period, unchanged from 0001375365-25-000005:mdna:72]

[0001375365-25-000006:mdna:96]
|  | Six Months EndedDecember 31, |  | Change |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 169.1 |  |  | $ | (324.6) |  |  | $ | 493.7 |  |  |  |  |
| Net cash used in investing activities | $ | (71.8) |  |  | $ | (22.5) |  |  | $ | (49.3) |  |  |  |  |
| Net cash (used in) provided by financing activities | $ | (337.4) |  |  | $ | 632.2 |  |  | $ | (969.6) |  |  |  |  |
| Effect of exchange rate fluctuations on cash | $ | 0.8 |  |  | $ | 0.2 |  |  | $ | 0.6 |  |  |  |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash | $ | (239.3) |  |  | $ | 285.2 |  |  | $ | (524.5) |  |  |  |  |

[0001375365-25-000006:mdna:97]
[same as prior period, unchanged from 0001375365-25-000005:mdna:75]

[0001375365-25-000006:mdna:98]
Net cash provided by operating activities increased by $493.7 million for the six months ended December 31, 2024, as compared to the six months ended December 31, 2023. This increase was primarily driven by a $292.0 million increase in net income, a $179.6 million increase in working capital, and a $22.1 million increase in non-cash items. The cash provided by working capital was primarily driven by a $1,755.1 million increase in inventory due to higher shipment of inventory to fulfill customer demand, a $35.3 million increase in accounts receivable due to cash collections, this was offset by a $1,386.5 million decrease in accounts payable due to timing of vendor payments, and a $224.3 million decrease in other operating assets and liabilities.

[0001375365-25-000006:mdna:99]
[same as prior period, unchanged from 0001375365-25-000005:mdna:77]

[0001375365-25-000006:mdna:100]
Net cash used in investing activities increased by $49.3 million for the six months ended December 31, 2024 as compared to the six months ended December 31, 2023 primarily due to an increase in property, plant and equipment of $54.5 million made in the six months ended December 31, 2024, partially offset by a decrease in investments of $5.2 million.

[0001375365-25-000006:mdna:101]
[same as prior period, unchanged from 0001375365-25-000005:mdna:79]

[0001375365-25-000006:mdna:102]
Net cash provided by financing activities decreased by $969.6 million for the six months ended December 31, 2024 as compared to the six months ended December 31, 2023. The decrease was primarily due to a decrease in issuance of common stock, net of issuing costs of $582.8 million, a decrease of $348.0 million in proceeds from borrowings, net of repayment and higher withholding tax payment for equity compensation related activities of $38.8 million.

[0001375365-25-000006:mdna:103]
SMCI | Q2 2025 Form 10-Q | 45

[0001375365-25-000006:mdna:104]
[same as prior period, unchanged from 0001375365-25-000005:mdna:81]

[0001375365-25-000006:mdna:105]
[same as prior period, unchanged from 0001375365-25-000005:mdna:82]

[0001375365-25-000006:mdna:106]
On February 11, 2025, we announced that we had entered into privately negotiated agreements with certain holders of the 2029 Convertible Notes to (i) purchase $700.0 million aggregate principal amount of newly issued 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”), and (ii) amend certain terms of and obtain waivers with respect to the 2029 Convertible Notes. On February 20, 2025, we executed a first supplemental indenture and second supplemental indenture related to the 2029 Convertible Notes that implemented the amendments to the 2029 Convertible Notes and we executed an indenture related to the 2028 Convertible Notes and issued the 2028 Convertible Notes pursuant to the terms of such indenture. Refer to Note 14, “Subsequent Events,” in our notes to condensed consolidated financial statements in this Quarterly Report for further information on the issuance of the 2028 Convertible Notes and the amendment of the terms of the 2029 Convertible Notes.

[0001375365-25-000006:mdna:107]
[same as prior period, unchanged from 0001375365-25-000005:mdna:84]

[0001375365-25-000006:mdna:108]
We anticipate our capital expenditures for the remainder of fiscal year 2025 will be in range of $76.0 million to $86.0 million, relating primarily to costs associated with our global manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades and expansion. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-25-000006:mdna:109]
We intend to continue to focus our capital expenditures in the remainder of fiscal year 2025 to support the growth of our operations. Our future capital requirements will depend on many factors including our growth rate, the timing and extent of spending to support development efforts, the expansion of sales and marketing activities, the introduction of new and enhanced software and services offerings and investments in our office facilities and our IT system infrastructure.

[0001375365-25-000006:mdna:110]
[same as prior period, unchanged from 0001375365-25-000005:mdna:87]

[0001375365-25-000006:mdna:111]
[same as prior period, unchanged from 0001375365-25-000005:mdna:88]

[0001375365-25-000006:mdna:112]
SMCI | Q2 2025 Form 10-Q | 46
