# SMCI 10-Q controls and the auditor's report


## item_4_controls

[0001375365-25-000006:item_4_controls:1]
Item 4.    Controls and Procedures

[0001375365-25-000006:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001375365-25-000006:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, is responsible for evaluating the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of the period covered by this report. Our disclosure controls and procedures are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Exchange Act is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure and is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC. Based upon this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of the end of the period covered by this report due to the material weaknesses in our internal control over financial reporting described below.

[0001375365-25-000006:item_4_controls:4]
As previously reported in our Annual Report on Form 10-K for the year ended June 30, 2024, management identified certain material weaknesses in our internal controls over financial reporting primarily pertaining to: (i) information technology general controls for certain IT systems that support the Company's financial reporting process were not appropriately identified, designed or implemented; (ii) controls to address segregation of duties conflicts were not properly designed and appropriately implemented; (iii) controls and documentation thereof, over the review and approval of manual journal entries were not properly designed and appropriately implemented to prevent unauthorized access to post journal entries; (iv) controls over the completeness and accuracy of information produced by the entity impacting multiple financial statement areas were not properly documented; and (v) management did not design, implement and retain appropriate documentation of control procedures to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including the timely identification and disclosure of new leasing arrangements and new related party transactions.

[0001375365-25-000006:item_4_controls:5]
The above material weaknesses could have increased the risk of unauthorized access to certain information technology systems that support our financial reporting processes, manipulation of data that we use to produce our financial statements, and/or lack of complete and accurate information, which could lead to financial misstatements and affect our ability to report our information on a timely basis.

[0001375365-25-000006:item_4_controls:6]
Notwithstanding the material weaknesses in internal control over financial reporting described above, management believes and has concluded that the condensed consolidated financial statements included in this Quarterly Report fairly present, in all material respects, our financial position, results of operations and cash flows for the periods presented in conformity with GAAP.

[0001375365-25-000006:item_4_controls:7]
Changes in Internal Control over Financial Reporting

[0001375365-25-000006:item_4_controls:8]
There were no changes in our internal control over financial reporting, as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act, during the quarter ended December 31, 2024 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-25-000006:item_4_controls:9]
Remediation Plan and Status

[0001375365-25-000006:item_4_controls:10]
Our management is committed to remediating the material weaknesses that we have identified and fostering continuous improvement in our internal controls. We are evaluating the material weaknesses described above and designing plans to remediate these weaknesses and enhancing our internal control environment. These plans include:

[0001375365-25-000006:item_4_controls:11]
•hiring additional qualified technical accounting, financial reporting, and internal audit personnel with public company experience; expanding other non-finance teams that are responsible for control execution in order to provide additional capacity and expertise, particularly as our revenue continues to increase;

[0001375365-25-000006:item_4_controls:12]
•continuing to conduct more training sessions for our accounting and finance staff focused on sufficiently documenting our internal control over the completeness and accuracy of the information we use to support our financial reporting;

[0001375365-25-000006:item_4_controls:13]
•reviewing the organization of our IT group with the goal of ensuring the organization can fully support the internal control needs of our company;

[0001375365-25-000006:item_4_controls:14]
SMCI | Q2 2025 Form 10-Q | 48

[0001375365-25-000006:item_4_controls:15]
•designing additional monitoring controls over manual journal entries, and actions of people with overlapping duties; and monitoring controls over access and change management for the IT systems to which this material weakness relates; and

[0001375365-25-000006:item_4_controls:16]
•upgrading our IT systems to include features that will scale, automate and strengthen our internal controls.

[0001375365-25-000006:item_4_controls:17]
We are committed to a strong internal control environment and to remediating these material weaknesses as soon as possible. We will determine that our material weaknesses have been fully remediated only after we have (i) implemented and tested the necessary changes and (ii) observed the remediated controls operate for a sufficient period of time for us to determine that such controls are operating effectively. We may also conclude that additional measures or costs are required to remediate the material weaknesses in our internal control over financial reporting. We will monitor and report the effectiveness of our remediation plan and refine our remediation plan as appropriate.

[0001375365-25-000006:item_4_controls:18]
Inherent Limitations on Effectiveness of Controls

[0001375365-25-000006:item_4_controls:19]
Because of inherent limitations, internal control over financial reporting may not prevent or detect misstatements and projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-25-000006:item_4_controls:20]
SMCI | Q2 2025 Form 10-Q | 49
