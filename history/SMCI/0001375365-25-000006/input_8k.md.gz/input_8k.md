# SMCI 8-K — 0001375365-25-000001 filed 2025-02-11

## item codes, every 8-K on or before 2025-02-25

- 2025-02-21 0001375365-25-000003 — 1.01, 2.03, 3.02, 9.01
- 2025-02-11 0001375365-25-000001 — 2.02, 8.01, 9.01
- 2024-12-27 0001375365-24-000046 — 1.02, 9.01
- 2024-12-06 0001375365-24-000045 — 3.01, 9.01
- 2024-12-02 0001375365-24-000044 — 5.02, 8.01, 9.01
- 2024-11-26 0001375365-24-000043 — 1.02, 9.01
- 2024-11-20 0001375365-24-000042 — 1.01, 2.03, 3.01, 9.01
- 2024-11-18 0001375365-24-000040 — 4.01, 8.01, 9.01
- 2024-11-05 0001375365-24-000038 — 1.02, 2.02, 9.01
- 2024-11-01 0001375365-24-000037 — 1.01, 2.03, 9.01
- 2024-10-30 0001375365-24-000036 — 4.01, 9.01
- 2024-09-30 0001375365-24-000035 — 1.01, 2.03, 3.03, 5.03, 9.01
- 2024-09-26 0001375365-24-000034 — 8.01, 9.01
- 2024-09-20 0001375365-24-000033 — 3.01, 9.01
- 2024-09-03 0001375365-24-000032 — 7.01, 9.01
- 2024-08-28 0001375365-24-000030 — 8.01, 9.01
- 2024-08-19 0001375365-24-000029 — 5.02, 7.01, 9.01
- 2024-08-06 0001375365-24-000028 — 2.02, 9.01
- 2024-07-22 0001375365-24-000027 — 1.01, 7.01, 9.01
- 2024-06-21 0001375365-24-000026 — 1.01, 2.03, 9.01
- 2024-05-09 0001375365-24-000023 — 3.01, 9.01
- 2024-04-30 0001375365-24-000021 — 2.02, 9.01
- 2024-03-22 0001375365-24-000020 — 1.01, 8.01, 9.01
- 2024-03-15 0001375365-24-000019 — 5.02, 9.01
- 2024-02-28 0001375365-24-000017 — 1.01, 2.03, 3.02, 9.01
- 2024-02-23 0001375365-24-000016 — 8.01, 9.01
- 2024-02-22 0001375365-24-000015 — 1.01, 8.01, 9.01
- 2024-02-20 0001375365-24-000014 — 1.01, 2.03, 9.01
- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2025-02-25

- 2025-02-11 0001375365-25-000002 — NT 10-Q, for the period ended 2024-12-31
- 2024-11-13 0001375365-24-000039 — NT 10-Q, for the period ended 2024-09-30
- 2024-08-30 0001375365-24-000031 — NT 10-K, for the period ended 2024-08-30
- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-25-000001:8k_2_02:1]
EX-99.1
2
q225pressrelease.htm
EX-99.1

[0001375365-25-000001:8k_2_02:2]
Document

[0001375365-25-000001:8k_2_02:3]
Supermicro Announces Second Quarter Fiscal Year 2025 Preliminary Financial Information

[0001375365-25-000001:8k_2_02:4]
SAN JOSE, Calif. -- February 11, 2025 -- (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI) (“Supermicro” or the “Company”), a Total IT Solution Provider for AI, Cloud, Storage, and 5G/Edge, today announced preliminary financial information for its second quarter of fiscal year 2025 ended December 31, 2024.

[0001375365-25-000001:8k_2_02:5]
Preliminary Second Quarter Fiscal Year 2025 Highlights

[0001375365-25-000001:8k_2_02:6]
The Company expects to report the following financial information for the quarter ended December 31, 2024:

[0001375365-25-000001:8k_2_02:7]
•Net sales in the range of $5.6 billion to $5.7 billion, reflecting 54% year-over-year growth at the midpoint

[0001375365-25-000001:8k_2_02:8]
•GAAP and non-GAAP gross margin in the range of 11.8% to 11.9%

[0001375365-25-000001:8k_2_02:9]
•GAAP diluted net income per common share in the range of $0.50 to $0.52, flat year-over-year

[0001375365-25-000001:8k_2_02:10]
•Non-GAAP diluted net income per common share in the range of $0.58 to $0.60, reflecting 5% year-over-year growth

[0001375365-25-000001:8k_2_02:11]
The non-GAAP gross margin expected to be reported for the second quarter of fiscal year 2025 adds back stock-based compensation expense of approximately $6.7 million. The non-GAAP diluted net income per common share expected to be reported for the second quarter of fiscal year 2025 includes adjustments for stock-based compensation expense of approximately $63.0 million, net of the related tax effects of approximately $19.1 million.

[0001375365-25-000001:8k_2_02:12]
The Company expects to report as of December 31, 2024 total cash and cash equivalents of approximately $1.4 billion and total debt of approximately $1.9 billion with bank debt comprising of approximately $0.2 billion and convertible notes of approximately $1.7 billion.

[0001375365-25-000001:8k_2_02:13]
“With our leading direct-liquid cooling (DLC) technology and over 30% of new data centers expected to adopt it in the next 12 months, Supermicro is well positioned to grow AI infrastructure designs wins based on NVIDIA Blackwell and more,” said Charles Liang, Founder, President and CEO of Supermicro. “Combined with exceptional product quality, service, software, networking, and security with data center building blocks, Supermicro will expand our leadership as the premier US-based data center infrastructure solution provider. We anticipate this technology transition sets a strong foundation for us now, resulting in FY25 revenue in the range of $23.5 billion to $25 billion, paving the way for $40 billion revenue in FY26.”

[0001375365-25-000001:8k_2_02:14]
Business Outlook

[0001375365-25-000001:8k_2_02:15]
The Company expects net sales in the range of $5.0 billion to $6.0 billion for the third quarter of the fiscal year 2025 ending March 31, 2025, GAAP net income per diluted share of $0.36 to $0.53 and non-GAAP net income per diluted share of $0.46 to $0.62. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 10.7% and 12.7%, respectively, and a fully diluted share count of approximately 642 million shares for GAAP and fully diluted share count of approximately 653 million shares for non-GAAP. The outlook for Q3 of fiscal year 2025 GAAP net income per diluted share includes approximately $65 million in expected stock-based compensation expense and other expenses, net of related tax effects of approximately $17 million, which are excluded from non-GAAP net income per diluted share.

[0001375365-25-000001:8k_2_02:16]
For fiscal year 2025, the Company is updating its revenue guidance from a range of $26 billion to $30 billion to a new range of $23.5 billion to $25 billion.

[0001375365-25-000001:8k_2_02:17]
Financial Information Is Preliminary and May Be Subject to Change

[0001375365-25-000001:8k_2_02:18]
The unaudited interim financial information presented in this press release is preliminary. The final financial results reported for this period may also differ from the results reported in this release.

[0001375365-25-000001:8k_2_02:19]
In particular, the data relating to the Company's financial results for the quarter ended December 31, 2024 and the adjustments to its financial results for the fourth quarter of fiscal year 2024 presented in this press release reflect the Company's preliminary estimated unaudited financial results, based upon information available to the Company as of the date of this press release. The Company has provided preliminary estimates of financial results primarily because its financial closing procedures for the quarter ended December 31, 2024 and preliminary estimated adjustments to results for the fiscal year ended June 30, 2024 are not yet complete. The data are not a comprehensive statement of the Company's results for such periods, and the actual results may differ materially from these preliminary estimated data. The Company's actual results remain subject to the completion of management’s and its audit committee’s review and other financial closing processes as well as the completion and preparation of its financial data for such periods. The Company's independent registered public accounting firm has not audited, reviewed, compiled or performed any procedures with respect to such preliminary data. During the course of the preparation of the Company's financial statements and related notes and the completion of the review for such periods, additional adjustments to the preliminary estimated financial information presented here may be identified, and its final results for these periods may vary from these preliminary estimates. This preliminary estimated data should not be considered a substitute for the financial statements to be prepared in accordance with accounting principles generally accepted in the United States and to be filed with the Securities and Exchange Commission once available.

[0001375365-25-000001:8k_2_02:20]
Corporate Updates

[0001375365-25-000001:8k_2_02:21]
Supermicro continues to work diligently toward the filing of its Annual Report on Form 10-K for the fiscal year ended June 30, 2024, and its Quarterly Report on Form 10-Q for the period ended September 30, 2024. Based on information currently available, the Company believes it will make such filings by February 25, 2025. Additionally, the Company today filed a Form 12b-25 for its second fiscal quarter and expects to file its Quarterly Report on Form 10-Q for period ended December 31, 2024, also by February 25, 2025.

[0001375365-25-000001:8k_2_02:22]
In a separate press release issued today, the Company announced that it had agreed to issue in a private placement $700 million of new 2.25% Convertible Senior Notes due 2028 and to amend the terms of its existing Convertible Senior Notes due 2029.

[0001375365-25-000001:8k_2_02:23]
In late 2024, the Company received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking certain documents following the publication of allegations in a short seller report which was published in August 2024. The Company is cooperating with these document requests. In addition, in connection with the delay in filing the periodic reports, several securities litigation complaints and derivative suits were filed against the Company. Management believes these complaints are without merit.

[0001375365-25-000001:8k_2_02:24]
Updates to Unaudited Preliminary Fiscal 2024 and Fourth Quarter Fiscal 2024 Results

[0001375365-25-000001:8k_2_02:25]
The Company is reconfirming that no previously issued financial statements require a restatement. As the Company works toward completing the audit, it made certain adjustments to the preliminary unaudited results for the fourth quarter of fiscal year 2024 that it announced on August 6, 2024. The adjustments recorded in the results for the fourth quarter of fiscal year 2024 include an increase in net sales of approximately $46 million, an increase in cost of sales of approximately $96 million, which includes a charge due to an increase in inventory reserves of approximately $45 million, and an increase in operating expenses of approximately $5 million. Until the Company’s fiscal year 2024 financial statements are filed, the Company is required to reassess its accounting estimates for financial reporting. The charge for inventory reserves results from an unanticipated decline in the market value of certain components that were held in the Company’s inventory or on non-cancellable purchase orders at the end of fiscal year 2024. Collectively, these changes resulted in a downward adjustment to the previously announced preliminary unaudited fiscal year 2024 and fourth quarter of fiscal year 2024 GAAP and non-GAAP diluted net income per common share of approximately $0.09 based on post-split diluted shares outstanding. The foregoing adjustments are to previously announced preliminary unaudited financial results and, as such, do not constitute a restatement.

[0001375365-25-000001:8k_2_02:26]
Conference Call and Webcast Information

[0001375365-25-000001:8k_2_02:27]
Supermicro will present a live audio webcast of a conference call to review the preliminary financial information for its second quarter

[0001375365-25-000001:8k_2_02:28]
of fiscal year 2025 today at 5:00 p.m. ET / 2:00 p.m. PT. The webcast will be available at https://ir.supermicro.com.

[0001375365-25-000001:8k_2_02:29]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-25-000001:8k_2_02:30]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-25-000001:8k_2_02:31]
Use of Non-GAAP Financial Measures

[0001375365-25-000001:8k_2_02:32]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets, and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. Pursuant to the requirements of SEC Regulation G, the reconciliation between the Company's GAAP and non-GAAP financial results is associated with stock-based compensation expenses of $63.0 million, net of the related tax effects of $19.1 million provided above.

[0001375365-25-000001:8k_2_02:33]
About Super Micro Computer, Inc.

[0001375365-25-000001:8k_2_02:34]
Supermicro (Nasdaq: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. We are a Total IT Solutions provider with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enable our development and production, enabling next generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-25-000001:8k_2_02:35]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-25-000001:8k_2_02:36]
Investor Relations Contact:

[0001375365-25-000001:8k_2_02:37]
Nicole Noutsios

[0001375365-25-000001:8k_2_02:38]
Stratos Advisors

[0001375365-25-000001:8k_2_02:39]
email: ir@supermicro.com

[0001375365-25-000001:8k_2_02:40]
Source: Super Micro Computer, Inc.
