# SMCI notes — 0001375365-25-000006


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-25-000006:notes:1]
[same as prior period, unchanged from 0001375365-25-000005:notes:1]

[0001375365-25-000006:notes:2]
[same as prior period, unchanged from 0001375365-25-000005:notes:2]

[0001375365-25-000006:notes:3]
[same as prior period, unchanged from 0001375365-25-000005:notes:3]

[0001375365-25-000006:notes:4]
[same as prior period, unchanged from 0001375365-25-000005:notes:4]

[0001375365-25-000006:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2024 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2025. These unaudited condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and related notes contained in the 2024 10-K.

[0001375365-25-000006:notes:6]
[same as prior period, unchanged from 0001375365-25-000005:notes:6]

[0001375365-25-000006:notes:7]
[same as prior period, unchanged from 0001375365-25-000005:notes:7]

[0001375365-25-000006:notes:8]
[same as prior period, unchanged from 0001375365-25-000005:notes:8]

[0001375365-25-000006:notes:9]
[same as prior period, unchanged from 0001375365-25-000005:notes:9]

[0001375365-25-000006:notes:10]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Percentage of total purchases |  |  |  |  |  |  |  |
| Supplier A | 63.5% |  | 68.1% |  | 64.5% |  | 62.9% |
| Supplier B | 6.0% |  | 7.3% |  | 5.8% |  | 8.6% |

[0001375365-25-000006:notes:11]
Purchases from Ablecom Technology, Inc. (“Ablecom”) and Compuware Technology, Inc. (“Compuware”), which are both related parties of the Company (see Note 9, "Related Party Transactions"), accounted for a combined 2.7% and 3.6% of total cost of sales for the three months ended December 31, 2024 and 2023, respectively, and a combined 3.7% and 4.6% of total cost of sales for the six months ended December 31, 2024 and 2023, respectively.

[0001375365-25-000006:notes:12]
[same as prior period, unchanged from 0001375365-25-000005:notes:13]

[0001375365-25-000006:notes:13]
[same as prior period, unchanged from 0001375365-25-000005:notes:14]

[0001375365-25-000006:notes:14]
[same as prior period, unchanged from 0001375365-25-000005:notes:15]

[0001375365-25-000006:notes:15]
|  | December 31, 2024 | June 30, 2024 |
| Percentage of accounts receivable |  |  |
| Customer A | 16.0% | 15.4% |
| Customer G | 57.3% | 44.8% |

[0001375365-25-000006:notes:16]
[same as prior period, unchanged from 0001375365-25-000005:notes:18]

[0001375365-25-000006:notes:17]
[same as prior period, unchanged from 0001375365-25-000005:notes:19]

[0001375365-25-000006:notes:18]
Customer A accounted for 27.1%, and customer G accounted for 30.6% of the net sales for the three months ended December 31, 2024 and customer A accounted for 23.9%, customer G accounted for 21.0% and customer B accounted for 14.9% of the net sales for the six months ended December 31, 2024. Customer A accounted for 25.5% and customer D accounted for 10.4% of the net sales for the three months ended December 31, 2023 and customer A accounted for 25.3% of the net sales for the six months ended December 31, 2023. Other customers were individually below 10% of the net sales for the three and six months ended December 31, 2024 and 2023.

[0001375365-25-000006:notes:19]
[same as prior period, unchanged from 0001375365-25-000005:notes:21]

[0001375365-25-000006:notes:20]
In November 2023, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2024, and for the interim period beginning July 1, 2025. The Company is currently evaluating this pronouncement and the impact it may have on its financial statement disclosures.

[0001375365-25-000006:notes:21]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2025. The Company is currently evaluating this pronouncement and the impact it may have on its financial statement disclosures.

[0001375365-25-000006:notes:22]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. The ASU may be applied prospectively or retrospectively and is effective for fiscal years beginning after December 15, 2026 and for the interim periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for the Company’s fiscal year beginning July 1, 2027, and for the interim period beginning July 1, 2028. The Company is currently evaluating this pronouncement and the impact it may have on its financial statement disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-25-000006:notes:23]
[same as prior period, unchanged from 0001375365-25-000005:notes:25]

[0001375365-25-000006:notes:24]
[same as prior period, unchanged from 0001375365-25-000005:notes:26]

[0001375365-25-000006:notes:25]
[same as prior period, unchanged from 0001375365-25-000005:notes:27]

[0001375365-25-000006:notes:26]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 5,487,150 |  |  | $ | 3,435,562 |  |  | $ | 11,234,931 |  |  | $ | 5,402,170 |  |
| Subsystems and accessories | 190,812 |  |  | 229,362 |  |  | 380,287 |  |  | 382,426 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |

[0001375365-25-000006:notes:27]
[same as prior period, unchanged from 0001375365-25-000005:notes:29]

[0001375365-25-000006:notes:28]
Revenue related to services for the three months ended December 31, 2024 and 2023 was $54.4 million, and $37.2 million, respectively, which is recognized over time ratably over the contract term. Revenue related to services for the six months ended December 31, 2024 and 2023 was $104.6 million and $72.4 million, respectively, which is recognized over time ratably over the contract term.

[0001375365-25-000006:notes:29]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2024 and 2023, of net sales by geographic region (in thousands):

[0001375365-25-000006:notes:30]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 3,846,960 |  |  | $ | 2,605,585 |  |  | $ | 8,088,309 |  |  | $ | 4,225,099 |  |
| Asia | 768,246 |  |  | 656,220 |  |  | 1,722,820 |  |  | 881,688 |  |
| Europe | 933,772 |  |  | 288,448 |  |  | 1,579,614 |  |  | 479,296 |  |
| Other | 128,984 |  |  | 114,671 |  |  | 224,475 |  |  | 198,513 |  |
| Total | $ | 5,677,962 |  |  | $ | 3,664,924 |  |  | $ | 11,615,218 |  |  | $ | 5,784,596 |  |

[0001375365-25-000006:notes:31]
[same as prior period, unchanged from 0001375365-25-000005:notes:33]

[0001375365-25-000006:notes:32]
[same as prior period, unchanged from 0001375365-25-000005:notes:34]

[0001375365-25-000006:notes:33]
[same as prior period, unchanged from 0001375365-25-000005:notes:35]

[0001375365-25-000006:notes:34]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2024, of $416.4 million, was $47.3 million and $115.5 million, respectively. Revenue recognized during the three and six months ended December 31, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $31.5 million and $75.2 million, respectively.

[0001375365-25-000006:notes:35]
Deferred revenue increased $182.3 million as of December 31, 2024 as compared to June 30, 2024. This increase was mainly due to the deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods.

[0001375365-25-000006:notes:36]
Transaction Price Allocated to the Remaining Performance Obligations
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. For contracts with a duration of more than one year, the value of the transaction price allocated to deferred revenue as of December 31, 2024 was approximately $598.7 million. The Company expects to recognize approximately 52%


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-25-000006:notes:37]
The following is a summary for the three and six months ended December 31, 2024 and 2023, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-25-000006:notes:38]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three and six months ended December 31, 2024 and 2023 (in thousands, except per share amounts):

[0001375365-25-000006:notes:39]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income - basic | $ | 320,596 |  |  | $ | 295,968 |  |  | $ | 744,923 |  |  | $ | 452,963 |  |
| Convertible Notes interest charge, net of tax | 1,110 |  |  | — |  |  | 3,859 |  |  | — |  |
| Net income - diluted | $ | 321,706 |  |  | $ | 295,968 |  |  | $ | 748,782 |  |  | $ | 452,963 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 592,507 |  |  | 541,354 |  |  | 591,033 |  |  | 536,141 |  |
| Effect of dilutive convertible notes | 12,860 |  |  | — |  |  | 12,860 |  | — |  |
| Effect of dilutive securities | 30,680 |  |  | 39,423 |  |  | 33,704 |  |  | 40,174 |  |
| Weighted-average shares outstanding - diluted | 636,047 |  |  | 580,777 |  |  | 637,597 |  |  | 576,315 |  |
| Net income per common share - basic | $ | 0.54 |  |  | $ | 0.55 |  |  | $ | 1.26 |  |  | $ | 0.84 |  |
| Net income per common share - diluted | $ | 0.51 |  |  | $ | 0.51 |  |  | $ | 1.17 |  |  | $ | 0.79 |  |

[0001375365-25-000006:notes:40]
For the three and six months ended December 31, 2024 and 2023, the Company had stock options and restricted stock units ("RSUs") outstanding that could potentially dilute basic earnings per share in the future but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 11,668,231 and 5,848,550 for the three months ended December 31, 2024 and 2023, respectively, and 7,627,082 and 4,612,920 for the six and months ended December 31, 2024 and 2023, respectively.

[0001375365-25-000006:notes:41]
Potentially dilutive shares of common stock issuable upon conversion of the Company's outstanding 0.00% Convertible Senior Notes due 2029 (the "2029 Convertible Notes") are determined using the if-converted method. For the three and six months ended December 31, 2024, all such shares issuable upon conversion of the 2029 Convertible Notes were dilutive.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-25-000006:notes:42]
[same as prior period, unchanged from 0001375365-25-000005:notes:45]

[0001375365-25-000006:notes:43]
[same as prior period, unchanged from 0001375365-25-000005:notes:46]

[0001375365-25-000006:notes:44]
|  | December 31, 2024 |  | June 30, 2024 |
| Cash and cash equivalents | $ | 1,430,002 |  |  | $ | 1,669,766 |  |
| Restricted cash included in other assets | 985 |  |  | 507 |  |
| Total cash, cash equivalents and restricted cash | $ | 1,430,987 |  |  | $ | 1,670,273 |  |

[0001375365-25-000006:notes:45]
[same as prior period, unchanged from 0001375365-25-000005:notes:48]

[0001375365-25-000006:notes:46]
|  | December 31, 2024 |  | June 30, 2024 |
| Finished goods | $ | 2,669,563 |  |  | $ | 3,312,768 |  |
| Work in process | 379,056 |  |  | 450,993 |  |
| Purchased parts and raw materials | 547,526 |  |  | 569,268 |  |
| Total inventories | $ | 3,596,145 |  |  | $ | 4,333,029 |  |

[0001375365-25-000006:notes:47]
The Company recorded a net provision for excess and obsolete inventory to cost of sales totaling $24.9 million and $8.4 million during the three months ended December 31, 2024 and 2023, respectively, and $34.0 million and $12.9 million for the six months ended December 31, 2024 and 2023, respectively.

[0001375365-25-000006:notes:48]
[same as prior period, unchanged from 0001375365-25-000005:notes:51]

[0001375365-25-000006:notes:49]
|  | December 31, 2024 |  | June 30, 2024 |
| Land | $ | 162,430 |  |  | $ | 150,137 |  |
| Buildings | 182,445 |  |  | 163,764 |  |
| Machinery and equipment | 172,639 |  |  | 156,496 |  |
| Building and leasehold improvements | 112,625 |  |  | 72,075 |  |
| Furniture and fixtures | 51,983 |  |  | 46,241 |  |
| Software | 26,580 |  |  | 24,363 |  |
| Building construction in progress | 336 |  |  | 14,828 |  |
|  | 709,038 |  |  | 627,904 |  |
| Accumulated depreciation and amortization | (231,546) |  |  | (213,896) |  |
| Property, plant and equipment, net | $ | 477,492 |  |  | $ | 414,008 |  |

[0001375365-25-000006:notes:50]
Depreciation and amortization expense for the three months ended December 31, 2024 and 2023, was $9.5 million and $7.3 million, respectively, and for the six months ended December 31, 2024 and 2023, was $18.5 million and $14.2 million, respectively.

[0001375365-25-000006:notes:51]
[same as prior period, unchanged from 0001375365-25-000005:notes:54]

[0001375365-25-000006:notes:52]
|  | December 31, 2024 |  | June 30, 2024 |
| Accrued payroll and related expenses | 70,415 |  |  | 62,006 |  |
| Customer deposits | 35,139 |  |  | 46,942 |  |
| Accrued cooperative marketing expenses | 23,335 |  |  | 15,967 |  |
| Accrued warranty costs | 10,444 |  |  | 10,009 |  |
| Operating lease liability | 6,836 |  |  | 9,248 |  |
| Accrued professional fees | 7,114 |  |  | 1,699 |  |
| Other | 75,864 |  |  | 113,803 |  |
| Total accrued liabilities | $ | 229,147 |  |  | $ | 259,674 |  |

[0001375365-25-000006:notes:53]
[same as prior period, unchanged from 0001375365-25-000005:notes:56]

[0001375365-25-000006:notes:54]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Balance, beginning of the period | $ | 17,953 |  |  | $ | 15,629 |  |  | $ | 17,815 |  |  | $ | 14,859 |  |
| Provision for warranty | 17,162 |  |  | 10,515 |  |  | 28,695 |  |  | 23,044 |  |
| Costs utilized | (15,855) |  |  | (9,587) |  |  | (26,853) |  |  | (21,391) |  |
| Change in estimated liability for pre-existing warranties | (972) |  |  | 59 |  |  | (1,369) |  |  | 104 |  |
| Balance, end of the period | 18,288 |  |  | 16,616 |  |  | 18,288 |  |  | 16,616 |  |
| Current portion | 10,444 |  |  | 9,554 |  |  | 10,444 |  |  | 9,554 |  |
| Non-current portion | $ | 7,844 |  |  | $ | 7,062 |  |  | $ | 7,844 |  |  | $ | 7,062 |  |

[0001375365-25-000006:notes:55]
[same as prior period, unchanged from 0001375365-25-000005:notes:58]


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-25-000006:notes:56]
[same as prior period, unchanged from 0001375365-25-000005:notes:59]

[0001375365-25-000006:notes:57]
[same as prior period, unchanged from 0001375365-25-000005:notes:60]

[0001375365-25-000006:notes:58]
[same as prior period, unchanged from 0001375365-25-000005:notes:61]

[0001375365-25-000006:notes:59]
The following table sets forth the Company’s financial instruments as of December 31, 2024 and June 30, 2024, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-25-000006:notes:60]
| December 31, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 30,619 |  |  | $ | — |  |  | $ | — |  |  | $ | 30,619 |  |
| Certificates of deposit | — |  |  | 482 |  |  | — |  |  | 482 |  |
| Investment in marketable equity security | 4,734 |  |  | — |  |  | — |  |  | 4,734 |  |
| Auction rate security | — |  |  | — |  |  | 1,829 |  |  | 1,829 |  |
| Total assets measured at fair value | $ | 35,353 |  |  | $ | 482 |  |  | $ | 1,829 |  |  | $ | 37,664 |  |
| June 30, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 340 |  |  | $ | — |  |  | $ | — |  |  | $ | 340 |  |
| Certificates of deposit | — |  |  | 486 |  |  | — |  |  | 486 |  |
| Investment in marketable equity security | 3,686 |  |  | — |  |  | — |  |  | 3,686 |  |
| Auction rate security | — |  |  | — |  |  | 1,829 |  |  | 1,829 |  |
| Total assets measured at fair value | $ | 4,026 |  |  | $ | 486 |  |  | $ | 1,829 |  |  | $ | 6,341 |  |

[0001375365-25-000006:notes:61]
(1) $30.4 million and $0.1 million in money market funds are included cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in Other assets in the condensed consolidated balance sheets as of December 31, 2024 and June 30, 2024, respectively.

[0001375365-25-000006:notes:62]
[same as prior period, unchanged from 0001375365-25-000005:notes:65]

[0001375365-25-000006:notes:63]
The investment in marketable equity security is carried at fair value using values available on a public exchange, is based on a Level 1 input, and is recorded in Prepaid expenses and other current assets in the condensed consolidated balance sheets. The unrealized gains and losses of the investment are included in earnings. For the three and six months ended December 31, 2024, an unrealized loss of $0.4 million and an unrealized gain of $1.0 million, respectively, has been recorded in Other income (expense), net in the condensed consolidated statement of operations. For the three and six months ended December 31, 2023, an unrealized gain of $0.3 million and a loss of $0.8 million, respectively, has been recorded in Other income (expense), net in the condensed consolidated statements of operations.

[0001375365-25-000006:notes:64]
The Company’s investment in an auction rate security is classified as an available for sale security within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of December 31, 2024 and June 30, 2024. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and using the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. The Company performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount does not result in a significantly higher or lower fair value measurement of the auction rate security as of December 31, 2024.

[0001375365-25-000006:notes:65]
For the three and six months ended December 31, 2024 and 2023, the unrealized gains and losses for the auction rate security in other comprehensive income are immaterial.

[0001375365-25-000006:notes:66]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions, and reasonable economic forecasts that affect collectability. For the three and six months ended December 31, 2024 and 2023, the credit losses related to the Company’s investments were not material.

[0001375365-25-000006:notes:67]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and six months ended December 31, 2024 and 2023.

[0001375365-25-000006:notes:68]
[same as prior period, unchanged from 0001375365-25-000005:notes:71]

[0001375365-25-000006:notes:69]
The Company's non-marketable equity securities consist of investments in privately held companies without readily determinable fair values and are classified as Level 2 in the fair value hierarchy. There were no additional investments during the three months and six months ended December 31, 2024 and 2023. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer.

[0001375365-25-000006:notes:70]
The Company performed a qualitative assessment to identify impairment indicators and records an impairment identified to Other income (expense), net on the condensed consolidated statements of operations. During the three and six months ended December 31, 2024, the Company did not record an impairment. The Company recorded $0.2 million and $1.8 million of impairment during the three and six months ended December 31, 2023, respectively.

[0001375365-25-000006:notes:71]
As of December 31, 2024 and June 30, 2024, the Company had $54.6 million and $54.6 million of investments in privately held companies recorded in Other assets on the condensed consolidated balance sheets for which the measurement alternative was elected.

[0001375365-25-000006:notes:72]
[same as prior period, unchanged from 0001375365-25-000005:notes:75]

[0001375365-25-000006:notes:73]
[same as prior period, unchanged from 0001375365-25-000005:notes:76]

[0001375365-25-000006:notes:74]
As of December 31, 2024 and June 30, 2024, total debt of $208.4 million and $476.4 million, respectively, is reported at amortized cost. The outstanding debt was categorized as Level 2 as it is not actively traded. The carrying value approximates fair value.

[0001375365-25-000006:notes:75]
The estimated fair value of the 2029 Convertible Notes was $1,543.5 million as of December 31, 2024. The estimated fair value of the 2029 Convertible Notes was determined through consideration of quoted market prices. The 2029 Convertible Notes are categorized as Level 2 since their fair value was based on Level 2 inputs of quoted prices.


## us-gaap:DebtDisclosureTextBlock

[0001375365-25-000006:notes:76]
Lines of Credit and Term Loans
Short-term and long-term loan obligations as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands):

[0001375365-25-000006:notes:77]
|  | December 31, |  | June 30, |
|  | 2024 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | 90,467 |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  |  | 9,215 |  |
| HSBC Bank Credit Lines | — |  |  | 30,000 |  |
| E.SUN Bank Credit Lines | 24,374 |  |  | 60,000 |  |
| Mega Bank Credit Lines | — |  |  | 50,000 |  |
| First Bank Credit Lines | — |  |  | 28,084 |  |
| Total line of credit | 114,841 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 13,964 |  |  | 17,918 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 28,291 |  |  | 31,155 |  |
| CTBC Term Loan Facility, due August 15, 2026 | 2,350 |  |  | 3,079 |  |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 17,062 |  |  | 22,116 |  |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 10,562 |  |  | 12,645 |  |
| Mega Bank Term Loan Facility, due October 3, 2026 | 21,327 |  |  | 27,644 |  |
| Total term loans | 93,556 |  |  | 114,557 |  |
| Total lines of credit and term loans | 208,397 |  |  | 476,429 |  |
| Lines of credit and current portion of term loans | 154,988 |  |  | 402,346 |  |
| Term loans, non-current | $ | 53,409 |  |  | $ | 74,083 |  |

[0001375365-25-000006:notes:78]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-25-000006:notes:79]
Available borrowings and interest rates as of December 31, 2024 and June 30, 2024 consisted of the following (in thousands except for percentages):

[0001375365-25-000006:notes:80]
|  | December 31, 2024 |  | June 30, 2024 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 350,000 |  |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  |  | n/a |  | $ | 132,000 |  |  | 7.33% |
| CTBC Credit Lines | $ | 94,533 |  |  | 2.15% - 5.79% |  | $ | 427 |  |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 29,140 |  |  | 1.88% - 5.30% |  | $ | 20,000 |  |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  |  | n/a |  | $ | 20,000 |  |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 35,626 |  |  | 2.02% - 6.17% |  | $ | — |  |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  |  | 1.90% - 5.26% |  | $ | — |  |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | 30,000 |  |  | 2.03% - 5.26% |  | $ | 1,916 |  |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | 47,224 |  |  | 2.32% - 5.95% |  | $ | 47,610 |  |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  |  | n/a |  | $ | — |  |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 2.08% |  | $ | — |  |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  |  | 1.53% - 2.03% |  | $ | — |  |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  |  | 1.87% - 2.17% |  | $ | — |  |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  |  | 2.02% |  | $ | — |  |  | 1.52% - 1.72% |

[0001375365-25-000006:notes:81]
See Note 7 "Short-term and Long-term Debt” and Note 16 "Subsequent Events" of the Company’s 2024 10-K for a more complete description of the Company's credit facilities.

[0001375365-25-000006:notes:82]
The Company entered into new agreements during the six months ended December 31, 2024 with the following terms:

[0001375365-25-000006:notes:83]
Bank of America

[0001375365-25-000006:notes:84]
Bridge Term Loan Facility

[0001375365-25-000006:notes:85]
On July 19, 2024, the Company entered into a Term Loan Credit Agreement, by and among the Company, the lenders

[0001375365-25-000006:notes:86]
party thereto,and Bank of America, N.A., as the administrative agent (the “Term Loan Agent”), which provided for a $500 million term loan facility (the “Bridge Term Loan Facility”). On September 27, 2024, the Company entered into Amendment No. 1 to Term Loan Credit Agreement (the “Term Loan Amendment”), by and among the Company, the lenders party thereto, and the Term Loan Agent, which amended the Bridge Term Loan Facility to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year 2024 under the Bridge Term Loan Facility from September 28, 2024 to November 27, 2024 and required the Company to prepay $250 million of the term loans outstanding thereunder.

[0001375365-25-000006:notes:87]
On November 1, 2024, the Company prepaid in full and terminated its obligations under the Term Loan Agreement.

[0001375365-25-000006:notes:88]
2018 Bank of America Credit Facility

[0001375365-25-000006:notes:89]
On July 19, 2024, the Company entered into an Eighth Amendment to Loan and Security Agreement, by and among the Company, the lenders party thereto, and Bank of America, N.A., as administrative agent for the lenders (the “ABL Agent”), which amends the Loan and Security Agreement, dated as of April 19, 2018 (the “ABL Agreement”) to, among other things, allow for the Company’s entry into and borrowing under the Term Loan Facility.

[0001375365-25-000006:notes:90]
On September 27, 2024, the Company entered into the Ninth Amendment to the ABL Agreement, by and among the Company, the lenders party thereto, and the ABL Agent, which amended the ABL Agreement to, among other things, extend the date by which the Company was required to deliver its audited financial statements for its fiscal year ended June 30, 2024 under the ABL Agreement and added a $70 million availability block to the U.S borrowing base thereunder.

[0001375365-25-000006:notes:91]
On November 20, 2024, the Company prepaid in full and terminated its obligations under the ABL Agreement.

[0001375365-25-000006:notes:92]
2022 Bank of America Credit Facility

[0001375365-25-000006:notes:93]
On November 20, 2024, the Company through Super Micro Computer, Inc. Taiwan (the "Taiwan Subsidiary"), a wholly owned subsidiary of the Company, terminated its obligations under the Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch.

[0001375365-25-000006:notes:94]
Cathay Bank

[0001375365-25-000006:notes:95]
Cathay Bank Line of Credit

[0001375365-25-000006:notes:96]
On October 28, 2024, the Company entered into a Third Amendment to Loan Agreement, by and among the Company and Cathay Bank, which amended the Loan Agreement, dated as of May 19, 2022 (the "Cathay Bank Loan Agreement"), to, among other things, (a) extend the date by which the Company was required to deliver its (i) audited financial statements for its fiscal year 2024 under the Cathay Bank Loan Agreement from October 28, 2024 to December 31, 2024 and (ii) balance sheet and income statement for its fiscal quarter ended September 30, 2024 under the Loan Agreement from November 29, 2024 to December 31, 2024 and (b) added a covenant requiring that the Company maintain at least $150 million of unrestricted cash at all times. On November 15, 2024, the Company also entered into a Fourth Amendment to Loan Agreement, by and between the Company and Cathay Bank, which amended the Cathay Bank Loan Agreement to, among other things, reduce the revolving line and letter of credit sublimit under the Cathay Bank Loan Agreement to $458,000. On November 20, 2024, the Company prepaid in full and terminated its obligations under the Cathay Bank Loan Agreement.

[0001375365-25-000006:notes:97]
E.SUN Bank

[0001375365-25-000006:notes:98]
E.SUN Bank Term Loan Facilities and Credit Lines

[0001375365-25-000006:notes:99]
On November 14, 2024, the Taiwan Subsidiary entered into amendments (the “E.SUN Amendments”) of various Notifications and Confirmations of Credit Agreements (the “Notifications and Confirmations”) previously entered into with E.SUN Bank, which among other things, extended the time period for the financial statements issued by the Taiwan Subsidiary for its fiscal year 2024 to be reviewed by E.SUN Bank from October 31, 2024 to December 31, 2024. In addition, the Notifications and Confirmations included various financial commitments applicable to the Subsidiary related to current ratio, net debt ratio, and interest coverage multiple. If such financial commitments are not achieved, the amortization period for the current balances thereunder will be shortened to one year starting from the 31st of the review month. The Company submitted the financial statements prior to December 31, 2024.

[0001375365-25-000006:notes:100]
HSBC Bank

[0001375365-25-000006:notes:101]
HSBC Bank Credit Lines

[0001375365-25-000006:notes:102]
On December 20, 2024, the General Loan, Export/Import Financing, Overdraft Facilities, and Securities Agreement which the Taiwan Subsidiary had entered into with the Taiwan affiliate of HSBC Bank (the “HSBC Loan Agreement”) was terminated and not renewed. The balance of $50 million under the HSBC Loan Agreement was fully repaid on September 9, 2024, and the loan had remained undrawn since such date.

[0001375365-25-000006:notes:103]
Principal payments on lines of credit and term loans are due as follows (in thousands):

[0001375365-25-000006:notes:104]
Fiscal Year                                                                                                                                                                                                Principal Payments

[0001375365-25-000006:notes:105]
| Remainder of 2025 |  | $ | 134,914 |  |
| 2026 |  | 40,147 |  |
| 2027 |  | 17,442 |  |
| 2028 |  | 5,883 |  |
| 2029 |  | 5,223 |  |
| 2030 and thereafter |  | 4,788 |  |
| Total lines of credit and term loans |  | $ | 208,397 |  |

[0001375365-25-000006:notes:106]
As of December 31, 2024, the Company was in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 6.
Convertible Notes 
2029 Convertible Notes

[0001375365-25-000006:notes:107]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of 2029 Convertible Notes. The Company received net proceeds from the offering of approximately $1,695.8 million. The Company used approximately $142.1 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. The 2029 Convertible Notes will mature on March 1, 2029, unless earlier converted, redeemed or repurchased. On February 20, 2025, the Company executed a first supplemental indenture and second supplemental indenture related to the 2029 Convertible Notes that implemented amendments to the 2029 Convertible Notes. Refer to Note 14. "Subsequent Events", in the notes to the condensed consolidated financial statements below.

[0001375365-25-000006:notes:108]
The 2029 Convertible Notes, when issued, did not bear regular interest, and the principal amount of the 2029 Convertible Notes did not accrete. Because the Company did not file its Annual Report on Form 10-K for the fiscal year ended June 30, 2024 in a timely manner, it elected to accrue special interest on the 2029 Convertible Notes and accrued additional interest on the 2029 Convertible Notes in accordance with the indenture governing the 2029 Convertible Notes (the "2029 Convertible Notes Indenture"). As of December 31, 2024, such accrued and unpaid interest under the 2029 Convertible Notes was $2.2 million. The 2029 Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election, at an initial conversion rate of 7.455 shares of common stock per $1,000 principal amount of 2029 Convertible Notes, which is equivalent to an initial conversion price of approximately $134.14 per share of common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2029 Convertible Notes Indenture. Special interest and additional interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture and have accrued on the 2029 Convertible Notes subsequent to June 30, 2024 as described above. The debt issuance costs are amortized to interest expense. The 2029 Convertible Notes do not contain financial maintenance covenants.

[0001375365-25-000006:notes:109]
Holders may convert their 2029 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the 2029 Convertible Notes Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date.

[0001375365-25-000006:notes:110]
If the Company undergoes a fundamental change (as defined in the 2029 Convertible Notes Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their 2029 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Convertible Notes to be repurchased, plus any accrued and unpaid special interest and additional interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2029 Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-25-000006:notes:111]
The 2029 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid special and additional interest, if any, to, but excluding, the redemption date.

[0001375365-25-000006:notes:112]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes. The 2029 Convertible Notes were not eligible for conversion as of December 31, 2024. No sinking fund is provided for the 2029 Convertible Notes.

[0001375365-25-000006:notes:113]
The 2029 Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the 2029 Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness; effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of December 31, 2024, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met. Therefore, the 2029 Convertible Notes are classified as long-term debt.

[0001375365-25-000006:notes:114]
The Company accounted for the issuance of the 2029 Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

[0001375365-25-000006:notes:115]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs of $24.4 million, was $1,700.6 million as of December 31, 2024. Interest expense related to the amortization of debt issuance costs was $1.5 million for the quarter ended December 31, 2024. The effective interest rate is 0.34%.

[0001375365-25-000006:notes:116]
Capped Calls

[0001375365-25-000006:notes:117]
In connection with the issuance of the 2029 Convertible Notes, the Company entered into privately negotiated capped call transactions (collectively, the “Capped Call Transactions”) with certain financial institutions (the “Capped Call Counterparties”). The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap. In connection with the amendment of the 2029 Convertible Notes, the Company entered into agreements to amend certain terms of the Capped Call Transactions. Refer to Note 14. "Subsequent Events", below.

[0001375365-25-000006:notes:118]
The Capped Call Transactions initially have a strike price of $134.14 per share, subject to certain adjustments, which corresponds to the initial conversion price of the 2029 Convertible Notes. The cap price of the Capped Call Transactions was initially $195.10 per share of common stock subject to certain adjustments under the terms of the Capped Call Transactions.

[0001375365-25-000006:notes:119]
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the 2029 Convertible Notes. As these transactions meet certain accounting criteria, the Capped Call Transactions of $142.1 million are recorded in stockholders’ equity and are not accounted for as derivatives. The Capped Call Transactions will not be remeasured as long as they continue to meet the conditions for equity classification. The 2029 Convertible Notes and the Capped Call Transactions have been integrated for tax purposes. The accounting impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the 2029 Convertible Notes.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-25-000006:notes:120]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and six months ended December 31, 2024 and 2023 were as follows (in thousands):

[0001375365-25-000006:notes:121]
|  | Three Months EndedDecember 31, |  | Six Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating lease expense (including expense for lease agreements with related parties of $165 and $139 for the three months ended December 31, 2024 and 2023, respectively, and $330 and $277 for the six months ended December 31, 2024 and 2023, respectively) | $ | 3,747 |  |  | $ | 2,354 |  |  | $ | 6,973 |  |  | $ | 4,539 |  |
| Cash payments for operating leases (including payments to related parties of $153 and $129 for the three months ended December 31, 2024 and 2023, respectively, $306 and $257 for the six months ended December 31, 2024 and 2023, respectively) | $ | 3,716 |  |  | $ | 2,204 |  |  | $ | 6,579 |  |  | $ | 4,287 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 690 |  |  | $ | 572 |  |  | $ | 18,472 |  |  | $ | 9,749 |  |

[0001375365-25-000006:notes:122]
During the three and six months ended December 31, 2024 and 2023, the Company’s costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three and six months ended December 31, 2024 and 2023 were immaterial.

[0001375365-25-000006:notes:123]
As of December 31, 2024, the weighted average remaining lease term for operating leases was 6.0 years and the weighted average discount rate was 5.3%. As of December 31, 2023, the weighted average remaining lease term for operating leases was 3.1 years and the weighted average discount rate was 4.2%. The short-term portion of the lease liability is included in accrued liabilities and the long-term portion of the lease liability is included in other long-term liabilities on the condensed consolidated balance sheets. Maturities of operating lease liabilities under non-cancelable operating lease arrangements as of December 31, 2024 were as follows (in thousands):

[0001375365-25-000006:notes:124]
| Fiscal Year: |  | Maturities of operating leases(1) |
| Remainder of 2025 |  | $ | 3,864 |  |
| 2026 |  | 10,452 |  |
| 2027 |  | 9,478 |  |
| 2028 |  | 8,198 |  |
| 2029 |  | 7,549 |  |
| 2030 and beyond |  | 19,533 |  |
| Total future lease payments |  | 59,074 |  |
| Less: Imputed interest |  | (10,368) |  |
| Present value of operating lease liabilities |  | 48,706 |  |
| Less: Current portion |  | (6,836) |  |
| Long-term portion of operating lease liabilities |  | $ | 41,870 |  |

[0001375365-25-000006:notes:125]
[same as prior period, unchanged from 0001375365-25-000005:notes:117]

[0001375365-25-000006:notes:126]
[same as prior period, unchanged from 0001375365-25-000005:notes:118]

[0001375365-25-000006:notes:127]
[same as prior period, unchanged from 0001375365-25-000005:notes:119]

[0001375365-25-000006:notes:128]
The Company holds an equity investment of $42.5 million in the sublicensee, which is classified under investments in privately held companies and recorded in Other assets on the condensed consolidated balance sheets. The sublicensee does not meet the criteria of a related party. Additionally, the sublicensee has been a customer of the Company, and the Company concluded that equity investment agreements and sub-licensing agreement are separate from revenue contracts as all transactions have been recorded at the respective fair values.

[0001375365-25-000006:notes:129]
Related party leases

[0001375365-25-000006:notes:130]
The Company has entered into lease agreements with related parties. See Note 9, "Related Party Transactions" for further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-25-000006:notes:131]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2024. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is the Company's Senior Vice President, Business Development and a director of the Company, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

[0001375365-25-000006:notes:132]
In October 2018, the Company's Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.8% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% effective March 1, 2020. The loan was originally made at Mr. Liang's request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of the Company's common stock that he held. The lenders called the loans in October 2018, following the suspension of the Company's common stock from trading on NASDAQ in August 2018 and the decline in the market price of the Company's common stock in October 2018. As of December 31, 2024 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.6 million and $16.4 million, respectively.

[0001375365-25-000006:notes:133]
Dealings with Ablecom

[0001375365-25-000006:notes:134]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-25-000006:notes:135]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 96.1% and 87.2% of the chassis included in the products sold by the Company during the three months ended December 31, 2024 and 2023, respectively, and 96.5% and 86.3% of the chassis included in the products sold by the Company during the six months ended December 31, 2024 and 2023, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-25-000006:notes:136]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. There is no revenue recognized by the Company from these transactions. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-25-000006:notes:137]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on December 31, 2024 were $25.9 million and $34.1 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Ablecom on June 30, 2024 were $99.0 million and $58.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices. The Company has extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000006:notes:138]
Dealings with Compuware

[0001375365-25-000006:notes:139]
The Company appointed Compuware as a non-exclusive authorized distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility of installing the Company's products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company's standard price for its purchases.

[0001375365-25-000006:notes:140]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. The Company has extended a $65.0 million trade credit line with a net 60 days payment terms to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000006:notes:141]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-25-000006:notes:142]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by the Company from these transactions. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-25-000006:notes:143]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on December 31, 2024 were $113.5 million and $66.9 million, respectively, and outstanding cancelable and non-cancelable purchase orders from the Company to Compuware on June 30, 2024 were $129.7 million and $93.5 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-25-000006:notes:144]
Dealings with Leadtek Research Inc.

[0001375365-25-000006:notes:145]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of the Company’s related parties had direct or indirect material interests in any transactions in which the Company was a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, an authorized reseller of the Company. During the three months ended December 31, 2024, the Company engaged in transactions in which it sold $0.2 million of servers to Leadtek and purchased $0.1 million of graphics cards from Leadtek. During the six months ended December 31, 2024, the Company engaged in transactions in which it sold $0.3 million of servers to Leadtek and purchased $0.5 million of graphics cards from Leadtek.

[0001375365-25-000006:notes:146]
Dealings with Investment in a Corporate Venture

[0001375365-25-000006:notes:147]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-25-000006:notes:148]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $7.3 million and $4.6 million as of December 31, 2024 and June 30, 2024, respectively, recorded in Other assets on the condensed consolidated balance sheets. The Company performed its impairment analysis on this investment and concluded the carrying value is not impaired as of December 31, 2024 and June 30, 2024. No impairment charge was recorded for the three and six months ended December 31, 2024 and 2023.

[0001375365-25-000006:notes:149]
The Company sold products worth $0.0 million and $11.4 million to the Corporate Venture during the three months ended December 31, 2024 and 2023, respectively, and $4.8 million and $12.2 million to the Corporate Venture during the six months ended December 31, 2024 and 2023, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2024 and June 30, 2024 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.0 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of December 31, 2024 and June 30, 2024, respectively.

[0001375365-25-000006:notes:150]
Other Transactions

[0001375365-25-000006:notes:151]
For the three months ended December 31, 2024, the Company had no transactions from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with the Company’s Chief Executive Officer. For the six months ended December 31, 2024, the Company had immaterial chargebacks from Green Earth. As of December 31, 2024, there was no balance due to and from Green Earth. As of June 30, 2024, the amounts due to and from Green Earth are immaterial.

[0001375365-25-000006:notes:152]
The Company had the following balances related to transactions with its related parties as of December 31, 2024 and June 30, 2024 (in thousands):

[0001375365-25-000006:notes:153]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek |  | Total |
|  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |  |  |  | December 31, 2024 |  | June 30, 2024 |  | December 31, 2024 |  | June 30, 2024 |
| Accounts receivable | $ | 2 |  |  | $ | 1 |  |  | $ | 34 |  |  | $ | 142 |  |  | $ | (2) |  |  | $ | 5,075 |  |  |  |  | $ | 134 |  |  | $ | 976 |  |  | $ | 168 |  |  | $ | 6,194 |  |
| Other receivable (1) | $ | 1,597 |  |  | $ | 1,927 |  |  | $ | 15,753 |  |  | $ | 10,012 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 17,350 |  |  | $ | 11,939 |  |
| Accounts payable | $ | 52,754 |  |  | $ | 98,629 |  |  | $ | 56,697 |  |  | $ | 66,436 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 84 |  |  | $ | 230 |  |  | $ | 109,535 |  |  | $ | 165,295 |  |
| Accrued liabilities (2) | $ | 294 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 170 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  | $ | 318 |  |  | $ | 170 |  |

[0001375365-25-000006:notes:154]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-25-000006:notes:155]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2024 and 2023, are as follows (in thousands):

[0001375365-25-000006:notes:156]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, | Three months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 5 |  |  | $ | 4 |  |  | $ | 11,065 |  |  | $ | 4,392 |  |  | $ | (51) |  |  | $ | 11,385 |  |  |  |  | $ | 258 |  |  | $ | — |  | $ | 11,277 |  |  | $ | 15,781 |  |
| Purchases - inventory | $ | 64,773 |  |  | $ | 50,586 |  |  | $ | 71,230 |  |  | $ | 61,859 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 106 |  |  | $ | — |  | $ | 136,109 |  |  | $ | 112,445 |  |
| Purchases - other miscellaneous items | $ | 3,764 |  |  | $ | 3,456 |  |  | $ | 294 |  |  | $ | 332 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 4,058 |  |  | $ | 3,788 |  |

[0001375365-25-000006:notes:157]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

[0001375365-25-000006:notes:158]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Net sales | $ | 7 |  |  | $ | 6 |  |  | $ | 21,040 |  |  | $ | 20,998 |  |  | $ | 4,776 |  |  | $ | 12,173 |  |  |  |  | $ | 329 |  |  | $ | — |  | $ | 26,152 |  |  | $ | 33,177 |  |
| Purchases - inventory | $ | 202,279 |  |  | $ | 97,199 |  |  | $ | 173,348 |  |  | $ | 128,353 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 534 |  |  | $ | — |  | 376,161 |  |  | 225,552 |  |
| Purchases - other miscellaneous items | $ | 10,118 |  |  | $ | 8,215 |  |  | $ | 1,031 |  |  | $ | 749 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 11,149 |  |  | $ | 8,964 |  |

[0001375365-25-000006:notes:159]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2024 and 2023, are as follows (in thousands):

[0001375365-25-000006:notes:160]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Leadtek | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, | Six months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 108 |  |  | $ | 3,239 |  |  | $ | 5,077 |  |  | $ | (1,625) |  |  |  |  | $ | 842 |  |  | $ | — |  | $ | 6,026 |  |  | $ | 1,614 |  |
| Changes in other receivable | $ | 330 |  |  | $ | 571 |  |  | $ | (5,741) |  |  | $ | (7,132) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | (5,411) |  |  | $ | (6,561) |  |
| Changes in accounts payable | $ | (45,875) |  |  | $ | 10,938 |  |  | $ | (9,739) |  |  | $ | 1,628 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 146 |  |  | $ | — |  | $ | (55,468) |  |  | $ | 12,566 |  |
| Changes in accrued liabilities | $ | 294 |  |  | $ | (156) |  |  | $ | (146) |  |  | $ | 4,648 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 148 |  |  | $ | 4,492 |  |
| Changes in other long-term liabilities | $ | 154 |  |  | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 154 |  |  | $ | (152) |  |
| Purchases of property, plant and equipment | $ | 6,525 |  |  | $ | 4,460 |  |  | $ | 357 |  |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 6,882 |  |  | $ | 4,528 |  |
| Unpaid property, plant and equipment | $ | 2,946 |  |  | $ | 2,570 |  |  | $ | 14 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | — |  | $ | 2,960 |  |  | $ | 2,577 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-25-000006:notes:161]
[same as prior period, unchanged from 0001375365-25-000005:notes:151]

[0001375365-25-000006:notes:162]
The Company has 10,000,000 shares of undesignated preferred stock, $0.001 par value per share, authorized but not issued with rights and preferences determined by the Company’s Board of Directors at the time of issuance of such shares. As of December 31, 2024 and 2023, there were no shares of preferred stock issued and outstanding.

[0001375365-25-000006:notes:163]
[same as prior period, unchanged from 0001375365-25-000005:notes:153]

[0001375365-25-000006:notes:164]
The Company may issue up to 1,000,000,000 shares of common stock, $0.001 par value per share. The holders of the Company's common stock are entitled to one vote for each share held of record on all matters submitted to a vote of stockholders.

[0001375365-25-000006:notes:165]
[same as prior period, unchanged from 0001375365-25-000005:notes:155]

[0001375365-25-000006:notes:166]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the “Original 2020 Plan”). The maximum number of shares available under the Original 2020 Plan was 50,000,000, plus 10,450,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 72,460,000 shares of common stock remained reserved for outstanding awards issued under the 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 20,000,000 shares.

[0001375365-25-000006:notes:167]
On January 22, 2024, the stockholders of the Company approved a further amendment and restatement of the Original 2020 Plan (as amended and restated from time to time, the “2020 Plan”) which, among other things, further increased the number of shares available for award under the 2020 Plan by an additional 15,000,000 shares.

[0001375365-25-000006:notes:168]
[same as prior period, unchanged from 0001375365-25-000005:notes:158]

[0001375365-25-000006:notes:169]
As of December 31, 2024, the Company had 5,226,084 authorized shares available for future issuance under the 2020 Plan.

[0001375365-25-000006:notes:170]
[same as prior period, unchanged from 0001375365-25-000005:notes:160]

[0001375365-25-000006:notes:171]
[same as prior period, unchanged from 0001375365-25-000005:notes:161]

[0001375365-25-000006:notes:172]
[same as prior period, unchanged from 0001375365-25-000005:notes:162]

[0001375365-25-000006:notes:173]
[same as prior period, unchanged from 0001375365-25-000005:notes:163]

[0001375365-25-000006:notes:174]
[same as prior period, unchanged from 0001375365-25-000005:notes:164]

[0001375365-25-000006:notes:175]
The fair value of the Company's RSUs are based on the closing market price of the Company’s common stock on the date of grant. The Company estimates the fair value of stock options granted using the Black-Scholes-option-pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-25-000006:notes:176]
[same as prior period, unchanged from 0001375365-25-000005:notes:166]

[0001375365-25-000006:notes:177]
[same as prior period, unchanged from 0001375365-25-000005:notes:167]

[0001375365-25-000006:notes:178]
[same as prior period, unchanged from 0001375365-25-000005:notes:168]

[0001375365-25-000006:notes:179]
[same as prior period, unchanged from 0001375365-25-000005:notes:169]

[0001375365-25-000006:notes:180]
The fair value of stock option grants for the three and six months ended December 31, 2024 and 2023 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-25-000006:notes:181]
|  | Three Months Ended December 31, |  | Six Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Risk-free interest rate | 4.17% - 4.20% |  | 4.78% |  | 3.82% - 4.20% |  | 4.15% - 4.78% |
| Expected term | 5.98 years |  | 5.99 years |  | 3.00 years - 5.98 years |  | 3.00 years - 5.99 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 67.17% |  | 58.89% |  | 63.67% - 69.97% |  | 56.87% - 58.89% |
| Weighted-average fair value of options | $20.82 |  | $15.61 |  | $30.29 |  | $17.92 |

[0001375365-25-000006:notes:182]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and six months ended December 31, 2024 and 2023 (in thousands):

[0001375365-25-000006:notes:183]
|  | Three Months Ended December 31, |  | Six Months EndedDecember 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of sales | $ | 6,694 |  |  | $ | 3,555 |  |  | $ | 10,653 |  |  | $ | 9,459 |  |
| Research and development | 50,809 |  |  | 25,439 |  |  | 87,336 |  |  | 61,149 |  |
| Sales and marketing | 9,559 |  |  | 4,340 |  |  | 17,322 |  |  | 10,005 |  |
| General and administrative | 15,060 |  |  | 9,727 |  |  | 30,825 |  |  | 19,827 |  |
| Stock-based compensation expense before taxes | 82,122 |  | * | 43,061 |  |  | 146,136 |  |  | 100,440 |  |
| Income tax impact | (19,136) |  |  | (9,569) |  |  | (35,009) |  |  | (25,434) |  |
| Stock-based compensation expense, net | $ | 62,986 |  |  | $ | 33,492 |  |  | $ | 111,127 |  |  | $ | 75,006 |  |

[0001375365-25-000006:notes:184]
During the three and six months ended December 31, 2024, stock-based compensation expense capitalized to our condensed consolidated balance sheets was $0.1 million and $0.3 million, respectively. No stock-based compensation expense was capitalized during the three and six months ended December 31, 2023.

[0001375365-25-000006:notes:185]
As of December 31, 2024, $192.1 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 3.03 years and $612.4 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.49 years.

[0001375365-25-000006:notes:186]
[same as prior period, unchanged from 0001375365-25-000005:notes:176]

[0001375365-25-000006:notes:187]
[same as prior period, unchanged from 0001375365-25-000005:notes:177]

[0001375365-25-000006:notes:188]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 10,000,000 shares of common stock to the Company’s CEO (the “2021 CEO Performance Stock Option”). As of December 31, 2024, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:

[0001375365-25-000006:notes:189]
[same as prior period, unchanged from 0001375365-25-000005:notes:179]

[0001375365-25-000006:notes:190]
[same as prior period, unchanged from 0001375365-25-000005:notes:180]

[0001375365-25-000006:notes:191]
[same as prior period, unchanged from 0001375365-25-000005:notes:181]

[0001375365-25-000006:notes:192]
[same as prior period, unchanged from 0001375365-25-000005:notes:182]

[0001375365-25-000006:notes:193]
[same as prior period, unchanged from 0001375365-25-000005:notes:183]

[0001375365-25-000006:notes:194]
[same as prior period, unchanged from 0001375365-25-000005:notes:184]

[0001375365-25-000006:notes:195]
During the three and six months ended December 31, 2024, the Company did not recognize compensation expense related to the 2021 CEO Performance Stock Option. During the three and six months ended December 31, 2023, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.5 million and $0.7 million, respectively. As of December 31, 2024 and June 30, 2024, the Company had no unrecognized compensation cost related to the 2021 CEO Performance Stock Option.

[0001375365-25-000006:notes:196]
[same as prior period, unchanged from 0001375365-25-000005:notes:186]

[0001375365-25-000006:notes:197]
[same as prior period, unchanged from 0001375365-25-000005:notes:187]

[0001375365-25-000006:notes:198]
The achievement status of the operational and stock price milestones as of December 31, 2024 was as follows:

[0001375365-25-000006:notes:199]
[same as prior period, unchanged from 0001375365-25-000005:notes:189]

[0001375365-25-000006:notes:200]
[same as prior period, unchanged from 0001375365-25-000005:notes:190]

[0001375365-25-000006:notes:201]
[same as prior period, unchanged from 0001375365-25-000005:notes:191]

[0001375365-25-000006:notes:202]
[same as prior period, unchanged from 0001375365-25-000005:notes:192]

[0001375365-25-000006:notes:203]
[same as prior period, unchanged from 0001375365-25-000005:notes:193]

[0001375365-25-000006:notes:204]
[same as prior period, unchanged from 0001375365-25-000005:notes:194]

[0001375365-25-000006:notes:205]
During the three and six months ended December 31, 2024, the Company recognized compensation expense related to the 2023 CEO Performance Stock Option of $3.8 million and $11.5 million, respectively. As of December 31, 2024, the Company had $7.4 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of December 31, 2024 is expected to be recognized over a period of 2.0 years. During the three and six months ended December 31, 2023, the Company recognized compensation expense related to the 2023 CEO Performance Stock Option of $2.5 million. As of December 31, 2023, the Company had $27.4 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of December 31, 2023 is expected to be recognized over a period of 1.75 years.

[0001375365-25-000006:notes:206]
[same as prior period, unchanged from 0001375365-25-000005:notes:196]

[0001375365-25-000006:notes:207]
The following table summarizes stock option activity during the six months ended December 31, 2024 under all plans:

[0001375365-25-000006:notes:208]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageGrant Date Fair Value |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2024 |  | 35,443,550 |  |  | $ | 17.57 |  |  |  |  |  |  |  |
| Granted |  | 2,276,818 |  |  | $ | 48.71 |  |  | $ | 30.30 |  |  |  |  |  |
| Exercised |  | (3,104,590) |  |  | $ | 4.13 |  |  |  |  |  |  |  |
| Forfeited/Cancelled |  | (421,768) |  |  | $ | 34.56 |  |  |  |  |  |  |  |
| Balance as of December 31, 2024 |  | 34,194,010 |  |  | $ | 20.65 |  |  |  |  | 7.16 |  |  |
| Options vested and expected to vest at December 31, 2024 |  | 34,194,010 |  |  | $ | 20.65 |  |  |  |  |  |  |  |
| Options exercisable December 31, 2024(1) |  | 18,661,920 |  |  | $ | 5.99 |  |  |  |  | 5.86 |  |  |

[0001375365-25-000006:notes:209]
(1)Due to the Company’s delay in filing the 2024 10-K, the Company's registration statements on Form S-8 was ineffective for shares underlying these options, and these options were not exercisable, as of December 31, 2024. These options become exercisable once the registration statements on Form S-8 become re-effective upon the filing of the Company’s 2024 10-K.

[0001375365-25-000006:notes:210]
The total pretax intrinsic value of options exercised during the three and six months ended December 31, 2024 was $52.7 million and $115.8 million, respectively. The total pretax intrinsic value of options exercised during the three and six months ended December 31, 2023 was $36.6 million and $82.5 million, respectively.

[0001375365-25-000006:notes:211]
[same as prior period, unchanged from 0001375365-25-000005:notes:200]

[0001375365-25-000006:notes:212]
The following table summarizes RSU activity during the six months ended December 31, 2024 under all plans:

[0001375365-25-000006:notes:213]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2024 | 21,272,990 |  |  | $ | 24.19 |  |  |  |  |  |  |
| Granted | 6,232,531 |  |  | $ | 44.41 |  |  |  |  |  |  |
| Released | (4,585,200) |  |  | $ | 13.38 |  |  |  |  |  |  |
| Forfeited | (644,565) |  |  | $ | 34.89 |  |  |  |  |  |  |
| Balance as of December 31, 2024 | 22,275,756 |  |  | $ | 31.77 |  |  |  |  |  |  |


## smci:SummaryOfOperationalAndStockPriceMilestonesTableTextBlock

[0001375365-25-000006:notes:214]
As of December 31, 2024, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-25-000006:notes:215]
Income Taxes
The Company recorded a provision for income taxes of $57.0 million and $131.7 million for the three and six months ended December 31, 2024, respectively, and $61.5 million and $81.7 million for the three and six months ended December 31, 2023, respectively. The effective tax rate was 15.2% and 15.1% for the three and six months ended December 31, 2024, respectively, and 17.3% and 15.3% for the three and six months ended December 31, 2023, respectively. The effective tax rate for the three months ended December 31, 2024 was lower than that for the three months ended December 31, 2023, primarily due to the increase in stock compensation tax deduction for the three months ended December 31, 2024. However, the effective tax rate for the six months ended December 31, 2024 remains nearly unchanged compared to the six months ended December 31, 2023, as the stock based compensation deduction remains relatively consistent year over year. The effective tax rates for the first three months and six months of fiscal years 2025 and 2024 were lower than the U.S. federal statutory rate of 21%, primarily due to tax benefits from the foreign-derived intangible income deduction, stock-based compensation, and the U.S. federal research tax credit.

[0001375365-25-000006:notes:216]
[same as prior period, unchanged from 0001375365-25-000005:notes:205]

[0001375365-25-000006:notes:217]
[same as prior period, unchanged from 0001375365-25-000005:notes:206]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-25-000006:notes:218]
Commitments and Contingencies
Litigation and claims

[0001375365-25-000006:notes:219]
On August 30, 2024, three putative class action complaints were filed against the Company, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. On October 28, 2024, the Spatz plaintiff voluntarily dismissed the Spatz complaint without prejudice against all Defendants, ending the suit. On November 21, 2024, the Averza Court entered a Stipulation and Order extending Defendants’ time to respond to the Averza complaint until after the Court appoints a lead plaintiff, which hearing is set for March 6, 2025. A similar stipulation was entered among the parties as to the Covey Financial complaint. On January 9, 2025, the Menditto plaintiff voluntarily dismissed the Menditto complaint without prejudice against all Defendants, ending the suit. The Company has not been served with the Norfolk County Retirement System complaint. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000006:notes:220]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been

[0001375365-25-000006:notes:221]
filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). The Company was named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that the Company’s officers and directors caused the Company to issue materially false and misleading statements concerning the Company’s business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On November 5, 2024, the Court in the Hollin Action entered a Stipulation and Order staying all proceedings in Hollin and any related federal derivative actions, which includes the Federal Derivative Litigation. The Court in the State Court Derivative Litigation stayed all proceedings until case management conferences were held in each suit, with the first conference scheduled for April 24, 2025 in Spatz. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000006:notes:222]
On November 22, 2024, a putative class action claim was filed against the Company in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that the Company violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding the Company’s financial results and its internal controls and procedures. A case management judge was assigned in December 2024, but no case conference has been scheduled and no timetable for subsequent procedural steps has been set. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and the Company is unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000006:notes:223]
In late 2024, the Company received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication in a short seller report which was published in August 2024. The Company is cooperating with these document requests and no charges have been brought as of the date of this filing.

[0001375365-25-000006:notes:224]
Other legal proceedings and indemnifications

[0001375365-25-000006:notes:225]
In addition to the matters described above, from time to time, the Company has been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s condensed consolidated financial condition, results of operations or liquidity as of December 31, 2024 and any prior periods.

[0001375365-25-000006:notes:226]
The Company has entered into indemnification agreements with its current and former directors and executive officers. Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-25-000006:notes:227]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2024, these remaining non-cancelable commitments were $2.3 billion, including $101.1 million for related parties. The Company also reviews and assesses the need for expected loss liabilities on a quarterly basis for all products it does not expect to sell for but has committed purchases from suppliers. There were no loss liabilities recognized as of December 31, 2024 and $26.4 million of loss liabilities were recognized in Accrued liabilities in the condensed consolidated balance sheets from purchase commitments as of June 30, 2024.

[0001375365-25-000006:notes:228]
Lease Commitments— See Note 8, "Leases," for a discussion of the Company's operating lease commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-25-000006:notes:229]
[same as prior period, unchanged from 0001375365-25-000005:notes:218]

[0001375365-25-000006:notes:230]
[same as prior period, unchanged from 0001375365-25-000005:notes:219]

[0001375365-25-000006:notes:231]
|  | December 31, |  | June 30, |
|  | 2024 |  | 2024 |
| Long-lived assets: |  |  |  |
| United States | $ | 306,546 |  |  | $ | 281,874 |  |
| Taiwan | 112,908 |  |  | 107,878 |  |
| Other | 58,038 |  |  | 24,256 |  |
|  | $ | 477,492 |  |  | $ | 414,008 |  |

[0001375365-25-000006:notes:232]
The table above excludes other assets, goodwill and intangible assets. Operating lease assets in the United States and the Netherlands were $37.8 million and $6.1 million as of December 31, 2024, respectively. Operating lease assets in the United States were $29.3 million as of June 30, 2024. Operating lease assets in all other countries were less than 10% as of December 31, 2024 and June 30, 2024.

[0001375365-25-000006:notes:233]
For the three months ended December 31, 2024 and 2023, 67.8% and 71.1% of the Company’s revenues were from the United States. For the six months ended December 31, 2024 and 2023, 69.6% and 73.0% of the Company’s revenues were from the United States. Other countries were individually less than 10%. The Company’s revenue by geographic region is based on where the products were shipped to for the three and six months ended December 31, 2024 and 2023.


## us-gaap:SubsequentEventsTextBlock

[0001375365-25-000006:notes:234]
Subsequent Events

[0001375365-25-000006:notes:235]
Amendment of 2029 Convertible Notes and associated capped calls

[0001375365-25-000006:notes:236]
On February 20, 2025, the Company amended the terms of the 2029 Convertible Notes pursuant to a first supplemental indenture and a second supplemental indenture, in each case by and between the Company and U.S. Bank Trust Company, National Association as trustee. The terms of the 2029 Convertible Notes were amended to (i) bear interest from February 20, 2025 at an annual rate of 3.50%, payable semi-annually in arrears on each March 1 and September 1, beginning on September 1, 2025 and (ii) include an updated initial conversion rate of 11.9842 shares of the Company's common stock per $1,000 principal amount of 2029 Convertible Notes (equivalent to an initial conversion price of approximately $83.44 per share of the Company’s common stock). The conversion rate and conversion price will be subject to adjustment upon the occurrence of certain events. The remaining terms of the 2029 Convertible Notes remain substantially unchanged.

[0001375365-25-000006:notes:237]
In connection with the amendment of the terms of the 2029 Convertible Notes, the Company amended the capped call transactions entered into in connection with the initial issuance of the 2029 Convertible Notes in February 2024. The amendments, among other things, make certain adjustments to the economic terms of the capped call transactions, including the cap price. The cap price, after giving effect to the amendments, is initially $94.1666 per share of the Company's common stock, and is subject to certain adjustments under the terms of the amended capped calls.

[0001375365-25-000006:notes:238]
Issuance of 2028 Convertible Notes

[0001375365-25-000006:notes:239]
On February 20, 2025, the Company issued $700.0 million aggregate principal amount of 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”) pursuant to an indenture, dated as of February 20, 2025 by and between the Company and U.S. Bank Trust Company, National Association, as trustee for gross proceeds of $700 million and approximately $50 million of issuance cost. The 2028 Convertible Notes were sold to investors pursuant to privately negotiated agreements. The 2028 Convertible Notes will mature on July 15, 2028, unless earlier redeemed, repurchased or converted. The 2028 Convertible Notes have an initial conversion rate of 16.3784 shares of the Company’s common stock per $1,000 principal amount of the 2028 Convertible Notes, which is equivalent to an initial conversion price of approximately $61.06 per share of the Company’s common stock, in each case subject to adjustment upon the occurrence of certain events. Prior to January 15, 2028, the 2028 Convertible Notes will be convertible only upon the satisfaction of certain conditions and during certain periods, and on and after January 15, 2028, at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date, the 2028 Convertible Notes will be convertible regardless of these conditions. The Company will settle conversions of the 2028 Convertible Notes by paying or delivering cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock at the Company’s election.
