# SMCI note change history — 0001375365-24-000011 → 0001375365-24-000022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:1]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2024 and any prior periods.
  (was, 2024-02-02, similarity 0.98):
[0001375365-24-000011:note_history:1]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of December 31, 2023 and any prior periods.

- changed (2024-05-06):
[0001375365-24-000022:note_history:2]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2024, these remaining noncancelable commitments were $2.9 billion, including $100.4 million for related parties.
  (was, 2024-02-02, similarity 0.8497):
[0001375365-24-000011:note_history:2]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of December 31, 2023, these remaining noncancelable commitments were $1.9 billion, including $87.4 million for related parties.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:3]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2024 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.
  (was, 2024-02-02, similarity 0.9546):
[0001375365-24-000011:note_history:3]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and six months ended December 31, 2023 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.

- added (2024-05-06):
[0001375365-24-000022:note_history:4]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Supplier A accounted for 69.8% and supplier B accounted for 5.1% of total purchases for the three months ended March 31, 2024, and supplier A accounted for 26.9% and supplier B accounted for 16.9% of total purchases for the three months ended March 31, 2023. Supplier A accounted for 65.8% and supplier B accounted for 7.1% of total purchases for the nine months ended March 31, 2024, and supplier A accounted for 23.6% and supplier B accounted for 15.8% of total purchases for the nine months ended March 31, 2023. The increase in the concentration of the Company's total purchases from supplier A for 69.8% and 65.8% of total purchases for the three and nine months ended March 31, 2024, respectively, is as a result of the purchase of key components to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 9, "Related Party Transactions") accounted for a combined 4.0% and 8.3% of total cost of sales for the three months ended March 31, 2024 and 2023, respectively, and a combined 4.4% and 7.0% of total cost of sales for the nine months ended March 31, 2024 and 2023, respectively.

- added (2024-05-06):
[0001375365-24-000022:note_history:5]
Customer A accounted for 27.9%, customer E accounted for 18.1% and customer B accounted for 15.4% of accounts receivable, net as of March 31, 2024. Customer A accounted for 22.9% and customer B accounted for 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.

- added (2024-05-06):
[0001375365-24-000022:note_history:6]
Customer A accounted for 21.2% and customer B accounted for 16.8% of the net sales for the three months ended March 31, 2024 and customer A accounted for 23.7% of the net sales for the nine months ended March 31, 2024. Customer A accounted for 10.7% of the net sales for the three months ended March 31, 2023, and customer C accounted for 11.8% of the net sales for the nine months ended March 31, 2023.

- removed (2024-05-06):
[0001375365-24-000011:note_history:7]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Two suppliers accounted for 68.1% and 7.3% of total purchases for the three months ended December 31, 2023, and the same two suppliers accounted for 17.6% and 14.1% of total purchases for the three months ended December 31, 2022. Two suppliers accounted for 62.9% and 8.6% of total purchases for the six months ended December 31, 2023, and the same two suppliers accounted for 22.3% and 15.3% of total purchases for the six months ended December 31, 2022. The increase in concentration of total purchases to one of the Company's suppliers to 68.1% and 62.9% of total purchases for the three and six months ended December 31, 2023, respectively, is as a result of the purchase of key components to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 8, "Related Party Transactions") accounted for a combined 3.6% and 6.7% of total cost of sales for the three months ended December 31, 2023 and 2022, respectively, and a combined 4.6% and 6.6% of total cost of sales for the six months ended December 31, 2023 and 2022, respectively.

- removed (2024-05-06):
[0001375365-24-000011:note_history:8]
Four customers accounted for 26.7%, 16.3%, 13.0% and 11.3% of accounts receivable, net as of December 31, 2023. Two customers accounted for 22.9% and 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.

- removed (2024-05-06):
[0001375365-24-000011:note_history:9]
Two customers accounted for 25.5% and 10.4% of the net sales for the three months ended December 31, 2023 and one customer accounted for 25.3% of the net sales for the six months ended December 31, 2023. No single customer accounted for 10% or more of the net sales for the three months ended December 31, 2022, and one customer accounted for 15.8% of the net sales for the six months ended December 31, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:10]
and Term Loans
Short-term and long-term loan obligations as of March 31, 2024 and June 30, 2023 consisted of the following (in thousands):
  (was, 2024-02-02, similarity 0.8394):
[0001375365-24-000011:note_history:10]
Short-term and Long-term Debt
Short-term and long-term debt obligations as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands):

- added (2024-05-06):
[0001375365-24-000022:note_history:11]
|  | March 31, |  | June 30, |
|  | 2024 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2024 CTBC Credit Lines | 24,994 |  |  | — |  |
| Chang Hwa Bank Credit Facility | — |  |  | — |  |
| 2023 HSBC Bank Credit Lines | 8,217 |  |  | — |  |
| 2022 E.SUN Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | 7,186 |  |  | — |  |
| Total line of credit | 40,397 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 20,178 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 33,029 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,493 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 24,995 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 13,877 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 31,243 |  |  | 38,668 |  |
| Total term loans | 126,815 |  |  | 158,719 |  |
| Total lines of credit and term loans | 167,212 |  |  | 290,302 |  |
| Lines of credit and current portion of term loans | 81,566 |  |  | 170,123 |  |
| Term loans, non-current | $ | 85,646 |  |  | $ | 120,179 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:12]
Available borrowings and interest rates as of March 31, 2024 and June 30, 2023 consisted of the following (in thousands except for percentages):
  (was, 2024-02-02, similarity 0.9668):
[0001375365-24-000011:note_history:12]
Available borrowings and interest rates as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):

- changed (2024-05-06):
[0001375365-24-000022:note_history:13]
|  | March 31, 2024 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 7.06% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  |  | 7.50% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2024 CTBC Credit Lines | $ | 160,006 |  |  | 1.94% - 6.26% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.30% |  | $ | 20,000 |  |  | 6.58% |
| 2023 HSBC Bank Credit Lines | $ | 41,783 |  |  | 2.03% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 12,814 |  |  | 1.90% - 1.91% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.68% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.53% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.87% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.52% - 1.72% |  | $ | — |  |  | 1.40% - 1.60% |
  (was, 2024-02-02, similarity 0.9871):
[0001375365-24-000011:note_history:13]
|  | December 31, 2023 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 6.82% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | — |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 417 |  |  | 7.36% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2023 CTBC Credit Line | $ | 68,127 |  |  | 1.96% - 6.52% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.38% |  | $ | 20,000 |  |  | 6.58% |
| HSBC Bank Credit Facility | $ | 20,296 |  |  | 1.90% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 4,474 |  |  | 1.90% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.55% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.20% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.40% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.75% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.75% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.40% - 1.60% |  | $ | — |  |  | 1.40% - 1.60% |

- changed (2024-05-06):
[0001375365-24-000022:note_history:14]
The Company entered into new agreements during the nine months ended March 31, 2024 with the following terms:
  (was, 2024-02-02, similarity 0.9333):
[0001375365-24-000011:note_history:14]
The Company entered into new agreements during the six months ended December 31, 2023 with the following terms:

- changed (2024-05-06):
[0001375365-24-000022:note_history:15]
On February 16, 2024 (the “Effective Date”), the Company's Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank. This agreement (which changed arrangements which had been entered into with CTBC Bank in September 2023), increased the aggregate total borrowings under the various individual credit arrangements with CTBC Bank from $105.0 million to $185.0 million. The credit arrangements under such general agreement now include the previous issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line”) and (iv) an import o/a loan line of credit of up to $80.0 million available through August 31, 2024 (the “Incremental Import Line,” and, together with the NTD Short Term Loan/Guarantee Line, the USD Short Term Loan Line, and the Export/Import Line, the “Increased CTBC Credit Lines”). Aggregate borrowings under all the Increased CTBC Credit Lines is subject to a cap of $185.0 million.
  (was, 2024-02-02, similarity 0.7299):
[0001375365-24-000011:note_history:15]
On September 28, 2023 (the “Effective Date”), the Company's Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank, which replaces the prior CTBC credit lines in their entirety and permits for borrowings, from time to time, thereunder pursuant to various individual credit arrangements and includes the previously issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), and (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line,” and, together with the NTD Short Term Loan/Guarantee Line and the USD Short Term Loan Line, the “New CTBC Credit Lines”). Aggregate borrowings under the New CTBC Credit Lines together is subject to a cap of $105.0 million.

- changed (2024-05-06):
[0001375365-24-000022:note_history:16]
Interest rates under each of the individual Increased CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the NTD Short Term Loan/Guarantee Line and USD Short Term Loan Line continue to be secured by certain of the Company's Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor of the Incremental Import Line provides for availability until August 31, 2024 with a final drawdown date of October 30, 2024. Such Incremental Import Line, which is reviewed quarterly for cancellation by the CTBC Bank, is also subject to an average usage requirement and fee for retaining the underutilized portion of such line. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, the Company to maintain ownership of all of the capital stock of the Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the Increased CTBC Credit Lines. The Increased CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable.
  (was, 2024-02-02, similarity 0.8486):
[0001375365-24-000011:note_history:16]
Interest rates under each of the individual New CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the NTD Short Term Loan/Guarantee Line and USD Short Term Loan Line are secured by certain of the Company's Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor for each of the individual New CTBC Credit Lines is one year. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, the Company to maintain ownership of all of the capital stock of its Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the New CTBC Credit Lines. The New CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable upon the occurrence of an event of default.

- changed (2024-05-06):
[0001375365-24-000022:note_history:17]
The Company's Taiwan subsidiary intends to use borrowings under the Increased CTBC Credit Lines in connection with financing of eligible accounts receivable and accounts payable (vendor invoices).
  (was, 2024-02-02, similarity 0.7664):
[0001375365-24-000011:note_history:17]
The Company's Taiwan subsidiary intends to use borrowings under the New CTBC Credit Lines in connection with financing of eligible accounts receivable and accounts payable (vendor invoices) and to finance additional improvements to the Company’s Bade Manufacturing Facility located in Taiwan.

- changed (2024-05-06):
[0001375365-24-000022:note_history:18]
As of March 31, 2024, the outstanding borrowings under the 2024 CTBC Bank Credit Lines were $25.0 million. The interest rate for these loans were 1.94% - 6.26% per annum as of March 31, 2024.
  (was, 2024-02-02, similarity 0.9471):
[0001375365-24-000011:note_history:18]
As of December 31, 2023, the outstanding borrowings under the 2023 CTBC Bank Credit Lines were $36.9 million. The interest rate for these loans were 1.96% - 6.52% per annum as of December 31, 2023.

- changed (2024-05-06):
[0001375365-24-000022:note_history:19]
As of March 31, 2024, the outstanding borrowings under HSBC Bank Credit Lines were $8.2 million. The interest rates for these loans were 2.03% - 6.37% per annum as of March 31, 2024.
  (was, 2024-02-02, similarity 0.9455):
[0001375365-24-000011:note_history:19]
As of December 31, 2023, the outstanding borrowings under HSBC Bank Credit Lines were $29.7 million. The interest rates for these loans were 1.90% - 6.37% per annum as of December 31, 2023.

- changed (2024-05-06):
[0001375365-24-000022:note_history:20]
Principal payments on lines of credit and term loans are due as follows (in thousands):
  (was, 2024-02-02, similarity 0.8111):
[0001375365-24-000011:note_history:20]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:21]
| Remainder of 2024 |  | $ | 50,690 |  |
| 2025 |  | 41,169 |  |
| 2026 |  | 41,169 |  |
| 2027 |  | 17,886 |  |
| 2028 |  | 6,033 |  |
| 2029 and thereafter |  | 10,265 |  |
| Total lines of credit and term loans |  | $ | 167,212 |  |
  (was, 2024-02-02, similarity 0.8955):
[0001375365-24-000011:note_history:21]
| Remainder of 2024 |  | $ | 254,997 |  |
| 2025 |  | 42,621 |  |
| 2026 |  | 42,621 |  |
| 2027 |  | 18,517 |  |
| 2028 |  | 6,246 |  |
| 2029 and thereafter |  | 10,627 |  |
| Total short-term and long-term debt |  | $ | 375,629 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:22]
The Company is in compliance with all the covenants for the outstanding loans.
Convertible Notes
2029 Convertible Notes
  (was, 2024-02-02, similarity 0.7565):
[0001375365-24-000011:note_history:22]
The Company is in compliance with all the covenants for the outstanding debt.

- added (2024-05-06):
[0001375365-24-000022:note_history:23]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of Convertible Notes. The Company received net proceeds from the offering of approximately $1,695.8 million. The Company used approximately $142.1 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. The Convertible Notes will mature on March 1, 2029.

- added (2024-05-06):
[0001375365-24-000022:note_history:24]
The Convertible Notes do not bear regular interest, and the principal amount of the Convertible Notes do not accrete. The Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election, at an initial conversion rate of 0.7455 shares of common stock per $1,000 principal amount of Convertible Notes, which is equivalent to an initial conversion price of  $1,341.38 per share of common stock. The conversion rate is subject to customary adjustments for certain events as described in the indenture governing the Convertible Notes (the "Indenture"). Special interest and additional interest will accrue on the Convertible Notes in the circumstances and at the rates described in the Indenture. The debt issuance costs are amortized to interest expense. The Convertible Notes do not contain financial maintenance covenants.

- added (2024-05-06):
[0001375365-24-000022:note_history:25]
Holders may convert their Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2024, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date.

- added (2024-05-06):
[0001375365-24-000022:note_history:26]
If the Company undergoes a fundamental change (as defined in the Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the Convertible Notes to be repurchased, plus any accrued and unpaid special interest and additional interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their Convertible Notes in connection with such corporate event or during the relevant redemption period.

- added (2024-05-06):
[0001375365-24-000022:note_history:27]
The Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid special and additional interest, if any, to, but excluding, the redemption date.

- added (2024-05-06):
[0001375365-24-000022:note_history:28]
The Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the Convertible Notes. The Convertible Notes were not eligible for conversion as of March 31, 2024. No sinking fund is provided for the Convertible Notes.

- added (2024-05-06):
[0001375365-24-000022:note_history:29]
The Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness; effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2024, none of the conditions permitting the holders of the Convertible Notes to convert their notes early had been met. Therefore, the Convertible Notes are classified as long-term.

- added (2024-05-06):
[0001375365-24-000022:note_history:30]
The Company accounted for the issuance of the Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

- added (2024-05-06):
[0001375365-24-000022:note_history:31]
The carrying value of the Convertible Notes, net of unamortized issuance costs of $28.7 million, was $1,696.3 million as of March 31, 2024. Interest expense related to the amortization of debt issuance costs was $0.5 million for the quarter ended March 31, 2024. The effective interest rate is 0.34%.

- added (2024-05-06):
[0001375365-24-000022:note_history:32]
Capped Calls

- added (2024-05-06):
[0001375365-24-000022:note_history:33]
In connection with the issuance of the Convertible Notes, the Company entered into privately negotiated capped call transactions (collectively, the “Capped Call Transactions”) with certain financial institutions (the “Capped Call Counterparties”). The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap.

- added (2024-05-06):
[0001375365-24-000022:note_history:34]
The Capped Call Transactions have an initial strike price of  $1,341.38 per share, subject to certain adjustments, which corresponds to the initial conversion price of the Convertible Notes. The cap price of the Capped Call Transactions was initially $1,951.04 per share of common stock, representing a premium of approximately 100% above the last reported sale price of $975.52 per share of common stock on February 22, 2024, and is subject to certain adjustments under the terms of the Capped Call Transactions.
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the Convertible Notes. As these transactions meet certain accounting criteria, the  Capped Call Transactions of $142.1 million are recorded in stockholders’ equity and are not accounted for as derivatives. The Capped Call Transactions will not be remeasured as long as they continue to meet the conditions for equity classification. The Convertible Notes and the Capped Call Transactions will be integrated for tax purposes. The accounting impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the Convertible Notes.

- removed (2024-05-06):
[0001375365-24-000011:note_history:35]
|  | December 31, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | 20,000 |  |  | — |  |
| Cathay Bank Line of Credit | 131,583 |  |  | 131,583 |  |
| 2023 CTBC Credit Lines | 36,873 |  |  | — |  |
| HSBC Bank Credit Facility | 29,704 |  |  | — |  |
| Mega Bank Credit Facility | 15,526 |  |  | — |  |
| Total line of credit | 233,686 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 22,911 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,579 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,991 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 28,463 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,419 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 35,580 |  |  | 38,668 |  |
| Total term loans | 141,943 |  |  | 158,719 |  |
| Total debt | 375,629 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 276,307 |  |  | 170,123 |  |
| Debt, non-current | $ | 99,322 |  |  | $ | 120,179 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:36]
Short-term and long-term loan obligations as of March 31, 2024 and June 30, 2023 consisted of the following (in thousands):
  (was, 2024-02-02, similarity 0.9258):
[0001375365-24-000011:note_history:36]
Short-term and long-term debt obligations as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands):

- added (2024-05-06):
[0001375365-24-000022:note_history:37]
|  | March 31, |  | June 30, |
|  | 2024 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2024 CTBC Credit Lines | 24,994 |  |  | — |  |
| Chang Hwa Bank Credit Facility | — |  |  | — |  |
| 2023 HSBC Bank Credit Lines | 8,217 |  |  | — |  |
| 2022 E.SUN Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | 7,186 |  |  | — |  |
| Total line of credit | 40,397 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 20,178 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 33,029 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,493 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 24,995 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 13,877 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 31,243 |  |  | 38,668 |  |
| Total term loans | 126,815 |  |  | 158,719 |  |
| Total lines of credit and term loans | 167,212 |  |  | 290,302 |  |
| Lines of credit and current portion of term loans | 81,566 |  |  | 170,123 |  |
| Term loans, non-current | $ | 85,646 |  |  | $ | 120,179 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:38]
Available borrowings and interest rates as of March 31, 2024 and June 30, 2023 consisted of the following (in thousands except for percentages):
  (was, 2024-02-02, similarity 0.9668):
[0001375365-24-000011:note_history:38]
Available borrowings and interest rates as of December 31, 2023 and June 30, 2023 consisted of the following (in thousands except for percentages):

- changed (2024-05-06):
[0001375365-24-000022:note_history:39]
|  | March 31, 2024 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 7.06% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  |  | 7.50% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2024 CTBC Credit Lines | $ | 160,006 |  |  | 1.94% - 6.26% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.30% |  | $ | 20,000 |  |  | 6.58% |
| 2023 HSBC Bank Credit Lines | $ | 41,783 |  |  | 2.03% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 12,814 |  |  | 1.90% - 1.91% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.68% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.53% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.87% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.52% - 1.72% |  | $ | — |  |  | 1.40% - 1.60% |
  (was, 2024-02-02, similarity 0.9871):
[0001375365-24-000011:note_history:39]
|  | December 31, 2023 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 6.82% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | — |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 417 |  |  | 7.36% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2023 CTBC Credit Line | $ | 68,127 |  |  | 1.96% - 6.52% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.38% |  | $ | 20,000 |  |  | 6.58% |
| HSBC Bank Credit Facility | $ | 20,296 |  |  | 1.90% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 4,474 |  |  | 1.90% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.55% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.20% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.40% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.75% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.75% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.40% - 1.60% |  | $ | — |  |  | 1.40% - 1.60% |

- removed (2024-05-06):
[0001375365-24-000011:note_history:40]
|  | December 31, |  | June 30, |
|  | 2023 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | 20,000 |  |  | — |  |
| Cathay Bank Line of Credit | 131,583 |  |  | 131,583 |  |
| 2023 CTBC Credit Lines | 36,873 |  |  | — |  |
| HSBC Bank Credit Facility | 29,704 |  |  | — |  |
| Mega Bank Credit Facility | 15,526 |  |  | — |  |
| Total line of credit | 233,686 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 22,911 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 35,579 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,991 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 28,463 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 15,419 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 35,580 |  |  | 38,668 |  |
| Total term loans | 141,943 |  |  | 158,719 |  |
| Total debt | 375,629 |  |  | 290,302 |  |
| Short-term debt and current portion of long-term debt | 276,307 |  |  | 170,123 |  |
| Debt, non-current | $ | 99,322 |  |  | $ | 120,179 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:41]
Principal payments on lines of credit and term loans are due as follows (in thousands):
  (was, 2024-02-02, similarity 0.8111):
[0001375365-24-000011:note_history:41]
Principal payments on short-term and long-term obligations are due as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:42]
| Remainder of 2024 |  | $ | 50,690 |  |
| 2025 |  | 41,169 |  |
| 2026 |  | 41,169 |  |
| 2027 |  | 17,886 |  |
| 2028 |  | 6,033 |  |
| 2029 and thereafter |  | 10,265 |  |
| Total lines of credit and term loans |  | $ | 167,212 |  |
  (was, 2024-02-02, similarity 0.8955):
[0001375365-24-000011:note_history:42]
| Remainder of 2024 |  | $ | 254,997 |  |
| 2025 |  | 42,621 |  |
| 2026 |  | 42,621 |  |
| 2027 |  | 18,517 |  |
| 2028 |  | 6,246 |  |
| 2029 and thereafter |  | 10,627 |  |
| Total short-term and long-term debt |  | $ | 375,629 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:43]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2024. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.
  (was, 2024-02-02, similarity 0.9955):
[0001375365-24-000011:note_history:43]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of December 31, 2023. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

- changed (2024-05-06):
[0001375365-24-000022:note_history:44]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.2% and 96.3% of the chassis included in the products sold by the Company during the three months ended March 31, 2024 and 2023, respectively, and 92.7% and 93.0% of the chassis included in the products sold by the Company during the nine months ended March 31, 2024 and 2023, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.
  (was, 2024-02-02, similarity 0.9682):
[0001375365-24-000011:note_history:44]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 87.2% and 95.5% of the chassis included in the products sold by the Company during the three months ended December 31, 2023 and 2022, respectively, and 86.3% and 91.8% of the chassis included in the products sold by the Company during the six months ended December 31, 2023 and 2022, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

- changed (2024-05-06):
[0001375365-24-000022:note_history:45]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on March 31, 2024 were $113.7 million and $48.4 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.
  (was, 2024-02-02, similarity 0.9945):
[0001375365-24-000011:note_history:45]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on December 31, 2023 were $49.1 million and $37.5 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

- changed (2024-05-06):
[0001375365-24-000022:note_history:46]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on March 31, 2024 were $147.7 million and $52.1 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.
  (was, 2024-02-02, similarity 0.9921):
[0001375365-24-000011:note_history:46]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on December 31, 2023 were $121.6 million and $49.9 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

- added (2024-05-06):
[0001375365-24-000022:note_history:47]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $5.1 million and $2.0 million as of March 31, 2024 and June 30, 2023, respectively. The Company does not believe that the equity investment carrying value is impaired as of March 31, 2024 and June 30, 2023. No impairment charge was recorded for the three and nine months ended March 31, 2024 and 2023.

- changed (2024-05-06):
[0001375365-24-000022:note_history:48]
The Company sold products worth $4.3 million and $6.4 million to the Corporate Venture during the three months ended March 31, 2024 and 2023, respectively, and $16.5 million and $23.6 million to the Corporate Venture during the nine months ended March 31, 2024 and 2023, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2024 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.8 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of March 31, 2024 and June 30, 2023, respectively.
  (was, 2024-02-02, similarity 0.9461):
[0001375365-24-000011:note_history:48]
The Company sold products worth $11.4 million and $6.0 million to the Corporate Venture during the three months ended December 31, 2023 and 2022, respectively, and $12.2 million and $17.3 million to the Corporate Venture during the six months ended December 31, 2023 and 2022, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of December 31, 2023 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $3.5 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of December 31, 2023 and June 30, 2023, respectively.

- changed (2024-05-06):
[0001375365-24-000022:note_history:49]
The Company had the following balances related to transactions with its related parties as of March 31, 2024 and June 30, 2023 (in thousands):
  (was, 2024-02-02, similarity 0.9663):
[0001375365-24-000011:note_history:49]
The Company had the following balances related to transactions with its related parties as of December 31, 2023 and June 30, 2023 (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:50]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | March 31, 2024 |  | June 30, 2023 |  | March 31, 2024 |  | June 30, 2023 |  | March 31, 2024 |  | June 30, 2023 |  |  |  | March 31, 2024 |  | June 30, 2023 |
| Accounts receivable | $ | 3 |  |  | $ | 2 |  |  | $ | 268 |  |  | $ | 3,528 |  |  | $ | 839 |  |  | $ | 1,943 |  |  |  |  | $ | 1,110 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 1,819 |  |  | $ | 2,841 |  |  | $ | 28,430 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 30,249 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 54,191 |  |  | $ | 35,711 |  |  | $ | 48,391 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 102,582 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 692 |  |  | $ | 1,230 |  |  | $ | 18,106 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,798 |  |  | $ | 14,017 |  |
  (was, 2024-02-02, similarity 0.9672):
[0001375365-24-000011:note_history:50]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  |  |  | December 31, 2023 |  | June 30, 2023 |
| Accounts receivable | $ | 2 |  |  | $ | 2 |  |  | $ | 289 |  |  | $ | 3,528 |  |  | $ | 3,568 |  |  | $ | 1,943 |  |  |  |  | $ | 3,859 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,270 |  |  | $ | 2,841 |  |  | $ | 32,023 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 34,293 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 46,649 |  |  | $ | 35,711 |  |  | $ | 55,051 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 101,700 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 1,074 |  |  | $ | 1,230 |  |  | $ | 17,435 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,509 |  |  | $ | 14,017 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:51]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2024 and 2023, are as follows (in thousands):
  (was, 2024-02-02, similarity 0.9695):
[0001375365-24-000011:note_history:51]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2023 and 2022, are as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:52]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended March 31, |  | Three months ended March 31, |  | Three months ended March 31, |  |  | Three months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Net sales | $ | 2 |  |  | $ | 2 |  |  | $ | 21,501 |  |  | $ | 2,826 |  |  | $ | 4,301 |  |  | $ | 6,360 |  |  |  |  | $ | 25,804 |  |  | $ | 9,188 |  |
| Purchases - inventory | $ | 65,933 |  |  | $ | 33,637 |  |  | $ | 64,464 |  |  | $ | 54,095 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 130,397 |  |  | $ | 87,732 |  |
| Purchases - other miscellaneous items | $ | 4,401 |  |  | $ | 2,329 |  |  | $ | 343 |  |  | $ | 541 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,744 |  |  | $ | 2,870 |  |
  (was, 2024-02-02, similarity 0.8357):
[0001375365-24-000011:note_history:52]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 6 |  |  | $ | 3 |  |  | $ | 20,998 |  |  | $ | 27,872 |  |  | $ | 12,173 |  |  | $ | 17,251 |  |  |  |  | $ | 33,177 |  |  | $ | 45,126 |  |
| Purchases - inventory | $ | 97,199 |  |  | $ | 94,562 |  |  | $ | 128,353 |  |  | $ | 100,717 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 225,552 |  |  | $ | 195,279 |  |
| Purchases - other miscellaneous items | $ | 8,215 |  |  | $ | 7,526 |  |  | $ | 749 |  |  | $ | 537 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 8,964 |  |  | $ | 8,063 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:53]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2024 and 2023, are as follows (in thousands):
  (was, 2024-02-02, similarity 0.9521):
[0001375365-24-000011:note_history:53]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:54]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Nine months ended March 31, |  | Nine months ended March 31, |  | Nine months ended March 31, |  |  | Nine months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Net sales | $ | 8 |  |  | $ | 6 |  |  | $ | 42,498 |  |  | $ | 30,699 |  |  | $ | 16,474 |  |  | $ | 23,611 |  |  |  |  | $ | 58,980 |  |  | $ | 54,316 |  |
| Purchases - inventory | $ | 163,131 |  |  | $ | 128,198 |  |  | $ | 192,817 |  |  | $ | 154,812 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 355,948 |  |  | $ | 283,010 |  |
| Purchases - other miscellaneous items | $ | 12,616 |  |  | $ | 9,855 |  |  | $ | 1,092 |  |  | $ | 1,078 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 13,708 |  |  | $ | 10,933 |  |
  (was, 2024-02-02, similarity 0.8026):
[0001375365-24-000011:note_history:54]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 4 |  |  | $ | 2 |  |  | $ | 4,392 |  |  | $ | 14,113 |  |  | $ | 11,385 |  |  | $ | 5,958 |  |  |  |  | $ | 15,781 |  |  | $ | 20,073 |  |
| Purchases - inventory | $ | 50,586 |  |  | $ | 46,715 |  |  | $ | 61,859 |  |  | $ | 52,028 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 112,445 |  |  | $ | 98,743 |  |
| Purchases - other miscellaneous items | $ | 3,456 |  |  | $ | 2,763 |  |  | $ | 332 |  |  | $ | 279 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 3,788 |  |  | $ | 3,042 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:55]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2024 and 2023, are as follows (in thousands):
  (was, 2024-02-02, similarity 0.9548):
[0001375365-24-000011:note_history:55]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:56]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Nine months ended March 31, |  | Nine months ended March 31, |  | Nine months ended March 31, |  |  | Nine months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 3,260 |  |  | $ | 293 |  |  | $ | 1,104 |  |  | $ | 6,074 |  |  |  |  | $ | 4,363 |  |  | $ | 6,367 |  |
| Changes in other receivable | $ | 1,022 |  |  | $ | 627 |  |  | $ | (3,539) |  |  | $ | (9,200) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (2,517) |  |  | $ | (8,573) |  |
| Changes in accounts payable | $ | 18,480 |  |  | $ | (14,094) |  |  | $ | (5,032) |  |  | $ | 2,852 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 13,448 |  |  | $ | (11,242) |  |
| Changes in accrued liabilities | $ | (538) |  |  | $ | (1,734) |  |  | $ | 5,319 |  |  | $ | 1,410 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,781 |  |  | $ | (324) |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (178) |  |  | $ | (241) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (178) |  |  | $ | (241) |  |
| Purchases of property, plant and equipment | $ | 8,935 |  |  | $ | 6,129 |  |  | $ | 197 |  |  | $ | 196 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 9,132 |  |  | $ | 6,325 |  |
| Unpaid property, plant and equipment | $ | 1,492 |  |  | $ | 1,369 |  |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 1,492 |  |  | $ | 1,391 |  |
  (was, 2024-02-02, similarity 0.6847):
[0001375365-24-000011:note_history:56]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Changes in accounts receivable | $ | — |  |  | $ | — |  |  | $ | 3,239 |  |  | $ | 137 |  |  | $ | (1,625) |  |  | $ | 3,041 |  |  |  |  | $ | 1,614 |  |  | $ | 3,178 |  |
| Changes in other receivable | $ | 571 |  |  | $ | 1,364 |  |  | $ | (7,132) |  |  | $ | (24,289) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (6,561) |  |  | $ | (22,925) |  |
| Changes in accounts payable | $ | 10,938 |  |  | $ | (3,589) |  |  | $ | 1,628 |  |  | $ | 4,340 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 12,566 |  |  | $ | 751 |  |
| Changes in accrued liabilities | $ | (156) |  |  | $ | (2,009) |  |  | $ | 4,648 |  |  | $ | 2,860 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,492 |  |  | $ | 851 |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | (168) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (152) |  |  | $ | (168) |  |
| Purchases of property, plant and equipment | $ | 4,460 |  |  | $ | 4,366 |  |  | $ | 68 |  |  | $ | 148 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,528 |  |  | $ | 4,514 |  |
| Unpaid property, plant and equipment | $ | 2,570 |  |  | $ | 1,764 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 2,577 |  |  | $ | 1,764 |  |

- removed (2024-05-06):
[0001375365-24-000011:note_history:57]
The Company recorded a deferred gain related to the contribution of certain technology rights. There was no balance in the deferred gain in the consolidated balance sheets as of December 31, 2023 and June 30, 2023.

- removed (2024-05-06):
[0001375365-24-000011:note_history:58]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. In June 2020, the third-party parent company that controls the Corporate Venture was placed on a U.S. government export control list, along with several of such third-party parent’s related entities and a separate listing for one of its subsidiaries. The Corporate Venture is not itself a restricted party. The Company has concluded that the Corporate Venture is in compliance with the new restrictions. The Company does not believe that the equity investment carrying value is impacted as of December 31, 2023. No impairment charge was recorded for the three and six months ended December 31, 2023 or 2022.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:59]
The Company had the following balances related to transactions with its related parties as of March 31, 2024 and June 30, 2023 (in thousands):
  (was, 2024-02-02, similarity 0.9663):
[0001375365-24-000011:note_history:59]
The Company had the following balances related to transactions with its related parties as of December 31, 2023 and June 30, 2023 (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:60]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | March 31, 2024 |  | June 30, 2023 |  | March 31, 2024 |  | June 30, 2023 |  | March 31, 2024 |  | June 30, 2023 |  |  |  | March 31, 2024 |  | June 30, 2023 |
| Accounts receivable | $ | 3 |  |  | $ | 2 |  |  | $ | 268 |  |  | $ | 3,528 |  |  | $ | 839 |  |  | $ | 1,943 |  |  |  |  | $ | 1,110 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 1,819 |  |  | $ | 2,841 |  |  | $ | 28,430 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 30,249 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 54,191 |  |  | $ | 35,711 |  |  | $ | 48,391 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 102,582 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 692 |  |  | $ | 1,230 |  |  | $ | 18,106 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,798 |  |  | $ | 14,017 |  |
  (was, 2024-02-02, similarity 0.9672):
[0001375365-24-000011:note_history:60]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  | December 31, 2023 |  | June 30, 2023 |  |  |  | December 31, 2023 |  | June 30, 2023 |
| Accounts receivable | $ | 2 |  |  | $ | 2 |  |  | $ | 289 |  |  | $ | 3,528 |  |  | $ | 3,568 |  |  | $ | 1,943 |  |  |  |  | $ | 3,859 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 2,270 |  |  | $ | 2,841 |  |  | $ | 32,023 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 34,293 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 46,649 |  |  | $ | 35,711 |  |  | $ | 55,051 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 101,700 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 1,074 |  |  | $ | 1,230 |  |  | $ | 17,435 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,509 |  |  | $ | 14,017 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:61]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2024 and 2023, are as follows (in thousands):
  (was, 2024-02-02, similarity 0.9695):
[0001375365-24-000011:note_history:61]
The Company’s results from transactions with its related parties for each of the three months ended December 31, 2023 and 2022, are as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:62]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended March 31, |  | Three months ended March 31, |  | Three months ended March 31, |  |  | Three months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Net sales | $ | 2 |  |  | $ | 2 |  |  | $ | 21,501 |  |  | $ | 2,826 |  |  | $ | 4,301 |  |  | $ | 6,360 |  |  |  |  | $ | 25,804 |  |  | $ | 9,188 |  |
| Purchases - inventory | $ | 65,933 |  |  | $ | 33,637 |  |  | $ | 64,464 |  |  | $ | 54,095 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 130,397 |  |  | $ | 87,732 |  |
| Purchases - other miscellaneous items | $ | 4,401 |  |  | $ | 2,329 |  |  | $ | 343 |  |  | $ | 541 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,744 |  |  | $ | 2,870 |  |
  (was, 2024-02-02, similarity 0.8357):
[0001375365-24-000011:note_history:62]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 6 |  |  | $ | 3 |  |  | $ | 20,998 |  |  | $ | 27,872 |  |  | $ | 12,173 |  |  | $ | 17,251 |  |  |  |  | $ | 33,177 |  |  | $ | 45,126 |  |
| Purchases - inventory | $ | 97,199 |  |  | $ | 94,562 |  |  | $ | 128,353 |  |  | $ | 100,717 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 225,552 |  |  | $ | 195,279 |  |
| Purchases - other miscellaneous items | $ | 8,215 |  |  | $ | 7,526 |  |  | $ | 749 |  |  | $ | 537 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 8,964 |  |  | $ | 8,063 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:63]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2024 and 2023, are as follows (in thousands):
  (was, 2024-02-02, similarity 0.9521):
[0001375365-24-000011:note_history:63]
The Company’s results from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:64]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Nine months ended March 31, |  | Nine months ended March 31, |  | Nine months ended March 31, |  |  | Nine months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Net sales | $ | 8 |  |  | $ | 6 |  |  | $ | 42,498 |  |  | $ | 30,699 |  |  | $ | 16,474 |  |  | $ | 23,611 |  |  |  |  | $ | 58,980 |  |  | $ | 54,316 |  |
| Purchases - inventory | $ | 163,131 |  |  | $ | 128,198 |  |  | $ | 192,817 |  |  | $ | 154,812 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 355,948 |  |  | $ | 283,010 |  |
| Purchases - other miscellaneous items | $ | 12,616 |  |  | $ | 9,855 |  |  | $ | 1,092 |  |  | $ | 1,078 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 13,708 |  |  | $ | 10,933 |  |
  (was, 2024-02-02, similarity 0.8026):
[0001375365-24-000011:note_history:64]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended December 31, |  | Three months ended December 31, |  | Three months ended December 31, |  |  | Three months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Net sales | $ | 4 |  |  | $ | 2 |  |  | $ | 4,392 |  |  | $ | 14,113 |  |  | $ | 11,385 |  |  | $ | 5,958 |  |  |  |  | $ | 15,781 |  |  | $ | 20,073 |  |
| Purchases - inventory | $ | 50,586 |  |  | $ | 46,715 |  |  | $ | 61,859 |  |  | $ | 52,028 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 112,445 |  |  | $ | 98,743 |  |
| Purchases - other miscellaneous items | $ | 3,456 |  |  | $ | 2,763 |  |  | $ | 332 |  |  | $ | 279 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 3,788 |  |  | $ | 3,042 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:65]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2024 and 2023, are as follows (in thousands):
  (was, 2024-02-02, similarity 0.9548):
[0001375365-24-000011:note_history:65]
The Company’s cash flow impact from transactions with its related parties for each of the six months ended December 31, 2023 and 2022, are as follows (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:66]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Nine months ended March 31, |  | Nine months ended March 31, |  | Nine months ended March 31, |  |  | Nine months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 3,260 |  |  | $ | 293 |  |  | $ | 1,104 |  |  | $ | 6,074 |  |  |  |  | $ | 4,363 |  |  | $ | 6,367 |  |
| Changes in other receivable | $ | 1,022 |  |  | $ | 627 |  |  | $ | (3,539) |  |  | $ | (9,200) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (2,517) |  |  | $ | (8,573) |  |
| Changes in accounts payable | $ | 18,480 |  |  | $ | (14,094) |  |  | $ | (5,032) |  |  | $ | 2,852 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 13,448 |  |  | $ | (11,242) |  |
| Changes in accrued liabilities | $ | (538) |  |  | $ | (1,734) |  |  | $ | 5,319 |  |  | $ | 1,410 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,781 |  |  | $ | (324) |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (178) |  |  | $ | (241) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (178) |  |  | $ | (241) |  |
| Purchases of property, plant and equipment | $ | 8,935 |  |  | $ | 6,129 |  |  | $ | 197 |  |  | $ | 196 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 9,132 |  |  | $ | 6,325 |  |
| Unpaid property, plant and equipment | $ | 1,492 |  |  | $ | 1,369 |  |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 1,492 |  |  | $ | 1,391 |  |
  (was, 2024-02-02, similarity 0.6847):
[0001375365-24-000011:note_history:66]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Six months ended December 31, |  | Six months ended December 31, |  | Six months ended December 31, |  |  | Six months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |
| Changes in accounts receivable | $ | — |  |  | $ | — |  |  | $ | 3,239 |  |  | $ | 137 |  |  | $ | (1,625) |  |  | $ | 3,041 |  |  |  |  | $ | 1,614 |  |  | $ | 3,178 |  |
| Changes in other receivable | $ | 571 |  |  | $ | 1,364 |  |  | $ | (7,132) |  |  | $ | (24,289) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (6,561) |  |  | $ | (22,925) |  |
| Changes in accounts payable | $ | 10,938 |  |  | $ | (3,589) |  |  | $ | 1,628 |  |  | $ | 4,340 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 12,566 |  |  | $ | 751 |  |
| Changes in accrued liabilities | $ | (156) |  |  | $ | (2,009) |  |  | $ | 4,648 |  |  | $ | 2,860 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,492 |  |  | $ | 851 |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (152) |  |  | $ | (168) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (152) |  |  | $ | (168) |  |
| Purchases of property, plant and equipment | $ | 4,460 |  |  | $ | 4,366 |  |  | $ | 68 |  |  | $ | 148 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,528 |  |  | $ | 4,514 |  |
| Unpaid property, plant and equipment | $ | 2,570 |  |  | $ | 1,764 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 2,577 |  |  | $ | 1,764 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:67]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 3,698,446 |  |  | $ | 1,163,723 |  |  | $ | 9,100,616 |  |  | $ | 4,537,710 |  |
| Subsystems and accessories | 151,620 |  |  | 119,573 |  |  | 534,046 |  |  | 400,911 |  |
| Total | $ | 3,850,066 |  |  | $ | 1,283,296 |  |  | $ | 9,634,662 |  |  | $ | 4,938,621 |  |
  (was, 2024-02-02, similarity 0.8717):
[0001375365-24-000011:note_history:67]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 3,435,562 |  |  | $ | 1,660,931 |  |  | $ | 5,402,170 |  |  | $ | 3,373,987 |  |
| Subsystems and accessories | 229,362 |  |  | 142,264 |  |  | 382,426 |  |  | 281,338 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:68]
The following is a summary for the three and nine months ended March 31, 2024 and 2023, of net sales by geographic region (in thousands):
  (was, 2024-02-02, similarity 0.9457):
[0001375365-24-000011:note_history:68]
The following is a summary for the three and six months ended December 31, 2023 and 2022, of net sales by geographic region (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:69]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 2,685,213 |  |  | $ | 785,548 |  |  | $ | 6,910,312 |  |  | $ | 3,172,444 |  |
| Asia | 764,614 |  |  | 214,363 |  |  | 1,646,302 |  |  | 815,098 |  |
| Europe | 297,653 |  |  | 228,531 |  |  | 776,949 |  |  | 776,138 |  |
| Other | 102,586 |  |  | 54,854 |  |  | 301,099 |  |  | 174,941 |  |
| Total | $ | 3,850,066 |  |  | $ | 1,283,296 |  |  | $ | 9,634,662 |  |  | $ | 4,938,621 |  |
  (was, 2024-02-02, similarity 0.8956):
[0001375365-24-000011:note_history:69]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 2,605,585 |  |  | $ | 1,091,391 |  |  | $ | 4,225,099 |  |  | $ | 2,386,895 |  |
| Asia | 656,220 |  |  | 330,711 |  |  | 881,688 |  |  | 600,735 |  |
| Europe | 288,448 |  |  | 312,533 |  |  | 479,296 |  |  | 547,607 |  |
| Other | 114,671 |  |  | 68,560 |  |  | 198,513 |  |  | 120,088 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-06):
[0001375365-24-000022:note_history:70]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 3,698,446 |  |  | $ | 1,163,723 |  |  | $ | 9,100,616 |  |  | $ | 4,537,710 |  |
| Subsystems and accessories | 151,620 |  |  | 119,573 |  |  | 534,046 |  |  | 400,911 |  |
| Total | $ | 3,850,066 |  |  | $ | 1,283,296 |  |  | $ | 9,634,662 |  |  | $ | 4,938,621 |  |
  (was, 2024-02-02, similarity 0.8717):
[0001375365-24-000011:note_history:70]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Server and storage systems | $ | 3,435,562 |  |  | $ | 1,660,931 |  |  | $ | 5,402,170 |  |  | $ | 3,373,987 |  |
| Subsystems and accessories | 229,362 |  |  | 142,264 |  |  | 382,426 |  |  | 281,338 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:71]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2024 and 2023, of net sales by geographic region (in thousands):
  (was, 2024-02-02, similarity 0.8983):
[0001375365-24-000011:note_history:71]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and six months ended December 31, 2023 and 2022, of net sales by geographic region (in thousands):

- changed (2024-05-06):
[0001375365-24-000022:note_history:72]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 2,685,213 |  |  | $ | 785,548 |  |  | $ | 6,910,312 |  |  | $ | 3,172,444 |  |
| Asia | 764,614 |  |  | 214,363 |  |  | 1,646,302 |  |  | 815,098 |  |
| Europe | 297,653 |  |  | 228,531 |  |  | 776,949 |  |  | 776,138 |  |
| Other | 102,586 |  |  | 54,854 |  |  | 301,099 |  |  | 174,941 |  |
| Total | $ | 3,850,066 |  |  | $ | 1,283,296 |  |  | $ | 9,634,662 |  |  | $ | 4,938,621 |  |
  (was, 2024-02-02, similarity 0.8956):
[0001375365-24-000011:note_history:72]
|  | Three Months Ended December 31, |  | Six Months Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States | $ | 2,605,585 |  |  | $ | 1,091,391 |  |  | $ | 4,225,099 |  |  | $ | 2,386,895 |  |
| Asia | 656,220 |  |  | 330,711 |  |  | 881,688 |  |  | 600,735 |  |
| Europe | 288,448 |  |  | 312,533 |  |  | 479,296 |  |  | 547,607 |  |
| Other | 114,671 |  |  | 68,560 |  |  | 198,513 |  |  | 120,088 |  |
| Total | $ | 3,664,924 |  |  | $ | 1,803,195 |  |  | $ | 5,784,596 |  |  | $ | 3,655,325 |  |

- changed (2024-05-06):
[0001375365-24-000022:note_history:73]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $28.9 million and $104.1 million, respectively.
  (was, 2024-02-02, similarity 0.9708):
[0001375365-24-000011:note_history:73]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and six months ended December 31, 2023, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $31.5 million and $75.2 million, respectively.

- changed (2024-05-06):
[0001375365-24-000022:note_history:74]
Deferred revenue increased $132.0 million as of March 31, 2024 as compared to the fiscal year ended June 30, 2023.  This increase was mainly due to deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $24.7 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.
  (was, 2024-02-02, similarity 0.8148):
[0001375365-24-000011:note_history:74]
Deferred revenue increased $79.2 million as of December 31, 2023 as compared to the fiscal year ended June 30, 2023. This increase was mainly due to a $44.3 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

- changed (2024-05-06):
[0001375365-24-000022:note_history:75]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2024 was approximately $436.5 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.
  (was, 2024-02-02, similarity 0.9931):
[0001375365-24-000011:note_history:75]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of December 31, 2023 was approximately $383.6 million. The Company expects to recognize approximately 50% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2024-05-06):
[0001375365-24-000011:note_history:76]
Capitalized Contract Acquisition Costs and Fulfillment Cost

- removed (2024-05-06):
[0001375365-24-000011:note_history:77]
Contract acquisition costs are those incremental costs that the Company incurs to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses paid to Company employees. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. The Company applies the practical expedient to expense incentive bonus costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, the Company applies judgment in the allocation of the incentive bonus cost asset between hardware and service performance obligations and expenses the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to the Company’s condensed consolidated financial statements.

- removed (2024-05-06):
[0001375365-24-000011:note_history:78]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period the services are expected to be provided. Such fulfillment costs are insignificant to the Company’s condensed consolidated financial statements.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-05-06):
[0001375365-24-000022:note_history:79]
Subsequent Events
On April 17, 2024, the Company’s Taiwan subsidiary renewed its credit agreement with Mega Bank, which increases the credit limit from $20 million to $50 million. This new loan is interest bearing, unsecured and the Company is not serving as a guarantor.

- added (2024-05-06):
[0001375365-24-000022:note_history:80]
On April 19, 2024, the Company’s Taiwan subsidiary entered into a credit agreement with E.SUN Bank which is valid from March 14, 2024, to March 14, 2025.  This includes a $60 million Import and Export Trade Facility which is unsecured, interest bearing  and not guaranteed by the Company.

- added (2024-05-06):
[0001375365-24-000022:note_history:81]
On April 26, 2024, the Company’s Taiwan subsidiary entered into a new credit facility with Chang Hwa Bank, updating its previous terms from October 2021 to include a combined credit limit of $20 million and an additional NTD300 million. This facility is unsecured, interest bearing and not guaranteed by the Company.

- added (2024-05-06):
[0001375365-24-000022:note_history:82]
On April 26, 2024, the Company's Taiwan subsidiary entered into a $30 million loan agreement with First Commercial Bank Co., Ltd.  This revolving loan is valid from February 17, 2024, to February 17, 2025, interest bearing and unsecured.  The Company does not act as a guarantor for this loan.

- removed (2024-05-06):
[0001375365-24-000011:note_history:83]
Subsequent Events
On January 26, 2024, the Company entered into an agreement to purchase real estate for an aggregate price of $80.0 million, subject to certain adjustments to be determined at closing. The transaction is expected to close during the third quarter of fiscal 2024. The Company plans to acquire this property using its own cash.

- removed (2024-05-06):
[0001375365-24-000011:note_history:84]
On January 31, 2024, the Company entered into a lease for approximately 260,000 square feet of space in San Jose, California for a term of 79 months. The Company currently intends to use such premises for additional warehouse space. The lease also provides that the Company is required to rent an additional approximate 198,000 square feet of space in the same building after such space becomes available for the remainder of the term stated above. Aggregate payment under the lease for both the primary space and additional space is approximately $0.6 million per month, subject to annual increase.
