# SMCI notes — 0001375365-24-000022


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-24-000022:notes:1]
[same as prior period, unchanged from 0001375365-24-000011:notes:1]

[0001375365-24-000022:notes:2]
[same as prior period, unchanged from 0001375365-24-000011:notes:2]

[0001375365-24-000022:notes:3]
[same as prior period, unchanged from 0001375365-24-000011:notes:3]

[0001375365-24-000022:notes:4]
[same as prior period, unchanged from 0001375365-24-000011:notes:4]

[0001375365-24-000022:notes:5]
The unaudited condensed consolidated financial statements included herein reflect all adjustments, including normal recurring adjustments, which are, in the opinion of management, necessary for a fair presentation of the consolidated financial position, results of operations and cash flows for the periods presented. The consolidated results of operations for the three and nine months ended March 31, 2024 are not necessarily indicative of the results that may be expected for future quarters or for the fiscal year ending June 30, 2024.

[0001375365-24-000022:notes:6]
[same as prior period, unchanged from 0001375365-24-000011:notes:6]

[0001375365-24-000022:notes:7]
[same as prior period, unchanged from 0001375365-24-000011:notes:7]

[0001375365-24-000022:notes:8]
Certain materials used by the Company in the manufacturing of its products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry. Supplier A accounted for 69.8% and supplier B accounted for 5.1% of total purchases for the three months ended March 31, 2024, and supplier A accounted for 26.9% and supplier B accounted for 16.9% of total purchases for the three months ended March 31, 2023. Supplier A accounted for 65.8% and supplier B accounted for 7.1% of total purchases for the nine months ended March 31, 2024, and supplier A accounted for 23.6% and supplier B accounted for 15.8% of total purchases for the nine months ended March 31, 2023. The increase in the concentration of the Company's total purchases from supplier A for 69.8% and 65.8% of total purchases for the three and nine months ended March 31, 2024, respectively, is as a result of the purchase of key components to build its solutions for the Company's customers. Purchases from Ablecom, and Compuware, related parties of the Company (see Part I, Item 1, Note 9, "Related Party Transactions") accounted for a combined 4.0% and 8.3% of total cost of sales for the three months ended March 31, 2024 and 2023, respectively, and a combined 4.4% and 7.0% of total cost of sales for the nine months ended March 31, 2024 and 2023, respectively.

[0001375365-24-000022:notes:9]
[same as prior period, unchanged from 0001375365-24-000011:notes:9]

[0001375365-24-000022:notes:10]
[same as prior period, unchanged from 0001375365-24-000011:notes:10]

[0001375365-24-000022:notes:11]
Customer A accounted for 27.9%, customer E accounted for 18.1% and customer B accounted for 15.4% of accounts receivable, net as of March 31, 2024. Customer A accounted for 22.9% and customer B accounted for 19.3% of accounts receivable, net as of June 30, 2023. These accounts receivable represent a concentration of credit risk to the Company.

[0001375365-24-000022:notes:12]
Customer A accounted for 21.2% and customer B accounted for 16.8% of the net sales for the three months ended March 31, 2024 and customer A accounted for 23.7% of the net sales for the nine months ended March 31, 2024. Customer A accounted for 10.7% of the net sales for the three months ended March 31, 2023, and customer C accounted for 11.8% of the net sales for the nine months ended March 31, 2023.

[0001375365-24-000022:notes:13]
[same as prior period, unchanged from 0001375365-24-000011:notes:13]

[0001375365-24-000022:notes:14]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.

[0001375365-24-000022:notes:15]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The amendments are effective for the Company’s annual periods beginning July 1, 2025, with early adoption permitted, and should be applied either prospectively or retrospectively. The Company is currently evaluating this guidance and the impact it may have on its financial statement disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-24-000022:notes:16]
[same as prior period, unchanged from 0001375365-24-000011:notes:16]

[0001375365-24-000022:notes:17]
[same as prior period, unchanged from 0001375365-24-000011:notes:17]

[0001375365-24-000022:notes:18]
[same as prior period, unchanged from 0001375365-24-000011:notes:18]

[0001375365-24-000022:notes:19]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 3,698,446 |  |  | $ | 1,163,723 |  |  | $ | 9,100,616 |  |  | $ | 4,537,710 |  |
| Subsystems and accessories | 151,620 |  |  | 119,573 |  |  | 534,046 |  |  | 400,911 |  |
| Total | $ | 3,850,066 |  |  | $ | 1,283,296 |  |  | $ | 9,634,662 |  |  | $ | 4,938,621 |  |

[0001375365-24-000022:notes:20]
[same as prior period, unchanged from 0001375365-24-000011:notes:20]

[0001375365-24-000022:notes:21]
International net sales are based on the country and geographic region to which the products were shipped. The following is a summary for the three and nine months ended March 31, 2024 and 2023, of net sales by geographic region (in thousands):

[0001375365-24-000022:notes:22]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States | $ | 2,685,213 |  |  | $ | 785,548 |  |  | $ | 6,910,312 |  |  | $ | 3,172,444 |  |
| Asia | 764,614 |  |  | 214,363 |  |  | 1,646,302 |  |  | 815,098 |  |
| Europe | 297,653 |  |  | 228,531 |  |  | 776,949 |  |  | 776,138 |  |
| Other | 102,586 |  |  | 54,854 |  |  | 301,099 |  |  | 174,941 |  |
| Total | $ | 3,850,066 |  |  | $ | 1,283,296 |  |  | $ | 9,634,662 |  |  | $ | 4,938,621 |  |

[0001375365-24-000022:notes:23]
[same as prior period, unchanged from 0001375365-24-000011:notes:23]

[0001375365-24-000022:notes:24]
[same as prior period, unchanged from 0001375365-24-000011:notes:24]

[0001375365-24-000022:notes:25]
[same as prior period, unchanged from 0001375365-24-000011:notes:25]

[0001375365-24-000022:notes:26]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede the Company’s satisfaction of the associated performance obligations. The Company’s deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of advance consideration received from non-cancellable non-refundable contract liabilities relating to the sale of future products. Revenue recognized during the three and nine months ended March 31, 2024, which was included in the opening deferred revenue balance as of June 30, 2023, of $304.4 million, was $28.9 million and $104.1 million, respectively.

[0001375365-24-000022:notes:27]
Deferred revenue increased $132.0 million as of March 31, 2024 as compared to the fiscal year ended June 30, 2023.  This increase was mainly due to deferral on invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $24.7 million increase in non-cancellable non-refundable advance consideration or cash consideration received from customers which preceded the Company's satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-24-000022:notes:28]
[same as prior period, unchanged from 0001375365-24-000011:notes:28]

[0001375365-24-000022:notes:29]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. The Company applies the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to remaining performance obligations as of March 31, 2024 was approximately $436.5 million. The Company expects to recognize approximately 53% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-24-000022:notes:30]
The following is a summary for the three and nine months ended March 31, 2024 and 2023, of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-24-000022:notes:31]
Net Income Per Common Share
The following table shows the computation of basic and diluted net income per common share for the three and nine months ended March 31, 2024 and 2023 (in thousands, except per share amounts):

[0001375365-24-000022:notes:32]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income - basic | $ | 402,459 |  |  | $ | 85,846 |  |  | $ | 855,422 |  |  | $ | 446,429 |  |
| Convertible notes interest charge, net of tax | 385 |  |  | — |  |  | 385 |  |  | — |  |
| Net income - diluted | $ | 402,844 |  |  | $ | 85,846 |  |  | $ | 855,807 |  |  | $ | 446,429 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 56,478 |  |  | 53,280 |  |  | 54,562 |  |  | 53,011 |  |
| Effect of dilutive convertible notes | 471 |  | — |  |  | 155 |  | — |  |
| Effect of dilutive securities | 4,482 |  |  | 2,953 |  |  | 4,172 |  |  | 2,785 |  |
| Weighted-average shares outstanding - diluted | 61,431 |  |  | 56,233 |  |  | 58,889 |  |  | 55,796 |  |
| Net income per common share - basic | $ | 7.13 |  |  | $ | 1.61 |  |  | $ | 15.68 |  |  | $ | 8.42 |  |
| Net income per common share - diluted | $ | 6.56 |  |  | $ | 1.53 |  |  | $ | 14.53 |  |  | $ | 8.00 |  |

[0001375365-24-000022:notes:33]
For the three and nine months ended March 31, 2024 and 2023, the Company had stock options and restricted stock units ("RSUs") outstanding that could potentially dilute basic earnings per share in the future, but were excluded from the computation of diluted net income per share in the periods presented, as their effect would have been anti-dilutive. The anti-dilutive common share equivalents resulting from outstanding equity awards were 8,804 and 187,358 for the three months ended March 31, 2024 and 2023, respectively, and 310,463 and 235,494 for the nine months ended March 31, 2024 and 2023, respectively.

[0001375365-24-000022:notes:34]
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-24-000022:notes:35]
[same as prior period, unchanged from 0001375365-24-000011:notes:37]

[0001375365-24-000022:notes:36]
[same as prior period, unchanged from 0001375365-24-000011:notes:38]

[0001375365-24-000022:notes:37]
|  | March 31, 2024 |  | June 30, 2023 |
| Cash and cash equivalents | $ | 2,115,476 |  |  | $ | 440,459 |  |
| Restricted cash included in other assets | 506 |  |  | 501 |  |
| Total cash, cash equivalents and restricted cash | $ | 2,115,982 |  |  | $ | 440,960 |  |

[0001375365-24-000022:notes:38]
[same as prior period, unchanged from 0001375365-24-000011:notes:40]

[0001375365-24-000022:notes:39]
|  | March 31, 2024 |  | June 30, 2023 |
| Finished goods | $ | 2,984,698 |  |  | $ | 1,045,177 |  |
| Work in process | 640,525 |  |  | 71,874 |  |
| Purchased parts and raw materials | 499,364 |  |  | 328,513 |  |
| Total inventories | $ | 4,124,587 |  |  | $ | 1,445,564 |  |

[0001375365-24-000022:notes:40]
[same as prior period, unchanged from 0001375365-24-000011:notes:42]

[0001375365-24-000022:notes:41]
|  | March 31, 2024 |  | June 30, 2023 |
| Land | $ | 149,394 |  |  | $ | 86,642 |  |
| Buildings | 163,510 |  |  | 143,496 |  |
| Machinery and equipment | 145,549 |  |  | 130,151 |  |
| Building and leasehold improvements | 65,185 |  |  | 59,634 |  |
| Furniture and fixtures | 40,429 |  |  | 36,303 |  |
| Software | 23,935 |  |  | 23,098 |  |
| Building construction in progress | 6,432 |  |  | 303 |  |
|  | 594,434 |  |  | 479,627 |  |
| Accumulated depreciation and amortization | (208,868) |  |  | (189,387) |  |
| Property, plant and equipment, net | $ | 385,566 |  |  | $ | 290,240 |  |

[0001375365-24-000022:notes:42]
[same as prior period, unchanged from 0001375365-24-000011:notes:44]

[0001375365-24-000022:notes:43]
|  | March 31, 2024 |  | June 30, 2023 |
| Customer deposits | $ | 73,786 |  |  | $ | 16,577 |  |
| Accrued payroll and related expenses | 54,745 |  |  | 53,439 |  |
| Contract manufacturers liabilities | 27,496 |  |  | 23,634 |  |
| Accrued cooperative marketing expenses | 13,536 |  |  | 9,744 |  |
| Accrued warranty costs | 10,028 |  |  | 9,079 |  |
| Operating lease liability | 8,154 |  |  | 7,292 |  |
| Other | 102,625 |  |  | 44,100 |  |
| Total accrued liabilities | $ | 290,370 |  |  | $ | 163,865 |  |

[0001375365-24-000022:notes:44]
[same as prior period, unchanged from 0001375365-24-000011:notes:46]

[0001375365-24-000022:notes:45]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Balance, beginning of the period | $ | 16,616 |  |  | $ | 13,276 |  |  | $ | 14,859 |  |  | $ | 12,136 |  |
| Provision for warranty | 13,176 |  |  | 9,419 |  |  | 36,220 |  |  | 26,969 |  |
| Costs utilized | (12,423) |  |  | (8,100) |  |  | (33,813) |  |  | (25,126) |  |
| Change in estimated liability for pre-existing warranties | 273 |  |  | 377 |  |  | 376 |  |  | 993 |  |
| Balance, end of the period | 17,642 |  |  | 14,972 |  |  | 17,642 |  |  | 14,972 |  |
| Current portion | 10,028 |  |  | 9,704 |  |  | 10,028 |  |  | 9,704 |  |
| Non-current portion | $ | 7,614 |  |  | $ | 5,268 |  |  | $ | 7,614 |  |  | $ | 5,268 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-24-000022:notes:46]
[same as prior period, unchanged from 0001375365-24-000011:notes:48]

[0001375365-24-000022:notes:47]
The Company’s investment in an auction rate security is classified within Level 3 of the fair value hierarchy as the determination of its fair value was not based on observable inputs as of March 31, 2024 and June 30, 2023. The Company is using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities.

[0001375365-24-000022:notes:48]
Financial Instruments Measured on a Recurring Basis

[0001375365-24-000022:notes:49]
The following table sets forth the Company’s financial instruments as of March 31, 2024 and June 30, 2023, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-24-000022:notes:50]
| March 31, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 313 |  |  | $ | — |  |  | $ | — |  |  | $ | 313 |  |
| Certificates of deposit | — |  |  | 489 |  |  | — |  |  | 489 |  |
| Investment in marketable equity security | 2,652 |  |  | — |  |  | — |  |  | 2,652 |  |
| Auction rate security | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |
| Total assets measured at fair value | $ | 2,965 |  |  | $ | 489 |  |  | $ | 1,843 |  |  | $ | 5,297 |  |
| June 30, 2023 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 20,823 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,823 |  |
| Certificates of deposit | — |  |  | 462 |  |  | — |  |  | 462 |  |
| Auction rate security | — |  |  | — |  |  | 1,843 |  |  | 1,843 |  |
| Total assets measured at fair value | $ | 20,823 |  |  | $ | 462 |  |  | $ | 1,843 |  |  | $ | 23,128 |  |

[0001375365-24-000022:notes:51]
(1) $0.1 million and $20.6 million in money market funds are included cash and cash equivalents and $0.2 million and $0.2 million in money market funds are included in restricted cash, non-current in other assets in the condensed consolidated balance sheets as of March 31, 2024 and June 30, 2023, respectively.

[0001375365-24-000022:notes:52]
The carrying amounts reported in the condensed consolidated balance sheets for cash and cash equivalents, accounts receivable, other assets, accounts payable and accrued liabilities approximate their fair values. The investment in marketable equity security is carried at fair value using values available on a public exchange and is based on a Level 1 input. The unrealized gains and losses of the investment is included in earnings. The condensed consolidated statement of operations for the three and nine months ended March 31, 2024, includes an unrealized loss of $1.5 million and $2.3 million, respectively, which have been recorded in Other income, net.

[0001375365-24-000022:notes:53]
On a quarterly basis, the Company also evaluates the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, and current economic conditions. For the three and nine months ended March 31, 2024, the credit losses related to the Company’s investments were not material.

[0001375365-24-000022:notes:54]
There was immaterial movement in the balances of the Company's financial assets measured at fair value on a recurring basis, consisting of investment in an auction rate security, using significant unobservable inputs (Level 3) for the three and nine months ended March 31, 2024 and 2023.

[0001375365-24-000022:notes:55]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in the three and nine months ended March 31, 2024 and 2023.

[0001375365-24-000022:notes:56]
The following is a summary of the Company’s investment in an auction rate security as of March 31, 2024 and June 30, 2023 (in thousands):

[0001375365-24-000022:notes:57]
[same as prior period, unchanged from 0001375365-24-000011:notes:60]

[0001375365-24-000022:notes:58]
No gain or loss was recognized in other comprehensive income for the auction rate security for the three and nine months ended March 31, 2024 and 2023.

[0001375365-24-000022:notes:59]
The Company measures the fair value of outstanding lines of credit and term loans for disclosure purposes on a recurring basis. As of March 31, 2024 and June 30, 2023, total lines of credit and term loans of $167.2 million and $290.3 million, respectively, was reported at amortized cost. This outstanding balance was classified as Level 2 as it was not actively traded. The amortized cost of the outstanding lines of credit and term loans approximates the fair value.

[0001375365-24-000022:notes:60]
Convertible notes

[0001375365-24-000022:notes:61]
The estimated fair value of the Company's 0% convertible senior notes due 2029 (the "Convertible Notes") was $1,911.6 million as of March 31, 2024. The Company measures the fair value of its convertible notes for disclosure purposes on a recurring basis. The estimated fair value of the Convertible Notes was determined through consideration of quoted market prices. The fair value of the Convertible Notes are categorized in Level 2 of the fair value hierarchy.

[0001375365-24-000022:notes:62]
Other Financial Assets - Investments in Non-Marketable Equity Securities

[0001375365-24-000022:notes:63]
The Company's non-marketable equity securities are investments in privately held companies without readily determinable fair values in the amount of $22.6 million and $1.7 million as of March 31, 2024 and June 30, 2023, respectively. The Company accounts for these investments at cost less impairment, if any, plus or minus changes from observable price changes in orderly transactions for the identical or similar investments by the same issuer. During the three and nine months ended March 31, 2024, the Company performed a qualitative assessment and identified impairment indicators. The Company recorded a $0.0 million and $1.8 million impairment during the three and nine months ended March 31, 2024, respectively, in Other income, net on the condensed consolidated statement of operations. The Company did not have any impairment to the carrying values of the non-marketable equity securities during the three and nine months ended March 31, 2023.


## us-gaap:DebtDisclosureTextBlock

[0001375365-24-000022:notes:64]
and Term Loans
Short-term and long-term loan obligations as of March 31, 2024 and June 30, 2023 consisted of the following (in thousands):

[0001375365-24-000022:notes:65]
|  | March 31, |  | June 30, |
|  | 2024 |  | 2023 |
| Line of credit: |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  |  | $ | — |  |
| 2022 Bank of America Credit Facility | — |  |  | — |  |
| Cathay Bank Line of Credit | — |  |  | 131,583 |  |
| 2024 CTBC Credit Lines | 24,994 |  |  | — |  |
| Chang Hwa Bank Credit Facility | — |  |  | — |  |
| 2023 HSBC Bank Credit Lines | 8,217 |  |  | — |  |
| 2022 E.SUN Bank Credit Facility | — |  |  | — |  |
| Mega Bank Credit Facility | 7,186 |  |  | — |  |
| Total line of credit | 40,397 |  |  | 131,583 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 20,178 |  |  | 26,853 |  |
| CTBC Term Loan Facility, due June 4, 2030 | 33,029 |  |  | 38,208 |  |
| 2021 CTBC Credit Lines, due August 15, 2026 | 3,493 |  |  | 4,721 |  |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | 24,995 |  |  | 33,513 |  |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | 13,877 |  |  | 16,756 |  |
| Mega Bank Credit Facility, due September 15, 2026 | 31,243 |  |  | 38,668 |  |
| Total term loans | 126,815 |  |  | 158,719 |  |
| Total lines of credit and term loans | 167,212 |  |  | 290,302 |  |
| Lines of credit and current portion of term loans | 81,566 |  |  | 170,123 |  |
| Term loans, non-current | $ | 85,646 |  |  | $ | 120,179 |  |

[0001375365-24-000022:notes:66]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-24-000022:notes:67]
Available borrowings and interest rates as of March 31, 2024 and June 30, 2023 consisted of the following (in thousands except for percentages):

[0001375365-24-000022:notes:68]
|  | March 31, 2024 |  | June 30, 2023 |
|  | Available borrowings |  | Interest rate |  | Available borrowings |  | Interest rate |
| Line of credit: |  |  |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | 350,000 |  |  | 7.06% |  | $ | 350,000 |  |  | 6.57% |
| 2022 Bank of America Credit Facility | $ | 20,000 |  |  | 6.49% |  | $ | 20,000 |  |  | 3.36% |
| Cathay Bank Line of Credit | $ | 132,000 |  |  | 7.50% |  | $ | 417 |  |  | 7.08% |
| 2022 CTBC Credit Lines | $ | — |  |  | — |  | $ | 105,000 |  |  | 3.33% |
| 2024 CTBC Credit Lines | $ | 160,006 |  |  | 1.94% - 6.26% |  | $ | — |  |  | — |
| Chang Hwa Bank Credit Facility | $ | 20,000 |  |  | 6.30% |  | $ | 20,000 |  |  | 6.58% |
| 2023 HSBC Bank Credit Lines | $ | 41,783 |  |  | 2.03% - 6.37% |  | $ | 50,000 |  |  | 4.50% |
| 2022 E.SUN Bank Credit Facility | $ | 30,000 |  |  | 6.67% |  | $ | 30,000 |  |  | 4.18% |
| Mega Bank Credit Facility | $ | 12,814 |  |  | 1.90% - 1.91% |  | $ | 20,000 |  |  | 2.55% |
| Term loan facilities: |  |  |  |  |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  |  | 1.68% |  | $ | — |  |  | 1.55% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  |  | 1.33% |  | $ | — |  |  | 1.20% |
| 2021 CTBC Credit Lines, due August 15, 2026 | $ | — |  |  | 1.53% |  | $ | — |  |  | 1.40% |
| 2021 E.SUN Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.87% |  | $ | 7,734 |  |  | 1.75% |
| 2022 ESUN Bank Credit Facility, due August 15, 2027 | $ | — |  |  | 1.87% |  | $ | — |  |  | 1.75% |
| Mega Bank Credit Facility, due September 15, 2026 | $ | — |  |  | 1.52% - 1.72% |  | $ | — |  |  | 1.40% - 1.60% |

[0001375365-24-000022:notes:69]
See “Part II. Item 8. Financial Statements and Supplementary Data – Note 7. Short-term and Long-term Debt” of the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2023 for a more complete description of the Company's credit facilities.

[0001375365-24-000022:notes:70]
The Company entered into new agreements during the nine months ended March 31, 2024 with the following terms:

[0001375365-24-000022:notes:71]
CTBC Bank

[0001375365-24-000022:notes:72]
2024 CTBC Bank Credit Lines

[0001375365-24-000022:notes:73]
On February 16, 2024 (the “Effective Date”), the Company's Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank. This agreement (which changed arrangements which had been entered into with CTBC Bank in September 2023), increased the aggregate total borrowings under the various individual credit arrangements with CTBC Bank from $105.0 million to $185.0 million. The credit arrangements under such general agreement now include the previous issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD1,250.0 million and NTD100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line”) and (iv) an import o/a loan line of credit of up to $80.0 million available through August 31, 2024 (the “Incremental Import Line,” and, together with the NTD Short Term Loan/Guarantee Line, the USD Short Term Loan Line, and the Export/Import Line, the “Increased CTBC Credit Lines”). Aggregate borrowings under all the Increased CTBC Credit Lines is subject to a cap of $185.0 million.

[0001375365-24-000022:notes:74]
Interest rates under each of the individual Increased CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the NTD Short Term Loan/Guarantee Line and USD Short Term Loan Line continue to be secured by certain of the Company's Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor of the Incremental Import Line provides for availability until August 31, 2024 with a final drawdown date of October 30, 2024. Such Incremental Import Line, which is reviewed quarterly for cancellation by the CTBC Bank, is also subject to an average usage requirement and fee for retaining the underutilized portion of such line. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, the Company to maintain ownership of all of the capital stock of the Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the Increased CTBC Credit Lines. The Increased CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable.

[0001375365-24-000022:notes:75]
The Company's Taiwan subsidiary intends to use borrowings under the Increased CTBC Credit Lines in connection with financing of eligible accounts receivable and accounts payable (vendor invoices).

[0001375365-24-000022:notes:76]
As of March 31, 2024, the outstanding borrowings under the 2024 CTBC Bank Credit Lines were $25.0 million. The interest rate for these loans were 1.94% - 6.26% per annum as of March 31, 2024.

[0001375365-24-000022:notes:77]
HSBC Bank

[0001375365-24-000022:notes:78]
2023 HSBC Bank Credit Lines

[0001375365-24-000022:notes:79]
On December 7, 2023, the Company's Taiwan subsidiary entered into a new Facility Letter with the Taiwan affiliate of HSBC Bank. The New Facility Letter is substantially identical to the prior Facility Letter entered into with HSBC Bank on February 7, 2023. The New Facility Letter permits borrowings up to a combined aggregate limit of $50 million which may be comprised of borrowings under a New Taiwan Dollar revolving facility with a sub-limit of NTD 300 million (the “NTD Revolver”) and an export/seller facility with a sub-limit of $50 million (the “Export/Seller Facility”, and together with the NTD Revolver, the "HSBC Bank Credit Lines"). Interest under both the NTD Revolver and Export/Seller Facility is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances. Interest payments thereunder are due on a monthly basis, or such other interest period as agreed by HSBC Bank, and principal is repayable on the due date.

[0001375365-24-000022:notes:80]
Amounts due under the New Facility Letter are currently not secured, but subject to HSBC Bank’s right of set-off and right to repayment on demand and call for cash coverage.

[0001375365-24-000022:notes:81]
As of March 31, 2024, the outstanding borrowings under HSBC Bank Credit Lines were $8.2 million. The interest rates for these loans were 2.03% - 6.37% per annum as of March 31, 2024.

[0001375365-24-000022:notes:82]
Principal payments on lines of credit and term loans are due as follows (in thousands):

[0001375365-24-000022:notes:83]
Fiscal Year                                                                                                                                                                                                Principal Payments

[0001375365-24-000022:notes:84]
| Remainder of 2024 |  | $ | 50,690 |  |
| 2025 |  | 41,169 |  |
| 2026 |  | 41,169 |  |
| 2027 |  | 17,886 |  |
| 2028 |  | 6,033 |  |
| 2029 and thereafter |  | 10,265 |  |
| Total lines of credit and term loans |  | $ | 167,212 |  |

[0001375365-24-000022:notes:85]
The Company is in compliance with all the covenants for the outstanding loans.
Convertible Notes
2029 Convertible Notes

[0001375365-24-000022:notes:86]
In February 2024, the Company issued $1,725.0 million aggregate principal amount of Convertible Notes. The Company received net proceeds from the offering of approximately $1,695.8 million. The Company used approximately $142.1 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. The Convertible Notes will mature on March 1, 2029.

[0001375365-24-000022:notes:87]
The Convertible Notes do not bear regular interest, and the principal amount of the Convertible Notes do not accrete. The Convertible Notes are convertible into cash, shares of the Company’s common stock, or a combination of cash and shares of common stock, at the Company’s election, at an initial conversion rate of 0.7455 shares of common stock per $1,000 principal amount of Convertible Notes, which is equivalent to an initial conversion price of  $1,341.38 per share of common stock. The conversion rate is subject to customary adjustments for certain events as described in the indenture governing the Convertible Notes (the "Indenture"). Special interest and additional interest will accrue on the Convertible Notes in the circumstances and at the rates described in the Indenture. The debt issuance costs are amortized to interest expense. The Convertible Notes do not contain financial maintenance covenants.

[0001375365-24-000022:notes:88]
Holders may convert their Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2024, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of Company’s common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock, as described in the Indenture; (4) if the Company calls such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date.

[0001375365-24-000022:notes:89]
If the Company undergoes a fundamental change (as defined in the Indenture), subject to certain conditions, holders may require the Company to repurchase for cash all or any portion of their Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the Convertible Notes to be repurchased, plus any accrued and unpaid special interest and additional interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if the Company issues a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-24-000022:notes:90]
The Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at the Company’s option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid special and additional interest, if any, to, but excluding, the redemption date.

[0001375365-24-000022:notes:91]
The Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the Convertible Notes. The Convertible Notes were not eligible for conversion as of March 31, 2024. No sinking fund is provided for the Convertible Notes.

[0001375365-24-000022:notes:92]
The Convertible Notes are general unsecured obligations of the Company and rank senior in right of payment to all of the Company’s existing and future indebtedness that is expressly subordinated in right of payment to the Convertible Notes; equal in right of payment with all of the Company’s existing and future senior, unsecured indebtedness; effectively subordinated to any of the Company’s existing and future secured indebtedness to the extent of the value of the collateral securing such indebtedness; and structurally subordinated to all existing and future indebtedness and other liabilities, including trade payables, and (to the extent the Company is not a holder thereof) preferred equity if any, of the Company’s current or future subsidiaries. As of March 31, 2024, none of the conditions permitting the holders of the Convertible Notes to convert their notes early had been met. Therefore, the Convertible Notes are classified as long-term.

[0001375365-24-000022:notes:93]
The Company accounted for the issuance of the Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

[0001375365-24-000022:notes:94]
The carrying value of the Convertible Notes, net of unamortized issuance costs of $28.7 million, was $1,696.3 million as of March 31, 2024. Interest expense related to the amortization of debt issuance costs was $0.5 million for the quarter ended March 31, 2024. The effective interest rate is 0.34%.

[0001375365-24-000022:notes:95]
Capped Calls

[0001375365-24-000022:notes:96]
In connection with the issuance of the Convertible Notes, the Company entered into privately negotiated capped call transactions (collectively, the “Capped Call Transactions”) with certain financial institutions (the “Capped Call Counterparties”). The Capped Call Transactions are expected generally to reduce the potential dilution to the Company’s common stock upon conversion of the Convertible Notes and/or offset any potential cash payments the Company is required to make in excess of the principal amount of the Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap.

[0001375365-24-000022:notes:97]
The Capped Call Transactions have an initial strike price of  $1,341.38 per share, subject to certain adjustments, which corresponds to the initial conversion price of the Convertible Notes. The cap price of the Capped Call Transactions was initially $1,951.04 per share of common stock, representing a premium of approximately 100% above the last reported sale price of $975.52 per share of common stock on February 22, 2024, and is subject to certain adjustments under the terms of the Capped Call Transactions.
For accounting purposes, each Capped Call Transaction is a separate transaction, and not part of the terms of the Convertible Notes. As these transactions meet certain accounting criteria, the  Capped Call Transactions of $142.1 million are recorded in stockholders’ equity and are not accounted for as derivatives. The Capped Call Transactions will not be remeasured as long as they continue to meet the conditions for equity classification. The Convertible Notes and the Capped Call Transactions will be integrated for tax purposes. The accounting impact of this tax treatment results in the Capped Call Transactions being deductible with the cost of the Capped Call Transactions qualifying as original issue discount for tax purposes over the term of the Convertible Notes.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-24-000022:notes:98]
Leases
The Company leases offices, warehouses and other premises, vehicles and certain equipment leased under non-cancelable operating leases. Operating lease expense recognized and supplemental cash flow information related to operating leases for the three and nine months ended March 31, 2024 and 2023 were as follows (in thousands):

[0001375365-24-000022:notes:99]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating lease expense (including expense for lease agreements with related parties of $86 and $139 for the three months ended March 31, 2024 and 2023, respectively, and $363 and $422 for the nine months ended March 31, 2024 and 2023, respectively) | $ | 2,538 |  |  | $ | 2,129 |  |  | $ | 7,076 |  |  | $ | 6,354 |  |
| Cash payments for operating leases (including payments to related parties of $75 and $134 for the three months ended March 31, 2024 and 2023, respectively, and $333 and $391 for the nine months ended March 31, 2024 and 2023, respectively) | $ | 2,469 |  |  | $ | 2,146 |  |  | $ | 6,756 |  |  | $ | 6,209 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 22,301 |  |  | $ | 655 |  |  | $ | 24,140 |  |  | $ | 1,679 |  |

[0001375365-24-000022:notes:100]
On January 31, 2024, the Company entered into a lease for approximately 260,000 square feet of space in San Jose, California for a term of 79 months. The Company commenced lease payments and accepted the premises, which it is utilizing as warehouse space, in March 2024. Aggregate payment under the lease is approximately $0.3 million per month, subject to an annual increase of 3%. On February 9, 2024, the Company consummated the purchase of certain real estate for $80.0 million in San Jose, California. Such purchased real estate was previously under lease, leading to the de-recognition of the related ROU asset of $7.9 million and lease liability of $8.3 million.

[0001375365-24-000022:notes:101]
During the three and nine months ended March 31, 2024 and 2023, the Company’s costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Non-lease variable payments expensed in the three and nine months ended March 31, 2024 were $0.6 million and $1.6 million, respectively. Non-lease variable payments expensed in the three and nine months ended March 31, 2023 were $0.5 million and $1.3 million, respectively.

[0001375365-24-000022:notes:102]
As of March 31, 2024, the weighted average remaining lease term for operating leases was 4.8 years and the weighted average discount rate was 5.0%. Maturities of operating lease liabilities under noncancelable operating lease arrangements as of March 31, 2024 were as follows (in thousands):

[0001375365-24-000022:notes:103]
| Fiscal Year: |  | Maturities of operating leases |
| Remainder of 2024 |  | $ | 2,165 |  |
| 2025 |  | 10,692 |  |
| 2026 |  | 7,628 |  |
| 2027 |  | 6,013 |  |
| 2028 |  | 5,001 |  |
| 2029 and beyond |  | 9,139 |  |
| Total future lease payments |  | 40,638 |  |
| Less: Imputed interest |  | (4,215) |  |
| Present value of operating lease liabilities |  | $ | 36,423 |  |

[0001375365-24-000022:notes:104]
The Company has entered into lease agreements with related parties. See Part I, Item 1, Note 9, “Related Party Transactions,” for a further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-24-000022:notes:105]
Related Party Transactions 
The Company has a variety of business relationships with Ablecom and Compuware. Ablecom and Compuware are both Taiwan corporations. Ablecom is one of the Company’s major contract manufacturers; Compuware is both a distributor of the Company’s products and a contract manufacturer for the Company. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, the Company’s President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 36.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director of the Company, collectively owned approximately 10.5% of Ablecom’s capital stock as of March 31, 2024. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, a member of Compuware’s Board of Directors and a holder of a significant equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and the Company does not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

[0001375365-24-000022:notes:106]
Dealings with Ablecom

[0001375365-24-000022:notes:107]
The Company has entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-24-000022:notes:108]
Under these agreements, the Company outsources to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.2% and 96.3% of the chassis included in the products sold by the Company during the three months ended March 31, 2024 and 2023, respectively, and 92.7% and 93.0% of the chassis included in the products sold by the Company during the nine months ended March 31, 2024 and 2023, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Ablecom for the design and engineering services, and further agrees to pay Ablecom for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-24-000022:notes:109]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of materials needed to manufacture the chassis from third parties and the Company provides certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to the Company. For the components purchased from the Company, Ablecom sells the components back to the Company at a price equal to the price at which the Company sold the components to Ablecom. The Company and Ablecom frequently review and negotiate the prices of the chassis the Company purchases from Ablecom. In addition to inventory purchases, the Company also incurs other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-24-000022:notes:110]
The Company’s exposure to financial loss as a result of its involvement with Ablecom is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on March 31, 2024 were $113.7 million and $48.4 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Ablecom on June 30, 2023 were $37.4 million and $23.7 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that the Company incorporates into its products, if Ablecom were to suddenly be unable to manufacture chassis for the Company, the Company’s business could suffer if the Company is unable to quickly qualify substitute suppliers who can supply high-quality chassis to the Company in volume and at acceptable prices.

[0001375365-24-000022:notes:111]
Dealings with Compuware

[0001375365-24-000022:notes:112]
The Company has entered into a distribution agreement with Compuware, under which the Company appointed Compuware as a non-exclusive distributor of the Company’s products in Taiwan, China and Australia. Compuware assumes the responsibility to install the Company’s products at the site of the end customer, if required, and administers customer support in exchange for a discount from the Company’s standard price for its purchases.

[0001375365-24-000022:notes:113]
The Company also has entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space.

[0001375365-24-000022:notes:114]
Under these agreements, the Company outsources to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to the Company’s specifications, and further agrees to build the tools needed to manufacture the products. The Company pays Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. The Company retains full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to the Company. The Company and Compuware frequently review and negotiate the prices of the power supplies the Company purchases from Compuware.

[0001375365-24-000022:notes:115]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for the Company. The Company sells to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to the Company at a purchase price equal to the price at which the Company sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs including overhead and labor. The Company and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products the Company purchases from Compuware. In addition to the inventory purchases, the Company also incurs costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-24-000022:notes:116]
The Company’s exposure to financial loss as a result of its involvement with Compuware is limited to potential losses on its purchase orders in the event of an unforeseen decline in the market price and/or demand of the Company’s products such that the Company incurs a loss on the sale or cannot sell the products. Outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on March 31, 2024 were $147.7 million and $52.1 million, respectively, and outstanding cancellable and non-cancellable purchase orders from the Company to Compuware on June 30, 2023 were $156.2 million and $46.8 million, respectively, effectively representing the exposure to financial loss. The Company does not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-24-000022:notes:117]
Dealings with Investment in a Corporate Venture

[0001375365-24-000022:notes:118]
In October 2016, the Company entered into agreements pursuant to which the Company contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand the Company’s presence in China. The Corporate Venture is 30% owned by the Company and 70% owned by another company in China. The transaction was closed in the third fiscal quarter of 2017 and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-24-000022:notes:119]
The Company monitors the investment for events or circumstances indicative of potential impairment and makes appropriate reductions in carrying values if it determines that an impairment charge is required. The carrying value of the equity investment in the corporate venture was $5.1 million and $2.0 million as of March 31, 2024 and June 30, 2023, respectively. The Company does not believe that the equity investment carrying value is impaired as of March 31, 2024 and June 30, 2023. No impairment charge was recorded for the three and nine months ended March 31, 2024 and 2023.

[0001375365-24-000022:notes:120]
The Company sold products worth $4.3 million and $6.4 million to the Corporate Venture during the three months ended March 31, 2024 and 2023, respectively, and $16.5 million and $23.6 million to the Corporate Venture during the nine months ended March 31, 2024 and 2023, respectively. The Company’s share of intra-entity profits on the products that remained unsold by the Corporate Venture as of March 31, 2024 and June 30, 2023 have been eliminated and have reduced the carrying value of the Company’s investment in the Corporate Venture. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. The Company had $0.8 million and $1.9 million due from the Corporate Venture in accounts receivable, net as of March 31, 2024 and June 30, 2023, respectively.

[0001375365-24-000022:notes:121]
The Company had the following balances related to transactions with its related parties as of March 31, 2024 and June 30, 2023 (in thousands):

[0001375365-24-000022:notes:122]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | March 31, 2024 |  | June 30, 2023 |  | March 31, 2024 |  | June 30, 2023 |  | March 31, 2024 |  | June 30, 2023 |  |  |  | March 31, 2024 |  | June 30, 2023 |
| Accounts receivable | $ | 3 |  |  | $ | 2 |  |  | $ | 268 |  |  | $ | 3,528 |  |  | $ | 839 |  |  | $ | 1,943 |  |  |  |  | $ | 1,110 |  |  | $ | 5,473 |  |
| Other receivable (1) | $ | 1,819 |  |  | $ | 2,841 |  |  | $ | 28,430 |  |  | $ | 24,891 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 30,249 |  |  | $ | 27,732 |  |
| Accounts payable | $ | 54,191 |  |  | $ | 35,711 |  |  | $ | 48,391 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 102,582 |  |  | $ | 89,134 |  |
| Accrued liabilities (2) | $ | 692 |  |  | $ | 1,230 |  |  | $ | 18,106 |  |  | $ | 12,787 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 18,798 |  |  | $ | 14,017 |  |

[0001375365-24-000022:notes:123]
| (1) Other receivables include receivables from vendors included in prepaid and other current assets. |
| (2) Includes current portion of operating lease liabilities included in other current liabilities. |

[0001375365-24-000022:notes:124]
The Company’s results from transactions with its related parties for each of the three months ended March 31, 2024 and 2023, are as follows (in thousands):

[0001375365-24-000022:notes:125]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Three months ended March 31, |  | Three months ended March 31, |  | Three months ended March 31, |  |  | Three months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Net sales | $ | 2 |  |  | $ | 2 |  |  | $ | 21,501 |  |  | $ | 2,826 |  |  | $ | 4,301 |  |  | $ | 6,360 |  |  |  |  | $ | 25,804 |  |  | $ | 9,188 |  |
| Purchases - inventory | $ | 65,933 |  |  | $ | 33,637 |  |  | $ | 64,464 |  |  | $ | 54,095 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 130,397 |  |  | $ | 87,732 |  |
| Purchases - other miscellaneous items | $ | 4,401 |  |  | $ | 2,329 |  |  | $ | 343 |  |  | $ | 541 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,744 |  |  | $ | 2,870 |  |

[0001375365-24-000022:notes:126]
The Company’s results from transactions with its related parties for each of the nine months ended March 31, 2024 and 2023, are as follows (in thousands):

[0001375365-24-000022:notes:127]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Nine months ended March 31, |  | Nine months ended March 31, |  | Nine months ended March 31, |  |  | Nine months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Net sales | $ | 8 |  |  | $ | 6 |  |  | $ | 42,498 |  |  | $ | 30,699 |  |  | $ | 16,474 |  |  | $ | 23,611 |  |  |  |  | $ | 58,980 |  |  | $ | 54,316 |  |
| Purchases - inventory | $ | 163,131 |  |  | $ | 128,198 |  |  | $ | 192,817 |  |  | $ | 154,812 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 355,948 |  |  | $ | 283,010 |  |
| Purchases - other miscellaneous items | $ | 12,616 |  |  | $ | 9,855 |  |  | $ | 1,092 |  |  | $ | 1,078 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 13,708 |  |  | $ | 10,933 |  |

[0001375365-24-000022:notes:128]
The Company’s cash flow impact from transactions with its related parties for each of the nine months ended March 31, 2024 and 2023, are as follows (in thousands):

[0001375365-24-000022:notes:129]
|  | Ablecom |  | Compuware |  | Corporate Venture |  |  | Total |
|  | Nine months ended March 31, |  | Nine months ended March 31, |  | Nine months ended March 31, |  |  | Nine months ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |
| Changes in accounts receivable | $ | (1) |  |  | $ | — |  |  | $ | 3,260 |  |  | $ | 293 |  |  | $ | 1,104 |  |  | $ | 6,074 |  |  |  |  | $ | 4,363 |  |  | $ | 6,367 |  |
| Changes in other receivable | $ | 1,022 |  |  | $ | 627 |  |  | $ | (3,539) |  |  | $ | (9,200) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (2,517) |  |  | $ | (8,573) |  |
| Changes in accounts payable | $ | 18,480 |  |  | $ | (14,094) |  |  | $ | (5,032) |  |  | $ | 2,852 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 13,448 |  |  | $ | (11,242) |  |
| Changes in accrued liabilities | $ | (538) |  |  | $ | (1,734) |  |  | $ | 5,319 |  |  | $ | 1,410 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 4,781 |  |  | $ | (324) |  |
| Changes in other long-term liabilities | $ | — |  |  | $ | — |  |  | $ | (178) |  |  | $ | (241) |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | (178) |  |  | $ | (241) |  |
| Purchases of property, plant and equipment | $ | 8,935 |  |  | $ | 6,129 |  |  | $ | 197 |  |  | $ | 196 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 9,132 |  |  | $ | 6,325 |  |
| Unpaid property, plant and equipment | $ | 1,492 |  |  | $ | 1,369 |  |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 1,492 |  |  | $ | 1,391 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-24-000022:notes:130]
[same as prior period, unchanged from 0001375365-24-000011:notes:119]

[0001375365-24-000022:notes:131]
On June 5, 2020, the stockholders of the Company approved the 2020 Equity and Incentive Compensation Plan (the “Original 2020 Plan”). The maximum number of shares available under the Original 2020 Plan was 5,000,000 plus 1,045,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 7,246,000 shares of common stock remained reserved for outstanding awards issued under the Original 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, the stockholders of the Company approved an amendment and restatement of the Original 2020 Plan which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 2,000,000 shares.

[0001375365-24-000022:notes:132]
On January 22, 2024, the stockholders of the Company approved a further amendment and restatement of the Original 2020 Plan (as amended and restated from time to time, the “2020 Plan”) which, among other things, further increased the number of shares available for award under the 2020 Plan by an additional 1,500,000 shares.

[0001375365-24-000022:notes:133]
[same as prior period, unchanged from 0001375365-24-000011:notes:122]

[0001375365-24-000022:notes:134]
As of March 31, 2024, the Company had 1,668,086 authorized shares available for future issuance under the 2020 Plan.

[0001375365-24-000022:notes:135]
Offerings of Common Stock

[0001375365-24-000022:notes:136]
[same as prior period, unchanged from 0001375365-24-000011:notes:125]

[0001375365-24-000022:notes:137]
[same as prior period, unchanged from 0001375365-24-000011:notes:126]

[0001375365-24-000022:notes:138]
On March 22, 2024, the Company completed a public offering of 2,000,000 shares of the Company's common stock at $875.00 per share. The Company received net proceeds of $1,731.5 million, after deducting underwriting discounts and commissions and offering expenses payable by the Company.

[0001375365-24-000022:notes:139]
[same as prior period, unchanged from 0001375365-24-000011:notes:127]

[0001375365-24-000022:notes:140]
[same as prior period, unchanged from 0001375365-24-000011:notes:128]

[0001375365-24-000022:notes:141]
No shares were repurchased under the share repurchase program during the three and nine months ended March 31, 2024. The share repurchase program was effective until January 31, 2024, at which time the remaining unutilized portion of such program expired.

[0001375365-24-000022:notes:142]
[same as prior period, unchanged from 0001375365-24-000011:notes:130]

[0001375365-24-000022:notes:143]
[same as prior period, unchanged from 0001375365-24-000011:notes:131]

[0001375365-24-000022:notes:144]
[same as prior period, unchanged from 0001375365-24-000011:notes:132]

[0001375365-24-000022:notes:145]
[same as prior period, unchanged from 0001375365-24-000011:notes:133]

[0001375365-24-000022:notes:146]
[same as prior period, unchanged from 0001375365-24-000011:notes:134]

[0001375365-24-000022:notes:147]
[same as prior period, unchanged from 0001375365-24-000011:notes:135]

[0001375365-24-000022:notes:148]
The fair value of stock option grants for the three and nine months ended March 31, 2024 and 2023 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-24-000022:notes:149]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Risk-free interest rate | 4.01% - 4.09% |  | 3.52% |  | 4.01% - 4.78% |  | 2.81% - 4.25% |
| Expected term | 3.00 years - 5.99 years |  | 6.07 years |  | 3.00 years - 5.99 years |  | 6.07 years |
| Dividend yield | —% |  | —% |  | —% |  | —% |
| Volatility | 59.74% - 64.55% |  | 51.61% |  | 56.87% - 64.55% |  | 50.62% - 51.68% |
| Weighted-average fair value of options | $290.08 |  | $41.50 |  | $205.79 |  | $35.06 |

[0001375365-24-000022:notes:150]
The following table shows total stock-based compensation expense included in the condensed consolidated statements of operations for the three and nine months ended March 31, 2024 and 2023 (in thousands):

[0001375365-24-000022:notes:151]
|  | Three Months Ended March 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of sales | $ | 3,221 |  |  | $ | 1,215 |  |  | $ | 12,680 |  |  | $ | 3,585 |  |
| Research and development | 24,856 |  |  | 8,097 |  |  | 86,005 |  |  | 23,549 |  |
| Sales and marketing | 4,993 |  |  | 1,214 |  |  | 14,998 |  |  | 3,471 |  |
| General and administrative | 23,037 |  |  | 3,126 |  |  | 42,864 |  |  | 11,042 |  |
| Stock-based compensation expense before taxes | 56,107 |  |  | 13,652 |  |  | 156,547 |  |  | 41,647 |  |
| Income tax impact | (47,023) |  |  | (3,444) |  |  | (72,641) |  |  | (8,165) |  |
| Stock-based compensation expense, net | $ | 9,084 |  |  | $ | 10,208 |  |  | $ | 83,906 |  |  | $ | 33,482 |  |

[0001375365-24-000022:notes:152]
As of March 31, 2024, $95.9 million of unrecognized compensation cost related to stock options is expected to be recognized over a weighted-average period of 3.25 years and $309.0 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.72 years. As described below, there is no unrecognized compensation cost related to the 2021 CEO Performance Stock Option as of March 31, 2024. Additionally, $36.9 million of unrecognized compensation cost related to the 2023 CEO Performance Stock Option is expected to be recognized over a period of 2.5 years.

[0001375365-24-000022:notes:153]
[same as prior period, unchanged from 0001375365-24-000011:notes:141]

[0001375365-24-000022:notes:154]
[same as prior period, unchanged from 0001375365-24-000011:notes:142]

[0001375365-24-000022:notes:155]
In March 2021, the Company’s Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 1,000,000 shares of common stock to the Company’s CEO (the “2021 CEO Performance Stock Option”). As of March 31, 2024, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:

[0001375365-24-000022:notes:156]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |  |  |
| $4.0 |  | Achieved |  | $45 |  | Achieved (1) |  |  |
| $4.8 |  | Achieved |  | $60 |  | Achieved (2) |  |  |
| $5.8 |  | Achieved |  | $75 |  | Achieved (3) |  |  |
| $6.8 |  | Achieved |  | $95 |  | Achieved (4) |  |  |
| $8.0 |  | Achieved |  | $120 |  | Achieved (5) |  |  |

[0001375365-24-000022:notes:157]
[same as prior period, unchanged from 0001375365-24-000011:notes:146]

[0001375365-24-000022:notes:158]
[same as prior period, unchanged from 0001375365-24-000011:notes:147]

[0001375365-24-000022:notes:159]
[same as prior period, unchanged from 0001375365-24-000011:notes:148]

[0001375365-24-000022:notes:160]
[same as prior period, unchanged from 0001375365-24-000011:notes:149]

[0001375365-24-000022:notes:161]
(5)The vesting of the fifth tranche of 200,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by the Company’s Compensation Committee in February 2024.

[0001375365-24-000022:notes:162]
During the three and nine months ended March 31, 2024, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.0 million and $0.7 million, respectively. During the three and nine months ended March 31, 2023, the Company recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.5 million and $3.8 million, respectively. As of March 31, 2024 and June 30, 2023, the Company had $0.0 million and $0.7 million, respectively, in unrecognized compensation cost related to the 2021 CEO Performance Stock Option.

[0001375365-24-000022:notes:163]
[same as prior period, unchanged from 0001375365-24-000011:notes:153]

[0001375365-24-000022:notes:164]
[same as prior period, unchanged from 0001375365-24-000011:notes:154]

[0001375365-24-000022:notes:165]
The achievement status of the operational and stock price milestones as of March 31, 2024 was as follows:

[0001375365-24-000022:notes:166]
| Annualized Revenue Milestone (in billions)(1) |  | Achievement Status |  | Stock Price Milestone(1) |  | Achievement Status |
| $13.0 |  | Probable |  | $450 |  | Achieved (2) |
| $15.0 |  | Probable |  | $600 |  | Achieved (3) |
| $17.0 |  | Probable |  | $750 |  | Achieved (4) |
| $19.0 |  | Probable |  | $900 |  | Achieved (5) |
| $21.0 |  | Not Probable |  | $1,100 |  | Not met |

[0001375365-24-000022:notes:167]
(1)Under the terms of the 2023 CEO Performance Stock Option, the annualized revenue milestones and stock price milestones set forth in the table above must be achieved by December 31, 2028 and March 31, 2029, respectively.

[0001375365-24-000022:notes:168]
(2)On March 2, 2024, the Compensation Committee certified achievement of the $450 stock price milestone based upon the 60 trading day average stock price from November 29, 2023 through February 26, 2024.

[0001375365-24-000022:notes:169]
(3)On April 1, 2024, the Compensation Committee certified achievement of the $600 stock price milestone based upon the 60 trading day average stock price from December 15, 2023 through March 13, 2024.

[0001375365-24-000022:notes:170]
(4)On April 1, 2024, the Compensation Committee certified achievement of the $750 stock price milestone based upon the 60 trading day average stock price from January 4, 2024 through April 1, 2024.

[0001375365-24-000022:notes:171]
(5)The 60 trading day average stock price from January 31, 2024 through April 25, 2024 was $903.10. Achievement of the $900 stock price milestone has not yet been certified by the Company’s Compensation Committee.

[0001375365-24-000022:notes:172]
During the three and nine months ended March 31, 2024, the Company recognized compensation expense related to the 2023 CEO Performance Stock Option of $16.9 million and $19.4 million, respectively. As of March 31, 2024, the Company had $36.9 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of March 31, 2024 is expected to be recognized over a period of 2.5 years.

[0001375365-24-000022:notes:173]
On the respective grant dates of each of the 2021 CEO Performance Award and the 2023 CEO Performance Award, a Monte Carlo simulation was used to determine for each tranche of each award (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of the Company’s future financial performance, each quarter, the Company will determine, using a Monte Carlo simulation, whether achievement is probable for each operational milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when the Company expects to achieve that operational milestone, or its “expected operational milestone achievement time.” When the Company first determines that an operational milestone has become probable of being achieved, the Company will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). The Company will immediately recognize a catch-up expense for all accumulated expenses from the respective grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, the Company will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-24-000022:notes:174]
The following table summarizes stock option activity during the nine months ended March 31, 2024 under all plans:

[0001375365-24-000022:notes:175]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageRemainingContractualTerm (in Years) |  |  |
| Balance as of June 30, 2023 |  | 3,302,533 |  |  | $ | 40.47 |  |  |  |  |  |
| Granted |  | 953,005 |  |  | $ | 404.50 |  |  |  |  |  |
| Exercised |  | (778,310) |  |  | $ | 32.54 |  |  |  |  |  |
| Forfeited/Cancelled |  | (10,874) |  |  | $ | 129.36 |  |  |  |  |  |
| Balance as of March 31, 2024 |  | 3,466,354 |  |  | $ | 142.08 |  |  | 7.17 |  |  |
| Options vested and exercisable at March 31, 2024 |  | 1,914,265 |  |  | $ | 40.26 |  |  | 5.67 |  |  |

[0001375365-24-000022:notes:176]
[same as prior period, unchanged from 0001375365-24-000011:notes:160]

[0001375365-24-000022:notes:177]
The following table summarizes RSU activity during the nine months ended March 31, 2024 under all plans:

[0001375365-24-000022:notes:178]
|  | Time-Based RSUsOutstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2023 | 2,042,986 |  |  | $ | 55.94 |  |  |  |  |  |  |
| Granted | 955,912 |  |  | $ | 346.51 |  |  |  |  |  |  |
| Released | (802,450) |  |  | $ | 112.25 |  |  |  |  |  |  |
| Forfeited | (66,515) |  |  | $ | 137.91 |  |  |  |  |  |  |
| Balance as of March 31, 2024 | 2,129,933 |  |  | $ | 162.57 |  |  |  |  |  |  |


## smci:SummaryOfOperationalAndStockPriceMilestonesTableTextBlock

[0001375365-24-000022:notes:179]
As of March 31, 2024, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-24-000022:notes:180]
Income Taxes
The Company recorded a benefit for income taxes of $20.0 million for the three months and a provision of $61.7 million for the nine months ended March 31, 2024, respectively. The Company recorded a provision for income taxes of $10.9 million and $79.4 million for the three and nine months ended March 31, 2023, respectively. The effective tax rate was (5.2)% and 6.7% for the three and nine months ended March 31, 2024, respectively, and 11.1% and 15.0% for the three and nine months ended March 31, 2023, respectively. The effective tax rate for both the three and nine months ended March 31, 2024 is lower than that for the three and nine months ended March 31, 2023, primarily due to significant increase in the stock-based compensation tax deduction, and research and development tax credits.

[0001375365-24-000022:notes:181]
The Tax Cuts and Jobs Act of 2017 eliminated the option to deduct research and development ("R&D") expenses in the year incurred and instead requires taxpayers to capitalize R&D expenses, including software development cost, and subsequently amortize such expenses over five years for R&D activities conducted in the United States and over fifteen years for R&D activities conducted outside of the United States beginning in the Company's fiscal year 2023. Although Congress has considered legislation that would defer, modify, and repeal the capitalization and amortization requirement, there is no assurance the provision will be deferred, repealed, or otherwise modified.

[0001375365-24-000022:notes:182]
The Company believes that it has adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than the Company's current position. Accordingly, the Company's provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-24-000022:notes:183]
[same as prior period, unchanged from 0001375365-24-000011:notes:166]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-24-000022:notes:184]
Commitments and Contingencies
Legal proceedings and indemnifications

[0001375365-24-000022:notes:185]
From time to time, the Company has been involved in various legal proceedings arising from the normal course of business activities. The resolution of any such matters have not had a material impact on the Company’s consolidated financial condition, results of operations or liquidity as of March 31, 2024 and any prior periods.

[0001375365-24-000022:notes:186]
The Company has entered into indemnification agreements with its current and former directors and executive officers.

[0001375365-24-000022:notes:187]
Under these agreements, the Company has agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments the Company could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, the Company maintains directors and officers liability insurance coverage to reduce its exposure to such obligations.

[0001375365-24-000022:notes:188]
Purchase Commitments— The Company has agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of March 31, 2024, these remaining noncancelable commitments were $2.9 billion, including $100.4 million for related parties.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-24-000022:notes:189]
[same as prior period, unchanged from 0001375365-24-000011:notes:172]

[0001375365-24-000022:notes:190]
[same as prior period, unchanged from 0001375365-24-000011:notes:173]

[0001375365-24-000022:notes:191]
|  | March 31, |  | June 30, |
|  | 2024 |  | 2023 |
| Long-lived assets: |  |  |  |
| United States | $ | 265,341 |  |  | $ | 183,485 |  |
| Asia | 117,785 |  |  | 104,094 |  |
| Europe | 2,440 |  |  | 2,661 |  |
|  | $ | 385,566 |  |  | $ | 290,240 |  |

[0001375365-24-000022:notes:192]
[same as prior period, unchanged from 0001375365-24-000011:notes:175]


## us-gaap:SubsequentEventsTextBlock

[0001375365-24-000022:notes:193]
Subsequent Events
On April 17, 2024, the Company’s Taiwan subsidiary renewed its credit agreement with Mega Bank, which increases the credit limit from $20 million to $50 million. This new loan is interest bearing, unsecured and the Company is not serving as a guarantor.

[0001375365-24-000022:notes:194]
On April 19, 2024, the Company’s Taiwan subsidiary entered into a credit agreement with E.SUN Bank which is valid from March 14, 2024, to March 14, 2025.  This includes a $60 million Import and Export Trade Facility which is unsecured, interest bearing  and not guaranteed by the Company.

[0001375365-24-000022:notes:195]
On April 26, 2024, the Company’s Taiwan subsidiary entered into a new credit facility with Chang Hwa Bank, updating its previous terms from October 2021 to include a combined credit limit of $20 million and an additional NTD300 million. This facility is unsecured, interest bearing and not guaranteed by the Company.

[0001375365-24-000022:notes:196]
On April 26, 2024, the Company's Taiwan subsidiary entered into a $30 million loan agreement with First Commercial Bank Co., Ltd.  This revolving loan is valid from February 17, 2024, to February 17, 2025, interest bearing and unsecured.  The Company does not act as a guarantor for this loan.
