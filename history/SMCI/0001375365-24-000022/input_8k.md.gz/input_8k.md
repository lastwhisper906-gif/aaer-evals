# SMCI 8-K — 0001375365-24-000021 filed 2024-04-30

## item codes, every 8-K on or before 2024-05-06

- 2024-04-30 0001375365-24-000021 — 2.02, 9.01
- 2024-03-22 0001375365-24-000020 — 1.01, 8.01, 9.01
- 2024-03-15 0001375365-24-000019 — 5.02, 9.01
- 2024-02-28 0001375365-24-000017 — 1.01, 2.03, 3.02, 9.01
- 2024-02-23 0001375365-24-000016 — 8.01, 9.01
- 2024-02-22 0001375365-24-000015 — 1.01, 8.01, 9.01
- 2024-02-20 0001375365-24-000014 — 1.01, 2.03, 9.01
- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2024-05-06

- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-24-000021:8k_2_02:1]
EX-99.1
2
exhibit991_20240331.htm
EX-99.1

[0001375365-24-000021:8k_2_02:2]
Document

[0001375365-24-000021:8k_2_02:3]
Exhibit 99.1

[0001375365-24-000021:8k_2_02:4]
Supermicro Announces Third Quarter Fiscal Year 2024 Financial Results

[0001375365-24-000021:8k_2_02:5]
SAN JOSE, Calif. -- April 30, 2024 (BUSINESS WIRE) -- Super Micro Computer, Inc. (Nasdaq: SMCI), a Total IT Solution Provider for AI, Cloud, Storage and 5G/Edge, today announced financial results for its third quarter of fiscal year 2024 ended March 31, 2024.

[0001375365-24-000021:8k_2_02:6]
Third Quarter Fiscal Year 2024 Highlights

[0001375365-24-000021:8k_2_02:7]
•Net sales of $3.85 billion versus $3.66 billion in the second quarter of fiscal year 2024 and $1.28 billion in the same quarter of last year.

[0001375365-24-000021:8k_2_02:8]
•Gross margin of 15.5% versus 15.4% in the second quarter of fiscal year 2024 and 17.6% in the same quarter of last year.

[0001375365-24-000021:8k_2_02:9]
•Net income of $402 million versus $296 million in the second quarter of fiscal year 2024 and $86 million in the same quarter of last year.

[0001375365-24-000021:8k_2_02:10]
•Diluted net income per common share of $6.56 versus $5.10 in the second quarter of fiscal year 2024 and $1.53 in the same quarter of last year.

[0001375365-24-000021:8k_2_02:11]
•Non-GAAP diluted net income per common share of $6.65 versus $5.59 in the second quarter of fiscal year 2024 and $1.63 in the same quarter of last year.

[0001375365-24-000021:8k_2_02:12]
•Cash flow used in operations for the third quarter of fiscal year 2024 of $1,520 million and capital expenditures of $93 million.

[0001375365-24-000021:8k_2_02:13]
Non-GAAP gross margin for the third quarter of fiscal year 2024 was 15.6% with adjustments for stock-based compensation expenses of $3 million. Non-GAAP diluted net income per common share for the third quarter of fiscal year 2024 was $6.65, with adjustments for stock-based compensation expenses of $9 million, net of the related tax effect of $47 million.

[0001375365-24-000021:8k_2_02:14]
As of March 31, 2024, total cash and cash equivalents was $2,115 million and total bank debt and convertible notes were $1,863 million.

[0001375365-24-000021:8k_2_02:15]
“We had yet another record quarter with fiscal Q3 revenue of $3.85 billion with non-GAAP EPS of $6.65 per share. This year-over-year revenue growth of 200% and year-over-year non-GAAP EPS growth of 308% was well above our industry peers,” said Charles Liang, President and CEO of Supermicro. “Strong demand for AI rack scale PnP solutions, along with our team’s ability to develop innovative DLC designs, enabled us to expand our market leadership in AI infrastructure. As new solutions ramp, including fully production ready DLC, we expect to continue gaining market share. As such, we are raising our fiscal year 2024 revenue outlook from $14.3 to $14.7 billion to a new range of $14.7 to $15.1 billion.”

[0001375365-24-000021:8k_2_02:16]
Business Outlook and Management Commentary

[0001375365-24-000021:8k_2_02:17]
For the fourth quarter of fiscal year 2024 ending June 30, 2024, the Company expects net sales of $5.1 billion to $5.5 billion, GAAP net income per diluted share of $7.20 to $8.05 and non-GAAP net income per diluted share of $7.62 to $8.42. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately -2.9% and 2.6%, respectively, and a fully diluted share count of 64.8 million shares for GAAP and fully diluted share count of 65.3 million shares for non-GAAP. The outlook for fourth quarter of fiscal year 2024 GAAP net income per diluted share includes approximately $30 million in expected stock-based compensation, net of related tax effects of $28 million that are excluded from non-GAAP net income per diluted share.

[0001375365-24-000021:8k_2_02:18]
For fiscal year 2024 ending June 30, 2024, the Company is raising its guidance for revenues from a range of $14.3 billion to $14.7 billion to a range of $14.7 billion to $15.1 billion and establishing guidance for GAAP net income per diluted share of $21.61 to $22.46 and non-GAAP net income per diluted share of $23.29 to $24.09. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 3.6% and 9.2%, respectively, and a fully diluted share count of 61.2 million shares for GAAP and fully diluted share count of 61.8 million shares for non-GAAP. The outlook for fiscal year 2024 GAAP net income per diluted share includes approximately $116 million in expected stock-based compensation, net of related tax effects of $98 million that are excluded from non-GAAP net income per diluted share.

[0001375365-24-000021:8k_2_02:19]
Conference Call and Webcast Information

[0001375365-24-000021:8k_2_02:20]
Supermicro will present a live audio webcast of a conference call to review its third quarter of fiscal year 2024 on Tuesday, April 30, 2024, at 5:00 p.m. ET / 2:00 p.m. PT.

[0001375365-24-000021:8k_2_02:21]
The webcast will be available at https://ir.supermicro.com.

[0001375365-24-000021:8k_2_02:22]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-24-000021:8k_2_02:23]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-24-000021:8k_2_02:24]
Use of Non-GAAP Financial Measures

[0001375365-24-000021:8k_2_02:25]
Non-GAAP gross margin discussed in this press release adds back stock-based compensation expenses. Non-GAAP diluted net income per common share discussed in this press release adds back stock-based compensation expenses and litigation recovery adjusted for the related tax effects. Management presents non-GAAP financial measures because it considers them to be important supplemental measures of performance. Management uses the non-GAAP financial measures for planning purposes, including analysis of the Company's performance against prior periods, the preparation of operating budgets and to determine appropriate levels of operating and capital investments. Management also believes that the non-GAAP financial measures provide additional insight for analysts and investors in evaluating the Company's financial and operational performance. However, these non-GAAP financial measures have limitations as an analytical tool and are not intended to be an alternative to financial measures prepared in accordance with GAAP. A reconciliation of GAAP gross margin to non-GAAP gross margin and from GAAP diluted net income per common share to non-GAAP diluted net income per common share is included in the tables below.

[0001375365-24-000021:8k_2_02:26]
About Super Micro Computer, Inc.

[0001375365-24-000021:8k_2_02:27]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first to market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. We are a Total IT Solutions manufacturer with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enable our development and production, enabling next generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-24-000021:8k_2_02:28]
Supermicro, Server Building Block Solutions, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-24-000021:8k_2_02:29]
Investor Relations Contact

[0001375365-24-000021:8k_2_02:30]
Nicole Noutsios

[0001375365-24-000021:8k_2_02:31]
email: ir@supermicro.com

[0001375365-24-000021:8k_2_02:32]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000021:8k_2_02:33]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-24-000021:8k_2_02:34]
(in thousands)

[0001375365-24-000021:8k_2_02:35]
(unaudited)

[0001375365-24-000021:8k_2_02:36]
|  | March 31, |  | June 30, |
|  | 2024 |  | 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,115,476 |  |  | $ | 440,459 |  |
| Accounts receivable, net of allowance for credit losses | 1,650,153 |  |  | 1,148,259 |  |
| Inventories | 4,124,587 |  |  | 1,445,564 |  |
| Prepaid expenses and other current assets | 173,716 |  |  | 145,144 |  |
| Total current assets | 8,063,932 |  |  | 3,179,426 |  |
| Property, plant and equipment, net | 385,566 |  |  | 290,240 |  |
| Deferred income taxes, net | 330,248 |  |  | 162,654 |  |
| Other assets | 83,035 |  |  | 42,409 |  |
| Total assets | $ | 8,862,781 |  |  | $ | 3,674,729 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,092,445 |  |  | $ | 776,831 |  |
| Accrued liabilities | 290,370 |  |  | 163,865 |  |
| Income taxes payable | 20,021 |  |  | 129,166 |  |
| Short-term debt | 81,566 |  |  | 170,123 |  |
| Deferred revenue | 233,293 |  |  | 134,667 |  |
| Total current liabilities | 1,717,695 |  |  | 1,374,652 |  |
| Deferred revenue, non-current | 203,198 |  |  | 169,781 |  |
| Long-term debt | 85,646 |  |  | 120,179 |  |
| Convertible notes | 1,696,255 |  |  | — |  |
| Other long-term liabilities | 65,831 |  |  | 37,947 |  |
| Total liabilities | 3,768,625 |  |  | 1,702,559 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 2,805,008 |  |  | 538,352 |  |
| Accumulated other comprehensive income | 549 |  |  | 639 |  |
| Retained earnings | 2,288,436 |  |  | 1,433,014 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 5,093,993 |  |  | 1,972,005 |  |
| Noncontrolling interest | 163 |  |  | 165 |  |
| Total stockholders’ equity | 5,094,156 |  |  | 1,972,170 |  |
| Total liabilities and stockholders’ equity | $ | 8,862,781 |  |  | $ | 3,674,729 |  |

[0001375365-24-000021:8k_2_02:37]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000021:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-24-000021:8k_2_02:39]
(in thousands, except per share amounts)

[0001375365-24-000021:8k_2_02:40]
(unaudited)

[0001375365-24-000021:8k_2_02:41]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 3,850,066 |  |  | $ | 1,283,296 |  |  | $ | 9,634,662 |  |  | $ | 4,938,621 |  |
| Cost of sales | 3,252,698 |  |  | 1,056,937 |  |  | 8,119,281 |  |  | 4,027,305 |  |
| Gross profit | 597,368 |  |  | 226,359 |  |  | 1,515,381 |  |  | 911,316 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 116,226 |  |  | 77,515 |  |  | 336,077 |  |  | 222,458 |  |
| Sales and marketing | 49,691 |  |  | 25,312 |  |  | 133,775 |  |  | 83,120 |  |
| General and administrative | 53,137 |  |  | 24,450 |  |  | 123,241 |  |  | 71,351 |  |
| Total operating expenses | 219,054 |  |  | 127,277 |  |  | 593,093 |  |  | 376,929 |  |
| Income from operations | 378,314 |  |  | 99,082 |  |  | 922,288 |  |  | 534,387 |  |
| Other income (expense), net | 10,035 |  |  | (78) |  |  | 8,762 |  |  | 1,641 |  |
| Interest expense | (6,246) |  |  | (1,288) |  |  | (16,240) |  |  | (6,982) |  |
| Income before income tax provision | 382,103 |  |  | 97,716 |  |  | 914,810 |  |  | 529,046 |  |
| Income tax benefit (provision) | 19,983 |  |  | (10,857) |  |  | (61,735) |  |  | (79,364) |  |
| Share of income (loss) from equity investee, net of taxes | 373 |  |  | (1,013) |  |  | 2,347 |  |  | (3,253) |  |
| Net income | $ | 402,459 |  |  | $ | 85,846 |  |  | $ | 855,422 |  |  | $ | 446,429 |  |
| Net income per common share: |  |  |  |  |  |  |  |
| Basic | $ | 7.13 |  |  | $ | 1.61 |  |  | $ | 15.68 |  |  | $ | 8.42 |  |
| Diluted | $ | 6.56 |  |  | $ | 1.53 |  |  | $ | 14.53 |  |  | $ | 8.00 |  |
| Weighted-average shares used in calculation of net income per common share: |  |  |  |  |  |  |  |
| Basic | 56,478 |  |  | 53,280 |  |  | 54,562 |  |  | 53,011 |  |
| Diluted | 61,431 |  |  | 56,233 |  |  | 58,889 |  |  | 55,796 |  |

[0001375365-24-000021:8k_2_02:42]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-24-000021:8k_2_02:43]
|  | Three Months EndedMarch 31, |  | Nine Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of sales | $ | 3,221 |  |  | $ | 1,215 |  |  | $ | 12,680 |  |  | $ | 3,585 |  |
| Research and development | 24,856 |  |  | 8,097 |  |  | 86,005 |  |  | 23,549 |  |
| Sales and marketing | 4,993 |  |  | 1,214 |  |  | 14,998 |  |  | 3,471 |  |
| General and administrative | 23,037 |  |  | 3,126 |  |  | 42,864 |  |  | 11,042 |  |
| Stock-based compensation expense | $ | 56,107 |  |  | $ | 13,652 |  |  | $ | 156,547 |  |  | $ | 41,647 |  |

[0001375365-24-000021:8k_2_02:44]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000021:8k_2_02:45]
SELECTED CASH FLOW INFORMATION

[0001375365-24-000021:8k_2_02:46]
(in thousands)

[0001375365-24-000021:8k_2_02:47]
(unaudited)

[0001375365-24-000021:8k_2_02:48]
|  | Nine Months EndedMarch 31, |
|  | 2024 |  | 2023 |
| Net cash (used in) provided by operating activities | $ | (1,844,158) |  |  | $ | 672,919 |  |
| Net cash used in investing activities | (131,969) |  |  | (28,618) |  |
| Net cash provided by (used in) financing activities | 3,652,783 |  |  | (547,291) |  |
| Effect of exchange rate fluctuations on cash | (1,634) |  |  | (2,269) |  |
| Net increase in cash, cash equivalents and restricted cash | 1,675,022 |  |  | 94,741 |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 440,960 |  |  | 268,559 |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 2,115,982 |  |  | $ | 363,300 |  |

[0001375365-24-000021:8k_2_02:49]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000021:8k_2_02:50]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-24-000021:8k_2_02:51]
(in thousands, except per share amounts)

[0001375365-24-000021:8k_2_02:52]
(unaudited)

[0001375365-24-000021:8k_2_02:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2024 |  |  | March 31, 2023 |  | March 31, 2024 |  | March 31, 2023 |
| GAAP GROSS PROFIT | $ | 597,368 |  |  |  | $ | 226,359 |  |  | $ | 1,515,381 |  |  | $ | 911,316 |  |
| Stock-based compensation | 3,221 |  |  |  | 1,215 |  |  | 12,680 |  |  | 3,585 |  |
| NON-GAAP GROSS PROFIT | $ | 600,589 |  |  |  | $ | 227,574 |  |  | $ | 1,528,061 |  |  | $ | 914,901 |  |
| GAAP GROSS MARGIN | 15.5 | % |  |  | 17.6 | % |  | 15.7 | % |  | 18.5 | % |
| Stock-based compensation | 0.1 | % |  |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| NON-GAAP GROSS MARGIN | 15.6 | % |  |  | 17.7 | % |  | 15.8 | % |  | 18.6 | % |
| GAAP OPERATING EXPENSE | $ | 219,054 |  |  |  | $ | 127,277 |  |  | $ | 593,093 |  |  | $ | 376,929 |  |
| Stock-based compensation | (52,886) |  |  |  | (12,437) |  |  | (143,867) |  |  | (38,062) |  |
| Litigation recovery | — |  |  |  | 1,540 |  |  | — |  |  | 3,770 |  |
| NON-GAAP OPERATING EXPENSE | $ | 166,168 |  |  |  | $ | 116,380 |  |  | $ | 449,226 |  |  | $ | 342,637 |  |
| GAAP INCOME FROM OPERATIONS | $ | 378,314 |  |  |  | $ | 99,082 |  |  | $ | 922,288 |  |  | $ | 534,387 |  |
| Stock-based compensation | 56,107 |  |  |  | 13,652 |  |  | 156,547 |  |  | 41,647 |  |
| Litigation recovery | — |  |  |  | (1,540) |  |  | — |  |  | (3,770) |  |
| NON-GAAP INCOME FROM OPERATIONS | $ | 434,421 |  |  |  | $ | 111,194 |  |  | $ | 1,078,835 |  |  | $ | 572,264 |  |
| GAAP OPERATING MARGIN | 9.8 | % |  |  | 7.7 | % |  | 9.6 | % |  | 10.8 | % |
| Stock-based compensation | 1.5 | % |  |  | 1.1 | % |  | 1.6 | % |  | 0.8 | % |
| Litigation recovery | — | % |  |  | (0.1) | % |  | — | % |  | (0.1) | % |
| NON-GAAP OPERATING MARGIN | 11.3 | % |  |  | 8.7 | % |  | 11.2 | % |  | 11.5 | % |
| GAAP TAX (BENEFIT) EXPENSE | $ | (19,983) |  |  |  | $ | 10,857 |  |  | $ | 61,735 |  |  | $ | 79,364 |  |
| Adjustments to tax provision | 47,023 |  |  |  | 4,433 |  |  | 72,641 |  |  | 11,963 |  |
| NON-GAAP TAX EXPENSE | $ | 27,040 |  |  |  | $ | 15,290 |  |  | $ | 134,376 |  |  | $ | 91,327 |  |
| GAAP NET INCOME | $ | 402,459 |  |  |  | $ | 85,846 |  |  | $ | 855,422 |  |  | $ | 446,429 |  |
| Stock-based compensation | 56,107 |  |  |  | 13,652 |  |  | 156,547 |  |  | 41,647 |  |
| Litigation recovery | — |  |  |  | (1,540) |  |  | — |  |  | (3,770) |  |
| Adjustments to tax provision | (47,023) |  |  |  | (4,433) |  |  | (72,641) |  |  | (11,963) |  |
| NON-GAAP NET INCOME | $ | 411,543 |  |  |  | $ | 93,525 |  |  | $ | 939,328 |  |  | $ | 472,343 |  |
| GAAP NET INCOME - BASIC | $ | 402,459 |  |  |  | $ | 85,846 |  |  | $ | 855,422 |  |  | $ | 446,429 |  |
| Convertible notes interest charge, net of tax | 385 |  |  |  | — |  |  | 385 |  |  | — |  |
| GAAP NET INCOME - DILUTED | $ | 402,844 |  |  |  | $ | 85,846 |  |  | $ | 855,807 |  |  | $ | 446,429 |  |
| NON-GAAP NET INCOME - DILUTED | $ | 411,928 |  |  |  | $ | 93,525 |  |  | $ | 939,713 |  |  | $ | 472,343 |  |
| GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 7.13 |  |  |  | $ | 1.61 |  |  | $ | 15.68 |  |  | $ | 8.42 |  |
| Impact of Non-GAAP adjustments | 0.16 |  |  |  | 0.15 |  |  | 1.54 |  |  | 0.49 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – BASIC | $ | 7.29 |  |  |  | $ | 1.76 |  |  | $ | 17.22 |  |  | $ | 8.91 |  |
| GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 6.56 |  |  |  | $ | 1.53 |  |  | $ | 14.53 |  |  | $ | 8.00 |  |

[0001375365-24-000021:8k_2_02:54]
SUPER MICRO COMPUTER, INC.

[0001375365-24-000021:8k_2_02:55]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-24-000021:8k_2_02:56]
(in thousands, except per share amounts)

[0001375365-24-000021:8k_2_02:57]
(unaudited)

[0001375365-24-000021:8k_2_02:58]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2024 |  |  | March 31, 2023 |  | March 31, 2024 |  | March 31, 2023 |
| Impact of Non-GAAP adjustments | 0.09 |  |  |  | 0.10 |  |  | 1.24 |  |  | 0.29 |  |
| NON-GAAP NET INCOME PER COMMON SHARE – DILUTED | $ | 6.65 |  |  |  | $ | 1.63 |  |  | $ | 15.77 |  |  | $ | 8.29 |  |
| WEIGHTED-AVERAGE SHARES USED IN COMPUTING NET INCOME PER COMMON SHARE |  |  |  |  |  |  |  |  |
| BASIC – GAAP | 56,478 |  |  |  | 53,280 |  |  | 54,562 |  |  | 53,011 |  |
| BASIC – NON-GAAP | 56,478 |  |  |  | 53,280 |  |  | 54,562 |  |  | 53,011 |  |
| DILUTED – GAAP | 61,431 |  |  |  | 56,233 |  |  | 58,889 |  |  | 55,796 |  |
| DILUTED – NON-GAAP | 61,953 |  |  |  | 57,315 |  |  | 59,578 |  |  | 56,966 |  |

[0001375365-24-000021:8k_2_02:59]
Non-GAAP diluted net income per common share for the second quarter of fiscal year 2024 was $5.59, with adjustments for stock-based compensation expenses of $33 million, net of the related tax effects of $10 million.
