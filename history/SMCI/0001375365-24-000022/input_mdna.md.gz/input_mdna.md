# SMCI MD&A — 0001375365-24-000022


## mdna

[0001375365-24-000022:mdna:1]
[same as prior period, unchanged from 0001375365-24-000011:mdna:1]

[0001375365-24-000022:mdna:2]
[same as prior period, unchanged from 0001375365-24-000011:mdna:2]

[0001375365-24-000022:mdna:3]
[same as prior period, unchanged from 0001375365-24-000011:mdna:3]

[0001375365-24-000022:mdna:4]
[same as prior period, unchanged from 0001375365-24-000011:mdna:4]

[0001375365-24-000022:mdna:5]
[same as prior period, unchanged from 0001375365-24-000011:mdna:5]

[0001375365-24-000022:mdna:6]
SMCI | Q3 2024 Form 10-Q | 33

[0001375365-24-000022:mdna:7]
[same as prior period, unchanged from 0001375365-24-000011:mdna:6]

[0001375365-24-000022:mdna:8]
The following is a summary of our financial highlights of the third quarter of fiscal year 2024:

[0001375365-24-000022:mdna:9]
•Net sales increased by 200.0% in the three months ended March 31, 2024 as compared to the three months ended March 31, 2023.

[0001375365-24-000022:mdna:10]
•Gross margin decreased to 15.5% in the three months ended March 31, 2024 from 17.6% in the three months ended March 31, 2023.

[0001375365-24-000022:mdna:11]
•Operating expenses increased by 72.1% as compared to the three months ended March 31, 2023 and were equal to 5.6% and 9.9% of net sales in the three months ended March 31, 2024 and 2023, respectively.

[0001375365-24-000022:mdna:12]
•Effective tax rate decreased to (5.2%) in the three months ended March 31, 2024 from 11.1% in the three months ended March 31, 2023.

[0001375365-24-000022:mdna:13]
•Issued $1,695.8 million of convertible notes and issued 2,000,000 common shares for $1,731.5 million to fund the growth of our business.

[0001375365-24-000022:mdna:14]
[same as prior period, unchanged from 0001375365-24-000011:mdna:13]

[0001375365-24-000022:mdna:15]
[same as prior period, unchanged from 0001375365-24-000011:mdna:14]

[0001375365-24-000022:mdna:16]
[same as prior period, unchanged from 0001375365-24-000011:mdna:15]

[0001375365-24-000022:mdna:17]
SMCI | Q3 2024 Form 10-Q | 34

[0001375365-24-000022:mdna:18]
[same as prior period, unchanged from 0001375365-24-000011:mdna:16]

[0001375365-24-000022:mdna:19]
[same as prior period, unchanged from 0001375365-24-000011:mdna:17]

[0001375365-24-000022:mdna:20]
|  | Three Months EndedMarch 31, |  | Nine Months EndedMarch 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 84.5 | % |  | 82.4 | % |  | 84.3 | % |  | 81.5 | % |
| Gross profit | 15.5 | % |  | 17.6 | % |  | 15.7 | % |  | 18.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 2.9 | % |  | 6.0 | % |  | 3.4 | % |  | 4.5 | % |
| Sales and marketing | 1.3 | % |  | 2.0 | % |  | 1.4 | % |  | 1.7 | % |
| General and administrative | 1.4 | % |  | 1.9 | % |  | 1.3 | % |  | 1.5 | % |
| Total operating expenses | 5.6 | % |  | 9.9 | % |  | 6.1 | % |  | 7.7 | % |
| Income from operations | 9.9 | % |  | 7.7 | % |  | 9.6 | % |  | 10.8 | % |
| Other income, net | 0.3 | % |  | — | % |  | 0.1 | % |  | — | % |
| Interest expense | (0.2) | % |  | (0.1) | % |  | (0.2) | % |  | (0.1) | % |
| Income before income tax provision | 10.0 | % |  | 7.6 | % |  | 9.5 | % |  | 10.7 | % |
| Income tax benefit (provision) | 0.5 | % |  | (0.8) | % |  | (0.6) | % |  | (1.6) | % |
| Share of income (loss) from equity investee, net of taxes | 0.0 | % |  | (0.1) | % |  | 0.0 | % |  | (0.1) | % |
| Net income | 10.5 | % |  | 6.7 | % |  | 8.9 | % |  | 9.0 | % |

[0001375365-24-000022:mdna:21]
[same as prior period, unchanged from 0001375365-24-000011:mdna:19]

[0001375365-24-000022:mdna:22]
[same as prior period, unchanged from 0001375365-24-000011:mdna:20]

[0001375365-24-000022:mdna:23]
[same as prior period, unchanged from 0001375365-24-000011:mdna:21]

[0001375365-24-000022:mdna:24]
The following table presents net sales by product type for the three and nine months ended March 31, 2024 and 2023 (dollars in millions):

[0001375365-24-000022:mdna:25]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Server and storage systems | $ | 3,698.5 |  |  | $ | 1,163.7 |  |  | $ | 2,534.8 |  |  | 217.8 | % |  | $ | 9,100.7 |  |  | $ | 4,537.7 |  |  | $ | 4,563.0 |  |  | 100.6 | % |
| Percentage of total net sales | 96.1 | % |  | 90.7 | % |  |  |  |  |  | 94.5 | % |  | 91.9 | % |  |  |  |  |
| Subsystems and accessories | $ | 151.6 |  |  | $ | 119.6 |  |  | $ | 32.0 |  |  | 26.8 | % |  | $ | 534.0 |  |  | $ | 400.9 |  |  | $ | 133.1 |  |  | 33.2 | % |
| Percentage of total net sales | 3.9 | % |  | 9.3 | % |  |  |  |  |  | 5.5 | % |  | 8.1 | % |  |  |  |  |
| Total net sales | $ | 3,850.1 |  |  | $ | 1,283.3 |  |  | $ | 2,566.8 |  |  | 200.0 | % |  | $ | 9,634.7 |  |  | $ | 4,938.6 |  |  | $ | 4,696.1 |  |  | 95.1 | % |

[0001375365-24-000022:mdna:26]
[same as prior period, unchanged from 0001375365-24-000011:mdna:25]

[0001375365-24-000022:mdna:27]
SMCI | Q3 2024 Form 10-Q | 35

[0001375365-24-000022:mdna:28]
Comparison of Three Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:29]
The period-over-period increase in net sales of our server and storage systems was primarily driven by an increase in the demand from customers for GPU servers, high performance computing (“HPC"), and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of average selling price ("ASP"). We expect net sales and ASPs to continue to increase in the near future, particularly in the United States and Asia, as demand from customers for these solutions continue to increase as a result of adoption of more advanced technologies including but not limited to liquid cooling solutions.

[0001375365-24-000022:mdna:30]
[same as prior period, unchanged from 0001375365-24-000011:mdna:28]

[0001375365-24-000022:mdna:31]
Comparison of Nine Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:32]
The period-over-period increase in net sales of our server and storage systems was primarily driven by an increase in the demand from customers for GPU servers, HPC, and rack-scale solutions which are generally more complex and of higher value, resulting in an increase of ASP. We expect net sales and ASPs to continue to increase in the near future, particularly in the United States and Asia, as demand from customers for these solutions continue to increase as a result of adoption of more advanced technologies including but not limited to liquid cooling solutions.

[0001375365-24-000022:mdna:33]
[same as prior period, unchanged from 0001375365-24-000011:mdna:31]

[0001375365-24-000022:mdna:34]
The following table presents net sales by geographic region for the three and nine months ended March 31, 2024 and 2023 (dollars in millions):

[0001375365-24-000022:mdna:35]
|  | Three Months Ended March 31, |  | Change |  | Change |  | Nine Months Ended March 31, |  | Change |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| United States | $ | 2,685.2 |  |  | $ | 785.5 |  |  | $ | 1,899.7 |  |  | 241.8 | % |  | $ | 6,910.3 |  |  | $ | 3,172.5 |  |  | $ | 3,737.8 |  |  | 117.8 | % |
| Percentage of total net sales | 69.7 | % |  | 61.2 | % |  |  |  |  |  | 71.7 | % |  | 64.2 | % |  |  |  |  |
| Asia | $ | 764.6 |  |  | $ | 214.4 |  |  | $ | 550.2 |  |  | 256.6 | % |  | $ | 1,646.3 |  |  | $ | 815.1 |  |  | $ | 831.2 |  |  | 102.0 | % |
| Percentage of total net sales | 19.9 | % |  | 16.7 | % |  |  |  |  |  | 17.1 | % |  | 16.5 | % |  |  |  |  |
| Europe | $ | 297.7 |  |  | $ | 228.5 |  |  | $ | 69.2 |  |  | 30.3 | % |  | $ | 777.0 |  |  | $ | 776.1 |  |  | $ | 0.9 |  |  | 0.1 | % |
| Percentage of total net sales | 7.7 | % |  | 17.8 | % |  |  |  |  |  | 8.1 | % |  | 15.7 | % |  |  |  |  |
| Others | $ | 102.6 |  |  | $ | 54.9 |  |  | $ | 47.7 |  |  | 86.9 | % |  | $ | 301.1 |  |  | $ | 174.9 |  |  | $ | 126.2 |  |  | 72.2 | % |
| Percentage of total net sales | 2.7 | % |  | 4.3 | % |  |  |  |  |  | 3.1 | % |  | 3.6 | % |  |  |  |  |
| Total net sales | $ | 3,850.1 |  |  | $ | 1,283.3 |  |  |  |  |  |  | $ | 9,634.7 |  |  | $ | 4,938.6 |  |  |  |  |  |

[0001375365-24-000022:mdna:36]
Comparison of Three Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:37]
The period-over-period increase in overall net sales is driven by an increase in demand from customers for GPU servers, HPC, and rack-scale solutions which have higher ASPs, especially for large enterprise and data center customers from the United States and Asia sales where they have experienced significant growth. The period-over-period increase of net sales in Asia, Europe and other regions is mainly due to an increase in net sales in Singapore, Taiwan, Germany and South Africa.

[0001375365-24-000022:mdna:38]
Customer A accounted for 21.2% and customer B accounted for 16.8% of the net sales for the three months ended March 31, 2024. Customer A accounted for 10.7% of the net sales for the three months ended March 31, 2023. We expect to continue to have customers exceeding 10% of net sales in future quarters.

[0001375365-24-000022:mdna:39]
Comparison of Nine Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:40]
SMCI | Q3 2024 Form 10-Q | 36

[0001375365-24-000022:mdna:41]
The period-over-period increase in overall net sales is driven by an increase in demand from customers for GPU servers, HPC and rack-scale solutions which have higher ASPs, especially for large enterprise and data center customers from the United States. The period-over-period increase of net sales in Asia and other regions is mainly due to an increase in net sales in Taiwan, Singapore, Canada and South Africa.

[0001375365-24-000022:mdna:42]
Customer A accounted for 23.7% of the net sales for the nine months ended March 31, 2024. Customer C accounted for 11.8% of the net sales for the nine months ended March 31, 2023. We expect to continue to have customers exceeding 10% of net sales in future quarters.

[0001375365-24-000022:mdna:43]
[same as prior period, unchanged from 0001375365-24-000011:mdna:41]

[0001375365-24-000022:mdna:44]
Cost of sales primarily consists of the costs to manufacture our products, which includes: the costs of materials, contract manufacturing, shipping, personnel expenses (salaries, benefits, stock-based compensation and incentive bonuses), equipment and facility expenses, warranty costs and inventory reserve charges. The primary factors that impact our cost of sales are the mix of products sold, changes in the cost of components, changes in logistic costs, changes in salary and benefits and overhead costs related to production as well as economies of scale gained from higher production volume in our facilities. Cost of sales as a percentage of net sales may increase or decrease over time if the changes in our costs are not matched by corresponding changes in our ASPs. Our cost of sales as a percentage of net sales is also impacted by the timing and extent to which we add to, and are able to efficiently utilize, our manufacturing capacity. Because we generally do not have long-term fixed supply agreements, our cost of sales is subject to frequent change based on the availability of materials and other market conditions. We expect inventory levels to continue to increase to support the future growth of our business. Certain materials used in the manufacturing of our products are available from a limited number of suppliers and we expect that this trend will continue in the future.

[0001375365-24-000022:mdna:45]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing generally performed at our manufacturing facilities in the same region where our products are sold. We work with Ablecom, one of our key contract manufacturers and also a related party to optimize modular designs for our chassis and certain other components. We also outsource to Compuware, also a related party, a portion of our design activities and a significant part of the manufacturing of certain components, particularly power supplies.

[0001375365-24-000022:mdna:46]
Cost of sales and gross margin for the three and nine months ended March 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-24-000022:mdna:47]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Cost of sales | $ | 3,252.7 |  |  | $ | 1,056.9 |  |  | $ | 2,195.8 |  |  | 207.8 | % |  | $ | 8,119.3 |  |  | $ | 4,027.3 |  |  | $ | 4,092.0 |  |  | 101.6 | % |
| Gross profit | $ | 597.4 |  |  | $ | 226.4 |  |  | $ | 371.0 |  |  | 163.9 | % |  | $ | 1,515.4 |  |  | $ | 911.3 |  |  | $ | 604.1 |  |  | 66.3 | % |
| Gross margin | 15.5 | % |  | 17.6 | % |  |  |  | (2.1) | % |  | 15.7 | % |  | 18.5 | % |  |  |  | (2.8) | % |

[0001375365-24-000022:mdna:48]
Comparison of Three Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:49]
The period-over-period increase in cost of sales was primarily attributed to an increase of $2,172.7 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, $9.4 million increase in inventory reserve charges, a $8.5 million increase in overhead cost and a $5.2 million increase in freight costs.

[0001375365-24-000022:mdna:50]
The period-over-period decrease in the gross margin percentage was primarily due to competitive pricing to win new design wins, product and customer mix, partially offset by higher efficiency in manufacturing operational costs.

[0001375365-24-000022:mdna:51]
Comparison of Nine Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:52]
The period-over-period increase in cost of sales was primarily attributed to an increase of $4,090.5 million in costs of materials and contract manufacturing expenses primarily related to the increase in net sales volume, a $10.1 million increase in overhead costs partially offset by a $5.3 million decrease in freight costs due to an improved supply chain and a $3.3 million decrease in inventory reserve charges.

[0001375365-24-000022:mdna:53]
The period-over-period decrease in the gross margin percentage was primarily due to competitive pricing to win new design wins, product and customer mix, partially offset by higher efficiency in manufacturing operational costs.

[0001375365-24-000022:mdna:54]
SMCI | Q3 2024 Form 10-Q | 37

[0001375365-24-000022:mdna:55]
[same as prior period, unchanged from 0001375365-24-000011:mdna:53]

[0001375365-24-000022:mdna:56]
[same as prior period, unchanged from 0001375365-24-000011:mdna:54]

[0001375365-24-000022:mdna:57]
[same as prior period, unchanged from 0001375365-24-000011:mdna:55]

[0001375365-24-000022:mdna:58]
[same as prior period, unchanged from 0001375365-24-000011:mdna:56]

[0001375365-24-000022:mdna:59]
Operating expenses for the three and nine months ended March 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-24-000022:mdna:60]
|  | Three Months Ended March 31, |  | Change |  | Nine Months Ended March 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Research and development | $ | 116.2 |  |  | $ | 77.5 |  |  | $ | 38.7 |  |  | 49.9 | % |  | $ | 336.1 |  |  | $ | 222.4 |  |  | $ | 113.7 |  |  | 51.1 | % |
| Percentage of total net sales | 2.9 | % |  | 6.0 | % |  |  |  |  |  | 3.4 | % |  | 4.5 | % |  |  |  |  |
| Sales and marketing | $ | 49.7 |  |  | $ | 25.3 |  |  | $ | 24.4 |  |  | 96.4 | % |  | $ | 133.8 |  |  | $ | 83.1 |  |  | $ | 50.7 |  |  | 61.0 | % |
| Percentage of total net sales | 1.3 | % |  | 2.0 | % |  |  |  |  |  | 1.4 | % |  | 1.7 | % |  |  |  |  |
| General and administrative | $ | 53.1 |  |  | $ | 24.5 |  |  | $ | 28.6 |  |  | 116.7 | % |  | $ | 123.2 |  |  | $ | 71.4 |  |  | $ | 51.8 |  |  | 72.5 | % |
| Percentage of total net sales | 1.4 | % |  | 1.9 | % |  |  |  |  |  | 1.3 | % |  | 1.3 | % |  |  |  |  |
| Total operating expenses | $ | 219.1 |  |  | $ | 127.3 |  |  | $ | 91.8 |  |  | 72.1 | % |  | $ | 593.1 |  |  | $ | 376.9 |  |  | $ | 216.2 |  |  | 57.4 | % |
| Percentage of total net sales | 5.6 | % |  | 9.9 | % |  |  |  |  |  | 6.1 | % |  | 7.6 | % |  |  |  |  |

[0001375365-24-000022:mdna:61]
SMCI | Q3 2024 Form 10-Q | 38

[0001375365-24-000022:mdna:62]
Comparison of Three Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:63]
Research and development expenses. The period-over-period increase in research and development expenses was driven by a $36.2 million increase in employee related costs primarily due to stock-based compensation increases of $16.8 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $3.6 million increase in product development costs to support the development of next generation products and technologies offset by a $1.1 million increase in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-24-000022:mdna:64]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was driven by a $19.5 million increase in employee related costs primarily due to stock-based compensation increases of $3.8 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $6.1 million increase in advertising and other expenses and a $1.2 million decrease in marketing development funds received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000022:mdna:65]
General and administrative expenses. The period-over-period increase in general and administrative expenses was driven by a $23.2 million increase in employee related costs primarily due to stock-based compensation increases of $19.9 million, salary increases and higher headcount as we expanded our workforce and invested in key talent and a $5.4 million increase in professional and service fees and other expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000022:mdna:66]
Comparison of Nine Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:67]
Research and development expenses. The period-over-period increase in research and development expenses was driven by a $108.8 million increase in employee related costs primarily due to stock-based compensation increases of $62.5 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $5.5 million increase in product development costs to support the development of next generation products and technologies offset by a $0.6 million increase in research and development credits received from certain suppliers and customers. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-24-000022:mdna:68]
Sales and marketing expenses. The period-over-period increase in sales and marketing expenses was driven by a $43.5 million increase in employee related costs primarily due to stock-based compensation increases of $11.5 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $9.6 million increase in advertising and other expenses and a $2.4 million decrease in marketing development funds received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000022:mdna:69]
General and administrative expenses. The period-over-period increase in general and administrative expenses was driven by a $39.6 million increase in employee related costs primarily due to stock-based compensation increases of $31.8 million, salary increases and higher headcount as we expanded our workforce and invested in key talent and a $12.2 million increase in professional and service fees and other expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-24-000022:mdna:70]
Interest Expense and Other Income (Expense), Net

[0001375365-24-000022:mdna:71]
Other income, net consists primarily of interest earned on our investment and cash balances and foreign exchange gains and losses.

[0001375365-24-000022:mdna:72]
[same as prior period, unchanged from 0001375365-24-000011:mdna:71]

[0001375365-24-000022:mdna:73]
SMCI | Q3 2024 Form 10-Q | 39

[0001375365-24-000022:mdna:74]
Interest expense and other income, net for the three and nine months ended March 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-24-000022:mdna:75]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Other income (expense), net | $ | 10.0 |  |  | $ | (0.1) |  |  | $ | 10.1 |  |  | (10,100) | % |  | $ | 8.8 |  |  | $ | 1.6 |  |  | $ | 7.2 |  |  | 450.0 | % |
| Interest expense | (6.2) |  |  | (1.3) |  |  | (4.9) |  |  | 376.9 | % |  | (16.2) |  |  | (6.9) |  |  | (9.3) |  |  | 134.8 | % |
| Interest expense and other income (expense), net | $ | 3.8 |  |  | $ | (1.4) |  |  | $ | 5.2 |  |  | (371.4) | % |  | $ | (7.4) |  |  | $ | (5.3) |  |  | $ | (2.1) |  |  | 39.6 | % |

[0001375365-24-000022:mdna:76]
Comparison of Three Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:77]
The increase of $5.2 million in interest expense and other income (expense), net was primarily attributable to a $10.1 million increase in other income (expense) driven by an increase in foreign currency exchange gain of $7.7 million due to a strong US dollar, and an increase of $3.9 million in interest income, offset by $1.5 million investment loss in marketable securities and a $4.9 million higher interest expense due to higher borrowing during the period.

[0001375365-24-000022:mdna:78]
Comparison of Nine Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:79]
The decrease of $2.1 million in interest expense and other income (expense), net was primarily attributable to a $9.3 million increase in interest expense due to higher borrowing during the period, offset by a $7.2 million increase in interest income and other income (expense) driven by an increase of $6.9 million in interest income and other income, an increase in foreign currency exchange gain of $4.4 million due to a strong US dollar, offset by $4.1 million investment loss in marketable securities.

[0001375365-24-000022:mdna:80]
Income Tax (Benefit) Provision

[0001375365-24-000022:mdna:81]
Our income tax (benefit) provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income and stock-based compensation.

[0001375365-24-000022:mdna:82]
Income tax (benefit) provision for income taxes and effective tax rates for the three and nine months ended March 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-24-000022:mdna:83]
|  | Three Months EndedMarch 31, |  | Change |  | Nine Months EndedMarch 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Income tax (benefit) provision | $ | (20.0) |  |  | $ | 10.9 |  |  | $ | (30.9) |  |  | (283.5) | % |  | $ | 61.7 |  |  | $ | 79.4 |  |  | $ | (17.7) |  |  | (22.3) | % |
| Percentage of total net sales | (0.5) | % |  | 0.8 | % |  |  |  |  |  | 0.6 | % |  | 1.6 | % |  |  |  |  |
| Effective tax rate | (5.2) | % |  | 11.1 | % |  |  |  |  |  | 6.7 | % |  | 15.0 | % |  |  |  |  |

[0001375365-24-000022:mdna:84]
Comparison of Three Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:85]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the three months ended March 31, 2024, is lower than that for the three months ended March 31, 2023, primarily due to the significant increase in stock-based compensation tax deduction, and research and development tax credits.

[0001375365-24-000022:mdna:86]
Comparison of Nine Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:87]
Our quarterly effective income tax rate is based on the estimated annual income tax rate forecast and discrete tax items recognized in the period. The effective tax rate for the nine months ended March 31, 2024, is lower than that for the nine months ended March 31, 2023, primarily due to the significant increase in stock-based compensation tax deduction, and research and development tax credits.

[0001375365-24-000022:mdna:88]
SMCI | Q3 2024 Form 10-Q | 40

[0001375365-24-000022:mdna:89]
[same as prior period, unchanged from 0001375365-24-000011:mdna:87]

[0001375365-24-000022:mdna:90]
[same as prior period, unchanged from 0001375365-24-000011:mdna:88]

[0001375365-24-000022:mdna:91]
Share of income (loss) from equity investee, net of taxes for the three and nine months ended March 31, 2024 and 2023 are as follows (dollars in millions):

[0001375365-24-000022:mdna:92]
|  | Three Months EndedMarch 31, |  | Change | Nine Months EndedMarch 31, |  | Change |
|  | 2024 |  | 2023 |  | $ |  | % |  | 2024 |  | 2023 |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | 0.4 |  |  | $ | (1.0) |  |  | $ | 1.4 |  |  | n/m (1) |  | $ | 2.3 |  |  | $ | (3.3) |  |  | $ | 5.6 |  |  | n/m (1) |
| Percentage of total net sales | — | % |  | (0.1) | % |  |  |  |  |  | — | % |  | (0.1) | % |  |  |  |  |

[0001375365-24-000022:mdna:93]
[same as prior period, unchanged from 0001375365-24-000011:mdna:91]

[0001375365-24-000022:mdna:94]
Comparison of Three Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:95]
The period-over-period increase of $1.4 million in share of income from equity investee, net of taxes was primarily due to improvement in profitability of the Corporate Venture.

[0001375365-24-000022:mdna:96]
Comparison of Nine Months Ended March 31, 2024 and 2023

[0001375365-24-000022:mdna:97]
The period-over-period increase of $5.6 million in share of income from equity investee, net of taxes was primarily due to improvement in profitability of the Corporate Venture.

[0001375365-24-000022:mdna:98]
[same as prior period, unchanged from 0001375365-24-000011:mdna:97]

[0001375365-24-000022:mdna:99]
We have financed our growth primarily with funds generated from operations, in addition to utilizing borrowing facilities and selling our common stock. Our recent drivers of liquidity changes have included an increase in the need for working capital due to higher levels of inventory required by growing revenues and to a lesser extent, longer supply chain lead times on certain key components. Our cash and cash equivalents were $2,115.5 million and $440.5 million as of March 31, 2024 and June 30, 2023, respectively. Our cash and cash equivalents in foreign locations were $262.1 million and $192.3 million as of March 31, 2024 and June 30, 2023, respectively.

[0001375365-24-000022:mdna:100]
[same as prior period, unchanged from 0001375365-24-000011:mdna:99]

[0001375365-24-000022:mdna:101]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the filing of this Quarterly Report on Form 10-Q. We continue to evaluate financing options that may be required to support the growth of our business.

[0001375365-24-000022:mdna:102]
On December 5, 2023, we completed a public offering of 2,415,805 shares of the our common stock at $262.00 per share, with 2,315,105 shares sold by us and 100,700 shares sold by selling stockholders.

[0001375365-24-000022:mdna:103]
[same as prior period, unchanged from 0001375365-24-000011:mdna:103]

[0001375365-24-000022:mdna:104]
SMCI | Q3 2024 Form 10-Q | 41

[0001375365-24-000022:mdna:105]
On February 16, 2024, our Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank, which increased the aggregate total borrowings from time to time under the various individual credit arrangements with CTBC Bank from $105.0 million to $185.0 million. Our Taiwan subsidiary intends to use borrowings under the increased CTBC credit lines in connection with financing of eligible accounts receivable and accounts payable (vendor invoices).

[0001375365-24-000022:mdna:106]
On February 27, 2024, we issued $1,725.0 million aggregate principal amount of 0.00% Convertible Senior Notes due 2029 (the “Convertible Notes”) in a private offering. The Convertible Notes, which are our senior unsecured obligations, will mature on March 1, 2029. They may be repurchased, redeemed, or converted in accordance with their terms before that date. The Convertible Notes do not bear regular interest, and the principal amount of the Convertible Notes will not accrete. The net proceeds from the issuance of the Convertible Notes were $1,553.7 million, net of debt issuance costs of $29.2 million and the related capped call transactions of $142.1 million. The Convertible Notes and capped call transactions are discussed further in Part I, Item 1, Note 7, “Convertible Notes". As of March 31, 2024, none of the conditions permitting the holders of the Convertible Notes to convert their notes early had been met.

[0001375365-24-000022:mdna:107]
On March 22, 2024, we completed a public offering of 2,000,000 shares of our common stock at $875.00 per share. We received net proceeds of approximately $1.73 billion, after deducting underwriting discounts and commissions and offering expenses payable by us.

[0001375365-24-000022:mdna:108]
[same as prior period, unchanged from 0001375365-24-000011:mdna:105]

[0001375365-24-000022:mdna:109]
|  | Nine Months EndedMarch 31, |  | Change |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (1,844.2) |  |  | $ | 672.9 |  |  | $ | (2,517.1) |  |  |  |  |
| Net cash used in investing activities | $ | (132.0) |  |  | $ | (28.6) |  |  | $ | (103.4) |  |  |  |  |
| Net cash provided by (used in) financing activities | $ | 3,652.8 |  |  | $ | (547.3) |  |  | $ | 4,200.1 |  |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 1,675.0 |  |  | $ | 94.7 |  |  | $ | 1,580.3 |  |  |  |  |

[0001375365-24-000022:mdna:110]
[same as prior period, unchanged from 0001375365-24-000011:mdna:107]

[0001375365-24-000022:mdna:111]
Net cash provided by operating activities decreased by $2,517.1 million for the nine months ended March 31, 2024 as compared to the nine months ended March 31, 2023. The decrease was primarily due to an increase in net cash required for net working capital of $2,978.8 million to manufacture products in order to meet customer demand and support expected business growth and a $62.2 million decrease in non-cash items. These decreases are partially offset by increase in net income of $409.0 million and stock-based compensation expense of $114.9 million. The key changes in net working capital of $2,978.8 million includes an increase in inventory of $2,652.8 million, and an increase in accounts receivable of $705.2 million offset by an increase in accounts payable of $318.7 million.

[0001375365-24-000022:mdna:112]
[same as prior period, unchanged from 0001375365-24-000011:mdna:109]

[0001375365-24-000022:mdna:113]
Net cash used in investing activities increased by $103.4 million for the nine months ended March 31, 2024 as compared to the nine months ended March 31, 2023 primarily due to an increase in purchases of property, plant and equipment of $82.0 million made in the nine months ended March 31, 2024 and an increase in investments of $21.4 million in the nine months ended March 31, 2024. Increase in property, plant and equipment is primarily related to the acquisition of previously leased real estate in San Jose, California, for $80 million.

[0001375365-24-000022:mdna:114]
[same as prior period, unchanged from 0001375365-24-000011:mdna:111]

[0001375365-24-000022:mdna:115]
Net cash provided by financing activities increased by $4,200.1 million for the nine months ended March 31, 2024 as compared to the nine months ended March 31, 2023. The increase was primarily due to proceeds of $2,314.0 million from our offerings of common stock, net of issuance costs, $1,695.8 million of proceeds from the sale of our Convertible Notes, net of debt issuance costs, an increase of $285.4 million in proceeds from borrowings, net of repayment, and stock repurchases of $146.5 million in the nine months ended March 31, 2023, offset by $142.1 million entering into capped call transactions related to our 2029 Convertible Notes and a higher withholding tax payment for equity compensation related activities of $99.5 million in the nine months ended March 31, 2024.

[0001375365-24-000022:mdna:116]
SMCI | Q3 2024 Form 10-Q | 42

[0001375365-24-000022:mdna:117]
[same as prior period, unchanged from 0001375365-24-000011:mdna:113]

[0001375365-24-000022:mdna:118]
Refer to Part I, Item 1, Note 6, “Lines of Credit and Term Loans,” in our notes to condensed consolidated financial statements in this Quarterly Report on Form 10-Q for further information on our outstanding bank debt.

[0001375365-24-000022:mdna:119]
[same as prior period, unchanged from 0001375365-24-000011:mdna:115]

[0001375365-24-000022:mdna:120]
We anticipate our capital expenditures for the remainder of fiscal year 2024 will be in range of $55.0 million to $65.0 million, relating primarily to costs associated with our manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades and expansion. During the second quarter of fiscal year 2023, we entered into a letter of understanding to acquire land in Malaysia to expand our manufacturing operations. A definitive agreement to acquire such land, subject to various conditions, was subsequently executed in January 2023. We obtained early access to such land prior to the acquisition, and we anticipate additional capital expenditures for the remainder of fiscal year 2024 of $24.0 million (included in the above range) for such initiative. In addition, in February 2024, we consummated the purchase of real estate comprising approximately 19.72 acres of land and 293,906 square feet of buildings and improvements located in proximity to the Company’s headquarters space in San Jose, California “as is” for an aggregate purchase price of $80.0 million. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on revenue growth, productivity, expenses, service levels and customer retention) and our expected return on investment.

[0001375365-24-000022:mdna:121]
[same as prior period, unchanged from 0001375365-24-000011:mdna:118]

[0001375365-24-000022:mdna:122]
[same as prior period, unchanged from 0001375365-24-000011:mdna:119]

[0001375365-24-000022:mdna:123]
[same as prior period, unchanged from 0001375365-24-000011:mdna:120]

[0001375365-24-000022:mdna:124]
SMCI | Q3 2024 Form 10-Q | 43
