# SMCI notes — 0001375365-25-000027


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001375365-25-000027:notes:1]
None


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001375365-25-000027:notes:2]
We have in place certain infrastructure, systems, policies, and procedures that are designed to proactively and reactively address risks from cybersecurity threats. This includes processes for assessing, identifying, and managing material risks from cybersecurity threats. Our information security management program seeks to follow processes set forth in recognized industry standards, and we evaluate and evolve our security measures as appropriate. We maintain a cybersecurity incident response plan that we practice and update as needed. The identification, assessment and management of cybersecurity risk is integrated into our overall enterprise risk management program that is ultimately overseen by the Board.

[0001375365-25-000027:notes:3]
We consult with external parties, such as third-party cybersecurity firms, to provide, among other things, monitoring of systems, threat intelligence, and employee cybersecurity training. We also use third parties to assist our risk management processes by conducting security assessments.

[0001375365-25-000027:notes:4]
We also have a vendor risk assessment process to oversee and identify risks from cybersecurity threats associated with our use of third-party service providers. These processes consist of the distribution and review of questionnaires designed to identify cybersecurity risks associated with the engagement of third parties. We also audit cybersecurity practices of certain third-party service providers, and take steps designed to ensure that such vendors have implemented data privacy and security controls that help mitigate the cybersecurity risks associated with these vendors, depending on the nature and sensitivity of the supplier and data it processes on our behalf. We routinely assess our high-risk suppliers’ conformance to industry standards and evaluate them for additional information, product, and physical security requirements. 
We employ a number of protective measures, including firewalls, endpoint detection and response technologies, regular annual training of employees with respect to cybersecurity and testing employee competence with anti-phishing policies followed up by additional remedial training as needed.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001375365-25-000027:notes:5]
Governance

[0001375365-25-000027:notes:6]
As part of its broader risk oversight activities, our Board maintains oversight of cybersecurity matters, including managing and assessing risks from cybersecurity threats. The Audit Committee also reviews the adequacy and effectiveness of our information security policies and practices and the internal controls regarding information security risks. The Audit Committee and the Board receive regular information security updates relating to cybersecurity risk from management, including from our Director of Information Security.

[0001375365-25-000027:notes:7]
Cybersecurity risk is primarily managed by our Directors of Information Security and Information Technology. These individuals have decades of experience in managing cybersecurity risk for public companies. Additionally, we have established a cross-functional Cybersecurity Committee, consisting of executive-level leadership, including representatives from Finance, IT, Legal, and other teams, that meets periodically to review cybersecurity risks, incidents, and assess emerging threats. The Cybersecurity Committee is also informed of our responses to such risks, incidents and threats.

[0001375365-25-000027:notes:8]
Our cybersecurity incident response plan also contains mechanisms to notify executive management of cybersecurity incidents. As part of the plan, an executive-level leadership team may be activated and can act to direct our response efforts, to include mitigation and remediation activities, when appropriate.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001375365-25-000027:notes:9]
Note 1.                 Organization and Summary of Significant Accounting Policies

[0001375365-25-000027:notes:10]
Organization

[0001375365-25-000027:notes:11]
Super Micro Computer, Inc. (“Super Micro Computer” or the “Company”) was incorporated in 1993. All references to “Super Micro Computer,” “we,” “us,” “our” or the “Company” mean Super Micro Computer, Inc. and its subsidiaries. Super Micro Computer is a global leader in server technology and green computing innovation. Super Micro Computer develops and provides high performance server and storage solutions based upon an innovative, modular and open-standard architecture. Super Micro Computer has operations primarily in the United States, Taiwan, and the Netherlands.

[0001375365-25-000027:notes:12]
Basis of Presentation

[0001375365-25-000027:notes:13]
The accompanying consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States (“U.S. GAAP”) and include the accounts of Super Micro Computer, Inc. and our wholly-owned subsidiaries where we have controlling financial interests, and any variable interest entities for which we are deemed to be the primary beneficiary. All intercompany balances and transactions have been eliminated.

[0001375365-25-000027:notes:14]
Forward Stock Split

[0001375365-25-000027:notes:15]
On September 30, 2024, we completed a 10-for-1 forward split of our common stock. Trading on a split-adjusted basis commenced on October 1, 2024. All references to shares of common stock and per share amounts contained in this Annual Report have been retroactively adjusted to reflect the stock split.

[0001375365-25-000027:notes:16]
Use of Estimates

[0001375365-25-000027:notes:17]
Preparation of consolidated financial statements in conformity with U.S. GAAP requires the use of estimates and judgments that affect the reported amounts in the consolidated financial statements and accompanying notes. These estimates form the basis for judgments we make about the carrying values of our assets and liabilities, which are not readily apparent from other sources. We base our estimates and judgments on historical information and on various other assumptions that we believe are reasonable under the circumstances. U.S. GAAP requires us to make estimates and judgments in several areas, including, but not limited to, those related to revenue recognition, income taxes, inventory valuation, useful lives of property, plant and equipment, product warranty accruals, impairment of investments and fair value of financial instruments and leases. These estimates are based on management’s knowledge about current events, interpretation of regulations, and expectations about actions we may undertake in the future. Actual results could differ materially from those estimates.

[0001375365-25-000027:notes:18]
Fair Value of Financial Instruments

[0001375365-25-000027:notes:19]
We account for certain assets and liabilities at fair value, which is the price that would be received upon the sale of an asset or paid to transfer a liability in an orderly arms-length transaction between market participants. When measuring fair value, we take into account the characteristics of the asset or liability that a market participant would consider when pricing the asset or liability at the measurement date. We consider one or more techniques for measuring fair value: market approach, income approach, and cost approach. The valuation techniques include inputs that are based on three different levels of observability to the market. We categorize each fair value measurements in one of these three levels based on the lowest level input that is significant to the fair value measurement in its entirety. These levels are:

[0001375365-25-000027:notes:20]
•Level 1 - Unadjusted quoted prices in active markets that are accessible at the measurement date for identical, unrestricted assets or liabilities;

[0001375365-25-000027:notes:21]
•Level 2 - Quoted prices in markets that are not active or financial instruments for which all significant inputs are observable, either directly or indirectly; and

[0001375365-25-000027:notes:22]
•Level 3 - Prices or valuations that require inputs that are both significant to the fair value measurement and unobservable.

[0001375365-25-000027:notes:23]
Accounts receivable, accounts payable, and accrued liabilities are carried at cost, which approximates fair value due to the short maturity of these instruments. Cash and cash equivalents, certificates of deposit, investment in an auction rate security, and marketable securities, included in prepaid expenses and other current assets and other assets in the consolidated balance sheets, are carried at fair value. Non-current accounts receivable, included in other assets in the consolidated balance sheets, are carried at amortized cost, and bear interest at rates that approximate current market rates for similar credit. We believe the carrying amounts approximate fair value because there have been no significant changes in market rates or credit risk. Short-term and long-term debt, the 2029 Convertible Notes, 2028 Convertible Notes, and the 2030 Convertible Notes, included in lines of credit and current portion of term loans, term loans, non-current, and convertible notes, respectively, in the consolidated balance sheets are all carried at amortized cost.

[0001375365-25-000027:notes:24]
Non-marketable Equity Securities

[0001375365-25-000027:notes:25]
Our non-marketable equity securities, included in other assets in the consolidated balance sheets, are investments in privately-held companies without readily determinable fair values. We elected to account for substantially all of our non-marketable equity securities using the measurement alternative, which is cost, less any impairment. We periodically review our non-marketable equity securities for impairment. When indicators exist and the estimated fair value of an investment is below its carrying amount, we write down the investment to its estimated fair value. The change in carrying value, resulted from the remeasurements, is recognized in other income, net on our consolidated statements of operations. For additional information, see Note 3, “Non-marketable Equity Securities”.

[0001375365-25-000027:notes:26]
Cash, Cash Equivalents, and Restricted Cash

[0001375365-25-000027:notes:27]
Cash and cash equivalents consist of cash on deposit with financial institutions globally and highly liquid investments with maturities of 90 days or less from the date of purchase. Cash equivalents consist primarily of money market funds and certificates of deposit with original maturities of less than three months. We classify certain restricted cash balances, consisting mostly of cash related to amounts held in bank accounts which are controlled by the lenders pursuant to the terms of certain debt agreements, certificates of deposit primarily related to leases and customs requirements, and money market accounts held in escrow pursuant to our workers’ compensation program, within other assets on our consolidated balance sheets, based upon the expected duration of the restrictions. For further details on our cash, cash equivalents, and restricted cash, see Note 6, “Balance Sheet Components” in the notes to the consolidated financial statements.

[0001375365-25-000027:notes:28]
Inventories

[0001375365-25-000027:notes:29]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of raw materials (principally electronic components), work in process (principally products being assembled) and finished goods. We evaluate inventory on a quarterly basis for excess and obsolescence and lower of cost or net realizable value and, as necessary, write down the valuation of inventories based upon our inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors. Once inventory is written down, its new value is maintained until it is sold or scrapped.

[0001375365-25-000027:notes:30]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold. For further details on our inventory, see Note 6, “Balance Sheet Components” in the notes to the consolidated financial statements.

[0001375365-25-000027:notes:31]
Property, Plant, and Equipment

[0001375365-25-000027:notes:32]
Property, plant, and equipment is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the related assets as follows:

[0001375365-25-000027:notes:33]
| Software | 3 years |
| Machinery and equipment | 3 to 7 years |
| Furniture and fixtures | 5 years |
| Buildings | 39 years |
| Building improvements | Up to 20 years |
| Land improvements | 15 years |
| Leasehold improvements | Shorter of lease term or estimated useful life |

[0001375365-25-000027:notes:34]
We evaluate at least annually the recoverability of property, plant, and equipment for possible impairment whenever events or circumstances indicate that the carrying amount of such assets may not be recoverable. If such review indicates that the carrying amount of property, plant and equipment assets is not recoverable, and the asset’s fair value is less than the carrying amount, an impairment charge is recognized. No impairment charges were recorded for property, plant, and equipment in any of the periods presented.

[0001375365-25-000027:notes:35]
The useful lives of our property, plant, and equipment are management’s estimates when the assets are initially recognized and are routinely reviewed for the remaining estimated useful lives. Our estimate of useful lives represents the best estimate of the useful lives based on current facts and circumstances but may differ from the actual useful lives due to changes to the business operations, changes in the planned use of assets, and technological advancements. When we change the estimated useful life assumption for any asset, the remaining carrying amount of the asset is accounted for prospectively and depreciated or amortized over the revised estimated useful life.

[0001375365-25-000027:notes:36]
Revenue Recognition

[0001375365-25-000027:notes:37]
We generate revenues from the sale of server and storage systems, subsystems, accessories and services.

[0001375365-25-000027:notes:38]
Product sales. We recognize revenue from sales of products as control is transferred to customers, which generally happens at the point of shipment or upon delivery, unless customer acceptance is required. Determining the point in time that control transfers to the customer requires judgment. Products sold by us are shipped from our facilities or drop shipped from our vendors. We may use distributors to sell products to end customers. Revenue from distributors is recognized when the distributor obtains control of the product, which generally happens at the point of shipment or upon delivery.

[0001375365-25-000027:notes:39]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration is estimated using either the expected value or most likely amount method, depending on which method better predicts the amount of consideration to which we may be entitled. As part of determining the transaction price in contracts with customers, we estimate reserves for future sales returns based on a review of our history of actual returns for each major product order and return type. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs.

[0001375365-25-000027:notes:40]
Services sales. Our sale of services mainly consists of extended warranty and on-site services as well as system rack installation and integration services. Revenue related to extended warranty commences upon the expiration of the standard warranty period and is recognized ratably over the contractual period as we stand ready to perform any required warranty service. Revenue related to on-site services commences upon recognition of the product sale and is recognized ratably over the contractual period as the on-site services are made available to the customer. These service contracts are typically one to five years in length. Revenue related to system rack installation and integration services is recognized when we perform the services and the customer receives and consumes the benefits.

[0001375365-25-000027:notes:41]
Contracts with multiple promised goods and services. Certain of our contracts contain multiple promised goods and services. We assess whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Performance obligations in a contract are identified based on the promised goods or services that will be transferred to the customer that are both capable of being distinct, whereby the customer can benefit from the service either on its own or together with other resources that are readily available from third parties or from us, and are distinct in the context of the contract, whereby the transfer of the services is separately identifiable from other promises in the contract. If these criteria are not met, the promised goods and services are accounted for as a combined performance obligation.

[0001375365-25-000027:notes:42]
If the contract contains a single performance obligation, the entire transaction price is allocated to the single performance obligation. For contracts that contain multiple performance obligations, we allocate the transaction price for each customer contract to each performance obligation based on the relative Stand-alone Selling Price (“SSP”) for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the related performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. We determine SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, we apply judgment to estimate the SSP. For all performance obligations, we are able to establish the SSP by maximizing the use of observable inputs. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-25-000027:notes:43]
Our credit terms are predominantly short-term in nature, however, we also grant extended payment terms for certain customers. For the contracts with the extended payment terms in which the financing component is determined to be significant to the contract, the contract transaction price is adjusted for the effect of a financing component.

[0001375365-25-000027:notes:44]
When we receive consideration from a customer prior to transferring goods or services to the customer, we record a contract liability (deferred revenue). We also recognize deferred revenue when we have an unconditional right to consideration (i.e., a receivable) before transfer of control of goods or services to a customer.

[0001375365-25-000027:notes:45]
Shipping and handling fees collected from customers are included in net sales when control of the product is transferred to the customer, and the related shipping and handling costs are included in cost of sales. We have elected to account for shipping and handling activities that occur after the customer has obtained control of a good as a fulfillment cost rather than as an additional promised service. Taxes imposed by governmental authorities on our revenue producing activities with customers, such as sales taxes and value added taxes, are excluded from net sales.

[0001375365-25-000027:notes:46]
Accounts Receivable and Allowance for Credit Losses

[0001375365-25-000027:notes:47]
We record amounts as accounts receivable when our right to consideration is unconditional. Accounts receivable are recorded at the invoiced amount. For certain customers, we require payment before the products or services are delivered to the customer.

[0001375365-25-000027:notes:48]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. We make estimates of expected credit and collectability trends for the allowance for credit losses and allowance for unbilled receivables based upon our assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from customers. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of operations. All receivables due beyond the 12 month period are classified as a non-current receivable within other assets on the consolidated balance sheets.

[0001375365-25-000027:notes:49]
As of June 30, 2025 and 2024, the allowance for credit losses on accounts receivable were not material. For further details on our non-current receivable and allowance for credit losses, see Note 6, “Balance Sheet Components” in the notes to the consolidated financial statements.

[0001375365-25-000027:notes:50]
Cost of Sales

[0001375365-25-000027:notes:51]
Cost of sales primarily consists of the costs of materials, contract manufacturing, in-bound shipping, personnel and related expenses including stock-based compensation, tariffs, equipment and facility expenses, warranty costs and write down adjustments for lower of cost or net realizable value and excess and obsolete inventory.

[0001375365-25-000027:notes:52]
Product Warranties

[0001375365-25-000027:notes:53]
We offer a limited warranty to end-users ranging from 15 to 39 months for products to repair or replace products for manufacturing defects or hardware component failures. Cost of sales includes the estimated cost of product warranties that are calculated at the point of revenue recognition. Under limited circumstances, we may offer an extended limited warranty to customers for certain products. We also accrue for known warranty and indemnification issues if a loss is probable and can be reasonably estimated. Warranty accruals are based on estimates that are updated on an ongoing basis taking into consideration inputs such as new product introductions, changes in the volume of claims compared with our historical experience, and the changes in the cost of servicing warranty claims. For further details on our product warranties, see Note 6, “Balance Sheet Components” in the notes to the consolidated financial statements.

[0001375365-25-000027:notes:54]
Research and Development

[0001375365-25-000027:notes:55]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as materials and supplies, consulting services, third-party testing services, and equipment and facility expenses related to our research and development activities. All research and development costs are expensed as incurred. We occasionally receive funding from certain suppliers and customers towards our development efforts and such amounts are recorded as a reduction of research and development expenses and were $32.6 million, $21.5 million, and $20.0 million for the fiscal years ended June 30, 2025, 2024, and 2023, respectively.

[0001375365-25-000027:notes:56]
Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.

[0001375365-25-000027:notes:57]
Advertising Costs

[0001375365-25-000027:notes:58]
Advertising costs net of reimbursements received under the cooperative marketing arrangements with our vendors, are expensed when incurred and are included in sales and marketing expenses on the consolidated statements of operations. We incurred advertising expenses of $38.1 million, $10.7 million and $2.0 million for the fiscal years ended June 30, 2025, 2024 and 2023, respectively.

[0001375365-25-000027:notes:59]
Stock-Based Compensation

[0001375365-25-000027:notes:60]
We recognize compensation expense for share-based awards, including stock options, restricted stock units (“RSUs”), and performance-based RSUs (“PRSUs”), based on their grant date fair values over the requisite service period. Stock options and RSUs are expensed on a straight-line basis, while PRSUs are expensed using an accelerated method if performance conditions are likely to be met. If not, no expense is recognized, and previously recognized expense is reversed. For market condition awards, which are typically performance-based, the fair value is amortized over the service period based on the probability of meeting performance criteria. The fair value of RSUs and PRSUs is based on our stock price at grant, while stock options are valued using the Black-Scholes model or Monte Carlo simulation for market-condition awards. The fair value is amortized straight-line over the service period. We recognize stock option and RSU forfeitures when they occur, without estimating forfeiture rates for new grants, while continuing to assess performance conditions.

[0001375365-25-000027:notes:61]
Leases

[0001375365-25-000027:notes:62]
We have arrangements for the right to use our office, warehouse spaces, and other premises, and equipment. We determine at inception if an arrangement is or contains a lease.

[0001375365-25-000027:notes:63]
Operating and finance leases are recorded as Right-of-use ("ROU") assets in other assets, and as lease liabilities in accrued liabilities and other long-term liabilities on our consolidated balance sheets. ROU assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments arising from the lease. Operating and finance lease ROU assets and liabilities are initially recognized based on the present value of lease payments over the lease term. In determining the present value of lease payments, we use the implicit interest rate if readily determinable. When the implicit interest rate is not readily determinable, we use the incremental borrowing rate, which is based on our collateralized borrowing capabilities over a similar term of the lease payments. When using the incremental borrowing rate, we utilize the consolidated group incremental borrowing rate. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term. We have elected the accounting policy to not recognize ROU assets and lease liabilities that arise from short-term (12 months or less) leases for any class of underlying asset. We account for fixed payments for lease and non-lease components as a single lease component from both a lessee and lessor perspective. Non-lease components that have variable costs, such as common area maintenance, are expensed as incurred and not included in the ROU assets and lease liabilities. Our finance leases are immaterial.

[0001375365-25-000027:notes:64]
Income Taxes

[0001375365-25-000027:notes:65]
We account for income taxes under an asset and liability approach. Deferred income taxes reflect the impact of temporary differences between assets and liabilities recognized for financial reporting purposes and such amounts recognized for income tax reporting purposes, net of operating loss carry-forwards and other tax credits measured by applying enacted tax laws related to the financial statement periods. Valuation allowances are provided when necessary to reduce deferred tax assets to an amount that is more likely than not to be realized.

[0001375365-25-000027:notes:66]
We recognize tax liabilities for uncertain income tax positions on the income tax return based on the two-step process. The first step is to determine whether it is more likely than not that each income tax position would be sustained upon audit. The second step is to estimate and measure the tax benefit as the amount that has a greater than 50% likelihood of being realized upon ultimate settlement with the tax authority. Estimating these amounts requires us to determine the probability of various possible outcomes. We evaluate these uncertain tax positions on a quarterly basis. This evaluation is based on the consideration of several factors, including changes in facts or circumstances, changes in applicable tax law, settlement of issues under audit and new exposures. If we later determine that our exposure is lower, or that the liability is insufficient to cover revised expectations, we adjust the liability and record a related charge in our tax provision during the period in which we make this determination.

[0001375365-25-000027:notes:67]
For non-US earnings in our foreign subsidiaries, we plan to indefinitely reinvest such earnings except for Netherlands. For the earnings we intend to indefinitely reinvest, no deferred tax liabilities for foreign withholding or other taxes have been recorded. The tax impact associated with the potential repatriation related to Netherlands, is estimated to be immaterial.

[0001375365-25-000027:notes:68]
Variable Interest Entities (“VIE”)

[0001375365-25-000027:notes:69]
When we obtain an economic interest in an entity, we evaluate whether the entity should be deemed a VIE, and, if so, whether we are the primary beneficiary and therefore required to consolidate the VIE, based on significant judgment whether we (i) have the power to direct the activities that most significantly impact the economic performance of the VIE and (ii) have the obligation to absorb losses or the right to receive benefits of the VIE that could potentially be significant to the VIE.

[0001375365-25-000027:notes:70]
On an ongoing basis, we re-evaluate the VIE assessment based on potential changes in facts and circumstances, including but not limited to, the shareholder loans to the entity and the execution of any future significant agreements between the entity and our shareholders and/or other third parties.

[0001375365-25-000027:notes:71]
Foreign Currency Remeasurement

[0001375365-25-000027:notes:72]
We use the U.S. dollar as our functional currency for all our international subsidiaries, except for Super Micro Asia and Technology Park, Inc., a consolidated variable interest entity. Foreign currency monetary assets and liabilities are remeasured into United States dollars at end-of-period exchange rates. Non-monetary assets and liabilities such as property, plant, and equipment and equity are remeasured at historical exchange rates. Revenue and expenses are remeasured at exchange rates in effect during each period, except for those expenses related to non-monetary balance sheet amounts, which are remeasured at historical exchange rates. Gains or losses from foreign currency remeasurement are included in other income, net in our consolidated statements of operations and, to date, have not been significant. Realized and unrealized foreign exchange (loss) gain for fiscal years ended June 30, 2025, 2024, and 2023 was $(11.6) million, $6.3 million, and $0.2 million, respectively.

[0001375365-25-000027:notes:73]
Net Income Per Share

[0001375365-25-000027:notes:74]
Basic net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed by dividing net income attributable to common stock by the weighted-average number of shares of common stock and potentially dilutive shares of common stock outstanding during the period. Potentially dilutive shares outstanding include the dilutive effect of equity awards, as well as convertible notes. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The dilutive effect of equity awards is calculated based on the average stock price for each fiscal period, using the treasury stock method. The dilutive effect of convertible notes is calculated using the if-converted method. Contingently issuable shares are included in computing basic net income per common share as of the date that all necessary conditions, including service vesting conditions have been satisfied. Contingently issuable shares are considered for computing diluted net income per common share as of the beginning of the period in which all necessary conditions have been satisfied and the only remaining vesting condition is a service vesting condition.

[0001375365-25-000027:notes:75]
Litigation, Investigation and Settlement Costs

[0001375365-25-000027:notes:76]
We currently are, and will likely continue to be, subject to claims, litigation, and other actions, including potential regulatory proceedings, involving patent and other intellectual property matters, taxes, labor and employment, competition and antitrust, commercial disputes, goods and services offered by us and by third parties, and other matters. There are many uncertainties associated with any litigation or investigation, and we cannot be certain that these actions or other third party claims against us will be resolved without litigation, fines and/or substantial settlement payments or judgments. If information becomes available that causes us to determine that a loss in any of our pending litigation, investigations or settlements is probable, and we can reasonably estimate the loss associated with such events, we will record the loss. However, the actual liability in any such litigation or investigation may be materially different from our estimates, which could require us to record additional costs. If we determine that a loss is reasonably possible and the loss or range of loss can be estimated, we disclose the reasonably possible loss. We accrue legal fees for litigation as the legal services are provided.

[0001375365-25-000027:notes:77]
Concentration of Supplier Risk

[0001375365-25-000027:notes:78]
Certain materials used by us in the manufacturing of our products are available from a limited number of suppliers. Shortages could occur in these materials due to an interruption of supply or increased demand in the industry.

[0001375365-25-000027:notes:79]
Two suppliers accounted for below percentage of total purchases:

[0001375365-25-000027:notes:80]
|  | June 30, 2025 |  | June 30, 2024 |  | June 30, 2023 |
| Percentage of total purchases |  |  |  |  |  |
| Supplier A | 64.4% |  | 65.4% |  | 30.7% |
| Supplier B | 5.1% |  | 6.3% |  | 13.5% |

[0001375365-25-000027:notes:81]
^The supplier references of A and B above may represent different suppliers than those reported in a previous period.

[0001375365-25-000027:notes:82]
Purchases from Ablecom and Compuware, our related parties, as shown in Note 10, “Related Party Transactions” in the notes to the consolidated financial statements, accounted for a combined 3.3%, 4.3%, and 6.6% of cost of sales on our consolidated statements of operations for the fiscal years ended June 30, 2025, 2024, and 2023, respectively.

[0001375365-25-000027:notes:83]
Concentration of Credit Risk

[0001375365-25-000027:notes:84]
Financial instruments, potentially subject to our concentration of credit risk, consist primarily of cash and cash equivalents, restricted cash, and accounts receivable. We deposit cash with high-quality financial institutions. These deposits are guaranteed by the federal deposit insurance corporation up to an insurance limit.

[0001375365-25-000027:notes:85]
Significant customer information is as follows:

[0001375365-25-000027:notes:86]
|  | June 30, 2025 |  | June 30, 2024 |
| Percentage of accounts receivable |  |  |  |
| Customer A | 33.4% |  | 15.4% |
| Customer B | 13.6% |  | * |
| Customer C | * |  | 44.8% |

[0001375365-25-000027:notes:87]
^The customer references of A-C above may represent different customers than those reported in a previous period.

[0001375365-25-000027:notes:88]
*Below 10%

[0001375365-25-000027:notes:89]
Concentration of Customer Risk

[0001375365-25-000027:notes:90]
The concentration of customer risk refers to the potential adverse impact on a business due to a high dependency on a limited number of customers. This risk arises when a significant portion of our revenue is generated from a small group of customers. If any of these key customers reduce their orders, delay payments, or terminate their contracts, the business could face substantial financial instability.

[0001375365-25-000027:notes:91]
|  | June 30, 2025 |  | June 30, 2024 |  | June 30, 2023 |
| Percentage of total net sales |  |  |  |  |  |
| Customer A | 20.9% |  | 20.0% |  | * |
| Customer B | 11.5% |  | * |  | * |
| Customer C | 11.3% |  | * |  | * |
| Customer D | 11.1% |  | * |  | * |

[0001375365-25-000027:notes:92]
^The customer references of A-D above may represent different customers than those reported in a previous period.

[0001375365-25-000027:notes:93]
Treasury Stock

[0001375365-25-000027:notes:94]
We account for treasury stock under the cost method. Upon the retirement of treasury shares, we deduct the par value of the retired treasury shares from common stock and allocate the excess of cost over par as a deduction to additional paid-in capital based on the pro-rata portion of additional paid-in-capital, and the remaining excess as a deduction to retained earnings. Retired treasury shares revert to the status of authorized but unissued shares.

[0001375365-25-000027:notes:95]
Accounting Pronouncements Recently Adopted

[0001375365-25-000027:notes:96]
In November 2023, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280) – Improvements to Reportable Segment Disclosures. This ASU requires that a public entity provide additional segment disclosures on an interim and annual basis. The amendments in this ASU should be applied retrospectively to all prior periods presented in the financial statements unless impracticable. Upon transition, the segment expense categories and amounts disclosed in the prior periods should be based on the significant segment expense categories identified and disclosed in the period of adoption. The ASU is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2024, and for the interim period beginning July 1, 2025. We noted that the adoption of this standard did not have a material impact on our consolidated financial statements, other than enhanced disclosures. Please refer to Note 15, “Segment Reporting” in the notes to the consolidated financial statements for further discussion.

[0001375365-25-000027:notes:97]
Accounting Pronouncements Not Yet Adopted

[0001375365-25-000027:notes:98]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which includes amendments that further enhance income tax disclosures, primarily through standardization and disaggregation of rate reconciliation categories and income taxes paid by jurisdiction. The standard is effective for annual periods beginning after December 15, 2024. Early adoption is permitted and should be applied prospectively, with retrospective application permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We do not expect the adoption of this standard to have a material impact on our consolidated financial statements other than additional disclosures.

[0001375365-25-000027:notes:99]
In March 2024, the FASB issued ASU 2024-02, Codification Improvements—Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements. The ASU affects a variety of Topics in the Codification. The amendments apply to all reporting entities within the scope of the affected accounting guidance. The ASU may be applied prospectively or retrospectively and is effective for fiscal years beginning after December 15, 2024. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2025. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001375365-25-000027:notes:100]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, but it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), which was issued to clarify the initial effective date for entities that do not have an annual reporting period that ends on December 31 (referred to as non-calendar year-end entities). The update clarified that ASU 2024-03 shall be effective for public business entities for annual reporting periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our consolidated financial statements other than additional disclosures.

[0001375365-25-000027:notes:101]
In May 2025, the FASB issued ASU 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810): Determining the Accounting Acquirer in the Acquisition of a Variable Interest Entity, which revises current guidance for determining the accounting acquirer for a transaction effected primarily by exchanging equity interests in which the legal acquiree is a variable interest entity that meets the definition of a business. The amendments require that an entity consider the same factors that are currently required for determining which entity is the accounting acquirer in other acquisition transactions. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2027. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001375365-25-000027:notes:102]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments–Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, which provides all entities with a practical expedient and entities other than public business entities with an accounting policy election when applying the guidance in Topic 326, Financial Instruments–Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. The ASU is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods. Early adoption is permitted. The ASU is effective for our fiscal year beginning July 1, 2026. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001375365-25-000027:notes:103]
Disaggregation of Revenue

[0001375365-25-000027:notes:104]
We disaggregate revenue by type of product and geographical region to depict the nature, amount, and timing of revenue and cash flows. Service and software revenues, which are less than 10%, are not a significant component of total revenue and are aggregated with server and storage systems revenue.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001375365-25-000027:notes:105]
^The supplier references of A and B above may represent different suppliers than those reported in a previous period.
Significant customer information is as follows:

[0001375365-25-000027:notes:106]
^The customer references of A-D above may represent different customers than those reported in a previous period.
*Below 10%


## us-gaap:FairValueDisclosuresTextBlock

[0001375365-25-000027:notes:107]
Note 2.                 Financial Instruments and Fair Value Measurements

[0001375365-25-000027:notes:108]
We classify our financial instruments, except for our investment in an auction rate security and other investments in privately held companies, within Level 1 or Level 2 in the fair value hierarchy because we use quoted prices in active markets or alternative pricing sources and models using market observable inputs to determine their fair value.

[0001375365-25-000027:notes:109]
Financial Instruments Measured at Fair Value on a Recurring Basis

[0001375365-25-000027:notes:110]
Cash and cash equivalents, certificates of deposit, investment in an auction rate security, and marketable securities, included in prepaid expenses and other current assets and other assets in the consolidated balance sheets, are carried at fair value.

[0001375365-25-000027:notes:111]
The following table sets forth our financial instruments as of June 30, 2025 and 2024, which are measured at fair value on a recurring basis by level within the fair value hierarchy. These are classified based on the lowest level of input that is significant to the fair value measurement (in thousands):

[0001375365-25-000027:notes:112]
| June 30, 2025 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 44 |  |  | $ | — |  |  | $ | — |  |  | $ | 44 |  |
| Certificates of deposit | — |  |  | 519 |  |  | — |  |  | 519 |  |
| Investment in marketable equity security | 6,239 |  |  | — |  |  | — |  |  | 6,239 |
| Auction rate security | — |  |  | — |  |  | 1,750 |  |  | 1,750 |  |
| Total assets measured at fair value | $ | 6,283 |  |  | $ | 519 |  |  | $ | 1,750 |  |  | $ | 8,552 |  |
| June 30, 2024 | Level 1 |  | Level 2 |  | Level 3 |  | Asset atFair Value |
| Assets |  |  |  |  |  |  |  |
| Money market funds(1) | $ | 340 |  |  | $ | — |  |  | $ | — |  |  | $ | 340 |  |
| Certificates of deposit | — |  |  | 486 |  |  | — |  |  | 486 |  |
| Investment in marketable equity security | 3,686 |  |  | — |  |  | — |  |  | 3,686 |  |
| Auction rate security | — |  |  | — |  |  | 1,829 |  |  | 1,829 |  |
| Total assets measured at fair value | $ | 4,026 |  |  | $ | 486 |  |  | $ | 1,829 |  |  | $ | 6,341 |  |

[0001375365-25-000027:notes:113]
(1)  All of the money market funds are included in cash and cash equivalents as of June 30, 2025. As of June 30, 2024, $0.1 million and $0.2 million of money market funds are included in cash and cash equivalents and restricted cash, non-current in other assets, respectively, in the consolidated balance sheets.

[0001375365-25-000027:notes:114]
The investment in marketable equity security is carried at fair value using values available on a public exchange, is based on a Level 1 input, and is recorded in prepaid expenses and other current assets in the consolidated balance sheets. The unrealized gains and losses of the investment are included in other income, net  in our consolidated statements of operations. As of June 30, 2025, we have investment of $6.2 million in a marketable equity security. An unrealized gain (loss) of $2.6 million and $(1.3) million was recorded in other income, net in the consolidated statements of operations for the fiscal years ended June 30, 2025 and 2024.

[0001375365-25-000027:notes:115]
Our investment in an auction rate security is classified as an available for sale security within Level 3 of the fair value hierarchy as the determination of our fair value was not based on observable inputs as of June 30, 2025 and June 30, 2024. See Note 1, “Organization and Summary of Significant Accounting Policies” in the notes to the consolidated financial statements for a discussion of our policies regarding the fair value hierarchy. We are using the discounted cash flow method to estimate the fair value of the auction rate security at each period end and using the following assumptions: (i) the expected yield based on observable market rate of similar securities, (ii) the security coupon rate that is reset monthly, (iii) the estimated holding period, and (iv) a liquidity discount. The liquidity discount assumption is based on the management estimate of lack of marketability discount of similar securities and is determined based on the analysis of financial market trends over time, recent redemptions of securities and other market activities. We performed a sensitivity analysis and applying a change of either plus or minus 100 basis points in the liquidity discount would not result in a significantly higher or lower fair value measurement of the auction rate security as of June 30, 2025.

[0001375365-25-000027:notes:116]
For the fiscal years ended June 30, 2025, 2024, and 2023, the unrealized gains and losses for the auction rate security in other comprehensive income were not material.

[0001375365-25-000027:notes:117]
On a quarterly basis, we also evaluate the current expected credit loss by considering factors such as historical experience, market data, issuer-specific factors, current economic conditions, and reasonable economic forecasts that affect collectability. For the fiscal years ended June 30, 2025, 2024, and 2023, the credit losses related to our investments were not material.

[0001375365-25-000027:notes:118]
There were no transfers between Level 1, Level 2 or Level 3 financial instruments in fiscal years 2025 and 2024.

[0001375365-25-000027:notes:119]
Financial Instruments Not Recorded at Fair Value

[0001375365-25-000027:notes:120]
Accounts receivable, accounts payable, and accrued liabilities are carried at cost, which approximates fair value due to the short maturity of these instruments.

[0001375365-25-000027:notes:121]
We estimate the fair value of outstanding debt, including our 2029 Convertible Notes, 2028 Convertible Notes, and 2030 Convertible Notes, for disclosure purposes on a recurring basis. Non-current accounts receivable, included in other assets in the consolidated balance sheets, are carried at amortized cost, and bear interest at rates that approximate current market rates for similar credit. We believe the carrying amounts approximate fair value because there have been no significant changes in market rates or credit risk.

[0001375365-25-000027:notes:122]
As of June 30, 2025 and 2024, our total lines of credit and term loans of $112.5 million and $476.4 million, respectively, are reported at amortized cost. The outstanding debt was categorized as Level 2 as it is not actively traded. The carrying value approximates fair value.

[0001375365-25-000027:notes:123]
The estimated fair value as of June 30, 2025 of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes were $1,801.9 million, $818.5 million, and $2,576.6 million, respectively. The estimated fair value as of June 30, 2024 of the 2029 Convertible Notes was $1,734.6 million. The estimated fair value of the 2029 Convertible Notes, the 2028 Convertible Notes, and the 2030 Convertible Notes was determined through consideration of quoted market prices. The 2029 Convertible Notes, 2028 Convertible Notes, and 2030 Convertible Notes are categorized as Level 2 since their fair value was based on Level 2 inputs of quoted prices.


## smci:NonMarketableEquityInvestmentsTextBlock

[0001375365-25-000027:notes:124]
Note 3.                 Non-marketable Equity Securities

[0001375365-25-000027:notes:125]
Our non-marketable equity securities, included in other assets in the consolidated balance sheets, consist of investments in privately held companies without readily determinable fair values. The following table shows our non-marketable equity securities that were measured using the measurement alternative (in thousands):

[0001375365-25-000027:notes:126]
|  | June 30, |
|  | 2025 |  | 2024 |
| Non-marketable equity securities under measurement alternative: |  |  |  |
| Opening gross investment balance | $ | 66,217 |  |  | $ | 1,728 |  |
| Investment made during the year | 56,000 |  |  | 64,489 |
| Cumulative impairment adjustment | (11,600) |  |  | (11,600) |  |
| Carrying value | $ | 110,617 |  |  | $ | 54,617 |  |

[0001375365-25-000027:notes:127]
We performed qualitative assessments to identify impairment indicators and no impairment was recognized during fiscal year ended June 30, 2025. During the fiscal year ended June 30, 2024, we recognized an impairment of $11.6 million and no impairment was recognized during fiscal year ended June 30, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001375365-25-000027:notes:128]
Note 4.                 Revenue

[0001375365-25-000027:notes:129]
The following is a summary of net sales by product type (in thousands):

[0001375365-25-000027:notes:130]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Server and storage systems | $ | 21,311,637 |  |  | $ | 14,185,220 |  |  | $ | 6,569,814 |  |
| Subsystems and accessories | 660,405 |  |  | 804,031 |  |  | 553,668 |  |
| Total | $ | 21,972,042 |  |  | $ | 14,989,251 |  |  | $ | 7,123,482 |  |

[0001375365-25-000027:notes:131]
Server and storage systems constitute an assembly and integration of subsystems and accessories, software, and related services. Subsystems and accessories are comprised of server boards, chassis and accessories.

[0001375365-25-000027:notes:132]
Total revenue recognized from all service and software for fiscal years ended June 30, 2025 and 2024 was $330.5 million and $228.3 million, respectively. Of this, revenue related to services recognized over time ratably over the contract term was $223.1 million for fiscal year ended June 30, 2025, and $152.1 million for fiscal year ended June 30, 2024.

[0001375365-25-000027:notes:133]
International net sales are based on the country and geographical region to which the products were shipped. The following is a summary of net sales by geographic region (in thousands):

[0001375365-25-000027:notes:134]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| United States | $ | 13,052,563 |  |  | $ | 10,187,331 |  |  | $ | 4,834,061 |  |
| Asia | 5,494,147 |  |  | 2,912,570 |  |  | 1,050,837 |  |
| Europe | 2,726,994 |  |  | 1,293,959 |  |  | 1,003,046 |  |
| Other | 698,338 |  |  | 595,391 |  |  | 235,538 |  |
| Total | $ | 21,972,042 |  |  | $ | 14,989,251 |  |  | $ | 7,123,482 |  |

[0001375365-25-000027:notes:135]
Contract Balances

[0001375365-25-000027:notes:136]
Generally, the payment terms of our offerings range from 30 to 60 days. In certain instances, customers may prepay for products and services in advance of delivery. Receivables represent our unconditional right to consideration for performance obligations that are either partially or fully completed.

[0001375365-25-000027:notes:137]
Contract assets are rights to consideration in exchange for goods or services that we have transferred to a customer when such right is conditional on something other than the passage of time. Such contract assets are insignificant to our consolidated financial statements.

[0001375365-25-000027:notes:138]
Contract liabilities consist of deferred revenue and relate to amounts invoiced to or advance consideration received from customers, which precede our satisfaction of the associated performance obligations. Our deferred revenue primarily results from customer payments received upfront for extended warranties and on-site services because these performance obligations are satisfied over time. Additionally, at times, deferred revenue may fluctuate due to the timing of non-refundable advance consideration received from non-cancelable contracts relating to the sale of future products. Revenue recognized during fiscal year ended June 30, 2025, which was included in the opening deferred revenue balance as of June 30, 2024 of $416.4 million, was $190.2 million. Revenue recognized during fiscal year ended June 30, 2024, which was included in the opening deferred revenue balance as of June 30, 2023 of $304.4 million, was $130.7 million.

[0001375365-25-000027:notes:139]
Deferred revenue increased by $315.0 million as of June 30, 2025, as compared to the fiscal year ended June 30, 2024.  This increase was mainly due to the deferral of invoiced amounts for service contracts during the period exceeding the recognized revenue from contracts entered into in prior periods. This was accompanied by a $11.5 million increase in non-refundable advance consideration or cash consideration received from customers which preceded our satisfaction of the associated performance obligations relating to product sales expected to be fulfilled in the next 12 months.

[0001375365-25-000027:notes:140]
Transaction Price Allocated to the Remaining Performance Obligations

[0001375365-25-000027:notes:141]
Remaining performance obligations represent in aggregate the amount of transaction price that has been allocated to performance obligations not delivered, or only partially delivered, as of the end of the reporting period. We apply the exemption to not disclose information about remaining performance obligations that are part of a contract that has an original expected duration of one year or less. These performance obligations generally consist of services, such as on-site services, including integration services and extended warranty services, that are contracted for one year or less, and products for which control has not yet been transferred. The value of the transaction price allocated to the remaining performance obligations as of June 30, 2025, was approximately $731.4 million. We expect to recognize approximately 50% of such value in the next 12 months, and the remainder thereafter.

[0001375365-25-000027:notes:142]
Capitalized Contract Acquisition Costs and Fulfillment Cost

[0001375365-25-000027:notes:143]
Contract acquisition costs are incremental costs that we incur to obtain a contract with a customer that it would not have incurred if the contract had not been obtained. Contract acquisition costs consist primarily of incentive bonuses paid to our sales employees. Contract acquisition costs are considered incremental and recoverable costs of obtaining and fulfilling a contract with a customer and are therefore capitalizable. We apply the practical expedient to expense contract acquisition costs as incurred if the amortization period would be one year or less, generally upon delivery of the associated server and storage systems or components. Where the amortization period of the contract cost would be more than a year, we apply judgment in the allocation of the contract acquisition costs asset between hardware and service performance obligations and expense the cost allocated to the hardware performance obligations upon delivery of associated server and storage systems or components and amortizes the cost allocated to service performance obligations over the period the services are expected to be provided. Contract acquisition costs allocated to service performance obligations that are subject to capitalization are insignificant to our consolidated financial statements.

[0001375365-25-000027:notes:144]
Contract fulfillment costs consist of costs paid in advance for outsourced services provided by third parties to the extent they are not in the scope of other guidance. Fulfillment costs paid in advance for outsourced services provided by third parties are capitalized and amortized over the period when the services are expected to be provided. Such fulfillment costs are insignificant to our consolidated financial statements. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and services provided over the contract term and at a point in time for system rack installation and integration services rendered.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001375365-25-000027:notes:145]
The following is a summary of net sales by geographic region (in thousands):


## us-gaap:EarningsPerShareTextBlock

[0001375365-25-000027:notes:146]
Note 5.                 Net Income Per Common Share

[0001375365-25-000027:notes:147]
The following table shows the computation of basic and diluted net income per common share for the years ended June 30, 2025, 2024, and 2023 (in thousands, except per share amounts):

[0001375365-25-000027:notes:148]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |
| Net income - basic | $ | 1,048,854 |  |  | $ | 1,152,666 |  |  | $ | 639,998 |  |
| Convertible Notes interest charge, net of tax | 5,726 |  |  | 1,480 |  |  | — |  |
| Net income - diluted | $ | 1,054,580 |  |  | $ | 1,154,146 |  |  | $ | 639,998 |  |
| Denominator: |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 593,665 |  | 555,878 |  | 529,249 |
| Effect of dilutive Convertible Notes | 4,685 |  | 4,392 |  | — |
| Effect of dilutive securities | 30,052 |  | 41,876 |  | 30,455 |
| Weighted-average shares outstanding - diluted | 628,402 |  | 602,146 |  |  | 559,704 |  |
| Net income per common share - basic | $ | 1.77 |  |  | $ | 2.07 |  |  | $ | 1.21 |  |
| Net income per common share - diluted | $ | 1.68 |  |  | $ | 1.92 |  |  | $ | 1.14 |  |

[0001375365-25-000027:notes:149]
Potentially dilutive shares of common stock issuable upon conversion of our outstanding 2029 Convertible Notes, outstanding 2028 Convertible Notes, and outstanding 2030 Convertible Notes are determined using the if-converted method. For the year ended June 30, 2025, shares issuable upon conversion of the 2028 Convertible Notes and 2030 Convertible Notes were dilutive and were included within the numerator for interest and denominator for shares issuable upon conversion of the diluted net income per common share computation. For year ended June 30, 2025, shares issuable upon conversion of the 2029 Convertible Notes were anti-dilutive.

[0001375365-25-000027:notes:150]
The following table presents the potentially dilutive shares that were excluded from the computation of diluted net income per share of common shares attributable to common stockholders, because their effect was anti-dilutive (in thousands):

[0001375365-25-000027:notes:151]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Stock-based awards | 14,707 |  |  | 2,700 |  |  | 1,778 |  |
| Convertible notes | 20,673 |  |  | — |  |  | — |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001375365-25-000027:notes:152]
Note 6.                 Balance Sheet Components

[0001375365-25-000027:notes:153]
The following tables provide details of the selected balance sheet items (in thousands):

[0001375365-25-000027:notes:154]
|  | June 30, |
|  | 2025 |  | 2024 |
| Cash and cash equivalents | $ | 5,169,911 |  |  | $ | 1,669,766 |  |
| Restricted cash included in other assets | 2,390 |  |  | 507 |  |
| Total cash, cash equivalents, and restricted cash | $ | 5,172,301 |  |  | $ | 1,670,273 |  |

[0001375365-25-000027:notes:155]
Allowance for credit losses

[0001375365-25-000027:notes:156]
We have established an allowance for credit losses. The allowance for credit losses is based upon the age of outstanding receivables, credit risk of specific customers, historical trends related to past losses and other relevant factors. Accounts receivable allowances as of June 30, 2025, 2024, and 2023 consisted of the following:

[0001375365-25-000027:notes:157]
|  | BeginningBalance |  | Credit Loss Recoveries, net |  | Write-offs |  | EndingBalance |
| Allowance for credit losses |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 73 |  |  | $ | (4) |  |  | $ | (69) |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | 82 |  |  | $ | (9) |  |  | $ | — |  |  | $ | 73 |  |
| Year Ended June 30, 2023 | $ | 1,753 |  |  | $ | (13) |  |  | $ | (1,659) |  |  | $ | 82 |  |

[0001375365-25-000027:notes:158]
|  | June 30, |
|  | 2025 |  | 2024 |
| Finished goods | $ | 3,465,352 |  |  | $ | 3,312,768 |  |
| Work in process | 674,613 |  |  | 450,993 |  |
| Purchased parts and raw materials | 540,410 |  |  | 569,268 |  |
| Total inventories | $ | 4,680,375 |  |  | $ | 4,333,029 |  |

[0001375365-25-000027:notes:159]
During the fiscal years ended June 30, 2025, 2024, and 2023, we recorded write down adjustments for excess and obsolete inventory and lower of cost and net realizable value adjustments to cost of sales totaling $232.0 million, $83.0 million, and $30.8 million, respectively.

[0001375365-25-000027:notes:160]
Property, Plant, and Equipment, net

[0001375365-25-000027:notes:161]
|  | June 30, |
|  | 2025 |  | 2024 |
| Land | $ | 162,848 |  |  | $ | 150,137 |  |
| Buildings | 182,466 |  |  | 163,764 |  |
| Machinery and equipment | 111,331 |  |  | 156,496 |  |
| Building and leasehold improvements | 121,665 |  |  | 72,075 |  |
| Furniture and fixtures | 36,268 |  |  | 46,241 |  |
| Software | 7,117 |  |  | 24,363 |  |
| Construction in progress | 1,038 |  |  | 14,828 |  |
| Property, plant, and equipment, gross | 622,733 |  |  | 627,904 |  |
| Accumulated depreciation and amortization | (118,245) |  |  | (213,896) |  |
| Property, plant, and equipment, net | $ | 504,488 |  |  | $ | 414,008 |  |

[0001375365-25-000027:notes:162]
Depreciation expense for the fiscal years ended June 30, 2025, 2024, and 2023 was $41.0 million, $30.1 million, and $26.9 million, respectively.

[0001375365-25-000027:notes:163]
During the fiscal year ended June 30, 2025, $128.3 million of fully depreciated assets were written off from the cost and accumulated depreciation amounts in the table above. These assets had a zero net book value, thus, no gain or loss was recognized on the consolidated statements of operations from the write off.

[0001375365-25-000027:notes:164]
Other Assets

[0001375365-25-000027:notes:165]
|  | June 30, |
|  | 2025 |  | 2024 |
| Non-current accounts receivable | $ | 166,405 |  |  | $ | — |  |
| Operating lease right-of-use asset | 293,692 |  |  | 34,566 |  |
| Long-term investments | 112,367 |  |  | 60,996 |  |
| Deferred service costs, non-current | 10,713 |  |  | 11,035 |  |
| Deposits | 4,980 |  |  | 4,508 |  |
| Restricted cash, non-current | 2,390 |  |  | 507 |  |
| Other | 14,324 |  |  | 3,340 |  |
| Total other assets | $ | 604,871 |  |  | $ | 114,952 |  |

[0001375365-25-000027:notes:166]
Accrued Liabilities

[0001375365-25-000027:notes:167]
|  | June 30, |
|  | 2025 |  | 2024 |
| Accrued payroll and related expenses | $ | 82,156 |  |  | $ | 62,006 |  |
| Customer deposits | 260,131 |  |  | 46,942 |  |
| Accrued professional fees | 8,098 |  |  | 1,699 |  |
| Accrued warranty costs | 9,753 |  |  | 10,009 |  |
| Accrued cooperative marketing expenses | 26,775 |  |  | 15,967 |  |
| Operating lease liability | 21,189 |  |  | 9,248 |  |
| Accrued Interest - Convertible Notes | 27,701 |  |  | — |  |
| Customer-related liabilities | 32,858 |  |  | 42,370 |  |
| Input Tax Payable | 39,161 |  |  | 14,064 |  |
| Other | 57,815 |  |  | 57,369 |  |
| Total accrued liabilities | $ | 565,637 |  |  | $ | 259,674 |  |

[0001375365-25-000027:notes:168]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Balance, beginning of the year | $ | 17,815 |  |  | $ | 14,859 |  |  | $ | 12,137 |  |
| Provision for warranty | 59,164 |  |  | 52,253 |  |  | 35,407 |  |
| Costs utilized | (56,572) |  |  | (49,204) |  |  | (33,784) |  |
| Change in estimated liability for pre-existing warranties | (3,453) |  |  | (93) |  |  | 1,099 |  |
| Balance, end of the year | $ | 16,954 |  |  | $ | 17,815 |  |  | $ | 14,859 |  |
| Current portion | 9,753 |  |  | 10,009 |  |  | 9,079 |  |
| Non-current portion | $ | 7,201 |  |  | $ | 7,806 |  |  | $ | 5,780 |  |

[0001375365-25-000027:notes:169]
The portion of the accrued warranty costs expected to be incurred within the next 12 months is included within accrued liabilities, while the remaining balance is included within other long-term liabilities on the consolidated balance sheets

[0001375365-25-000027:notes:170]
Offsetting of Financial Assets and Liabilities

[0001375365-25-000027:notes:171]
We have agreements with certain contract manufacturers that allow us to offset receivables and payables with those counterparties. As of June 30, 2025, the gross amount recorded within our consolidated balance sheets in prepaid expenses and other current assets and accounts payable was $16.2 million and $40.0 million, respectively. As of June 30, 2024, the gross amount recorded within our consolidated balance sheets in prepaid expenses and other current assets and accounts payable was $14.0 million and $38.3 million, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001375365-25-000027:notes:172]
Note 7.                 Lines of Credit and Term Loans

[0001375365-25-000027:notes:173]
Short-term and long-term loan obligations with respect to revolving lines of credit and term loans as of June 30, 2025 and 2024 consisted of the following (in thousands):

[0001375365-25-000027:notes:174]
|  | June 30, |
|  | 2025 |  | 2024 |
| Line of credit: |  |  |  |
| CTBC Credit Lines | $ | — |  |  | $ | 184,573 |  |
| Chang Hwa Bank Credit Lines | — |  | 9,215 |
| HSBC Bank Credit Lines | — |  | 30,000 |
| E.SUN Bank Credit Lines | 30,000 |  | 60,000 |
| Mega Bank Credit Lines | — |  | 50,000 |
| First Bank Credit Lines | — |  | 28,084 |  |
| Total lines of credit | 30,000 |  |  | 361,872 |  |
| Term loan facilities: |  |  |  |
| Chang Hwa Bank Credit Facility due October 15, 2026 | 11,399 |  | 17,918 |
| CTBC Term Loan Facility, due June 4, 2030 | 28,822 |  | 31,155 |
| CTBC Term Loan Facility, due August 15, 2026 | 1,846 |  | 3,079 |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | 13,678 |  | 22,116 |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | 9,632 |  | 12,645 |
| Mega Bank Term Loan Facility, due October 3, 2026 | 17,098 |  | 27,644 |
| Total term loans | 82,475 |  | 114,557 |
| Total lines of credit and term loans | 112,475 |  | 476,429 |
| Lines of credit and current portion of term loans | 75,060 |  | 402,346 |
| Term loans, non-current | $ | 37,415 |  |  | $ | 74,083 |  |

[0001375365-25-000027:notes:175]
Activities under Revolving Lines of Credit and Term Loans

[0001375365-25-000027:notes:176]
Available borrowings and interest rates as of June 30, 2025 and June 30, 2024 consisted of the following (in thousands except for percentages):

[0001375365-25-000027:notes:177]
|  | June 30, 2025 |  | June 30, 2024 |
|  | Available borrowings | Interest rate |  | Available borrowings | Interest rate |
| Line of credit: |  |  |  |  |  |
| 2018 Bank of America Credit Facility | $ | — |  | —% |  | $ | 350,000 |  | 6.82% |
| 2022 Bank of America Credit Facility | $ | — |  | —% |  | $ | 20,000 |  | 6.49% |
| Cathay Bank Line of Credit | $ | — |  | —% |  | $ | 132,000 |  | 7.33% |
| CTBC Credit Lines | $ | 185,000 |  | 2.63% - 5.79% |  | $ | 427 |  | 2.09% - 6.13% |
| Chang Hwa Bank Credit Lines | $ | 30,259 |  | 1.88% - 5.16% |  | $ | 20,000 |  | 1.88% - 6.33% |
| HSBC Bank Credit Lines | $ | — |  | —% - —% |  | $ | 20,000 |  | 2.03% - 6.28% |
| E.SUN Bank Credit Lines | $ | 30,000 |  | 2.02% - 5.12% |  | $ | — |  | 2.02% - 6.17% |
| Mega Bank Credit Lines | $ | 50,000 |  | 1.90% - 5.26% |  | $ | — |  | 1.90% - 5.80% |
| First Bank Credit Lines | $ | — |  | —% - —% |  | $ | 1,916 |  | 2.03% - 6.19% |
| Yuanta Bank Credit Lines | $ | — |  | —% - —% |  | $ | 47,610 |  | 2.32% - 6.33% |
| Term loan facilities: |  |  |  |  |  |
| Bank of America Term Loan | $ | — |  | n/a |  | $ | — |  | n/a |
| Chang Hwa Bank Credit Facility due October 15, 2026 | $ | — |  | 2.08% |  | $ | — |  | 1.68% |
| CTBC Term Loan Facility, due June 4, 2030 | $ | — |  | 1.33% - 1.83% |  | $ | — |  | 1.33% |
| CTBC Term Loan Facility, due August 15, 2026 | $ | — |  | 1.53% - 2.03% |  | $ | — |  | 1.53% |
| E.SUN Bank Term Loan Facility, due September 15, 2026 | $ | — |  | 2.22% |  | $ | — |  | 1.87% |
| E.SUN Bank Term Loan Facility, due August 15, 2027 | $ | — |  | 1.92% |  | $ | — |  | 1.87% |
| Mega Bank Term Loan Facility, due October 3, 2026 | $ | — |  | 2.02% |  | $ | — |  | 1.52% - 1.72% |

[0001375365-25-000027:notes:178]
Bank of America

[0001375365-25-000027:notes:179]
2018 Bank of America Credit Facility (terminated in November 2024)

[0001375365-25-000027:notes:180]
In April 2018, we entered into a revolving line of credit with Bank of America for up to $250.0 million (as amended from time to time, the “2018 Bank of America Credit Facility”). On March 3, 2022, the 2018 Bank of America Credit Facility was amended to, among other items, increase the size of the facility from $200.0 million to $350.0 million and change provisions relating to payments and LIBOR replacement mechanics to Secured Overnight Financing Rate (“SOFR”). The obligations bear a base interest rate plus 0.5% to 1.5% based on the SOFR availability. As of June, 30, 2024, the total outstanding borrowing under this credit facility was $0.0 million.

[0001375365-25-000027:notes:181]
On July 19, 2024 and on September 27, 2024, we entered into the Eighth and Ninth Amendments to Loan and Security Agreement, which amended the Loan and Security Agreement, dated as of April 19, 2018 (the “ABL Agreement”)which amended, among other things the due date to deliver our audited financial statements for the fiscal year ended June 30, 2024 under the agreement.

[0001375365-25-000027:notes:182]
On November 20, 2024, we terminated our obligations under the ABL Agreement.

[0001375365-25-000027:notes:183]
2022 Bank of America Credit Facility (terminated in November 2024)

[0001375365-25-000027:notes:184]
On March 23, 2022, we, through our Taiwan subsidiary, entered into an Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch (the “2022 Bank of America Credit Facility”), for an amount not to exceed in aggregate $20.0 million. The interest rate will be quoted by Bank of America - Taipei Branch for each drawdown.

[0001375365-25-000027:notes:185]
As of June 30, 2024, we had no outstanding borrowings under the 2022 Bank of America Credit Facility and on November 20, 2024, we terminated our obligations under the Uncommitted Facility Agreement for credit lines with Bank of America – Taipei Branch.

[0001375365-25-000027:notes:186]
Bridge Term Loan Facility (terminated in November 2024)

[0001375365-25-000027:notes:187]
On July 19, 2024, we entered into a Term Loan Credit Agreement, by and among us, the lenders party thereto, and Bank of America, N.A., as the administrative agent (the “Term Loan Agent”), which provided for a $500.0 million term loan facility (the “Bridge Term Loan Facility”). This term loan was amended on September 27, 2024 which amended, among other things, the date by which we were required to deliver our audited financial statements for the fiscal year 2024 under the agreement, and on November 1, 2024, we paid the borrowing in full and terminated our obligations under the Term Loan Agreement.

[0001375365-25-000027:notes:188]
Cathay Bank

[0001375365-25-000027:notes:189]
Cathay Bank Line of Credit (terminated in November 2024)

[0001375365-25-000027:notes:190]
On May 19, 2022 (the “Cathay Bank Effective Date”), we entered into a Loan Agreement (the “Cathay Bank Loan Agreement”) with Cathay Bank pursuant to which Cathay Bank has agreed to provide a revolving line of credit of up to $132.0 million (the “Commitment”) for the five-year period following the Cathay Bank Effective Date. The interest rate under the Cathay Bank Loan Agreement is based upon either the SOFR index or prime rate index, at our quarterly election, plus a tiered spread that is based upon the average amounts deposited by us at Cathay Bank as a percentage of the Commitment. The spread is either 1.65% or 2.00% if the index is SOFR index, or 1.25% or 1.00% if the spread is the prime rate index with the higher spread applying in each case if an amount less than 25% of the Commitment is on deposit with Cathay Bank.

[0001375365-25-000027:notes:191]
As of June 30, 2024, the outstanding borrowing under this line of credit was $0.0 million.

[0001375365-25-000027:notes:192]
On October 28, 2024 and on November 15, 2024, we entered into the Third and Fourth Amendments to the Loan Agreement , which amended, among other things the date by which we were required to deliver our audited financial statements under the agreement and on November 20, 2024, we repaid the borrowing in full and terminated our obligations under the Cathay Bank Loan Agreement.

[0001375365-25-000027:notes:193]
CTBC Bank

[0001375365-25-000027:notes:194]
CTBC Credit Lines

[0001375365-25-000027:notes:195]
On September 28, 2023, our Taiwan subsidiary entered into a general agreement for omnibus credit lines with CTBC Bank (the “2023 CTBC Agreement”), which replaces the prior CTBC credit lines in their entirety and permits for borrowings, from time to time, thereunder pursuant to various individual credit arrangements and includes the previously issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD 1,250.0 million and NTD 100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), and (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “Export/Import Line,” and, together with the NTD Short Term Loan/Guarantee Line and the USD Short Term Loan Line, the “New CTBC Credit Lines”). Aggregate borrowings under the New CTBC Credit Lines together is subject to a cap of $105.0 million.

[0001375365-25-000027:notes:196]
On February 16, 2024, our Taiwan subsidiary entered into a new general agreement for omnibus credit lines with CTBC Bank (the “2024 CTBC Agreement”). This agreement (which changed arrangements under the 2023 CTBC Agreement), increased the aggregate total borrowings under the various individual credit arrangements with CTBC Bank from $105.0 million to $185.0 million. The credit arrangements under the 2024 CTBC Agreement now include the previous issued long and medium term loan facility of NTD 1,550.0 million entered in 2021 and 2020 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD 1,250.0 million and NTD 100.0 million, respectively (the “New NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “New USD Short Term Loan Line”), (iii) an export/import o/a loan line providing a line of credit of up to $105.0 million for exports and $50.0 million for imports (the “New Export/Import Line”), and (iv) an import o/a loan line of credit of up to $80.0 million available through August 31, 2024 (the “Incremental Import Line,” and, together with the New NTD Short Term Loan/Guarantee Line, the New USD Short Term Loan Line, and the New Export/Import Line, the “Increased CTBC Credit Lines”). Aggregate borrowings under all the Increased CTBC Credit Lines are subject to a cap of $185.0 million.

[0001375365-25-000027:notes:197]
Interest rates under each of the individual Increased CTBC Credit Lines are to be established according to individual credit arrangements, which interest rates shall be subject to adjustment depending on the satisfaction of certain conditions. Each of the New NTD Short Term Loan/Guarantee Line and the New USD Short Term Loan Line continue to be secured by certain of our Taiwan subsidiary’s assets, including certain property, land, and plant. The tenor of the Incremental Import Line provides for availability until August 31, 2024, with a final drawdown date of February 28, 2025. Such Incremental Import Line, which is reviewed quarterly for cancellation by the CTBC Bank, is also subject to an average usage requirement and fee for retaining the underutilized portion of such line. For the Long and Medium Loan Facility, the Taiwan subsidiary is subject to various financial covenants, including current ratio, debt service coverage ratio, and financial debt ratio requirements. In the event the Taiwan subsidiary does not satisfy such financial covenants, CTBC Bank is permitted to, among other things, reduce the permitted total borrowings to a cap of $70.0 million from $105.0 million. Additional covenants require, among other things, us to maintain ownership of all of the capital stock of the Taiwan subsidiary and prohibit secondary mortgages on certain assets securing various of the Increased CTBC Credit Lines. The Increased CTBC Credit Lines have customary default provisions permitting CTBC Bank to suspend the extension of credit, reduce the credit line, shorten the credit extension term, or declare all principal and interest amounts immediately due and payable.

[0001375365-25-000027:notes:198]
2025 CTBC Facility Letter

[0001375365-25-000027:notes:199]
On February 27, 2025, our Taiwan Subsidiary received a new facility letter from CTBC Bank (“2025 Facility”), issued under the general agreement for omnibus credit lines with CTBC Bank, dated February 16, 2024 (the “2024 CTBC Agreement”). As a result, the credit arrangements under the 2024 CTBC Agreement now include the previously issued long and medium-term loan facility of NTD 1,550.0 million entered into in 2020 and 2021 (the “Long and Medium Loan Facility”), and each of (i) a short-term loan and guarantee line providing credit of up to NTD 1,800.0 million and NTD 100.0 million, respectively (the “NTD Short Term Loan/Guarantee Line”), (ii) a short-term loan providing a line of credit of up to $40.0 million (the “USD Short Term Loan Line”), (iii) an export/import open account loan line providing a line of credit of up to $105.0 million for exports and imports (the “Export/Import Line”) and (iv) an import o/a loan line of credit of up to $80.0 million (the “Import O/A Line,” and, together with the NTD Short Term Loan/Guarantee Line, the USD Short Term Loan Line, and the Export/Import Line, the “2025 CTBC Credit Lines”). Aggregate borrowings under all the 2025 CTBC Credit Lines are subject to a cap of $185.0 million as set forth under the 2024 CTBC Agreement.

[0001375365-25-000027:notes:200]
The 2025 Facility expires on February 28, 2026. As of June 30, 2025 and 2024, the outstanding borrowings under the CTBC Credit Lines were $0.0 million and $184.6 million, respectively.  As of June 30, 2025, the amount available for future borrowing under the 2025 CTBC Bank Credit Lines was $185.0 million.

[0001375365-25-000027:notes:201]
CTBC Term Loan Facility

[0001375365-25-000027:notes:202]
We, through our Taiwan subsidiary, entered into certain credit agreement, dated May 6, 2020, with CTBC Bank Co., Ltd. (“CTBC”), which provided for a ten-year, non-revolving term loan facility (the “2020 CTBC Term Loan Facility”) to borrow up to NTD 1,200.0 million.

[0001375365-25-000027:notes:203]
On July 20, 2021, we, through our Taiwan subsidiary, entered into a general agreement for omnibus credit lines with CTBC (the “2021 CTBC Credit Facility"), which replaced the prior CTBC credit facilities, other than the 2020 CTBC Team Loan Facility, in their entirety and permit borrowings, from time to time, pursuant to a term loan facility of up to NTD 1,550.0 million including the existing 2020 CTBC Term Loan Facility of NTD 1,200.0 million and a new 75-month, non-revolving term loan facility of NTD 350.0 million to use to purchase machinery and equipment for the Company’s Bade Manufacturing Facility located in Taiwan (the “2021 CTBC Machine Loan”).

[0001375365-25-000027:notes:204]
As of June 30, 2025 and 2024, the amounts outstanding under the 2020 CTBC Term Loan Facility were $28.8 million and $31.2 million, respectively. As of June 30, 2025 and 2024, under the 2021 CTBC Machine Loan, the amounts outstanding were $1.8 million and $3.1 million, respectively.

[0001375365-25-000027:notes:205]
As of June 30, 2025, the net book value of land and building located in Bade, Taiwan, collateralizing the CTBC Credit Line and Term Loan Facility was $75.1 million.

[0001375365-25-000027:notes:206]
Chang Hwa Bank

[0001375365-25-000027:notes:207]
Chang Hwa Bank Credit Lines and Credit Facility

[0001375365-25-000027:notes:208]
On October 5, 2021 (the “Chang Hwa Bank Effective Date”), we, through our Taiwan subsidiary, entered into a credit facility (the “Chang Hwa Bank Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”). The Chang Hwa Bank Credit Facility permits borrowings of up to NTD 1,000.0 million (the “Chang Hwa Bank Term Loan Facility”), including up to $20.0 million as loans, advances, acceptances, bills, bank guarantees, overdrafts, letters of credit, and other types of drawdown instruments (the “CHB Credit Lines”). Terms for specific drawdown instruments issued under the Chang Hwa Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are set forth in the Import O/A Loan Contract and Export O/A Loan Contract, which were entered into on the Chang Hwa Bank Effective Date None of these Loan Contracts are secured and there are no financial covenants.

[0001375365-25-000027:notes:209]
On May 13, 2022, Chang Hwa Bank notified us that it increased the borrowing capacity limit by $20.0 million.

[0001375365-25-000027:notes:210]
On April 26, 2024 (the “CHB Effective Date”), our Taiwan subsidiary entered into a credit facility (the “New Credit Facility”) with Chang Hwa Commercial Bank, Ltd. (“Chang Hwa Bank”) which was substantially similar to the Chang Hwa Bank Credit Facility, except the credit limit thereunder was updated to include, in addition to $20.0 million from the Chang Hwa Bank Credit Facility, an additional credit limit of NTD 300.0 million (together, the “CHB Credit Lines”).

[0001375365-25-000027:notes:211]
Terms for specific drawdown instruments issued under the New Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in separate loan contracts (each, a “Loan Contract”) negotiated with the Chang Hwa Bank. Under three Loan Contracts entered into on the CHB Effective Date, our Taiwan subsidiary and the Bank have agreed to each of the following: (a) our Taiwan subsidiary may choose one of the following, subject to a cap of $20.0 million under the CHB Credit Lines: (i) a Loan Contract providing for the drawdown of up to $20.0 million for an import loan (the “Import Open Account O/A Loan”), with the interest rate thereunder is based on Taipei Forex Inc (“TAIFX”) plus a fixed margin; or (ii) a Loan Contract providing for the drawdown of up to $20.0 million for an export loan (the “Export Open Account O/A Loan”). with the interest rate thereunder is based on TAIFX plus a fixed margin; and (b) a Loan Contract for a general working capital loan (the “General Working Capital Loan”), subject to a cap of NTD 300.0 million under the CHB Credit Lines, with the interest rate set at a fixed premium to a specified one-year time savings deposit rate, subject to a floor of 1.4%.

[0001375365-25-000027:notes:212]
None of the Import O/A Loan, Export O/A Loan, or General Working Capital Loan are secured and there are no financial covenants. Under the New Credit Facility, the Bank has the right to demand collateral for debts owed.

[0001375365-25-000027:notes:213]
As of June 30, 2025 and 2024, the outstanding borrowings under the CHB Credit Lines were $0.0 million and $9.2 million, respectively. As of June 30, 2025, the amount available for future borrowing under the CHB Credit Lines was $30.3 million.

[0001375365-25-000027:notes:214]
As of June 30, 2025 and 2024, the total outstanding borrowings under the Chang Hwa Bank Term Loan Facility were denominated in NTD and remeasured into U.S. dollars at $11.4 million and $17.9 million, respectively.

[0001375365-25-000027:notes:215]
E.SUN Bank

[0001375365-25-000027:notes:216]
E.SUN Bank Credit Lines

[0001375365-25-000027:notes:217]
On June 17, 2023, we, through our Taiwan subsidiary, entered into a Notification and Confirmation pursuant to which the Taiwan subsidiary and E.SUN Bank agreed to drawdowns of up to $30.0 million for an import o/a financing loan with a tenor of 120 days (the “2023 Import O/A Loan”). The period of use is between May 16, 2023 and May 16, 2024. The interest rate thereunder is based on the US dollar offered rate of the Taipai Forex Trading Center (“TAIFX3”) plus a fixed margin, subject to negotiation on a monthly basis and adjustment under certain circumstances. Interest payments are due on a monthly basis, and the principal is repayable on the due date. The 2023 Import O/A Loan is not secured. Such Notification and Confirmation replaced the Notification and Confirmation entered into on the 2022 E.SUN Bank Effective Date related to the 2022 Import O/A Loan.

[0001375365-25-000027:notes:218]
On April 19, 2024, and renewed on May 19, 2025, our Taiwan subsidiary entered into unsecured credit facilities with E.SUN Bank consisting of: (i) an Import and Export Trade Facility, comprising import and export O/A financing loans, and (ii) a short-term loan facility. The combined borrowing limit under both facilities is $60.0 million for the O/A Loan, including up to NTD 800.0 million for the short-term loan. Drawdowns under the O/A loans have a tenor of 120 days; drawdowns under the short-term loan have a tenor of 180 days. The O/A loans bear interest at TAIFX3 plus a fixed margin, and the short-term loan bears interest at E.SUN Bank’s one-month time savings deposit rate index plus a fixed margin, subject to a stated minimum. Interest rates may be adjusted under certain conditions. The facilities are available on a revolving basis through April 1, 2026 and require us to maintain continuous NASDAQ listing and 100% ownership of the Taiwan subsidiary; noncompliance may result in suspension of availability and accelerated repayment.

[0001375365-25-000027:notes:219]
As of June 30, 2025 and 2024, the outstanding borrowings under the E.SUN Bank Credit Lines were $30.0 million  and $60.0 million, respectively. As of June 30, 2025, the amount available for future borrowing under the E.SUN Bank Credit Lines was $30.0 million.

[0001375365-25-000027:notes:220]
E.SUN Bank Term Loan Facility

[0001375365-25-000027:notes:221]
On September 13, 2021 (the “Old E.SUN Bank Effective Date”), we, through our Taiwan subsidiary, entered into a new General Credit Agreement with E.SUN Bank, which replaced the Prior E.SUN Bank Credit Facility (the “2021 E.SUN Bank Credit Facility”). The 2021 E.SUN Bank Credit Facility permitted borrowings of up to NTD 1,600.0 million.

[0001375365-25-000027:notes:222]
Terms for specific drawdown instruments issued under the 2021 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, were to be set forth in Notifications and Confirmation of Credit Conditions (a “Notification and Confirmation”) negotiated with E.SUN Bank. A Notification and Confirmation was entered into on the Old E.SUN Bank Effective Date for a five-year, non-revolving term loan facility to obtain up to NTD 1,600.0 million in financing for use in research and development activities (the “Term Loan”). As of June 30, 2025 and 2024, the total outstanding borrowings under the Term Loan were denominated in NTD and remeasured into U.S. dollars of $13.7 million and $22.1 million, respectively.

[0001375365-25-000027:notes:223]
On August 9, 2022 (the “2022 E.SUN Bank Effective Date”), we, through our Taiwan subsidiary, entered into a new General Credit Agreement with E.SUN Bank, which replaced the 2021 E.SUN Bank Credit Facility (the “2022 E.SUN Bank Credit Facility”). The 2022 E.SUN Bank Credit Facility permits borrowings of up to NTD 680.0 million and the prior medium term loan under the Prior E.SUN Bank Credit Facility shall not exceed in aggregate NTD 1,800.0 million.

[0001375365-25-000027:notes:224]
Terms for specific drawdown instruments issued under the 2022 E.SUN Bank Credit Facility, such as credit amount, term of use, mode of drawdown, specific lending rate, and other relevant terms, are to be set forth in a Notifications and Confirmation. Under a Notification and Confirmation entered into on the 2022 E.SUN Bank Effective Date, our Taiwan subsidiary and E.SUN Bank have agreed to a Medium Term Credit Loan of NTD 680.0 million with a tenor of five years.

[0001375365-25-000027:notes:225]
On November 14, 2024 and June 27, 2025, the Taiwan Subsidiary entered into amendments (the “2025 E.SUN Amendments”) of various Notifications and Confirmations of Credit Agreements (the “Notifications and Confirmations”) previously entered into with E.SUN Bank, which modified certain covenant requirements.

[0001375365-25-000027:notes:226]
As of June 30, 2025 and 2024, the amount outstanding under the Term Loan was denominated in NTD and remeasured into US dollars of $9.6 million and $12.6 million, respectively.

[0001375365-25-000027:notes:227]
HSBC Bank

[0001375365-25-000027:notes:228]
HSBC Bank Credit Lines (terminated in December 2024)

[0001375365-25-000027:notes:229]
On January 7, 2022 (the “HSBC Bank Effective Date”), we, through our Taiwan subsidiary, entered into a General Loan, Export/Import Financing, Overdraft Facilities and Securities Agreement (the “Loan Agreement”) with a Taiwan affiliate of HSBC Bank (“HSBC Bank”). HSBC Bank agreed to a $30.0 million export/seller trade facility under the Loan Agreement with a tenor of 120 days. The interest rate thereunder is based on HSBC Bank’s base rate plus a fixed margin, subject to adjustment under certain circumstances.

[0001375365-25-000027:notes:230]
As of June 30, 2024, the outstanding borrowings under the HSBC Loan Agreement was $30.0 million, which was fully paid on September 9, 2024, during fiscal year 2025. On December 20, 2024, the General Loan, Export/Import Financing, Overdraft Facilities, and Securities Agreement which the Taiwan Subsidiary had entered into with the Taiwan affiliate of HSBC Bank (the “HSBC Loan Agreement”) was terminated and not renewed.

[0001375365-25-000027:notes:231]
Mega Bank

[0001375365-25-000027:notes:232]
Mega Bank Credit Facilities

[0001375365-25-000027:notes:233]
On April 17, 2024, we, through our Taiwan subsidiary, entered into an Omnibus Credit Authorization Agreement (the “2024 Omnibus Credit Authorization Agreement”) with Mega International Commercial Bank (“Mega Bank”), which was substantially similar to the 2023 Omnibus Authorization Agreement, except the credit limit thereunder was increased from $20.0 million (or foreign currency equivalent) to $50.0 million (or foreign currency equivalent) (the “Mega Bank Credit Limit”). During the loan period, our Taiwan subsidiary is required to maintain certain specified deposit balances with Mega Bank and we are required to maintain 100% direct or indirect share ownership of our Taiwan subsidiary.

[0001375365-25-000027:notes:234]
The 2024 Omnibus Credit Authorization Agreement set forth additional terms of the individual credit authorizations. Our Taiwan subsidiary also received a Credit Authorization Approval Notice (the “Approval Notice”) from an associated branch of Mega Bank. Pursuant to such Approval Notice, the associated Mega Bank branch permits our Taiwan subsidiary to make drawdowns up to the Mega Bank Credit Limit for short-term loans for material purchases and operating revolver with a tenor not to exceed 120 days. The Approval Notice also includes a sub-item credit limit of NTD 1,200.0 million as short-term loans for turnover. Interest on drawdowns denominated in US dollars is based upon TAIFX OFFER for three or six months, interest on drawdowns denominated in NTD is based upon Taipei Interbank Offered Rate (“TAIBOR”) for three or six months, and interest on drawdowns denominated in other currencies is based upon Mega Bank’s cost of borrowing plus a specified premium, subject to periodic adjustment and adjustment in certain other circumstances, such as failure to maintain a sufficient balance in a demand deposit account with Mega Bank which are subject to Mega Bank’s right of set off. Amounts borrowed are otherwise unsecured.

[0001375365-25-000027:notes:235]
On June 24, 2025, we, through our Taiwan subsidiary, entered into an Omnibus Credit Authorization Agreement (the “New Omnibus Credit Authorization Agreement”) with Mega International Commercial Bank (“Mega Bank”), which was substantially similar to the 2024 Omnibus Credit Authorization Agreement. The New Omnibus Credit Authorized Agreement also includes a sub-item credit limit of NTD 600.0 million as short-term loans for turnover. Interest on drawdowns denominated in US dollars is based upon TAIFX OFFER for three or six months, interest on drawdowns denominated in NTD is based upon TAIBOR for three or six months, and interest on drawdowns denominated in other currencies is based upon Mega Bank’s cost of borrowing plus a specified premium, subject to periodic adjustment and adjustment in certain other circumstances, such as failure to maintain a sufficient balance in a demand deposit account with Mega Bank which are subject to Mega Bank’s right of set off. Amounts borrowed are otherwise unsecured. During the loan period, our Taiwan subsidiary is required to maintain certain specified deposit balances with Mega Bank and we are required to maintain 100% direct or indirect share ownership of our Taiwan subsidiary. 100% of deposit needs to be pledged to Mega Bank for the amount of actual drawdown exceeding $30.0 million.

[0001375365-25-000027:notes:236]
As of June 30, 2025 and 2024, the outstanding borrowings under the Mega Bank credit lines were $0.0 million and $50.0 million, respectively. As of June 30, 2025, the amount available for future borrowing under the Mega Bank credit lines was $50.0 million.

[0001375365-25-000027:notes:237]
Mega Bank Term Loan Facilities

[0001375365-25-000027:notes:238]
On September 13, 2021 (the “Mega Bank Effective Date”), we, through our Taiwan subsidiary, entered into a NTD 1,200.0 million credit facility (the “Mega Bank Credit Facility”) with Mega Bank. The Mega Bank Credit Facility will be used to support manufacturing activities (such as purchase of materials and components), and to provide medium-term working capital (the “Permitted Uses”). Drawdowns under the Mega Bank Credit Facility may be made through December 31, 2024, with the first drawdown date not later than November 5, 2021. The first drawdown date was on October 4, 2021. Drawdowns may be in amounts of up to 80% of Permitted Uses certified to the Bank in drawdown certificates. The interest rate is subject to adjustment in certain circumstances, such as events of default. Interest is payable monthly. Principal payments for amounts borrowed commence on the 15th day of the month following two years after the first drawdown and are repaid in monthly installments over a period of three years thereafter. The Mega Bank Credit Facility is unsecured and has customary default provisions permitting Mega Bank to reduce or cancel the extension of credit, or declare all principal and interest amounts immediately due and payable.

[0001375365-25-000027:notes:239]
As of June 30, 2025 and 2024, the total outstanding borrowings under the Mega Bank Credit Facility were denominated in NTD and remeasured into U.S. dollars at $17.1 million and $27.6 million, respectively.

[0001375365-25-000027:notes:240]
Yuanta Bank

[0001375365-25-000027:notes:241]
Yuanta Bank Credit Lines (expired in May 2025)

[0001375365-25-000027:notes:242]
On May 23, 2024, our Taiwan subsidiary entered into an Omnibus Credit Agreement and an additional agreement with Yuanta Commercial Bank Co., Ltd., securing credit lines up to NTD 1,550.0 million. The agreement allows for revolving borrowings, including: (i) Working Capital Loans up to NTD 1,550.0 million, (ii) Overseas Purchase Loans up to $50.0 million, and (iii) Export Loans up to $50.0 million.

[0001375365-25-000027:notes:243]
As of June 30, 2024, there were no outstanding borrowings and on May 23, 2025, the agreement expired.

[0001375365-25-000027:notes:244]
First Bank

[0001375365-25-000027:notes:245]
First Bank Credit Lines

[0001375365-25-000027:notes:246]
On April 26, 2024, our Taiwan subsidiary entered into a Credit Agreement and a Foreign Currency Agreement with First Commercial Bank Co., Ltd. (“First Bank”), providing a foreign currency working capital loan of up to $30.0 million including a sub-item credit limit of NTD 900.0 million on a revolving basis (the "First Bank Loan"). The loan terms, outlined in a Facility Letter from First Bank dated February 20, 2024, set the contract period from February 17, 2024, to February 17, 2025, with interest rates based on TAIFX or base rate plus a premium, depending on the currency.

[0001375365-25-000027:notes:247]
The loan is unsecured but subject to First Bank’s right of set-off, with the possibility of requiring collateral at the bank’s discretion. First Bank retains the right to reduce the facility amount, shorten the repayment term, or call the loan in full under certain conditions, such as missed interest or principal payments, failure to meet obligations to other financial institutions, or material legal violations by the Subsidiary.

[0001375365-25-000027:notes:248]
As of June 30, 2024, the outstanding borrowings under the First Bank credit lines were $28.1 million. The First Bank Loan was paid in full and expired on February 17, 2025.

[0001375365-25-000027:notes:249]
The agreement was renewed on July 18, 2025. The credit lines are reduced from $30.0 million to $20.0 million, including a sub-item credit limit of NTD 600.0 million as short-term loans for turnover.

[0001375365-25-000027:notes:250]
Future Payments Schedule

[0001375365-25-000027:notes:251]
Principal payments on short-term and long-term debt obligations are due as follows (in thousands):

[0001375365-25-000027:notes:252]
| Fiscal Year: |  | Principal Payments |
| 2026 |  | $ | 75,060 |  |
| 2027 |  | 19,576 |  |
| 2028 |  | 6,603 |  |
| 2029 |  | 5,862 |  |
| 2030 |  | 5,374 |  |
| Total short-term and long-term debt |  | $ | 112,475 |  |

[0001375365-25-000027:notes:253]
As of June 30, 2025, we were in compliance with all the covenants for the revolving lines of credit and term loans identified in this Note 7, “Lines of Credit and Term Loans”.

[0001375365-25-000027:notes:254]
Note 8.                 Convertible Notes

[0001375365-25-000027:notes:255]
2029 Convertible Notes

[0001375365-25-000027:notes:256]
In February 2024, we issued $1,725.0 million aggregate principal amount of 0.0% Convertible Senior Notes due 2029 (the “Original 2029 Convertible Notes”). On February 11, 2025, we entered into privately negotiated subscription agreements with certain holders of the Original 2029 Convertible Notes (the “Convertible Note SPAs”) to, among other things, amend certain terms of, and obtain waivers with respect to, the Original 2029 Convertible Notes and to issue $700.0 million aggregate principal amount of the 2028 Convertible Notes (as further described below). On February 12, 2025, pricing of the amended 2029 Convertible Notes and 2028 Convertible Notes was set pursuant to the Convertible Note SPAs, establishing a binding commitment by the parties to the Convertible Note SPAs. On February 20, 2025,we amended and supplemented that certain indenture governing the Original 2029 Convertible Notes (the “Original 2029 Notes Indenture”), dated as of February 27, 2024, by entering into a first supplemental indenture and a second supplemental indenture (the Original 2029 Notes Indenture, as so amended, the “2029 Convertible Notes Indenture”), in each case the 2029 Convertible Notes were amended to (i) bear interest from February 20, 2025 at an annual rate of 3.50%, payable semi-annually in arrears on each March 1 and September 1, beginning on September 1, 2025 and (ii) include an updated conversion rate of 11.9842 shares of our common stock per $1,000 principal amount of 2029 Convertible Notes which is equivalent to a conversion price of approximately $83.44 per share of our common stock, in each case subject to adjustment as set forth in 2029 Convertible Notes Indenture (such amendments, the “Amendments”). The 2029 Convertible Notes are convertible into cash, shares of our common stock, or a combination of cash and shares of common stock, at our election. The other terms of the 2029 Convertible Notes remained substantially unchanged. The amendment was treated as an extinguishment of the original debt and an issuance of the new debt, in which a debt extinguishment loss of $30.3 million was recognized in other income, net in the consolidated statements of operations during the year ended June 30, 2025.

[0001375365-25-000027:notes:257]
Special interest will accrue on the 2029 Convertible Notes in the circumstances and at the rates described in the 2029 Convertible Notes Indenture. The debt issuance costs are amortized to interest expense.

[0001375365-25-000027:notes:258]
Holders may convert their 2029 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2024, if the last reported sale price per share of our common stock exceeds 130% of the conversion price for each of at least 20 trading days during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on our common stock, as described in the 2029 Convertible Notes Indenture; (4) if we call such notes for redemption; and (5) at any time from, and including, September 1, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-25-000027:notes:259]
If we undergo a fundamental change (as defined in the 2029 Convertible Notes Indenture), subject to certain conditions, holders may require us to repurchase for cash all or any portion of their 2029 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2029 Convertible Notes to be repurchased, plus any accrued and unpaid special interest and additional interest, if any, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if we issue a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2029 Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-25-000027:notes:260]
The 2029 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at our option at any time, and from time to time, on or after March 1, 2027 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of our common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the notes to be redeemed, plus accrued and unpaid special and additional interest, if any, to, but excluding, the redemption date.

[0001375365-25-000027:notes:261]
The 2029 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2029 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2029 Convertible Notes.

[0001375365-25-000027:notes:262]
The 2029 Convertible Notes are senior unsecured obligations for us and rank senior in right of payment to all of our existing and future senior unsecured indebtedness, and senior to any future subordinated indebtedness. As of June 30, 2025, none of the conditions permitting the holders of the 2029 Convertible Notes to convert their notes early had been met.

[0001375365-25-000027:notes:263]
We accounted for the issuance of the 2029 Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

[0001375365-25-000027:notes:264]
The carrying value of the 2029 Convertible Notes, net of unamortized issuance costs of $21.3 million, was $1,703.7 million as of June 30, 2025. Interest expense related to the amortization of debt issuance costs was $3.4 million and interest was $22.0 million for the year ended June 30, 2025. The effective interest rate is 3.86%. For the year ended June 30, 2024, the effective interest rate was 0.34%, and the interest expense related to the amortization of debt issuance costs was $1.9 million.

[0001375365-25-000027:notes:265]
In February 2024, in connection with the issuance of the Original 2029 Convertible Notes, we entered into privately negotiated capped call transactions. These capped call instruments featured an initial strike price of $134.14 and a cap price of $195.10 per share, subject to adjustment. For accounting purposes, the capped call transactions were treated as separate equity-classified instruments, not embedded derivatives, and were recorded in stockholders’ equity at a cost of $142.1 million. On February 12, 2025, in connection with the Amendments, we also entered into agreements to amend certain terms of the privately negotiated capped call transactions (collectively and as amended, the “2029 Capped Call Transactions”) originally entered into with certain financial institutions (the “2029 Capped Call Counterparties”) on February 22, 2024. The amendments, among other things, make certain adjustments to the economic terms of the capped call transactions, including the strike price and cap price. The cap price, after giving effect to the amendments, is initially $94.17 per share of our common stock, and is subject to certain adjustments under the terms of the amended capped calls. The number of shares underlying the Capped Calls increased from 7.455 to 11.984 per $1,000 principal amount of 2029 Convertible Notes.

[0001375365-25-000027:notes:266]
The 2029 Capped Call Transactions are expected generally to reduce the potential dilution to our common stock upon conversion of the 2029 Convertible Notes and/or offset any potential cash payments we are required to make in excess of the principal amount of the 2029 Convertible Notes, as the case may be, with such reduction and/or offset, in each case subject to a cap.

[0001375365-25-000027:notes:267]
The amendment to the 2029 Capped Call Transactions did not change the recognition of the 2029 Capped Call Transactions as shareholders’ equity and did not result in any incremental value requiring recognition. The amended 2029 Convertible Notes and the amended 2029 Capped Call Transactions have been integrated for tax purposes. Accordingly, the premiums paid for the purchases of the Capped Calls are deductible for income tax purposes over the term of the Notes. A reduction of deferred tax assets of $18.5 million were recorded in stockholders’ equity to reflect the tax impact of the extinguishment and re-issuance of the 2029 Convertible Notes and the capped call transactions.

[0001375365-25-000027:notes:268]
2028 Convertible Notes

[0001375365-25-000027:notes:269]
On February 20, 2025, we issued $700.00 million aggregate principal amount of our 2.25% Convertible Senior Notes due 2028 (the “2028 Convertible Notes”) pursuant to an indenture by and between us and U.S. Bank Trust Company, National Association, as trustee (the “2028 Convertible Notes Indenture”). We incurred $16.3 million of issuance costs and fees payable to the placement agents. The 2028 Convertible Notes will mature on July 15, 2028, unless earlier repurchased, redeemed or converted.

[0001375365-25-000027:notes:270]
The 2028 Convertible Notes bear interest from February 20, 2025 at an annual rate of 2.25%, payable semi-annually in arrears on each January 15 and July 15, beginning on July 15, 2025. The 2028 Convertible Notes are convertible into cash, shares of our common stock, or a combination of cash and shares of our common stock, at our election, at an initial conversion rate of 16.3784 shares of our common stock per $1,000 principal amount of 2028 Convertible Notes, which is equivalent to an initial conversion price of approximately $61.06 per share of our common stock. The conversion rate is subject to customary adjustments for certain events as described in the 2028 Convertible Notes Indenture. We may pay special interest, if any, at its election as the sole remedy relating to a failure to comply with its reporting obligations and will be obligated to pay additional interest, if any, under the circumstances set forth in the 2028 Convertible Notes Indenture.

[0001375365-25-000027:notes:271]
Holders may convert their 2028 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on June 30, 2025, if the last reported sale price per share of our common stock exceeds 130% of the conversion price for each of at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “2028 Convertible Note measurement period”) in which the trading price per $1,000 principal amount of 2028 Convertible Notes for each trading day of the 2028 Convertible Note measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on our common stock, as described in the 2028 Convertible Notes Indenture; (4) if we call the 2028 Convertible Notes for redemption; and (5) at any time from, and including, January 15, 2028 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-25-000027:notes:272]
If we undergoes a fundamental change (as defined in the 2028 Convertible Notes Indenture), subject to certain conditions, holders may require us to repurchase for cash all or any portion of their 2028 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2028 Convertible Notes to be repurchased, plus any accrued and unpaid interest, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if we issue a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2028 Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-25-000027:notes:273]
The 2028 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at our option at any time, and from time to time, on or after March 1, 2026 and on or before the 20th scheduled trading day immediately before the maturity date, but only if the last reported sale price per share of our common stock exceeds 150% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the 2028 Convertible Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date.

[0001375365-25-000027:notes:274]
The 2028 Convertible Notes have customary provisions relating to the occurrence of “events of default” (as defined in the 2028 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2028 Convertible Notes.

[0001375365-25-000027:notes:275]
The 2028 Convertible Notes are general unsecured obligations for us and rank senior in right of payment to all of our existing and future senior unsecured indebtedness, and senior to any future subordinated indebtedness. As of June 30, 2025, none of the conditions permitting the holders of the 2028 Convertible Notes to convert their notes early had been met.

[0001375365-25-000027:notes:276]
We accounted for the issuance of the 2028 Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

[0001375365-25-000027:notes:277]
The carrying value of the 2028 Convertible Notes, net of unamortized issuance costs of $14.6 million, was $685.4 million as of June 30, 2025. Interest expense related to the amortization of debt issuance costs was $1.7 million and for interest was $5.7 million for the year ended June 30, 2025. The effective interest rate is 2.97%.

[0001375365-25-000027:notes:278]
2030 Convertible Notes

[0001375365-25-000027:notes:279]
On June 23, 2025, we issued $2,300.0 million aggregate principal amount of 2030 Convertible Notes which included $300.0 million exercise in full of the overallotment option. We received net proceeds from the offering of approximately $2,256.0 million. We used approximately $182.2 million of the net proceeds to fund the cost of entering into the Capped Call Transactions described below. In addition, we used approximately $200.0 million of the net proceeds to repurchase 4,891,171 shares of its common stock, $0.001 par value per share from certain purchasers of the Convertible Notes (refer to Note 11, “Stock-based Compensation and Stockholders’ Equity” in the notes to the consolidated financial statements for further details).

[0001375365-25-000027:notes:280]
The 2030 Convertible Notes will mature on June 15, 2030, unless earlier redeemed, repurchased or converted in accordance with their terms prior to such date. Prior to the close of business on the business day immediately preceding December 17, 2029, the 2030 Convertible Notes will be convertible only upon the satisfaction of certain conditions and during certain periods, and on and after December 17, 2029, at any time prior to the close of business on the second scheduled trading day immediately preceding the maturity date, the 2030 Convertible Notes will be convertible regardless of these conditions. We will settle conversions by paying or delivering, as applicable, cash, shares of our common stock or a combination of cash and shares of the our common stock at the our election.

[0001375365-25-000027:notes:281]
The 2030 Convertible Notes will not bear regular interest, and the principal amount of the note will not accrete. However, special interest and additional interest, if any, will accrue under the circumstances and at the rates set forth in the Indenture. The 2030 Convertible Notes will be convertible, at our election, into cash, shares of our common stock, or a combination of both, based on the applicable conversion rate at the time of conversion. The 2030 Convertible Notes will constitute senior, unsecured obligations for us and will rank equally in right of payment with our existing and future senior unsecured indebtedness, including its 2028 and 2029 convertible senior notes. The 2030 Convertible Notes were not eligible for conversion as of June 30, 2025.

[0001375365-25-000027:notes:282]
Holders may convert their 2030 Convertible Notes at their option only in the following circumstances: (1) during any calendar quarter commencing after the calendar quarter ending on September 30, 2025, if the last reported sale price per share of our common stock exceeds 130% of the conversion price for each of at least 20 trading days during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any five consecutive trading day period (such five consecutive trading day period, the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on our common stock, as described in the Indenture; (4) if we call such notes for redemption; and (5) at any time from, and including, December 17, 2029 until the close of business on the second scheduled trading day immediately before the maturity date irrespective of the circumstances in (1) - (4) above.

[0001375365-25-000027:notes:283]
The initial conversion rate is 18.1154 shares per $1,000 principal amount of 2030 Convertible Notes, which represents an initial conversion price of approximately $55.20 per share, and is subject to adjustment in accordance with the terms of the Indenture.

[0001375365-25-000027:notes:284]
If we undergoes a fundamental change (as defined in the 2030 Convertible Notes Indenture), subject to certain conditions, holders may require us to repurchase for cash all or any portion of their 2030 Convertible Notes, at a fundamental change repurchase price equal to 100% of the principal amount of the 2030 Convertible Notes to be repurchased, plus any accrued and unpaid interest, up to, but excluding, the fundamental change repurchase date. In addition, following certain corporate events or if we issue a notice of redemption, it will, under certain circumstances, increase the conversion rate for holders who elect to convert their 2030 Convertible Notes in connection with such corporate event or during the relevant redemption period.

[0001375365-25-000027:notes:285]
The 2030 Convertible Notes are redeemable, in whole or in part (subject to certain limitations), for cash at our option at any time, and from time to time, on or after June 15, 2028 and on or before the 20th scheduled trading day immediately before the maturity date, but only if (i) the 2030 Convertible Notes are “freely tradable” (as defined in the 2030 Convertible Notes Indenture), and all accrued and unpaid additional interest, if any, has been paid, as of the date we send the related redemption notice and (ii) the last reported sale price per share of our common stock exceeds 130% of the conversion price for a specified period of time. The redemption price will be equal to the principal amount of the 2030 Convertible Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date.

[0001375365-25-000027:notes:286]
The 2030 Convertible Notes have customary provisions relating to the occurrence of “event of default” (as defined in the 2030 Convertible Notes Indenture). The occurrence of such events of default may result in the acceleration of all amounts due under the 2030 Convertible Notes.

[0001375365-25-000027:notes:287]
We accounted for the issuance of the 2030 Convertible Notes as a single liability measured at its amortized cost, as no other embedded features require bifurcation and recognition as derivatives.

[0001375365-25-000027:notes:288]
The carrying value of the 2030 Convertible Notes, net of unamortized issuance costs of $43.9 million, was $2,256.1 million as of June 30, 2025. Interest expense related to the amortization of debt issuance costs was $0.1 million for the year ended June 30, 2025. The effective interest rate is 0.39%.

[0001375365-25-000027:notes:289]
In connection with the 2030 Convertible Notes, we entered into privately negotiated capped call transactions (collectively, the “2030 Capped Call Transactions”) with certain financial institutions (the “2030 Capped Call Counterparties”). The 2030 Capped Call Transactions are expected generally to reduce potential dilution to holders of our common stock upon any conversion of the 2030 Convertible Notes and/or offset any potential cash payments we are required to make in excess of the principal amount of such converted 2030 Convertible Notes, as the case may be, with such reduction and/or offset subject to a cap. The cap price of the 2030 Capped Call Transactions is initially $81.78 per share of common stock, representing a premium of 100% above the last reported sale price of $40.89 per share of common stock on June 23, 2025, and is subject to certain adjustments under the terms of the 2030 Capped Call Transactions.

[0001375365-25-000027:notes:290]
The 2030 Capped Call Transactions will not affect any holder’s rights under the 2030 Convertible Notes. Holders of the 2030 Convertible Notes will not have any rights with respect to the 2030 Capped Call Transactions. As these transactions meet certain accounting criteria, the 2030 Capped Call Transactions of $182.2 million are recorded in stockholders’ equity and are not accounted for as derivatives. The 2030 Capped Call Transactions have been integrated for tax purposes. Accordingly, the premiums paid for the purchases of the 2030 Capped Call Transactions are deductible for income tax purposes over the term of the 2030 Convertible Notes, subject to limitations. Deferred tax assets of $43.0 million were recorded in stockholders' equity to reflect the tax impact of the issuance of the 2030 Convertible Notes and the 2030 Capped Call Transactions.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001375365-25-000027:notes:291]
Note 9.                 Leases

[0001375365-25-000027:notes:292]
We lease offices, warehouses and other premises, vehicles, and certain equipment under non-cancelable operating leases. Operating lease expense recognized, and supplemental cash flow information related to operating leases for the years ended June 30, 2025, 2024, and 2023 were as follows (in thousands):

[0001375365-25-000027:notes:293]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Operating lease expense (including expense for lease agreements with related parties of $742, $450, and $561 for the years ended June 30, 2025, 2024, and 2023, respectively) | $ | 22,977 |  |  | $ | 9,983 |  |  | $ | 8,299 |  |
| Cash payments for operating leases (including payments to related parties of $726, $406, and $524 for the years ended June 30, 2025, 2024, and 2023 , respectively) | $ | 17,849 |  |  | $ | 9,343 |  |  | $ | 8,275 |  |
| New operating lease assets obtained in exchange for operating lease liabilities | $ | 276,170 |  |  | $ | 32,581 |  |  | $ | 3,197 |  |

[0001375365-25-000027:notes:294]
During the years ended June 30, 2025, 2024 and 2023, our costs related to short-term lease arrangements for real estate and non-real estate assets were immaterial. Variable lease payments expensed in the years ended June 30, 2025, 2024, and 2023 were $3.4 million, $2.3 million, and $1.8 million, respectively.

[0001375365-25-000027:notes:295]
As of June 30, 2025 and June 30, 2024, the Operating lease ROU assets recorded within other assets on the consolidated balance sheets were $293.7 million and $34.6 million, respectively.

[0001375365-25-000027:notes:296]
As the interest rate in the lease contract is typically not readily available, we estimate the incremental borrowing rate considering credit notching approach based on information available at lease commencement. As of June 30, 2025, the weighted average remaining lease term for operating leases was 9.1 years and the weighted average discount rate was 5.8%. As of June 30, 2024, the weighted average remaining lease term for operating leases was 4.7 years and the weighted average discount rate was 5.1%. The short-term portion of the lease liability is included in accrued liabilities and the long-term portion of the lease liability is included in other long-term liabilities on the consolidated balance sheets.

[0001375365-25-000027:notes:297]
In June 2024, we entered into a lease agreement for a 21 megawatt (“MW”) data center co-location space located in Vernon, California (the “Data Center Space”) that will expire on October 31, 2035. We do not have an option to extend (or to terminate) the lease. The lease agreement consists of three tranches, with the first tranche of 6 MW having commenced on January 24, 2025, and the second tranche of 9 MW commenced on May 12, 2025 and the third tranche of 6 MW expected to commence in October 2025. The Data Center Space lease has escalating base rent due to base rate ($/MW/Month) increase in every 12 months from service commencement date. During the first twelve months of initial term, we have no obligation to pay base rent in excess of base rent ramp maximum amount. The ROU asset and lease liability associated with the commencement of three tranches totaling $211.9 million, were recorded during the year ended June 30, 2025. The lease agreement includes variable lease payments related to power consumption charges. Variable lease payments not dependent on a rate or index associated with our leases are recognized when the event, activity, or circumstance in the lease agreement on which those payments are assessed as probable. Variable lease payments are presented as operating expenses in the consolidated statement of operations.

[0001375365-25-000027:notes:298]
Simultaneously, we entered into a sublicense agreement with an unrelated party to sublease the entire space in Vernon, California (the “Sublicense”). The Sublicense term coincides with our Data Center Space lease. We accounted for the lease as an operating lease and the sublicense as a sublease under Accounting Standards Codification Topic 842, Leases. The Sublicense did not relieve our original obligation under the Data Center Space lease, and therefore we did not adjust the operating lease ROU asset and related liability. Sublicense income is recognized on a straight-line basis and the rental income is included in other income, net on the consolidated statements of operations. For the year ended June 30, 2025, we recorded $8.0 million rental income. As of June 30, 2025, the future total minimum sublicense receipts expected to be received are as follows (in thousands):

[0001375365-25-000027:notes:299]
| Fiscal Year: |  | Future minimum sublicense receipts(1) |
| 2026 |  | $ | 24,684 |  |
| 2027 |  | 27,459 |  |
| 2028 |  | 28,255 |  |
| 2029 |  | 29,132 |  |
| 2030 |  | 30,006 |  |
| 2031 and beyond |  | 169,980 |  |
| Total sublicense receipts - Lessor |  | $ | 309,516 |  |

[0001375365-25-000027:notes:300]
(1) The table does not include amounts pertaining to leases that have not yet commenced.

[0001375365-25-000027:notes:301]
The future undiscounted fixed non-cancelable payment obligation and future minimum sublicense receipts pertaining to the remaining tranche that has not yet commenced as of June 30, 2025 is approximately $117.7 million and $124.8 million, respectively.

[0001375365-25-000027:notes:302]
We hold an equity investment of $92.5 million in the sub-licensee, which is classified under investments in privately held companies and recorded in other assets on the consolidated balance sheets. The sub-licensee does not meet the criteria of a related party. Additionally, the sub-licensee has been our customer, and we concluded that equity investment agreements and sub-licensing agreement are separate from revenue contracts as all transactions have been recorded at the respective fair values.

[0001375365-25-000027:notes:303]
Additionally, the warehouse lease in San Jose, California commenced on May 1, 2025 for 66 months, expiring in October, 2030. In connection with this lease, we recorded $14.3 million ROU asset and lease liability to the consolidated balance sheets as of June 30, 2025.

[0001375365-25-000027:notes:304]
Maturities of operating lease liabilities under non-cancelable operating lease arrangements as of June 30, 2025, were as follows (in thousands):

[0001375365-25-000027:notes:305]
| Fiscal Year: |  | Maturities of operating leases(1) |
| 2026 |  | $ | 39,846 |  |
| 2027 |  | 43,938 |  |
| 2028 |  | 43,218 |  |
| 2029 |  | 43,635 |  |
| 2030 |  | 44,866 |  |
| 2031 and beyond |  | 182,932 |  |
| Total future lease payments |  | 398,435 |  |
| Less: Imputed interest |  | (96,878) |  |
| Present value of operating lease liabilities |  | 301,557 |  |
| Less: Current portion |  | (21,189) |  |
| Long-term portion of operating lease liabilities |  | $ | 280,368 |  |

[0001375365-25-000027:notes:306]
Related party leases

[0001375365-25-000027:notes:307]
We have entered into lease agreements with related parties. See Note 10, “Related Party Transactions” in the notes to the consolidated financial statements for further discussion.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001375365-25-000027:notes:308]
Note 10.                 Related Party Transactions

[0001375365-25-000027:notes:309]
We have a variety of business relationships with Ablecom and Compuware, both of which are Taiwan-based corporations. Both Ablecom and Compuware are a major contract manufacturer for us and Compuware is also a distributor of our products. Ablecom’s Chief Executive Officer, Steve Liang, is the brother of Charles Liang, our President, Chief Executive Officer and Chairman of the Board. Steve Liang and his family members owned approximately 35.0% of Ablecom’s stock and Charles Liang and his spouse, Sara Liu, who is also an officer and director for us, collectively owned approximately 10.5% of Ablecom’s capital stock as of June 30, 2025. Bill Liang, a brother of both Charles Liang and Steve Liang, is a member of the Board of Directors of Ablecom. Bill Liang is also the Chief Executive Officer of Compuware, Chairman of Compuware’s Board of Directors and a holder of equity interest in Compuware. Steve Liang is also a member of Compuware’s Board of Directors and is an equity holder of Compuware. Neither Charles Liang nor Sara Liu own any capital stock of Compuware and we do not own any of Ablecom or Compuware’s capital stock. In addition, a sibling of Yih-Shyan (Wally) Liaw, who is our Senior Vice President, Business Development and a director of ours, owns approximately 11.7% of Ablecom’s capital stock and 8.7% of Compuware’s capital stock.

[0001375365-25-000027:notes:310]
In October 2018, our Chief Executive Officer, Charles Liang, personally borrowed approximately $12.9 million from Chien-Tsun Chang, the spouse of Steve Liang. The loan is unsecured, has no maturity date and bore interest at 0.8% per month for the first six months, increased to 0.85% per month through February 28, 2020, and reduced to 0.25% per month effective March 1, 2020. The loan was originally made at Mr. Liang’s request to provide funds to repay margin loans to two financial institutions, which loans had been secured by shares of our common stock that he held. The lenders called the loans in October 2018, following the suspension of our common stock from trading on Nasdaq in August 2018 and the decline in the market price of our common stock in October 2018. As of June 30, 2025 and June 30, 2024, the amount due on the unsecured loan (including principal and accrued interest) was approximately $16.8 million and $16.4 million.

[0001375365-25-000027:notes:311]
Dealings with Ablecom

[0001375365-25-000027:notes:312]
We have entered into a series of agreements with Ablecom, including multiple product development, production and service agreements, credit agreements, product manufacturing agreements, manufacturing services agreements and lease agreements for warehouse space.

[0001375365-25-000027:notes:313]
Under these agreements, we outsource to Ablecom a portion of its design activities and a significant part of its server chassis manufacturing as well as an immaterial portion of other components. Ablecom manufactured approximately 95.4%, 93.6%, and 91.9% of the chassis purchased by us during fiscal years 2025, 2024, and 2023, respectively. With respect to design activities, Ablecom generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Ablecom for the design and engineering services, and further agree to pay Ablecom for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling.

[0001375365-25-000027:notes:314]
With respect to the manufacturing aspects of the relationship, Ablecom purchases most of the materials needed to manufacture the chassis from third parties and we provide certain components used in the manufacturing process (such as power supplies) to Ablecom through consignment or sales transactions. Ablecom uses these materials and components to manufacture the completed chassis and then sell them back to us. For the components purchased from us, Ablecom sells the components back to us at a price equal to the price at which we sold the components to Ablecom. There is no revenue recognized by us from these transactions. We and Ablecom frequently review and negotiate the prices of the chassis we purchase from Ablecom. In addition to inventory purchases, we also incur other costs associated with design services, tooling and other miscellaneous costs from Ablecom.

[0001375365-25-000027:notes:315]
Our exposure to financial loss as a result of our involvement with Ablecom is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Ablecom on June 30, 2025 and 2024 were $30.6 million and $58.8 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Ablecom, or any losses that the equity holders of Ablecom may suffer. Since Ablecom manufactures substantially all the chassis that we incorporate into its products, if Ablecom were to suddenly be unable to manufacture chassis for us, our business could suffer if we are unable to quickly qualify substitute suppliers who can supply high-quality chassis to us in volume and at acceptable prices. We have extended a $10.0 million trade credit line with a net 30 days payment terms to Ablecom through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000027:notes:316]
Dealings with Compuware

[0001375365-25-000027:notes:317]
We appointed Compuware as a non-exclusive authorized distributor of our products in Taiwan, China, and Australia. Compuware assumes the responsibility of installing our products at the site of the end customer, if required, and administers customer support in exchange for a discount from our standard price for its purchases. From time to time, Compuware acts as a sales representative for us in exchange for a fee that is based on a percentage of net sales generated from customers introduced to us. The fee structure for Compuware is comparable to the fee structure offered to other sales representatives in the same geographic region.

[0001375365-25-000027:notes:318]
We also have entered into a series of agreements with Compuware, including multiple product development, production and service agreements, product manufacturing agreements, and lease agreements for office space. We have extended a $65.0 million trade credit line with a net 60 days payment terms to Compuware through a credit agreement that outlines the terms and conditions governing their business dealings.

[0001375365-25-000027:notes:319]
Under these agreements, we outsource to Compuware a portion of its design activities and a significant part of its power supplies manufacturing as well as an immaterial portion of other components. With respect to design activities, Compuware generally agrees to design certain agreed-upon products according to our specifications, and further agrees to build the tools needed to manufacture the products. We pay Compuware for the design and engineering services, and further agrees to pay Compuware for the tooling. We retain full ownership of any intellectual property resulting from the design of these products and tooling. With respect to the manufacturing aspects of the relationship, Compuware purchases most of the materials needed to manufacture the power supplies from outside markets and uses these materials to manufacture the products and then sell those products to us. We and Compuware frequently review and negotiate the prices of the power supplies we purchase from Compuware.

[0001375365-25-000027:notes:320]
Compuware also manufactures motherboards, backplanes and other components used on printed circuit boards for us. We sell to Compuware most of the components needed to manufacture the above products. Compuware uses the components to manufacture the products and then sells the products back to us at a purchase price equal to the price at which we sold the components to Compuware, plus a “manufacturing value added” fee and other miscellaneous material charges and costs, including overhead and labor. There is no revenue recognized by us from these transactions. We and Compuware frequently review and negotiate the amount of the “manufacturing value added” fee that will be included in the price of the products we purchase from Compuware. In addition to the inventory purchases, we also incur costs associated with design services, tooling assets, and miscellaneous costs.

[0001375365-25-000027:notes:321]
Our exposure to financial loss as a result of our involvement with Compuware is limited to potential losses on our purchase orders in the event of an unforeseen decline in the market price and/or demand of our products such that we incur a loss on the sale or cannot sell the products. Non-cancelable purchase orders from us to Compuware on June 30, 2025 and 2024 were $118.3 million and $93.5 million, respectively, effectively representing the exposure to financial loss. We do not directly or indirectly guarantee any obligations of Compuware, or any losses that the equity holders of Compuware may suffer.

[0001375365-25-000027:notes:322]
During the fiscal year ended June 30, 2025, we agreed to pay a finder’s fee of approximately $1.6 million which represents 1% of the net sales from a customer referred to us by Compuware. This finder’s fee is consistent with market terms given Compuware's limited role and industry margins. The agreement doesn’t require us to absorb losses or provide subordinated financing.

[0001375365-25-000027:notes:323]
Dealings with Leadtek Research Inc.

[0001375365-25-000027:notes:324]
In October 2023, Ablecom and Compuware acquired an approximately 30% interest in Leadtek Research Inc. (“Leadtek”), a Taiwan company specializing in providing professional graphics cards and workstation solutions (the “Leadtek Investment”). Prior to the Leadtek Investment, none of our related parties had direct or indirect material interests in any transactions in which we were a participant with Leadtek. Commencing with the closing of the Leadtek Investment, Steve Liang and Bill Liang have served as two of the seven members of the Leadtek board of directors. At the time of Leadtek Investment, Leadtek was, and it continues to be, our authorized reseller. During the fiscal years ended 2025 and 2024, we engaged in transactions whereby we sold $0.7 million and $1.4 million of servers to Leadtek, and purchased $0.5 million and $2.1 million of graphic cards from Leadtek, respectively.

[0001375365-25-000027:notes:325]
Dealings with Investment in a Corporate Venture

[0001375365-25-000027:notes:326]
In October 2016, we entered into agreements pursuant to which we contributed certain technology rights in connection with an investment in a privately-held company (the “Corporate Venture”) located in China to expand our presence in China. The Corporate Venture is 30% owned by us and 70% owned by another company in China. The transaction was closed in the third quarter of the fiscal year ended June 30, 2017, and the investment is accounted for using the equity method. As such, the Corporate Venture is also a related party.

[0001375365-25-000027:notes:327]
We monitor the investment for events or circumstances indicative of potential impairment and make appropriate reductions in carrying values if we determine that an impairment charge is required. As of June 30, 2025, we concluded the Corporate Venture would be divested in the fiscal year ending June 2026. We performed an impairment analysis on this investment and concluded the remaining carrying value of the equity investment of $6.7 million was impaired as of June 30, 2025. As of June 30, 2024, the carrying value of the equity investment of $4.6 million was recorded in other assets on the consolidated balance sheets, and was not impaired as of June 30, 2024.

[0001375365-25-000027:notes:328]
We sold products worth $11.0 million, $21.8 million, and $24.2 million to the Corporate Venture in the fiscal years 2025, 2024, and 2023, respectively, and our share of intra-entity profits on the products that remained unsold by the Corporate Venture as of June 30, 2025 and June 30, 2024 have been eliminated and have reduced the carrying value of our investment in the Corporate Venture prior to impairment write-off. To the extent that the elimination of intra-entity profits reduces the investment balance below zero, such amounts are recorded within accrued liabilities. We had less than $0.1 million and $5.1 million due from the Corporate Venture in accounts receivable, net as of June 30, 2025 and 2024, respectively.

[0001375365-25-000027:notes:329]
Other Transactions

[0001375365-25-000027:notes:330]
For the fiscal year ended June 30, 2025, we had immaterial chargebacks from Green Earth Liang’s Inc. (“Green Earth”), an entity affiliated with our Chief Executive Officer. As of June 30, 2025, there was no balance due to and from Green Earth. For the fiscal year ended June 30, 2024, we had immaterial sales to and purchases from Green Earth. As of June 30, 2024, the amounts due to and from Green Earth were immaterial.

[0001375365-25-000027:notes:331]
For the fiscal year ended June 30, 2025, we had no transactions directly or indirectly to Aeon Lighting Technology Inc. (“Aeon Lighting”). Aeon Lighting is a company which is owned more than 10% by James Liang, a brother of our Chief Executive Officer. James Liang is also a director of Aeon Lighting and serves as the Chief Executive Officer of such entity. For the fiscal year ended June 30, 2024, we had immaterial sales of products indirectly to Aeon Lighting. As of June 30, 2025 and 2024, amount due from Aeon Lighting were none and immaterial, respectively.

[0001375365-25-000027:notes:332]
In June 2025, we invested $6.0 million and acquired an approximately 11% interest in Ampera, Inc. (“Ampera”), a clean energy technology company focused on the development and deployment of advanced battery storage solutions. This investment is accounted for as a non-marketable security, see Note 3, “Non-marketable Equity Securities”. We represent approximately 33% on the board of directors as we have one board of director seat on a board of three. With the combination of our 11% equity interest and board representation, we have the ability to exercise significant influence over the operating and financial policies of Ampera. For the fiscal year ended June 30, 2025, we had no sale or purchases transactions with Ampera. As of June 30, 2025, there was no balance due to and from Ampera.

[0001375365-25-000027:notes:333]
We had the following balances related to transactions with our related parties as of the fiscal years ended June 30, 2025, 2024, and 2023 (in thousands):

[0001375365-25-000027:notes:334]
|  | Accounts receivable |  | Other receivables (1) |  | Accounts payable |  | Accrued liabilities (2) |  | Other long-term liabilities (3) |
| Ablecom |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 1 |  |  | $ | 1,059 |  |  | $ | 55,460 |  |  | $ | 753 |  |  | $ | 114 |  |
| Year Ended June 30, 2024 | $ | 1 |  |  | $ | 1,927 |  |  | $ | 98,629 |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | 2 |  |  | $ | 2,841 |  |  | $ | 35,711 |  |  | $ | 1,230 |  |  | $ | — |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 285 |  |  | $ | 12,686 |  |  | $ | 74,292 |  |  | $ | 291 |  |  | $ | 494 |  |
| Year Ended June 30, 2024 | $ | 142 |  |  | $ | 10,012 |  |  | $ | 66,436 |  |  | $ | 170 |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | 3,528 |  |  | $ | 24,891 |  |  | $ | 53,423 |  |  | $ | 12,787 |  |  | $ | — |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | 5,075 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | 1,943 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 77 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | 976 |  |  | $ | — |  |  | $ | 230 |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 393 |  |  | $ | 13,745 |  |  | $ | 129,752 |  |  | $ | 1,044 |  |  | $ | 608 |  |
| Year Ended June 30, 2024 | $ | 6,194 |  |  | $ | 11,939 |  |  | $ | 165,295 |  |  | $ | 170 |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | 5,473 |  |  | $ | 27,732 |  |  | $ | 89,134 |  |  | $ | 14,017 |  |  | $ | — |  |

[0001375365-25-000027:notes:335]
(1) Other receivables includes receivables from vendors included in prepaid expenses and other current assets.

[0001375365-25-000027:notes:336]
(2) Includes current portion of operating lease liabilities included in accrued liabilities.

[0001375365-25-000027:notes:337]
(3) Other long-term liabilities includes non-current portion of lease liabilities.

[0001375365-25-000027:notes:338]
Our results from transactions with our related parties for each of the fiscal years ended June 30, 2025, 2024, and 2023, are as follows (in thousands):

[0001375365-25-000027:notes:339]
|  | Net sales |  | Cost of sales |  | Research and development |  | Sales and marketing |  | Purchases of fixed assets |
| Ablecom |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 317 |  |  | $ | 321,866 |  |  | $ | 5,026 |  |  | $ | — |  |  | $ | 18,659 |  |
| Year Ended June 30, 2024 | $ | 11 |  |  | $ | 269,256 |  |  | $ | 4,513 |  |  | $ | — |  |  | $ | 11,990 |  |
| Year Ended June 30, 2023 | $ | 8 |  |  | $ | 167,801 |  |  | $ | 4,439 |  |  | $ | — |  |  | $ | 7,691 |  |
| Compuware |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 30,238 |  |  | $ | 328,258 |  |  | $ | 1,686 |  |  | $ | 1,649 |  |  | $ | 558 |  |
| Year Ended June 30, 2024 | $ | 46,618 |  |  | $ | 280,801 |  |  | $ | 1,377 |  |  | $ | — |  |  | $ | 163 |  |
| Year Ended June 30, 2023 | $ | 36,286 |  |  | $ | 216,961 |  |  | $ | 1,738 |  |  | $ | — |  |  | $ | 273 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 11,027 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | 21,806 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | 24,243 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 677 |  |  | $ | 534 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | 1,356 |  |  | $ | 2,079 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 42,259 |  |  | $ | 650,658 |  |  | $ | 6,712 |  |  | $ | 1,649 |  |  | $ | 19,217 |  |
| Year Ended June 30, 2024 | $ | 69,791 |  |  | $ | 552,136 |  |  | $ | 5,890 |  |  | $ | — |  |  | $ | 12,153 |  |
| Year Ended June 30, 2023 | $ | 60,537 |  |  | $ | 384,762 |  |  | $ | 6,177 |  |  | $ | — |  |  | $ | 7,964 |  |

[0001375365-25-000027:notes:340]
Our cash flow impact from transactions with our related parties for the fiscal years ended June 30, 2025, 2024, and 2023, are as follows (in thousands):

[0001375365-25-000027:notes:341]
|  | Changes in accounts receivable |  | Changes in prepaid expenses and other assets |  | Changes in accounts payable |  | Changes in accrued liabilities |  | Changes in other long-term liabilities |  | Cash payment for property, plant, and equipment |  | Unpaid property, plant, and equipment |
| Ablecom |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | — |  |  | $ | 868 |  |  | $ | (43,169) |  |  | $ | 753 |  |  | $ | 114 |  |  | $ | 17,119 |  |  | $ | 3,879 |  |
| Year Ended June 30, 2024 | $ | 1 |  |  | $ | 914 |  |  | $ | 62,918 |  |  | $ | (1,230) |  |  | $ | — |  |  | $ | 10,428 |  |  | $ | 2,339 |  |
| Year Ended June 30, 2023 | $ | — |  |  | $ | 1,975 |  |  | $ | (6,752) |  |  | $ | (2,301) |  |  | $ | — |  |  | $ | 7,498 |  |  | $ | 777 |  |
| Compuware |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | (143) |  |  | $ | (2,674) |  |  | $ | 7,856 |  |  | $ | 121 |  |  | $ | 494 |  |  | $ | 558 |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | 3,386 |  |  | $ | 14,879 |  |  | $ | 13,013 |  |  | $ | (12,617) |  |  | $ | (178) |  |  | $ | 197 |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | (3,124) |  |  | $ | (5,295) |  |  | $ | 8,531 |  |  | $ | (2,358) |  |  | $ | (321) |  |  | $ | 346 |  |  | $ | 33 |  |
| Corporate Venture |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 5,045 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | (3,132) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | 6,049 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Leadtek |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 899 |  |  | $ | — |  |  | $ | (230) |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2024 | $ | (976) |  |  | $ | — |  |  | $ | 230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Year Ended June 30, 2023 | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Year Ended June 30, 2025 | $ | 5,801 |  |  | $ | (1,806) |  |  | $ | (35,543) |  |  | $ | 874 |  |  | $ | 608 |  |  | $ | 17,677 |  |  | $ | 3,879 |  |
| Year Ended June 30, 2024 | $ | (721) |  |  | $ | 15,793 |  |  | $ | 76,161 |  |  | $ | (13,847) |  |  | $ | (178) |  |  | $ | 10,625 |  |  | $ | 2,339 |  |
| Year Ended June 30, 2023 | $ | 2,925 |  |  | $ | (3,320) |  |  | $ | 1,779 |  |  | $ | (4,659) |  |  | $ | (321) |  |  | $ | 7,844 |  |  | $ | 810 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001375365-25-000027:notes:342]
Note 11.               Stock-based Compensation and Stockholders’ Equity

[0001375365-25-000027:notes:343]
Preferred Stock

[0001375365-25-000027:notes:344]
We have 10,000,000 shares of undesignated preferred stock, $0.001 par value per share, authorized but not issued with rights and preferences determined by our Board of Directors at the time of issuance of such shares. As of June 30, 2025 and 2024, there were no shares of preferred stock issued and outstanding.

[0001375365-25-000027:notes:345]
Common Stock

[0001375365-25-000027:notes:346]
We may issue up to 1,000,000,000 shares of common stock, $0.001 par value per share. The holders of our common stock are entitled to one vote for each share held of record on all matters submitted to a vote of stockholders.

[0001375365-25-000027:notes:347]
Equity Incentive Plan

[0001375365-25-000027:notes:348]
On June 5, 2020, our stockholders approved the 2020 Equity and Incentive Compensation Plan (the “Original 2020 Plan”). The maximum number of shares available under the Original 2020 Plan was 50,000,000 plus 10,450,000 shares of common stock that remained available for future awards under the 2016 Equity Incentive Plan (the “2016 Plan”), at the time of adoption of the Original 2020 Plan. No other awards can be granted under the 2016 Plan and 72,460,000 shares of common stock remained reserved for outstanding awards issued under the 2016 Plan at the time of adoption of the Original 2020 Plan. On May 18, 2022, our stockholders approved an amendment and restatement of the Original 2020 Plan which, among other things, increased the number of shares available for award under the 2020 Plan by an additional 20,000,000 shares.

[0001375365-25-000027:notes:349]
On January 22, 2024, our stockholders approved a further amendment and restatement of the Original 2020 Plan (as amended and restated from time to time, the “2020 Plan”) which, among other things, further increased the number of shares available for award under the 2020 Plan by an additional 15,000,000 shares.

[0001375365-25-000027:notes:350]
On June 4, 2025, our stockholders approved a further amendment and restatement of the Original 2020 Plan (as amended and restated from time to time, the “2020 Plan”) which, among other things, further increased the number of shares available for award under the 2020 Plan by an additional 18,000,000 shares.

[0001375365-25-000027:notes:351]
Under the 2020 Plan, we can grant stock options, stock appreciation rights, restricted stock, RSUs, performance shares, performance units, dividend equivalents, and certain other awards, including those denominated or payable in, or otherwise based on, our common stock. The exercise price per share for incentive stock options granted to employees owning shares representing more than 10% of our outstanding voting stock at the time of grant cannot be less than 110% of the fair value of the underlying shares on the grant date. Nonqualified stock options and incentive stock options granted to all other persons are granted at a price not less than 100% of the fair value. Options generally expire ten years after the date of grant. Stock options and RSUs generally vest over four years; 25% at the end of one year and one sixteenth per quarter thereafter.

[0001375365-25-000027:notes:352]
As of June 30, 2025, we had 17,217,058 authorized shares available for future issuance under the 2020 Plan.

[0001375365-25-000027:notes:353]
Offerings of Common Stock

[0001375365-25-000027:notes:354]
On December 5, 2023, we completed a public offering of 24,158,050 shares of our common stock at $26.20 per share, with 23,151,050 shares sold by us and 1,007,000 shares sold by selling stockholders.

[0001375365-25-000027:notes:355]
We received net proceeds of approximately $582.8 million, after deducting underwriting discounts and commissions and offering expenses payable by us. We did not receive any proceeds from the sale of the shares of common stock by the selling stockholders.

[0001375365-25-000027:notes:356]
On March 22, 2024, we completed a public offering of 20,000,000 shares of our common stock at $87.50 per share. We received net proceeds of $1,731.5 million, after deducting underwriting discounts and commissions and offering expenses payable by us.

[0001375365-25-000027:notes:357]
Common Stock Repurchase and Retirement

[0001375365-25-000027:notes:358]
On August 3, 2022, after the expiration of a prior share repurchase program on July 31, 2022, a duly authorized subcommittee of our Board approved a new share repurchase program to repurchase shares of our common stock for up to $200 million at prevailing prices in the open market. The share repurchase program was effective until January 31, 2024 or until the maximum amount of common stock is repurchased, whichever occurred first. Under the common stock repurchase program, shares may be purchased from time to time in open market transactions, block trades, through plans established under the Securities Exchange Act Rule 10b5-1, or otherwise. The number of shares purchased and the timing of such purchases are based on working capital requirements, market and general business conditions, and other factors, including alternative investment opportunities.

[0001375365-25-000027:notes:359]
The share repurchase program was effective until January 31, 2024, at which time the remaining un-utilized portion of such program expired. No shares were repurchased under the share repurchase program during the fiscal year ended June 30, 2024.

[0001375365-25-000027:notes:360]
In June 2025, we repurchased 4,891,171 shares of our common stock for an aggregate purchase price of approximately $200.0 million. The repurchased shares were subsequently retired. The repurchase was conducted concurrently with our offering of the 2030 Convertible Notes, in privately negotiated transactions with certain purchasers of the 2030 Convertible Notes. The transactions were effected through one of the initial purchasers of the 2030 Convertible Notes or our affiliates, in each case, acting as our agent. The repurchase price was $40.89 per share, which represented the closing trading price of our common stock on June 23, 2025, the date on which the 2030 Convertible Notes were priced.

[0001375365-25-000027:notes:361]
This repurchase was conducted outside of a publicly announced repurchase plan or program, and was not made pursuant to a Rule 10b5-1 trading plan or under the Rule 10b-18 safe harbor. We have not adopted any publicly announced repurchase plans or programs, and no such plans were in effect during fiscal year 2025.

[0001375365-25-000027:notes:362]
Determining Fair Value

[0001375365-25-000027:notes:363]
The fair value of our RSUs are based on the closing market price of our common stock on the date of grant. We estimate the fair value of stock options granted using the Black-Scholes option pricing model. This fair value is then amortized ratably over the requisite service periods of the awards, which is generally the vesting period. The key inputs in using the Black-Scholes-option-pricing model were as follows:

[0001375365-25-000027:notes:364]
Expected Term—Our expected term represents the period that our stock-based awards are expected to be outstanding and was determined based on our historical experience.

[0001375365-25-000027:notes:365]
Expected Volatility—Expected volatility is based on our implied and historical volatility.

[0001375365-25-000027:notes:366]
Expected Dividend—The Black-Scholes valuation model calls for a single expected dividend yield as an input and the we  have no plans to pay dividends.

[0001375365-25-000027:notes:367]
Risk-Free Interest Rate—The risk-free interest rate used in the Black-Scholes valuation method is based on the United States Treasury zero coupon issues in effect at the time of grant for periods corresponding with the expected term of option.

[0001375365-25-000027:notes:368]
The fair value of stock option grants for the fiscal years ended June 30, 2025, 2024, and 2023 was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001375365-25-000027:notes:369]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Risk-free interest rate | 3.82% - 4.39% |  | 4.01% - 4.78% |  | 2.81% - 4.25% |
| Expected term | 3.00 years - 5.98 years |  | 3.00 years - 5.99 years |  | 6.07 years |
| Dividend yield | — | % |  | — | % |  | — | % |
| Volatility | 63.67% - 95.28% |  | 56.87% - 64.55% |  | 50.62% - 53.47% |
| Weighted-average fair value of options | $ | 26.94 |  |  | $ | 28.58 |  |  | $ | 6.21 |  |

[0001375365-25-000027:notes:370]
The following table shows total stock-based compensation expense included in the consolidated statements of operations for the fiscal years ended June 30, 2025, 2024, and 2023 (in thousands):

[0001375365-25-000027:notes:371]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Cost of sales | $ | 24,505 |  |  | $ | 15,864 |  |  | $ | 4,574 |  |
| Research and development | 195,444 |  |  | 114,895 |  |  | 30,736 |  |
| Sales and marketing | 37,784 |  |  | 21,195 |  |  | 4,599 |  |
| General and administrative | 56,719 |  |  | 79,553 |  |  | 14,524 |  |
| Stock-based compensation expense before taxes | 314,452 |  |  | 231,507 |  |  | 54,433 |  |
| Income tax impact | (75,562) |  |  | (92,810) |  |  | (18,106) |  |
| Stock-based compensation expense, net | $ | 238,890 |  |  | $ | 138,697 |  |  | $ | 36,327 |  |

[0001375365-25-000027:notes:372]
During the year ended June 30, 2025, stock-based compensation expense capitalized to our consolidated balance sheets was $0.5 million. During the year ended June 30, 2024 and 2023, there was no stock-based compensation expense capitalized to our consolidated balance sheets.

[0001375365-25-000027:notes:373]
Stock Option Activity

[0001375365-25-000027:notes:374]
2021 CEO Performance Award

[0001375365-25-000027:notes:375]
In March 2021, our Compensation Committee of the Board of Directors (the “Compensation Committee”) approved the grant of a stock option award for 10,000,000 shares of common stock to our CEO (the “2021 CEO Performance Stock Option”). As of June 30, 2025, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:

[0001375365-25-000027:notes:376]
| Annualized Revenue Milestone (in billions) |  | Achievement Status |  | Stock Price Milestone |  | Achievement Status |
| $4.0 |  | Achieved |  | $4.50 |  | Achieved (1) |
| $4.8 |  | Achieved |  | $6.00 |  | Achieved (2) |
| $5.8 |  | Achieved |  | $7.50 |  | Achieved (3) |
| $6.8 |  | Achieved |  | $9.50 |  | Achieved (4) |
| $8.0 |  | Achieved |  | $12.00 |  | Achieved (5) |

[0001375365-25-000027:notes:377]
(1) The vesting of the first tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option, representing one-fifth of such award, was certified by our Compensation Committee in August 2022.

[0001375365-25-000027:notes:378]
(2) The vesting of the second tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by our Compensation Committee in October 2022.

[0001375365-25-000027:notes:379]
(3) The vesting of the third tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by our Compensation Committee in January 2023.

[0001375365-25-000027:notes:380]
(4) The vesting of the fourth tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by our Compensation Committee in September 2023.

[0001375365-25-000027:notes:381]
(5) The vesting of the fifth tranche of 2,000,000 option shares under the 2021 CEO Performance Stock Option representing one-fifth of such award was certified by our Compensation Committee in February 2024.

[0001375365-25-000027:notes:382]
During the fiscal year ended June 30, 2025, we did not recognize compensation expense related to the 2021 CEO Performance Stock Option. During the fiscal year ended June 30, 2024, we recognized compensation expense related to the 2021 CEO Performance Stock Option of $0.7 million. As of June 30, 2025 and 2024, we had no unrecognized compensation cost related to the 2021 CEO Performance Stock Option.

[0001375365-25-000027:notes:383]
2023 CEO Performance Award

[0001375365-25-000027:notes:384]
In November 2023, the Compensation Committee approved the grant of a stock option award for 5,000,000 shares of common stock to our CEO (the “2023 CEO Performance Stock Option”). The 2023 CEO Performance Stock Option has five vesting tranches with a vesting schedule based entirely on the attainment of operational milestones (performance conditions) and market conditions, assuming (1) continued employment either as the CEO or in such capacity as agreed upon between our CEO and the Board and (2) service through each vesting date. Each of the five vesting tranches of the 2023 CEO Performance Stock Option will vest upon certification by the Compensation Committee that both (i) the market price milestone for such tranche, which begins at $45.00 per share for the first tranche and increases up to $110.00 per share thereafter (based on a 60 trading day average stock price), has been achieved, and (ii) any one of five operational milestones focused on total revenue, as reported under U.S. GAAP, have been achieved for the previous four consecutive fiscal quarters. Upon vesting and exercise, including the payment of the exercise price of $45.00 per share, prior to November 14, 2026, our CEO must hold shares that he acquires until November 14, 2026, other than those shares sold pursuant to a cashless exercise where shares are simultaneously sold to pay for the exercise price and any required tax withholding.

[0001375365-25-000027:notes:385]
The achievement status of the operational and stock price milestones as of June 30, 2025 was as follows:

[0001375365-25-000027:notes:386]
| Annualized Revenue Milestone (in billions)(1) |  | Achievement Status |  | Stock Price Milestone(1) |  | Achievement Status |
| $13.0 |  | Achieved (6) |  | $45 |  | Achieved (2) |
| $15.0 |  | Achieved (7) |  | $60 |  | Achieved (3) |
| $17.0 |  | Achieved (8) |  | $75 |  | Achieved (4) |
| $19.0 |  | Achieved (9) |  | $90 |  | Achieved (5) |
| $21.0 |  | Achieved (10) |  | $110 |  | Not yet achieved |

[0001375365-25-000027:notes:387]
(1) Under the terms of the 2023 CEO Performance Stock Option, the annualized revenue milestones and stock price milestones set forth in the table above must be achieved by December 31, 2028 and March 31, 2029, respectively.

[0001375365-25-000027:notes:388]
(2) On March 2, 2024, the Compensation Committee certified achievement of the $45 stock price milestone based upon the 60 trading day average stock price from November 29, 2023 through February 26, 2024.

[0001375365-25-000027:notes:389]
(3) On April 1, 2024, the Compensation Committee certified achievement of the $60 stock price milestone based upon the 60 trading day average stock price from December 15, 2023 through March 13, 2024.

[0001375365-25-000027:notes:390]
(4) On April 1, 2024, the Compensation Committee certified achievement of the $75 stock price milestone based upon the 60 trading day average stock price from January 4, 2024 through April 1, 2024.

[0001375365-25-000027:notes:391]
(5) On May 5, 2024, the Compensation Committee certified achievement of the $90 stock price milestone based upon the 60 trading day average stock price from January 31, 2024 through April 25, 2024.

[0001375365-25-000027:notes:392]
(6) On February 27, 2025, the Compensation Committee certified achievement of the $13.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of June 30, 2024.

[0001375365-25-000027:notes:393]
(7) On April 22, 2025, the Compensation Committee certified achievement of the $15.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of September 30, 2024.

[0001375365-25-000027:notes:394]
(8) On April 22, 2025, the Compensation Committee certified achievement of the $17.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of September 30, 2024.

[0001375365-25-000027:notes:395]
(9) On April 22, 2025, the Compensation Committee certified achievement of the $19.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of December 31, 2024.

[0001375365-25-000027:notes:396]
(10) On August 26, 2025, the Compensation Committee certified achievement of the $21.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of March 31, 2025.

[0001375365-25-000027:notes:397]
During the fiscal years ended June 30, 2025 and 2024, we recognized compensation expense related to the 2023 CEO Performance Stock Option of $13.4 million and $49.1 million. As of June 30, 2025, we had $5.5 million in unrecognized compensation cost related to the 2023 CEO Performance Stock Option. The unrecognized compensation cost as of June 30, 2025 is expected to be recognized over a period of 1.5 years.

[0001375365-25-000027:notes:398]
On the respective grant dates of each of the 2021 CEO Performance Award and the 2023 CEO Performance Award, a Monte Carlo simulation was used to determine for each tranche of each award (i) a fixed expense amount for such tranche and (ii) the future time when the market price milestone for such tranche was expected to be achieved, or its “expected market price milestone achievement time.” Separately, based on a subjective assessment of our future financial performance, each quarter, we will determine, using a Monte Carlo simulation, whether achievement is probable for each operational milestone that has not previously been achieved or deemed probable of achievement, and, if so, the future time when we expect to achieve that operational milestone, or its “expected operational milestone achievement time.” When we first determine that an operational milestone has become probable of being achieved, we will allocate the entire expense for the related tranche over the number of quarters between the grant date and the then-applicable “expected vesting time.” The “expected vesting time” at any given time is the later of (i) the expected operational milestone achievement time (if the related operational milestone has not yet been achieved) and (ii) the expected market price milestone achievement time (if the related market price milestone has not yet been achieved). We will immediately recognize a catch-up expense for all accumulated expenses from the respective grant date through the quarter in which the operational milestone was first deemed probable of being achieved. Each quarter thereafter, we will recognize the prorated portion of the then-remaining expense for the tranche based on the number of quarters between such quarter and the then-applicable expected vesting time, except that upon vesting of a tranche, all remaining expenses for that tranche will be immediately recognized.

[0001375365-25-000027:notes:399]
The following table summarizes stock option activity during the fiscal year ended June 30, 2025, under all plans:

[0001375365-25-000027:notes:400]
|  |  | OptionsOutstanding |  | WeightedAverageExercisePrice perShare |  | WeightedAverageGrant Date Fair Value |  | WeightedAverageRemainingContractualTerm(in Years) |  | AggregateIntrinsicValue(in thousands) |
| Balance as of June 30, 2024 |  | 35,443,550 |  |  | $ | 17.57 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Granted |  | 5,302,345 |  |  | $ | 41.34 |  |  | $ | 26.94 |  |  | — |  |  | $ | — |  |
| Exercised |  | (4,963,846) |  |  | $ | 5.05 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Forfeited/Cancelled |  | (933,916) |  |  | $ | 36.13 |  |  | $ | — |  |  | — |  |  | $ | — |  |
| Balance as of June 30, 2025 |  | 34,848,133 |  |  | $ | 22.47 |  |  | $ | — |  |  | 6.99 |  | $ | 988,321 |  |
| Options exercisable as of June 30, 2025 |  | 23,287,734 |  |  | $ | 15.12 |  |  | $ | — |  |  | 6.15 |  | $ | 802,643 |  |

[0001375365-25-000027:notes:401]
As of June 30, 2025, $221.3 million of unrecognized compensation cost related to stock options and CEO performance stock options is expected to be recognized over a weighted-average period of 2.65 years.

[0001375365-25-000027:notes:402]
For the fiscal year ended June 30, 2025, the tax benefit from options exercised was $28.3 million. The total pretax intrinsic value of options exercised during the fiscal years ended June 30, 2025, 2024, and 2023 was $182.9 million, $475.0 million, and $110.1 million, respectively. In fiscal year 2025, we withheld 765,888 shares upon the exercise of stock options with value equivalent to the sum of the aggregate exercise price for the total number of shares exercised plus the minimum amount we were required to withhold to satisfy our statutory tax withholding obligations upon such exercise. No shares were withheld from option exercises in fiscal years 2024 and 2023. Total payments to tax authorities to satisfy our minimum withholding obligations were $27.2 million in fiscal year 2025 and none in fiscal years 2024 and 2023. These payments are reflected as a financing activity within the consolidated statements of cash flows. Pursuant to the terms of the 2020 Plan, shares withheld in connection with net-share settlements are not added back to the 2020 Plan.

[0001375365-25-000027:notes:403]
Additional information regarding options outstanding as of June 30, 2025, is as follows:

[0001375365-25-000027:notes:404]
|  |  | Options Outstanding |  | Options Vested and Exercisable |
| Range ofExercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualTerm (Years) |  | Weighted-AverageExercisePrice PerShare |  | NumberExercisable |  | Weighted-AverageExercisePrice PerShare |
| $1.30 - $3.55 |  | 3,835,044 |  |  | 3.41 |  | $ | 2.60 |  |  | 3,754,804 |  |  | $ | 2.58 |  |
| $3.79 - $4.24 |  | 2,180,490 |  |  | 6.20 |  | $ | 3.97 |  |  | 1,678,060 |  |  | $ | 3.95 |  |
| $4.50 - $4.50 |  | 10,000,000 |  |  | 5.67 |  | $ | 4.50 |  |  | 10,000,000 |  |  | $ | 4.50 |  |
| $5.22 - $26.26 |  | 4,371,204 |  |  | 7.64 |  | $ | 12.37 |  |  | 1,989,440 |  |  | $ | 11.71 |  |
| $27.80 - $33.76 |  | 4,230,639 |  |  | 8.83 |  | $ | 31.79 |  |  | 1,055,280 |  |  | $ | 33.45 |  |
| $36.00 - $42.95 |  | 528,389 |  |  | 9.82 |  | $ | 36.01 |  |  | — |  |  | $ | — |  |
| $45.00 - $45.00 |  | 5,000,000 |  |  | 8.38 |  | $ | 45.00 |  |  | 4,000,000 |  |  | $ | 45.00 |  |
| $45.32 - $69.80 |  | 3,058,127 |  |  | 9.20 |  | $ | 52.74 |  |  | 389,520 |  |  | $ | 51.77 |  |
| $76.19 - $76.19 |  | 1,527,480 |  |  | 8.74 |  | $ | 76.19 |  |  | 391,450 |  |  | $ | 76.19 |  |
| $78.27 - $78.27 |  | 116,760 |  |  | 8.84 |  | $ | 78.27 |  |  | 29,180 |  |  | $ | 78.27 |  |
| $1.30 - $78.27 |  | 34,848,133 |  |  | 6.99 |  | $ | 22.47 |  |  | 23,287,734 |  |  | $ | 15.12 |  |

[0001375365-25-000027:notes:405]
RSU Activity

[0001375365-25-000027:notes:406]
The following table summarizes RSU activity during the fiscal year ended June 30, 2025 under all plans:

[0001375365-25-000027:notes:407]
|  |  | Time-based RSUs Outstanding |  | WeightedAverageGrant-Date Fair Value per Share |  |  |  |  |  |
| Balance as of June 30, 2024 |  | 21,272,990 |  |  | $ | 24.19 |  |  |  |  |  |  |
| Granted |  | 10,621,254 |  |  | $ | 40.92 |  |  |  |  |  |  |
| Vested |  | (9,927,956) |  |  | $ | 19.92 |  |  |  |  |  |  |
| Forfeited |  | (1,537,641) |  |  | $ | 34.16 |  |  |  |  |  |  |
| Balance as of June 30, 2025 |  | 20,428,647 |  |  | $ | 34.22 |  |  |  |  |  |  |

[0001375365-25-000027:notes:408]
As of June 30, 2025, $610.1 million of unrecognized compensation cost related to unvested RSUs is expected to be recognized over a weighted-average period of 2.51 years.

[0001375365-25-000027:notes:409]
Total fair value of RSUs vested as of the respective vesting dates for the fiscal years ended June 30, 2025, 2024, and 2023 was approximately $197.8 million, $105.2 million, and $37.6 million, respectively.

[0001375365-25-000027:notes:410]
The total pretax intrinsic value of RSUs vested was $376.9 million, $563.0 million, and $95.0 million for the fiscal years ended June 30, 2025, 2024, and 2023, respectively. In fiscal years 2025, 2024, and 2023, we withheld 3,008,315, 3,142,910, and 3,047,520 RSUs with value equivalent to the employees’ minimum statutory obligation for the applicable income and other employment taxes from the vesting and release of 9,927,956, 10,340,470, and 9,936,350 RSUs, respectively, and remitted the cash to the appropriate taxing authorities. The total shares withheld were based on the value of the equity awards on their respective vesting dates as determined by our closing stock price. Total payments for the employees’ tax obligations to tax authorities were $115.3 million, $174.4 million, and $28.2 million for the fiscal years ended June 30, 2025, 2024, and 2023, respectively, and are reflected as a financing activity within the consolidated statements of cash flows. Pursuant to the terms of the 2020 Plan, shares withheld in connection with net-share settlements are not added back to the 2020 Plan.


## smci:SummaryOfOperationalAndStockPriceMilestonesTableTextBlock

[0001375365-25-000027:notes:411]
As of June 30, 2025, the 2021 CEO Performance Stock Option had fully vested based upon achievement of operational and stock price milestones as follows:

[0001375365-25-000027:notes:412]
(9) On April 22, 2025, the Compensation Committee certified achievement of the $19.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of December 31, 2024. 
(10) On August 26, 2025, the Compensation Committee certified achievement of the $21.0 billion revenue milestone based on our previous four consecutive fiscal quarters revenue as of March 31, 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001375365-25-000027:notes:413]
Note 12.               Income Taxes

[0001375365-25-000027:notes:414]
The components of income before income tax provision for the fiscal years ended June 30, 2025, 2024, and 2023 are as follows (in thousands):

[0001375365-25-000027:notes:415]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| United States | $ | 1,064,753 |  |  | $ | 1,110,906 |  |  | $ | 632,237 |  |
| Foreign | 147,163 |  |  | 103,233 |  |  | 122,060 |  |
| Income before income tax provision | $ | 1,211,916 |  |  | $ | 1,214,139 |  |  | $ | 754,297 |  |

[0001375365-25-000027:notes:416]
The income tax provision for the fiscal years ended June 30, 2025, 2024, and 2023, consists of the following (in thousands):

[0001375365-25-000027:notes:417]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Current: |  |  |  |  |  |
| Federal | $ | 266,228 |  |  | $ | 173,838 |  |  | $ | 149,217 |  |
| State | 36,749 |  |  | 20,969 |  |  | 23,096 |  |
| Foreign | 68,512 |  |  | 36,986 |  |  | 31,063 |  |
|  | 371,489 |  |  | 231,793 |  |  | 203,376 |  |
| Deferred: |  |  |  |  |  |
| Federal | (161,039) |  |  | (162,286) |  |  | (80,975) |  |
| State | (11,983) |  |  | (5,405) |  |  | (9,633) |  |
| Foreign | (41,616) |  |  | (808) |  |  | (2,102) |  |
|  | (214,638) |  |  | (168,499) |  |  | (92,710) |  |
| Income tax provision | $ | 156,851 |  |  | $ | 63,294 |  |  | $ | 110,666 |  |

[0001375365-25-000027:notes:418]
Our net deferred tax assets as of June 30, 2025 and 2024 consist of the following (in thousands):

[0001375365-25-000027:notes:419]
|  | June 30, |
|  | 2025 |  | 2024 |
| Capitalized research and development costs | $ | 334,534 |  |  | $ | 240,489 |  |
| Research and development credits | 76,013 |  |  | 56,707 |  |
| Deferred revenue | 64,119 |  |  | 35,815 |  |
| Convertible Notes | 52,552 |  |  | 31,819 |  |
| Inventory valuation | 87,373 |  |  | 33,255 |  |
| Stock-based compensation | 32,301 |  |  | 16,389 |  |
| Lease obligations | 67,620 |  |  | 7,274 |  |
| Warranty accrual | 3,585 |  |  | 3,737 |  |
| Accrued vacation and bonus | 6,733 |  |  | 3,668 |  |
| Bad debt and other reserves | 4,809 |  |  | 2,597 |
| Marketing fund accrual | 4,388 |  |  | 2,102 |  |
| Other | 24,581 |  |  | 4,910 |  |
| Total gross deferred income tax assets | 758,608 |  |  | 438,762 |  |
| Less valuation allowance | (78,934) |  |  | (59,841) |  |
| Total deferred tax assets | 679,674 |  |  | 378,921 |  |
| Right of use asset | (65,946) |  |  | (7,005) |  |
| Depreciation and amortization | (6,312) |  |  | (6,744) |  |
| Total deferred tax liabilities | (72,258) |  |  | (13,749) |  |
| Deferred income tax assets, net | $ | 607,416 |  |  | $ | 365,172 |  |

[0001375365-25-000027:notes:420]
We assess our deferred tax assets for recoverability on a regular basis, and where applicable, a valuation allowance is recorded to reduce the total deferred tax asset to an amount that will, more likely than not, be realized in the future. As of June 30, 2025, we believe that most of its deferred tax assets are “more-likely-than not” to be realized with the exception of state research and development tax credits and unrealized capital losses that have not met the “more-likely than not” realization threshold criteria. As a result, at June 30, 2025, the gross excess credits of $96.2 million, or net of federal tax benefit of $76.0 million, were subject to a full valuation allowance. At June 30, 2024, the gross excess credits of $71.8 million, or net of federal tax benefit of $56.7 million, were subject to a full valuation allowance. The change in valuation allowance is $19.1 million and $23.2 million for the fiscal years ended June 30, 2025 and 2024, respectively. We will continue to review its deferred tax assets in accordance with the applicable accounting standards. The net deferred tax assets balance as of June 30, 2025 and 2024 was $607.4 million and $365.2 million, respectively.

[0001375365-25-000027:notes:421]
The following is a reconciliation for the fiscal years ended June 30, 2025, 2024, and 2023, of the statutory rate to our effective federal tax rate:

[0001375365-25-000027:notes:422]
|  |  | Years Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Income tax provision at statutory rate |  | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax, net of federal tax benefit |  | 1.1 |  |  | 1.0 |  |  | 1.1 |  |
| Foreign rate differential |  | 0.5 |  |  | 0.2 |  |  | 0.8 |  |
| Research and development tax credit |  | (3.8) |  |  | (6.0) |  |  | (3.3) |  |
| Uncertain tax positions, net of (settlement) with Tax Authorities |  | 0.1 |  |  | 1.1 |  |  | 0.1 |  |
| Foreign derived intangible / Subpart F income inclusion |  | (2.5) |  |  | (2.2) |  |  | (1.9) |  |
| Stock-based compensation |  | (4.5) |  |  | (11.8) |  |  | (3.4) |  |
| Provision to return true-up |  | (0.1) |  |  | (0.1) |  |  | (0.1) |  |
| Officer Comp IRC section 162(m) limitation |  | 0.9 |  |  | 1.8 |  |  | 0.2 |  |
| Others, net |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Effective tax rate |  | 12.9 | % |  | 5.2 | % |  | 14.7 | % |

[0001375365-25-000027:notes:423]
As of June 30, 2025, we had state research and development tax credit carryforwards of $126.3 million. The state research and development tax credits will carry forward indefinitely to offset future state income taxes.

[0001375365-25-000027:notes:424]
The following table summarizes the activity related to the unrecognized tax benefits (in thousands):

[0001375365-25-000027:notes:425]
|  | Gross*UnrecognizedIncome TaxBenefits |
| Balance at June 30, 2022 | $ | 38,001 |  |
| Gross increases: |  |
| For current year’s tax positions | 6,632 |  |
| For prior years’ tax positions | 1,616 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (2,077) |  |
| Decreases due to lapse of statute of limitations | (1,429) |  |
| Balance at June 30, 2023 | 42,743 |  |
| Gross increases: |  |
| For current year’s tax positions | 19,577 |  |
| For prior years’ tax positions | 3,076 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (8,981) |  |
| Decreases due to lapse of statute of limitations | (2,974) |  |
| Balance at June 30, 2024 | 53,441 |  |
| Gross increases: |  |
| For current year’s tax positions | 12,283 |  |
| For prior years’ tax positions | 2,333 |  |
| Gross decreases: |  |
| Decreases due to settlements with taxing authority | (2,782) |  |
| Decreases due to lapse of statute of limitations | (3,706) |  |
| Balance at June 30, 2025 | $ | 61,569 |  |

[0001375365-25-000027:notes:426]
*Excludes interest, penalties, federal benefit of state reserves

[0001375365-25-000027:notes:427]
We had gross unrecognized tax benefits of $61.6 million, $53.4 million and $42.7 million as of June 30, 2025, 2024, and 2023, respectively.

[0001375365-25-000027:notes:428]
For fiscal year 2025 and 2024, total unrecognized income tax benefits were $30.9 million, and $28.6 million, respectively, if recognized, would affect the effective tax rate.

[0001375365-25-000027:notes:429]
Our policy is to include interest and penalties related to unrecognized tax benefits within the income tax provision in the consolidated statements of operations. As of June 30, 2025 and 2024, we had accrued $5.0 million and $4.4 million for the payment of interest and penalties relating to unrecognized tax benefits, respectively. The impact of interest and penalties on our income tax provision was immaterial for the fiscal years ended June 30, 2025, and June 30, 2024.

[0001375365-25-000027:notes:430]
We believe that we have adequately provided reserves for all uncertain tax positions; however, amounts asserted by tax authorities could be greater or less than our current position. Accordingly, our provision on federal, state and foreign tax related matters to be recorded in the future may change as revised estimates are made or as the underlying matters are settled or otherwise resolved.

[0001375365-25-000027:notes:431]
We are subject to taxation and files income tax returns in the U.S. federal jurisdiction and various state and foreign jurisdictions. The federal statute of limitations remains open in general for tax years ended June 30, 2022 and after. Various states statute of limitations remains open in general for tax years ended June 30, 2021 and after. Certain statutes of limitations in major foreign jurisdictions remain open in general for the tax years ended June 30, 2020 and after. It is reasonably possible that our gross unrecognized tax benefits will decrease by approximately $4.1 million, in the next 12 months, due to the lapse of the statute of limitations. These adjustments, if recognized, would positively impact our effective tax rate, and would be recognized as additional tax benefits.

[0001375365-25-000027:notes:432]
Subsequent to June 30, 2025, the OBBBA was enacted in the U.S. on July 4, 2025. The OBBBA includes significant provisions, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions effective in 2025 and others implemented through 2027. We are currently assessing its impact on our consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001375365-25-000027:notes:433]
Note 13.               Commitments and Contingencies

[0001375365-25-000027:notes:434]
Litigation and claims

[0001375365-25-000027:notes:435]
On August 30, 2024, three putative class action complaints were filed against us, the Company’s Chief Executive Officer, and the Company’s Chief Financial Officer in the U.S. District Court for the Northern District of California (Averza v. Super Micro Computer, Inc., et al., No. 5:24-cv-06147, Menditto v. Super Micro Computer, Inc., et al., No. 3:24-cv-06149, and Spatz v. Super Micro Computer, Inc., et al., No. 5:24-cv-06193). On October 4, 2024, a fourth putative class action complaint was filed in the same court (Norfolk County Retirement System v. Super Micro Computer, Inc., et al., No. 5:24-cv-06980). On October 18, 2024, a fifth putative class action complaint was filed in the same court (Covey Financial Inc., et al. v. Super Micro Computer, Inc., et al., No. 5:24-cv-07274). The complaints contain similar allegations, claiming that (i) each of the defendants violated Section 10(b) of the Securities Exchange Act and Rule 10b-5 promulgated thereunder and (ii) each of the Company’s Chief Executive Officer and the Company’s Chief Financial Officer violated Section 20(a) of the Securities Exchange Act as controlling persons of the Company for the alleged violations under (i), due (in each case) to alleged misrepresentations and/or omissions in public statements regarding our financial results and its internal controls and procedures. The Spatz and Menditto plaintiffs have voluntarily dismissed their respective complaints without prejudice against all Defendants, ending the suits. The Averza, and Covey Financial, and Norfolk County complaints are pending as the Court finalizes the appointment of Universal-Investment-Gesellschaft mbH as lead plaintiff and prepares to consolidate the cases. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000027:notes:436]
On September 11, 2024, certain current and former directors and certain current officers of the Company were named as defendants in a putative derivative lawsuit filed in the U.S. District Court for the Northern District of California, captioned Hollin v. Liang, et al., Case No. 5:24-cv-06410 (the “Hollin Action”). Four additional putative derivative lawsuits have been filed in the same court, captioned Latypov v. Liang, et al., Case No. 5:24-cv-06779 (filed Sept. 26, 2024), Keritsis v. Liang, et al., Case No. 5:24-cv-07753 (filed Nov. 6, 2024), Roy v. Liang, et al., Case No. 5:24-cv-08006 (filed Nov. 14, 2024), and Jha v. Liang, et al., No. 5:24-cv-08792 (filed Dec. 5, 2024) (together with the Hollin Action, the “Federal Derivative Litigation”). On November 20, 2024, a similar putative derivative lawsuit was filed in the Superior Court of California, County of Santa Clara, captioned Spatz v. Liang, et al., Case No. 24CV452241 (the “Spatz Action”). Two additional putative derivative lawsuits have been filed in the same court, captioned Clark v. Liang, et al., Case No. 24CV454416 (filed Dec. 17, 2024) and Carter, et al. v. Liang, et al., Case No. 24CV454689 (filed Dec. 20, 2024) (together with the Spatz Action, the “State Court Derivative Litigation,” and together with the Federal Derivative Litigation, the “Derivative Litigation”). We were also named as a nominal defendant in the Derivative Litigation. The Federal Derivative Litigation purports to allege derivative claims for breaches of Sections 10(b), 14(a), and 20(a) of the Securities Exchange Act of 1934, as amended, and Rules 10b-5 and 14a-9 promulgated thereunder, breach of fiduciary duty, aiding and abetting breach of fiduciary duty, unjust enrichment, abuse of control, gross mismanagement, waste of corporate assets, and contribution arising out of allegations that our officers and directors caused us to issue materially false and misleading statements concerning our business operations and financial results. The State Court Derivative Litigation purports to allege claims for breach of fiduciary duty, aiding and abetting breach of fiduciary duty, waste of corporate assets, unjust enrichment, and insider trading arising out of similar allegations as the Federal Derivative Litigation. The plaintiffs in the Derivative Litigation seek unspecified money damages, in addition to punitive damages and other relief. On January 14, 2025, the Court in the Hollin Action granted plaintiffs’ motion to consolidate the five previously stayed Federal Derivative Litigation actions. On March 24, 2025, the Court in the Spatz Action entered a Stipulation and Order staying all proceedings and consolidating the three State Court Derivative Litigation actions. These matters are too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000027:notes:437]
On November 22, 2024, a putative class action claim was filed against us in Ontario Superior Court of Justice, Canada, captioned 1000099739 Ontario Ltd. v. Super Micro Computer, Inc., No. CV-24-00731863-OOCP. The claim alleges that we violated Common Law (primary and secondary market misrepresentations) and the Ontario Securities Act, due to alleged misrepresentations and/or omissions in public statements regarding our financial results and its internal controls and procedures. We filed a motion to dismiss for lack of jurisdiction on August 1, 2025, with the hearing scheduled for December 8, 2025. The matter is too preliminary to form a judgment as to whether the likelihood of an adverse outcome is probable and we are unable to estimate the possible loss or range of loss, if any.

[0001375365-25-000027:notes:438]
In late 2024, we received subpoenas from the Department of Justice and the Securities and Exchange Commission seeking a variety of documents following the publication of a short seller report in August 2024. We are cooperating with these document requests and there have been no charges brought against any person as of the date of this filing.

[0001375365-25-000027:notes:439]
Other legal proceedings and indemnifications

[0001375365-25-000027:notes:440]
In addition to the matters described above, from time to time, we have been involved in various legal proceedings, disputes, claims, and regulatory or governmental inquiries and investigations arising from the normal course of business activities. The resolution of any such matters have not had a material impact on our consolidated financial condition, results of operations or liquidity as of June 30, 2025, and any prior periods.

[0001375365-25-000027:notes:441]
We have entered into indemnification agreements with our current and former directors and executive officers. Under these agreements, we have agreed to indemnify such individuals to the fullest extent permitted by law against liabilities that arise by reason of their status as directors or officers and to advance expenses incurred by such individuals in connection with related legal proceedings. It is not possible to determine the maximum potential amount of payments we could be required to make under these agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each claim. However, we maintain directors and officers liability insurance coverage to reduce our exposure to such obligations.

[0001375365-25-000027:notes:442]
Purchase Commitments - We have agreements to purchase inventory and non-inventory items primarily through the next 12 months. As of June 30, 2025, these remaining non-cancelable commitments were $1.6 billion, including $148.9 million to related parties. We also review and assess the need for expected loss liabilities on a quarterly basis for all products we do not expect to sell for but have committed purchases from suppliers. There were no loss liabilities recognized in accrued liabilities in the consolidated balance sheets from purchase commitments as of June 30, 2025. As of June 30, 2024, there was $26.4 million of material loss liabilities recorded in the consolidated balance sheets from purchase commitments.

[0001375365-25-000027:notes:443]
Lease Commitments - See Note 9, “Leases” in the notes to the consolidated financial statements for a discussion of our operating lease commitments.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001375365-25-000027:notes:444]
Note 14.               Retirement Plans

[0001375365-25-000027:notes:445]
We sponsor a 401(k) savings plan for eligible United States employees and their beneficiaries. Contributions made by us are discretionary, and no contributions have been made for the fiscal years ended June 30, 2025, 2024, and 2023.

[0001375365-25-000027:notes:446]
Beginning in March 2003, employees of Super Micro Computer, B.V. are required to deduct a portion of their gross wages based on a defined age-dependent premium and invest the amount in a defined contribution plan. We are required to match the amount that is deducted monthly from employees’ wages. Similar to contributions into a 401(k) plan, our obligation is limited to the contributions made to the contribution plan. Investment risk and investment rewards are assumed by the employees and not by us. For the fiscal years ended June 30, 2025, 2024, and 2023, our matching contribution was $1.1 million, $1.1 million, and $0.9 million, respectively.

[0001375365-25-000027:notes:447]
We contribute to a defined contribution pension plan administered by the government of Taiwan that covers all eligible employees within Taiwan. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of Taiwan’s plan. The funding policy is consistent with the local requirements of Taiwan. Our obligation is limited to the contributions made to the pension plan. We have no control over the investment strategy of the assets of the government administered pension plan. For the fiscal years ended June 30, 2025, 2024, and 2023, our contribution was $4.6 million, $4.1 million, and $3.6 million, respectively.

[0001375365-25-000027:notes:448]
We have a defined benefit pension plan under the Taiwan Labor Standards Law for certain employees of Super Micro Computer, Inc. Taiwan that provides benefits based on an employee’s length of service and average monthly salary for the six-month period prior to retirement. We contribute an amount equal to 2% of salaries paid each month to the pension fund (the “Fund”), which is administered by the Labor Pension Fund Supervisory Committee (the “Committee”) and deposited in the Committee’s name in the Bank of Taiwan. Before the end of each year, we assess the balance in the Fund. If the amount of the balance in the Fund is inadequate to pay retirement benefits for eligible employees in the next year, we are required to fund the difference in one appropriation that should be made before the end of March 31 of the next year. The Fund is operated and managed by the government’s designated authorities. As such, we do not have any right to intervene in the investments of the Fund. For the fiscal years ended June 30, 2025, 2024, and 2023, we recorded a pension credit of $0.1 million, $0.1 million, and $0.1 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001375365-25-000027:notes:449]
Note 15.               Segment Reporting

[0001375365-25-000027:notes:450]
Segment Information

[0001375365-25-000027:notes:451]
We operate in one operating segment that develops and provides high-performance server solutions based upon an innovative, modular and open-standard architecture. Our Chief Executive Officer is the chief operating decision maker (“CODM”) and is responsible for assessing our performance. Our organizational structure is based on functional lines, with department heads and shared resources reporting either directly to the CODM or to a direct report of the CODM. The CODM reviews financial information presented on a consolidated basis and uses net income for purposes of evaluating financial performance and making operating decisions for us.

[0001375365-25-000027:notes:452]
The CODM reviews significant operating expenses as components of net income, including research and development expenses, sales and marketing expenses, and general and administrative expenses, which are each separately disclosed and presented in the consolidated statements of operations.

[0001375365-25-000027:notes:453]
Additionally, the CODM reviews significant segment expenses including the net provision for excess and obsolete inventory, recorded to cost of sales, which is separately disclosed in Note 6, “Balance Sheet Components”, and stock-based compensation, which is separately disclosed in Note 11, “Stock-based Compensation and Stockholders’ Equity” in the notes to the consolidated financial statements.

[0001375365-25-000027:notes:454]
The measure of segment assets is reported on the consolidated balance sheet as total consolidated assets. The accounting policies of our consolidated segment are the same as those described in Note 1, “Organization and Summary of Significant Accounting Policies”

[0001375365-25-000027:notes:455]
Long-lived assets

[0001375365-25-000027:notes:456]
The following is a summary of property, plant, and equipment, net (in thousands):

[0001375365-25-000027:notes:457]
|  | June 30, |  |  |
|  | 2025 |  | 2024 |  |  |
| United States | $ | 313,739 |  |  | $ | 281,874 |  |  |  |
| Taiwan | 104,435 |  |  | 107,878 |  |  |  |
| Malaysia | 61,205 |  | 21,740 |  |  |
| Other | 25,109 |  |  | 2,516 |  |  |  |
|  | $ | 504,488 |  |  | $ | 414,008 |  |  |  |

[0001375365-25-000027:notes:458]
The table above excludes other assets and intangible assets. Operating lease assets in the United States and the Netherlands were $279.5 million and $10.4 million as of June 30, 2025, respectively. Operating lease assets in the United States was $29.3 million as of June 30, 2024. Operating lease assets in all other countries were less than 10% as of June 30, 2025 and 2024.

[0001375365-25-000027:notes:459]
For the year ended June 30, 2025, 59.4% and 10.9% of revenues were from the United States and Thailand, respectively. For the year ended June 30, 2024 and 2023, 68.0% and 67.9% of our revenues were from the United States. Revenue from all other countries were individually less than 10% for each of the periods presented. Our revenue by geographic region is based on where the products were shipped to for fiscal years ended June 30, 2025, 2024, and 2023.


## us-gaap:SubsequentEventsTextBlock

[0001375365-25-000027:notes:460]
Note 16.               Subsequent Events

[0001375365-25-000027:notes:461]
On July 16, 2025, we entered into a Receivables Purchase Agreement (as amended, supplemented or otherwise modified from time to time, the “Receivables Purchase Agreement”), by and among, us, as seller and guarantor, MUFG Bank, Ltd. (“MUFG”), Crédit Agricole Corporate and Investment Bank, and certain other entities from time to time party thereto as purchasers (the “Purchasers”), and MUFG as administrative agent (in such capacity, the “Administrative Agent”).

[0001375365-25-000027:notes:462]
Pursuant to the Receivables Purchase Agreement, we may, subject to the terms and conditions set out therein, sell certain of its accounts receivable and related rights to the Purchasers (the “Purchased Receivables”). The Receivables Purchase Agreement provides for an uncommitted facility with an initial aggregate facility limit of $1,790.0 million. The Purchasers may elect in their sole direction to purchase eligible accounts receivable offered by us under the Receivables Purchase Agreement at the applicable purchase discount. The purchase price for any purchased receivable will be the net invoice amount of the purchased receivable, minus the applicable discount, which is set at Term SOFR (as defined in the Receivables Purchase Agreement) plus a specified discount assigned to each account debtor in the range of 1.15% - 2.80%, and calculated on the basis of a specified discount period. In the event the purchase of such Purchased Receivables is not characterized as a sale, we will be deemed to have granted a security interest in such Purchased Receivables and the proceeds thereof in favor of the Purchasers.

[0001375365-25-000027:notes:463]
Either us, the Administrative Agent, or the Required Purchasers (as defined in the Receivables Purchase Agreement) have the right to terminate the Receivables Purchase Agreement with 30 days’ prior written notice to the other party, or, if a Termination Event (as defined in the Receivables Purchase Agreement) shall have occurred and be continuing, the Receivables Purchase Agreement may be terminated by the Administrative Agent or the Required Purchasers immediately upon written notice to us.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001375365-25-000027:notes:464]
During the three months ended June 30, 2025, the following executive officers and directors (as defined in Rule 16a-1(f) under the Exchange Act) of ours adopted or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation S-K.

[0001375365-25-000027:notes:465]
| Name |  | Action |  | Adoption/Termination Date |  | Trading Arrangement |  | Total Shares of Common Stock to be Sold(3) |  | Expiration Date(4) |
|  |  |  | Rule 10b5-1(1) |  | Non-Rule 10b5-1(2) |  |  |
| David Weigand (Senior Vice President, Chief Financial Officer and Chief Compliance Officer) |  | Adoption |  | May 30, 2025 |  | X |  |  |  | 50,000 |  | December 1, 2025 |
| Sara Liu (Co-Founder, Senior Vice President and Director) |  | Adoption |  | May 29, 2025 |  | X |  |  |  | 600,000 |  | March 1, 2026 |

[0001375365-25-000027:notes:466]
_________________

[0001375365-25-000027:notes:467]
(1) Contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act.

[0001375365-25-000027:notes:468]
(2) “Non-Rule 10b5-1 trading arrangement” as defined in Item 408(c) of Regulation S-K under the Exchange Act.

[0001375365-25-000027:notes:469]
(3) This number represents the maximum number of shares of common stock that may be sold pursuant to the trading plan. The number of shares actually sold will depend on the satisfaction of certain conditions as set forth in the plan.

[0001375365-25-000027:notes:470]
(4) In each case, the trading plan may expire on an earlier date if and when all transactions thereunder are completed.


## ecd:AwardTmgMnpiDiscTextBlock

[0001375365-25-000027:notes:471]
Policies and Practices Regarding the Grant of Equity Awards

[0001375365-25-000027:notes:472]
The Compensation Committee generally holds regular quarterly meetings (which are typically held after the completion of a fiscal quarter and shortly before the Company announces its results for the just completed fiscal quarter (each, a “Regular Quarterly Meeting”)), and at such meeting the Committee considers and approves stock options and other equity-based awards, including relevant terms such as the effective date of the grant. In addition, the Compensation Committee may grant stock options and other equity-based awards between Regular Quarterly Meetings at special meetings or via unanimous written consent (together, “Special Meetings”).

[0001375365-25-000027:notes:473]
Awards of stock options and other equity-based awards are typically made by the Compensation Committee in the following circumstances:

[0001375365-25-000027:notes:474]
1.Initial and Biennial awards: Eligible employees (including our NEOs) receive equity-based awards (which may include stock options) in connection with their commencement of service with the Company or when a change in status occurs enabling such employee to become eligible to receive equity-based awards.  Proposed awards are generally submitted to the Compensation Committee for approval at the first Regular Quarterly Meeting after the commencement of service by such employee or the date the change in such employee’s status occurs. Thereafter, such employee would generally be eligible to receive a refresh equity-based award (which may include stock options) at the biennial Regular Quarterly Meeting following the date of the first award (all such awards, “Biennial Awards”);

[0001375365-25-000027:notes:475]
2.Scheduled Awards: The Compensation Committee also considers various scheduled awards which generally occur on a regular recurring basis (together, “Scheduled Awards”).  Examples of such Scheduled Awards include:

[0001375365-25-000027:notes:476]
a.The grant of the equity component of director compensation in connection with annual director service (the “Annual Director Service Award”) or lead independent director service (the “Lead Independent Director Service Award”). See “Director Compensation” for additional discussion with respect to our non-employee director compensation program.

[0001375365-25-000027:notes:477]
b.The grant of equity awards earned under the performance program for a NEO (which, to date, has not included stock options) (“Performance Award Grants”). Such awards generally have terms that were pre-approved by the Compensation Committee at the time the performance program for the named executive officer was adopted by the Compensation Committee earlier in such fiscal year, including specified deadline dates prior to which such Performance Awards Grants are to be made and after which the results used to determine performance (some of which may depend upon financial results that are published in the Annual Report) are calculated.

[0001375365-25-000027:notes:478]
3.    Special Awards: From time to time, the Compensation Committee will consider, on an as-needed basis, grants of equity based-awards (which may include stock options). Circumstances for such awards may include special recognition bonuses or for the hiring or retention of a high-value employee.

[0001375365-25-000027:notes:479]
The Company’s Insider Trading Policy provides for a trading window (the “Trading Window”) which generally (i) opens following the closing of trading on the second full trading day following the public issuance of the Company’s earnings release for the most recent fiscal quarter and (ii) closes at the close of trading on the last day of the second month of a fiscal quarter (i.e., the last day of August, November, February and May). Our Insider Trading Policy prohibits our directors, executive officers, employees and contractors from engaging in any transactions in publicly traded options, such as puts and calls, and other derivative securities, including any hedging or similar transaction, with respect to our common stock.

[0001375365-25-000027:notes:480]
The Compensation Committee has generally set the grant date of options awarded to NEOs for Initial and Biennial Awards to be the first full trading day occurring after the next opening of the Trading Window, with the exercise price of the options to be equal to the closing price of our common stock on the grant date. During fiscal year 2025, Mr. Kao received  Biennial Awards as refresh grants that included both stock options and RSUs The awards were approved at the October 30, 2024 Quarterly Meeting, and became effective on November 8, 2024, the first full trading day after the Trading Window was opened on November 7, 2024, following the Company’s disclosure on November 5, 2024 of its preliminary results for the first fiscal quarter ended on September 30, 2024. On November 13, 2024, we filed a Form NT 10-Q disclosing that we would not be able to file timely our Quarterly Report on Form 10-Q for the first fiscal quarter ended September 30, 2024.  We subsequently filed that report, along with our Annual Report on Form 10-K for the fiscal year ended June 30, 2024 and our Quarterly Report on Form 10-Q for our second fiscal quarter ended December 31, 2024, on February 25, 2025.

[0001375365-25-000027:notes:481]
During fiscal year 2025, except as provided in the chart below, we did not grant stock options (or similar awards) to any of our NEOs during the period beginning four business days before and ending one business day after the filing of any Company periodic report on Form 10-Q or Form 10-K, or the filing or furnishing of any Company Form 8-K that disclosed any material non-public information:

[0001375365-25-000027:notes:482]
| Name | Grant date | Number of securitiesunderlying the award | Exerciseprice of the award($/Share) | Grant date fair value of the award | Percentage change in the closing market price of the securities underlying the award between the trading day ending immediately prior to the disclosure of material nonpublic information and the trading day beginning immediately following the disclosure of material nonpublicinformation |
| (a) | (b) | (c) | (d) | (e) | (f) |
| Charles Liang | N/A | N/A | N/A | N/A | N/A |
| David Weigand | N/A | N/A | N/A | N/A | N/A |

[0001375365-25-000027:notes:483]
| Don Clegg | N/A | N/A | N/A | N/A | N/A |
| George Kao | 11/8/2024 | 32,629 | $24.52 | $15.66(1) | -17.0%(2) |

[0001375365-25-000027:notes:484]
(1)The amount disclosed represents the grant date fair value of the stock option award calculated in accordance with ASC Topic 718, using the Black Scholes option pricing model. Assumptions used in the calculation of this amount are included in Part II, Item 8, “Financial Statements and Supplementary Data”, and, Note 11, “Stock-based Compensation and Stockholders’ Equity” in the notes to the consolidated financial statements for fiscal year 2025 included in this Annual Report on Form 10-K.

[0001375365-25-000027:notes:485]
(2)Represents the percentage decrease in the market price of our common stock between (x) November 12, 2024 (the trading day ending immediately prior to November 13, 2024, which was the day we filed a Form NT 10-Q disclosing that we would not be able to file our Quarterly Report on Form 10-Q for the quarter ended September 30, 2024 on a timely basis) and (y) November 14, 2024 (the trading day immediately following November 13, 2024).
