# SMCI 8-K — 0001375365-25-000023 filed 2025-08-05

## item codes, every 8-K on or before 2025-08-28

- 2025-08-05 0001375365-25-000023 — 2.02, 9.01
- 2025-07-21 0001375365-25-000022 — 1.01, 2.03, 9.01
- 2025-06-27 0001375365-25-000020 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-06-23 0001375365-25-000018 — 8.01, 9.01
- 2025-06-06 0001375365-25-000016 — 5.02, 5.07, 9.01
- 2025-05-06 0001375365-25-000013 — 2.02, 9.01
- 2025-04-29 0001375365-25-000012 — 2.02, 9.01
- 2025-03-31 0001375365-25-000008 — 5.02, 7.01, 9.01
- 2025-02-26 0001375365-25-000007 — 3.01, 5.08, 8.01, 9.01
- 2025-02-21 0001375365-25-000003 — 1.01, 2.03, 3.02, 9.01
- 2025-02-11 0001375365-25-000001 — 2.02, 8.01, 9.01
- 2024-12-27 0001375365-24-000046 — 1.02, 9.01
- 2024-12-06 0001375365-24-000045 — 3.01, 9.01
- 2024-12-02 0001375365-24-000044 — 5.02, 8.01, 9.01
- 2024-11-26 0001375365-24-000043 — 1.02, 9.01
- 2024-11-20 0001375365-24-000042 — 1.01, 2.03, 3.01, 9.01
- 2024-11-18 0001375365-24-000040 — 4.01, 8.01, 9.01
- 2024-11-05 0001375365-24-000038 — 1.02, 2.02, 9.01
- 2024-11-01 0001375365-24-000037 — 1.01, 2.03, 9.01
- 2024-10-30 0001375365-24-000036 — 4.01, 9.01
- 2024-09-30 0001375365-24-000035 — 1.01, 2.03, 3.03, 5.03, 9.01
- 2024-09-26 0001375365-24-000034 — 8.01, 9.01
- 2024-09-20 0001375365-24-000033 — 3.01, 9.01
- 2024-09-03 0001375365-24-000032 — 7.01, 9.01
- 2024-08-28 0001375365-24-000030 — 8.01, 9.01
- 2024-08-19 0001375365-24-000029 — 5.02, 7.01, 9.01
- 2024-08-06 0001375365-24-000028 — 2.02, 9.01
- 2024-07-22 0001375365-24-000027 — 1.01, 7.01, 9.01
- 2024-06-21 0001375365-24-000026 — 1.01, 2.03, 9.01
- 2024-05-09 0001375365-24-000023 — 3.01, 9.01
- 2024-04-30 0001375365-24-000021 — 2.02, 9.01
- 2024-03-22 0001375365-24-000020 — 1.01, 8.01, 9.01
- 2024-03-15 0001375365-24-000019 — 5.02, 9.01
- 2024-02-28 0001375365-24-000017 — 1.01, 2.03, 3.02, 9.01
- 2024-02-23 0001375365-24-000016 — 8.01, 9.01
- 2024-02-22 0001375365-24-000015 — 1.01, 8.01, 9.01
- 2024-02-20 0001375365-24-000014 — 1.01, 2.03, 9.01
- 2024-02-01 0001375365-24-000010 — 1.01, 9.01
- 2024-01-29 0001375365-24-000008 — 2.02, 9.01
- 2024-01-25 0001375365-24-000005 — 5.02, 5.07, 9.01
- 2024-01-18 0001375365-24-000002 — 2.02, 9.01
- 2023-12-11 0001375365-23-000050 — 1.01, 2.03, 9.01
- 2023-12-08 0001375365-23-000044 — 1.01, 7.01, 9.01
- 2023-12-05 0001193125-23-289241 — 1.01, 8.01, 9.01
- 2023-11-20 0001375365-23-000043 — 5.02, 9.01
- 2023-11-01 0001375365-23-000040 — 2.02, 9.01
- 2023-10-27 0001375365-23-000039 — 8.01, 9.01
- 2023-10-02 0001375365-23-000038 — 1.01, 2.03, 9.01
- 2023-08-08 0001375365-23-000034 — 2.02, 9.01
- 2023-07-20 0001375365-23-000033 — 2.02, 9.01
- 2023-06-23 0001375365-23-000032 — 1.01, 9.01
- 2023-05-23 0001375365-23-000030 — 5.07, 9.01
- 2023-05-02 0001375365-23-000027 — 2.02, 9.01
- 2023-04-24 0001375365-23-000026 — 2.02, 9.01
- 2023-03-15 0001375365-23-000023 — 4.01, 9.01
- 2023-02-10 0001375365-23-000019 — 1.01, 2.03, 9.01
- 2023-01-31 0001375365-23-000009 — 2.02, 9.01
- 2023-01-18 0001375365-23-000004 — 2.02, 9.01
- 2022-12-20 0001375365-22-000124 — 5.02, 7.01, 9.01
- 2022-11-01 0001375365-22-000115 — 2.02, 9.01
- 2022-10-19 0001375365-22-000109 — 2.02, 9.01
- 2022-08-12 0001375365-22-000097 — 1.01, 2.03, 9.01
- 2022-08-09 0001375365-22-000092 — 2.02, 8.01, 9.01
- 2022-07-20 0001375365-22-000086 — 2.02, 9.01
- 2022-05-23 0001375365-22-000073 — 1.01, 2.03, 9.01
- 2022-05-19 0001375365-22-000068 — 5.02, 5.07, 9.01
- 2022-05-03 0001375365-22-000053 — 2.02, 9.01
- 2022-04-28 0001375365-22-000049 — 1.01, 2.03, 9.01
- 2022-04-18 0001375365-22-000046 — 2.02, 9.01
- 2022-04-06 0001375365-22-000037 — 5.02, 8.01, 9.01
- 2022-03-31 0001375365-22-000027 — 5.02, 9.01
- 2022-03-16 0001375365-22-000024 — 8.01
- 2022-03-04 0001375365-22-000021 — 1.01, 9.01
- 2022-02-01 0001375365-22-000008 — 2.02, 9.01
- 2022-01-13 0001375365-22-000003 — 1.01, 2.03, 9.01
- 2021-12-21 0001375365-21-000093 — 8.01
- 2021-11-12 0001375365-21-000087 — 1.01, 9.01
- 2021-11-02 0001375365-21-000078 — 2.02, 9.01
- 2021-10-12 0001375365-21-000075 — 1.01, 2.03, 9.01
- 2021-10-04 0001375365-21-000067 — 5.02, 9.01
- 2021-09-17 0001375365-21-000064 — 1.01, 2.03, 9.01
- 2021-08-10 0001375365-21-000055 — 2.02, 9.01
- 2021-07-26 0001375365-21-000050 — 1.01, 2.03, 9.01
- 2021-06-29 0001375365-21-000047 — 1.01, 9.01
- 2021-06-03 0001375365-21-000039 — 5.07, 9.01
- 2021-05-04 0001375365-21-000029 — 2.02, 9.01
- 2021-03-04 0001375365-21-000022 — 5.02, 7.01, 9.01
- 2021-02-12 0001375365-21-000015 — 7.01, 8.01
- 2021-02-02 0001375365-21-000005 — 2.02, 5.02, 8.01, 9.01
- 2020-12-04 0001375365-20-000077 — 1.01, 2.03, 9.01
- 2020-11-03 0001375365-20-000069 — 2.02, 5.02, 8.01, 9.01
- 2020-08-25 0001375365-20-000059 — 8.01, 9.01
- 2020-08-11 0001375365-20-000057 — 2.02, 9.01
- 2020-06-11 0001375365-20-000052 — 5.02, 9.01
- 2020-06-09 0001375365-20-000050 — 5.07, 9.01
- 2020-05-26 0001375365-20-000044 — 5.02, 9.01
- 2020-05-18 0001375365-20-000042 — 8.01, 9.01
- 2020-05-13 0001375365-20-000035 — 1.01, 9.01
- 2020-05-07 0001375365-20-000030 — 2.02, 9.01
- 2020-04-02 0001375365-20-000021 — 2.02, 7.01, 9.01
- 2020-03-10 0001375365-20-000019 — 5.02, 9.01
- 2020-02-21 0001375365-20-000015 — 8.01
- 2020-02-06 0001375365-20-000008 — 2.02, 9.01
- 2020-01-09 0001375365-20-000004 — 2.02, 9.01
- 2019-12-20 0001375365-19-000080 — 7.01, 8.01, 9.01
- 2019-11-14 0001375365-19-000059 — 2.02
- 2019-09-09 0001375365-19-000052 — 5.02
- 2019-08-15 0001375365-19-000047 — 2.02, 9.01
- 2019-07-02 0001375365-19-000045 — 1.01, 5.02, 9.01
- 2019-05-17 0001375365-19-000041 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2019-03-11 0001375365-19-000010 — 3.01
- 2019-02-27 0001375365-19-000008 — 5.02
- 2019-02-14 0001375365-19-000006 — 2.02, 9.01
- 2019-02-05 0001375365-19-000002 — 1.01, 2.03, 5.02, 5.05, 9.01
- 2018-12-11 0001375365-18-000004 — 7.01, 9.01
- 2018-11-15 0001628280-18-014419 — 2.02, 4.02
- 2018-10-22 0001628280-18-012712 — 7.01, 9.01
- 2018-10-15 0001628280-18-012549 — 7.01, 9.01
- 2018-09-12 0001628280-18-011798 — 1.01, 2.03, 9.01
- 2018-08-23 0001628280-18-011320 — 3.01, 9.01
- 2018-08-21 0001628280-18-011282 — 2.02, 9.01
- 2018-08-21 0001628280-18-011280 — 3.01, 9.01
- 2018-07-13 0001628280-18-009214 — 3.01
- 2018-05-21 0001628280-18-007027 — 3.01, 9.01
- 2018-05-03 0001628280-18-005840 — 2.02, 9.01
- 2018-04-24 0001628280-18-004949 — 1.01, 2.03, 9.01
- 2018-03-16 0001628280-18-003318 — 3.01, 9.01
- 2018-03-13 0001628280-18-003140 — 1.01, 2.03, 9.01
- 2018-02-21 0001628280-18-001928 — 3.01, 9.01
- 2018-01-30 0001628280-18-000714 — 2.02, 5.02
- 2018-01-17 0001628280-18-000366 — 1.01, 2.03, 9.01
- 2017-11-20 0001628280-17-011731 — 3.01, 9.01
- 2017-10-31 0001193125-17-327461 — 1.01, 2.03, 9.01
- 2017-10-26 0001628280-17-010235 — 2.02, 9.01
- 2017-09-15 0001628280-17-009319 — 3.01, 9.01
- 2017-08-03 0001628280-17-008033 — 2.02, 9.01
- 2017-07-20 0001628280-17-007157 — 2.02, 9.01
- 2017-04-27 0001628280-17-004432 — 2.02, 9.01
- 2017-03-02 0001628280-17-002111 — 5.07
- 2017-01-26 0001628280-17-000437 — 2.02, 9.01
- 2016-10-27 0001628280-16-020384 — 2.02, 9.01
- 2016-08-04 0001628280-16-018511 — 2.02, 9.01
- 2016-07-18 0001628280-16-017629 — 2.02, 8.01, 9.01
- 2016-04-28 0001628280-16-014939 — 2.02, 9.01
- 2016-04-15 0001628280-16-014222 — 2.02, 9.01
- 2016-03-14 0001628280-16-012679 — 5.02, 5.07, 9.01
- 2016-01-28 0001628280-16-010494 — 2.02, 9.01
- 2016-01-12 0001628280-16-010201 — 2.02, 9.01
- 2015-11-16 0001628280-15-008826 — 2.02 — amendment of 0001628280-15-007783
- 2015-10-22 0001628280-15-007783 — 2.02, 9.01
- 2015-10-08 0001628280-15-007626 — 2.02, 9.01
- 2015-08-04 0001628280-15-006029 — 2.02, 9.01
- 2015-04-21 0001628280-15-002702 — 2.02, 9.01
- 2015-02-17 0001628280-15-000794 — 5.07
- 2015-01-20 0001628280-15-000167 — 2.02, 5.02, 9.01
- 2014-10-21 0001445305-14-004352 — 2.02, 9.01
- 2014-08-05 0001445305-14-003415 — 2.02, 9.01
- 2014-04-22 0001445305-14-001395 — 2.02, 9.01
- 2014-02-14 0001445305-14-000466 — 5.07
- 2014-01-21 0001445305-14-000098 — 2.02, 9.01
- 2013-10-22 0001445305-13-002463 — 2.02, 9.01
- 2013-09-24 0001445305-13-002310 — 1.01, 8.01, 9.01
- 2013-08-06 0001445305-13-001917 — 2.02, 9.01
- 2013-04-23 0001445305-13-000877 — 2.02, 9.01
- 2013-02-19 0001445305-13-000250 — 5.07
- 2013-01-22 0001445305-13-000069 — 2.02, 9.01
- 2012-10-23 0001445305-12-003188 — 2.02, 9.01
- 2012-10-09 0001193125-12-417907 — 2.02, 9.01
- 2012-08-07 0001445305-12-002515 — 2.02, 9.01
- 2012-07-19 0001445305-12-002197 — 2.02, 9.01
- 2012-04-24 0001193125-12-178867 — 2.02, 5.02, 9.01
- 2012-02-13 0001193125-12-056746 — 5.07
- 2012-01-24 0001193125-12-021796 — 2.02, 9.01
- 2012-01-11 0001193125-12-008154 — 2.02, 9.01
- 2011-10-25 0001193125-11-280271 — 2.02, 9.01
- 2011-08-02 0001193125-11-206358 — 2.02, 9.01
- 2011-04-26 0001193125-11-109567 — 2.02, 9.01
- 2011-02-11 0001193125-11-032611 — 5.07, 9.01
- 2011-01-25 0001193125-11-013905 — 2.02, 9.01
- 2010-10-26 0001193125-10-236684 — 2.02, 9.01
- 2010-08-03 0001193125-10-175287 — 2.02, 9.01
- 2010-04-27 0001193125-10-094875 — 2.02, 9.01
- 2010-01-26 0001193125-10-013011 — 2.02, 9.01
- 2009-10-27 0001193125-09-214853 — 2.02, 9.01
- 2009-08-05 0001193125-09-165425 — 2.02, 9.01
- 2009-04-29 0001193125-09-091987 — 2.02, 9.01
- 2009-04-16 0001193125-09-080301 — 2.02, 9.01
- 2009-01-30 0001193125-09-014857 — 5.02, 9.01
- 2009-01-28 0001193125-09-013101 — 2.02, 9.01
- 2009-01-06 0001193125-09-001255 — 2.02, 9.01
- 2008-12-02 0001193125-08-246479 — 5.02, 9.01
- 2008-11-14 0001193125-08-236155 — 8.01, 9.01
- 2008-10-29 0001193125-08-219043 — 2.02, 9.01
- 2008-08-06 0001193125-08-168255 — 2.02, 5.02, 9.01
- 2008-05-14 0001193125-08-114658 — 4.02
- 2008-04-29 0001193125-08-095093 — 2.02, 9.01
- 2008-04-22 0001193125-08-085982 — 3.01, 9.01
- 2008-04-10 0001193125-08-078235 — 2.02, 3.01, 9.01
- 2008-01-30 0001193125-08-015488 — 2.02, 9.01
- 2007-11-14 0001193125-07-246505 — 7.01, 9.01
- 2007-10-31 0001193125-07-231112 — 2.02, 9.01
- 2007-08-07 0001193125-07-173675 — 2.02, 9.01
- 2007-06-29 0001193125-07-146800 — 1.01, 9.01
- 2007-05-09 0001157523-07-004890 — 2.02, 8.01, 9.01
- 2007-05-02 0001193125-07-099560 — 5.02

## late-filing notifications on or before 2025-08-28

- 2025-02-11 0001375365-25-000002 — NT 10-Q, for the period ended 2024-12-31
- 2024-11-13 0001375365-24-000039 — NT 10-Q, for the period ended 2024-09-30
- 2024-08-30 0001375365-24-000031 — NT 10-K, for the period ended 2024-08-30
- 2019-11-12 0001375365-19-000055 — NT 10-Q, for the period ended 2019-09-30
- 2019-08-30 0001375365-19-000049 — NT 10-K, for the period ended 2019-06-30
- 2019-05-10 0001375365-19-000016 — NT 10-Q, for the period ended 2019-03-31
- 2019-02-14 0001375365-19-000004 — NT 10-Q, for the period ended 2018-12-31
- 2018-11-13 0001628280-18-014173 — NT 10-Q, for the period ended 2018-09-30
- 2018-08-29 0001628280-18-011521 — NT 10-K, for the period ended 2018-08-29
- 2018-05-10 0001628280-18-006545 — NT 10-Q, for the period ended 2018-05-10
- 2018-02-09 0001628280-18-001354 — NT 10-Q, for the period ended 2018-02-09
- 2017-11-13 0001628280-17-011478 — NT 10-Q, for the period ended 2017-11-13
- 2017-08-29 0001628280-17-008984 — NT 10-K, for the period ended 2017-08-29
- 2015-11-10 0001628280-15-008619 — NT 10-Q, for the period ended 2015-09-30
- 2015-08-31 0001628280-15-006916 — NT 10-K, for the period ended 2015-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001375365-25-000023:8k_2_02:1]
EX-99.1
2
exhibit991_q425.htm
EX-99.1

[0001375365-25-000023:8k_2_02:2]
Document

[0001375365-25-000023:8k_2_02:3]
Exhibit 99.1

[0001375365-25-000023:8k_2_02:4]
Supermicro Announces Fourth Quarter and Full Fiscal Year 2025 Financial Results

[0001375365-25-000023:8k_2_02:5]
SAN JOSE, Calif. -- August 5, 2025 -- (BUSINESS WIRE) -- Super Micro Computer, Inc. (NASDAQ: SMCI) (“Supermicro” or the “Company”), a Total IT Solution Provider for AI, Cloud, Storage, and 5G/Edge, today announced unaudited financial results for its fourth quarter and full fiscal year ended June 30, 2025.

[0001375365-25-000023:8k_2_02:6]
Fourth Quarter Fiscal Year 2025 Highlights

[0001375365-25-000023:8k_2_02:7]
•Net sales of $5.8 billion versus $4.6 billion in Q3'25 and $5.4 billion in Q4'24.

[0001375365-25-000023:8k_2_02:8]
•Gross margin of 9.5% versus 9.6% in Q3'25 and 10.2% in Q4'24.

[0001375365-25-000023:8k_2_02:9]
•Net income of $195 million versus $109 million in Q3'25 and $297 million in Q4'24.

[0001375365-25-000023:8k_2_02:10]
•Diluted net income per common share of $0.31 versus $0.17 in Q3'25 and $0.46 in Q4'24.

[0001375365-25-000023:8k_2_02:11]
•Non-GAAP diluted net income per common share of $0.41 versus $0.31 in Q3'25 and $0.54 in Q4'24.

[0001375365-25-000023:8k_2_02:12]
•Cash flow provided by operations for Q4'25 of $864 million and capital expenditures and investments of $79 million.

[0001375365-25-000023:8k_2_02:13]
“We made solid progress in FY25 by growing our AI solution leadership in Neoclouds, CSPs, Enterprises, and Sovereign entities, which fueled our 47% annual growth,” said Charles Liang, Founder, President and CEO of Supermicro. “I’m especially excited about our new Datacenter Building Block Solutions (DCBBS), which offer exceptional value to customers seeking faster datacenter deployment and time-to-online advantages. With support from our expanding global operations that help mitigate tariffs and regional costs, combined with a growing enterprise customer base, AI product innovations, and robust DCBBS-powered total solutions, we’re on track to grow more large-scale datacenter customers from four in FY25 to six to eight in FY26.”

[0001375365-25-000023:8k_2_02:14]
The Non-GAAP gross margin for the fourth quarter of fiscal year 2025 was 9.6% with adjustments for stock-based compensation expenses of $7 million. The Non-GAAP diluted net income per common share for the fourth quarter of fiscal year 2025 was $0.41.

[0001375365-25-000023:8k_2_02:15]
Fiscal Year 2025 Summary

[0001375365-25-000023:8k_2_02:16]
Net sales for the fiscal year ended June 30, 2025, were $22.0 billion versus $15.0 billion for the fiscal year ended June 30, 2024. Net income for fiscal year 2025 was $1.0 billion, or $1.68 per diluted share, versus $1.2 billion, or $1.92 per diluted share, for fiscal year 2024.

[0001375365-25-000023:8k_2_02:17]
For the full fiscal year ended 2025, the Non-GAAP gross margin was 11.2% with adjustments for stock-based compensation expenses of $25 million. Non-GAAP net income for fiscal year 2025 was $1.3 billion, or $2.06 per diluted share, versus $1.3 billion, or $2.12 per diluted share, for fiscal year 2024. This non-GAAP net income includes adjustments for stock-based compensation expenses and the loss on extinguishment of convertible notes of $239 million and $23 million, which are net of the related tax effect of $75 million and $8 million for fiscal year 2025.

[0001375365-25-000023:8k_2_02:18]
As of June 30, 2025, total cash and cash equivalents was $5.2 billion and total bank debt and convertible notes were $4.8 billion.

[0001375365-25-000023:8k_2_02:19]
Business Outlook

[0001375365-25-000023:8k_2_02:20]
The Company expects net sales of $6.0 billion to $7.0 billion for the first quarter of fiscal year 2026 ending September 30, 2025, GAAP net income per diluted share of $0.30 to $0.42 and non-GAAP net income per diluted share of $0.40 to $0.52. The Company’s projections for GAAP and non-GAAP net income per diluted share assume a tax rate of approximately 13.0% and 15.5%, respectively, and a fully diluted share count of 631 million shares for GAAP and fully diluted share count of 644 million shares for non-GAAP. The outlook for first quarter of fiscal year 2026 GAAP net income per diluted share includes approximately $69 million in expected stock-based compensation, net of related tax effects of $20 million that are excluded from non-GAAP net income per diluted share.

[0001375365-25-000023:8k_2_02:21]
For fiscal year 2026, the Company expects net sales of at least $33.0 billion.

[0001375365-25-000023:8k_2_02:22]
Conference Call and Webcast Information

[0001375365-25-000023:8k_2_02:23]
Supermicro will present a live audio webcast of a conference call to review its fourth quarter and full-year fiscal 2025 financial results on Tuesday, August 5, 2025, at 5:00 p.m. ET / 2:00 p.m. PT. The webcast will be available at https://ir.supermicro.com.

[0001375365-25-000023:8k_2_02:24]
A replay of the webcast will be available shortly after the call at the same website and will remain accessible for one year.

[0001375365-25-000023:8k_2_02:25]
Cautionary Statement Regarding Forward Looking Statements

[0001375365-25-000023:8k_2_02:26]
About Super Micro Computer, Inc.

[0001375365-25-000023:8k_2_02:27]
Supermicro (NASDAQ: SMCI) is a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, Supermicro is committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. We are a Total IT Solutions manufacturer with server, AI, storage, IoT, switch systems, software, and support services. Supermicro's motherboard, power, and chassis design expertise further enables our development and production, enabling next-generation innovation from cloud to edge for our global customers. Our products are designed and manufactured in-house (in the US, Taiwan, and the Netherlands), leveraging global operations for scale and efficiency and optimized to improve TCO and reduce environmental impact (Green Computing). The award-winning portfolio of Server Building Block Solutions® allows customers to optimize for their exact workload and application by selecting from a broad family of systems built from our flexible and reusable building blocks that support a comprehensive set of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions (air-conditioned, free air cooling or liquid cooling).

[0001375365-25-000023:8k_2_02:28]
Supermicro, Server Building Block Solution, and We Keep IT Green are trademarks and/or registered trademarks of Super Micro Computer, Inc.

[0001375365-25-000023:8k_2_02:29]
All other brands, names, and trademarks are the property of their respective owners.

[0001375365-25-000023:8k_2_02:30]
Investor Relations Contact:

[0001375365-25-000023:8k_2_02:31]
Nicole Noutsios

[0001375365-25-000023:8k_2_02:32]
Stratos Advisors

[0001375365-25-000023:8k_2_02:33]
email: ir@supermicro.com

[0001375365-25-000023:8k_2_02:34]
Source: Super Micro Computer, Inc.

[0001375365-25-000023:8k_2_02:35]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:36]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001375365-25-000023:8k_2_02:37]
(in thousands)

[0001375365-25-000023:8k_2_02:38]
(unaudited)

[0001375365-25-000023:8k_2_02:39]
|  | June 30, |  | June 30, |
|  | 2025 |  | 2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,169,911 |  |  | $ | 1,669,766 |  |
| Accounts receivable, net of allowance for credit losses | 2,374,602 |  |  | 2,737,331 |  |
| Inventories | 4,680,375 |  |  | 4,333,029 |  |
| Prepaid expenses and other current assets | 243,171 |  |  | 191,834 |  |
| Total current assets | 12,468,059 |  |  | 8,931,960 |  |
| Property, plant, and equipment, net | 504,488 |  |  | 414,008 |  |
| Deferred income taxes, net | 607,416 |  |  | 365,172 |  |
| Other assets | 438,466 |  |  | 114,952 |  |
| Total assets | $ | 14,018,429 |  |  | $ | 9,826,092 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 1,281,977 |  |  | $ | 1,472,381 |  |
| Accrued liabilities | 565,637 |  |  | 259,674 |  |
| Income taxes payable | 53,381 |  |  | 18,268 |  |
| Lines of credit and current portion of term loans | 75,060 |  |  | 402,346 |  |
| Deferred revenue | 368,737 |  |  | 193,052 |  |
| Total current liabilities | 2,344,792 |  |  | 2,345,721 |  |
| Deferred revenue, non-current | 362,645 |  |  | 223,324 |  |
| Term loans, non-current | 37,415 |  |  | 74,083 |  |
| Convertible notes | 4,645,178 |  |  | 1,697,716 |  |
| Other long-term liabilities | 326,528 |  |  | 67,878 |  |
| Total liabilities | 7,716,558 |  |  | 4,408,722 |  |
| Stockholders’ equity: |  |  |  |
| Common stock and additional paid-in capital | 2,866,449 |  |  | 2,830,820 |  |
| Accumulated other comprehensive income | 705 |  |  | 706 |  |
| Retained earnings | 3,434,539 |  |  | 2,585,680 |  |
| Total Super Micro Computer, Inc. stockholders’ equity | 6,301,693 |  |  | 5,417,206 |  |
| Non-controlling interest | 178 |  |  | 164 |  |
| Total stockholders’ equity | 6,301,871 |  |  | 5,417,370 |  |
| Total liabilities and stockholders’ equity | $ | 14,018,429 |  |  | $ | 9,826,092 |  |

[0001375365-25-000023:8k_2_02:40]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001375365-25-000023:8k_2_02:42]
(in thousands, except per share amounts)

[0001375365-25-000023:8k_2_02:43]
(unaudited)

[0001375365-25-000023:8k_2_02:44]
|  | Three Months Ended June 30, |  | Twelve Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |
| Net sales | $ | 5,756,911 |  |  | $ | 5,354,589 |  |  | $ | 21,972,042 |  |  | $ | 14,989,251 |  |  |  |
| Cost of sales | 5,212,809 |  |  | 4,808,560 |  |  | 19,542,120 |  |  | 12,927,841 |  |  |  |
| Gross profit | 544,102 |  |  | 546,029 |  |  | 2,429,922 |  |  | 2,061,410 |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Research and development | 183,221 |  |  | 127,471 |  |  | 636,550 |  |  | 463,548 |  |  |  |
| Sales and marketing | 64,739 |  |  | 55,963 |  |  | 273,139 |  |  | 189,738 |  |  |  |
| General and administrative | 67,751 |  |  | 74,109 |  |  | 267,239 |  |  | 197,350 |  |  |  |
| Total operating expenses | 315,711 |  |  | 257,543 |  |  | 1,176,928 |  |  | 850,636 |  |  |  |
| Income from operations | 228,391 |  |  | 288,486 |  |  | 1,252,994 |  |  | 1,210,774 |  |  |  |
| Other income, net | 16,616 |  |  | 13,955 |  |  | 18,495 |  |  | 22,717 |  |  |  |
| Interest expense | (22,282) |  |  | (3,112) |  |  | (59,573) |  |  | (19,352) |  |  |  |
| Income before income tax provision | 222,725 |  |  | 299,329 |  |  | 1,211,916 |  |  | 1,214,139 |  |  |  |
| Income tax provision | (19,307) |  |  | (1,559) |  |  | (156,851) |  |  | (63,294) |  |  |  |
| Share of (loss) income from equity investee, net of taxes | (8,264) |  |  | (526) |  |  | (6,211) |  |  | 1,821 |  |  |  |
| Net income | $ | 195,154 |  |  | $ | 297,244 |  |  | $ | 1,048,854 |  |  | $ | 1,152,666 |  |  |  |
| Net income per common share (A): |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.33 |  |  | $ | 0.51 |  |  | $ | 1.77 |  |  | $ | 2.07 |  |  |  |
| Diluted | $ | 0.31 |  |  | $ | 0.46 |  |  | $ | 1.68 |  |  | $ | 1.92 |  |  |  |
| Weighted-average shares used in the calculation of net income per common share (A): |  |  |  |  |  |  |  |  |  |
| Basic | 597,627 |  |  | 586,883 |  |  | 593,665 |  |  | 555,878 |  |  |  |
| Diluted | 624,671 |  |  | 642,081 |  |  | 628,402 |  |  | 602,146 |  |  |  |

[0001375365-25-000023:8k_2_02:45]
(A) Reflects a ten-for-one stock split on September 30, 2024.

[0001375365-25-000023:8k_2_02:46]
Stock-based compensation is included in the following cost and expense categories by period (in thousands):

[0001375365-25-000023:8k_2_02:47]
|  |  | Three Months Ended June 30, |  | Years Ended June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |
| Cost of sales |  | $ | 6,792 |  |  | $ | 3,185 |  |  | $ | 24,505 |  |  | $ | 15,865 |  |  |  |
| Research and development |  | 53,854 |  |  | 28,890 |  |  | 195,444 |  |  | 114,895 |  |  |  |
| Sales and marketing |  | 10,539 |  |  | 6,197 |  |  | 37,784 |  |  | 21,195 |  |  |  |
| General and administrative |  | 12,427 |  |  | 36,688 |  |  | 56,719 |  |  | 79,552 |  |  |  |
| Stock-based compensation expense, before taxes |  | $ | 83,612 |  |  | $ | 74,960 |  |  | $ | 314,452 |  |  | $ | 231,507 |  |  |  |

[0001375365-25-000023:8k_2_02:48]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-25-000023:8k_2_02:50]
(in thousands)

[0001375365-25-000023:8k_2_02:51]
(unaudited)

[0001375365-25-000023:8k_2_02:52]
|  | Years ended June 30, |
|  | 2025 |  | 2024 |  |
| OPERATING ACTIVITIES: |  |  |  |  |
| Net income | $ | 1,048,854 |  |  | $ | 1,152,666 |  |  |
| Reconciliation of net income to net cash provided by (used in) operating activities: |  |  |  |  |
| Depreciation and amortization | 58,344 |  |  | 38,693 |  |  |
| Amortization of debt discount and issuance costs | 10,268 |  |  | 2,292 |  |  |
| Stock-based compensation expense | 314,452 |  |  | 231,507 |  |  |
| Share of loss (income) from equity investee | 6,211 |  |  | (1,821) |  |  |
| Unrealized foreign currency exchange loss (gain) | 18,832 |  |  | (531) |  |  |
| Loss on extinguishment of convertible notes | 30,251 |  |  | — |  |  |
| Deferred income taxes, net | (214,638) |  |  | (168,499) |  |  |
| Other non-cash (income) expense, net | (3,077) |  |  | 12,343 |  |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net | 362,681 |  |  | (1,589,187) |  |  |
| Inventories | (355,606) |  |  | (2,899,996) |  |  |
| Prepaid expenses and other assets | (58,447) |  |  | (44,646) |  |  |
| Accounts payable | (180,968) |  |  | 679,190 |  |  |
| Accrued liabilities | 272,404 |  |  | 92,942 |  |  |
| Income taxes payable | 32,043 |  |  | (110,897) |  |  |
| Deferred revenue | 315,006 |  |  | 111,927 |  |  |
| Other long-term liabilities | 2,914 |  |  | 8,045 |  |  |
| Net cash provided by (used in) operating activities | 1,659,524 |  |  | (2,485,972) |  |  |
| INVESTING ACTIVITIES: |  |  |  |  |
| Purchases of property, plant, and equipment | (127,214) |  |  | (124,279) |  |  |
| Investment in equity securities | (56,000) |  |  | (69,673) |  |  |
| Acquisition, net of cash acquired | — |  |  | (296) |  |  |
| Net cash used in investing activities | (183,214) |  |  | (194,248) |  |  |
| FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from lines of credit and term loans | 1,387,991 |  |  | 2,156,529 |  |  |
| Repayment of lines of credit and term loans | (1,768,650) |  |  | (1,967,545) |  |  |
| Proceeds from exercise of stock options | 20,898 |  |  | 29,453 |  |  |
| Payment for withholding taxes related to settlement of equity awards | (142,348) |  |  | (174,354) |  |  |
| Stock repurchases | (200,000) |  |  | — |  |  |
| Issuances of common stock in public offerings, net of issuance costs | — |  |  | 2,313,983 |  |  |
| Debt issuance costs in connection with amended 2029 Convertibles Notes | (31,217) |  |  | — |  |  |
| Proceeds from issuance of 2029 Convertible Notes, net of issuance costs | — |  |  | 1,695,768 |  |  |
| Proceeds from issuance of 2028 Convertible Notes, net of issuance costs | 683,696 |  |  | — |  |  |
| Proceeds from issuance of 2030 Convertible Notes, net of issuance costs | 2,255,973 |  |  | — |  |  |
| Purchase of capped calls | (182,215) |  |  | (142,140) |  |  |
| Other | (83) |  |  | 30 |  |  |
| Net cash provided by financing activities | 2,024,045 |  |  | 3,911,724 |  |  |
| Effect of exchange rate fluctuations on cash | 1,673 |  |  | (2,191) |  |  |
| Net increase in cash, cash equivalents and restricted cash | 3,502,028 |  |  | 1,229,313 |  |  |
| Cash, cash equivalents and restricted cash at the beginning of the period | 1,670,273 |  |  | 440,960 |  |  |
| Cash, cash equivalents and restricted cash at the end of the period | $ | 5,172,301 |  |  | $ | 1,670,273 |  |  |

[0001375365-25-000023:8k_2_02:53]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001375365-25-000023:8k_2_02:55]
(in thousands)

[0001375365-25-000023:8k_2_02:56]
(unaudited)

[0001375365-25-000023:8k_2_02:57]
|  | Years ended June 30, |
|  | 2025 |  | 2024 |  |
| Supplemental disclosure of cash flow information: |  |  |  |  |
| Cash paid for interest | $ | 25,490 |  |  | $ | 16,015 |  |  |
| Cash paid for taxes, net of refunds | $ | 327,158 |  |  | $ | 392,020 |  |  |
| Non-cash investing and financing activities: |  |  |  |  |
| Unpaid property, plant, and equipment purchases | $ | 16,208 |  |  | $ | 19,613 |  |  |
| Right of use assets obtained in exchange for operating lease commitments | $ | 276,170 |  |  | $ | 32,581 |  |  |
| Transfer of inventory to property, plant, and equipment, net | $ | 8,260 |  |  | $ | 12,535 |  |  |

[0001375365-25-000023:8k_2_02:58]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:59]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000023:8k_2_02:60]
(in thousands, except per share amounts)

[0001375365-25-000023:8k_2_02:61]
(unaudited)

[0001375365-25-000023:8k_2_02:62]
Use of Non-GAAP Financial Measures

[0001375365-25-000023:8k_2_02:63]
To supplement its condensed consolidated financial results presented in accordance with United States Generally Accepted Accounting Principles (“GAAP”), the Company uses non-GAAP measures that are adjusted for certain items from the most directly comparable GAAP measures. The specific non-GAAP measures presented below are: gross margin; operating expenses; net income; net income per common share; diluted net income; diluted net income per common share; and effective tax rate. Management believes these non-GAAP measures provide useful information to investors by offering a consistent basis for comparing the Company's performance across periods, excluding items that are not reflective of our core operating results. These non-GAAP measures are not prepared in accordance with GAAP or intended to be a replacement for GAAP financial data; and therefore, should be reviewed together with the GAAP measures and are not intended to serve as a substitute for results under GAAP, and may be different from non-GAAP measures used by other companies.

[0001375365-25-000023:8k_2_02:64]
We exclude the following adjustments from our non-GAAP financial measures:

[0001375365-25-000023:8k_2_02:65]
Non-GAAP Adjustments

[0001375365-25-000023:8k_2_02:66]
•Stock-based compensation: Stock-based compensation relates primarily to our equity incentive awards. Stock-based compensation is a non-cash expense that is dependent on market forces that are difficult to predict. We believe that this adjustment for stock-based compensation provides investors with a basis to measure the company's core performance, including compared with the performance of other companies, without the period-to-period variability created by stock-based compensation.

[0001375365-25-000023:8k_2_02:67]
•Loss on extinguishment of convertible notes: We exclude the loss on extinguishment of debt related to our convertible notes from our non-GAAP results, as it is a non-recurring, financing-related charge that does not reflect our underlying operating performance in the period incurred. We believe it is appropriate to exclude this loss - and to present it separately - to provide investors with greater insight, as it is a non-recurring financing activity and is not reflective of ongoing operating results.

[0001375365-25-000023:8k_2_02:68]
•Adjusted EBITDA adjustments: When calculating Adjusted EBITDA, in addition to the adjustments described above, we exclude the impact of Interest expense, Income tax (provision) benefit, and Depreciation and amortization during the period.

[0001375365-25-000023:8k_2_02:69]
Pursuant to the requirements of SEC Regulation G, please see the tables below for the reconciliations of GAAP to Non-GAAP measures. These should be read together with the preceding financial statements prepared in accordance with GAAP.

[0001375365-25-000023:8k_2_02:70]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:71]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000023:8k_2_02:72]
(in thousands, except per share amounts)

[0001375365-25-000023:8k_2_02:73]
(unaudited)

[0001375365-25-000023:8k_2_02:74]
Reconciliation of GAAP Net Income to Adjusted EBITDA:

[0001375365-25-000023:8k_2_02:75]
|  | Three months ended |  | Twelve months ended |
|  | June 30, 2025 |  |  |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| GAAP Net Income | $ | 195,154 |  |  |  |  | $ | 297,244 |  |  | $ | 1,048,854 |  |  | $ | 1,152,666 |  |
| Interest expense | 22,282 |  |  |  |  | 3,112 |  |  | 59,573 |  |  | 19,352 |  |
| Income tax provision | 19,307 |  |  |  |  | 1,559 |  |  | 156,851 |  |  | 63,294 |  |
| Depreciation & Amortization | 18,636 |  |  |  |  | 10,287 |  |  | 58,344 |  |  | 38,693 |  |
| Stock-based compensation | 83,612 |  |  |  |  | 74,960 |  |  | 314,452 |  |  | 231,507 |  |
| Loss on extinguishment of convertible notes | — |  |  |  |  | — |  |  | 30,251 |  |  | — |  |
| Adjusted EBITDA | $ | 338,991 |  |  |  |  | $ | 387,162 |  |  | $ | 1,668,325 |  |  | $ | 1,505,512 |  |
| Adjusted EBITDA % of net sales | 5.9 | % |  |  |  | 7.2 | % |  | 7.6 | % |  | 10.0 | % |

[0001375365-25-000023:8k_2_02:76]
Reconciliation of GAAP to Non-GAAP Gross Margin:

[0001375365-25-000023:8k_2_02:77]
|  | Three months ended |  | Twelve months ended |
|  | June 30, 2025 |  |  |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| GAAP Gross Profit | $ | 544,102 |  |  |  |  | $ | 546,029 |  |  | $ | 2,429,922 |  |  | $ | 2,061,410 |  |
| Stock-based compensation | 6,792 |  |  |  |  | 3,185 |  |  | 24,505 |  |  | 15,865 |  |
| Non-GAAP Gross Profit | $ | 550,894 |  |  |  |  | $ | 549,214 |  |  | $ | 2,454,427 |  |  | $ | 2,077,275 |  |
| GAAP gross margin (%) | 9.5 | % |  |  |  | 10.2 | % |  | 11.1 | % |  | 13.8 | % |
| Stock-based compensation (%) | 0.1 | % |  |  |  | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Non-GAAP gross margin (%) | 9.6 | % |  |  |  | 10.3 | % |  | 11.2 | % |  | 13.9 | % |

[0001375365-25-000023:8k_2_02:78]
Reconciliation of GAAP to Non-GAAP Operating Expenses:

[0001375365-25-000023:8k_2_02:79]
|  | Three months ended |  | Twelve months ended |
|  | June 30, 2025 |  |  |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| GAAP Operating Expenses | $ | 315,711 |  |  |  |  | $ | 257,543 |  |  | $ | 1,176,928 |  |  | $ | 850,636 |  |
| Adjustments to operating expenses |  |  |  |  |  |  |  |  |  |
| GAAP R&D operating expenses | 183,221 |  |  |  |  | 127,471 |  |  | 636,550 |  |  | 463,548 |  |
| Stock-based compensation | 53,854 |  |  |  |  | 28,890 |  |  | 195,444 |  |  | 114,895 |  |
| Non-GAAP R&D operating expenses | 129,367 |  |  |  |  | 98,581 |  |  | 441,106 |  |  | 348,653 |  |
| GAAP S&M operating expenses | 64,739 |  |  |  |  | 55,963 |  |  | 273,139 |  |  | 189,738 |  |
| Stock-based compensation | 10,539 |  |  |  |  | 6,197 |  |  | 37,784 |  |  | 21,195 |  |
| Non-GAAP S&M operating expenses | 54,200 |  |  |  |  | 49,766 |  |  | 235,355 |  |  | 168,543 |  |
| GAAP G&A operating expenses | 67,751 |  |  |  |  | 74,109 |  |  | 267,239 |  |  | 197,350 |  |
| Stock-based compensation | 12,427 |  |  |  |  | 36,688 |  |  | 56,719 |  |  | 79,552 |  |
| Non-GAAP G&A operating expenses | 55,324 |  |  |  |  | 37,421 |  |  | 210,520 |  |  | 117,798 |  |
| Non-GAAP Operating Expenses | $ | 238,891 |  |  |  |  | $ | 185,768 |  |  | $ | 886,981 |  |  | $ | 634,994 |  |

[0001375365-25-000023:8k_2_02:80]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:81]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000023:8k_2_02:82]
(in thousands, except per share amounts)

[0001375365-25-000023:8k_2_02:83]
(unaudited)

[0001375365-25-000023:8k_2_02:84]
Reconciliation of GAAP to Non-GAAP Net Income:

[0001375365-25-000023:8k_2_02:85]
|  | Three months ended |  | Twelve months ended |
|  | June 30, 2025 |  |  |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| GAAP net income - basic | $ | 195,154 |  |  |  |  | $ | 297,244 |  |  | $ | 1,048,854 |  |  | $ | 1,152,666 |  |
| Adjustments related to stock-based compensation: |  |  |  |  |  |  |  |  |  |
| Cost of sales | 6,792 |  |  |  |  | 3,185 |  |  | 24,505 |  |  | 15,865 |  |
| Operating expenses | 76,820 |  |  |  |  | 71,775 |  |  | 289,947 |  |  | 215,642 |  |
| Total adjustments to GAAP income from operations | 83,612 |  |  |  |  | 74,960 |  |  | 314,452 |  |  | 231,507 |  |
| Adjustments related to loss on extinguishment of convertible notes: |  |  |  |  |  |  |  |  |  |
| Other expense | — |  |  |  |  | — |  |  | 30,251 |  |  | — |  |
| Total adjustments to GAAP Other expense | — |  |  |  |  | — |  |  | 30,251 |  |  | — |  |
| Total adjustments to GAAP income before income tax provision | 83,612 |  |  |  |  | 74,960 |  |  | 344,703 |  |  | 231,507 |  |
| Income tax effect of non-GAAP adjustments | (18,120) |  |  |  |  | (20,169) |  |  | (82,835) |  |  | (92,810) |  |
| Non-GAAP net income - basic | $ | 260,646 |  |  |  |  | $ | 352,035 |  |  | $ | 1,310,722 |  |  | $ | 1,291,363 |  |
| GAAP net income - basic | $ | 195,154 |  |  |  |  | $ | 297,244 |  |  | $ | 1,048,854 |  |  | $ | 1,152,666 |  |
| Convertible note interest charge, net of tax | 75 |  |  |  |  | 1,095 |  |  | 5,726 |  |  | 1,480 |  |
| GAAP net income - diluted | $ | 195,229 |  |  |  |  | $ | 298,339 |  |  | $ | 1,054,580 |  |  | $ | 1,154,146 |  |
| Non-GAAP net income - basic | $ | 260,646 |  |  |  |  | $ | 352,035 |  |  | $ | 1,310,722 |  |  | $ | 1,291,363 |  |
| Convertible note interest charge, net of tax | 75 |  |  |  |  | 1,095 |  |  | 5,726 |  |  | 1,480 |  |
| Non-GAAP net income - diluted | $ | 260,721 |  |  |  |  | $ | 353,130 |  |  | $ | 1,316,448 |  |  | $ | 1,292,843 |  |
| Weighted-average shares used in the calculation of net income per common share: |  |  |  |  |  |  |  |  |  |
| Basic - GAAP | 597,627 |  |  |  |  | 586,883 |  |  | 593,665 |  |  | 555,878 |  |
| Basic - Non-GAAP | 597,627 |  |  |  |  | 586,883 |  |  | 593,665 |  |  | 555,878 |  |
| Diluted - GAAP | 624,671 |  |  |  |  | 642,081 |  |  | 628,402 |  |  | 602,146 |  |
| Non-GAAP adjustment | 13,663 |  |  |  |  | 6,186 |  |  | 11,768 |  |  | 6,713 |  |
| Diluted - Non-GAAP | 638,334 |  |  |  |  | 648,267 |  |  | 640,170 |  |  | 608,859 |  |

[0001375365-25-000023:8k_2_02:86]
SUPER MICRO COMPUTER, INC.

[0001375365-25-000023:8k_2_02:87]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001375365-25-000023:8k_2_02:88]
(in thousands, except per share amounts)

[0001375365-25-000023:8k_2_02:89]
(unaudited)

[0001375365-25-000023:8k_2_02:90]
Reconciliation of GAAP to Non-GAAP EPS:

[0001375365-25-000023:8k_2_02:91]
|  | Three months ended |  | Twelve months ended |
|  | June 30, 2025 |  |  |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| GAAP Net Income per common share - basic | $ | 0.33 |  |  |  |  | $ | 0.51 |  |  | $ | 1.77 |  |  | $ | 2.07 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation - basic | 0.14 |  |  |  |  | 0.13 |  |  | 0.53 |  |  | 0.42 |  |
| Loss on extinguishment of convertible notes - basic | — |  |  |  |  | — |  |  | 0.05 |  |  | — |  |
| Income tax - basic | (0.03) |  |  |  |  | (0.04) |  |  | (0.14) |  |  | (0.17) |  |
| Non-GAAP Net Income per common share - basic | $ | 0.44 |  |  |  |  | $ | 0.60 |  |  | $ | 2.21 |  |  | $ | 2.32 |  |
| GAAP net income per common share - diluted | $ | 0.31 |  |  |  |  | $ | 0.46 |  |  | $ | 1.68 |  |  | $ | 1.92 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation - diluted | 0.13 |  |  |  |  | 0.12 |  |  | 0.48 |  |  | 0.38 |  |
| Loss on extinguishment of convertible notes - diluted | — |  |  |  |  | — |  |  | 0.04 |  |  | — |  |
| Income tax - diluted | (0.03) |  |  |  |  | (0.04) |  |  | (0.14) |  |  | (0.18) |  |
| Non-GAAP Net Income per common share – diluted | $ | 0.41 |  |  |  |  | $ | 0.54 |  |  | $ | 2.06 |  |  | $ | 2.12 |  |

[0001375365-25-000023:8k_2_02:92]
GAAP to Non-GAAP Effective Tax Rate:

[0001375365-25-000023:8k_2_02:93]
|  | Three months ended |  | Twelve months ended |
|  | June 30, 2025 |  |  |  | June 30, 2024 |  | June 30, 2025 |  | June 30, 2024 |
| GAAP effective tax rate | 8.7 | % |  |  |  | 0.5 | % |  | 12.9 | % |  | 5.2 | % |
| Total adjustments to GAAP provision to income tax | 3.5 | % |  |  |  | 5.3 | % |  | 2.5 | % |  | 5.6 | % |
| Non-GAAP effective tax rate | 12.2 | % |  |  |  | 5.8 | % |  | 15.4 | % |  | 10.8 | % |
