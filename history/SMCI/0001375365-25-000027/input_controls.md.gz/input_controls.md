# SMCI 10-K controls and the auditor's report


## auditors_report

[0001375365-25-000027:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001375365-25-000027:auditors_report:2]
Stockholders and Board of Directors

[0001375365-25-000027:auditors_report:3]
Super Micro Computer, Inc.

[0001375365-25-000027:auditors_report:4]
San Jose, California

[0001375365-25-000027:auditors_report:5]
Opinion on the Consolidated Financial Statements

[0001375365-25-000027:auditors_report:6]
We have audited the accompanying consolidated balance sheets of Super Micro Computer, Inc. (the “Company”) as of June 30, 2025 and 2024, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for each of the years then ended, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at June 30, 2025 and 2024, and the results of its operations and its cash flows for the years then ended, in conformity with accounting principles generally accepted in the United States of America.

[0001375365-25-000027:auditors_report:7]
We also have audited the adjustments to the 2023 consolidated financial statements to retrospectively apply the stock split, as discussed in Note 1. In our opinion, such adjustments are appropriate and have been properly applied. We were not engaged to audit, review, or apply any procedures to the 2023 consolidated financial statements of the Company other than with respect to the adjustments and, accordingly, we do not express an opinion or any other form of assurance on the 2023 consolidated financial statements taken as a whole.

[0001375365-25-000027:auditors_report:8]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of June 30, 2025, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) and our report dated August 28, 2025 expressed an adverse opinion thereon.

[0001375365-25-000027:auditors_report:9]
Basis for Opinion

[0001375365-25-000027:auditors_report:10]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-25-000027:auditors_report:11]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud.

[0001375365-25-000027:auditors_report:12]
Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001375365-25-000027:auditors_report:13]
Critical Audit Matters

[0001375365-25-000027:auditors_report:14]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of the critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001375365-25-000027:auditors_report:15]
SMCI | 2025 Form 10-K | 56

[0001375365-25-000027:auditors_report:16]
Valuation of Inventories

[0001375365-25-000027:auditors_report:17]
As described in Notes 1 and 6 to the consolidated financial statements, the Company’s consolidated inventories balance, which is stated at lower of cost, using weighted average cost method, or net realizable value, was $4.68 billion as June 30, 2025. The Company evaluates inventories for excess and obsolescence and lower of cost or net realizable value and, as necessary, writes down the valuation of inventories based upon the Company’s inventory aging, forecasted usage and sales, anticipated selling price, product obsolescence and other factors.

[0001375365-25-000027:auditors_report:18]
We identified the valuation of inventories as a critical audit matter. Auditing the valuation of inventories, which includes write-down percentages for excess and obsolescence applied to the different inventory aging categories, involved especially challenging and subjective auditor judgments due to the nature and extent of effort required to address this matter.

[0001375365-25-000027:auditors_report:19]
The primary procedures we performed to address this critical audit matter included:

[0001375365-25-000027:auditors_report:20]
•Inquiring of various personnel in the Company including but not limited to finance and operations personnel about the expected product lifecycles and product development plans to understand and evaluate the Company’s methodology for determining inventory that is excess or obsolete and the key assumptions and judgments made as part of the process, including the write-down percentages used to write down the valuation of inventories.

[0001375365-25-000027:auditors_report:21]
•Assessing management’s estimate of write-down percentages by recalculating inventory turns and historical write-down percentages across multiple fiscal periods and comparing it with the write-down percentages used by management to evaluate management’s ability to accurately estimate excess and obsolete inventories.

[0001375365-25-000027:auditors_report:22]
•Testing the completeness and accuracy of the underlying data utilized in management’s excess and obsolescence analysis, including the classification of inventory by aging category.

[0001375365-25-000027:auditors_report:23]
•Assessing the existence of contradictory evidence based on reading the Company’s press releases and industry reports, as well as our observations and inquiries as to changes within the business.

[0001375365-25-000027:auditors_report:24]
Revenue Recognition from Contracts with Customers

[0001375365-25-000027:auditors_report:25]
As described in Notes 1 and 4 to the consolidated financial statements, the Company’s net sales were $21.97 billion for the year ended June 30, 2025. The Company recognizes revenue upon transfer of control of promised goods or services in a contract. Transfer of control of promised goods generally occurs at the point of shipment or upon delivery to the customer.

[0001375365-25-000027:auditors_report:26]
We identified the auditing of revenue recognition from contracts with customers as a critical audit matter because it involved a high degree of auditor effort required in performing audit procedures.

[0001375365-25-000027:auditors_report:27]
The primary procedures we performed to address this critical audit matter included:

[0001375365-25-000027:auditors_report:28]
•Evaluating revenue transactions on a sample basis by obtaining and inspecting source documents, such as purchase orders, sales quotations, contracts, invoices, and proof of shipment or proof of delivery.

[0001375365-25-000027:auditors_report:29]
•Inspecting a sample of credit memos and the related invoice to assess whether they were recorded in the appropriate period.

[0001375365-25-000027:auditors_report:30]
•Evaluating the completeness and accuracy of information produced by the entity.

[0001375365-25-000027:auditors_report:31]
•Evaluating the completeness and accuracy of the terms and conditions in certain customer contracts, including confirming the terms and conditions of contracts.

[0001375365-25-000027:auditors_report:32]
/s/ BDO USA, P.C.

[0001375365-25-000027:auditors_report:33]
We have served as the Company’s auditor since 2024.

[0001375365-25-000027:auditors_report:34]
San Jose, California

[0001375365-25-000027:auditors_report:35]
August 28, 2025

[0001375365-25-000027:auditors_report:36]
SMCI | 2025 Form 10-K | 57

[0001375365-25-000027:auditors_report:37]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001375365-25-000027:auditors_report:38]
To the Stockholders and the Board of Directors of Super Micro Computer, Inc.

[0001375365-25-000027:auditors_report:39]
Opinion on the Financial Statements

[0001375365-25-000027:auditors_report:40]
We have audited, before the effects of the adjustments to retrospectively apply the stock split discussed in Note 1 to the consolidated financial statements, the related consolidated statements of operations, comprehensive income, stockholders' equity, and cash flows, for the year ended June 30, 2023, and the related notes (collectively referred to as the "financial statements") (the June 30, 2023 financial statements before the effects of the retrospective adjustments discussed in Note 1 to the financial statements are not presented herein). In our opinion, the 2023 financial statements, before the effects of the adjustments to retrospectively apply the stock split discussed in Note 1 to the financial statements, present fairly, in all material respects, the results of its operations and its cash flows for the year ended June 30, 2023, in conformity with accounting principles generally accepted in the United States of America.

[0001375365-25-000027:auditors_report:41]
We were not engaged to audit, review, or apply any procedures to the adjustments to retrospectively apply the stock split discussed in Note 1 to the financial statements, and accordingly, we do not express an opinion or any other form of assurance about whether such retrospective adjustments are appropriate and have been properly applied. Those retrospective adjustments were audited by the successor auditor.

[0001375365-25-000027:auditors_report:42]
Basis for Opinion

[0001375365-25-000027:auditors_report:43]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audit. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-25-000027:auditors_report:44]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-25-000027:auditors_report:45]
/s/ DELOITTE & TOUCHE LLP

[0001375365-25-000027:auditors_report:46]
San Jose, California

[0001375365-25-000027:auditors_report:47]
August 25, 2023

[0001375365-25-000027:auditors_report:48]
We began serving as the Company’s auditor in 2003. In 2023, we became the predecessor auditor.

[0001375365-25-000027:auditors_report:49]
SMCI | 2025 Form 10-K | 58

[0001375365-25-000027:auditors_report:50]
SUPER MICRO COMPUTER, INC.


## item_9a

[0001375365-25-000027:item_9a:1]
Item 9A.    Controls and Procedures

[0001375365-25-000027:item_9a:2]
Attached as exhibits to this Form 10-K are certifications of our Chief Executive Officer and Chief Financial Officer, which are required in accordance with Rule 13a-14 of the Exchange Act. This “Controls and Procedures” section includes information concerning the internal controls and controls evaluation referred to in the certifications.

[0001375365-25-000027:item_9a:3]
(a) Management’s Evaluation of Disclosure Controls and Procedures

[0001375365-25-000027:item_9a:4]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, is responsible for evaluating the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rules 13a-15(e) and 15d-15(e)) as of  June 30, 2025 . Our disclosure controls and procedures are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file under the Exchange Act is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure and is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the SEC. Based upon this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were not effective at the reasonable assurance level as of June 30, 2025 due to the material weaknesses in our internal control over financial reporting described below. Notwithstanding the identified material weaknesses, management believes and has concluded that the consolidated financial statements included in this Annual Report fairly present, in all material respects, our financial condition, results of operations and cash flows for the periods presented in conformity with U.S. GAAP.

[0001375365-25-000027:item_9a:5]
(b) Management’s Annual Report on Internal Control over Financial Reporting

[0001375365-25-000027:item_9a:6]
Internal control over financial reporting refers to the process designed by, or under the supervision of, our Chief Executive Officer and Chief Financial Officer, and effected by our, management and other personnel, to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles, and includes those policies and procedures that:

[0001375365-25-000027:item_9a:7]
•pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets and liabilities;

[0001375365-25-000027:item_9a:8]
•provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and directors; and

[0001375365-25-000027:item_9a:9]
•provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of our assets and liabilities that could have a material effect on our  consolidated financial statements.

[0001375365-25-000027:item_9a:10]
SMCI | 2025 Form 10-K | 119

[0001375365-25-000027:item_9a:11]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act). Our management, including our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of June 30, 2025. In making this assessment, our management used the criteria established in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”).

[0001375365-25-000027:item_9a:12]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected in a timely basis.

[0001375365-25-000027:item_9a:13]
We have identified the following unremediated material weaknesses in internal control over financial reporting as of June 30, 2025:

[0001375365-25-000027:item_9a:14]
(i) information technology general controls for certain  systems that support our financial reporting process were not appropriately identified, designed or implemented; (ii) controls to address segregation of duties conflicts were not properly designed and appropriately implemented; (iii) controls over the completeness and accuracy of information we produce, impacting multiple financial statement areas were not properly implemented or documented; and (iv) we did not design, implement and retain appropriate documentation of control procedures to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including the timely identification and disclosure of new related party transactions.

[0001375365-25-000027:item_9a:15]
The above material weaknesses could have increased the risk of unauthorized access to certain information technology systems that support our financial reporting processes, manipulation of data that we use to produce our financial statements, and/or lack of complete and accurate information, which could lead to financial misstatements and affect our ability to report our information on a timely basis.

[0001375365-25-000027:item_9a:16]
Notwithstanding the material weaknesses in internal control over financial reporting described above, management believes and has concluded that the consolidated financial statements included in this Annual Report fairly present, in all material respects, our financial position, results of operations and cash flows for the periods presented in conformity with U.S. GAAP.

[0001375365-25-000027:item_9a:17]
(c) Inherent Limitations on Effectiveness of Controls

[0001375365-25-000027:item_9a:18]
Because of inherent limitations, internal control over financial reporting may not prevent or detect misstatements and projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-25-000027:item_9a:19]
Our independent registered public accounting firm, BDO USA, P.C., has audited our consolidated financial statements as of June 30, 2025, and for the two fiscal years then ended, included in this Annual Report which is contained in Item 8, “Financial Statements and Supplementary Data” and also as part of its audit, has issued an attestation report on our internal control over financial reporting, which is contained below.

[0001375365-25-000027:item_9a:20]
SMCI | 2025 Form 10-K | 120

[0001375365-25-000027:item_9a:21]
(d) Remediation Plan and Status

[0001375365-25-000027:item_9a:22]
We have identified and are implementing actions intended to improve the effectiveness of our internal control over financial reporting and disclosure controls and procedures and will continue to do so until the remediation of the material weaknesses identified above is complete, and we are able to conclude that both our internal control over financial reporting and our disclosure controls and procedures are effective. During the year ended June 30, 2025, we began to implement changes designed to improve our internal controls over financial reporting and to remediate the material weaknesses, including, but not limited to:

[0001375365-25-000027:item_9a:23]
•Enhancing our accounting organization’s competencies by adding additional qualified leadership personnel with strong technical accounting, external reporting and governance experience; specifically,

[0001375365-25-000027:item_9a:24]
◦identified and hired a Vice President who is qualified to lead our technical accounting, external reporting and global internal controls compliance;

[0001375365-25-000027:item_9a:25]
◦reassessed our accounting procedures and related documentation, and, as part of the financial reporting process, began implementing the use of supplementary checklists as well as conducting additional reviews and evaluations of transactions to improve the accuracy and reliability of our financial information.

[0001375365-25-000027:item_9a:26]
◦replaced certain existing financial personnel with appropriate qualified personnel  to ensure that procedures are implemented, adequate reviews are performed, and financial information as presented is accurate.

[0001375365-25-000027:item_9a:27]
◦Promoted our controller to Chief Accounting Officer.

[0001375365-25-000027:item_9a:28]
•In June 2025, we launched a global learning management and communication system, to develop and roll out appropriate compliance and other mandatory training courses, across various areas, including Finance, Compliance, Information Technology and Sales, to our global workforce to ensure that our personnel stay current on a wide variety of areas;

[0001375365-25-000027:item_9a:29]
•Established and implemented a standard policy for manual journal entry creation and posting, including clear documentation criteria, review and approval requirements based on the risk profile of the financial statement line item impacted, with  automated workflow mapping that more extensively utilizes the functionality and automation solutions available in our ERP system. This includes more rigorous enforcement of user roles and access controls to ensure oversight and prevent unauthorized entries. We believe these actions have remediated the material weakness we previously identified relating to the review and approval of manual journal entries and the prevention of any unauthorized access to post journal entries;

[0001375365-25-000027:item_9a:30]
•Completed a risk-based review of our overall IT architecture, including the composition of our IT organization and applications, to ensure that all systems that support our financial reporting processes were appropriately identified to be part of the population over which we design and maintain ITGCs. In addition, we also either designed additional controls or have executed on existing controls diligently,  including expanding the applications that are included within the scope of our Information Technology General Controls, with an increased emphasis on provisioning, change management and privileged and firefighter access related processes, thereby strengthening the design and implementation and operating effectiveness (for certain applications) of our overall information technology related processes and controls;

[0001375365-25-000027:item_9a:31]
•Re-evaluated and established and/or amended additional key entity level controls covering a wide variety of areas including but not limited to our global SOX program, fraud risk assessment, hiring practices and global corporate trainings to align closely with our overall strategies and the overall COSO framework; and

[0001375365-25-000027:item_9a:32]
•Began implementing a full redesign of our ERP system security role structure and segregation of duties (“SOD”) rulesets. This redesign is foundational to both remediating the SOD-related material weakness and building a sustainable, compliant access model. As part of this reset, we are adopting a leading practice, template driven approach, that will bring standardization to our ruleset and eliminate SOD conflicts and/or mitigate them as appropriate.

[0001375365-25-000027:item_9a:33]
Implementing and maintaining an effective financial reporting system is a continuous effort that requires us to anticipate and react to changes in our business and in the economic and regulatory environments, and to expend significant resources to maintain a financial reporting system that is adequate to satisfy our reporting obligations. As we continue to evaluate and take actions to improve our internal control over financial reporting, we may take additional actions to address control deficiencies or modify certain of the remediation measures described above.

[0001375365-25-000027:item_9a:34]
While we have made progress to enhance our internal control over financial reporting, we are still in the process of implementing these processes, procedures and controls. We will require additional time to complete implementation and to assess and ensure the long-term sustainability of these procedures. We believe the above actions will be effective in remediating the material weaknesses described above, and we will continue to devote significant time and attention to these remedial efforts. However, the material weaknesses cannot be considered remediated until the applicable remedial controls operate for a sufficient period of time and management has concluded that these controls are operating effectively.

[0001375365-25-000027:item_9a:35]
SMCI | 2025 Form 10-K | 121

[0001375365-25-000027:item_9a:36]
(e) Changes in Internal Control over Financial Reporting

[0001375365-25-000027:item_9a:37]
Except for the changes in the internal controls to remediate a material weakness over the review and approval of manual journal entries and other changes  as part of our plans to remediate the above mentioned material weaknesses as discussed above, there was no change in our internal control over financial reporting that occurred during the quarter ended June 30, 2025 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0001375365-25-000027:item_9a:38]
However, as noted above, we will be implementing changes to our internal control over financial reporting to address the material weaknesses described above.

[0001375365-25-000027:item_9a:39]
SMCI | 2025 Form 10-K | 122

[0001375365-25-000027:item_9a:40]
Report of Independent Registered Public Accounting Firm

[0001375365-25-000027:item_9a:41]
Stockholders and Board of Directors

[0001375365-25-000027:item_9a:42]
Super Micro Computer, Inc.

[0001375365-25-000027:item_9a:43]
San Jose, California

[0001375365-25-000027:item_9a:44]
Opinion on Internal Control over Financial Reporting

[0001375365-25-000027:item_9a:45]
We have audited Super Micro Computer, Inc.’s (the “Company’s”) internal control over financial reporting as of June 30, 2025, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (the “COSO criteria”). In our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of June 30, 2025, based on the COSO criteria.

[0001375365-25-000027:item_9a:46]
We do not express an opinion or any other form of assurance on management’s statements referring to any corrective actions taken by the Company after the date of management’s assessment.

[0001375365-25-000027:item_9a:47]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the consolidated balance sheets of the Company as of June 30, 2025 and 2024, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for each of the years then ended, and the related notes (collectively referred to as the “consolidated financial statements”) and our report dated August 28, 2025 expressed an unqualified opinion thereon.

[0001375365-25-000027:item_9a:48]
Basis for Opinion

[0001375365-25-000027:item_9a:49]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Item 9A, Management’s Annual Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001375365-25-000027:item_9a:50]
We conducted our audit of internal control over financial reporting in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audit also included performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001375365-25-000027:item_9a:51]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the Company’s annual or interim financial statements will not be prevented or detected on a timely basis. Material weaknesses were identified and described in management’s assessment regarding the following: (1) information technology general controls  for certain systems that support the Company's financial reporting process were not appropriately identified, designed or implemented; (2) controls to address segregation of duties conflicts were not properly designed and appropriately implemented; (3) controls over the completeness and accuracy of information produced by the entity impacting multiple financial statement areas were not properly implemented or documented; and (4) management did not design, implement and retain appropriate documentation of control procedures to achieve timely, complete and accurate recording and disclosures across multiple financial statement areas including the timely identification and disclosure of  new related party transactions. These material weaknesses were considered in determining the nature, timing, and extent of audit tests applied in our audit of the 2025 consolidated financial statements, and this report does not affect our report dated August 28, 2025 on those consolidated financial statements.

[0001375365-25-000027:item_9a:52]
SMCI | 2025 Form 10-K | 123

[0001375365-25-000027:item_9a:53]
Definition and Limitations of Internal Control over Financial Reporting

[0001375365-25-000027:item_9a:54]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001375365-25-000027:item_9a:55]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001375365-25-000027:item_9a:56]
/s/ BDO USA, P.C.

[0001375365-25-000027:item_9a:57]
San Jose, California

[0001375365-25-000027:item_9a:58]
August 28, 2025

[0001375365-25-000027:item_9a:59]
SMCI | 2025 Form 10-K | 124
