# SMCI MD&A — 0001375365-25-000027


## mdna

[0001375365-25-000027:mdna:1]
Item 7.        Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001375365-25-000027:mdna:2]
Overview

[0001375365-25-000027:mdna:3]
We are a global leader in Application-Optimized Total IT Solutions. Founded and operating in San Jose, California, we are committed to delivering first-to-market innovation for Enterprise, Cloud, AI, and 5G Telco/Edge IT Infrastructure. As a Total IT Solutions manufacturer, our offerings include server, AI systems, storage, IoT devices, switches, software, and support services. Supermicro's expertise in motherboard, power, and chassis design expertise drives our ability to develop and produce next-generation innovations, from cloud to edge, for our global customers. Our products are designed and manufactured in-house across facilities in the United States, Taiwan, and the Netherlands. Leveraging our global operations for scale and efficiency, we optimize solutions to improve TCO while reducing environmental impact through Green Computing initiatives. Our award-winning portfolio of Server Building Block Solutions empowers customers to tailor systems precisely to their exact workloads and applications. By selecting from a broad family of flexible and reusable building blocks, customers can configure a comprehensive range of form factors, processors, memory, GPUs, storage, networking, power, and cooling solutions, including air-conditioned, free air, and liquid cooling solutions.

[0001375365-25-000027:mdna:4]
We commenced operations in 1993 and have been profitable every year since inception. For fiscal years 2025, 2024, and 2023, our net income was $1,048.9 million, $1,152.7 million, and $640.0 million, respectively.

[0001375365-25-000027:mdna:5]
In order to increase our sales and profits, we believe that we must continue to develop flexible application optimized server and storage solutions while being among the first to market with new features and products. Our focus is on delivering Total IT Solutions that integrate, validate, and deliver server, storage, networking and software at the rack and cluster (multi-rack) level. Additionally, we will continue to expand our software offerings and enhance customer service and support, particularly as we increase our focus on large enterprise and data center customers. A key component of our strategy is our DCBBS, which significantly reduces data center build time and enables full integration of AI computing, server, storage, networking, rack, cabling, liquid cooling, end-to-end management software, onsite deployment services, and ongoing maintenance. To further expand our market share, we also recognize the need to strengthen our network of sales partners and distribution channels.

[0001375365-25-000027:mdna:6]
We measure our financial success based on various key indicators, including growth in net sales, gross profit margin, operating margin, and net income per common share. In additional to these financial metrics, a critical non-financial indicator of our success is our ability to rapidly introduce new products and deliver the latest application-optimized server and storage solutions. To support this, we work closely with the developers and manufacturers of key components, allowing us to integrate emerging technologies as they become available. Our ability to quickly bring new products to market, which we believe is enabled by our Building Block Solution architecture and has historically enabled us to capitalize on major technology transitions such as the launch of new GPUs, microprocessors and storage technologies. Accordingly, we closely monitor the product introduction cycles of industry leaders, including NVIDIA Corporation, Intel Corporation, Advanced Micro Devices, Inc., Broadcom Inc., Samsung Electronics Company Limited, Micron Technology, Inc. and others. This strategic focus directly informs our research and development investments, as we continue to allocate resources toward both our current initiatives and future product innovation.

[0001375365-25-000027:mdna:7]
AI and Data Centers

[0001375365-25-000027:mdna:8]
The growing use of AI, which requires enhanced datacenter capabilities, has substantially increased demand for our products. We expect this trend to continue, with further demand for datacenter expansion driven by the AI market. As a result, we will continue to enhance our product capabilities and expand our service offerings, including DCBBS to address the growing demand in the AI market and datacenter markets. We believe that our ability to tailor certain products to the unique needs of these sectors sets us apart from many competitors and positions us to capture an even greater market share going forward.

[0001375365-25-000027:mdna:9]
SMCI | 2025 Form 10-K | 41

[0001375365-25-000027:mdna:10]
Macroeconomic Factors

[0001375365-25-000027:mdna:11]
Macroeconomic factors, including inflation, interest rate changes, capital market volatility, global supply chain constraints, tariffs, and global economic and geopolitical developments, have had and may continue to have direct and indirect impacts on our business and results of operations, particularly demand for our products and net sales. While difficult to isolate and quantify, these macroeconomic factors have also impacted and may continue to impact our supply chain and manufacturing costs, employee wages, costs for capital equipment and value of our investments.  Further, while many of these macroeconomic factors could have a long term impact, others may have a short term impact which could lead to our financial results not being comparable on a period to period basis.

[0001375365-25-000027:mdna:12]
Financial Highlights

[0001375365-25-000027:mdna:13]
The following is a summary of our financial highlights for fiscal years 2025 and 2024:

[0001375365-25-000027:mdna:14]
|  |  | Years Ended June 30, |
|  |  | 2025 |  | 2024 |
| Net sales |  | $ | 21,972,042 |  |  | $ | 14,989,251 |  |
| Gross profit |  | 2,429,922 |  |  | 2,061,410 |  |
| Total operating expenses |  | 1,176,928 |  | 850,636 |  |
| Income from operations |  | 1,252,994 |  |  | 1,210,774 |  |
| Net income |  | 1,048,854 |  |  | 1,152,666 |  |
| Net income per diluted share |  | 1.68 |  |  | 1.92 |  |

[0001375365-25-000027:mdna:15]
•Net sales increased by 46.6% in fiscal year 2025 as compared to fiscal year 2024. driven by an increase in demand from customers for GPU servers, HPC and rack-scale solutions which have higher average selling prices, primarily due to large enterprise and data center customers from the United States, Asia, and Europe where we experienced significant growth.

[0001375365-25-000027:mdna:16]
•Gross margin decreased to 11.1% in fiscal year 2025 from 13.8% in fiscal year 2024, primarily due to our strategy to offer competitive pricing to gain market share, change in product and customer mix, and higher manufacturing related expenses.

[0001375365-25-000027:mdna:17]
•Operating expenses increased by 38.4% in fiscal year 2025 as compared to fiscal year 2024, primarily due to higher headcount and increases in salary and stock-based compensation.

[0001375365-25-000027:mdna:18]
•Net income decreased to $1,048.9 million in fiscal year 2025 as compared to $1,152.7 million in fiscal year 2024, which was primarily due to decrease in gross profit and increase in operating and other expenses partially, offset by the increase in net sales in fiscal year 2025 as compared to fiscal year 2024.

[0001375365-25-000027:mdna:19]
Critical Accounting Estimates

[0001375365-25-000027:mdna:20]
General

[0001375365-25-000027:mdna:21]
Our consolidated financial statements are prepared in accordance with generally accepted accounting principles in the United States (“U.S. GAAP”). The preparation of these consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. On an ongoing basis, we regularly evaluate our accounting estimates based on historical experience and on various other assumptions that we believe are reasonable under the circumstances. The actual impact on our financial performance could differ from these estimates under different assumptions or conditions.

[0001375365-25-000027:mdna:22]
An accounting estimate is considered critical if both (i) the nature of the estimates or assumptions is material due to the levels of subjectivity and judgment involved, and (ii) the impact within a reasonable range of outcomes of the estimates and assumptions is material to our consolidated financial statements. We have critical accounting estimates in the areas of inventories, revenue recognition, income taxes, when applicable, have the greatest potential impact on our consolidated financial statements. Therefore, we consider these to be our critical accounting estimates.

[0001375365-25-000027:mdna:23]
For further information on all of our significant accounting policies, see Note 1. “Organization and Summary of Significant Accounting Policies” in the notes to the consolidated financial statements in this Annual Report.

[0001375365-25-000027:mdna:24]
SMCI | 2025 Form 10-K | 42

[0001375365-25-000027:mdna:25]
Revenue Recognition

[0001375365-25-000027:mdna:26]
We generate revenue from the sale of server and storage systems, including systems and related services, subsystems and accessories.

[0001375365-25-000027:mdna:27]
We apply judgment in determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. As part of determining the transaction price in contracts with customers, we estimate reserves for future sales returns based on our history of actual returns for each major product line. Based upon historical experience, a refund liability is recorded at the time of sale for estimated product returns and an asset is recognized for the amount expected to be recorded in inventory upon product return, less the expected recovery costs.

[0001375365-25-000027:mdna:28]
We allocate the transaction price of each customer contract to each performance obligation based on the relative Standalone Selling Price (“SSP”) for each performance obligation within each contract. We recognize the amount of transaction price allocated to each performance obligation within a customer contract as revenue at the time the respective performance obligation is satisfied by transferring control of the promised good or service to a customer. Determining the relative SSP for contracts that contain multiple performance obligations requires significant judgment. We determine SSP based on the price at which the performance obligation is sold separately. If the SSP is not observable through past transactions, we apply judgment to estimate the SSP. For substantially all of the performance obligations, we are able to establish the SSP based on the observable prices of products or services sold separately in comparable circumstances to similar customers. We typically establish an SSP range for our products and services, which is reassessed on a periodic basis or when facts and circumstances change. SSP for our products and services can evolve over time due to changes in our pricing practices, internally approved pricing guidelines with respect to geographies, customer type, internal costs, and gross margin objectives for the related performance obligations which can also be influenced by intense competition, changes in demand for our products and services, economic and other factors.

[0001375365-25-000027:mdna:29]
Revenue is recognized either over time or at a point in time, depending on when control of the underlying products or services are transferred to the customer, which may require judgment. Revenue is recognized at a point in time for products. Revenue is recognized over time for extended warranty and on-site services provided and at a point in time for other services such as rack installation and integration services.

[0001375365-25-000027:mdna:30]
Inventories

[0001375365-25-000027:mdna:31]
Inventories are stated at lower of cost, using weighted average cost method, or net realizable value. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. Inventories consist of raw materials (principally electronic components), work in process (principally products being assembled) and finished goods (principally finished products and products ready for sale). We evaluate inventory on a quarterly basis for lower of cost or net realizable value and excess and obsolescence and, as necessary, write down the valuation of inventories.

[0001375365-25-000027:mdna:32]
We charge cost of sales for inventory provisions to write-down our inventory to the lower of cost or net realizable value or for obsolete or excess inventory, and for excess product purchase commitments. Most of our inventory provisions relate to excess quantities of products or components, based on our inventory levels and future product purchase commitments compared to assumptions about future demand and market conditions, which requires management judgment. Situations that may result in excess or obsolete inventory or excess product purchase commitments include changes in business and economic conditions, changes in market conditions, sudden and significant decreases in demand for our products, including potential cancellation or deferral of customer purchase orders, inventory obsolescence because of changing technology and customer requirements, new product introductions resulting in less demand for existing products or inconsistent spikes in demand, failure to estimate customer demand properly, ordering in advance of historical lead-times, government regulations and the impact of changes in future demand, or increase in demand for competitive products, including competitive actions. Net realizable value is the estimated selling price of our products in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation.

[0001375365-25-000027:mdna:33]
Our inventory and capacity purchase commitments are based on forecasts of future customer demand and consider our third-party manufacturers’ lead times and constraints. Our manufacturing lead times can be and have been long, and in some cases, extended beyond twelve months for some products. We may place non-cancellable inventory orders for certain product components in advance of our historical lead times, pay premiums and provide deposits to secure future supply and capacity. We also adjust to other market factors, such as product offerings and pricing actions by our competitors, new product transitions, and macroeconomic conditions - all of which may impact demand for our products.

[0001375365-25-000027:mdna:34]
SMCI | 2025 Form 10-K | 43

[0001375365-25-000027:mdna:35]
We receive various rebate incentives from certain suppliers based on our contractual arrangements, including volume-based rebates. The rebates earned are recognized as a reduction of cost of inventories and reduce the cost of sales in the period when the related inventory is sold.

[0001375365-25-000027:mdna:36]
Income Taxes

[0001375365-25-000027:mdna:37]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes and income tax assets and liabilities, including evaluating uncertainties in the application of accounting principles and complex tax laws.

[0001375365-25-000027:mdna:38]
Our calculation of deferred tax assets and liabilities is based on certain estimates and judgments and involves dealing with uncertainties in the application of complex tax laws. Our estimates of deferred tax assets and liabilities may change based, in part, on added certainty or finality to an anticipated outcome, changes in accounting standards or tax laws in the U.S. or foreign jurisdictions where we operate, or changes in other facts or circumstances. In addition, we recognize liabilities for potential U.S. and foreign income tax contingencies based on our estimate of whether, and the extent to which, additional taxes may be due. If we determine that payment of these amounts is unnecessary or if the recorded tax liability is less than our current assessment, we may be required to recognize an income tax benefit or additional income tax expense in our financial statements accordingly.

[0001375365-25-000027:mdna:39]
We record a valuation allowance to reduce deferred tax assets to the amount that is believed more likely than not to be realized based on all available evidence. To the extent realization of the deferred tax assets becomes more-likely-than-not, we would recognize such deferred tax assets as income tax benefits during the period.

[0001375365-25-000027:mdna:40]
We recognize the benefit from a tax position only if it is more-likely-than-not that the position would be sustained upon audit based solely on the technical merits of the tax position. Our policy is to include interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0001375365-25-000027:mdna:41]
Results of Operations

[0001375365-25-000027:mdna:42]
Components of Results of Operations

[0001375365-25-000027:mdna:43]
Net Sales

[0001375365-25-000027:mdna:44]
Net sales primarily consist of sales of our server and storage solutions, including systems and related services, subsystems, and accessories. The key factors that impact net sales of our server and storage systems are the number of servers and racks sold, as well as the average selling prices per server or rack. For subsystems and accessories, the main drivers of net sales are the number of units shipped and the average selling price per unit. The prices for our server and storage systems can vary widely depending on the configuration, including factors such as speed, functionality and performance of key components, including CPUs, GPUs, SSDs, cooling systems, and memory. Similarly, the prices for our subsystems and accessories fluctuate depending on the relative value of the specific item being purchased. such as power supplies, server boards, chassis or other accessories.

[0001375365-25-000027:mdna:45]
Cost of Sales, Gross Profit and Gross Margin

[0001375365-25-000027:mdna:46]
Cost of sales primarily consists of the costs to manufacture our products, which includes: the costs of components and materials, contract manufacturing, shipping, personnel expenses (salaries, benefits, stock-based compensation and incentive bonuses), equipment and facility expenses, warranty costs and inventory reserve charges.

[0001375365-25-000027:mdna:47]
We use several suppliers and contract manufacturers to design and manufacture subsystems in accordance with our specifications, with most final assembly and testing performed at our manufacturing facilities in the region where our products are sold. We work with Ablecom, one of our key contract manufacturers and a related party, for our chassis and certain other components. We also outsource a significant part of the manufacturing of certain components, particularly power supplies, to Compuware, also a related party. We also collaborate on design and development activities with Ablecom and Compuware, where we substantially fund the design costs and retain the intellectual property rights. Our purchases of products from Ablecom and Compuware combined represented 3.3%, 4.3%, and 6.6% of our cost of sales for fiscal years 2025, 2024, and 2023, respectively. For further details on our dealings with related parties, see Note 10, “Related Party Transactions” in the notes to the consolidated financial statements.

[0001375365-25-000027:mdna:48]
SMCI | 2025 Form 10-K | 44

[0001375365-25-000027:mdna:49]
Research and Development

[0001375365-25-000027:mdna:50]
Research and development expenses consist of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our research and development personnel, as well as product development costs such as materials and supplies, consulting services, third-party testing services and equipment and facility expenses related to our research and development activities.

[0001375365-25-000027:mdna:51]
Sales and Marketing

[0001375365-25-000027:mdna:52]
Sales and marketing expenses consist primarily of personnel expenses including salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our sales and marketing personnel, cost for trade shows, sales representative fees and marketing programs. From time to time, we receive marketing development funding from certain suppliers. Under these arrangements, we are reimbursed for certain marketing costs that we incur as part of the joint promotion of our products and those of our suppliers. These amounts offset a portion of the related expenses and have the effect of reducing our reported sales and marketing expenses.

[0001375365-25-000027:mdna:53]
General and Administrative

[0001375365-25-000027:mdna:54]
General and administrative expenses consist primarily of general corporate costs, including personnel expenses such as salaries, benefits, stock-based compensation and incentive bonuses, and related expenses for our general and administrative personnel, financial reporting, corporate governance and compliance, outside legal, audit, tax fees, insurance and credit losses on accounts receivable.

[0001375365-25-000027:mdna:55]
Other Income, Net and Interest Expense

[0001375365-25-000027:mdna:56]
Other income, net and interest expense consists of interest earned on our investments and cash balances, interest incurred on our debt, and foreign exchange gains and losses.

[0001375365-25-000027:mdna:57]
Income Tax Provision

[0001375365-25-000027:mdna:58]
Our income tax provision is based on our taxable income generated in the jurisdictions in which we operate, which primarily include the United States, Taiwan, and the Netherlands. Our effective tax rate differs from the statutory rate primarily due to research and development tax credits, certain non-deductible expenses, tax benefits from foreign derived intangible income, and stock-based compensation. A reconciliation of the federal statutory income tax rate to our effective tax rate is set forth in Note 12, “Income Taxes” in the notes to the consolidated financial statements in this Annual Report.

[0001375365-25-000027:mdna:59]
SMCI | 2025 Form 10-K | 45

[0001375365-25-000027:mdna:60]
The following table presents certain items of our consolidated statements of operations for the years ended June 30, 2025, 2024, and 2023 (in millions):

[0001375365-25-000027:mdna:61]
|  | Years Ended June 30, |
|  | 2025 |  | 2024* |  | 2023* |
| Net sales | $ | 21,972.0 |  |  | $ | 14,989.2 |  |  | $ | 7,123.5 |  |
| Cost of sales | 19,542.1 |  |  | 12,927.8 |  |  | 5,840.5 |  |
| Gross profit | 2,429.9 |  |  | 2,061.4 |  |  | 1,283.0 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 636.6 |  |  | 463.5 |  |  | 307.3 |  |
| Sales and marketing | 273.1 |  |  | 189.7 |  |  | 115.0 |  |
| General and administrative | 267.2 |  |  | 197.4 |  |  | 99.6 |  |
| Total operating expenses | 1,176.9 |  |  | 850.6 |  |  | 521.9 |  |
| Income from operations | 1,253.0 |  |  | 1,210.8 |  |  | 761.1 |  |
| Other income, net | 18.5 |  |  | 22.7 |  |  | 3.6 |  |
| Interest expense | (59.6) |  |  | (19.4) |  |  | (10.5) |  |
| Income before income tax provision | 1,211.9 |  |  | 1,214.1 |  |  | 754.3 |  |
| Income tax provision | (156.8) |  |  | (63.3) |  |  | (110.7) |  |
| Share of income (loss) from equity investee, net of taxes | (6.2) |  |  | 1.8 |  |  | (3.6) |  |
| Net income | $ | 1,048.9 |  |  | $ | 1,152.7 |  |  | $ | 640.0 |  |

[0001375365-25-000027:mdna:62]
* Totals may not sum due to rounding.

[0001375365-25-000027:mdna:63]
The following table presents certain items of our consolidated statements of operations expressed as a percentage of net sales for the years ended June 30, 2025, 2024, and 2023:

[0001375365-25-000027:mdna:64]
|  | Years Ended June 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Net sales | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of sales | 88.9 | % |  | 86.2 | % |  | 82.0 | % |
| Gross profit | 11.1 | % |  | 13.8 | % |  | 18.0 | % |
| Operating expenses: |  |  |  |  |  |
| Research and development | 2.9 | % |  | 3.1 | % |  | 4.3 | % |
| Sales and marketing | 1.2 | % |  | 1.3 | % |  | 1.6 | % |
| General and administrative | 1.3 | % |  | 1.3 | % |  | 1.4 | % |
| Total operating expenses | 5.4 | % |  | 5.7 | % |  | 7.3 | % |
| Income from operations | 5.7 | % |  | 8.1 | % |  | 10.7 | % |
| Other income, net | 0.1 | % |  | 0.1 | % |  | 0.1 | % |
| Interest expense | (0.3) | % |  | (0.1) | % |  | (0.1) | % |
| Income before income tax provision | 5.5 | % |  | 8.1 | % |  | 10.7 | % |
| Income tax provision | (0.7) | % |  | (0.4) | % |  | (1.6) | % |
| Share of income (loss) from equity investee, net of taxes | — | % |  | — | % |  | (0.1) | % |
| Net income | 4.8 | % |  | 7.7 | % |  | 9.0 | % |

[0001375365-25-000027:mdna:65]
SMCI | 2025 Form 10-K | 46

[0001375365-25-000027:mdna:66]
Net Sales by Product Type

[0001375365-25-000027:mdna:67]
The following table presents net sales by product type for fiscal years 2025, 2024, and 2023 (dollars in millions):

[0001375365-25-000027:mdna:68]
|  | Years Ended June 30, |  | 2025 over 2024 Change |  | 2024 over 2023 Change |
|  | 2025 |  | 2024 |  | 2023 |  | $ |  | % |  | $ |  | % |
| Server and storage systems | $ | 21,311.6 |  |  | $ | 14,185.2 |  |  | $ | 6,569.8 |  |  | $ | 7,126.4 |  |  | 50.2 | % |  | $ | 7,615.4 |  |  | 115.9 | % |
| Percentage of total net sales | 97.0 | % |  | 94.6 | % |  | 92.2 | % |  |  |  |  |  |  |  |  |
| Subsystems and accessories | $ | 660.4 |  |  | 804.0 |  |  | 553.7 |  |  | (143.6) |  |  | (17.9) | % |  | 250.3 |  |  | 45.2 | % |
| Percentage of total net sales | 3.0 | % |  | 5.4 | % |  | 7.8 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 21,972.0 |  |  | $ | 14,989.2 |  |  | $ | 7,123.5 |  |  | $ | 6,982.8 |  |  | 46.6 | % |  | $ | 7,865.7 |  |  | 110.4 | % |

[0001375365-25-000027:mdna:69]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-25-000027:mdna:70]
During fiscal year 2025, we experienced increased net sales from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to the strong demand and increased billings for GPU & Super Racks of $5,804.0 million or 52% compared to prior year, including liquid-cooled and air-cooled servers which are generally more complex and of higher value, primarily related to our H200, H100, and B200 systems, resulting in an increase of average selling price of 34%. Our services and software net sales, included in server and storage systems net sales, increased by $102.2 million year-over-year.

[0001375365-25-000027:mdna:71]
The year-over-year decrease in net sales for our subsystems and accessories is primarily due to our strategic shift to focus on prioritizing sales of our server and storage systems.

[0001375365-25-000027:mdna:72]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000027:mdna:73]
During fiscal year 2024, we experienced increased net sales from server and storage systems, particularly from our large enterprise and datacenter customers. The year-over-year increase in net sales of server and storage systems was primarily due to the strong demand for GPU based rack-scale solutions, including liquid-cooled and air-cooled servers which are generally more complex and of higher value, resulting in an increase of average selling prices.

[0001375365-25-000027:mdna:74]
The year-over-year increase in net sales for our subsystems and accessories is primarily due to increased demand of accessories sold to our larger enterprise and data center customers as more accessories and spares were purchased in conjunction with the increased volume of full systems and servers. Our services and software net sales, included in server and storage systems net sales, increased by $53.8 million year-over-year.

[0001375365-25-000027:mdna:75]
Net Sales by Geography

[0001375365-25-000027:mdna:76]
The following table presents percentages of net sales by geographic region for fiscal years 2025, 2024, and 2023 (dollars in millions):

[0001375365-25-000027:mdna:77]
|  | Years Ended June 30, |  | 2025 over 2024 Change |  | 2024 over 2023 Change |
|  | 2025 |  | 2024 |  | 2023 |  | $ |  | % |  | $ |  | % |
| United States | $ | 13,052.6 |  |  | $ | 10,187.2 |  |  | $ | 4,834.1 |  |  | $ | 2,865.4 |  |  | 28.1 | % |  | $ | 5,353.1 |  |  | 110.7 | % |
| Percentage of total net sales | 59.4 | % |  | 68.0 | % |  | 67.9 | % |  |  |  |  |  |  |  |  |
| Asia | 5,494.1 |  |  | 2,912.6 |  |  | 1,050.8 |  |  | 2,581.5 |  |  | 88.6 | % |  | 1,861.8 |  |  | 177.2 | % |
| Percentage of total net sales | 25.0 | % |  | 19.4 | % |  | 14.7 | % |  |  |  |  |  |  |  |  |
| Europe | 2,727.0 |  |  | 1,294.0 |  |  | 1,003.1 |  |  | 1,433.0 |  |  | 110.7 | % |  | 290.9 |  |  | 29.0 | % |
| Percentage of total net sales | 12.4 | % |  | 8.6 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |
| Others | 698.3 |  |  | 595.4 |  |  | 235.5 |  |  | 102.9 |  |  | 17.3 | % |  | 359.9 |  |  | 152.8 | % |
| Percentage of total net sales | 3.2 | % |  | 4.0 | % |  | 3.3 | % |  |  |  |  |  |  |  |  |
| Total net sales | $ | 21,972.0 |  |  | $ | 14,989.2 |  |  | $ | 7,123.5 |  |  | $ | 6,982.8 |  |  | 46.6 | % |  | $ | 7,865.7 |  |  | 110.4 | % |

[0001375365-25-000027:mdna:78]
SMCI | 2025 Form 10-K | 47

[0001375365-25-000027:mdna:79]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-25-000027:mdna:80]
The year-over-year increase in total net sales is driven by an increase in demand from customers for GPU servers, HPC and rack-scale solutions which have higher average selling prices, especially from large enterprise and data center customers resulting in increased sales of 28.1% in the United States, 85.9% in Thailand and Japan, and 111.9% in the United Kingdom, Sweden, and Spain, where we have experienced significant growth.

[0001375365-25-000027:mdna:81]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000027:mdna:82]
The year-over-year increase in total net sales is driven by an increase in demand from customers for GPU servers, HPC and rack-scale solutions which have higher average selling prices, especially for large enterprise and data center customers from the United States. The year-over-year increase of net sales in the regions outside the United States is mainly due to an increase in net sales in Singapore, Taiwan, South Africa and Germany, including the increase in demand from customers for GPU servers in those countries.

[0001375365-25-000027:mdna:83]
Cost of Sales, Gross Profit, and Gross Margin

[0001375365-25-000027:mdna:84]
Cost of sales and gross margin for fiscal years 2025, 2024, and 2023 are as follows (dollars in millions):

[0001375365-25-000027:mdna:85]
|  | Years Ended June 30, |  | 2025 over 2024 Change |  | 2024 over 2023 Change |
|  | 2025 |  | 2024 |  | 2023 |  | $ |  | % |  | $ |  | % |
| Cost of sales | $ | 19,542.1 |  |  | $ | 12,927.8 |  |  | $ | 5,840.5 |  |  | $ | 6,614.3 |  |  | 51.2 | % |  | $ | 7,087.3 |  |  | 121.3 | % |
| Gross profit | 2,429.9 |  |  | 2,061.4 |  |  | 1,283.0 |  |  | 368.5 |  |  | 17.9 | % |  | 778.4 |  |  | 60.7 | % |
| Gross margin | 11.1 | % |  | 13.8 | % |  | 18.0 | % |  |  |  | (2.7) | % |  |  |  | (4.2) | % |

[0001375365-25-000027:mdna:86]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-25-000027:mdna:87]
The year-over-year increase in cost of sales was primarily attributed to an increase of $6,353.2 million or 50.6% in costs of components, materials, and contract manufacturing expenses primarily due to increases in shipments of GPU servers, HPC, and rack-scale solutions which have higher costs and a $86.5 million or 493.6% increase in tariff expense related to new trade policies enacted during the year, a $149.6 million or 179.2% increase in inventory write-down adjustments from aged inventory, a $67.9 million or 28.6% increase in overhead costs which includes higher labor costs attributed to increase of operating activities, and a $43.6 million or 75.5% increase in freight charges.

[0001375365-25-000027:mdna:88]
The year-over-year decrease of 2.7% in gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition and a change in product and customer mix.

[0001375365-25-000027:mdna:89]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000027:mdna:90]
The year-over-year increase in cost of sales was primarily attributed to an increase of $7,006.7 million in costs of components, materials and contract manufacturing expenses primarily related to the increase in shipments of GPU servers, HPC, and rack scale solutions which have higher costs, a $52.3 million increase in inventory write-down adjustments, a $19.6 million increase in overhead costs which includes labor costs attributed to increase of operation activities and a $8.7 million increase in freight charges.

[0001375365-25-000027:mdna:91]
The year-over-year decrease in the gross margin percentage was primarily due to our strategy to offer competitive pricing to gain market share, increased competition and a change in product and customer mix.

[0001375365-25-000027:mdna:92]
SMCI | 2025 Form 10-K | 48

[0001375365-25-000027:mdna:93]
Operating Expenses

[0001375365-25-000027:mdna:94]
Operating expenses for fiscal years 2025, 2024, and 2023 are as follows (dollars in millions):

[0001375365-25-000027:mdna:95]
|  | Years Ended June 30, |  | 2025 over 2024 Change |  | 2024 over 2023 Change |
|  | 2025 |  | 2024 |  | 2023 |  | $ |  | % |  | $ |  | % |
| Research and development | $ | 636.6 |  |  | $ | 463.5 |  |  | $ | 307.3 |  |  | $ | 173.1 |  |  | 37.3 | % |  | $ | 156.2 |  |  | 50.8 | % |
| Percentage of total net sales | 2.9 | % |  | 3.1 | % |  | 4.3 | % |  |  |  |  |  |  |  |  |
| Sales and marketing | 273.1 |  |  | 189.7 |  |  | 115.0 |  |  | 83.4 |  |  | 44.0 | % |  | 74.7 |  |  | 65.0 | % |
| Percentage of total net sales | 1.2 | % |  | 1.3 | % |  | 1.6 | % |  |  |  |  |  |  |  |  |
| General and administrative | 267.2 |  |  | 197.4 |  |  | 99.6 |  |  | 69.8 |  |  | 35.4 | % |  | 97.8 |  |  | 98.2 | % |
| Percentage of total net sales | 1.3 | % |  | 1.3 | % |  | 1.4 | % |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 1,176.9 |  |  | $ | 850.6 |  |  | $ | 521.9 |  |  | $ | 326.3 |  |  | 38.4 | % |  | $ | 328.7 |  |  | 63.0 | % |

[0001375365-25-000027:mdna:96]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-25-000027:mdna:97]
Research and development expenses. The year-over-year increase in research and development expenses was primarily driven by a $153.2 million or 34.7% increase in employee-related costs, mainly comprised of a $81.0 million or 70.0% increase in stock-based compensation, and $60.2 million or 20.2% increase in salaries, as we expanded our workforce and invested in key talent. Additionally, there was a $28.3 million or 78.3% increase in product development costs to support the development of next-generation products and technologies. These increases along with other immaterial cost increases were partially offset by an $11.0 million or 50.9% increase in research and development fees received from certain suppliers and customers. Looking ahead, we expect research and development expenses to continue to rise as we expand our workforce and invest in key talent to remain at the forefront of innovation in next-generation products and technologies.

[0001375365-25-000027:mdna:98]
Sales and marketing expenses. The year-over-year increase in sales and marketing expenses was primarily driven by a $53.5 million or 30.9% increase in employee-related costs, mainly due to a $30.9 million  or 23.0% increase in salaries and a $16.6 million or 78.3% increase in stock-based compensation, similarly to our research and development expenses as we expanded our workforce and invested in key talent company-wide. Additionally, there was a $50.0 million or 164.6% increase in advertising, travel, and other related expenses due to an increase in our marketing efforts to support the launch and promotion of new products. These increases, along with other immaterial cost increases, were partially offset by a $20.8 million or 132.6% increase in additional marketing development fees received from certain vendors. Looking ahead, we expect sales and marketing expenses to continue to rise as we expand our workforce and invest in key talent.

[0001375365-25-000027:mdna:99]
General and administrative expenses. The year-over-year increase in general and administrative expenses was primarily driven by a $74.0 million or 241.0% increase in professional and service fees, reflecting higher costs for external accounting, audit, tax, legal, and advisory services, primarily driven by the Special Committee investigation and the delay in filing our Annual Report on Form 10-K for fiscal year 2024. These services were necessary to support enhancements in our external reporting processes and compliance activities during fiscal year ended 2025. Additionally, there was a $20.7 million or 37.5% increase in facilities costs such as rental costs, utility costs, and indirect depreciation costs, which are related to our efforts to expand our production capacity in order to support growing customer demands. These increases, along with other immaterial cost increases, were partially offset by a $22.8 million or 28.6% decrease in employee-related costs related to stock-based compensation. Looking ahead, we expect general and administrative expenses to continue rising as we invest in process improvements, expand our workforce, and attract key talent to support our strategic initiatives and operational growth.

[0001375365-25-000027:mdna:100]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000027:mdna:101]
Research and development expenses. The year-over-year increase in research and development expenses was driven by a $140.4 million increase in employee related costs primarily due to stock-based compensation increases of $84.2 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $17.1 million increase in product development costs to support next generation products and technologies, offset by a $1.3 million increase in research and development fees. We believe that research and development expenses will continue to increase as we continue to expand our workforce and invest in key talent to stay at the forefront of development of next generation products and technologies.

[0001375365-25-000027:mdna:102]
SMCI | 2025 Form 10-K | 49

[0001375365-25-000027:mdna:103]
Sales and marketing expenses. The year-over-year increase in sales and marketing expenses was driven by a $64.8 million increase in employee related costs primarily due to stock-based compensation increases of $16.6 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, a $10.6 million increase in advertising and other expenses offset by a $0.7 million increase in marketing development fees received. We believe that sales and marketing expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000027:mdna:104]
General and administrative expenses. The year-over-year increase in general and administrative expenses was driven by a $74.4 million increase in employee related costs primarily due to stock-based compensation increases of $65.0 million, salary increases and higher headcount as we expanded our workforce and invested in key talent, and a $23.4 million increase in professional and service fees and other expenses. We believe that general and administrative expenses will continue to increase as we continue to expand our workforce and invest in key talent.

[0001375365-25-000027:mdna:105]
Other Income, Net and Interest Expense

[0001375365-25-000027:mdna:106]
Other income, net and interest expense for fiscal years 2025, 2024, and 2023 are as follows (dollars in millions):

[0001375365-25-000027:mdna:107]
|  | Years Ended June 30, |  | 2025 over 2024 Change |  | 2024 over 2023 Change |
|  | 2025 |  | 2024 |  | 2023 |  | $ |  | % |  | $ |  | % |
| Other income, net | $ | 18.5 |  |  | $ | 22.7 |  |  | $ | 3.6 |  |  | $ | (4.2) |  |  | (18.5) | % |  | $ | 19.1 |  |  | 530.6 | % |
| Interest expense | (59.6) |  |  | (19.4) |  |  | (10.5) |  |  | (40.2) |  |  | 207.2 | % |  | (8.9) |  |  | 84.8 | % |
| Other income, net and interest expense | $ | (41.1) |  |  | $ | 3.3 |  |  | $ | (6.9) |  |  | $ | (44.4) |  |  | (1,345.5) | % |  | $ | 10.2 |  |  | (147.8) | % |

[0001375365-25-000027:mdna:108]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-25-000027:mdna:109]
The year-over-year decrease in other income, net, was primarily attributable to a $30.3 million or 100.0% increase for loss on extinguishment of our Original 2029 Convertible Notes resulting from the 2029 Convertible Notes Amendments (see Note 8, “Convertible Notes”), and a $17.9 million or 283.8% increase in foreign exchange losses. The increase in interest expense was primarily due to a $34.6 million or 1774.1% increase in interest and amortization related to the amended 2029 Convertible Note and newly issued 2028 Convertible Notes and 2030 Convertible Notes. These increases in expense were partially offset by a $15.7 million or 119.5% net movement in investment gains/(loss), as we incurred a loss in prior year of $13.1 million and a gain in the current year of $2.6 million, and a $31.0 million or 104.8% increase in interest income due to higher average monthly cash balances held in interest-bearing demand deposit accounts.

[0001375365-25-000027:mdna:110]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000027:mdna:111]
The increase in Other income, net of $19.1 million was driven by an increase of $26.1 million in interest income due to higher balances held in interest-bearing deposit accounts during the year, and an increase in foreign currency exchange gain of $6.1 million due to a strong US dollar, offset by a $13.1 million investment and impairment loss in equity securities. The increase in interest expense of $8.9 million was due to higher borrowing and higher interest rates on our outstanding line of credit and term loan balances.

[0001375365-25-000027:mdna:112]
Income Tax Provision

[0001375365-25-000027:mdna:113]
Provision for income taxes and effective tax rates for fiscal years 2025, 2024, and 2023 are as follows (dollars in millions):

[0001375365-25-000027:mdna:114]
|  | Years Ended June 30, |  | 2025 over 2024 Change |  | 2024 over 2023 Change |
|  | 2025 |  | 2024 |  | 2023 |  | $ |  | % |  | $ |  | % |
| Income tax provision | $ | (156.8) |  |  | $ | (63.3) |  |  | $ | (110.7) |  |  | $ | (93.5) |  |  | 147.7 | % |  | $ | 47.4 |  |  | (42.8) | % |
| Effective tax rate | (12.9) | % |  | (5.2) | % |  | (14.7) | % |  |  |  |  |  |  |  |  |

[0001375365-25-000027:mdna:115]
SMCI | 2025 Form 10-K | 50

[0001375365-25-000027:mdna:116]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-25-000027:mdna:117]
The year-over year increase in the effective tax rate is attributable to a decrease in the stock compensation tax deduction and lower research and development tax credits, both driven by the decrease in our stock price. The total effective tax rate increased by 7.7%, from 5.2% in fiscal year 2024, to 12.9% in fiscal year 2025.

[0001375365-25-000027:mdna:118]
Subsequent to June 30, 2025, the OBBBA was enacted in the U.S. on July 4, 2025. The OBBBA includes significant provisions, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions effective in 2025 and others implemented through 2027. We are currently assessing its impact on our consolidated financial statements.

[0001375365-25-000027:mdna:119]
In December 2023, Malaysia enacted legislation to implement the OECD Pillar Two global minimum tax framework effective January 1, 2025. Our Malaysian subsidiary was incorporated in October 2022 and commenced operations in July 2025, at which time it began a 10-year income tax exemption under an approved government incentive program. We continue to monitor administrative guidance from the OECD and tax authorities regarding the interaction between the 10-year tax holiday and the 15% minimum tax requirement under Pillar Two and will evaluate the impact of such guidance when issued to determine whether adjustments to our income tax provision or financial statement disclosures are required.

[0001375365-25-000027:mdna:120]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000027:mdna:121]
The year-over-year decrease in the effective tax rate is attributable to higher tax deductions from stock-based compensation, an increase in the R&D tax credit. As a result of these favorable elements which were partially offset by certain unfavorable items including an increase in IRC section 162(m) officers’ compensation tax add back, the total effective tax rate decreased by 9.5%, from 14.7% in fiscal year 2023, to 5.2% in fiscal year 2024.

[0001375365-25-000027:mdna:122]
Share of Income (Loss) from Equity Investee, Net of Taxes

[0001375365-25-000027:mdna:123]
Share of income (loss) from equity investee, net of taxes represents our share of income (loss) from the Corporate Venture in which we have a 30% ownership.

[0001375365-25-000027:mdna:124]
Share of income (loss) from equity investee, net of taxes for fiscal years 2025, 2024 and 2023 are as follows (dollars in millions):

[0001375365-25-000027:mdna:125]
|  | Years Ended June 30, |  | 2025 over 2024 Change |  | 2024 over 2023 Change |
|  | 2025 |  | 2024 |  | 2023 |  | $ |  | % |  | $ |  | % |
| Share of income (loss) from equity investee, net of taxes | $ | (6.2) |  |  | $ | 1.8 |  |  | $ | (3.6) |  |  | $ | (8.0) |  |  | (444.4) | % |  | $ | 5.4 |  |  | (150.0) | % |
| Percentage of total net sales | — | % | * | — | % | * | (0.1) | % |  |  |  |  |  |  |  |  |

[0001375365-25-000027:mdna:126]
* Represents an amount less than 0.1%.

[0001375365-25-000027:mdna:127]
Fiscal Year 2025 Compared with Fiscal Year 2024

[0001375365-25-000027:mdna:128]
The period-over-period decrease of $8.0 million in share of income from equity investee, net of taxes was primarily due to reduction in profitability from reduced sales of the Corporate Venture. During the year ended June 30, 2025, we recognized an impairment of $6.7 million on this investment. Refer to Note 10, “Related Party Transactions” for more details.

[0001375365-25-000027:mdna:129]
Fiscal Year 2024 Compared with Fiscal Year 2023

[0001375365-25-000027:mdna:130]
The period-over-period increase of $5.4 million in share of income from equity investee, net of taxes was primarily due to improvement in profitability from increased sales of the Corporate Venture.

[0001375365-25-000027:mdna:131]
SMCI | 2025 Form 10-K | 51

[0001375365-25-000027:mdna:132]
Liquidity and Capital Resources

[0001375365-25-000027:mdna:133]
We have financed our growth primarily with funds generated from operations, as well as utilizing borrowing facilities, selling our common stock, and issuing convertible notes. Recent drivers of liquidity changes included an increase in the need for working capital due to higher levels of inventory required by growing revenues, greater requests for longer payment terms from customers due to increasing system costs and to a lesser extent longer supply chain lead times on certain key components. Our cash and cash equivalents were $5,169.9 million and $1,669.8 million as of June 30, 2025 and 2024, respectively. Our cash and cash equivalents held in foreign locations was $607.2 million and $337.3 million as of June 30, 2025 and 2024, respectively.

[0001375365-25-000027:mdna:134]
Amounts held outside of the United States are typically used to meet non-U.S. liquidity needs. Repatriations of these funds are generally not subject to U.S. federal income tax, though state income or foreign withholding taxes may apply. In cases where local restrictions prevent the intercompany transfer of funds, our strategy is to retain cash balances outside the U.S. and meet liquidity needs through operating cash flows, external borrowings, or both. We do not expect restrictions or potential taxes on the repatriation of amounts held outside the U.S. to materially affect our overall liquidity, financial condition, or results of operations.

[0001375365-25-000027:mdna:135]
We believe that our current cash, cash equivalents, borrowing capacity available from our credit facilities and internally generated cash flows will be sufficient to support our operating businesses and maturing debt and interest payments for the 12 months following the issuance of these consolidated financial statements. We continue to assess financing options that may be necessary to support the growth of our business.

[0001375365-25-000027:mdna:136]
Our key cash flow metrics were as follows (in millions):

[0001375365-25-000027:mdna:137]
|  | Years Ended June 30, |  | 2025 over 2024 |  | 2024 over 2023 |  |  |
|  | 2025 |  | 2024 |  | 2023 |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 1,659.5 |  |  | $ | (2,486.0) |  |  | $ | 663.6 |  |  | $ | 4,145.5 |  |  | $ | (3,149.6) |  |  |  |
| Net cash used in investing activities | (183.2) |  |  | (194.2) |  |  | (39.5) |  |  | 11.0 |  |  | (154.7) |  |  |  |
| Net cash provided by (used in) financing activities | 2,024.0 |  |  | 3,911.7 |  |  | (448.3) |  |  | (1,887.7) |  |  | 4,360.0 |  |  |  |
| Effect of exchange rate fluctuations on cash | 1.7 |  |  | (2.2) |  |  | (3.4) |  |  | 3.9 |  |  | 1.2 |  |  |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 3,502.0 |  |  | $ | 1,229.3 |  |  | $ | 172.4 |  |  | $ | 2,272.7 |  |  | $ | 1,056.9 |  |  |  |

[0001375365-25-000027:mdna:138]
Operating Activities

[0001375365-25-000027:mdna:139]
Net cash provided by operating activities during fiscal 2025 mostly consisted of $1,048.9 million net income adjusted for certain non-cash items, such as $314.5 million of share-based compensation expense, $58.3 million of depreciation and amortization expense, and changes in working capital. The increase in cash flows from operating activities during fiscal 2025 compared to fiscal 2024, was due to an increase in cash collection from our customers driven by the increase in revenue reduction in inventory purchase, partially offset by higher cash paid for interest and other operational spending.

[0001375365-25-000027:mdna:140]
Investing Activities

[0001375365-25-000027:mdna:141]
Net cash used in investing activities during fiscal 2025 mostly consisted of $127.2 million of purchases of property, plant, and equipment as we continued to invest in servers, data centers, and network infrastructure, and $56.0 million of net purchases of non-marketable equity securities. The decrease in cash used in investing activities during fiscal 2025 compared to fiscal 2024 was mostly due to decreases in net purchases of non-marketable equity securities, partially offset by higher purchases of property, plant, and equipment.

[0001375365-25-000027:mdna:142]
Financing Activities

[0001375365-25-000027:mdna:143]
Net cash provided by financing activities during fiscal 2025 mostly consisted of issuance of the 2028 Convertible Notes and the 2030 Convertible Notes of $683.7 million and $2,256.0 million, respectively, partially offset by common stock repurchase of $200.0 million and net repayment of debts. The decrease in cash provided by financing activities during fiscal 2025 compared to fiscal 2024, was mostly due to decrease in issuance of common stock, decrease in proceeds from debt, and increase in repurchase of common stock, partially offset by increase in issuance of the convertible notes.

[0001375365-25-000027:mdna:144]
SMCI | 2025 Form 10-K | 52

[0001375365-25-000027:mdna:145]
Material Cash Requirements

[0001375365-25-000027:mdna:146]
Refer to Note 7, “Lines of Credit and Term Loans” in the notes to the consolidated financial statements in this Annual Report for further information on our outstanding debt.

[0001375365-25-000027:mdna:147]
Refer to Note 8, “Convertible Notes”, in the notes to the consolidated financial statements in this Annual Report for further information on the amendment of the terms of the 2029 Convertible Notes, and the issuance of the 2028 Convertible Notes and the 2030 Convertible Notes.

[0001375365-25-000027:mdna:148]
Capital Expenditure Requirements

[0001375365-25-000027:mdna:149]
We anticipate our capital expenditures for the fiscal year 2026 will be in range of $180.0 million to $200.0 million, primarily relating to costs associated with our global manufacturing capabilities, including tooling for new products, new information technology investments, and facilities upgrades and expansion. We will also continue to evaluate new business opportunities and new markets. As a result, our future growth within the existing business or new opportunities and markets may dictate the need for additional facilities and capital expenditures to support that growth. We evaluate capital expenditure projects based on a variety of factors, including expected strategic impacts (such as forecasted impact on net sales growth, productivity, expenses, service levels and customer retention).

[0001375365-25-000027:mdna:150]
Our future capital requirements will depend on a variety of factors, including our growth rate, the timing and scale of investments to support product development, the expansion of sales and marketing efforts, the launch of new and enhanced software and services offerings, and continued investments in our office facilities and IT system infrastructure.

[0001375365-25-000027:mdna:151]
Contractual Obligations

[0001375365-25-000027:mdna:152]
Our estimated future obligations as of June 30, 2025, include both current and long-term obligations. For our long-term debt as noted in Note 7, “Lines of Credit and Term Loans” in the notes to the consolidated financial statements, we have a current obligation of $75.1 million and a long-term obligation of $37.4 million. Additionally, as noted in Note 8, “Convertible Notes” in the notes to the consolidated financial statements, we have a convertible debt obligation of $4,725.0 million. Under our operating leases as noted in Note 9, “Leases” in the notes to the consolidated financial statements, we have a current obligation of $21.2 million and a long-term obligation of $280.4 million. Pursuant to the data center lease agreement dated June 14, 2025, we anticipate making an approximately $117.7 million lease payment subject to the remaining tranches expected to commence on October 2, 2025, which is not reflected in the consolidated balance sheets as the lease has not commenced. As noted in Note 13, “Commitments and Contingencies” in the notes to the consolidated financial statements, we have current obligations related to non-cancelable purchase commitments of $1.6 billion.

[0001375365-25-000027:mdna:153]
Recent Accounting Pronouncements

[0001375365-25-000027:mdna:154]
For a description of recent accounting pronouncements, including the expected dates of adoption and estimated effects, if any, on our consolidated financial statements, see Note 1, “Organization and Summary of Significant Accounting Policies” in the notes to the consolidated financial statements in this Annual Report.

[0001375365-25-000027:mdna:155]
SMCI | 2025 Form 10-K | 53
