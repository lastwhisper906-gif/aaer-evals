# EXTR MD&A — 0001564590-21-005006


## mdna

[0001564590-21-005006:mdna:1]
[same as prior period, unchanged from 0001564590-20-048853:mdna:1]

[0001564590-21-005006:mdna:2]
[same as prior period, unchanged from 0001564590-20-048853:mdna:2]

[0001564590-21-005006:mdna:3]
[same as prior period, unchanged from 0001564590-20-048853:mdna:3]

[0001564590-21-005006:mdna:4]
Extreme is a leader in providing cloud-driven networking solutions for enterprise, data center, and service provider customers. Providing a combined end-to-end solution from the Internet of Things (“IoT”) edge to the cloud, Extreme designs, develops, and manufactures wired and wireless network infrastructure equipment as well as designs and develops a leading cloud networking platform and application portfolio using cloud management, machine learning, and artificial intelligence to deliver network policy, analytics, security, and access controls. Extreme cloud-driven technologies provide flexibility and scalability in deployment, management, and licensing of networks globally, and the global cloud footprint provides service to over 50,000 customers and over 10 million daily users across the world including some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing. We derive substantially all of our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0001564590-21-005006:mdna:5]
Key elements of our strategy and differentiation include:

[0001564590-21-005006:mdna:6]
|  | • | Creating effortless networking solutions that allow all of us to advance. We believe that progress is achieved when we connect—allowing us to learn, understand, create, and grow. We make connecting simple and easy with effortless networking experiences that enable all of us to advance how we live, work and share. |

[0001564590-21-005006:mdna:7]
|  | • | Provide a differentiated end-to-end cloud architecture. Cloud networking is projected to be the fastest growing segment of the networking industry and technologies have evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by machine learning (“ML”) and artificial intelligence (“AI”) that spans from the IoT edge to the enterprise data center. Key characteristics of our cloud architecture include: |

[0001564590-21-005006:mdna:8]
|  | o | A robust cloud management platform that delivers visibility, intelligence, and assurance from the IoT edge to the core. |

[0001564590-21-005006:mdna:9]
|  | o | Cloud Choice for customers: solution available on all major cloud providers (Amazon Web Services (“AWS”), Google Cloud Platform (“GCP”) and Microsoft Azure) |

[0001564590-21-005006:mdna:10]
|  | o | Unlimited Network Data plans for the length of the cloud subscription to improve an organization’s ability to make smarter, more effective business decisions. |

[0001564590-21-005006:mdna:11]
|  | o | Consumption Flexibility: offer a range of financing and network purchase options. Our value-based subscription tiers (Connect, Pilot, etc.) provide customers with flexibility to grow as they go, as well as offer pool-able and portable licenses that can be transferred between products (AP’s, switches etc.) at one fixed price. |

[0001564590-21-005006:mdna:12]
|  | o | “No 9’s” Reliability and Resiliency to ensure business continuity for our customers |

[0001564590-21-005006:mdna:13]
|  | o | Zero-Trust Security and Privacy (ISO 27001 Security Certified) |

[0001564590-21-005006:mdna:14]
[same as prior period, unchanged from 0001564590-20-048853:mdna:21]

[0001564590-21-005006:mdna:15]
|  | • | End to End Portfolio. Our cloud-driven solutions provide visibility, control and strategic intelligence from the edge to the data center, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points, Wireless Local Area Network (“WLAN”) controllers, routers, and an extensive portfolio of software applications that deliver AI-enhanced access control, network and application analytics, as well as network management. All can be managed, assessed and controlled from a single pane of glass on premises or from the cloud. |

[0001564590-21-005006:mdna:16]
|  | • | Offer customers choice: cloud or on-premises. We leverage the cloud where it makes sense for our customers and provide on-premises solutions where customers need it and also have a solution for those that want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what’s going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for bring your own device (“BYOD”) and IoT usage. |

[0001564590-21-005006:mdna:17]
|  | • | Provide high-quality “in-house” customer service and support. We seek to enhance customer satisfaction and build customer loyalty through high-quality service and support. This includes a wide range of standard support programs to the level of service our customers require, from standard business hours to global 24-hour-a-day, 365-days-a-year real-time responsive support. |

[0001564590-21-005006:mdna:18]
|  | • | Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience and our operating systems - the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud. |

[0001564590-21-005006:mdna:19]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our cloud architecture with machine learning and AI-driven insights. |

[0001564590-21-005006:mdna:20]
|  | • | Offer a superior quality of experience. Our network-powered application analytics provide actionable business insights by capturing and analyzing context-based data about the network and applications to deliver meaningful intelligence about applications, users, locations and devices. With an easy to comprehend dashboard, our applications help businesses turn their network into a strategic business asset that helps executives make faster and more effective decisions. |

[0001564590-21-005006:mdna:21]
|  | • | Expand market penetration by targeting high-growth market segments. Within the Campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our Data Center approach leverages our product portfolio to address the needs of public and private Cloud Data Center providers. We believe that cloud networking compound annual growth rate will continue to outpace the compound annual growth rate for on-premises managed networking. Our focus is on expanding our technology foothold in the critical cloud networking segment to accelerate not only cloud management adoption, but also subscription-based licensing (SaaS) consumption. |

[0001564590-21-005006:mdna:22]
|  | • | Leverage and expand multiple distribution channels. We distribute our products through select distributors, a large number of resellers and system-integrators worldwide, as well as several large strategic partners. We maintain a field sales force to support our channel partners and to sell directly to certain strategic accounts. As an independent networking vendor, we seek to provide products that, when combined with the offerings of our channel partners, create compelling solutions for end-user customers. |

[0001564590-21-005006:mdna:23]
|  | • | Maintain and extend our strategic relationships. We have established strategic relationships with a number of industry-leading vendors to both, provide increased and enhanced routes to market, and collaboratively develop unique solutions. |

[0001564590-21-005006:mdna:24]
[same as prior period, unchanged from 0001564590-20-048853:mdna:62]

[0001564590-21-005006:mdna:25]
During the second quarter of fiscal 2021, we achieved the following results:

[0001564590-21-005006:mdna:26]
|  | • | Net revenues of $242.1 million compared to $267.5 million in the second quarter of fiscal 2020. |

[0001564590-21-005006:mdna:27]
[same as prior period, unchanged from 0001564590-20-048853:mdna:19]

[0001564590-21-005006:mdna:28]
|  | • | Product revenues of $165.8 million compared to $190.5 million in the second quarter of fiscal 2020. |

[0001564590-21-005006:mdna:29]
|  | • | Service and subscription revenues of $76.3 million compared to $77.0 million in the second quarter of fiscal 2020. |

[0001564590-21-005006:mdna:30]
|  | • | Total gross margin of 57.9% of net revenues compared to 55.6% of net revenues in the second quarter of fiscal 2020. |

[0001564590-21-005006:mdna:31]
|  | • | Operating income of $5.7 million compared to operating loss of $15.2 million in the second quarter of fiscal 2020. |

[0001564590-21-005006:mdna:32]
|  | • | Net loss of $3.1 million compared to net loss of $23.5 million in the second quarter of fiscal 2020. |

[0001564590-21-005006:mdna:33]
During the first six months of fiscal 2021, we reflected the following results:

[0001564590-21-005006:mdna:34]
|  | • | Cash flows provided by operating activities of $62.8 million compared to $21.9 million in the six months ended December 31, 2019. |

[0001564590-21-005006:mdna:35]
|  | • | Cash of $184.0 million as of December 31, 2020 compared to $193.9 million as of June 30, 2020. |

[0001564590-21-005006:mdna:36]
[same as prior period, unchanged from 0001564590-20-048853:mdna:72]

[0001564590-21-005006:mdna:37]
A novel strain of coronavirus emerged in December 2019. This coronavirus, now known as COVID-19, spread around the world and resulted in authorities implementing numerous measures to try to contain the virus, such as travel bans and restrictions, quarantines, shelter-in-place orders and shutdowns and was declared a pandemic in March 2020. COVID-19 has had and we expect will continue to have an adverse effect on our results of operations due to supply chain disruptions and reduced demand for our products. Because of this, we realigned our operations and recorded severance and benefits charges of $5.8 million during the third quarter of our fiscal 2020. Although we expect to reduce research and development and sales and marketing costs for the year ended June 30, 2021 compared to the year ended June 30, 2020, given the uncertainty around the extent and timing of the potential future spread or mitigation of COVID-19 and around the imposition or relaxation of protective measures, we cannot further reasonably estimate the impact of the COVID-19 pandemic on our future results of operations or financial position. See also Part II, Item 1A – Risk Factors.

[0001564590-21-005006:mdna:38]
[same as prior period, unchanged from 0001564590-20-048853:mdna:74]

[0001564590-21-005006:mdna:39]
[same as prior period, unchanged from 0001564590-20-048853:mdna:75]

[0001564590-21-005006:mdna:40]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | $ Change |  |  | % Change |  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | $ Change |  |  | % Change |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 165,845 |  |  | $ | 190,492 |  |  | $ | (24,647 | ) |  |  | (12.9 | )% |  | $ | 327,241 |  |  | $ | 375,626 |  |  | $ | (48,385 | ) |  |  | (12.9 | )% |  |
| Percentage of net revenues |  |  | 68.5 | % |  |  | 71.2 | % |  |  |  |  |  |  |  |  |  |  | 68.5 | % |  |  | 71.8 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 76,283 |  |  |  | 76,980 |  |  |  | (697 | ) |  |  | (0.9 | )% |  |  | 150,689 |  |  |  | 147,352 |  |  |  | 3,337 |  |  |  | 2.3 | % |  |
| Percentage of net revenues |  |  | 31.5 | % |  |  | 28.8 | % |  |  |  |  |  |  |  |  |  |  | 31.5 | % |  |  | 28.2 | % |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 242,128 |  |  | $ | 267,472 |  |  | $ | (25,344 | ) |  |  | (9.5 | )% |  | $ | 477,930 |  |  | $ | 522,978 |  |  | $ | (45,048 | ) |  |  | (8.6 | )% |  |

[0001564590-21-005006:mdna:41]
Product revenues decreased $24.6 million or 12.9% for the three months ended December 31, 2020, as compared to the corresponding period of fiscal 2020. Product revenues decreased $48.4 million or 12.9% for the six months ended December 31, 2020, as compared to the corresponding period of fiscal 2020. The product revenues decline was primarily due to the continued impact of the global outbreak of COVID-19 across all geographies.

[0001564590-21-005006:mdna:42]
Service and subscription revenues decreased $0.7 million, or 0.9% for the three months ended December 31, 2020 as compared to the corresponding period in fiscal 2020. Service and subscription revenues increased $3.3 million, or 2.3% for the six months ended December 31, 2020 as compared to the corresponding period in fiscal 2020.  The decrease in services and subscription revenue for the three months ended December 31, 2020 was primarily due to the continued impact of the global outbreak of COVID-19 across all geographies, partially offset by increased subscription revenue.  The increase in service and subscription revenues for the six months ended December 31, 2020 was primarily due to growth in subscription revenues.

[0001564590-21-005006:mdna:43]
[same as prior period, unchanged from 0001564590-20-048853:mdna:79]

[0001564590-21-005006:mdna:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | $ Change |  |  | % Change |  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 91,840 |  |  | $ | 99,105 |  |  | $ | (7,265 | ) |  |  | (7.3 | )% |  | $ | 179,841 |  |  | $ | 192,848 |  |  | $ | (13,007 | ) |  |  | (6.7 | )% |  |
| Percentage of product revenues |  |  | 55.4 | % |  |  | 52.0 | % |  |  |  |  |  |  |  |  |  |  | 55.0 | % |  |  | 51.3 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 48,352 |  |  |  | 49,566 |  |  |  | (1,214 | ) |  |  | (2.4 | )% |  |  | 95,369 |  |  |  | 93,066 |  |  |  | 2,303 |  |  |  | 2.5 | % |  |
| Percentage of service and subscription revenues |  |  | 63.4 | % |  |  | 64.4 | % |  |  |  |  |  |  |  |  |  |  | 63.3 | % |  |  | 63.2 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 140,192 |  |  | $ | 148,671 |  |  | $ | (8,479 | ) |  |  | (5.7 | )% |  | $ | 275,210 |  |  | $ | 285,914 |  |  | $ | (10,704 | ) |  |  | (3.7 | )% |  |
| Percentage of net revenues |  |  | 57.9 | % |  |  | 55.6 | % |  |  |  |  |  |  |  |  |  |  | 57.6 | % |  |  | 54.7 | % |  |  |  |  |  |  |  |  |  |

[0001564590-21-005006:mdna:45]
Product gross profit decreased $7.3 million or 7.3% for the three months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The decrease in product gross profit was primarily due to lower revenues. This was partially offset by lower distribution charges of $2.3 million, which were mainly due to decreased tariffs, lower expensing of the fair value step-up of inventories acquired from Aerohive of $3.4 million, lower warranty costs of $2.5 million and more favorable manufacturing costs due to cost reduction efforts including a reduction in product costs.

[0001564590-21-005006:mdna:46]
Product gross profit decreased $13.0 million or 6.7% for the six months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The decrease in product gross profit was primarily due to lower revenues. This was partially offset by lower excess and obsolete inventory charges of $3.8 million, lower expensing of the fair value step-up of inventories acquired from Aerohive of $7.3 million, lower warranty costs of $5.4 million and more favorable manufacturing costs due to cost reduction efforts including a reduction in product costs.

[0001564590-21-005006:mdna:47]
Service and subscription gross profit decreased $1.2 million or 2.4% for the three months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The decrease was primarily due to lower service and subscription revenues and increased cloud service costs and higher personnel costs, partially offset by reduced return costs.

[0001564590-21-005006:mdna:48]
Service and subscription gross profit increased $2.3 million or 2.5% for six months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The increase was primarily due to higher service and subscription revenues and reduced return costs, partially offset by higher personnel costs and increased cloud service costs.

[0001564590-21-005006:mdna:49]
[same as prior period, unchanged from 0001564590-20-048853:mdna:83]

[0001564590-21-005006:mdna:50]
[same as prior period, unchanged from 0001564590-20-048853:mdna:84]

[0001564590-21-005006:mdna:51]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | $ Change |  |  | % Change |  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | $ Change |  |  | % Change |  |  |
| Research and development |  | $ | 49,186 |  |  | $ | 55,380 |  |  | $ | (6,194 | ) |  |  | (11.2 | )% |  | $ | 98,710 |  |  | $ | 114,496 |  |  | $ | (15,786 | ) |  |  | (13.8 | )% |  |
| Sales and marketing |  |  | 66,732 |  |  |  | 75,436 |  |  |  | (8,704 | ) |  |  | (11.5 | )% |  |  | 131,057 |  |  |  | 146,793 |  |  |  | (15,736 | ) |  |  | (10.7 | )% |  |
| General and administrative |  |  | 16,360 |  |  |  | 15,098 |  |  |  | 1,262 |  |  |  | 8.4 | % |  |  | 32,821 |  |  |  | 30,080 |  |  |  | 2,741 |  |  |  | 9.1 | % |  |
| Acquisition and integration costs |  |  | — |  |  |  | 8,994 |  |  |  | (8,994 | ) |  |  | (100.0 | )% |  |  | 1,975 |  |  |  | 24,919 |  |  |  | (22,944 | ) |  |  | (92.1 | )% |  |
| Restructuring and related charges, net of reversals |  |  | 695 |  |  |  | 6,622 |  |  |  | (5,927 | ) |  |  | (89.5 | )% |  |  | 1,696 |  |  |  | 12,759 |  |  |  | (11,063 | ) |  |  | (86.7 | )% |  |
| Amortization of intangibles |  |  | 1,506 |  |  |  | 2,377 |  |  |  | (871 | ) |  |  | (36.6 | )% |  |  | 3,298 |  |  |  | 4,307 |  |  |  | (1,009 | ) |  |  | (23.4 | )% |  |
| Total operating expenses |  | $ | 134,479 |  |  | $ | 163,907 |  |  | $ | (29,428 | ) |  |  | (18.0 | )% |  | $ | 269,557 |  |  | $ | 333,354 |  |  | $ | (63,797 | ) |  |  | (19.1 | )% |  |

[0001564590-21-005006:mdna:52]
[same as prior period, unchanged from 0001564590-20-048853:mdna:86]

[0001564590-21-005006:mdna:53]
[same as prior period, unchanged from 0001564590-20-048853:mdna:87]

[0001564590-21-005006:mdna:54]
Research and development expenses decreased by $6.2 million or 11.2% for the three months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The decrease in research and development expenses was due to a $6.6 million decrease in personnel costs primarily due to lower headcount as a result of the cost reduction actions taken in fiscal 2020, a $1.8 million decrease in facility and information technology costs, a $1.7 million decrease in software licenses and engineering project costs and a $0.3 million decrease in travel and other expenses, partially offset by a $4.2 million increase in professional and contractor fees.

[0001564590-21-005006:mdna:55]
Research and development expenses decreased by $15.8 million or 13.8% for the six months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The decrease in research and development expenses was due to a $16.1 million decrease in personnel costs primarily due to lower headcount as a result of the cost reduction actions taken in fiscal 2020, a $3.0 million decrease in facility and information technology costs, a $2.6 million decrease in software licenses and engineering project costs and a $0.8 million decrease in travel and other expenses, partially offset by a $6.7 million increase in professional and contractor fees.

[0001564590-21-005006:mdna:56]
[same as prior period, unchanged from 0001564590-20-048853:mdna:89]

[0001564590-21-005006:mdna:57]
[same as prior period, unchanged from 0001564590-20-048853:mdna:90]

[0001564590-21-005006:mdna:58]
Sales and marketing expenses decreased by $8.7 million or 11.5% for the three months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The decrease in sales and marketing expenses was primarily due to a $1.8 million decrease in personnel costs, a $3.5 million decrease in travel costs due to COVID-19, a $1.2 million decrease in professional and recruiting fees, a $0.8 million decrease in software and equipment related costs and a $1.4 million decrease in other expenses primarily marketing and sales promotions costs.

[0001564590-21-005006:mdna:59]
Sales and marketing expenses decreased by $15.7 million or 10.7% for the six months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The decrease in sales and marketing expenses was primarily due to a $4.0 million decrease in personnel costs, a $6.6 million decrease in travel costs due to COVID-19, a $2.6 million decrease in professional and recruiting fees, a $1.1 million decrease in software and equipment related costs and a $1.4 million decrease in other expenses primarily sales promotions costs.

[0001564590-21-005006:mdna:60]
[same as prior period, unchanged from 0001564590-20-048853:mdna:92]

[0001564590-21-005006:mdna:61]
[same as prior period, unchanged from 0001564590-20-048853:mdna:93]

[0001564590-21-005006:mdna:62]
General and administrative expenses increased by $1.3 million or 8.4% for the three months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The increase in general and administrative expenses was primarily due to a $2.1 million increase in personnel costs primarily compensation expenses and a $1.5 million increase in facility and information technology costs, partially offset by a $1.1 million decrease in software and equipment related costs, a $0.6 million decrease in legal and professional fees and a $0.6 million decrease in travel and other expenses.

[0001564590-21-005006:mdna:63]
General and administrative expenses increased by $2.7 million or 9.1% for the six months ended December 31, 2020, as compared to the corresponding period in fiscal 2020. The increase in general and administrative expenses was primarily due to a $3.0 million increase in personnel costs primarily compensation expenses and a $2.1 million increase in facility and information technology costs, partially offset by a $1.0 million decrease in software and equipment related costs, a $0.4 million decrease in legal and professional fees and a $1.0 million decrease in travel and other expenses.

[0001564590-21-005006:mdna:64]
[same as prior period, unchanged from 0001564590-20-048853:mdna:95]

[0001564590-21-005006:mdna:65]
During the three months ended December 31, 2020, we did not incur any acquisition and integration costs.  During the six months ended December 31, 2020 we incurred $2.0 million of acquisition and integration costs. Acquisition and integration costs for the six months ended December 31, 2020 consisted primarily of additional professional fees for system integration and financial services related to the Aerohive acquisition which are now complete.

[0001564590-21-005006:mdna:66]
During the three and six months ended December 31, 2019, we incurred $9.0 million and $24.9 million, respectively of acquisition and integration costs including a $6.8 million compensation charge for certain Aerohive Executives’ stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts. Other acquisition and integration costs consisted primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees.

[0001564590-21-005006:mdna:67]
[same as prior period, unchanged from 0001564590-20-048853:mdna:98]

[0001564590-21-005006:mdna:68]
For the three and six months ended December 31, 2020, we recorded restructuring charges of $0.7 million and $1.7 million, respectively.  We continued our cost reduction initiative began in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of $0.4 million and $1.1 million, respectively, related to the 2020 Plan.  In addition, we had facility-related charges of $0.3 million and $0.6 million, respectively, related to our previously impaired facilities.

[0001564590-21-005006:mdna:69]
For the three months ended December 31, 2019, we recorded restructuring charges of $6.6 million. The charges consisted primarily of excess facility charges of $3.9 million for impairment of right-of-use assets related mainly to our Milpitas, California facilities.  Additionally, we continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and we recorded severance and benefits charges of $2.7 million. For the six months ended December 31, 2019, we recorded restructuring charges of $12.8 million. The charges consisted primarily of excess facility charges of $7.9 million for impairment of right-of-use assets related to our Milpitas California, South San Jose California, and Salem, New Hampshire facilities.  Additionally, we continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and we recorded severance and benefits charges of $4.9 million.

[0001564590-21-005006:mdna:70]
[same as prior period, unchanged from 0001564590-20-048853:mdna:101]

[0001564590-21-005006:mdna:71]
During the three months ended December 31, 2020 and 2019, we recorded $1.5 million and $2.4 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The decrease was primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-21-005006:mdna:72]
During the six months ended December 31, 2020 and 2019, we recorded $3.3 million and $4.3 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The decrease was primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized, partially offset by an increase from full period amortization of acquired intangibles from the Aerohive acquisition.

[0001564590-21-005006:mdna:73]
[same as prior period, unchanged from 0001564590-20-048853:mdna:103]

[0001564590-21-005006:mdna:74]
During the three months ended December 31, 2020 and 2019, we recorded $6.1 million and $6.2 million, respectively, in interest expense.  The decreases in interest expense were primarily driven by lower average loan balances for the three months ended December 31, 2020 under our 2019 Credit Agreement.

[0001564590-21-005006:mdna:75]
During the six months ended December 31, 2020 and 2019, we recorded $12.7 million and $11.4 million, respectively, in interest expense. The increases in interest expense were primarily driven by higher average loan balances for the six months ended December 31, 2020 under our 2019 Credit Agreement.

[0001564590-21-005006:mdna:76]
Other Expense, Net

[0001564590-21-005006:mdna:77]
During the three months ended December 31, 2020 and 2019, we recorded other expense, net of $1.0 million and $0.7 million, respectively. During the six months ended December 31, 2020 and 2019, we recorded other expense, net of $1.8 million and $0.2 million, respectively. The changes for the three and six months ended December 31, 2020 was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-21-005006:mdna:78]
[same as prior period, unchanged from 0001564590-20-048853:mdna:107]

[0001564590-21-005006:mdna:79]
For the three months ended December 31, 2020 and 2019, we recorded an income tax provision of $1.8 million and $1.8 million, respectively.  For the six months ended December 31, 2020 and 2019, we recorded an income tax provision of $3.1 million and $3.4 million, respectively.

[0001564590-21-005006:mdna:80]
The income tax provisions for the three and six months ended December 31, 2020 and 2019 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business, and (4) state taxes in jurisdictions where we have no remaining state net operating losses.

[0001564590-21-005006:mdna:81]
[same as prior period, unchanged from 0001564590-20-048853:mdna:110]

[0001564590-21-005006:mdna:82]
[same as prior period, unchanged from 0001564590-20-048853:mdna:111]

[0001564590-21-005006:mdna:83]
[same as prior period, unchanged from 0001564590-20-048853:mdna:112]

[0001564590-21-005006:mdna:84]
[same as prior period, unchanged from 0001564590-20-048853:mdna:113]

[0001564590-21-005006:mdna:85]
[same as prior period, unchanged from 0001564590-20-048853:mdna:114]

[0001564590-21-005006:mdna:86]
[same as prior period, unchanged from 0001564590-20-048853:mdna:115]

[0001564590-21-005006:mdna:87]
[same as prior period, unchanged from 0001564590-20-048853:mdna:116]

[0001564590-21-005006:mdna:88]
[same as prior period, unchanged from 0001564590-20-048853:mdna:117]

[0001564590-21-005006:mdna:89]
[same as prior period, unchanged from 0001564590-20-048853:mdna:118]

[0001564590-21-005006:mdna:90]
[same as prior period, unchanged from 0001564590-20-048853:mdna:119]

[0001564590-21-005006:mdna:91]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Cash |  | $ | 183,969 |  |  | $ | 193,872 |  |

[0001564590-21-005006:mdna:92]
As of December 31, 2020, our principal sources of liquidity consisted of cash of $184.0 million and accounts receivable, net of $128.2 million, and available borrowings under our five-year 2019 Revolving Facility of $55.0 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $184.0 million of cash at December 31, 2020, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-21-005006:mdna:93]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in fiscal 2019 and $30.0 million was used for repurchases in fiscal 2020. Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. There were no repurchases in the three and six months ended December 31, 2020.

[0001564590-21-005006:mdna:94]
In connection with the acquisition of Aerohive as discussed in Note 4 of the accompanying condensed consolidated financial statements, as of August 9, 2019, we amended the 2018 Credit Agreement, which is no longer outstanding, and entered into the 2019 Credit Agreement, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (“2019 Revolving Facility”).  In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-21-005006:mdna:95]
[same as prior period, unchanged from 0001564590-20-048853:mdna:124]

[0001564590-21-005006:mdna:96]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-21-005006:mdna:97]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-21-005006:mdna:98]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the Second Amendment which supersedes the First Amendment and provides certain revised terms and financial covenants effective through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we are not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and we are restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the Fourth amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021. We expect to be in compliance with the original terms of the 2019 Credit Agreement prior to June 30, 2021.

[0001564590-21-005006:mdna:99]
[same as prior period, unchanged from 0001564590-20-048853:mdna:128]

[0001564590-21-005006:mdna:100]
[same as prior period, unchanged from 0001564590-20-048853:mdna:129]

[0001564590-21-005006:mdna:101]
[same as prior period, unchanged from 0001564590-20-048853:mdna:130]

[0001564590-21-005006:mdna:102]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Net cash provided by operating activities |  | $ | 62,771 |  |  | $ | 21,911 |  |
| Net cash used in investing activities |  |  | (8,039 | ) |  |  | (183,647 | ) |
| Net cash (used in) provided by financing activities |  |  | (65,237 | ) |  |  | 132,736 |  |
| Foreign currency effect on cash |  |  | 602 |  |  |  | (193 | ) |
| Net decrease in cash |  | $ | (9,903 | ) |  | $ | (29,193 | ) |

[0001564590-21-005006:mdna:103]
Net Cash Provided by Operating Activities

[0001564590-21-005006:mdna:104]
Cash flows provided by operations in the six months ended December 31, 2020, were $62.8 million, including our net loss of $11.9 million and non-cash expenses of $61.7 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and imputed interest.  Other sources of cash for the period included a decrease in inventory and increases in accounts payable, accrued compensation, and deferred revenues. This was partially offset by decreases in other current and long-term liabilities and operating lease liabilities and increases in accounts receivables and prepaid expenses and other current assets.

[0001564590-21-005006:mdna:105]
Cash flows provided by operations in the six months ended December 31, 2019, were $21.9 million, including our net loss of $61.3 million and non-cash expenses of $72.1 million for items such as amortization of intangibles, reduction in carrying amount of right-of-use asset, depreciation, restructuring, deferred income taxes and imputed interest.  Other sources of cash for the period included a decrease in accounts receivables and inventory and increases in deferred revenues. This was partially offset by decreases in accounts payable, accrued compensation, other current and long-term liabilities, and operating lease liabilities.

[0001564590-21-005006:mdna:106]
[same as prior period, unchanged from 0001564590-20-048853:mdna:135]

[0001564590-21-005006:mdna:107]
Cash flows used in investing activities in the six months ended December 31, 2020 were $8.0 million for the purchases of property and equipment.

[0001564590-21-005006:mdna:108]
Cash flows used in investing activities in the six months ended December 31, 2019 were $183.6 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $9.4 million, which was partially offset by proceeds of $45.2 million related to the maturity and sales of short-term investments.

[0001564590-21-005006:mdna:109]
[same as prior period, unchanged from 0001564590-20-048853:mdna:138]

[0001564590-21-005006:mdna:110]
Cash flows used in financing activities in the six months ended December 31, 2020 were $65.2 million due primarily to debt repayments of $64.5 million, payment of contingent consideration of $1.0 million, and $2.0 million for deferred payments on acquisitions. This was partially offset by $2.3 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (our “ESPP”), exercise of stock options, net of taxes paid on vested, and released stock awards.

[0001564590-21-005006:mdna:111]
Cash flows provided by financing activities in the six months ended December 31, 2019 were $132.7 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $2.9 million of proceeds from the issuance of shares of our common stock under our ESPP, the exercise of stock options and net of taxes paid on vested and released stock awards. This was partially offset by debt repayments of $25.0 million, assumed from the Aerohive acquisition, payment of loan fees of $10.5 million, contingent consideration of $2.0 million, and $2.2 million for deferred payments on acquisitions.  Cash flows provided by financing activities for the period also included repurchasing of our common shares valued at $25.2 million executed through an accelerated share repurchase program. In addition, related to this transaction, there was an equity forward contract related to the Company’s stock of $4.8 million.

[0001564590-21-005006:mdna:112]
[same as prior period, unchanged from 0001564590-20-048853:mdna:141]

[0001564590-21-005006:mdna:113]
Foreign currency effect on cash increased in the six months ended December 31, 2020 and 2019, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-21-005006:mdna:114]
[same as prior period, unchanged from 0001564590-20-048853:mdna:143]

[0001564590-21-005006:mdna:115]
The following summarizes our contractual obligations as of December 31, 2020, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-21-005006:mdna:116]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 356,250 |  |  | $ | 21,375 |  |  | $ | 68,875 |  |  | $ | 266,000 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 54,651 |  |  |  | 17,218 |  |  |  | 29,764 |  |  |  | 7,669 |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 38,015 |  |  |  | 38,015 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 85,383 |  |  |  | 20,367 |  |  |  | 34,858 |  |  |  | 17,233 |  |  |  | 12,925 |  |
| Lease payments on operating leases |  |  | 66,852 |  |  |  | 21,442 |  |  |  | 29,666 |  |  |  | 9,708 |  |  |  | 6,036 |  |
| Deferred payments for an acquisition |  |  | 9,000 |  |  |  | 4,000 |  |  |  | 5,000 |  |  |  | — |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 1,168 |  |  |  | 925 |  |  |  | 243 |  |  |  | — |  |  |  | — |  |
| Other liabilities |  |  | 956 |  |  |  | 265 |  |  |  | 529 |  |  |  | 162 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 612,275 |  |  | $ | 123,607 |  |  | $ | 168,935 |  |  | $ | 300,772 |  |  | $ | 18,961 |  |

[0001564590-21-005006:mdna:117]
[same as prior period, unchanged from 0001564590-20-048853:mdna:146]

[0001564590-21-005006:mdna:118]
[same as prior period, unchanged from 0001564590-20-048853:mdna:147]

[0001564590-21-005006:mdna:119]
[same as prior period, unchanged from 0001564590-20-048853:mdna:148]

[0001564590-21-005006:mdna:120]
[same as prior period, unchanged from 0001564590-20-048853:mdna:149]

[0001564590-21-005006:mdna:121]
[same as prior period, unchanged from 0001564590-20-048853:mdna:150]

[0001564590-21-005006:mdna:122]
[same as prior period, unchanged from 0001564590-20-048853:mdna:151]

[0001564590-21-005006:mdna:123]
[same as prior period, unchanged from 0001564590-20-048853:mdna:152]

[0001564590-21-005006:mdna:124]
[same as prior period, unchanged from 0001564590-20-048853:mdna:153]

[0001564590-21-005006:mdna:125]
[same as prior period, unchanged from 0001564590-20-048853:mdna:154]

[0001564590-21-005006:mdna:126]
We did not have any material commitments for capital expenditures as of December 31, 2020.

[0001564590-21-005006:mdna:127]
[same as prior period, unchanged from 0001564590-20-048853:mdna:156]

[0001564590-21-005006:mdna:128]
We did not have any off-balance sheet arrangements as of December 31, 2020.
