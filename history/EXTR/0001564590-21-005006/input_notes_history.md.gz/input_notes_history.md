# EXTR note change history — 0001564590-20-048853 → 0001564590-21-005006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001564590-21-005006:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2020, the Company had commitments to purchase $38.0 million of inventory and other services.
  (was, 2020-10-29, similarity 0.7592):
[0001564590-20-048853:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer

- changed (2021-02-09):
[0001564590-21-005006:note_history:2]
All currency conversions in this Legal Proceedings section are as of December 31, 2020.
  (was, 2020-10-29, similarity 0.9693):
[0001564590-20-048853:note_history:2]
All currency conversions in this Legal Proceedings section are as of September 30, 2020.

- changed (2021-02-09):
[0001564590-21-005006:note_history:3]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The Federal Circuit Court ruled for XR on November 25, 2020 in Cisco’s appeal of the ‘231 PTAB decision, and a status conference has been set for February 22, 2021. The Company believes the claims are without merit and intends to defend them vigorously.
  (was, 2020-10-29, similarity 0.922):
[0001564590-20-048853:note_history:3]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is now set for November 23, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

- changed (2021-02-09):
[0001564590-21-005006:note_history:4]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, pursuant to the appeal filed by Orckit on March 13, 2020.
  (was, 2020-10-29, similarity 0.9021):
[0001564590-20-048853:note_history:4]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents.  After a hearing on January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company.  The matter is proceeding through the appeal process, pursuant to the appeal filed by Orckit on March 13, 2020.

- changed (2021-02-09):
[0001564590-21-005006:note_history:5]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, and the Court issued an infringement decision against the Company and granted to Orckit the right to enforce an injunction against the Company. The Company filed a notice of appeal on November 12, 2020 and the matter is proceeding through the appellate process.
  (was, 2020-10-29, similarity 0.6663):
[0001564590-20-048853:note_history:5]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that we no longer sell in Germany.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  The Company filed a nullity action with the German Federal Patent Court, seeking to invalidate the asserted patent.  Orckit has filed its substantive reasons for opposing the Company’s nullity action on June 11, 2020.  A hearing was held on September 29, 2020, and the Court issued an infringement decision and injunction against the Company.  The Company is evaluating its options for further proceedings.

- added (2021-02-09):
[0001564590-21-005006:note_history:6]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019. Both cases were filed in the Federal Patent Court in Munich and seek to invalidate the asserted patents. Both nullity actions are proceeding.

- changed (2021-02-09):
[0001564590-21-005006:note_history:7]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). A first and second hearing in the trial were held and the Court subsequently ordered the parties to retain a third-party appraisal center to analyze and report to the Court on various technical aspects of the case and has set out the scope of the appraisal.  The appraisal has not been conducted yet, and the Court has not issued a decision.  The Company believes that the claims are without merit and intends to defend them vigorously.
  (was, 2020-10-29, similarity 0.7206):
[0001564590-20-048853:note_history:7]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). A first hearing in the trial was held on July 30, 2020, and the Court held a second hearing for September 4, 2020.  The Court then ordered the parties to retain a third-party appraisal center to analyze and report to the Court on various technical aspects of the case.  The Company believes that the claims are without merit and intends to defend them vigorously.

- added (2021-02-09):
[0001564590-21-005006:note_history:8]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware. The lawsuit alleges direct infringement of four U.S. patents. DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees. DataCloud amended the complaint on November 13, 2020, asserting claims of direct, induced, and willful infringement of four new patents, and has petitioned to file a second amended complaint by February 12, 2021. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- changed (2021-02-09):
[0001564590-21-005006:note_history:9]
On August 14, 2020, American Patents LLC filed a patent infringement lawsuit against the Company in the Western District of Texas. The complaint alleged direct and indirect infringement of certain U.S. patents and seeks injunctive relief, unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The parties have settled the case for a non-material amount, and the case was dismissed on November 16, 2020.
  (was, 2020-10-29, similarity 0.8516):
[0001564590-20-048853:note_history:9]
On August 14, 2020, American Patents LLC filed a patent infringement lawsuit against the Company in the Western District of Texas.  The complaint alleges direct and indirect infringement of certain U.S. patents and seeks injunctive relief, unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  The parties have reached settlement terms for a non-material amount and are finalizing a settlement agreement.

- changed (2021-02-09):
[0001564590-21-005006:note_history:10]
Hanger Solutions, LLC v. Extreme Networks, Inc.
  (was, 2020-10-29, similarity 0.7527):
[0001564590-20-048853:note_history:10]
Proven Networks, LLC v. Extreme Networks, Inc.

- added (2021-02-09):
[0001564590-21-005006:note_history:11]
On January 14, 2021, Hanger Solutions, LLC (“Hanger”) filed a patent infringement lawsuit against the Company in the District of Delaware. The complaint alleges infringement of three U.S. patents. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- changed (2021-02-09):
[0001564590-21-005006:note_history:12]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other
  (was, 2020-10-29, similarity 0.6126):
[0001564590-20-048853:note_history:12]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- added (2021-02-09):
[0001564590-21-005006:note_history:13]
liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- removed (2021-02-09):
[0001564590-20-048853:note_history:14]
procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2020, the Company had commitments to purchase $33.9 million of inventory and other services.

- removed (2021-02-09):
[0001564590-20-048853:note_history:15]
On March 24, 2020, Proven Networks, LLC (“Proven”) filed a patent infringement lawsuit against the Company in the Northern District of California. The lawsuit alleged direct and indirect infringement of three U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of Extreme Analytics Extreme XOS, and certain network devices equipped with the Extreme XOS operating system.  Proven sought injunctive relief, unspecified damages, pre- and post-judgment interest, and attorneys’ fees.  The parties have reached a settlement in this case that was not material and the case was subsequently dismissed.

- removed (2021-02-09):
[0001564590-20-048853:note_history:16]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware.  The lawsuit alleges direct infringement of four U.S. patents based on Company’s shipping, distributing, making, using, importing, offering for sale, and/or selling of Extreme SLX Insight Architecture, Extreme Management Center, ExtremeSwitching switches, and ExtremeCloud Subscription Service.  DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001564590-21-005006:note_history:17]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2020. The results of operations for the three and six months ended December 31, 2020 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.
  (was, 2020-10-29, similarity 0.775):
[0001564590-20-048853:note_history:17]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2020. The results of operations for the three months ended September 30, 2020 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001564590-21-005006:note_history:18]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 21,375 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,463 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 18,912 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 334,875 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,934 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 328,941 |  |  |  | 394,585 |  |
| Total debt |  | $ | 347,853 |  |  | $ | 411,101 |  |
  (was, 2020-10-29, similarity 0.9548):
[0001564590-20-048853:note_history:18]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 19,000 |  |
| Revolving Facility |  | $ | 35,000 |  |  | $ | — |  |
| Less: unamortized debt issuance costs |  |  | (2,485 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 51,515 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 342,000 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (6,539 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 335,461 |  |  |  | 394,585 |  |
| Total debt |  | $ | 386,976 |  |  | $ | 411,101 |  |

- added (2021-02-09):
[0001564590-21-005006:note_history:19]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

- changed (2021-02-09):
[0001564590-21-005006:note_history:20]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of December 31, 2020 was 4.65%.
  (was, 2020-10-29, similarity 0.9934):
[0001564590-20-048853:note_history:20]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of September 30, 2020 was 4.85%.

- changed (2021-02-09):
[0001564590-21-005006:note_history:21]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.7 million for the three months ended December 31, 2020 and 2019, and totaled $1.5 million and $1.1 million for the six months ended December 31, 2020 and 2019.
  (was, 2020-10-29, similarity 0.8292):
[0001564590-20-048853:note_history:21]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.5 million for the three months ended September 30, 2020 and 2019.

- added (2021-02-09):
[0001564590-21-005006:note_history:22]
During the six months ended December 31, 2020, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at December 31, 2020.   The Company has $55.0 million of availability under the 2019 Revolving Facility as of December 31, 2020.

- changed (2021-02-09):
[0001564590-21-005006:note_history:23]
The Company had $8.8 million of outstanding letters of credit as of December 31, 2020.
  (was, 2020-10-29, similarity 0.9682):
[0001564590-20-048853:note_history:23]
The Company had $7.7 million of outstanding letters of credit as of September 30, 2020.

- removed (2021-02-09):
[0001564590-20-048853:note_history:24]
During the three months ended September 30, 2020, the Company repaid $20.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million.  Although not required under the terms of the 2019 Credit Agreement and amendments, the Company intends to repay the balance of $35.0 million in full under the 2019 Revolving Facility within the next 12 months should market conditions improve, and has classified the remaining balance as a current liability as of September 30, 2020 in the accompanying condensed consolidated balance sheets. The Company has $20.0 million of availability under the 2019 Revolving Facility as of September 30, 2020. In October 2020, the Company repaid another $20.0 million against its 2019 Revolving Credit Facility and has a remaining outstanding balance of $15.0 million.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001564590-21-005006:note_history:25]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 21,375 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,463 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 18,912 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 334,875 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,934 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 328,941 |  |  |  | 394,585 |  |
| Total debt |  | $ | 347,853 |  |  | $ | 411,101 |  |
  (was, 2020-10-29, similarity 0.9548):
[0001564590-20-048853:note_history:25]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 19,000 |  |
| Revolving Facility |  | $ | 35,000 |  |  | $ | — |  |
| Less: unamortized debt issuance costs |  |  | (2,485 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 51,515 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 342,000 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (6,539 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 335,461 |  |  |  | 394,585 |  |
| Total debt |  | $ | 386,976 |  |  | $ | 411,101 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001564590-21-005006:note_history:26]
|  |  | Three Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |
| Other |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |
| Total Americas |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |
| EMEA |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |
| APAC |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |
| Total net revenues |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |
  (was, 2020-10-29, similarity 0.9889):
[0001564590-20-048853:note_history:26]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |
| Other |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |
| Total Americas |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |
| EMEA |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |
| APAC |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |
| Total net revenues |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |

- added (2021-02-09):
[0001564590-21-005006:note_history:27]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |
| Other |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |
| Total Americas |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |
| EMEA |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |
| APAC |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |
| Total net revenues |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |

- added (2021-02-09):
[0001564590-21-005006:note_history:28]
For the three months ended December 31, 2020 the Company reflected 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020 the Company reflected 10% of its revenues from the Netherlands and 10% of its revenue from Germany.  No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2020 or 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001564590-21-005006:note_history:29]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.
  (was, 2020-10-29, similarity 0.9689):
[0001564590-20-048853:note_history:29]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- changed (2021-02-09):
[0001564590-21-005006:note_history:30]
On December 31, 2020, the Company had $309.1 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 40 percent of its deferred revenue as revenue in fiscal 2021, an additional 34 percent in fiscal 2022 and 26 percent of the balance thereafter.
  (was, 2020-10-29, similarity 0.9895):
[0001564590-20-048853:note_history:30]
On September 30, 2020, the Company had $297.8 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 54 percent of its deferred revenue as revenue in fiscal 2021, an additional 25 percent in fiscal 2022 and 21 percent of the balance thereafter.

- changed (2021-02-09):
[0001564590-21-005006:note_history:31]
Revenue recognized for the three months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $68.8 million and $67.2 million, respectively. Revenue recognized for the six months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $120.5 million and $90.9 million, respectively.
  (was, 2020-10-29, similarity 0.6597):
[0001564590-20-048853:note_history:31]
Revenue recognized for the three months ended September 30, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $66.9 million and $53.8 million, respectively.

- changed (2021-02-09):
[0001564590-21-005006:note_history:32]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $9.2 million and $8.1 million at December 31, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2020 and 2019, was $1.2 million and $1.5 million, respectively. Amortization recognized during the six months ended December 31, 2020 and 2019, was $2.5 million and $3.0 million, respectively.
  (was, 2020-10-29, similarity 0.934):
[0001564590-20-048853:note_history:32]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.7 million and $8.1 million at September 30, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2020 and 2019, was $1.2 million and $1.4 million, respectively.

- changed (2021-02-09):
[0001564590-21-005006:note_history:33]
|  |  | Three Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |
| Other |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |
| Total Americas |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |
| EMEA |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |
| APAC |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |
| Total net revenues |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |
  (was, 2020-10-29, similarity 0.9889):
[0001564590-20-048853:note_history:33]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |
| Other |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |
| Total Americas |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |
| EMEA |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |
| APAC |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |
| Total net revenues |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |

- added (2021-02-09):
[0001564590-21-005006:note_history:34]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |
| Other |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |
| Total Americas |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |
| EMEA |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |
| APAC |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |
| Total net revenues |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |

- added (2021-02-09):
[0001564590-21-005006:note_history:35]
For the three months ended December 31, 2020 the Company reflected 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020 the Company reflected 10% of its revenues from the Netherlands and 10% of its revenue from Germany.  No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2020 or 2019.

- changed (2021-02-09):
[0001564590-21-005006:note_history:36]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Tech Data Corporation |  | 21% |  |  | 14% |  |  | 24% |  |  | 15% |  |
| Jenne Corporation |  | 11% |  |  | 18% |  |  | 13% |  |  | 16% |  |
| Westcon Group Inc. |  | 19% |  |  | 15% |  |  | 16% |  |  | 13% |  |
  (was, 2020-10-29, similarity 0.7535):
[0001564590-20-048853:note_history:36]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Tech Data Corporation |  | 27% |  |  | 16% |  |
| Jenne Corporation |  | 15% |  |  | 14% |  |
| Westcon Group Inc. |  | 13% |  |  | 10% |  |

- changed (2021-02-09):
[0001564590-21-005006:note_history:37]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  | 20% |  |  | 23% |  |
| Jenne Corporation |  | 16% |  |  | 25% |  |
| Westcon Group Inc. |  | 18% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |
  (was, 2020-10-29, similarity 0.8202):
[0001564590-20-048853:note_history:37]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  |  | 33 | % |  |  | 23 | % |
| Jenne Corporation |  |  | 22 | % |  |  | 25 | % |
| Westcon Group Inc. |  |  | 12 | % |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001564590-21-005006:note_history:38]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.
  (was, 2020-10-29, similarity 0.9689):
[0001564590-20-048853:note_history:38]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- changed (2021-02-09):
[0001564590-21-005006:note_history:39]
On December 31, 2020, the Company had $309.1 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 40 percent of its deferred revenue as revenue in fiscal 2021, an additional 34 percent in fiscal 2022 and 26 percent of the balance thereafter.
  (was, 2020-10-29, similarity 0.9895):
[0001564590-20-048853:note_history:39]
On September 30, 2020, the Company had $297.8 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 54 percent of its deferred revenue as revenue in fiscal 2021, an additional 25 percent in fiscal 2022 and 21 percent of the balance thereafter.

- changed (2021-02-09):
[0001564590-21-005006:note_history:40]
Revenue recognized for the three months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $68.8 million and $67.2 million, respectively. Revenue recognized for the six months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $120.5 million and $90.9 million, respectively.
  (was, 2020-10-29, similarity 0.6597):
[0001564590-20-048853:note_history:40]
Revenue recognized for the three months ended September 30, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $66.9 million and $53.8 million, respectively.

- changed (2021-02-09):
[0001564590-21-005006:note_history:41]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $9.2 million and $8.1 million at December 31, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2020 and 2019, was $1.2 million and $1.5 million, respectively. Amortization recognized during the six months ended December 31, 2020 and 2019, was $2.5 million and $3.0 million, respectively.
  (was, 2020-10-29, similarity 0.934):
[0001564590-20-048853:note_history:41]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.7 million and $8.1 million at September 30, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2020 and 2019, was $1.2 million and $1.4 million, respectively.

- changed (2021-02-09):
[0001564590-21-005006:note_history:42]
|  |  | Three Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |
| Other |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |
| Total Americas |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |
| EMEA |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |
| APAC |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |
| Total net revenues |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |
  (was, 2020-10-29, similarity 0.9889):
[0001564590-20-048853:note_history:42]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |
| Other |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |
| Total Americas |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |
| EMEA |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |
| APAC |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |
| Total net revenues |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |

- added (2021-02-09):
[0001564590-21-005006:note_history:43]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |
| Other |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |
| Total Americas |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |
| EMEA |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |
| APAC |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |
| Total net revenues |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |

- added (2021-02-09):
[0001564590-21-005006:note_history:44]
For the three months ended December 31, 2020 the Company reflected 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020 the Company reflected 10% of its revenues from the Netherlands and 10% of its revenue from Germany.  No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2020 or 2019.
