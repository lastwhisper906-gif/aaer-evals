# EXTR notes — 0001564590-21-005006


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-21-005006:notes:1]
[same as prior period, unchanged from 0001564590-20-048853:notes:1]

[0001564590-21-005006:notes:2]
[same as prior period, unchanged from 0001564590-20-048853:notes:2]

[0001564590-21-005006:notes:3]
[same as prior period, unchanged from 0001564590-20-048853:notes:3]

[0001564590-21-005006:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2020. The results of operations for the three and six months ended December 31, 2020 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.

[0001564590-21-005006:notes:5]
[same as prior period, unchanged from 0001564590-20-048853:notes:5]

[0001564590-21-005006:notes:6]
[same as prior period, unchanged from 0001564590-20-048853:notes:6]

[0001564590-21-005006:notes:7]
[same as prior period, unchanged from 0001564590-20-048853:notes:7]

[0001564590-21-005006:notes:8]
[same as prior period, unchanged from 0001564590-20-048853:notes:8]

[0001564590-21-005006:notes:9]
[same as prior period, unchanged from 0001564590-20-048853:notes:9]

[0001564590-21-005006:notes:10]
[same as prior period, unchanged from 0001564590-20-048853:notes:10]

[0001564590-21-005006:notes:11]
[same as prior period, unchanged from 0001564590-20-048853:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-21-005006:notes:12]
[same as prior period, unchanged from 0001564590-20-048853:notes:12]

[0001564590-21-005006:notes:13]
[same as prior period, unchanged from 0001564590-20-048853:notes:13]

[0001564590-21-005006:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-21-005006:notes:15]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 was effective for fiscal years beginning after December 15, 2019.  The Company adopted the standard on July 1, 2020 and the impact of the adoption was not material to the Company's condensed consolidated financial statements as credit losses are not expected to be significant based on historical collection trends, the financial condition of payment partners, and external market factors.

[0001564590-21-005006:notes:16]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-21-005006:notes:17]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-21-005006:notes:18]
Recently Issued Accounting Pronouncements

[0001564590-21-005006:notes:19]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-005006:notes:20]
[same as prior period, unchanged from 0001564590-20-048853:notes:20]

[0001564590-21-005006:notes:21]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-21-005006:notes:22]
[same as prior period, unchanged from 0001564590-20-048853:notes:22]

[0001564590-21-005006:notes:23]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

[0001564590-21-005006:notes:24]
[same as prior period, unchanged from 0001564590-20-048853:notes:24]

[0001564590-21-005006:notes:25]
On December 31, 2020, the Company had $309.1 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 40 percent of its deferred revenue as revenue in fiscal 2021, an additional 34 percent in fiscal 2022 and 26 percent of the balance thereafter.

[0001564590-21-005006:notes:26]
[same as prior period, unchanged from 0001564590-20-048853:notes:26]

[0001564590-21-005006:notes:27]
Revenue recognized for the three months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $68.8 million and $67.2 million, respectively. Revenue recognized for the six months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $120.5 million and $90.9 million, respectively.

[0001564590-21-005006:notes:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $9.2 million and $8.1 million at December 31, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2020 and 2019, was $1.2 million and $1.5 million, respectively. Amortization recognized during the six months ended December 31, 2020 and 2019, was $2.5 million and $3.0 million, respectively.

[0001564590-21-005006:notes:29]
[same as prior period, unchanged from 0001564590-20-048853:notes:29]

[0001564590-21-005006:notes:30]
[same as prior period, unchanged from 0001564590-20-048853:notes:30]

[0001564590-21-005006:notes:31]
[same as prior period, unchanged from 0001564590-20-048853:notes:31]

[0001564590-21-005006:notes:32]
|  |  | Three Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |
| Other |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |
| Total Americas |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |
| EMEA |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |
| APAC |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |
| Total net revenues |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |

[0001564590-21-005006:notes:33]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |
| Other |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |
| Total Americas |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |
| EMEA |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |
| APAC |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |
| Total net revenues |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |

[0001564590-21-005006:notes:34]
For the three months ended December 31, 2020 the Company reflected 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020 the Company reflected 10% of its revenues from the Netherlands and 10% of its revenue from Germany.  No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2020 or 2019.

[0001564590-21-005006:notes:35]
[same as prior period, unchanged from 0001564590-20-048853:notes:33]

[0001564590-21-005006:notes:36]
[same as prior period, unchanged from 0001564590-20-048853:notes:34]

[0001564590-21-005006:notes:37]
[same as prior period, unchanged from 0001564590-20-048853:notes:35]

[0001564590-21-005006:notes:38]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Tech Data Corporation |  | 21% |  |  | 14% |  |  | 24% |  |  | 15% |  |
| Jenne Corporation |  | 11% |  |  | 18% |  |  | 13% |  |  | 16% |  |
| Westcon Group Inc. |  | 19% |  |  | 15% |  |  | 16% |  |  | 13% |  |

[0001564590-21-005006:notes:39]
[same as prior period, unchanged from 0001564590-20-048853:notes:37]

[0001564590-21-005006:notes:40]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  | 20% |  |  | 23% |  |
| Jenne Corporation |  | 16% |  |  | 25% |  |
| Westcon Group Inc. |  | 18% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-005006:notes:41]
[same as prior period, unchanged from 0001564590-20-048853:notes:39]

[0001564590-21-005006:notes:42]
[same as prior period, unchanged from 0001564590-20-048853:notes:40]

[0001564590-21-005006:notes:43]
[same as prior period, unchanged from 0001564590-20-048853:notes:41]

[0001564590-21-005006:notes:44]
[same as prior period, unchanged from 0001564590-20-048853:notes:42]

[0001564590-21-005006:notes:45]
The Acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive were recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets.  Of the total purchase consideration, $192.6 million was allocated to goodwill, $52.5 million to identifiable intangible assets and the remainder to net tangible assets assumed.  All valuations were finalized as of June 30, 2020.

[0001564590-21-005006:notes:46]
[same as prior period, unchanged from 0001564590-20-048853:notes:44]

[0001564590-21-005006:notes:47]
[same as prior period, unchanged from 0001564590-20-048853:notes:45]

[0001564590-21-005006:notes:48]
The unaudited pro forma financial information for the three and six months ended December 31, 2019 combines the historical results for Extreme for such periods assuming the transaction closed on July 1, 2019, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-21-005006:notes:49]
[same as prior period, unchanged from 0001564590-20-048853:notes:47]

[0001564590-21-005006:notes:50]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2019 |  |
| Net revenues |  | $ | 268,367 |  |  | $ | 536,045 |  |
| Net loss |  | $ | (5,031 | ) |  | $ | (28,847 | ) |
| Net loss per share - basic and diluted |  | $ | (0.04 | ) |  | $ | (0.24 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 119,555 |  |  |  | 119,891 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-21-005006:notes:51]
[same as prior period, unchanged from 0001564590-20-048853:notes:49]

[0001564590-21-005006:notes:52]
[same as prior period, unchanged from 0001564590-20-048853:notes:50]

[0001564590-21-005006:notes:53]
[same as prior period, unchanged from 0001564590-20-048853:notes:51]

[0001564590-21-005006:notes:54]
[same as prior period, unchanged from 0001564590-20-048853:notes:52]

[0001564590-21-005006:notes:55]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Finished goods |  | $ | 43,212 |  |  | $ | 52,879 |  |
| Raw materials |  |  | 6,618 |  |  |  | 9,710 |  |
| Total Inventories |  | $ | 49,830 |  |  | $ | 62,589 |  |

[0001564590-21-005006:notes:56]
[same as prior period, unchanged from 0001564590-20-048853:notes:54]

[0001564590-21-005006:notes:57]
[same as prior period, unchanged from 0001564590-20-048853:notes:55]

[0001564590-21-005006:notes:58]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Computers and equipment |  | $ | 75,882 |  |  | $ | 73,244 |  |
| Purchased software |  |  | 38,177 |  |  |  | 34,015 |  |
| Office equipment, furniture and fixtures |  |  | 10,779 |  |  |  | 10,639 |  |
| Leasehold improvements |  |  | 53,421 |  |  |  | 52,317 |  |
| Total property and equipment |  |  | 178,259 |  |  |  | 170,215 |  |
| Less: accumulated depreciation and amortization |  |  | (122,285 | ) |  |  | (111,402 | ) |
| Property and equipment, net |  | $ | 55,974 |  |  | $ | 58,813 |  |

[0001564590-21-005006:notes:59]
[same as prior period, unchanged from 0001564590-20-048853:notes:57]

[0001564590-21-005006:notes:60]
[same as prior period, unchanged from 0001564590-20-048853:notes:58]

[0001564590-21-005006:notes:61]
[same as prior period, unchanged from 0001564590-20-048853:notes:59]

[0001564590-21-005006:notes:62]
[same as prior period, unchanged from 0001564590-20-048853:notes:60]

[0001564590-21-005006:notes:63]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2020 and 2019 (in thousands):

[0001564590-21-005006:notes:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Balance beginning of period |  | $ | 13,484 |  |  | $ | 15,988 |  |  | $ | 14,035 |  |  | $ | 14,779 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 570 |  |
| New warranties issued |  |  | 3,056 |  |  |  | 5,539 |  |  |  | 6,135 |  |  |  | 11,461 |  |
| Warranty expenditures |  |  | (3,467 | ) |  |  | (5,318 | ) |  |  | (7,097 | ) |  |  | (10,601 | ) |
| Balance end of period |  | $ | 13,073 |  |  | $ | 16,209 |  |  | $ | 13,073 |  |  | $ | 16,209 |  |

[0001564590-21-005006:notes:65]
[same as prior period, unchanged from 0001564590-20-048853:notes:63]

[0001564590-21-005006:notes:66]
[same as prior period, unchanged from 0001564590-20-048853:notes:67]

[0001564590-21-005006:notes:67]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company does not invest an amount exceeding 10% of its combined cash and cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-005006:notes:68]
[same as prior period, unchanged from 0001564590-20-048853:notes:69]

[0001564590-21-005006:notes:69]
[same as prior period, unchanged from 0001564590-20-048853:notes:70]

[0001564590-21-005006:notes:70]
[same as prior period, unchanged from 0001564590-20-048853:notes:71]

[0001564590-21-005006:notes:71]
[same as prior period, unchanged from 0001564590-20-048853:notes:72]

[0001564590-21-005006:notes:72]
[same as prior period, unchanged from 0001564590-20-048853:notes:73]

[0001564590-21-005006:notes:73]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at December 31, 2020 and June 30, 2020 (in thousands).

[0001564590-21-005006:notes:74]
| December 31, 2020 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 127 |  |  | $ | — |  |  | $ | 127 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 127 |  |  | $ | — |  |  | $ | 127 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 22 |  |  | $ | — |  |  | $ | 22 |  |
| Interest rate swaps |  |  | — |  |  |  | 1,676 |  |  |  | — |  |  |  | 1,676 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 1,168 |  |  |  | 1,168 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,698 |  |  | $ | 1,168 |  |  | $ | 2,866 |  |

[0001564590-21-005006:notes:75]
[same as prior period, unchanged from 0001564590-20-048853:notes:76]

[0001564590-21-005006:notes:76]
[same as prior period, unchanged from 0001564590-20-048853:notes:77]

[0001564590-21-005006:notes:77]
[same as prior period, unchanged from 0001564590-20-048853:notes:78]

[0001564590-21-005006:notes:78]
As of December 31, 2020 and June 30, 2020, the Company had foreign exchange forward contracts with notional principal amount of $22.7 million and $4.0 million, respectively. For the three and six months ended December 31, 2020, there were unrealized gains of $0.1 million and $0.1 million, respectively. For the three and six months ended December 31, 2020, there were realized gains of $0.3 million and $0.4 million, respectively.  There were no foreign exchange forward contracts or related gains or losses for the three and six months ended December 31, 2019. These contracts have maturities of less than 40 days. Changes in the fair value of these foreign exchange forward contracts are included in other expense, net. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-21-005006:notes:79]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of December 31, 2020 and as of June 30, 2020, the Company had interest rate swap contracts with the total notional amount of $200.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive loss. As of December 31, 2020 and as of June 30, 2020, these contracts had an unrealized loss of $1.7 million and $1.8 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-21-005006:notes:80]
The fair value of the borrowings under the 2019 Credit Agreement (as defined below) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Since the interest rate is variable in the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $356.3 million and $420.8 million as of December 31, 2020, and June 30, 2020, respectively.

[0001564590-21-005006:notes:81]
[same as prior period, unchanged from 0001564590-20-048853:notes:82]

[0001564590-21-005006:notes:82]
At December 31, 2020 and June 30, 2020, the Company reflected one liability measured at fair value of $1.2 million and $2.2 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-21-005006:notes:83]
[same as prior period, unchanged from 0001564590-20-048853:notes:84]

[0001564590-21-005006:notes:84]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Beginning balance |  |  | 2,167 |  |  |  | 6,298 |  |
| Payments |  |  | (1,021 | ) |  |  | (2,206 | ) |
| Accretion on discount |  |  | 22 |  |  |  | 60 |  |
| Ending balance |  | $ | 1,168 |  |  | $ | 4,152 |  |

[0001564590-21-005006:notes:85]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three and six months ended December 31, 2020 and 2019. There were no impairments recorded for the three and six months ended December 31, 2020 and 2019.

[0001564590-21-005006:notes:86]
[same as prior period, unchanged from 0001564590-20-048853:notes:87]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-005006:notes:87]
[same as prior period, unchanged from 0001564590-20-048853:notes:88]

[0001564590-21-005006:notes:88]
[same as prior period, unchanged from 0001564590-20-048853:notes:89]

[0001564590-21-005006:notes:89]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.1 years |  | $ | 156,100 |  |  | $ | 117,034 |  |  | $ | 39,066 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 52,077 |  |  |  | 10,962 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.0 years |  |  | 10,700 |  |  |  | 9,407 |  |  |  | 1,293 |  |
| License agreements |  | 5.9 years |  |  | 2,445 |  |  |  | 2,018 |  |  |  | 427 |  |
| Other intangibles |  | — years |  |  | 1,382 |  |  |  | 1,382 |  |  |  | — |  |
| Total intangibles, net |  |  |  | $ | 234,066 |  |  | $ | 182,318 |  |  | $ | 51,748 |  |

[0001564590-21-005006:notes:90]
[same as prior period, unchanged from 0001564590-20-048853:notes:91]

[0001564590-21-005006:notes:91]
[same as prior period, unchanged from 0001564590-20-048853:notes:92]

[0001564590-21-005006:notes:92]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Amortization in “Cost of revenues: Product and Service and subscription” |  | $ | 6,649 |  |  | $ | 6,970 |  |  | $ | 13,348 |  |  | $ | 13,465 |  |
| Amortization of intangibles in "Operations" |  |  | 1,506 |  |  |  | 2,377 |  |  |  | 3,298 |  |  |  | 4,307 |  |
| Total amortization expense |  | $ | 8,155 |  |  | $ | 9,347 |  |  | $ | 16,646 |  |  | $ | 17,772 |  |

[0001564590-21-005006:notes:93]
[same as prior period, unchanged from 0001564590-20-048853:notes:94]


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-005006:notes:94]
| 8. | Debt |

[0001564590-21-005006:notes:95]
The Company’s debt is comprised of the following (in thousands):

[0001564590-21-005006:notes:96]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 21,375 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,463 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 18,912 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 334,875 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,934 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 328,941 |  |  |  | 394,585 |  |
| Total debt |  | $ | 347,853 |  |  | $ | 411,101 |  |

[0001564590-21-005006:notes:97]
In connection with the Acquisition discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-21-005006:notes:98]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380 million and a five-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-21-005006:notes:99]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.40%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-21-005006:notes:100]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-21-005006:notes:101]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirements and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5%, and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-21-005006:notes:102]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-21-005006:notes:103]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of December 31, 2020 was 4.65%.

[0001564590-21-005006:notes:104]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.7 million for the three months ended December 31, 2020 and 2019, and totaled $1.5 million and $1.1 million for the six months ended December 31, 2020 and 2019.

[0001564590-21-005006:notes:105]
During the six months ended December 31, 2020, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at December 31, 2020.   The Company has $55.0 million of availability under the 2019 Revolving Facility as of December 31, 2020.

[0001564590-21-005006:notes:106]
The Company had $8.8 million of outstanding letters of credit as of December 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-005006:notes:107]
| 9. | Commitments and Contingencies |

[0001564590-21-005006:notes:108]
Purchase Commitments

[0001564590-21-005006:notes:109]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2020, the Company had commitments to purchase $38.0 million of inventory and other services.

[0001564590-21-005006:notes:110]
Legal Proceedings

[0001564590-21-005006:notes:111]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-21-005006:notes:112]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-21-005006:notes:113]
All currency conversions in this Legal Proceedings section are as of December 31, 2020.

[0001564590-21-005006:notes:114]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-21-005006:notes:115]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The Federal Circuit Court ruled for XR on November 25, 2020 in Cisco’s appeal of the ‘231 PTAB decision, and a status conference has been set for February 22, 2021. The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-21-005006:notes:116]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-21-005006:notes:117]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, pursuant to the appeal filed by Orckit on March 13, 2020.

[0001564590-21-005006:notes:118]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, and the Court issued an infringement decision against the Company and granted to Orckit the right to enforce an injunction against the Company. The Company filed a notice of appeal on November 12, 2020 and the matter is proceeding through the appellate process.

[0001564590-21-005006:notes:119]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019. Both cases were filed in the Federal Patent Court in Munich and seek to invalidate the asserted patents. Both nullity actions are proceeding.

[0001564590-21-005006:notes:120]
The Company believes that all claims in both cases filed by Orckit are without merit and intends to defend them vigorously.

[0001564590-21-005006:notes:121]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

[0001564590-21-005006:notes:122]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). A first and second hearing in the trial were held and the Court subsequently ordered the parties to retain a third-party appraisal center to analyze and report to the Court on various technical aspects of the case and has set out the scope of the appraisal.  The appraisal has not been conducted yet, and the Court has not issued a decision.  The Company believes that the claims are without merit and intends to defend them vigorously.

[0001564590-21-005006:notes:123]
DataCloud Technologies, LLC. v. Extreme Networks, Inc.

[0001564590-21-005006:notes:124]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware. The lawsuit alleges direct infringement of four U.S. patents. DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees. DataCloud amended the complaint on November 13, 2020, asserting claims of direct, induced, and willful infringement of four new patents, and has petitioned to file a second amended complaint by February 12, 2021. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-21-005006:notes:125]
American Patents LLC v. Extreme Networks, Inc.

[0001564590-21-005006:notes:126]
On August 14, 2020, American Patents LLC filed a patent infringement lawsuit against the Company in the Western District of Texas. The complaint alleged direct and indirect infringement of certain U.S. patents and seeks injunctive relief, unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The parties have settled the case for a non-material amount, and the case was dismissed on November 16, 2020.

[0001564590-21-005006:notes:127]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-21-005006:notes:128]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-21-005006:notes:129]
Hanger Solutions, LLC v. Extreme Networks, Inc.

[0001564590-21-005006:notes:130]
On January 14, 2021, Hanger Solutions, LLC (“Hanger”) filed a patent infringement lawsuit against the Company in the District of Delaware. The complaint alleges infringement of three U.S. patents. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-21-005006:notes:131]
Indemnification Obligations

[0001564590-21-005006:notes:132]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other

[0001564590-21-005006:notes:133]
liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-21-005006:notes:134]
[same as prior period, unchanged from 0001564590-20-048853:notes:133]

[0001564590-21-005006:notes:135]
[same as prior period, unchanged from 0001564590-20-048853:notes:134]

[0001564590-21-005006:notes:136]
[same as prior period, unchanged from 0001564590-20-048853:notes:135]

[0001564590-21-005006:notes:137]
The Company’s Board of Directors (the “Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of shares of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 8, 2020, to extend the Restated Rights Plan through May 31, 2021, which was ratified by the stockholders of the Company at the annual meeting of stockholders on November 5, 2020.

[0001564590-21-005006:notes:138]
[same as prior period, unchanged from 0001564590-20-048853:notes:137]

[0001564590-21-005006:notes:139]
[same as prior period, unchanged from 0001564590-20-048853:notes:138]

[0001564590-21-005006:notes:140]
[same as prior period, unchanged from 0001564590-20-048853:notes:139]

[0001564590-21-005006:notes:141]
[same as prior period, unchanged from 0001564590-20-048853:notes:140]

[0001564590-21-005006:notes:142]
[same as prior period, unchanged from 0001564590-20-048853:notes:141]

[0001564590-21-005006:notes:143]
On November 2, 2018, the Company announced the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions. In February 2020, the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020. A maximum of $30.0 million of the Company’s common stock may be repurchased in any calendar year.

[0001564590-21-005006:notes:144]
There were no shares repurchased during the three and six months ended December 31, 2020.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-005006:notes:145]
[same as prior period, unchanged from 0001564590-20-048853:notes:144]

[0001564590-21-005006:notes:146]
[same as prior period, unchanged from 0001564590-20-048853:notes:145]

[0001564590-21-005006:notes:147]
[same as prior period, unchanged from 0001564590-20-048853:notes:146]

[0001564590-21-005006:notes:148]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 6,149 |  |  |  | 13,118 |  |
| Employee stock options and awards outstanding |  |  | 12,478 |  |  |  | 10,396 |  |
| 2014 Employee Stock Purchase Plan |  |  | 5,913 |  |  |  | 7,364 |  |
| Total shares reserved for issuance |  |  | 24,540 |  |  |  | 30,878 |  |

[0001564590-21-005006:notes:149]
[same as prior period, unchanged from 0001564590-20-048853:notes:148]

[0001564590-21-005006:notes:150]
[same as prior period, unchanged from 0001564590-20-048853:notes:149]

[0001564590-21-005006:notes:151]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Cost of product revenues |  | $ | 314 |  |  | $ | 402 |  |  | $ | 572 |  |  | $ | 652 |  |
| Cost of service and subscription revenues |  |  | 439 |  |  |  | 505 |  |  |  | 811 |  |  |  | 852 |  |
| Research and development |  |  | 2,694 |  |  |  | 3,260 |  |  |  | 4,966 |  |  |  | 5,695 |  |
| Sales and marketing |  |  | 3,239 |  |  |  | 3,511 |  |  |  | 5,886 |  |  |  | 7,230 |  |
| General and administrative |  |  | 3,409 |  |  |  | 2,801 |  |  |  | 6,162 |  |  |  | 4,884 |  |
| Integration costs |  |  | — |  |  |  | 479 |  |  |  | — |  |  |  | 479 |  |
| Total share-based compensation expense |  | $ | 10,095 |  |  | $ | 10,958 |  |  | $ | 18,397 |  |  | $ | 19,792 |  |

[0001564590-21-005006:notes:152]
[same as prior period, unchanged from 0001564590-20-048853:notes:151]

[0001564590-21-005006:notes:153]
The following table summarizes stock option activity for the six months ended December 31, 2020 (in thousands, except per share and contractual term):

[0001564590-21-005006:notes:154]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2020 |  |  | 2,922 |  |  | $ | 4.95 |  |  |  | 3.09 |  |  | $ | 1,688 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (19 | ) |  |  | 4.39 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (600 | ) |  |  | 5.30 |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2020 |  |  | 2,303 |  |  | $ | 4.87 |  |  |  | 3.33 |  |  | $ | 4,653 |  |
| Vested and expected to vest at December 31, 2020 |  |  | 2,303 |  |  | $ | 4.87 |  |  |  | 3.33 |  |  | $ | 4,653 |  |
| Exercisable at December 31, 2020 |  |  | 1,262 |  |  | $ | 3.50 |  |  |  | 1.89 |  |  | $ | 4,274 |  |

[0001564590-21-005006:notes:155]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the six months ended December 31, 2020. The average fair value of the stock options granted during the six months ended December 31, 2019 was $3.52.

[0001564590-21-005006:notes:156]
[same as prior period, unchanged from 0001564590-20-048853:notes:155]

[0001564590-21-005006:notes:157]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance or market-condition RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the awards’ fair value as of the date of grant.  The Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-21-005006:notes:158]
The following table summarizes stock award activity for the six months ended December 31, 2020 (in thousands, except grant date fair value):

[0001564590-21-005006:notes:159]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2020 |  |  | 7,474 |  |  | $ | 6.83 |  |  |  |  |  |
| Granted |  |  | 5,703 |  |  |  | 4.70 |  |  |  |  |  |
| Released |  |  | (2,342 | ) |  |  | 7.24 |  |  |  |  |  |
| Cancelled |  |  | (660 | ) |  |  | 9.37 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2020 |  |  | 10,175 |  |  | $ | 5.37 |  |  | $ | 70,104 |  |
| Vested and expected to vest at December 31, 2020 |  |  | 9,709 |  |  | $ | 5.32 |  |  | $ | 66,864 |  |

[0001564590-21-005006:notes:160]
The RSU's granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company. The stock awards granted during the six months ended December 31, 2020 included 1.6 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0001564590-21-005006:notes:161]
[same as prior period, unchanged from 0001564590-20-048853:notes:160]

[0001564590-21-005006:notes:162]
On July 27, 2020, the Compensation Committee of the Board granted 0.5 million RSUs with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. These MSUs will vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods from August 15, 2020 through August 15, 2023, subject to the grantees’ continued service through the certification of performance.

[0001564590-21-005006:notes:163]
[same as prior period, unchanged from 0001564590-20-048853:notes:162]

[0001564590-21-005006:notes:164]
[same as prior period, unchanged from 0001564590-20-048853:notes:163]

[0001564590-21-005006:notes:165]
[same as prior period, unchanged from 0001564590-20-048853:notes:164]

[0001564590-21-005006:notes:166]
[same as prior period, unchanged from 0001564590-20-048853:notes:165]

[0001564590-21-005006:notes:167]
During fiscal 2019 and 2018, the Company approved the grant of 0.6 million shares underlying stock awards each year in the form of restricted stock units with certain performance conditions (“PSUs”) to named executive officers and other vice president level employees. These PSUs would vest once the Company’s U.S. GAAP earnings aggregates at least $0.09 per share over two consecutive quarters exclusive of the PSU related share-based compensation expense (the “Performance Thresholds”). Upon satisfying the Performance Thresholds, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the Performance Thresholds are not met by the third anniversary of the grant date for each award, that award is canceled. The PSUs issued in fiscal 2018 expired and were cancelled during the three and six months ended December 31, 2020 without the achievement of the Performance Thresholds.  During the three and six months ended December 31, 2020 and 2019 the Performance Thresholds for outstanding performance PSUs issued in fiscal 2019 were not deemed probable to be achieved, and as such, no compensation expense was recorded in either reporting period.

[0001564590-21-005006:notes:168]
[same as prior period, unchanged from 0001564590-20-048853:notes:167]

[0001564590-21-005006:notes:169]
There were 1.5 million and 1.2 million shares issued under the ESPP during the six months ended December 31, 2020 and 2019, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001564590-21-005006:notes:170]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 0.12 | % |  |  | 1.85 | % |
| Volatility |  |  | 119 | % |  |  | 43 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-21-005006:notes:171]
The weighted-average grant-date fair value of shares issued under the ESPP during the six months ended December 31, 2020 and 2019 was $2.23 and $2.02, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-005006:notes:172]
[same as prior period, unchanged from 0001564590-20-048853:notes:171]

[0001564590-21-005006:notes:173]
[same as prior period, unchanged from 0001564590-20-048853:notes:172]

[0001564590-21-005006:notes:174]
[same as prior period, unchanged from 0001564590-20-048853:notes:173]

[0001564590-21-005006:notes:175]
[same as prior period, unchanged from 0001564590-20-048853:notes:174]

[0001564590-21-005006:notes:176]
| Long-lived Assets |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Americas |  | $ | 161,396 |  |  | $ | 177,443 |  |
| EMEA |  |  | 33,052 |  |  |  | 39,477 |  |
| APAC |  |  | 16,932 |  |  |  | 16,802 |  |
| Total long-lived assets |  | $ | 211,380 |  |  | $ | 233,722 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-21-005006:notes:177]
[same as prior period, unchanged from 0001564590-20-048853:notes:176]

[0001564590-21-005006:notes:178]
[same as prior period, unchanged from 0001564590-20-048853:notes:181]

[0001564590-21-005006:notes:179]
[same as prior period, unchanged from 0001564590-20-048853:notes:182]

[0001564590-21-005006:notes:180]
[same as prior period, unchanged from 0001564590-20-048853:notes:183]

[0001564590-21-005006:notes:181]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt.  As of December 31, 2020, the total notional amount of these interest rate swaps was $200.0 million and had maturity dates through April 2023. As of December 31, 2020, these contracts had an unrealized loss of $1.7 million which is recorded in “Accumulated other comprehensive loss” with the associated liability in “Other accrued liabilities” in the condensed consolidated balance sheets and other financial statements. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. The Company did not have any interest rate swaps as of or for the six months ended December 31, 2019. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive loss related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $1.0 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0001564590-21-005006:notes:182]
[same as prior period, unchanged from 0001564590-20-048853:notes:177]

[0001564590-21-005006:notes:183]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. Unrealized gains recorded in the condensed consolidated statement of operations from these transactions during the three and six months ended December 31, 2020 were $0.1 million and $0.1 million, respectively. Realized gains and losses recorded in the condensed consolidated statement of operations from these transactions during the three and six months ended December 31, 2020 were $0.3 million and $0.4 million, respectively. There were no related gains and losses for the six months ended December 31, 2019 as the Company did not have any foreign exchange forward contracts at December 31, 2019.

[0001564590-21-005006:notes:184]
As of December 31, 2020, foreign exchange forward contracts had a notional principal amount of $22.7 million. These contracts have maturities of less than 40 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001564590-21-005006:notes:185]
The Company recognized total foreign currency losses of $1.3 million and $0.8 million for the three months ended December 31, 2020 and 2019, respectively related to the change in fair value of foreign currency denominated assets and liabilities. The Company recognized total foreign currency losses of $2.4 million and $0.2 million for the six months ended December 31, 2020 and 2019, respectively related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-005006:notes:186]
[same as prior period, unchanged from 0001564590-20-048853:notes:185]

[0001564590-21-005006:notes:187]
The Company recorded $0.7 million and $1.7 million of restructuring charges, net of reversals and impairments during the three and six months ended December 31, 2020, respectively. Total restructuring charges included severance, benefits, and equipment relocation charges of $0.4 million and $1.1 million, as well as facility related charges of $0.3 million and $0.6 million for the three and six months ended December 31, 2020, respectively. Severance and benefit restructuring charges consisted primarily of additional employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under the 2020 Plan, the Company is relocating certain of its lab test equipment to third-party consulting companies. The Company has incurred $9.2 million of charges under the 2020 Plan through December 31, 2020. The Company expects to incur additional equipment related relocation expenses of $0.8 million and expects to substantially complete these activities by the first half of fiscal 2022. The facility restructuring charges included additional facilities expenses related to previously impaired facilities.

[0001564590-21-005006:notes:188]
The Company recorded $6.6 million and $12.8 million of restructuring charges, net of reversals and impairment during the three and six months ended December 31, 2019, respectively. The charges included $3.9 million and $7.9 million, respectively, for the impairment of right-of-use assets related to facilities which the Company has exited, and $2.7 million and $4.9 million, respectively for and employee severance and benefit expenses incurred under the Company’s restructuring plans initiated in prior years which were completed as of the end of fiscal 2020.

[0001564590-21-005006:notes:189]
Restructuring liabilities related to severance, benefits, and equipment relocation obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. The following table summarizes the activity related to the severance, benefits, and equipment relocation liabilities during the three and six months ended December 31, 2020 (in thousands):

[0001564590-21-005006:notes:190]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Severance and Other |  |  | Severance and Other |  |
| Balance at beginning of period |  | $ | 302 |  |  | $ | 2,137 |  |  | $ | 2,219 |  |  | $ | 3,559 |  |
| Period charges |  |  | 475 |  |  |  | 3,284 |  |  |  | 1,247 |  |  |  | 5,879 |  |
| Period reversals |  |  | (78 | ) |  |  | (596 | ) |  |  | (128 | ) |  |  | (1,005 | ) |
| Period payments |  |  | (518 | ) |  |  | (3,957 | ) |  |  | (3,157 | ) |  |  | (7,565 | ) |
| Balance at end of period |  | $ | 181 |  |  | $ | 868 |  |  | $ | 181 |  |  | $ | 868 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-005006:notes:191]
[same as prior period, unchanged from 0001564590-20-048853:notes:190]

[0001564590-21-005006:notes:192]
For the three months ended December 31, 2020 and 2019, the Company recorded an income tax provision of $1.8 million and $1.8 million, respectively. For the six months ended December 31, 2020 and 2019, the Company recorded an income tax provision of $3.1 and $3.4 million, respectively.

[0001564590-21-005006:notes:193]
The income tax provisions for the three and six months ended December 31, 2020 and 2019, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade, and (4) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”). The interim income tax provisions for the three and six months ended December 30, 2020 and 2019 were calculated using the discrete effective tax rate method as allowed by Accounting Standards Codification (“ASC”) 740-270-30-18, “Income Taxes – Interim Reporting.”  The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate.  The discrete method treats the year to date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001564590-21-005006:notes:194]
On December 27,2020 the Consolidated Appropriations Act (“CAA”), 2021 was signed into law in the United States.  Along with providing funding for normal government operations, the bill provides for additional COVID-19 focused relief in part, in the form of modification and extension of certain CARES Act provisions (discussed below) as well as modification and extension of other traditional tax provisions.  The Company has reviewed the provisions of the CAA and has determined there is no material impact on the Company’s current or deferred tax position.

[0001564590-21-005006:notes:195]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in the United States.  The CARES Act, among other things, includes modifications to net operating loss carryforward provisions and the net interest expense deduction, and deferment of employer social security tax payments.  The Company has evaluated the provisions of the CARES Act and how certain elections may impact its financial position and results of operations, and determined the enactment of the CARES Act did not have a material impact to the Company’s income tax provision for the three and six months ended December 31, 2020, or to the Company’s net deferred tax assets as of December 31, 2020.

[0001564590-21-005006:notes:196]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if

[0001564590-21-005006:notes:197]
business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-21-005006:notes:198]
On August 9, 2019, the Company completed its acquisition of Aerohive.  This acquisition was treated as a non-taxable stock acquisition and, therefore, Extreme Networks will have carryover tax basis in the assets and liabilities acquired. During the fourth quarter of fiscal 2020 following the acquisition of Aerohive, the Company realigned the Aerohive related non U.S. intellectual property rights to correspond with the Company’s global operating model.  This transaction resulted in recognition of a $75.0 million U.S. tax gain which was fully consumed by existing NOLs and the intangibles transferred are being amortized over 10 years for Irish statutory purposes.

[0001564590-21-005006:notes:199]
The Company had $24.2 million of unrecognized tax benefits as of December 31, 2020.  If fully recognized in the future, $0.5 million would impact the effective tax rate and $23.7 million, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-21-005006:notes:200]
[same as prior period, unchanged from 0001564590-20-048853:notes:198]

[0001564590-21-005006:notes:201]
[same as prior period, unchanged from 0001564590-20-048853:notes:199]


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-005006:notes:202]
[same as prior period, unchanged from 0001564590-20-048853:notes:200]

[0001564590-21-005006:notes:203]
Basic net loss per share is calculated by dividing net loss by the weighted average number of shares of common stock outstanding during the period. Dilutive income per share is calculated by dividing net income by the weighted average number of shares of common stock used in the basic net loss per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0001564590-21-005006:notes:204]
[same as prior period, unchanged from 0001564590-20-048853:notes:202]

[0001564590-21-005006:notes:205]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Net loss |  | $ | (3,050 | ) |  | $ | (23,538 | ) |  | $ | (11,862 | ) |  | $ | (61,276 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 123,264 |  |  |  | 119,555 |  |  |  | 122,485 |  |  |  | 119,891 |  |
| Net loss per share - basic and diluted |  | $ | (0.02 | ) |  | $ | (0.20 | ) |  | $ | (0.10 | ) |  | $ | (0.51 | ) |

[0001564590-21-005006:notes:206]
[same as prior period, unchanged from 0001564590-20-048853:notes:204]

[0001564590-21-005006:notes:207]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Options to purchase common stock |  |  | 2,156 |  |  |  | 3,177 |  |  |  | 2,345 |  |  |  | 3,037 |  |
| Restricted stock units |  |  | 9,553 |  |  |  | 10,378 |  |  |  | 9,003 |  |  |  | 9,862 |  |
| Employee Stock Purchase Plan shares |  |  | 1,324 |  |  |  | 1,500 |  |  |  | 1,040 |  |  |  | 1,500 |  |
| Total shares excluded |  |  | 13,033 |  |  |  | 15,055 |  |  |  | 12,388 |  |  |  | 14,399 |  |
