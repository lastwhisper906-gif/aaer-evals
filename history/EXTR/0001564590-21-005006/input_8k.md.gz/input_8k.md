# EXTR 8-K — 0001564590-21-005000 filed 2021-02-09

## item codes, every 8-K on or before 2021-02-09

- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2021-02-09

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-005000:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-21-005000:8k_2_02:2]
extr-ex991_6.htm

[0001564590-21-005000:8k_2_02:3]
Exhibit 99.1

[0001564590-21-005000:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-21-005000:8k_2_02:5]
Extreme Networks Reports Second Quarter Fiscal Year 2021 Financial Results

[0001564590-21-005000:8k_2_02:6]
Achieved Record Non-GAAP Gross Margin and Double-Digit Operating Profit

[0001564590-21-005000:8k_2_02:7]
Reaffirms Q3 Business Outlook

[0001564590-21-005000:8k_2_02:8]
SAN JOSE, Calif., February 9, 2021 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its second fiscal quarter ended December 31, 2020, which follows Extreme’s preliminary results reported on January 27, 2021. The company has finalized its quarter-end procedures and is reporting its final Q2 financial results.

[0001564590-21-005000:8k_2_02:9]
Fiscal Second Quarter Results:

[0001564590-21-005000:8k_2_02:10]
|  | • | Revenue $242.1 million, down 9% year-over-year and up 3% quarter-over-quarter |

[0001564590-21-005000:8k_2_02:11]
|  | • | GAAP EPS $(0.02), up from ($0.20) in Q2 last year |

[0001564590-21-005000:8k_2_02:12]
|  | • | Non-GAAP EPS $0.13, up from $0.11 in Q2 last year |

[0001564590-21-005000:8k_2_02:13]
|  | • | GAAP gross margin 57.9% compared to 55.6% in Q2 last year |

[0001564590-21-005000:8k_2_02:14]
|  | • | Non-GAAP gross margin 61.0% compared to 60.0% in Q2 last year |

[0001564590-21-005000:8k_2_02:15]
|  | • | GAAP operating margin 2.4% compared to (5.7)% in Q2 last year |

[0001564590-21-005000:8k_2_02:16]
|  | • | Non-GAAP operating margin 10.2%, compared to 9.0% in Q2 last year |

[0001564590-21-005000:8k_2_02:17]
|  | • | Net cash provided by operating activities of $38.0 million |

[0001564590-21-005000:8k_2_02:18]
|  | • | Free Cash Flow of $33.0 million |

[0001564590-21-005000:8k_2_02:19]
“Our Q2 results reflect the strength of Extreme’s financial and business performance, despite the challenging operating environment. We reiterate our previously issued Q3 business outlook. We expect double-digit year-over-year revenue growth and margin expansion due to increased demand in the marketplace for our differentiated solutions in the second half of FY21,” stated Ed Meyercord, President and CEO of Extreme.

[0001564590-21-005000:8k_2_02:20]
“Our final Q2 results are highlighted by 3% sequential revenue growth and record non-GAAP gross margins, driven by a third consecutive quarter of improvement in product gross margin. We achieved double-digit operating margin two quarters ahead of our prior expectations, with a 10.2% non-GAAP operating margin, and generated over $30 in million cash flow,” stated Remi Thomas, CFO of Extreme.

[0001564590-21-005000:8k_2_02:21]
Fiscal Q2 2021 Financial Metrics:

[0001564590-21-005000:8k_2_02:22]
(in millions, except percentages and per share information)

[0001564590-21-005000:8k_2_02:23]
|  |  | Q2 FY'21 |  |  | Q2 FY'20 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 165.8 |  |  | $ | 190.5 |  |  | $ | (24.7 | ) |  |  | (13 | )% |
| Service and subscription |  |  | 76.3 |  |  |  | 77.0 |  |  |  | (0.7 | ) |  |  | (1 | )% |
| Total net revenue |  | $ | 242.1 |  |  | $ | 267.5 |  |  | $ | (25.4 | ) |  |  | (9 | )% |
| Gross margin |  |  | 57.9 | % |  |  | 55.6 | % |  | 230 bps |  |  | - |  |
| Operating margin |  |  | 2.4 | % |  |  | (5.7 | )% |  | 806 bps |  |  | - |  |
| Net loss |  | $ | (3.1 | ) |  | $ | (23.5 | ) |  | $ | 20.4 |  |  |  | 87 | % |
| Net loss per diluted share |  | $ | (0.02 | ) |  | $ | (0.20 | ) |  | $ | 0.18 |  |  |  | 90 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 165.8 |  |  | $ | 190.5 |  |  | $ | (24.7 | ) |  |  | (13 | )% |
| Service and subscription |  |  | 76.3 |  |  |  | 77.0 |  |  |  | (0.7 | ) |  |  | (1 | )% |
| Total net revenue |  | $ | 242.1 |  |  | $ | 267.5 |  |  | $ | (25.4 | ) |  |  | (9 | )% |
| Gross margin |  |  | 61.0 | % |  |  | 60.0 | % |  | 100 bps |  |  | - |  |
| Operating margin |  |  | 10.2 | % |  |  | 9.0 | % |  | 120 bps |  |  | - |  |
| Net income |  | $ | 16.0 |  |  | $ | 13.1 |  |  | $ | 2.9 |  |  |  | 22 | % |
| Net income per diluted share |  | $ | 0.13 |  |  | $ | 0.11 |  |  | $ | 0.02 |  |  |  | 18 | % |

[0001564590-21-005000:8k_2_02:24]
|  | • | Q2 ending cash balance was $184.0 million, a decrease of $9.1 million from the end of Q1. This was primarily driven by cash usage of $42.5 million for financing activities, primarily due to full repayment of our revolving credit facility and principal payments on our term loan, along with $5.0 million for capital expenditures, partially offset by operating cash flow generation of $38.0 million. |

[0001564590-21-005000:8k_2_02:25]
|  | • | Q2 accounts receivable balance was $128.2 million, with days sales outstanding of 49, an increase of 1 day from Q1 and a decrease of 6 days from Q2 last year. |

[0001564590-21-005000:8k_2_02:26]
|  | • | Q2 ending inventory was $49.8 million, a decrease of $6.0 million from Q1 and a decrease of $29.9 million from Q2 last year. The year-over-year and quarter-over-quarter decreases in inventory largely reflects improved demand planning, SKU rationalization and higher inventory turnover. |

[0001564590-21-005000:8k_2_02:27]
|  | • | Q2 ending gross debt* was $356.3 million, a decrease of $39.8 million from the prior quarter. The decrease reflects the principal debt payment of approximately $4.8 million and payments of $35.0 million on the revolving credit facility. The $19.0 million decrease from Q2 last year resulted primarily from principal debt payments. Net debt* of $172.3 million decreased by $30.6 million from $202.9 million in Q1. |

[0001564590-21-005000:8k_2_02:28]
|  | • | Since publishing its preliminary Q2 results on January 27, 2021, the Company has now finalized the estimate of its distributor rebate accrual and recorded an immaterial adjustment, which is incorporated in its Q2 reported financial results. This had no effect on quarterly cash flows. |

[0001564590-21-005000:8k_2_02:29]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors

[0001564590-21-005000:8k_2_02:30]
regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-21-005000:8k_2_02:31]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Cash flow provided by operations | $ | 38,026 |  |  | $ | 22,112 |  |  | $ | 62,771 |  |  | $ | 21,911 |  |
| Less: PP&E CapEx spending |  | (5,016 | ) |  |  | (4,198 | ) |  |  | (8,039 | ) |  |  | (9,438 | ) |
| Total free cash flow | $ | 33,010 |  |  | $ | 17,914 |  |  | $ | 54,732 |  |  | $ | 12,473 |  |

[0001564590-21-005000:8k_2_02:32]
*Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs. Net debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-21-005000:8k_2_02:33]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 356.3 |  |  | $ | 184.0 |  |  | $ | 172.3 |  |

[0001564590-21-005000:8k_2_02:34]
Business Outlook:

[0001564590-21-005000:8k_2_02:35]
For its third quarter of fiscal 2021, ending March 31, 2021, the Company is targeting:

[0001564590-21-005000:8k_2_02:36]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ3'21 Guidance – GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 240.0 |  |  | $ | 250.0 |  |
| Gross Margin |  | 58.4 | % |  |  | 59.5 | % |
| Operating Expenses | $ | 137.6 |  |  | $ | 139.6 |  |
| Operating Margin |  | 1.1 | % |  |  | 3.7 | % |
| Net Income (loss) | $ | (5.5 | ) |  | $ | 1.1 |  |
| Net Income (loss) per diluted share | $ | (0.04 | ) |  | $ | 0.01 |  |
| Shares outstanding used in calculating GAAP EPS | 124.7 |  |  | 126.6 |  |
| FQ3’21 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 240.0 |  |  | $ | 250.0 |  |
| Gross Margin |  | 61.5 | % |  |  | 62.5 | % |
| Operating Expenses | $ | 126.0 |  |  | $ | 128.0 |  |
| Operating Margin |  | 9.0 | % |  |  | 11.3 | % |
| Net Income | $ | 13.5 |  |  | $ | 20.1 |  |
| Income per diluted share | $ | 0.11 |  |  | $ | 0.16 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 126.6 |  |  |  | 126.6 |  |

[0001564590-21-005000:8k_2_02:37]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY’21 guidance:

[0001564590-21-005000:8k_2_02:38]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 58.4% - 59.5% |  |  | 1.1% - 3.7% |  |  | $(0.04) - $0.01 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.4% |  |  | 2.4% |  |  |  | 0.05 |  |
| Share-based compensation | 0.3% |  |  | 4.1% |  |  |  | 0.08 |  |
| Restructuring |  | — |  |  | 0.3% |  |  |  | 0.01 |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.9% |  |  |  | 0.02 |  |
| Non-GAAP | 61.5% - 62.5% |  |  | 9.0% - 11.3% |  |  | $0.11- $0.16 |  |

[0001564590-21-005000:8k_2_02:39]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-21-005000:8k_2_02:40]
About Extreme:

[0001564590-21-005000:8k_2_02:41]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-21-005000:8k_2_02:42]
Extreme Networks, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries.   Other trademarks shown herein are the property of their respective owners.

[0001564590-21-005000:8k_2_02:43]
Non-GAAP Financial Measures:

[0001564590-21-005000:8k_2_02:44]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, inventory valuation adjustment, and restructuring charges.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-21-005000:8k_2_02:45]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-21-005000:8k_2_02:46]
Forward Looking Statements:

[0001564590-21-005000:8k_2_02:47]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2020, Quarterly Report on Form 10-Q for the quarter ended September 30, 2020, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-21-005000:8k_2_02:48]
###

[0001564590-21-005000:8k_2_02:49]
EXTREME NETWORKS, INC.

[0001564590-21-005000:8k_2_02:50]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-21-005000:8k_2_02:51]
(In thousands, except per share amounts)

[0001564590-21-005000:8k_2_02:52]
(Unaudited)

[0001564590-21-005000:8k_2_02:53]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 183,969 |  |  | $ | 193,872 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,335 and $1,212, respectively |  |  | 128,242 |  |  |  | 122,727 |  |
| Inventories |  |  | 49,830 |  |  |  | 62,589 |  |
| Prepaid expenses and other current assets |  |  | 41,257 |  |  |  | 35,019 |  |
| Total current assets |  |  | 403,298 |  |  |  | 414,207 |  |
| Property and equipment, net |  |  | 55,974 |  |  |  | 58,813 |  |
| Operating lease right-of-use assets, net |  |  | 45,087 |  |  |  | 51,274 |  |
| Intangible assets, net |  |  | 51,748 |  |  |  | 68,394 |  |
| Goodwill |  |  | 331,159 |  |  |  | 331,159 |  |
| Other assets |  |  | 58,571 |  |  |  | 55,241 |  |
| Total assets |  | $ | 945,837 |  |  | $ | 979,088 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,463 and $2,484, respectively |  | $ | 18,912 |  |  | $ | 16,516 |  |
| Accounts payable |  |  | 53,677 |  |  |  | 48,439 |  |
| Accrued compensation and benefits |  |  | 62,212 |  |  |  | 50,884 |  |
| Accrued warranty |  |  | 13,073 |  |  |  | 14,035 |  |
| Current portion, operating lease liabilities |  |  | 19,226 |  |  |  | 19,196 |  |
| Current portion, deferred revenue |  |  | 198,291 |  |  |  | 190,226 |  |
| Other accrued liabilities |  |  | 56,851 |  |  |  | 58,525 |  |
| Total current liabilities |  |  | 422,242 |  |  |  | 397,821 |  |
| Deferred revenue, less current portion |  |  | 110,844 |  |  |  | 100,961 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $5,934 and $7,165, respectively |  |  | 328,941 |  |  |  | 394,585 |  |
| Operating lease liabilities, less current portion |  |  | 42,059 |  |  |  | 50,238 |  |
| Deferred income taxes |  |  | 2,650 |  |  |  | 2,334 |  |
| Other long-term liabilities |  |  | 21,176 |  |  |  | 27,751 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 130,180 and 127,114 shares issued, respectively; 123,583 and 120,517 shares outstanding, respectively |  |  | 130 |  |  |  | 127 |  |
| Additional paid-in-capital |  |  | 1,055,719 |  |  |  | 1,035,041 |  |
| Accumulated other comprehensive loss |  |  | (2,670 | ) |  |  | (6,378 | ) |
| Accumulated deficit |  |  | (992,141 | ) |  |  | (980,279 | ) |
| Treasury stock at cost: 6,597 and 6,597 shares, respectively |  |  | (43,113 | ) |  |  | (43,113 | ) |
| Total stockholders’ equity |  |  | 17,925 |  |  |  | 5,398 |  |
| Total liabilities and stockholders’ equity |  | $ | 945,837 |  |  | $ | 979,088 |  |

[0001564590-21-005000:8k_2_02:54]
EXTREME NETWORKS, INC.

[0001564590-21-005000:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-005000:8k_2_02:56]
(In thousands, except per share amounts)

[0001564590-21-005000:8k_2_02:57]
(Unaudited)

[0001564590-21-005000:8k_2_02:58]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 165,845 |  |  | $ | 190,492 |  |  | $ | 327,241 |  |  | $ | 375,626 |  |
| Service and subscription |  |  | 76,283 |  |  |  | 76,980 |  |  |  | 150,689 |  |  |  | 147,352 |  |
| Total net revenues |  |  | 242,128 |  |  |  | 267,472 |  |  |  | 477,930 |  |  |  | 522,978 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 74,005 |  |  |  | 91,387 |  |  |  | 147,400 |  |  |  | 182,778 |  |
| Service and subscription |  |  | 27,931 |  |  |  | 27,414 |  |  |  | 55,320 |  |  |  | 54,286 |  |
| Total cost of revenues |  |  | 101,936 |  |  |  | 118,801 |  |  |  | 202,720 |  |  |  | 237,064 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 91,840 |  |  |  | 99,105 |  |  |  | 179,841 |  |  |  | 192,848 |  |
| Service and subscription |  |  | 48,352 |  |  |  | 49,566 |  |  |  | 95,369 |  |  |  | 93,066 |  |
| Total gross profit |  |  | 140,192 |  |  |  | 148,671 |  |  |  | 275,210 |  |  |  | 285,914 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 49,186 |  |  |  | 55,380 |  |  |  | 98,710 |  |  |  | 114,496 |  |
| Sales and marketing |  |  | 66,732 |  |  |  | 75,436 |  |  |  | 131,057 |  |  |  | 146,793 |  |
| General and administrative |  |  | 16,360 |  |  |  | 15,098 |  |  |  | 32,821 |  |  |  | 30,080 |  |
| Acquisition and integration costs |  |  | — |  |  |  | 8,994 |  |  |  | 1,975 |  |  |  | 24,919 |  |
| Restructuring and related charges, net of reversals |  |  | 695 |  |  |  | 6,622 |  |  |  | 1,696 |  |  |  | 12,759 |  |
| Amortization of intangibles |  |  | 1,506 |  |  |  | 2,377 |  |  |  | 3,298 |  |  |  | 4,307 |  |
| Total operating expenses |  |  | 134,479 |  |  |  | 163,907 |  |  |  | 269,557 |  |  |  | 333,354 |  |
| Operating income (loss) |  |  | 5,713 |  |  |  | (15,236 | ) |  |  | 5,653 |  |  |  | (47,440 | ) |
| Interest income |  |  | 82 |  |  |  | 477 |  |  |  | 200 |  |  |  | 1,144 |  |
| Interest expense |  |  | (6,068 | ) |  |  | (6,234 | ) |  |  | (12,731 | ) |  |  | (11,398 | ) |
| Other expense, net |  |  | (954 | ) |  |  | (748 | ) |  |  | (1,841 | ) |  |  | (190 | ) |
| Income (loss) before income taxes |  |  | (1,227 | ) |  |  | (21,741 | ) |  |  | (8,719 | ) |  |  | (57,884 | ) |
| Provision for income taxes |  |  | 1,823 |  |  |  | 1,797 |  |  |  | 3,143 |  |  |  | 3,392 |  |
| Net loss |  | $ | (3,050 | ) |  | $ | (23,538 | ) |  | $ | (11,862 | ) |  | $ | (61,276 | ) |
| Basic and diluted loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic and diluted |  | $ | (0.02 | ) |  | $ | (0.20 | ) |  | $ | (0.10 | ) |  | $ | (0.51 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 123,264 |  |  |  | 119,555 |  |  |  | 122,485 |  |  |  | 119,891 |  |

[0001564590-21-005000:8k_2_02:59]
EXTREME NETWORKS, INC.

[0001564590-21-005000:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-21-005000:8k_2_02:61]
(In thousands)

[0001564590-21-005000:8k_2_02:62]
(Unaudited)

[0001564590-21-005000:8k_2_02:63]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (11,862 | ) |  | $ | (61,276 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 12,471 |  |  |  | 14,251 |  |
| Amortization of intangible assets |  |  | 16,646 |  |  |  | 17,772 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 8,072 |  |  |  | 8,477 |  |
| Provision for doubtful accounts |  |  | 143 |  |  |  | 626 |  |
| Share-based compensation |  |  | 18,397 |  |  |  | 19,792 |  |
| Deferred income taxes |  |  | 628 |  |  |  | 801 |  |
| Non-cash restructuring and impairment charges |  |  | - |  |  |  | 7,622 |  |
| Non-cash interest expense |  |  | 2,171 |  |  |  | 1,982 |  |
| Other |  |  | 3,195 |  |  |  | 735 |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (5,658 | ) |  |  | 25,751 |  |
| Inventories |  |  | 6,340 |  |  |  | 3,157 |  |
| Prepaid expenses and other assets |  |  | (3,740 | ) |  |  | (274 | ) |
| Accounts payable |  |  | 4,913 |  |  |  | (9,070 | ) |
| Accrued compensation and benefits |  |  | 10,984 |  |  |  | (3,036 | ) |
| Operating lease liabilities |  |  | (10,116 | ) |  |  | (9,051 | ) |
| Deferred revenue |  |  | 17,949 |  |  |  | 6,181 |  |
| Other current and long-term liabilities |  |  | (7,762 | ) |  |  | (2,529 | ) |
| Net cash provided by operating activities |  |  | 62,771 |  |  |  | 21,911 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (8,039 | ) |  |  | (9,438 | ) |
| Business acquisitions, net of cash acquired |  |  | — |  |  |  | (219,458 | ) |
| Maturities and sales of investments |  |  | — |  |  |  | 45,249 |  |
| Net cash used in investing activities |  |  | (8,039 | ) |  |  | (183,647 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 199,500 |  |
| Payments on debt obligations |  |  | (64,500 | ) |  |  | (24,950 | ) |
| Loan fees on borrowings |  |  | — |  |  |  | (10,514 | ) |
| Equity forward contract |  |  | — |  |  |  | (4,821 | ) |
| Repurchase of common stock |  |  | — |  |  |  | (25,179 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 2,284 |  |  |  | 2,906 |  |
| Payment of contingent consideration obligations |  |  | (1,021 | ) |  |  | (2,206 | ) |
| Deferred payments on an acquisition |  |  | (2,000 | ) |  |  | (2,000 | ) |
| Net cash (used in) provided by financing activities |  |  | (65,237 | ) |  |  | 132,736 |  |
| Foreign currency effect on cash |  |  | 602 |  |  |  | (193 | ) |
| Net decrease in cash |  |  | (9,903 | ) |  |  | (29,193 | ) |
| Cash at beginning of period |  |  | 193,872 |  |  |  | 169,607 |  |
| Cash at end of period |  | $ | 183,969 |  |  | $ | 140,414 |  |

[0001564590-21-005000:8k_2_02:64]
Extreme Networks, Inc.

[0001564590-21-005000:8k_2_02:65]
Non-GAAP Measures of Financial Performance

[0001564590-21-005000:8k_2_02:66]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per diluted share and non-GAAP free cash flow.

[0001564590-21-005000:8k_2_02:67]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme also presents its target for non-GAAP operating expenses, which is operating expenses less share-based compensation expense, restructuring charges and amortization of acquired intangibles.

[0001564590-21-005000:8k_2_02:68]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-21-005000:8k_2_02:69]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-21-005000:8k_2_02:70]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquired inventory adjustments, acquisition and integration costs, amortization of acquired intangibles, inventory valuation adjustments, and restructuring charges.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-21-005000:8k_2_02:71]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-21-005000:8k_2_02:72]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-21-005000:8k_2_02:73]
Acquired inventory adjustments. Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-21-005000:8k_2_02:74]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-21-005000:8k_2_02:75]
Amortization of acquired intangibles. Amortization of acquired intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-21-005000:8k_2_02:76]
Inventory valuation adjustments. Adjustments relating to the mark down of inventory due to duplication of products lines with acquisition of Aerohive net of recoveries on the sale of inventory marked down in previous quarters.

[0001564590-21-005000:8k_2_02:77]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-21-005000:8k_2_02:78]
Income Taxes. Beginning with our first quarter of fiscal 2021, we are changing how we calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.   Previously, the non-GAAP tax provision consisted of current and deferred income tax expense on a GAAP basis as if our carryforward net operating losses were sufficient to offset our non-GAAP adjustments.   Beginning with our first quarter of fiscal 2021, we have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which consequently, enables our use of research and development tax credits which were previously not utilizable.  The non-GAAP tax provision will now consist of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.  We have adjusted the fiscal 2020 non-GAAP tax provision to reflect the 2020 non-GAAP operating results to be comparable with fiscal 2021 results.  As a result of this change, non-GAAP net income for the second quarter of fiscal 2020 changed from $0.13 per diluted share as previously reported to $0.11 per diluted share.

[0001564590-21-005000:8k_2_02:79]
This change will not affect our non-GAAP income before income taxes, actual cash tax payments or cash flows, but will result in a higher or lower non-GAAP provision for income taxes depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of June 30, 2020, we had U.S. federal net operating loss carryforwards of $310 million and state net operating loss carryforwards of $181 million.  We do not expect to pay substantial taxes on a GAAP basis in the U.S. for the foreseeable future due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Irish operating company which has fully utilized available net operating loss carryforwards as of the second quarter of fiscal 2021.  We also believe our long-term effective GAAP tax rate will be lower than the U.S. statutory rate based upon our established tax structure.

[0001564590-21-005000:8k_2_02:80]
EXTREME NETWORKS, INC.

[0001564590-21-005000:8k_2_02:81]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-005000:8k_2_02:82]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-21-005000:8k_2_02:83]
(In thousands, except percentages and per share amounts)

[0001564590-21-005000:8k_2_02:84]
(Unaudited)

[0001564590-21-005000:8k_2_02:85]
| Revenues | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Revenues - GAAP | $ | 242,128 |  |  | $ | 267,472 |  |  | $ | 477,930 |  |  | $ | 522,978 |  |

[0001564590-21-005000:8k_2_02:86]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Gross profit - GAAP | $ | 140,192 |  |  | $ | 148,671 |  |  | $ | 275,210 |  |  | $ | 285,914 |  |
| Gross margin - GAAP percentage |  | 57.9 | % |  |  | 55.6 | % |  |  | 57.6 | % |  |  | 54.7 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 753 |  |  |  | 907 |  |  |  | 1,383 |  |  |  | 1,504 |  |
| Acquired inventory adjustments |  | — |  |  |  | 3,434 |  |  |  | — |  |  |  | 7,303 |  |
| Acquisition and integration costs |  | — |  |  |  | 1,734 |  |  |  | 10 |  |  |  | 1,884 |  |
| Amortization of intangibles |  | 6,633 |  |  |  | 6,867 |  |  |  | 13,266 |  |  |  | 13,259 |  |
| Inventory valuation adjustments |  | — |  |  |  | (1,169 | ) |  |  | — |  |  |  | 3,677 |  |
| Total adjustments to GAAP gross profit | $ | 7,386 |  |  | $ | 11,773 |  |  | $ | 14,659 |  |  | $ | 27,627 |  |
| Gross profit - non-GAAP | $ | 147,578 |  |  | $ | 160,444 |  |  | $ | 289,869 |  |  | $ | 313,541 |  |
| Gross margin - non-GAAP percentage |  | 61.0 | % |  |  | 60.0 | % |  |  | 60.7 | % |  |  | 60.0 | % |

[0001564590-21-005000:8k_2_02:87]
| Non-GAAP Operating Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| GAAP operating income (loss) | $ | 5,713 |  |  | $ | (15,236 | ) |  | $ | 5,653 |  |  | $ | (47,440 | ) |
| GAAP operating income (loss) percentage |  | 2.4 | % |  |  | (5.7 | )% |  |  | 1.2 | % |  |  | (9.1 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 753 |  |  |  | 907 |  |  |  | 1,383 |  |  |  | 1,504 |  |
| Share-based compensation expense, R&D |  | 2,694 |  |  |  | 3,260 |  |  |  | 4,966 |  |  |  | 5,695 |  |
| Share-based compensation expense, S&M |  | 3,239 |  |  |  | 3,511 |  |  |  | 5,886 |  |  |  | 7,230 |  |
| Share-based compensation expense, G&A |  | 3,409 |  |  |  | 2,801 |  |  |  | 6,162 |  |  |  | 4,884 |  |
| Inventory valuation adjustments |  | — |  |  |  | (1,169 | ) |  |  | — |  |  |  | 3,677 |  |
| Acquisition and integration costs |  | — |  |  |  | 10,728 |  |  |  | 1,985 |  |  |  | 26,803 |  |
| Restructuring charges, net of reversals |  | 695 |  |  |  | 6,622 |  |  |  | 1,696 |  |  |  | 12,759 |  |
| Acquired inventory adjustments |  | — |  |  |  | 3,434 |  |  |  | — |  |  |  | 7,303 |  |
| Amortization of intangibles |  | 8,139 |  |  |  | 9,244 |  |  |  | 16,564 |  |  |  | 17,566 |  |
| Total adjustments to GAAP operating income (loss) | $ | 18,929 |  |  | $ | 39,338 |  |  | $ | 38,642 |  |  | $ | 87,421 |  |
| Non-GAAP operating income | $ | 24,642 |  |  | $ | 24,102 |  |  | $ | 44,295 |  |  | $ | 39,981 |  |
| Non-GAAP operating income percentage |  | 10.2 | % |  |  | 9.0 | % |  |  | 9.3 | % |  |  | 7.6 | % |

[0001564590-21-005000:8k_2_02:88]
| Non-GAAP Net Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| GAAP net loss | $ | (3,050 | ) |  | $ | (23,538 | ) |  | $ | (11,862 | ) |  | $ | (61,276 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 10,095 |  |  |  | 10,479 |  |  |  | 18,397 |  |  |  | 19,313 |  |
| Inventory valuation adjustments |  | — |  |  |  | (1,169 | ) |  |  | — |  |  |  | 3,677 |  |
| Acquisition and integration costs |  | — |  |  |  | 10,728 |  |  |  | 1,985 |  |  |  | 26,803 |  |
| Restructuring charge, net of reversal |  | 695 |  |  |  | 6,622 |  |  |  | 1,696 |  |  |  | 12,759 |  |
| Acquired inventory adjustments |  | — |  |  |  | 3,434 |  |  |  | — |  |  |  | 7,303 |  |
| Amortization of intangibles |  | 8,139 |  |  |  | 9,244 |  |  |  | 16,564 |  |  |  | 17,566 |  |
| Tax effect of non-GAAP adjustments |  | 107 |  |  |  | (2,669 | ) |  |  | 165 |  |  |  | (4,104 | ) |
| Total adjustments to GAAP net loss | $ | 19,036 |  |  | $ | 36,669 |  |  | $ | 38,807 |  |  | $ | 83,317 |  |
| Non-GAAP net income | $ | 15,986 |  |  | $ | 13,131 |  |  | $ | 26,945 |  |  | $ | 22,041 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.13 |  |  | $ | 0.11 |  |  | $ | 0.22 |  |  | $ | 0.18 |  |
| Shares used in net income per share-diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation - basic |  | 123,264 |  |  |  | 119,555 |  |  |  | 122,485 |  |  |  | 119,891 |  |
| Potentially dilutive equity awards |  | 2,463 |  |  |  | 3,632 |  |  |  | 1,681 |  |  |  | 3,555 |  |
| Non-GAAP diluted shares used in per share calculation |  | 125,727 |  |  |  | 123,187 |  |  |  | 124,166 |  |  |  | 123,446 |  |
