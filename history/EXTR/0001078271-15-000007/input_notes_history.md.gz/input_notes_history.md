# EXTR note change history — 0001078271-14-000064 → 0001078271-15-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-01-30):
[0001078271-15-000007:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2014, the Company had non-cancelable commitments to purchase $102.4 million of such inventory.
  (was, 2014-10-29, similarity 0.983):
[0001078271-14-000064:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2014, the Company had non-cancelable commitments to purchase approximately $90.7 million of such inventory.

- changed (2015-01-30):
[0001078271-15-000007:note_history:2]
The Company is a member of RPX Corporation’s (“RPX”) network of clients, who procure patent risk management services from RPX.  On September 30, 2014, RPX signed an agreement on behalf of its members (including Extreme) with Selene to resolve the litigation cases against its members by Selene and to obtain a license for all RPX members to the 444 Patent and its foreign counterparts.  As a result, a Release Agreement was finalized on November 19, 2014 and the litigation was dismissed in US District court for the District of Delaware on November 20, 2014.
  (was, 2014-10-29, similarity 0.7664):
[0001078271-14-000064:note_history:2]
The Company is a member of RPX Corporation’s (“RPX”) network of clients, who procure patent risk management services from RPX.  On September 30, 2014, RPX signed an agreement on behalf of its members (including Extreme) with Selene to resolve the litigation cases against its members by Selene and to obtain a license for all RPX members to the 444 Patent and its foreign counterparts.  As a result, the Company expects this case to be dismissed shortly without any further liability to Company.

- added (2015-01-30):
[0001078271-15-000007:note_history:3]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014. COT then filed a motion to dismiss COT as a defendant in this lawsuit and the court granted COT’s motion. Although this litigation is in the discovery stage, Plaintiffs have filed a motion for Summary Judgment/Adjudication, which will be heard on February 26, 2015, on the issue of whether the work performed by the defendants constitutes “construction” under the Act.  The Company will vigorously oppose this motion. This litigation is in the early stages of discovery.

- changed (2015-01-30):
[0001078271-15-000007:note_history:4]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014 by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US$1.5 million), plus interest and penalties (that are currently estimated to be approximately US$9 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution; however, the court ruled that a cash deposit of the full amount at issue is to be made by Enterasys.  Enterasys then prepared a motion aimed at the partial reconsideration of such decision concerning the need for a deposit, which was denied on October 10, 2014.  The Company appealed this ruling on October 30, 2014 and is currently awaiting a decision from the Court of Appeals.
  (was, 2014-10-29, similarity 0.6917):
[0001078271-14-000064:note_history:4]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014 by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US$1.5 million), plus interest and penalties (that are currently estimated to be approximately US$9 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  In the first week of October, the preliminary injunction was granted with regard to the stay of execution; however, the court ruled that a cash deposit of the full amount at issue is to be made by Enterasys.  Enterasys then prepared a motion aimed at the partial reconsideration of such decision concerning the need for a deposit, which was denied on October 10, 2014.  The Company is currently considering an appeal to the Court of Appeals against such denial.

- changed (2015-01-30):
[0001078271-15-000007:note_history:5]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from $0 million to $9 million, of which the Company believes $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.
  (was, 2014-10-29, similarity 0.9521):
[0001078271-14-000064:note_history:5]
Given the preliminary nature of the lawsuit and the uncertainty of the legal environment in Brazil, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position, cash flows or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from $0 million to $9 million, of which the Company believes $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.

- removed (2015-01-30):
[0001078271-14-000064:note_history:6]
Net Navigation Systems, LLC.

- removed (2015-01-30):
[0001078271-14-000064:note_history:7]
On April 23, 2014, Net Navigation Systems, LLC (“Net Navigation”) filed a complaint against Extreme Networks, Inc. in the Eastern District of Texas.  In the Complaint, the plaintiff asserts infringement of U.S. Patent No. 6,625,122 (“the ’122 Patent”), entitled “Selection of Data for Network Transmission,” which issued on September 23, 2003.  Although somewhat vague, the Complaint identifies the following products as accused of infringing the ‘122 Patent:  “Networking products capable of providing priority to different data flows based on bandwidth.”  The Complaint also states that Extreme has infringed by “making, selling, and causing its customers to use networking products capable of providing priority to different data flows based on bandwidth, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.”  The Complaint also asserts infringement of U.S. Patent No. 6,434,145 (“the ’145 Patent”), entitled “Processing of Network Data by Parallel Processing Channels,” which issued on August 13, 2002.  Again, although somewhat vague, the Complaint states that Extreme has infringed by “making, using, importing, selling, and/or offering for sale in the United States, including within this judicial district, networking products that use parallel processing channels, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.” Net Navigation, a non-practicing entity, seeks injunctive relief as well as monetary damages, cost, expenses and attorney fees, although the complaint seeks no quantified amount.  The Company denies the claims and is preparing to vigorously defend our technology.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

- removed (2015-01-30):
[0001078271-14-000064:note_history:8]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014 and is considering filing a cross-claim against COT.  This litigation is in the early stages of discovery.

- removed (2015-01-30):
[0001078271-14-000064:note_history:9]
Indemnification Obligations

- removed (2015-01-30):
[0001078271-14-000064:note_history:10]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of September 30, 2014, the Company had no outstanding indemnification claims.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-01-30):
[0001078271-15-000007:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2014. The results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.
  (was, 2014-10-29, similarity 0.7788):
[0001078271-14-000064:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2014. The results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-01-30):
[0001078271-15-000007:note_history:12]
|  |  | December 31, 2014 |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |  |  |
| Term Loan |  | $ | 8,125 |  |  | $ | 5,688 |  |
| Revolving Facility |  | — |  |  | 24,000 |  |
| Current portion of long-term debt |  | $ | 8,125 |  |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |  |  |
| Term Loan |  | $ | 52,000 |  |  | $ | 56,875 |  |
| Revolving Facility |  | 29,000 |  |  | 35,000 |  |
| Total long-term debt, less current portion |  | 81,000 |  |  | 91,875 |  |
| Total debt |  | $ | 89,125 |  |  | $ | 121,563 |  |

- removed (2015-01-30):
[0001078271-14-000064:note_history:13]
|  |  | September 30, 2014 |
| Current portion of long-term debt: |  |  |
| Term Loan |  | 6,500 |  |
| Revolving Facility |  | 24,000 |  |
| Current portion of long-term debt |  | 30,500 |  |
| Long-term debt, less current portion: |  |  |
| Term Loan |  | 55,250 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt, less current portion |  | 90,250 |  |
| Total debt |  | 120,750 |  |
