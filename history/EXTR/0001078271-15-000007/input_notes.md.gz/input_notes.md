# EXTR notes — 0001078271-15-000007


## extr:DeferredRevenueRollForwardTableTextBlock

[0001078271-15-000007:notes:1]
The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-15-000007:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Balance beginning of period | $ | 87,012 |  |  | $ | 37,091 |  |  | $ | 89,657 |  |  | $ | 38,003 |  |
| Assumed from acquisition | — |  |  | 35,879 |  |  | — |  |  | 35,879 |  |
| New support arrangements | 35,517 |  |  | 33,146 |  |  | 64,056 |  |  | 46,489 |  |
| Recognition of support revenue | (31,156 | ) |  | (24,631 | ) |  | (62,340 | ) |  | (38,886 | ) |
| Balance end of period | 91,373 |  |  | 81,485 |  |  | 91,373 |  |  | 81,485 |  |
| Less: current portion | 67,433 |  |  | 63,150 |  |  | 67,433 |  |  | 63,150 |  |
| Non-current deferred revenue | $ | 23,940 |  |  | $ | 18,335 |  |  | $ | 23,940 |  |  | $ | 18,335 |  |


## extr:ScheduleOfDeferredDistributorsRevenueTableTextBlock

[0001078271-15-000007:notes:3]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors (in thousands):

[0001078271-15-000007:notes:4]
|  | December 31, 2014 |  | June 30, 2014 |
| Deferred distributors revenue | $ | 40,901 |  |  | $ | 40,715 |  |
| Deferred cost of sales to distributors | (9,729 | ) |  | (8,723 | ) |
| Deferred distributors revenue, net of cost of sales to distributors | $ | 31,172 |  |  | $ | 31,992 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-15-000007:notes:5]
[same as prior period, unchanged from 0001078271-14-000064:notes:1]

[0001078271-15-000007:notes:6]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| December 31, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 951 |  |  | $ | 951 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 20,317 |  |  | 20,321 |  |  | 4 |  |  | — |  |
|  | $ | 21,268 |  |  | $ | 21,272 |  |  | $ | 4 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 951 |  |  | $ | 951 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 20,317 |  |  | 20,321 |  |  | 4 |  |  | — |  |
|  | $ | 21,268 |  |  | $ | 21,272 |  |  | $ | 4 |  |  | $ | — |  |
| June 30, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |

[0001078271-15-000007:notes:7]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at December 31, 2014, by contractual maturity, were as follows (in thousands):

[0001078271-15-000007:notes:8]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 20,317 |  |  | $ | 20,321 |  |
| Total investments in available for sale debt securities | $ | 20,317 |  |  | $ | 20,321 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001078271-15-000007:notes:9]
[same as prior period, unchanged from 0001078271-14-000064:notes:5]

[0001078271-15-000007:notes:10]
[same as prior period, unchanged from 0001078271-14-000064:notes:6]

[0001078271-15-000007:notes:11]
[same as prior period, unchanged from 0001078271-14-000064:notes:7]

[0001078271-15-000007:notes:12]
The following table summarizes the final allocation as of September 30, 2014 of the tangible and identifiable intangible assets acquired and liabilities assumed as compared to the allocation as of December 31, 2013, the quarter in which the transaction was completed (in thousands):

[0001078271-15-000007:notes:13]
[same as prior period, unchanged from 0001078271-14-000064:notes:9]

[0001078271-15-000007:notes:14]
| a. | The Company finalized the working capital adjustment during the nine months ended September 30, 2014, which led to a decrease of $2.4 million in receivables and a corresponding increase in cash. As a result of this adjustment, the total cash acquired from the acquisition also increased by the same amount. The net effect of this adjustment is an increase in goodwill of $2.4 million. |

[0001078271-15-000007:notes:15]
| b. | The Company obtained new information regarding the existence of prepaids as of the acquisition date which led to a decrease in the fair value of current assets of $1.5 million, and a corresponding increase in goodwill. The change in the amortization of prepaids due to the change in fair value of current assets was immaterial. |

[0001078271-15-000007:notes:16]
| c. | The Company updated its preliminary estimate of the fair value of property and equipment which led to a decrease of $3.0 million in property and equipment with a corresponding increase in goodwill. The Company also updated the fair values of the asset retirement obligations and the related asset retirement assets which led to an increase in the fair value of property and equipment of $1.2 million and a corresponding increase in current liabilities and other long-term liabilities of $0.2 million and $1.0 million, respectively. The decrease in depreciation expense due to the change in fair value of property and equipment was immaterial. |

[0001078271-15-000007:notes:17]
| d. | During the nine months ended September 30, 2014, there were no changes to the fair value of the identifiable intangible assets acquired. However, the Company revised the estimated useful life of Order backlog from 1.5 years to 1 year. |

[0001078271-15-000007:notes:18]
| e. | The Company obtained new information regarding accruals for litigation and statutory tax assessment as of the acquisition date which led to an increase in the fair value of current liabilities of $5.4 million and a corresponding increase in goodwill. |

[0001078271-15-000007:notes:19]
| f. | The Company obtained new information regarding the existence of accrued liabilities as of the acquisition date which led to a net increase in the fair value of accrued liabilities by $0.5 million with a corresponding increase in goodwill. |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-15-000007:notes:20]
Commitments and Contingencies

[0001078271-15-000007:notes:21]
Purchase Commitments

[0001078271-15-000007:notes:22]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2014, the Company had non-cancelable commitments to purchase $102.4 million of such inventory.

[0001078271-15-000007:notes:23]
Legal Proceedings

[0001078271-15-000007:notes:24]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-15-000007:notes:25]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-15-000007:notes:26]
Intellectual Property Litigation

[0001078271-15-000007:notes:27]
Selene Communication Technologies, LLC.

[0001078271-15-000007:notes:28]
On April 7, 2014, Selene Communication Technologies, LLC (“Selene”), filed a complaint in the US District Court for the District of Delaware against Extreme and Enterasys asserting a cause of action for infringement of United States Patent No. 7,143,444 (the “444 Patent”). Selene has also recently sued a number of other technology companies including Cisco for infringement of the 444 Patent.  Selene, a non-practicing entity, seeks injunctive relief as well as monetary damages, costs, expenses and attorney fees, although the complaint seeks no quantified amount.

[0001078271-15-000007:notes:29]
The Company is a member of RPX Corporation’s (“RPX”) network of clients, who procure patent risk management services from RPX.  On September 30, 2014, RPX signed an agreement on behalf of its members (including Extreme) with Selene to resolve the litigation cases against its members by Selene and to obtain a license for all RPX members to the 444 Patent and its foreign counterparts.  As a result, a Release Agreement was finalized on November 19, 2014 and the litigation was dismissed in US District court for the District of Delaware on November 20, 2014.

[0001078271-15-000007:notes:30]
Commonwealth of Kentucky

[0001078271-15-000007:notes:31]
On or about February 3, 2014, a class action lawsuit was filed in the Commonwealth of Kentucky against Enterasys Networks, Inc. and two other defendants.  The complaint alleges that Enterasys and its subcontractor, TJL Information Technologies, Inc., d.b.a. Unbridled Information Technologies (“Subcontractor”), violated Kentucky’s wage and hour laws and failed to pay the prevailing wage in violation of the Kentucky State Prevailing Wage Act (the “Act”) on various public works projects for a number of Kentucky government agencies since January 2010.  Plaintiffs also allege common law actions for quantum merit and unjust enrichment and they seek monetary damages, costs, expenses and attorney fees, although there was no quantified amount identified.  One of the defendants, Integrated Facility Systems, LLC (“IFS”), has also filed a cross-claim against Enterasys.  The Company denies the claims and filed answers to both the complaint and cross-claim on April 16, 2014.  In addition, the Company filed a cross-claim for indemnity against IFS.

[0001078271-15-000007:notes:32]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014. COT then filed a motion to dismiss COT as a defendant in this lawsuit and the court granted COT’s motion. Although this litigation is in the discovery stage, Plaintiffs have filed a motion for Summary Judgment/Adjudication, which will be heard on February 26, 2015, on the issue of whether the work performed by the defendants constitutes “construction” under the Act.  The Company will vigorously oppose this motion. This litigation is in the early stages of discovery.

[0001078271-15-000007:notes:33]
ICMS Tax Assessment Matters

[0001078271-15-000007:notes:34]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014 by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US$1.5 million), plus interest and penalties (that are currently estimated to be approximately US$9 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution; however, the court ruled that a cash deposit of the full amount at issue is to be made by Enterasys.  Enterasys then prepared a motion aimed at the partial reconsideration of such decision concerning the need for a deposit, which was denied on October 10, 2014.  The Company appealed this ruling on October 30, 2014 and is currently awaiting a decision from the Court of Appeals.

[0001078271-15-000007:notes:35]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from $0 million to $9 million, of which the Company believes $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-15-000007:notes:36]
The following table summarizes deferred revenue, net (in thousands):

[0001078271-15-000007:notes:37]
|  | December 31, 2014 |  | June 30, 2014 |
| Deferred services | $ | 91,373 |  |  | $ | 89,657 |  |
| Deferred product and other revenue | 6,920 |  |  | 8,020 |  |
| Total deferred revenue | 98,293 |  |  | 97,677 |  |
| Less: current portion | 74,353 |  |  | 74,735 |  |
| Non-current deferred revenue, net | $ | 23,940 |  |  | $ | 22,942 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-15-000007:notes:38]
[same as prior period, unchanged from 0001078271-14-000064:notes:38]

[0001078271-15-000007:notes:39]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as "Other assets" at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company from time to time enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. At December 31, 2014, these forward foreign currency contracts had a notional principal amount of $2.3 million and an immaterial unrealized loss on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-15-000007:notes:40]
Foreign currency transaction gains and losses from operations was a gain of less than $0.1 million and $1.0 million loss for the three months ended December 31, 2014 and December 31, 2013, respectively. Foreign currency transaction gains and losses from operations were a $0.3 million loss and $1.1 million loss for the six months ended December 31, 2014 and December 31, 2013, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-15-000007:notes:41]
[same as prior period, unchanged from 0001078271-14-000064:notes:41]

[0001078271-15-000007:notes:42]
As of December 31, 2014, the Company had 19,315,115 shares available for issuance, of which 12,000,000 shares are available under the 2014 Employee Stock Purchase Plan, which was approved by the shareholders on November 12, 2014, 466,187 shares are available under the 1999 Employee Stock Purchase Plan and 6,848,968 shares are available under the 2013 Stock Plan.

[0001078271-15-000007:notes:43]
[same as prior period, unchanged from 0001078271-14-000064:notes:42]

[0001078271-15-000007:notes:44]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Cost of product revenue | $ | 275 |  |  | $ | 198 |  |  | $ | 558 |  |  | $ | 300 |  |
| Cost of service revenue | 272 |  |  | — |  |  | 563 |  |  | 40 |  |
| Research and development | 1,544 |  |  | 898 |  |  | 3,188 |  |  | 1,141 |  |
| Sales and marketing | 1,566 |  |  | 1,279 |  |  | 3,123 |  |  | 1,850 |  |
| General and administrative | 1,092 |  |  | 1,083 |  |  | 2,131 |  |  | 1,702 |  |
| Total share-based compensation expense | $ | 4,749 |  |  | $ | 3,458 |  |  | $ | 9,563 |  |  | $ | 5,033 |  |

[0001078271-15-000007:notes:45]
During the three and six months ended December 31, 2014 and 2013, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial.

[0001078271-15-000007:notes:46]
[same as prior period, unchanged from 0001078271-14-000064:notes:48]

[0001078271-15-000007:notes:47]
[same as prior period, unchanged from 0001078271-14-000064:notes:49]

[0001078271-15-000007:notes:48]
The following table summarizes stock award activity for the six months ended December 31, 2014:

[0001078271-15-000007:notes:49]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2014 | 6,000 |  |  | $ | 4.98 |  |  |  |
| Granted | 828 |  |  | $ | 3.83 |  |  |  |
| Vested | (1,805 | ) |  | $ | 5.25 |  |  | $ | 6,689 |  |
| Cancelled | (358 | ) |  | $ | 4.28 |  |  |  |
| Non-vested stock outstanding at December 31, 2014 | 4,665 |  |  | $ | 4.72 |  |  |  |

[0001078271-15-000007:notes:50]
The following table summarizes stock option activity under all plans for the six months ended December 31, 2014:

[0001078271-15-000007:notes:51]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2014 | 11,732 |  |  | $ | 4.26 |  |  | 5.13 |  |  | 6,846 |  |
| Granted | 1,063 |  |  | $ | 4.21 |  |  |  |  |  |
| Exercised | (381 | ) |  | $ | 3.29 |  |  |  |  | $ | 329 |  |
| Cancelled | (1,074 | ) |  | $ | 5.14 |  |  |  |  |  |
| Options outstanding at December 31, 2014 | 11,340 |  |  | $ | 4.20 |  |  | 4.96 |  |  | $ | 1,618 |  |
| Exercisable at December 31, 2014 | 5,373 |  |  | $ | 3.86 |  |  | 3.99 |  |  | $ | 1,225 |  |
| Vested and expected to vest at December 31, 2014 | 10,396 |  |  | $ | 4.17 |  |  | 4.87 |  |  | $ | 1,573 |  |

[0001078271-15-000007:notes:52]
The weighted-average grant-date per share fair value of options granted during the three months ended December 31, 2014 and 2013 was $1.66 and $2.35, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended December 31, 2014 and 2013 was $1.17 and $1.35, respectively.

[0001078271-15-000007:notes:53]
The weighted-average grant-date per share fair value of options granted during the six months ended December 31, 2014 and 2013 was $1.96 and $2.33, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s ESPP during the six months ended December 31, 2014 and 2013 was $1.33 and $1.21, respectively.

[0001078271-15-000007:notes:54]
[same as prior period, unchanged from 0001078271-14-000064:notes:54]

[0001078271-15-000007:notes:55]
[same as prior period, unchanged from 0001078271-14-000064:notes:53]

[0001078271-15-000007:notes:56]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Expected life | 4.8 years |  |  | 4.0 years |  |  | 0.25 years |  |  | 0.25 years |  |  | 4.7 years |  |  | 4.0 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.67 | % |  | 1.14 | % |  | 0.03 | % |  | 0.11 | % |  | 1.61 | % |  | 1.20 | % |  | 0.02 | % |  | 0.10 | % |
| Volatility | 54 | % |  | 55 | % |  | 63 | % |  | 47 | % |  | 54 | % |  | 56 | % |  | 57 | % |  | 41 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-15-000007:notes:57]
Dilutive earnings per share is calculated by dividing net earnings by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0001078271-15-000007:notes:58]
Net Loss Per Share

[0001078271-15-000007:notes:59]
Basic earnings per share is calculated by dividing net earnings by the weighted average number of common shares outstanding during the period. Dilutive earnings per share is calculated by dividing net earnings by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.

[0001078271-15-000007:notes:60]
The following table presents the calculation of basic and diluted net loss per share (in thousands, except per share data):

[0001078271-15-000007:notes:61]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Net loss | $ | (13,105 | ) |  | $ | (15,986 | ) |  | $ | (32,435 | ) |  | $ | (16,022 | ) |
| Weighted-average shares used in per share calculation – basic and diluted | 98,677 |  |  | 95,216 |  |  | 97,996 |  |  | 94,639 |  |
| Net loss per share – basic and diluted | $ | (0.13 | ) |  | $ | (0.17 | ) |  | $ | (0.33 | ) |  | $ | (0.17 | ) |

[0001078271-15-000007:notes:62]
The following securities were excluded from the computation of diluted net loss per share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001078271-15-000007:notes:63]
|  |  | December 31, 2014 |  | December 31, 2013 |
| Options to purchase common stock |  | 9,203 |  |  | 5,833 |  |
| Restricted stock units |  | 1,369 |  |  | 1,101 |  |
| Employee Stock Purchase Plan shares |  | 563 |  |  | 154 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-15-000007:notes:64]
[same as prior period, unchanged from 0001078271-14-000064:notes:62]

[0001078271-15-000007:notes:65]
[same as prior period, unchanged from 0001078271-14-000064:notes:63]

[0001078271-15-000007:notes:66]
| December 31, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 951 |  |  | $ | — |  |  | $ | — |  |  | $ | 951 |  |
| Corporate notes/bonds | — |  |  | 20,321 |  |  | — |  |  | 20,321 |  |
| Foreign currency forward contracts | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 951 |  |  | $ | 20,322 |  |  | $ | — |  |  | $ | 21,273 |  |

[0001078271-15-000007:notes:67]
[same as prior period, unchanged from 0001078271-14-000064:notes:65]

[0001078271-15-000007:notes:68]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three and six months ended December 31, 2014. There were no liabilities as of December 31, 2014 that were being measured using fair value on a recurring basis.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-15-000007:notes:69]
[same as prior period, unchanged from 0001078271-14-000064:notes:67]

[0001078271-15-000007:notes:70]
For the three and six months ended December 31, 2014, the Company recorded an income tax provision of $1.3 million and $2.3 million, respectively. For the three and six months ended December 31, 2013, the Company recorded an income tax provision of $0.9 million and $1.4 million, respectively.

[0001078271-15-000007:notes:71]
The income tax provisions for the three and six months ended December 31, 2014 and 2013 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and six months ended December 31, 2014 and 2013, and therefore may not reflect the annual effective tax rate.

[0001078271-15-000007:notes:72]
[same as prior period, unchanged from 0001078271-14-000064:notes:70]

[0001078271-15-000007:notes:73]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries.  The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  During the three and six months ended December 31, 2014, the Company deducted $1.1 million and $2.2 million, respectively of tax amortization expense related to capitalized goodwill.  As of December 31, 2014, the Company recorded a deferred tax liability of $1.9 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets.

[0001078271-15-000007:notes:74]
The Company had $11.5 million of unrecognized tax benefits as of December 31, 2014. The future impact of the unrecognized tax benefit of $11.5 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001078271-15-000007:notes:75]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Condensed Consolidated Statements of Operations and were immaterial for the three and six months ended December 31, 2014 and 2013. Accrued interest and penalties were $42,000 as of December 31, 2013 and have been fully reversed as of December 31, 2014.

[0001078271-15-000007:notes:76]
[same as prior period, unchanged from 0001078271-14-000064:notes:74]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-15-000007:notes:77]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with original maturities of greater than three months, but less than one year at the balance sheet date are classified as Short-term investments.

[0001078271-15-000007:notes:78]
[same as prior period, unchanged from 0001078271-14-000064:notes:76]

[0001078271-15-000007:notes:79]
[same as prior period, unchanged from 0001078271-14-000064:notes:77]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-15-000007:notes:80]
Recently Issued Accounting Pronouncements

[0001078271-15-000007:notes:81]
In May 2014, the FASB, jointly with the International Accounting Standards Board, issued Accounting Standard Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers ("ASU 2014-09"). This ASU's core principle is that a reporting entity will recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In applying this new guidance to contracts within its scope, an entity will: (1) identify the contract(s) with a customer, (2) identify the performance obligation in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, this new guidance will require significantly expanded disclosures about revenue recognition. ASU 2014-09 is effective for annual reporting periods (including interim reporting periods within those annual periods) beginning after December 15, 2016. Early application is not permitted. Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this ASU. The Company is currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-15-000007:notes:82]
[same as prior period, unchanged from 0001078271-14-000064:notes:80]

[0001078271-15-000007:notes:83]
[same as prior period, unchanged from 0001078271-14-000064:notes:81]

[0001078271-15-000007:notes:84]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2014. The results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-15-000007:notes:85]
[same as prior period, unchanged from 0001078271-14-000064:notes:87]

[0001078271-15-000007:notes:86]
|  | December 31, 2014 |  | June 30, 2014 |
| Cash | $ | 88,021 |  |  | $ | 72,623 |  |
| Cash equivalents | $ | 951 |  |  | $ | 567 |  |
| Short-term investments | 20,321 |  |  | 32,692 |  |
| Total available-for-sale | $ | 21,272 |  |  | $ | 33,259 |  |
| Total cash, cash equivalents and available for sale securities | $ | 109,293 |  |  | $ | 105,882 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-15-000007:notes:87]
The Company's debt is comprised of the following:

[0001078271-15-000007:notes:88]
|  |  | December 31, 2014 |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |  |  |
| Term Loan |  | $ | 8,125 |  |  | $ | 5,688 |  |
| Revolving Facility |  | — |  |  | 24,000 |  |
| Current portion of long-term debt |  | $ | 8,125 |  |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |  |  |
| Term Loan |  | $ | 52,000 |  |  | $ | 56,875 |  |
| Revolving Facility |  | 29,000 |  |  | 35,000 |  |
| Total long-term debt, less current portion |  | 81,000 |  |  | 91,875 |  |
| Total debt |  | $ | 89,125 |  |  | $ | 121,563 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-15-000007:notes:89]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2014 and 2013:

[0001078271-15-000007:notes:90]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Balance beginning of period | $ | 7,889 |  |  | $ | 3,440 |  |  | $ | 7,551 |  |  | $ | 3,296 |  |
| Assumed from acquisition | — |  |  | 3,732 |  |  | — |  |  | 3,732 |  |
| New warranties issued | 1,683 |  |  | 1,654 |  |  | 3,948 |  |  | 2,958 |  |
| Warranty expenditures | (1,727 | ) |  | (1,347 | ) |  | (3,654 | ) |  | (2,507 | ) |
| Balance end of period | $ | 7,845 |  |  | $ | 7,479 |  |  | $ | 7,845 |  |  | $ | 7,479 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-15-000007:notes:91]
[same as prior period, unchanged from 0001078271-14-000064:notes:93]

[0001078271-15-000007:notes:92]
|  | Three Months Ended |  | Six Months Ended |
| Net Revenues: | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 58,160 |  |  | $ | 56,292 |  |  | $ | 116,648 |  |  | $ | 81,681 |  |
| Other | 12,576 |  |  | 13,913 |  |  | 19,917 |  |  | 20,214 |  |
| Total Americas | 70,736 |  |  | 70,205 |  |  | 136,565 |  |  | 101,895 |  |
| EMEA | 62,574 |  |  | 61,292 |  |  | 116,509 |  |  | 92,133 |  |
| APAC | 13,898 |  |  | 15,086 |  |  | 30,408 |  |  | 28,470 |  |
| Total net revenues | $ | 147,208 |  |  | $ | 146,583 |  |  | $ | 283,482 |  |  | $ | 222,498 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001078271-15-000007:notes:93]
| Long Lived Assets: |  | December 31, 2014 |  | June 30, 2014 |
| Americas |  | $ | 93,778 |  |  | $ | 104,387 |  |
| EMEA |  | 37,021 |  |  | 45,191 |  |
| APAC |  | 3,552 |  |  | 3,121 |  |
| Total long lived assets |  | $ | 134,351 |  |  | $ | 152,699 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-15-000007:notes:94]
[same as prior period, unchanged from 0001078271-14-000064:notes:95]

[0001078271-15-000007:notes:95]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Techdata |  | 15% |  | * |  | 15% |  | * |
| Westcon Group Inc. |  | 13% |  | 10% |  | 13% |  | 12% |
| * Less than 10% of net revenue |  |  |  |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-15-000007:notes:96]
[same as prior period, unchanged from 0001078271-14-000064:notes:97]

[0001078271-15-000007:notes:97]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of its customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-15-000007:notes:98]
[same as prior period, unchanged from 0001078271-14-000064:notes:101]

[0001078271-15-000007:notes:99]
[same as prior period, unchanged from 0001078271-14-000064:notes:102]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-15-000007:notes:100]
[same as prior period, unchanged from 0001078271-14-000064:notes:103]

[0001078271-15-000007:notes:101]
Cash, Cash Equivalents, Short-Term Investments

[0001078271-15-000007:notes:102]
[same as prior period, unchanged from 0001078271-14-000064:notes:105]

[0001078271-15-000007:notes:103]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income (loss) into earnings using the specific identification method.  The Company recorded an other-than temporary impairment loss of $148,000 during the six months ended December 31, 2013.

[0001078271-15-000007:notes:104]
[same as prior period, unchanged from 0001078271-14-000064:notes:107]

[0001078271-15-000007:notes:105]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net (in thousands):

[0001078271-15-000007:notes:106]
[same as prior period, unchanged from 0001078271-14-000064:notes:109]

[0001078271-15-000007:notes:107]
[same as prior period, unchanged from 0001078271-14-000064:notes:111]

[0001078271-15-000007:notes:108]
The Company records revenue from its distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to its distributors in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its condensed consolidated balance sheet. The amount shown as “Deferred distributors revenue, net of cost of sales to distributors” represents the deferred gross profit on sales to distributors based on contractual pricing.

[0001078271-15-000007:notes:109]
[same as prior period, unchanged from 0001078271-14-000064:notes:115]

[0001078271-15-000007:notes:110]
On October 31, 2013, the Company entered into a Credit Agreement (the “Credit Agreement”) which provides for a five-year revolving credit facility for up to $60 million (the “Revolving Facility”) and a $65 million five-year term loan (the “Term Loan”) and together with the Revolving Facility (the “Senior Secured Credit Facilities”).  During the three months ended December 31, 2014, the Company amended the Credit Agreement and among other things modified certain financial covenants governing quick and leverage ratios.  The proceeds from the Term Loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The Company also drew $35 million of the Revolving Facility to pay a portion of the purchase price of Enterasys and subsequently drew $24 million in the first quarter of fiscal 2015 to fund working capital requirements.  Such additional draw of $24 million and an additional $6 million of the Revolving Facility were repaid during second fiscal quarter of 2015.

[0001078271-15-000007:notes:111]
The Credit Agreement contains, among others, certain financial covenants that require the Company to maintain defined minimum financial ratios which may limit the Company’s availability to borrowings under the Revolving Facility. As of December 31, 2014, the Company had $17.4 million of availability under the Revolving Facility.

[0001078271-15-000007:notes:112]
The Company had $1.0 million of outstanding letters of credit as of December 31, 2014.

[0001078271-15-000007:notes:113]
[same as prior period, unchanged from 0001078271-14-000064:notes:117]

[0001078271-15-000007:notes:114]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product.  The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2014 and 2013:

[0001078271-15-000007:notes:115]
The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The maximum potential amount of future payments the Company could be required to make under these indemnification agreements is not estimable.   We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001078271-15-000007:notes:116]
[same as prior period, unchanged from 0001078271-14-000064:notes:120]

[0001078271-15-000007:notes:117]
[same as prior period, unchanged from 0001078271-14-000064:notes:121]
