# EXTR 8-K — 0001078271-15-000004 filed 2015-01-28

## item codes, every 8-K on or before 2015-01-30

- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2015-01-30

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-15-000004:8k_2_02:1]
EX-99.1
2
extr8kq215ex991.htm
EARNINGS PRESS RELEASE

[0001078271-15-000004:8k_2_02:2]
EXTR 8K Q2'15 EX 99.1

[0001078271-15-000004:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-15-000004:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3456 |  | 408/579-3483 |
| fyoshino@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-15-000004:8k_2_02:5]
Extreme Networks Reports Second Quarter Fiscal Year 2015 Financial Results

[0001078271-15-000004:8k_2_02:6]
GAAP Revenue of $147.2 million

[0001078271-15-000004:8k_2_02:7]
GAAP EPS Loss of $0.13

[0001078271-15-000004:8k_2_02:8]
Non-GAAP Revenue of $148.0 million

[0001078271-15-000004:8k_2_02:9]
Non-GAAP EPS of $0.05

[0001078271-15-000004:8k_2_02:10]
SAN JOSE, Calif., Jan. 28, 2015 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for the second quarter of fiscal year 2015, ended December 31, 2014.  GAAP revenue was $147.2 million and non-GAAP revenue was $148.0 million.  GAAP net loss for the second fiscal quarter was $13.1 million, or $0.13 per share, and non-GAAP net income was $4.7 million, or $0.05 per diluted share.  This is the fourth quarter that Extreme Networks is reporting full quarter results that include the Enterasys acquisition.

[0001078271-15-000004:8k_2_02:11]
“We made solid progress towards improving our results in the second fiscal quarter.  Non-GAAP revenues were up 8% from the prior quarter at $148 million.  Non-GAAP operating income was up over five-fold from the prior quarter reaching $6.7 million and EPS was $0.05 compared to a penny loss in Q1.  At the same time we strengthened our balance sheet, reducing debt by $32 million while maintaining cash at $109 million, slightly above the prior quarter,” said Chuck Berger, president and CEO of Extreme Networks.  “We added several large new customers during the quarter including the Green Bay Packers, Baltimore Ravens, University of Maryland and Penn State University.

[0001078271-15-000004:8k_2_02:12]
“We also continued to strengthen our sales leadership adding Stephen Patak and Bob Gault as heads of U.S. and Canada sales and worldwide channels respectively,” Berger continued.  “Together they bring more than 30 years of experience in the networking industry.  In addition, David Hume joined as CIO and Frank Yoshino was appointed vice president, treasury and IR. Raj Khanna joined our Board of Directors in December. Raj brings extensive financial and internal audit experience over a 30 year career at Xerox, Sun and Qualcomm.”

[0001078271-15-000004:8k_2_02:13]
Key Accomplishments in Fiscal Q2 FY 2015:

[0001078271-15-000004:8k_2_02:14]
| • | Product innovation continued with the introduction of the Summit® 460-G2 fixed switch, the most powerful edge switch in our portfolio. We also broadened our IdentiFi Wi-Fi product offering with the AP3805, a full featured enterprise-class 802.11ac access point at an entry-level price point. |

[0001078271-15-000004:8k_2_02:15]
| • | Lenovo selected Extreme Networks to provide networking technology for its high performance computing (HPC) solution. |

[0001078271-15-000004:8k_2_02:16]
| • | Continued success with the NFL by adding the Baltimore Ravens and the Green Bay Packers as new customers for our in stadium Wi-Fi solutions. Extreme Networks was also named the first official Wi-Fi Solutions Provider of the NFL. |

[0001078271-15-000004:8k_2_02:17]
| • | We announced a co-marketing and sales agreement with IMG College, part of WME-IMR, who owns the marketing and media rights to over 90 division one universities. The University of |

[0001078271-15-000004:8k_2_02:18]
Maryland selected our IdentiFi Wi-Fi solution for its football and basketball venues, joining Baylor University, an IMG partner university, who went live with Extreme in the prior quarter.

[0001078271-15-000004:8k_2_02:19]
| • | Microsoft, Palo Alto Networks, VMWare, A19 Networks, NetOptics/IXIA and Sanbolic joined the Extreme Technology Solutions Partner (TSP) program joining more than 50 existing members, adding support to our open and standards-based networking and SDN technology. |

[0001078271-15-000004:8k_2_02:20]
| • | Key account wins: |

[0001078271-15-000004:8k_2_02:21]
| • | Green Bay Packers |

[0001078271-15-000004:8k_2_02:22]
| • | Baltimore Ravens |

[0001078271-15-000004:8k_2_02:23]
| • | Penn State University |

[0001078271-15-000004:8k_2_02:24]
| • | Hartford County Public Schools |

[0001078271-15-000004:8k_2_02:25]
| • | Sejong City Office of Education |

[0001078271-15-000004:8k_2_02:26]
| • | Caledonia Community Schools |

[0001078271-15-000004:8k_2_02:27]
| • | Charite Campus Mitte |

[0001078271-15-000004:8k_2_02:28]
| • | Riken Japan |

[0001078271-15-000004:8k_2_02:29]
Fiscal Q2 2015 Financial Metrics:

[0001078271-15-000004:8k_2_02:30]
|  |  | Second Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2015 |  | 2014 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 112.5 |  |  | $ | 119.1 |  |  | $ | (6.6 | ) |  | (6 | )% |
| Service |  | $ | 34.7 |  |  | $ | 27.5 |  |  | $ | 7.2 |  |  | 26 | % |
| Total Net Revenue |  | $ | 147.2 |  |  | $ | 146.6 |  |  | $ | 0.6 |  |  | — | % |
| Gross Margin |  | 51.1 | % |  | 47.6 | % |  | 3.5 | % |  | 7 | % |
| Operating Loss |  | (7.5 | )% |  | (9.4 | )% |  | 1.9 | % |  | (20 | )% |
| Net Loss |  | $ | (13.1 | ) |  | $ | (16.0 | ) |  | $ | 2.9 |  |  | (18 | )% |
| Loss per diluted share |  | $ | (0.13 | ) |  | $ | (0.17 | ) |  | $ | 0.04 |  |  | (24 | )% |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 112.5 |  |  | $ | 119.1 |  |  | $ | (6.6 | ) |  | (6 | )% |
| Service |  | $ | 35.5 |  |  | $ | 29.2 |  |  | $ | 6.3 |  |  | 22 | % |
| Total Net Revenue |  | $ | 148.0 |  |  | $ | 148.3 |  |  | $ | (0.3 | ) |  | — | % |
| Gross Margin |  | 54.6 | % |  | 56.4 | % |  | (1.8 | )% |  | (3 | )% |
| Operating Margin |  | 4.5 | % |  | 11.0 | % |  | (6.5 | )% |  | (59 | )% |
| Net Income |  | $ | 4.7 |  |  | $ | 14.1 |  |  | $ | (9.4 | ) |  | (67 | )% |
| Earnings per diluted share |  | $ | 0.05 |  |  | $ | 0.14 |  |  | $ | (0.09 | ) |  | (64 | )% |

[0001078271-15-000004:8k_2_02:31]
| • | Cash and investments ended the quarter at $109.3 million, as compared to $104.5 million from the prior quarter. |

[0001078271-15-000004:8k_2_02:32]
| • | Accounts receivable balance ending Q2 was $93.5 million, with days sales outstanding (DSO) of 57. |

[0001078271-15-000004:8k_2_02:33]
| • | Inventory ending Q2 was $54.4 million, a decrease of $0.9 million from the prior quarter, due to continued right-sizing of inventory. |

[0001078271-15-000004:8k_2_02:34]
Business Outlook:

[0001078271-15-000004:8k_2_02:35]
For its third quarter of fiscal 2015 ending March 31, 2015, the Company is targeting GAAP revenue in a range of $129 million to $139 million with non-GAAP revenue in a range of $130 million to $140 million. GAAP gross margin is targeted between 51.0% and 52.0% and non-GAAP gross margin targeted between 55.0% and 56.0%. Operating expenses are targeted to be between $83 million and $84.6 million on a GAAP basis and $72.5 million to $74.5 million on a non-GAAP basis. GAAP net loss is targeted to be between $14 million to $19.5 million, or $0.14 to $0.20 per share.  Non-GAAP earnings are targeted in a range of a net loss of $3.1 million to net income of $1.8 million, or a loss of $0.03 to net income of $0.02 per diluted share. The GAAP and non-GAAP net (loss) income targets are based on an estimated 99 million and 101 million, average outstanding shares respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses and the purchase accounting adjustment related to deferred service revenue.

[0001078271-15-000004:8k_2_02:36]
Conference Call:

[0001078271-15-000004:8k_2_02:37]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the second fiscal quarter results and third fiscal quarter business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through January 27, 2016.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #:63414269.

[0001078271-15-000004:8k_2_02:38]
About Extreme Networks:

[0001078271-15-000004:8k_2_02:39]
Extreme Networks, Inc. (NASDAQ: EXTR) is setting a new standard for superior customer experience by delivering network-powered innovation and marketing leading service and support. Extreme Networks delivers high-performance switching and routing products for data center and core-to-edge networks, wired/wireless LAN access, and unified network management and control. Our award-winning solutions include software-defined networking (SDN), cloud and high-density Wi-Fi, BYOD and enterprise mobility, identity access management and security.  Extreme Networks is headquartered in San Jose, CA and has more than 12,000 customers in over 80 countries. For more information, visit http://www.extremenetworks.com.

[0001078271-15-000004:8k_2_02:40]
Non-GAAP Financial Measures:

[0001078271-15-000004:8k_2_02:41]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income/(loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, and share-based compensation.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company and the Company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the Company's operating activities with the Company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the Company's historical performance and in planning its future business activities. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's financial information presented in accordance with GAAP.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring charges, net of reversals and share-based compensation expense.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-15-000004:8k_2_02:42]
Forward Looking Statements:

[0001078271-15-000004:8k_2_02:43]
Actual results, including with respect to the Company's financial targets and general business prospects, could differ materially due to a number of factors, including the risks that:

[0001078271-15-000004:8k_2_02:44]
| • | The Company may not achieve targeted revenues for the Company's products and services given increasing price competition and product technology developments in key network switching equipment markets; |

[0001078271-15-000004:8k_2_02:45]
| • | Ongoing uncertainty in global economic conditions, infrastructure development or customer demand could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; |

[0001078271-15-000004:8k_2_02:46]
| • | The Company may be unable to effectively integrate the businesses of Extreme Networks and Enterasys Networks, both in terms of customer acceptance of combined product lines as well as the need to align the Company's cost structure to meet the company's financial goals, including controlling expenses, and meeting financial covenants as part of the Company's debt financing used to acquire Enterasys Networks; |

[0001078271-15-000004:8k_2_02:47]
| • | The Company may not accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; |

[0001078271-15-000004:8k_2_02:48]
| • | The Company is dependent on third parties to manufacture its products and any potential production delays could preclude the Company from shipping sufficient quantities to meet customer orders or could result in higher production costs and lower margins; |

[0001078271-15-000004:8k_2_02:49]
| • | The Company may be unable to complete development and commercialization of products under development, such as its pipeline of new network switches and related software; |

[0001078271-15-000004:8k_2_02:50]
| • | The Company may be adversely affected by ongoing litigation. |

[0001078271-15-000004:8k_2_02:51]
EXTREME NETWORKS, INC.

[0001078271-15-000004:8k_2_02:52]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-15-000004:8k_2_02:53]
(In thousands, except share and per share amounts)

[0001078271-15-000004:8k_2_02:54]
(Unaudited)

[0001078271-15-000004:8k_2_02:55]
|  | December 31, 2014 |  | June 30, 2014 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 88,972 |  |  | $ | 73,190 |  |
| Short-term investments | 20,321 |  |  | 32,692 |  |
| Accounts receivable, net of allowances of $6,138 at December 31, 2014 and $3,618 at June 30, 2014 | 93,519 |  |  | 124,664 |  |
| Inventories | 54,431 |  |  | 57,109 |  |
| Deferred income taxes | 911 |  |  | 1,058 |  |
| Prepaid expenses and other current assets | 11,929 |  |  | 14,143 |  |
| Total current assets | 270,083 |  |  | 302,856 |  |
| Property and equipment, net | 43,568 |  |  | 46,554 |  |
| Intangible assets, net | 69,880 |  |  | 87,459 |  |
| Goodwill | 70,877 |  |  | 70,877 |  |
| Other assets | 20,903 |  |  | 18,686 |  |
| Total assets | $ | 475,311 |  |  | $ | 526,432 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 8,125 |  |  | $ | 29,688 |  |
| Accounts payable | 45,503 |  |  | 37,308 |  |
| Accrued compensation and benefits | 22,476 |  |  | 26,677 |  |
| Restructuring liabilities | 75 |  |  | 322 |  |
| Accrued warranty | 7,845 |  |  | 7,551 |  |
| Deferred revenue, net | 74,353 |  |  | 74,735 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 31,172 |  |  | 31,992 |  |
| Other accrued liabilities | 36,030 |  |  | 38,035 |  |
| Total current liabilities | 225,579 |  |  | 246,308 |  |
| Deferred revenue, less current portion | 23,940 |  |  | 22,942 |  |
| Long-term debt, less current portion | 81,000 |  |  | 91,875 |  |
| Other long-term liabilities | 10,676 |  |  | 8,595 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 134,116 |  |  | 156,712 |  |
| Total liabilities and stockholders’ equity | $ | 475,311 |  |  | $ | 526,432 |  |

[0001078271-15-000004:8k_2_02:56]
EXTREME NETWORKS, INC.

[0001078271-15-000004:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000004:8k_2_02:58]
(In thousands, except per share amounts)

[0001078271-15-000004:8k_2_02:59]
(Unaudited)

[0001078271-15-000004:8k_2_02:60]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 112,501 |  |  | $ | 119,065 |  |  | $ | 215,173 |  |  | $ | 180,109 |  |
| Service | 34,707 |  |  | 27,518 |  |  | 68,309 |  |  | 42,389 |  |
| Total net revenues | 147,208 |  |  | 146,583 |  |  | 283,482 |  |  | 222,498 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 60,496 |  |  | 66,893 |  |  | 114,521 |  |  | 94,409 |  |
| Service | 11,550 |  |  | 9,845 |  |  | 23,272 |  |  | 14,538 |  |
| Total cost of revenues | 72,046 |  |  | 76,738 |  |  | 137,793 |  |  | 108,947 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 52,005 |  |  | 52,172 |  |  | 100,652 |  |  | 85,700 |  |
| Service | 23,157 |  |  | 17,673 |  |  | 45,037 |  |  | 27,851 |  |
| Total gross profit | 75,162 |  |  | 69,845 |  |  | 145,689 |  |  | 113,551 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 24,000 |  |  | 18,896 |  |  | 47,347 |  |  | 28,832 |  |
| Sales and marketing | 43,971 |  |  | 40,636 |  |  | 88,750 |  |  | 63,330 |  |
| General and administrative | 10,306 |  |  | 11,189 |  |  | 21,380 |  |  | 18,125 |  |
| Acquisition and integration costs | 3,500 |  |  | 8,688 |  |  | 7,558 |  |  | 12,382 |  |
| Restructuring charge, net of reversals | — |  |  | 430 |  |  | — |  |  | 505 |  |
| Amortization of intangibles | 4,467 |  |  | 3,778 |  |  | 8,934 |  |  | 3,778 |  |
| Total operating expenses | 86,244 |  |  | 83,617 |  |  | 173,969 |  |  | 126,952 |  |
| Operating loss | (11,082 | ) |  | (13,772 | ) |  | (28,280 | ) |  | (13,401 | ) |
| Interest income | 196 |  |  | 172 |  |  | 342 |  |  | 447 |  |
| Interest expense | (825 | ) |  | (524 | ) |  | (1,661 | ) |  | (524 | ) |
| Other expense, net | (64 | ) |  | (937 | ) |  | (498 | ) |  | (1,192 | ) |
| Loss before income taxes | (11,775 | ) |  | (15,061 | ) |  | (30,097 | ) |  | (14,670 | ) |
| Provision for income taxes | 1,330 |  |  | 925 |  |  | 2,338 |  |  | 1,352 |  |
| Net loss | $ | (13,105 | ) |  | $ | (15,986 | ) |  | $ | (32,435 | ) |  | $ | (16,022 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.13 | ) |  | $ | (0.17 | ) |  | $ | (0.33 | ) |  | $ | (0.17 | ) |
| Net loss per share - diluted | $ | (0.13 | ) |  | $ | (0.17 | ) |  | $ | (0.33 | ) |  | $ | (0.17 | ) |
| Shares used in per share calculation - basic | 98,677 |  |  | 95,216 |  |  | 97,996 |  |  | 94,639 |  |
| Shares used in per share calculation - diluted | 98,677 |  |  | 95,216 |  |  | 97,996 |  |  | 94,639 |  |

[0001078271-15-000004:8k_2_02:61]
EXTREME NETWORKS, INC.

[0001078271-15-000004:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-15-000004:8k_2_02:63]
(In thousands)

[0001078271-15-000004:8k_2_02:64]
(Unaudited)

[0001078271-15-000004:8k_2_02:65]
|  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |
| Net cash provided by (used in) operating activities | $ | 41,453 |  |  | $ | (4,869 | ) |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (3,962 | ) |  | (12,562 | ) |
| Acquisition, net of cash acquired | — |  |  | (180,000 | ) |
| Purchases of investments | — |  |  | (9,045 | ) |
| Proceeds from maturities of investments and marketable securities | 3,000 |  |  | 20,062 |  |
| Proceeds from sales of investments and marketable securities | 9,051 |  |  | 54,578 |  |
| Purchases of intangible assets | (419 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 7,670 |  |  | (126,967 | ) |
| Cash flows from financing activities: |  |  |  |
| Borrowings under Revolving Facility | 24,000 |  |  | 35,000 |  |
| Issuance of Term Loan | — |  |  | 65,000 |  |
| Repayment of debt | (56,438 | ) |  | (813 | ) |
| Proceeds from issuance of common stock | 1,722 |  |  | 4,803 |  |
| Net cash (used in) provided by financing activities | (30,716 | ) |  | 103,990 |  |
| Foreign currency effect on cash | (2,625 | ) |  | 347 |  |
| Net increase (decrease) in cash and cash equivalents | 15,782 |  |  | (27,499 | ) |
| Cash and cash equivalents at beginning of period | 73,190 |  |  | 95,803 |  |
| Cash and cash equivalents at end of period | $ | 88,972 |  |  | $ | 68,304 |  |

[0001078271-15-000004:8k_2_02:66]
Extreme Networks, Inc.

[0001078271-15-000004:8k_2_02:67]
Non-GAAP Measures of Financial Performance

[0001078271-15-000004:8k_2_02:68]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-15-000004:8k_2_02:69]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles and  restructuring expenses

[0001078271-15-000004:8k_2_02:70]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-15-000004:8k_2_02:71]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-15-000004:8k_2_02:72]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, and restructuring expenses.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-15-000004:8k_2_02:73]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-15-000004:8k_2_02:74]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-15-000004:8k_2_02:75]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-15-000004:8k_2_02:76]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-15-000004:8k_2_02:77]
Purchase accounting adjustments relating to deferred revenue.  Purchase accounting adjustments consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001078271-15-000004:8k_2_02:78]
Purchase accounting adjustments relating to inventory.  Purchase accounting adjustments relating to inventory consists of the amortization of the step up value from the valuation of the inventory at fair value in cost of revenues as part of business

[0001078271-15-000004:8k_2_02:79]
combination accounting.  Extreme Networks excludes these expenses since they result from an event that is out the ordinary course of continuing operations.

[0001078271-15-000004:8k_2_02:80]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-15-000004:8k_2_02:81]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the Company's cash balance for the period.

[0001078271-15-000004:8k_2_02:82]
EXTREME NETWORKS, INC.

[0001078271-15-000004:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000004:8k_2_02:84]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-15-000004:8k_2_02:85]
(In thousands, except per share amounts)

[0001078271-15-000004:8k_2_02:86]
(Unaudited)

[0001078271-15-000004:8k_2_02:87]
| Non-GAAP Revenue | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Revenue - GAAP Basis | $ | 147,208 |  |  | $ | 146,583 |  |  | $ | 283,482 |  |  | $ | 222,498 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 1,764 |  |  | $ | 1,533 |  |  | $ | 1,764 |  |
| Revenue - Non-GAAP Basis | $ | 147,974 |  |  | $ | 148,347 |  |  | $ | 285,015 |  |  | $ | 224,262 |  |
| Non-GAAP Gross Margin | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Gross profit - GAAP Basis | $ | 75,162 |  |  | $ | 69,845 |  |  | $ | 145,689 |  |  | $ | 113,551 |  |
| Gross margin - GAAP Basis percentage | 51.1 | % |  | 47.6 | % |  | 51.4 | % |  | 51.0 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 547 |  |  | $ | 198 |  |  | $ | 1,121 |  |  | $ | 502 |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 11,000 |  |  | $ | 1,533 |  |  | $ | 11,000 |  |
| Amortization of intangibles | $ | 4,292 |  |  | $ | 2,694 |  |  | $ | 8,583 |  |  | $ | 2,694 |  |
| Gross profit - Non-GAAP Basis | $ | 80,767 |  |  | $ | 83,737 |  |  | $ | 156,926 |  |  | $ | 127,747 |  |
| Gross margin - Non-GAAP Basis percentage | 54.6 | % |  | 56.4 | % |  | 55.1 | % |  | 57.0 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| GAAP operating loss | $ | (11,082 | ) |  | $ | (13,772 | ) |  | $ | (28,280 | ) |  | $ | (13,401 | ) |
| GAAP operating loss income percentage | (7.5 | )% |  | (9.4 | )% |  | (10.0 | )% |  | (6.0 | )% |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 4,750 |  |  | $ | 3,458 |  |  | $ | 9,563 |  |  | $ | 5,033 |  |
| Acquisition and integration costs | $ | 3,500 |  |  | $ | 8,688 |  |  | $ | 7,558 |  |  | $ | 12,382 |  |
| Restructuring charge, net of reversal | $ | — |  |  | $ | 430 |  |  | $ | — |  |  | $ | 505 |  |
| Amortization of intangibles | $ | 8,759 |  |  | $ | 6,472 |  |  | $ | 17,517 |  |  | $ | 6,472 |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 11,000 |  |  | $ | 1,533 |  |  | $ | 11,000 |  |
| Total adjustments to GAAP operating income | $ | 17,775 |  |  | $ | 30,048 |  |  | $ | 36,171 |  |  | $ | 35,392 |  |
| Non-GAAP operating income | $ | 6,693 |  |  | $ | 16,276 |  |  | $ | 7,891 |  |  | $ | 21,991 |  |
| Non-GAAP operating income percentage | 4.5 | % |  | 11.0 | % |  | 2.8 | % |  | 9.8 | % |

[0001078271-15-000004:8k_2_02:88]
| Non-GAAP Net Income | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| GAAP net loss | $ | (13,105 | ) |  | $ | (15,986 | ) |  | $ | (32,435 | ) |  | $ | (16,022 | ) |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 4,750 |  |  | $ | 3,458 |  |  | $ | 9,563 |  |  | $ | 5,033 |  |
| Acquisition and integration costs | $ | 3,500 |  |  | $ | 8,688 |  |  | $ | 7,558 |  |  | $ | 12,382 |  |
| Restructuring charge, net of reversal | $ | — |  |  | $ | 430 |  |  | $ | — |  |  | $ | 505 |  |
| Amortization of intangibles | $ | 8,759 |  |  | $ | 6,472 |  |  | $ | 17,517 |  |  | $ | 6,472 |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 11,000 |  |  | $ | 1,533 |  |  | $ | 11,000 |  |
| Total adjustments to GAAP net income | $ | 17,775 |  |  | $ | 30,048 |  |  | $ | 36,171 |  |  | $ | 35,392 |  |
| Non-GAAP net income | $ | 4,670 |  |  | $ | 14,062 |  |  | $ | 3,736 |  |  | $ | 19,370 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.05 |  |  | $ | 0.14 |  |  | $ | 0.04 |  |  | $ | 0.20 |  |
| Shares used in diluted net income per share calculation | 100,788 |  |  | 98,352 |  |  | 100,606 |  |  | 97,023 |  |
| Free Cash Flow | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | December 31, 2014 |  | December 31, 2013 |
| Cash flow provided by operations | $ | 39,822 |  |  | $ | (6,794 | ) |  | $ | 41,453 |  |  | $ | (4,869 | ) |
| Add: PP&E CapEx spending | $ | (1,178 | ) |  | $ | (2,754 | ) |  | $ | (3,962 | ) |  | $ | (12,562 | ) |
| Total free cash flow | $ | 38,644 |  |  | $ | (9,548 | ) |  | $ | 37,491 |  |  | $ | (17,431 | ) |
