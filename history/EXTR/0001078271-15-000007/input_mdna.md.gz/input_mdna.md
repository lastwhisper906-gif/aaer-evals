# EXTR MD&A — 0001078271-15-000007


## mdna

[0001078271-15-000007:mdna:1]
[same as prior period, unchanged from 0001078271-14-000064:mdna:1]

[0001078271-15-000007:mdna:2]
[same as prior period, unchanged from 0001078271-14-000064:mdna:2]

[0001078271-15-000007:mdna:3]
[same as prior period, unchanged from 0001078271-14-000064:mdna:3]

[0001078271-15-000007:mdna:4]
[same as prior period, unchanged from 0001078271-14-000064:mdna:4]

[0001078271-15-000007:mdna:5]
[same as prior period, unchanged from 0001078271-14-000064:mdna:5]

[0001078271-15-000007:mdna:6]
[same as prior period, unchanged from 0001078271-14-000064:mdna:6]

[0001078271-15-000007:mdna:7]
[same as prior period, unchanged from 0001078271-14-000064:mdna:7]

[0001078271-15-000007:mdna:8]
[same as prior period, unchanged from 0001078271-14-000064:mdna:8]

[0001078271-15-000007:mdna:9]
[same as prior period, unchanged from 0001078271-14-000064:mdna:9]

[0001078271-15-000007:mdna:10]
[same as prior period, unchanged from 0001078271-14-000064:mdna:10]

[0001078271-15-000007:mdna:11]
[same as prior period, unchanged from 0001078271-14-000064:mdna:11]

[0001078271-15-000007:mdna:12]
[same as prior period, unchanged from 0001078271-14-000064:mdna:12]

[0001078271-15-000007:mdna:13]
During the second quarter of fiscal 2015, we achieved the following results:

[0001078271-15-000007:mdna:14]
| • | Net revenues of $147.2 million compared to net revenues of $146.6 million in the second quarter of fiscal 2014. |

[0001078271-15-000007:mdna:15]
| • | Product revenues of $112.5 million compared to product revenues of $119.1 million in the second quarter of fiscal 2014. |

[0001078271-15-000007:mdna:16]
| • | Service revenues of $34.7 million compared to service revenues of $27.5 million in the second quarter of fiscal 2014. |

[0001078271-15-000007:mdna:17]
| • | Total gross margin of 51% of net revenues compared to total gross margin of 48% of net revenues in the second quarter of fiscal 2014. |

[0001078271-15-000007:mdna:18]
| • | Operating loss of $11.1 million compared to operating loss of $13.8 million in the second quarter of fiscal 2014. |

[0001078271-15-000007:mdna:19]
| • | Net loss of $13.1 million compared to net loss of $16.0 million in the second quarter of fiscal 2014. |

[0001078271-15-000007:mdna:20]
| • | Cash flow provided by operating activities of $41.5 million in the three months ended December 31, 2014 compared to cash flow used in operating activities of $4.9 million in the three months ended December 31, 2013. |

[0001078271-15-000007:mdna:21]
| • | Cash and cash equivalents, short-term investments and marketable securities increased by $3.4 million to $109.3 million as of December 31, 2014 from $105.9 million as of June 30, 2014, primarily due to increased proceeds from cash provided by operations offset by repayment of debt. |

[0001078271-15-000007:mdna:22]
[same as prior period, unchanged from 0001078271-14-000064:mdna:22]

[0001078271-15-000007:mdna:23]
The following table presents the total net revenue geographically for the three and six months ended December 31, 2014 and December 31, 2013 (dollars in thousands):

[0001078271-15-000007:mdna:24]
|  | Three Months Ended |  | Six Months Ended |
| Net Revenues | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |  | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 58,160 |  |  | $ | 56,292 |  |  | $ | 1,868 |  |  | 3.3 | % |  | $ | 116,648 |  |  | $ | 81,681 |  |  | $ | 34,967 |  |  | 42.8 | % |
| Other | 12,576 |  |  | 13,913 |  |  | (1,337 | ) |  | (9.6 | )% |  | 19,917 |  |  | 20,214 |  |  | (297 | ) |  | (1.5 | )% |
| Total Americas | 70,736 |  |  | 70,205 |  |  | 531 |  |  | 0.8 | % |  | 136,565 |  |  | 101,895 |  |  | 34,670 |  |  | 34.0 | % |
| Percentage of net revenue | 48.0 | % |  | 47.9 | % |  |  |  |  |  | 48.2 | % |  | 45.8 | % |  |  |  |  |  |  |
| EMEA | 62,574 |  |  | 61,292 |  |  | 1,282 |  |  | 2.1 | % |  | 116,509 |  |  | 92,133 |  |  | 24,376 |  |  | 26.5 | % |
| Percentage of net revenue | 42.5 | % |  | 41.8 | % |  |  |  |  |  | 41.1 | % |  | 41.4 | % |  |  |  |  |  |  |
| APAC | 13,898 |  |  | 15,086 |  |  | (1,188 | ) |  | (7.9 | )% |  | 30,408 |  |  | 28,470 |  |  | 1,938 |  |  | 6.8 | % |
| Percentage of net revenue | 9.4 | % |  | 10.3 | % |  |  |  |  |  | 10.7 | % |  | 12.8 | % |  |  |  |  |
| Total net revenues | $ | 147,208 |  |  | $ | 146,583 |  |  | $ | 625 |  |  | 0.4 | % |  | $ | 283,482 |  |  | $ | 222,498 |  |  | $ | 60,984 |  |  | 27.4 | % |

[0001078271-15-000007:mdna:25]
[same as prior period, unchanged from 0001078271-14-000064:mdna:25]

[0001078271-15-000007:mdna:26]
The following table presents net product and service revenue for the three and six months ended December 31, 2014 and December 31, 2013 (dollars in thousands):

[0001078271-15-000007:mdna:27]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |  | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 112,501 |  |  | $ | 119,065 |  |  | $ | (6,564 | ) |  | (5.5 | )% |  | $ | 215,173 |  |  | $ | 180,109 |  |  | $ | 35,064 |  |  | 19.5 | % |
| Percentage of net revenue | 76.4 | % |  | 81.2 | % |  |  |  |  |  | 75.9 | % |  | 80.9 | % |  |  |  |  |
| Service | 34,707 |  |  | 27,518 |  |  | 7,189 |  |  | 26.1 | % |  | 68,309 |  |  | 42,389 |  |  | 25,920 |  |  | 61.1 | % |
| Percentage of net revenue | 23.6 | % |  | 18.8 | % |  |  |  |  |  | 24.1 | % |  | 19.1 | % |  |  |  |  |
| Total net revenues | $ | 147,208 |  |  | $ | 146,583 |  |  | $ | 625 |  |  | 0.4 | % |  | $ | 283,482 |  |  | $ | 222,498 |  |  | $ | 60,984 |  |  | 27.4 | % |

[0001078271-15-000007:mdna:28]
Product revenue decreased $6.6 million or 5.5% in the second quarter of fiscal 2015 compared to the corresponding period of fiscal 2014. In the second quarter of fiscal 2015, the Company experienced a decrease in shipments due to product constraints, timing of orders and increased price competition. Product revenue increased $35.1 million or 19.5% in the six months ended December 31, 2014 compared to the corresponding period of fiscal 2014 due to increased product shipments and customers as a result of our acquisition of Enterasys on October 31, 2013.

[0001078271-15-000007:mdna:29]
Service revenue increased $7.2 million or 26.1% in the second quarter of fiscal 2015 and $25.9 million or 61.1% for the six months ended December 31, 2014 compared to the corresponding periods of fiscal 2014 due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys on October 31, 2013. In addition, purchase accounting charges against service revenue decreased $1.0 million in the second quarter of fiscal 2015 as compared to fiscal 2014.

[0001078271-15-000007:mdna:30]
20

[0001078271-15-000007:mdna:31]
Gross Profit

[0001078271-15-000007:mdna:32]
The following table presents the product and service revenue gross profit and the respective gross profit percentages for the three and six months ended December 31, 2014 and 2013 (dollars in thousands):

[0001078271-15-000007:mdna:33]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |  | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 52,005 |  |  | $ | 52,172 |  |  | $ | (167 | ) |  | (0.3 | )% |  | $ | 100,652 |  |  | $ | 85,700 |  |  | $ | 14,952 |  |  | 17.4 | % |
| Percentage of product revenue | 46.2 | % |  | 43.8 | % |  |  |  |  |  | 46.8 | % |  | 47.6 | % |  |  |  |  |
| Service | 23,157 |  |  | 17,673 |  |  | 5,484 |  |  | 31.0 | % |  | 45,037 |  |  | 27,851 |  |  | 17,186 |  |  | 61.7 | % |
| Percentage of service revenue | 66.7 | % |  | 64.2 | % |  |  |  |  |  | 65.9 | % |  | 65.7 | % |  |  |  |  |
| Total gross profit | $ | 75,162 |  |  | $ | 69,845 |  |  | $ | 5,317 |  |  | 7.6 | % |  | $ | 145,689 |  |  | $ | 113,551 |  |  | $ | 32,138 |  |  | 28.3 | % |
| Percentage of net revenue | 51.1 | % |  | 47.7 | % |  |  |  |  |  | 51.4 | % |  | 51.0 | % |  |  |  |  |

[0001078271-15-000007:mdna:34]
[same as prior period, unchanged from 0001078271-14-000064:mdna:33]

[0001078271-15-000007:mdna:35]
Product gross profit remained flat in the second quarter of fiscal 2015 as compared to the corresponding period in 2014. Gross profit was impacted during the second quarter of fiscal 2015 by a decrease in product revenue of $6.6 million and higher material costs in addition to increases in the amortization of the developed technology intangibles related to the acquisition of Enterasys on October 31, 2013 of $1.5 million, excess and obsolete inventory charges of $1.0 million and higher distribution expenses as compared to the corresponding period of fiscal 2014.  Gross profit for the second quarter of fiscal 2014 was negatively impacted by $9.2 million related to the sale of inventory which had been adjusted to fair value upon the Enterasys acquisition due to purchase accounting.

[0001078271-15-000007:mdna:36]
Product gross profit increased to $100.7 million in the six months ended December 31, 2014 from $85.7 million in the corresponding period for 2014.  Product gross profit for the six months ended December 31, 2014 was favorably impacted by an increase in product revenue of $35.2 million, offset by higher material costs and increases in excess and obsolete inventory charges of $2.5 million, amortization of the developed technology intangibles from the acquisition of Enterasys of $5.6 million and warranty reserves of $0.5 million.  Gross profit for the second quarter of fiscal 2014 was negatively impacted by $9.2 million related to the sale of inventory which had been adjusted to fair value upon the Enterasys acquisition due to purchase accounting.

[0001078271-15-000007:mdna:37]
Our cost of service revenue consists primarily of personnel, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross profit increased to $23.2 million in the second quarter of fiscal 2015 from $17.7 million in the second quarter of fiscal 2014. The increase in service gross profit was primarily due to higher revenue from an increased customer base as a result of our acquisition of Enterasys offset by higher service labor costs of approximately 110 employees.

[0001078271-15-000007:mdna:38]
Service gross profit for the six months ended December 31, 2014 increased to $45.0 million in the second quarter of fiscal 2015 from $27.9 million in the corresponding period for 2014 primarily due to increase in service revenue of $25.9 million offset by increased personnel, overhead and travel costs for approximately 110 employees as a result of the acquisition of Enterasys on October 31, 2013.

[0001078271-15-000007:mdna:39]
[same as prior period, unchanged from 0001078271-14-000064:mdna:36]

[0001078271-15-000007:mdna:40]
The following table presents operating expenses and operating income (dollars in thousands):

[0001078271-15-000007:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |  | December 31, 2014 |  | December 31, 2013 |  | $Change |  | %Change |
| Research and development | $ | 24,000 |  |  | $ | 18,896 |  |  | $ | 5,104 |  |  | 27.0 | % |  | $ | 47,347 |  |  | $ | 28,832 |  |  | $ | 18,515 |  |  | 64.2 | % |
| Sales and marketing | 43,971 |  |  | 40,636 |  |  | 3,335 |  |  | 8.2 | % |  | 88,750 |  |  | 63,330 |  |  | 25,420 |  |  | 40.1 | % |
| General and administrative | 10,306 |  |  | 11,189 |  |  | (883 | ) |  | (7.9 | )% |  | 21,380 |  |  | 18,125 |  |  | 3,255 |  |  | 18.0 | % |
| Acquisition and integration costs | 3,500 |  |  | 8,688 |  |  | (5,188 | ) |  | (59.7 | )% |  | 7,558 |  |  | 12,382 |  |  | (4,824 | ) |  | (39.0 | )% |
| Restructuring charge, net of reversals | — |  |  | 430 |  |  | (430 | ) |  | (100.0 | )% |  | — |  |  | 505 |  |  | (505 | ) |  | (100.0 | )% |
| Amortization of intangibles | 4,467 |  |  | 3,778 |  |  | 689 |  |  | 18.2 | % |  | 8,934 |  |  | 3,778 |  |  | 5,156 |  |  | 136.5 | % |
| Total operating expenses | $ | 86,244 |  |  | $ | 83,617 |  |  | $ | 2,627 |  |  | 3.1 | % |  | $ | 173,969 |  |  | $ | 126,952 |  |  | $ | 47,017 |  |  | 37.0 | % |
| Operating loss | $ | (11,082 | ) |  | $ | (13,772 | ) |  | $ | 2,690 |  |  | 19.5 | % |  | $ | (28,280 | ) |  | $ | (13,401 | ) |  | $ | (14,879 | ) |  | (111.0 | )% |

[0001078271-15-000007:mdna:42]
[same as prior period, unchanged from 0001078271-14-000064:mdna:39]

[0001078271-15-000007:mdna:43]
[same as prior period, unchanged from 0001078271-14-000064:mdna:40]

[0001078271-15-000007:mdna:44]
Research and development expenses increased by $5.1 million, or 27.0% and increased by $18.5 million or 64.2% for the three and six months ended December 31, 2014 as compared to the corresponding periods of fiscal 2014. The increases in research and development expenses were due to increased personnel costs of approximately 300 employees and higher occupancy costs of additional facilities, primarily in Salem New Hampshire and Toronto Canada, as a result of our acquisition of Enterasys on October 31, 2013.

[0001078271-15-000007:mdna:45]
[same as prior period, unchanged from 0001078271-14-000064:mdna:42]

[0001078271-15-000007:mdna:46]
[same as prior period, unchanged from 0001078271-14-000064:mdna:43]

[0001078271-15-000007:mdna:47]
Sales and marketing expenses increased by $3.3 million, or 8.2% and increased by $25.4 million or 40.1% for the three and six months ended December 31, 2014 as compared to the corresponding periods of fiscal 2014. The increases in sales and marketing expenses were primarily due to additional headcount of approximately 330 employees and facilities expense as well as additional spending on sales and marketing programs as a result of our acquisition of Enterasys on October 31, 2013.

[0001078271-15-000007:mdna:48]
[same as prior period, unchanged from 0001078271-14-000064:mdna:45]

[0001078271-15-000007:mdna:49]
General and administrative expenses decreased by $0.9 million, or 7.9% for the three months ended December 31, 2014 and increased by $3.3 million or 18.0% for the six months ended December 31, 2014 as compared to the corresponding periods of fiscal 2014. The decrease in general and administrative expenses was primarily due to lower bonus accruals and lower travel costs offset by additional month of personnel costs and higher recruiting costs related to our acquisition of Enterasys on October 31, 2013. The increase in general and administrative expenses during the six months ending December 31, 2014, compared to the corresponding period of fiscal 2014, was primarily due to higher personnel and travel costs due to an increase in headcount of approximately 100 employees, and higher occupancy costs due to additional facilities in Salem, New Hampshire and Shannon, Ireland as a result of our acquisition of Enterasys on October 31, 2013 and an increase in bad debt expense.

[0001078271-15-000007:mdna:50]
[same as prior period, unchanged from 0001078271-14-000064:mdna:47]

[0001078271-15-000007:mdna:51]
Acquisition and Integration costs include those costs that the company has incurred only as result of the acquisition of Enterasys and related subsequent integration of the two companies.  The Company expects to continue to incur principally integration costs for the remainder of fiscal 2015.

[0001078271-15-000007:mdna:52]
We incurred $3.5 million and $7.6 million of integration costs during the three and six months ended December 31, 2014, primarily for IT, warehouse, and sales integration and severance costs. The Company expects to incur integration costs through fiscal 2015.  The Company incurred $8.7 million and $12.4 million of acquisition and integration costs during the three and six months ended December 31, 2013.

[0001078271-15-000007:mdna:53]
Amortization of Intangibles

[0001078271-15-000007:mdna:54]
During the three and six months ended December 31, 2014, we recorded $4.5 million and $8.9 million of amortization expense and during the three and six months ended December 31, 2013, we recorded $3.8 million of amortization expense, primarily for certain intangible assets related to the acquisition of Enterasys on October 31, 2013.

[0001078271-15-000007:mdna:55]
[same as prior period, unchanged from 0001078271-14-000064:mdna:53]

[0001078271-15-000007:mdna:56]
During the three and six months ended December 31, 2014 we recorded $0.8 million and $1.7 million in interest expense related to the Credit Facility that the Company entered into on October 31, 2013.

[0001078271-15-000007:mdna:57]
[same as prior period, unchanged from 0001078271-14-000064:mdna:55]

[0001078271-15-000007:mdna:58]
Other expense, net decreased by $0.9 million in the second quarter of fiscal 2015 compared to the corresponding period of fiscal 2014.  The increase in other expense, net was primarily due to losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001078271-15-000007:mdna:59]
[same as prior period, unchanged from 0001078271-14-000064:mdna:57]

[0001078271-15-000007:mdna:60]
For the three and six months ended December 31, 2014, we recorded an income tax provision of $1.3 million and $2.3 million, respectively. For the three and six months ended December 31, 2013, we recorded an income tax provision of $0.9 million and $1.4 million, respectively.

[0001078271-15-000007:mdna:61]
The income tax provisions for the three and six months ended December 31, 2014 and 2013 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.

[0001078271-15-000007:mdna:62]
[same as prior period, unchanged from 0001078271-14-000064:mdna:60]

[0001078271-15-000007:mdna:63]
[same as prior period, unchanged from 0001078271-14-000064:mdna:61]

[0001078271-15-000007:mdna:64]
[same as prior period, unchanged from 0001078271-14-000064:mdna:62]

[0001078271-15-000007:mdna:65]
[same as prior period, unchanged from 0001078271-14-000064:mdna:63]

[0001078271-15-000007:mdna:66]
[same as prior period, unchanged from 0001078271-14-000064:mdna:64]

[0001078271-15-000007:mdna:67]
[same as prior period, unchanged from 0001078271-14-000064:mdna:65]

[0001078271-15-000007:mdna:68]
[same as prior period, unchanged from 0001078271-14-000064:mdna:66]

[0001078271-15-000007:mdna:69]
[same as prior period, unchanged from 0001078271-14-000064:mdna:67]

[0001078271-15-000007:mdna:70]
[same as prior period, unchanged from 0001078271-14-000064:mdna:68]

[0001078271-15-000007:mdna:71]
[same as prior period, unchanged from 0001078271-14-000064:mdna:69]

[0001078271-15-000007:mdna:72]
[same as prior period, unchanged from 0001078271-14-000064:mdna:70]

[0001078271-15-000007:mdna:73]
See Note 3 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001078271-15-000007:mdna:74]
[same as prior period, unchanged from 0001078271-14-000064:mdna:72]

[0001078271-15-000007:mdna:75]
[same as prior period, unchanged from 0001078271-14-000064:mdna:73]

[0001078271-15-000007:mdna:76]
|  | December 31, 2014 |  | June 30, 2014 |
| Cash and cash equivalent | $ | 88,972 |  |  | $ | 73,190 |  |
| Short-term investments | 20,321 |  |  | 32,692 |  |
| Total cash and investments | $ | 109,293 |  |  | $ | 105,882 |  |
| Working capital | $ | 44,504 |  |  | $ | 56,548 |  |

[0001078271-15-000007:mdna:77]
As of December 31, 2014, our principal sources of liquidity consisted of cash, cash equivalents and investments of $109.3 million, net accounts receivable of $93.5 million and $1.0 million of letters of credit and borrowings from the Revolving Facility under which the Company had $17.4 million of availability at December 31, 2014.  Our principal uses of cash will include purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development, marketing of our products, purchases of property and equipment, repayments of debt and related interest. We believe that our $109.3 million of cash and cash equivalents and investments at December 31, 2014 along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001078271-15-000007:mdna:78]
Our Credit Agreement contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum a Consolidated Leverage Ratio and several other covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.  During the three months ended December 31, 2014, the Company amended the Credit Agreement and among other things modified certain financial covenants governing quick and leverage ratios.

[0001078271-15-000007:mdna:79]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Agreement may be accelerated upon certain events of default.  We believe we are in compliance and expect to remain in compliance with our Credit Agreement covenants and they are not expected to impact our liquidity or capital resources.

[0001078271-15-000007:mdna:80]
[same as prior period, unchanged from 0001078271-14-000064:mdna:78]

[0001078271-15-000007:mdna:81]
[same as prior period, unchanged from 0001078271-14-000064:mdna:79]

[0001078271-15-000007:mdna:82]
|  | Six Months Ended |
|  | December 31, 2014 |  | December 31, 2013 |
| Net cash provided by (used in) operating activities | $ | 41,453 |  |  | $ | (4,869 | ) |
| Net cash provided by (used in) investing activities | 7,670 |  |  | (126,967 | ) |
| Net cash (used in) provided by financing activities | (30,716 | ) |  | 103,990 |  |
| Foreign currency effect on cash | (2,625 | ) |  | 347 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 15,782 |  |  | $ | (27,499 | ) |

[0001078271-15-000007:mdna:83]
Net Cash Provided by (Used In) Operating Activities

[0001078271-15-000007:mdna:84]
Cash flows provided by operations was $41.5 million in the six months ending December 31, 2014.  Current period's net loss was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation.  Accounts receivables decreased primarily due to higher collections.  Inventories decreased primarily due to the timing of inventory receipts to bring the inventory levels in line with the near term demand.  Accounts payable increased due to timing of payments.  Such increases in cash inflows offset by decreases in accrued compensation due to lower commissions and bonus accruals.

[0001078271-15-000007:mdna:85]
Cash flows used in operations was $4.9 million in the six months ending December 31, 2013.  The net loss for the period was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation.  Accounts receivables, inventory and accounts payables primarily increased due to increased activity post acquisition.

[0001078271-15-000007:mdna:86]
Net Cash Provided by (Used In) Investing Activities

[0001078271-15-000007:mdna:87]
Cash flow provided by investing activities in the six months ending December 31, 2014 was $7.7 million, primarily comprised of $4.0 million used to purchase property and equipment offset by proceeds of $3.0 million from the maturities and $9.1 million from the sale of investments.

[0001078271-15-000007:mdna:88]
Cash flow used in investing activities in the six months ending December 31, 2013 was $127.0 million, comprised of $180.0 million net cash used in the acquisition of Enterasys, purchases of investments of $9.0 million, $12.6 million used to purchase property and equipment offset by proceeds of $20.1 million from the maturities of investments and proceeds of $54.6 million from the sale of investments.

[0001078271-15-000007:mdna:89]
Net Cash (Used In) Provided by Financing Activities

[0001078271-15-000007:mdna:90]
Cash flow used in financing activities in the six months ending December 31, 2014 was $30.7 million, comprised of  $56.4 million of cash used for repayment of debt offset by a draw on the Revolving Facility of $24 million during the six months ended December 31, 2014 for working capital requirements, $1.7 million proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-15-000007:mdna:91]
Cash flow provided by financing activities in the six months ending December 31, 2013 was $104.0 million, comprised of the issuance of a Term Loan of $65.0 million and a draw on the Revolving Facility of $35 million used for the acquisition of Enterasys, $4.8 million proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards offset by $0.8 million of cash used for repayment of debt.

[0001078271-15-000007:mdna:92]
Foreign currency effect on cash

[0001078271-15-000007:mdna:93]
Foreign currency effect on cash increased in the six months ending December 31, 2014, primarily due to changes in foreign currency exchange rates between US Dollar and particularly the Euro, Great Britain Pound, Brazilian Real, Swedish Krona, Indian Rupee and Australian Dollar.

[0001078271-15-000007:mdna:94]
[same as prior period, unchanged from 0001078271-14-000064:mdna:91]

[0001078271-15-000007:mdna:95]
The following summarizes our contractual obligations at December 31, 2014, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-15-000007:mdna:96]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 89,126 |  |  | $ | 8,125 |  |  | $ | 34,938 |  |  | $ | 46,063 |  |  | $ | — |  |
| Interest on debt obligations | 7,493 |  |  | 2,540 |  |  | 3,971 |  |  | 982 |  |  | — |  |
| Non-cancellable inventory purchase commitments | 102,437 |  |  | 102,437 |  |  | — |  |  | — |  |  | — |  |
| Non-cancellable operating lease obligations | 56,194 |  |  | 9,237 |  |  | 15,501 |  |  | 13,756 |  |  | 17,700 |  |
| Other liabilities | 10,100 |  |  | 5,991 |  |  | 3,983 |  |  | 126 |  |  | — |  |
| Total contractual cash obligations | $ | 265,350 |  |  | $ | 128,330 |  |  | $ | 58,393 |  |  | $ | 60,927 |  |  | $ | 17,700 |  |

[0001078271-15-000007:mdna:97]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $102.4 million as of December 31, 2014.  We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-15-000007:mdna:98]
[same as prior period, unchanged from 0001078271-14-000064:mdna:95]

[0001078271-15-000007:mdna:99]
[same as prior period, unchanged from 0001078271-14-000064:mdna:96]

[0001078271-15-000007:mdna:100]
[same as prior period, unchanged from 0001078271-14-000064:mdna:97]

[0001078271-15-000007:mdna:101]
We did not have any material commitments for capital expenditures as of December 31, 2014.

[0001078271-15-000007:mdna:102]
[same as prior period, unchanged from 0001078271-14-000064:mdna:99]

[0001078271-15-000007:mdna:103]
We did not have any off-balance sheet arrangements as of December 31, 2014.
