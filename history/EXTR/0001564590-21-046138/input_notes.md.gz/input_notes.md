# EXTR notes — 0001564590-21-046138


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-21-046138:notes:1]
Portions of the registrant's definitive proxy statement for the year ended June 30, 2021 Annual Meeting of Stockholders to be filed with the Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated herein by reference in Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-21-046138:notes:2]
1. Description of Business and Basis of Presentation

[0001564590-21-046138:notes:3]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-21-046138:notes:4]
Fiscal Year

[0001564590-21-046138:notes:5]
The Company uses a fiscal calendar year ending on June 30.  All references herein to fiscal year ended “fiscal year ended  2021” or “2021”; “fiscal 2020” or “2020”; “fiscal 2019” or “2019” represent the fiscal years ending, respectively.

[0001564590-21-046138:notes:6]
Principles of Consolidation

[0001564590-21-046138:notes:7]
The consolidated financial statements include the accounts of Extreme Networks, Inc. and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-21-046138:notes:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end exchange rates; and revenues and expenses are translated using the monthly average rate.

[0001564590-21-046138:notes:9]
Accounting Estimates

[0001564590-21-046138:notes:10]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the financial statements and the accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-21-046138:notes:11]
2. Summary of Significant Accounting Policies

[0001564590-21-046138:notes:12]
Revenue Recognition

[0001564590-21-046138:notes:13]
The Company derives revenues primarily from sales of its networking equipment, with the remaining revenues generated from software delivered as a service (“SaaS”) and service fees relating to maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0001564590-21-046138:notes:14]
See Note 3, Revenues for further discussion.

[0001564590-21-046138:notes:15]
Cash and Cash Equivalents

[0001564590-21-046138:notes:16]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents.

[0001564590-21-046138:notes:17]
Allowance for Product Returns

[0001564590-21-046138:notes:18]
The Company maintains estimates for product returns based on its historical returns, analysis of credit memos and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is shown as a reduction of accounts receivable as there is a contractual right of offset and returns are applied to accounts receivable balances outstanding as of the balance sheet date. There have not been material revisions to the estimated product returns for any periods presented.

[0001564590-21-046138:notes:19]
Allowance for Credit Losses

[0001564590-21-046138:notes:20]
The Company maintains an allowance for credit losses which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring certain of its customers in the Asia-Pacific region to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001564590-21-046138:notes:21]
Inventories

[0001564590-21-046138:notes:22]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory is obsolete or may be in excess of anticipated demand based upon assumptions about future demand. At the point of the loss recognition, a new lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-21-046138:notes:23]
Long-Lived Assets

[0001564590-21-046138:notes:24]
Long-lived assets include (a) property and equipment, (b) operating lease right-of-use (“ROU”) assets, (c) goodwill and intangible assets, and (d) other assets. Property and equipment, ROU assets, and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001564590-21-046138:notes:25]
(a) Property and Equipment, Net

[0001564590-21-046138:notes:26]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and purchased software. Estimated useful lives of three to seven years are used for office equipment and furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms.

[0001564590-21-046138:notes:27]
(b) ROU Assets

[0001564590-21-046138:notes:28]
ROU assets under the Company’s operating leases represent the Company’s right to use an underlying asset over the lease term. The ROU asset is reduced over a straight-line or other systematic basis representative of the pattern in which the Company expects to consume the ROU assets’ future economic benefits. The ROU asset is also adjusted for leasehold improvements paid by the lessor, lease incentives, and asset impairments, among other things.

[0001564590-21-046138:notes:29]
(c) Goodwill and Intangible Assets

[0001564590-21-046138:notes:30]
Goodwill and intangible assets are generated as a result of business combinations and are comprised of, among other things, developed technology, customer relationships, trade names, and licensing agreements.

[0001564590-21-046138:notes:31]
The remaining lives of intangibles are considered regularly along with assessments of impairment and lives are adjusted or impairment charges taken when required.

[0001564590-21-046138:notes:32]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company has one reporting unit and performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceed directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Any loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. Based on the results of the goodwill impairment analyses, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0001564590-21-046138:notes:33]
Business Combinations

[0001564590-21-046138:notes:34]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, useful lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0001564590-21-046138:notes:35]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0001564590-21-046138:notes:36]
Deferred Revenue

[0001564590-21-046138:notes:37]
Deferred revenue represents amounts for (i) deferred maintenance, support, and SaaS revenues, and (ii) other deferred revenue including professional services when the revenue recognition criteria have not been met.

[0001564590-21-046138:notes:38]
Product Warranties and Guarantees

[0001564590-21-046138:notes:39]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-21-046138:notes:40]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-21-046138:notes:41]
Stock-based Compensation

[0001564590-21-046138:notes:42]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock options and share purchase options under the 2014 ESPP using the Black-Scholes-Merton option valuation model. The fair value of RSUs is based on the closing stock price of the Company’s common stock on the grant date.

[0001564590-21-046138:notes:43]
The Company grants certain employees performance-based stock options and RSUs. The performance metrics include company-wide financial performance and/or market conditions. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0001564590-21-046138:notes:44]
Advertising

[0001564590-21-046138:notes:45]
Advertising costs are expensed as incurred. Advertising expenses were immaterial in fiscal years 2021, 2020 and 2019.

[0001564590-21-046138:notes:46]
Income Taxes

[0001564590-21-046138:notes:47]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0001564590-21-046138:notes:48]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions.  The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.  For additional discussion, see Note 16, Income Taxes.

[0001564590-21-046138:notes:49]
Recently Adopted Accounting Pronouncements

[0001564590-21-046138:notes:50]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also requires lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

[0001564590-21-046138:notes:51]
The Company adopted the new standards beginning with its fiscal year 2020. Topic 842 is applied on the modified retrospective method, applying the new standard to all leases existing as of July 1, 2019. The Company adopted the new standard using the effective date of July 1, 2019 as the date of initial application. Consequently, financial information has not been updated, and disclosures required under the new standard will not be provided for dates and periods prior to July 1, 2019.

[0001564590-21-046138:notes:52]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and provides maintenance and support over a service period which is recognized under ASC Topic 606. See Note 9, Leases for additional information regarding the Company’s leases.

[0001564590-21-046138:notes:53]
On July 1, 2019, the Company recognized ROU assets of $64.6 million and corresponding lease liabilities of $79.5 million on the consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases

[0001564590-21-046138:notes:54]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 was effective for fiscal years beginning after December 15, 2019.  The Company adopted the standard on July 1, 2020 and the impact of the adoption was not material to the Company's  consolidated financial statements as credit losses are not expected to be significant based on historical collection trends, the financial condition of customers, and external market factors.

[0001564590-21-046138:notes:55]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-21-046138:notes:56]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-21-046138:notes:57]
Recently Issued Accounting Pronouncements

[0001564590-21-046138:notes:58]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company has evaluated the impact of the new standard and has determined there will not be a material impact to the Company’s consolidated financial statements or related disclosures.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001564590-21-046138:notes:59]
The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts, and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-21-046138:notes:60]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations.  In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0001564590-21-046138:notes:61]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenues from maintenance contracts and SaaS are recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to five years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales taxes collected from customers are excluded from revenues.  Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-21-046138:notes:62]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return

[0001564590-21-046138:notes:63]
certain specified amounts of inventory. Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price. At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation adjustments are an additional form of variable consideration and are estimated using the expected value method based on historical return rates based on historical return rates and estimates provided by the distributors. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-21-046138:notes:64]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using the other observable inputs.

[0001564590-21-046138:notes:65]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenue recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.

[0001564590-21-046138:notes:66]
At June 30, 2021, the Company had $345.6 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 60 percent of this amount in fiscal 2022, an additional 21 percent in fiscal 2023 and 19 percent of the balance thereafter.

[0001564590-21-046138:notes:67]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually).  The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenue.  These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-21-046138:notes:68]
Revenue recognized for the years ended June 30, 2021 and 2020, that was included in the deferred revenue balance at the beginning of each period was $188.4 million and $137.6 million, respectively.

[0001564590-21-046138:notes:69]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals, are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $13.1 million and $8.1 million at June 30, 2021 and 2020, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations.  Amortization recognized during the years ended 2021, 2020 and 2019 was $5.6 million, $5.2 million and $3.0 million, respectively.

[0001564590-21-046138:notes:70]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-21-046138:notes:71]
Disaggregation of Revenues: The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan. The following tables set forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-21-046138:notes:72]
|  |  | Year Ended June 30, 2021 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 244,851 |  |  | $ | 240,620 |  |  | $ | 485,471 |  |
| Other |  |  | 31,583 |  |  |  | 16,466 |  |  |  | 48,049 |  |
| Total Americas |  |  | 276,434 |  |  |  | 257,086 |  |  |  | 533,520 |  |
| EMEA |  |  | 250,897 |  |  |  | 136,648 |  |  |  | 387,545 |  |
| APAC |  |  | 14,280 |  |  |  | 74,073 |  |  |  | 88,353 |  |
| Total net revenues |  | $ | 541,611 |  |  | $ | 467,807 |  |  | $ | 1,009,418 |  |

[0001564590-21-046138:notes:73]
|  |  | Year Ended June 30, 2020 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 218,276 |  |  | $ | 241,493 |  |  | $ | 459,769 |  |
| Other |  |  | 19,530 |  |  |  | 20,103 |  |  |  | 39,633 |  |
| Total Americas |  |  | 237,806 |  |  |  | 261,596 |  |  |  | 499,402 |  |
| EMEA |  |  | 218,947 |  |  |  | 138,254 |  |  |  | 357,201 |  |
| APAC |  |  | 21,554 |  |  |  | 69,862 |  |  |  | 91,416 |  |
| Total net revenues |  | $ | 478,307 |  |  | $ | 469,712 |  |  | $ | 948,019 |  |

[0001564590-21-046138:notes:74]
|  |  | Year Ended June 30, 2019 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 259,873 |  |  | $ | 238,832 |  |  | $ | 498,705 |  |
| Other |  |  | 22,264 |  |  |  | 20,632 |  |  |  | 42,896 |  |
| Total Americas |  |  | 282,137 |  |  |  | 259,464 |  |  |  | 541,601 |  |
| EMEA |  |  | 229,223 |  |  |  | 129,104 |  |  |  | 358,327 |  |
| APAC |  |  | 14,598 |  |  |  | 81,263 |  |  |  | 95,861 |  |
| Total net revenues |  | $ | 525,958 |  |  | $ | 469,831 |  |  | $ | 995,789 |  |

[0001564590-21-046138:notes:75]
For the year ended June 30, 2021 the Company generated 11% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company’s net revenue for the years ended June 30, 2020 or 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-046138:notes:76]
3. Revenues

[0001564590-21-046138:notes:77]
Concentrations

[0001564590-21-046138:notes:78]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-21-046138:notes:79]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenues:

[0001564590-21-046138:notes:80]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  | 19% |  |  | 18% |  |  | 18% |  |
| Jenne Corporation |  | 18% |  |  | 15% |  |  | 17% |  |
| Westcon Group Inc. |  | 16% |  |  | 13% |  |  | 12% |  |

[0001564590-21-046138:notes:81]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable, net:

[0001564590-21-046138:notes:82]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  | 19% |  |  | 23% |  |
| Jenne Corporation |  | 24% |  |  | 25% |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-046138:notes:83]
4. Business Combinations

[0001564590-21-046138:notes:84]
The Company completed one acquisition during the fiscal year ended June 30, 2020. The acquisition was accounted for using the acquisition method of accounting. The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The purchase price of each acquisition has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach. The fair value of property and equipment was determined using a cost approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount the Company would be required to pay to a third party to assume the obligation. Intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. Results of operations of the acquired entity is included in the Company’s operations beginning with the closing date of each acquisition.

[0001564590-21-046138:notes:85]
Fiscal 2020 Acquisition

[0001564590-21-046138:notes:86]
Aerohive Acquisition

[0001564590-21-046138:notes:87]
On August 9, 2019 (the “Acquisition Date”) the Company consummated its acquisition (the “Acquisition”) of all of the outstanding common stock of Aerohive Networks, Inc. (“Aerohive”) pursuant to that certain Agreement and Plan of Merger (the “Merger Agreement”) entered into as of June 26, 2019.  Under the terms of the Acquisition, the net consideration paid by Extreme to Aerohive stockholders was $267.1 million.  The acquired assets and liabilities of Aerohive were recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets. All valuations were finalized as of June 30, 2020.

[0001564590-21-046138:notes:88]
The components of aggregate purchase consideration are as follows (in thousands):

[0001564590-21-046138:notes:89]
| Purchase consideration |  | August 9, 2019 |  |
| Cash paid to acquire outstanding shares |  | $ | 263,616 |  |
| Replacement of stock-based awards |  |  | 3,530 |  |
| Aggregate purchase consideration |  | $ | 267,146 |  |

[0001564590-21-046138:notes:90]
The purchase price allocation is set forth in the table below and reflects estimated fair values (in thousands).

[0001564590-21-046138:notes:91]
|  | Final Allocation as of June 30, 2020 |  |
| Cash and cash equivalents | $ | 44,158 |  |
| Short-term investments |  | 45,148 |  |
| Accounts receivable, net |  | 11,753 |  |
| Inventories |  | 19,232 |  |
| Prepaid expenses and other current assets |  | 3,924 |  |
| Property and equipment |  | 2,364 |  |
| Operating lease right-of-use assets |  | 6,336 |  |
| Other assets |  | 2,195 |  |
| Debt |  | (20,000 | ) |
| Accounts payable |  | (9,737 | ) |
| Accrued compensation and benefits |  | (7,129 | ) |
| Accrued warranty |  | (570 | ) |
| Other accrued liabilities |  | (1,960 | ) |
| Operating lease liabilities |  | (4,752 | ) |
| Deferred revenue |  | (68,415 | ) |
| Other liabilities |  | (483 | ) |
| Net tangible assets |  | 22,064 |  |
| Identifiable intangible assets |  | 52,500 |  |
| Goodwill |  | 192,582 |  |
| Total intangible assets acquired |  | 245,082 |  |
| Total net assets acquired | $ | 267,146 |  |

[0001564590-21-046138:notes:92]
The following table presents details of the identifiable intangible assets acquired as part of the Acquisition (dollars in thousands):

[0001564590-21-046138:notes:93]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 4 |  |  | $ | 39,100 |  |
| Backlog |  |  | 1 |  |  |  | 400 |  |
| Customer relationships |  |  | 7 |  |  |  | 11,400 |  |
| Trade names |  |  | 1 |  |  |  | 1,600 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 52,500 |  |

[0001564590-21-046138:notes:94]
The amortization for the developed technology and backlog is recorded in “Cost of revenues” for product and service and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statements of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Aerohive along with the future potential of the technology. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as the Acquisition is a nontaxable stock acquisition.

[0001564590-21-046138:notes:95]
The results of operations of Aerohive are included in the accompanying consolidated statements of operations beginning August 9, 2019.  The Aerohive revenues for the year ended June 30, 2020 were $125.1 million and were incorporated into the revenues of the Company.  Certain associated expenses of Aerohive were incorporated with the results of operations of the Company and, therefore, stand-alone operating results are not available for the year ended June 30, 2020.

[0001564590-21-046138:notes:96]
In the year ended June 30, 2020, the Company incurred acquisition and integration related expenses of $32.1 million associated with the Acquisition, including a $6.8 million compensation charge for certain Aerohive Executive stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts.  Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for terminated Aerohive employees.  Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0001564590-21-046138:notes:97]
Pro Forma Financial Information

[0001564590-21-046138:notes:98]
The following unaudited pro forma results of operations are presented as though the Acquisition had occurred as of July 1, 2018, the beginning of fiscal 2019, after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization of intangibles, acquisition and integration costs, and interest income and expense.

[0001564590-21-046138:notes:99]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2019, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-21-046138:notes:100]
The unaudited pro forma financial information for the year ended June 30, 2020 combines the historical results for Extreme for such periods, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-21-046138:notes:101]
Pro forma results of operations for the year ended June 30, 2019 combines the historical results of operations for Extreme and for Aerohive.

[0001564590-21-046138:notes:102]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0001564590-21-046138:notes:103]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Net revenues |  | $ | 962,399 |  |  | $ | 1,139,321 |  |
| Net loss |  | $ | (85,392 | ) |  | $ | (120,146 | ) |
| Net loss per share - basic and diluted |  | $ | (0.71 | ) |  | $ | (1.02 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 119,814 |  |  |  | 117,954 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-21-046138:notes:104]
5. Balance Sheet Components

[0001564590-21-046138:notes:105]
Accounts Receivable

[0001564590-21-046138:notes:106]
The following is a summary of accounts receivable (in thousands):

[0001564590-21-046138:notes:107]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Accounts receivable |  | $ | 324,343 |  |  | $ | 240,503 |  |
| Customer rebates |  |  | (149,510 | ) |  |  | (88,601 | ) |
| Allowance for credit losses |  |  | (986 | ) |  |  | (1,212 | ) |
| Allowance for product returns |  |  | (17,371 | ) |  |  | (27,963 | ) |
| Accounts receivable, net |  | $ | 156,476 |  |  | $ | 122,727 |  |

[0001564590-21-046138:notes:108]
The following table is a summary of the allowance for credit losses (in thousands):

[0001564590-21-046138:notes:109]
| Description |  | Balance at beginning of period |  |  | Provision for expected credit losses |  |  | Deductions (1) |  |  | Balance at end of period |  |
| Year Ended June 30, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 1,212 |  |  | $ | 409 |  |  | $ | (635 | ) |  | $ | 986 |  |
| Year Ended June 30, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 1,054 |  |  | $ | 1,289 |  |  | $ | (1,131 | ) |  | $ | 1,212 |  |
| Year Ended June 30, 2019: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 1,478 |  |  | $ | 1,407 |  |  | $ | (1,831 | ) |  | $ | 1,054 |  |

[0001564590-21-046138:notes:110]
|  | (1) | Uncollectible accounts written off, net of recoveries |

[0001564590-21-046138:notes:111]
The following table is a summary of the Company’s allowance for product returns (in thousands):

[0001564590-21-046138:notes:112]
| Description |  | Balance at beginning of period |  | Additions |  | Deductions |  | Balance at end of period |
| Year Ended June 30, 2021: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $27,963 |  | $67,113 |  | $(77,705) |  | $17,371 |
| Year Ended June 30, 2020: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $25,897 |  | $76,802 |  | $(74,736) |  | $27,963 |
| Year Ended June 30, 2019: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $11,266 |  | $85,190 |  | $(70,559) |  | $25,897 |

[0001564590-21-046138:notes:113]
The following is a summary of the Company’s inventory by category (in thousands):

[0001564590-21-046138:notes:114]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Finished goods |  | $ | 27,901 |  |  | $ | 52,879 |  |
| Raw materials |  |  | 4,984 |  |  |  | 9,710 |  |
| Total Inventories |  | $ | 32,885 |  |  | $ | 62,589 |  |

[0001564590-21-046138:notes:115]
Property and Equipment, Net

[0001564590-21-046138:notes:116]
The following is a summary of the Company’s property and equipment by category (in thousands):

[0001564590-21-046138:notes:117]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Computers and equipment |  | $ | 75,866 |  |  | $ | 73,244 |  |
| Purchased software |  |  | 40,037 |  |  |  | 34,015 |  |
| Office equipment, furniture and fixtures |  |  | 10,201 |  |  |  | 10,639 |  |
| Leasehold improvements |  |  | 53,329 |  |  |  | 52,317 |  |
| Total property and equipment |  |  | 179,433 |  |  |  | 170,215 |  |
| Less: accumulated depreciation and amortization |  |  | (124,429 | ) |  |  | (111,402 | ) |
| Property and equipment, net |  | $ | 55,004 |  |  | $ | 58,813 |  |

[0001564590-21-046138:notes:118]
The Company recognized depreciation expense of $23.0 million, $28.6 million, and $26.9 million related to property and equipment during the years ended 2021, 2020 and 2019, respectively.

[0001564590-21-046138:notes:119]
The following table summarizes contract liabilities which are shown as deferred revenue (in thousands):

[0001564590-21-046138:notes:120]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Deferred maintenance, support, and SaaS |  | $ | 328,797 |  |  | $ | 279,368 |  |
| Other deferred revenue |  |  | 16,787 |  |  |  | 11,819 |  |
| Total deferred revenue |  |  | 345,584 |  |  |  | 291,187 |  |
| Less: current portion |  |  | 212,412 |  |  |  | 190,226 |  |
| Non-current deferred revenue |  | $ | 133,172 |  |  | $ | 100,961 |  |

[0001564590-21-046138:notes:121]
Accrued Warranty

[0001564590-21-046138:notes:122]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0001564590-21-046138:notes:123]
|  |  |  | Year Ended |  |
|  |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Balance beginning of period |  |  | $ | 14,035 |  |  | $ | 14,779 |  |  | $ | 12,807 |  |
| Warranties assumed due to acquisitions |  |  |  | — |  |  |  | 570 |  |  |  | — |  |
| New warranties issued |  |  |  | 11,760 |  |  |  | 19,686 |  |  |  | 22,919 |  |
| Warranty expenditures |  |  |  | (14,172 | ) |  |  | (21,000 | ) |  |  | (20,947 | ) |
| Balance end of period |  |  | $ | 11,623 |  |  | $ | 14,035 |  |  | $ | 14,779 |  |

[0001564590-21-046138:notes:124]
Other Long-term Liabilities

[0001564590-21-046138:notes:125]
The following is a summary of long-term liabilities (in thousands):

[0001564590-21-046138:notes:126]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Acquisition-related deferred payments, less current portion |  | $ | 1,978 |  |  | $ | 5,847 |  |
| Other contractual obligations, less current portion |  |  | 8,553 |  |  |  | 16,722 |  |
| Other |  |  | 4,014 |  |  |  | 5,182 |  |
| Total other long-term liabilities |  | $ | 14,545 |  |  | $ | 27,751 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-046138:notes:127]
6. Fair Value Measurements

[0001564590-21-046138:notes:128]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0001564590-21-046138:notes:129]
|  | • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-21-046138:notes:130]
|  | • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-21-046138:notes:131]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value. |

[0001564590-21-046138:notes:132]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-21-046138:notes:133]
| June 30, 2021 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 560 |  |  | $ | — |  |  | $ | 560 |  |
| Interest rate swaps |  |  | — |  |  |  | 1,133 |  |  |  | — |  |  |  | 1,133 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 913 |  |  |  | 913 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,693 |  |  | $ | 913 |  |  | $ | 2,606 |  |

[0001564590-21-046138:notes:134]
| June 30, 2020 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Interest rate swaps |  |  | — |  |  |  | 1,769 |  |  |  | — |  |  |  | 1,769 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 2,167 |  |  |  | 2,167 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,777 |  |  | $ | 2,167 |  |  | $ | 3,944 |  |

[0001564590-21-046138:notes:135]
The Company’s financial instruments consist of cash, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0001564590-21-046138:notes:136]
The fair value of derivative instruments under our foreign exchange forward contracts and interest rate swaps are estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.

[0001564590-21-046138:notes:137]
As of June 30, 2021 and 2020 foreign exchange forward currency contracts not designated as hedging instruments had a notional amount of $23.0 million and $4.0 million, respectively. These contracts have maturities of less than 40 days. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income or expense. For the years ended June 30, 2021 and 2020, the net gains recorded in the consolidated statements of operations related to these contracts were $0.5 million and $0.1 million, respectively. There were no foreign exchange forward contracts at June 30, 2019. As of June 30, 2021 foreign exchange forward currency contracts designated as hedging instruments had a notional amount of $21.8 million. These contracts have maturities of less than twelve months. Gains and losses arising from contracts designated as hedging instruments are recorded as a component of accumulated other comprehensive income (loss). As of June 30, 2021, these contracts had unrealized losses of $0.2 million. There were no foreign exchange forward contracts at June 30, 2020 and June 30, 2019 that were designated as hedging instruments. See Note 14, Derivatives and Hedging for additional information.

[0001564590-21-046138:notes:138]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of June 30, 2021, the Company had entered into multiple interest rate swap contracts with the total notional amount of $200.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive income (loss). As of June 30, 2021, and 2020 these contracts had unrealized losses of $1.1 million and $1.8 million, respectively. There were no interest rate swaps outstanding at June 30, 2019. See Note 14, Derivatives and Hedging for additional information.

[0001564590-21-046138:notes:139]
The fair value of the borrowings under the Credit Agreement (as defined below) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Since the interest rate is variable in the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $346.7 million and $420.8 million as of June 30, 2021 and 2020, respectively. Such differences are immaterial for all periods presented.

[0001564590-21-046138:notes:140]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.

[0001564590-21-046138:notes:141]
At June 30, 2021 and June 30, 2020, the Company reflected one liability measured at fair value of $0.9 million and $2.2 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying consolidated statements of operations.

[0001564590-21-046138:notes:142]
The change in the acquisition-related contingent consideration obligations is as follows (in thousands):

[0001564590-21-046138:notes:143]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Beginning balance |  | $ | 2,167 |  |  | $ | 6,298 |  |  | $ | 12,749 |  |
| Payments |  |  | (1,298 | ) |  |  | (4,251 | ) |  |  | (6,695 | ) |
| Accretion on discount |  |  | 44 |  |  |  | 120 |  |  |  | 244 |  |
| Ending balance |  | $ | 913 |  |  | $ | 2,167 |  |  | $ | 6,298 |  |

[0001564590-21-046138:notes:144]
There were no transfers of assets or liabilities between Level 1, Level 2 or Level 3 during the year ended June 30, 2021 or 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-21-046138:notes:145]
7. Goodwill and Intangible Assets

[0001564590-21-046138:notes:146]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-21-046138:notes:147]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Balance at beginning of period |  | $ | 331,159 |  |  | $ | 138,577 |  |
| Additions due to acquisitions (see Note 4) |  |  | — |  |  |  | 192,582 |  |
| Balance at end of period |  | $ | 331,159 |  |  | $ | 331,159 |  |

[0001564590-21-046138:notes:148]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0001564590-21-046138:notes:149]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 1.8 years |  | $ | 156,100 |  |  | $ | 129,861 |  |  | $ | 26,239 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 54,204 |  |  |  | 8,835 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 0.7 years |  |  | 10,700 |  |  |  | 10,128 |  |  |  | 572 |  |
| License agreements |  | 5.4 years |  |  | 2,445 |  |  |  | 2,053 |  |  |  | 392 |  |
| Total intangibles, net |  |  |  | $ | 232,684 |  |  | $ | 196,646 |  |  | $ | 36,038 |  |

[0001564590-21-046138:notes:150]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 156,100 |  |  | $ | 103,806 |  |  | $ | 52,294 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 49,598 |  |  |  | 13,441 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.4 years |  |  | 10,700 |  |  |  | 8,554 |  |  |  | 2,146 |  |
| License agreements |  | 5.8 years |  |  | 2,445 |  |  |  | 1,932 |  |  |  | 513 |  |
| Other intangibles |  | — years |  |  | 1,382 |  |  |  | 1,382 |  |  |  | — |  |
| Total intangibles, net |  |  |  | $ | 234,066 |  |  | $ | 165,672 |  |  | $ | 68,394 |  |

[0001564590-21-046138:notes:151]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-21-046138:notes:152]
|  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Amortization of intangibles in “Total cost of revenues” |  | $ | 26,246 |  |  | $ | 26,793 |  |  | $ | 19,638 |  |
| Amortization of intangibles in "Operations" |  |  | 6,110 |  |  |  | 8,425 |  |  |  | 6,346 |  |
| Total amortization expense |  | $ | 32,356 |  |  | $ | 35,218 |  |  | $ | 25,984 |  |

[0001564590-21-046138:notes:153]
The amortization expense that is recognized in “Total cost of revenues” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-21-046138:notes:154]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0001564590-21-046138:notes:155]
| For the fiscal year ending: |  |  |  |  |
| 2022 |  | $ | 17,674 |  |
| 2023 |  |  | 12,278 |  |
| 2024 |  |  | 2,515 |  |
| 2025 |  |  | 1,700 |  |
| 2026 |  |  | 1,700 |  |
| Thereafter |  |  | 171 |  |
| Total |  | $ | 36,038 |  |


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-046138:notes:156]
8. Debt

[0001564590-21-046138:notes:157]
The Company’s debt is comprised of the following (in thousands):

[0001564590-21-046138:notes:158]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 26,125 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,404 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 23,721 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 320,625 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (4,760 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 315,865 |  |  |  | 394,585 |  |
| Total debt |  | $ | 339,586 |  |  | $ | 411,101 |  |

[0001564590-21-046138:notes:159]
On May 1, 2018, the Company entered into a Credit Agreement (the “2018 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as an administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The 2018 Credit Agreement provided for i) a $40 million five-year revolving credit facility (the “2018 Revolving Facility”), ii) a $190 million five-year term loan (the “2018 Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“2018 Incremental Facility”).

[0001564590-21-046138:notes:160]
In connection with the Acquisition as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-21-046138:notes:161]
The 2019 Credit Agreement, which replaced the 2018 Credit Agreement, provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-21-046138:notes:162]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-21-046138:notes:163]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-21-046138:notes:164]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5% and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-21-046138:notes:165]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-21-046138:notes:166]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve month period ended March 31, 2021 the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing its Form 10-Q for the quarterly period ended March 31, 2021.  Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the Suspension Period to 2.75%, and the unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-21-046138:notes:167]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of June 30, 2021 was 2.8% and as of June 30, 2020 was 5.6%.

[0001564590-21-046138:notes:168]
Amortization of deferred financing costs is included in “Interest expense” in the accompanying consolidated statements of operations, totaled $3.0 million, $2.5 million and $0.6 million in fiscal years ended 2021, 2020 and 2019, respectively.

[0001564590-21-046138:notes:169]
During the year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility that was outstanding as of June 30, 2020 and has no outstanding balance as of June 30, 2021. The Company has $60.2 million availability under the 2019 Revolving Facility as of June 30, 2021.

[0001564590-21-046138:notes:170]
The Company had $14.8 million of outstanding letters of credit as of June 30, 2021.

[0001564590-21-046138:notes:171]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0001564590-21-046138:notes:172]
| For the fiscal year ending: |  |  |  |  |
| 2022 |  | $ | 26,125 |  |
| 2023 |  |  | 35,625 |  |
| 2024 |  |  | 38,000 |  |
| 2025 |  |  | 247,000 |  |
| Total |  | $ | 346,750 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-21-046138:notes:173]
9. Leases

[0001564590-21-046138:notes:174]
Lessee Considerations

[0001564590-21-046138:notes:175]
The Company leases certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2028. Its leases generally have terms that range from one year to ten years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0001564590-21-046138:notes:176]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or right-of-use (“ROU”) asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate at the commencement date because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is the rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. The biggest drivers having the greatest effect determining the incremental borrowing rate for each one of the Company’s leases are term of the lease and the currency the in which the lease obligation is satisfied. Operating lease assets also included a reclassification for previous asset impairments and associated restructuring liabilities, deferred rent, lease incentives and initial direct costs which reduced the operating lease ROU assets as of July 1, 2019.

[0001564590-21-046138:notes:177]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for non-lease costs and variable lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s consolidated statements of operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0001564590-21-046138:notes:178]
Activity and other information relating to operating leases is as follows (in thousands, except for lease term and discount rate):

[0001564590-21-046138:notes:179]
|  |  | Year Ended |  |
|  |  | June 30, 2021 |  | June 30, 2020 |  |
| Operating lease costs | $ | 18,840 |  | $ | 19,600 |  |
| Variable lease costs |  |  | 6,487 |  |  | 6,176 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 22,676 |  |  | 21,064 |  |
| ROU assets obtained for new lease obligations |  | 2,162 |  |  | 3,779 |  |
| ROU assets obtained from Aerohive business combination |  | — |  |  | 6,336 |  |

[0001564590-21-046138:notes:180]
|  |  | June 30, 2021 |  | June 30, 2020 |  |
| Weighted average remaining lease term (in years) |  | 3.7 |  |  | 4.3 |  |
| Weighted Average Discount Rate |  | 4.5 | % |  | 4.5 | % |

[0001564590-21-046138:notes:181]
Short-term lease expense, which represents expense for leases with terms of one year or less, was not material for the years ended June 30, 2021 and 2020.

[0001564590-21-046138:notes:182]
The maturities of the Company’s operating lease liabilities as of June 30, 2021 by fiscal year are as follows:

[0001564590-21-046138:notes:183]
|  |  | Operating Leases (in thousands) |  |
| 2022 |  | $ | 20,541 |  |
| 2023 |  |  | 15,774 |  |
| 2024 |  |  | 6,552 |  |
| 2025 |  |  | 4,457 |  |
| 2026 |  |  | 4,313 |  |
| Thereafter |  |  | 3,951 |  |
| Total future minimum lease payments |  |  | 55,588 |  |
| Less amount representing interest |  |  | (4,330 | ) |
| Total operating lease liabilities |  | $ | 51,258 |  |
| Operating lease liabilities, current |  | $ | 18,743 |  |
| Operating lease liabilities, non-current |  | $ | 32,515 |  |

[0001564590-21-046138:notes:184]
Sublease Considerations

[0001564590-21-046138:notes:185]
The Company currently is a sublessor on several operating facility subleases that expire on various dates through fiscal 2023. The subleases have original terms ranging from two to six years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. These operating subleases include only lease components. The Company included $2.9 million and $2.5 million of sublease income in lease expense for the years ended June 30, 2021 and 2020, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-046138:notes:186]
10. Commitments and Contingencies

[0001564590-21-046138:notes:187]
Purchase Commitments

[0001564590-21-046138:notes:188]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2021, the Company had non-cancelable commitments to purchase $38.2 million of inventory and other services, which will be received and consumed during fiscal 2022. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0001564590-21-046138:notes:189]
Legal Proceedings

[0001564590-21-046138:notes:190]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-21-046138:notes:191]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any

[0001564590-21-046138:notes:192]
reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-21-046138:notes:193]
All currency conversions in this Legal Proceedings section are as of June 30, 2021.

[0001564590-21-046138:notes:194]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-21-046138:notes:195]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. patent based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The stay issued by the District Court in 2018 has been lifted.

[0001564590-21-046138:notes:196]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-21-046138:notes:197]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0001564590-21-046138:notes:198]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment.  The Company has filed a request with the Court to suspend enforcement of the judgment. The matter is proceeding through the appellate process.

[0001564590-21-046138:notes:199]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019. Both cases were filed in the Federal Patent Court in Munich and seek to invalidate the asserted patents. Both nullity actions are proceeding.

[0001564590-21-046138:notes:200]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-21-046138:notes:201]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending.

[0001564590-21-046138:notes:202]
Mala Technologies Ltd. v. Extreme Networks, Inc., Extreme Networks GmbH, and Extreme Networks Ireland Ltd.  On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.

[0001564590-21-046138:notes:203]
Indemnification Obligations

[0001564590-21-046138:notes:204]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-21-046138:notes:205]
11. Stockholders’ Equity

[0001564590-21-046138:notes:206]
Preferred Stock

[0001564590-21-046138:notes:207]
In April 2001, in connection with entering into the Company’s Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors (the “Board”) is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2021, no shares of preferred stock were outstanding.

[0001564590-21-046138:notes:208]
Stockholders’ Rights Agreement

[0001564590-21-046138:notes:209]
On April 26, 2012, the Company entered into the “Restated Rights Plan. The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0001564590-21-046138:notes:210]
The Company’s Board of Directors adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. From 2013 through 2020, the Board and stockholders approved amendments providing for one-year extensions of the term of the Restated Rights Plan.  On May 17, 2021, the Board unanimously approved the 2021 Tax Benefit Preservation Plan, which amends and restates the Restated Rights Plan with a term that expires  on  May 17, 2024, subject to approval by the stockholders of the Company at the annual meeting of stockholders on November 4, 2021.

[0001564590-21-046138:notes:211]
Equity Incentive Plan

[0001564590-21-046138:notes:212]
The Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan to increase the maximum number of available shares by 7.0 million shares.  The amendment was ratified by a majority of the stockholders at the Company’s annual meeting of stockholders held on November 7, 2019.

[0001564590-21-046138:notes:213]
Employee Stock Purchase Plan

[0001564590-21-046138:notes:214]
The Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares.  The amendment was ratified by a majority of the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018.

[0001564590-21-046138:notes:215]
Common Stock Repurchases

[0001564590-21-046138:notes:216]
On November 2, 2018, the Company announced that the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions.    In February 2020, the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020.  A maximum of $30.0 million may be repurchased in any calendar year.

[0001564590-21-046138:notes:217]
In fiscal 2020, the Company entered into an accelerated share repurchase agreement (the “November 2019 ASR”) to repurchase shares of the Company’s common stock.  Pursuant to the November 2019 ASR, the Company paid $30.0 million for 4.2 million shares at an average cash purchase price paid of $7.09. There were no shares repurchased during the year ended June 30, 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-046138:notes:218]
12. Employee Benefit Plans

[0001564590-21-046138:notes:219]
As of June 30, 2021, the Company has the following share-based compensation plans:

[0001564590-21-046138:notes:220]
2013 Equity Incentive Plan

[0001564590-21-046138:notes:221]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, up to 12.7 million shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan.  The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting.  During the fiscal year ended 2020 an additional 7.0 million shares were authorized and made available for grant under the 2013 Plan. As of June 30, 2021, total options and awards to acquire 10.3 million shares were outstanding under the 2013 Plan and 6.8 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0001564590-21-046138:notes:222]
Aerohive 2014 Equity Incentive Plan

[0001564590-21-046138:notes:223]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the “Aerohive Plan”).  Stock awards outstanding under the Aerohive Plan were converted into awards for Extreme shares as of the Acquisition Date at a predetermined rate pursuant to the Merger Agreement.  As of  June 30, 2021, total awards to acquire 0.05 million shares of Extreme common stock were outstanding under the Aerohive Plan.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0001564590-21-046138:notes:224]
Shares Reserved for Issuance

[0001564590-21-046138:notes:225]
The following are shares reserved for issuance (in thousands):

[0001564590-21-046138:notes:226]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 6,753 |  |  |  | 13,118 |  |
| Employee stock options and awards outstanding |  |  | 10,359 |  |  |  | 10,396 |  |
| 2014 Employee Stock Purchase Plan |  |  | 4,414 |  |  |  | 7,364 |  |
| Total shares reserved for issuance |  |  | 21,526 |  |  |  | 30,878 |  |

[0001564590-21-046138:notes:227]
Stock Options

[0001564590-21-046138:notes:228]
The following table summarizes stock option activity under all plans (shares and intrinsic value in thousands):

[0001564590-21-046138:notes:229]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2020 |  |  | 2,922 |  |  | $ | 4.95 |  |  |  | 3.09 |  |  | $ | 1,688 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (622 | ) |  |  | 3.21 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (655 | ) |  |  | 5.39 |  |  |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2021 |  |  | 1,645 |  |  | $ | 5.44 |  |  |  | 3.62 |  |  | $ | 9,404 |  |
| Vested and expected to vest at June 30, 2021 |  |  | 1,645 |  |  | $ | 5.44 |  |  |  | 3.62 |  |  | $ | 9,404 |  |
| Exercisable at June 30, 2021 |  |  | 1,241 |  |  | $ | 5.04 |  |  |  | 3.16 |  |  | $ | 7,588 |  |

[0001564590-21-046138:notes:230]
The total intrinsic value of options exercised in fiscal years 2021, 2020 and 2019 was $3.9 million, $0.6 million and $0.8 million, respectively.

[0001564590-21-046138:notes:231]
The weighted average estimated fair value of stock options granted in fiscal year 2020 was $3.52. The weighted average estimated fair value of stock options granted in fiscal year 2019 was $2.62 per share.  As of June 30, 2021, there was $1.2 million of total unrecognized compensation cost related to unvested stock options that will be recognized over a weighted-average period of 1.9 years.

[0001564590-21-046138:notes:232]
Stock Options – Performance Stock Options

[0001564590-21-046138:notes:233]
During the first quarter of fiscal 2019, the Company granted 851,700 Performance Stock Options (“PSOs”) to certain officers and executive vice presidents that will vest if the Company’s stock price achieves a price hurdle of $10.00 during the three-year performance period from August 29, 2018 through August 31, 2021. The price hurdle will be deemed to have been achieved if, at any time over the performance period, the Company’s stock maintains a price of $10.00 for 30 consecutive days.  If the price hurdle is achieved, the PSOs will vest (ratably based upon the time elapsed between August 31, 2018 and the date the hurdle is met) and the remainder will vest quarterly through August 31, 2021.  The grant date fair value of these PSOs was $2.62.

[0001564590-21-046138:notes:234]
During the fourth quarter of fiscal 2021, the price hurdle was achieved and 550,300 PSOs remain outstanding as of June 30, 2021.

[0001564590-21-046138:notes:235]
Stock Awards

[0001564590-21-046138:notes:236]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (“RSUs”), including performance-based or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the award’s intrinsic value as of the date of grant.

[0001564590-21-046138:notes:237]
The following table summarizes stock award activity (shares and market value in thousands):

[0001564590-21-046138:notes:238]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2020 |  |  | 7,474 |  |  | $ | 6.83 |  |  |  |  |  |
| Granted |  |  | 6,367 |  |  |  | 5.16 |  |  |  |  |  |
| Released |  |  | (3,909 | ) |  |  | 6.86 |  |  |  |  |  |
| Cancelled |  |  | (1,218 | ) |  |  | 7.58 |  |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2021 |  |  | 8,714 |  |  | $ | 5.51 |  |  | $ | 97,252 |  |
| Stock awards expected to vest at June 30, 2021 |  |  | 8,714 |  |  | $ | 5.51 |  |  | $ | 97,252 |  |

[0001564590-21-046138:notes:239]
The RSU's granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company.

[0001564590-21-046138:notes:240]
The aggregate fair value, as of the respective grant dates of awards granted during the years ended 2021, 2020 and 2019 was $32.9 million, $45.9 million and $30.0 million, respectively.

[0001564590-21-046138:notes:241]
For each of the fiscal years ended 2021, 2020 and 2019, the Company withheld an aggregate of 1.3 million shares upon the vesting of awards, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0001564590-21-046138:notes:242]
For fiscal years ended 2021, 2020 and 2019, the Company remitted cash of $9.2 million, $8.0 million and $8.4 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0001564590-21-046138:notes:243]
As of June 30, 2021, there was $32.7 million in unrecognized compensation costs related to non-vested stock awards which includes the performance and market condition awards as discussed below. This cost is expected to be recognized over a weighted-average period of 1.4 years.

[0001564590-21-046138:notes:244]
Stock Awards - Fiscal 2021

[0001564590-21-046138:notes:245]
RSUs granted during fiscal 2021to named executive officers and directors totaled 1.6 million awards which included awards with market conditions as discussed below.

[0001564590-21-046138:notes:246]
On July 27, 2020, the Compensation Committee of the Board granted 0.5 million RSUs with vesting based on market conditions (“MSU”) to certain of the Company’s named executive officers. These MSUs will vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods from August 15, 2020 through August 15, 2023, subject to the grantees’ continued service through the certification of performance.

[0001564590-21-046138:notes:247]
| Level | Relative TSR | Shares Vested |  |
| Below Threshold | TSR is less than the Index by more than 37.5 percentage points | 0% |  |
| Threshold | TSR is less than the Index by 37.5 percentage points | 25% |  |
| Target | TSR equals the Index | 100% |  |
| Maximum | TSR is greater than the Index by 25 percentage points or more | 150% |  |

[0001564590-21-046138:notes:248]
Total shareholder return is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years 1 and 2 and the ability for up to the maximum of the full award to vest based on the full 3-year TSR less any shares vested based on 1- and 2- year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0001564590-21-046138:notes:249]
The grant date fair value of each MSU was determined using the Monte-Carlo simulation model. The weighted-average grant-date fair value of these MSU was $5.32. The assumptions used in the Monte-Carlo simulation included the expected volatility of 69%, risk-free rate of 0.18%, no expected dividend yield, expected term of 3 years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0001564590-21-046138:notes:250]
Stock Awards - Fiscal 2020

[0001564590-21-046138:notes:251]
RSUs granted during fiscal 2020 included 0.6 million RSUs to named executive officers and directors.

[0001564590-21-046138:notes:252]
Stock Awards - Fiscal 2019 and 2018

[0001564590-21-046138:notes:253]
During fiscal 2019 and 2018, the Company approved the grant of 0.6 million shares underlying stock awards each year in the form of restricted stock units with certain performance conditions (“PSUs”) to named executive officers and other vice president level employees. These PSUs would vest once the Company’s earnings as determined under U.S. generally accepted accounting principles aggregates at least $0.09 per share over two consecutive quarters exclusive of the PSU related share-based compensation expense (the “Performance Thresholds”). Upon satisfying the Performance Thresholds, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter will vest on the same schedule as the RSUs, subject to continued service to the Company.  The PSUs will expire if the Performance Thresholds are not met by the third anniversary of their respective grant dates.  The PSUs issued in fiscal 2018 expired in August 2020 without achieving the Performance Threshold.   During the year ended June 30, 2021, the Performance Threshold for outstanding PSUs issued in fiscal 2019 were achieved and, the Company recorded $2.7 million compensation expense related to these PSU’s.

[0001564590-21-046138:notes:254]
Stock Awards - Performance Grant Activity

[0001564590-21-046138:notes:255]
The following table summarizes PSU’s with market or performance-based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0001564590-21-046138:notes:256]
|  |  | Fiscal year 2021 |  |  | Fiscal year 2020 |  |  | Fiscal year 2019 |  |
| Performance awards granted |  |  | 475 |  |  |  | — |  |  |  | 635 |  |
| Performance awards earned |  |  | — |  |  |  | 56 |  |  |  | 342 |  |

[0001564590-21-046138:notes:257]
2014 Employee Stock Purchase Plan

[0001564590-21-046138:notes:258]
On August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. The Board of Directors unanimously approved an amendment to the 2014 ESPP to increase the maximum number of shares that will be available for sale by 7.5 million shares which was ratified by the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018. The 2014 ESPP replaced the 1999 Employee Stock Purchase Plan. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period had a maximum duration of six months. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.

[0001564590-21-046138:notes:259]
During the fiscal years ended June 30, 2021 and 2020, there were 2.9 million and 2.7 million shares issued under the 2014 ESPP.  As of June 30, 2021, there have been an aggregate 15.1 million shares issued under the 2014 ESPP.

[0001564590-21-046138:notes:260]
Effective with the offering period beginning on February 1, 2016, the Company amended the 2014 ESPP to increase the maximum shares issuable for each purchase period from 1.0 million shares to 1.5 million shares. Effective with the offering period beginning on August 1, 2016, the Company amended the 2014 ESPP so that all future offering periods are limited to six months and to make certain other changes to the 2014 ESPP including adding new contribution limits for each offering period.

[0001564590-21-046138:notes:261]
Share-Based Compensation Expense

[0001564590-21-046138:notes:262]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (in thousands):

[0001564590-21-046138:notes:263]
|  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Cost of product revenues |  | $ | 1,209 |  |  | $ | 1,240 |  |  | $ | 844 |  |
| Cost of service and subscription revenues |  |  | 1,662 |  |  |  | 1,620 |  |  |  | 1,639 |  |
| Research and development |  |  | 9,969 |  |  |  | 10,324 |  |  |  | 10,443 |  |
| Sales and marketing |  |  | 12,505 |  |  |  | 11,914 |  |  |  | 11,747 |  |
| General and administrative |  |  | 13,706 |  |  |  | 12,265 |  |  |  | 8,224 |  |
| Integration costs |  |  | — |  |  |  | 479 |  |  |  | — |  |
| Total share-based compensation expense |  | $ | 39,051 |  |  | $ | 37,842 |  |  | $ | 32,897 |  |

[0001564590-21-046138:notes:264]
The Company uses the straight-line method for expense attribution, other than for the PSUs and MSU’s, which may use  the accelerated attribution method. The Company does not estimate forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur.

[0001564590-21-046138:notes:265]
The fair value of each stock option grant under the Company’s 2013 Plan is estimated on the date of grant that uses the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-21-046138:notes:266]
The fair value of each RSU grant with market-based vesting criteria under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-21-046138:notes:267]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP shares is the offering period for each purchase. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-21-046138:notes:268]
The weighted-average estimated per share fair value of shares purchased under the 2014 ESPP in fiscal years 2021, 2020 and 2019, was $2.47, $1.90 and $2.71, respectively.

[0001564590-21-046138:notes:269]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 0.09 | % |  |  | 1.71 | % |  | 2.22%-2.46% |  |
| Volatility |  |  | 95 | % |  |  | 43 | % |  |  | 70 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-21-046138:notes:270]
401(k) Plan

[0001564590-21-046138:notes:271]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $19,500 for calendar year 2021. Employees age 50 or over may elect to contribute an additional $6,500. The amount contributed to the Plan is on a pre-tax basis.

[0001564590-21-046138:notes:272]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately.  In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. The program effective during fiscal 2021 was established to match $0.50 for every Dollar contributed by the employee up to the first 5.0% of pay. The Company’s matching contributions to the Plan totaled $4.2 million, $3.2 million and $4.2 million, for fiscal years ended 2021, 2020 and 2019, respectively. No discretionary contributions were made in fiscal years ended 2021, 2020 and 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-046138:notes:273]
13. Information about Segments of Geographic Areas

[0001564590-21-046138:notes:274]
The Company operates in one segment, which develops and markets network infrastructure equipment.  Revenues are attributed to a geographical area based on the location of the customers.  The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan.  The Company’s chief operating decision maker (“CODM”), who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-21-046138:notes:275]
See Note 3. Revenues for the Company’s revenues by geographic regions and channel based on the customers’ billing address.

[0001564590-21-046138:notes:276]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-21-046138:notes:277]
| Long-lived Assets |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Americas |  | $ | 151,839 |  |  | $ | 177,443 |  |
| EMEA |  |  | 25,940 |  |  |  | 39,477 |  |
| APAC |  |  | 13,560 |  |  |  | 16,802 |  |
| Total long-lived assets |  | $ | 191,339 |  |  | $ | 233,722 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-21-046138:notes:278]
14. Derivatives and Hedging

[0001564590-21-046138:notes:279]
Interest Rate Swaps

[0001564590-21-046138:notes:280]
The Company is exposed to interest rate risk on its debt. The Company enters into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which has floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0001564590-21-046138:notes:281]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly

[0001564590-21-046138:notes:282]
effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive income (loss) and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0001564590-21-046138:notes:283]
During the fiscal year ended June 30, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt.  As of June 30, 2021 and June 30, 2020, the total notional amount of these interest rate swaps were $200.0 million and had maturity dates through April 2023. As of June 30, 2021 and June 30, 2020, these contracts had unrealized losses of $1.1 million and $1.8 million, respectively, which are recorded in accumulated other comprehensive income (loss) with the associated liability in “Other accrued liabilities” in the accompanying consolidated balance sheets. The Company did not have any interest rate swaps as of June 30, 2019. Realized gains and losses are recognized as incurred into interest expense. Amounts reported in accumulated other comprehensive income related to these cash flow hedges will be reclassified to interest expense over the life of the swap contracts. The Company estimates that $0.9 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measures.

[0001564590-21-046138:notes:284]
Foreign Exchange Forward Contracts

[0001564590-21-046138:notes:285]
The Company uses derivative financial instruments to manage exposures to foreign currency that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies.

[0001564590-21-046138:notes:286]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying consolidated statements of operations. As of June 30, 2021 and 2020 foreign exchange forward currency contracts not designated as hedging instruments had the total notional amount of $23.0 million and $4.0 million, respectively. At June 30, 2019 the Company did not have any foreign exchange forward contracts. These contracts had maturities of less than 40 days. For the years ended June 30, 2021 and 2020, the net gains recorded in the consolidated statement of operations from these contracts were $0.5 million and $0.1 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001564590-21-046138:notes:287]
For foreign exchange forward contracts designated as hedging instruments, gains and losses arising from these contracts are recorded as a component of accumulated other comprehensive income (loss) on the consolidated balance sheets. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect our earnings. As of June 30, 2021 foreign exchange forward contracts designated as hedging instruments had the notional amount of $21.8 million. These contracts have maturities of less than twelve months. As of June 30, 2021, these contracts had unrealized losses of $0.2 million which are recorded in accumulated other comprehensive income (loss) with the associated liability in other accrued liabilities in the accompanying consolidated balance sheets. There were no foreign exchange forward contracts at June 30, 2020 and June 30, 2019 that were designated as hedging instruments.

[0001564590-21-046138:notes:288]
Foreign currency transaction gains and losses from operations was a loss of $2.2 million in fiscal year ended June 30, 2021 and gains of $0.6 million and $0.1 million in the fiscal years 2020 and 2019.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-046138:notes:289]
15. Restructuring, Impairments, and Related Charges

[0001564590-21-046138:notes:290]
As of June 30, 2021 and June 30, 2020, restructuring liabilities were $0.3 million and $2.2 million, respectively, which are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. The restructuring liabilities consist of obligations pertaining to the estimated future obligations for non-cancelable lease payments and severance and benefits obligations through June 30, 2019 and only severance, benefits and other related obligations subsequent to the adoption of ASU 2016-02 Leases (Topic 842) on July 1, 2019.  During years ended 2021, 2020 and 2019, the Company recorded restructuring, impairments and related charges of $2.6 million, $22.0 million and $5.1 million, respectively. The charges are reflected in “Restructuring and related charges” in the consolidated statements of operations.

[0001564590-21-046138:notes:291]
2021 Restructuring

[0001564590-21-046138:notes:292]
During fiscal 2021, the Company continued its cost reduction initiative begun in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of  $1.5 million, related to the 2020 Plan.  In addition, the Company incurred facility-related charges of $1.1 million, related to previously impaired facilities. Severance and benefits charges consisted primarily of additional employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”). With the reduction and realignment of the headcount under the 2020 Plan, the Company is relocating certain of its lab equipment to third-party consulting companies. The Company has incurred $9.6 million of charges under the 2020 Plan through June 30, 2021. The Company expects to incur additional equipment related relocation expenses of $0.5 million and expects to substantially complete these activities by the first half of fiscal 2022. The facility restructuring charges included additional facilities expenses related to previously impaired facilities.

[0001564590-21-046138:notes:293]
2020 Restructuring and Impairment

[0001564590-21-046138:notes:294]
During fiscal 2020, the Company moved to reduce its operating expenses by exiting a floor in its San Jose, California facility and consolidating its workforce.  Also, the Company exited additional space in its Salem, New Hampshire facility, which includes general office and lab space. The Company continued its initiative to realign its operations resulting from the acquisition of Aerohive and consolidating its workforce and exiting the facility it acquired from Aerohive in Milpitas, California which includes general office and lab space.  The Company had the intent and ability to sub-lease these facilities which it had ceased using and as such, had considered estimated future sub-lease income based on its existing lease agreements, as well as the local real estate market conditions, in measuring the amount of asset impairment. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.

[0001564590-21-046138:notes:295]
With the global disruptions and slow-down in the demand of its products caused by the global pandemic outbreak, COVID-19, and the uncertainty around the timing of the recovery of the market, the Company initiated a reduction-in-force plan (the 2020 Plan) to reduce its operating costs and enhance financial flexibility. The plan affected approximately 320 employees primarily from the research and development and sales organizations who were located mainly in the U.S. and India. The Company recorded restructuring charges of $8.1 million during the fiscal year ended June 30, 2020 related to the 2020 Plan. The Company incurred additional charges related to this 2020 Plan through the first quarter of fiscal 2021, which primarily included employee severance and benefit expenses. The Company recorded additional severance and benefits charges of $5.4 million for the fiscal year ended June 30, 2020 related to the previous year’s restructuring plans.  In total the Company incurred $13.5 million in restructuring charges for the year ended June 30, 2020 which were all severance and benefit related. In addition, the Company recorded facility impairment related charges of $8.5 million for the fiscal year ended June 30, 2020 which included $6.7 million for the impairment of ROU assets as referenced in the preceding paragraph, $0.9 million for impairment of long-lived assets, and $0.9 million of other charges related to previously impaired facilities.

[0001564590-21-046138:notes:296]
2019 Restructuring and Impairment

[0001564590-21-046138:notes:297]
The Company recorded a total of $5.1 million in restructuring and impairment charges during the year ended June 30, 2019. A reduction-in-force in its fourth fiscal quarter of fiscal 2019 was announced to better align its work force and operating expenses. Costs associated with the 2019 Plan are primarily comprised of employee severance and benefits expenses, relocation of personnel and equipment and exit of excess facilities. The Company recorded $3.7 million related to employee severance and benefits expenses during the year ended June 30, 2019 under the 2019 Plan. Also, $1.1 million of additional charges related to continuation of earlier actions associated with a reduction-in-force in the fourth quarter of fiscal 2018. The Company also incurred charges of $0.3 million for changes to its estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of its excess facilities.

[0001564590-21-046138:notes:298]
Restructuring liabilities consist of (in thousands):

[0001564590-21-046138:notes:299]
|  |  | Excess Facilities |  |  | Severance and Other |  |  | Total |  |
| Balance as of June 30, 2018 |  | $ | 1,797 |  |  | $ | 4,658 |  |  | $ | 6,455 |  |
| Period charges |  |  | 254 |  |  |  | 5,274 |  |  |  | 5,528 |  |
| Period reversals |  |  | — |  |  |  | (438 | ) |  |  | (438 | ) |
| Period payments |  |  | (287 | ) |  |  | (5,935 | ) |  |  | (6,222 | ) |
| Balance as of June 30, 2019 |  | $ | 1,764 |  |  | $ | 3,559 |  |  | $ | 5,323 |  |
| Period charges |  |  | — |  |  |  | 14,875 |  |  |  | 14,875 |  |
| Period reversals |  |  | — |  |  |  | (1,369 | ) |  |  | (1,369 | ) |
| Reclassification to reduce operating lease assets |  |  | (1,764 | ) |  |  | — |  |  |  | (1,764 | ) |
| Period payments |  |  | — |  |  |  | (14,846 | ) |  |  | (14,846 | ) |
| Balance at June 30, 2020 |  | $ | — |  |  | $ | 2,219 |  |  | $ | 2,219 |  |
| Period charges |  |  | — |  |  |  | 1,597 |  |  |  | 1,597 |  |
| Period reversals |  |  | — |  |  |  | (128 | ) |  |  | (128 | ) |
| Period payments |  |  | — |  |  |  | (3,417 | ) |  |  | (3,417 | ) |
| Balance at June 30, 2021 |  | $ | — |  |  | $ | 271 |  |  | $ | 271 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-046138:notes:300]
16. Income Taxes

[0001564590-21-046138:notes:301]
Income (loss) before income taxes is as follows (in thousands):

[0001564590-21-046138:notes:302]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | (4,194 | ) |  | $ | (143,651 | ) |  | $ | 22,330 |  |
| Foreign |  |  | 14,379 |  |  |  | 23,159 |  |  |  | (48,204 | ) |
| Income (loss) before income taxes |  | $ | 10,185 |  |  | $ | (120,492 | ) |  | $ | (25,874 | ) |

[0001564590-21-046138:notes:303]
The provision (benefit) for income taxes for the years ended 2021, 2020 and 2019 consisted of the following (in thousands):

[0001564590-21-046138:notes:304]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | — |  |  | $ | (22 | ) |  | $ | — |  |
| State |  |  | 1,160 |  |  |  | 256 |  |  |  | 655 |  |
| Foreign |  |  | 5,334 |  |  |  | 4,597 |  |  |  | 5,100 |  |
| Total current |  |  | 6,494 |  |  |  | 4,831 |  |  |  | 5,755 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 324 |  |  |  | 333 |  |  |  | (3,691 | ) |
| State |  |  | 1,169 |  |  |  | 44 |  |  |  | (488 | ) |
| Foreign |  |  | 262 |  |  |  | 1,145 |  |  |  | (1,597 | ) |
| Total deferred |  |  | 1,755 |  |  |  | 1,522 |  |  |  | (5,776 | ) |
| Provision (benefit) for income taxes |  | $ | 8,249 |  |  | $ | 6,353 |  |  | $ | (21 | ) |

[0001564590-21-046138:notes:305]
The difference between the provision (benefit) for income taxes and the amount computed by applying the federal statutory income tax rate (21 percent) to income (loss) before income taxes is explained below (in thousands):

[0001564590-21-046138:notes:306]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Tax at federal statutory rate |  | $ | 2,139 |  |  | $ | (25,303 | ) |  | $ | (5,433 | ) |
| State income tax, net of federal benefit |  |  | 917 |  |  |  | 202 |  |  |  | 517 |  |
| Release of foreign valuation allowance |  |  | — |  |  |  | — |  |  |  | (2,794 | ) |
| Release of US valuation allowance – Tax reform |  |  | — |  |  |  | — |  |  |  | (4,680 | ) |
| Establishment of Irish valuation allowance |  |  | — |  |  |  | — |  |  |  | 8,642 |  |
| US valuation allowance change – deferred tax movement |  |  | (9,387 | ) |  |  | 2,414 |  |  |  | (4,444 | ) |
| Research and development credits |  |  | (2,423 | ) |  |  | (4,947 | ) |  |  | (6,598 | ) |
| Tax impact of foreign earnings |  |  | 11,979 |  |  |  | 6,925 |  |  |  | 9,817 |  |
| Foreign withholding taxes |  |  | 828 |  |  |  | 762 |  |  |  | 745 |  |
| Stock based compensation |  |  | 1,162 |  |  |  | 4,349 |  |  |  | 2,436 |  |
| Goodwill amortization |  |  | 1,467 |  |  |  | 331 |  |  |  | 834 |  |
| Nondeductible officer compensation |  |  | 1,496 |  |  |  | 862 |  |  |  | 713 |  |
| Nondeductible meals and entertainment |  |  | 71 |  |  |  | 364 |  |  |  | 517 |  |
| AMT credit monetization |  |  | — |  |  |  | (22 | ) |  |  | — |  |
| Gain on transfer of intellectual property ("IP") |  |  | — |  |  |  | 19,819 |  |  |  | — |  |
| Other |  |  | — |  |  |  | 597 |  |  |  | (293 | ) |
| Provision (benefit) for income taxes |  | $ | 8,249 |  |  | $ | 6,353 |  |  | $ | (21 | ) |

[0001564590-21-046138:notes:307]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001564590-21-046138:notes:308]
|  |  | June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2019 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 69,126 |  |  | $ | 74,548 |  |  | $ | 36,514 |  |
| Tax credit carry-forwards |  |  | 68,003 |  |  |  | 67,364 |  |  |  | 54,745 |  |
| Depreciation |  |  | 3,113 |  |  |  | 2,755 |  |  |  | 2,168 |  |
| Intangible amortization |  |  | 35,340 |  |  |  | 32,642 |  |  |  | 36,882 |  |
| Deferred revenue |  |  | 11,625 |  |  |  | 7,610 |  |  |  | 1,887 |  |
| Inventory write-downs |  |  | 14,501 |  |  |  | 13,014 |  |  |  | 10,277 |  |
| Other allowances and accruals |  |  | 28,899 |  |  |  | 32,318 |  |  |  | 30,210 |  |
| Stock based compensation |  |  | 2,792 |  |  |  | 3,169 |  |  |  | 4,114 |  |
| Deferred intercompany gain |  |  | 3,693 |  |  |  | 3,693 |  |  |  | 3,693 |  |
| Ireland goodwill amortization |  |  | 6,303 |  |  |  | 7,132 |  |  |  | — |  |
| Other |  |  | 1,175 |  |  |  | 888 |  |  |  | 673 |  |
| Total deferred tax assets |  |  | 244,570 |  |  |  | 245,133 |  |  |  | 181,163 |  |
| Valuation allowance |  |  | (230,588 | ) |  |  | (232,862 | ) |  |  | (169,343 | ) |
| Total net deferred tax assets |  |  | 13,982 |  |  |  | 12,271 |  |  |  | 11,820 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill amortization |  |  | (8,575 | ) |  |  | (6,691 | ) |  |  | (4,904 | ) |
| Prepaid commissions |  |  | (3,166 | ) |  |  | (1,958 | ) |  |  | (1,585 | ) |
| Deferred tax liability on foreign withholdings |  |  | (578 | ) |  |  | (551 | ) |  |  | (505 | ) |
| Total deferred tax liabilities |  |  | (12,319 | ) |  |  | (9,200 | ) |  |  | (6,994 | ) |
| Net deferred tax assets |  | $ | 1,663 |  |  | $ | 3,071 |  |  | $ | 4,826 |  |
| Recorded as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net non-current deferred tax assets |  |  | 5,491 |  |  |  | 5,405 |  |  |  | 6,783 |  |
| Net non-current deferred tax liabilities |  |  | (3,828 | ) |  |  | (2,334 | ) |  |  | (1,957 | ) |
| Net deferred tax assets |  | $ | 1,663 |  |  | $ | 3,071 |  |  | $ | 4,826 |  |

[0001564590-21-046138:notes:309]
The Company’s global valuation allowance decreased by $2.2 million in the fiscal year ended June 30, 2021 and increased by $63.5 million in the fiscal year ended June 30, 2020. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against certain non-U.S. deferred tax assets in Ireland and Brazil.  The valuation allowance is determined by assessing both negative and positive available evidence to determine whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years and the cyclical nature of the Company's business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001564590-21-046138:notes:310]
As of June 30, 2021, the Company had net operating loss carry-forwards (“NOLs”) for U.S. federal and state tax purposes of $242.0 million and $156.2 million, respectively.  As of June 30, 2021, the Company also had foreign net operating loss carry-forwards in Ireland, Australia and Brazil of $17.2 million, $7.7 million and $14.7 million, respectively.  As of June 30, 2021, the Company also had federal and state tax credit carry-forwards of $42.8 million and $31.9 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits.  Of the $242.0 million U.S. federal net operating loss carry-forwards, $144.9 million will begin to expire in the fiscal year ending June 30, 2033 and $97.1 million have an indefinite carryforward life. The state net operating losses of $156.2 million will begin to partially expire in the fiscal year ending June 30, 2022. The foreign net operating losses can generally be carried forward indefinitely.  Federal research and development tax credits of $33.7 million will expire beginning in fiscal 2022, if not utilized and foreign tax credits of $9.1 million will expire beginning in fiscal 2022.  North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2024, if not utilized. California state research and development tax credits of $31.0 million do not expire and can be carried forward indefinitely.

[0001564590-21-046138:notes:311]
In October 2020, the Company performed an analysis under Section 382 of the Internal Revenue Code (“IRC”)  with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of these U.S. tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2020, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes. The Company also performed in June 2020 a separate IRC section 382 analysis with respect to the NOLs and tax credits acquired from Aerohive and have determined that while the Company will be subject to an annual limitation, the Company should not be limited on the full utilization of the losses and credits during the statutory allowable carryforward period for the NOLs and credits.

[0001564590-21-046138:notes:312]
As of June 30, 2021, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $29.1 million.  It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the U.S. The Company has reviewed its prior position on the reinvestment of earnings of certain foreign subsidiaries and has recorded a deferred tax liability of $0.6 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential tax associated with repatriation of these earnings as well as the deemed repatriation related to U.S. tax reform enacted in 2017 is $5.3 million.

[0001564590-21-046138:notes:313]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business, the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire, Texas and North Carolina. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years ended June 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years ended June 2000 forward due to net operating losses. Statutes related to material foreign jurisdictions are generally open for fiscal years ended June 2017 forward for Ireland and for tax year ended March 2018 forward for India.

[0001564590-21-046138:notes:314]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in the United States.  The CARES Act, among other things, includes modifications to net operating loss carryforward provisions and net interest expense deductions, and allows deferment of employer social security tax payments.  The Company evaluated the provisions of the CARES Act and how certain elections may impact our financial position and results of operations, and have determined the enactment of the CARES Act did not have a material impact to the income tax provision for the fiscal year ended June 30, 2020, or to the net deferred tax assets as of June 30, 2020.

[0001564590-21-046138:notes:315]
The U.S. tax rules require U.S. tax on foreign earnings, known as Global Intangible Low Taxed Income (“GILTI”).  Under U.S. GAAP, taxpayers are allowed to make an accounting policy election of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred under the period cost method.

[0001564590-21-046138:notes:316]
On August 9, 2019, the Company completed its acquisition of Aerohive. This acquisition was treated as a non-taxable stock acquisition and therefore Extreme Networks has carryover tax basis in the assets and liabilities acquired.  During the fourth quarter of fiscal 2020 following the acquisition of Aerohive, the Company realigned the Aerohive related non-American intellectual property (“IP”) rights to correspond with the Company’s global operating model.  This transaction resulted in recognition of a $75 million U.S. tax gain which was fully consumed by existing NOLs and the intangibles transferred are being amortized over 10 years for Irish statutory purposes.

[0001564590-21-046138:notes:317]
As of June 30, 2021, the Company had $19.1 million of unrecognized tax benefits.  If fully recognized in the future, $0.4 million would impact the effective tax rate, and $18.7 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance.  The Company does not reasonably expect the amount of unrealized tax benefits to materially decrease during the next twelve months. The decrease in the current year related to prior year tax positions relates to the reclassification of an unrecognized tax benefit to a valuation allowance with no net impact to the financial statements.

[0001564590-21-046138:notes:318]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001564590-21-046138:notes:319]
| Balance at June 30, 2018 |  | $ | 17,506 |  |
| Increase related to prior year tax positions |  |  | 26 |  |
| Lapse of statute of limitations |  |  | (364 | ) |
| Balance at June 30, 2019 |  |  | 17,168 |  |
| Increase related to prior year tax positions |  |  | 8,906 |  |
| Increase related to current year tax positions |  |  | 44 |  |
| Decrease related to prior year tax positions |  |  | (1,800 | ) |
| Lapse of statute of limitations |  |  | (421 | ) |
| Balance at June 30, 2020 |  |  | 23,897 |  |
| Decrease related to prior year tax positions |  |  | (4,296 | ) |
| Increase related to prior year tax positions |  |  | 28 |  |
| Increase related to current year tax positions |  |  | 72 |  |
| Lapse of statute of limitations |  |  | (637 | ) |
| Balance at June 30, 2021 |  | $ | 19,064 |  |

[0001564590-21-046138:notes:320]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of tax expense in the consolidated statements of operations and totaled less than $0.1 million for each of the years ended 2021, 2020 and 2019.


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-046138:notes:321]
17. Net Income (Loss) Per Share

[0001564590-21-046138:notes:322]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock outstanding during the period. Diluted income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock used in the basic net income (loss) per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested restricted stock.

[0001564590-21-046138:notes:323]
The following table presents the calculation of basic and diluted net income (loss) per share (in thousands, except per share data):

[0001564590-21-046138:notes:324]
|  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Net income (loss) |  | $ | 1,936 |  |  | $ | (126,845 | ) |  | $ | (25,853 | ) |
| Weighted-average shares used in per share calculation - basic |  |  | 124,019 |  |  |  | 119,814 |  |  |  | 117,954 |  |
| Options to purchase common stock |  |  | 542 |  |  |  | — |  |  |  | — |  |
| Restricted stock units |  |  | 3,047 |  |  |  | — |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | 61 |  |  |  | — |  |  |  | — |  |
| Weighted-average shares used in per share calculation - diluted |  |  | 127,669 |  |  |  | 119,814 |  |  |  | 117,954 |  |
| Net income (loss) per share - basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.02 |  |  | $ | (1.06 | ) |  | $ | (0.22 | ) |
| Net income (loss) per share - diluted |  | $ | 0.02 |  |  | $ | (1.06 | ) |  | $ | (0.22 | ) |

[0001564590-21-046138:notes:325]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.  Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net loss per share since the effect of including them would have been anti-dilutive due to the net loss position of the Company during the periods presented.

[0001564590-21-046138:notes:326]
The following securities were excluded from the computation of net income (loss) per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001564590-21-046138:notes:327]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Options to purchase common stock |  |  | 637 |  |  |  | 3,036 |  |  |  | 2,693 |  |
| Restricted stock units |  |  | 80 |  |  |  | 8,103 |  |  |  | 8,337 |  |
| Employee Stock Purchase Plan shares |  |  | 334 |  |  |  | 553 |  |  |  | 612 |  |
| Total shares excluded |  |  | 1,051 |  |  |  | 11,692 |  |  |  | 11,642 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-21-046138:notes:328]
18. Subsequent Event

[0001564590-21-046138:notes:329]
On August 6, 2021, the Company along with its subsidiary Extreme Networks Ireland Holding Ltd, entered into a put option agreement with InfoVista SAS, relating to the transfer of ownership of Ipanematech SAS (“Ipanematech”). Appended to the put option agreement is a form of sale and purchase agreement which provides for the acquisition at a fixed purchase price of €60 million (approximately $73 million based on the currency exchange rate as of the time of the announcement), payable at closing of the acquisition.

[0001564590-21-046138:notes:330]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanematech will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of Ipanematech will be included in the operations of the Company beginning with the closing date. As of the date of the filing of this Form 10-K, the initial purchase price allocation has not been prepared as the acquisition has not been completed.

[0001564590-21-046138:notes:331]
For the fiscal year ended June 30, 2021, the transaction costs related to this acquisition were immaterial and were included in “General and administrative” expense in the accompanying consolidated statements of operations.
