# EXTR 8-K — 0001564590-21-038470 filed 2021-07-28

## item codes, every 8-K on or before 2021-08-27

- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2021-08-27

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-038470:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-21-038470:8k_2_02:2]
extr-ex991_6.htm

[0001564590-21-038470:8k_2_02:3]
Exhibit 99.1

[0001564590-21-038470:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-21-038470:8k_2_02:5]
Extreme Networks Reports Fourth Quarter and Full Fiscal Year 2021 Financial Results

[0001564590-21-038470:8k_2_02:6]
Industry leadership in enterprise cloud-driven networking drives market share gains highlighted by record revenue and free cash flow

[0001564590-21-038470:8k_2_02:7]
SAN JOSE, Calif., July 28, 2021 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fourth fiscal quarter and fiscal year ended June 30, 2021.

[0001564590-21-038470:8k_2_02:8]
Fiscal Fourth Quarter Results:

[0001564590-21-038470:8k_2_02:9]
|  | • | Revenue $278.1 million, up 29% year-over-year and up 10% quarter-over-quarter |

[0001564590-21-038470:8k_2_02:10]
|  | • | GAAP EPS $0.08, up from ($0.18) in Q4 last year |

[0001564590-21-038470:8k_2_02:11]
|  | • | Non-GAAP EPS $0.19, up from $0.03 in Q4 last year |

[0001564590-21-038470:8k_2_02:12]
|  | • | GAAP gross margin 57.9% compared to 56.0% in Q4 last year |

[0001564590-21-038470:8k_2_02:13]
|  | • | Non-GAAP gross margin 60.5% compared to 59.4% in Q4 last year |

[0001564590-21-038470:8k_2_02:14]
|  | • | GAAP operating margin 6.3% compared to (6.1)% in Q4 last year |

[0001564590-21-038470:8k_2_02:15]
|  | • | Non-GAAP operating margin 13.4% compared to 5.2% in Q4 last year |

[0001564590-21-038470:8k_2_02:16]
|  | • | Net cash provided by operating activities of $57.0 million |

[0001564590-21-038470:8k_2_02:17]
|  | • | Free Cash Flow of $52.2 million |

[0001564590-21-038470:8k_2_02:18]
Fiscal Year 2021 Results:

[0001564590-21-038470:8k_2_02:19]
|  | • | Revenue $1,009.4 million, up 6% compared to $948.0 million in fiscal 2020 |

[0001564590-21-038470:8k_2_02:20]
|  | • | GAAP operating margin 3.4% compared to (10.4)% in fiscal 2020 |

[0001564590-21-038470:8k_2_02:21]
|  | • | Non-GAAP operating margin 10.9% compared to 4.3% in fiscal 2020 |

[0001564590-21-038470:8k_2_02:22]
|  | • | Free Cash Flow of $127.4 million |

[0001564590-21-038470:8k_2_02:23]
“Demand for our enterprise solutions is unprecedented, as momentum in our business built through the fiscal year and culminated in 36% year-over-year bookings growth in Q4. Our record setting revenue of over $1 billion for the fiscal year is even more meaningful considering we tripled product backlog during the period. And, the fact that our cloud new subscription bookings grew 111% year-over-year is a proof point that we’re taking share in the fastest growing segment of the networking industry, solidifying our #2 market share position,” stated Ed Meyercord, President and CEO of Extreme.

[0001564590-21-038470:8k_2_02:24]
“Our innovative and industry-leading solutions for both the Infinite Enterprise and for 5G cloud-native network infrastructure are resonating with customers and creating significant growth opportunities for Extreme. During Q4 we extended our technology differentiation with the most successful product launch in our most recent history with the 5420 universal hardware platform, the 9920 next-gen packet broker, and the release of Extreme CoPilot, our Explainable-AI tool. And just yesterday, we announced that we

[0001564590-21-038470:8k_2_02:25]
are the first in the industry to ship game-changing Wi-Fi 6E access points to customers,” concluded Meyercord.

[0001564590-21-038470:8k_2_02:26]
“Extreme has never been in a stronger financial position. With record non-GAAP operating margins and $127.4 million in free cash flow generated during FY21, our net debt position fell to just under $100 million. In Q4, we navigated a unique environment of rising demand, but also rising supply chain constraints, leading to results that are a testament to our focus on driving operational excellence,” stated Rémi Thomas, CFO of Extreme.

[0001564590-21-038470:8k_2_02:27]
“The current environment of supply chain constraints has created record backlog and added incremental costs that will continue to increase into the September quarter. Importantly, we have secured vendor commitments that will allow us to accelerate product delivery and bring down backlog as of Q2 and beyond. As a result, we are confident in guiding FY22 revenue towards the high-end of our 5% to 9% long-term growth target, with double-digit operating income margins and significant free cash flow growth,” concluded Thomas.

[0001564590-21-038470:8k_2_02:28]
Recent Key Highlights:

[0001564590-21-038470:8k_2_02:29]
|  | • | Extreme is first in the industry to ship enterprise-grade Wi-Fi 6E access points. TheAP4000 universal wireless platform is the most advanced Wi-Fi 6E solution in the market with industry-leading cloud management and capable of operating in the new 6 GHz frequency band. AP4000 will enable multi-gigabit, low latency connections and new use cases for high-reliability customer experiences, eliminating downtime and reducing risk of data and privacy vulnerabilities for high-density environments, such sports and entertainment, schools, warehouses, and healthcare facilities. |

[0001564590-21-038470:8k_2_02:30]
|  | • | In June 2021, Extreme provided automated access to our explainable artificial intelligence/ machine learning insights tool, “CoPilot,” within the ExtremeCloud IQ platform. CoPilot was launched with anomalous threat detection, the ability to reduce false alarms, and troubleshooting capabilities for IT professionals tasked with managing complex, often highly distributed, networks. New features will be added in fiscal Q2 and we expect CoPilot to become a billable license in the second half of FY22. |

[0001564590-21-038470:8k_2_02:31]
|  | • | Extreme introduced the 9920 intelligent next generation packet broker for service provider networks. The platform delivers high-speed throughput at 12.8 Tbps for detailed data insights and provides the flexibility to adapt for future network enhancements so service providers can quickly respond to new user demands and 5G use cases. It is based on the Intel Tofino™ 2 programmable ASIC, providing a massively scalable architecture that easily integrates with existing service provider environments and can quickly adapt to new use cases. |

[0001564590-21-038470:8k_2_02:32]
|  | • | A report from 650 Group identified Extreme as the second leading vendor in the cloud-managed network services market, with more market share than the third and fourth ranked vendors combined in CY20. Extreme also significantly outpaced the market, delivering 101% |

[0001564590-21-038470:8k_2_02:33]
|  |  | revenue growth year over year from 2019 to 2020 while the overall market experienced 28% revenue growth during that same period. |

[0001564590-21-038470:8k_2_02:34]
|  | • | Wynn Resorts, a developer and operator of luxury hotels and casinos with locations in Las Vegas, Boston, Macau, and Cotai, selected Extreme to deploy a next-generation Fabric network across its Las Vegas location, and a separate fabric-based network for audio visual (A/V) system management. By standardizing on Extreme, Wynn can simplify device on-boarding and management across properties and deliver a secure, dedicated connection for bandwidth-intensive A/V equipment. |

[0001564590-21-038470:8k_2_02:35]
|  | • | Retailer Colruyt Group, which operates 619 stores and supplies over 580 independent shops throughout Belgium, Luxembourg and France, deployed Extreme’s Wi-Fi solutions and cloud management platform across its retail and corporate office locations. Extreme’s network solutions enable Colruyt Group Services to support the opening of new physical locations, increase bandwidth in response to growing numbers of IoT devices, and deliver network insights such as device location data to help inform sales strategies. |

[0001564590-21-038470:8k_2_02:36]
|  | • | Madrid-based grocery retailer Ahorramas deployed Extreme Wi-Fi 6 access points, SD-WAN solutions, and ExtremeCloud IQ network management software across its 265 retail locations. The new network enables the grocery retailer to simplify network management, as Extreme wired network solutions were previously deployed across its corporate offices and warehouses. It also delivers an improved Wi-Fi experience for employees and customers in all retail locations. |

[0001564590-21-038470:8k_2_02:37]
Fiscal Q4 2021 and Fiscal Year 2021 Financial Metrics:

[0001564590-21-038470:8k_2_02:38]
(in millions, except percentages and per share information)

[0001564590-21-038470:8k_2_02:39]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | Change |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | Change |  |
| Product |  | $ | 195.8 |  |  | $ | 141.5 |  |  |  | 38 | % |  | $ | 699.4 |  |  | $ | 653.6 |  |  |  | 7 | % |
| Service and subscription |  |  | 82.3 |  |  |  | 74.0 |  |  |  | 11 | % |  |  | 310.0 |  |  |  | 294.4 |  |  |  | 5 | % |
| Total net revenue |  | $ | 278.1 |  |  | $ | 215.5 |  |  |  | 29 | % |  | $ | 1,009.4 |  |  | $ | 948.0 |  |  |  | 6 | % |
| Gross margin |  |  | 57.9 | % |  |  | 56.0 | % |  | 190 bps |  |  |  | 58.0 | % |  |  | 54.6 | % |  | 340 bps |  |
| Operating margin |  |  | 6.3 | % |  |  | (6.1 | )% |  | 1240 bps |  |  |  | 3.4 | % |  |  | (10.4 | )% |  | 1384 bps |  |
| Net income (loss) |  | $ | 10.3 |  |  | $ | (21.2 | ) |  |  | 149 | % |  | $ | 1.9 |  |  | $ | (126.8 | ) |  |  | 101 | % |
| Net income (loss) per diluted share |  | $ | 0.08 |  |  | $ | (0.18 | ) |  |  | 144 | % |  | $ | 0.02 |  |  | $ | (1.06 | ) |  |  | 102 | % |

[0001564590-21-038470:8k_2_02:40]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | Change |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | Change |  |
| Product |  | $ | 195.8 |  |  | $ | 141.5 |  |  |  | 38 | % |  | $ | 699.4 |  |  | $ | 653.6 |  |  |  | 7 | % |
| Service and subscription |  |  | 82.3 |  |  |  | 74.0 |  |  |  | 11 | % |  |  | 310.0 |  |  |  | 294.4 |  |  |  | 5 | % |
| Total net revenue |  | $ | 278.1 |  |  | $ | 215.5 |  |  |  | 29 | % |  | $ | 1,009.4 |  |  | $ | 948.0 |  |  |  | 6 | % |
| Gross margin |  |  | 60.5 | % |  |  | 59.4 | % |  | 110 bps |  |  |  | 60.9 | % |  |  | 59.1 | % |  | 180 bps |  |
| Operating margin |  |  | 13.4 | % |  |  | 5.2 | % |  | 820 bps |  |  |  | 10.9 | % |  |  | 4.3 | % |  | 660 bps |  |
| Net income |  | $ | 24.6 |  |  | $ | 3.3 |  |  |  | 635 | % |  | $ | 72.4 |  |  | $ | 14.1 |  |  |  | 412 | % |
| Net income per diluted share |  | $ | 0.19 |  |  | $ | 0.03 |  |  |  | 533 | % |  | $ | 0.57 |  |  | $ | 0.12 |  |  |  | 375 | % |

[0001564590-21-038470:8k_2_02:41]
|  | • | Q4 ending cash balance was $246.9 million, an increase of $43.8 million from the end of Q3. This was primarily driven by operating cash flow generation of $57.0 million, partially offset by cash usage of $8.4 million for financing activities, along with $4.9 million for capital expenditures. |

[0001564590-21-038470:8k_2_02:42]
|  | • | Q4 accounts receivable balance was $156.5 million, an increase of $25.9 million from the end of Q3 and with days sales outstanding of 51, an increase of 5 days from Q3 and a decrease of 1 day from Q4 last year. |

[0001564590-21-038470:8k_2_02:43]
|  | • | Q4 ending inventory was $32.9 million, a decrease of $11.0 million from Q3 and a decrease of $29.7 million from Q4 last year. The year-over-year and quarter-over-quarter decreases in inventory largely reflect improved demand planning, SKU rationalization and higher inventory turnover. In addition, supply constraints in the recent quarters have contributed to the reduction in inventory. |

[0001564590-21-038470:8k_2_02:44]
|  | • | Q4 ending gross debt* was $346.8 million, a decrease of $4.8 million from the prior quarter. The $74.0 million decrease from Q4 last year resulted primarily from principal payments and payments on our revolver loan. Net debt* of $99.9 million decreased by $48.5 million from $148.4 million in Q3. |

[0001564590-21-038470:8k_2_02:45]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-21-038470:8k_2_02:46]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Cash flow provided by operations | $ | 57,039 |  |  | $ | 8,823 |  |  | $ | 144,535 |  |  | $ | 35,884 |  |
| Less: Property and equipment capital expenditures |  | (4,858 | ) |  |  | (2,638 | ) |  |  | (17,176 | ) |  |  | (15,268 | ) |
| Total free cash flow | $ | 52,181 |  |  | $ | 6,185 |  |  | $ | 127,359 |  |  | $ | 20,616 |  |

[0001564590-21-038470:8k_2_02:47]
*Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs. Net debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-21-038470:8k_2_02:48]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 346.8 |  |  | $ | 246.9 |  |  | $ | 99.9 |  |

[0001564590-21-038470:8k_2_02:49]
Business Outlook:

[0001564590-21-038470:8k_2_02:50]
For its first quarter of fiscal 2022, ending September 30, 2021, the Company is targeting:

[0001564590-21-038470:8k_2_02:51]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ1'22 Guidance – GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 250.0 |  |  | $ | 265.0 |  |
| Gross margin |  | 55.6 | % |  |  | 57.8 | % |
| Operating expenses | $ | 132.6 |  |  | $ | 134.6 |  |
| Operating margin |  | 2.6 | % |  |  | 7.0 | % |
| Net income (loss) | $ | 0.1 |  |  | $ | 12.1 |  |
| Net income (loss) per diluted share | $ | 0.00 |  |  | $ | 0.09 |  |
| Shares outstanding used in calculating GAAP EPS | 133.2 |  |  | 133.2 |  |
| FQ1’22 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 250.0 |  |  | $ | 265.0 |  |
| Gross margin |  | 58.0 | % |  |  | 60.0 | % |
| Operating expenses | $ | 121.5 |  |  | $ | 123.5 |  |
| Operating margin |  | 9.4 | % |  |  | 13.4 | % |
| Net income | $ | 16.7 |  |  | $ | 26.7 |  |
| Net income per diluted share | $ | 0.13 |  |  | $ | 0.20 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 133.2 |  |  |  | 133.2 |  |

[0001564590-21-038470:8k_2_02:52]
The following table shows the GAAP to non-GAAP reconciliation for Q1 FY’22 guidance:

[0001564590-21-038470:8k_2_02:53]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.6% - 57.8% |  |  | 2.6% - 7.0% |  |  | $0.00 - $0.09 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.7% |  |  | 1.7% |  |  |  | 0.03 |  |
| Share-based compensation | 0.3% |  |  | 3.9% |  |  |  | 0.08 |  |
| Restructuring |  | — |  |  | 0.3% |  |  |  | — |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.8% |  |  |  | 0.02 |  |
| Tax effect of non-GAAP adjustments |  | — |  |  |  | — |  |  | (0.00) - (0.02) |  |
| Non-GAAP | 58.0% - 60.0% |  |  | 9.4% - 13.4% |  |  | $0.13- $0.20 |  |

[0001564590-21-038470:8k_2_02:54]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-21-038470:8k_2_02:55]
Conference Call:

[0001564590-21-038470:8k_2_02:56]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the fourth fiscal quarter results as well as the business outlook for first fiscal quarter ending September 30, 2021, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. The conference call may also be heard by dialing 1 (877) 303-9826 or international 1 (224) 357-2194 with Conference ID # 8056219. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 8056219. The encore recording will be available for at least 7 days following the call.

[0001564590-21-038470:8k_2_02:57]
About Extreme:

[0001564590-21-038470:8k_2_02:58]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-21-038470:8k_2_02:59]
Extreme Networks, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001564590-21-038470:8k_2_02:60]
Non-GAAP Financial Measures:

[0001564590-21-038470:8k_2_02:61]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of intangibles, inventory valuation adjustment, and restructuring charges.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-21-038470:8k_2_02:62]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-21-038470:8k_2_02:63]
Forward-Looking Statements:

[0001564590-21-038470:8k_2_02:64]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2020, Quarterly Report on Form 10-Q for the quarter ended December 31, 2020 and March 31, 2021, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-21-038470:8k_2_02:65]
###

[0001564590-21-038470:8k_2_02:66]
EXTREME NETWORKS, INC.

[0001564590-21-038470:8k_2_02:67]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-21-038470:8k_2_02:68]
(In thousands, except per share amounts)

[0001564590-21-038470:8k_2_02:69]
(Unaudited)

[0001564590-21-038470:8k_2_02:70]
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 246,894 |  |  | $ | 193,872 |  |
| Accounts receivable, net of allowance for doubtful accounts of $986 and $1,212, respectively |  |  | 156,476 |  |  |  | 122,727 |  |
| Inventories |  |  | 32,885 |  |  |  | 62,589 |  |
| Prepaid expenses and other current assets |  |  | 51,340 |  |  |  | 35,019 |  |
| Total current assets |  |  | 487,595 |  |  |  | 414,207 |  |
| Property and equipment, net |  |  | 55,004 |  |  |  | 58,813 |  |
| Operating lease right-of-use assets, net |  |  | 36,927 |  |  |  | 51,274 |  |
| Intangible assets, net |  |  | 36,038 |  |  |  | 68,394 |  |
| Goodwill |  |  | 331,159 |  |  |  | 331,159 |  |
| Other assets |  |  | 63,370 |  |  |  | 55,241 |  |
| Total assets |  | $ | 1,010,093 |  |  | $ | 979,088 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,404 and $2,484, respectively |  | $ | 23,721 |  |  | $ | 16,516 |  |
| Accounts payable |  |  | 60,142 |  |  |  | 48,439 |  |
| Accrued compensation and benefits |  |  | 71,610 |  |  |  | 50,884 |  |
| Accrued warranty |  |  | 11,623 |  |  |  | 14,035 |  |
| Current portion, operating lease liabilities |  |  | 18,743 |  |  |  | 19,196 |  |
| Current portion, deferred revenue |  |  | 212,412 |  |  |  | 190,226 |  |
| Other accrued liabilities |  |  | 57,449 |  |  |  | 58,525 |  |
| Total current liabilities |  |  | 455,700 |  |  |  | 397,821 |  |
| Deferred revenue, less current portion |  |  | 133,172 |  |  |  | 100,961 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $4,760 and $7,165, respectively |  |  | 315,865 |  |  |  | 394,585 |  |
| Operating lease liabilities, less current portion |  |  | 32,515 |  |  |  | 50,238 |  |
| Deferred income taxes |  |  | 3,828 |  |  |  | 2,334 |  |
| Other long-term liabilities |  |  | 14,545 |  |  |  | 27,751 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 133,279 and 127,114 shares issued, respectively; 126,682 and 120,517 shares outstanding, respectively |  |  | 133 |  |  |  | 127 |  |
| Additional paid-in-capital |  |  | 1,078,602 |  |  |  | 1,035,041 |  |
| Accumulated other comprehensive loss |  |  | (2,811 | ) |  |  | (6,378 | ) |
| Accumulated deficit |  |  | (978,343 | ) |  |  | (980,279 | ) |
| Treasury stock at cost: 6,597 and 6,597 shares, respectively |  |  | (43,113 | ) |  |  | (43,113 | ) |
| Total stockholders’ equity |  |  | 54,468 |  |  |  | 5,398 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,010,093 |  |  | $ | 979,088 |  |

[0001564590-21-038470:8k_2_02:71]
EXTREME NETWORKS, INC.

[0001564590-21-038470:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-038470:8k_2_02:73]
(In thousands, except per share amounts)

[0001564590-21-038470:8k_2_02:74]
(Unaudited)

[0001564590-21-038470:8k_2_02:75]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 195,821 |  |  | $ | 141,478 |  |  | $ | 699,396 |  |  | $ | 653,651 |  |
| Service and subscription |  |  | 82,267 |  |  |  | 74,044 |  |  |  | 310,022 |  |  |  | 294,368 |  |
| Total net revenues |  |  | 278,088 |  |  |  | 215,522 |  |  |  | 1,009,418 |  |  |  | 948,019 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 86,116 |  |  |  | 71,628 |  |  |  | 309,958 |  |  |  | 326,333 |  |
| Service and subscription |  |  | 30,872 |  |  |  | 23,304 |  |  |  | 114,337 |  |  |  | 103,847 |  |
| Total cost of revenues |  |  | 116,988 |  |  |  | 94,932 |  |  |  | 424,295 |  |  |  | 430,180 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 109,705 |  |  |  | 69,850 |  |  |  | 389,438 |  |  |  | 327,318 |  |
| Service and subscription |  |  | 51,395 |  |  |  | 50,740 |  |  |  | 195,685 |  |  |  | 190,521 |  |
| Total gross profit |  |  | 161,100 |  |  |  | 120,590 |  |  |  | 585,123 |  |  |  | 517,839 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 49,376 |  |  |  | 44,533 |  |  |  | 196,995 |  |  |  | 209,606 |  |
| Sales and marketing |  |  | 74,886 |  |  |  | 66,707 |  |  |  | 276,841 |  |  |  | 283,632 |  |
| General and administrative |  |  | 17,357 |  |  |  | 15,792 |  |  |  | 66,201 |  |  |  | 60,991 |  |
| Acquisition and integration costs |  |  | — |  |  |  | 1,998 |  |  |  | 1,975 |  |  |  | 32,073 |  |
| Restructuring and related charges, net of reversals |  |  | 504 |  |  |  | 2,604 |  |  |  | 2,625 |  |  |  | 22,011 |  |
| Amortization of intangibles |  |  | 1,406 |  |  |  | 2,059 |  |  |  | 6,110 |  |  |  | 8,425 |  |
| Total operating expenses |  |  | 143,529 |  |  |  | 133,693 |  |  |  | 550,747 |  |  |  | 616,738 |  |
| Operating income (loss) |  |  | 17,571 |  |  |  | (13,103 | ) |  |  | 34,376 |  |  |  | (98,899 | ) |
| Interest income |  |  | 71 |  |  |  | 54 |  |  |  | 352 |  |  |  | 1,420 |  |
| Interest expense |  |  | (4,531 | ) |  |  | (6,373 | ) |  |  | (22,856 | ) |  |  | (23,750 | ) |
| Other (expense) income, net |  |  | (115 | ) |  |  | (391 | ) |  |  | (1,687 | ) |  |  | 737 |  |
| Income (loss) before income taxes |  |  | 12,996 |  |  |  | (19,813 | ) |  |  | 10,185 |  |  |  | (120,492 | ) |
| Provision for income taxes |  |  | 2,670 |  |  |  | 1,404 |  |  |  | 8,249 |  |  |  | 6,353 |  |
| Net Income (loss) |  | $ | 10,326 |  |  | $ | (21,217 | ) |  | $ | 1,936 |  |  | $ | (126,845 | ) |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.08 |  |  | $ | (0.18 | ) |  | $ | 0.02 |  |  | $ | (1.06 | ) |
| Net income (loss) per share - diluted |  | $ | 0.08 |  |  | $ | (0.18 | ) |  | $ | 0.02 |  |  | $ | (1.06 | ) |
| Shares used in per share calculation - basic |  |  | 126,318 |  |  |  | 120,314 |  |  |  | 124,019 |  |  |  | 119,814 |  |
| Shares used in per share calculation - diluted |  |  | 132,355 |  |  |  | 120,314 |  |  |  | 127,669 |  |  |  | 119,814 |  |

[0001564590-21-038470:8k_2_02:76]
EXTREME NETWORKS, INC.

[0001564590-21-038470:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-21-038470:8k_2_02:78]
(In thousands)

[0001564590-21-038470:8k_2_02:79]
(Unaudited)

[0001564590-21-038470:8k_2_02:80]
|  |  | Year Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net Income (loss) |  | $ | 1,936 |  |  | $ | (126,845 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 22,961 |  |  |  | 28,603 |  |
| Amortization of intangible assets |  |  | 32,356 |  |  |  | 35,218 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 16,134 |  |  |  | 16,420 |  |
| Provision for doubtful accounts |  |  | 409 |  |  |  | 1,289 |  |
| Share-based compensation |  |  | 39,051 |  |  |  | 37,842 |  |
| Deferred income taxes |  |  | 1,785 |  |  |  | 1,760 |  |
| Non-cash restructuring and impairment charges |  |  | - |  |  |  | 7,622 |  |
| Non-cash interest expense |  |  | 5,055 |  |  |  | 4,196 |  |
| Other |  |  | 3,989 |  |  |  | (349 | ) |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (34,158 | ) |  |  | 62,151 |  |
| Inventories |  |  | 22,729 |  |  |  | 19,951 |  |
| Prepaid expenses and other assets |  |  | (18,979 | ) |  |  | 781 |  |
| Accounts payable |  |  | 10,810 |  |  |  | (26,080 | ) |
| Accrued compensation and benefits |  |  | 20,088 |  |  |  | (8,080 | ) |
| Operating lease liabilities |  |  | (19,986 | ) |  |  | (17,345 | ) |
| Deferred revenue |  |  | 54,398 |  |  |  | 19,530 |  |
| Other current and long-term liabilities |  |  | (14,043 | ) |  |  | (20,780 | ) |
| Net cash provided by operating activities |  |  | 144,535 |  |  |  | 35,884 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (17,176 | ) |  |  | (15,268 | ) |
| Business acquisition, net of cash acquired |  |  | — |  |  |  | (219,458 | ) |
| Maturities and sales of investments |  |  | — |  |  |  | 45,249 |  |
| Net cash used in investing activities |  |  | (17,176 | ) |  |  | (189,477 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 199,500 |  |
| Payments on debt obligations |  |  | (74,000 | ) |  |  | (34,517 | ) |
| Loan fees on borrowings |  |  | — |  |  |  | (12,029 | ) |
| Repurchase of common stock |  |  | — |  |  |  | (30,000 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 4,516 |  |  |  | 8,789 |  |
| Payment of contingent consideration obligations |  |  | (1,298 | ) |  |  | (4,251 | ) |
| Deferred payments on an acquisition |  |  | (4,000 | ) |  |  | (4,000 | ) |
| Net cash (used in) provided by financing activities |  |  | (74,782 | ) |  |  | 178,492 |  |
| Foreign currency effect on cash |  |  | 445 |  |  |  | (634 | ) |
| Net increase in cash |  |  | 53,022 |  |  |  | 24,265 |  |
| Cash at beginning of period |  |  | 193,872 |  |  |  | 169,607 |  |
| Cash at end of period |  | $ | 246,894 |  |  | $ | 193,872 |  |

[0001564590-21-038470:8k_2_02:81]
Extreme Networks, Inc.

[0001564590-21-038470:8k_2_02:82]
Non-GAAP Measures of Financial Performance

[0001564590-21-038470:8k_2_02:83]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share and non-GAAP free cash flow.

[0001564590-21-038470:8k_2_02:84]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme also presents its range for projected non-GAAP operating expenses, which is operating expenses less share-based compensation expense, restructuring charges and amortization of intangibles.

[0001564590-21-038470:8k_2_02:85]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-21-038470:8k_2_02:86]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-21-038470:8k_2_02:87]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquired inventory adjustments, acquisition and integration costs, amortization of intangibles, inventory valuation adjustments, restructuring charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-21-038470:8k_2_02:88]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-21-038470:8k_2_02:89]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-21-038470:8k_2_02:90]
Acquired inventory adjustments. Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-21-038470:8k_2_02:91]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-21-038470:8k_2_02:92]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-21-038470:8k_2_02:93]
Inventory valuation adjustments. Adjustments relating to the mark down of inventory due to duplication of products lines with acquisition of Aerohive net of recoveries on the sale of inventory marked down in previous quarters.

[0001564590-21-038470:8k_2_02:94]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-21-038470:8k_2_02:95]
Tax effect of non-GAAP adjustments. Beginning with our first quarter of fiscal 2021, we changed how we calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.   Previously, the non-GAAP tax provision consisted of current and deferred income tax expense on a GAAP basis as if our carryforward net operating losses were sufficient to offset our non-GAAP adjustments.  Beginning with our first quarter of fiscal 2021, we have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits which were previously not utilizable.  The non-GAAP tax provision now consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.  We have adjusted the fiscal 2020 non-GAAP tax provision to reflect the 2020 non-GAAP operating results to be comparable with fiscal 2021 results.  As a result of this change, the non-GAAP net income for the three months ended June 30, 2020 remained the same at $0.03 per diluted share as previously reported, but the non-GAAP net income for the year ended June 30, 2020 changed from $0.10 per diluted share as previously reported to $0.12 net income per diluted share.

[0001564590-21-038470:8k_2_02:96]
This change does not affect our non-GAAP income (loss) before income taxes, actual cash tax payments or cash flows, but will result in a higher or lower non-GAAP provision for income taxes depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of June 30, 2021, we had U.S. federal net operating loss carryforwards of $241 million, state net operating loss carryforwards of $156 million and Irish net operating losses of $17 million. As of June 30, 2020, we had U.S. federal net operating loss carryforwards of $310 million and state net operating loss carryforwards of $181 million.  We do not expect to pay substantial taxes on a GAAP basis in the U.S. for the foreseeable future due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Irish operating

[0001564590-21-038470:8k_2_02:97]
company which has fully utilized available net operating loss carryforwards during fiscal 2021.  We also believe our long-term effective GAAP tax rate will be lower than the U.S. statutory rate based upon our established tax structure.

[0001564590-21-038470:8k_2_02:98]
EXTREME NETWORKS, INC.

[0001564590-21-038470:8k_2_02:99]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-038470:8k_2_02:100]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-21-038470:8k_2_02:101]
(In thousands, except percentages and per share amounts)

[0001564590-21-038470:8k_2_02:102]
(Unaudited)

[0001564590-21-038470:8k_2_02:103]
| Revenues | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Revenues - GAAP | $ | 278,088 |  |  | $ | 215,522 |  |  | $ | 1,009,418 |  |  | $ | 948,019 |  |

[0001564590-21-038470:8k_2_02:104]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Gross profit - GAAP | $ | 161,100 |  |  | $ | 120,590 |  |  | $ | 585,123 |  |  | $ | 517,839 |  |
| Gross margin - GAAP percentage |  | 57.9 | % |  |  | 56.0 | % |  |  | 58.0 | % |  |  | 54.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 779 |  |  |  | 708 |  |  |  | 2,871 |  |  |  | 2,860 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 7,303 |  |
| Acquisition and integration costs |  | — |  |  |  | 98 |  |  |  | 10 |  |  |  | 2,169 |  |
| Amortization of intangibles |  | 6,432 |  |  |  | 6,633 |  |  |  | 26,129 |  |  |  | 26,430 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,677 |  |
| Total adjustments to GAAP gross profit | $ | 7,211 |  |  | $ | 7,439 |  |  | $ | 29,010 |  |  | $ | 42,439 |  |
| Gross profit - non-GAAP | $ | 168,311 |  |  | $ | 128,029 |  |  | $ | 614,133 |  |  | $ | 560,278 |  |
| Gross margin - non-GAAP percentage |  | 60.5 | % |  |  | 59.4 | % |  |  | 60.8 | % |  |  | 59.1 | % |

[0001564590-21-038470:8k_2_02:105]
| Non-GAAP Operating Income (Loss) | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| GAAP operating income (loss) | $ | 17,571 |  |  | $ | (13,103 | ) |  | $ | 34,376 |  |  | $ | (98,899 | ) |
| GAAP operating income (loss) percentage |  | 6.3 | % |  |  | (6.1 | )% |  |  | 3.4 | % |  |  | (10.4 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 779 |  |  |  | 708 |  |  |  | 2,871 |  |  |  | 2,860 |  |
| Share-based compensation expense, R&D |  | 2,589 |  |  |  | 2,111 |  |  |  | 9,969 |  |  |  | 10,324 |  |
| Share-based compensation expense, S&M |  | 3,469 |  |  |  | 3,346 |  |  |  | 12,505 |  |  |  | 11,914 |  |
| Share-based compensation expense, G&A |  | 4,619 |  |  |  | 4,742 |  |  |  | 13,706 |  |  |  | 12,265 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,677 |  |
| Acquisition and integration costs |  | — |  |  |  | 2,096 |  |  |  | 1,985 |  |  |  | 34,242 |  |
| Restructuring charges, net of reversals |  | 504 |  |  |  | 2,604 |  |  |  | 2,625 |  |  |  | 22,011 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 7,303 |  |
| Amortization of intangibles |  | 7,838 |  |  |  | 8,692 |  |  |  | 32,239 |  |  |  | 34,855 |  |
| Total adjustments to GAAP operating income (loss) | $ | 19,798 |  |  | $ | 24,299 |  |  | $ | 75,900 |  |  | $ | 139,451 |  |
| Non-GAAP operating income | $ | 37,369 |  |  | $ | 11,196 |  |  | $ | 110,276 |  |  | $ | 40,552 |  |
| Non-GAAP operating income percentage |  | 13.4 | % |  |  | 5.2 | % |  |  | 10.9 | % |  |  | 4.3 | % |

[0001564590-21-038470:8k_2_02:106]
| Non-GAAP net income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2021 |  |  | June 30, 2020 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| GAAP net income (loss) | $ | 10,326 |  |  | $ | (21,217 | ) |  | $ | 1,936 |  |  | $ | (126,845 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 11,456 |  |  |  | 10,907 |  |  |  | 39,051 |  |  |  | 37,363 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,677 |  |
| Acquisition and integration costs |  | — |  |  |  | 2,096 |  |  |  | 1,985 |  |  |  | 34,242 |  |
| Restructuring charge, net of reversal |  | 504 |  |  |  | 2,604 |  |  |  | 2,625 |  |  |  | 22,011 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 7,303 |  |
| Amortization of intangibles |  | 7,838 |  |  |  | 8,692 |  |  |  | 32,239 |  |  |  | 34,855 |  |
| Tax effect of non-GAAP adjustments |  | (5,514 | ) |  |  | 266 |  |  |  | (5,608 | ) |  |  | 1,542 |  |
| Total adjustments to GAAP net income (loss) | $ | 14,284 |  |  | $ | 24,565 |  |  | $ | 70,292 |  |  | $ | 140,993 |  |
| Non-GAAP net income | $ | 24,610 |  |  | $ | 3,348 |  |  | $ | 72,228 |  |  | $ | 14,148 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.19 |  |  | $ | 0.03 |  |  | $ | 0.57 |  |  | $ | 0.12 |  |
| Shares used in net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation - basic |  | 126,318 |  |  |  | 120,314 |  |  |  | 124,019 |  |  |  | 119,814 |  |
| Potentially dilutive equity awards |  | 6,037 |  |  |  | 484 |  |  |  | 3,650 |  |  |  | 2,419 |  |
| GAAP and Non-GAAP shares used in per share calculation - diluted |  | 132,355 |  |  |  | 120,798 |  |  |  | 127,669 |  |  |  | 122,233 |  |
