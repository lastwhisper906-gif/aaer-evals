# EXTR 10-K controls and the auditor's report


## auditors_report

[0001564590-21-046138:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001564590-21-046138:auditors_report:2]
To the Stockholders and the Board of Directors of Extreme Networks, Inc.

[0001564590-21-046138:auditors_report:3]
Opinion on the Financial Statements

[0001564590-21-046138:auditors_report:4]
We have audited the accompanying consolidated balance sheet of Extreme Networks, Inc. (the Company) as of June 30, 2021, the related consolidated statements of operations, comprehensive income, stockholders' equity and cash flows for the year ended June 30, 2021, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at June 30, 2021, and the results of its operations and its cash flows for the year ended June 30, 2021, in conformity with U.S. generally accepted accounting principles.

[0001564590-21-046138:auditors_report:5]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of June 30, 2021, based on criteria established in Internal Control-Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) and our report dated August 27, 2021 expressed an unqualified opinion thereon.

[0001564590-21-046138:auditors_report:6]
Basis for Opinion

[0001564590-21-046138:auditors_report:7]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company’s financial statements based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-21-046138:auditors_report:8]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001564590-21-046138:auditors_report:9]
Critical Audit Matter

[0001564590-21-046138:auditors_report:10]
The critical audit matter communicated below is a matter arising from the current period audit of the financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of the critical audit matter does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001564590-21-046138:auditors_report:11]
Revenue Recognition – Variable Consideration

[0001564590-21-046138:auditors_report:12]
| Description of the Matter | As described in Note 3 to the consolidated financial statements, the Company determines the transaction price for sales to its stocking distributors after estimating the variable consideration for expected rebates resulting from future discounts on the contract price. The estimated rebate reserve is presented as a reduction of accounts receivable in the consolidated balance sheet, which totaled $149.5 million as of June 30, 2021. The Company evaluates the products remaining in the distribution channel at period end and uses the expected value method to estimate the expected variable consideration related to future price adjustments, including an evaluation of historical actual rebate claims, estimated future end customer pricing, and business trends. Auditing management’s estimate of the variable consideration for stocking distributor rebates was challenging and complex due to the effort required to assess the reasonableness of management’s estimates and judgments, including the period of time historical actual rebate claims are considered and estimated future end customer pricing. Changes in these estimates can have a material effect on the amount of variable consideration recognized. |

[0001564590-21-046138:auditors_report:13]
| How We Addressed the Matterin Our Audit | We obtained an understanding, evaluated the design, and tested the operating effectiveness of the Company’s internal controls over the estimation of variable consideration for stocking distributor rebates. This included testing the relevant controls over management's review of the significant estimates and judgments including the period of time historical actual rebate claims are considered and estimates of future end customer pricing. Our audit procedures also included testing the controls over the completeness and accuracy of the data used in the estimation of the of variable consideration for stocking distributor rebates, including inventory held in the channel. Our audit procedures over variable consideration for stocking distributor rebates included, among others, assessing the stocking distributor rebate reserve methodology for reasonableness, testing the completeness and accuracy of the historical actual rebate claims data, and comparing management’s estimates of future end customer pricing with recent actual pricing adjustments. We also evaluated potential contrary evidence, including the historical accuracy of management's estimates by comparing the stocking distributor rebate reserve estimates to the actual rebates issued in subsequent periods. In addition, we also performed a sensitivity analysis and confirmed inventory held in the channel. Finally, we assessed the appropriateness of the related disclosures in the consolidated financial statements. |

[0001564590-21-046138:auditors_report:14]
/s/ Ernst & Young LLP

[0001564590-21-046138:auditors_report:15]
We have served as the Company’s auditor since 2020.

[0001564590-21-046138:auditors_report:16]
San Jose, California

[0001564590-21-046138:auditors_report:17]
August 27, 2021

[0001564590-21-046138:auditors_report:18]
49

[0001564590-21-046138:auditors_report:19]
Report of Independent Registered Public Accounting Firm

[0001564590-21-046138:auditors_report:20]
To the Stockholders and the Board of Directors of Extreme Networks, Inc.

[0001564590-21-046138:auditors_report:21]
Opinion on Internal Control Over Financial Reporting

[0001564590-21-046138:auditors_report:22]
We have audited Extreme Networks, Inc.’s internal control over financial reporting as of June 30, 2021, based on criteria established in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO criteria). In our opinion, Extreme Networks, Inc. (the Company) maintained, in all material respects, effective internal control over financial reporting as of June 30, 2021, based on the COSO criteria.

[0001564590-21-046138:auditors_report:23]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated balance sheet of the Company as of June 30, 2021, the related consolidated statements of operations, comprehensive income, stockholders' equity and cash flows for the year ended June 30, 2021, and the related notes and our report dated August 27, 2021 expressed an unqualified opinion thereon.

[0001564590-21-046138:auditors_report:24]
Basis for Opinion

[0001564590-21-046138:auditors_report:25]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-21-046138:auditors_report:26]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.

[0001564590-21-046138:auditors_report:27]
Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001564590-21-046138:auditors_report:28]
Definition and Limitations of Internal Control Over Financial Reporting

[0001564590-21-046138:auditors_report:29]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001564590-21-046138:auditors_report:30]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-21-046138:auditors_report:31]
/s/ Ernst & Young LLP

[0001564590-21-046138:auditors_report:32]
San Jose, California

[0001564590-21-046138:auditors_report:33]
August 27, 2021

[0001564590-21-046138:auditors_report:34]
Report of Independent Registered Public Accounting Firm

[0001564590-21-046138:auditors_report:35]
To the Stockholders and Board of Directors

[0001564590-21-046138:auditors_report:36]
Extreme Networks, Inc.:

[0001564590-21-046138:auditors_report:37]
Opinion on the Consolidated Financial Statements

[0001564590-21-046138:auditors_report:38]
We have audited the accompanying consolidated balance sheet of Extreme Networks, Inc. and subsidiaries (the Company) as of June 30, 2020, the related consolidated statements of operations, comprehensive loss, stockholders’ equity, and cash flows for each of the years in the two-year period ended June 30, 2020 and the related notes (collectively, the consolidated financial statements).  In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2020 and the results of its operations and its cash flows for each of the years in the two-year period ended June 30, 2020, in conformity with U.S. generally accepted accounting principles.

[0001564590-21-046138:auditors_report:39]
Change in Accounting Principle

[0001564590-21-046138:auditors_report:40]
As discussed in Note 2 to the consolidated financial statements, the Company has changed its method of accounting for leases as of July 1, 2019 due to the adoption of Accounting Standards Update 2016-02, Leases, and several related amendments, as issued by the Financial Accounting Standards Board.

[0001564590-21-046138:auditors_report:41]
Basis for Opinion

[0001564590-21-046138:auditors_report:42]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on these consolidated financial statements based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-21-046138:auditors_report:43]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001564590-21-046138:auditors_report:44]
/s/KPMG LLP

[0001564590-21-046138:auditors_report:45]
We served as the Company’s auditor from 2010 to 2020.

[0001564590-21-046138:auditors_report:46]
Raleigh, North Carolina

[0001564590-21-046138:auditors_report:47]
August 31, 2020

[0001564590-21-046138:auditors_report:48]
EXTREME NETWORKS, INC.


## item_9a

[0001564590-21-046138:item_9a:1]
Item 9A. Controls and Procedures

[0001564590-21-046138:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-21-046138:item_9a:3]
Disclosure controls and procedures are controls and procedures designed to reasonably assure that information required to be disclosed in our reports filed under the Securities Exchange Act of 1934 as amended, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and to reasonably assure that such information is accumulated and communicated to our management, including the Chief Executive Officer (“CEO”) and the Chief Financial Officer (“CFO”), as appropriate to allow timely decisions regarding required disclosure.

[0001564590-21-046138:item_9a:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we evaluated the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO concluded that our disclosure controls and procedures were effective as of June 30, 2021.

[0001564590-21-046138:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001564590-21-046138:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over our financial reporting. There are inherent limitations in the effectiveness of any system of internal control, including the possibility of human error and the circumvention or overriding of controls. Accordingly, even effective internal controls can provide only reasonable assurances with respect to financial statement preparation. Further because of changes in conditions, the effectiveness of internal control may vary over time.

[0001564590-21-046138:item_9a:7]
We assessed the effectiveness of our internal control over financial reporting as of June 30, 2021.  In making this assessment, we used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in Internal Control-Integrated Framework (2013). Based on our assessment using those criteria, we concluded that, as of June 30, 2021, our internal control over financial reporting is effective.

[0001564590-21-046138:item_9a:8]
Our independent registered public accounting firm, Ernst & Young LLP, has audited the consolidated financial statements as of and for the year ended June 30, 2021 included in this Annual Report on Form 10-K and has issued its report on our internal control over financial reporting as of June 30, 2021.

[0001564590-21-046138:item_9a:9]
Changes in Internal Control over Financial Reporting

[0001564590-21-046138:item_9a:10]
There were no changes in our internal control over financial reporting (as defined in Rules 13a – 15(f) and 15d – 15(f) under the Securities Exchange Act of 1934) during the fourth quarter of 2021 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-21-046138:item_9a:11]
Inherent Limitations on Effectiveness of Controls

[0001564590-21-046138:item_9a:12]
Our management, including the CEO and CFO, does not expect that our disclosure controls or our internal control over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. Our controls and procedures are designed to provide reasonable assurance that our control system’s objective will be met, and our CEO and CFO have concluded that our disclosure controls and procedures are effective at the reasonable assurance level. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within Extreme have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events. Projections of any evaluation of the effectiveness of controls in future periods are subject to risks. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Notwithstanding these limitations, our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives. Our CEO and CFO have concluded that our disclosure controls and procedures are, in fact, effective at the “reasonable assurance” level.
