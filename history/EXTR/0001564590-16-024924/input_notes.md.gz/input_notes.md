# EXTR notes — 0001564590-16-024924


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-16-024924:notes:1]
1. Description of Business and Basis of Presentation

[0001564590-16-024924:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-16-024924:notes:3]
Fiscal Year

[0001564590-16-024924:notes:4]
The Company uses a fiscal calendar year ending on June 30.  All references herein to  "fiscal 2016" or "2016"; “fiscal 2015” or “2015”; "fiscal 2014" or "2014" represent the fiscal years ending June 30, 2016,  2015 and 2014, respectively .

[0001564590-16-024924:notes:5]
Principles of Consolidation

[0001564590-16-024924:notes:6]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-16-024924:notes:7]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001564590-16-024924:notes:8]
Accounting Estimates

[0001564590-16-024924:notes:9]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-16-024924:notes:10]
2. Business Combinations

[0001564590-16-024924:notes:11]
On October 31, 2013 (the “Acquisition Date”), the Company completed the acquisition of Enterasys Networks, Inc. ("Enterasys"), a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired. The Company also assumed outstanding options and restricted stock units of Enterasys at the Acquisition Date, all of which were unvested.

[0001564590-16-024924:notes:12]
The acquisition has been accounted for using the acquisition method of accounting. The purchase price allocation as of the Acquisition Date is set forth in the table below and reflects various fair value estimates. These estimates were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of September 30, 2014.

[0001564590-16-024924:notes:13]
The following table below summarizes the allocation as of September 30, 2014 of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-16-024924:notes:14]
|  |  | September 30, 2014 |  |
| Cash |  | $ | 7,397 |  |
| Receivables |  |  | 23,271 |  |
| Inventory |  |  | 33,662 |  |
| Other current assets |  |  | 7,374 |  |
| Property and equipment |  |  | 21,293 |  |
| Identifiable intangible assets |  |  | 108,900 |  |
| In-process research and development |  |  | 3,000 |  |
| Deferred tax assets |  |  | 9 |  |
| Other assets |  |  | 7,343 |  |
| Goodwill |  |  | 70,877 |  |
| Current liabilities |  |  | (81,535 | ) |
| Other long-term liabilities |  |  | (14,194 | ) |
| Total purchase price allocation |  | $ | 187,397 |  |
| Less: Cash acquired from acquisition |  |  | (7,397 | ) |
| Total purchase price consideration, net of cash acquired |  | $ | 180,000 |  |

[0001564590-16-024924:notes:15]
There were no adjustments to the allocation of assets acquired or liabilities assumed from June 30, 2014 through the time the Company finalized the allocation as of September 30, 2014.

[0001564590-16-024924:notes:16]
The fair value of the acquired intangible assets was estimated using an income approach.  Under this method, an intangible asset's fair value is equal to the present value of the incremental after-tax cash flows (excess earnings) attributable solely to the intangible asset over its remaining useful life.  To calculate fair value, the Company used cash flows discounted at rates considered appropriate given the inherent risks associated with each type of asset. The Company believes that the level and timing of cash flows appropriately reflect market participant assumptions. Cash flows were assumed to extend through the remaining economic useful life of each class of intangible asset.

[0001564590-16-024924:notes:17]
The fair value of the acquired deferred revenue was estimated using the cost build-up approach.  The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay a third party to assume the obligation. The fair value of the deferred revenue obligation is affected most significantly by the estimated costs required to support the obligation, but is also affected by the assumed profit and the discount rate.

[0001564590-16-024924:notes:18]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001564590-16-024924:notes:19]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |  |
| Developed technology |  | 3 |  | $ | 45,000 |  |
| Customer relationships |  | 3 |  |  | 37,000 |  |
| Maintenance contracts |  | 5 |  |  | 17,000 |  |
| Trademarks |  | 3 |  |  | 2,500 |  |
| Order backlog |  | 1 |  |  | 7,400 |  |
| Total identifiable intangible assets |  | 3 |  | $ | 108,900 |  |

[0001564590-16-024924:notes:20]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Enterasys.  The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001564590-16-024924:notes:21]
The Company had an indefinite-lived asset of $3.0 million as of the Acquisition Date which represents the fair value of in-process research and development activities.  The Company completed the research and development efforts in the fourth quarter of fiscal 2014 and has determined that the asset is an identifiable intangible asset with an estimated useful life of three years.  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013. For the year ended June 30, 2014, $227.7 million of revenue and $13.5 million of operating income from Enterasys are included in the consolidated statement of operations.  The Company incurred $6.0 million of acquisition-related expenses for the year ended June 30, 2014. Such acquisition-related costs are included in "Acquisition and integration costs" on the consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees payable to financial and legal advisors.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-16-024924:notes:22]
3. Summary of Significant Accounting Policies

[0001564590-16-024924:notes:23]
Revenue Recognition

[0001564590-16-024924:notes:24]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001564590-16-024924:notes:25]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP.  The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

[0001564590-16-024924:notes:26]
Pursuant to the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.

[0001564590-16-024924:notes:27]
The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company generally recognizes product revenue from its value-added resellers, non-stocking distributors and end-user customers at the time of shipment, provided that persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and collection of the sales proceeds is reasonably assured.  In instances where the criteria for revenue recognition are not met, revenue is deferred until all criteria have been met. Sales taxes collected from customers are excluded from revenues.

[0001564590-16-024924:notes:28]
The Company sells its products and maintenance contracts to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The Company defers recognition of revenue on all sales to its stocking distributors until the distributors sell the product, as evidenced by “sales-out” reports that the distributors provide.  The Company grants these distributors the right to return a portion of unsold inventory for the purpose of stock rotation and certain price protection rights. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction.  The Company also provides distributors with credits for changes in selling prices based on competitive conditions, and allows distributors to participate in cooperative marketing programs (See Deferred Distributors Revenue, Net of Cost of Sales to Distributors, below in this footnote for additional information).  The Company maintains estimated accruals and allowances for these exposures based upon the Company's historical experience.  In connection with cooperative advertising programs, if the Company does not meet the criteria for recognizing the expense as marketing expense the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001564590-16-024924:notes:29]
The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users. For product sales to non-stocking distributors and value-added resellers, the Company does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Accordingly, the Company recognizes revenue upon transfer of title and risk of loss or damage, generally upon shipment. In connection with cooperative advertising programs and certain price protection rights that may occur under contractual arrangements with its resellers, if the Company does not meet the criteria for recognizing the expense as marketing expense, the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001564590-16-024924:notes:30]
Allowance for Product Returns

[0001564590-16-024924:notes:31]
The Company provides an allowance for product returns based on its historical returns, analysis of credit memo data and its return policies.  The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors for which it has billed the customer for the product but has yet to recognize revenue. The allowance for product returns is a reduction of accounts receivable. If the historical data that the Company uses to calculate the estimated product returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. The allowance for product returns estimate is also impacted by the timing of the actual product return from the customer. The Company estimates and adjusts this allowance at each balance sheet date.

[0001564590-16-024924:notes:32]
The following table is a summary of our allowance for product returns (in thousands).

[0001564590-16-024924:notes:33]
| Description |  | Balance at beginning of period |  |  | Additions |  |  | (Deductions) |  |  | Balance at end of period |  |
| Year Ended June 30, 2016: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 1,080 |  |  | $ | 3,478 |  |  | $ | (2,949 | ) |  | $ | 1,609 |  |
| Year Ended June 30, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  |  | 2,700 |  |  |  | 3,306 |  |  |  | (4,926 | ) |  |  | 1,080 |  |
| Year Ended June 30, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 777 |  |  | $ | 3,063 |  |  | $ | (1,140 | ) |  | $ | 2,700 |  |

[0001564590-16-024924:notes:34]
Allowance for Doubtful Accounts

[0001564590-16-024924:notes:35]
The Company maintains an allowance for doubtful accounts which reflects its best estimate of potentially uncollectible trade receivables.  The allowance is based on both specific and general reserves.  The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position.  Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience.  The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001564590-16-024924:notes:36]
The following table is a summary of the allowance for doubtful accounts (in thousands).

[0001564590-16-024924:notes:37]
| Description |  | Balance at beginning of period |  |  | Charges to bad debt expenses |  |  | Deductions (1) |  |  | Balance at end of period |  |
| Year Ended June 30, 2016: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,316 |  |  | $ | 834 |  |  | $ | (502 | ) |  | $ | 1,648 |  |
| Year Ended June 30, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  |  | 918 |  |  |  | 940 |  |  |  | (542 | ) |  |  | 1,316 |  |
| Year Ended June 30, 2014: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 475 |  |  | $ | 468 |  |  | $ | (25 | ) |  | $ | 918 |  |

[0001564590-16-024924:notes:38]
| (1) | Uncollectible accounts written off, net of recoveries |

[0001564590-16-024924:notes:39]
Concentrations

[0001564590-16-024924:notes:40]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments.  The Company does not invest an amount exceeding 10% of its combined cash or cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001564590-16-024924:notes:41]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-16-024924:notes:42]
The following table sets forth major customers accounting for 10% or more of our net revenue:

[0001564590-16-024924:notes:43]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Tech Data Corporation |  |  | 17 | % |  |  | 15 | % |  |  | 11 | % |
| Westcon Group Inc. |  |  | 14 | % |  |  | 15 | % |  |  | 11 | % |
| Jenne |  |  | 14 | % |  | * |  |  | * |  |

[0001564590-16-024924:notes:44]
| * | Less than 10% of net revenue |

[0001564590-16-024924:notes:45]
The following table sets forth major customers accounting for 10% or more of our accounts receivable balance.

[0001564590-16-024924:notes:46]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Westcon Group Inc. |  |  | 19 | % |  |  | 27 | % |  |  | 19 | % |
| Tech Data Corporation |  |  | 11 | % |  | * |  |  |  | 13 | % |

[0001564590-16-024924:notes:47]
| * | Less than 10% of accounts receivable |

[0001564590-16-024924:notes:48]
Inventory Valuation

[0001564590-16-024924:notes:49]
The Company's inventory balance as of June 30, 2016 and 2015 was $41.0 million and $58.0 million, respectively. The Company values its inventory at lower of cost or market.  Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis.  The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand.  At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.  Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-16-024924:notes:50]
The following is a summary of our inventory by category (in thousands).

[0001564590-16-024924:notes:51]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Finished goods |  | $ | 38,751 |  |  | $ | 55,301 |  |
| Raw materials |  |  | 2,238 |  |  |  | 2,713 |  |
| Total Inventory |  | $ | 40,989 |  |  | $ | 58,014 |  |

[0001564590-16-024924:notes:52]
Cash Equivalents, Short-Term Investments and Marketable Securities

[0001564590-16-024924:notes:53]
The following is a summary of Cash and Available-for-Sale Securities (in thousands)

[0001564590-16-024924:notes:54]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Cash |  | $ | 89,847 |  |  | $ | 71,455 |  |
| Cash equivalents |  | $ | 4,275 |  |  | $ | 4,770 |  |
| Total available-for-sale |  | $ | 4,275 |  |  | $ | 4,770 |  |
| Total cash, cash equivalents and available for sale securities |  | $ | 94,122 |  |  | $ | 76,225 |  |

[0001564590-16-024924:notes:55]
Available-for-Sale Securities

[0001564590-16-024924:notes:56]
The following is a summary of available-for-sale securities (in thousands):

[0001564590-16-024924:notes:57]
|  |  |  |  |  |  |  |  |  |  | Unrealized |  |  | Unrealized |  |
|  |  | Amortized |  |  |  |  |  |  | Holding |  |  | Holding |  |
|  |  | Cost |  |  | Fair Value |  |  | Gains |  |  | Losses |  |
| June 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |
| June 30, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,770 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,770 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 4,770 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,770 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |

[0001564590-16-024924:notes:58]
The Company did not have any available-for sale investments in debt securities at June 30, 2016.

[0001564590-16-024924:notes:59]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with maturities of greater than three months, but less than one year at the balance sheet date are classified as Short-term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

[0001564590-16-024924:notes:60]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value.  The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes a other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001564590-16-024924:notes:61]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method.  Realized gains or losses recognized on the sale of investments were not significant for fiscal 2016, 2015 or 2014.  As of June 30, 2016 and June 30, 2015, the Company did not hold any investment securities.   For investments that were in an unrealized loss position as of June 30, 2014, the Company recorded an other-than-temporary impairment loss of $158,000 during the year ended June 30, 2014.

[0001564590-16-024924:notes:62]
Fair Value of Financial Instruments

[0001564590-16-024924:notes:63]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3).  The three levels are defined as follows:

[0001564590-16-024924:notes:64]
|  | · | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-16-024924:notes:65]
|  | · | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-16-024924:notes:66]
|  | · | Level 3 Inputs - unobservable inputs reflecting the Company's own assumptions in measuring the asset or liability at fair value. |

[0001564590-16-024924:notes:67]
The Company did not hold any financial liabilities that required measurement at fair value on a recurring basis.  The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis (in thousands):

[0001564590-16-024924:notes:68]
| June 30, 2016 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,275 |  |
| Total |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,275 |  |

[0001564590-16-024924:notes:69]
| June 30, 2015 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |
| Total |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |

[0001564590-16-024924:notes:70]
Level 2 investments: the Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2.  There were no transfers of assets or liabilities between Level 1 and Level 2 during the fiscal years 2016 or 2015.

[0001564590-16-024924:notes:71]
The fair value of the borrowings under the credit facility is estimated based on valuations provided by alternative pricing sources supported by observable inputs which are considered Level 2.  The carrying amount and estimated fair value of the Company’s total long-term indebtedness, including current portion was $55.5 million and $66.9 million as of June 30, 2016 and 2015, respectively.

[0001564590-16-024924:notes:72]
Level 3 investments: The Company did not hold any Level 3 investments.

[0001564590-16-024924:notes:73]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.  There were no impairments recorded for the fiscal years 2016 or 2015.

[0001564590-16-024924:notes:74]
Long-Lived Assets

[0001564590-16-024924:notes:75]
Long-lived assets include (a) property and equipment, (b) goodwill and intangible assets, and (c) other assets.  Property and equipment, goodwill and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable.  If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. The Company reduces the carrying value of service inventory to net realizable value based on expected quantities needed to satisfy contractual service requirements of customers.

[0001564590-16-024924:notes:76]
(a) Property and Equipment, Net

[0001564590-16-024924:notes:77]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets.  Estimated useful lives of one to four years are used for computer equipment and software.  Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years). Property and equipment consist of the following (in thousands):

[0001564590-16-024924:notes:78]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Computer equipment |  | $ | 34,657 |  |  | $ | 32,753 |  |
| Purchased software |  |  | 5,574 |  |  |  | 5,425 |  |
| Office equipment, furniture and fixtures |  |  | 10,385 |  |  |  | 10,908 |  |
| Leasehold improvements |  |  | 19,342 |  |  |  | 24,293 |  |
| Total property and equipment |  |  | 69,958 |  |  |  | 73,379 |  |
| Less: accumulated depreciation and amortization |  |  | (40,378 | ) |  |  | (33,517 | ) |
| Property and equipment, net |  | $ | 29,580 |  |  | $ | 39,862 |  |

[0001564590-16-024924:notes:79]
(b) Goodwill and Intangibles

[0001564590-16-024924:notes:80]
As part of the acquisition of Enterasys, the Company acquired $70.9 million in goodwill which has been allocated to the Company's only reportable segment, the development and marketing of network infrastructure equipment.

[0001564590-16-024924:notes:81]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-16-024924:notes:82]
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 70,877 |  |  | $ | 70,877 |  |
| Changes during period |  |  | — |  |  |  | — |  |
| Balance at end of period |  | $ | 70,877 |  |  | $ | 70,877 |  |

[0001564590-16-024924:notes:83]
The following tables summarize the components of gross and net intangible asset balances (dollars in thousands):

[0001564590-16-024924:notes:84]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 0.20 years |  | $ | 48,000 |  |  | $ | 43,028 |  |  | $ | 4,972 |  |
| Customer relationships |  | 0.30 years |  |  | 37,000 |  |  |  | 32,889 |  |  |  | 4,111 |  |
| Maintenance contracts |  | 2.30 years |  |  | 17,000 |  |  |  | 9,067 |  |  |  | 7,933 |  |
| Trademarks |  | 0.30 years |  |  | 2,500 |  |  |  | 2,222 |  |  |  | 278 |  |
| License agreements |  | 9.70 years |  |  | 3,413 |  |  |  | 1,473 |  |  |  | 1,940 |  |
| Other intangibles |  | 3.70 years |  |  | 1,428 |  |  |  | 900 |  |  |  | 528 |  |
| Total intangibles, net |  |  |  | $ | 109,341 |  |  | $ | 89,579 |  |  | $ | 19,762 |  |

[0001564590-16-024924:notes:85]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 1.20 years |  | $ | 48,000 |  |  | $ | 28,194 |  |  | $ | 19,806 |  |
| Customer relationships |  | 1.30 years |  |  | 37,000 |  |  |  | 20,556 |  |  |  | 16,444 |  |
| Maintenance contracts |  | 3.30 years |  |  | 17,000 |  |  |  | 5,667 |  |  |  | 11,333 |  |
| Trademarks |  | 1.30 years |  |  | 2,500 |  |  |  | 1,389 |  |  |  | 1,111 |  |
| Order backlog |  | 0.30 years |  |  | 7,400 |  |  |  | 6,967 |  |  |  | 433 |  |
| License agreements |  | 10.20 years |  |  | 10,924 |  |  |  | 8,620 |  |  |  | 2,304 |  |
| Other intangibles |  | 3.80 years |  |  | 2,684 |  |  |  | 1,983 |  |  |  | 701 |  |
| Total intangibles, net |  |  |  | $ | 125,508 |  |  | $ | 73,376 |  |  | $ | 52,132 |  |

[0001564590-16-024924:notes:86]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-16-024924:notes:87]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Amortization in "Cost of revenue for products" |  | $ | 15,369 |  |  | $ | 18,082 |  |  | $ | 12,060 |  |
| Amortization of intangibles |  |  | 17,001 |  |  |  | 17,869 |  |  |  | 16,711 |  |
| Total amortization |  | $ | 32,370 |  |  | $ | 35,951 |  |  | $ | 28,771 |  |

[0001564590-16-024924:notes:88]
The amortization expense that is recognized in "Cost of revenues for products" is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-16-024924:notes:89]
The estimated future amortization expense to be recorded for each of the next five years is as follows (in thousands):

[0001564590-16-024924:notes:90]
| For the fiscal year ending: |  |  |  |  |
| 2017 |  | $ | 13,323 |  |
| 2018 |  |  | 3,724 |  |
| 2019 |  |  | 1,457 |  |
| 2020 |  |  | 264 |  |
| 2021 |  |  | 139 |  |
| Thereafter, |  |  | 855 |  |
| Total |  | $ | 19,762 |  |

[0001564590-16-024924:notes:91]
(c) Other Assets

[0001564590-16-024924:notes:92]
Other assets primarily consists of service inventory and long term deposits. The Company holds service inventory to support customers who have purchased service contracts with a hardware replacement element, as well as to support our warranty program. See Inventory Valuation above in this footnote for additional information.  The Company held service inventory of $16.0 million and $18.1 million as of June 30, 2016 and 2015, respectively.

[0001564590-16-024924:notes:93]
Deferred Revenue, Net

[0001564590-16-024924:notes:94]
Deferred revenue, net represents amounts for (i) deferred maintenance revenue and (ii) deferred product revenue net of the related cost of revenue and other (professional services and training) when the revenue recognition criteria have not been met.  The following table summarizes deferred revenue (in thousands):

[0001564590-16-024924:notes:95]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Deferred maintenance revenue |  | $ | 83,419 |  |  | $ | 87,441 |  |
| Deferred product and other revenue |  |  | 11,441 |  |  |  | 12,341 |  |
| Total deferred revenue, net |  |  | 94,860 |  |  |  | 99,782 |  |
| Less: current portion |  |  | 72,934 |  |  |  | 76,551 |  |
| Non-current deferred revenue, net |  | $ | 21,926 |  |  | $ | 23,231 |  |

[0001564590-16-024924:notes:96]
The Company offers for sale to its customers, renewable support arrangements, including extended warranty contracts that range generally from one to five years. Deferred support revenue is included within deferred revenue, net within the maintenance revenue category above. The change in the Company’s deferred maintenance revenue balance in relation to these arrangements was as follows (in thousands):

[0001564590-16-024924:notes:97]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Balance beginning of period |  | $ | 87,441 |  |  | $ | 89,657 |  |
| New maintenance arrangements |  |  | 110,192 |  |  |  | 119,906 |  |
| Recognition of maintenance revenue |  |  | (114,214 | ) |  |  | (122,122 | ) |
| Balance end of period |  |  | 83,419 |  |  |  | 87,441 |  |
| Less: current portion |  |  | 61,493 |  |  |  | 64,210 |  |
| Non-current deferred revenue |  | $ | 21,926 |  |  | $ | 23,231 |  |

[0001564590-16-024924:notes:98]
Deferred Distributors Revenue, Net of Cost of Sales to Distributors

[0001564590-16-024924:notes:99]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay on a current basis for product delivered.  The Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its consolidated balance sheets.  Deferred distributors revenue, net of cost of sales to distributors effectively represents the gross margin on the sale to the distributor; however, the amount of gross margin the Company recognizes in future periods will frequently be less than the originally recorded deferred distributors revenue, net of cost of sales to distributors as a result of price concessions negotiated at time of sell-through to end customers.  The Company sells each item in its product catalog to all of its distributors worldwide at contractually discounted prices.  However, distributors resell the Company’s products to end customers at a very broad range of individually negotiated price points based on customer, product, quantity, geography, and other competitive conditions which results in the Company remitting back to the distributors a portion of their original purchase price after the resale transaction is completed.  Thus, a portion of the deferred revenue balance represents a portion of distributors’ original purchase price that will be remitted back to the distributors in the future.  The wide range and variability of negotiated price credits granted to distributors does not allow the Company to accurately estimate the portion of the balance in the deferred revenue that will be remitted to the distributors.  Therefore, the Company does not reduce deferred revenue by anticipated future price credits; instead, price credits are recorded against revenue when incurred, which is generally at the time the distributor sells the product.

[0001564590-16-024924:notes:100]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors (in thousands):

[0001564590-16-024924:notes:101]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Deferred distributors revenue |  | $ | 35,138 |  |  | $ | 53,366 |  |
| Deferred cost of sales to distributors |  |  | (8,321 | ) |  |  | (12,491 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | $ | 26,817 |  |  | $ | 40,875 |  |

[0001564590-16-024924:notes:102]
Debt

[0001564590-16-024924:notes:103]
The Company's debt is comprised of the following (in thousands):

[0001564590-16-024924:notes:104]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 17,875 |  |  | $ | 11,375 |  |
| Current portion of long-term debt |  | $ | 17,875 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 27,625 |  |  | $ | 45,500 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 37,625 |  |  |  | 55,500 |  |
| Total debt |  | $ | 55,500 |  |  | $ | 66,875 |  |

[0001564590-16-024924:notes:105]
The Company's debt repayment schedule by period is as follows (in thousands):

[0001564590-16-024924:notes:106]
| For the fiscal year ending: |  |  |  |  |
| 2017 |  | $ | 17,875 |  |
| 2018 |  |  | 21,938 |  |
| 2019 |  |  | 15,687 |  |
| Total |  | $ | 55,500 |  |

[0001564590-16-024924:notes:107]
On October 31, 2013, the Company entered into a credit agreement which provides for a $60 million five-year Revolving Facility and a $65 million five-year Term Loan (together the “Senior Secured Credit Facilities”).  The Company used the proceeds from the Term Loan and also drew $35 million of the Revolving Facility for the purchase of all of the issued and outstanding capital stock of Enterasys.  The Company has availability of borrowings from the Revolving Facility of $34.1 million as of June 30, 2016.

[0001564590-16-024924:notes:108]
In the fourth quarter of fiscal 2015, the Company amended the Senior Secured Credit Facilities.  The amendment, among other items, reduced the lenders commitment by $10.0 million to a total of $115.0 million.  The amended commitment provides for a $50 million five-year Revolving Facility.  Borrowings under the Senior Secured Credit Facilities, as amended, bear interest, at the Company's election, at a rate per annum equal to an agreed to applicable margin plus (a) the higher of the prime rate in effect on such day or the federal funds effective rate in effect on such day plus 0.75% or (b) an adjusted Libor rate.  In addition, the Company is required to pay a quarterly commitment fee of between 0.375% and 0.50% (currently 0.375%) on the unused portion of the Revolving Facility based on the Company’s Consolidated Leverage Ratio.  Principal installments are payable on the Term Loan in varying percentages quarterly starting December 31, 2013 and to the extent not previously paid, all outstanding balances are to be paid at maturity. If not repaid before maturity, the draws on the Revolving Facility shall be repaid on the original maturity date. The Senior Secured Credit Facilities, as amended, are secured by substantially all of the Company’s assets and are jointly and severally guaranteed by the Company and certain of its subsidiaries.

[0001564590-16-024924:notes:109]
The Senior Secured Credit Facilities, as amended contain financial covenants that require the Company to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other financial and non-financial covenants and restrictions that limit the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets, etc.  These covenants, which are described more fully in the Senior Secured Credit Facilities, as amended, (incorporated herein by reference on Form 8-K) to which reference is made for a complete statement of the covenants, are subject to certain exceptions. The Company is in compliance with its covenants.

[0001564590-16-024924:notes:110]
The Senior Secured Credit Facilities, as amended, also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by the Company is false or misleading in any material respect, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended, may be accelerated upon certain events of default.

[0001564590-16-024924:notes:111]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $1.3 million of financing costs related to the initial Senior Secured Credit Facilities during the year ended June 30, 2014.  During the year ended June 30, 2015, in conjunction with the amending of the Senior Secured Credit Facilities noted above, the Company incurred an additional $0.5 million of costs.  Amortization of deferred financing costs is included in "Interest expense" in the consolidated statements of operations, totaled $0.5 million, $0.4 million and $0.2 million in fiscal years 2016, 2015 and 2014, respectively.

[0001564590-16-024924:notes:112]
The Company had $0.9 million of outstanding letters of credit as of June 30, 2016 and 2015.

[0001564590-16-024924:notes:113]
Guarantees and Product Warranties

[0001564590-16-024924:notes:114]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates.  The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-16-024924:notes:115]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty.  The following table summarizes the activity related to the Company’s product warranty liability during the following period (in thousands):

[0001564590-16-024924:notes:116]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Balance beginning of period |  | $ | 8,676 |  |  | $ | 7,551 |  |
| New warranties issued |  |  | 8,176 |  |  |  | 8,822 |  |
| Warranty expenditures |  |  | (7,252 | ) |  |  | (7,697 | ) |
| Balance end of period |  | $ | 9,600 |  |  | $ | 8,676 |  |

[0001564590-16-024924:notes:117]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-16-024924:notes:118]
Other Accrued Liabilities

[0001564590-16-024924:notes:119]
The following are the components of other accrued liabilities (in thousands):

[0001564590-16-024924:notes:120]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Accrued general and administrative costs |  | $ | 4,079 |  |  | $ | 1,204 |  |
| Restructuring |  |  | 2,522 |  |  |  | 5,854 |  |
| Other accrued liabilities |  |  | 20,090 |  |  |  | 25,565 |  |
| Total other accrued liabilities |  | $ | 26,691 |  |  | $ | 32,623 |  |

[0001564590-16-024924:notes:121]
Advertising

[0001564590-16-024924:notes:122]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue.  All other advertising costs are expensed as incurred.  Advertising expenses were $0.3 million, $0.5 million and $0.5 million in fiscal years 2016, 2015 and 2014, respectively.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-16-024924:notes:123]
4. Recently Issued Accounting Pronouncements

[0001564590-16-024924:notes:124]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-09 (Topic 718), Compensation – Stock Compensation (“ASU 2016-09”) which identifies areas for simplification involving several aspects of accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, an option to recognize gross stock compensation expense with actual forfeitures recognized as they occur, as well as certain classifications on the statement of cash flows. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2018.

[0001564590-16-024924:notes:125]
In March 2016, the FASB issued ASU No. 2016-06 (Topic 815), Derivatives and Hedging– Contingent Put and Call Options in Debt Instruments (“ASU 2016-06”), which will reduce diversity of practice in identifying embedded derivatives in debt instruments. ASU 2016-06 clarifies that the nature of an exercise contingency is not subject to the “clearly and closely” criteria for purposes of assessing whether the call or put option must be separated from the debt instrument and accounted for separately as a derivative. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2018.

[0001564590-16-024924:notes:126]
In February 2016, the FASB issued ASU No. 2016-02 (Topic 842), Leases (“ASU 2016-02”) which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under ASU 2016-02, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the income statement will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of ASU 2016-02 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, ASU 2016-02 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2020.

[0001564590-16-024924:notes:127]
In January 2016, the FASB issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities.  The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2019.

[0001564590-16-024924:notes:128]
In May 2014, the FASB issued ASU No. 2014-09 (Topic 606)—Revenue from Contracts with Customers (“ASU 2014-09”) which provides guidance for revenue recognition. This ASU affects all contracts that the Company enters into with customers to transfer goods and services or for the transfer of nonfinancial assets. This ASU will supersede the revenue recognition requirements in Topic 605, and most industry specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard's core principle is that revenue is recognized when promised goods or services are transferred to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods or services. In doing so, the Company will need to use additional judgment and estimates than under the existing guidance. These may include identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. In August 2015, the FASB issued ASU 2015-14 which deferred the effective date of the new revenue standard from December 15, 2016 to December 15, 2017, with early adoption permitted as of annual reporting periods beginning after December 15, 2016. Accordingly, the ASU will be effective for the Company beginning fiscal year 2019.  In addition, in March 2016, the FASB issued ASU No. 2016-08 (Topic 606) Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net) (“ASU 2016-08”), which clarifies the principal-versus-agent guidance in Topic 606 and requires an entity to determine whether the nature of its promise to provide goods or services to a customer is performed in a principal or agent capacity and to recognize revenue in a gross or net manner based on its principal/agent designation. In April 2016, the FASB also issued ASU No. 2016-10 (Topic 606) Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing (“ASU 2016-10”), which amends the revenue guidance on identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB also issued ASU No. 2016-12 (Topic 606) Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”), which amends the revenue guidance to clarify measurement and presentation as well as to include some practical expedients and policy elections. There are two transition methods available under the new standard, either cumulative effect or retrospective. ASU 2016-08, ASU 2016-10, and ASU 2016-12 must be adopted concurrently with the adoption of ASU 2014-09. The Company is currently evaluating the impact of the adoption of this standard on its Consolidated Financial Statements and disclosures.

[0001564590-16-024924:notes:129]
In April 2015, the FASB issued ASU No. 2015-03 - Simplifying the Presentation of Debt Issuance Costs (“ASU 2015-03”), which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. ASU 2015-03 requires retrospective adoption and will be effect for annual and interim periods in fiscal years beginning after December 15, 2015. Adoption of this standard will not have a material impact on our financial statements and footnote disclosures.  This guidance will become effective for the Company beginning with its fiscal year 2017.

[0001564590-16-024924:notes:130]
Recently Adopted Accounting Pronouncements

[0001564590-16-024924:notes:131]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes ("ASU 2015-17"), which simplifies the presentation of deferred tax assets and deferred tax liabilities. The new guidance no longer requires the presentation of current deferred tax assets and deferred tax liabilities on a classified balance sheet, rather requiring all to be presented as non-current. This guidance is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. The Company prospectively adopted this guidance in the fourth quarter of fiscal 2016. As required by this guidance, all deferred tax assets and liabilities are classified as non-current in our consolidated balance sheet as of June 30, 2016, which is a change from our historical presentation wherein certain of our deferred tax assets and liabilities were classified as current and the remainder were classified as non-current. The June 30, 2015 balance sheet has not been retrospectively adjusted. As this guidance impacts presentation only, the adoption of ASU 2015-17 did not have an impact on the results of operations or cash flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-024924:notes:132]
5. Commitments, Contingencies and Leases

[0001564590-16-024924:notes:133]
Leases

[0001564590-16-024924:notes:134]
The Company currently leases its current headquarters, research and development facilities and office spaces for its various United States and international operations. Certain leases contain rent escalation clauses and renewal options. As part of the Company’s existing leased facilities, the Company has received lease incentives which take the form of a fixed allowance towards lease improvements on the respective facility. The Company used the allowance to make leasehold improvements which are being depreciated over the useful life of the assets or the lease term, whichever is shorter. The offsetting lease incentives liability is being amortized on a straight-line basis over the term of the lease as an offset to rent expense.

[0001564590-16-024924:notes:135]
Future annual minimum lease payments under all non-cancelable operating leases having initial or remaining lease terms in excess of one year at June 30, 2016 were as follows (in thousands):

[0001564590-16-024924:notes:136]
| For the fiscal year ending: |  | Future Lease Payments |  |
| 2017 |  | $ | 9,733 |  |
| 2018 |  |  | 8,794 |  |
| 2019 |  |  | 8,322 |  |
| 2020 |  |  | 8,065 |  |
| 2021 |  |  | 7,401 |  |
| Thereafter |  |  | 13,076 |  |
| Total minimum payments |  | $ | 55,391 |  |

[0001564590-16-024924:notes:137]
Rent expense was $8.5 million, $11.1 million and $10.2 million in fiscal years 2016, 2015 and 2014, respectively.

[0001564590-16-024924:notes:138]
Purchase Commitments

[0001564590-16-024924:notes:139]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2016, the Company had non-cancelable commitments to purchase $63.7 million of such inventory, which will be received and consumed during the first half of fiscal 2017

[0001564590-16-024924:notes:140]
Legal Proceedings

[0001564590-16-024924:notes:141]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-16-024924:notes:142]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-16-024924:notes:143]
Brazilian Tax Assessment Matters

[0001564590-16-024924:notes:144]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.0 million), plus interest and penalties BRL  16.6 million (US $5.1 million).  Possible court fees are estimated to be BRL 4.0 million (US $1.2 million).  All currency conversions in this Legal Proceedings section are as of June 30, 2016.  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

[0001564590-16-024924:notes:145]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits are expected to cover the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company changed its ICMS procedures effective May 2009 and a similar tax assessment is not anticipated.  The Company has provided the requested information for these tax years to the Brazilian tax authorities, but has received no further response from the Brazilian tax authorities.

[0001564590-16-024924:notes:146]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL  24.0 million (US $7.3 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $2.9 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

[0001564590-16-024924:notes:147]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from the Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

[0001564590-16-024924:notes:148]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-16-024924:notes:149]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from November 4, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  Lead plaintiff will file a consolidated complaint, which the defendants expect to move to dismiss.  The Company believes the claims are without merit and intends to vigorously defend the claims.

[0001564590-16-024924:notes:150]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and have submitted a stipulation to that effect to the court.

[0001564590-16-024924:notes:151]
Indemnification Obligations

[0001564590-16-024924:notes:152]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of June 30, 2016, the Company had no outstanding indemnification claims.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-16-024924:notes:153]
6. Stockholders’ Equity

[0001564590-16-024924:notes:154]
Preferred Stock

[0001564590-16-024924:notes:155]
In April 2001, in connection with the entering into of the Company's Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2016, no shares of preferred stock were outstanding.

[0001564590-16-024924:notes:156]
Stockholders’ Rights Agreement

[0001564590-16-024924:notes:157]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of our Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as subsequently amended, between us and Mellon Investor Services LLC (the “Prior Rights Plan”).

[0001564590-16-024924:notes:158]
The Board adopted the Restated Rights Plan to preserve the value of our deferred tax assets, including our net operating loss carry forwards, with respect to our ability to fully use its tax benefits to offset future income which may be limited if we experience an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of our common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of us and our stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 our Board and shareholders have approved an amendment providing for a one year extension of the term of the Restated Rights Plan.  Our Board of Directors unanimously approved an amendment to the Restated Rights Plan on May 5, 2016 to extend the Restated Rights Plan through May 31, 2017, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting, expected to be held on November 18, 2016.

[0001564590-16-024924:notes:159]
Shares Reserved for Issuance

[0001564590-16-024924:notes:160]
The following are shares reserved for issuance (in thousands):

[0001564590-16-024924:notes:161]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| 2014 Employee Stock Purchase Plan |  |  | 10,001 |  |  |  | 12,000 |  |
| Employee stock options and awards outstanding |  |  | 10,609 |  |  |  | 15,273 |  |
| Employee stock options and awards available for grant |  |  | 5,401 |  |  |  | 5,450 |  |
| Total shares reserved for issuance |  |  | 26,011 |  |  |  | 32,723 |  |

[0001564590-16-024924:notes:162]
The following table summarizes the transfer of shares between the respective plans for the periods presented (in thousands):

[0001564590-16-024924:notes:163]
|  |  | 2005 Plan |  |  | 2013 Plan |  |  | Total |  |
| Shares available at June 30, 2014 |  |  | — |  |  |  | 8,762 |  |  |  | 8,762 |  |
| Granted |  |  | — |  |  |  | (7,060 | ) |  |  | (7,060 | ) |
| Canceled |  |  | 1,537 |  |  |  | 2,211 |  |  |  | 3,748 |  |
| Transferred |  |  | (1,537 | ) |  |  | 1,537 |  |  |  | — |  |
| Shares available at June 30, 2015 |  |  | — |  |  |  | 5,450 |  |  |  | 5,450 |  |
| Granted |  |  | — |  |  |  | (5,141 | ) |  |  | (5,141 | ) |
| Canceled |  |  | 5,803 |  |  |  | — |  |  |  | 5,803 |  |
| Transferred |  |  | (5,092 | ) |  |  | 5,092 |  |  |  | — |  |
| Retired |  |  | (711 | ) |  |  | — |  |  |  | (711 | ) |
| Shares available at June 30, 2016 |  |  | — |  |  |  | 5,401 |  |  |  | 5,401 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-024924:notes:164]
7. Employee Benefit Plans (including Share-based Compensation)

[0001564590-16-024924:notes:165]
As of June 30, 2016, the Company has the following share-based compensation plans:

[0001564590-16-024924:notes:166]
2013 Equity Incentive Plan

[0001564590-16-024924:notes:167]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaces the 2005 Equity Incentive Plan (the "2005 Plan").  Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants.  The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees.  The 2013 Plan authorizes the issuance of 9,000,000 shares of the Company’s common stock.  In addition, up to 12,709,153 shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan.  The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted.  Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting.  As of June 30, 2016, total options and awards to acquire 5,845,085 shares were outstanding under the 2013 Plan and 5,401,052 shares are available for grant under the 2013 Plan.  Options granted under this plan have a contractual term of seven years.

[0001564590-16-024924:notes:168]
Enterasys 2013 Stock Plan

[0001564590-16-024924:notes:169]
Pursuant to the acquisition of Enterasys on October 31, 2013, the Company assumed the Enterasys 2013 Stock Plan (the "Enterasys Plan"). As of June 30, 2016, total options and awards to acquire 2,009,138 shares were outstanding under the Enterasys Plan.  Options granted under this plan have a contractual term of seven years.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired in the Enterasys Plan. No future grants may be made from the Enterasys Plan.

[0001564590-16-024924:notes:170]
2005 Equity Incentive Plan

[0001564590-16-024924:notes:171]
The 2005 Plan was adopted by the Company’s Board of Directors on October 20, 2005, and approved by stockholders on December 2, 2005.  The 2005 Plan replaced the Amended 1996 Stock Option Plan (the “1996 Plan”), the 2000 Non-statutory Stock Option Plan and the 2001 Non-statutory Stock Option Plan.  The 2005 Plan includes provisions upon the granting of certain awards defined by the 2005 Plan as Full Value Awards in which the shares available for grant under the 2005 Plan are decremented 1.5 shares for each such award granted.  Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2005 Plan for future issuance as was applied upon granting. Effective November 20, 2013, the 2005 Plan was replaced with the 2013 Plan, and, as of June 30, 2016, total options and awards to acquire 2,754,804 shares were outstanding under the 2005 Plan.  No future grants may be made from the 2005 Plan, however, outstanding options and awards forfeited or canceled were allowed to be  transferred to the 2013 Plan until December 2, 2015, at which time, no further shares may be transferred.  To date there have been 6,628,643 shares transferred to the 2013 Plan.

[0001564590-16-024924:notes:172]
Amended 1996 Stock Option Plan

[0001564590-16-024924:notes:173]
The 1996 Plan was originally adopted in September 1996, and provided for the grant of options for common stock to eligible participants.  Effective December 2, 2005, the 1996 Plan was terminated, and, as of June 30, 2016, no options to acquire shares remain outstanding under the 1996 Plan. No future grants may be made from the 1996 Plan.

[0001564590-16-024924:notes:174]
The following table summarizes stock option activity under all plans (shares and intrinsic value in thousands):

[0001564590-16-024924:notes:175]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2015 |  |  | 10,604 |  |  | $ | 4.03 |  |  |  | 3.79 |  |  | $ | 410 |  |
| Granted |  |  | 5 |  |  | $ | 3.79 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (382 | ) |  | $ | 3.21 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (3,842 | ) |  | $ | 3.99 |  |  |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2016 |  |  | 6,385 |  |  | $ | 4.10 |  |  |  | 3.70 |  |  | $ | 1,416 |  |
| Exercisable at June 30, 2016 |  |  | 4,676 |  |  | $ | 4.28 |  |  |  | 2.82 |  |  | $ | 602 |  |
| Vested and expected to vest at June 30, 2016 |  |  | 6,122 |  |  | $ | 4.14 |  |  |  | 3.21 |  |  | $ | 1,254 |  |

[0001564590-16-024924:notes:176]
The following table summarizes significant ranges of outstanding and exercisable options at June 30, 2016 (shares outstanding and exercisable, in thousands):

[0001564590-16-024924:notes:177]
| Options Outstanding |  |  | Options Exercisable |  |
|  |  |  |  |  |  | Weighted- |  |  | Weighted- |  |  |  |  |  |  | Weighted- |  |
|  |  | Number |  |  | Average |  |  | Average |  |  | Number |  |  | Average |  |
| Range of |  | Outstanding |  |  | Remaining |  |  | Exercise |  |  | Exercisable |  |  | Exercise |  |
| Exercise Prices |  | (000’s) |  |  | Contractual Life |  |  | Price |  |  | (000’s) |  |  | Price |  |
|  |  |  |  |  |  | (In years) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| $1.69 – $2.32 |  |  | 258 |  |  |  | 1.90 |  |  | $ | 2.06 |  |  |  | 258 |  |  | $ | 2.06 |  |
| $2.51 – $2.51 |  |  | 1,006 |  |  |  | 5.84 |  |  | $ | 2.51 |  |  |  | 107 |  |  | $ | 2.51 |  |
| $2.82 – $3.29 |  |  | 672 |  |  |  | 2.03 |  |  | $ | 3.13 |  |  |  | 615 |  |  | $ | 3.15 |  |
| $3.38 – $3.55 |  |  | 686 |  |  |  | 2.38 |  |  | $ | 3.51 |  |  |  | 555 |  |  | $ | 3.50 |  |
| $3.58 – $4.25 |  |  | 1,143 |  |  |  | 1.27 |  |  | $ | 4.01 |  |  |  | 1,102 |  |  | $ | 4.01 |  |
| $4.29 – $4.29 |  |  | 2 |  |  |  | 0.69 |  |  | $ | 4.29 |  |  |  | 2 |  |  | $ | 4.29 |  |
| $5.21 – $5.21 |  |  | 204 |  |  |  | 1.61 |  |  | $ | 5.21 |  |  |  | 175 |  |  | $ | 5.21 |  |
| $5.30 – $5.30 |  |  | 1,923 |  |  |  | 4.25 |  |  | $ | 5.30 |  |  |  | 1,559 |  |  | $ | 5.30 |  |
| $5.67 – $5.67 |  |  | 446 |  |  |  | 3.47 |  |  | $ | 5.67 |  |  |  | 269 |  |  | $ | 5.67 |  |
| $6.15 – $6.15 |  |  | 45 |  |  |  | 3.39 |  |  | $ | 6.15 |  |  |  | 34 |  |  | $ | 6.15 |  |
| $1.69 – $6.15 |  |  | 6,385 |  |  |  | 3.70 |  |  | $ | 4.10 |  |  |  | 4,676 |  |  | $ | 4.28 |  |

[0001564590-16-024924:notes:178]
The total intrinsic value of options exercised in fiscal years 2016, 2015 and 2014 was $0.2 million, $0.4 million and $4.1 million, respectively.

[0001564590-16-024924:notes:179]
Stock Awards

[0001564590-16-024924:notes:180]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors.  Stock awards generally provide for the issuance of restricted stock units (including performance or market-based restricted stock units (“PSU”)) which vest over a fixed period of time or based upon the satisfaction of certain performance criteria. The Company recognizes compensation expense on the awards over the vesting period based on the award’s intrinsic value as of the date of grant.

[0001564590-16-024924:notes:181]
During fiscal 2016 and fiscal 2015, the Company began expensing PSU’s with market or performance based conditions to senior executive officers that had been granted during fiscal 2016 and fiscal 2015. The Company uses a Monte-Carlo simulation model to determine the fair value and the derived service period of PSU’s, with market or performance conditions or combinations of those conditions with a service condition, on the date of grant.

[0001564590-16-024924:notes:182]
The following table summarizes stock award activity (shares and market value in thousands):

[0001564590-16-024924:notes:183]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2015 |  |  | 4,597 |  |  | $ | 3.82 |  |  |  |  |  |
| Granted |  |  | 3,399 |  |  | $ | 3.15 |  |  |  |  |  |
| Vested |  |  | (2,602 | ) |  | $ | 4.20 |  |  |  |  |  |
| Cancelled |  |  | (1,170 | ) |  | $ | 2.95 |  |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2016 |  |  | 4,224 |  |  | $ | 3.36 |  |  | $ | 14,319 |  |

[0001564590-16-024924:notes:184]
The aggregate fair value, as of the respective vesting dates of RSUs vested during the fiscal years ended June 30, 2016, 2015 and 2014 was $8.6 million, $8.9 million and $6.1 million, respectively.

[0001564590-16-024924:notes:185]
For the fiscal years ended June 30, 2016, 2015 and 2014, the Company withheld an aggregate of 118,129 shares, 826,943 shares and 277,473 shares, respectively, upon the vesting of RSUs, based upon the closing share price on the vesting date to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For fiscal years 2016, 2015 and 2014, the Company then remitted cash of $0.2 million, $2.8 million and $1.6 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the consolidated statements of cash flows. The payment had the effect on shares issued by the Company as it reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital.

[0001564590-16-024924:notes:186]
Performance Grant Activity

[0001564590-16-024924:notes:187]
The following table summarizes PSU’s with market or performance based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands).

[0001564590-16-024924:notes:188]
|  |  | Fiscal year 2016 |  |  | Fiscal year 2015 |  |  | Fiscal year 2014 |  |
| Performance awards granted |  |  | 695 |  |  |  | 615 |  |  |  | — |  |
| Performance awards earned |  |  | 582 |  |  |  | — |  |  |  | — |  |

[0001564590-16-024924:notes:189]
2014 Employee Stock Purchase Plan

[0001564590-16-024924:notes:190]
In August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”).  On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12,000,000 shares. The 2014 ESPP replaced the 1999 Employee Stock Purchase Plan.  The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding.  Each purchase period has a maximum duration of six (6) months.  The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.  The 2014 ESPP currently has offerings periods of either 6 months or 24 months, commonly referred to as "look back periods".   As of June 30, 2016, there have been 1,999,625 shares issued under the 2014 ESPP.

[0001564590-16-024924:notes:191]
Effective with the offering period beginning on February 1, 2016, the Company amended the 2014 ESPP to increase the maximum shares issuable for each purchase period from 1,000,000 shares to 1,500,000 shares. Effective with the offering period beginning on August 1, 2016, the Company amended the 2014 ESPP so that all future offering periods are limited to six months and to make certain other changes to the 2014 ESPP including adding new contribution limits for each offering period.  Existing open offering periods prior to the effective date of the changes were unaffected by the amendments to the 2014 ESPP.

[0001564590-16-024924:notes:192]
1999 Employee Stock Purchase Plan

[0001564590-16-024924:notes:193]
In January 1999, the Board of Directors approved the adoption of Extreme Network’s 1999 Employee Stock Purchase Plan (the “1999 ESPP”).  On December 2, 2005, the stockholders approved an amendment to the 1999 ESPP to increase the maximum number of shares of common stock that may be issued under the plan by 5,000,000 to a total of 12,000,000 shares.  The 1999 ESPP was replaced by the 2014 ESPP.  The 1999 ESPP allowed eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation. The price at which the common stock could be purchased was 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. Through June 30, 2015, 11,933,618 shares were purchased under the 1999 ESPP.  All remaining shares available under the 1999 ESPP have been retired.

[0001564590-16-024924:notes:194]
Share Based Compensation Expense

[0001564590-16-024924:notes:195]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (in thousands):

[0001564590-16-024924:notes:196]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Cost of product revenue |  | $ | 882 |  |  | $ | 1,067 |  |  | $ | 836 |  |
| Cost of service revenue |  |  | 1,041 |  |  |  | 1,068 |  |  |  | 895 |  |
| Research and development |  |  | 4,559 |  |  |  | 5,365 |  |  |  | 4,111 |  |
| Sales and marketing |  |  | 4,633 |  |  |  | 5,170 |  |  |  | 6,430 |  |
| General and administrative |  |  | 3,677 |  |  |  | 5,131 |  |  |  | 3,650 |  |
| Total share-based compensation expense |  | $ | 14,792 |  |  | $ | 17,801 |  |  | $ | 15,922 |  |

[0001564590-16-024924:notes:197]
The amount of stock based compensation expense capitalized in inventory has been immaterial for each of the periods presented. As of June 30, 2016, there was $1.7 million of total unrecognized compensation cost related to unvested stock options. This cost is expected to be recognized over a weighted-average period of approximately 1.8 years.  As of June 30, 2016, there were $10.1 million in unrecognized compensation costs related to non-vested stock awards.  This cost is expected to be recognized over a weighted-average period of approximately 1.9 years

[0001564590-16-024924:notes:198]
The weighted-average grant-date per share fair value of options granted in fiscal years 2016, 2015 and 2014, was $1.59, $1.75 and $2.36, respectively.

[0001564590-16-024924:notes:199]
The average fair-value and the average derived service period on the grant-date for the performance-based option awards with market conditions, granted in fiscal 2015, was $1.21 and 1.9 years respectively.

[0001564590-16-024924:notes:200]
The Company uses the straight-line method for expense attribution, and the Company estimates forfeitures and only recognizes expense for those shares expected to vest.  The Company’s estimated forfeiture rate in fiscal 2016 based on the Company’s historical forfeiture experience is 13% for non-executives and 19% for executives.

[0001564590-16-024924:notes:201]
The fair value of each stock option grant under the Company's 2013 Plan and 2005 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-16-024924:notes:202]
Under the 2013 Plan the Company uses a Monte-Carlo simulation model to determine the fair value and the derived service period of option grants, with market, performance or service conditions or combinations of those conditions, on the date of grant.

[0001564590-16-024924:notes:203]
The fair value of each share purchase option under the Company's 2014 ESPP and 1999 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP and the 1999 ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on a blended rate of the implied volatilities from traded options and historical volatility on the Company’s stock.

[0001564590-16-024924:notes:204]
The weighted-average estimated per share fair value of shares purchased under the 2014 ESPP and 1999 ESPP in fiscal years 2016, 2015 and 2014, was $0.92, $0.90 and $1.64, respectively.

[0001564590-16-024924:notes:205]
|  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Expected life |  | 4.0 years |  |  | 4.23 years |  |  | 4.40 years |  |  | 1.21 years |  |  | 0.66 years |  |  | 0.25 years |  |
| Risk-free interest rate |  |  | 1.78 | % |  |  | 1.17 | % |  |  | 1.24 | % |  |  | 0.33 | % |  |  | 0.10 | % |  |  | 0.08 | % |
| Volatility |  |  | 52 | % |  |  | 50 | % |  |  | 56 | % |  |  | 58 | % |  |  | 59 | % |  |  | 58 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-16-024924:notes:206]
401(k) Plan

[0001564590-16-024924:notes:207]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $18,000 for calendar year 2016. Employees age 50 or over may elect to contribute an additional $6,000. The amount contributed to the Plan is on a pre-tax basis.

[0001564590-16-024924:notes:208]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. During the year ended June 30, 2014, eligible employees from Enterasys were also added to the Plan as of the acquisition date.  The program is to match $0.50 for every Dollar contributed by the employee up to the first 2.5% of pay.  The Company’s matching contributions to the Plan totaled $1.2 million, $1.1 million and $0.8 million, for fiscal years 2016, 2015 and 2014, respectively.  No discretionary contributions were made in fiscal years 2016, 2015 or 2014.


## us-gaap:TreasuryStockTextBlock

[0001564590-16-024924:notes:209]
8. Common Stock Repurchases and Retirement

[0001564590-16-024924:notes:210]
Common Stock Repurchases

[0001564590-16-024924:notes:211]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which were to be purchased over a three year period in the open market or in privately negotiated transactions.  All repurchased shares were retired and included in the Company's authorized but unissued shares. During the year ended June 30, 2013, the Company repurchased 4.1 million shares of common stock at a total cost of $14.5 million.  No shares were repurchased during the years ended June 30, 2016, 2015 and 2014.  On October 1, 2015 the repurchase program ended.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-024924:notes:212]
9. Income Taxes

[0001564590-16-024924:notes:213]
Income before income taxes is as follows (in thousands):

[0001564590-16-024924:notes:214]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Domestic |  | $ | (31,700 | ) |  | $ | (72,176 | ) |  | $ | (70,321 | ) |
| Foreign |  |  | 4,152 |  |  |  | 5,340 |  |  |  | 17,200 |  |
| Total |  | $ | (27,548 | ) |  | $ | (66,836 | ) |  | $ | (53,121 | ) |

[0001564590-16-024924:notes:215]
The provision for income taxes for fiscal years 2016, 2015 and 2014 consisted of the following (in thousands):

[0001564590-16-024924:notes:216]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 727 |  |  | $ | 476 |  |  | $ | 22 |  |
| State |  |  | 75 |  |  |  | 13 |  |  |  | 329 |  |
| Foreign |  |  | 1,793 |  |  |  | 2,447 |  |  |  | 2,987 |  |
| Total current |  |  | 2,595 |  |  |  | 2,936 |  |  |  | 3,338 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 1,659 |  |  |  | 1,507 |  |  |  | 1,632 |  |
| State |  |  | 108 |  |  |  | 103 |  |  |  | 76 |  |
| Foreign |  |  | (26 | ) |  |  | 261 |  |  |  | (857 | ) |
| Total deferred |  |  | 1,741 |  |  |  | 1,871 |  |  |  | 851 |  |
| Provision for income taxes |  | $ | 4,336 |  |  | $ | 4,807 |  |  | $ | 4,189 |  |

[0001564590-16-024924:notes:217]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (35 percent) to income before taxes is explained below (in thousands):

[0001564590-16-024924:notes:218]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Tax at federal statutory rate |  | $ | (9,642 | ) |  | $ | (23,392 | ) |  | $ | (18,592 | ) |
| State income tax, net of federal benefit |  |  | 75 |  |  |  | 13 |  |  |  | 329 |  |
| Change in valuation allowance |  |  | 7,898 |  |  |  | 24,408 |  |  |  | 22,565 |  |
| Research and development credits |  |  | (1,364 | ) |  |  | (303 | ) |  |  | (1,836 | ) |
| Foreign earnings taxed at other than U.S. rates |  |  | 1,678 |  |  |  | (1,113 | ) |  |  | (346 | ) |
| Stock based compensation |  |  | 3,564 |  |  |  | 2,298 |  |  |  | 348 |  |
| Goodwill amortization |  |  | 1,672 |  |  |  | 1,690 |  |  |  | 1,097 |  |
| Other |  |  | 455 |  |  |  | 1,206 |  |  |  | 624 |  |
| Provision for income taxes |  | $ | 4,336 |  |  | $ | 4,807 |  |  | $ | 4,189 |  |

[0001564590-16-024924:notes:219]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001564590-16-024924:notes:220]
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 108,563 |  |  | $ | 114,151 |  |  | $ | 97,630 |  |
| Tax credit carry-forwards |  |  | 32,730 |  |  |  | 30,824 |  |  |  | 30,019 |  |
| Depreciation |  |  | — |  |  |  | — |  |  |  | 129 |  |
| Intangible amortization |  |  | 28,480 |  |  |  | 17,978 |  |  |  | 6,061 |  |
| Deferred revenue (net) |  |  | 7,955 |  |  |  | 7,811 |  |  |  | 10,540 |  |
| Warrant amortization |  |  | — |  |  |  | 1,355 |  |  |  | 2,723 |  |
| Inventory write-downs |  |  | 6,207 |  |  |  | 6,048 |  |  |  | 3,265 |  |
| Other allowances and accruals |  |  | 10,568 |  |  |  | 8,645 |  |  |  | 6,380 |  |
| Stock based compensation |  |  | 4,048 |  |  |  | 6,783 |  |  |  | 6,257 |  |
| Other |  |  | 4,275 |  |  |  | 5,902 |  |  |  | 10,772 |  |
| Total deferred tax assets |  |  | 202,826 |  |  |  | 199,497 |  |  |  | 173,776 |  |
| Valuation allowance |  |  | (201,405 | ) |  |  | (197,576 | ) |  |  | (172,475 | ) |
| Total net deferred tax assets |  |  | 1,421 |  |  |  | 1,921 |  |  |  | 1,301 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation |  |  | (343 | ) |  |  | (707 | ) |  |  | — |  |
| Goodwill amortization |  |  | (4,459 | ) |  |  | (2,787 | ) |  |  | (1,097 | ) |
| Foreign exchange gain |  |  | — |  |  |  | — |  |  |  | (2,670 | ) |
| Deferred tax liability on foreign withholdings |  |  | (235 | ) |  |  | (194 | ) |  |  | (167 | ) |
| Total deferred tax liabilities |  |  | (5,037 | ) |  |  | (3,688 | ) |  |  | (3,934 | ) |
| Net deferred tax assets (liabilities) |  | $ | (3,616 | ) |  | $ | (1,767 | ) |  | $ | (2,633 | ) |
| Recorded as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net current deferred tax assets |  | $ | — |  |  | $ | 760 |  |  | $ | 1,058 |  |
| Net non-current deferred tax assets |  |  | 1,077 |  |  |  | 452 |  |  |  | 230 |  |
| Net current deferred tax liabilities |  |  | — |  |  |  | — |  |  |  | (2,657 | ) |
| Net non-current deferred tax liabilities |  |  | (4,693 | ) |  |  | (2,979 | ) |  |  | (1,264 | ) |
| Net deferred tax assets (liabilities) |  | $ | (3,616 | ) |  | $ | (1,767 | ) |  | $ | (2,633 | ) |

[0001564590-16-024924:notes:221]
The Company's global valuation allowance increased by $3.8 million in the fiscal year ended June 30, 2016 and $25.1 million in the fiscal year ended June 30, 2015. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against non-U.S. deferred tax assets in Australia, Brazil, Japan and Singapore.  The valuation allowance is determined by assessing both negative and positive available evidence to assess whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of the Company's business provides sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001564590-16-024924:notes:222]
On December 18, 2015 President Barack Obama signed H.R. 2029, the Protecting Americans from Tax Hikes (“PATH”) Act of 2015, which makes the Section 41 research credit, which expired on December 31, 2014, a permanent provision of the Internal Revenue Code.  The law extends the research credit permanently and retroactively to January 1, 2015.  This change has been reflected in our tax credit carryforwards with an offsetting adjustment to our US valuation allowance.

[0001564590-16-024924:notes:223]
As of June 30, 2016, the Company had net operating loss carry-forwards for U.S. federal and state tax purposes of $322.7 million and $138.3 million, respectively, of which $38.6 million and $36.0 million, respectively, represent deductions from share-based compensation for which a benefit would be recorded in additional paid-in capital when realized. As of June 30, 2016, the Company also had foreign net operating loss carry-forwards in Ireland, Australia and Japan of $41.4 million, $9.4 million and $0.4 million, respectively.  As of June 30, 2016, the Company also had federal and state tax credit carry-forwards of $22.1 million and $16.2 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits with a small portion representing Alternative Minimum Tax Credits.  The U.S. federal net operating loss carry-forwards of $322.7 million will begin to expire in the fiscal year ending June 30, 2021 and state net operating losses of $138.3 million began to partially expire in the fiscal year ending June 30, 2016. The foreign net operating losses can generally be carried forward indefinitely.  Federal research and development tax credits of $14.2 million will expire beginning in fiscal 2019, if not utilized and foreign tax credits of $7.5 million will expire beginning in fiscal 2020.  North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2023, if not utilized. California state research and development tax credits of $15.3 million do not expire and can be carried forward indefinitely.

[0001564590-16-024924:notes:224]
As of January 2016, the Company performed an Internal Revenue Code section 382 analysis with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2016, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes.

[0001564590-16-024924:notes:225]
As of June 30, 2016, the Company intends to indefinitely reinvest the earnings of approximately $10.3 million of certain foreign corporations. The unrecognized deferred tax liability associated with these earnings is approximately $0.3 million.

[0001564590-16-024924:notes:226]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, Brazil, India, California, New Hampshire and North Carolina.  The Company is not currently under examination by any federal, state or foreign tax authority with respect to income taxes.  The Company recently settled an income tax examination of one of its subsidiaries with the Malaysian tax authorities for the 2012, 2013 and 2014 years of assessment resulting in a minimal amount of tax due.  The tax reserves were adjusted appropriately to reflect this settlement.

[0001564590-16-024924:notes:227]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.

[0001564590-16-024924:notes:228]
During the fiscal year ended June 30, 2014, the Company acquired the stock of Enterasys Networks, Inc. and as such they became a wholly owned subsidiary of Extreme Networks.  With respect to this acquisition, the Company made an election under Internal Revenue Code section 338(h)(10) to treat the acquisition as an asset purchase from a tax perspective.  Under this election the tax basis of all assets is effectively reset to that of fair market value and therefore the transaction did not result in the recording of an opening net deferred tax position as the Company's tax basis in the acquired assets equaled its book basis.

[0001564590-16-024924:notes:229]
As of June 30, 2016, the Company had $11.7 million of unrecognized tax benefits.  If fully recognized in the future, there would be no impact to the effective tax rate, and $11.7 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance.  The Company does not reasonably expect the amount of unrealized tax benefits to decrease during the next twelve months.

[0001564590-16-024924:notes:230]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001564590-16-024924:notes:231]
| Balance at June 30, 2013 |  | $ | 10,898 |  |
| Decrease related to prior year tax positions |  |  | — |  |
| Increase related to prior year tax positions |  |  | 415 |  |
| Increase related to current year tax positions |  |  | 464 |  |
| Lapse of statute of limitations |  |  | (177 | ) |
| Balance at June 30, 2014 |  | $ | 11,600 |  |
| Decrease related to prior year tax positions |  |  | (225 | ) |
| Increase related to prior year tax positions |  |  | 288 |  |
| Increase related to current year tax positions |  |  | 254 |  |
| Lapse of statute of limitations |  |  | (158 | ) |
| Settlements with tax authorities |  |  | (400 | ) |
| Balance at June 30, 2015 |  | $ | 11,359 |  |
| Increase related to prior year tax positions |  |  | 174 |  |
| Increase related to current year tax positions |  |  | 120 |  |
| Balance at June 30, 2016 |  | $ | 11,653 |  |

[0001564590-16-024924:notes:232]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the consolidated statement of operations and totaled less than $0.1 million for each of the fiscal years 2016, 2015 and 2014.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-024924:notes:233]
10. Disclosure about Segments of an Enterprise and Geographic Areas

[0001564590-16-024924:notes:234]
We conduct business globally and are primarily managed on a geographic theater basis.  Our chief operating decision maker ("CODM"), who is our CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-16-024924:notes:235]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the CODM with respect to the allocation of resources and performance.

[0001564590-16-024924:notes:236]
The Company operates in one segment, the development and marketing of network infrastructure equipment.  Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan.

[0001564590-16-024924:notes:237]
The Company attributes revenues to geographic regions based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001564590-16-024924:notes:238]
|  |  | Year Ended |  |
| Net Revenues: |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 237,933 |  |  | $ | 238,748 |  |  | $ | 211,734 |  |
| Other |  |  | 44,455 |  |  |  | 31,931 |  |  |  | 45,790 |  |
| Total Americas |  |  | 282,388 |  |  |  | 270,679 |  |  |  | 257,524 |  |
| EMEA: |  |  |  |  |  |  |  |  |  |  |  |  |
| Germany |  |  | 65,799 |  |  |  | 67,316 |  |  |  | 66,099 |  |
| Other |  |  | 130,789 |  |  |  | 156,052 |  |  |  | 136,456 |  |
| Total EMEA |  |  | 196,588 |  |  |  | 223,368 |  |  |  | 202,555 |  |
| APAC: |  |  | 49,413 |  |  |  | 58,893 |  |  |  | 59,475 |  |
| Total net revenues |  | $ | 528,389 |  |  | $ | 552,940 |  |  | $ | 519,554 |  |

[0001564590-16-024924:notes:239]
The Company's long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-16-024924:notes:240]
| Long Lived Assets: |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Americas |  | $ | 58,277 |  |  | $ | 87,071 |  |
| EMEA |  |  | 14,234 |  |  |  | 29,610 |  |
| APAC |  |  | 2,493 |  |  |  | 3,108 |  |
| Total long lived assets |  | $ | 75,004 |  |  | $ | 119,789 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-024924:notes:241]
11. Net Loss Per Share

[0001564590-16-024924:notes:242]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to options, warrants and unvested restricted stock.  The following table presents the calculation of basic and diluted net loss per share (in thousands, except per share data):

[0001564590-16-024924:notes:243]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Net loss |  | $ | (31,884 | ) |  | $ | (71,643 | ) |  | $ | (57,310 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 103,074 |  |  |  | 99,000 |  |  |  | 95,515 |  |
| Net loss per share - basic and diluted |  | $ | (0.31 | ) |  | $ | (0.72 | ) |  | $ | (0.60 | ) |

[0001564590-16-024924:notes:244]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.  Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net loss per share since the effect of including them would have been anti-dilutive due to the net loss position of the Company during the periods presented.

[0001564590-16-024924:notes:245]
The following securities were excluded from the computation of outstanding diluted earnings per common share because they would have been anti-dilutive (in thousands).

[0001564590-16-024924:notes:246]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Options to purchase common stock |  |  | 6,937 |  |  |  | 7,542 |  |  |  | 7,595 |  |
| Restricted stock units |  |  | 353 |  |  |  | 133 |  |  |  | 1,580 |  |
| Total shares excluded |  |  | 7,290 |  |  |  | 7,675 |  |  |  | 9,175 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-024924:notes:247]
12. Foreign Exchange Forward Contracts

[0001564590-16-024924:notes:248]
The Company has used derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes.

[0001564590-16-024924:notes:249]
At June 30, 2016 and 2015, the Company did not have any forward foreign currency contracts.

[0001564590-16-024924:notes:250]
Foreign currency transaction gains and losses from operations were a gain of $1.3 million in fiscal 2016 and losses of $1.0 million and $1.5 million in fiscal years 2015 and 2014, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-024924:notes:251]
13. Restructuring Charges

[0001564590-16-024924:notes:252]
As of June 30, 2016, restructuring liabilities were $4.6 million and consisted primarily of obligations pertaining to the estimated future obligations for non-cancelable lease payments, of which, payments will continue through fiscal year 2023, due to the length of the lease agreements. The restructuring liability is recorded in "Other accrued liabilities" and “Other long-term liabilities” in the consolidated balance sheets.  During fiscal years 2016, 2015 and 2014, the Company recorded restructuring charges, net of reversals, of $11.0 million, $9.8 million and $0.5 million, respectively.

[0001564590-16-024924:notes:253]
Fiscal 2016

[0001564590-16-024924:notes:254]
During fiscal 2016, the Company continued its initiative to realign its operations with a second phase by abandoning excess facilities, primarily in San Jose, California; Salem, New Hampshire; Research Triangle Park, North Carolina and other smaller leased locations. The abandoned facilities represented approximately 32% of the floor space in the aggregate at these locations and included general office and warehouse space.

[0001564590-16-024924:notes:255]
In conjunction with the exiting of facilities noted above, we incurred $11.0 of restructuring charges. Excess facilities charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and contract termination charges of $5.4 million, acceleration of depreciation of leasehold improvements of $4.5 million, professional fees of $1.0 million and other of $0.1 million.

[0001564590-16-024924:notes:256]
Significant restructuring charges incurred during 2016, by location, included $1.8 million of charges for excess facilities pertaining to the estimated future obligations for non-cancelable lease payments at our San Jose location.  This represented 39% of the San Jose leased space.  The Company amended its facility lease at its North Carolina location and exited excess space while recording $4.1 million of charges, which included $3.1 million in accelerated depreciation of leasehold improvements. This action represented 36% of the North Carolina location lease space. The Company recorded $4.4 million of charges for excess facilities at its Salem location, which included $1.3 million in accelerated depreciation of leasehold improvements.  This action represented 27% of the Salem lease space.  The excess facilities payments will continue through fiscal year 2023, due to the length of the lease agreements.

[0001564590-16-024924:notes:257]
Fiscal 2015

[0001564590-16-024924:notes:258]
During the fourth quarter of fiscal 2015, the Company reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment.  We initiated a plan to reduce worldwide headcount by more than 225 employees, primarily in sales and marketing, as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions.  The Company recorded $9.7 million of charges associated with its Phase One initiative.

[0001564590-16-024924:notes:259]
Fiscal 2014

[0001564590-16-024924:notes:260]
In fiscal 2014, the Company incurred an additional $0.5 million of expenses related to a restructuring plan originating in 2013. As part of its restructuring efforts in the second quarter of fiscal 2013, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. There were no outstanding liabilities as of June 30, 2015.

[0001564590-16-024924:notes:261]
Restructuring liabilities consist of (in thousands):

[0001564590-16-024924:notes:262]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2013 |  | $ | — |  |  | $ | 1,217 |  |  | $ | 249 |  |  | $ | 1,466 |  |
| Period charges |  |  | 628 |  |  |  | 119 |  |  |  | 86 |  |  |  | 833 |  |
| Period reversals |  |  | (11 | ) |  |  | (309 | ) |  |  | (4 | ) |  |  | (324 | ) |
| Addition from acquisition |  |  | (20 | ) |  |  | — |  |  |  | — |  |  |  | (20 | ) |
| Period payments |  |  | (275 | ) |  |  | (1,027 | ) |  |  | (331 | ) |  |  | (1,633 | ) |
| Balance as of June 30, 2014 |  |  | 322 |  |  |  | — |  |  |  | — |  |  |  | 322 |  |
| Period charges |  |  | 0 |  |  |  | 9,694 |  |  |  | 125 |  |  |  | 9,819 |  |
| Period payments |  |  | (322 | ) |  |  | (3,957 | ) |  |  | (8 | ) |  |  | (4,287 | ) |
| Balance as of June 30, 2015 |  |  | — |  |  |  | 5,737 |  |  |  | 117 |  |  |  | 5,854 |  |
| Period charges |  |  | 10,811 |  |  |  | 668 |  |  |  | 237 |  |  |  | 11,716 |  |
| Period reversals |  |  | (18 | ) |  |  | (618 | ) |  |  | (90 | ) |  |  | (726 | ) |
| Non cash adjustments |  |  | (4,463 | ) |  |  | — |  |  |  | — |  |  |  | (4,463 | ) |
| Period payments |  |  | (1,686 | ) |  |  | (5,787 | ) |  |  | (264 | ) |  |  | (7,737 | ) |
| Balance as of June 30, 2016 |  | $ | 4,644 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,644 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,522 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,122 |  |
