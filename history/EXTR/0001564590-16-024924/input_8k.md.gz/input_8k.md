# EXTR 8-K — 0001564590-16-022347 filed 2016-08-03

## item codes, every 8-K on or before 2016-09-06

- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2016-09-06

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-16-022347:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-16-022347:8k_2_02:2]
extr-ex991_6.htm

[0001564590-16-022347:8k_2_02:3]
Exhibit 99.1

[0001564590-16-022347:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-16-022347:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations |  | Media Contact |
| 408/579-3456 |  | 617/624-3231 |
| fyoshino@extremenetworks.com |  | ExtremeUS@racepointglobal.com |

[0001564590-16-022347:8k_2_02:6]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2016 Financial Results

[0001564590-16-022347:8k_2_02:7]
Q4 GAAP Revenue of $139.6 Million & Non-GAAP Revenue of $140.0 Million

[0001564590-16-022347:8k_2_02:8]
Q4 GAAP EPS Loss of $0.02 & Non-GAAP EPS Income of $0.10

[0001564590-16-022347:8k_2_02:9]
Fiscal Year GAAP Revenue of $528.4 Million & Non-GAAP Revenue of $529.9 Million

[0001564590-16-022347:8k_2_02:10]
Fiscal Year GAAP EPS Loss of $0.31 & Non-GAAP EPS Income of $0.28

[0001564590-16-022347:8k_2_02:11]
SAN JOSE, Calif., August 3, 2016 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for its fiscal fourth quarter ended June 30, 2016.  Fourth quarter GAAP revenue was $139.6 million and non-GAAP revenue was $140.0 million.  GAAP net loss for the fourth fiscal quarter was $2.3 million, or $0.02 per basic share, and non-GAAP net income was $10.2 million, or $0.10 per diluted share.  For the full fiscal year 2016, Extreme Networks reported GAAP revenue of $528.4 million, compared to $552.9 million for fiscal 2015.  Fiscal year 2016 non-GAAP revenue was $529.9 million compared to $556.0 million in fiscal 2015.  GAAP net loss was $31.9 million, or $0.31 per share, for fiscal 2016, compared to GAAP net loss of $71.6 million, or $0.72 per share, for fiscal 2015.  On a non-GAAP basis, net income for fiscal 2016 was $29.4 million, or $0.28 per diluted share, compared to $5.9 million, or $0.06 per diluted share, for fiscal 2015.

[0001564590-16-022347:8k_2_02:12]
“Our results reflect solid execution and significant earnings growth compared to the prior year period. Success in delivering software-driven networking solutions to our enterprise customers, combined with prudent expense controls, produced a significant annual improvement of 400% to our bottom line on a non-GAAP basis and a healthy balance sheet,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-16-022347:8k_2_02:13]
“The line-up of new technology solutions like our enhanced wireless cloud management platform released last week is generating excitement with our field sales teams, partners and customers alike.  With a strict focus on our enterprise campus vertical markets, our tailored portfolio of wired and wireless products, custom software solutions and superior in-sourced technical support, we believe we are in a strong position heading into fiscal 2017.   We have the most competitive solutions for managing the enterprise campus from access edge to the private cloud."

[0001564590-16-022347:8k_2_02:14]
Recent Key Events:

[0001564590-16-022347:8k_2_02:15]
|  | · | Strengthened the Executive Leadership Team. We announced the appointment of Drew Davies to Executive Vice President and Chief Financial Officer effective June 1st. |

[0001564590-16-022347:8k_2_02:16]
|  | · | Unveiled Cloud-Managed Networking Platform. During the quarter, we introduced ExtremeCloud™, a cloud-managed networking platform, designed for zero-touch provisioning, management simplicity and partner enablement through white labeling of the offering. |

[0001564590-16-022347:8k_2_02:17]
|  | · | Strategic Relationship with the Buffalo Sabres. To implement an arena-wide Wi-Fi solution for the 2016 NHL Draft and upcoming hockey season, the Buffalo Sabres partnered with Extreme to deliver pervasive and secure high-density Wi-Fi in the First Niagara Center. Extreme Networks and partner Carousel Industries have now implemented two large scale venue Wi-Fi deployments in Buffalo, N.Y. at Ralph Wilson Stadium and First Niagara Center. |

[0001564590-16-022347:8k_2_02:18]
|  | · | Highlighted Our Customer Success with Concurrency. To support BYOD and improve network security and performance among its three locations, Concurrency, an IT consulting agency, selected Extreme’s software-driven wired and wireless solutions. |

[0001564590-16-022347:8k_2_02:19]
|  | · | Key Customer Wins in Focus Markets. Extreme Networks continued to showcase customer momentum across the global education, healthcare, manufacturing, hospitality and government markets. Customers continue to note Extreme’s software and services as value added differentiators for choosing our solutions. Notable customer wins in key vertical markets include the University of Wisconsin, Charleston Area Medical Center, Leder & Schuh AG, SJM Casino, and the State of North Dakota. |

[0001564590-16-022347:8k_2_02:20]
Fiscal Q4 2016 Financial Metrics:

[0001564590-16-022347:8k_2_02:21]
|  |  | 2016 |  |  | 2015 |  |  | Change |  |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 106.0 |  |  | $ | 116.3 |  |  | $ | (10.3 | ) |  |  | (9 | )% |
| Service |  |  | 33.6 |  |  |  | 33.6 |  |  |  | (0.0 | ) |  |  | 0 | % |
| Total Net Revenue |  | $ | 139.6 |  |  | $ | 149.9 |  |  | $ | (10.3 | ) |  |  | (7 | )% |
| Gross Margin |  |  | 52.1 | % |  |  | 50.9 | % |  |  | 1.2 | % |  |  | 2 | % |
| Operating Margin |  |  | (0.3 | )% |  |  | (9.0 | )% |  |  | 8.7 | % |  |  | 97 | % |
| Net Loss |  | $ | (2.3 | ) |  | $ | (15.7 | ) |  | $ | 13.4 |  |  |  | 85 | % |
| Loss per basic share |  | $ | (0.02 | ) |  | $ | (0.16 | ) |  | $ | 0.14 |  |  |  | 88 | % |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 106.0 |  |  | $ | 116.3 |  |  | $ | (10.3 | ) |  |  | (9 | )% |
| Service |  |  | 34.0 |  |  |  | 34.3 |  |  |  | (0.3 | ) |  |  | (1 | )% |
| Total Net Revenue |  | $ | 140.0 |  |  | $ | 150.6 |  |  | $ | (10.6 | ) |  |  | (7 | )% |
| Gross Margin |  |  | 54.8 | % |  |  | 54.4 | % |  |  | 0.4 | % |  |  | 1 | % |
| Operating Margin |  |  | 8.6 | % |  |  | 8.2 | % |  |  | 0.4 | % |  |  | 5 | % |
| Net Income |  | $ | 10.2 |  |  | $ | 10.1 |  |  | $ | 0.1 |  |  |  | 1 | % |
| Earnings per diluted share |  | $ | 0.10 |  |  | $ | 0.10 |  |  | $ | - |  |  |  | — |  |

[0001564590-16-022347:8k_2_02:22]
|  | · | Cash and investments ended the quarter at $94.1 million, as compared to $88.3 million from the prior quarter and up $17.9 million from the previous year-end. |

[0001564590-16-022347:8k_2_02:23]
|  | · | Accounts receivable balance ending Q4 was $81.4 million, with days sales outstanding (“DSO”) of 53. |

[0001564590-16-022347:8k_2_02:24]
|  | · | Inventory ending Q4 was $41.0 million, a decrease of $11.8 million from the prior quarter and down $17.0 million from the previous year. |

[0001564590-16-022347:8k_2_02:25]
Business Outlook:

[0001564590-16-022347:8k_2_02:26]
On an annual basis for fiscal year 2017 we are targeting revenue growth of 2% to 4%.  For its first quarter of fiscal 2017 ending September 30, 2016, the Company is targeting GAAP revenue in a range of $120.6 million to $130.6 million with non-GAAP revenue in a range of $121.0 million to $131.0 million. GAAP gross margin is targeted between 53.5% and 55.0% and non-GAAP gross margin is targeted between 56.7% and 58.1%. Operating expenses are targeted to be between $70.0 million and $72.5 million on a GAAP basis and $63.5 million to $66.0 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $1.5 million to $6.2 million, or a loss of $0.01 to $0.06 per share.  Non-GAAP earnings are targeted in a range of net income of $4.3 million to $9.0 million, or $0.04 to $0.09 per diluted share. The GAAP and non-GAAP net income (loss) targets are based on an estimated 106 million and 108 million average outstanding shares, respectively.

[0001564590-16-022347:8k_2_02:27]
Conference Call:

[0001564590-16-022347:8k_2_02:28]
Extreme Networks will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the fourth fiscal quarter results as well as the first quarter and full fiscal year 2017 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August 3, 2017.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406   Conference ID # 43898604.

[0001564590-16-022347:8k_2_02:29]
About Extreme Networks:

[0001564590-16-022347:8k_2_02:30]
Extreme Networks, Inc. (“EXTR”) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, we go to extreme measures for our 20,000-plus customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, education, government, healthcare, manufacturing and hospitality. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-16-022347:8k_2_02:31]
Extreme Networks and the Extreme Networks logo, ExtremeManagement, ExtremeWireless, ExtremeControl and ExtremeAnalytics are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-16-022347:8k_2_02:32]
Non-GAAP Financial Measures:

[0001564590-16-022347:8k_2_02:33]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income (loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, litigation expenses, executive transition expenses and overhead adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the

[0001564590-16-022347:8k_2_02:34]
Company's marketplace performance, and the Company's ability to generate cash from operations. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-16-022347:8k_2_02:35]
Forward Looking Statements:

[0001564590-16-022347:8k_2_02:36]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-16-022347:8k_2_02:37]
EXTREME NETWORKS, INC.

[0001564590-16-022347:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-16-022347:8k_2_02:39]
(In thousands)

[0001564590-16-022347:8k_2_02:40]
(Unaudited)

[0001564590-16-022347:8k_2_02:41]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 94,122 |  |  | $ | 76,225 |  |
| Accounts receivable, net of allowances of $3,257 at June 30, 2016 and $2,396 at June 30, 2015 |  |  | 81,419 |  |  |  | 92,737 |  |
| Inventories |  |  | 40,989 |  |  |  | 58,014 |  |
| Deferred income taxes |  |  | - |  |  |  | 760 |  |
| Prepaid expenses and other current assets |  |  | 12,438 |  |  |  | 10,258 |  |
| Total current assets |  |  | 228,968 |  |  |  | 237,994 |  |
| Property and equipment, net |  |  | 29,580 |  |  |  | 39,862 |  |
| Intangible assets, net |  |  | 19,762 |  |  |  | 52,132 |  |
| Goodwill |  |  | 70,877 |  |  |  | 70,877 |  |
| Other assets |  |  | 25,662 |  |  |  | 27,795 |  |
| Total assets |  | $ | 374,849 |  |  | $ | 428,660 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 17,875 |  |  | $ | 11,375 |  |
| Accounts payable |  |  | 30,711 |  |  |  | 40,135 |  |
| Accrued compensation and benefits |  |  | 27,145 |  |  |  | 25,195 |  |
| Accrued warranty |  |  | 9,600 |  |  |  | 8,676 |  |
| Deferred revenue, net |  |  | 72,934 |  |  |  | 76,551 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  |  | 26,817 |  |  |  | 40,875 |  |
| Other accrued liabilities |  |  | 26,691 |  |  |  | 32,623 |  |
| Total current liabilities |  |  | 211,773 |  |  |  | 235,430 |  |
| Deferred revenue, less current portion |  |  | 21,926 |  |  |  | 23,231 |  |
| Long-term debt, less current portion |  |  | 37,625 |  |  |  | 55,500 |  |
| Deferred income taxes |  |  | 4,693 |  |  |  | 2,979 |  |
| Other long-term liabilities |  |  | 8,635 |  |  |  | 7,285 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 90,197 |  |  |  | 104,235 |  |
| Total liabilities and stockholders’ equity |  | $ | 374,849 |  |  | $ | 428,660 |  |

[0001564590-16-022347:8k_2_02:42]
EXTREME NETWORKS, INC.

[0001564590-16-022347:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-022347:8k_2_02:44]
(In thousands, except per share amounts)

[0001564590-16-022347:8k_2_02:45]
(Unaudited)

[0001564590-16-022347:8k_2_02:46]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 106,017 |  |  | $ | 116,347 |  |  | $ | 395,464 |  |  | $ | 418,046 |  |
| Service |  |  | 33,600 |  |  |  | 33,523 |  |  |  | 132,925 |  |  |  | 134,894 |  |
| Total net revenues |  |  | 139,617 |  |  |  | 149,870 |  |  |  | 528,389 |  |  |  | 552,940 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 54,462 |  |  |  | 60,736 |  |  |  | 208,739 |  |  |  | 225,018 |  |
| Service |  |  | 12,480 |  |  |  | 12,807 |  |  |  | 48,862 |  |  |  | 48,185 |  |
| Total cost of revenues |  |  | 66,942 |  |  |  | 73,543 |  |  |  | 257,601 |  |  |  | 273,203 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 51,555 |  |  |  | 55,611 |  |  |  | 186,725 |  |  |  | 193,028 |  |
| Service |  |  | 21,120 |  |  |  | 20,716 |  |  |  | 84,063 |  |  |  | 86,709 |  |
| Total gross profit |  |  | 72,675 |  |  |  | 76,327 |  |  |  | 270,788 |  |  |  | 279,737 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 18,885 |  |  |  | 22,242 |  |  |  | 78,721 |  |  |  | 93,447 |  |
| Sales and marketing |  |  | 39,364 |  |  |  | 41,322 |  |  |  | 150,806 |  |  |  | 169,299 |  |
| General and administrative |  |  | 9,767 |  |  |  | 11,001 |  |  |  | 37,675 |  |  |  | 42,092 |  |
| Acquisition and integration costs |  |  | - |  |  |  | 923 |  |  |  | 1,145 |  |  |  | 10,205 |  |
| Restructuring charge, net of reversals |  |  | 998 |  |  |  | 9,819 |  |  |  | 10,990 |  |  |  | 9,819 |  |
| Amortization of intangibles |  |  | 4,141 |  |  |  | 4,467 |  |  |  | 17,001 |  |  |  | 17,869 |  |
| Total operating expenses |  |  | 73,155 |  |  |  | 89,774 |  |  |  | 296,338 |  |  |  | 342,731 |  |
| Operating loss |  |  | (480 | ) |  |  | (13,447 | ) |  |  | (25,550 | ) |  |  | (62,994 | ) |
| Interest income |  |  | 29 |  |  |  | 70 |  |  |  | 113 |  |  |  | 541 |  |
| Interest expense |  |  | (694 | ) |  |  | (757 | ) |  |  | (3,098 | ) |  |  | (3,177 | ) |
| Other income (expense), net |  |  | 174 |  |  |  | (174 | ) |  |  | 987 |  |  |  | (1,206 | ) |
| Loss before income taxes |  |  | (971 | ) |  |  | (14,308 | ) |  |  | (27,548 | ) |  |  | (66,836 | ) |
| Provision for income taxes |  |  | 1,369 |  |  |  | 1,349 |  |  |  | 4,336 |  |  |  | 4,807 |  |
| Net loss |  | $ | (2,340 | ) |  | $ | (15,657 | ) |  | $ | (31,884 | ) |  | $ | (71,643 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.02 | ) |  | $ | (0.16 | ) |  | $ | (0.31 | ) |  | $ | (0.72 | ) |
| Net loss per share - diluted |  | $ | (0.02 | ) |  | $ | (0.16 | ) |  | $ | (0.31 | ) |  | $ | (0.72 | ) |
| Shares used in per share calculation - basic |  |  | 104,837 |  |  |  | 100,226 |  |  |  | 103,074 |  |  |  | 99,000 |  |
| Shares used in per share calculation - diluted |  |  | 104,837 |  |  |  | 100,226 |  |  |  | 103,074 |  |  |  | 99,000 |  |

[0001564590-16-022347:8k_2_02:47]
EXTREME NETWORKS, INC.

[0001564590-16-022347:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-16-022347:8k_2_02:49]
(In thousands)

[0001564590-16-022347:8k_2_02:50]
(Unaudited)

[0001564590-16-022347:8k_2_02:51]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Net cash provided by operating activities |  | $ | 30,366 |  |  | $ | 37,423 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (5,327 | ) |  |  | (7,205 | ) |
| Purchases of non-marketable equity investment |  |  | - |  |  |  | (3,000 | ) |
| Proceeds from maturities of investments and marketable securities |  |  | - |  |  |  | 23,321 |  |
| Proceeds from sales of investments and marketable securities |  |  | - |  |  |  | 9,051 |  |
| Purchases of intangible assets |  |  | - |  |  |  | (569 | ) |
| Net cash (used in) provided by investing activities |  |  | (5,327 | ) |  |  | 21,598 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | 15,000 |  |  |  | 24,000 |  |
| Repayment of debt |  |  | (26,375 | ) |  |  | (78,688 | ) |
| Proceeds from issuance of common stock |  |  | 4,637 |  |  |  | 2,218 |  |
| Net cash used in financing activities |  |  | (6,738 | ) |  |  | (52,470 | ) |
| Foreign currency effect on cash |  |  | (404 | ) |  |  | (3,516 | ) |
| Net increase in cash and cash equivalents |  |  | 17,897 |  |  |  | 3,035 |  |
| Cash and cash equivalents at beginning of period |  |  | 76,225 |  |  |  | 73,190 |  |
| Cash and cash equivalents at end of period |  | $ | 94,122 |  |  | $ | 76,225 |  |

[0001564590-16-022347:8k_2_02:52]
Extreme Networks, Inc.

[0001564590-16-022347:8k_2_02:53]
Non-GAAP Measures of Financial Performance

[0001564590-16-022347:8k_2_02:54]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-16-022347:8k_2_02:55]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring expenses, litigation expenses, executive transition and overhead adjustments.

[0001564590-16-022347:8k_2_02:56]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-16-022347:8k_2_02:57]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-16-022347:8k_2_02:58]
For its internal planning process, and as discussed further below, Extreme Networks' management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, restructuring expenses, litigation expenses, executive transition expenses and overhead adjustments.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-16-022347:8k_2_02:59]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-16-022347:8k_2_02:60]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-16-022347:8k_2_02:61]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-16-022347:8k_2_02:62]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-16-022347:8k_2_02:63]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-16-022347:8k_2_02:64]
Restructuring expenses. Restructuring expenses primarily consist of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-16-022347:8k_2_02:65]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matter as a result of a securities laws class action lawsuit.

[0001564590-16-022347:8k_2_02:66]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits.  The expenses are incurred through execution of pre-established employment contracts with senior executives.  The severance and termination benefits are cash transactions, while the share-based compensation are non-cash expenses the Company does not believe these expenses are reflective of ongoing cash requirements related to its operating results.

[0001564590-16-022347:8k_2_02:67]
Overhead adjustments. Overhead adjustment relate to service inventory overhead capitalization, this was a one-time event and was non-cash in nature.

[0001564590-16-022347:8k_2_02:68]
In addition to the non-GAAP measures discussed above, Extreme Networks uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-16-022347:8k_2_02:69]
EXTREME NETWORKS, INC.

[0001564590-16-022347:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-022347:8k_2_02:71]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-16-022347:8k_2_02:72]
(In thousands, except per share amounts)

[0001564590-16-022347:8k_2_02:73]
(Unaudited)

[0001564590-16-022347:8k_2_02:74]
| Non-GAAP Revenue | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Revenue - GAAP Basis | $ | 139,617 |  |  | $ | 149,870 |  |  | $ | 528,389 |  |  | $ | 552,940 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | 377 |  |  |  | 766 |  |  |  | 1,508 |  |  |  | 3,065 |  |
| Revenue - Non-GAAP Basis | $ | 139,994 |  |  | $ | 150,636 |  |  | $ | 529,897 |  |  | $ | 556,005 |  |

[0001564590-16-022347:8k_2_02:75]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Gross profit - GAAP Basis | $ | 72,675 |  |  | $ | 76,327 |  |  | $ | 270,788 |  |  | $ | 279,737 |  |
| Gross margin - GAAP Basis percentage |  | 52.1 | % |  |  | 50.9 | % |  |  | 51.2 | % |  |  | 50.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 279 |  |  |  | 496 |  |  |  | 1,923 |  |  |  | 2,135 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 1,508 |  |  |  | 3,065 |  |
| Amortization of intangibles |  | 3,417 |  |  |  | 4,292 |  |  |  | 14,833 |  |  |  | 17,166 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Gross profit - Non-GAAP Basis | $ | 76,748 |  |  | $ | 81,881 |  |  | $ | 287,559 |  |  | $ | 302,103 |  |
| Gross margin - Non-GAAP Basis percentage |  | 54.8 | % |  |  | 54.4 | % |  |  | 54.3 | % |  |  | 54.3 | % |

[0001564590-16-022347:8k_2_02:76]
| Non-GAAP Operating Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| GAAP operating loss | $ | (480 | ) |  | $ | (13,447 | ) |  | $ | (25,550 | ) |  | $ | (62,994 | ) |
| GAAP operating loss percentage |  | (0.3 | )% |  |  | (9.0 | )% |  |  | (4.8 | )% |  |  | (11.4 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 2,673 |  |  |  | 3,470 |  |  |  | 14,792 |  |  |  | 17,405 |  |
| Acquisition and integration costs |  | - |  |  |  | 923 |  |  |  | 1,145 |  |  |  | 10,205 |  |
| Restructuring charge, net of reversal |  | 998 |  |  |  | 9,819 |  |  |  | 10,990 |  |  |  | 9,819 |  |
| Amortization of intangibles |  | 7,558 |  |  |  | 8,759 |  |  |  | 31,834 |  |  |  | 35,035 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 1,508 |  |  |  | 3,065 |  |
| Executive transition costs |  | 771 |  |  |  | 1,989 |  |  |  | 2,166 |  |  |  | 1,989 |  |
| Litigation |  | 167 |  |  |  | - |  |  |  | 331 |  |  |  | - |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Total adjustments to GAAP operating loss | $ | 12,544 |  |  | $ | 25,726 |  |  | $ | 61,273 |  |  | $ | 77,518 |  |
| Non-GAAP operating income | $ | 12,064 |  |  | $ | 12,279 |  |  | $ | 35,723 |  |  | $ | 14,524 |  |
| Non-GAAP operating income percentage |  | 8.6 | % |  |  | 8.2 | % |  |  | 6.7 | % |  |  | 2.6 | % |

[0001564590-16-022347:8k_2_02:77]
| Non-GAAP Net Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| GAAP net loss | $ | (2,340 | ) |  | $ | (15,657 | ) |  | $ | (31,884 | ) |  | $ | (71,643 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 2,673 |  |  |  | 3,470 |  |  |  | 14,792 |  |  |  | 17,405 |  |
| Acquisition and integration costs |  | - |  |  |  | 923 |  |  |  | 1,145 |  |  |  | 10,205 |  |
| Restructuring charge, net of reversal |  | 998 |  |  |  | 9,819 |  |  |  | 10,990 |  |  |  | 9,819 |  |
| Amortization of intangibles |  | 7,558 |  |  |  | 8,759 |  |  |  | 31,834 |  |  |  | 35,035 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 1,508 |  |  |  | 3,065 |  |
| Executive transition costs |  | 771 |  |  |  | 1,989 |  |  |  | 2,166 |  |  |  | 1,989 |  |
| Litigation |  | 167 |  |  |  | - |  |  |  | 331 |  |  |  | - |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Total adjustments to GAAP net loss | $ | 12,544 |  |  | $ | 25,726 |  |  | $ | 61,273 |  |  | $ | 77,518 |  |
| Non-GAAP net income | $ | 10,204 |  |  | $ | 10,069 |  |  | $ | 29,389 |  |  | $ | 5,875 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.10 |  |  | $ | 0.10 |  |  | $ | 0.28 |  |  | $ | 0.06 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 107,275 |  |  |  | 101,205 |  |  |  | 105,306 |  |  |  | 100,802 |  |

[0001564590-16-022347:8k_2_02:78]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Cash flow provided by operations | $ | 11,451 |  |  | $ | 3,856 |  |  | $ | 30,366 |  |  | $ | 37,423 |  |
| Less: PP&E CapEx spending |  | (2,529 | ) |  | $ | (1,594 | ) |  |  | (5,327 | ) |  |  | (7,205 | ) |
| Total free cash flow | $ | 8,922 |  |  | $ | 2,262 |  |  | $ | 25,039 |  |  | $ | 30,218 |  |
