# EXTR MD&A — 0001564590-16-024924


## mdna

[0001564590-16-024924:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-16-024924:mdna:2]
Business Overview

[0001564590-16-024924:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Item 8 of Part II of this Report.

[0001564590-16-024924:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles, or U.S. GAAP.  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and spare parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-16-024924:mdna:5]
Extreme is a leading provider of network infrastructure equipment and offer related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996, and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. Substantially all of our revenue is derived from the sale of our networking equipment and related maintenance contracts.

[0001564590-16-024924:mdna:6]
Restructuring

[0001564590-16-024924:mdna:7]
During the fourth quarter of fiscal 2015, we implemented a plan to reduce costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions.

[0001564590-16-024924:mdna:8]
During fiscal 2016, we continued our initiative to realign our operations with a second phase by abandoning excess facilities, primarily in San Jose, California; Salem, New Hampshire; Research Triangle Park, North Carolina in addition to other smaller leased locations. Such facilities represented approximately 32% of the floor space in the aggregate at these locations and included general office and warehouse space. We may terminate or choose not to renew leases for excess facilities in future periods as we further align our organization to our business and operational needs.

[0001564590-16-024924:mdna:9]
Amendment to Rights Agreement

[0001564590-16-024924:mdna:10]
On April 26, 2012, we entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of our Common Stock. Each Right initially represents the right to purchase one one-thousandth of a share of our Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as subsequently amended, between us and Mellon Investor Services LLC (the “Prior Rights Plan”).

[0001564590-16-024924:mdna:11]
The Board adopted the Restated Rights Plan to preserve the value of our deferred tax assets, including our net operating loss carry forwards, with respect to our ability to fully use tax benefits to offset future income which may be limited if we experience an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986, as amended as a result of ordinary buying and selling of our common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of us and our stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 our Board and shareholders have approved an amendment providing for a one year extension of the term of the Restated Rights Plan.  Our Board of Directors unanimously approved an amendment to the Restated Rights Plan on May 5, 2016 to extend the Restated Rights Plan through May 31, 2017, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting, expected to be held on November 18, 2016.

[0001564590-16-024924:mdna:12]
Results of Operations

[0001564590-16-024924:mdna:13]
Our operations and financial performance during fiscal 2016, achieved the following results:

[0001564590-16-024924:mdna:14]
|  | · | Net revenue of $528.4 million, a decrease of 4.4% from fiscal 2015 net revenue of $552.9 million. |

[0001564590-16-024924:mdna:15]
|  | · | Product revenue of $395.5 million, a decrease of 5.4% from fiscal 2015 product revenue of $418.0 million. |

[0001564590-16-024924:mdna:16]
|  | · | Service revenue of $132.9 million, a decrease of 1.5% from fiscal 2015 service revenue of $134.9 million. |

[0001564590-16-024924:mdna:17]
|  | · | Total gross margin of 51.2% of net revenue in fiscal 2016, compared to 50.6% in fiscal 2015. |

[0001564590-16-024924:mdna:18]
|  | · | Restructuring charge of $11.0 million, for excess facilities and contract termination. |

[0001564590-16-024924:mdna:19]
|  | · | Operating loss of $25.6 million, a decrease in the operating loss of $37.4 million from fiscal 2015. |

[0001564590-16-024924:mdna:20]
|  | · | Net loss was $31.9 million in fiscal 2016, a decrease of $39.8 million from a net loss of $71.6 million in fiscal 2015. |

[0001564590-16-024924:mdna:21]
|  | · | Cash flow provided by operating activities was $30.4 million, compared to cash flow provided by operating activities of $37.4 million in fiscal 2015, a decrease of $7.1 million. Cash and cash equivalents were $94.1 million as of June 30, 2016, an increase of $17.9 million compared to fiscal 2015. |

[0001564590-16-024924:mdna:22]
Net Revenue

[0001564590-16-024924:mdna:23]
The following table presents net product and service revenue for the fiscal years 2016, 2015 and 2014 (dollars in thousands):

[0001564590-16-024924:mdna:24]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |  | June 30, 2015 |  |  | June 30, 2014 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 395,464 |  |  | $ | 418,046 |  |  | $ | (22,582 | ) |  |  | (5.4 | )% |  | $ | 418,046 |  |  | $ | 411,761 |  |  | $ | 6,285 |  |  |  | 1.5 | % |
| Percentage of net revenue |  |  | 74.8 | % |  |  | 75.6 | % |  |  |  |  |  |  |  |  |  |  | 75.6 | % |  |  | 79.3 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 132,925 |  |  |  | 134,894 |  |  |  | (1,969 | ) |  |  | (1.5 | )% |  |  | 134,894 |  |  | $ | 107,793 |  |  |  | 27,101 |  |  |  | 25.1 | % |
| Percentage of net revenue |  |  | 25.2 | % |  |  | 24.4 | % |  |  |  |  |  |  |  |  |  |  | 24.4 | % |  |  | 20.7 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 528,389 |  |  | $ | 552,940 |  |  | $ | (24,551 | ) |  |  | (4.4 | )% |  | $ | 552,940 |  |  | $ | 519,554 |  |  | $ | 33,386 |  |  |  | 6.4 | % |

[0001564590-16-024924:mdna:25]
Product revenue decreased $22.6 million or 5.4% for the year-ended June 30, 2016, compared to the corresponding period of fiscal 2015. The decrease in sales was primarily due to an increase in competitive pricing pressure on lower volumes of chassis (modular) based products due to market shifts towards fixed products which are generally lower cost and are capable of rapidly adapting to changes and needs of the marketplace. The growth in the fixed products was not sufficient to offset the modular product decline and to a lesser extent, to the strengthening of the United States Dollar in nearly all geographical regions.

[0001564590-16-024924:mdna:26]
Product revenue increased $6.3 million or 1.5% for the year-ended June 30, 2015, compared to the corresponding period of fiscal 2014. The fiscal 2015 period reflects increased product shipments and customers as a result of our acquisition of Enterasys, whereas the fiscal 2014 period only reflects eight months of sales subsequent to the October 31, 2013 acquisition date.  However, the increase in sales was partially offset by declines of customer spending across each geographical region and an increase in customer discounts.  The decline in customer spending was partially due to the significant strengthening of the United States Dollar in all geographical areas and the entrance of competitors in regions where we have a strong presence, specifically in Asia Pacific and EMEA regions.

[0001564590-16-024924:mdna:27]
Service revenue decreased $2.0 million or 1.5% for the year-ended June 30, 2016 compared to the corresponding period of fiscal 2015 due to a decrease in service maintenance contracts and professional service and training revenues.  Partially offsetting the decrease were lower purchase accounting charges related to deferred service revenues which decreased $1.6 million for the year-ended June 30, 2016, to $1.5 million from $3.1 million in the corresponding period of fiscal 2015.

[0001564590-16-024924:mdna:28]
Service revenue increased $27.1 million or 25.1% for the year-ended June 30, 2015 compared to the corresponding period of fiscal 2014 due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys.  Purchase accounting charges related to deferred service revenues decreased $2.2 million for the year-ended June 30, 2015, to $3.1 million from $5.3 million in the corresponding period of fiscal 2014.

[0001564590-16-024924:mdna:29]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenue geographically for the fiscal years 2016, 2015 and 2014 (dollars in thousands):

[0001564590-16-024924:mdna:30]
|  |  | Year Ended |  |  | Year Ended |  |
| Net Revenues |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |  | June 30, 2015 |  |  | June 30, 2014 |  |  | $ Change |  |  | % Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 237,933 |  |  | $ | 238,748 |  |  | $ | (815 | ) |  |  | (0.3 | )% |  | $ | 238,748 |  |  | $ | 211,734 |  |  | $ | 27,014 |  |  |  | 12.8 | % |
| Other |  |  | 44,455 |  |  |  | 31,931 |  |  |  | 12,524 |  |  |  | 39.2 | % |  |  | 31,931 |  |  |  | 45,790 |  |  |  | (13,859 | ) |  |  | (30.3 | )% |
| Total Americas |  |  | 282,388 |  |  |  | 270,679 |  |  |  | 11,709 |  |  |  | 4.3 | % |  |  | 270,679 |  |  |  | 257,524 |  |  |  | 13,155 |  |  |  | 5.1 | % |
| Percentage of net revenue |  |  | 53.4 | % |  |  | 49.0 | % |  |  |  |  |  |  |  |  |  |  | 49.0 | % |  |  | 49.6 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 196,588 |  |  |  | 223,368 |  |  |  | (26,780 | ) |  |  | (12.0 | )% |  |  | 223,368 |  |  |  | 202,555 |  |  |  | 20,813 |  |  |  | 10.3 | % |
| Percentage of net revenue |  |  | 37.2 | % |  |  | 40.4 | % |  |  |  |  |  |  |  |  |  |  | 40.4 | % |  |  | 39.0 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 49,413 |  |  |  | 58,893 |  |  |  | (9,480 | ) |  |  | (16.1 | )% |  |  | 58,893 |  |  |  | 59,475 |  |  |  | (582 | ) |  |  | (1.0 | )% |
| Percentage of net revenue |  |  | 9.4 | % |  |  | 10.7 | % |  |  |  |  |  |  |  |  |  |  | 10.7 | % |  |  | 11.4 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 528,389 |  |  | $ | 552,940 |  |  | $ | (24,551 | ) |  |  | (4.4 | )% |  | $ | 552,940 |  |  | $ | 519,554 |  |  | $ | 33,386 |  |  |  | 6.4 | % |

[0001564590-16-024924:mdna:31]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEM, and direct sales.  Revenue through our distributor channel was 49% of total product revenue in fiscal 2016, 47% of total product revenue in fiscal 2015 and 44% of total product revenue in fiscal 2014.

[0001564590-16-024924:mdna:32]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001564590-16-024924:mdna:33]
Cost of Revenue and Gross Profit

[0001564590-16-024924:mdna:34]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenue for the fiscal years 2016, 2015 and 2014 (dollars in thousands):

[0001564590-16-024924:mdna:35]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |  | June 30, 2015 |  |  | June 30, 2014 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 186,725 |  |  | $ | 193,028 |  |  | $ | (6,303 | ) |  |  | (3.3 | )% |  | $ | 193,028 |  |  | $ | 198,088 |  |  | $ | (5,060 | ) |  |  | (2.6 | )% |
| Percentage of product revenue |  |  | 47.2 | % |  |  | 46.2 | % |  |  |  |  |  |  |  |  |  |  | 46.2 | % |  |  | 48.1 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 84,063 |  |  |  | 86,709 |  |  |  | (2,646 | ) |  |  | (3.1 | )% |  |  | 86,709 |  |  |  | 69,241 |  |  |  | 17,468 |  |  |  | 25.2 | % |
| Percentage of service revenue |  |  | 63.2 | % |  |  | 64.3 | % |  |  |  |  |  |  |  |  |  |  | 64.3 | % |  |  | 64.2 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 270,788 |  |  | $ | 279,737 |  |  | $ | (8,949 | ) |  |  | (3.2 | )% |  | $ | 279,737 |  |  | $ | 267,329 |  |  | $ | 12,408 |  |  |  | 4.6 | % |
| Percentage of net revenue |  |  | 51.2 | % |  |  | 50.6 | % |  |  |  |  |  |  |  |  |  |  | 50.6 | % |  |  | 51.5 | % |  |  |  |  |  |  |  |  |

[0001564590-16-024924:mdna:36]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001564590-16-024924:mdna:37]
Product gross profit decreased to $186.7 million for the year-ended June 30, 2016, from $193.0 million in the corresponding period of fiscal 2015.  Product gross profit for the year-ended June 30, 2016, was unfavorably impacted by a decrease in product revenue of $22.6 million, offset by lower amortization of developed technology intangibles of $2.3 million, lower royalty charges of $1.9 million and warranty charges of $0.8 million.

[0001564590-16-024924:mdna:38]
Product gross profit decreased to $193.0 million for the year-ended June 30, 2015, from $198.1 million in the corresponding period of fiscal 2014.  Product gross profit for the year-ended June 30, 2015, was favorably impacted by an increase in product revenue of $6.3 million, offset by higher material costs and increases of $5.8 million in excess and obsolete inventory charges, $6.1 million for amortization of the developed technology intangibles from the acquisition of Enterasys, $3.4 million for distribution costs due to higher utilization of air freight and $3.3 million of warranty charges. Gross profit for fiscal 2014, was negatively impacted by $11.1 million related to the sale of inventory which had been adjusted to fair value upon the Enterasys acquisition due to purchase accounting.

[0001564590-16-024924:mdna:39]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spare parts used in providing support under customer maintenance contracts.

[0001564590-16-024924:mdna:40]
Service gross profit decreased to $84.1 million for the year-ended June 30, 2016, from $86.7 million in the corresponding period of fiscal 2015, primarily due to a decrease in service revenue of $2.0 million and increased operating expenses, primarily professional fees of $0.6 million.

[0001564590-16-024924:mdna:41]
Service gross profit increased to $86.7 million for the year-ended June 30, 2015, from $69.2 million in the corresponding period of fiscal 2014, primarily due to an increase in service revenue of $27.1 million partially offset by increased personnel, overhead and travel costs as a result of the acquisition of Enterasys.

[0001564590-16-024924:mdna:42]
Operating Expenses

[0001564590-16-024924:mdna:43]
The following table presents operating expenses and operating income (dollars in thousands):

[0001564590-16-024924:mdna:44]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |  | June 30, 2015 |  |  | June 30, 2014 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 78,721 |  |  | $ | 93,447 |  |  | $ | (14,726 | ) |  |  | (15.8 | )% |  | $ | 93,447 |  |  | $ | 77,146 |  |  | $ | 16,301 |  |  |  | 21.1 | % |
| Sales and marketing |  |  | 150,806 |  |  |  | 169,299 |  |  |  | (18,493 | ) |  |  | (10.9 | )% |  |  | 169,299 |  |  |  | 156,666 |  |  |  | 12,633 |  |  |  | 8.1 | % |
| General and administrative |  |  | 37,675 |  |  |  | 42,092 |  |  |  | (4,417 | ) |  |  | (10.5 | )% |  |  | 42,092 |  |  |  | 40,812 |  |  |  | 1,280 |  |  |  | 3.1 | % |
| Acquisition and integration costs |  |  | 1,145 |  |  |  | 10,205 |  |  |  | (9,060 | ) |  |  | (88.8 | )% |  |  | 10,205 |  |  |  | 25,716 |  |  |  | (15,511 | ) |  |  | (60.3 | )% |
| Restructuring charge, net of reversals |  |  | 10,990 |  |  |  | 9,819 |  |  |  | 1,171 |  |  |  | 11.9 | % |  |  | 9,819 |  |  |  | 510 |  |  |  | 9,309 |  |  |  | 1,825.3 | % |
| Amortization of intangibles |  |  | 17,001 |  |  |  | 17,869 |  |  |  | (868 | ) |  |  | (4.9 | )% |  |  | 17,869 |  |  |  | 16,711 |  |  |  | 1,158 |  |  |  | 6.9 | % |
| Total operating expenses |  | $ | 296,338 |  |  | $ | 342,731 |  |  | $ | (46,393 | ) |  |  | (13.5 | )% |  | $ | 342,731 |  |  | $ | 317,561 |  |  | $ | 25,170 |  |  |  | 7.9 | % |
| Operating loss |  | $ | (25,550 | ) |  | $ | (62,994 | ) |  | $ | 37,444 |  |  |  | 59.4 | % |  | $ | (62,994 | ) |  | $ | (50,232 | ) |  | $ | (12,762 | ) |  |  | (25.4 | )% |

[0001564590-16-024924:mdna:45]
The following table highlights our operating expenses and operating loss as a percentage of net revenues:

[0001564590-16-024924:mdna:46]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Research and development |  |  | 14.9 | % |  |  | 16.9 | % |  |  | 14.8 | % |
| Sales and marketing |  |  | 28.5 | % |  |  | 30.6 | % |  |  | 30.2 | % |
| General and administrative |  |  | 7.1 | % |  |  | 7.6 | % |  |  | 7.9 | % |
| Acquisition and integration costs |  |  | 0.2 | % |  |  | 1.8 | % |  |  | 4.9 | % |
| Restructuring charge, net of reversals |  |  | 2.1 | % |  |  | 1.8 | % |  |  | 0.1 | % |
| Amortization of intangibles |  |  | 3.2 | % |  |  | 3.2 | % |  |  | 3.2 | % |
| Total operating expenses |  |  | 56.1 | % |  |  | 62.0 | % |  |  | 61.1 | % |
| Operating loss |  |  | (4.8 | )% |  |  | (11.4 | )% |  |  | (9.7 | )% |

[0001564590-16-024924:mdna:47]
Research and Development Expenses

[0001564590-16-024924:mdna:48]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-16-024924:mdna:49]
Research and development expenses decreased by $14.7 million or 15.8% for fiscal 2016 as compared to fiscal 2015. The decrease in spending is related to $11.6 million of personnel costs, which includes compensation, benefits and non-cash stock based compensation, $1.6 million in reduced supplies and equipment costs, $1.2 million in depreciation and $0.3 million of other costs.

[0001564590-16-024924:mdna:50]
Research and development expenses increased by $16.3 million or 21.1% for fiscal 2015 as compared to fiscal 2014. The increase in research and development expenses was primarily due to increased spending as a result of our acquisition of Enterasys.  The increase in spending related to $13.4 million of personnel costs, which includes compensation, benefits and non-cash stock based compensation, including $0.4 million of expense related to our executive transition activity, $1.3 million in depreciation and $0.8 million for supplies and equipment.

[0001564590-16-024924:mdna:51]
Sales and Marketing Expenses

[0001564590-16-024924:mdna:52]
Sales and marketing expenses consist of salaries, commissions and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001564590-16-024924:mdna:53]
Sales and marketing expenses decreased by $18.5 million or 10.9% for the year-ended June 30, 2016 as compared to the corresponding period of fiscal 2015.  The decrease in sales and marketing expenses during fiscal 2016 was primarily due to lower personnel costs including benefits and non-cash stock compensation of $11.5 million, $3.1 million in reduced travel costs, $2.4 million in occupancy expense and $1.9 million for sales conferences and related costs.  In addition, sales and marketing professional fees decreased by $0.8 million during the period.

[0001564590-16-024924:mdna:54]
Sales and marketing expenses increased by $12.6 million or 8.1% for the year-ended June 30, 2015 as compared to the corresponding period of fiscal 2014.  The increase in sales and marketing expenses during fiscal 2015 was primarily due to $6.7 million of higher compensation, benefits and non-cash stock compensation, including $0.5 million of expense related to our executive transition activity, $2.7 million in marketing expense, $1.8 million in facilities and $0.8 million in depreciation.  All of these factors were primarily driven by the acquisition of Enterasys.

[0001564590-16-024924:mdna:55]
General and Administrative Expenses

[0001564590-16-024924:mdna:56]
General and administrative expense consists primarily of personnel costs, legal and professional service costs, share-based compensation, travel and facilities and information technology costs.

[0001564590-16-024924:mdna:57]
General and administrative expenses decreased by $4.4 million or 10.5% for the year-ended June 30, 2016 as compared to the corresponding period of fiscal 2015.  The decrease in general and administrative expenses was primarily due to $3.6 million in lower personnel costs related to our reduced headcount, as well as reduced professional fees of $1.9 million and other expenses of $0.4 million.

[0001564590-16-024924:mdna:58]
General and administrative expenses increased by $1.3 million or 3.1% for the year-ended June 30, 2015 as compared to the corresponding period of fiscal 2014.  The increase in general and administrative expenses was primarily due to $1.1 million in higher personnel costs related to our executive transition activity, higher occupancy costs due to additional facilities in Salem, New Hampshire and Shannon, Ireland as a result of our acquisition of Enterasys, a $0.8 million increase in bad debt expense and $0.2 million in professional service fees.  This increase was partially offset by $1.0 million in lower travel costs.

[0001564590-16-024924:mdna:59]
Acquisition and Integration Costs

[0001564590-16-024924:mdna:60]
As a result of our acquisition of Enterasys, we incurred $1.1 million, $10.2 million and $25.7 million of acquisition and integration costs in fiscal 2016, 2015 and 2014, respectively.  For fiscal 2016 and 2015, the entire $1.1 million and $10.2 million, respectively, of expense was related to integration costs.   The fiscal 2014 expense was related to $19.7 million of integration costs and the remaining $6.0 million expense was related to acquisition costs.  The lower fiscal 2016 integration expenses was due to winding down of integration activities associated with the acquisition, which included lower severance and termination costs, information systems applications costs and consulting fees.  The lower fiscal 2015 integration expenses were due to lower severance and termination costs and third party consulting fees.

[0001564590-16-024924:mdna:61]
Restructuring Charge, Net of Reversals

[0001564590-16-024924:mdna:62]
During fiscal years 2016, 2015 and 2014, we recorded restructuring charges, net of reversals, of $11.0 million, $9.8 million and $0.5 million, respectively.

[0001564590-16-024924:mdna:63]
2015 Restructuring Plan

[0001564590-16-024924:mdna:64]
Fiscal year 2016 – Phase 2

[0001564590-16-024924:mdna:65]
During fiscal 2016, we continued our initiative that began in fiscal 2015, to realign our operations with a second phase by abandoning excess facilities, primarily in San Jose, California; Salem, New Hampshire; Research Triangle Park, North Carolina in addition to other smaller leased locations. The abandoned facilities represented approximately 32% of the floor space in the aggregate at these locations and included general office and warehouse space.

[0001564590-16-024924:mdna:66]
In conjunction with the exiting of facilities noted above, we incurred $11.0 of restructuring charges. Excess facilities charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and contract termination charges of $5.4 million, acceleration of depreciation of leasehold improvements of $4.5 million, professional fees of $1.0 million and other expenses of $0.1 million.

[0001564590-16-024924:mdna:67]
Significant restructuring charges incurred during the period, by location, included $1.8 million of charges for excess facilities pertaining to the estimated future obligations for non-cancelable lease payments at our San Jose location.  This represented 39% of the San Jose lease space.  We amended our facility lease at our North Carolina location and exited excess space while recording $4.1 million of charges, which included $3.1 million in accelerated depreciation of leasehold improvements. This action represented 36% of the North Carolina location lease space. We recorded $4.4 million of charges for excess facilities at our Salem location, which included $1.3 million in accelerated depreciation of leasehold improvements.  This action represented 27% of the Salem lease space.

[0001564590-16-024924:mdna:68]
As of June 30, 2016, we reflect restructuring liabilities of $4.6 million related to the excess facilities charges, of which, payments will continue through fiscal year 2023, due to the length of the lease agreements.  The restructuring liability is recorded in "Other accrued liabilities" and “Other long-term liabilities” on the consolidated balance sheets.

[0001564590-16-024924:mdna:69]
Fiscal year 2015-Phase 1

[0001564590-16-024924:mdna:70]
During the fourth quarter of fiscal 2015, we implemented a plan to reduce costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. We have expensed all costs associated with this initiative.  As of June 30, 2015, we reflected a restructuring liability of $5.9 million related to this initiative which was fully paid as of June 30, 2016.

[0001564590-16-024924:mdna:71]
Fiscal year 2014

[0001564590-16-024924:mdna:72]
In fiscal 2014, we incurred an additional $0.5 million of expenses related to a restructuring plan originating in 2013.  As part of our restructuring efforts that began in fiscal 2013, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. There were no outstanding liabilities related to the fiscal 2013 restructuring as of June 30, 2015.

[0001564590-16-024924:mdna:73]
Amortization of Intangibles

[0001564590-16-024924:mdna:74]
During fiscal 2016, 2015 and 2014, we recorded $17.0 million, $17.9 million and $16.7 million, respectively, of amortization expenses in operating expenses primarily for certain intangibles related to the acquisition of Enterasys.

[0001564590-16-024924:mdna:75]
Interest Income

[0001564590-16-024924:mdna:76]
Interest income was $0.1 million, $0.5 million and $0.8 million in fiscal years 2016, 2015 and 2014, respectively, representing a decrease of $0.4 million in fiscal 2016 from fiscal 2015 and a decrease of $0.3 million in fiscal 2015 from fiscal 2014.  The decrease in interest income in fiscal 2016 and 2015 was due to a decrease in the investment balances to fund debt reduction.

[0001564590-16-024924:mdna:77]
Interest Expense

[0001564590-16-024924:mdna:78]
We had $3.1 million, $3.2 million and $2.1 million of interest expense for fiscal 2016, 2015 and 2014, respectively.  Interest expense in fiscal years 2016, 2015 and 2014 was primarily related to the Senior Secured Credit Facilities, as amended, we entered into on October 31, 2013.

[0001564590-16-024924:mdna:79]
Other (Expense) Income, net

[0001564590-16-024924:mdna:80]
Other (expense) income, net was income of $1.0 million in fiscal 2016 and expense of $1.2 million and $1.6 million in fiscal years 2015 and 2014, respectively.  Other expense in the respective periods was primarily due to the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-16-024924:mdna:81]
Provision for Income Taxes

[0001564590-16-024924:mdna:82]
We are subject to income taxes in the United States and numerous foreign jurisdictions.  Our effective tax rate differs from the U.S. federal statutory rate of 35% primarily due to the impact of state taxes, foreign operations which are generally taxed at lower statutory rates and the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions.  For the fiscal years ended June 30, 2016, 2015 and 2014, we recorded income tax provisions of $4.3 million, $4.8 million and $4.2 million, respectively.  The effective tax rates for fiscal years ended June 30, 2016, 2015 and 2014 were 15.7%, 7.2% and 7.9%, respectively.

[0001564590-16-024924:mdna:83]
For the fiscal years ended June 30, 2016, 2015 and 2014 the majority of our tax provision related to taxes on our foreign operations as well as state taxes due to the full valuation allowance on our U.S. and certain foreign deferred tax assets.  In the fiscal year ended June 30, 2014, a portion of our provision resulted from the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.

[0001564590-16-024924:mdna:84]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 35% and for further explanation of our provision for income taxes, see Note 9 to the consolidated financial statements.

[0001564590-16-024924:mdna:85]
Critical Accounting Policies and Estimates

[0001564590-16-024924:mdna:86]
Our significant accounting policies are more fully described in Note 3 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001564590-16-024924:mdna:87]
Revenue Recognition

[0001564590-16-024924:mdna:88]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for our products. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and the collection of the sales proceeds is reasonably assured. In instances where any of the criteria for revenue recognition are not met, we defer revenue until all criteria have been met.

[0001564590-16-024924:mdna:89]
Product revenue from our value-added resellers, non-stocking distributors and end-user customers is recognized at the time of shipment, provided that all of the foregoing revenue recognition requirements have been satisfied.  We generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits. Accordingly, we recognize revenue upon transfer of title and risk of loss to the customer, which is generally upon shipment. We maintain estimated accruals and allowances for sales incentives and other programs that we may make available to our partners, based on historical experience or applicable contractual terms. Sales taxes collected from customers are excluded from revenues.  Shipping costs are included in cost of product revenues.

[0001564590-16-024924:mdna:90]
We also sell our products to distributors that stock inventory and sell to resellers. We defer recognition of revenue on all sales to our stocking distributors until the distributors have sold the products, as evidenced by sales data that the distributors provide to us. We grant stocking distributors certain price protection rights and the right to return a portion of unsold inventory for the purpose of stock rotation. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. We also provide stocking distributors with credits for changes in selling prices based on competitive conditions, and provide funding for our distributors and their resellers to perform marketing development activities. We maintain estimated accruals and allowances for these exposures based upon our contractual obligations. Our marketing development channel programs do not meet the criteria for recognizing the costs as marketing expenses and therefore these costs are accrued as a reduction to revenue in the same period that the products are sold.

[0001564590-16-024924:mdna:91]
Revenue from maintenance contracts is deferred and recognized ratably over the contractual service period, which is typically from one to two years. Professional service revenue is recognized upon delivery or completion of performance.

[0001564590-16-024924:mdna:92]
Our networking products are tangible products that contain software and non-software components that function together to deliver the tangible product's essential functionality. Our sales arrangements may contain multiple deliverables comprised of our tangible products, standalone software licenses, and maintenance offerings depending on the distribution sales channel through which the products are sold and the requirements of our customers. We recognize revenue for our multiple deliverable arrangements in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. The industry-specific software revenue recognition guidance does not apply to the sales of our tangible products.  Software revenue guidance is applied to sales of our standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001564590-16-024924:mdna:93]
Pursuant to the guidance of the accounting standard for multiple-deliverable revenue arrangements, we allocate the total arrangement consideration to each separable element of an arrangement based on the relative selling price of each element.  We determine the standalone selling price for each element based on a selling price hierarchy. Under the selling price hierarchy, the selling price for each deliverable is based on our vendor-specific objective evidence ("VSOE") of selling price, which is determined by a substantial majority of our historical standalone sales transactions for a product or service falling within a reasonable range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, we determine the best estimate of standalone selling price (“ESP”) for a product or service by considering several factors including, but not limited to, the 12-month historical median sales price, sales channels, geography, gross margin consistency, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, we apply management judgment to determine the best estimate of selling price through consultation with and formal approval by our management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of all other deliverables is determined by using ESP. We regularly review VSOE, TPE and ESP for all of our products and services and maintain internal controls over the establishment and updates of these estimates.

[0001564590-16-024924:mdna:94]
Pursuant to the software revenue recognition accounting standard, we continue to recognize revenue for software using the residual method for our sales of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the multiple deliverable arrangement, we recognize revenue in accordance with our policies for product, software, and maintenance revenue recognition.

[0001564590-16-024924:mdna:95]
We provide an allowance for sales returns based on our historical returns, analysis of credit memo data and our return policies. The allowance for sales returns was $1.6 million and $1.1 million as of June 30, 2016 and 2015, respectively, for estimated future returns that were recorded as a reduction of our accounts receivable. If the historical data that we use to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. We estimate and adjust this allowance at each balance sheet date.

[0001564590-16-024924:mdna:96]
40

[0001564590-16-024924:mdna:97]
Goodwill

[0001564590-16-024924:mdna:98]
Goodwill is assessed for impairment annually during the fourth quarter of the fiscal year (which begins on April 1) or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. We have determined that we have one reporting unit. To test goodwill for impairment, we first perform a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, we then perform the two-step goodwill impairment test. Otherwise, the two-step goodwill impairment test is not required. Under the two-step goodwill impairment test, we in the first step, compare the estimated fair value of a reporting unit to its carrying value. If the fair value of the reporting unit exceeds the carrying value, no impairment loss is recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which we determine the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

[0001564590-16-024924:mdna:99]
We completed our annual goodwill impairment test in the fourth quarter of fiscal 2016 and determined there was no impairment as the fair value of the reporting unit exceeded its carrying value.

[0001564590-16-024924:mdna:100]
Share-based Payments

[0001564590-16-024924:mdna:101]
We use the Black-Scholes option-pricing model to determine the fair value of option grants other than option grants, with market, performance conditions, options assumed as part of the Enterasys acquisition, and share purchase options under our Employee Stock Purchase Plan (“ESPP”) on the date of grant with the weighted average assumptions. We use the Monte-Carlo simulation model to determine the fair value and the derived service period of option grants, with market, performance or service conditions or combinations of those conditions, on the date of grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of purchase options under our ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of each option and ESPP award is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on our stock and historical volatility on our stock. We do not currently pay cash dividends on our common stock and do not anticipate doing so in the foreseeable future. Accordingly, our expected dividend yield is zero. We are required to estimate forfeitures at the time of grant and revise those estimates in subsequent periods if actual forfeitures differ from those estimates.  In fiscal 2016, our estimated forfeiture rates based on historical forfeiture experiences are 19% for executives and 13% for non-executive employees.  We use the straight-line method for expense attribution, and we only recognize expense for those shares expected to vest.

[0001564590-16-024924:mdna:102]
Restructuring Charges

[0001564590-16-024924:mdna:103]
We recognize a liability for exit and disposal activities when the liability is incurred.  A liability for post-employment benefits, including severance, is recorded upon attainment of certain criteria including when payment is probable, the amount is reasonably estimable, and the obligation relates to rights that have vested or accumulated.  Facilities consolidation charges are calculated using estimates and are based upon the remaining future lease commitments for vacated facilities from the date of facility consolidation, net of estimated future sublease income. The estimated costs of vacating these leased facilities are based on market information and trend analysis.

[0001564590-16-024924:mdna:104]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives.  Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provision.

[0001564590-16-024924:mdna:105]
New Accounting Pronouncements

[0001564590-16-024924:mdna:106]
See Note 4 of the accompanying consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-16-024924:mdna:107]
Liquidity and Capital Resources

[0001564590-16-024924:mdna:108]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001564590-16-024924:mdna:109]
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Cash and cash equivalent |  | $ | 94,122 |  |  | $ | 76,225 |  |  | $ | 73,190 |  |
| Short term investments |  |  | — |  |  |  | — |  |  | $ | 32,692 |  |
| Total cash and investments |  | $ | 94,122 |  |  | $ | 76,225 |  |  | $ | 105,882 |  |
| Working capital |  | $ | 17,195 |  |  | $ | 2,564 |  |  | $ | 56,548 |  |

[0001564590-16-024924:mdna:110]
As of June 30, 2016, our principal sources of liquidity consisted of cash and cash equivalents of $94.1 million, accounts receivable, net of $81.4 million and availability of borrowings from the Revolving Facility of $34.1 million as of June 30, 2016.  We anticipate that our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment.  We believe that our  $94.1 million of cash and cash equivalents at June 30, 2016, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-16-024924:mdna:111]
The Senior Secured Credit Facilities, as amended, contain financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and several other financial and non-financial covenants and restrictions that limit our ability, among other things, to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.

[0001564590-16-024924:mdna:112]
The Senior Secured Credit Facilities, as amended, also include customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, any representation or warranty made by us being false or misleading in any material respect, certain insolvency or receivership events affecting our Company, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended, may be accelerated upon certain events of default. We believe we are in compliance and expect to remain in compliance with the covenants of the Senior Secured Credit Facilities, as amended, and they are not expected to negatively impact our liquidity or capital resources. The Senior Secured Credit Facilities, as amended, is more fully described in Note 3 of Notes to Consolidated Financial Statements.

[0001564590-16-024924:mdna:113]
Key Components of Cash Flows and Liquidity

[0001564590-16-024924:mdna:114]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001564590-16-024924:mdna:115]
|  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2014 |  |
| Net cash provided by (used in) operating activities |  | $ | 30,366 |  |  | $ | 37,423 |  |  | $ | (26,843 | ) |
| Net cash (used in) provided by investing activities |  |  | (5,327 | ) |  |  | 21,598 |  |  |  | (126,189 | ) |
| Net cash (used in) provided by financing activities |  |  | (6,738 | ) |  |  | (52,470 | ) |  |  | 129,580 |  |
| Foreign currency effect on cash |  |  | (404 | ) |  |  | (3,516 | ) |  |  | 839 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 17,897 |  |  | $ | 3,035 |  |  | $ | (22,613 | ) |

[0001564590-16-024924:mdna:116]
Cash, cash equivalents and short-term investments were $94.1 million at June 30, 2016, representing an increase of $17.9 million from $76.2 million at June 30, 2015.  Cash and cash equivalents increased primarily due to cash provided by operations of $30.4 million offset by cash used in investing activities of $5.3 million, cash used in financing activities of $6.7 million and a negative foreign currency impact of $0.4 million.

[0001564590-16-024924:mdna:117]
Cash, cash equivalents and short-term investments were $76.2 million at June 30, 2015, representing a decrease of $29.7 million from $105.9 million at June 30, 2014.  Cash and cash equivalents increased primarily due to cash provided by operations of $37.4 million and cash provided by investing activities of $21.6 million offset by cash used in financing activities of $52.5 million and foreign currency impact of $3.5 million.

[0001564590-16-024924:mdna:118]
Cash provided by operating activities for the year ended June 30, 2016 was $30.4 million compared to cash provided by operating activities of $37.4 million in fiscal 2015, a decrease of $7.1 million.  The current year's net loss of $31.9 million was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.  Other contributing factors to cash provided by operating activities for the year ended June 30, 2016 were decreases in accounts receivables and inventory as a source of cash offset by declines in the balance of our deferred revenues and accounts payable which decreased cash.

[0001564590-16-024924:mdna:119]
Cash provided by operating activities was $37.4 million during fiscal 2015 compared to cash used in operating activities of $26.8 million in fiscal 2014, an increase of $64.3 million.  The net loss of $71.6 million during fiscal 2015 was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation. Decreases in accounts receivables and increases in deferred revenue were also factors contributing to the cash provided by operating activities for the year ended June 30, 2015.

[0001564590-16-024924:mdna:120]
Cash used in operating activities was $26.8 million during fiscal 2014 compared to cash provided by operating activities of $32.2 million in fiscal 2013, a decrease of $59.1 million during the year ended June 30, 2014. The year's net loss of 57.3 million was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation. Post-

[0001564590-16-024924:mdna:121]
42

[0001564590-16-024924:mdna:122]
43

[0001564590-16-024924:mdna:123]
acquisition increases in accounts receivables, inventory, accounts payable and deferred revenue were the primary factors contributing to the cash used in operating activities for the year ended June 30, 2014 .

[0001564590-16-024924:mdna:124]
Cash used in investing activities during fiscal 2016 totaled $5.3 million, was mainly due to capital expenditures.

[0001564590-16-024924:mdna:125]
Cash flow provided by investing activities during fiscal 2015 total $21.6 million, and was mainly due to proceeds from sales and maturities of investments of $32.4 million offset by capital expenditures of $7.2 million and purchase of non-marketable equity investment of $3.0 million.

[0001564590-16-024924:mdna:126]
Cash flow used in investing activities during fiscal 2014 was $126.2 million primarily from $180.0 million proceeds used for acquisition of Enterasys, capital expenditures of $22.4 million and purchases of investments of $9.0 million. Such decreases were offset by proceeds from maturities of investments and marketable securities of $28.7 million and sales of investments and marketable securities of $56.6 million.

[0001564590-16-024924:mdna:127]
Cash used in financing activities during fiscal 2016 was $6.7 million due to the repayment of debt of $26.4 million offset by borrowings of $15.0 million on the Revolving Facility for working capital requirements and proceeds from the sale of common stock of $4.6 million primarily through our Employee Stock Purchase Plan.

[0001564590-16-024924:mdna:128]
Cash flow used in financing activities during fiscal 2015 was $52.5 million mainly due to the repayment of debt of $78.7 million offset with borrowings of $24.0 million on the Revolving Facility for working capital requirements.

[0001564590-16-024924:mdna:129]
Cash flow provided by financing activities during 2014 was $129.6 million resulting from issuance of Term Loan of $65 million and a draw on the Revolving Facility of $59 million used for the acquisition of Enterasys and working capital requirements, and $8.0 million proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001564590-16-024924:mdna:130]
Contractual Obligations

[0001564590-16-024924:mdna:131]
The following summarizes our contractual obligations at June 30, 2016, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-16-024924:mdna:132]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 55,500 |  |  | $ | 17,875 |  |  | $ | 37,625 |  |  | $ | — |  |  | $ | — |  |
| Interest on debt obligations |  |  | 2,925 |  |  |  | 1,703 |  |  |  | 1,222 |  |  |  | — |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 63,676 |  |  |  | 63,676 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 55,391 |  |  |  | 9,733 |  |  |  | 17,116 |  |  |  | 15,466 |  |  |  | 13,076 |  |
| Other liabilities |  |  | 1,911 |  |  |  | 1,716 |  |  |  | 195 |  |  |  | — |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 179,403 |  |  | $ | 94,703 |  |  | $ | 56,158 |  |  | $ | 15,466 |  |  | $ | 13,076 |  |

[0001564590-16-024924:mdna:133]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast.  Inventory purchase commitments were $63.7 million as of June 30, 2016, a decrease of $6.2 million from $69.9 million as of June 30, 2015.

[0001564590-16-024924:mdna:134]
Non-cancelable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001564590-16-024924:mdna:135]
Other liabilities include the Company's commitments towards debt related fees and specific arrangements other than inventory.

[0001564590-16-024924:mdna:136]
The amounts in the table above exclude income tax liabilities related to uncertain tax positions as existing tax attributes of the Company are available to offset any potential income tax obligations.

[0001564590-16-024924:mdna:137]
We did not have any material commitments for capital expenditures as of June 30, 2016.

[0001564590-16-024924:mdna:138]
Off-Balance Sheet Arrangements

[0001564590-16-024924:mdna:139]
We did not have any off-balance sheet arrangements as of June 30, 2016.

[0001564590-16-024924:mdna:140]
Capital Resources and Financial Condition

[0001564590-16-024924:mdna:141]
As of June 30, 2016, we had $94.1 million in cash and cash equivalents.  We believe that our current cash, cash equivalents, cash available from future operations along with the availability of borrowings from the Revolving Facility will enable us to meet our working capital requirements for at least the next 12 months.

[0001564590-16-024924:mdna:142]
45
