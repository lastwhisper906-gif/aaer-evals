# EXTR 8-K — 0001078271-14-000006 filed 2014-02-05

## item codes, every 8-K on or before 2014-02-06

- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2014-02-06

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-14-000006:8k_2_02:1]
EX-99.1
2
extr8kq214ex991.htm
PRESS RELEASE

[0001078271-14-000006:8k_2_02:2]
EXTR 8K Q2'14 EX 99.1

[0001078271-14-000006:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-14-000006:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-14-000006:8k_2_02:5]
Extreme Networks Reports Second Quarter Fiscal Year 2014 Financial Results

[0001078271-14-000006:8k_2_02:6]
Completed Acquisition of Enterasys Networks for $180M - Doubled in Size and

[0001078271-14-000006:8k_2_02:7]
immediately accretive to non-GAAP EPS

[0001078271-14-000006:8k_2_02:8]
GAAP Revenue: $146.6 million & non-GAAP Revenue: $148.3 million

[0001078271-14-000006:8k_2_02:9]
GAAP EPS: Loss of $0.17 primarily related to acquisition expenses

[0001078271-14-000006:8k_2_02:10]
Non-GAAP EPS: $0.14, increased $0.11 compared to the prior year

[0001078271-14-000006:8k_2_02:11]
SAN JOSE, Calif., February 5, 2014/PRNewswire/ -- Extreme Networks, Inc. (Nasdaq: EXTR) today announced GAAP revenue of $146.6 million for its second quarter of fiscal 2014 ending December 31, 2013. This represents a 94% increase compared to revenue of $75.6 million reported for the second quarter of fiscal 2013 and a 93% increase compared to the first quarter of fiscal 2014. The second fiscal quarter results included two full months of Enterasys ownership.  GAAP net loss for the second fiscal quarter was $16.0 million or $0.17 per share, which includes $11.0 million of purchase accounting expenses, $8.7 million of acquisition and integration costs, $6.5 million of amortization of intangibles related to the Enterasys Networks acquisition and $3.5 million of stock based compensation.  This is compared to a GAAP net loss for the second quarter of fiscal 2013 of $4.2 million or $0.04 per share, which included $5.2 million related to restructuring charges and $1.6 million of stock based compensation.  On a non-GAAP basis, revenue was $148.3 million, which includes a purchase accounting adjustment of $1.8 million and net income for the second quarter of fiscal 2014 was $14.1 million, or $0.14 per diluted share, compared to non-GAAP net income for the second quarter of fiscal 2013 of $2.8 million, or $0.03 per diluted share.

[0001078271-14-000006:8k_2_02:12]
“We completed the acquisition of Enterasys on the final day of October making Extreme the fifth largest Ethernet switching company in the market. Our second quarter non-GAAP results, that were within our guidance on both revenue and earnings per share; demonstrate the scale we have achieved as a result of the acquisition” said Chuck Berger, president and CEO for Extreme Networks.  “Our integration plans are on track.  The senior management team for the combined Company has been established and announced and we continue to make steady progress towards a complete integration.  In mid January, in a joint announcement with the NFL, we were named the Official WIFI analytics provider of the NFL and Super Bowl XLVIII.  Our newly released Purview WIFI data analytics product provided the NFL with detailed information about WIFI usage at Super Bowl XLVIII.”

[0001078271-14-000006:8k_2_02:13]
Fiscal Q2 2014 Financial Metrics:

[0001078271-14-000006:8k_2_02:14]
|  |  | Second Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2014 |  | 2013 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 119.1 |  |  | $ | 60.3 |  |  | $ | 58.8 |  |  | 98 | % |
| Service |  | $ | 27.5 |  |  | $ | 15.3 |  |  | $ | 12.2 |  |  | 80 | % |
| Total Net Revenue |  | $ | 146.6 |  |  | $ | 75.6 |  |  | $ | 71.0 |  |  | 94 | % |
| Gross Margin |  | 48 | % |  | 54 | % |  | (6 | )% |  |  |
| Operating Margin/Loss |  | (9 | )% |  | (5 | )% |  | (4 | )% |  |  |
| Net Income |  | $ | (16.0 | ) |  | $ | (4.2 | ) |  | $ | (11.8 | ) |  |  |
| Earnings per diluted share |  | $ | (0.17 | ) |  | $ | (0.04 | ) |  | $ | (0.13 | ) |  |  |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 119.1 |  |  | $ | 60.3 |  |  | $ | 58.8 |  |  | 98 | % |
| Service |  | $ | 29.2 |  |  | $ | 15.3 |  |  | $ | 13.9 |  |  | 91 | % |
| Total Net Revenue |  | $ | 148.3 |  |  | $ | 75.6 |  |  | $ | 72.7 |  |  | 96 | % |
| Gross Margin |  | 56 | % |  | 54 | % |  | 2 | % |  |  |
| Operating Margin |  | 11 | % |  | 4 | % |  | 7 | % |  |  |
| Net Income |  | $ | 14.1 |  |  | $ | 2.8 |  |  | $ | 11.3 |  |  |  |
| Earnings per diluted share |  | $ | 0.14 |  |  | $ | 0.03 |  |  | $ | 0.11 |  |  |  |

[0001078271-14-000006:8k_2_02:15]
| • | Non-GAAP Gross margin for Q2 was 56.4%, an increase of two percentage points year over year and a decrease of two percentage points quarter over quarter. |

[0001078271-14-000006:8k_2_02:16]
| • | Cash and investments ended the quarter at $112.0 million, as compared to $199.4 million from Q1 of fiscal 2014. We used $180 million related to the acquisition of Enterasys Networks and acquired $100 million in debt during the quarter. |

[0001078271-14-000006:8k_2_02:17]
| • | Accounts receivable balance ending Q2 was $94.3 million, a (net) increase of $55.0 million from Q1 of fiscal 2014, with days sales outstanding (DSO) of 58, an increase of 11 days from Q1 of fiscal 2014. We recorded $25.7 million of accounts receivable as part of the Enterasys acquisition on October 31, 2013. |

[0001078271-14-000006:8k_2_02:18]
| • | Inventory ending Q2 was $62.9 million, a (net) increase of $32.5 million from Q1 of fiscal 2014 and represents 85 days of inventory (DOI), a decrease of 14 days from Q1 of fiscal 2014. We recorded $33.7 million of inventory as part of the Enterasys acquisition on October 31, 2013. |

[0001078271-14-000006:8k_2_02:19]
Recent Business Highlights:

[0001078271-14-000006:8k_2_02:20]
| • | Extreme Networks completed the acquisition of Enterasys Networks for $180 million, net of cash acquired, on October 31, 2013. The company also entered into a 5 year $125 million credit facility and drew $65 million in term debt and $35 million in revolver debt for the acquisition and to fund general corporate obligations. The company has $25 million remaining on the credit facility. |

[0001078271-14-000006:8k_2_02:21]
| • | Extreme Networks and Enterasys Networks’ L2/3 Ethernet switch revenues during Q2 CY13 combined for #5 in overall market share among leading vendors, according to statistics from the Dell’Oro Group’s 1Q13 L2/3 Ethernet market share report. |

[0001078271-14-000006:8k_2_02:22]
| • | The National Football League (NFL) and Super Bowl XLVIII named Extreme Networks as its Official Wi-Fi Analytics Provider. |

[0001078271-14-000006:8k_2_02:23]
| • | A Readers' Choice Top 100 Product award has been awarded to Extreme Networks for its IdentiFi Wireless solution by District Administration magazine, a key source of information for school superintendents across the country. |

[0001078271-14-000006:8k_2_02:24]
| • | Extreme introduced the Summit® X770, a groundbreaking, highly scalable Top of Rack (TOR) switch with market leading 10GbE density and investment protection aimed at data centers and big data. |

[0001078271-14-000006:8k_2_02:25]
.

[0001078271-14-000006:8k_2_02:26]
Business Outlook:

[0001078271-14-000006:8k_2_02:27]
Financial targets for the third fiscal quarter reflect the acquisition of Enterasys Networks for a full quarter. For its third quarter of fiscal 2014 ending March 31, 2014, the company is targeting GAAP revenue in a range of $138 million to $153 million with non-GAAP revenue in a range of $140 million to $155 million.  GAAP gross margin is targeted in a range of 50% to 52% and non-GAAP gross margin targeted to be 55% to 57%. Operating expenses are targeted to be between $88 million and $94 million on a GAAP basis and $75 million to $81 million on a non-GAAP basis. GAAP net loss is targeted to be between $15 million to $20 million, or $0.15 to $0.21 per diluted share. Non-GAAP net income is targeted in a range of $0.5 million to $6.0 million, or $0.01 to $0.06 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 96 million +/- and 99 million +/- average shares respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses and the step-up value of the acquired inventory and the purchase accounting value related to deferred service revenue.

[0001078271-14-000006:8k_2_02:28]
Financial Model Targets:

[0001078271-14-000006:8k_2_02:29]
The company is targeting a quarterly financial model of operating at a non-GAAP operating income of 10% +/-, by the end of fiscal 2015.  To achieve this goal, the company intends to focus on completing the integration of the two companies and growing its revenue with high performing and lower cost products and services.

[0001078271-14-000006:8k_2_02:30]
The schedules attached to this release are an integral part of the release.

[0001078271-14-000006:8k_2_02:31]
Conference Call:

[0001078271-14-000006:8k_2_02:32]
Extreme Networks will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the highlights of the second fiscal quarter 2014 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through February 14th, 2014.  The conference call may also be heard by dialing 1-877-303-9826 (international callers' dial 1-224-357 2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. "The encore recording can be accessed by dialing (855) 859-2056 /or international 1

[0001078271-14-000006:8k_2_02:33]
(404) 537-3406; Conference ID #: 52887320"

[0001078271-14-000006:8k_2_02:34]
About Extreme Networks:

[0001078271-14-000006:8k_2_02:35]
Extreme Networks, Inc. sets the new standard for superior customer experience by delivering network-powered innovation and best-in-class service and support. The company delivers high-performance switching and routing products for data center and core-to-edge networks, wired/wireless LAN access, and unified network management and control.  Our award-winning solutions include software-defined networking (SDN), cloud and high-density Wi-Fi, BYOD and enterprise mobility, identity access management and security.  Extreme Networks is headquartered in San Jose, CA and has more than 12,000 customers in over 80 countries.

[0001078271-14-000006:8k_2_02:36]
For more information, visit the company's website at http://www.extremenetworks.com.

[0001078271-14-000006:8k_2_02:37]
Non-GAAP Financial Measures:

[0001078271-14-000006:8k_2_02:38]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). To supplement its consolidated financial statements presented in accordance with GAAP, the Company is also providing with this press release non-GAAP net income/(loss) and non-GAAP operating income/(loss). In preparing non-GAAP information, the company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, share-based compensation, gain on sale of facilities and litigation settlements.  The company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the company and the company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the company's operating activities with the company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the company’s historical performance and in planning its future business activities. Please note that the company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the company presents should be considered in conjunction with, and not as a substitute for, the company’s financial information presented in accordance with GAAP.  The company has provided a non-GAAP reconciliation of the Condensed Consolidated Statement of Operations for the periods presented in this release, which are adjusted to exclude acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, share-based compensation expense and gain on sale of facilities for these periods. These measures should only be used to evaluate the company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-14-000006:8k_2_02:39]
Forward Looking Statements:

[0001078271-14-000006:8k_2_02:40]
Actual results, including with respect to the company’s financial targets and general business prospects, could differ materially due to a number of factors, including the risk that the company may not obtain sufficient orders to achieve targeted revenues for the company's products and services given both increasing price competition in key network switching equipment markets and the need to align the company’s cost structure to meet the company’s financial goals; the company’s effectiveness in controlling expenses, the risk that it or its distributors and other channel partners are not able to develop and expand customer bases and accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; the risk that its results will suffer if it is unable to balance fluctuations in customer demand and capacity; risks associated with the ramp-up of production of

[0001078271-14-000006:8k_2_02:41]
its new products and its entry into new business channels different from those in which it has historically operated; the risk that it may experience production delays that preclude it from shipping sufficient quantities to meet customer orders or that result in higher production costs and lower margins; ongoing uncertainty in global economic conditions, infrastructure development or customer demand that could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; its ability to complete development and commercialization of products under development, such as its pipeline of new network switches and related software; its ability to lower costs; risks resulting from the concentration of business among few customers, including the risk that customers may reduce or cancel orders or fail to honor purchase commitments; the rapid development of new technology and competing products that may impair demand or render its products obsolete; the potential lack of customer acceptance for new products; risks associated with ongoing litigation; a dependency on third parties for certain components and for the manufacturing of the company's products; our ability to receive the anticipated benefits of the acquisition of Enterasys; and the ability to meet and effectively manage the Company’s debt obligations. More information about potential factors that could affect the company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission. Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-14-000006:8k_2_02:42]
EXTREME NETWORKS, INC.

[0001078271-14-000006:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-14-000006:8k_2_02:44]
(In thousands, except share and per share amounts)

[0001078271-14-000006:8k_2_02:45]
(Unaudited)

[0001078271-14-000006:8k_2_02:46]
|  | December 31, 2013 |  | June 30, 2013 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 68,304 |  |  | $ | 95,803 |  |
| Short-term investments | 43,713 |  |  | 43,034 |  |
| Accounts receivable, net of allowances of $1,627 at December 31, 2013 and $1,252 at June 30, 2013 | 94,337 |  |  | 47,642 |  |
| Inventories | 62,935 |  |  | 16,167 |  |
| Deferred income taxes | 863 |  |  | 386 |  |
| Prepaid expenses and other current assets | 15,273 |  |  | 5,749 |  |
| Total current assets | 285,425 |  |  | 208,781 |  |
| Property and equipment, net | 49,416 |  |  | 23,644 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Intangible assets | 109,146 |  |  | 4,243 |  |
| Goodwill | 57,922 |  |  | — |  |
| Other assets, net | 15,546 |  |  | 7,980 |  |
| Total assets | $ | 517,455 |  |  | $ | 311,424 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 4,063 |  |  | $ | — |  |
| Accounts payable | 54,422 |  |  | 27,163 |  |
| Accrued compensation and benefits | 26,557 |  |  | 13,503 |  |
| Restructuring liabilities | 709 |  |  | 1,466 |  |
| Accrued warranty | 4,618 |  |  | 3,296 |  |
| Deferred revenue, net | 71,435 |  |  | 33,184 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 22,184 |  |  | 17,388 |  |
| Other accrued liabilities | 25,701 |  |  | 16,502 |  |
| Total current liabilities | 209,689 |  |  | 112,502 |  |
| Deferred revenue, less current portion | 18,335 |  |  | 8,270 |  |
| Long-term debt, less current portion | 95,125 |  |  | — |  |
| Other long-term liabilities | 9,913 |  |  | 1,507 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 184,393 |  |  | 189,145 |  |
| Total liabilities and stockholders’ equity | $ | 517,455 |  |  | $ | 311,424 |  |

[0001078271-14-000006:8k_2_02:47]
EXTREME NETWORKS, INC.

[0001078271-14-000006:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000006:8k_2_02:49]
(In thousands, except per share amounts)

[0001078271-14-000006:8k_2_02:50]
(Unaudited)

[0001078271-14-000006:8k_2_02:51]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 119,065 |  |  | $ | 60,259 |  |  | $ | 180,109 |  |  | $ | 121,378 |  |
| Service | 27,518 |  |  | 15,292 |  |  | 42,389 |  |  | 30,300 |  |
| Total net revenues | 146,583 |  |  | 75,551 |  |  | 222,498 |  |  | 151,678 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 66,893 |  |  | 29,377 |  |  | 94,409 |  |  | 59,853 |  |
| Service | 9,845 |  |  | 5,435 |  |  | 14,538 |  |  | 11,111 |  |
| Total cost of revenues | 76,738 |  |  | 34,812 |  |  | 108,947 |  |  | 70,964 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 52,172 |  |  | 30,882 |  |  | 85,700 |  |  | 61,525 |  |
| Service | 17,673 |  |  | 9,857 |  |  | 27,851 |  |  | 19,189 |  |
| Total gross profit | 69,845 |  |  | 40,739 |  |  | 113,551 |  |  | 80,714 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18,896 |  |  | 11,007 |  |  | 28,832 |  |  | 21,573 |  |
| Sales and marketing | 40,636 |  |  | 22,093 |  |  | 63,330 |  |  | 44,120 |  |
| General and administrative | 11,189 |  |  | 6,644 |  |  | 18,125 |  |  | 12,003 |  |
| Acquisition and integration costs | 8,688 |  |  | — |  |  | 12,382 |  |  | — |  |
| Restructuring charge, net of reversals | 430 |  |  | 5,176 |  |  | 505 |  |  | 5,167 |  |
| Amortization of intangibles | 3,778 |  |  | — |  |  | 3,778 |  |  | — |  |
| Litigation settlement | — |  |  | (421 | ) |  | — |  |  | (421 | ) |
| Gain on sale of facilities | — |  |  | — |  |  | — |  |  | (11,539 | ) |
| Total operating expenses | 83,617 |  |  | 44,499 |  |  | 126,952 |  |  | 70,903 |  |
| Operating (loss) income | (13,772 | ) |  | (3,760 | ) |  | (13,401 | ) |  | 9,811 |  |
| Interest income | 172 |  |  | 261 |  |  | 447 |  |  | 531 |  |
| Interest expense | (524 | ) |  | (1 | ) |  | (524 | ) |  | (1 | ) |
| Other expense, net | (937 | ) |  | (300 | ) |  | (1,192 | ) |  | (649 | ) |
| (Loss) income before income taxes | (15,061 | ) |  | (3,800 | ) |  | (14,670 | ) |  | 9,692 |  |
| Provision for income taxes | 925 |  |  | 406 |  |  | 1,352 |  |  | 983 |  |
| Net (loss) income | $ | (15,986 | ) |  | $ | (4,206 | ) |  | $ | (16,022 | ) |  | $ | 8,709 |  |
| Basic and diluted net income per share: |  |  |  |  |  |  |  |
| Net (loss) income per share - basic | $ | (0.17 | ) |  | $ | (0.04 | ) |  | $ | (0.17 | ) |  | $ | 0.09 |  |
| Net (loss) income per share - diluted | $ | (0.17 | ) |  | $ | (0.04 | ) |  | $ | (0.17 | ) |  | $ | 0.09 |  |
| Shares used in per share calculation - basic | 95,216 |  |  | 94,501 |  |  | 94,639 |  |  | 94,619 |  |
| Shares used in per share calculation - diluted | 95,216 |  |  | 94,501 |  |  | 94,639 |  |  | 95,514 |  |

[0001078271-14-000006:8k_2_02:52]
EXTREME NETWORKS, INC.

[0001078271-14-000006:8k_2_02:53]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-14-000006:8k_2_02:54]
(In thousands)

[0001078271-14-000006:8k_2_02:55]
(Unaudited)

[0001078271-14-000006:8k_2_02:56]
|  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |
| Net cash (used in) provided by operating activities | $ | (4,869 | ) |  | $ | 8,077 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (12,562 | ) |  | (3,026 | ) |
| Acquisition, net of cash acquired | (180,000 | ) |  | — |  |
| Purchases of investments | (9,045 | ) |  | (25,886 | ) |
| Proceeds from maturities of investments and marketable securities | 20,062 |  |  | 9,322 |  |
| Proceeds from sales of investments and marketable securities | 54,578 |  |  | 8,447 |  |
| Purchases of intangible assets | — |  |  | (335 | ) |
| Proceeds from sales of facilities | — |  |  | 42,659 |  |
| Net cash (used in) provided by investing activities | (126,967 | ) |  | 31,181 |  |
| Cash flows from financing activities: |  |  |  |
| Draw on Revolving Facility | 35,000 |  |  | — |  |
| Issuance of Term Loan | 65,000 |  |  | — |  |
| Repayment of debt | (813 | ) |  | — |  |
| Proceeds from issuance of common stock | 4,803 |  |  | 1,614 |  |
| Repurchase of common stock | — |  |  | (6,171 | ) |
| Net cash provided by (used in) financing activities | 103,990 |  |  | (4,557 | ) |
| Foreign currency effect on cash | 347 |  |  | 469 |  |
| Net (decrease) increase in cash and cash equivalents | (27,499 | ) |  | 35,170 |  |
| Cash and cash equivalents at beginning of period | 95,803 |  |  | 54,596 |  |
| Cash and cash equivalents at end of period | $ | 68,304 |  |  | $ | 89,766 |  |

[0001078271-14-000006:8k_2_02:57]
Extreme Networks, Inc.

[0001078271-14-000006:8k_2_02:58]
Non-GAAP Measures of Financial Performance

[0001078271-14-000006:8k_2_02:59]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-14-000006:8k_2_02:60]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring expenses and gains related to the sale of the Santa Clara campus.

[0001078271-14-000006:8k_2_02:61]
Non-GAAP measures presented in this press release are not in accordance with or an alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-14-000006:8k_2_02:62]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-14-000006:8k_2_02:63]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring expenses and gains related to the sale of the Santa Clara campus.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-14-000006:8k_2_02:64]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-14-000006:8k_2_02:65]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-14-000006:8k_2_02:66]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-14-000006:8k_2_02:67]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-14-000006:8k_2_02:68]
Purchase accounting adjustments relating to inventory and deferred revenue.  Purchase accounting adjustments consists of adjustments to the carrying value of deferred revenue and the step up of the carrying value for finished goods inventory.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.   The carrying value of the finished goods inventories acquired was adjusted to reflect only a selling profit margin that a market participant would incur to fulfill an order.  However, we have excluded the step up adjustment since we believe it is not reflective of the normal profit margin we expect on similar types of transactions with 3rd party customers.

[0001078271-14-000006:8k_2_02:69]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-14-000006:8k_2_02:70]
Gains related to the sale of facilities.  The one-time net gain related to the sale of the Santa Clara campus consists of the gross proceeds of the sale less the expenses directly related to the sale such as commissions, closing costs and legal fees.  Extreme Networks excludes this gain because it is a one-time event and does not believe that the gain is reflective of ongoing operations.

[0001078271-14-000006:8k_2_02:71]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the Company's cash balance for the period.

[0001078271-14-000006:8k_2_02:72]
EXTREME NETWORKS, INC.

[0001078271-14-000006:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000006:8k_2_02:74]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-14-000006:8k_2_02:75]
(In thousands, except per share amounts)

[0001078271-14-000006:8k_2_02:76]
(Unaudited)

[0001078271-14-000006:8k_2_02:77]
| Non-GAAP Revenue | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Revenue - GAAP Basis | $ | 146,583 |  |  | $ | 75,551 |  |  | $ | 222,498 |  |  | $ | 151,678 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Purchase accounting adjustment | $ | 1,764 |  |  | $ | — |  |  | $ | 1,764 |  |  | $ | — |  |
| Revenue - Non-GAAP Basis | $ | 148,347 |  |  | $ | 75,551 |  |  | $ | 224,262 |  |  | $ | 151,678 |  |
| Non-GAAP Gross Margin | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Gross profit - GAAP Basis | $ | 69,845 |  |  | $ | 40,739 |  |  | $ | 113,551 |  |  | $ | 80,714 |  |
| Gross margin - GAAP Basis percentage | 47.6 | % |  | 53.9 | % |  | 51.0 | % |  | 53.2 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 198 |  |  | $ | 206 |  |  | $ | 502 |  |  | $ | 538 |  |
| Purchase accounting adjustments | $ | 11,000 |  |  | $ | — |  |  | $ | 11,000 |  |  | $ | — |  |
| Amortization of intangibles | $ | 2,694 |  |  | $ | — |  |  | $ | 2,694 |  |  | $ | — |  |
| Gross profit - Non-GAAP Basis | $ | 83,737 |  |  | $ | 40,945 |  |  | $ | 127,748 |  |  | $ | 81,252 |  |
| Gross margin - Non-GAAP Basis percentage | 56.4 | % |  | 54.2 | % |  | 57.0 | % |  | 53.6 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| GAAP operating income | $ | (13,772 | ) |  | $ | (3,760 | ) |  | $ | (13,401 | ) |  | $ | 9,811 |  |
| GAAP operating income percentage | (9.4 | )% |  | (5.0 | )% |  | (6.0 | )% |  | 6.5 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 3,458 |  |  | $ | 1,616 |  |  | $ | 5,033 |  |  | $ | 3,784 |  |
| Acquisition and integration costs | $ | 8,688 |  |  | $ | — |  |  | $ | 12,382 |  |  | $ | — |  |
| Restructuring charge, net of reversal | $ | 430 |  |  | $ | 5,176 |  |  | $ | 505 |  |  | $ | 5,167 |  |
| Amortization of intangibles | $ | 6,472 |  |  | $ | — |  |  | $ | 6,472 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 11,000 |  |  | $ | — |  |  | $ | 11,000 |  |  | $ | — |  |
| Litigation settlement | $ | — |  |  | $ | (421 | ) |  | $ | — |  |  | $ | (421 | ) |
| Gain of sale of facilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |
| Total adjustments to GAAP operating income | $ | 30,048 |  |  | $ | 6,371 |  |  | $ | 35,392 |  |  | $ | (3,009 | ) |
| Non-GAAP operating income | $ | 16,276 |  |  | $ | 2,611 |  |  | $ | 21,991 |  |  | $ | 6,802 |  |
| Non-GAAP operating income percentage | 11.0 | % |  | 3.5 | % |  | 9.8 | % |  | 4.5 | % |
| Non-GAAP Net Income | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |

[0001078271-14-000006:8k_2_02:78]
| GAAP net income | $ | (15,986 | ) |  | $ | (4,206 | ) |  | $ | (16,022 | ) |  | $ | 8,709 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 3,458 |  |  | $ | 1,616 |  |  | $ | 5,033 |  |  | $ | 3,784 |  |
| Acquisition and integration costs | $ | 8,688 |  |  | $ | — |  |  | $ | 12,382 |  |  | $ | — |  |
| Restructuring charge, net of reversal | $ | 430 |  |  | $ | 5,176 |  |  | $ | 505 |  |  | $ | 5,167 |  |
| Amortization of intangibles | $ | 6,472 |  |  | $ | — |  |  | $ | 6,472 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 11,000 |  |  | $ | — |  |  | $ | 11,000 |  |  | $ | — |  |
| Litigation settlement | $ | — |  |  | $ | (421 | ) |  | $ | — |  |  | $ | (421 | ) |
| Gain of sale of facilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |
| Currency loss from closing of a foreign subsidiary | $ | — |  |  | $ | 616 |  |  | $ | — |  |  | $ | 465 |  |
| Total adjustments to GAAP net income | $ | 30,048 |  |  | $ | 6,987 |  |  | $ | 35,392 |  |  | $ | (2,544 | ) |
| Non-GAAP net income | $ | 14,062 |  |  | $ | 2,781 |  |  | $ | 19,370 |  |  | $ | 6,165 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.14 |  |  | $ | 0.03 |  |  | $ | 0.20 |  |  | $ | 0.06 |  |
| Shares used in diluted net income per share calculation | 98,352 |  |  | 94,501 |  |  | 97,023 |  |  | 95,514 |  |
| Free Cash Flow | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Cash flow used in operations | $ | (6,794 | ) |  | $ | 1,025 |  |  | $ | (4,869 | ) |  | $ | 8,077 |  |
| Add: PP&E CapEx spending | (2,754 | ) |  | (1,464 | ) |  | (12,562 | ) |  | 3,026 |  |
| Total free cash flow | $ | (9,548 | ) |  | $ | (439 | ) |  | $ | (17,431 | ) |  | $ | 11,103 |  |
