# EXTR notes — 0001078271-14-000008


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-14-000008:notes:1]
[same as prior period, unchanged from 0001078271-13-000062:notes:1]

[0001078271-14-000008:notes:2]
[same as prior period, unchanged from 0001078271-13-000062:notes:2]

[0001078271-14-000008:notes:3]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| December 31, 2013 |  |  |  |  |  |  |  |
| Money market funds | $ | 17,909 |  |  | $ | 17,909 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 43,600 |  |  | 43,713 |  |  | 113 |  |  | — |  |
|  | $ | 61,509 |  |  | $ | 61,622 |  |  | $ | 113 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 17,909 |  |  | $ | 17,909 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 43,600 |  |  | 43,713 |  |  | 113 |  |  | — |  |
|  | $ | 61,509 |  |  | $ | 61,622 |  |  | $ | 113 |  |  | $ | — |  |
| June 30, 2013 |  |  |  |  |  |  |  |
| Money market funds | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 110,078 |  |  | 109,810 |  |  | 126 |  |  | (394 | ) |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 42,994 |  |  | 43,034 |  |  | 44 |  |  | (4 | ) |
| Marketable securities | 67,084 |  |  | 66,776 |  |  | 82 |  |  | (390 | ) |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |

[0001078271-14-000008:notes:4]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at December 31, 2013, by contractual maturity, were as follows (in thousands):

[0001078271-14-000008:notes:5]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 43,600 |  |  | $ | 43,713 |  |
| Total investments in available for sale debt securities | $ | 43,600 |  |  | $ | 43,713 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001078271-14-000008:notes:6]
The following table summarizes the pro forma financial information (in thousands, except per share amounts):

[0001078271-14-000008:notes:7]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Net revenues |  | $ | 159,944 |  |  | $ | 158,258 |  |  | $ | 321,837 |  |  | $ | 327,599 |  |
| Net loss |  | $ | (55,090 | ) |  | $ | (15,196 | ) |  | $ | (51,682 | ) |  | $ | (14,833 | ) |
| Net loss per share – basic and diluted |  | $ | (0.57 | ) |  | $ | (0.16 | ) |  | $ | (0.54 | ) |  | $ | (0.16 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001078271-14-000008:notes:8]
Business combinations

[0001078271-14-000008:notes:9]
On October 31, 2013 (the “Acquisition Date”), the Company completed the acquisition of Enterasys, a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired.  The purchase price consideration is provisional as it is still pending post close adjustments as defined in the Stock Purchase Agreement (the "Agreement") signed by the Company and Enterprise Networks Holdings, Inc. on September 12, 2013.  The Company also assumed outstanding options and restricted stock units of Enterasys at the Acquisition Date, all of which were unvested.

[0001078271-14-000008:notes:10]
The acquisition has been accounted for using the acquisition method of accounting.   The provisional purchase price has been allocated on a preliminary basis to tangible and intangible assets acquired and liabilities assumed.  The final purchase price allocation is pending the finalization of valuations, which may result in an adjustment to the preliminary purchase price allocation. Also, additional information which existed as of the acquisition date but was unknown to the Company at that time, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date, and may result in a change in the purchase price allocation.  While management believes that its preliminary estimates and assumptions underlying the valuations are reasonable, different estimates and assumptions could result in different valuations assigned to the individual assets acquired and liabilities assumed, and the resulting amount of goodwill.

[0001078271-14-000008:notes:11]
Also, on October 31, 2013, the Company entered into a $125 million senior secured credit facilities agreement consisting of a $65 million term loan facility (“Term Loan”) and a revolving credit facility of $60 million (“Revolving Facility”).  Both facilities mature on October 31, 2018.  The Company drew $35 million of the $60 million Revolving Facility and used the proceeds from the Term Loan to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys.

[0001078271-14-000008:notes:12]
The estimated purchase price has been allocated to Enterasys’ tangible and identifiable intangible assets acquired and liabilities assumed on a preliminary basis as follows (in thousands):

[0001078271-14-000008:notes:13]
|  |  | Amount |  |
| Cash |  | $ | 4,969 |  |
| Receivables |  | 25,699 |  |
| Inventory |  | 33,662 |  |
| Other current assets |  | 8,888 |  |
| Property and equipment |  | 23,122 |  |
| Identifiable intangible assets |  | 108,900 |  |
| In-process research and development |  | 3,000 |  |
| Deferred tax assets |  | 9 |  |
| Other assets |  | 7,343 |  |
| Goodwill |  | 57,922 |  |
| Current liabilities |  | (75,394 | ) |
| Other long term liabilities |  | (13,151 | ) |
| Total purchase price allocation |  | $ | 184,969 |  |
| Less: Cash acquired from acquisition |  | (4,969 | ) |
| Total purchase price consideration, net of cash acquired |  | $ | 180,000 |  |

[0001078271-14-000008:notes:14]
The estimated purchase price has been allocated based on the preliminary estimates of the fair value of assets acquired and liabilities assumed as of the acquisition date.  The Company also continues to analyze the tax implications of the acquisition of Enterasys which may ultimately impact the overall level of goodwill associated with the acquisition.

[0001078271-14-000008:notes:15]
The following table presents details of the preliminary identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001078271-14-000008:notes:16]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |
| Developed technology |  | 3 |  | $ | 45,000 |  |
| Customer relationships |  | 3 |  | 37,000 |  |
| Maintenance contracts |  | 5 |  | 17,000 |  |
| Trademarks |  | 3 |  | 2,500 |  |
| Order backlog |  | 1.5 |  | 7,400 |  |
| Total identifiable intangible assets |  |  |  | $ | 108,900 |  |

[0001078271-14-000008:notes:17]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the condensed consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Enterasys.  The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001078271-14-000008:notes:18]
The Company also has an indefinite lived asset of $3.0 million which represents the fair value of in-process research and development activities.  Once the related research and development efforts are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.

[0001078271-14-000008:notes:19]
The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013. For the six months ended December 31, 2013, $70.1 million of revenue and $1.2 million of operating income from Enterasys is included in the consolidated statement of operations.  The Company incurred $5.8 million acquisition-related expenses of which $2.1 million was incurred in the three months ended December 31, 2013.  Such acquisition-related costs are included in "Acquisition-integration expenses" on the condensed consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees payable to financial and legal advisors.

[0001078271-14-000008:notes:20]
Pro forma financial information

[0001078271-14-000008:notes:21]
The following unaudited pro forma results of operations are presented as though the acquisition of Enterasys had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, stock-based compensation for the options and restricted stock units assumed, depreciation and amortization on acquired property and equipment and intangibles, interest income and expense and related tax effects. The pro forma results of operations do not reflect the impact of non-recurring charges that have resulted from or in connection with the acquisition including acquisition and integration expenses incurred in connection with the acquisition.  The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the earliest period presented, nor are they necessarily indicative of future operating results.

[0001078271-14-000008:notes:22]
The unaudited pro forma financial information for the three months ended December 31, 2013 combines the results for the Extreme for the three months ended December 31, 2013, which include the results of Enterasys subsequent to the acquisition date, and the historical results for Enterasys for the month ended October 31, 2013. The unaudited pro forma financial information for the six months ended December 31, 2013 combines the results for Extreme for the six months ended December 31, 2013, which include the results of Enterasys subsequent to the acquisition date, and the historical results for Enterasys for the three months ended September 30, 2013 and the month ended October 31, 2013. The unaudited pro forma financial information for the three and six months ended December 31, 2012 combines the historical results for Extreme for those periods, with the historical results for Enterasys for the three and six months ended December 31, 2012. The following table summarizes the pro forma financial information (in thousands, except per share amounts):


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-14-000008:notes:23]
Commitments and Contingencies

[0001078271-14-000008:notes:24]
Purchase Commitments

[0001078271-14-000008:notes:25]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2013, the Company had non-cancelable commitments to purchase approximately $63.2 million of such inventory.

[0001078271-14-000008:notes:26]
Legal Proceedings

[0001078271-14-000008:notes:27]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-14-000008:notes:28]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-14-000008:notes:29]
Intellectual Property Litigation

[0001078271-14-000008:notes:30]
Relay IP Inc.

[0001078271-14-000008:notes:31]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775 (Extreme Case). Further on May 6, 2013 they also filed a similar suit against Enterasys in the same court, Civil Action case number 13-774.The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on both cases in July, 2013. The suit is one of approximately 40 nearly simultaneous suits filed against numerous networking equipment manufacturers, suppliers, operators, and users including Cisco Systems, Hewlett-Packard, Juniper Networks, Avaya, Extreme and Enterasys.  The Company denies the claims and intends to vigorously defend itself in both cases. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

[0001078271-14-000008:notes:32]
ReefEdge

[0001078271-14-000008:notes:33]
On September 17, 2012, ReefEdge filed suit against Enterasys in the United States District Court for the District of Delaware alleging certain of the company's products (wireless controllers and wireless access points), infringe three ReefEdge U.S. patents (6633761, 6975864, 7197308).  ReefEdge, a Non-Practicing Entity, seeks injunctive relief as well as monetary damages, cost, expenses and attorney fees, although there was no quantified amount sought.  Preliminary talks have taken place between the parties. Enterasys has filed its Answer to the claims and is awaiting a scheduling conference. Extreme assumed this litigation as part of the acquisition of Enterasys.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

[0001078271-14-000008:notes:34]
Indemnification Obligations

[0001078271-14-000008:notes:35]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of December 31, 2013, the Company had no outstanding indemnification claims.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-14-000008:notes:36]
The following table summarizes deferred revenue, net at December 31, 2013 and June 30, 2013, respectively (in thousands):

[0001078271-14-000008:notes:37]
|  | December 31, 2013 |  | June 30, 2013 |
| Deferred services | $ | 81,485 |  |  | $ | 38,003 |  |
| Deferred product and other revenue | 8,285 |  |  | 3,451 |  |
| Total deferred revenue | 89,770 |  |  | 41,454 |  |
| Less: current portion | 71,435 |  |  | 33,184 |  |
| Non-current deferred revenue, net | $ | 18,335 |  |  | $ | 8,270 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-14-000008:notes:38]
[same as prior period, unchanged from 0001078271-13-000062:notes:23]

[0001078271-14-000008:notes:39]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. At December 31, 2013, these forward foreign currency contracts had a notional principal amount of $6.7 million and a $0.1 million unrealized loss on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-14-000008:notes:40]
Foreign currency transaction gains and losses from operations were a $1.0 million loss and a $1.1 million loss for the three and six months ended December 31, 2013, respectively.  Foreign currency transaction gains and losses from operations were a $0.4 million gain and a $0.1 million gain for the three and six months ended December 31, 2012.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-14-000008:notes:41]
[same as prior period, unchanged from 0001078271-13-000062:notes:26]

[0001078271-14-000008:notes:42]
[same as prior period, unchanged from 0001078271-13-000062:notes:27]

[0001078271-14-000008:notes:43]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Cost of product revenue | $ | 198 |  |  | $ | 121 |  |  | $ | 300 |  |  | $ | 295 |  |
| Cost of service revenue | — |  |  | 85 |  |  | 40 |  |  | 244 |  |
| Research and development | 898 |  |  | 288 |  |  | 1,141 |  |  | 720 |  |
| Sales and marketing | 1,279 |  |  | 567 |  |  | 1,850 |  |  | 1,295 |  |
| General and administrative | 1,083 |  |  | 555 |  |  | 1,702 |  |  | 1,230 |  |
| Total share-based compensation expense | $ | 3,458 |  |  | $ | 1,616 |  |  | $ | 5,033 |  |  | $ | 3,784 |  |

[0001078271-14-000008:notes:44]
During the three and six months ended December 31, 2013 and 2012, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial. The income tax benefit for share-based compensation expense was immaterial in the three and six months ended December 31, 2013 and 2012.

[0001078271-14-000008:notes:45]
The weighted-average grant-date per share fair value of options granted during the three months ended December 31, 2013 and 2012 were $2.35 and $1.73, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended December 31, 2013 and 2012 were $1.35 and $0.91, respectively.

[0001078271-14-000008:notes:46]
The weighted-average grant-date per share fair value of options granted during the six months ended December 31, 2013 and 2012 were $2.33 and $1.81, respectively. The weighted-average estimated per share fair value of shares purchased under the ESPP during the six months ended December 31, 2013 and 2012 were $1.21 and $0.89, respectively.

[0001078271-14-000008:notes:47]
The following table summarizes stock option activity under all plans for the six months ended December 31, 2013:

[0001078271-14-000008:notes:48]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2013 | 9,145 |  |  | $ | 3.66 |  |  |  |  |  |
| Granted | 5,199 |  |  | $ | 5.14 |  |  |  |  |  |
| Exercised | (1,305 | ) |  | $ | 3.54 |  |  |  |  | $ | 2,356 |  |
| Cancelled | (975 | ) |  | $ | 4.83 |  |  |  |  |  |
| Options outstanding at December 31, 2013 | 12,064 |  |  | $ | 4.22 |  |  | 5.54 |  | $ | 33,338 |  |
| Exercisable at December 31, 2013 | 3,792 |  |  | $ | 3.78 |  |  | 3.50 |  | $ | 12,196 |  |
| Vested and expected to vest at December 31, 2013 | 10,996 |  |  | $ | 4.19 |  |  | 5.44 |  | $ | 30,710 |  |

[0001078271-14-000008:notes:49]
Included in the options granted above are 4.2 million options, assumed in connection with the acquisition of Enterasys on October 31, 2013, at an exercise price of $5.30.

[0001078271-14-000008:notes:50]
[same as prior period, unchanged from 0001078271-13-000062:notes:33]

[0001078271-14-000008:notes:51]
Stock awards may be granted under the 2013 Plan on terms approved by the Board of Directors. Stock awards generally provide for the issuance of restricted stock which vests over a fixed period.

[0001078271-14-000008:notes:52]
The following table summarizes stock award activity for the six months ended December 31, 2013:

[0001078271-14-000008:notes:53]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2013 | 2,686 |  |  | $ | 3.09 |  |  |  |
| Granted | 4,202 |  |  | $ | 5.54 |  |  |  |
| Vested | (613 | ) |  | $ | 3.49 |  |  | $ | 3,338 |  |
| Cancelled | (352 | ) |  | $ | 3.51 |  |  |  |
| Non-vested stock outstanding at December 31, 2013 | 5,923 |  |  | $ | 4.45 |  |  |  |

[0001078271-14-000008:notes:54]
Included in the restricted stock units granted above are 2.7 million restricted stock units assumed in connection with the acquisition of Enterasys on October 31, 2013, with a grant-date fair value of $5.30.

[0001078271-14-000008:notes:55]
Excluding the options assumed as part of the Enterasys acquisition, the fair value of each option award and share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of performance-based option awards, with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-14-000008:notes:56]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Expected life | 4 years |  |  | 4 years |  |  | 0.25 years |  |  | 0.25 years |  |  | 4 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.14 | % |  | 0.57 | % |  | 0.11 | % |  | 0.04 | % |  | 1.20 | % |  | 0.71 | % |  | 0.10 | % |  | 0.05 | % |
| Volatility | 55 | % |  | 63 | % |  | 47 | % |  | 50 | % |  | 56 | % |  | 64 | % |  | 41 | % |  | 59 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |

[0001078271-14-000008:notes:57]
[same as prior period, unchanged from 0001078271-13-000062:notes:39]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-14-000008:notes:58]
[same as prior period, unchanged from 0001078271-13-000062:notes:40]

[0001078271-14-000008:notes:59]
[same as prior period, unchanged from 0001078271-13-000062:notes:41]


## us-gaap:EarningsPerShareTextBlock

[0001078271-14-000008:notes:60]
Net (Loss) Income Per Share

[0001078271-14-000008:notes:61]
The following table presents the calculation of basic and diluted net (loss) income per share (in thousands, except per share data):

[0001078271-14-000008:notes:62]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Net (loss) income | $ | (15,986 | ) |  | $ | (4,206 | ) |  | $ | (16,022 | ) |  | $ | 8,709 |  |
| Weighted-average shares used in per share calculation – basic | 95,216 |  |  | 94,501 |  |  | 94,639 |  |  | 94,619 |  |
| Incremental shares using the treasury stock method: |  |  |  |  |  |  |  |
| Stock options | — |  |  | — |  |  | — |  |  | 418 |  |
| Restricted stock units | — |  |  | — |  |  | — |  |  | 370 |  |
| Employee Stock Purchase Plan | — |  |  | — |  |  | — |  |  | 107 |  |
| Weighted -average share used in per share calculation – diluted | 95,216 |  |  | 94,501 |  |  | 94,639 |  |  | 95,514 |  |
| Net (loss) income per share – basic | $ | (0.17 | ) |  | $ | (0.04 | ) |  | (0.17 | ) |  | 0.09 |  |
| Net (loss) income per share – diluted | $ | (0.17 | ) |  | $ | (0.04 | ) |  | (0.17 | ) |  | 0.09 |  |

[0001078271-14-000008:notes:63]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For the three months ended December 31, 2013 and 2012, the Company excluded 3.9 million and 7.3 million outstanding weighted average stock options and awards, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.  For the six months ended December 31, 2013 and 2012, the Company excluded 2.6 million and  7.0 million outstanding weighted average stock options and awards, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-14-000008:notes:64]
[same as prior period, unchanged from 0001078271-13-000062:notes:46]

[0001078271-14-000008:notes:65]
[same as prior period, unchanged from 0001078271-13-000062:notes:47]

[0001078271-14-000008:notes:66]
| December 31, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 17,909 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,909 |  |
| Corporate notes/bonds | — |  |  | 43,713 |  |  | — |  |  | 43,713 |  |
| Foreign currency forward contracts | — |  |  | 79 |  |  | — |  |  | 79 |  |
| Total | $ | 17,909 |  |  | $ | 43,792 |  |  | $ | — |  |  | $ | 61,701 |  |

[0001078271-14-000008:notes:67]
[same as prior period, unchanged from 0001078271-13-000062:notes:49]

[0001078271-14-000008:notes:68]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three and six months ended December 31, 2013 and 2012.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-14-000008:notes:69]
[same as prior period, unchanged from 0001078271-13-000062:notes:51]

[0001078271-14-000008:notes:70]
Long-lived assets include property and equipment, and service inventory.  Property and equipment assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets or asset groups. The Company reduces the carrying value of service inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-14-000008:notes:71]
[same as prior period, unchanged from 0001078271-13-000062:notes:53]

[0001078271-14-000008:notes:72]
For the three and six months ended December 31, 2013, the Company recorded an income tax provision of $0.9 million and $1.4 million, respectively.  For the three and six months ended December 31, 2012, the Company recorded an income tax provision of $0.4 million and $1.0 million, respectively.

[0001078271-14-000008:notes:73]
The income tax provisions for the three and six months ended December 31, 2013 and 2012 consisted primarily of taxes on the income of our foreign subsidiaries as well as U.S. state income taxes. The income tax provision for the three and six months ended December 31, 2013 also includes an expense related to a deferred tax liability for the amortization of goodwill recorded as a result of the acquisition of Enterasys.  The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and six months ended December 31, 2013 and 2012, and may not reflect the annual effective tax rate.

[0001078271-14-000008:notes:74]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as substantially all of the acquired Enterasys foreign entities’ deferred tax assets with the exception of certain foreign deferred tax assets.  No valuation allowance has been established against the non-U.S. deferred tax assets of the legacy Extreme Networks, Inc. foreign subsidiaries. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis. The Company's inconsistent earnings in recent periods, coupled with the Company's inability to forecast greater than one quarter in advance and the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions. This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001078271-14-000008:notes:75]
On October 31, 2013, the Company acquired all of the stock of Enterasys.  The acquisition included a US parent company as well as their wholly owned foreign subsidiaries.  The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has preliminarily estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  During the current period, the Company deducted $0.6 million of tax amortization expense related to capitalized goodwill.  As of December 31, 2013, the Company recorded a deferred tax liability of $0.2 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets.

[0001078271-14-000008:notes:76]
The Company had $10.9 million of unrecognized tax benefits as of December 31, 2013. The future impact of the unrecognized tax benefit of $10.9 million, if recognized, is as follows: approximately $0.3 million would impact the effective tax rate, and approximately $10.6 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.1 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-14-000008:notes:77]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Condensed Consolidated Statements of Operations and were immaterial for the three and six months ended December 31, 2013 and 2012. Accrued interest and penalties were $46,000 and $0.1 million as of December 31, 2013 and 2012, respectively.

[0001078271-14-000008:notes:78]
[same as prior period, unchanged from 0001078271-13-000062:notes:59]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-14-000008:notes:79]
[same as prior period, unchanged from 0001078271-13-000062:notes:62]

[0001078271-14-000008:notes:80]
[same as prior period, unchanged from 0001078271-13-000062:notes:63]

[0001078271-14-000008:notes:81]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income (loss) into earnings using the specific identification method.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-14-000008:notes:82]
Recently Issued Accounting Pronouncements

[0001078271-14-000008:notes:83]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013. The Company intends to adopt this standard prospectively in the first quarter of its fiscal year ending June 30, 2015. The Company does not believe this updated standard will have a material impact on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-14-000008:notes:84]
[same as prior period, unchanged from 0001078271-13-000062:notes:67]

[0001078271-14-000008:notes:85]
[same as prior period, unchanged from 0001078271-13-000062:notes:68]

[0001078271-14-000008:notes:86]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2013. The results of operations for the three and six months ended December 31, 2013 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.

[0001078271-14-000008:notes:87]
On October 31, 2013, the Company completed the acquisition of Enterasys Networks, Inc., a Delaware corporation ("Enterasys"), whereby Enterasys became a wholly-owned subsidiary of the Company (see Note 4: "Business Combinations" for further discussion).  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-14-000008:notes:88]
[same as prior period, unchanged from 0001078271-13-000062:notes:70]

[0001078271-14-000008:notes:89]
As part of the Company's on-going restructuring efforts, during the second quarter of fiscal year 2013, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. Restructuring expense was $0.4 million and $0.5 million in the three and six months ended December 31, 2013.  Restructuring expense was $5.2 million and $5.2 million in the three and six months ended December 31, 2012.

[0001078271-14-000008:notes:90]
The following table summarizes restructuring activities for the six months ended December 31, 2013:

[0001078271-14-000008:notes:91]
|  |  | Termination Benefits (1) |  | Contract Termination |  | Other Cost |  | Total |
| Balance at June 30, 2013 |  | $ | 1,217 |  |  | $ | — |  |  | $ | 249 |  |  | $ | 1,466 |  |
| Assumed from acquisition |  | — |  |  | 127 |  |  | — |  |  | 127 |  |
| Period charges |  | 110 |  |  | 628 |  |  | 83 |  |  | 821 |  |
| Period reversals |  | (309 | ) |  | (7 | ) |  | — |  |  | (316 | ) |
| Period payments |  | (950 | ) |  | (107 | ) |  | (332 | ) |  | (1,389 | ) |
| Restructuring liabilities at December 31, 2013 |  | $ | 68 |  |  | $ | 641 |  |  | $ | — |  |  | $ | 709 |  |

[0001078271-14-000008:notes:92]
[same as prior period, unchanged from 0001078271-13-000062:notes:74]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-14-000008:notes:93]
[same as prior period, unchanged from 0001078271-13-000062:notes:75]

[0001078271-14-000008:notes:94]
[same as prior period, unchanged from 0001078271-13-000062:notes:76]

[0001078271-14-000008:notes:95]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

[0001078271-14-000008:notes:96]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-14-000008:notes:97]
[same as prior period, unchanged from 0001078271-13-000062:notes:79]

[0001078271-14-000008:notes:98]
[same as prior period, unchanged from 0001078271-13-000062:notes:80]

[0001078271-14-000008:notes:99]
|  | December 31, 2013 |  | June 30, 2013 |
| Cash | $ | 50,395 |  |  | $ | 41,518 |  |
| Cash equivalents | $ | 17,909 |  |  | $ | 54,285 |  |
| Short-term investments | 43,713 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total available-for-sale | $ | 61,622 |  |  | $ | 164,095 |  |
| Total cash, cash equivalents and available for sale securities | $ | 112,017 |  |  | $ | 205,613 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-14-000008:notes:100]
The Company's debt is comprised of the following:

[0001078271-14-000008:notes:101]
|  |  | December 31, 2013 |
| Current portion of long-term debt |  |  |
| Term Loan |  | 4,063 |  |
| Current portion of long-term debt |  | 4,063 |  |
| Long-term debt, less current portion |  |  |
| Term Loan |  | 60,125 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt less current portion |  | 95,125 |  |
| Total debt |  | 99,188 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001078271-14-000008:notes:102]
The following tables present details of the Company’s intangible assets (in thousands):

[0001078271-14-000008:notes:103]
| December 31, 2013 |  | Weighted average remaining amortization period |  | Gross |  | Accumulated amortization |  | Net |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.7 years |  | $ | 45,000 |  |  | $ | 2,694 |  |  | $ | 42,306 |  |
| Customer relationships |  | 2.8 years |  | 37,000 |  |  | 2,056 |  |  | 34,944 |  |
| Maintenance contracts |  | 4.8 years |  | 17,000 |  |  | 567 |  |  | 16,433 |  |
| Trademarks |  | 2.8 years |  | 2,500 |  |  | 139 |  |  | 2,361 |  |
| Order backlog |  | 1.2 years |  | 7,400 |  |  | 1,017 |  |  | 6,383 |  |
| Patents |  | 6.2 years |  | 1,800 |  |  | 918 |  |  | 882 |  |
| License agreements |  | 10.7 years |  | 10,447 |  |  | 7,801 |  |  | 2,646 |  |
| Other intangibles |  | 1.7 years |  | 659 |  |  | 468 |  |  | 191 |  |
| Total intangible assets with finite lives |  |  |  | 121,806 |  |  | 15,660 |  |  | 106,146 |  |
| In-process research and development, with indefinite life |  |  |  | 3,000 |  |  | — |  |  | 3,000 |  |
| Total |  |  |  | $ | 124,806 |  |  | $ | 15,660 |  |  | $ | 109,146 |  |

[0001078271-14-000008:notes:104]
| June 30, 2013 |  | Weighted average remaining amortization period |  | Gross |  | Accumulated amortization |  | Net |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |
| Patents |  | 6.7 years |  | $ | 1,800 |  |  | $ | 846 |  |  | $ | 954 |  |
| License agreements |  | 10.3 years |  | 10,447 |  |  | 7,407 |  |  | 3,040 |  |
| Other intangibles |  | 2.3 years |  | 659 |  |  | 410 |  |  | 249 |  |
| Total intangible assets with finite lives |  |  |  | 12,906 |  |  | 8,663 |  |  | 4,243 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-14-000008:notes:105]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2013 and 2012:

[0001078271-14-000008:notes:106]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Balance beginning of period | $ | 3,440 |  |  | $ | 2,971 |  |  | $ | 3,296 |  |  | $ | 2,871 |  |
| Assumed from acquisition | 3,732 |  |  | — |  |  | 3,732 |  |  | — |  |
| New warranties issued | 1,654 |  |  | 1,942 |  |  | 2,958 |  |  | 3,504 |  |
| Warranty expenditures | (1,347 | ) |  | (1,942 | ) |  | (2,507 | ) |  | (3,404 | ) |
| Balance end of period | $ | 7,479 |  |  | $ | 2,971 |  |  | $ | 7,479 |  |  | $ | 2,971 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-14-000008:notes:107]
[same as prior period, unchanged from 0001078271-13-000062:notes:84]

[0001078271-14-000008:notes:108]
|  | Three Months Ended |  | Six Months Ended |
| Net Revenues: | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 56,292 |  |  | $ | 22,731 |  |  | $ | 81,681 |  |  | $ | 47,935 |  |
| Other | 13,913 |  |  | 10,767 |  |  | 20,214 |  |  | 20,545 |  |
| Total Americas | 70,205 |  |  | 33,498 |  |  | 101,895 |  |  | 68,480 |  |
| EMEA | 61,292 |  |  | 28,700 |  |  | 92,133 |  |  | 57,220 |  |
| APAC | 15,086 |  |  | 13,353 |  |  | 28,470 |  |  | 25,978 |  |
| Total net revenues | $ | 146,583 |  |  | $ | 75,551 |  |  | $ | 222,498 |  |  | $ | 151,678 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001078271-14-000008:notes:109]
The estimated future amortization expense for finite lived intangibles to be recorded for each of the next five years is as follows (in thousands):

[0001078271-14-000008:notes:110]
| Fiscal year |  | Amount |
| 2014 (remaining 6 months) |  | $ | 19,881 |  |
| 2015 |  | 36,248 |  |
| 2016 |  | 31,287 |  |
| 2017 |  | 12,379 |  |
| 2018 |  | 3,682 |  |
| Thereafter |  | 2,669 |  |
| Total |  | $ | 106,146 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-14-000008:notes:111]
[same as prior period, unchanged from 0001078271-13-000062:notes:86]

[0001078271-14-000008:notes:112]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Westcon Group Inc. |  | 10 | % |  | 14 | % |  | 12 | % |  | 15 | % |
| Scansource, Inc. |  | * |  |  | 12 | % |  | * |  |  | 12 | % |
| Tech Data |  | * |  |  | 12 | % |  | * |  |  | 11 | % |
| Ericsson AB |  | * |  |  | 10 | % |  | * |  |  | 10 | % |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-14-000008:notes:113]
[same as prior period, unchanged from 0001078271-13-000062:notes:88]

[0001078271-14-000008:notes:114]
[same as prior period, unchanged from 0001078271-13-000062:notes:89]

[0001078271-14-000008:notes:115]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, and Australia.

[0001078271-14-000008:notes:116]
Substantially all of the Company’s assets were attributable to North America operations at December 31, 2013 and June 30, 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-14-000008:notes:117]
[same as prior period, unchanged from 0001078271-13-000062:notes:92]

[0001078271-14-000008:notes:118]
Business Combinations

[0001078271-14-000008:notes:119]
The Company applies the acquisition method of accounting for business combinations, including its acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.

[0001078271-14-000008:notes:120]
Goodwill

[0001078271-14-000008:notes:121]
Goodwill is assessed for impairment annually or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. Goodwill is tested for impairment at the reporting unit level at the beginning of fourth quarter of the fiscal year and at least annually thereafter. To test goodwill for impairment, the Company first performs a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, the Company will then perform the two-step goodwill impairment test. Otherwise, the two-step goodwill impairment test is not required.  Under the two-step goodwill impairment test, the Company would, in the first step, compare the estimated fair value of a reporting unit to its carrying value.  If the fair value of the reporting unit exceeds the carrying value, no impairment loss would be recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which the Company determines the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

[0001078271-14-000008:notes:122]
Intangible Assets

[0001078271-14-000008:notes:123]
Intangibles assets are reviewed for impairment annually or more frequently when an event occurs or circumstances change that would more likely than not reduce the fair value of the asset below its carrying value.  License agreements are presented at cost, net of accumulated amortization and are amortized over their estimated useful life.  The in-process research and development efforts will be monitored regularly for completion and once they are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.  The Company determines that our in-process research and development project is complete when all material research and development costs have been incurred and no significant risks remain. The Company  reviews the carrying value of indefinite-lived intangible assets for impairment at least annually during the last quarter of our fiscal year, or more frequently if we believe indicators of impairment exist.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-14-000008:notes:124]
[same as prior period, unchanged from 0001078271-13-000062:notes:98]

[0001078271-14-000008:notes:125]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income (loss) into earnings using the specific identification method. As of December 31, 2013, five out of twenty-five investment securities had unrealized losses.  Such unrealized losses in total were immaterial for the three and six months ended December 31, 2013.  The Company recorded an other than temporary impairment loss of $148,000 during the six months ended December 31, 2013.

[0001078271-14-000008:notes:126]
[same as prior period, unchanged from 0001078271-13-000062:notes:99]

[0001078271-14-000008:notes:127]
Goodwill and Intangibles

[0001078271-14-000008:notes:128]
As part of the acquisition of Enterasys, the Company assumed $57.9 million in goodwill which has been allocated to the Company's only reportable segment, the development and marketing of network infrastructure equipment.

[0001078271-14-000008:notes:129]
Amortization expense was $6.7 million and $7.0 million respectively, for the three and six months ended December 31, 2013.  Amortization expense was $0.4 million and $0.8 million respectively, for the three and six months ended December 31, 2012. Of the total amount recognized, $2.9 million and $3.2 million for the three and six months ended December 31, 2013 and $0.4 million and $0.8 million respectively for the three and six months ended December 31, 2012, is included in "Cost of revenues for products" on the condensed consolidated statements of operations, while the remainder of the amortization expense is included in "Amortization of intangibles" on the condensed consolidated statement of operations.  The amortization expense for developed technology, patents, license agreements and other intangibles is recognized in "Cost of revenues for products" on the condensed consolidated statement of operations.  The estimated future amortization expense for finite lived intangibles to be recorded for each of the next five years is as follows (in thousands):

[0001078271-14-000008:notes:130]
[same as prior period, unchanged from 0001078271-13-000062:notes:100]

[0001078271-14-000008:notes:131]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net at December 31, 2013 and June 30, 2013, respectively (in thousands):

[0001078271-14-000008:notes:132]
[same as prior period, unchanged from 0001078271-13-000062:notes:101]

[0001078271-14-000008:notes:133]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Balance beginning of period | $ | 37,091 |  |  | $ | 35,661 |  |  | $ | 38,003 |  |  | $ | 37,461 |  |
| Assumed from acquisition | 35,879 |  |  | — |  |  | 35,879 |  |  | — |  |
| New support arrangements | 33,146 |  |  | 14,776 |  |  | 46,489 |  |  | 27,313 |  |
| Recognition of support revenue | (24,631 | ) |  | (14,640 | ) |  | (38,886 | ) |  | (28,977 | ) |
| Balance end of period | 81,485 |  |  | 35,797 |  |  | 81,485 |  |  | 35,797 |  |
| Less: current portion | 63,150 |  |  | 27,664 |  |  | 63,150 |  |  | 27,664 |  |
| Non-current deferred revenue | $ | 18,335 |  |  | $ | 8,133 |  |  | $ | 18,335 |  |  | $ | 8,133 |  |

[0001078271-14-000008:notes:134]
[same as prior period, unchanged from 0001078271-13-000062:notes:103]

[0001078271-14-000008:notes:135]
[same as prior period, unchanged from 0001078271-13-000062:notes:104]

[0001078271-14-000008:notes:136]
[same as prior period, unchanged from 0001078271-13-000062:notes:105]

[0001078271-14-000008:notes:137]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at December 31, 2013 and June 30, 2013, respectively (in thousands):

[0001078271-14-000008:notes:138]
|  | December 31, 2013 |  | June 30, 2013 |
| Deferred distributors revenue | $ | 28,943 |  |  | $ | 22,411 |  |
| Deferred cost of sales to distributors | (6,759 | ) |  | (5,023 | ) |
| Deferred distributors revenue, net of cost of sales to distributors | $ | 22,184 |  |  | $ | 17,388 |  |

[0001078271-14-000008:notes:139]
Debt

[0001078271-14-000008:notes:140]
On October 31, 2013, the Company entered into a Credit Agreement (the “Credit Agreement”) which provides for a $60 million five-year revolving credit facility (the “Revolving Facility”) and a $65 million five-year term loan (the “Term Loan”) and together with the Revolving Facility (the “Senior Secured Credit Facilities”).  The proceeds from the Term Loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The company also drew $35 million of the Revolving Facility to pay a portion of the purchase price.

[0001078271-14-000008:notes:141]
Borrowings under the Senior Secured Credit Facilities bear interest, at the Company's election, at a rate per annum equal to an agreed to applicable margin plus (a) the higher of (x) the prime rate in effect on such day or (y) the federal funds effective rate in effect on such day plus 0.50%, or (b) an adjusted Libor rate. In addition, the Company is required to pay a commitment fee of between 0.375% and 0.50% quarterly (currently 0.50%) on the unused portion of the Revolving Facility, also based on the Company’s Consolidated Leverage Ratio.  Principal installments are payable on the Term Loan in varying percentages quarterly starting December 31, 2013 and to the extent not previously paid, all outstanding balance to be paid at maturity. If not repaid before maturity, he draws on the Revolving Facility shall be repaid on the maturity date. The Senior Secured Credit Facilities are secured by substantially all of the Company’s assets and are jointly and severally guaranteed by the Company and certain of its subsidiaries.

[0001078271-14-000008:notes:142]
The Credit Agreement contains financial covenants that require the Company to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other covenants and restrictions that limit the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets, etc.  These covenants, which are described more fully in the Credit Agreement, to which reference is made for a complete statement of the covenants, are subject to certain exceptions. The Company currently is in compliance with its covenants.

[0001078271-14-000008:notes:143]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by the Company is false or misleading in any material respect, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company.  The amounts outstanding under the Senior Secured Credit Facilities may be accelerated upon certain events of default.

[0001078271-14-000008:notes:144]
[same as prior period, unchanged from 0001078271-13-000062:notes:108]

[0001078271-14-000008:notes:145]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2013 and 2012:

[0001078271-14-000008:notes:146]
As of December 31, 2013, of the $7.5 million in warranty liability, $4.6 million was classified as current and the remainder is included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001078271-14-000008:notes:147]
[same as prior period, unchanged from 0001078271-13-000062:notes:110]

[0001078271-14-000008:notes:148]
[same as prior period, unchanged from 0001078271-13-000062:notes:111]

[0001078271-14-000008:notes:149]
[same as prior period, unchanged from 0001078271-13-000062:notes:112]

[0001078271-14-000008:notes:150]
[same as prior period, unchanged from 0001078271-13-000062:notes:113]


## us-gaap:TreasuryStockTextBlock

[0001078271-14-000008:notes:151]
[same as prior period, unchanged from 0001078271-13-000062:notes:114]

[0001078271-14-000008:notes:152]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which may be purchased over a three year period in the open market or in privately negotiated transactions. Since the inception of the program, 4.1 million shares have been repurchased and $60.5 million of the authorized amount is remaining. All repurchased shares will be retired and included in the Company's authorized but unissued shares. During the three and six months ended December 31, 2013, the Company did not repurchase any shares of common stock.
