# EXTR 10-Q controls and the auditor's report


## item_4_controls

[0001078271-14-000008:item_4_controls:1]
| Item 4. | Controls and Procedures |

[0001078271-14-000008:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001078271-14-000008:item_4_controls:3]
Disclosure controls and procedures are controls and procedures designed to reasonably assure that information required to be disclosed in our reports filed under the Securities Exchange Act of 1934 as amended, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC's rules and forms and to reasonably assure that such information is accumulated and communicated to our management, including the Chief Executive Officer (“CEO”) and the Chief Financial Officer (“CFO”), as appropriate to allow timely decisions regarding required disclosure.

[0001078271-14-000008:item_4_controls:4]
Our assessment of the internal controls excluded Enterasys Networks Inc. (“Enterasys”) which was acquired on October 31, 2013.  Enterasys had net revenues of $70 million and total assets of $135 million, which are included in the condensed consolidated financial statements of the Company as of and for the three months ended December 31, 2013. We are currently assessing the control environment of this acquired business. Enterasys’s sales constitute approximately 48% of our sales for the quarterly period covered by this report, and Enterasys's assets constitute approximately 26% of our total assets as of the end of such period.

[0001078271-14-000008:item_4_controls:5]
Under guidelines established by the SEC, companies are allowed to exclude acquisitions from their assessment of internal control over financial reporting during the first year of an acquisition while integrating the acquired company.

[0001078271-14-000008:item_4_controls:6]
Under the supervision and with the participation of our management, including our CEO and CFO, we evaluated the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO concluded that our disclosure controls and procedures were effective as of the end of the period covered by this Report.

[0001078271-14-000008:item_4_controls:7]
Management's Report on Internal Control over Financial Reporting

[0001078271-14-000008:item_4_controls:8]
Our management is responsible for establishing and maintaining adequate internal control over our financial reporting. There are inherent limitations in the effectiveness of any system of internal control, including the possibility of human error and the circumvention or overriding of controls. Accordingly, even effective internal controls can provide only reasonable assurances with respect to financial statement preparation. Further because of changes in conditions, the effectiveness of internal control may vary over time.

[0001078271-14-000008:item_4_controls:9]
We assessed the effectiveness of our internal control over financial reporting as of the end of the period covered by this Report. In making this assessment, we used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control-Integrated Framework.

[0001078271-14-000008:item_4_controls:10]
Based on our assessment using those criteria, we concluded that, as of the end of the period covered by this Report, our internal control over financial reporting is effective.

[0001078271-14-000008:item_4_controls:11]
Changes in Internal Control over Financial Reporting

[0001078271-14-000008:item_4_controls:12]
As noted above, our assessment of the internal controls excluded Enterasys which was acquired on October 31, 2013. Under guidelines established by the SEC, companies are permitted to exclude acquisitions from their assessment of internal control over financial reporting during the first year of an acquisition while integrating the acquired company.  During the integration period management is developing additional controls to ensure the financial information provided by Enterasys Networks, Inc. is complete and accurate in all material respects.

[0001078271-14-000008:item_4_controls:13]
Except as noted above, there were no changes in our internal control over financial reporting during the quarter ended December 31, 2013 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001078271-14-000008:item_4_controls:14]
Inherent Limitations on Effectiveness of Controls

[0001078271-14-000008:item_4_controls:15]
Our management, including the CEO and CFO, does not expect that our disclosure controls or our internal control over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system's objectives will be met. Our controls and procedures are designed to provide reasonable assurance that our control system's objective will be met and our CEO and CFO have concluded that our disclosure controls and procedures are effective at the reasonable assurance level. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within

[0001078271-14-000008:item_4_controls:16]
35

[0001078271-14-000008:item_4_controls:17]
Extreme Networks have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events. Projections of any evaluation of the effectiveness of controls in future periods are subject to risks. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Notwithstanding these limitations, our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives. Our CEO and CFO have concluded that our disclosure controls and procedures are, in fact, effective at the “reasonable assurance” level.

[0001078271-14-000008:item_4_controls:18]
36
