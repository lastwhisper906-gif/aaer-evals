# EXTR note change history — 0001078271-13-000062 → 0001078271-14-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-02-06):
[0001078271-14-000008:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2013, the Company had non-cancelable commitments to purchase approximately $63.2 million of such inventory.
  (was, 2013-11-04, similarity 0.9944):
[0001078271-13-000062:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2013, the Company had non-cancelable commitments to purchase approximately $80.0 million of such inventory.

- added (2014-02-06):
[0001078271-14-000008:note_history:2]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775 (Extreme Case). Further on May 6, 2013 they also filed a similar suit against Enterasys in the same court, Civil Action case number 13-774.The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on both cases in July, 2013. The suit is one of approximately 40 nearly simultaneous suits filed against numerous networking equipment manufacturers, suppliers, operators, and users including Cisco Systems, Hewlett-Packard, Juniper Networks, Avaya, Extreme and Enterasys.  The Company denies the claims and intends to vigorously defend itself in both cases. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

- added (2014-02-06):
[0001078271-14-000008:note_history:3]
ReefEdge

- added (2014-02-06):
[0001078271-14-000008:note_history:4]
On September 17, 2012, ReefEdge filed suit against Enterasys in the United States District Court for the District of Delaware alleging certain of the company's products (wireless controllers and wireless access points), infringe three ReefEdge U.S. patents (6633761, 6975864, 7197308).  ReefEdge, a Non-Practicing Entity, seeks injunctive relief as well as monetary damages, cost, expenses and attorney fees, although there was no quantified amount sought.  Preliminary talks have taken place between the parties. Enterasys has filed its Answer to the claims and is awaiting a scheduling conference. Extreme assumed this litigation as part of the acquisition of Enterasys.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

- changed (2014-02-06):
[0001078271-14-000008:note_history:5]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of December 31, 2013, the Company had no outstanding indemnification claims.
  (was, 2013-11-04, similarity 0.9967):
[0001078271-13-000062:note_history:5]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of September 30, 2013, the Company had no outstanding indemnification claims.

- removed (2014-02-06):
[0001078271-13-000062:note_history:6]
Chrimar Systems

- removed (2014-02-06):
[0001078271-13-000062:note_history:7]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 (the "Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.

- removed (2014-02-06):
[0001078271-13-000062:note_history:8]
During the quarter ending March 31, 2013, venue for the Delaware action was transferred to the United States District Court for the District of Northern California.

- removed (2014-02-06):
[0001078271-13-000062:note_history:9]
On July 16, 2013, the parties entered into a confidential patent license and settlement agreement (“Agreement”). Pursuant to that Agreement, the Company paid $1.4 million on July 25, 2013 and Chrimar filed for dismissal of the Delaware Action with prejudice on July 29, 2013. All matters between the parties have now been resolved.

- removed (2014-02-06):
[0001078271-13-000062:note_history:10]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775. The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on July 15, 2013. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-02-06):
[0001078271-14-000008:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2013. The results of operations for the three and six months ended December 31, 2013 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.
  (was, 2013-11-04, similarity 0.7788):
[0001078271-13-000062:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2013. The results of operations for the three months ended September 30, 2013 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.

- added (2014-02-06):
[0001078271-14-000008:note_history:12]
On October 31, 2013, the Company completed the acquisition of Enterasys Networks, Inc., a Delaware corporation ("Enterasys"), whereby Enterasys became a wholly-owned subsidiary of the Company (see Note 4: "Business Combinations" for further discussion).  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-02-06):
[0001078271-14-000008:note_history:13]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.
  (was, 2013-11-04, similarity 0.8592):
[0001078271-13-000062:note_history:13]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

- changed (2014-02-06):
[0001078271-14-000008:note_history:14]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.
  (was, 2013-11-04, similarity 0.9642):
[0001078271-13-000062:note_history:14]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.

- added (2014-02-06):
[0001078271-14-000008:note_history:15]
Business Combinations

- added (2014-02-06):
[0001078271-14-000008:note_history:16]
The Company applies the acquisition method of accounting for business combinations, including its acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.

- added (2014-02-06):
[0001078271-14-000008:note_history:17]
Goodwill

- added (2014-02-06):
[0001078271-14-000008:note_history:18]
Goodwill is assessed for impairment annually or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. Goodwill is tested for impairment at the reporting unit level at the beginning of fourth quarter of the fiscal year and at least annually thereafter. To test goodwill for impairment, the Company first performs a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, the Company will then perform the two-step goodwill impairment test. Otherwise, the two-step goodwill impairment test is not required.  Under the two-step goodwill impairment test, the Company would, in the first step, compare the estimated fair value of a reporting unit to its carrying value.  If the fair value of the reporting unit exceeds the carrying value, no impairment loss would be recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which the Company determines the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

- added (2014-02-06):
[0001078271-14-000008:note_history:19]
Long-Lived Assets

- added (2014-02-06):
[0001078271-14-000008:note_history:20]
Long-lived assets include property and equipment, and service inventory.  Property and equipment assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets or asset groups. The Company reduces the carrying value of service inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts.

- added (2014-02-06):
[0001078271-14-000008:note_history:21]
Intangible Assets

- added (2014-02-06):
[0001078271-14-000008:note_history:22]
Intangibles assets are reviewed for impairment annually or more frequently when an event occurs or circumstances change that would more likely than not reduce the fair value of the asset below its carrying value.  License agreements are presented at cost, net of accumulated amortization and are amortized over their estimated useful life.  The in-process research and development efforts will be monitored regularly for completion and once they are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.  The Company determines that our in-process research and development project is complete when all material research and development costs have been incurred and no significant risks remain. The Company  reviews the carrying value of indefinite-lived intangible assets for impairment at least annually during the last quarter of our fiscal year, or more frequently if we believe indicators of impairment exist.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2014-02-06):
[0001078271-14-000008:note_history:23]
The Company's debt is comprised of the following:

- added (2014-02-06):
[0001078271-14-000008:note_history:24]
|  |  | December 31, 2013 |
| Current portion of long-term debt |  |  |
| Term Loan |  | 4,063 |  |
| Current portion of long-term debt |  | 4,063 |  |
| Long-term debt, less current portion |  |  |
| Term Loan |  | 60,125 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt less current portion |  | 95,125 |  |
| Total debt |  | 99,188 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2014-02-06):
[0001078271-14-000008:note_history:25]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.
  (was, 2013-11-04, similarity 0.8592):
[0001078271-13-000062:note_history:25]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

- changed (2014-02-06):
[0001078271-14-000008:note_history:26]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.
  (was, 2013-11-04, similarity 0.9642):
[0001078271-13-000062:note_history:26]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-02-06):
[0001078271-13-000062:note_history:27]
Subsequent Events

- removed (2014-02-06):
[0001078271-13-000062:note_history:28]
Acquisition of Enterasys Networks

- removed (2014-02-06):
[0001078271-13-000062:note_history:29]
On October 31, 2013, the Company consummated the previously announced acquisition from Enterprise Networks Holdings Inc., of all of the issued and outstanding capital stock of Enterasys Networks, Inc. (“Enterasys”), a privately held provider of wired and wireless network infrastructure and security solutions based in Salem, New Hampshire.  The purchase price paid by the Company was $180 million in cash, consisting of cash on hand and borrowings under a new credit facility. We have agreed to reimburse the sellers on a dollar-for-dollar basis for any cash remaining in Enterasys at the closing.  The purchase price is subject to customary post-closing purchase price adjustments. The purchase of Enterasys has been accounted for as a business combination under the acquisition method.  Enterasys is now a wholly-owned subsidiary of the Company and the results of operations of Enterasys (beginning with the closing date of the acquisition) and the estimated fair value of assets acquired will be included in the Company’s consolidated financial statements beginning in the second quarter of fiscal 2014.

- removed (2014-02-06):
[0001078271-13-000062:note_history:30]
Senior Secured Credit Agreement

- removed (2014-02-06):
[0001078271-13-000062:note_history:31]
On October 31, 2013, the Company entered into a $125 million senior secured credit facilities agreement consisting of a $65 million term loan facility (“Term loan”) and a revolving credit facility of $60 million (“Revolving facility”).  Both facilities mature on October 31, 2018.  The  proceeds of the Term loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The company drew $35 million of the $60 million Revolving facility to pay fees and expenses incurred in connection with the acquisition and to provide ongoing working capital and for other general corporate purposes. Borrowings under the Term loan and Revolving facility bear interest, at the Company’s election, at a rate per annum equal to an agreed to applicable margin plus (a) the prime rate in effect on such day or (b) Libor. The credit facility contains standard events of default and financial covenants, including those that require the Company to maintain certain leverage and quick and fixed charge coverage ratios.
