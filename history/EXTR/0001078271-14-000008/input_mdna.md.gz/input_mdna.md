# EXTR MD&A — 0001078271-14-000008


## mdna

[0001078271-14-000008:mdna:1]
[same as prior period, unchanged from 0001078271-13-000062:mdna:1]

[0001078271-14-000008:mdna:2]
[same as prior period, unchanged from 0001078271-13-000062:mdna:2]

[0001078271-14-000008:mdna:3]
[same as prior period, unchanged from 0001078271-13-000062:mdna:3]

[0001078271-14-000008:mdna:4]
On October 31, 2013 (the “Acquisition Date”), we completed the acquisition of Enterasys Networks, Inc. (“Enterasys”), a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired, whereby Enterasys became our wholly-owned subsidiary.   The combined entity immediately became a networking industry leader with more than 12,000 customers. As a combined Company, we believe we will set the standard for the networking industry with a strategic focus on three principles:

[0001078271-14-000008:mdna:5]
Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center networking, switching and routing, Software-Defined Networking (SDN), wired and wireless LAN access, network management and security. This broader solutions portfolio can be leveraged to better serve existing and new customers. We will continue to enhance and support the product roadmaps of both companies going forward to protect the investments of customers and avoid any disruption to their businesses. We intend to significantly increase research and development to accelerate the vision for high-performance, modular, open networking.

[0001078271-14-000008:mdna:6]
Leading customer service and support: We are working to augment our current outsourced support model by integrating Enterasys' in-sourced expertise, building on Enterasys' award-winning heritage and strong commitment to exceptional customer experience. The Company's expanded global network of channel partners and distributors will benefit from expanded services and support capabilities.

[0001078271-14-000008:mdna:7]
Strong Channels and Strategic Partners: Our focus will be to leverage the capabilities of the combined Company and expand existing partnerships with Ericsson and the developing partnership with Lenovo as well as continue to add new strategic partnerships in the future. Additionally, we will increase our focus on partnering with distributors and channel partners globally. The goal will be to develop and enhance relationships that grow revenue and profits for the Company and our alliance and channel partners. At the same time, we are investing in infrastructure to make doing business with the Company easier and more efficient.

[0001078271-14-000008:mdna:8]
[same as prior period, unchanged from 0001078271-13-000062:mdna:4]

[0001078271-14-000008:mdna:9]
We outsource the majority of our manufacturing and supply chain management operations as part of our strategy to maintain global manufacturing capabilities and to reduce our costs. We conduct quality assurance, manufacturing engineering, document control and test development at engineering facilities in or near Research Triangle Park, North Carolina, Salem, New Hampshire, Chennai, India and Toronto, Canada. This approach enables us to attract talent in our selected regions and quickly respond to changes in market demand.

[0001078271-14-000008:mdna:10]
The market for network infrastructure equipment is highly competitive and dominated by a few large companies. The current economic climate has further driven consolidation of vendors within the Ethernet networking market and with vendors from adjacent markets, including storage, security, wireless and voice applications. We believe that the underpinning technology for all of these adjacent markets is Ethernet. As a result, we believe that, as an independent Ethernet switch vendor, we must provide products that, when combined with the products of our large strategic partners, create compelling solutions for end user customers. Our approach is to focus on the intelligence and automation layer that spans our hardware and software products that facilitates end-to-end solutions, as opposed to positioning Extreme Networks as a low-cost-vendor with point products.

[0001078271-14-000008:mdna:11]
[same as prior period, unchanged from 0001078271-13-000062:mdna:7]

[0001078271-14-000008:mdna:12]
[same as prior period, unchanged from 0001078271-13-000062:mdna:8]

[0001078271-14-000008:mdna:13]
During the second quarter of fiscal 2014, we achieved the following results:

[0001078271-14-000008:mdna:14]
| • | Net revenues of $146.6 million compared to net revenues of $75.6 million in the second quarter of fiscal 2013. |

[0001078271-14-000008:mdna:15]
| • | Product revenues of $119.1 million compared to product revenues of $60.3 million in the second quarter of fiscal 2013. |

[0001078271-14-000008:mdna:16]
| • | Service revenues of $27.5 million compared to service revenues of $15.3 million in the second quarter of fiscal 2013. |

[0001078271-14-000008:mdna:17]
| • | Total gross margin of 48% of net revenues compared to total gross margin of 54% of net revenues in the second quarter of fiscal 2013. |

[0001078271-14-000008:mdna:18]
| • | Operating loss of $13.8 million compared to operating loss of $3.8 million in the second quarter of fiscal 2013. |

[0001078271-14-000008:mdna:19]
| • | Net loss of $16.0 million compared to net loss of $4.2 million in the second quarter of fiscal 2013. |

[0001078271-14-000008:mdna:20]
| • | Cash flow used in operating activities of $4.9 million in the six months ended December 31, 2013 compared to cash flow provided by operating activities of $8.1 million in the six months ended December 31, 2012. |

[0001078271-14-000008:mdna:21]
| • | Cash and cash equivalents, short-term investments and marketable securities decreased by $93.6 million to $112.0 million as of December 31, 2013 from $205.6 million as of June 30, 2013, primarily due to cash used to fund a portion of the acquisition of Enterasys. |

[0001078271-14-000008:mdna:22]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, India, and Australia.

[0001078271-14-000008:mdna:23]
The following table presents the total net revenue geographically for the three and six months ended December 31, 2013 and December 31, 2012, respectively (dollars in thousands):

[0001078271-14-000008:mdna:24]
|  | Three Months Ended |  | Six Months Ended |
| Net Revenues | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |  | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 56,292 |  |  | $ | 22,731 |  |  | $ | 33,561 |  |  | 147.6 | % |  | $ | 81,681 |  |  | $ | 47,935 |  |  | $ | 33,746 |  |  | 70.4 | % |
| Other | 13,913 |  |  | 10,767 |  |  | 3,146 |  |  | 29.2 | % |  | 20,214 |  |  | 20,545 |  |  | (331 | ) |  | (1.6 | )% |
| Total Americas | 70,205 |  |  | 33,498 |  |  | 36,707 |  |  | 109.6 | % |  | 101,895 |  |  | 68,480 |  |  | 33,415 |  |  | 48.8 | % |
| Percentage of net revenue | 48.0 | % |  | 44.3 | % |  |  |  |  |  | 45.8 | % |  | 45.1 | % |  |  |  |  |  |  |
| EMEA | 61,292 |  |  | 28,700 |  |  | 32,592 |  |  | 113.6 | % |  | 92,133 |  |  | 57,220 |  |  | 34,913 |  |  | 61.0 | % |
| Percentage of net revenue | 41.8 | % |  | 38.0 | % |  |  |  |  |  | 41.4 | % |  | 37.7 | % |  |  |  |  |  |  |
| APAC | 15,086 |  |  | 13,353 |  |  | 1,733 |  |  | 13.0 | % |  | 28,470 |  |  | 25,978 |  |  | 2,492 |  |  | 9.6 | % |
| Percentage of net revenue | 10.3 | % |  | 17.7 | % |  |  |  |  |  | 12.8 | % |  | 17.1 | % |  |  |  |  |
| Total net revenues | $ | 146,583 |  |  | $ | 75,551 |  |  | $ | 71,032 |  |  | 94.0 | % |  | $ | 222,498 |  |  | $ | 151,678 |  |  | $ | 70,820 |  |  | 46.7 | % |

[0001078271-14-000008:mdna:25]
[same as prior period, unchanged from 0001078271-13-000062:mdna:20]

[0001078271-14-000008:mdna:26]
The following table presents net product and service revenue for the three and six months ended December 31, 2013 and December 31, 2012, respectively (dollars in thousands):

[0001078271-14-000008:mdna:27]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |  | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 119,065 |  |  | $ | 60,259 |  |  | $ | 58,806 |  |  | 97.6 | % |  | $ | 180,109 |  |  | $ | 121,378 |  |  | $ | 58,731 |  |  | 48.4 | % |
| Percentage of net revenue | 81.2 | % |  | 79.8 | % |  |  |  |  |  | 80.9 | % |  | 80.0 | % |  |  |  |  |
| Service | 27,518 |  |  | 15,292 |  |  | 12,226 |  |  | 80.0 | % |  | 42,389 |  |  | 30,300 |  |  | 12,089 |  |  | 39.9 | % |
| Percentage of net revenue | 18.8 | % |  | 20.2 | % |  |  |  |  |  | 19.1 | % |  | 20.0 | % |  |  |  |  |
| Total net revenues | $ | 146,583 |  |  | $ | 75,551 |  |  | $ | 71,032 |  |  | 94.0 | % |  | $ | 222,498 |  |  | $ | 151,678 |  |  | $ | 70,820 |  |  | 46.7 | % |

[0001078271-14-000008:mdna:28]
Product revenue increased $58.8 million or 97.6% in the second quarter of fiscal 2014 compared to the corresponding period of fiscal 2013. Product revenue increased $58.7 million or 48.4% in the six months ending December 31, 2013 compared to the corresponding period of fiscal 2013. In the three and six months ending December 31, 2013, there was a significant increase in the number of customers and products sold during the period due to our acquisition of Enterasys.  This resulted in a significant increase in our product revenue in all regions.

[0001078271-14-000008:mdna:29]
Service revenue increased $12.2 million or 80.0% in the second quarter of fiscal 2014 and $12.1 million or 39.9% in the six months ended December 31, 2013 compared to the corresponding period of fiscal 2013. The increase in the three and six months ended December 31, 2013 was due to an increase in service maintenance contract, professional service & training revenues due to our acquisition of Enterasys.

[0001078271-14-000008:mdna:30]
26

[0001078271-14-000008:mdna:31]
[same as prior period, unchanged from 0001078271-13-000062:mdna:25]

[0001078271-14-000008:mdna:32]
The following table presents the gross profit on product and service revenue and the gross profit percentage of product and service revenue for the three and six months ended December 31, 2013 and 2012 (in thousands):

[0001078271-14-000008:mdna:33]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |  | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 52,172 |  |  | $ | 30,882 |  |  | $ | 21,290 |  |  | 68.9 | % |  | $ | 85,700 |  |  | $ | 61,525 |  |  | $ | 24,175 |  |  | 39.3 | % |
| Percentage of product revenue | 43.8 | % |  | 51.3 | % |  |  |  |  |  | 47.6 | % |  | 50.7 | % |  |  |  |  |
| Service | 17,673 |  |  | 9,857 |  |  | 7,816 |  |  | 79.3 | % |  | 27,851 |  |  | 19,189 |  |  | 8,662 |  |  | 45.1 | % |
| Percentage of service revenue | 64.2 | % |  | 64.5 | % |  |  |  |  |  | 65.7 | % |  | 63.3 | % |  |  |  |  |
| Total gross profit | $ | 69,845 |  |  | $ | 40,739 |  |  | $ | 29,106 |  |  | 71.4 | % |  | $ | 113,551 |  |  | $ | 80,714 |  |  | $ | 32,837 |  |  | 40.7 | % |
| Percentage of net revenue | 47.7 | % |  | 53.9 | % |  |  |  |  |  | 51.0 | % |  | 53.2 | % |  |  |  |  |

[0001078271-14-000008:mdna:34]
[same as prior period, unchanged from 0001078271-13-000062:mdna:28]

[0001078271-14-000008:mdna:35]
Product gross margin decreased to 43.8% from 51.3% in the second quarter of fiscal 2014 and decreased to 47.6% from 50.7% in the six months ended December 31, 2013 compared to the corresponding periods of fiscal 2013.  The decrease in product gross margin for the three and six months ended December 31, 2013 was primarily due to higher material, labor and overhead costs from the additional headcount and warehouses due to our acquisition of Enterasys, a $9.2 million charge related to a portion of the release of the step-up value for inventory as required by business combination accounting and $2.7 million increase in the amortization of the developed technology intangibles from the acquisition of Enterasys.  Such increases for the six months ended December 31, 2013 were offset by lower excess and obsolete inventory charges as compared to corresponding period of fiscal 2013.

[0001078271-14-000008:mdna:36]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross margin decreased to 64.2% from 64.5% in the second quarter of fiscal 2014 and increased to 65.7% from 63.3% during the six months ended December 31, 2013 as compared to the corresponding periods of fiscal 2013.  The service gross margin for the three months ended December 31, 2013 decreased primarily due to higher labor, overhead and travel cost due to the acquisition of Enterasys.  The service gross margin for the six months ended December 31, 2013 increased primarily due to cost reduction initiatives partially offset by the increased cost of revenues from the acquisition of Enterasys.

[0001078271-14-000008:mdna:37]
[same as prior period, unchanged from 0001078271-13-000062:mdna:31]

[0001078271-14-000008:mdna:38]
[same as prior period, unchanged from 0001078271-13-000062:mdna:32]

[0001078271-14-000008:mdna:39]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |  | December 31, 2013 |  | December 31, 2012 |  | $Change |  | %Change |
| Research and development | $ | 18,896 |  |  | $ | 11,007 |  |  | $ | 7,889 |  |  | 71.7 | % |  | $ | 28,832 |  |  | $ | 21,573 |  |  | $ | 7,259 |  |  | 33.6 | % |
| Sales and marketing | 40,636 |  |  | 22,093 |  |  | 18,543 |  |  | 83.9 | % |  | 63,330 |  |  | 44,120 |  |  | 19,210 |  |  | 43.5 | % |
| General and administrative | 11,189 |  |  | 6,644 |  |  | 4,545 |  |  | 68.4 | % |  | 18,125 |  |  | 12,003 |  |  | 6,122 |  |  | 51.0 | % |
| Acquisition and integration costs | 8,688 |  |  | — |  |  | 8,688 |  |  | 100.0 | % |  | 12,382 |  |  | — |  |  | 12,382 |  |  | 100.0 | % |
| Restructuring charge, net of reversals | 430 |  |  | 5,176 |  |  | (4,746 | ) |  | 91.7 | % |  | 505 |  |  | 5,167 |  |  | (4,662 | ) |  | (90.2 | )% |
| Amortization of intangibles | 3,778 |  |  | — |  |  | 3,778 |  |  | 100.0 | % |  | 3,778 |  |  | — |  |  | 3,778 |  |  | 100.0 | % |
| Litigation settlement | — |  |  | (421 | ) |  | 421 |  |  | (100.0 | )% |  | — |  |  | (421 | ) |  | 421 |  |  | (100.0 | )% |
| Gain on sale of facilities | — |  |  | — |  |  | — |  |  | — | % |  | — |  |  | (11,539 | ) |  | 11,539 |  |  | (100.0 | )% |
| Total operating expenses | $ | 83,617 |  |  | $ | 44,499 |  |  | $ | 39,118 |  |  | 87.9 | % |  | $ | 126,952 |  |  | $ | 70,903 |  |  | $ | 56,049 |  |  | 79.1 | % |
| Operating income | $ | (13,772 | ) |  | $ | (3,760 | ) |  | $ | (10,012 | ) |  | 266.3 | % |  | $ | (13,401 | ) |  | $ | 9,811 |  |  | $ | (23,212 | ) |  | (236.6 | )% |

[0001078271-14-000008:mdna:40]
[same as prior period, unchanged from 0001078271-13-000062:mdna:35]

[0001078271-14-000008:mdna:41]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |  | December 31, 2013 |  | December 31, 2012 |
| Research and development | 12.9 | % |  | 14.6 | % |  | 13.0 | % |  | 14.2 | % |
| Sales and marketing | 27.7 | % |  | 29.2 | % |  | 28.5 | % |  | 29.1 | % |
| General and administrative | 7.6 | % |  | 8.8 | % |  | 8.1 | % |  | 7.9 | % |
| Acquisition and integration costs | 5.9 | % |  | — | % |  | 5.56 | % |  | — | % |
| Restructuring charge, net of reversals | 0.3 | % |  | 6.9 | % |  | 0.2 | % |  | 3.4 | % |
| Amortization of intangibles | 2.6 | % |  | — | % |  | 1.70 | % |  | — | % |
| Litigation settlement | — | % |  | (0.6 | )% |  | — | % |  | (0.3 | )% |
| Gain on sale of facilities | — | % |  | — | % |  | — | % |  | (7.6 | )% |
| Total operating expenses | 57.0 | % |  | 58.9 | % |  | 57.1 | % |  | 46.7 | % |
| Operating income | (9.4 | )% |  | (5.0 | )% |  | (6.0 | )% |  | 6.5 | % |

[0001078271-14-000008:mdna:42]
[same as prior period, unchanged from 0001078271-13-000062:mdna:37]

[0001078271-14-000008:mdna:43]
[same as prior period, unchanged from 0001078271-13-000062:mdna:38]

[0001078271-14-000008:mdna:44]
Research and development expenses increased by $7.9 million, or 71.7% in the second quarter of fiscal 2014 and $7.3 million or 33.6% for the six months ended December 31, 2013 as compared to the corresponding periods of fiscal 2013. The increase in research and development expenses for the three and six months ended December 31, 2013 was primarily due to increased personnel costs from the additional headcount from the acquisition of Enterasys. Such increases were slightly offset by lower spending on engineering projects due to differences in timing and pattern of planned engineering project spending as compared to fiscal 2013.

[0001078271-14-000008:mdna:45]
[same as prior period, unchanged from 0001078271-13-000062:mdna:40]

[0001078271-14-000008:mdna:46]
[same as prior period, unchanged from 0001078271-13-000062:mdna:41]

[0001078271-14-000008:mdna:47]
Sales and marketing expenses increased by $18.5 million, or 83.9% in the second quarter of fiscal 2014 and $19.2 million or 43.5% for the six months ended December 31, 2013 as compared to the corresponding periods of fiscal 2013. The increase in sales and marketing expenses for the three and six months ended December 31, 2013 was primarily due to increased personnel costs due to increased headcount as well as increased spending on sales and marketing programs due to additional programs from the acquisition of Enterasys.

[0001078271-14-000008:mdna:48]
[same as prior period, unchanged from 0001078271-13-000062:mdna:43]

[0001078271-14-000008:mdna:49]
General and administrative expenses increased by $4.5 million, or 68.4% in the second quarter of fiscal 2014 and $6.1 million or 51.0% for the six months ended December 31, 2013, compared to the corresponding periods of fiscal 2013. The increase in general and administrative expenses during the three and six months ending December 31, 2013, compared to the corresponding periods of fiscal 2013, was primarily due to higher personnel and travel costs and higher rent charges due to additional headcount and facilities from the acquisition of Enterasys.

[0001078271-14-000008:mdna:50]
Acquisition and integration Costs

[0001078271-14-000008:mdna:51]
As a result of our acquisition of Enterasys, we incurred $8.7 million and $12.4 million of acquisition and integration costs during the second quarter and six months ended December 31, 2013.  The Company anticipates to incur integration costs for the next two years.

[0001078271-14-000008:mdna:52]
[same as prior period, unchanged from 0001078271-13-000062:mdna:47]

[0001078271-14-000008:mdna:53]
Restructuring charges decreased by $4.7 million in the second quarter of fiscal 2014 and six months ended December 31, 2013 compared to the corresponding periods of fiscal 2013.  During the second quarter of fiscal 2013, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. The Company has substantially expensed all of the costs associated with this initiative.  As of December 31, 2013, we had restructuring liabilities of $0.7 million, which we anticipate paying by the end of fiscal 2015.

[0001078271-14-000008:mdna:54]
Amortization of intangibles

[0001078271-14-000008:mdna:55]
During the second quarter of fiscal 2014, we recorded $3.8 million amortization of certain intangibles related to the acquisition of Enterasys on October 31, 2013.

[0001078271-14-000008:mdna:56]
Litigation Settlement

[0001078271-14-000008:mdna:57]
During the second quarter of fiscal 2013, we recognized a litigation award of $0.4 million related to a favorable verdict on a trial.

[0001078271-14-000008:mdna:58]
[same as prior period, unchanged from 0001078271-13-000062:mdna:49]

[0001078271-14-000008:mdna:59]
[same as prior period, unchanged from 0001078271-13-000062:mdna:50]

[0001078271-14-000008:mdna:60]
[same as prior period, unchanged from 0001078271-13-000062:mdna:51]

[0001078271-14-000008:mdna:61]
Other expense, net increased by $0.6 million in the second quarter of fiscal 2014 and by $0.5 million for the six months ended December 31, 2013 compared to the corresponding periods of fiscal 2013.  The increase in other expense, net was primarily due to losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.  For the six months ended December 31, 2013, we had an additional decrease from an other than temporary impairment loss of $148,000, recorded in the first quarter of fiscal 2014.

[0001078271-14-000008:mdna:62]
[same as prior period, unchanged from 0001078271-13-000062:mdna:53]

[0001078271-14-000008:mdna:63]
For the three and six months ended December 31, 2013, we recorded an income tax provision of $0.9 million and $1.4 million, respectively.  For the three and six months ended December 31, 2012, we recorded an income tax provision of $0.4 million and $1.0 million, respectively.

[0001078271-14-000008:mdna:64]
The income tax provisions for the three and six months ended December 31, 2013 and 2012 consisted primarily of taxes on the income of our foreign subsidiaries as well as U.S. state income taxes. The income tax provision for the three and six months ended December 31, 2013 also includes an expense related to a deferred tax liability for the amortization of goodwill recorded as a result of the acquisition of Enterasys.

[0001078271-14-000008:mdna:65]
[same as prior period, unchanged from 0001078271-13-000062:mdna:56]

[0001078271-14-000008:mdna:66]
[same as prior period, unchanged from 0001078271-13-000062:mdna:57]

[0001078271-14-000008:mdna:67]
[same as prior period, unchanged from 0001078271-13-000062:mdna:58]

[0001078271-14-000008:mdna:68]
[same as prior period, unchanged from 0001078271-13-000062:mdna:59]

[0001078271-14-000008:mdna:69]
[same as prior period, unchanged from 0001078271-13-000062:mdna:60]

[0001078271-14-000008:mdna:70]
[same as prior period, unchanged from 0001078271-13-000062:mdna:61]

[0001078271-14-000008:mdna:71]
[same as prior period, unchanged from 0001078271-13-000062:mdna:62]

[0001078271-14-000008:mdna:72]
[same as prior period, unchanged from 0001078271-13-000062:mdna:63]

[0001078271-14-000008:mdna:73]
[same as prior period, unchanged from 0001078271-13-000062:mdna:64]

[0001078271-14-000008:mdna:74]
[same as prior period, unchanged from 0001078271-13-000062:mdna:65]

[0001078271-14-000008:mdna:75]
| • | Legal Contingencies |

[0001078271-14-000008:mdna:76]
[same as prior period, unchanged from 0001078271-13-000062:mdna:67]

[0001078271-14-000008:mdna:77]
We added the following policies to our critical accounting policies during the second quarter of fiscal 2014.

[0001078271-14-000008:mdna:78]
Business Combinations

[0001078271-14-000008:mdna:79]
We apply the acquisition method of accounting for business combinations, including its acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of each transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001078271-14-000008:mdna:80]
Goodwill

[0001078271-14-000008:mdna:81]
Goodwill is assessed for impairment annually or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. Goodwill is tested for impairment at the reporting unit level at adoption and at least annually thereafter.  To test goodwill for impairment, we first perform a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, we will then perform the two-step goodwill impairment test.

[0001078271-14-000008:mdna:82]
Otherwise, the two-step goodwill impairment test is not required.  Under the two-step goodwill impairment test, we would, in the first step, compare the estimated fair value of a reporting unit to its carrying value. If the fair value of the reporting unit exceeds the carrying value, no impairment loss would be recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which we determine the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

[0001078271-14-000008:mdna:83]
[same as prior period, unchanged from 0001078271-13-000062:mdna:69]

[0001078271-14-000008:mdna:84]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013. We intend to adopt this standard prospectively in the first quarter of its fiscal year ending June 30, 2015. We do not believe this updated standard will have a material impact on its consolidated financial statements.

[0001078271-14-000008:mdna:85]
[same as prior period, unchanged from 0001078271-13-000062:mdna:72]

[0001078271-14-000008:mdna:86]
[same as prior period, unchanged from 0001078271-13-000062:mdna:73]

[0001078271-14-000008:mdna:87]
|  | December 31, 2013 |  | June 30, 2013 |
| Cash and cash equivalent | $ | 68,304 |  |  | $ | 95,803 |  |
| Short-term investments | 43,713 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total cash and investments | $ | 112,017 |  |  | $ | 205,613 |  |
| Working capital | $ | 75,736 |  |  | $ | 96,279 |  |

[0001078271-14-000008:mdna:88]
As of December 31, 2013, our principal sources of liquidity consisted of cash, cash equivalents and investments of $112.0 million, net accounts receivable of $94.3 million and borrowings from the Revolving Facility under which the Company had $25.0 million of availability at December 31, 2013.  Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products, purchases of property and equipment and repurchases of our common stock. We believe that our $112.0 million of cash and cash equivalents and investments at December 31, 2013 along with the availability of borrowings from the Revolving Facility of $25.0 million will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001078271-14-000008:mdna:89]
Our Credit Agreement contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum a Consolidated Leverage Ratio and several other covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001078271-14-000008:mdna:90]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Agreement may be accelerated upon certain events of default.  We believe we are in compliance and expect to remain in compliance with our Credit Agreement covenants and they are not expected to impact our liquidity or capital resources.

[0001078271-14-000008:mdna:91]
[same as prior period, unchanged from 0001078271-13-000062:mdna:77]

[0001078271-14-000008:mdna:92]
[same as prior period, unchanged from 0001078271-13-000062:mdna:78]

[0001078271-14-000008:mdna:93]
|  | Six Months Ended |
|  | December 31, 2013 |  | December 31, 2012 |
| Net cash (used in) provided by operating activities | $ | (4,869 | ) |  | $ | 8,077 |  |
| Net cash (used in) provided by investing activities | $ | (126,967 | ) |  | $ | 31,181 |  |
| Net cash provided by (used in) financing activities | $ | 103,990 |  |  | $ | (4,557 | ) |
| Foreign currency effect on cash | $ | 347 |  |  | $ | 469 |  |
| Net (decrease) increase in cash and cash equivalents | $ | (27,499 | ) |  | $ | 35,170 |  |

[0001078271-14-000008:mdna:94]
[same as prior period, unchanged from 0001078271-13-000062:mdna:80]

[0001078271-14-000008:mdna:95]
Cash flows from operations decreased by $12.3 million in the six months ending December 31, 2013 compared to the corresponding period of fiscal 2013, primarily due to the post acquisition increase in accounts receivables, increase in inventory balances and timing of inventory receipts to bring the inventory levels in line with the near term demand and an increase in post acquisition accounts payable balance and the timing of payments.  Such decreases were partially offset by $4.9 million cash received as tenant incentives from the landlords of existing leased facilities which the Company used towards leasehold improvements.

[0001078271-14-000008:mdna:96]
[same as prior period, unchanged from 0001078271-13-000062:mdna:82]

[0001078271-14-000008:mdna:97]
Cash flow used in investing activities in the six months ending December 31, 2013 was $127.0 million, comprised of $180.0 million net cash used for the acquisition of Enterasys, purchases of investments of $9.0 million, $12.6 million used to purchase property and equipment offset by proceeds of $20.1 million from the maturities of investments and proceeds of $54.6 million from the sale of investments.

[0001078271-14-000008:mdna:98]
[same as prior period, unchanged from 0001078271-13-000062:mdna:84]

[0001078271-14-000008:mdna:99]
Cash flow provided by financing activities in the six months ending December 31, 2013 was $104.0 million, comprised of issuance of Term Loan of $65.0 million and a draw on the Revolving Facility of $35 million used for the acquisition of Enterasys, $4.8 million proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards offset by $0.8 million of cash used for repayment of debt.

[0001078271-14-000008:mdna:100]
[same as prior period, unchanged from 0001078271-13-000062:mdna:86]

[0001078271-14-000008:mdna:101]
The following summarizes our contractual obligations at December 31, 2013, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-14-000008:mdna:102]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 99,187 |  |  | $ | 4,062 |  |  | $ | 22,750 |  |  | $ | 72,375 |  |  | $ | — |  |
| Interest on debt obligations | 10,005 |  |  | 2,610 |  |  | 4,657 |  |  | 2,738 |  |  | — |  |
| Non-cancellable inventory purchase commitments | 63,165 |  |  | 63,165 |  |  | — |  |  | — |  |  | — |  |
| Non-cancellable operating lease obligations | 62,146 |  |  | 10,871 |  |  | 15,095 |  |  | 12,975 |  |  | 23,205 |  |
| Other liabilities | 9,869 |  |  | 3,032 |  |  | 4,530 |  |  | 809 |  |  | 1,498 |  |
| Total contractual cash obligations | $ | 244,372 |  |  | $ | 83,740 |  |  | $ | 47,032 |  |  | $ | 88,897 |  |  | $ | 24,703 |  |

[0001078271-14-000008:mdna:103]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $63.2 million as of December 31, 2013, an increase of $13.1 million from $50.1 million as of June 30, 2013. We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-14-000008:mdna:104]
[same as prior period, unchanged from 0001078271-13-000062:mdna:90]

[0001078271-14-000008:mdna:105]
Other liabilities include the Company's commitments towards debt related fees and specific arrangements other than inventory.

[0001078271-14-000008:mdna:106]
[same as prior period, unchanged from 0001078271-13-000062:mdna:92]

[0001078271-14-000008:mdna:107]
We did not have any material commitments for capital expenditures as of December 31, 2013.

[0001078271-14-000008:mdna:108]
[same as prior period, unchanged from 0001078271-13-000062:mdna:94]

[0001078271-14-000008:mdna:109]
We did not have any off-balance sheet arrangements as of December 31, 2013.
