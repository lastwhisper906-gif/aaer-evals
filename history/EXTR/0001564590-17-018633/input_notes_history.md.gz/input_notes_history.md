# EXTR note change history — 0001564590-17-000906 → 0001564590-17-008860


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001564590-17-008860:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2017, the Company had non-cancelable commitments to purchase $88.9 million of such inventory.  As of March 31, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $22.8 of software and support services.
  (was, 2017-02-02, similarity 0.9833):
[0001564590-17-000906:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2016, the Company had non-cancelable commitments to purchase $93.6 million of such inventory.  As of December 31, 2016 the Company had non-cancelable software and maintenance support commitments to purchase $24.2 of software and support services.

- changed (2017-05-04):
[0001564590-17-008860:note_history:2]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of March 31, 2017.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.1 million), plus interest and penalties BRL 18.1 million (US $5.8 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.
  (was, 2017-02-02, similarity 0.9961):
[0001564590-17-000906:note_history:2]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of December 31, 2016.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.0 million), plus interest and penalties BRL 17.7 million (US $5.4 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

- changed (2017-05-04):
[0001564590-17-008860:note_history:3]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits covered the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company had changed its ICMS procedures effective May 2009. This audit was recently completed and in March 2017 the Company paid BRL 0.2 million (US $0.1 ) related to the audit.
  (was, 2017-02-02, similarity 0.724):
[0001564590-17-000906:note_history:3]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits are expected to cover the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company changed its ICMS procedures effective May 2009 and a similar tax assessment is not anticipated.  The Company has provided the requested information for these tax years to the Brazilian tax authorities, but has received no further response from the Brazilian tax authorities.

- changed (2017-05-04):
[0001564590-17-008860:note_history:4]
Based on the currently available information, the Company believes the ultimate outcome of the above assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL 25.3 million (US $8.1 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $3.0 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.
  (was, 2017-02-02, similarity 0.9951):
[0001564590-17-000906:note_history:4]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL 25.3 million (US $7.8 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $2.9 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

- changed (2017-05-04):
[0001564590-17-008860:note_history:5]
On October 23 and 29, 2015, complaints were filed alleging violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint. On November 10, 2016 defendants filed a motion to dismiss the complaint and on April 27, 2017, the case was dismissed by the court, with leave to amend the complaint.  Plaintiffs have until May 29, 2017, if they elect to file an amended complaint.
  (was, 2017-02-02, similarity 0.8282):
[0001564590-17-000906:note_history:5]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint. On November 10, 2016 defendants filed a motion to dismiss.  The motion is scheduled to be heard, after completion of the briefing, on February 9, 2017.   The Company believes the claims are without merit and intends to vigorously defend the claims.

- changed (2017-05-04):
[0001564590-17-008860:note_history:6]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.
  (was, 2017-02-02, similarity 0.9911):
[0001564590-17-000906:note_history:6]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation to that effect.

- changed (2017-05-04):
[0001564590-17-008860:note_history:7]
Plectrum, LLC v. Extreme Networks, Inc. Patent Infringement Suit
  (was, 2017-02-02, similarity 0.7862):
[0001564590-17-000906:note_history:7]
Dunti Network Technologies, LLC v Extreme Networks, Inc. Patent Infringement Suit

- changed (2017-05-04):
[0001564590-17-008860:note_history:8]
On February 27, 2017, the Company was served with a patent infringement complaint, dated February 2, 2017, and filed by Plectrum LLC in the U.S. District Court for the Eastern District of Texas.  The case is Plectrum LLC v. Extreme Networks, Inc., No. 4:17-cv-0079.  The complaint asserts infringement of U.S. Patent Nos. 5,978,951, 6,205,149, and 6,751,677.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s S-Series products and Summit Series Switch products.  Plectrum seeks an injunction and damages of an unspecified amount.  The Company has not yet responded to the complaint.
  (was, 2017-02-02, similarity 0.627):
[0001564590-17-000906:note_history:8]
On September 22, 2016, the Company was served with a patent infringement complaint by Dunti Network Technologies, LLC in the U.S. District Court for the Eastern District of Texas.  The case is Dunti Network Technologies, LLC v. Extreme Networks, Inc., No. 2:16-cv-01034.  The complaint asserts infringement of U.S. Patent Nos. 6,587,462, 6,788,701, 6,804,235, 6,643,286, and 7,778,259.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s BlackDiamond-X, Summit X670, and Summit X770 series switches.  Dunti sought damages of an unspecified amount.  Dunti moved to dismiss the case and the case against the Company was dismissed by the court as of December 27, 2016.

- added (2017-05-04):
[0001564590-17-008860:note_history:9]
XR Communications, LLC d/b/a Vivato Technologies, LLC v. Extreme Networks, Inc.

- added (2017-05-04):
[0001564590-17-008860:note_history:10]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies, LLC) sued Extreme in the Central District of California.   The complaint asserts infringement of U.S. Patent Nos. 7,062,296; 7,729,728; and 6,611,231. XR seeks damages of an unspecified amount and on-going royalties, but not an injunction. The Company has not yet responded to the complaint.  The Company believes the claims are without merit and intends to vigorously defend the claims.

- changed (2017-05-04):
[0001564590-17-008860:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of March 31, 2017, the Company had no outstanding indemnification claims.
  (was, 2017-02-02, similarity 0.9939):
[0001564590-17-000906:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of December 31, 2016, the Company had no outstanding indemnification claims.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001564590-17-008860:note_history:12]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2017  The results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.
  (was, 2017-02-02, similarity 0.9404):
[0001564590-17-000906:note_history:12]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2016  The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001564590-17-008860:note_history:13]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 11,149 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 11,149 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 73,775 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 83,775 |  |  |  | 37,446 |  |
| Total debt |  | $ | 94,924 |  |  | $ | 55,074 |  |
  (was, 2017-02-02, similarity 0.9851):
[0001564590-17-000906:note_history:13]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 10,020 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 10,020 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 77,127 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 87,127 |  |  |  | 37,446 |  |
| Total debt |  | $ | 97,147 |  |  | $ | 55,074 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-05-04):
[0001564590-17-000906:note_history:14]
14.Subsequent Events

- removed (2017-05-04):
[0001564590-17-000906:note_history:15]
On January 5, 2017, Extreme Networks, Inc. (the "Company") approved and on January 6, 2017 began executing a reduction-in-force plan (the ”Plan”) to re-align the Company’s resources as a result of the Company’s purchase of the wireless LAN business of Zebra Technologies Corporation. The Company expects to incur charges of approximately $6.5 million and affected employees worldwide and all functional areas. Upon completion of the Plan, the potential savings is expected to yield annualized savings of approximately $8.0 million. The costs associated with this Plan are primarily employee severance and benefits expenses.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.
