# EXTR MD&A — 0001564590-17-018633


## mdna

[0001564590-17-018633:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-17-018633:mdna:2]
Business Overview

[0001564590-17-018633:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Item 8 of Part II of this Report.

[0001564590-17-018633:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles, or U.S. GAAP.  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-17-018633:mdna:5]
Extreme is a leading provider of network infrastructure equipment and offers related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996, and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. Substantially all of our revenue is derived from the sale of our networking equipment and related maintenance contracts.

[0001564590-17-018633:mdna:6]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from the data center to the access point, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. We strive to help our customers and partners Connect Beyond the Network by building world-class software and network infrastructure solutions that solve the wide range of problems faced by IT departments.

[0001564590-17-018633:mdna:7]
Enterprise network administrators from the data center to the access layer need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever present need for network security.  Accelerators such as Internet of Things (“IoT”), artificial intelligence (“AI”), bring your own device (“BYOD”), machine learning, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-17-018633:mdna:8]
A trend effecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud and third-party, public cloud services with orchestration between the two platforms. We introduced our Cloud offering in 2016 and announced its enhanced cloud offering in 2017.  ExtremeCloud is the only offering in the market that seamlessly integrates the cloud with on-premise infrastructures.  (See Part 1, Item 1. Business, for additional discussion of the Company’s business)

[0001564590-17-018633:mdna:9]
Acquisition

[0001564590-17-018633:mdna:10]
On October 28, 2016, we completed the acquisition of Zebra’s WLAN Business assets.  Under the terms of the purchase agreement, we acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for net cash consideration to $49.5 million.

[0001564590-17-018633:mdna:11]
We have accounted for the acquisition using the acquisition method of accounting.  The purchase price allocation as of the acquisition date is set forth in Note 2 Business Combinations in our Notes to Consolidated Financial Statements and reflects fair values. The fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of June 30, 2017.

[0001564590-17-018633:mdna:12]
During the fiscal year ended June 30, 2017, we recognized acquisition costs of $2.1 million and integration costs of $6.6 million, which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-17-018633:mdna:13]
On July 14, 2017, we completed the acquisition of Avaya Networking, Avaya’s fabric-based secure networking solutions and network security solutions business, that had been announced on March 7, 2017, and funds were remitted to Avaya pursuant to the purchase agreement. We acquired customers, employees, technology and other assets, as well as assume contracts and other liabilities of the Avaya Networking business, for a purchase price of $100.0 million, subject to certain adjustments.  Pursuant to certain ancillary agreements, Avaya will also provide us with access to certain technology related to Avaya Networking, as well as transition services for a period of time following the closing of the transaction.  As a condition of our agreement, the Company made deposits of $10.2 million in our fiscal third quarter to be applied to the purchase price upon closing.  See Note 14. Subsequent Events for additional information.

[0001564590-17-018633:mdna:14]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Avaya Networking will be recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of Avaya Networking will be included in our operations beginning with the closing date as noted above.

[0001564590-17-018633:mdna:15]
During fiscal year ended June 30, 2017, we recognized acquisition costs of $2.2 million, which is included in “Acquisition and integration costs” in the accompanying consolidated statements of operations related to the Purchase Agreement.

[0001564590-17-018633:mdna:16]
Future Acquisitions

[0001564590-17-018633:mdna:17]
On March 29, 2017, we entered into an additional Asset Purchase Agreement (the “Purchase Agreement II”) with LSI Corporation, (“LSI”), and, solely for the purposes set forth in the Purchase Agreement II, Broadcom to purchase the Brocade Data business of Brocade.  Upon the terms and subject to the conditions of the Purchase Agreement II, we will acquire customers, employees, technology and other assets of Brocade Data, as well as assume certain contracts and other liabilities of Brocade Data, for an upfront cash closing payment equal to $35.0 million, plus a deferred payment equal to $20.0 million to be paid $1 million per quarter for 20 quarters following the closing date of the transaction (the “Closing,” and such date, the “Closing Date”), plus quarterly earn out payments equal to 50% of profits of Brocade Data for the five-year period commencing at the end of our first full fiscal quarter following the Closing Date.  Pursuant to certain ancillary agreements, LSI will also provide us with access to certain technology related to Brocade Data, as well as transition services for a period of time following the Closing.  The acquisition will include the rights to have manufactured and sold Brocade’s current SLX based solutions product portfolio, which launched in March 2017.  The Purchase Agreement II is contingent upon Broadcom acquiring Brocade.   (See Item 1A Risk Factors for additional information).

[0001564590-17-018633:mdna:18]
During the fiscal year ended June 30 2017, we recognized acquisition costs of $2.2 million, which is included in “Acquisition and integration costs” in the accompanying consolidated statements of operations related to the Purchase Agreement II.

[0001564590-17-018633:mdna:19]
Results of Operations

[0001564590-17-018633:mdna:20]
Following is a summary of our results of operations during fiscal 2017:

[0001564590-17-018633:mdna:21]
|  | • | Net revenue of $598.1 million, increased 13.2% from fiscal 2016 net revenue of $528.4 million. |

[0001564590-17-018633:mdna:22]
|  | • | Product revenue of $451.5 million, increased 14.2% from fiscal 2016 product revenue of $395.5 million. |

[0001564590-17-018633:mdna:23]
|  | • | Service revenue of $146.7 million, increased 10.3% from fiscal 2016 service revenue of $132.9 million. |

[0001564590-17-018633:mdna:24]
|  | • | Total gross margin of 54.3% of net revenue in fiscal 2017, compared to 51.2% in fiscal 2016. |

[0001564590-17-018633:mdna:25]
|  | • | Restructuring charge of $8.9 million, for excess facilities and contract termination. |

[0001564590-17-018633:mdna:26]
|  | • | Operating loss of $0.7 million, was a decrease in the operating loss of $24.8 million from fiscal 2016. |

[0001564590-17-018633:mdna:27]
|  | • | Net loss was $8.5 million in fiscal 2017, a decrease of $23.4 million from a net loss of $31.9 million in fiscal 2016. |

[0001564590-17-018633:mdna:28]
|  | • | Cash flow provided by operating activities of $59.3 million, compared to cash flow provided by operating activities of $30.4 million in fiscal 2016, an increase of $28.9 million. Cash and cash equivalents were $130.5 million as of June 30, 2017, an increase of $36.4 million compared to fiscal.2016 |

[0001564590-17-018633:mdna:29]
Net Revenues

[0001564590-17-018633:mdna:30]
The following table presents net product and service revenue for the fiscal years 2017, 2016 and 2015 (dollars in thousands):

[0001564590-17-018633:mdna:31]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 451,459 |  |  | $ | 395,464 |  |  | $ | 55,995 |  |  |  | 14.2 | % |  | $ | 395,464 |  |  | $ | 418,046 |  |  | $ | (22,582 | ) |  |  | (5.4 | )% |
| Percentage of net revenue |  |  | 75.5 | % |  |  | 74.8 | % |  |  |  |  |  |  |  |  |  |  | 74.8 | % |  |  | 75.6 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 146,659 |  |  |  | 132,925 |  |  |  | 13,734 |  |  |  | 10.3 | % |  |  | 132,925 |  |  | $ | 134,894 |  |  |  | (1,969 | ) |  |  | (1.5 | )% |
| Percentage of net revenue |  |  | 24.5 | % |  |  | 25.2 | % |  |  |  |  |  |  |  |  |  |  | 25.2 | % |  |  | 24.4 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 598,118 |  |  | $ | 528,389 |  |  | $ | 69,729 |  |  |  | 13.2 | % |  | $ | 528,389 |  |  | $ | 552,940 |  |  | $ | (24,551 | ) |  |  | (4.4 | )% |

[0001564590-17-018633:mdna:32]
Product revenue increased $56.0 million or 14.2% for the year ended June 30, 2017, compared to the corresponding period of fiscal 2016. The increase in product revenue was primarily a result of the acquisition of the WLAN Business during fiscal 2017 and to lower discounting from list price.  The increase was partially offset by lower e-rate educational revenue.

[0001564590-17-018633:mdna:33]
Product revenue decreased $22.6 million or 5.4% for the year ended June 30, 2016, compared to the corresponding period of fiscal 2015. The decrease in product revenue was primarily due to an increase in competitive pricing pressure on lower volumes of modular (chassis based) switching products resulting from market shifts towards fixed products which are generally lower cost and are capable of rapidly adapting to changes and needs of the marketplace. The growth in the fixed products was not sufficient to offset the modular product decline and to a lesser extent, to the strengthening of the United States Dollar in nearly all geographical regions.

[0001564590-17-018633:mdna:34]
Service revenue increased $13.7 million or 10.3% for the year ended June 30, 2017, compared to the corresponding period of fiscal 2016. The increase in service revenue was primarily a result of the acquisition of the WLAN Business during fiscal 2017, the increased number of service contracts acquired and lower purchase accounting charges.

[0001564590-17-018633:mdna:35]
Service revenue decreased $2.0 million or 1.5% for the year ended June 30, 2016 compared to the corresponding period of fiscal 2015 due to a decrease in service maintenance contracts and professional service and training revenues.  Partially offsetting the decrease were lower purchase accounting charges related to deferred service revenues, which decreased to $1.5 million for the year-ended June 30, 2016, from $3.1 million in the corresponding period of fiscal 2015.

[0001564590-17-018633:mdna:36]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenue geographically for the fiscal years 2017, 2016 and 2015 (dollars in thousands):

[0001564590-17-018633:mdna:37]
|  |  | Year Ended |  |  | Year Ended |  |
| Net Revenues |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 303,617 |  |  | $ | 237,933 |  |  | $ | 65,684 |  |  |  | 27.6 | % |  | $ | 237,933 |  |  | $ | 238,748 |  |  | $ | (815 | ) |  |  | (0.3 | )% |
| Other |  |  | 24,530 |  |  |  | 44,455 |  |  |  | (19,925 | ) |  |  | (44.8 | )% |  |  | 44,455 |  |  |  | 31,931 |  |  |  | 12,524 |  |  |  | 39.2 | % |
| Total Americas |  |  | 328,147 |  |  |  | 282,388 |  |  |  | 45,759 |  |  |  | 16.2 | % |  |  | 282,388 |  |  |  | 270,679 |  |  |  | 11,709 |  |  |  | 4.3 | % |
| Percentage of net revenue |  |  | 54.9 | % |  |  | 53.4 | % |  |  |  |  |  |  |  |  |  |  | 53.4 | % |  |  | 49.0 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 216,015 |  |  |  | 196,588 |  |  |  | 19,427 |  |  |  | 9.9 | % |  |  | 196,588 |  |  |  | 223,368 |  |  |  | (26,780 | ) |  |  | (12.0 | )% |
| Percentage of net revenue |  |  | 36.1 | % |  |  | 37.2 | % |  |  |  |  |  |  |  |  |  |  | 37.2 | % |  |  | 40.4 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 53,956 |  |  |  | 49,413 |  |  |  | 4,543 |  |  |  | 9.2 | % |  |  | 49,413 |  |  |  | 58,893 |  |  |  | (9,480 | ) |  |  | (16.1 | )% |
| Percentage of net revenue |  |  | 9.0 | % |  |  | 9.4 | % |  |  |  |  |  |  |  |  |  |  | 9.4 | % |  |  | 10.7 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 598,118 |  |  | $ | 528,389 |  |  | $ | 69,729 |  |  |  | 13.2 | % |  | $ | 528,389 |  |  | $ | 552,940 |  |  | $ | (24,551 | ) |  |  | (4.4 | )% |

[0001564590-17-018633:mdna:38]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEMs, and direct sales.  Revenue through our distributor channel was 49% of total product revenue in fiscal years 2017 and 2016 and 47% of total product revenue in fiscal 2015.

[0001564590-17-018633:mdna:39]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001564590-17-018633:mdna:40]
Cost of Revenues and Gross Profit

[0001564590-17-018633:mdna:41]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenues for the fiscal years 2017, 2016 and 2015 (dollars in thousands):

[0001564590-17-018633:mdna:42]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 233,732 |  |  | $ | 186,725 |  |  | $ | 47,007 |  |  |  | 25.2 | % |  | $ | 186,725 |  |  | $ | 193,028 |  |  | $ | (6,303 | ) |  |  | (3.3 | )% |
| Percentage of product revenue |  |  | 51.8 | % |  |  | 47.2 | % |  |  |  |  |  |  |  |  |  |  | 47.2 | % |  |  | 46.2 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 90,753 |  |  |  | 84,063 |  |  |  | 6,690 |  |  |  | 8.0 | % |  |  | 84,063 |  |  |  | 86,709 |  |  |  | (2,646 | ) |  |  | (3.1 | )% |
| Percentage of service revenue |  |  | 61.9 | % |  |  | 63.2 | % |  |  |  |  |  |  |  |  |  |  | 63.2 | % |  |  | 64.3 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 324,485 |  |  | $ | 270,788 |  |  | $ | 53,697 |  |  |  | 19.8 | % |  | $ | 270,788 |  |  | $ | 279,737 |  |  | $ | (8,949 | ) |  |  | (3.2 | )% |
| Percentage of net revenue |  |  | 54.3 | % |  |  | 51.2 | % |  |  |  |  |  |  |  |  |  |  | 51.2 | % |  |  | 50.6 | % |  |  |  |  |  |  |  |  |

[0001564590-17-018633:mdna:43]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001564590-17-018633:mdna:44]
Product gross profit increased to $233.7 million for the year-ended June 30, 2017, from $186.7 million in the corresponding period of fiscal 2016.  Product gross profit for the year-ended June 30, 2017, was favorably impacted by an increase in product revenue of $65.7 million due primarily to the acquisition of the WLAN Business, lower amortization of developed technology intangibles of $8.3 million and more favorable manufacturing costs due to cost reduction efforts and lower warranty charges of $2.2 million.  The increases in product gross profit were partially offset by integration costs of $5.0 million primarily related to excess inventory charges related to the discontinuance of certain product lines due to the WLAN Business acquisition and increased royalty charges of $2.6 million.

[0001564590-17-018633:mdna:45]
Product gross profit decreased to $186.7 million for the year-ended June 30, 2016, from $193.0 million in the corresponding period of fiscal 2015.  Product gross profit for the year-ended June 30, 2016, was unfavorably impacted by a decrease in product revenue of $22.6 million, offset by lower amortization of developed technology intangibles of $2.3 million, lower royalty charges of $1.9 million and warranty charges of $0.8 million.

[0001564590-17-018633:mdna:46]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts.

[0001564590-17-018633:mdna:47]
Service gross profit increased to $90.8 million for the year-ended June 30, 2017, from $84.1 million in the corresponding period of fiscal 2016, primarily due to an increase in service revenue of $6.7 million related to the acquisition of the WLAN Business and the increased number of service contracts acquired.

[0001564590-17-018633:mdna:48]
Service gross profit decreased to $84.1 million for the year-ended June 30, 2016, from $86.7 million in the corresponding period of fiscal 2015, primarily due to a decrease in service revenue of $2.0 million and increased operating expenses, primarily professional fees of $0.6 million.

[0001564590-17-018633:mdna:49]
Operating Expenses

[0001564590-17-018633:mdna:50]
The following table presents operating expenses and operating income (dollars in thousands):

[0001564590-17-018633:mdna:51]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 93,724 |  |  | $ | 78,721 |  |  | $ | 15,003 |  |  |  | 19.1 | % |  | $ | 78,721 |  |  | $ | 93,447 |  |  | $ | (14,726 | ) |  |  | (15.8 | )% |
| Sales and marketing |  |  | 162,927 |  |  |  | 150,806 |  |  |  | 12,121 |  |  |  | 8.0 | % |  |  | 150,806 |  |  |  | 169,299 |  |  |  | (18,493 | ) |  |  | (10.9 | )% |
| General and administrative |  |  | 37,864 |  |  |  | 37,675 |  |  |  | 189 |  |  |  | 0.5 | % |  |  | 37,675 |  |  |  | 42,092 |  |  |  | (4,417 | ) |  |  | (10.5 | )% |
| Acquisition and integration costs |  |  | 13,105 |  |  |  | 1,145 |  |  |  | 11,960 |  |  |  | 1,044.5 | % |  |  | 1,145 |  |  |  | 10,205 |  |  |  | (9,060 | ) |  |  | (88.8 | )% |
| Restructuring and related charges, net of reversals |  |  | 8,896 |  |  |  | 10,990 |  |  |  | (2,094 | ) |  |  | (19.1 | )% |  |  | 10,990 |  |  |  | 9,819 |  |  |  | 1,171 |  |  |  | 11.9 | % |
| Amortization of intangibles |  |  | 8,702 |  |  |  | 17,001 |  |  |  | (8,299 | ) |  |  | (48.8 | )% |  |  | 17,001 |  |  |  | 17,869 |  |  |  | (868 | ) |  |  | (4.9 | )% |
| Total operating expenses |  | $ | 325,218 |  |  | $ | 296,338 |  |  | $ | 28,880 |  |  |  | 9.7 | % |  | $ | 296,338 |  |  | $ | 342,731 |  |  | $ | (46,393 | ) |  |  | (13.5 | )% |

[0001564590-17-018633:mdna:52]
The following table highlights our operating expenses and operating loss as a percentage of net revenues:

[0001564590-17-018633:mdna:53]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Research and development |  |  | 15.7 | % |  |  | 14.9 | % |  |  | 16.9 | % |
| Sales and marketing |  |  | 27.2 | % |  |  | 28.5 | % |  |  | 30.6 | % |
| General and administrative |  |  | 6.3 | % |  |  | 7.1 | % |  |  | 7.6 | % |
| Acquisition and integration costs |  |  | 2.2 | % |  |  | 0.2 | % |  |  | 1.8 | % |
| Restructuring charge, net of reversals |  |  | 1.5 | % |  |  | 2.1 | % |  |  | 1.8 | % |
| Amortization of intangibles |  |  | 1.5 | % |  |  | 3.2 | % |  |  | 3.2 | % |
| Total operating expenses |  |  | 54.4 | % |  |  | 56.1 | % |  |  | 62.0 | % |
| Operating loss |  |  | (0.1 | )% |  |  | (4.8 | )% |  |  | (11.4 | )% |

[0001564590-17-018633:mdna:54]
Research and Development Expenses

[0001564590-17-018633:mdna:55]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-17-018633:mdna:56]
Research and development expenses increased by $15.0 million or 19.1% for fiscal 2017 as compared to fiscal 2016. The increase in spending was primarily a result of the acquisition of the WLAN Business during fiscal 2017, and consists of $11.7 million of personnel costs, which includes compensation, benefits and non-cash stock based compensation, $1.3 million of technology and facility costs, $1.2 million of consulting and contract projects and $0.8 million of supplies and equipment costs.

[0001564590-17-018633:mdna:57]
Research and development expenses decreased by $14.7 million or 15.8% for fiscal 2016 as compared to fiscal 2015. The decrease in spending was related to $11.6 million of personnel costs, which includes compensation, benefits and non-cash stock based compensation, $1.6 million in reduced supplies and equipment costs, $1.2 million in depreciation and $0.3 million of other costs.

[0001564590-17-018633:mdna:58]
Sales and Marketing Expenses

[0001564590-17-018633:mdna:59]
Sales and marketing expenses consist of salaries, commissions and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001564590-17-018633:mdna:60]
Sales and marketing expenses increased by $12.1 million or 8.0% for the year-ended June 30, 2017, as compared to the corresponding period of fiscal 2016.  The increase in sales and marketing expenses during fiscal 2017 was primarily a result of the acquisition of the WLAN Business during fiscal 2017, and consists of higher personnel costs including benefits and non-cash stock compensation of $9.2 million, $1.8 million in travel costs and $1.1 million in additional professional fees.

[0001564590-17-018633:mdna:61]
Sales and marketing expenses decreased by $18.5 million or 10.9% for the year-ended June 30, 2016 as compared to the corresponding period of fiscal 2015.  The decrease in sales and marketing expenses during fiscal 2016 was primarily due to lower personnel costs including benefits and non-cash stock compensation of $11.5 million, $3.1 million in reduced travel costs, $2.4 million in reduced occupancy expense and $1.9 million in reduced sales conferences and related costs.  In addition, sales and marketing professional fees decreased by $0.8 million during the period.

[0001564590-17-018633:mdna:62]
General and Administrative Expenses

[0001564590-17-018633:mdna:63]
General and administrative expense consists primarily of personnel costs, legal and professional service costs, share-based compensation, travel and facilities and information technology costs.

[0001564590-17-018633:mdna:64]
General and administrative expenses increased by $0.2 million or 0.5% for the year-ended June 30, 2017, as compared to the corresponding period of fiscal 2016.  The increase in general and administrative expenses was primarily due to increases of $1.1 million in professional fees, $0.6 million in recruiting fees, and $0.2 million of taxes and franchise fees. The increase was partial offset by $0.9 million in lower personnel costs related to our reduced headcount and $0.6 million in our provision for bad debts.

[0001564590-17-018633:mdna:65]
General and administrative expenses decreased by $4.4 million or 10.5% for the year-ended June 30, 2016 as compared to the corresponding period of fiscal 2015.  The decrease in general and administrative expenses was primarily due to $3.6 million in lower personnel costs related to our reduced headcount, as well as reduced professional fees of $1.9 million and other expenses of $0.4 million.

[0001564590-17-018633:mdna:66]
Acquisition and Integration Costs

[0001564590-17-018633:mdna:67]
As a result of our acquisitions of the WLAN Business in fiscal 2017 and Enterasys in fiscal 2014, we incurred $13.1 million, $1.1 million and $10.2 million of acquisition and integration costs in fiscal years 2017, 2016 and 2015, respectively.

[0001564590-17-018633:mdna:68]
For fiscal 2017, we incurred $2.1 million of acquisition and $6.6 million of integration costs related to the WLAN Business acquisition.  We also incurred acquisition costs of $2.2 million and $2.2 million related to our acquisition of Avaya Networking on July 14, 2017, and anticipated acquisition of Brocade Data, respectively.

[0001564590-17-018633:mdna:69]
For fiscal 2016 and 2015, the entire $1.1 million and $10.2 million, respectively, of expense was related to integration costs of the Enterasys acquisition.   The lower fiscal 2016 integration expenses were due to winding down of integration activities associated with the acquisition, which included lower severance and termination costs, information systems applications costs and consulting fees.

[0001564590-17-018633:mdna:70]
Restructuring and Related Charges, Net of Reversals

[0001564590-17-018633:mdna:71]
As of June 30, 2017, restructuring liabilities were $4.1 million and consisted primarily of obligations for estimated future obligations for non-cancelable lease payments for excess facilities, and for severance payments and benefits. The restructuring liability is recorded in "Other accrued liabilities" and “Other long-term liabilities” on the consolidated balance sheets. During fiscal years 2017, 2016 and 2015, we recorded restructuring charges and related charges, net of reversals, of $8.9 million, $11.0 million and $9.8 million, respectively.

[0001564590-17-018633:mdna:72]
Fiscal year 2017

[0001564590-17-018633:mdna:73]
Pursuant to the WLAN Business acquisition from Zebra, we assumed a facility lease located at 6480 Via del Oro in San Jose, California (“Via del Oro”) and transferred our headquarters from Rio Robles Drive in San Jose, California (“Rio Robles”) to Via del Oro.  We consolidated our existing workforce from our previous headquarters with employees assumed from Zebra to the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to our move from the Rio Robles facility and abandonment of all leasehold improvements, we accelerated the amortization of the remaining leasehold improvements for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  We recorded accelerated amortization expense for the year ended June 30, 2017 of $2.6 million and it is reflected in "Restructuring and related charges, net of reversals" in the condensed consolidated statements of operations.

[0001564590-17-018633:mdna:74]
We entered into a sublease agreement related to our Rio Robles facility during the third quarter of fiscal 2017 for the remaining duration of the lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease. The net adjustments, including modifications to our future obligations for non-cancellable lease payments and related future subleasing income resulted in additional charges of $2.0 million during fiscal 2017. The excess facilities payments will continue through fiscal year 2023.

[0001564590-17-018633:mdna:75]
In anticipation of the acquisition of Avaya Networking on July 14, 2017 and our anticipated acquisition of the Brocade Data business, we reoccupied the majority of the previously exited space at our Salem, New Hampshire location during our fiscal fourth quarter to accommodate the growth in headcount and lab facility requirements. This action resulted in a reversal of prior restructuring expense accruals of $1.3 million

[0001564590-17-018633:mdna:76]
We also implemented a reduction-in-force which affected 90 employees.  We recorded severance and benefits charges of $5.6 million during the year ended June 30, 2017.  Cash payments of $3.8 million have been made with the balance of cash payments expected to be paid by the end of the second quarter of fiscal 2018.

[0001564590-17-018633:mdna:77]
Fiscal year 2016

[0001564590-17-018633:mdna:78]
During fiscal 2016, we incurred $11.0 million of restructuring charges. Excess facilities charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and contract termination charges of $5.4 million, acceleration of depreciation of leasehold improvements of $4.5 million, professional fees of $1.0 million and other expenses of $0.1 million.

[0001564590-17-018633:mdna:79]
Significant restructuring charges incurred during 2016, by location, included $1.8 million of charges for excess facilities pertaining to the estimated future obligations for non-cancelable lease payments at Rio Robles.  This represented 39% of the San Jose leased space.  We amended our facility lease at our North Carolina location and exited excess space while recording $4.1 million of charges, which included $3.1 million in accelerated depreciation of leasehold improvements. This action represented 36% of the North Carolina location lease space. We recorded $4.4 million of charges for excess facilities at our Salem location, which included $1.3 million in accelerated depreciation of leasehold improvements.  This action represented 27% of the Salem lease space.

[0001564590-17-018633:mdna:80]
Fiscal year 2015

[0001564590-17-018633:mdna:81]
During the fourth quarter of fiscal 2015, we implemented a plan to reduce costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. We have expensed all costs associated with this initiative.  The restructuring liability related to this initiative was fully paid as of June 30, 2016.

[0001564590-17-018633:mdna:82]
Amortization of Intangibles

[0001564590-17-018633:mdna:83]
During fiscal 2017, 2016 and 2015, we recorded $8.7 million, $17.0 million and $17.9 million, respectively, of amortization expenses in operating expenses primarily for certain intangibles related to the acquisition of Enterasys and the WLAN Business.  The lower amortization expense in fiscal 2017 is due to the Enterasys intangible assets becoming fully amortized during fiscal 2017.

[0001564590-17-018633:mdna:84]
Interest Income

[0001564590-17-018633:mdna:85]
Interest income was $0.7 million, $0.1 million and $0.5 million in fiscal years 2017, 2016 and 2015, respectively, representing an increase of $0.6 million in fiscal 2017 from fiscal 2016, and a decrease of $0.4 million in fiscal 2016 from fiscal 2015.  The increase in fiscal 2017 was due to higher cash balances and interest earned on notes receivable. The decrease in interest income in fiscal 2016 and 2015 was due to a decrease in the investment balances to fund debt reduction.

[0001564590-17-018633:mdna:86]
Interest Expense

[0001564590-17-018633:mdna:87]
We had $4.1 million, $3.1 million and $3.2 million of interest expense for fiscal 2017, 2016 and 2015, respectively.  Interest expense in fiscal years 2017, 2016 and 2015 was primarily related to our Credit Facility.  The increase in interest expense for fiscal 2017 is related to our increased borrowings to finance the WLAN Business acquisition in October 2016.

[0001564590-17-018633:mdna:88]
Other Income (Loss), net

[0001564590-17-018633:mdna:89]
We incurred other loss of less than $0.1 million in fiscal 2017, other income of $1.0 million in fiscal 2016, and other loss of $1.2 million in fiscal 2015.  Other income (loss) in the respective periods was primarily due to the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-17-018633:mdna:90]
Provision for Income Taxes

[0001564590-17-018633:mdna:91]
We are subject to income taxes in the United States and numerous foreign jurisdictions.  Our effective tax rate differs from the U.S. federal statutory rate of 35% primarily due to the impact of state taxes, foreign operations which are generally taxed at lower statutory rates and the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions.  For the fiscal years ended June 30, 2017, 2016 and 2015, we recorded income tax provisions of $4.3 million, $4.3 million and $4.8 million, respectively.  The effective tax rates for fiscal years ended June 30, 2017, 2016 and 2015, were 103.9%, 15.7% and 7.2%, respectively.

[0001564590-17-018633:mdna:92]
For the fiscal years ended June 30, 2017, 2016 and 2015, the majority of our tax provision related to taxes on our foreign operations as well as state taxes due to the full valuation allowance on our U.S. and certain foreign deferred tax assets.

[0001564590-17-018633:mdna:93]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 35% and for further explanation of our provision for income taxes, see Note 9 to the consolidated financial statements.

[0001564590-17-018633:mdna:94]
Critical Accounting Policies and Estimates

[0001564590-17-018633:mdna:95]
Our significant accounting policies are more fully described in Note 3 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001564590-17-018633:mdna:96]
Revenue Recognition

[0001564590-17-018633:mdna:97]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for our products. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and the collection of the sales proceeds is reasonably assured. In instances where any of the criteria for revenue recognition are not met, we defer revenue until all criteria have been met.

[0001564590-17-018633:mdna:98]
Product revenue from our value-added resellers, non-stocking distributors and end-user customers is recognized at the time of shipment, provided that all of the foregoing revenue recognition requirements have been satisfied.  We generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits. Accordingly, we recognize revenue upon transfer of title and risk of loss to the customer, which is generally upon shipment. We maintain estimated accruals and allowances for sales incentives and other programs that we may make available to our partners, based on historical experience or applicable contractual terms. Sales taxes collected from customers are excluded from revenues.  Shipping costs are included in cost of product revenues.

[0001564590-17-018633:mdna:99]
We also sell our products to distributors that stock inventory and sell to resellers. We defer recognition of revenue on all sales to our stocking distributors until the distributors have sold the products, as evidenced by sales data that the distributors provide to us. We grant stocking distributors certain price protection rights and the right to return a portion of unsold inventory for the purpose of stock rotation. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. We also provide stocking distributors with credits for changes in selling prices based on competitive conditions, and provide funding for our distributors and their resellers to perform marketing development activities. We maintain estimated accruals and allowances for these exposures based upon our contractual obligations. Our marketing development channel programs do not meet the criteria for recognizing the costs as marketing expenses and therefore these costs are accrued as a reduction to revenue in the same period that the products are sold.

[0001564590-17-018633:mdna:100]
Revenue from maintenance contracts is deferred and recognized ratably over the contractual service period, which is typically from one to two years. Professional service revenue is recognized upon delivery or completion of performance.

[0001564590-17-018633:mdna:101]
Our networking products are tangible products that contain software and non-software components that function together to deliver the tangible product's essential functionality. Our sales arrangements may contain multiple deliverables comprised of our tangible products, standalone software licenses, and maintenance offerings depending on the distribution sales channel through which the products are sold and the requirements of our customers. We recognize revenue for our multiple deliverable arrangements in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. The industry-specific software revenue recognition guidance does not apply to the sales of our tangible products.  Software revenue guidance is applied to sales of our standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001564590-17-018633:mdna:102]
Pursuant to the guidance of the accounting standard for multiple-deliverable revenue arrangements, we allocate the total arrangement consideration to each separable element of an arrangement based on the relative selling price of each element.  We determine the standalone selling price for each element based on a selling price hierarchy. Under the selling price hierarchy, the selling price for each deliverable is based on our vendor-specific objective evidence ("VSOE") of selling price, which is determined by a substantial majority of our historical standalone sales transactions for a product or service falling within a reasonable range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, we determine the best estimate of standalone selling price (“ESP”) for a product or service by considering several factors including, but not limited to, the 12-month historical median sales price, sales channels, geography, gross margin consistency, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, we apply management judgment to determine the best estimate of selling price through consultation with and formal approval by our management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of all other deliverables is determined by using ESP. We regularly review VSOE, TPE and ESP for all of our products and services and maintain internal controls over the establishment and updates of these estimates.

[0001564590-17-018633:mdna:103]
Pursuant to the software revenue recognition accounting standard, we continue to recognize revenue for software using the residual method for our sales of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the multiple deliverable arrangement, we recognize revenue in accordance with our policies for product, software, and maintenance revenue recognition.

[0001564590-17-018633:mdna:104]
We provide an allowance for sales returns based on our historical returns, analysis of credit memo data and our return policies. The allowance for sales returns was $0.5 million and $1.6 million as of June 30, 2017 and 2016, respectively, for estimated future returns that were recorded as a reduction of our accounts receivable. If the historical data that we use to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. We estimate and adjust this allowance at each balance sheet date.

[0001564590-17-018633:mdna:105]
Goodwill

[0001564590-17-018633:mdna:106]
We assess goodwill for impairment annually during the fourth quarter of the fiscal year (which begins on April 1) or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. We have determined that we have one reporting unit. To test goodwill for impairment, we have opted to bypass the qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value and proceed directly to the two-step goodwill impairment test. Under the two-step goodwill impairment test, we in the first step, compare the estimated fair value of a reporting unit to its carrying value. If the fair value of the reporting unit exceeds the carrying value, no impairment loss is recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which we determine the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

[0001564590-17-018633:mdna:107]
We completed our annual goodwill impairment test in the fourth quarter of fiscal 2017 and determined there was no impairment as the fair value of the reporting unit exceeded its carrying value.

[0001564590-17-018633:mdna:108]
Business Combinations

[0001564590-17-018633:mdna:109]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-17-018633:mdna:110]
Share-based Payments

[0001564590-17-018633:mdna:111]
We use the Black-Scholes option-pricing model to determine the fair value of option grants other than option grants, with market or performance conditions, options assumed as part of the Enterasys acquisition, and share purchase options under our Employee Stock Purchase Plan (“ESPP”) on the date of grant with the weighted average assumptions. We use the Monte-Carlo simulation model to determine the fair value and the derived service period of option grants, with market, performance or service conditions or combinations of those conditions, on the date of grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of purchase options under our ESPP represents the contractual life of the ESPP purchase period. The risk-free rate is based upon the estimated life of each option and ESPP award is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility of our stock. We do not currently pay cash dividends on our common stock and do not anticipate doing so in the foreseeable future. Accordingly, our expected dividend yield is zero. In fiscal 2016, our estimated forfeiture rates based on historical forfeiture experiences were 19% for executives and 13% for non-executive employees.  Beginning in fiscal 2017, we no longer estimate forfeitures at the time of grant but rather record actual forfeitures at the time of separation.  We use the straight-line method for expense attribution, and we only recognize expense for those shares expected to vest.

[0001564590-17-018633:mdna:112]
Restructuring Charges

[0001564590-17-018633:mdna:113]
We recognize a liability for exit and disposal activities when the liability is incurred.  A liability for post-employment benefits, including severance, is recorded upon attainment of certain criteria including when payment is probable, the amount is reasonably estimable, and the obligation relates to rights that have vested or accumulated.  Facilities consolidation charges are calculated using estimates and are based upon the remaining future lease commitments for vacated facilities from the date of facility consolidation, net of estimated future sublease income. The estimated costs of vacating these leased facilities are based on market information and trend analysis.

[0001564590-17-018633:mdna:114]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives.  Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provision.

[0001564590-17-018633:mdna:115]
New Accounting Pronouncements

[0001564590-17-018633:mdna:116]
See Note 4 of the accompanying consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-17-018633:mdna:117]
Liquidity and Capital Resources

[0001564590-17-018633:mdna:118]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001564590-17-018633:mdna:119]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Cash and cash equivalent |  | $ | 130,450 |  |  | $ | 94,122 |  |
| Total cash and investments |  | $ | 130,450 |  |  | $ | 94,122 |  |
| Working capital |  | $ | 69,145 |  |  | $ | 17,442 |  |

[0001564590-17-018633:mdna:120]
As of June 30, 2017, our principal sources of liquidity consisted of cash and cash equivalents of $130.5 million, accounts receivable, net of $120.8 million and availability of borrowings from the Revolving Facility of $39.1 million.  We anticipate that our principal uses of cash for fiscal 2018 will include the acquisition of Avaya’s fabric-based secure networking solutions and network security solutions business and our anticipated acquisition of Brocade’s data center technology business, repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment.  We believe that our $130.5 million of cash and cash equivalents at June 30, 2017, cash flows from operations along with the availability of additional borrowings from our Credit Facility, as amended, will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-17-018633:mdna:121]
During the second quarter of fiscal 2017, we entered into an Amended and Restated Credit Agreement (the “Credit Facility”) with Silicon Valley Bank, as administrative agent and collateral agent, and the financial institutions that are a party thereto as lenders (“Lenders”).   The Credit Facility provided for a five-year $90.5 million term loan (“Term Loan”) and a five-year $50.0 million revolving loan facility (“Revolver”), which included a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Facility among other things, amended and restated our previous credit facility.  The borrowings under the Credit Facility during fiscal 2017 were used to acquire the WLAN Business as more fully described in Note 2. Business Combinations, in the Notes to Consolidated Financial Statements.

[0001564590-17-018633:mdna:122]
On July 14, 2017, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amends the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and Lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the Term Loan facilities in a principal amount of up to $183.7 million and (b) the Revolver  in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver until July 2022, (iii) provides for an uncommitted additional incremental loan facility in a principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as Lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed an additional $80.0 million under the Term Loan which was used to fund the purchase of the Avaya Networking business (see Note 14. Subsequent Events, in the Notes to Consolidated Financial Statements).

[0001564590-17-018633:mdna:123]
Key Components of Cash Flows and Liquidity

[0001564590-17-018633:mdna:124]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001564590-17-018633:mdna:125]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Net cash provided by operating activities |  | $ | 59,283 |  |  | $ | 30,366 |  |  | $ | 37,423 |  |
| Net cash (used in) provided by investing activities |  |  | (71,752 | ) |  |  | (5,327 | ) |  |  | 21,598 |  |
| Net cash provided by (used in) financing activities |  |  | 48,708 |  |  |  | (6,738 | ) |  |  | (52,470 | ) |
| Foreign currency effect on cash |  |  | 89 |  |  |  | (404 | ) |  |  | (3,516 | ) |
| Net increase in cash and cash equivalents |  | $ | 36,328 |  |  | $ | 17,897 |  |  | $ | 3,035 |  |

[0001564590-17-018633:mdna:126]
Cash and cash equivalents were $130.5 million at June 30, 2017, representing an increase of $36.4 million from $94.1 million at June 30, 2016.  Cash and cash equivalents increased primarily due to cash provided by operations of $59.3 million, and cash provided by financing activities of $48.7 million, offset by cash used in investing activities of $71.8 million.

[0001564590-17-018633:mdna:127]
Cash and cash equivalents were $94.1 million at June 30, 2016, representing an increase of $17.9 million from $76.2 million at June 30, 2015.  Cash and cash equivalents increased primarily due to cash provided by operations of $30.4 million, offset by cash used in investing activities of $5.3 million and cash used in financing activities of $6.7 million.

[0001564590-17-018633:mdna:128]
Net Cash Provided by Operating Activities

[0001564590-17-018633:mdna:129]
Cash provided by operating activities during fiscal 2017 was $59.3 million, compared to cash provided by operating activities of $30.4 million in fiscal 2016, an increase of $28.9 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2017 were decreases in inventory and prepaid expenses, and increases to accrued compensation and benefits, deferred revenues and other liabilities in addition to non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.   These amounts were partially offset by an increase in accounts receivables and our current year’s net loss of $8.5 million.

[0001564590-17-018633:mdna:130]
Cash provided by operating activities during fiscal 2016 was $30.4 million, compared to $37.4 million in fiscal 2015, a decrease of $7.0 million.  The net loss of $31.9 million was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.  Other contributing factors to cash provided by operating activities for the year ended June 30, 2016 were decreases in accounts receivables and inventory as a source of cash offset by declines in the balance of our deferred revenues and accounts payable which decreased cash.

[0001564590-17-018633:mdna:131]
Net Cash (Used in) Provided by Investing Activities

[0001564590-17-018633:mdna:132]
Cash used in investing activities during fiscal 2017 was $71.8 million, was mainly due to our acquisition of the WLAN Business of $51.1 million, deposits for future acquisitions of $10.2 million and capital expenditures of $10.4 million.

[0001564590-17-018633:mdna:133]
Cash used in investing activities during fiscal 2016 totaled $5.3 million, was mainly due to capital expenditures.

[0001564590-17-018633:mdna:134]
Net cash Provided by (Used in) Financing Activities

[0001564590-17-018633:mdna:135]
Cash provided by financing activities during fiscal 2017 was $48.7 million due primarily to $48.2 million in borrowings of debt pursuant to our WLAN Business acquisition, $11.8 million in proceeds from the sale of our common stock, primarily through the exercise of stock options and our Employee Stock Purchase Plan, partially offset by repayments of debit of $10.0 million.

[0001564590-17-018633:mdna:136]
Cash flow used in financing activities during fiscal 2016 was $6.7 million mainly due to $26.4 million in repayments of debt, offset by borrowings of $15.0 million on the Revolving Facility for working capital requirements and proceeds from the sale of common stock of $4.6 million primarily through our Employee Stock Purchase Plan.

[0001564590-17-018633:mdna:137]
Contractual Obligations

[0001564590-17-018633:mdna:138]
The following summarizes our contractual obligations at June 30, 2017, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-17-018633:mdna:139]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 93,712 |  |  | $ | 12,444 |  |  | $ | 38,463 |  |  | $ | 42,805 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 11,600 |  |  |  | 3,967 |  |  |  | 5,868 |  |  |  | 1,765 |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 83,234 |  |  |  | 83,234 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable purchase commitments |  |  | 21,474 |  |  |  | 4,974 |  |  |  | 10,500 |  |  |  | 6,000 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 54,794 |  |  |  | 12,949 |  |  |  | 20,870 |  |  |  | 14,813 |  |  |  | 6,162 |  |
| Other liabilities |  |  | 880 |  |  |  | 196 |  |  |  | 391 |  |  |  | 293 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 265,694 |  |  | $ | 117,764 |  |  | $ | 76,092 |  |  | $ | 65,676 |  |  | $ | 6,162 |  |

[0001564590-17-018633:mdna:140]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast.  Inventory purchase commitments were $83.2 million as of June 30, 2017, an increase of $19.5 million from $63.7 million as of June 30, 2016.

[0001564590-17-018633:mdna:141]
Non-cancelable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001564590-17-018633:mdna:142]
Other liabilities include our commitments towards debt related fees and specific arrangements other than inventory.

[0001564590-17-018633:mdna:143]
The amounts in the table above exclude immaterial income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of the settlement.

[0001564590-17-018633:mdna:144]
We did not have any material commitments for capital expenditures as of June 30, 2017.

[0001564590-17-018633:mdna:145]
Off-Balance Sheet Arrangements

[0001564590-17-018633:mdna:146]
We did not have any off-balance sheet arrangements as of June 30, 2017.

[0001564590-17-018633:mdna:147]
Capital Resources and Financial Condition

[0001564590-17-018633:mdna:148]
As of June 30, 2017, we had $130.5 million in cash and cash equivalents.  We believe that our current cash, cash equivalents, cash available from future operations along with the availability of borrowings from our Credit Facility, as amended, will enable us to meet our working capital requirements for at least the next 12 months.
