# EXTR notes — 0001564590-17-018633


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-17-018633:notes:1]
1. Description of Business and Basis of Presentation

[0001564590-17-018633:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-17-018633:notes:3]
Fiscal Year

[0001564590-17-018633:notes:4]
The Company uses a fiscal calendar year ending on June 30.  All references herein to  “fiscal 2017” or “2017”; “fiscal 2016” or “2016”; “fiscal 2015” or “2015” represent the fiscal years ending 2017, 2016 and 2015, respectively.

[0001564590-17-018633:notes:5]
Principles of Consolidation

[0001564590-17-018633:notes:6]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-17-018633:notes:7]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001564590-17-018633:notes:8]
Accounting Estimates

[0001564590-17-018633:notes:9]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-018633:notes:10]
2. Business Combinations

[0001564590-17-018633:notes:11]
On October 28, 2016, the Company completed the acquisition of the wireless local area network (“WLAN”) business (“WLAN Business”) from Zebra Technologies Corporation (“Zebra”).  Under the terms of the purchase agreement, the Company acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for an initial purchase price of $51.1 million.  Subsequent to year end, Zebra agreed to pay $1.6 million as a final settlement regarding all outstanding working capital claims of the Company, thereby reducing the net cash consideration to $49.5 million.  The $1.6 million is included in “Prepaid expenses and other current assets” in the consolidated balance sheet as of June 30, 2017.

[0001564590-17-018633:notes:12]
The acquisition has been accounted for using the acquisition method of accounting.  The purchase price allocation as of the Acquisition Date is set forth in the table below and reflects fair values. The fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of June 30, 2017.

[0001564590-17-018633:notes:13]
The following table below summarizes the final allocation as of June 30, 2017, of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-17-018633:notes:14]
|  | Preliminary Allocation as of October 26, 2016 |  |  | Adjustments |  |  | Final Allocation as of June 30, 2017 |  |
| Receivables, net | $ | 17,818 |  |  | $ | (3,182 | ) | (a) | $ | 14,636 |  |
| Inventory |  | 12,408 |  |  |  | 1,185 |  | (b) |  | 13,593 |  |
| Other current assets |  | 808 |  |  |  | — |  |  |  | 808 |  |
| Property and equipment |  | 1,780 |  |  |  | 1,379 |  | (c) |  | 3,159 |  |
| Identifiable intangible assets |  | 20,500 |  |  |  | (200 | ) | (d) |  | 20,300 |  |
| In-process research and development |  | 1,600 |  |  |  | (200 | ) | (d) |  | 1,400 |  |
| Other assets |  | 7,634 |  |  |  | — |  |  |  | 7,634 |  |
| Goodwill |  | 9,836 |  |  |  | (497 | ) |  |  | 9,339 |  |
| Deferred revenue |  | (13,533 | ) |  |  | (626 | ) | (e) |  | (14,159 | ) |
| Other liabilities |  | (7,763 | ) |  |  | 562 |  | (f) |  | (7,201 | ) |
| Total purchase price allocation | $ | 51,088 |  |  | $ | (1,579 | ) |  | $ | 49,509 |  |

[0001564590-17-018633:notes:15]
The purchase price has been allocated based on the fair value of assets acquired and liabilities assumed as of the acquisition date.  The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach.  The fair value of property and equipment was determined using a cost approach.  The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay a third party to assume the obligation.  Valuations of the intangible assets were valued using income approaches based on projections provided by management, which we consider to be Level 3 inputs.

[0001564590-17-018633:notes:16]
The changes during the period in the table above is as follows: a) obtainment of information on accounts receivable and related reserves of matters that existed as of the acquisition date; b) additional receipts of products that existed as of the acquisition date; c) additional fixed assets acquired in India as of the acquisition date; d) revised net realizable value based on finalization of valuation; e) additional maintenance contracts identified and transferred from Zebra to the Company that existed as of the acquisition date; f) additional employee benefits assumed that existed as of the acquisition date.

[0001564590-17-018633:notes:17]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001564590-17-018633:notes:18]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |  |
| Developed technology |  | 6 |  | $ | 14,400 |  |
| Customer relationships |  | 4 |  |  | 3,300 |  |
| Trademarks |  | 5 |  |  | 2,600 |  |
| Total identifiable intangible assets |  |  |  | $ | 20,300 |  |

[0001564590-17-018633:notes:19]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the condensed consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the WLAN Business.  The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001564590-17-018633:notes:20]
The Company also has an indefinite lived asset of $1.4 million which represents the fair value of in-process research and development activities.  Once the related research and development efforts are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or become a finite lived asset and apply the appropriate accounting accordingly.

[0001564590-17-018633:notes:21]
The results of operations of the WLAN Business are included in the consolidated results of operations beginning October 28, 2016.  The WLAN Business revenue for fiscal 2017 was $86.0 million and has been incorporated into the revenue of the Company.  The associated expenses of the WLAN Business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available. The Company incurred $2.1 million of acquisition and $6.6 million of integration-related expenses during the year ended June 30, 2017 included in "Acquisition and integration costs" on the consolidated statements of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and Information Technology consultants and companies.

[0001564590-17-018633:notes:22]
Pro forma financial information

[0001564590-17-018633:notes:23]
The following unaudited pro forma results of operations are presented as though the acquisition of the WLAN Business had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-17-018633:notes:24]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the earliest period presented, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-17-018633:notes:25]
The unaudited pro forma financial information for the year ended June 30, 2017, combines the results of Extreme for the year ended June 30, 2017, which include the results of the WLAN Business subsequent to the acquisition date, and the historical results of the WLAN Business for the four months ended October 28, 2016.

[0001564590-17-018633:notes:26]
The unaudited pro forma financial information for the year ended June 30, 2016, combines the historical results of Extreme for that period, with the historical results of the WLAN Business for the year ended June 30, 2016.

[0001564590-17-018633:notes:27]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0001564590-17-018633:notes:28]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Net revenues |  | $ | 641,390 |  |  | $ | 628,079 |  |
| Net income (loss) |  | $ | 7,380 |  |  | $ | (62,281 | ) |
| Net earnings (loss) per share - basic |  | $ | 0.07 |  |  | $ | (0.60 | ) |
| Net earnings (loss) per share - diluted |  | $ | 0.07 |  |  | $ | (0.60 | ) |
| Shares used in per share calculation - basic |  |  | 108,273 |  |  |  | 103,074 |  |
| Shares used in per share calculation - diluted |  |  | 111,472 |  |  |  | 103,074 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-17-018633:notes:29]
3. Summary of Significant Accounting Policies

[0001564590-17-018633:notes:30]
Revenue Recognition

[0001564590-17-018633:notes:31]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001564590-17-018633:notes:32]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP.  The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition

[0001564590-17-018633:notes:33]
Pursuant to the software revenue recognition accounting standard, the Company recognizes revenue for standalone software products (including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold) using the residual method, as VSOE has been established for undelivered elements (typically post contract support).

[0001564590-17-018633:notes:34]
The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company generally recognizes product revenue from its value-added resellers, non-stocking distributors and end-user customers at the time of shipment, provided that persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and collection of the sales proceeds is reasonably assured.  In instances where the criteria for revenue recognition are not met, revenue is deferred until all criteria have been met. Sales taxes collected from customers are excluded from revenues.

[0001564590-17-018633:notes:35]
The Company sells its products and maintenance contracts to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The Company defers recognition of revenue on all sales to its stocking distributors until the distributors sell the product, as evidenced by “sales-out” reports that the distributors provide.  The Company grants these distributors the right to return a portion of unsold inventory for the purpose of stock rotation and certain price protection rights. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction.  The Company also provides distributors with credits for changes in selling prices based on competitive conditions, and allows distributors to participate in cooperative marketing programs (See Deferred Distributors Revenue, Net of Cost of Sales to Distributors, below in this footnote for additional information).  The Company maintains estimated accruals and allowances for these exposures based upon the Company's historical experience.  In connection with cooperative advertising programs, if the Company does not meet the criteria for recognizing the expense as marketing expense the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001564590-17-018633:notes:36]
The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users. For product sales to non-stocking distributors and value-added resellers, the Company does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Accordingly, the Company recognizes revenue upon transfer of title and risk of loss or damage, generally upon shipment. In connection with cooperative advertising programs and certain price protection rights that may occur under contractual arrangements with its resellers, if the Company does not meet the criteria for recognizing the expense as marketing expense, the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001564590-17-018633:notes:37]
Allowance for Product Returns

[0001564590-17-018633:notes:38]
The Company provides an allowance for product returns based on its historical returns, analysis of credit memo data and its return policies.  The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors for which it has billed the customer for the product but has yet to recognize revenue. The allowance for product returns is a reduction of accounts receivable. If the historical data that the Company uses to calculate the estimated product returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. The allowance for product returns estimate is also impacted by the timing of the actual product return from the customer. The Company estimates and adjusts this allowance at each balance sheet date.

[0001564590-17-018633:notes:39]
The following table is a summary of our allowance for product returns (in thousands).

[0001564590-17-018633:notes:40]
| Description |  | Balance at beginning of period |  |  | Additions |  |  | Deductions |  |  | Balance at end of period |  |
| Year Ended June 30, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 1,609 |  |  | $ | 3,658 |  |  | $ | (4,725 | ) |  | $ | 542 |  |
| Year Ended June 30, 2016: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 1,080 |  |  | $ | 3,478 |  |  | $ | (2,949 | ) |  | $ | 1,609 |  |
| Year Ended June 30, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 2,700 |  |  | $ | 3,306 |  |  | $ | (4,926 | ) |  | $ | 1,080 |  |

[0001564590-17-018633:notes:41]
Allowance for Doubtful Accounts

[0001564590-17-018633:notes:42]
The Company maintains an allowance for doubtful accounts which reflects its best estimate of potentially uncollectible trade receivables.  The allowance is based on both specific and general reserves.  The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position.  Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience.  The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001564590-17-018633:notes:43]
The following table is a summary of the allowance for doubtful accounts (in thousands).

[0001564590-17-018633:notes:44]
| Description |  | Balance at beginning of period |  |  | Charges to bad debt expenses |  |  | Deductions (1) |  |  | Balance at end of period |  |
| Year Ended June 30, 2017: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,648 |  |  | $ | 323 |  |  | $ | (781 | ) |  | $ | 1,190 |  |
| Year Ended June 30, 2016: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,316 |  |  | $ | 834 |  |  | $ | (502 | ) |  | $ | 1,648 |  |
| Year Ended June 30, 2015: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 918 |  |  | $ | 940 |  |  | $ | (542 | ) |  | $ | 1,316 |  |

[0001564590-17-018633:notes:45]
| (1) | Uncollectible accounts written off, net of recoveries |

[0001564590-17-018633:notes:46]
Business Combinations

[0001564590-17-018633:notes:47]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price).  Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0001564590-17-018633:notes:48]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.

[0001564590-17-018633:notes:49]
Concentrations

[0001564590-17-018633:notes:50]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments.  The Company does not invest an amount exceeding 10% of its combined cash or cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001564590-17-018633:notes:51]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-17-018633:notes:52]
The following table sets forth major customers accounting for 10% or more of our net revenue:

[0001564590-17-018633:notes:53]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Tech Data Corporation |  |  | 15% |  |  |  | 17% |  |  |  | 15% |  |
| Jenne Corporation |  |  | 15% |  |  |  | 14% |  |  | * |  |
| Westcon Group Inc. |  |  | 11% |  |  |  | 14% |  |  |  | 15% |  |

[0001564590-17-018633:notes:54]
| * | Less than 10% of net revenue |

[0001564590-17-018633:notes:55]
The following table sets forth major customers accounting for 10% or more of our accounts receivable balance:

[0001564590-17-018633:notes:56]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Tech Data Corporation |  |  | 18% |  |  |  | 11% |  |  | * |  |
| Jenne Corporation |  |  | 12% |  |  | * |  |  | * |  |
| Westcon Group Inc. |  |  | 11% |  |  |  | 19% |  |  |  | 27% |  |

[0001564590-17-018633:notes:57]
| * | Less than 10% of accounts receivable |

[0001564590-17-018633:notes:58]
Cash and Cash Equivalents

[0001564590-17-018633:notes:59]
The following is a summary of Cash and cash equivalents (in thousands):

[0001564590-17-018633:notes:60]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Cash |  | $ | 126,159 |  |  | $ | 89,847 |  |
| Cash equivalents (consisting of available-sale-securities) |  |  | 4,291 |  |  |  | 4,275 |  |
| Total cash and cash equivalents |  | $ | 130,450 |  |  | $ | 94,122 |  |

[0001564590-17-018633:notes:61]
Available-for-Sale Securities

[0001564590-17-018633:notes:62]
The following is a summary of available-for-sale securities (in thousands):

[0001564590-17-018633:notes:63]
|  |  |  |  |  |  |  |  |  |  | Unrealized |  |  | Unrealized |  |
|  |  | Amortized |  |  |  |  |  |  | Holding |  |  | Holding |  |
|  |  | Cost |  |  | Fair Value |  |  | Gains |  |  | Losses |  |
| June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,291 |  |  | $ | 4,291 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,291 |  |  | $ | 4,291 |  |  | $ | — |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 4,291 |  |  | $ | 4,291 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,291 |  |  | $ | 4,291 |  |  | $ | — |  |  | $ | — |  |
| June 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |
|  |  | $ | 4,275 |  |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |

[0001564590-17-018633:notes:64]
The Company did not have any available-for sale investments in debt securities at June 30, 2017 or 2016.

[0001564590-17-018633:notes:65]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with maturities of greater than three months, but less than one year at the balance sheet date are classified as Short-term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. The Company diversifies its investments by limiting its holdings with any individual issuer except for direct obligations of the United States government, securities issued by agencies of the United States government and money market funds.

[0001564590-17-018633:notes:66]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value.  The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001564590-17-018633:notes:67]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method.  Realized gains or losses recognized on the sale of investments were not significant for fiscal 2015.  As of June 30, 2017 and 2016, the Company did not hold any investment securities.

[0001564590-17-018633:notes:68]
Fair Value of Financial Instruments

[0001564590-17-018633:notes:69]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3).  The three levels are defined as follows:

[0001564590-17-018633:notes:70]
|  | • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-17-018633:notes:71]
|  | • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-17-018633:notes:72]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company's own assumptions in measuring the asset or liability at fair value. |

[0001564590-17-018633:notes:73]
The Company did not hold any financial liabilities that required measurement at fair value on a recurring basis.  The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis (in thousands):

[0001564590-17-018633:notes:74]
| June 30, 2017 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,291 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,291 |  |
| Investment in non-marketable equity |  |  | — |  |  |  | — |  |  |  | 3,000 |  |  |  | 3,000 |  |
| Total |  | $ | 4,291 |  |  | $ | — |  |  | $ | 3,000 |  |  | $ | 7,291 |  |

[0001564590-17-018633:notes:75]
| June 30, 2016 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,275 |  |
| Investment in non-marketable equity |  |  | — |  |  |  | — |  |  |  | 3,000 |  |  |  | 3,000 |  |
| Total |  | $ | 4,275 |  |  | $ | — |  |  | $ | 3,000 |  |  | $ | 7,275 |  |

[0001564590-17-018633:notes:76]
Level 2 investments: The Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2.  There were no transfers of assets or liabilities between Level 1 and Level 2 during the fiscal years 2017 or 2016

[0001564590-17-018633:notes:77]
The fair value of the derivative instruments under our foreign currency contracts is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the short duration until maturity of the derivative instruments, the fair value approximates the carrying amount of the Company’s contacts of $27 thousand.

[0001564590-17-018633:notes:78]
The fair value of the borrowings under the Credit Facility is estimated based on valuations provided by alternative pricing sources supported by observable inputs which are considered Level 2.  The carrying amount and estimated fair value of the Company’s total long-term indebtedness, including current portion was $93.7 million and $55.5 million as of June 30, 2017 and 2016, respectively.

[0001564590-17-018633:notes:79]
Level 3 investments: Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.  The Company reflects a non-marketable equity investment as Level 3 in the fair value hierarchy as it is based on unobservable inputs that market participants would use in pricing this asset due to the absence of recent comparable market transactions and inherent lack of liquidity.  During fiscal 2015, the Company purchased a $3.0 million equity interest in a company that operates in the enterprise software platform industry.  The Company did not entered into any other transactions with the entity during fiscal 2017.   Subsequent to the year end, this entity was sold to a third party.  The Company will recognized a gain on the investment of approximately $3.7 million in the first quarter of fiscal year 2018. There were no transfers of assets or liabilities between Level 2 and Level 3 during the fiscal years 2017 or 2016. There were no impairments recorded for the fiscal years 2017 or 2016.

[0001564590-17-018633:notes:80]
Inventory Valuation

[0001564590-17-018633:notes:81]
The Company's inventory balance as of June 30, 2017 and 2016 was $45.9 million and $41.0 million, respectively. The Company values its inventory at lower of cost or market.  Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis.  The Company has established inventory allowances when conditions exist that suggest that inventory may be in excess of anticipated demand based upon assumptions about future demand or is obsolete.  At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.  Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-17-018633:notes:82]
The following is a summary of our inventory by category (in thousands).

[0001564590-17-018633:notes:83]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Finished goods |  | $ | 45,090 |  |  | $ | 38,751 |  |
| Raw materials |  |  | 790 |  |  |  | 2,238 |  |
| Total Inventory |  | $ | 45,880 |  |  | $ | 40,989 |  |

[0001564590-17-018633:notes:84]
Long-Lived Assets

[0001564590-17-018633:notes:85]
Long-lived assets include (a) property and equipment, (b) goodwill and intangible assets, and (c) other assets.  Property and equipment and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable.  If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001564590-17-018633:notes:86]
Goodwill and indefinite-lived intangible assets are generated as a result of business combinations. The Company’s indefinite-lived intangible assets are comprised of acquired in-process research and development (“IPR&D”), which is treated as indefinite until the completion or abandonment of the associated research and development effort.  During the development period, the Company conducts an IPR&D impairment test annually and whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, deteriorating financial performance, strategic decisions made in response to economic, market, and competitive conditions, the impact of the economic environment on us and our customer base, and/or other relevant events such as changes in management, key personnel, litigations, or customers.  Management did not identify any triggering events for any periods presented.

[0001564590-17-018633:notes:87]
The Company evaluates goodwill for impairment on an annual basis (on the first day of its fourth fiscal quarter) or whenever events occur or facts and circumstances change that would more likely than not reduce the fair value of a reporting unit below its carrying amount. An impairment loss is recognized to the extent that the carrying amount of goodwill exceeds the asset’s implied fair value. Based on the results of the goodwill impairment analyses, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0001564590-17-018633:notes:88]
Other assets consist primarily of service parts and long term deposits. The Company reduces the carrying value of service parts to net realizable value based on expected quantities needed to satisfy contractual service requirements of customers.

[0001564590-17-018633:notes:89]
(a) Property and Equipment, Net

[0001564590-17-018633:notes:90]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets.  Estimated useful lives of one to four years are used for computer equipment and software.  Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years). Property and equipment consist of the following (in thousands):

[0001564590-17-018633:notes:91]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Computer equipment |  | $ | 34,716 |  |  | $ | 34,657 |  |
| Purchased software |  |  | 11,785 |  |  |  | 5,574 |  |
| Office equipment, furniture and fixtures |  |  | 10,852 |  |  |  | 10,385 |  |
| Leasehold improvements |  |  | 23,046 |  |  |  | 19,342 |  |
| Total property and equipment |  |  | 80,399 |  |  |  | 69,958 |  |
| Less: accumulated depreciation and amortization |  |  | (50,159 | ) |  |  | (40,378 | ) |
| Property and equipment, net |  | $ | 30,240 |  |  | $ | 29,580 |  |

[0001564590-17-018633:notes:92]
We recognized depreciation expense of $10.6 million, $10.8 million, and $12.8 million related to property and equipment during the years ended June 30, 2017, 2016, and 2015, respectively.

[0001564590-17-018633:notes:93]
(b) Goodwill and Intangibles

[0001564590-17-018633:notes:94]
As part of the acquisition of WLAN Business, the Company acquired $9.3 million in goodwill which has been allocated to the Company's only reportable segment, the development and marketing of network infrastructure equipment.

[0001564590-17-018633:notes:95]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-17-018633:notes:96]
|  |  | June 30, 2017 |  |
| Balance as of June 30, 2016 |  | $ | 70,877 |  |
| Additions due to acquisition |  |  | 9,339 |  |
| Balance at end of period |  | $ | 80,216 |  |

[0001564590-17-018633:notes:97]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0001564590-17-018633:notes:98]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 5.3 years |  | $ | 55,400 |  |  | $ | 42,689 |  |  | $ | 12,711 |  |
| Customer relationships |  | 3.3 years |  |  | 40,300 |  |  |  | 37,567 |  |  |  | 2,733 |  |
| Maintenance contracts |  | 1.3 years |  |  | 17,000 |  |  |  | 12,467 |  |  |  | 4,533 |  |
| Trademarks |  | 4.3 years |  |  | 5,100 |  |  |  | 2,846 |  |  |  | 2,254 |  |
| License agreements |  | 6.4 years |  |  | 2,445 |  |  |  | 1,120 |  |  |  | 1,325 |  |
| Other intangibles |  | 2.7 years |  |  | 1,382 |  |  |  | 1,001 |  |  |  | 381 |  |
| Total intangibles, net with finite lives |  |  |  |  | 121,627 |  |  |  | 97,690 |  |  |  | 23,937 |  |
| In-process research and development, with indefinite life |  |  |  |  | 1,400 |  |  |  | — |  |  |  | 1,400 |  |
| Total intangibles, net |  |  |  | $ | 123,027 |  |  | $ | 97,690 |  |  | $ | 25,337 |  |

[0001564590-17-018633:notes:99]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 0.2 years |  | $ | 48,000 |  |  | $ | 43,028 |  |  | $ | 4,972 |  |
| Customer relationships |  | 0.3 years |  |  | 37,000 |  |  |  | 32,889 |  |  |  | 4,111 |  |
| Maintenance contracts |  | 2.3 years |  |  | 17,000 |  |  |  | 9,067 |  |  |  | 7,933 |  |
| Trademarks |  | 0.3 years |  |  | 2,500 |  |  |  | 2,222 |  |  |  | 278 |  |
| License agreements |  | 9.7 years |  |  | 3,413 |  |  |  | 1,473 |  |  |  | 1,940 |  |
| Other intangibles |  | 3.7 years |  |  | 1,428 |  |  |  | 900 |  |  |  | 528 |  |
| Total intangibles, net |  |  |  | $ | 109,341 |  |  | $ | 89,579 |  |  | $ | 19,762 |  |

[0001564590-17-018633:notes:100]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-17-018633:notes:101]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Amortization in "Cost of revenues: Product" |  | $ | 7,020 |  |  | $ | 15,369 |  |  | $ | 18,082 |  |
| Amortization of intangibles |  |  | 8,702 |  |  |  | 17,001 |  |  |  | 17,869 |  |
| Total amortization |  | $ | 15,722 |  |  | $ | 32,370 |  |  | $ | 35,951 |  |

[0001564590-17-018633:notes:102]
The amortization expense that is recognized in "Cost of revenues: Product" is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-17-018633:notes:103]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0001564590-17-018633:notes:104]
| For the fiscal year ending: |  |  |  |  |
| 2018 |  | $ | 7,620 |  |
| 2019 |  |  | 5,292 |  |
| 2020 |  |  | 4,061 |  |
| 2021 |  |  | 3,266 |  |
| 2022 |  |  | 2,594 |  |
| Thereafter, |  |  | 1,104 |  |
| Total |  | $ | 23,937 |  |

[0001564590-17-018633:notes:105]
(c) Other Assets

[0001564590-17-018633:notes:106]
Other assets primarily consist of service parts and long term deposits. The Company holds service parts to support customers who have purchased service contracts with a hardware replacement element, as well as to support our warranty program. The Company held service parts of $10.1 million and $16.0  million as of June 30, 2017 and 2016, respectively.

[0001564590-17-018633:notes:107]
Deferred Revenue, Net

[0001564590-17-018633:notes:108]
Deferred revenue, net represents amounts for (i) deferred maintenance revenue and (ii) deferred product revenue net of the related cost of revenue and other (professional services and training) when the revenue recognition criteria have not been met.  The following table summarizes deferred revenue (in thousands):

[0001564590-17-018633:notes:109]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Deferred maintenance |  | $ | 97,310 |  |  | $ | 83,419 |  |
| Deferred product and other revenue |  |  | 7,031 |  |  |  | 11,441 |  |
| Total deferred revenue, net |  |  | 104,341 |  |  |  | 94,860 |  |
| Less: current portion |  |  | 79,048 |  |  |  | 72,934 |  |
| Non-current deferred revenue, net |  | $ | 25,293 |  |  | $ | 21,926 |  |

[0001564590-17-018633:notes:110]
The Company offers for sale to its customers, renewable support arrangements, including extended warranty contracts that range generally from one to five years. Deferred support revenue is included within deferred revenue, net within the maintenance revenue category above. The change in the Company’s deferred maintenance revenue balance in relation to these arrangements was as follows (in thousands):

[0001564590-17-018633:notes:111]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Balance beginning of period |  | $ | 83,419 |  |  | $ | 87,441 |  |
| Deferred maintenance assumed due to acquisition |  |  | 14,159 |  |  |  | — |  |
| New maintenance arrangements |  |  | 125,542 |  |  |  | 110,192 |  |
| Recognition of maintenance revenue |  |  | (125,810 | ) |  |  | (114,214 | ) |
| Balance end of period |  |  | 97,310 |  |  |  | 83,419 |  |
| Less: current portion |  |  | 72,017 |  |  |  | 61,493 |  |
| Non-current deferred revenue |  | $ | 25,293 |  |  | $ | 21,926 |  |

[0001564590-17-018633:notes:112]
Deferred Distributors Revenue, Net of Cost of Sales to Distributors

[0001564590-17-018633:notes:113]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay on a current basis for product delivered.  The Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its consolidated balance sheets.  Deferred distributors revenue, net of cost of sales to distributors effectively represents the gross margin on the sale to the distributor; however, the amount of gross margin the Company recognizes in future periods will frequently be less than the originally recorded deferred distributors revenue, net of cost of sales to distributors as a result of price concessions negotiated at time of sell-through to end customers.  The Company sells each item in its product catalog to all of its distributors worldwide at contractually discounted prices.  However, distributors resell the Company’s products to end customers at a very broad range of individually negotiated price points based on customer, product, quantity, geography, and other competitive conditions which results in the Company remitting back to the distributors a portion of their original purchase price after the resale transaction is completed.  Thus, a portion of the deferred revenue balance represents a portion of distributors’ original purchase price that will be remitted back to the distributors in the future.  The wide range and variability of negotiated price credits granted to distributors does not allow the Company to accurately estimate the portion of the balance in the deferred revenue that will be remitted to the distributors.  Therefore, the Company does not reduce deferred revenue by anticipated future price credits; instead, price credits are recorded against revenue when incurred, which is generally at the time the distributor sells the product.

[0001564590-17-018633:notes:114]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors (in thousands):

[0001564590-17-018633:notes:115]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Deferred distributors revenue |  | $ | 55,335 |  |  | $ | 35,138 |  |
| Deferred cost of sales to distributors |  |  | (11,810 | ) |  |  | (8,321 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | $ | 43,525 |  |  | $ | 26,817 |  |

[0001564590-17-018633:notes:116]
Debt

[0001564590-17-018633:notes:117]
The Company's debt is comprised of the following (in thousands):

[0001564590-17-018633:notes:118]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 12,444 |  |  | $ | 17,875 |  |
| Less: unamortized debt issuance costs |  |  | (164 | ) |  |  | (247 | ) |
| Current portion of long-term debt |  | $ | 12,280 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 71,268 |  |  | $ | 27,625 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (846 | ) |  |  | (179 | ) |
| Total long-term debt, less current portion |  |  | 80,422 |  |  |  | 37,446 |  |
| Total debt |  | $ | 92,702 |  |  | $ | 55,074 |  |

[0001564590-17-018633:notes:119]
The Company's debt repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0001564590-17-018633:notes:120]
| For the fiscal year ending: |  |  |  |  |
| 2018 |  | $ | 12,444 |  |
| 2019 |  |  | 16,969 |  |
| 2020 |  |  | 21,494 |  |
| 2021 |  |  | 26,019 |  |
| 2022 |  |  | 16,786 |  |
| Total |  | $ | 93,712 |  |

[0001564590-17-018633:notes:121]
During the second quarter of fiscal 2017, the Company entered into an Amended and Restated Credit Agreement (the “Credit Facility”) with Silicon Valley Bank, as administrative agent and collateral agent, and the financial institutions that are a party thereto as lenders (“Lenders”).   The Credit Facility provided for a five-year $90.5 million term loan (“Term Loan”) and a five-year $50.0 million revolving loan facility (“Revolver”), which included a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Facility among other things, amended and restated the Company’s previous credit facility.  The borrowings under the Credit Facility during fiscal 2017 were used to acquire the WLAN Business as more fully described in Note 2.

[0001564590-17-018633:notes:122]
The Credit Facility was amended on March 2, 2017, by Amendment One to such agreement, in anticipation of the acquisition of specified assets and liabilities of Avaya, Inc. (“Avaya”) as more fully described in the Form 8-K filed on that date.

[0001564590-17-018633:notes:123]
On July 14, 2017, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and Lenders.  Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the Term Loan in a principal amount of up to $183.7 million and (b) the Revolver in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as Lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed an additional $80.0 million under the Term Loan which was used to fund the purchase of the Avaya Networking business (see Note 14).

[0001564590-17-018633:notes:124]
Borrowings under the Term Loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum).  Borrowings under the Revolver bear interest, at the Company’s option, at a rate equal to either the LIBOR rate, plus an applicable margin (currently 3.25% per annum) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based).  The Revolver has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum.

[0001564590-17-018633:notes:125]
If not repaid earlier, the borrowings on the Revolver shall be repaid on the termination date. The Credit Facility, as amended is secured by substantially all of the Company’s assets and is jointly and severally guaranteed by the Company and certain of its subsidiaries.

[0001564590-17-018633:notes:126]
The Credit Facility contains financial covenants that require the Company to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other financial and non-financial covenants and restrictions that limit the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets, etc.  These covenants, are subject to certain exceptions.

[0001564590-17-018633:notes:127]
The Credit Facility also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by the Company is false or misleading in any material respect, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company.  The amounts outstanding under the Credit Facility may be accelerated upon certain events of default.

[0001564590-17-018633:notes:128]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2017, in conjunction with the amending of the Credit Facility, as noted above, the Company incurred $1.3 million of deferred financing costs.

[0001564590-17-018633:notes:129]
Amortization of deferred financing costs is included in "Interest expense" in the consolidated statements of operations, totaled $0.5 million, $0.5 million and $0.4 million in fiscal years 2017, 2016 and 2015, respectively.

[0001564590-17-018633:notes:130]
The Company had $39.1 million of availability under the Revolver as of June 30, 2017.  The Company had $0.9 million of outstanding letters of credit as of June 30, 2017 and 2016.

[0001564590-17-018633:notes:131]
Guarantees and Product Warranties

[0001564590-17-018633:notes:132]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates.  The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-17-018633:notes:133]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty.  The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0001564590-17-018633:notes:134]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Balance beginning of period |  | $ | 9,600 |  |  | $ | 8,676 |  |
| Warranties assumed due to acquisition |  |  | 2,034 |  |  |  | — |  |
| New warranties issued |  |  | 6,015 |  |  |  | 8,176 |  |
| Warranty expenditures |  |  | (7,642 | ) |  |  | (7,252 | ) |
| Balance end of period |  | $ | 10,007 |  |  | $ | 9,600 |  |

[0001564590-17-018633:notes:135]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-17-018633:notes:136]
Advertising

[0001564590-17-018633:notes:137]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue.  All other advertising costs are expensed as incurred.  Advertising expenses were $0.4  million, $0.3 million and $0.5 million in fiscal years 2017, 2016 and 2015, respectively.

[0001564590-17-018633:notes:138]
Income Taxes

[0001564590-17-018633:notes:139]
We account for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings.   A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0001564590-17-018633:notes:140]
The Company accounts for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes. For additional discussion, see Note 9. Income Taxes.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-17-018633:notes:141]
4. Recently Issued Accounting Pronouncements

[0001564590-17-018633:notes:142]
In May 2014, the FASB issued ASU No. 2014-09 (Topic 606)—Revenue from Contracts with Customers (“ASU 2014-09”) which provides a new five-step model for revenue recognition. This ASU affects all contracts that the Company enters into with customers to transfer goods and services or for the transfer of nonfinancial assets. This ASU will supersede the revenue recognition requirements in Topic 605, and most industry specific guidance. This ASU also supersedes the cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts and provides new cost guidance under Sub Topic 340-40.

[0001564590-17-018633:notes:143]
The standard's core principle is that revenue is recognized when control of promised goods or services is transferred to customers in an amount that reflects the consideration to which the Company expects to be entitled in exchange for those goods or services. As a result, the Company will use additional judgments and estimates under the new revenue standard. These may include identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation.

[0001564590-17-018633:notes:144]
In August 2015, the FASB issued ASU 2015-14 which deferred the effective date of the new revenue standard from December 15, 2016 to December 15, 2017, with early adoption permitted as of annual reporting periods beginning after December 15, 2016. Accordingly, the ASU will be effective for the Company beginning fiscal year 2018.  In addition, in March 2016, the FASB issued ASU No. 2016-08 (Topic 606) Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net) (“ASU 2016-08”), which clarifies the principal-versus-agent guidance in Topic 606 and requires an entity to determine whether the nature of its promise to provide goods or services to a customer is performed in a principal or agent capacity and to recognize revenue in a gross or net manner based on its principal/agent designation. In April 2016, the FASB also issued ASU No. 2016-10 (Topic 606) Revenue from Contracts with Customers: Identifying Performance Obligations and Licensing (“ASU 2016-10”), which amends the revenue guidance on identifying performance obligations and accounting for licenses of intellectual property. In May 2016, the FASB also issued ASU No. 2016-12 (Topic 606) Revenue from Contracts with Customers: Narrow-Scope Improvements and Practical Expedients (“ASU 2016-12”), which amends the revenue guidance to clarify measurement and presentation as well as to include some practical expedients and policy elections. There are two transition methods available under the new standard, either cumulative effect or retrospective. There are optional practical expedients which may be applied under both methods. ASU 2016-08, ASU 2016-10, and ASU 2016-12 must be adopted concurrently with the adoption of ASU 2014-09.

[0001564590-17-018633:notes:145]
We will be utilizing the full retrospective method of adoption for Topic 606 applied to those contracts for which all (or substantially all) of the revenue was not previously recognized in accordance with revenue guidance that is in effect before that date. This method will require the restatement of each prior reporting period presented. The most significant impact of the standard to the Company relates to our accounting for distributor and reseller revenues from a primarily “sell-through” model, where revenue is not recognized until inventory is sold from our distribution channel to their customer, to “sell-in” as revenue will be recognized upon transfer of control to our customers, including distributors. We continue to evaluate certain product return estimates for determining the transaction price and the standalone selling price of certain performance obligations, such as standalone software where historically we have recognized revenue on the residual method, and certain return estimates. Adoption of the new standard will result in a reduction in accounts receivable for the estimated returns and rebates payable upon sell-through and a decrease in deferred distributor revenue as a result of recognizing revenue upon transfer of control.

[0001564590-17-018633:notes:146]
The table below presents the estimated impact to our Consolidated Statements of Operations line items for the fiscal periods ended (in thousands):

[0001564590-17-018633:notes:147]
|  |  | June 30, 2017 |  | June 30, 2016 * |
| Net Revenue |  | $8,000 – $14,000 |  | $(6,500) – $(12,500) |
| Gross profit |  | $5,500 – $11,500 |  | $(3,500) – $(9,500) |
| Operating income (loss) |  | $6,000 – $12,000 |  | $(2,500) – $(8,500) |

[0001564590-17-018633:notes:148]
| * | Excludes the financial impact of pre-fiscal 2016 amounts which will be reflected in the retained earnings. |

[0001564590-17-018633:notes:149]
We do not anticipate the new standard to modify our current business practices nor do we expect to have an impact on our debt covenants.  As we implement the new standard, we will develop internal controls to ensure that we adequately evaluate our portfolio of contracts under the five-step model and accurately restate our prior-period operating results under ASU 2014-09. This guidance will become effective for the Company beginning with its fiscal year 2018.

[0001564590-17-018633:notes:150]
In March 2016, the FASB issued ASU No. 2016-06 (Topic 815), Derivatives and Hedging– Contingent Put and Call Options in Debt Instruments (“ASU 2016-06”), which will reduce diversity of practice in identifying embedded derivatives in debt instruments. ASU 2016-06 clarifies that the nature of an exercise contingency is not subject to the “clearly and closely” criteria for purposes of assessing whether the call or put option must be separated from the debt instrument and accounted for separately as a derivative. The adoption of this guidance will not have a material effect on our financial statements. This guidance will be effective for the Company beginning with its fiscal year 2018.

[0001564590-17-018633:notes:151]
In May 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (ASU) 2017-09, Compensation—Stock Compensation (Topic 718) - Scope of Modification Accounting (“ASU 2017-09”) which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under ASC 718. Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The guidance is effective prospectively for fiscal years beginning after December 15, 2017, and interim periods within that reporting period. Early adoption is permitted, including adoption in any interim period. We do not expect the adoption of this guidance to have a material effect on our financial statements. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-17-018633:notes:152]
In January 2016, the FASB issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities.  The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2019.

[0001564590-17-018633:notes:153]
In February 2016, the FASB issued ASU No. 2016-02 (Topic 842), Leases (“ASU 2016-02”) which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under ASU 2016-02, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the income statement will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of ASU 2016-02 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, ASU 2016-02 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2020.

[0001564590-17-018633:notes:154]
Recently Adopted Accounting Pronouncements

[0001564590-17-018633:notes:155]
In April 2015, the FASB issued ASU No. 2015-03 - Simplifying the Presentation of Debt Issuance Costs (“ASU 2015-03”), which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. ASU 2015-03 requires retrospective adoption and will be effect for annual and interim periods in fiscal years beginning after December 15, 2015. Adoption of this standard did not have a material impact on our financial statements and footnote disclosures.

[0001564590-17-018633:notes:156]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2016-09 (Topic 718), Compensation – Stock Compensation (“ASU 2016-09”) which identifies areas for simplification involving several aspects of accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, an option to recognize gross stock compensation expense with actual forfeitures recognized as they occur, as well as certain classifications on the statement of cash flows. This guidance did not have a material impact on the results of operations or cash flows.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-018633:notes:157]
5. Commitments and Contingencies

[0001564590-17-018633:notes:158]
Leases

[0001564590-17-018633:notes:159]
The Company currently leases its current headquarters, research and development facilities and office spaces for its various United States and international operations. Certain leases contain rent escalation clauses and renewal options. As part of the Company’s existing leased facilities, the Company has received lease incentives which take the form of a fixed allowance towards lease improvements on the respective facility. The Company used the allowance to make leasehold improvements which are being depreciated over the useful life of the assets or the lease term, whichever is shorter. The offsetting lease incentives liability is being amortized on a straight-line basis over the term of the lease as an offset to rent expense.

[0001564590-17-018633:notes:160]
Future annual minimum lease payments under all non-cancelable operating leases having initial or remaining lease terms in excess of one year at June 30, 2017, were as follows (in thousands):

[0001564590-17-018633:notes:161]
| For the fiscal year ending: |  | Future Lease Payments |  |
| 2018 |  | $ | 12,949 |  |
| 2019 |  |  | 11,883 |  |
| 2020 |  |  | 8,988 |  |
| 2021 |  |  | 7,680 |  |
| 2022 |  |  | 7,132 |  |
| Thereafter |  |  | 6,162 |  |
| Total minimum payments |  | $ | 54,794 |  |

[0001564590-17-018633:notes:162]
Rent expense was $9.4 million, $8.5 million and $11.1 million in fiscal years 2017, 2016 and 2015, respectively.

[0001564590-17-018633:notes:163]
Purchase Commitments

[0001564590-17-018633:notes:164]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2017, the Company had non-cancelable commitments to purchase $83.2 million of such inventory, which will be received and consumed during the first half of fiscal 2018

[0001564590-17-018633:notes:165]
Legal Proceedings

[0001564590-17-018633:notes:166]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-17-018633:notes:167]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would cause a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company presently is unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-17-018633:notes:168]
Brazilian Tax Assessment Matters

[0001564590-17-018633:notes:169]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The tax authorities also are seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Brasil the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009.  The value of the ICMS tax credits disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.0 million), excluding interest and penalties.

[0001564590-17-018633:notes:170]
On January 10, 2014, Enterasys Brasil filed a lawsuit to overturn or reduce the ICMS Tax Assessments. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  The lawsuit remains ongoing.  With accrued interest and penalties totaling BRL 18.4 million (US $5.6 million), the disputed assessment is 21.9 million BRL (US $6.7 million) as of June 30, 2017.  If the Sao Paolo Tax Administration were to prevail in the lawsuit, the court also could order Enterasys Brasil to pay attorneys’ fees ranging from BRL 1.2 million (US $0.4 million) to BRL 1.8 million (US $0.5 million); if Enterasys Brasil elected to pay voluntarily the full assessment amount (including accrued interest and penalties), attorneys’ fees would be BRL 4.4 million (US $1.3 million).  All currency conversions in this Legal Proceedings section are as of June 30, 2017.

[0001564590-17-018633:notes:171]
On or about June 18, 2014, the State of San Paolo notified Enterasys Brasil that it intended to audit its records for tax years 2012 and 2013.  In addition, Enterasys Brasil received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits covered the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009; however, Enterasys Brasil had changed its ICMS procedures effective May 2009. This audit was recently completed, and in March 2017, Enterasys Brasil paid BRL 0.2 million (US $0.1  million) in expenses related to the audit.

[0001564590-17-018633:notes:172]
Based on the currently available information, the Company believes the ultimate outcome of the above assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against Enterasys Brasil are without merit, and Enterasys Brasil is defending the claims vigorously.  However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, the Company is unable to determine the likelihood of an unfavorable outcome against Enterasys Brasil, which recorded an accrual of BRL 9.4 million (US $2.9 million) as of the date the Company acquired Enterasys Networks, as such matter relates to the period before the acquisition.

[0001564590-17-018633:notes:173]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of and indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from the Seller in connection with either the ICMS Tax Assessments or the expenses related to the audit.

[0001564590-17-018633:notes:174]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-17-018633:notes:175]
On October 23 and 29, 2015, putative class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  Defendants’ motion to dismiss currently is scheduled to be heard on December 14, 2017. The Company believes plaintiffs’ claims are without merit and intends to defend them vigorously.

[0001564590-17-018633:notes:176]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.

[0001564590-17-018633:notes:177]
Plectrum LLC v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-17-018633:notes:178]
On February 2, 2017, Plectrum LLC (“Plectrum”) sued the Company in the U.S. District Court for the Eastern District of Texas (Plectrum LLC v. Extreme Networks, Inc., No. 4:17-CV-0079).  The complaint asserted infringement of U.S. Patent Nos. 5,978,951, 6,205,149, and 6,751,677 based on the Company’s manufacture, use, sale, and/or offer for sale of its S-Series and Summit Series Switch products.  Plectrum sought an injunction and unspecified damages.  On June 24, 2017, the Court dismissed the case with prejudice after the parties advised that they had resolved the matter.

[0001564590-17-018633:notes:179]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-17-018633:notes:180]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) sued the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-17-018633:notes:181]
Indemnification Obligations

[0001564590-17-018633:notes:182]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of June 30, 2017, the Company had no outstanding indemnification claims.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-17-018633:notes:183]
6. Stockholders’ Equity

[0001564590-17-018633:notes:184]
Preferred Stock

[0001564590-17-018633:notes:185]
In April 2001, in connection with the entering into of the Company's Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2017, no shares of preferred stock were outstanding.

[0001564590-17-018633:notes:186]
Stockholders’ Rights Agreement

[0001564590-17-018633:notes:187]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of our Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as subsequently amended, between us and Mellon Investor Services LLC (the “Prior Rights Plan”).

[0001564590-17-018633:notes:188]
The Board adopted the Restated Rights Plan to preserve the value of our deferred tax assets, including our net operating loss carry forwards, with respect to our ability to fully use its tax benefits to offset future income which may be limited if we experience an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of our common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of us and our stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 our Board and shareholders have approved an amendment providing for a one year extension of the term of the Restated Rights Plan.  Our Board of Directors unanimously approved an amendment to the Restated Rights Plan on May 9, 2017 to extend the Restated Rights Plan through May 31, 2018, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting, expected to be held on November 9, 2017.

[0001564590-17-018633:notes:189]
Shares Reserved for Issuance

[0001564590-17-018633:notes:190]
The following are shares reserved for issuance (in thousands):

[0001564590-17-018633:notes:191]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,785 |  |  |  | 10,001 |  |
| Employee stock options and awards outstanding |  |  | 9,726 |  |  |  | 10,609 |  |
| 2013 Employee Plan shares available for grant |  |  | 7,629 |  |  |  | 5,401 |  |
| Total shares reserved for issuance |  |  | 25,140 |  |  |  | 26,011 |  |

[0001564590-17-018633:notes:192]
The following table summarizes the transfer of shares between the respective plans for the periods presented (in thousands):

[0001564590-17-018633:notes:193]
|  |  | 2005 Plan |  |  | 2013 Plan |  |  | Total |  |
| Shares available at June 30, 2014 |  |  | — |  |  |  | 8,762 |  |  |  | 8,762 |  |
| Granted |  |  | — |  |  |  | (7,060 | ) |  |  | (7,060 | ) |
| Canceled |  |  | 1,537 |  |  |  | 2,211 |  |  |  | 3,748 |  |
| Transferred |  |  | (1,537 | ) |  |  | 1,537 |  |  |  | — |  |
| Shares available at June 30, 2015 |  |  | — |  |  |  | 5,450 |  |  |  | 5,450 |  |
| Granted |  |  | — |  |  |  | (5,141 | ) |  |  | (5,141 | ) |
| Canceled |  |  | 5,803 |  |  |  | — |  |  |  | 5,803 |  |
| Transferred |  |  | (5,092 | ) |  |  | 5,092 |  |  |  | — |  |
| Retired |  |  | (711 | ) |  |  | — |  |  |  | (711 | ) |
| Shares available at June 30, 2016 |  |  | — |  |  |  | 5,401 |  |  |  | 5,401 |  |
| Additional shares authorized |  |  | — |  |  |  | 8,300 |  |  |  | 8,300 |  |
| Granted |  |  | — |  |  |  | (7,865 | ) |  |  | (7,865 | ) |
| Canceled |  |  | — |  |  |  | 1,793 |  |  |  | 1,793 |  |
| Shares available at June 30, 2017 |  |  | — |  |  |  | 7,629 |  |  |  | 7,629 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-018633:notes:194]
7. Employee Benefit Plans (including Share-based Compensation)

[0001564590-17-018633:notes:195]
As of June 30, 2017, the Company has the following share-based compensation plans:

[0001564590-17-018633:notes:196]
2013 Equity Incentive Plan

[0001564590-17-018633:notes:197]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the "2005 Plan").  Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants.  The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees.  The 2013 Plan authorizes the issuance of 9,000,000 shares of the Company’s common stock.  In addition, up to 12,709,153 shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan.  The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted.  Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting.  During the fiscal year ended June 30, 2017, an additional 8,300,000 shares were authorized and made available for grant under the 2013 Plan.  As of June 30, 2017, total options and awards to acquire 7,994,086 shares were outstanding under the 2013 Plan and 7,628,980 shares are available for grant under the 2013 Plan.  Options granted under this plan have a contractual term of seven years.

[0001564590-17-018633:notes:198]
Enterasys 2013 Stock Plan

[0001564590-17-018633:notes:199]
Pursuant to the acquisition of Enterasys on October 31, 2013, the Company assumed the Enterasys 2013 Stock Plan (the "Enterasys Plan"). As of June 30, 2017, total options and awards to acquire 1,282,691 shares were outstanding under the Enterasys Plan.  Options granted under this plan have a contractual term of seven years.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired in the Enterasys Plan. No future grants may be made from the Enterasys Plan.

[0001564590-17-018633:notes:200]
2005 Equity Incentive Plan

[0001564590-17-018633:notes:201]
The 2005 Plan was adopted by the Company’s Board of Directors on October 20, 2005, and approved by stockholders on December 2, 2005.  The 2005 Plan replaced the Amended 1996 Stock Option Plan (the “1996 Plan”), the 2000 Non-statutory Stock Option Plan and the 2001 Non-statutory Stock Option Plan.  The 2005 Plan includes provisions upon the granting of certain awards defined by the 2005 Plan as Full Value Awards in which the shares available for grant under the 2005 Plan are decremented 1.5 shares for each such award granted.  Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2005 Plan for future issuance as was applied upon granting. Effective November 20, 2013, the 2005 Plan was replaced with the 2013 Plan, and, as of June 30, 2017, total options and awards to acquire 449,062 shares were outstanding under the 2005 Plan.  No future grants may be made from the 2005 Plan, however, outstanding options and awards forfeited or canceled were allowed to be transferred to the 2013 Plan until December 2, 2015, at which time, no further shares may be transferred.  There were a total of 6,628,643 shares transferred to the 2013 Plan.

[0001564590-17-018633:notes:202]
Amended 1996 Stock Option Plan

[0001564590-17-018633:notes:203]
The 1996 Plan was originally adopted in September 1996, and provided for the grant of options for common stock to eligible participants.  Effective December 2, 2005, the 1996 Plan was terminated, and, as of June 30, 2016, no options to acquire shares remain outstanding under the 1996 Plan. No future grants may be made from the 1996 Plan.

[0001564590-17-018633:notes:204]
The following table summarizes stock option activity under all plans (shares and intrinsic value in thousands):

[0001564590-17-018633:notes:205]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2016 |  |  | 6,385 |  |  | $ | 4.10 |  |  |  | 3.70 |  |  | $ | 1,416 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (2,348 | ) |  |  | 3.98 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (975 | ) |  |  | 4.48 |  |  |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2017 |  |  | 3,062 |  |  | $ | 4.06 |  |  |  | 4.19 |  |  | $ | 15,868 |  |
| Vested and expected to vest at June 30, 2017 |  |  | 3,062 |  |  | $ | 4.06 |  |  |  | 4.19 |  |  | $ | 15,868 |  |
| Exercisable at June 30, 2017 |  |  | 2,299 |  |  | $ | 4.43 |  |  |  | 3.38 |  |  | $ | 11,017 |  |

[0001564590-17-018633:notes:206]
The following table summarizes significant ranges of outstanding and exercisable options at June 30, 2017, (shares outstanding and exercisable, in thousands):

[0001564590-17-018633:notes:207]
| Options Outstanding |  |  | Options Exercisable |  |
|  |  |  |  |  |  | Weighted- |  |  | Weighted- |  |  |  |  |  |  | Weighted- |  |
|  |  | Number |  |  | Average |  |  | Average |  |  | Number |  |  | Average |  |
| Range of |  | Outstanding |  |  | Remaining |  |  | Exercise |  |  | Exercisable |  |  | Exercise |  |
| Exercise Prices |  | (000’s) |  |  | Contractual Life |  |  | Price |  |  | (000’s) |  |  | Price |  |
|  |  |  |  |  |  | (In years) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| $1.69 – $2.05 |  |  | 99 |  |  |  | 1.32 |  |  | $ | 2.02 |  |  |  | 99 |  |  | $ | 2.02 |  |
| $2.51 – $2.51 |  |  | 947 |  |  |  | 6.74 |  |  | $ | 2.51 |  |  |  | 332 |  |  | $ | 2.51 |  |
| $2.94 – $3.54 |  |  | 345 |  |  |  | 2.35 |  |  | $ | 3.34 |  |  |  | 295 |  |  | $ | 3.32 |  |
| $3.55 – $3.87 |  |  | 113 |  |  |  | 3.00 |  |  | $ | 3.69 |  |  |  | 102 |  |  | $ | 3.70 |  |
| $4.18 – $4.18 |  |  | 26 |  |  |  | 3.08 |  |  | $ | 4.18 |  |  |  | 26 |  |  | $ | 4.18 |  |
| $4.25 – $4.25 |  |  | 31 |  |  |  | 0.30 |  |  | $ | 4.25 |  |  |  | 32 |  |  | $ | 4.25 |  |
| $5.21 – $5.21 |  |  | 43 |  |  |  | 4.13 |  |  | $ | 5.21 |  |  |  | 31 |  |  | $ | 5.21 |  |
| $5.30 – $5.30 |  |  | 1,271 |  |  |  | 3.33 |  |  | $ | 5.30 |  |  |  | 1,242 |  |  | $ | 5.30 |  |
| $5.67 – $5.67 |  |  | 172 |  |  |  | 3.61 |  |  | $ | 5.67 |  |  |  | 127 |  |  | $ | 5.67 |  |
| $6.15 – $6.15 |  |  | 15 |  |  |  | 3.20 |  |  | $ | 6.15 |  |  |  | 13 |  |  | $ | 6.15 |  |
| $1.69 – $6.15 |  |  | 3,062 |  |  |  | 4.19 |  |  | $ | 4.06 |  |  |  | 2,299 |  |  | $ | 4.43 |  |

[0001564590-17-018633:notes:208]
The total intrinsic value of options exercised in fiscal years 2017, 2016 and 2015 was $5.7 million, $0.2 million and $0.4 million, respectively.

[0001564590-17-018633:notes:209]
There were no stock options granted in fiscal 2017.  The weighted-average grant-date per share fair value of stock options granted in fiscal years 2016 and 2015, was $1.59 and $1.75, respectively. As of June 30, 2017, there was $0.4 million of total unrecognized compensation cost related to unvested stock options. This cost is expected to be recognized over a weighted-average period of 1.3 years.

[0001564590-17-018633:notes:210]
The average fair-value and the average derived service period on the grant-date for the performance-based stock option awards with market conditions, granted in fiscal 2015, was $1.21 and 1.9 years respectively.

[0001564590-17-018633:notes:211]
Stock Awards

[0001564590-17-018633:notes:212]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors.  Stock awards generally provide for the issuance of restricted stock units (“RSU’s”), including performance or market-based restricted stock units (“PSU”) which vest over a fixed period of time or based upon the satisfaction of certain performance criteria. The Company recognizes compensation expense on the awards over the vesting period based on the award’s intrinsic value as of the date of grant.

[0001564590-17-018633:notes:213]
During fiscal years 2017, 2016 and 2015, the Company began expensing PSU’s with market or performance based conditions to senior executive officers that had been granted during fiscal years 2017, 2016 and 2015. The Company uses a Monte-Carlo simulation model to determine the fair value and the derived service period of PSU’s, with market or performance conditions or combinations of those conditions with a service condition, on the date of grant.

[0001564590-17-018633:notes:214]
The following table summarizes stock award activity (shares and market value in thousands):

[0001564590-17-018633:notes:215]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2016 |  |  | 4,224 |  |  | $ | 3.36 |  |  |  |  |  |
| Granted |  |  | 5,045 |  |  |  | 5.26 |  |  |  |  |  |
| Vested |  |  | (1,721 | ) |  |  | 3.80 |  |  |  |  |  |
| Cancelled |  |  | (884 | ) |  |  | 3.47 |  |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2017 |  |  | 6,664 |  |  | $ | 4.66 |  |  | $ | 61,440 |  |

[0001564590-17-018633:notes:216]
The aggregate fair value, as of the respective vesting dates of RSUs vested during the fiscal years ended  June 30, 2017, 2016 and 2015 was $9.1 million, $8.6 million and $8.9 million, respectively.

[0001564590-17-018633:notes:217]
For the fiscal years ended June 30, 2017, 2016 and 2015, the Company withheld an aggregate of 361,369 shares, 118,129 shares and 826,943 shares, respectively, upon the vesting of RSUs, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0001564590-17-018633:notes:218]
For fiscal years 2017, 2016 and 2015, the Company remitted cash of $2.0 million, $0.2 million and $2.8 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheet and as a reduction of “Proceeds for issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0001564590-17-018633:notes:219]
As of June 30, 2017, there were $25.1 million in unrecognized compensation costs related to non-vested stock awards.  This cost is expected to be recognized over a weighted-average period of 1.9 years

[0001564590-17-018633:notes:220]
Performance Grant Activity

[0001564590-17-018633:notes:221]
The following table summarizes PSU’s with market or performance based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0001564590-17-018633:notes:222]
|  |  | Fiscal year 2017 |  |  | Fiscal year 2016 |  |  | Fiscal year 2015 |  |
| Performance awards granted |  |  | 2,106 |  |  |  | 695 |  |  |  | 615 |  |
| Performance awards earned |  |  | 839 |  |  |  | 582 |  |  |  | — |  |

[0001564590-17-018633:notes:223]
2014 Employee Stock Purchase Plan

[0001564590-17-018633:notes:224]
In August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”).  On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12,000,000 shares. The 2014 ESPP replaced the 1999 Employee Stock Purchase Plan.  The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding.  Each purchase period has a maximum duration of six (6) months.  The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.  The 2014 ESPP currently has offerings periods of either 6 months or 24 months, commonly referred to as "look back periods".   As of June 30, 2017, there have been 4,215,122 shares issued under the 2014 ESPP.

[0001564590-17-018633:notes:225]
Effective with the offering period beginning on February 1, 2016, the Company amended the 2014 ESPP to increase the maximum shares issuable for each purchase period from 1,000,000 shares to 1,500,000 shares. Effective with the offering period beginning on August 1, 2016, the Company amended the 2014 ESPP so that all future offering periods are limited to six months and to make certain other changes to the 2014 ESPP including adding new contribution limits for each offering period.  Existing open offering periods prior to the effective date of the changes were unaffected by the amendments to the 2014 ESPP.

[0001564590-17-018633:notes:226]
1999 Employee Stock Purchase Plan

[0001564590-17-018633:notes:227]
In January 1999, the Board of Directors approved the adoption of Extreme Network’s 1999 Employee Stock Purchase Plan (the “1999 ESPP”).  On December 2, 2005, the stockholders approved an amendment to the 1999 ESPP to increase the maximum number of shares of common stock that may be issued under the plan by 5,000,000 to a total of 12,000,000 shares.  The 1999 ESPP was replaced by the 2014 ESPP.  The 1999 ESPP allowed eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation. The price at which the common stock could be purchased was 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. Through June 30, 2015, 11,933,618 shares were purchased under the 1999 ESPP.  All remaining shares available under the 1999 ESPP have been retired.

[0001564590-17-018633:notes:228]
Share Based Compensation Expense

[0001564590-17-018633:notes:229]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (in thousands):

[0001564590-17-018633:notes:230]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Cost of product revenue |  | $ | 333 |  |  | $ | 882 |  |  | $ | 1,067 |  |
| Cost of service revenue |  |  | 589 |  |  |  | 1,041 |  |  |  | 1,068 |  |
| Research and development |  |  | 3,312 |  |  |  | 4,559 |  |  |  | 5,365 |  |
| Sales and marketing |  |  | 4,253 |  |  |  | 4,633 |  |  |  | 5,170 |  |
| General and administrative |  |  | 4,146 |  |  |  | 3,677 |  |  |  | 5,131 |  |
| Total share-based compensation expense |  | $ | 12,633 |  |  | $ | 14,792 |  |  | $ | 17,801 |  |

[0001564590-17-018633:notes:231]
The amount of stock based compensation expense capitalized in inventory has been immaterial for each of the periods presented.

[0001564590-17-018633:notes:232]
The Company uses the straight-line method for expense attribution.  Beginning in fiscal 2017, the Company no longer estimates forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur.  The Company’s estimated forfeiture rate in fiscal 2016 based on the Company’s historical forfeiture experience was 13% for non-executives and 19% for executives.

[0001564590-17-018633:notes:233]
The fair value of each stock option grant under the Company's 2013 Plan and 2005 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-17-018633:notes:234]
Under the 2013 Plan the Company uses a Monte-Carlo simulation model to determine the fair value and the derived service period of stock option grants, with market, performance or service conditions or combinations of those conditions, on the date of grant.

[0001564590-17-018633:notes:235]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP.  The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-17-018633:notes:236]
The weighted-average estimated per share fair value of shares purchased under the 2014 ESPP and 1999 ESPP in fiscal years 2017, 2016 and 2015, was $1.24, $0.92 and $0.90, respectively.

[0001564590-17-018633:notes:237]
|  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2016 |  |  | June 30, 2015 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Expected life |  | 4.00 years |  |  | 4.23 years |  |  | 0.49 years |  |  | 1.21years |  |  | 0.66 years |  |
| Risk-free interest rate |  |  | 1.78 | % |  |  | 1.17 | % |  |  | 0.40 | % |  |  | 0.33 | % |  |  | 0.10 | % |
| Volatility |  |  | 52 | % |  |  | 50 | % |  |  | 38 | % |  |  | 58 | % |  |  | 59 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-17-018633:notes:238]
401(k) Plan

[0001564590-17-018633:notes:239]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees.  Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $18,000 for calendar year 2017.  Employees age 50 or over may elect to contribute an additional $6,000. The amount contributed to the Plan is on a pre-tax basis.

[0001564590-17-018633:notes:240]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately.  In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year.  The program during fiscal 2017 is to match $0.50 for every Dollar contributed by the employee up to the first 2.5% of pay.  The Company’s matching contributions to the Plan totaled $1.4 million, $1.2 million and $1.1 million, for fiscal years 2017, 2016 and 2015, respectively.  No discretionary contributions were made in fiscal years 2017, 2016 or 2015.


## us-gaap:TreasuryStockTextBlock

[0001564590-17-018633:notes:241]
8. Common Stock Repurchases and Retirement

[0001564590-17-018633:notes:242]
Common Stock Repurchases

[0001564590-17-018633:notes:243]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which were to be purchased over a three year period.   On October 1, 2015 the repurchase program ended. No shares were repurchased during the years ended June 30, 2016 or 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-018633:notes:244]
9. Income Taxes

[0001564590-17-018633:notes:245]
Income before income taxes is as follows (in thousands):

[0001564590-17-018633:notes:246]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | (10,953 | ) |  | $ | (31,700 | ) |  | $ | (72,176 | ) |
| Foreign |  |  | 6,776 |  |  |  | 4,152 |  |  |  | 5,340 |  |
| Total |  | $ | (4,177 | ) |  | $ | (27,548 | ) |  | $ | (66,836 | ) |

[0001564590-17-018633:notes:247]
The provision for income taxes for fiscal years 2017, 2016 and 2015 consisted of the following (in thousands):

[0001564590-17-018633:notes:248]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (155 | ) |  | $ | 727 |  |  | $ | 476 |  |
| State |  |  | 168 |  |  |  | 75 |  |  |  | 13 |  |
| Foreign |  |  | 2,332 |  |  |  | 1,793 |  |  |  | 2,447 |  |
| Total current |  |  | 2,345 |  |  |  | 2,595 |  |  |  | 2,936 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 3,063 |  |  |  | 1,659 |  |  |  | 1,507 |  |
| State |  |  | 99 |  |  |  | 108 |  |  |  | 103 |  |
| Foreign |  |  | (1,167 | ) |  |  | (26 | ) |  |  | 261 |  |
| Total deferred |  |  | 1,995 |  |  |  | 1,741 |  |  |  | 1,871 |  |
| Provision for income taxes |  | $ | 4,340 |  |  | $ | 4,336 |  |  | $ | 4,807 |  |

[0001564590-17-018633:notes:249]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (35 percent) to income before taxes is explained below (in thousands):

[0001564590-17-018633:notes:250]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Tax at federal statutory rate |  | $ | (1,461 | ) |  | $ | (9,642 | ) |  | $ | (23,392 | ) |
| State income tax, net of federal benefit |  |  | 168 |  |  |  | 75 |  |  |  | 13 |  |
| Change in valuation allowance |  |  | 5,616 |  |  |  | 7,898 |  |  |  | 24,408 |  |
| Research and development credits |  |  | (1,355 | ) |  |  | (1,364 | ) |  |  | (303 | ) |
| Foreign earnings taxed at other than U.S. rates |  |  | (492 | ) |  |  | 1,678 |  |  |  | (1,113 | ) |
| Stock based compensation |  |  | (573 | ) |  |  | 3,564 |  |  |  | 2,298 |  |
| Goodwill amortization |  |  | 1,795 |  |  |  | 1,672 |  |  |  | 1,690 |  |
| Nondeductible officer compensation |  |  | 470 |  |  |  | 77 |  |  |  | — |  |
| Nondeductible meals and entertainment |  |  | 391 |  |  |  | 289 |  |  |  | 341 |  |
| AMT credit monetization |  |  | (155 | ) |  |  | — |  |  |  | — |  |
| Other |  |  | (64 | ) |  |  | 89 |  |  |  | 865 |  |
| Provision for income taxes |  | $ | 4,340 |  |  | $ | 4,336 |  |  | $ | 4,807 |  |

[0001564590-17-018633:notes:251]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001564590-17-018633:notes:252]
|  |  | June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 109,170 |  |  | $ | 108,563 |  |  | $ | 114,151 |  |
| Tax credit carry-forwards |  |  | 34,444 |  |  |  | 32,730 |  |  |  | 30,824 |  |
| Depreciation |  |  | 1,312 |  |  |  | — |  |  |  | — |  |
| Intangible amortization |  |  | 32,919 |  |  |  | 28,480 |  |  |  | 17,978 |  |
| Deferred revenue (net) |  |  | 10,612 |  |  |  | 7,955 |  |  |  | 7,811 |  |
| Warrant amortization |  |  | — |  |  |  | — |  |  |  | 1,355 |  |
| Inventory write-downs |  |  | 11,111 |  |  |  | 6,207 |  |  |  | 6,048 |  |
| Other allowances and accruals |  |  | 13,002 |  |  |  | 10,568 |  |  |  | 8,645 |  |
| Stock based compensation |  |  | 3,545 |  |  |  | 4,048 |  |  |  | 6,783 |  |
| Other |  |  | 4,270 |  |  |  | 4,275 |  |  |  | 5,902 |  |
| Total deferred tax assets |  |  | 220,385 |  |  |  | 202,826 |  |  |  | 199,497 |  |
| Valuation allowance |  |  | (219,403 | ) |  |  | (201,405 | ) |  |  | (197,576 | ) |
| Total net deferred tax assets |  |  | 982 |  |  |  | 1,421 |  |  |  | 1,921 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation |  |  | — |  |  |  | (343 | ) |  |  | (707 | ) |
| Goodwill amortization |  |  | (6,254 | ) |  |  | (4,459 | ) |  |  | (2,787 | ) |
| Foreign exchange gain |  |  | — |  |  |  | — |  |  |  | — |  |
| Deferred tax liability on foreign withholdings |  |  | (321 | ) |  |  | (235 | ) |  |  | (194 | ) |
| Total deferred tax liabilities |  |  | (6,575 | ) |  |  | (5,037 | ) |  |  | (3,688 | ) |
| Net deferred tax assets (liabilities) |  | $ | (5,593 | ) |  | $ | (3,616 | ) |  | $ | (1,767 | ) |
| Recorded as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net current deferred tax assets |  | $ | — |  |  | $ | — |  |  | $ | 760 |  |
| Net non-current deferred tax assets |  |  | 982 |  |  |  | 1,077 |  |  |  | 452 |  |
| Net non-current deferred tax liabilities |  |  | (6,575 | ) |  |  | (4,693 | ) |  |  | (2,979 | ) |
| Net deferred tax assets (liabilities) |  | $ | (5,593 | ) |  | $ | (3,616 | ) |  | $ | (1,767 | ) |

[0001564590-17-018633:notes:253]
The Company's global valuation allowance increased by $18.0 million in the fiscal year ended June 30, 2017 and $3.8 million in the fiscal year ended June 30, 2016. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against non-U.S. deferred tax assets in Australia, Brazil, Japan and Singapore.  The valuation allowance is determined by assessing both negative and positive available evidence to assess whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of the Company's business provides sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001564590-17-018633:notes:254]
As of June 30, 2017, the Company had net operating loss carry-forwards for U.S. federal and state tax purposes of $291.3 million and $93.7 million, respectively.  As of June 30, 2017, the Company also had foreign net operating loss carry-forwards in Ireland, Australia, Brazil and Japan of $46.7 million, $9.8 million, $7.3 million and $0.3 million, respectively.  As of June 30, 2017, the Company also had federal and state tax credit carry-forwards of $23.8 million and $16.4 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits with a small portion representing Alternative Minimum Tax Credits.  The U.S. federal net operating loss carry-forwards of $291.3 million will begin to expire in the fiscal year ending June 30, 2021 and state net operating losses of $93.7 million began to partially expire in the fiscal year ending June 30, 2017. The foreign net operating losses can generally be carried forward indefinitely.  Federal research and development tax credits of $15.5 million will expire beginning in fiscal 2019, if not utilized and foreign tax credits of $8.1 million will expire beginning in fiscal 2021.  North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2023, if not utilized. California state research and development tax credits of $15.5 million do not expire and can be carried forward indefinitely.

[0001564590-17-018633:notes:255]
As of January 2016, the Company performed an Internal Revenue Code section 382 analysis with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2016, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes.

[0001564590-17-018633:notes:256]
As of June 30, 2017, the Company intends to indefinitely reinvest the earnings of approximately $11.5 million of certain foreign corporations. The unrecognized deferred tax liability associated with these earnings is approximately $0.2 million.

[0001564590-17-018633:notes:257]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, Brazil, India, California, New Hampshire and North Carolina.  As of June 30, 2017, the Company is not currently under examination by any federal, state or foreign tax authority with respect to income taxes.

[0001564590-17-018633:notes:258]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.

[0001564590-17-018633:notes:259]
During the fiscal year ended June 30, 2014, the Company acquired the stock of Enterasys Networks, Inc. and as such they became a wholly owned subsidiary of Extreme Networks.  With respect to this acquisition, the Company made an election under Internal Revenue Code section 338(h)(10) to treat the acquisition as an asset purchase from a tax perspective.  Under this election the tax basis of all assets is effectively reset to that of fair market value and therefore the transaction did not result in the recording of an opening net deferred tax position as the Company's tax basis in the acquired assets equaled its book basis. The resulting intangible assets and goodwill are being amortized for tax purposes over 15 years.

[0001564590-17-018633:notes:260]
During the fiscal year ended June 30, 2017, the Company acquired certain networking assets from Zebra Technologies.  For tax purposes, the resulting intangible assets and goodwill from this acquisition are also being amortized over 15 years.

[0001564590-17-018633:notes:261]
As of June 30, 2017, the Company had $18.9 million of unrecognized tax benefits.  If fully recognized in the future, there would be no impact to the effective tax rate, and $18.9 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance.  The Company does not reasonably expect the amount of unrealized tax benefits to decrease during the next twelve months. The increase for fiscal year 2017 relates substantially to previously unrecorded foreign net operating losses.

[0001564590-17-018633:notes:262]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001564590-17-018633:notes:263]
| Balance at June 30, 2014 |  | $ | 11,600 |  |
| Decrease related to prior year tax positions |  |  | (225 | ) |
| Increase related to prior year tax positions |  |  | 288 |  |
| Increase related to current year tax positions |  |  | 254 |  |
| Lapse of statute of limitations |  |  | (158 | ) |
| Settlements with tax authorities |  |  | (400 | ) |
| Balance at June 30, 2015 |  |  | 11,359 |  |
| Increase related to prior year tax positions |  |  | 174 |  |
| Lapse of statute of limitations |  |  | 120 |  |
| Balance at June 30, 2016 |  |  | 11,653 |  |
| Increase related to prior year tax positions |  |  | 7,180 |  |
| Increase related to current year tax positions |  |  | 233 |  |
| Lapse of statute of limitations |  |  | (153 | ) |
| Balance at June 30, 2017 |  | $ | 18,913 |  |

[0001564590-17-018633:notes:264]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the consolidated statement of operations and totaled less than $0.1 million for each of the fiscal years 2017, 2016 and 2015.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-018633:notes:265]
10. Disclosure about Segments of an Enterprise and Geographic Areas

[0001564590-17-018633:notes:266]
We conduct business globally and are primarily managed on a geographic theater basis.  Our chief operating decision maker ("CODM"), who is our CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-17-018633:notes:267]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the CODM with respect to the allocation of resources and performance.

[0001564590-17-018633:notes:268]
The Company operates in one segment, the development and marketing of network infrastructure equipment.  Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan.

[0001564590-17-018633:notes:269]
The Company attributes revenues to geographic regions based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001564590-17-018633:notes:270]
|  |  | Year Ended |  |
| Net Revenues: |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 303,617 |  |  | $ | 237,933 |  |  | $ | 238,748 |  |
| Other |  |  | 24,530 |  |  |  | 44,455 |  |  |  | 31,931 |  |
| Total Americas |  |  | 328,147 |  |  |  | 282,388 |  |  |  | 270,679 |  |
| EMEA: |  |  |  |  |  |  |  |  |  |  |  |  |
| Germany |  |  | 81,001 |  |  |  | 65,799 |  |  |  | 67,316 |  |
| Other |  |  | 135,014 |  |  |  | 130,789 |  |  |  | 156,052 |  |
| Total EMEA |  |  | 216,015 |  |  |  | 196,588 |  |  |  | 223,368 |  |
| APAC: |  |  | 53,956 |  |  |  | 49,413 |  |  |  | 58,893 |  |
| Total net revenues |  | $ | 598,118 |  |  | $ | 528,389 |  |  | $ | 552,940 |  |

[0001564590-17-018633:notes:271]
The Company's long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-17-018633:notes:272]
| Long Lived Assets: |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Americas |  | $ | 64,890 |  |  | $ | 57,851 |  |  | $ | 87,071 |  |
| EMEA |  |  | 8,998 |  |  |  | 14,234 |  |  |  | 29,610 |  |
| APAC |  |  | 4,275 |  |  |  | 2,493 |  |  |  | 3,108 |  |
| Total long lived assets |  | $ | 78,163 |  |  | $ | 74,578 |  |  | $ | 119,789 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-018633:notes:273]
11. Net Loss Per Share

[0001564590-17-018633:notes:274]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to options, warrants and unvested restricted stock.  The following table presents the calculation of basic and diluted net loss per share (in thousands, except per share data):

[0001564590-17-018633:notes:275]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Net loss |  | $ | (8,517 | ) |  | $ | (31,884 | ) |  | $ | (71,643 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 108,273 |  |  |  | 103,074 |  |  |  | 99,000 |  |
| Net loss per share - basic and diluted |  | $ | (0.08 | ) |  | $ | (0.31 | ) |  | $ | (0.72 | ) |

[0001564590-17-018633:notes:276]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.  Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net loss per share since the effect of including them would have been anti-dilutive due to the net loss position of the Company during the periods presented.

[0001564590-17-018633:notes:277]
The following securities were excluded from the computation of outstanding diluted earnings per common share because they would have been anti-dilutive (in thousands):

[0001564590-17-018633:notes:278]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2015 |  |
| Options to purchase common stock |  |  | — |  |  |  | 6,937 |  |  |  | 7,542 |  |
| Restricted stock units |  |  | 220 |  |  |  | 353 |  |  |  | 133 |  |
| Employee Stock Purchase Plan shares |  |  | — |  |  |  | — |  |  |  | 185 |  |
| Total shares excluded |  |  | 220 |  |  |  | 7,290 |  |  |  | 7,675 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-018633:notes:279]
12. Foreign Exchange Forward Contracts

[0001564590-17-018633:notes:280]
The Company uses derivative financial instruments to manage exposures to foreign currency.  The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures.   The Company does not enter into derivatives for speculative or trading purposes.  The Company records all derivatives on the balance sheet as “Other accrued liabilities” at fair value.  Changes in the fair value of derivatives are recognized in earnings as “Other income (loss)”.  The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies.  Cash flows from such hedges are classified as operating activities.

[0001564590-17-018633:notes:281]
At June 30, 2017, forward foreign currency contracts had a notional principal amount of $6.7 million. These contracts have maturities of less than 60 days.  Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.  At June 30, 2016, the Company did not have any forward foreign currency contracts outstanding.

[0001564590-17-018633:notes:282]
Foreign currency transaction gains and losses from operations were losses of $0.7 million and $1.0 million in fiscal 2017 and 2015, respectively and gains of $1.3 million in fiscal 2016.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-018633:notes:283]
13. Restructuring Charges

[0001564590-17-018633:notes:284]
As of June 30, 2017, restructuring liabilities were $4.1 million and consisted of obligations pertaining to the estimated future obligations for non-cancelable lease payments and severance and benefits obligations. The restructuring liability of $4.1 million is recorded in "Other accrued liabilities" and “Other long-term liabilities” in the consolidated balance sheets.   During fiscal years 2017, 2016 and 2015, the Company recorded restructuring charges, net of reversals, of $8.9 million, $11.0 million and $9.8 million, respectively.  The charges are reflected in "Restructuring and related charges, net of reversals" in the consolidated statements of operations.

[0001564590-17-018633:notes:285]
Fiscal year 2017

[0001564590-17-018633:notes:286]
Pursuant with the WLAN Business acquisition from Zebra, the Company assumed a facility lease located at 6480 Via del Oro in San Jose, California (“Via del Oro”) and transferred the Company’s headquarters from Rio Robles Drive in San Jose, California (“Rio Robles”) to Via del Oro.  The Company consolidated its existing workforce with employees assumed from Zebra at the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to the Company’s move from the Rio Robles facility and abandonment of all leasehold improvements, it accelerated the amortization of the remaining leasehold improvements balance for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  The Company recorded accelerated amortization expense for the year ended June 30, 2017 of $2.6 million and it is reflected in "Restructuring and related charges, net of reversals" in the condensed consolidated statements of operations.

[0001564590-17-018633:notes:287]
The Company entered into a sublease agreement for its Rio Robles facility during the third quarter of fiscal 2017.  The sublease is for the remaining duration of the Company’s lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease. The net adjustments, including modifications to its future obligations for non-cancellable lease payments and related future subleasing income resulted in additional charges of $2.0 million during fiscal 2017. The excess facilities payments will continue through fiscal year 2023.

[0001564590-17-018633:notes:288]
In anticipation of the acquisition of Avaya Networking (see Note 14), the Company reoccupied the majority of its exited space at its Salem New Hampshire location during its fiscal fourth quarter to accommodate the growth in headcount and lab facility requirements.  This action resulted in a reversal of prior accruals of $1.3 million.

[0001564590-17-018633:notes:289]
In conjunction with the consolidation actions noted above, the Company announced a reduction-in-force affecting 90 employees.  The Company recorded $5.6 million in severance and benefits charges, net during the year ended June 30, 2017.  Cash payments of $3.8 million were made during the year and the balance of cash payments are expected to be paid by the end of the second quarter of fiscal 2018.

[0001564590-17-018633:notes:290]
Fiscal year 2016

[0001564590-17-018633:notes:291]
During fiscal 2016, the Company continued its initiative to realign its operations by abandoning excess facilities, primarily in San Jose, California; Salem, New Hampshire; Morrisville, North Carolina and other smaller leased locations. The abandoned facilities represented approximately 32% of the floor space in the aggregate at these locations and included general office and warehouse space.

[0001564590-17-018633:notes:292]
In conjunction with the exiting of facilities noted above, we incurred $11.0 million of restructuring charges. Excess facilities charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and contract termination charges of $5.4 million, acceleration of depreciation of leasehold improvements of $4.5 million, professional fees of $1.0 million and other of $0.1 million.

[0001564590-17-018633:notes:293]
Significant restructuring charges incurred during 2016, by location, included $1.8 million of charges for excess facilities pertaining to the estimated future obligations for non-cancelable lease payments at Rio Robles.  This represented 39% of the San Jose leased space.  The Company amended its facility lease at its North Carolina location and exited excess space while recording $4.1 million of charges, which included $3.1 million in accelerated depreciation of leasehold improvements. This action represented 36% of the North Carolina location lease space. The Company recorded $4.4 million of charges for excess facilities at its Salem location, which included $1.3 million in accelerated depreciation of leasehold improvements.  This action represented 27% of the Salem lease space.

[0001564590-17-018633:notes:294]
Fiscal year 2015

[0001564590-17-018633:notes:295]
During the fourth quarter of fiscal 2015, the Company reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment.  We initiated a plan to reduce worldwide headcount by more than 225 employees, primarily in sales and marketing, as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions.  The Company recorded $9.7 million of charges associated with this initiative.   The restructuring liability related to this initiative was fully paid as of June 30, 2016.

[0001564590-17-018633:notes:296]
Restructuring liabilities consist of (in thousands):

[0001564590-17-018633:notes:297]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2014 |  | $ | 322 |  |  | $ | — |  |  | $ | — |  |  | $ | 322 |  |
| Period charges |  |  | — |  |  |  | 9,694 |  |  |  | 125 |  |  |  | 9,819 |  |
| Period payments |  |  | (322 | ) |  |  | (3,957 | ) |  |  | (8 | ) |  |  | (4,287 | ) |
| Balance as of June 30, 2015 |  |  | — |  |  |  | 5,737 |  |  |  | 117 |  |  |  | 5,854 |  |
| Period charges |  |  | 10,811 |  |  |  | 668 |  |  |  | 237 |  |  |  | 11,716 |  |
| Period reversals |  |  | (18 | ) |  |  | (618 | ) |  |  | (90 | ) |  |  | (726 | ) |
| Non cash adjustments |  |  | (4,463 | ) |  |  | — |  |  |  | — |  |  |  | (4,463 | ) |
| Period payments |  |  | (1,686 | ) |  |  | (5,787 | ) |  |  | (264 | ) |  |  | (7,737 | ) |
| Balance as of June 30, 2016 |  |  | 4,644 |  |  |  | — |  |  |  | — |  |  |  | 4,644 |  |
| Period charges |  |  | 1,951 |  |  |  | 5,728 |  |  |  | 2,663 |  |  |  | 10,342 |  |
| Period reversals |  |  | (1,337 | ) |  |  | (109 | ) |  |  | — |  |  |  | (1,446 | ) |
| Non cash adjustments |  |  | — |  |  |  | — |  |  |  | (2,578 | ) |  |  | (2,578 | ) |
| Period payments |  |  | (3,074 | ) |  |  | (3,766 | ) |  |  | — |  |  |  | (6,840 | ) |
| Balance as of June 30, 2017 |  | $ | 2,184 |  |  | $ | 1,853 |  |  | $ | 85 |  |  | $ | 4,122 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,394 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,728 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-17-018633:notes:298]
14. Subsequent Event

[0001564590-17-018633:notes:299]
Avaya Acquisition

[0001564590-17-018633:notes:300]
On July 14, 2017, (the “Closing”) the Company completed its acquisition of Avaya’s fabric-based secure networking solutions and network security solutions business (“Avaya Networking”), that had been announced on March 7, 2017.  Upon the terms and subject to the conditions of the asset purchase agreement, the Company will acquire customers, employees, technology and other assets of Avaya Networking, as well as assume certain contracts and other liabilities of Avaya Networking, for a purchase price of $100.0 million, subject to adjustments set forth in the Purchase Agreement related to net working capital, deferred revenue, certain assumed lease obligations and certain assumed pension obligations for transferring employees of Avaya Networking.  Pursuant to certain ancillary agreements, Avaya will also provide the Company with access to specified technology related to Avaya Networking, as well as transition services for a period of time following the Closing of the transaction. As a condition of the agreement, the Company had made deposits of $10.2 million in the third quarter of fiscal 2017, which were applied to the purchase price upon Closing.  The deposit is included in “Prepaid and other current assets” in the consolidated balance sheet as of June 30, 2017.

[0001564590-17-018633:notes:301]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Avaya Networking will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of Avaya Networking will be included in the operations of the Company beginning with the Closing. As of the date of the filing of this Form 10-K, the initial purchase price allocation has not been prepared as there has not been sufficient time to complete the related activities

[0001564590-17-018633:notes:302]
During the fiscal year ended June 30, 2017, the Company recognized transaction costs of $2.2 million which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-17-018633:notes:303]
Borrowing Facility

[0001564590-17-018633:notes:304]
In connection with the Closing noted above, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and Lenders.  Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the Term Loan in a principal amount of up to $183.7 million and (b) the Revolver in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver until July 2022, (iii) provides for an uncommitted additional incremental loan facility in a principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as Lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed an additional $80.0 million under the Term Loan which was used to fund the purchase of the Avaya Networking business.

[0001564590-17-018633:notes:305]
Borrowings under the Amended Term Loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum).  Borrowings under the Revolving Loan bear interest, at the Company’s option, at a rate equal to either the LIBOR rate, plus an applicable margin (currently 3.25% per annum) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based).  The Revolving Loan has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum.
