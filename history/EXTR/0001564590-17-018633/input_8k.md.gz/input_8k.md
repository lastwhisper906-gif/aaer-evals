# EXTR 8-K — 0001564590-17-017659 filed 2017-08-14

## item codes, every 8-K on or before 2017-09-13

- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2017-09-13

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-017659:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-17-017659:8k_2_02:2]
extr-ex991_6.htm

[0001564590-17-017659:8k_2_02:3]
Exhibit 99.1

[0001564590-17-017659:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-17-017659:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Laurie Little |  | Media Contact Ben Haber |
| 212/481-2050 |  | 617/624-3200 |
| extreme@tpr-ir.com |  | ExtremeUS@racepointglobal.com |

[0001564590-17-017659:8k_2_02:6]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2017 Financial Results

[0001564590-17-017659:8k_2_02:7]
SAN JOSE, Calif., August 14, 2017 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal fourth quarter and full fiscal year ended June 30, 2017.

[0001564590-17-017659:8k_2_02:8]
Fourth Quarter Results:

[0001564590-17-017659:8k_2_02:9]
|  | • | Fourth quarter revenue was $178.7 million, an increase of 28% year-over-year. |

[0001564590-17-017659:8k_2_02:10]
|  | • | GAAP gross margin for the fourth fiscal quarter was 56.9% and non-GAAP gross margin was 57.1%, an increase of 230 basis points year-over-year. |

[0001564590-17-017659:8k_2_02:11]
|  | • | GAAP operating margin for the fourth fiscal quarter was 8.2% and non-GAAP operating margin was 12.2%, an increase of 360 basis points year-over-year. |

[0001564590-17-017659:8k_2_02:12]
|  | • | GAAP net income for the fourth fiscal quarter was $12.2 million, or $0.11 per diluted share, and non-GAAP net income was $19.4 million, or $0.17 per diluted share, an increase of $0.07 year-over-year. |

[0001564590-17-017659:8k_2_02:13]
Full Year Results:

[0001564590-17-017659:8k_2_02:14]
|  | • | Fiscal year GAAP revenue was $598.1 million, an increase of 13% year-over-year. |

[0001564590-17-017659:8k_2_02:15]
|  | • | Fiscal year GAAP net loss per share was $0.08 and non-GAAP net income per share was $0.46, an increase of $0.18 year-over-year. |

[0001564590-17-017659:8k_2_02:16]
“Led by solid organic growth and continued execution of our recently acquired WLAN business, we concluded 2017 with one of our strongest performances in recent years," stated Ed Meyercord, President and CEO of Extreme Networks.  “During our fourth quarter, revenue from our Extreme solutions portfolio generated organic growth of 6% driven by record wireless performance that was at or above current industry growth rates, while our non-GAAP gross margins expanded by 230 basis points year-over-year to 57.1% through our high-quality solution selling strategy and disciplined approach to discounting.  Even more noteworthy, for the first time since 2013, we achieved positive GAAP earnings, while delivering non-GAAP earnings at or above our expectations for the ninth consecutive quarter.

[0001564590-17-017659:8k_2_02:17]
“The successful integration of our WLAN acquisition validates our pursuit of accretive acquisitions and we are poised to build on this momentum with the recent closing of the Avaya networking business acquisition and the pending closing of the Brocade data center networking business acquisition.  Heading into fiscal 2018, we plan to leverage our expanded market share and significant cross selling opportunities

[0001564590-17-017659:8k_2_02:18]
supported by the combination of these transformative acquisitions, greater penetration across our target verticals and the continued introduction of new products and services.   We anticipate these actions will enable us to reach critical mass and build on our leadership position in the enterprise networking industry as we continue to deliver software-driven, end-to-end, wired and wireless networking solutions for enterprise customers," concluded Meyercord.

[0001564590-17-017659:8k_2_02:19]
Recent Key Events:

[0001564590-17-017659:8k_2_02:20]
|  | • | Closed the Acquisition of Avaya’s Networking Business: Extreme completed the acquisition of |

[0001564590-17-017659:8k_2_02:21]
|  | • | Avaya’s networking business in July and has commenced the integration process. As part of this transaction, Extreme acquired customers, employees and technology assets from Avaya that strengthen Extreme’s position as a leader across the education, healthcare, and government markets. Technology assets include Avaya’s award winning fabric technology for highly secure, simplified access, management and control, in addition to a new family of high performance modular switches, software tools and IoT technology. |

[0001564590-17-017659:8k_2_02:22]
|  | • | Introduced New Networking Solutions and Enhancements to Software, Switching, and Wireless portfolio: |

[0001564590-17-017659:8k_2_02:23]
|  | • | Information Governance Engine (software): Extreme's Information Governance Engine replaces the current manual and error-prone network compliance process with a fully automated and repeatable solution capable of completing an assessment in minutes. This addition to Extreme's product portfolio highlights the company's focus on the technology and security needs of today's healthcare industry and other verticals that are challenged by the increasing use of mobile and IoT devices to improve patient care. |

[0001564590-17-017659:8k_2_02:24]
|  | • | ExtremeGuest Analytics (software): Enables retailers and hospitality to provide simple guest sign-on, obtain in-depth analytics of shoppers/visitors, including demographics and preferences, and gather metrics between stores and locations. These analytics provide brick and mortar retailers with the tools they need to compete with online retailers including information such as the number of mobile customers that entered a store, new customers vs. repeat customers, and customer duration in a store. |

[0001564590-17-017659:8k_2_02:25]
|  | • | ExtremeSwitching 200 Series (project name ‘Street Fighter’): A new family of economical, managed Gigabit Ethernet switches that address the wired connections of PCs, servers and storage devices in addition to PoE to power wireless APs and IP phones. The family can also be flexibly managed via ExtremeCloud, ExtremeManagement, web client or industry-standard command line interface (CLI). |

[0001564590-17-017659:8k_2_02:26]
|  | • | ExtremeWireless WiNG AP 7602 and AP 7622: Priced for the budget-conscious mass market applications and include enterprise-grade features and Bluetooth customer engagement applicable in our target verticals, especially hospitality and retail. |

[0001564590-17-017659:8k_2_02:27]
|  | • | Key Customer Wins in Focus Markets: Extreme Networks continued to showcase customer momentum across the global education, hospitality and government markets. Customers continue to note Extreme's software and services as value added differentiators for choosing our solutions. Notable customer wins in key vertical markets include the Tampa Bay Buccaneers, the Metro Toronto Convention Centre (Canada’s Largest Convention Center), Suffolk University, Humble Independent School District, Perth & Kinross Council. Papworth Hospital and Bowen Center. |

[0001564590-17-017659:8k_2_02:28]
|  | • | Update on Brocade Acquisition: Extreme expects to close on its purchase of the data center networking assets of Brocade Communications Systems (“Brocade”) within 2-3 business days of the completed Brocade – Broadcom Limited merger, currently expected to close during Brocade’s fourth fiscal quarter ending October 29, 2017. |

[0001564590-17-017659:8k_2_02:29]
Fiscal Q4 2017 Financial Metrics:

[0001564590-17-017659:8k_2_02:30]
(in millions, except percentages and per share information)

[0001564590-17-017659:8k_2_02:31]
|  |  | 2017 |  |  | 2016 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 140.8 |  |  | $ | 106.0 |  |  | $ | 34.7 |  |  |  | 33 | % |
| Service |  |  | 38.0 |  |  |  | 33.6 |  |  |  | 4.4 |  |  |  | 13 | % |
| Total Net Revenue |  | $ | 178.7 |  |  | $ | 139.6 |  |  | $ | 39.1 |  |  |  | 28 | % |
| Gross Margin |  |  | 56.9 | % |  |  | 52.1 | % |  | 480bps |  |  |  | 9 | % |
| Operating Margin |  |  | 8.2 | % |  |  | (.3 | )% |  | 850bps |  |  | NM |  |
| Net Income (Loss) |  | $ | 12.2 |  |  | $ | (2.3 | ) |  | $ | 14.5 |  |  | NM |  |
| Income (loss) per basic and diluted share |  | $ | 0.11 |  |  | $ | (0.02 | ) |  | $ | 0.13 |  |  | NM |  |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 140.8 |  |  | $ | 106.0 |  |  | $ | 34.7 |  |  |  | 33 | % |
| Service |  |  | 38.0 |  |  |  | 34.0 |  |  |  | 4.0 |  |  |  | 12 | % |
| Total Net Revenue |  | $ | 178.7 |  |  | $ | 140.0 |  |  | $ | 38.7 |  |  |  | 28 | % |
| Gross Margin |  |  | 57.1 | % |  |  | 54.8 | % |  | 230bps |  |  |  | 5 | % |
| Operating Margin |  |  | 12.2 | % |  |  | 8.6 | % |  | 360bps |  |  |  | 42 | % |
| Net Income |  | $ | 19.4 |  |  | $ | 10.2 |  |  | $ | 9.2 |  |  |  | 90 | % |
| Earnings per diluted share |  | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.07 |  |  |  | 70 | % |

[0001564590-17-017659:8k_2_02:32]
|  | • | Cash and investments ended the quarter at $130.5 million, an increase of $13.2 million from the prior quarter and an increase of $36.4 million from the prior year. |

[0001564590-17-017659:8k_2_02:33]
|  | • | Accounts receivable balance ending Q4 was $120.8 million, with days sales outstanding (“DSO”) of 61. |

[0001564590-17-017659:8k_2_02:34]
|  | • | Inventory ending Q4 was $45.9 million, a decrease of $1.8 million from the prior quarter and an increase of $4.9 million from the prior year. |

[0001564590-17-017659:8k_2_02:35]
Business Outlook:

[0001564590-17-017659:8k_2_02:36]
For its first quarter of fiscal 2018 ending September 30, 2017, the Company is targeting revenue in a range of $200.0 million to $210.0 million.  GAAP gross margin is targeted between 53.5% and 55.5% and non-GAAP gross margin is targeted between 55.5% and 57.5%. Operating expenses are targeted to be between $105.0 million and $109.0 million on a GAAP basis and $96.0 million to $99.0 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $1.2 million to net income of $5.5 million or earnings of $(0.01) to $0.05 per diluted share.  Non-GAAP earnings are targeted in a range of net income of $12.5 million to $19.5 million, or $0.11 to $0.17 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 116.2 million average outstanding shares.

[0001564590-17-017659:8k_2_02:37]
The following table shows the GAAP to non-GAAP reconciliation for Q1FY’18 guidance:

[0001564590-17-017659:8k_2_02:38]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 53.5% - 55.5% |  |  | 0.5% - 3.7% |  |  | ($0.01) - $0.05 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles |  | 2.1% |  |  |  | 2.1% |  |  | $ | 0.03 |  |
| Stock based compensation |  | 0.1% |  |  |  | 1.6% |  |  | $ | 0.03 |  |
| Amortization of non product intangibles | - |  |  |  | 1.0% |  |  | $ | 0.02 |  |
| Acquisition and integration costs | - |  |  |  | 2.3% |  |  | $ | 0.04 |  |
| Non-GAAP | 55.5% - 57.5% |  |  | 7.5% - 10.4% |  |  | $0.11 - $0.17 |  |

[0001564590-17-017659:8k_2_02:39]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-17-017659:8k_2_02:40]
Conference Call:

[0001564590-17-017659:8k_2_02:41]
Extreme will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the fourth fiscal quarter results as well as the first fiscal quarter 2018 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August 13, 2018.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406   Conference ID # 6976972.

[0001564590-17-017659:8k_2_02:42]
About Extreme Networks:

[0001564590-17-017659:8k_2_02:43]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, on premise or through the cloud, we go to extreme measures for our customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-17-017659:8k_2_02:44]
Extreme Networks and the Extreme Networks logo, ExtremeManagement, ExtremeWireless, ExtremeControl and ExtremeAnalytics are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-17-017659:8k_2_02:45]
Non-GAAP Financial Measures:

[0001564590-17-017659:8k_2_02:46]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, executive transition costs, litigation expenses and overhead adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the

[0001564590-17-017659:8k_2_02:47]
Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-17-017659:8k_2_02:48]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-17-017659:8k_2_02:49]
Forward Looking Statements:

[0001564590-17-017659:8k_2_02:50]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-17-017659:8k_2_02:51]
EXTREME NETWORKS, INC.

[0001564590-17-017659:8k_2_02:52]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-017659:8k_2_02:53]
(In thousands)

[0001564590-17-017659:8k_2_02:54]
(Unaudited)

[0001564590-17-017659:8k_2_02:55]
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 130,450 |  |  | $ | 94,122 |  |
| Accounts receivable, net of allowances of $1,732 at June 30, 2017 and $3,257 at June 30, 2016 |  |  | 120,770 |  |  |  | 81,419 |  |
| Inventories |  |  | 45,880 |  |  |  | 40,989 |  |
| Prepaid expenses and other current assets |  |  | 27,867 |  |  |  | 12,438 |  |
| Total current assets |  |  | 324,967 |  |  |  | 228,968 |  |
| Property and equipment, net |  |  | 30,240 |  |  |  | 29,580 |  |
| Intangible assets, net |  |  | 25,337 |  |  |  | 19,762 |  |
| Goodwill |  |  | 80,216 |  |  |  | 70,877 |  |
| Other assets |  |  | 22,586 |  |  |  | 25,236 |  |
| Total assets |  | $ | 483,346 |  |  | $ | 374,423 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 12,280 |  |  | $ | 17,628 |  |
| Accounts payable |  |  | 31,587 |  |  |  | 30,711 |  |
| Accrued compensation and benefits |  |  | 42,662 |  |  |  | 27,145 |  |
| Accrued warranty |  |  | 10,007 |  |  |  | 9,600 |  |
| Deferred revenue, net |  |  | 79,048 |  |  |  | 72,934 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  |  | 43,525 |  |  |  | 26,817 |  |
| Other accrued liabilities |  |  | 36,713 |  |  |  | 26,691 |  |
| Total current liabilities |  |  | 255,822 |  |  |  | 211,526 |  |
| Deferred revenue, less current portion |  |  | 25,293 |  |  |  | 21,926 |  |
| Long-term debt, less current portion |  |  | 80,422 |  |  |  | 37,446 |  |
| Deferred income taxes |  |  | 6,576 |  |  |  | 4,693 |  |
| Other long-term liabilities |  |  | 8,526 |  |  |  | 8,635 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 106,707 |  |  |  | 90,197 |  |
| Total liabilities and stockholders’ equity |  | $ | 483,346 |  |  | $ | 374,423 |  |

[0001564590-17-017659:8k_2_02:56]
EXTREME NETWORKS, INC.

[0001564590-17-017659:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-017659:8k_2_02:58]
(In thousands, except per share amounts)

[0001564590-17-017659:8k_2_02:59]
(Unaudited)

[0001564590-17-017659:8k_2_02:60]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 140,750 |  |  | $ | 106,017 |  |  | $ | 451,459 |  |  | $ | 395,464 |  |
| Service |  |  | 37,951 |  |  |  | 33,600 |  |  |  | 146,659 |  |  |  | 132,925 |  |
| Total net revenues |  |  | 178,701 |  |  |  | 139,617 |  |  |  | 598,118 |  |  |  | 528,389 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 61,740 |  |  |  | 54,462 |  |  |  | 217,727 |  |  |  | 208,739 |  |
| Service |  |  | 15,222 |  |  |  | 12,480 |  |  |  | 55,906 |  |  |  | 48,862 |  |
| Total cost of revenues |  |  | 76,962 |  |  |  | 66,942 |  |  |  | 273,633 |  |  |  | 257,601 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 79,010 |  |  |  | 51,555 |  |  |  | 233,732 |  |  |  | 186,725 |  |
| Service |  |  | 22,729 |  |  |  | 21,120 |  |  |  | 90,753 |  |  |  | 84,063 |  |
| Total gross profit |  |  | 101,739 |  |  |  | 72,675 |  |  |  | 324,485 |  |  |  | 270,788 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 26,721 |  |  |  | 18,885 |  |  |  | 93,724 |  |  |  | 78,721 |  |
| Sales and marketing |  |  | 46,103 |  |  |  | 39,364 |  |  |  | 162,927 |  |  |  | 150,806 |  |
| General and administrative |  |  | 10,568 |  |  |  | 9,767 |  |  |  | 37,864 |  |  |  | 37,675 |  |
| Acquisition and integration costs |  |  | 3,197 |  |  |  | - |  |  |  | 13,105 |  |  |  | 1,145 |  |
| Restructuring and related charges, net of reversals |  |  | (676 | ) |  |  | 998 |  |  |  | 8,896 |  |  |  | 10,990 |  |
| Amortization of intangibles |  |  | 1,192 |  |  |  | 4,141 |  |  |  | 8,702 |  |  |  | 17,001 |  |
| Total operating expenses |  |  | 87,105 |  |  |  | 73,155 |  |  |  | 325,218 |  |  |  | 296,338 |  |
| Operating income (loss) |  |  | 14,634 |  |  |  | (480 | ) |  |  | (733 | ) |  |  | (25,550 | ) |
| Interest income |  |  | 315 |  |  |  | 29 |  |  |  | 689 |  |  |  | 113 |  |
| Interest expense |  |  | (1,086 | ) |  |  | (694 | ) |  |  | (4,086 | ) |  |  | (3,098 | ) |
| Other income (expense), net |  |  | (598 | ) |  |  | 174 |  |  |  | (47 | ) |  |  | 987 |  |
| Income (loss) before income taxes |  |  | 13,265 |  |  |  | (971 | ) |  |  | (4,177 | ) |  |  | (27,548 | ) |
| Provision for income taxes |  |  | 1,088 |  |  |  | 1,369 |  |  |  | 4,340 |  |  |  | 4,336 |  |
| Net income (loss) |  | $ | 12,177 |  |  | $ | (2,340 | ) |  | $ | (8,517 | ) |  | $ | (31,884 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.11 |  |  | $ | (0.02 | ) |  | $ | (0.08 | ) |  | $ | (0.31 | ) |
| Net income (loss) per share - diluted |  | $ | 0.11 |  |  | $ | (0.02 | ) |  | $ | (0.08 | ) |  | $ | (0.31 | ) |
| Shares used in per share calculation - basic |  |  | 110,500 |  |  |  | 104,837 |  |  |  | 108,273 |  |  |  | 103,074 |  |
| Shares used in per share calculation - diluted |  |  | 114,524 |  |  |  | 104,837 |  |  |  | 108,273 |  |  |  | 103,074 |  |

[0001564590-17-017659:8k_2_02:61]
EXTREME NETWORKS, INC.

[0001564590-17-017659:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-017659:8k_2_02:63]
(In thousands)

[0001564590-17-017659:8k_2_02:64]
(Unaudited)

[0001564590-17-017659:8k_2_02:65]
|  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Net cash provided by operating activities |  | $ | 59,283 |  |  | $ | 30,366 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (10,425 | ) |  |  | (5,327 | ) |
| Acquisition |  |  | (51,088 | ) |  |  | - |  |
| Deposit related to future acquisition |  |  | (10,239 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (71,752 | ) |  |  | (5,327 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | - |  |  |  | 15,000 |  |
| Borrowings under Term Loan |  |  | 48,250 |  |  |  |  |  |
| Loan fees on borrowings |  |  | (1,327 | ) |  |  |  |  |
| Repayment of debt |  |  | (10,038 | ) |  |  |  |  |
| Proceeds from issuance of common stock |  |  | 11,823 |  |  |  | 4,637 |  |
| Net cash provided by (used in) financing activities |  |  | 48,708 |  |  |  | 19,637 |  |
| Foreign currency effect on cash |  |  | 89 |  |  |  | (404 | ) |
| Net increase in cash and cash equivalents |  |  | 36,328 |  |  |  | 44,272 |  |
| Cash and cash equivalents at beginning of period |  |  | 94,122 |  |  |  | 76,225 |  |
| Cash and cash equivalents at end of period |  | $ | 130,450 |  |  | $ | 120,497 |  |

[0001564590-17-017659:8k_2_02:66]
Extreme Networks, Inc.

[0001564590-17-017659:8k_2_02:67]
Non-GAAP Measures of Financial Performance

[0001564590-17-017659:8k_2_02:68]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-17-017659:8k_2_02:69]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of intangibles, restructuring expenses, executive transition expenses, litigation expense and overhead adjustments.

[0001564590-17-017659:8k_2_02:70]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-17-017659:8k_2_02:71]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-17-017659:8k_2_02:72]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustment, amortization of intangibles, restructuring expenses, executive transition costs, litigation expenses and overhead adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-17-017659:8k_2_02:73]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-17-017659:8k_2_02:74]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-17-017659:8k_2_02:75]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Zebra Technologies Corporation’s wireless LAN business b) Avaya, Inc.’s networking assets, as well as the fabric-based secure networking solutions and network security

[0001564590-17-017659:8k_2_02:76]
solutions business of Avaya, Inc., and c) Brocade’s data center assets; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-17-017659:8k_2_02:77]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-17-017659:8k_2_02:78]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-17-017659:8k_2_02:79]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-17-017659:8k_2_02:80]
Restructuring expenses. Restructuring expenses primarily consist of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-17-017659:8k_2_02:81]
Executive transition expenses.  Executive transition expenses consist of severance and termination benefits and legal transition cash transactions.  The expenses are incurred through execution of pre-established employment contracts with senior executives.  The Company does not believe these expenses are reflective of ongoing cash requirements related to its operating results.

[0001564590-17-017659:8k_2_02:82]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matter as a result of a securities laws class action lawsuit.

[0001564590-17-017659:8k_2_02:83]
Overhead adjustments. Overhead adjustment relates to service inventory overhead capitalization, this was a one-time event and was non-cash in nature.

[0001564590-17-017659:8k_2_02:84]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-17-017659:8k_2_02:85]
EXTREME NETWORKS, INC.

[0001564590-17-017659:8k_2_02:86]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-017659:8k_2_02:87]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-17-017659:8k_2_02:88]
(In thousands, except percentage and per share amounts)

[0001564590-17-017659:8k_2_02:89]
(Unaudited)

[0001564590-17-017659:8k_2_02:90]
| Non-GAAP Revenue | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Revenue - GAAP Basis | $ | 178,701 |  |  | $ | 139,617 |  |  | $ | 598,118 |  |  | $ | 528,389 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,508 |  |
| Revenue - Non-GAAP Basis | $ | 178,701 |  |  | $ | 139,994 |  |  | $ | 598,251 |  |  | $ | 529,897 |  |

[0001564590-17-017659:8k_2_02:91]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Gross profit - GAAP Basis | $ | 101,739 |  |  | $ | 72,675 |  |  | $ | 324,485 |  |  | $ | 270,788 |  |
| Gross margin - GAAP Basis percentage |  | 56.9 | % |  |  | 52.1 | % |  |  | 54.3 | % |  |  | 51.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 185 |  |  |  | 279 |  |  |  | 922 |  |  |  | 1,923 |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,508 |  |
| Acquired inventory adjustments |  | - |  |  |  | - |  |  |  | 4,263 |  |  |  | - |  |
| Acquisition and integration costs |  | (579 | ) |  |  | - |  |  |  | 4,525 |  |  |  | - |  |
| Amortization of intangibles |  | 633 |  |  |  | 3,417 |  |  |  | 6,661 |  |  |  | 14,834 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Gross profit - Non-GAAP Basis | $ | 101,978 |  |  | $ | 76,748 |  |  | $ | 340,989 |  |  | $ | 287,560 |  |
| Gross margin - Non-GAAP Basis percentage |  | 57.1 | % |  |  | 54.8 | % |  |  | 57.0 | % |  |  | 54.3 | % |

[0001564590-17-017659:8k_2_02:92]
| Non-GAAP Operating Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| GAAP operating income (loss) percentage | $ | 14,634 |  |  | $ | (480 | ) |  | $ | (733 | ) |  | $ | (25,550 | ) |
| GAAP operating income (loss) percentage |  | 8.2 | % |  |  | (.3 | )% |  |  | (.1 | )% |  |  | (4.8 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,304 |  |  |  | 2,673 |  |  |  | 12,633 |  |  |  | 14,792 |  |
| Acquisition and integration costs |  | 2,618 |  |  |  | - |  |  |  | 17,630 |  |  |  | 1,145 |  |
| Restructuring charge, net of reversal |  | (676 | ) |  |  | 998 |  |  |  | 8,896 |  |  |  | 10,990 |  |
| Acquired inventory adjustments |  | - |  |  |  | - |  |  |  | 4,263 |  |  |  | - |  |
| Amortization of intangibles |  | 1,825 |  |  |  | 7,558 |  |  |  | 15,363 |  |  |  | 31,835 |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,508 |  |
| Executive transition costs |  | - |  |  |  | 771 |  |  |  | 34 |  |  |  | 2,166 |  |
| Litigation |  | 166 |  |  |  | 167 |  |  |  | 385 |  |  |  | 331 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Total adjustments to GAAP operating income (loss) | $ | 7,237 |  |  | $ | 12,544 |  |  | $ | 59,337 |  |  | $ | 61,274 |  |
| Non-GAAP operating income | $ | 21,871 |  |  | $ | 12,064 |  |  | $ | 58,604 |  |  | $ | 35,724 |  |
| Non-GAAP operating income percentage |  | 12.2 | % |  |  | 8.6 | % |  |  | 9.8 | % |  |  | 6.7 | % |

[0001564590-17-017659:8k_2_02:93]
| Non-GAAP Net Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| GAAP net income (loss) | $ | 12,177 |  |  | $ | (2,340 | ) |  | $ | (8,517 | ) |  | $ | (31,884 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,304 |  |  |  | 2,673 |  |  |  | 12,633 |  |  |  | 14,792 |  |
| Acquisition and integration costs |  | 2,618 |  |  |  | - |  |  |  | 17,630 |  |  |  | 1,145 |  |
| Restructuring charge, net of reversal |  | (676 | ) |  |  | 998 |  |  |  | 8,896 |  |  |  | 10,990 |  |
| Amortization of intangibles |  | 1,825 |  |  |  | 7,558 |  |  |  | 15,363 |  |  |  | 31,835 |  |
| Acquired inventory adjustments |  | - |  |  |  | - |  |  |  | 4,263 |  |  |  | - |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,508 |  |
| Executive transition costs |  | - |  |  |  | 771 |  |  |  | 34 |  |  |  | 2,166 |  |
| Litigation |  | 166 |  |  |  | 167 |  |  |  | 385 |  |  |  | 331 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Total adjustments to GAAP net income (loss) | $ | 7,237 |  |  | $ | 12,544 |  |  | $ | 59,337 |  |  | $ | 61,274 |  |
| Non-GAAP net income | $ | 19,414 |  |  | $ | 10,204 |  |  | $ | 50,820 |  |  | $ | 29,390 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.46 |  |  | $ | 0.28 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 114,524 |  |  |  | 107,275 |  |  |  | 111,472 |  |  |  | 105,306 |  |

[0001564590-17-017659:8k_2_02:94]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Cash flow provided by operations | $ | 15,161 |  |  | $ | 11,451 |  |  | $ | 59,283 |  |  | $ | 30,366 |  |
| Less: PP&E CapEx spending |  | (2,593 | ) |  | $ | (2,529 | ) |  |  | (10,425 | ) |  |  | (5,327 | ) |
| Total free cash flow | $ | 12,568 |  |  | $ | 8,922 |  |  | $ | 48,858 |  |  | $ | 25,039 |  |
