# EXTR 8-K — 0001193125-26-025650 filed 2026-01-28

## item codes, every 8-K on or before 2026-01-29

- 2026-01-28 0001193125-26-025650 — 2.02, 9.01
- 2026-01-07 0001193125-26-005441 — 5.02
- 2025-11-13 0001193125-25-280277 — 5.07, 9.01
- 2025-11-10 0001193125-25-273961 — 7.01, 9.01
- 2025-10-29 0001193125-25-254626 — 2.02, 9.01
- 2025-08-06 0000950170-25-103531 — 2.02, 9.01
- 2025-04-30 0000950170-25-060571 — 2.02, 9.01
- 2025-02-18 0000950170-25-021808 — 8.01, 9.01
- 2025-01-29 0000950170-25-010203 — 2.02, 9.01
- 2024-11-15 0000950170-24-127573 — 5.07, 9.01
- 2024-10-30 0000950170-24-118589 — 2.02, 9.01
- 2024-08-07 0000950170-24-092273 — 2.02, 9.01
- 2024-05-01 0000950170-24-050891 — 2.02, 9.01
- 2024-01-31 0000950170-24-009144 — 2.02, 9.01
- 2024-01-08 0001193125-24-004497 — 5.02
- 2024-01-08 0000950170-24-002958 — 2.02, 9.01
- 2023-11-09 0000950170-23-062050 — 5.03, 5.07, 9.01
- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2026-01-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001193125-26-025650:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0001193125-26-025650:8k_2_02:2]
EX-99.1

[0001193125-26-025650:8k_2_02:3]
Exhibit 99.1

[0001193125-26-025650:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001193125-26-025650:8k_2_02:5]
Extreme Networks Reports Second Quarter Fiscal Year 2026 Financial Results

[0001193125-26-025650:8k_2_02:6]
Revenue up 14% year-over-year, seventh consecutive quarter of sequential growth

[0001193125-26-025650:8k_2_02:7]
SaaS ARR up 25% YoY

[0001193125-26-025650:8k_2_02:8]
Morrisville, NC, January 28, 2026 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its second quarter of fiscal 2026 ended December 31, 2025.

[0001193125-26-025650:8k_2_02:9]
“Extreme is taking share from the largest players in enterprise networking, which is reflected in seven consecutive quarters of sequential revenue growth,” said Ed Meyercord, President and CEO of Extreme. “Extreme Platform ONE bookings in the quarter were twice our plan, highlighting our customers’ need for a platform that simplifies operations, automates complex networking tasks, and delivers faster, more resilient experiences through advanced AI.”

[0001193125-26-025650:8k_2_02:10]
Meyercord continued, “With the ever-changing supply chain conditions, we remain confident in our ability to deliver networking solutions that our customers demand. The combination of our talented team, strong supplier relationships, operational agility, and experience navigating changing market conditions, positions Extreme for continued growth.”

[0001193125-26-025650:8k_2_02:11]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, “Second quarter results exceeded our expectations for revenue and profitability. Our results highlight the leverage in our business model, where earnings growth exceeds revenue growth by 10 percentage points. We’re executing well on our strategy, while navigating the current supply chain environment. We are raising our revenue outlook for fiscal '26 and continue to focus on increasing profitability.”

[0001193125-26-025650:8k_2_02:12]
Fiscal Second Quarter Results:

[0001193125-26-025650:8k_2_02:13]
•
Revenue $317.9 million, up 14% year-over-year and up 2.5% quarter-over-quarter

[0001193125-26-025650:8k_2_02:14]
•
SaaS ARR $226.8 million, up 25.2% year-over-year and 4.9% quarter-over-quarter

[0001193125-26-025650:8k_2_02:15]
•
GAAP diluted EPS $0.06, compared to $0.06 last year and $0.04 last quarter

[0001193125-26-025650:8k_2_02:16]
•
Non-GAAP diluted EPS $0.26, compared to $0.21 last year and $0.22 last quarter

[0001193125-26-025650:8k_2_02:17]
•
GAAP gross margin 61.4%, compared to 62.7% last year and 60.6% last quarter

[0001193125-26-025650:8k_2_02:18]
•
Non-GAAP gross margin 62.0%, compared to 63.4% last year and 61.3% last quarter

[0001193125-26-025650:8k_2_02:19]
•
GAAP operating margin 4.1%, compared to 4.5% last year and 3.6% last quarter

[0001193125-26-025650:8k_2_02:20]
•
Non-GAAP operating margin 15.0%, compared to 14.7% last year and 13.3% last quarter

[0001193125-26-025650:8k_2_02:21]
Liquidity:

[0001193125-26-025650:8k_2_02:22]
•
Q2 ending cash balance was $219.8 million, an increase of $10.8 million from the end of Q1 2026 and an increase of $49.5 million from the end of Q2 in the prior year.

[0001193125-26-025650:8k_2_02:23]
•
Q2 net cash was $47.3 million, as compared to net cash of $7.8 million at the end of Q1 2026 and net debt of $14.7 million at the end of Q2 in the prior year.

[0001193125-26-025650:8k_2_02:24]
Recent Key Highlights:

[0001193125-26-025650:8k_2_02:25]
•
Extreme was named as a Leader in the IDC MarketScape: Worldwide Enterprise Wireless LAN 2025 Vendor Assessment (Doc #US52978225, October 2025), with IDC noting strengths including Extreme Platform ONE, strong reviews from customers for responsive support services, expertise in high-density environments, and highly flexible deployment and management options for customers through its Universal Hardware.

[0001193125-26-025650:8k_2_02:26]
•
During the quarter, Extreme hosted both an Investor Day and its inaugural AI Summit in New York City. Investor Day centered on our long-term vision, financial outlook, and the key drivers of growth, while the AI Summit brought together industry leaders and CxOs for a forward-looking discussion on the future of AI and its impact on how enterprises build and operate networks.

[0001193125-26-025650:8k_2_02:27]
•
Organizations including Baylor University, Barnsley College, Henry Ford Health, University Hospital Birmingham NHS Foundation Trust, Six Flags, and multiple NFL teams including the Pittsburgh Steelers, chose Extreme’s Wi-Fi 7 solutions to deliver faster, more reliable connectivity and drive more efficient operations.

[0001193125-26-025650:8k_2_02:28]
•
TJ Regional Health selected Extreme to modernize its network across 15 facilities with a resilient, fabric-based architecture delivering reliability for clinical systems, EHR access, and high-density Wi-Fi 7 connectivity. By deploying Extreme Platform ONE with Fabric and advanced wired and wireless solutions, TJ Regional gains simplified operations and future-ready performance for clinical workflows.

[0001193125-26-025650:8k_2_02:29]
•
Groupe Jolimont, one of Belgium’s leading healthcare systems, has modernized its network with Extreme to support reliable, high-quality patient care across its seven hospital sites. By deploying Extreme Platform ONE, Jolimont can leverage AI-driven insights and automation to manage its switching and Wi-Fi environment faster, smarter, and more efficiently. The upgraded network will help power critical use cases such as electronic health records access, connected medical devices, real-time clinical collaboration, and enhanced digital experiences for both staff and patients.

[0001193125-26-025650:8k_2_02:30]
•
Sunis Hotels, a Turkish hospitality brand with a growing portfolio of coastal resorts along the Mediterranean and Aegean is modernizing its network with Extreme to enhance guest experience and support core systems, IoT, and security at scale. Extreme beat a larger competitor by demonstrating a stronger grasp of hospitality’s need for always-on, high-performance connectivity, delivering an integrated Wi-Fi, switching, and Fabric experience through ExtremeCloud.

[0001193125-26-025650:8k_2_02:31]
•
Extreme expanded its relationship with the world’s largest theme park operator by adding Six Flags Great Adventure in New Jersey. The deployment marks the twelfth Six Flags property to standardize on Extreme and includes Wi-Fi 6E and Wi-Fi 7, universal switching, and fabric, delivering high-performance connectivity for guests while supporting critical park operations.

[0001193125-26-025650:8k_2_02:32]
•
SK bioscience, a leading South Korean biotech company, is deploying Extreme Platform ONE to support rapid growth across its expanded offices and new R&D center. The platform simplifies network operations while delivering the reliability and performance needed to support

[0001193125-26-025650:8k_2_02:33]
data-intensive research, connected labs, and collaboration between scientists. This ensures researchers stay focused on innovation, not IT complexity, as SK bioscience scales its critical R&D initiatives.

[0001193125-26-025650:8k_2_02:34]
Fiscal Q2 2026 Financial Results:

[0001193125-26-025650:8k_2_02:35]
(in millions, except percentages and per share information)

[0001193125-26-025650:8k_2_02:36]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | Change |  |
| Product |  | $ | 197.8 |  |  | $ | 172.3 |  |  | $ | 25.5 |  |
| Subscription and support |  |  | 120.1 |  |  |  | 107.1 |  |  |  | 13.0 |  |
| Total net revenue |  | $ | 317.9 |  |  | $ | 279.4 |  |  | $ | 38.5 |  |
| Gross margin |  |  | 61.4 | % |  |  | 62.7 | % |  |  | (1.3 | )% |
| Operating margin |  |  | 4.1 | % |  |  | 4.5 | % |  |  | (0.4 | )% |
| Net income |  | $ | 7.9 |  |  | $ | 7.4 |  |  | $ | 0.5 |  |
| Net income per diluted share |  | $ | 0.06 |  |  | $ | 0.06 |  |  | $ | - |  |

[0001193125-26-025650:8k_2_02:37]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | Change |  |
| Product |  | $ | 197.8 |  |  | $ | 172.3 |  |  | $ | 25.5 |  |
| Subscription and support |  |  | 120.1 |  |  |  | 107.1 |  |  |  | 13.0 |  |
| Total net revenue |  | $ | 317.9 |  |  | $ | 279.4 |  |  | $ | 38.5 |  |
| Gross margin |  |  | 62.0 | % |  |  | 63.4 | % |  |  | (1.4 | )% |
| Operating margin |  |  | 15.0 | % |  |  | 14.7 | % |  |  | 0.3 | % |
| Net income |  | $ | 34.7 |  |  | $ | 28.6 |  |  | $ | 6.1 |  |
| Net income per diluted share |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.05 |  |

[0001193125-26-025650:8k_2_02:38]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by (used in) operating activities, less purchases of property, equipment and capitalized software development costs. Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, equipment and capitalized software development costs, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows the non-GAAP free cash flow calculation (in millions):

[0001193125-26-025650:8k_2_02:39]
| Free Cash Flow | Three Months Ended |  |
|  | December 31, 2025 |  |  | December 31, 2024 |  |
| Cash flow provided by operations | $ | 50.1 |  |  | $ | 21.5 |  |
| Less: Capital expenditures for property, equipment and capitalized software development costs |  | (7.1 | ) |  |  | (5.4 | ) |
| Total free cash flow | $ | 43.0 |  |  | $ | 16.1 |  |

[0001193125-26-025650:8k_2_02:40]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of Extreme Platform ONE, ExtremeCloud IQ and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue

[0001193125-26-025650:8k_2_02:41]
or deferred revenue that are accounted for under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0001193125-26-025650:8k_2_02:42]
Gross debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0001193125-26-025650:8k_2_02:43]
Net cash: is defined as cash and cash equivalents minus gross debt, as shown in the table below (in millions):

[0001193125-26-025650:8k_2_02:44]
| Cash and cash equivalents |  |  | Gross debt |  |  | Net cash |  |
| $ | 219.8 |  |  | $ | 172.5 |  |  | $ | 47.3 |  |

[0001193125-26-025650:8k_2_02:45]
Business Outlook:

[0001193125-26-025650:8k_2_02:46]
For its third quarter fiscal 2026, ending March 31, 2026, the Company is targeting:

[0001193125-26-025650:8k_2_02:47]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ3'26 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 309.1 |  |  | $ | 314.1 |  |
| Gross margin |  | 60.4 | % |  |  | 60.8 | % |
| Operating margin |  | 2.8 | % |  |  | 4.1 | % |
| Earnings per share | $ | 0.03 |  |  | $ | 0.06 |  |
| Diluted Shares outstanding used in calculating GAAP EPS |  | 135.8 |  |  |  | 135.8 |  |
| FQ3'26 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 309.1 |  |  | $ | 314.1 |  |
| Gross margin |  | 61.0 | % |  |  | 61.4 | % |
| Operating margin |  | 13.6 | % |  |  | 14.8 | % |
| Earnings per share | $ | 0.23 |  |  | $ | 0.25 |  |
| Diluted Shares outstanding used in calculating non-GAAP EPS |  | 135.8 |  |  |  | 135.8 |  |

[0001193125-26-025650:8k_2_02:48]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY'26 guidance:

[0001193125-26-025650:8k_2_02:49]
|  | FQ3'26 |
|  | Gross Margin |  | Operating Margin |  | Earnings per Share |
| GAAP | 60.4% - 60.8% |  | 2.8% - 4.1% |  | $0.03 - $0.06 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.5% |  | 7.3% - 7.4% |  | 0.17 |
| Amortization of product intangibles | 0.1% |  | 0.1% |  | 0.00 |
| Amortization of non-product intangibles | — |  | 0.1% |  | 0.00 |
| Other non-recurring costs | — |  | 0.8% |  | 0.02 |
| Litigation charges | — |  | 0.7% |  | 0.02 |
| System transition costs | — |  | 1.7% |  | 0.04 |
| Tax adjustment | — |  | — |  | (0.06) - (0.05) |
| Non-GAAP | 61.0% - 61.4% |  | 13.6% - 14.8% |  | $0.23 - $0.25 |

[0001193125-26-025650:8k_2_02:50]
The total percentage rate changes may not equal the total change in all cases due to rounding.

[0001193125-26-025650:8k_2_02:51]
For the full year fiscal 2026, ending June 30, 2026, the Company is targeting:

[0001193125-26-025650:8k_2_02:52]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FY'26 Guidance |  |  |  |  |  |
| Total net revenue | $ | 1,262.0 |  |  | $ | 1,270.0 |  |
| Gross margin |  | 60.5 | % |  |  | 61.1 | % |
| Operating margin |  | 4.1 | % |  |  | 4.6 | % |
| Earnings per share | $ | 0.24 |  |  | $ | 0.29 |  |
| Diluted Shares outstanding used in calculating GAAP EPS |  | 135.4 |  |  |  | 135.4 |  |
| FY'26 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 1,262.0 |  |  | $ | 1,270.0 |  |
| Gross margin |  | 61.1 | % |  |  | 61.7 | % |
| Operating margin |  | 14.3 | % |  |  | 14.8 | % |
| Earnings per share | $ | 0.98 |  |  | $ | 1.02 |  |
| Diluted Shares outstanding used in calculating non-GAAP EPS |  | 135.4 |  |  |  | 135.4 |  |

[0001193125-26-025650:8k_2_02:53]
The following table shows the GAAP to non-GAAP reconciliation for FY'26 guidance:

[0001193125-26-025650:8k_2_02:54]
|  | FY'26 |
|  | Gross Margin |  | Operating Margin |  | Earnings per Share |
| GAAP | 60.5% - 61.1% |  | 4.1% - 4.6% |  | $0.24 - $0.29 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.5% |  | 7.2% |  | 0.67 |
| Amortization of product intangibles | 0.1% |  | 0.1% |  | 0.01 |
| Amortization of non-product intangibles | — |  | 0.1% |  | 0.01 |
| Other non-recurring costs | — |  | 0.5% |  | 0.05 |
| Litigation charges | — |  | 0.6% |  | 0.06 |
| System transition costs | — |  | 1.7% |  | 0.15 |
| Tax adjustment | — |  | — |  | (0.22) - (0.21) |
| Non-GAAP | 61.1% - 61.7% |  | 14.3% - 14.8% |  | $0.98 - $1.02 |

[0001193125-26-025650:8k_2_02:55]
The total percentage rate changes may not equal the total change in all cases due to rounding.

[0001193125-26-025650:8k_2_02:56]
Conference Call:

[0001193125-26-025650:8k_2_02:57]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the second quarter results of fiscal 2026 as well as the business outlook for the third quarter of fiscal 2026 ending March 31, 2026 and the full year fiscal 2026, ending June 30, 2026, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Registration Link) and you will be provided with dial in details. If you would like to participate in the Q&A, please register here: Q&A Registration Link. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0001193125-26-025650:8k_2_02:58]
About Extreme:

[0001193125-26-025650:8k_2_02:59]
Extreme Networks, Inc. (EXTR) is a leader in AI-driven cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence, analytics, and automation. Tens of thousands of customers globally trust our AI-driven cloud networking solutions and industry-leading support to enable businesses to drive value, foster innovation, and overcome extreme challenges. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, X (Formerly Twitter), Facebook or Instagram

[0001193125-26-025650:8k_2_02:60]
Extreme Networks, ExtremeCloud, Extreme Platform ONE, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001193125-26-025650:8k_2_02:61]
Non-GAAP Financial Measures:

[0001193125-26-025650:8k_2_02:62]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, Adjusted EBITDA, net cash (debt) and free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, other non-recurring costs, debt refinancing charges and the tax effect of non-GAAP adjustments. The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0001193125-26-025650:8k_2_02:63]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated. These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001193125-26-025650:8k_2_02:64]
Forward-Looking Statements:

[0001193125-26-025650:8k_2_02:65]
For more information about factors that could cause actual results and other future events to differ materially from those suggested or indicated by such forward-looking statements, see “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov). As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely

[0001193125-26-025650:8k_2_02:66]
affected. Except as required under the U.S. federal securities laws and the rules and regulations of the Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001193125-26-025650:8k_2_02:67]
###

[0001193125-26-025650:8k_2_02:68]
EXTREME NETWORKS, INC.

[0001193125-26-025650:8k_2_02:69]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-26-025650:8k_2_02:70]
(In thousands, except per share amounts)

[0001193125-26-025650:8k_2_02:71]
(Unaudited)

[0001193125-26-025650:8k_2_02:72]
|  |  | December 31, 2025 |  |  | June 30, 2025 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 219,791 |  |  | $ | 231,745 |  |
| Accounts receivable, net |  |  | 152,427 |  |  |  | 126,708 |  |
| Inventories |  |  | 83,593 |  |  |  | 102,578 |  |
| Prepaid expenses and other current assets |  |  | 79,917 |  |  |  | 74,265 |  |
| Total current assets |  |  | 535,728 |  |  |  | 535,296 |  |
| Property and equipment, net |  |  | 50,228 |  |  |  | 44,366 |  |
| Operating lease right-of-use assets, net |  |  | 34,925 |  |  |  | 38,655 |  |
| Goodwill |  |  | 399,850 |  |  |  | 399,574 |  |
| Intangible assets, net |  |  | 4,682 |  |  |  | 6,541 |  |
| Other assets |  |  | 143,253 |  |  |  | 128,786 |  |
| Total assets |  | $ | 1,168,666 |  |  | $ | 1,153,218 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 64,814 |  |  | $ | 63,939 |  |
| Accrued compensation and benefits |  |  | 66,527 |  |  |  | 62,895 |  |
| Accrued warranty |  |  | 9,628 |  |  |  | 9,684 |  |
| Current portion of deferred revenue |  |  | 328,164 |  |  |  | 325,078 |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $698 and $729, respectively |  |  | 16,802 |  |  |  | 14,271 |  |
| Current portion, operating lease liabilities |  |  | 12,233 |  |  |  | 11,456 |  |
| Other accrued liabilities |  |  | 66,974 |  |  |  | 100,552 |  |
| Total current liabilities |  |  | 565,142 |  |  |  | 587,875 |  |
| Deferred revenue, less current portion |  |  | 314,728 |  |  |  | 292,415 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $937 and $1,276, respectively |  |  | 154,063 |  |  |  | 163,724 |  |
| Operating lease liabilities, less current portion |  |  | 29,025 |  |  |  | 33,991 |  |
| Deferred income taxes |  |  | 7,196 |  |  |  | 7,033 |  |
| Other long-term liabilities |  |  | 2,600 |  |  |  | 2,596 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 155,339 and 152,673 shares issued, respectively; 134,153 and 132,064 shares outstanding, respectively |  |  | 155 |  |  |  | 153 |  |
| Additional paid-in-capital |  |  | 1,328,970 |  |  |  | 1,298,791 |  |
| Accumulated other comprehensive loss |  |  | (9,477 | ) |  |  | (8,137 | ) |
| Accumulated deficit |  |  | (935,942 | ) |  |  | (949,429 | ) |
| Treasury stock at cost, 21,186 shares and 20,609 shares, respectively |  |  | (287,794 | ) |  |  | (275,794 | ) |
| Total stockholders’ equity |  |  | 95,912 |  |  |  | 65,584 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,168,666 |  |  | $ | 1,153,218 |  |

[0001193125-26-025650:8k_2_02:73]
EXTREME NETWORKS, INC.

[0001193125-26-025650:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-26-025650:8k_2_02:75]
(In thousands, except per share amounts)

[0001193125-26-025650:8k_2_02:76]
(Unaudited)

[0001193125-26-025650:8k_2_02:77]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 197,765 |  |  | $ | 172,261 |  |  | $ | 391,806 |  |  | $ | 334,545 |  |
| Subscription and support |  |  | 120,160 |  |  |  | 107,094 |  |  |  | 236,364 |  |  |  | 214,014 |  |
| Total net revenues |  |  | 317,925 |  |  |  | 279,355 |  |  |  | 628,170 |  |  |  | 548,559 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 87,000 |  |  |  | 72,604 |  |  |  | 173,128 |  |  |  | 142,006 |  |
| Subscription and support |  |  | 35,845 |  |  |  | 31,628 |  |  |  | 71,933 |  |  |  | 61,923 |  |
| Total cost of revenues |  |  | 122,845 |  |  |  | 104,232 |  |  |  | 245,061 |  |  |  | 203,929 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 110,765 |  |  |  | 99,657 |  |  |  | 218,678 |  |  |  | 192,539 |  |
| Subscription and support |  |  | 84,315 |  |  |  | 75,466 |  |  |  | 164,431 |  |  |  | 152,091 |  |
| Total gross profit |  |  | 195,080 |  |  |  | 175,123 |  |  |  | 383,109 |  |  |  | 344,630 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 57,522 |  |  |  | 54,883 |  |  |  | 115,275 |  |  |  | 109,334 |  |
| Sales and marketing |  |  | 89,393 |  |  |  | 79,967 |  |  |  | 178,316 |  |  |  | 161,350 |  |
| General and administrative |  |  | 30,951 |  |  |  | 26,064 |  |  |  | 60,138 |  |  |  | 62,665 |  |
| Restructuring and related charges |  |  | 167 |  |  |  | 1,035 |  |  |  | 538 |  |  |  | 2,312 |  |
| Amortization of intangible assets |  |  | 407 |  |  |  | 509 |  |  |  | 907 |  |  |  | 1,021 |  |
| Total operating expenses |  |  | 182,088 |  |  |  | 162,458 |  |  |  | 358,822 |  |  |  | 336,682 |  |
| Operating income |  |  | 12,992 |  |  |  | 12,665 |  |  |  | 24,287 |  |  |  | 7,948 |  |
| Interest income |  |  | 1,132 |  |  |  | 839 |  |  |  | 2,329 |  |  |  | 1,685 |  |
| Interest expense |  |  | (3,360 | ) |  |  | (4,179 | ) |  |  | (7,013 | ) |  |  | (8,601 | ) |
| Other income (expense), net |  |  | (360 | ) |  |  | 661 |  |  |  | (847 | ) |  |  | (60 | ) |
| Income before income taxes |  |  | 10,404 |  |  |  | 9,986 |  |  |  | 18,756 |  |  |  | 972 |  |
| Provision for income taxes |  |  | 2,528 |  |  |  | 2,604 |  |  |  | 5,269 |  |  |  | 4,094 |  |
| Net income (loss) |  | $ | 7,876 |  |  | $ | 7,382 |  |  | $ | 13,487 |  |  | $ | (3,122 | ) |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | 0.06 |  |  | $ | 0.06 |  |  | $ | 0.10 |  |  | $ | (0.02 | ) |
| Net income (loss) per share – diluted |  | $ | 0.06 |  |  | $ | 0.06 |  |  | $ | 0.10 |  |  | $ | (0.02 | ) |
| Shares used in per share calculation – basic |  |  | 133,914 |  |  |  | 132,381 |  |  |  | 133,443 |  |  |  | 131,778 |  |
| Shares used in per share calculation – diluted |  |  | 135,166 |  |  |  | 134,107 |  |  |  | 135,379 |  |  |  | 131,778 |  |

[0001193125-26-025650:8k_2_02:78]
EXTREME NETWORKS, INC.

[0001193125-26-025650:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-26-025650:8k_2_02:80]
(In thousands)

[0001193125-26-025650:8k_2_02:81]
(Unaudited)

[0001193125-26-025650:8k_2_02:82]
|  |  | Six Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income (loss) |  | $ | 13,487 |  |  | $ | (3,122 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 7,793 |  |  |  | 7,804 |  |
| Amortization of intangible assets |  |  | 1,870 |  |  |  | 2,251 |  |
| Amortization of cloud computing implementation costs |  |  | 1,025 |  |  |  | — |  |
| Reduction in carrying amount of right-of-use asset |  |  | 5,104 |  |  |  | 4,894 |  |
| Provision for credit losses |  |  | 320 |  |  |  | 27 |  |
| Share-based compensation |  |  | 44,679 |  |  |  | 41,219 |  |
| Deferred income taxes |  |  | 414 |  |  |  | (987 | ) |
| Provision for (benefit from) excess and obsolete inventory |  |  | 1,270 |  |  |  | (271 | ) |
| Non-cash interest expense |  |  | 609 |  |  |  | 594 |  |
| Other |  |  | 951 |  |  |  | (801 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (26,039 | ) |  |  | (28,083 | ) |
| Inventories |  |  | 15,821 |  |  |  | 411 |  |
| Prepaid expenses and other assets |  |  | (25,724 | ) |  |  | (9,969 | ) |
| Accounts payable |  |  | 766 |  |  |  | 1,177 |  |
| Accrued compensation and benefits |  |  | 3,342 |  |  |  | 16,995 |  |
| Operating lease liabilities |  |  | (5,554 | ) |  |  | (5,375 | ) |
| Deferred revenue |  |  | 27,920 |  |  |  | 17,421 |  |
| Other current and long-term liabilities |  |  | (31,914 | ) |  |  | (4,067 | ) |
| Net cash provided by operating activities |  |  | 36,140 |  |  |  | 40,118 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures for property, equipment and capitalized software development costs |  |  | (13,922 | ) |  |  | (12,325 | ) |
| Net cash used in investing activities |  |  | (13,922 | ) |  |  | (12,325 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Borrowings under revolving facility |  |  | 25,000 |  |  |  | — |  |
| Payments on revolving facility |  |  | (25,000 | ) |  |  | — |  |
| Payments on debt obligations |  |  | (7,500 | ) |  |  | (5,000 | ) |
| Payments on debt financing costs |  |  | — |  |  |  | (695 | ) |
| Repurchase of common stock |  |  | (12,000 | ) |  |  | — |  |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (14,498 | ) |  |  | (8,300 | ) |
| Net cash used in financing activities |  |  | (33,998 | ) |  |  | (13,995 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (174 | ) |  |  | (175 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (11,954 | ) |  |  | 13,623 |  |
| Cash and cash equivalents at beginning of period |  |  | 231,745 |  |  |  | 156,699 |  |
| Cash and cash equivalents at end of period |  | $ | 219,791 |  |  | $ | 170,322 |  |

[0001193125-26-025650:8k_2_02:83]
Extreme Networks, Inc.

[0001193125-26-025650:8k_2_02:84]
Non-GAAP Measures of Financial Performance

[0001193125-26-025650:8k_2_02:85]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, Adjusted EBITDA (calculated as GAAP net income excluding interest, income taxes, depreciation and amortization as well as costs or benefits that are not reflective of the Company's ongoing or expected future operational performance as noted below), net cash (debt) and free cash flow.

[0001193125-26-025650:8k_2_02:86]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001193125-26-025650:8k_2_02:87]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP. These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-26-025650:8k_2_02:88]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value. In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001193125-26-025650:8k_2_02:89]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, other non-recurring costs, debt refinancing charges, and the tax effect of non-GAAP adjustments. Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001193125-26-025650:8k_2_02:90]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001193125-26-025650:8k_2_02:91]
Share-based compensation. Share-based compensation consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan. Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001193125-26-025650:8k_2_02:92]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships and trademarks. The amortization of the developed technology are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses. Extreme excludes these expenses since they result from an

[0001193125-26-025650:8k_2_02:93]
intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001193125-26-025650:8k_2_02:94]
Restructuring and related charges. Restructuring and related charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001193125-26-025650:8k_2_02:95]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution, our configure, price, quote solution and our enterprise resource planning tools that were not capitalizable. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0001193125-26-025650:8k_2_02:96]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for non-recurring litigations offset by any proceeds received or expected to be received from insurance.

[0001193125-26-025650:8k_2_02:97]
Debt refinancing charges. Debt refinancing charges consist of costs that were not capitalizable and are included in other expense, net, that occurred in conjunction with the amendments related to our outstanding credit facility.

[0001193125-26-025650:8k_2_02:98]
Other non-recurring costs. Other non-recurring costs consist of certain external advisory and professional fees incurred for various non-recurring transactions and activities that occur outside of the normal course of business. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0001193125-26-025650:8k_2_02:99]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0001193125-26-025650:8k_2_02:100]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0001193125-26-025650:8k_2_02:101]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Canadian, German and Indian subsidiaries which perform research and development and sales and marketing activities for the Company, as well as the Company’s Irish trading subsidiaries.

[0001193125-26-025650:8k_2_02:102]
EXTREME NETWORKS, INC.

[0001193125-26-025650:8k_2_02:103]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-26-025650:8k_2_02:104]
GAAP TO NON-GAAP RECONCILIATION

[0001193125-26-025650:8k_2_02:105]
(In thousands, except percentages and per share amounts)

[0001193125-26-025650:8k_2_02:106]
(Unaudited)

[0001193125-26-025650:8k_2_02:107]
| Revenues | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Revenues – GAAP | $ | 317,925 |  |  | $ | 279,355 |  |  | $ | 628,170 |  |  | $ | 548,559 |  |

[0001193125-26-025650:8k_2_02:108]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Gross profit – GAAP | $ | 195,080 |  |  | $ | 175,123 |  |  | $ | 383,109 |  |  | $ | 344,630 |  |
| Gross margin – GAAP percentage |  | 61.4 | % |  |  | 62.7 | % |  |  | 61.0 | % |  |  | 62.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 796 |  |  |  | 680 |  |  |  | 1,548 |  |  |  | 1,298 |  |
| Share-based compensation expense, Subscription and support |  | 759 |  |  |  | 798 |  |  |  | 1,486 |  |  |  | 1,487 |  |
| Amortization of intangibles, Product |  | 334 |  |  |  | 589 |  |  |  | 927 |  |  |  | 1,195 |  |
| Total adjustments to GAAP gross profit | $ | 1,889 |  |  | $ | 2,067 |  |  | $ | 3,961 |  |  | $ | 3,980 |  |
| Gross profit – non-GAAP | $ | 196,969 |  |  | $ | 177,190 |  |  | $ | 387,070 |  |  | $ | 348,610 |  |
| Gross margin – non-GAAP percentage |  | 62.0 | % |  |  | 63.4 | % |  |  | 61.6 | % |  |  | 63.6 | % |

[0001193125-26-025650:8k_2_02:109]
| Non-GAAP Operating Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| GAAP operating income | $ | 12,992 |  |  | $ | 12,665 |  |  | $ | 24,287 |  |  | $ | 7,948 |  |
| GAAP operating margin |  | 4.1 | % |  |  | 4.5 | % |  |  | 3.9 | % |  |  | 1.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,555 |  |  |  | 1,478 |  |  |  | 3,034 |  |  |  | 2,785 |  |
| Share-based compensation expense, R&D |  | 4,639 |  |  |  | 4,467 |  |  |  | 9,086 |  |  |  | 8,680 |  |
| Share-based compensation expense, S&M |  | 8,009 |  |  |  | 7,596 |  |  |  | 15,522 |  |  |  | 14,478 |  |
| Share-based compensation expense, G&A |  | 8,696 |  |  |  | 7,911 |  |  |  | 17,037 |  |  |  | 15,276 |  |
| Restructuring and related charges |  | 167 |  |  |  | 1,035 |  |  |  | 538 |  |  |  | 2,312 |  |
| Litigation charges |  | 822 |  |  |  | 877 |  |  |  | 2,759 |  |  |  | 11,593 |  |
| System transition costs |  | 6,467 |  |  |  | 4,026 |  |  |  | 11,392 |  |  |  | 9,371 |  |
| Amortization of intangibles |  | 741 |  |  |  | 1,098 |  |  |  | 1,834 |  |  |  | 2,216 |  |
| Other non-recurring costs |  | 3,648 |  |  |  | — |  |  |  | 3,648 |  |  |  | — |  |
| Total adjustments to GAAP operating income | $ | 34,744 |  |  | $ | 28,488 |  |  | $ | 64,850 |  |  | $ | 66,711 |  |
| Non-GAAP operating income | $ | 47,736 |  |  | $ | 41,153 |  |  | $ | 89,137 |  |  | $ | 74,659 |  |
| Non-GAAP operating margin |  | 15.0 | % |  |  | 14.7 | % |  |  | 14.2 | % |  |  | 13.6 | % |

[0001193125-26-025650:8k_2_02:110]
| Non-GAAP Net Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| GAAP net income (loss) | $ | 7,876 |  |  | $ | 7,382 |  |  | $ | 13,487 |  |  | $ | (3,122 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 22,899 |  |  |  | 21,452 |  |  |  | 44,679 |  |  |  | 41,219 |  |
| Restructuring and related charges |  | 167 |  |  |  | 1,035 |  |  |  | 538 |  |  |  | 2,312 |  |
| Litigation charges |  | 822 |  |  |  | 877 |  |  |  | 2,759 |  |  |  | 11,593 |  |
| System transition costs |  | 6,467 |  |  |  | 4,026 |  |  |  | 11,392 |  |  |  | 9,371 |  |
| Amortization of intangibles |  | 741 |  |  |  | 1,098 |  |  |  | 1,834 |  |  |  | 2,216 |  |
| Other non-recurring costs |  | 3,648 |  |  |  | — |  |  |  | 3,648 |  |  |  | — |  |
| Debt refinancing charges |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |
| Tax effect of non-GAAP adjustments |  | (7,895 | ) |  |  | (7,297 | ) |  |  | (13,468 | ) |  |  | (12,695 | ) |
| Total non-GAAP adjustments to GAAP net income (loss) | $ | 26,849 |  |  | $ | 21,191 |  |  | $ | 51,382 |  |  | $ | 54,095 |  |
| Non-GAAP net income | $ | 34,725 |  |  | $ | 28,573 |  |  | $ | 64,869 |  |  | $ | 50,973 |  |
| Earnings (loss) per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) per share – diluted | $ | 0.06 |  |  | $ | 0.06 |  |  | $ | 0.10 |  |  | $ | (0.02 | ) |
| Non-GAAP net income per share – diluted | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.48 |  |  | $ | 0.38 |  |
| Shares used in net income (loss) per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP shares used in per share calculation – basic |  | 133,914 |  |  |  | 132,381 |  |  |  | 133,443 |  |  |  | 131,778 |  |
| Potentially dilutive equity awards |  | 1,252 |  |  |  | 1,726 |  |  |  | 1,936 |  |  |  | 1,462 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 135,166 |  |  |  | 134,107 |  |  |  | 135,379 |  |  |  | 133,240 |  |

[0001193125-26-025650:8k_2_02:111]
| Adjusted EBITDA | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| GAAP net income (loss) | $ | 7,876 |  |  | $ | 7,382 |  |  | $ | 13,487 |  |  | $ | (3,122 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation expense |  | 3,994 |  |  |  | 3,863 |  |  |  | 7,793 |  |  |  | 7,804 |  |
| Amortization expense |  | 1,784 |  |  |  | 1,116 |  |  |  | 2,895 |  |  |  | 2,251 |  |
| Share-based compensation expense |  | 22,899 |  |  |  | 21,452 |  |  |  | 44,679 |  |  |  | 41,219 |  |
| Restructuring and related charges |  | 167 |  |  |  | 1,035 |  |  |  | 538 |  |  |  | 2,312 |  |
| Litigation charges |  | 822 |  |  |  | 877 |  |  |  | 2,759 |  |  |  | 11,593 |  |
| System transition costs |  | 6,467 |  |  |  | 4,026 |  |  |  | 11,392 |  |  |  | 9,371 |  |
| Other non-recurring costs |  | 3,648 |  |  |  | — |  |  |  | 3,648 |  |  |  | — |  |
| Debt refinancing charges |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |
| Interest income |  | (1,132 | ) |  |  | (839 | ) |  |  | (2,329 | ) |  |  | (1,685 | ) |
| Interest expense |  | 3,360 |  |  |  | 4,179 |  |  |  | 7,013 |  |  |  | 8,601 |  |
| Provision for income taxes |  | 2,528 |  |  |  | 2,604 |  |  |  | 5,269 |  |  |  | 4,094 |  |
| Total adjustments to GAAP net income (loss) |  | 44,537 |  |  |  | 38,313 |  |  |  | 83,657 |  |  |  | 85,639 |  |
| Adjusted EBITDA | $ | 52,413 |  |  | $ | 45,695 |  |  | $ | 97,144 |  |  | $ | 82,517 |  |
