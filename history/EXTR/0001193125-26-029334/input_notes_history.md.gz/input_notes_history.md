# EXTR note change history — 0001193125-25-258554 → 0001193125-26-029334


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-01-29):
[0001193125-26-029334:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2025, the Company had commitments to purchase $52.2 million of inventory.
  (was, 2025-10-30, similarity 0.9942):
[0001193125-25-258554:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2025, the Company had commitments to purchase $48.8 million of inventory.

- changed (2026-01-29):
[0001193125-26-029334:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2025-10-30, similarity 0.7598):
[0001193125-25-258554:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex

- changed (2026-01-29):
[0001193125-26-029334:note_history:3]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.
  (was, 2025-10-30, similarity 0.6598):
[0001193125-25-258554:note_history:3]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.

- added (2026-01-29):
[0001193125-26-029334:note_history:4]
Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.

- changed (2026-01-29):
[0001193125-26-029334:note_history:5]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these shareholder derivative cases names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. Plaintiffs filed an amended complaint in the two California shareholder derivative cases on December 1, 2025.  The Company filed a motion to dismiss the amended complaint on December 19, 2025. The North Carolina case remains stayed pending a decision on the motion to dismiss the second amended complaint in the Class Action.
  (was, 2025-10-30, similarity 0.7811):
[0001193125-25-258554:note_history:5]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these cases (collectively, the “Derivative Cases”) names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. These cases remain stayed pending a decision on the motion to dismiss the second amended complaint in the Class Action.

- changed (2026-01-29):
[0001193125-26-029334:note_history:6]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.
  (was, 2025-10-30, similarity 0.8884):
[0001193125-25-258554:note_history:6]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s

- removed (2026-01-29):
[0001193125-25-258554:note_history:7]
judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- removed (2026-01-29):
[0001193125-25-258554:note_history:8]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

- removed (2026-01-29):
[0001193125-25-258554:note_history:9]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP sought actual damages and profits attributed to the infringement, as well as equitable relief. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. The parties reached a settlement, and on July 29, 2025, the case was dismissed with prejudice.

- removed (2026-01-29):
[0001193125-25-258554:note_history:10]
limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-01-29):
[0001193125-26-029334:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2025. The results of operations for the three and six months ended December 31, 2025 are not necessarily indicative of the results that may be expected for fiscal 2026 or any future periods.
  (was, 2025-10-30, similarity 0.775):
[0001193125-25-258554:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2025. The results of operations for the three months ended September 30, 2025 are not necessarily indicative of the results that may be expected for fiscal 2026 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-01-29):
[0001193125-26-029334:note_history:12]
In December 2025, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2025-11, Interim Reporting (Topic 270): Narrow-Scope Improvements. This ASU provides clarifications intended to improve the consistency and usability of interim disclosure requirements, including a comprehensive listing of required interim disclosures. The standard introduces a new disclosure principle for interim reporting to help entities determine whether disclosures not specified in Topic 270 should be provided in interim periods. ASU 2025-11 is effective for fiscal years beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-11 on its consolidated financial statements and related disclosures.

- added (2026-01-29):
[0001193125-26-029334:note_history:13]
In November 2025, the FASB issued ASU 2025-09, Derivatives and Hedging (Topic 815): Hedge Accounting Improvements. This ASU amends certain aspects of existing guidance to more closely align hedge accounting with the economics of the Company’s risk management activities. ASU 2025-09 is effective for fiscal years beginning after December 15, 2026, and interim periods within those annual reporting periods and should be applied on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-09 on its consolidated financial statements and related disclosures.

- changed (2026-01-29):
[0001193125-26-029334:note_history:14]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. This ASU removes all references to prescriptive and sequential software development stages and requires entities to begin capitalizing software costs when management authorizes and commits to funding the software project, and it is probable that the project will be completed, and the software will be used for its intended purpose. The amendments in this ASU are effective for fiscal years beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-06 on its consolidated financial statements and related disclosures.
  (was, 2025-10-30, similarity 0.9407):
[0001193125-25-258554:note_history:14]
In September 2025, the Financial Accounting Standards Board (“FASB") issued Accounting Standards Update ("ASU") 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. This ASU removes all references to prescriptive and sequential software development stages and requires entities to begin capitalizing software costs when management authorizes and commits to funding the software project, and it is probable that the project will be completed, and the software will be used for its intended purpose. The amendments in this ASU are effective for fiscal years beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-06 on its consolidated financial statements and related disclosures.

- changed (2026-01-29):
[0001193125-26-029334:note_history:15]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. The Company will be adopting ASU 2023-09 for fiscal year ended June 30, 2026.
  (was, 2025-10-30, similarity 0.7804):
[0001193125-25-258554:note_history:15]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-29):
[0001193125-26-029334:note_history:16]
|  |  | December 31, 2025 |  |  | June 30, 2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term loan |  | $ | 17,500 |  |  | $ | 15,000 |  |
| Less: unamortized debt issuance costs |  |  | (698 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 16,802 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term loan |  | $ | 155,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (937 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 154,063 |  |  |  | 163,724 |  |
| Total debt |  | $ | 170,865 |  |  | $ | 177,995 |  |
  (was, 2025-10-30, similarity 0.941):
[0001193125-25-258554:note_history:16]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 16,250 |  |  | $ | 15,000 |  |
| Revolving Facility |  |  | 25,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (714 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 40,536 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 160,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,104 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 158,896 |  |  |  | 163,724 |  |
| Total debt |  | $ | 199,432 |  |  | $ | 177,995 |  |

- changed (2026-01-29):
[0001193125-26-029334:note_history:17]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the Amended and Restated Credit Agreement, dated August 9, 2019, by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.
  (was, 2025-10-30, similarity 0.6832):
[0001193125-25-258554:note_history:17]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the Amended and Restated Credit Agreement, dated August 9, 2019, by and among the Company, as borrower,

- changed (2026-01-29):
[0001193125-26-029334:note_history:18]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provided a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024. As of December 31, 2025, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.
  (was, 2025-10-30, similarity 0.9961):
[0001193125-25-258554:note_history:18]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provided a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024. As of September 30, 2025, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

- changed (2026-01-29):
[0001193125-26-029334:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each of the three months ended December 31, 2025 and 2024, and was $0.6 million for each of the six months ended December 31, 2025 and 2024. The interest rate was 5.92% and 6.84% as of December 31, 2025 and 2024, respectively.
  (was, 2025-10-30, similarity 0.7886):
[0001193125-25-258554:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each of the three months ended September 30, 2025 and 2024, respectively. The interest rate was 6.54% and 7.52% as of September 30, 2025 and 2024, respectively.

- added (2026-01-29):
[0001193125-26-029334:note_history:20]
As of December 31, 2025, the Company did not have any outstanding balance against its 2023 Revolving Facility and had $135.8 million of availability for borrowing under the 2023 Revolving Facility. During the three and six months ended December 31, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

- changed (2026-01-29):
[0001193125-26-029334:note_history:21]
The Company had $14.2 million of outstanding letters of credit as of December 31, 2025.
  (was, 2025-10-30, similarity 0.9682):
[0001193125-25-258554:note_history:21]
The Company had $14.2 million of outstanding letters of credit as of September 30, 2025.

- removed (2026-01-29):
[0001193125-25-258554:note_history:22]
several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

- removed (2026-01-29):
[0001193125-25-258554:note_history:23]
During the three months ended September 30, 2025, the Company borrowed $25.0 million against the 2023 Revolving Facility which was subsequently paid out in October 2025. The Company had $110.8 million of availability under the 2023 Revolving Facility as of September 30, 2025. During the three months ended September 30, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-01-29):
[0001193125-26-029334:note_history:24]
|  |  | December 31, 2025 |  |  | June 30, 2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term loan |  | $ | 17,500 |  |  | $ | 15,000 |  |
| Less: unamortized debt issuance costs |  |  | (698 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 16,802 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term loan |  | $ | 155,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (937 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 154,063 |  |  |  | 163,724 |  |
| Total debt |  | $ | 170,865 |  |  | $ | 177,995 |  |
  (was, 2025-10-30, similarity 0.941):
[0001193125-25-258554:note_history:24]
|  |  | September 30,2025 |  |  | June 30,2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 16,250 |  |  | $ | 15,000 |  |
| Revolving Facility |  |  | 25,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (714 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 40,536 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 160,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,104 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 158,896 |  |  |  | 163,724 |  |
| Total debt |  | $ | 199,432 |  |  | $ | 177,995 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-29):
[0001193125-26-029334:note_history:25]
The following table presents the Company’s net revenues disaggregated by geographic region (in thousands):
  (was, 2025-10-30, similarity 0.9533):
[0001193125-25-258554:note_history:25]
The following table sets forth the Company’s net revenues disaggregated by geographic region (in thousands):

- changed (2026-01-29):
[0001193125-26-029334:note_history:26]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 135,173 |  |  | $ | 119,678 |  |  | $ | 271,557 |  |  | $ | 272,931 |  |
| Other |  |  | 13,218 |  |  |  | 11,710 |  |  |  | 26,093 |  |  |  | 23,892 |  |
| Total Americas |  |  | 148,391 |  |  |  | 131,388 |  |  |  | 297,650 |  |  |  | 296,823 |  |
| EMEA |  |  | 140,389 |  |  |  | 128,257 |  |  |  | 261,635 |  |  |  | 213,175 |  |
| APAC |  |  | 29,145 |  |  |  | 19,710 |  |  |  | 68,885 |  |  |  | 38,561 |  |
| Total net revenues |  | $ | 317,925 |  |  | $ | 279,355 |  |  | $ | 628,170 |  |  | $ | 548,559 |  |
  (was, 2025-10-30, similarity 0.6675):
[0001193125-25-258554:note_history:26]
|  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Americas: |  |  |  |  |  |  |
| United States |  |  | 136,384 |  |  | $ | 153,253 |  |
| Other |  |  | 12,875 |  |  |  | 12,182 |  |
| Total Americas |  |  | 149,259 |  |  |  | 165,435 |  |
| EMEA |  |  | 121,246 |  |  |  | 84,918 |  |
| APAC |  |  | 39,740 |  |  |  | 18,851 |  |
| Total net revenues |  | $ | 310,245 |  |  | $ | 269,204 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-29):
[0001193125-26-029334:note_history:27]
As of December 31, 2025, the Company had $642.9 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 30% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 34% in fiscal 2027, and the remaining 36% of the balance thereafter.
  (was, 2025-10-30, similarity 0.9904):
[0001193125-25-258554:note_history:27]
As of September 30, 2025, the Company had $632.2 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 27% in fiscal 2027, and the remaining 30% of the balance thereafter.

- changed (2026-01-29):
[0001193125-26-029334:note_history:28]
Revenue recognized for the three months ended December 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $107.6 million and $101.3 million, respectively. Revenue recognized for the six months ended December 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $193.7 million and $183.3 million, respectively.
  (was, 2025-10-30, similarity 0.6597):
[0001193125-25-258554:note_history:28]
Revenue recognized for the three months ended September 30, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $104.7 million and $100.3 million, respectively.

- changed (2026-01-29):
[0001193125-26-029334:note_history:29]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $29.4 million and $26.9 million as of December 31, 2025 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2025 and 2024 was $3.5 million and $3.1 million, respectively. Amortization recognized during the six months ended December 31, 2025 and 2024 was $6.9 million and $6.1 million, respectively.
  (was, 2025-10-30, similarity 0.9413):
[0001193125-25-258554:note_history:29]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $28.6 million and $26.9 million as of September 30, 2025 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2025 and 2024 was $3.4 million and $3.0 million, respectively.

- changed (2026-01-29):
[0001193125-26-029334:note_history:30]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table presents the Company’s net revenues disaggregated by geographic region (in thousands):
  (was, 2025-10-30, similarity 0.9609):
[0001193125-25-258554:note_history:30]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by geographic region (in thousands):

- changed (2026-01-29):
[0001193125-26-029334:note_history:31]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 135,173 |  |  | $ | 119,678 |  |  | $ | 271,557 |  |  | $ | 272,931 |  |
| Other |  |  | 13,218 |  |  |  | 11,710 |  |  |  | 26,093 |  |  |  | 23,892 |  |
| Total Americas |  |  | 148,391 |  |  |  | 131,388 |  |  |  | 297,650 |  |  |  | 296,823 |  |
| EMEA |  |  | 140,389 |  |  |  | 128,257 |  |  |  | 261,635 |  |  |  | 213,175 |  |
| APAC |  |  | 29,145 |  |  |  | 19,710 |  |  |  | 68,885 |  |  |  | 38,561 |  |
| Total net revenues |  | $ | 317,925 |  |  | $ | 279,355 |  |  | $ | 628,170 |  |  | $ | 548,559 |  |
  (was, 2025-10-30, similarity 0.6675):
[0001193125-25-258554:note_history:31]
|  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Americas: |  |  |  |  |  |  |
| United States |  |  | 136,384 |  |  | $ | 153,253 |  |
| Other |  |  | 12,875 |  |  |  | 12,182 |  |
| Total Americas |  |  | 149,259 |  |  |  | 165,435 |  |
| EMEA |  |  | 121,246 |  |  |  | 84,918 |  |
| APAC |  |  | 39,740 |  |  |  | 18,851 |  |
| Total net revenues |  | $ | 310,245 |  |  | $ | 269,204 |  |

- added (2026-01-29):
[0001193125-26-029334:note_history:32]
For the three and six months ended December 31, 2025 the Company generated 15% and 13% of its net revenues from the Netherlands, respectively. For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of the Company's net revenues for the three and six months ended December 31, 2025 and 2024.

- changed (2026-01-29):
[0001193125-26-029334:note_history:33]
The following table presents customers accounting for 10% or more of the Company’s net revenues for the periods indicated below:
  (was, 2025-10-30, similarity 0.9609):
[0001193125-25-258554:note_history:33]
The following table sets forth customers accounting for 10% or more of the Company’s net revenues for the periods indicated below:

- changed (2026-01-29):
[0001193125-26-029334:note_history:34]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, 2025 |  | December 31, 2024 |  | December 31, 2025 |  | December 31, 2024 |
| Westcon Group, Inc. |  | 22% |  | 22% |  | 19% |  | 18% |
| TD Synnex Corporation |  | 17% |  | 17% |  | 16% |  | 19% |
| Jenne, Inc. |  | 16% |  | 15% |  | 17% |  | 18% |
  (was, 2025-10-30, similarity 0.6788):
[0001193125-25-258554:note_history:34]
|  |  | Three Months Ended |
|  |  | September 30,2025 |  | September 30,2024 |
| Jenne, Inc. |  | 18% |  | 21% |
| TD Synnex Corporation |  | 16% |  | 22% |
| Westcon Group, Inc. |  | 15% |  | 15% |

- changed (2026-01-29):
[0001193125-26-029334:note_history:35]
The following table presents major customers accounting for 10% or more of the Company’s net accounts receivable balance:
  (was, 2025-10-30, similarity 0.9587):
[0001193125-25-258554:note_history:35]
The following table sets forth major customers accounting for 10% or more of the Company’s net accounts receivable balance:

- changed (2026-01-29):
[0001193125-26-029334:note_history:36]
|  |  | December 31, 2025 |  | June 30, 2025 |
| Jenne, Inc. |  | 22% |  | 22% |
| Westcon Group, Inc. |  | 16% |  | * |
| TD Synnex Corporation |  | 10% |  | * |
| Ericsson, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |
  (was, 2025-10-30, similarity 0.8088):
[0001193125-25-258554:note_history:36]
|  |  | September 30,2025 |  | June 30,2025 |
| Jenne, Inc. |  | 21% |  | 22% |
| J's Communication Co., Ltd. |  | 11% |  | * |
| Ericcson, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |

- removed (2026-01-29):
[0001193125-25-258554:note_history:37]
For the three months ended September 30, 2025 and 2024 no foreign country accounted for 10% or more of the Company's net revenues.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-01-29):
[0001193125-26-029334:note_history:38]
As of December 31, 2025, the Company had $642.9 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 30% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 34% in fiscal 2027, and the remaining 36% of the balance thereafter.
  (was, 2025-10-30, similarity 0.9904):
[0001193125-25-258554:note_history:38]
As of September 30, 2025, the Company had $632.2 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 27% in fiscal 2027, and the remaining 30% of the balance thereafter.

- changed (2026-01-29):
[0001193125-26-029334:note_history:39]
Revenue recognized for the three months ended December 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $107.6 million and $101.3 million, respectively. Revenue recognized for the six months ended December 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $193.7 million and $183.3 million, respectively.
  (was, 2025-10-30, similarity 0.6597):
[0001193125-25-258554:note_history:39]
Revenue recognized for the three months ended September 30, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $104.7 million and $100.3 million, respectively.

- changed (2026-01-29):
[0001193125-26-029334:note_history:40]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $29.4 million and $26.9 million as of December 31, 2025 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2025 and 2024 was $3.5 million and $3.1 million, respectively. Amortization recognized during the six months ended December 31, 2025 and 2024 was $6.9 million and $6.1 million, respectively.
  (was, 2025-10-30, similarity 0.9413):
[0001193125-25-258554:note_history:40]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $28.6 million and $26.9 million as of September 30, 2025 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2025 and 2024 was $3.4 million and $3.0 million, respectively.

- changed (2026-01-29):
[0001193125-26-029334:note_history:41]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table presents the Company’s net revenues disaggregated by geographic region (in thousands):
  (was, 2025-10-30, similarity 0.9609):
[0001193125-25-258554:note_history:41]
The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table sets forth the Company’s net revenues disaggregated by geographic region (in thousands):

- changed (2026-01-29):
[0001193125-26-029334:note_history:42]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 135,173 |  |  | $ | 119,678 |  |  | $ | 271,557 |  |  | $ | 272,931 |  |
| Other |  |  | 13,218 |  |  |  | 11,710 |  |  |  | 26,093 |  |  |  | 23,892 |  |
| Total Americas |  |  | 148,391 |  |  |  | 131,388 |  |  |  | 297,650 |  |  |  | 296,823 |  |
| EMEA |  |  | 140,389 |  |  |  | 128,257 |  |  |  | 261,635 |  |  |  | 213,175 |  |
| APAC |  |  | 29,145 |  |  |  | 19,710 |  |  |  | 68,885 |  |  |  | 38,561 |  |
| Total net revenues |  | $ | 317,925 |  |  | $ | 279,355 |  |  | $ | 628,170 |  |  | $ | 548,559 |  |
  (was, 2025-10-30, similarity 0.6675):
[0001193125-25-258554:note_history:42]
|  | Three Months Ended |  |
|  |  | September 30,2025 |  |  | September 30,2024 |  |
| Americas: |  |  |  |  |  |  |
| United States |  |  | 136,384 |  |  | $ | 153,253 |  |
| Other |  |  | 12,875 |  |  |  | 12,182 |  |
| Total Americas |  |  | 149,259 |  |  |  | 165,435 |  |
| EMEA |  |  | 121,246 |  |  |  | 84,918 |  |
| APAC |  |  | 39,740 |  |  |  | 18,851 |  |
| Total net revenues |  | $ | 310,245 |  |  | $ | 269,204 |  |

- added (2026-01-29):
[0001193125-26-029334:note_history:43]
For the three and six months ended December 31, 2025 the Company generated 15% and 13% of its net revenues from the Netherlands, respectively. For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of the Company's net revenues for the three and six months ended December 31, 2025 and 2024.

- removed (2026-01-29):
[0001193125-25-258554:note_history:44]
For the three months ended September 30, 2025 and 2024 no foreign country accounted for 10% or more of the Company's net revenues.
