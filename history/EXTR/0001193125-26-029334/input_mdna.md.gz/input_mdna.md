# EXTR MD&A — 0001193125-26-029334


## mdna

[0001193125-26-029334:mdna:1]
[same as prior period, unchanged from 0001193125-25-258554:mdna:1]

[0001193125-26-029334:mdna:2]
[same as prior period, unchanged from 0001193125-25-258554:mdna:2]

[0001193125-26-029334:mdna:3]
[same as prior period, unchanged from 0001193125-25-258554:mdna:3]

[0001193125-26-029334:mdna:4]
Extreme Networks, Inc. (“Extreme,” “Company,” “we,” “us” and “our”) is a leader in AI-powered cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence (“AI”), analytics, and automation and have industry-leading support services. Tens of thousands of customers globally trust Extreme to drive value, foster innovation, and overcome extreme challenges. Extreme also designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment. Our Extreme Platform ONETM solution, announced in December 2024 and made generally available in July 2025, is a technology platform that is designed to reduce the complexity for enterprises by seamlessly integrating networking, security and AI solutions into a single platform. AI-powered automation includes conversational, interactive and autonomous AI agents—to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex tasks.

[0001193125-26-029334:mdna:5]
[same as prior period, unchanged from 0001193125-25-258554:mdna:5]

[0001193125-26-029334:mdna:6]
[same as prior period, unchanged from 0001193125-25-258554:mdna:6]

[0001193125-26-029334:mdna:7]
[same as prior period, unchanged from 0001193125-25-258554:mdna:7]

[0001193125-26-029334:mdna:8]
[same as prior period, unchanged from 0001193125-25-258554:mdna:8]

[0001193125-26-029334:mdna:9]
[same as prior period, unchanged from 0001193125-25-258554:mdna:9]

[0001193125-26-029334:mdna:10]
We believe that the network has never been more vital than it is today. As administrators grapple with more data, coming from more places, more connected devices, and more Software-as-a-Service (“SaaS”) based applications, the cloud is fundamental to managing and maintaining a modern network. Traditional network offerings are not well-suited to fulfill enterprise expectations for rapid delivery of new services, more flexible business models, real-time response, and massive scalability. We expect Extreme Platform ONE to deliver significant productivity gains for IT teams by streamlining network design, deployment, management, and commercial operations through its generative, multimodal, and agentic AI capabilities.

[0001193125-26-029334:mdna:11]
[same as prior period, unchanged from 0001193125-25-258554:mdna:11]

[0001193125-26-029334:mdna:12]
Service providers are investing in network enhancements with platforms and applications that deliver data insights, provide flexibility, and can quickly respond to new user demands and 5G use cases. The scale of issues and challenges seen within service provider networks is even greater than the enterprise network—thus they too can greatly benefit from operational gains from Extreme Platform ONE.

[0001193125-26-029334:mdna:13]
[same as prior period, unchanged from 0001193125-25-258554:mdna:13]

[0001193125-26-029334:mdna:14]
[same as prior period, unchanged from 0001193125-25-258554:mdna:14]

[0001193125-26-029334:mdna:15]
[same as prior period, unchanged from 0001193125-25-258554:mdna:15]

[0001193125-26-029334:mdna:16]
[same as prior period, unchanged from 0001193125-25-258554:mdna:16]

[0001193125-26-029334:mdna:17]
[same as prior period, unchanged from 0001193125-25-258554:mdna:17]

[0001193125-26-029334:mdna:18]
[same as prior period, unchanged from 0001193125-25-258554:mdna:18]

[0001193125-26-029334:mdna:19]
[same as prior period, unchanged from 0001193125-25-258554:mdna:19]

[0001193125-26-029334:mdna:20]
[same as prior period, unchanged from 0001193125-25-258554:mdna:20]

[0001193125-26-029334:mdna:21]
[same as prior period, unchanged from 0001193125-25-258554:mdna:21]

[0001193125-26-029334:mdna:22]
[same as prior period, unchanged from 0001193125-25-258554:mdna:22]

[0001193125-26-029334:mdna:23]
[same as prior period, unchanged from 0001193125-25-258554:mdna:23]

[0001193125-26-029334:mdna:24]
[same as prior period, unchanged from 0001193125-25-258554:mdna:24]

[0001193125-26-029334:mdna:25]
[same as prior period, unchanged from 0001193125-25-258554:mdna:25]

[0001193125-26-029334:mdna:26]
[same as prior period, unchanged from 0001193125-25-258554:mdna:26]

[0001193125-26-029334:mdna:27]
[same as prior period, unchanged from 0001193125-25-258554:mdna:27]

[0001193125-26-029334:mdna:28]
[same as prior period, unchanged from 0001193125-25-258554:mdna:28]

[0001193125-26-029334:mdna:29]
[same as prior period, unchanged from 0001193125-25-258554:mdna:29]

[0001193125-26-029334:mdna:30]
[same as prior period, unchanged from 0001193125-25-258554:mdna:30]

[0001193125-26-029334:mdna:31]
[same as prior period, unchanged from 0001193125-25-258554:mdna:31]

[0001193125-26-029334:mdna:32]
[same as prior period, unchanged from 0001193125-25-258554:mdna:32]

[0001193125-26-029334:mdna:33]
[same as prior period, unchanged from 0001193125-25-258554:mdna:33]

[0001193125-26-029334:mdna:34]
[same as prior period, unchanged from 0001193125-25-258554:mdna:34]

[0001193125-26-029334:mdna:35]
[same as prior period, unchanged from 0001193125-25-258554:mdna:35]

[0001193125-26-029334:mdna:36]
[same as prior period, unchanged from 0001193125-25-258554:mdna:36]

[0001193125-26-029334:mdna:37]
[same as prior period, unchanged from 0001193125-25-258554:mdna:37]

[0001193125-26-029334:mdna:38]
o
ExtremeCloud Universal ZTNA is the first network security offering to integrate network, application, and device security within a single solution. By combining Cloud Network Access Control (“NAC”) and Zero Trust Network Access (“ZTNA”) into a single, easy-to-use SaaS offering, we help customers ensure unified observability, frictionless user experiences and a consistent security policy for applications and devices as well as support secure hybrid work use cases for customers. As the virtual private network (“VPN”) market transitions to ZTNA, the proliferation of individual applications, each with their own policy and dashboard, is adding complexity and expense for enterprise

[0001193125-26-029334:mdna:39]
customers. We expect the broadening of our security offering to drive significant traction for our business with growth opportunities.

[0001193125-26-029334:mdna:40]
[same as prior period, unchanged from 0001193125-25-258554:mdna:40]

[0001193125-26-029334:mdna:41]
[same as prior period, unchanged from 0001193125-25-258554:mdna:41]

[0001193125-26-029334:mdna:42]
[same as prior period, unchanged from 0001193125-25-258554:mdna:42]

[0001193125-26-029334:mdna:43]
[same as prior period, unchanged from 0001193125-25-258554:mdna:43]

[0001193125-26-029334:mdna:44]
[same as prior period, unchanged from 0001193125-25-258554:mdna:44]

[0001193125-26-029334:mdna:45]
[same as prior period, unchanged from 0001193125-25-258554:mdna:45]

[0001193125-26-029334:mdna:46]
[same as prior period, unchanged from 0001193125-25-258554:mdna:46]

[0001193125-26-029334:mdna:47]
[same as prior period, unchanged from 0001193125-25-258554:mdna:47]

[0001193125-26-029334:mdna:48]
[same as prior period, unchanged from 0001193125-25-258554:mdna:48]

[0001193125-26-029334:mdna:49]
[same as prior period, unchanged from 0001193125-25-258554:mdna:49]

[0001193125-26-029334:mdna:50]
During the second quarter of fiscal 2026, we achieved the following results:

[0001193125-26-029334:mdna:51]
•
Net revenues of $317.9 million compared to $279.4 million in the second quarter of fiscal 2025.

[0001193125-26-029334:mdna:52]
•
Product revenues of $197.8 million compared to $172.3 million in the second quarter of fiscal 2025.

[0001193125-26-029334:mdna:53]
•
Subscription and support revenues of $120.2 million compared to $107.1 million in the second quarter of fiscal 2025.

[0001193125-26-029334:mdna:54]
•
Total gross margin of 61.4% of net revenues compared to 62.7% of net revenues in the second quarter of fiscal 2025.

[0001193125-26-029334:mdna:55]
•
Operating income of $13.0 million compared to operating income of $12.7 million in the second quarter of fiscal 2025.

[0001193125-26-029334:mdna:56]
•
Net income of $7.9 million compared to  $7.4 million in the second quarter of fiscal 2025.

[0001193125-26-029334:mdna:57]
During the first six months of fiscal 2026, we reflected the following results:

[0001193125-26-029334:mdna:58]
•
Cash flows provided by operating activities of $36.1 million compared to $40.1 million in the six months ended December 31, 2024.

[0001193125-26-029334:mdna:59]
•
Cash and cash equivalents of $219.8 million as of December 31, 2025 compared to $231.7 million as of June 30, 2025.

[0001193125-26-029334:mdna:60]
[same as prior period, unchanged from 0001193125-25-258554:mdna:60]

[0001193125-26-029334:mdna:61]
[same as prior period, unchanged from 0001193125-25-258554:mdna:61]

[0001193125-26-029334:mdna:62]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | $Change |  |  | %Change |  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | $Change |  |  | %Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 197,765 |  |  | $ | 172,261 |  |  | $ | 25,504 |  |  |  | 14.8 | % |  | $ | 391,806 |  |  | $ | 334,545 |  |  | $ | 57,261 |  |  |  | 17.1 | % |
| Percentage of net revenues |  |  | 62.2 | % |  |  | 61.7 | % |  |  |  |  |  |  |  |  | 62.4 | % |  |  | 61.0 | % |  |  |  |  |  |  |
| Subscription and support |  |  | 120,160 |  |  |  | 107,094 |  |  |  | 13,066 |  |  |  | 12.2 | % |  |  | 236,364 |  |  |  | 214,014 |  |  |  | 22,350 |  |  |  | 10.4 | % |
| Percentage of net revenues |  |  | 37.8 | % |  |  | 38.3 | % |  |  |  |  |  |  |  |  | 37.6 | % |  |  | 39.0 | % |  |  |  |  |  |  |
| Total net revenues |  | $ | 317,925 |  |  | $ | 279,355 |  |  | $ | 38,570 |  |  |  | 13.8 | % |  | $ | 628,170 |  |  | $ | 548,559 |  |  | $ | 79,611 |  |  |  | 14.5 | % |

[0001193125-26-029334:mdna:63]
[same as prior period, unchanged from 0001193125-25-258554:mdna:63]

[0001193125-26-029334:mdna:64]
Product revenues increased $25.5 million or 14.8% for the three months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. Product revenues increased $57.3 million or 17.1% for the six months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in product revenues was primarily due to strong demand for our products, which contributed to higher bookings and higher shipments than the corresponding period in fiscal 2025.

[0001193125-26-029334:mdna:65]
Subscription and support revenues increased $13.1 million or 12.2% for the three months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. Subscription and support revenues increased $22.4 million or 10.4% for the six months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in subscription and support revenues was driven by increased adoption of our cloud network management solutions and continued growth in our subscription business.

[0001193125-26-029334:mdna:66]
[same as prior period, unchanged from 0001193125-25-258554:mdna:66]

[0001193125-26-029334:mdna:67]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | $Change |  |  | %Change |  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | $Change |  |  | %Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 110,765 |  |  | $ | 99,657 |  |  | $ | 11,108 |  |  |  | 11.1 | % |  | $ | 218,678 |  |  | $ | 192,539 |  |  | $ | 26,139 |  |  |  | 13.6 | % |  |
| Percentage of product revenues |  |  | 56.0 | % |  |  | 57.9 | % |  |  |  |  |  |  |  |  | 55.8 | % |  |  | 57.6 | % |  |  |  |  |  |  |  |
| Subscription and support |  |  | 84,315 |  |  |  | 75,466 |  |  |  | 8,849 |  |  |  | 11.7 | % |  |  | 164,431 |  |  |  | 152,091 |  |  |  | 12,340 |  |  |  | 8.1 | % |  |
| Percentage of subscription and support revenues |  |  | 70.2 | % |  |  | 70.5 | % |  |  |  |  |  |  |  |  | 69.6 | % |  |  | 71.1 | % |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 195,080 |  |  | $ | 175,123 |  |  | $ | 19,957 |  |  |  | 11.4 | % |  | $ | 383,109 |  |  | $ | 344,630 |  |  | $ | 38,479 |  |  |  | 11.2 | % |  |
| Percentage of net revenues |  |  | 61.4 | % |  |  | 62.7 | % |  |  |  |  |  |  |  |  | 61.0 | % |  |  | 62.8 | % |  |  |  |  |  |  |  |

[0001193125-26-029334:mdna:68]
Product gross profit increased $11.1 million or 11.1% for the three months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. Product gross profit increased $26.1 million or 13.6% for the six months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in product gross profit was primarily due to higher product revenues, partially offset by increased distribution costs and unfavorable purchase price variance related to increased costs for memory components.

[0001193125-26-029334:mdna:69]
Subscription and support gross profit increased $8.8 million or 11.7% for the three months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. Subscription and support gross profit increased $12.3 million or 8.1% for the six months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in subscription and support gross profit was primarily due to higher subscription revenues, partially offset by higher subscription hosting costs and professional services costs.

[0001193125-26-029334:mdna:70]
[same as prior period, unchanged from 0001193125-25-258554:mdna:70]

[0001193125-26-029334:mdna:71]
[same as prior period, unchanged from 0001193125-25-258554:mdna:71]

[0001193125-26-029334:mdna:72]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | $Change |  |  | %Change |  |  | December 31, 2025 |  |  | December 31, 2024 |  |  | $Change |  |  | %Change |  |  |  |
| Research and development |  | $ | 57,522 |  |  | $ | 54,883 |  |  | $ | 2,639 |  |  |  | 4.8 | % |  | $ | 115,275 |  |  | $ | 109,334 |  |  | $ | 5,941 |  |  |  | 5.4 | % |  |  |
| Sales and marketing |  |  | 89,393 |  |  |  | 79,967 |  |  |  | 9,426 |  |  |  | 11.8 | % |  |  | 178,316 |  |  |  | 161,350 |  |  |  | 16,966 |  |  |  | 10.5 | % |  |  |
| General and administrative |  |  | 34,599 |  |  |  | 26,064 |  |  |  | 8,535 |  |  |  | 32.7 | % |  |  | 63,786 |  |  |  | 62,665 |  |  |  | 1,121 |  |  |  | 1.8 | % |  |  |
| Restructuring and related charges |  |  | 167 |  |  |  | 1,035 |  |  |  | (868 | ) |  |  | (83.9 | )% |  |  | 538 |  |  |  | 2,312 |  |  |  | (1,774 | ) |  |  | (76.7 | )% |  |  |
| Amortization of intangible assets |  |  | 407 |  |  |  | 509 |  |  |  | (102 | ) |  |  | (20.0 | )% |  |  | 907 |  |  |  | 1,021 |  |  |  | (114 | ) |  |  | (11.2 | )% |  |  |
| Total operating expenses |  | $ | 182,088 |  |  | $ | 162,458 |  |  | $ | 19,630 |  |  |  | 12.1 | % |  | $ | 358,822 |  |  | $ | 336,682 |  |  | $ | 22,140 |  |  |  | 6.6 | % |  |  |

[0001193125-26-029334:mdna:73]
[same as prior period, unchanged from 0001193125-25-258554:mdna:73]

[0001193125-26-029334:mdna:74]
[same as prior period, unchanged from 0001193125-25-258554:mdna:74]

[0001193125-26-029334:mdna:75]
Research and development expenses increased by $2.6 million or 4.8% for the three months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in research and development expenses was primarily due to a $1.3 million increase in personnel costs due to higher compensation and benefits costs, a $1.1 million increase in engineering project costs, and a $0.9 million increase in information technology, equipment and depreciation costs, offset by a $0.7 million decrease in facilities and occupancy related costs.

[0001193125-26-029334:mdna:76]
Research and development expenses increased by $5.9 million or 5.4% for the six months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in research and development expenses was primarily due to a $3.4 million increase in personnel costs due to higher compensation and benefits costs, a $2.0 million increase in engineering project costs, and a $1.6 million increase in information technology, equipment costs and depreciation costs, offset by a $1.1 million decrease in facilities and occupancy related costs.

[0001193125-26-029334:mdna:77]
[same as prior period, unchanged from 0001193125-25-258554:mdna:76]

[0001193125-26-029334:mdna:78]
[same as prior period, unchanged from 0001193125-25-258554:mdna:77]

[0001193125-26-029334:mdna:79]
Sales and marketing expenses increased by $9.4 million or 11.8% for the three months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in sales and marketing expenses was primarily due to a $4.0 million increase in sales and marketing costs primarily related to higher sales commissions, a $3.6 million increase in personnel costs due to higher headcount and higher salaries and benefits costs and a $1.8 million increase in other expenses primarily related to information technology and equipment costs and professional fees.

[0001193125-26-029334:mdna:80]
Sales and marketing expenses increased by $17.0 million or 10.5% for the six months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in sales and marketing expenses was primarily due to a $8.2 million increase in personnel costs due to higher headcount and higher salaries and benefits costs, a $6.0 million increase in sales and marketing costs primarily related to higher sales commissions and higher travel costs, a $1.7 million increase in information technology and equipment costs, and a $1.1 million increase in other expenses primarily related to professional fees.

[0001193125-26-029334:mdna:81]
[same as prior period, unchanged from 0001193125-25-258554:mdna:79]

[0001193125-26-029334:mdna:82]
[same as prior period, unchanged from 0001193125-25-258554:mdna:80]

[0001193125-26-029334:mdna:83]
General and administrative expenses increased by $8.5 million or 32.7% for the three months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in general and administrative expenses was primarily due to a $3.8 million increase in professional fees, a $2.4 million increase in personnel costs due to higher headcount and higher salaries and benefits costs, a $2.4 million increase in system transition costs, partially offset by a $0.1 million decrease in legal costs related to litigation matters.

[0001193125-26-029334:mdna:84]
General and administrative expenses increased by $1.1 million or 1.8% for the six months ended December 31, 2025 as compared to the corresponding period in fiscal 2025. The increase in general and administrative expenses was primarily due to a $4.4 million increase in personnel costs due to higher headcount and higher salaries and benefits costs, a $3.1 million increase in professional fees, a $2.0 million increase in software licensing costs and a $2.0 million increase in system transition costs, partially offset by a $8.8 million decrease in legal costs related to litigation matters, a $1.2 million decrease in depreciation costs and a $0.4 million decrease in other expenses primarily related to information technology and equipment costs.

[0001193125-26-029334:mdna:85]
[same as prior period, unchanged from 0001193125-25-258554:mdna:82]

[0001193125-26-029334:mdna:86]
For the three and six months ended December 31, 2025, we recorded restructuring charges of $0.2 million and $0.5 million, respectively, which primarily consisted of asset disposal costs and reversals of previously established accruals related to unused severance benefits associated with the reduction-in-force actions related to the “Q2 2024 Plan”, and “2023 Plan”, each as described in Note 13, Restructuring and Related Charges, in the Notes to Condensed Consolidated Financial Statements included elsewhere in this Report.

[0001193125-26-029334:mdna:87]
For the three and six months ended December 31, 2024, we recorded restructuring and related charges of $1.0 million and $2.3 million, respectively, which primarily consisted of additional severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q2 2024 Plan”, and “Q3 2024 Plan”, each as described in Note 13, Restructuring and Related Charges, in the Notes to Condensed Consolidated Financial Statements included elsewhere in this Report.

[0001193125-26-029334:mdna:88]
[same as prior period, unchanged from 0001193125-25-258554:mdna:85]

[0001193125-26-029334:mdna:89]
During the three months ended December 31, 2025 and 2024, we recorded $0.4 million and $0.5 million of operating expenses, respectively, related to the amortization of intangible assets.

[0001193125-26-029334:mdna:90]
During the six months ended December 31, 2025 and 2024, we recorded $0.9 million and $1.0 million of operating expenses, respectively, related to the amortization of intangible assets.

[0001193125-26-029334:mdna:91]
[same as prior period, unchanged from 0001193125-25-258554:mdna:87]

[0001193125-26-029334:mdna:92]
During the three months ended December 31, 2025 and 2024, we recorded $1.1 million and $0.8 million, respectively, in interest income. The increase in interest income was primarily related to the higher interest earned on our cash accounts due to higher interest rates as well as higher cash and cash equivalents balances held during the second quarter in fiscal 2026.

[0001193125-26-029334:mdna:93]
During the six months ended December 31, 2025 and 2024, we recorded $2.3 million and $1.7 million, respectively, in interest income. The increase in interest income was primarily related to the higher interest earned on our cash accounts due to interest rates as well as higher cash and cash equivalents balances held during the first half of fiscal 2026.

[0001193125-26-029334:mdna:94]
[same as prior period, unchanged from 0001193125-25-258554:mdna:89]

[0001193125-26-029334:mdna:95]
During the three months ended December 31, 2025 and 2024, we recorded $3.4 million and $4.2 million, respectively, in interest expense related to the debt obligations held under our Amended Credit Agreement. The decrease in interest expense was primarily due to lower average rates under the Amended Credit Agreement.

[0001193125-26-029334:mdna:96]
During the six months ended December 31, 2025 and 2024, we recorded $7.0 million and $8.6 million, respectively, in interest expense related to the debt obligations held under our Amended Credit Agreement. The decrease in interest expense was primarily due to lower average rates under the Amended Credit Agreement.

[0001193125-26-029334:mdna:97]
Other Income (Expense), Net

[0001193125-26-029334:mdna:98]
During the three months ended December 31, 2025 and 2024, we recorded other expense, net of $0.4 million and other income, net of $0.7 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001193125-26-029334:mdna:99]
During the six months ended December 31, 2025 and 2024, we recorded other expense, net of $0.8 million and less than $0.1 million, respectively. The other expense, net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001193125-26-029334:mdna:100]
[same as prior period, unchanged from 0001193125-25-258554:mdna:93]

[0001193125-26-029334:mdna:101]
For the three months ended December 31, 2025 and 2024, we recorded an income tax provision of $2.5 million and $2.6 million, respectively.

[0001193125-26-029334:mdna:102]
For the six months ended December 31, 2025 and 2024, we recorded an income tax provision of $5.3 million and $4.1 million, respectively.

[0001193125-26-029334:mdna:103]
The income tax provisions for the three and six months ended December 31, 2025 and 2024 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications System.

[0001193125-26-029334:mdna:104]
[same as prior period, unchanged from 0001193125-25-258554:mdna:96]

[0001193125-26-029334:mdna:105]
[same as prior period, unchanged from 0001193125-25-258554:mdna:97]

[0001193125-26-029334:mdna:106]
[same as prior period, unchanged from 0001193125-25-258554:mdna:98]

[0001193125-26-029334:mdna:107]
[same as prior period, unchanged from 0001193125-25-258554:mdna:99]

[0001193125-26-029334:mdna:108]
[same as prior period, unchanged from 0001193125-25-258554:mdna:100]

[0001193125-26-029334:mdna:109]
[same as prior period, unchanged from 0001193125-25-258554:mdna:101]

[0001193125-26-029334:mdna:110]
[same as prior period, unchanged from 0001193125-25-258554:mdna:102]

[0001193125-26-029334:mdna:111]
[same as prior period, unchanged from 0001193125-25-258554:mdna:103]

[0001193125-26-029334:mdna:112]
|  |  | December 31, 2025 |  |  | June 30, 2025 |  |
| Cash and cash equivalents |  | $ | 219,791 |  |  | $ | 231,745 |  |

[0001193125-26-029334:mdna:113]
As of December 31, 2025, our principal sources of liquidity consisted of cash and cash equivalents of $219.8 million, accounts receivable, net of $152.4 million, and available borrowings under our 2023 Revolving Facility of $135.8 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, repayments of debt and related interest and share repurchases. We believe that our $219.8 million of cash and cash equivalents at December 31, 2025, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0001193125-26-029334:mdna:114]
On February 18, 2025, we announced that our Board had authorized management to repurchase up to $200 million of shares of the Company's common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”). Under these repurchase programs, purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The 2025 Repurchase Program does not obligate us to acquire any shares of our common stock, and it may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended December 31, 2025, the Company did not repurchase any shares of its common stock. During the six months ended December 31, 2025, we repurchased a total of 577,281 shares of our common stock on the open market at a total cost of $12.0 million with an average price of $20.79 per share. As of December 31, 2025, the Company had $188.0 million available under the 2025 Repurchase Program.

[0001193125-26-029334:mdna:115]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use the proceeds of the loans for working capital and general corporate purposes.

[0001193125-26-029334:mdna:116]
At our election, the initial term loan under the 2023 Credit Agreement may be made as either a base rate loan or a Secured Overnight Financing Rate loan (“SOFR loan”). The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s Consolidated Leverage Ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. We also agreed to pay other closing fees, arrangement fees, and administration fees.

[0001193125-26-029334:mdna:117]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001193125-26-029334:mdna:118]
On August 14, 2024, we entered into an Amendment Number One to the 2023 Credit Agreement the (the 2023 Credit Agreement as amended by that certain Amendment Number One, “Amended Credit Agreement”). Under the Amended Credit Agreement, we modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the Amended Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with our operations and activities.

[0001193125-26-029334:mdna:119]
As of December 31, 2025, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0001193125-26-029334:mdna:120]
[same as prior period, unchanged from 0001193125-25-258554:mdna:112]

[0001193125-26-029334:mdna:121]
[same as prior period, unchanged from 0001193125-25-258554:mdna:113]

[0001193125-26-029334:mdna:122]
|  |  | Six Months Ended |  |
|  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Net cash provided by operating activities |  | $ | 36,140 |  |  | $ | 40,118 |  |
| Net cash used in investing activities |  |  | (13,922 | ) |  |  | (12,325 | ) |
| Net cash used in financing activities |  |  | (33,998 | ) |  |  | (13,995 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (174 | ) |  |  | (175 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (11,954 | ) |  | $ | 13,623 |  |

[0001193125-26-029334:mdna:123]
Net Cash Provided by Operating Activities

[0001193125-26-029334:mdna:124]
Cash flows provided by operations in the six months ended December 31, 2025 were $36.1 million, including our net income of $13.5 million and non-cash expenses of $64.0 million for items such as amortization of intangible assets, amortization of cloud computing implementation costs, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory, provision for credit losses and interest. Other sources of cash for the period included a decrease in inventories and increases in accounts payable, deferred revenue and accrued compensation and benefits. This was partially offset by increases in accounts receivable and other current and non-current assets as well as decreases in operating lease liabilities and other accrued liabilities.

[0001193125-26-029334:mdna:125]
Cash flows provided by operations in the six months ended December 31, 2024 were $40.1 million, including our net loss of $3.1 million and non-cash expenses of $54.7 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in inventories and increases in accounts payable, deferred revenue and accrued compensation and benefits. This was partially offset by increases in accounts receivable and other assets as well as decreases in operating lease liabilities and other liabilities.

[0001193125-26-029334:mdna:126]
[same as prior period, unchanged from 0001193125-25-258554:mdna:118]

[0001193125-26-029334:mdna:127]
Cash flows used in investing activities in the six months ended December 31, 2025 were $13.9 million for the purchases of property and equipment and capitalized software development costs.

[0001193125-26-029334:mdna:128]
Cash flows used in investing activities in the six months ended December 31, 2024 were $12.3 million for the purchases of property and equipment and capitalized software development costs.

[0001193125-26-029334:mdna:129]
[same as prior period, unchanged from 0001193125-25-258554:mdna:121]

[0001193125-26-029334:mdna:130]
Cash flows used in financing activities in the six months ended December 31, 2025 were $34.0 million primarily due to share repurchases of $12.0 million under the 2025 Repurchase Program, payments of $14.5 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options and debt repayments of $7.5 million.

[0001193125-26-029334:mdna:131]
Cash flows used in financing activities in the six months ended December 31, 2024 were $14.0 million primarily due to payments of $8.3 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, a payment of $0.7 million for debt financing costs related to the Amended Credit Agreement, and debt repayments of $5.0 million.

[0001193125-26-029334:mdna:132]
[same as prior period, unchanged from 0001193125-25-258554:mdna:124]

[0001193125-26-029334:mdna:133]
Foreign currency effect on cash and cash equivalents decreased in the six months ended December 31, 2025, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the Euro.

[0001193125-26-029334:mdna:134]
[same as prior period, unchanged from 0001193125-25-258554:mdna:126]

[0001193125-26-029334:mdna:135]
As of December 31, 2025, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0001193125-26-029334:mdna:136]
Our debt obligations relate to amounts owed under our Amended Credit Agreement. As of December 31, 2025, we had $172.5 million of debt outstanding, which is payable on quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0001193125-26-029334:mdna:137]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of December 31, 2025, we had non-cancelable commitments to purchase $52.2 million of inventory. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0001193125-26-029334:mdna:138]
We have contractual commitments to our suppliers which represent commitments for future services. As of December 31, 2025, we had contractual commitments of $12.9 million that are due through our fiscal year 2027.

[0001193125-26-029334:mdna:139]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of December 31, 2025, the value of our obligations under operating leases was $47.9 million.

[0001193125-26-029334:mdna:140]
[same as prior period, unchanged from 0001193125-25-258554:mdna:132]

[0001193125-26-029334:mdna:141]
We did not have any material commitments for capital expenditures as of December 31, 2025.

[0001193125-26-029334:mdna:142]
[same as prior period, unchanged from 0001193125-25-258554:mdna:134]

[0001193125-26-029334:mdna:143]
We did not have any off-balance sheet arrangements as of December 31, 2025.
