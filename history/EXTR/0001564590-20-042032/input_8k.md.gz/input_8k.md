# EXTR 8-K — 0001564590-20-036431 filed 2020-08-05

## item codes, every 8-K on or before 2020-08-31

- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2020-08-31

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-036431:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-20-036431:8k_2_02:2]
extr-ex991_6.htm

[0001564590-20-036431:8k_2_02:3]
Exhibit 99.1

[0001564590-20-036431:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-20-036431:8k_2_02:5]
Extreme Networks Reports Fourth Fiscal Quarter and Fiscal Year 2020 Financial Results

[0001564590-20-036431:8k_2_02:6]
Revenue Growth Drives Return to Non-GAAP Profitability and Cash Generation

[0001564590-20-036431:8k_2_02:7]
SAN JOSE, Calif., August 5, 2020 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fourth fiscal quarter and fiscal year- ended June 30, 2020.

[0001564590-20-036431:8k_2_02:8]
Fiscal Fourth Quarter Results:

[0001564590-20-036431:8k_2_02:9]
|  | • | Revenue $215.5 million, down 15% year-over-year and up 3% quarter-over-quarter |

[0001564590-20-036431:8k_2_02:10]
|  | • | GAAP EPS $(0.18), down from $(0.14) in Q4 last year |

[0001564590-20-036431:8k_2_02:11]
|  | • | Non-GAAP EPS $0.03, down from $0.06 in Q4 last year |

[0001564590-20-036431:8k_2_02:12]
|  | • | GAAP gross margin 56.0% compared to 55.1% in Q4 last year |

[0001564590-20-036431:8k_2_02:13]
|  | • | Non-GAAP gross margin 59.4% compared to 59.2% in Q4 last year |

[0001564590-20-036431:8k_2_02:14]
|  | • | GAAP operating margin (6.1)% compared to (4.8)% in Q4 last year |

[0001564590-20-036431:8k_2_02:15]
|  | • | Non-GAAP operating margin 5.2%, compared to 4.9% in Q4 last year |

[0001564590-20-036431:8k_2_02:16]
|  | • | Net cash provided by operating activities of $8.8 million |

[0001564590-20-036431:8k_2_02:17]
|  | • | Free Cash Flow of $6.2 million |

[0001564590-20-036431:8k_2_02:18]
“During Q4 Extreme established itself as a critical business partner to our customers and partners with two industry-leading offers. We announced unparalleled choice of cloud management across all three public cloud platforms, and we set a new standard for access to cloud data and insights by offering unlimited data to cloud customers for the lifetime of their subscriptions. These actions helped us to substantially grow our lead generation during the quarter, which bodes well for future funnel growth. We achieved 4% sequential product revenue growth and grew our subscription and services revenue 18% year-over-year. We also grew our cloud new subscription bookings by 42% quarter-over-quarter. These trends highlight the pace at which our customers are embracing our solutions,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-20-036431:8k_2_02:19]
“We are positioning Extreme for future growth and our outlook for Q1’21 reflects our expectations for continued sequential improvement in revenue and operating income. Heading into FY21 we have revamped our go-to-market by removing silos between channel and direct sales, strengthened key partner relationships, and segmented our sales organization to better serve specific customers. We also brought on a new Chief Revenue Officer who has a proven track record of helping organizations transition to more cloud and subscription-oriented businesses,” concluded Meyercord.

[0001564590-20-036431:8k_2_02:20]
Remi Thomas, CFO of Extreme Networks noted: “Following the sequential improvement in revenue, return to non-GAAP profitability, and positive cash flow we achieved in Q4, we ended FY20 on a stronger note in a difficult environment. We are also increasingly confident in our outlook heading into FY21 as we are seeing improving customer demand in key verticals such as Government, Education, and Manufacturing. These trends are reflected in our better-than-seasonal Q1 outlook that calls for a 4% sequential increase in revenue.  We also remain confident in our margin outlook heading into FY21 as

[0001564590-20-036431:8k_2_02:21]
we reduced our non-GAAP operating expenses by $20 million, or 15%, year-over-year in Q4. We expect the combination of improved revenue and lowered costs and expenses to drive increased operating leverage throughout FY21. Finally, our balance sheet remains solid with $194 million of cash and cash equivalents on hand at the end of Q4.”

[0001564590-20-036431:8k_2_02:22]
Recent Key Highlights:

[0001564590-20-036431:8k_2_02:23]
|  | • | Rancho California Water District, an essential public utility in Temecula, California, delivers high-quality water and reclamation services to 150,000 customers every day. The company deployed Extreme's wired and wireless networking solutions to connect and power 45,000 service connection across 150 square miles, ensuring safety, redundancy, and reliability in its operations. |

[0001564590-20-036431:8k_2_02:24]
|  | • | Red Deer Public School District in Alberta, Canada, upgraded its system-wide network with Extreme Wi-Fi 6 access points, switches, and Extreme Fabric Connect virtualization technology along with the ExtremeCloud IQTM solution. The fabric-based network allows the district’s small IT team to automate onboarding of new access points and edge devices, and leverage policy services to control user and device access to the network. ExtremeCloud IQ delivers centralized management and industry-leading uptime, ensuring a secure, reliable digital learning experience for 11,000 students and 1,400 staff across 28 schools and administrative buildings. |

[0001564590-20-036431:8k_2_02:25]
|  | • | Jefferson County Public Schools (JCPS), the largest school system in Kentucky and the 29th largest in the United States, will deploy Extreme wired and wireless solutions, including Extreme Wi-Fi 6 access points and the ExtremeCloud IQ cloud management platform, as part of a district-wide network upgrade. The refreshed network will power cutting-edge digital learning tools and applications in the classroom for 6,738 teachers and 98,361 students at 169 schools upon reopening. |

[0001564590-20-036431:8k_2_02:26]
|  | • | The Community of Madrid's Agency for Digital Administration (Madrid Digital) deployed Extreme wireless networking solutions to connect 17,000 healthcare and administrative staff at hospitals, nursing homes, mental health, and occupational therapy centers with their patients within the Madrid region of Spain. The clinical-grade network is deployed across 30 distributed locations, providing 1.5 million citizens with access to virtual health and social services and protecting staff and patients from the risk of contagion. |

[0001564590-20-036431:8k_2_02:27]
|  | • | Extreme will hold its third annual Connect User Conference September 16-17. The 100 percent virtual event is designed to show customers how we will help them advance their networks and their business to drive strategic outcomes. Attendees will receive technology training, and be able to virtually network and collaborate with industry experts while exploring the future of networking. Register here: https://extremeconnect.co/virtual |

[0001564590-20-036431:8k_2_02:28]
|  | • | Extreme announced it is the first to offer “unlimited data” to its cloud customers, setting a new standard for access to cloud data and insights that is unmatched in the industry. Effective July 1, all new ExtremeCloud IQ Pilot subscribers have access to unlimited data for the lifetime of their subscriptions. With unlimited data, customers gain unprecedented access to historical data to inform future planning via a single, centralized management tool. |

[0001564590-20-036431:8k_2_02:29]
|  | • | Extreme also announced that its ExtremeCloud IQ solution is fully operationalized to run on Amazon Web Services, Google Cloud Platform, and Microsoft Azure. Extreme is the only |

[0001564590-20-036431:8k_2_02:30]
|  |  | cloud networking company concurrently operating ISO/IEC 27001 certified cloud management implementations across major public cloud platforms, as well as in private and on-premises clouds, providing customers with unprecedented flexibility and choice. |

[0001564590-20-036431:8k_2_02:31]
|  | • | Extreme was named the only “Game Changer” in the Sports Innovation Lab Power Play Index, which charts the top 10 technology providers best positioned to deliver connectivity for fans and network solutions for stadiums and entertainment venues. The market assessment was built from evaluating market data from January 2019 to December 2019. |

[0001564590-20-036431:8k_2_02:32]
|  | • | Extreme announced that it is partnering with colleges and universities around the world to deliver Extreme Academy, an academic curriculum designed to educate aspiring IT professionals on networking, security, and cloud fundamentals, as well as machine learning and artificial intelligence. Students who complete the courses can earn an Extreme Networks Associate level qualification. |

[0001564590-20-036431:8k_2_02:33]
|  | • | Extreme announced availability of new, pre-packaged connectivity kits to help sports and entertainment venues accelerate digital transformation efforts and safely bring fans back to stadiums, arenas, ballparks, and racetracks. The Event and Venue Operations (EVO) kits provide venue-optimized, high-density Wi-Fi 6 solutions that will support the rapid roll-out of digital ticketing and touchless payments. |

[0001564590-20-036431:8k_2_02:34]
|  | • | Extreme added new sales and marketing leadership, including Joe Vitalone as Chief Revenue Officer and Wes Durow as Chief Marketing Officer. |

[0001564590-20-036431:8k_2_02:35]
|  | • | Extreme also appointed Nabil Bukhari to Chief Technology Officer, in addition to his role as Chief Product Officer. |

[0001564590-20-036431:8k_2_02:36]
Fiscal Q4 2020 Financial Metrics:

[0001564590-20-036431:8k_2_02:37]
(in millions, except percentages and per share information)

[0001564590-20-036431:8k_2_02:38]
|  |  | Q4 FY'20 |  |  | Q4 FY'19 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 141.5 |  |  | $ | 189.5 |  |  | $ | (48.0 | ) |  |  | (25 | )% |
| Service |  |  | 74.0 |  |  |  | 62.8 |  |  |  | 11.2 |  |  |  | 18 | % |
| Total net revenue |  | $ | 215.5 |  |  | $ | 252.3 |  |  | $ | (36.8 | ) |  |  | (15 | )% |
| Gross margin |  |  | 56.0 | % |  |  | 55.1 | % |  | 90 bps |  |  | - |  |
| Operating margin |  |  | (6.1 | )% |  |  | (4.8 | )% |  | -124 bps |  |  | - |  |
| Net loss |  | $ | (21.2 | ) |  | $ | (17.1 | ) |  | $ | (4.1 | ) |  |  | (24 | )% |
| Net loss per diluted share |  | $ | (0.18 | ) |  | $ | (0.14 | ) |  | $ | (0.04 | ) |  |  | (29 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 141.5 |  |  | $ | 189.5 |  |  | $ | (48.0 | ) |  |  | (25 | )% |
| Service |  |  | 74.0 |  |  |  | 62.8 |  |  |  | 11.2 |  |  |  | 18 | % |
| Total net revenue |  | $ | 215.5 |  |  | $ | 252.3 |  |  | $ | (36.8 | ) |  |  | (15 | )% |
| Gross margin |  |  | 59.4 | % |  |  | 59.2 | % |  | 20 bps |  |  | - |  |
| Operating margin |  |  | 5.2 | % |  |  | 4.9 | % |  | 30 bps |  |  | - |  |
| Net income |  | $ | 3.1 |  |  | $ | 7.6 |  |  | $ | (4.5 | ) |  |  | (60 | )% |
| Net income per diluted share |  | $ | 0.03 |  |  | $ | 0.06 |  |  | $ | (0.03 | ) |  |  | (50 | )% |

[0001564590-20-036431:8k_2_02:39]
|  | • | Q4 ending cash and cash equivalents balance was $193.9 million, a decrease of $2.5 million from the end of Q3. This was primarily driven by cash usage of $8.8 million for financing activities and $2.6 million for capital expenditures, partially offset by operating cash flow generation of $8.8 million. |

[0001564590-20-036431:8k_2_02:40]
|  | • | Q4 accounts receivable balance was $122.7 million, with days sales outstanding of 52, an increase of 10 days from Q3 and a decrease of 11 days from Q4 last year. |

[0001564590-20-036431:8k_2_02:41]
|  | • | Q4 ending inventory was $62.6 million, a decrease of $3.6 million from Q3 and a decrease of $1.0 million from Q4 last year. The year-over-year and quarter-over-quarter decrease in inventory largely reflects demand planning considerations. |

[0001564590-20-036431:8k_2_02:42]
|  | • | Q4 ending gross debt* was $420.8 million, a decrease of $4.8 million from the prior quarter. The sequential decrease reflects the principal debt payment of approximately $5 million. The $240.3 million increase from Q4 last year resulted from the acquisition of Aerohive Networks in August 2019. Net debt* of $226.9 million decreased by $2.2 million from $229.1 million in Q3. |

[0001564590-20-036431:8k_2_02:43]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow as useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. As shown in the table below (in thousands):

[0001564590-20-036431:8k_2_02:44]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Cash flow provided by operations | $ | 8,823 |  |  | $ | 25,443 |  |  | $ | 35,884 |  |  | $ | 104,945 |  |
| Less: PP&E CapEx spending |  | (2,638 | ) |  |  | (6,549 | ) |  |  | (15,268 | ) |  |  | (22,730 | ) |
| Total free cash flow | $ | 6,185 |  |  | $ | 18,894 |  |  | $ | 20,616 |  |  | $ | 82,215 |  |

[0001564590-20-036431:8k_2_02:45]
*Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs. Net debt is defined as gross debt minus cash and cash equivalents, as shown in the table below (in millions):

[0001564590-20-036431:8k_2_02:46]
| Gross debt |  |  | Cash and cash equivalents |  |  | Net debt |  |
| $ | 420.8 |  |  | $ | 193.9 |  |  | $ | 226.9 |  |

[0001564590-20-036431:8k_2_02:47]
Business Outlook:

[0001564590-20-036431:8k_2_02:48]
For its first quarter of fiscal 2021, ending September 30, 2020, the Company is targeting:

[0001564590-20-036431:8k_2_02:49]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ1'21 Guidance – GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 220.0 |  |  | $ | 230.0 |  |
| Gross Margin |  | 55.8 | % |  |  | 56.8 | % |
| Operating Expenses | $ | 131.1 |  |  | $ | 135.1 |  |
| Operating Margin |  | (3.8 | )% |  |  | (2.0 | )% |
| Net Loss | $ | (16.9 | ) |  | $ | (13.1 | ) |
| Loss per basic share | $ | (0.14 | ) |  | $ | (0.11 | ) |
| Shares outstanding used in calculating GAAP EPS | 121.7 |  |  | 121.7 |  |
| FQ1’21 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 220.0 |  |  | $ | 230.0 |  |
| Gross Margin |  | 59.0 | % |  |  | 60.0 | % |
| Operating Expenses | $ | 120.6 |  |  | $ | 124.6 |  |
| Operating Margin |  | 4.2 | % |  |  | 5.8 | % |
| Net Income | $ | 0.7 |  |  | $ | 4.9 |  |
| Income per diluted share | $ | 0.01 |  |  | $ | 0.04 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 122.2 |  |  |  | 122.2 |  |

[0001564590-20-036431:8k_2_02:50]
The following table shows the GAAP to non-GAAP reconciliation for Q1 FY’21 guidance:

[0001564590-20-036431:8k_2_02:51]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.8% - 56.8% |  |  | (3.8)% - (2.0)% |  |  | $(0.14) - $(0.11) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.5% |  |  | 2.5% |  |  | $ | 0.05 |  |
| Stock based compensation | 0.3% |  |  | 3.3% |  |  | $ | 0.06 |  |
| Restructuring | - |  |  | 0.2% |  |  | $ | 0.01 |  |
| Acquisition and integration costs | - |  |  | 0.5% |  |  | $ | 0.01 |  |
| Amortization of non-product intangibles | 0.4% |  |  | 1.3% |  |  | $ | 0.02 |  |
| Non-GAAP | 59.0% - 60.0% |  |  | 4.2% - 5.8% |  |  | $0.01- $0.04 |  |

[0001564590-20-036431:8k_2_02:52]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-20-036431:8k_2_02:53]
Conference Call:

[0001564590-20-036431:8k_2_02:54]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the fourth fiscal quarter results as well as the business outlook for first fiscal quarter ending September 30, 2020, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for 7 days following the call. The conference call may also be heard by dialing 1 (877) 303-9826 or international 1 (224) 357-2194 with Conference ID # 6127689. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 6127689. The encore recording will be available for 7 days following the call.

[0001564590-20-036431:8k_2_02:55]
About Extreme Networks:

[0001564590-20-036431:8k_2_02:56]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven

[0001564590-20-036431:8k_2_02:57]
networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-20-036431:8k_2_02:58]
Extreme Networks, the Extreme Networks logo, ExtremeCloud IQ, and Extreme Fabric Connect, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries.

[0001564590-20-036431:8k_2_02:59]
Non-GAAP Financial Measures:

[0001564590-20-036431:8k_2_02:60]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP net revenue, non-GAAP gross margins, non-GAAP operating margins, non-GAAP net income, non-GAAP net income per share, and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of stock-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, inventory valuation adjustment, restructuring charges, loss on lease contracts, and certain income tax adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-20-036431:8k_2_02:61]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-20-036431:8k_2_02:62]
Forward Looking Statements:

[0001564590-20-036431:8k_2_02:63]
and any worsening of the global business and economic environment as a result, on the Company’s business, financial condition and operating results.

[0001564590-20-036431:8k_2_02:64]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2019, and Quarterly Report on Form 10-Q for the quarter ended March 31, 2020 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-20-036431:8k_2_02:65]
###

[0001564590-20-036431:8k_2_02:66]
EXTREME NETWORKS, INC.

[0001564590-20-036431:8k_2_02:67]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-036431:8k_2_02:68]
(in thousands, except per share amounts)

[0001564590-20-036431:8k_2_02:69]
(Unaudited)

[0001564590-20-036431:8k_2_02:70]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 193,872 |  |  | $ | 169,607 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,212 and $1,054, respectively |  |  | 122,727 |  |  |  | 174,414 |  |
| Inventories |  |  | 62,589 |  |  |  | 63,589 |  |
| Prepaid expenses and other current assets |  |  | 35,019 |  |  |  | 34,379 |  |
| Total current assets |  |  | 414,207 |  |  |  | 441,989 |  |
| Property and equipment, net |  |  | 58,813 |  |  |  | 73,554 |  |
| Operating lease right-of-use assets, net |  |  | 51,274 |  |  |  | — |  |
| Intangible assets, net |  |  | 68,394 |  |  |  | 51,112 |  |
| Goodwill |  |  | 331,159 |  |  |  | 138,577 |  |
| Other assets |  |  | 55,241 |  |  |  | 51,642 |  |
| Total assets |  | $ | 979,088 |  |  | $ | 756,874 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,484 and $489, respectively |  | $ | 16,516 |  |  | $ | 9,011 |  |
| Accounts payable |  |  | 48,439 |  |  |  | 65,704 |  |
| Accrued compensation and benefits |  |  | 50,884 |  |  |  | 51,625 |  |
| Accrued warranty |  |  | 14,035 |  |  |  | 14,779 |  |
| Current portion, operating lease liability |  |  | 19,196 |  |  |  | — |  |
| Current portion, deferred revenue, net |  |  | 190,226 |  |  |  | 144,230 |  |
| Other accrued liabilities |  |  | 58,525 |  |  |  | 70,680 |  |
| Total current liabilities |  |  | 397,821 |  |  |  | 356,029 |  |
| Deferred revenue, less current portion |  |  | 100,961 |  |  |  | 59,012 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $7,165 and $1,261, respectively |  |  | 394,585 |  |  |  | 169,739 |  |
| Operating lease liability, less current portion |  |  | 50,238 |  |  |  | — |  |
| Deferred income taxes |  |  | 2,334 |  |  |  | 1,957 |  |
| Other long-term liabilities |  |  | 27,751 |  |  |  | 54,150 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000 shares authorized; 127,114 and 121,538 shares issued, respectively; 120,517 and 119,172 shares outstanding, respectively |  |  | 127 |  |  |  | 122 |  |
| Additional paid-in-capital |  |  | 1,035,041 |  |  |  | 986,772 |  |
| Accumulated other comprehensive loss |  |  | (6,378 | ) |  |  | (2,473 | ) |
| Accumulated deficit |  |  | (980,279 | ) |  |  | (853,434 | ) |
| Treasury stock at cost: 6,597 and 2,366 shares, respectively |  |  | (43,113 | ) |  |  | (15,000 | ) |
| Total stockholders’ equity |  |  | 5,398 |  |  |  | 115,987 |  |
| Total liabilities and stockholders’ equity |  | $ | 979,088 |  |  | $ | 756,874 |  |

[0001564590-20-036431:8k_2_02:71]
EXTREME NETWORKS, INC.

[0001564590-20-036431:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-036431:8k_2_02:73]
(In thousands, except per share amounts)

[0001564590-20-036431:8k_2_02:74]
(Unaudited)

[0001564590-20-036431:8k_2_02:75]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 141,478 |  |  | $ | 189,544 |  |  | $ | 653,651 |  |  | $ | 747,571 |  |
| Service |  |  | 74,044 |  |  |  | 62,815 |  |  |  | 294,368 |  |  |  | 248,218 |  |
| Total net revenues |  |  | 215,522 |  |  |  | 252,359 |  |  |  | 948,019 |  |  |  | 995,789 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 71,628 |  |  |  | 89,312 |  |  |  | 326,333 |  |  |  | 346,218 |  |
| Service |  |  | 23,304 |  |  |  | 24,101 |  |  |  | 103,847 |  |  |  | 98,336 |  |
| Total cost of revenues |  |  | 94,932 |  |  |  | 113,413 |  |  |  | 430,180 |  |  |  | 444,554 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 69,850 |  |  |  | 100,232 |  |  |  | 327,318 |  |  |  | 401,353 |  |
| Service |  |  | 50,740 |  |  |  | 38,714 |  |  |  | 190,521 |  |  |  | 149,882 |  |
| Total gross profit |  |  | 120,590 |  |  |  | 138,946 |  |  |  | 517,839 |  |  |  | 551,235 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 44,533 |  |  |  | 54,606 |  |  |  | 209,606 |  |  |  | 210,132 |  |
| Sales and marketing |  |  | 66,707 |  |  |  | 77,081 |  |  |  | 283,632 |  |  |  | 285,326 |  |
| General and administrative |  |  | 15,792 |  |  |  | 13,487 |  |  |  | 60,991 |  |  |  | 55,623 |  |
| Acquisition and integration costs |  |  | 1,998 |  |  |  | 831 |  |  |  | 32,073 |  |  |  | 3,444 |  |
| Restructuring charges, net of reversals and impairment |  |  | 2,604 |  |  |  | 3,808 |  |  |  | 22,011 |  |  |  | 5,090 |  |
| Amortization of intangibles |  |  | 2,059 |  |  |  | 1,338 |  |  |  | 8,425 |  |  |  | 6,346 |  |
| Total operating expenses |  |  | 133,693 |  |  |  | 151,151 |  |  |  | 616,738 |  |  |  | 565,961 |  |
| Operating loss |  |  | (13,103 | ) |  |  | (12,205 | ) |  |  | (98,899 | ) |  |  | (14,726 | ) |
| Interest income |  |  | 54 |  |  |  | 567 |  |  |  | 1,420 |  |  |  | 2,232 |  |
| Interest expense |  |  | (6,373 | ) |  |  | (3,009 | ) |  |  | (23,750 | ) |  |  | (12,597 | ) |
| Other income (expense), net |  |  | (391 | ) |  |  | (438 | ) |  |  | 737 |  |  |  | (783 | ) |
| Loss before income taxes |  |  | (19,813 | ) |  |  | (15,085 | ) |  |  | (120,492 | ) |  |  | (25,874 | ) |
| Provision (benefit) for income taxes |  |  | 1,404 |  |  |  | 1,970 |  |  |  | 6,353 |  |  |  | (21 | ) |
| Net loss |  | $ | (21,217 | ) |  | $ | (17,055 | ) |  | $ | (126,845 | ) |  | $ | (25,853 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic and diluted |  | $ | (0.18 | ) |  | $ | (0.14 | ) |  | $ | (1.06 | ) |  | $ | (0.22 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 120,314 |  |  |  | 118,961 |  |  |  | 119,814 |  |  |  | 117,954 |  |

[0001564590-20-036431:8k_2_02:76]
EXTREME NETWORKS, INC.

[0001564590-20-036431:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-036431:8k_2_02:78]
(In thousands) (Unaudited)

[0001564590-20-036431:8k_2_02:79]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (126,845 | ) |  | $ | (25,853 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 28,603 |  |  |  | 26,889 |  |
| Amortization of intangible assets |  |  | 35,218 |  |  |  | 25,984 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 16,420 |  |  |  | - |  |
| Provision for doubtful accounts |  |  | 1,289 |  |  |  | 1,407 |  |
| Share-based compensation |  |  | 37,842 |  |  |  | 32,897 |  |
| Deferred income taxes |  |  | 1,760 |  |  |  | (5,766 | ) |
| Non-cash restructuring and impairment charges |  |  | 7,622 |  |  |  | - |  |
| Unrealized/realized loss (gain) on equity investment |  |  | - |  |  |  | 508 |  |
| Non-cash interest expense |  |  | 4,196 |  |  |  | 3,022 |  |
| Other |  |  | (349 | ) |  |  | 54 |  |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 62,151 |  |  |  | 36,331 |  |
| Inventories |  |  | 19,951 |  |  |  | 278 |  |
| Prepaid expenses and other assets |  |  | 781 |  |  |  | (6,979 | ) |
| Accounts payable |  |  | (26,080 | ) |  |  | (9,850 | ) |
| Accrued compensation and benefits |  |  | (8,080 | ) |  |  | 1,274 |  |
| Operating lease liabilities |  |  | (17,345 | ) |  |  | - |  |
| Deferred revenue |  |  | 19,530 |  |  |  | 28,716 |  |
| Other current and long-term liabilities |  |  | (20,780 | ) |  |  | (3,967 | ) |
| Net cash provided by operating activities |  |  | 35,884 |  |  |  | 104,945 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (15,268 | ) |  |  | (22,730 | ) |
| Business acquisitions, net of cash acquired |  |  | (219,458 | ) |  |  | — |  |
| Maturities and sales of investments |  |  | 45,249 |  |  |  | 921 |  |
| Net cash used in investing activities |  |  | (189,477 | ) |  |  | (21,809 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Borrowings under Term Loan |  |  | 199,500 |  |  |  | — |  |
| Loan fees on borrowings |  |  | (12,029 | ) |  |  | (545 | ) |
| Repayments of debt |  |  | (34,517 | ) |  |  | (19,875 | ) |
| Repurchase of common stock |  |  | (30,000 | ) |  |  | (15,000 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 8,789 |  |  |  | 11,484 |  |
| Payment of contingent consideration obligations |  |  | (4,251 | ) |  |  | (6,506 | ) |
| Deferred payments on an acquisition |  |  | (4,000 | ) |  |  | (4,000 | ) |
| Net cash provided by (used in) financing activities |  |  | 178,492 |  |  |  | (34,442 | ) |
| Foreign currency effect on cash |  |  | (634 | ) |  |  | (226 | ) |
| Net increase in cash and cash equivalents |  |  | 24,265 |  |  |  | 48,468 |  |
| Cash and cash equivalents at beginning of period |  |  | 169,607 |  |  |  | 121,139 |  |
| Cash and cash equivalents at end of period |  | $ | 193,872 |  |  | $ | 169,607 |  |

[0001564590-20-036431:8k_2_02:80]
Extreme Networks, Inc.

[0001564590-20-036431:8k_2_02:81]
Non-GAAP Measures of Financial Performance

[0001564590-20-036431:8k_2_02:82]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating income, non-GAAP earnings per diluted share and free cash flow.

[0001564590-20-036431:8k_2_02:83]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, inventory valuation adjustments, loss on lease contracts, and certain income tax adjustments.

[0001564590-20-036431:8k_2_02:84]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-20-036431:8k_2_02:85]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-20-036431:8k_2_02:86]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, inventory valuation adjustments, restructuring charges, loss on lease contracts, and certain income tax adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-20-036431:8k_2_02:87]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-20-036431:8k_2_02:88]
Stock-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme Networks excludes stock-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001564590-20-036431:8k_2_02:89]
Acquired inventory adjustments. Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-20-036431:8k_2_02:90]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive in fiscal 2020 and the acquisition of the Campus Fabric and Data Center Businesses in fiscal 2018.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-20-036431:8k_2_02:91]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-20-036431:8k_2_02:92]
Inventory valuation adjustments. Adjustments relating to the mark down of inventory due to duplication of products lines with acquisition of Aerohive net of recoveries on the sale of inventory marked down in previous quarters.

[0001564590-20-036431:8k_2_02:93]
Restructuring charge. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-20-036431:8k_2_02:94]
Loss on lease contracts. The loss on lease contracts refers to leased facilities to which the Company has a contractual obligation but will not receive a future financial benefit.

[0001564590-20-036431:8k_2_02:95]
Income taxes. Income tax adjustment relates to a tax benefit resulting from changes introduced by tax reform related to US net operating losses allowing the release of US valuation allowance as well as a separate tax benefit resulting from the release of a foreign valuation allowance given anticipated future profitability.

[0001564590-20-036431:8k_2_02:96]
We do not reflect a tax effect associated with the non-GAAP operating adjustments as the adjustments are primarily related to the US entity which has a full valuation of various loss carryforward tax attributes.

[0001564590-20-036431:8k_2_02:97]
EXTREME NETWORKS, INC.

[0001564590-20-036431:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-036431:8k_2_02:99]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-20-036431:8k_2_02:100]
(In thousands, except percentages and per share amounts)

[0001564590-20-036431:8k_2_02:101]
(Unaudited)

[0001564590-20-036431:8k_2_02:102]
| Non-GAAP Revenues | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Revenues - GAAP Basis | $ | 215,522 |  |  | $ | 252,359 |  |  | $ | 948,019 |  |  | $ | 995,789 |  |
| Revenues - non-GAAP Basis | $ | 215,522 |  |  | $ | 252,359 |  |  | $ | 948,019 |  |  | $ | 995,789 |  |

[0001564590-20-036431:8k_2_02:103]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Gross profit - GAAP Basis | $ | 120,590 |  |  | $ | 138,946 |  |  | $ | 517,839 |  |  | $ | 551,235 |  |
| Gross margin - GAAP Basis percentage |  | 56.0 | % |  |  | 55.1 | % |  |  | 54.6 | % |  |  | 55.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 708 |  |  |  | 195 |  |  |  | 2,860 |  |  |  | 2,483 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Acquisition and integration costs |  | 98 |  |  |  | — |  |  |  | 2,169 |  |  |  | 1,752 |  |
| Amortization of intangibles |  | 6,633 |  |  |  | 4,809 |  |  |  | 26,430 |  |  |  | 19,222 |  |
| Inventory valuation adjustments |  | — |  |  |  | 5,334 |  |  |  | 3,677 |  |  |  | 5,334 |  |
| Total adjustments to GAAP gross profit | $ | 7,439 |  |  | $ | 10,338 |  |  | $ | 42,439 |  |  | $ | 28,791 |  |
| Gross profit - non-GAAP | $ | 128,029 |  |  | $ | 149,284 |  |  | $ | 560,278 |  |  | $ | 580,026 |  |
| Gross margin - non-GAAP percentage |  | 59.4 | % |  |  | 59.2 | % |  |  | 59.1 | % |  |  | 58.2 | % |

[0001564590-20-036431:8k_2_02:104]
| Non-GAAP Operating Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| GAAP operating loss | $ | (13,103 | ) |  | $ | (12,205 | ) |  | $ | (98,899 | ) |  | $ | (14,726 | ) |
| GAAP operating loss percentage |  | (6.1 | )% |  |  | (4.8 | )% |  |  | (10.4 | )% |  |  | (1.5 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense, cost of revenues |  | 708 |  |  |  | 195 |  |  |  | 2,860 |  |  |  | 2,483 |  |
| Stock based compensation expense, R&D |  | 2,111 |  |  |  | 2,490 |  |  |  | 10,324 |  |  |  | 10,443 |  |
| Stock based compensation expense, S&M |  | 3,346 |  |  |  | 3,218 |  |  |  | 11,914 |  |  |  | 11,747 |  |
| Stock based compensation expense, G&A |  | 4,742 |  |  |  | 2,655 |  |  |  | 12,265 |  |  |  | 8,224 |  |
| Inventory valuation adjustments |  | — |  |  |  | 5,334 |  |  |  | 3,677 |  |  |  | 5,334 |  |
| Acquisition and integration costs |  | 2,096 |  |  |  | 831 |  |  |  | 34,242 |  |  |  | 5,196 |  |
| Restructuring charges, net of reversals |  | 2,604 |  |  |  | 3,808 |  |  |  | 22,011 |  |  |  | 5,090 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Amortization of intangibles |  | 8,692 |  |  |  | 6,147 |  |  |  | 34,855 |  |  |  | 25,568 |  |
| Loss on lease contracts |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,288 |  |
| Total adjustments to GAAP operating loss | $ | 24,299 |  |  | $ | 24,678 |  |  | $ | 139,451 |  |  | $ | 75,373 |  |
| Non-GAAP operating income | $ | 11,196 |  |  | $ | 12,473 |  |  | $ | 40,552 |  |  | $ | 60,647 |  |
| Non-GAAP operating income percentage |  | 5.2 | % |  |  | 4.9 | % |  |  | 4.3 | % |  |  | 6.1 | % |

[0001564590-20-036431:8k_2_02:105]
| Non-GAAP Net Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| GAAP net loss | $ | (21,217 | ) |  | $ | (17,055 | ) |  | $ | (126,845 | ) |  | $ | (25,853 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 10,907 |  |  |  | 8,558 |  |  |  | 37,363 |  |  |  | 32,897 |  |
| Inventory valuation adjustments |  | — |  |  |  | 5,334 |  |  |  | 3,677 |  |  |  | 5,334 |  |
| Acquisition and integration costs |  | 2,096 |  |  |  | 831 |  |  |  | 34,242 |  |  |  | 5,196 |  |
| Restructuring charge, net of reversal |  | 2,604 |  |  |  | 3,808 |  |  |  | 22,011 |  |  |  | 5,090 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Amortization of intangibles |  | 8,692 |  |  |  | 6,147 |  |  |  | 34,855 |  |  |  | 25,568 |  |
| Loss on lease contracts |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,288 |  |
| Income tax |  | — |  |  |  | — |  |  |  | — |  |  |  | (7,770 | ) |
| Total adjustments to GAAP net loss | $ | 24,299 |  |  | $ | 24,678 |  |  | $ | 139,451 |  |  | $ | 67,603 |  |
| Non-GAAP net income | $ | 3,082 |  |  | $ | 7,623 |  |  | $ | 12,606 |  |  | $ | 41,750 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.03 |  |  | $ | 0.06 |  |  | $ | 0.10 |  |  | $ | 0.35 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 120,798 |  |  |  | 122,226 |  |  |  | 122,233 |  |  |  | 120,714 |  |
