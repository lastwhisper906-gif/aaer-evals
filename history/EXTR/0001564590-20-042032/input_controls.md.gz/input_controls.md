# EXTR 10-K controls and the auditor's report


## auditors_report

[0001564590-20-042032:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001564590-20-042032:auditors_report:2]
To the Stockholders and Board of Directors

[0001564590-20-042032:auditors_report:3]
Extreme Networks, Inc.:

[0001564590-20-042032:auditors_report:4]
Opinions on the Consolidated Financial Statements and Internal Control Over Financial Reporting

[0001564590-20-042032:auditors_report:5]
We have audited the accompanying consolidated balance sheets of Extreme Networks, Inc. and subsidiaries (the Company) as of June 30, 2020 and 2019, the related consolidated statements of operations, comprehensive loss, stockholders’ equity, and cash flows for each of the years in the three-year period ended June 30, 2020 and the related notes (collectively, the consolidated financial statements). We also have audited the Company’s internal control over financial reporting as of June 30, 2020, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001564590-20-042032:auditors_report:6]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of June 30, 2020 and 2019 and the results of its operations and its cash flows for each of the years in the three-year period ended June 30, 2020, in conformity with U.S. generally accepted accounting principles. Also, in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2020, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0001564590-20-042032:auditors_report:7]
The Company acquired Aerohive Networks, Inc. (Aerohive) during fiscal 2020, and management excluded from its assessment of the effectiveness of the Company’s internal control over financial reporting as of June 30, 2020, Aerohive’s internal control over financial reporting associated with 3% of total assets and 13% of total revenues included in the consolidated financial statements of the Company as of and for the year ended June 30, 2020.   Our audit of internal control over financial reporting of the Company also excluded an evaluation of the internal control over financial reporting of Aerohive.

[0001564590-20-042032:auditors_report:8]
Change in Accounting Principle

[0001564590-20-042032:auditors_report:9]
As discussed in Note 2 to the consolidated financial statements, the Company has changed its method of accounting for leases as of July 1, 2019 due to the adoption of Accounting Standards Update 2016-02, Leases, and several related amendments, as issued by the Financial Accounting Standards Board.

[0001564590-20-042032:auditors_report:10]
Basis for Opinions

[0001564590-20-042032:auditors_report:11]
The Company’s management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s consolidated financial statements and an opinion on the Company’s internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-20-042032:auditors_report:12]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001564590-20-042032:auditors_report:13]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001564590-20-042032:auditors_report:14]
Definition and Limitations of Internal Control Over Financial Reporting

[0001564590-20-042032:auditors_report:15]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in

[0001564590-20-042032:auditors_report:16]
accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001564590-20-042032:auditors_report:17]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-20-042032:auditors_report:18]
Critical Audit Matters

[0001564590-20-042032:auditors_report:19]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001564590-20-042032:auditors_report:20]
Assessment of effect of international tax realignment

[0001564590-20-042032:auditors_report:21]
As discussed in Note 16 to the consolidated financial statements, the Company continued the realignment of its international structure in the current year. Assets acquired in the acquisition of Aerohive Networks, Inc. were transferred amongst legal entities residing in different tax jurisdictions, resulting in changes to the income tax provision and related disclosures.

[0001564590-20-042032:auditors_report:22]
We identified the assessment of the effect of the international tax realignment as a critical audit matter. Due to the significance of the Company’s foreign operations subject to the realignment of its international structure, there was complexity in assessing the implications of the realignment on the income tax provision and related disclosures. Complex auditor judgment was required to evaluate the Company’s interpretation of applicable tax laws, regulations and the relevant topics of the accounting standards codification and their application to specific aspects of the Company’s realignment activities.

[0001564590-20-042032:auditors_report:23]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s income tax process, including controls related to the identification and assessment of the tax and accounting positions taken due to the realignment. Due to the complexity of tax law, which is often subject to interpretation, combined with the complexity of applying the accounting requirements, we involved tax professionals with specialized skills and knowledge, who assisted in evaluating:

[0001564590-20-042032:auditors_report:24]
|  | • | The Company’s interpretation and application of tax laws and regulations, |

[0001564590-20-042032:auditors_report:25]
|  | • | The Company’s application of relevant accounting guidance related to the accounting for income taxes, including the intra-entity transfer of assets, and business combinations, and |

[0001564590-20-042032:auditors_report:26]
|  | • | The Company’s compliance with the intercompany agreements which were executed as part of the realignment. |

[0001564590-20-042032:auditors_report:27]
Evaluation of the estimated market value of finished goods inventory.

[0001564590-20-042032:auditors_report:28]
As discussed in Note 2 to the consolidated financial statements, the Company assesses its finished goods inventory to identify excess or obsolete inventory and potential declines in its value. Finished goods inventory as of June 30, 2020 was $52.9 million.

[0001564590-20-042032:auditors_report:29]
We identified the evaluation of the estimated market value of finished goods inventory as a critical audit matter. There was a high degree of subjectivity in evaluating management’s assumptions used to evaluate whether they could sell certain inventory which has limited future product demand forecasted, due to the nature of the evidence available related to the expectation.

[0001564590-20-042032:auditors_report:30]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s process to assess excess or obsolete inventory. This included controls related to the determination of the estimated market value and the evaluation of management’s assumptions used to evaluate whether they could   sell certain inventory with limited future product demand forecasted. We challenged management’s expectation to sell certain inventory by evaluating the historical results of similar assumptions management has made and by assessing the reasonableness of management’s planned actions through independent corroboration. We performed an assessment of physical inventory disposals to determine whether inventory write-downs were taken in the correct period. We also performed inquiries with product line managers and examined product roadmaps to determine whether new product launches would contradict management’s assumption that they could sell inventory with limited future product demand.

[0001564590-20-042032:auditors_report:31]
Evaluation of the fair value of certain intangible assets acquired in the Aerohive Networks, Inc. business combination

[0001564590-20-042032:auditors_report:32]
As discussed in Note 4 to the consolidated financial statements, on August 9, 2019, the Company acquired Aerohive Networks, Inc. (“Aerohive”) for total consideration of $267 million. In connection with the acquisition, the Company recorded various intangible assets, which included developed technology and customer relationships with an acquisition-date fair value of $39.1 million and $11.4 million, respectively.

[0001564590-20-042032:auditors_report:33]
We identified the evaluation of the fair value of developed technology and customer relationships  acquired in the Aerohive transaction as a critical audit matter. There was a high degree of subjectivity in developing the key assumptions used to determine the acquisition-date fair value of these intangible assets.  Specifically, the discounted cash flow models included internally-developed assumptions for which there was limited observable market information. In addition, the fair value of these intangible asset was sensitive to possible changes to the following key assumptions:

[0001564590-20-042032:auditors_report:34]
Developed Technology:

[0001564590-20-042032:auditors_report:35]
|  | • | Forecasted revenues, including technology life |

[0001564590-20-042032:auditors_report:36]
|  | • | Forecasted cost of sales and operating expenses, including research and development maintenance rates |

[0001564590-20-042032:auditors_report:37]
Customer Relationships:

[0001564590-20-042032:auditors_report:38]
|  | • | Forecasted revenues and earnings before interest, and taxes (EBIT) margins |

[0001564590-20-042032:auditors_report:39]
|  | • | Estimated annual customer retention rate |

[0001564590-20-042032:auditors_report:40]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s acquisition-date valuation process to develop the key assumptions, as listed above. We evaluated the Company’s forecasted revenues, annual customer retention rate, and EBIT margins attributable to customer relationships by comparing to relevant support including, where applicable, (a) peer group and market participant data, (b) actual EBIT margins for technology distributors, (c) industry reports, and (d) historical actual Aerohive results.  We evaluated the forecasted revenues, technology life, costs of sales and operating expenses, and research and development maintenance rates attributable to developed technology by comparing to relevant support including, where applicable, (a)  peer group and market participant data, (b) industry reports and (c) historical actual Aerohive results.  In addition, we involved valuation professionals with specialized skills and knowledge, who assisted in:

[0001564590-20-042032:auditors_report:41]
|  | • | Evaluating the valuation methodologies used by the Company; |

[0001564590-20-042032:auditors_report:42]
|  | • | Evaluating the peer group and market participant data used in the assessment of assumptions noted above; and |

[0001564590-20-042032:auditors_report:43]
|  | • | Assessing the reasonableness of technology life and research and development maintenance rates based on the nature of the technology acquired. |

[0001564590-20-042032:auditors_report:44]
/s/KPMG LLP

[0001564590-20-042032:auditors_report:45]
We have served as the Company’s auditor since 2010.

[0001564590-20-042032:auditors_report:46]
Raleigh, North Carolina

[0001564590-20-042032:auditors_report:47]
August 31, 2020

[0001564590-20-042032:auditors_report:48]
EXTREME NETWORKS, INC.


## item_9a

[0001564590-20-042032:item_9a:1]
Item 9A. Controls and Procedures

[0001564590-20-042032:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-20-042032:item_9a:3]
Disclosure controls and procedures are controls and procedures designed to reasonably assure that information required to be disclosed in our reports filed under the Securities Exchange Act of 1934 as amended, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and to reasonably assure that such information is accumulated and communicated to our management, including the Chief Executive Officer (“CEO”) and the Chief Financial Officer (“CFO”), as appropriate to allow timely decisions regarding required disclosure.

[0001564590-20-042032:item_9a:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we evaluated the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO concluded that our disclosure controls and procedures were effective as of  June 30, 2020.

[0001564590-20-042032:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001564590-20-042032:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over our financial reporting. There are inherent limitations in the effectiveness of any system of internal control, including the possibility of human error and the circumvention or overriding of controls. Accordingly, even effective internal controls can provide only reasonable assurances with respect to financial statement preparation. Further because of changes in conditions, the effectiveness of internal control may vary over time.

[0001564590-20-042032:item_9a:7]
95

[0001564590-20-042032:item_9a:8]
EXTREME NETWORKS, INC.

[0001564590-20-042032:item_9a:9]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS—(Continued)

[0001564590-20-042032:item_9a:10]
We assessed the effectiveness of our internal control over financial reporting as of June 30, 2020.  In making this assessment, we used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in Internal Control-Integrated Framework (2013). Based on our assessment using those criteria, we concluded that, as of June 30, 2020, our internal control over financial reporting is effective.

[0001564590-20-042032:item_9a:11]
During the year ended June 30, 2020, we completed our acquisitions of Aerohive Networks, Inc. (“Aerohive”). In conducting our evaluation of the effectiveness of our internal controls over financial reporting as of June 30, 2020, we have elected to exclude the Aerohive business from our evaluation for fiscal 2020 as permitted under current Securities and Exchange Commission rules and regulations. As of and for the year ended June 30, 2020, the assets and revenues of the acquired businesses not included in our evaluation represented 3% of consolidated assets and 13% of consolidated revenues. We are currently in the process of integrating and assessing the internal controls over financial reporting of the acquired businesses with the rest of our Company. The integration may lead to changes in future periods, but we do not expect these changes to materially affect our internal controls over financial reporting. We expect to complete this integration in fiscal 2021.

[0001564590-20-042032:item_9a:12]
Our independent registered public accounting firm, KPMG LLP, has audited the financial statements included in this Annual Report on Form 10-K and has issued its report on our internal control over financial reporting as of June 30, 2020.

[0001564590-20-042032:item_9a:13]
Changes in Internal Control over Financial Reporting

[0001564590-20-042032:item_9a:14]
There were no changes in our internal control over financial reporting (as defined in Rules 13a – 15(f) and 15d – 15(f) under the Securities Exchange Act of 1934) during the fourth quarter of 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-20-042032:item_9a:15]
Inherent Limitations on Effectiveness of Controls

[0001564590-20-042032:item_9a:16]
Our management, including the CEO and CFO, does not expect that our disclosure controls or our internal control over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. Our controls and procedures are designed to provide reasonable assurance that our control system’s objective will be met, and our CEO and CFO have concluded that our disclosure controls and procedures are effective at the reasonable assurance level. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within Extreme have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events. Projections of any evaluation of the effectiveness of controls in future periods are subject to risks. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Notwithstanding these limitations, our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives. Our CEO and CFO have concluded that our disclosure controls and procedures are, in fact, effective at the “reasonable assurance” level.
