# EXTR MD&A — 0001564590-20-042032


## mdna

[0001564590-20-042032:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-20-042032:mdna:2]
Business Overview

[0001564590-20-042032:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Part II, Item 8 of this Report.

[0001564590-20-042032:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles, or U.S. GAAP.  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-20-042032:mdna:5]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leading provider of networking software, hardware and services and offers related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California.  We derive substantially all of our revenues from the sale of our networking software, hardware and services, and related maintenance contracts.

[0001564590-20-042032:mdna:6]
Extreme is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from enterprise edge to the cloud, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. Extreme gives customers and partners the power to mix and match this broad array of software, hardware, and services (including third-party applications) to tailor a solution that can be managed and automated from end-to-end and calls this customizable portfolio Extreme ElementsTM.

[0001564590-20-042032:mdna:7]
Enterprise network administrators need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security.  Accelerators such as Internet of Things (“IoT”), artificial intelligence (“AI”), bring your own device (“BYOD”), machine learning, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-20-042032:mdna:8]
A trend affecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud, and third-party, public cloud services with orchestration between the two platforms. We introduced our Cloud offering in 2016 and in August 2019 acquired Aerohive Networks, Inc to enhance our Cloud strategy with a 3rd generation Cloud platform and to accelerate adoption of hybrid cloud networking solutions in the Enterprise. Extreme’s enhanced Cloud solution will be the only offering in the market that seamlessly integrates the cloud with on-premises infrastructures and enables visibility from the edge to everywhere. See Part 1, Item 1. Business, for additional discussion of our business.

[0001564590-20-042032:mdna:9]
Acquisition

[0001564590-20-042032:mdna:10]
Aerohive Networks, Inc

[0001564590-20-042032:mdna:11]
On August 9, 2019 (the “Closing Date”) the Company completed its acquisition of Aerohive, a publicly held network company, for $263.6 million in cash consideration and assumption of certain employee equity awards.

[0001564590-20-042032:mdna:12]
The business combination was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive are recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of Aerohive are included in our operations beginning with the Closing Date.

[0001564590-20-042032:mdna:13]
During the fiscal year ended June 30, 2020 and 2019, the Company recognized related transaction costs of $32.1 million and $0.8 million, respectively, which is included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0001564590-20-042032:mdna:14]
Results of Operations

[0001564590-20-042032:mdna:15]
Following is a summary of our results of operations during fiscal year ended June 30, 2020:

[0001564590-20-042032:mdna:16]
|  | • | Net revenues of $948.0 million, decreased 4.8% from fiscal 2019 net revenues of $995.8 million. |

[0001564590-20-042032:mdna:17]
|  | • | Product revenues of $653.7 million, decreased 12.6% from fiscal 2019 product revenues of $747.6 million. |

[0001564590-20-042032:mdna:18]
|  | • | Service revenues of $294.4 million, increased 18.6% from fiscal 2019 service revenues of $248.2 million. |

[0001564590-20-042032:mdna:19]
|  | • | Total gross margin of 54.6% of net revenues in fiscal 2020, compared to 55.4% in fiscal 2019. |

[0001564590-20-042032:mdna:20]
|  | • | Operating loss of $98.9 million, compared to operating loss of $14.7 million in fiscal 2019. |

[0001564590-20-042032:mdna:21]
|  | • | Net loss was $126.8 million in fiscal 2020, compared to a net loss of $25.9 million in fiscal 2019. |

[0001564590-20-042032:mdna:22]
|  | • | Cash flow provided by operating activities of $35.9 million, compared to cash flow provided by operating activities of $104.9 million in fiscal 2019, a decrease of $69.1 million. Cash was $193.9 million as of June 30, 2020, an increase of $24.3 million compared to the end of fiscal 2019. |

[0001564590-20-042032:mdna:23]
Recent Events

[0001564590-20-042032:mdna:24]
In January 2020, an outbreak of a new strain of coronavirus, COVID-19, was identified in Wuhan, China. Through the first quarter of 2020, the disease became widespread around the world, and on March 11, 2020, the World Health Organization declared a pandemic. The Coronavirus outbreak has had and we expect will continue to have an adverse effect on our results of operations due to supply chain disruptions and weakened demand for our products. For example, we recently realigned our operations and recorded severance and benefits charges under our 2020 restructuring plan of $8.1 million for the year ended June 30, 2020. Although we expect to reduce research and development and sales and marketing costs during our fiscal year 2021, given the uncertainty around the extent and timing of the potential future spread or mitigation of the Coronavirus and around the imposition or relaxation of protective measures, we cannot further reasonably estimate the impact of the COVID-19 pandemic on our future results of operations or financial position. See also Part I, Item 1A – Risk Factors.

[0001564590-20-042032:mdna:25]
Net Revenues

[0001564590-20-042032:mdna:26]
The following table presents net product and service revenues for the fiscal year ended June 30, 2020, 2019 and 2018 (dollars in thousands):

[0001564590-20-042032:mdna:27]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | $ Change |  |  | % Change |  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 653,651 |  |  | $ | 747,571 |  |  | $ | (93,920 | ) |  |  | (12.6 | )% |  | $ | 747,571 |  |  | $ | 764,455 |  |  | $ | (16,884 | ) |  |  | (2.2 | )% |
| Percentage of net revenues |  |  | 68.9 | % |  |  | 75.1 | % |  |  |  |  |  |  |  |  |  |  | 75.1 | % |  |  | 77.8 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 294,368 |  |  |  | 248,218 |  |  |  | 46,150 |  |  |  | 18.6 | % |  |  | 248,218 |  |  |  | 218,687 |  |  |  | 29,531 |  |  |  | 13.5 | % |
| Percentage of net revenues |  |  | 31.1 | % |  |  | 24.9 | % |  |  |  |  |  |  |  |  |  |  | 24.9 | % |  |  | 22.2 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 948,019 |  |  | $ | 995,789 |  |  | $ | (47,770 | ) |  |  | (4.8 | )% |  | $ | 995,789 |  |  | $ | 983,142 |  |  | $ | 12,647 |  |  |  | 1.3 | % |

[0001564590-20-042032:mdna:28]
Product revenues decreased $93.9 million or 12.6% for the year ended June 30, 2020, compared to the corresponding period of fiscal 2019. Product revenues were impacted in the second half of fiscal 2020 by a material slow-down in global demand as most of Extreme's largest end markets enacted quarantine and social distancing protocols. Supply constraints, along with additional logistics related challenges in certain countries due to border closures, also contributed to the shortfall. The decline in such revenues was partially offset by growth relating to the acquisition of Aerohive.

[0001564590-20-042032:mdna:29]
Product revenues decreased $16.9 million or 2.2% for the year ended June 30, 2019, compared to the corresponding period of fiscal 2018. The decrease in product revenues were driven primarily by a lower overall volume of sales in the Americas attributed to our Data Center Business, but with strengthening sales in our Federal and OEM Data Center sectors. To a lesser extent, there was a modest decrease in product revenues in APAC, and revenues remained consistent in the EMEA region.

[0001564590-20-042032:mdna:30]
Service revenues increased $46.2 million or 18.6% for the year ended June 30, 2020, compared to the corresponding period of fiscal 2019. The increase in service revenues was primarily attributable to growth related to the acquisition of Aerohive.

[0001564590-20-042032:mdna:31]
Service revenues increased $29.5 million or 13.5% for the year ended June 30, 2019, compared to the corresponding period of fiscal 2018. The increase in service revenues was driven primarily by growth across all regions owing to a higher number of maintenance contracts related to the Data Center Business acquisition.

[0001564590-20-042032:mdna:32]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenues geographically for the fiscal years ended 2020, 2019 and 2018 (dollars in thousands):

[0001564590-20-042032:mdna:33]
|  |  | Year Ended |  |  | Year Ended |  |
| Net Revenues |  | June 30, 2020 |  |  | June 30, 2019 |  |  | $ Change |  |  | % Change |  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 459,769 |  |  | $ | 498,705 |  |  | $ | (38,936 | ) |  |  | (7.8 | )% |  | $ | 498,705 |  |  | $ | 491,617 |  |  | $ | 7,088 |  |  |  | 1.4 | % |
| Other |  |  | 39,633 |  |  |  | 42,896 |  |  |  | (3,263 | ) |  |  | (7.6 | )% |  |  | 42,896 |  |  |  | 44,688 |  |  |  | (1,792 | ) |  |  | (4.0 | )% |
| Total Americas |  |  | 499,402 |  |  |  | 541,601 |  |  |  | (42,199 | ) |  |  | (7.8 | )% |  |  | 541,601 |  |  |  | 536,305 |  |  |  | 5,296 |  |  |  | 1.0 | % |
| Percentage of net revenues |  |  | 52.7 | % |  |  | 54.4 | % |  |  |  |  |  |  |  |  |  |  | 54.4 | % |  |  | 54.6 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 357,201 |  |  |  | 358,327 |  |  |  | (1,126 | ) |  |  | (0.3 | )% |  |  | 358,327 |  |  |  | 354,746 |  |  |  | 3,581 |  |  |  | 1.0 | % |
| Percentage of net revenues |  |  | 37.7 | % |  |  | 36.0 | % |  |  |  |  |  |  |  |  |  |  | 36.0 | % |  |  | 36.1 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 91,416 |  |  |  | 95,861 |  |  |  | (4,445 | ) |  |  | (4.6 | )% |  |  | 95,861 |  |  |  | 92,091 |  |  |  | 3,770 |  |  |  | 4.1 | % |
| Percentage of net revenues |  |  | 9.6 | % |  |  | 9.6 | % |  |  |  |  |  |  |  |  |  |  | 9.6 | % |  |  | 9.4 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 948,019 |  |  | $ | 995,789 |  |  | $ | (47,770 | ) |  |  | (4.8 | )% |  | $ | 995,789 |  |  | $ | 983,142 |  |  | $ | 12,647 |  |  |  | 1.3 | % |

[0001564590-20-042032:mdna:34]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEMs and direct sales.  Revenues through our distributor channel were 73% of total product revenues in fiscal 2020, 70% of total product revenues in fiscal 2019 and 69% in fiscal 2018.

[0001564590-20-042032:mdna:35]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001564590-20-042032:mdna:36]
Cost of Revenues and Gross Profit

[0001564590-20-042032:mdna:37]
The following table presents the gross profit on product and service revenues and the gross profit percentage of net revenues for the fiscal years ended 2020, 2019 and 2018 (dollars in thousands):

[0001564590-20-042032:mdna:38]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | $ Change |  |  | % Change |  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 327,318 |  |  | $ | 401,353 |  |  | $ | (74,035 | ) |  |  | (18.4 | )% |  | $ | 401,353 |  |  | $ | 407,393 |  |  | $ | (6,040 | ) |  |  | (1.5 | )% |
| Percentage of product revenues |  |  | 50.1 | % |  |  | 53.7 | % |  |  |  |  |  |  |  |  |  |  | 53.7 | % |  |  | 53.3 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 190,521 |  |  |  | 149,882 |  |  |  | 40,639 |  |  |  | 27.1 | % |  |  | 149,882 |  |  |  | 127,124 |  |  |  | 22,758 |  |  |  | 17.9 | % |
| Percentage of service revenues |  |  | 64.7 | % |  |  | 60.4 | % |  |  |  |  |  |  |  |  |  |  | 60.4 | % |  |  | 58.1 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 517,839 |  |  | $ | 551,235 |  |  | $ | (33,396 | ) |  |  | (6.1 | )% |  | $ | 551,235 |  |  | $ | 534,517 |  |  | $ | 16,718 |  |  |  | 3.1 | % |
| Percentage of net revenues |  |  | 54.6 | % |  |  | 55.4 | % |  |  |  |  |  |  |  |  |  |  | 55.4 | % |  |  | 54.4 | % |  |  |  |  |  |  |  |  |

[0001564590-20-042032:mdna:39]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing, engineering and document control at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001564590-20-042032:mdna:40]
Product gross profit decreased to $327.3 million for the year ended June 30, 2020, from $401.4 million in the corresponding period of fiscal 2019, primarily due to lower product revenues, the expensing of the fair value step-up of inventories acquired from Aerohive of $7.2 million, higher distribution charges of $5.6 million, higher amortization of intangible assets of $4.2 million and higher excess and obsolete inventory charges of $3.3 million.  This was partially offset by more favorable manufacturing costs due to cost reduction efforts, lower warranty costs of $3.2 million and lower royalty payments of $1.2 million.

[0001564590-20-042032:mdna:41]
Product gross profit decreased to $401.4 million for the year ended June 30, 2019, from $407.4 million in the corresponding period of fiscal 2018, primarily due to lower product revenues, higher distribution costs of $10.9 million, higher warranty charges of $8.2 million, amortization of developed technology intangibles due to the acquisition of the Data Center Business of $2.8 million and additional operations costs of $4.7 million mainly driven by higher personnel costs due to additional headcount. These increases were partially offset by lower product costs due to cost reduction efforts as well as decreased integration costs from acquisitions of $9.5 million.

[0001564590-20-042032:mdna:42]
Our cost of service revenues consist primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts.

[0001564590-20-042032:mdna:43]
Service gross profit increased to $190.5 million for the year ended June 30, 2020, from $149.9 million in the corresponding period of fiscal 2019, primarily due to a higher level of service revenues related to the acquisition of the Aerohive, partially offset by higher service material costs and personnel costs due to increased headcount to support acquired contracts as well as higher amortization of intangible assets of $3.0 million for the fiscal year ended June 30, 2020.

[0001564590-20-042032:mdna:44]
Service gross profit increased to $149.9 million for the year ended June 30, 2019, from $127.1 million in the corresponding period of fiscal 2018, primarily due to the acquisition of the Data Center Business as a result of a higher number of maintenance contracts.

[0001564590-20-042032:mdna:45]
Operating Expenses

[0001564590-20-042032:mdna:46]
The following table presents operating expenses and operating income (dollars in thousands):

[0001564590-20-042032:mdna:47]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | $ Change |  |  | % Change |  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 209,606 |  |  | $ | 210,132 |  |  | $ | (526 | ) |  |  | (0.3 | )% |  | $ | 210,132 |  |  | $ | 183,877 |  |  | $ | 26,255 |  |  |  | 14.3 | % |
| Sales and marketing |  |  | 283,632 |  |  |  | 285,326 |  |  |  | (1,694 | ) |  |  | (0.6 | )% |  |  | 285,326 |  |  |  | 267,107 |  |  |  | 18,219 |  |  |  | 6.8 | % |
| General and administrative |  |  | 60,991 |  |  |  | 55,623 |  |  |  | 5,368 |  |  |  | 9.7 | % |  |  | 55,623 |  |  |  | 50,988 |  |  |  | 4,635 |  |  |  | 9.1 | % |
| Acquisition and integration costs |  |  | 32,073 |  |  |  | 3,444 |  |  |  | 28,629 |  |  |  | 831.3 | % |  |  | 3,444 |  |  |  | 53,900 |  |  |  | (50,456 | ) |  |  | (93.6 | )% |
| Restructuring charges, net of reversals and impairment |  |  | 22,011 |  |  |  | 5,090 |  |  |  | 16,921 |  |  |  | 332.4 | % |  |  | 5,090 |  |  |  | 8,140 |  |  |  | (3,050 | ) |  |  | (37.5 | )% |
| Amortization of intangibles |  |  | 8,425 |  |  |  | 6,346 |  |  |  | 2,079 |  |  |  | 32.8 | % |  |  | 6,346 |  |  |  | 8,715 |  |  |  | (2,369 | ) |  |  | (27.2 | )% |
| Total operating expenses |  | $ | 616,738 |  |  | $ | 565,961 |  |  | $ | 50,777 |  |  |  | 9.0 | % |  | $ | 565,961 |  |  | $ | 572,727 |  |  | $ | (6,766 | ) |  |  | (1.2 | )% |

[0001564590-20-042032:mdna:48]
The following table highlights our operating expenses and operating loss as a percentage of net revenues:

[0001564590-20-042032:mdna:49]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Research and development |  |  | 22.1 | % |  |  | 21.1 | % |  |  | 18.7 | % |
| Sales and marketing |  |  | 29.9 | % |  |  | 28.7 | % |  |  | 27.2 | % |
| General and administrative |  |  | 6.4 | % |  |  | 5.6 | % |  |  | 5.2 | % |
| Acquisition and integration costs |  |  | 3.4 | % |  |  | 0.3 | % |  |  | 5.5 | % |
| Restructuring charges, net of reversals and impairment |  |  | 2.3 | % |  |  | 0.5 | % |  |  | 0.8 | % |
| Amortization of intangibles |  |  | 0.9 | % |  |  | 0.6 | % |  |  | 0.9 | % |
| Total operating expenses |  |  | 65.1 | % |  |  | 56.8 | % |  |  | 58.3 | % |
| Operating loss |  |  | (10.4 | )% |  |  | (1.5 | )% |  |  | (3.9 | )% |

[0001564590-20-042032:mdna:50]
Research and Development Expenses

[0001564590-20-042032:mdna:51]
Research and development expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-20-042032:mdna:52]
Research and development expenses remained relatively flat for year ended June 30, 2020 as compared to fiscal 2019. There was a $2.2 million decrease in personnel and related compensation costs, $1.0 million decrease in equipment related costs, and $1.0 million decrease in travel, supplies and facility and information technology costs, offset by a $4.0 million increase in engineering projects costs.

[0001564590-20-042032:mdna:53]
Research and development expenses increased by $26.3 million or 14.3% for fiscal 2019 as compared to fiscal 2018. The increase in research and development expenses during fiscal 2019 was due to $13.4 million related to third-party design and engineering collaboration charges, a $10.8 million increase in personnel costs, $5.5 million in increased facility and information technology costs and $0.9 million in increased supplies and equipment costs offset by a $3.3 million decrease in contract labor and a $1.0 million decrease in travel, recruiting and other costs.

[0001564590-20-042032:mdna:54]
Sales and Marketing Expenses

[0001564590-20-042032:mdna:55]
Sales and marketing expenses consist of personnel costs (which consists of compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001564590-20-042032:mdna:56]
Sales and marketing expenses decreased by $1.7 million or 0.6% for the year ended June 30, 2020, as compared to the corresponding period of fiscal 2019. The decrease was primarily due to a $8.6 million decrease in travel, marketing, meeting and conference costs partially offset by a $3.0 million increase in personnel and related costs, a $2.1 increase in software, supplies and equipment costs, and a $1.8 million increase in facility and information technology costs.

[0001564590-20-042032:mdna:57]
42

[0001564590-20-042032:mdna:58]
Sales and marketing expenses increased by $18.2 million or 6.8% for the year ended June 30, 2019, as compared to the corresponding period of fiscal 2018. The increase in sales and marketing expenses during fiscal 2019 consisted of higher personnel costs of $15.2 million, $2.5 million in increased software, supplies and equipment costs, $1.1 million in increased travel, marketing, meeting and conference costs offset by a $0.6 million decrease in facility and information technology costs.

[0001564590-20-042032:mdna:59]
General and Administrative Expenses

[0001564590-20-042032:mdna:60]
General and administrative expense consists primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001564590-20-042032:mdna:61]
General and administrative expenses increased by $5.4 million or 9.7% for the year ended June 30, 2020, as compared to the corresponding period of fiscal 2019.  The increase in general and administrative expenses during fiscal 2020 was primarily due to a $5.4 million increase in personnel and related costs.

[0001564590-20-042032:mdna:62]
General and administrative expenses increased by $4.6 million or 9.1% for the year ended June 30, 2019, as compared to the corresponding period of fiscal 2018.  The increase in general and administrative expenses during fiscal 2019 was primarily due to $2.4 million in higher personnel costs, $1.3 million in higher facility and information technology costs, a $1.3 million increase in lease termination costs and a $0.6 million increase in supplier contract termination costs partially offset by a $1.0 million reduction in travel, professional fees and other costs.

[0001564590-20-042032:mdna:63]
Acquisition and Integration Costs, Net of Bargain Purchase Gain

[0001564590-20-042032:mdna:64]
As a result of our acquisitions of Aerohive in fiscal 2020 and the Campus Fabric, Data Center, and Capital Financing Businesses in fiscal 2018, we incurred $32.1 million, $3.4 million and $53.9 million of acquisition and integration costs, net of bargain purchase gain in fiscal years ended 2020, 2019 and 2018, respectively.

[0001564590-20-042032:mdna:65]
For fiscal 2020, we incurred $32.1 million of operating integration costs related to the Aerohive acquisition which consisted primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees. The acquisition and integration costs also included a $6.8 million compensation charge for certain Aerohive executives’ stock awards that were accelerated due to change-in-control and termination provisions included in the executives’ employment contracts.

[0001564590-20-042032:mdna:66]
For fiscal 2019, we incurred $3.4 million of operating integration costs related to the acquisitions of the Campus Fabric and Data Center Businesses along with initial acquisition costs related to the Aerohive acquisition.

[0001564590-20-042032:mdna:67]
For fiscal 2018, we incurred $12.4 million of acquisition and $6.3 million of integration costs related to the acquisition of the Campus Fabric Business and $36.0 million of acquisition and $4.2 million of integration costs related to the acquisition of the Data Center Business. The Data Center Business acquisition costs includes a $25.0 million consent fee paid to Broadcom, to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade. We also recorded a gain on bargain purchase of $5.0 million related to the acquisition of the Capital Financing Business.

[0001564590-20-042032:mdna:68]
Restructuring, impairment, and Related Charges, Net of Reversals

[0001564590-20-042032:mdna:69]
During fiscal years ended 2020, 2019 and 2018, we recorded restructuring, impairment, and related charges, net of reversals, of $22.0 million, $5.1 million and $8.1 million, respectively.

[0001564590-20-042032:mdna:70]
Fiscal year ended 2020

[0001564590-20-042032:mdna:71]
During fiscal 2020, we reduced our current and future operating expenses by exiting a floor of a building in our San Jose, California headquarters facility and consolidating our workforce.  Also, we exited additional space in our Salem, New Hampshire facility, which includes general office and lab space. We continued our initiative to realign our operations resulting from the acquisition of Aerohive by consolidating our workforce and exiting the facility acquired from Aerohive in Milpitas, California which includes general office and lab space.

[0001564590-20-042032:mdna:72]
With the global disruptions and slow-down in the demand of our products caused by the global pandemic outbreak, COVID-19, and the uncertainty around the timing of the recovery of the market, we initiated a reduction-in-force plan (the 2020 Plan) to reduce our operating costs and enhance financial flexibility. The plan affected approximately 320 employees primarily from the research and development and sales organizations who were located mainly in the United States and India. We recorded restructuring charges of $8.1 million during the fiscal year ended June 30, 2020 related to the 2020 Plan. The costs associated with this restructuring plan primarily included employee severance and benefit expenses. We recorded additional severance and benefits charges of $5.4 million for the fiscal year ended June 30, 2020 related to the prior period restructuring plans. In total we incurred $13.5 million in restructuring charges for the year ended June 30, 2020 which were all severance and benefit related. In addition, we recorded facility impairment related charges of $8.5 million for the fiscal year ended June 30, 2020 which included $6.7 million for the impairment of ROU assets as discussed in the preceding paragraph, $0.9 million for impairment of long-lived assets, and $0.9 million of other charges related to previously impaired facilities. We expect to incur additional charges related to this 2020 Plan through the first

[0001564590-20-042032:mdna:73]
quarter of fiscal 2021. The amount and timing of the actual charges are uncertain due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.

[0001564590-20-042032:mdna:74]
Fiscal year ended 2019

[0001564590-20-042032:mdna:75]
On June 25, 2019, we began executing a reduction-in-force plan (the 2019 Plan) to better align our work force and operating expenses. We recorded $3.7 million related to employee severance and benefits expenses during the year ended June 30, 2019 under the 2019 plan. We also incurred $1.1 million in additional charges related to continuation of earlier actions associated with a reduction-in-force in the fourth quarter of fiscal 2018. We also incurred charges of $0.3 million for changes to estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of excess facilities.

[0001564590-20-042032:mdna:76]
Costs associated with the 2019 Plan are primarily comprised of employee severance and benefits expenses, relocation of personnel and equipment and exit of excess facilities.

[0001564590-20-042032:mdna:77]
Fiscal year ended 2018

[0001564590-20-042032:mdna:78]
During fiscal 2018, we announced and began executing a reduction-in-force in our third and fourth fiscal quarters as a result of the acquisitions of the Campus Fabric and the Data Center Businesses. We recorded restructuring charges of $7.9 million related to employee severance and benefits expenses during fiscal 2018. We also incurred charges of $0.2 million for changes to our estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of our excess facilities.

[0001564590-20-042032:mdna:79]
Amortization of Intangibles

[0001564590-20-042032:mdna:80]
During fiscal years ended 2020, 2019 and 2018, we recorded $8.4 million, $6.3 million and $8.7 million, respectively, of amortization expenses in operating expenses primarily for certain intangibles related to the acquisitions of the Aerohive, Campus Fabric, Data Center and WLAN Businesses and Enterasys. The increase in amortization expense in fiscal 2020 from fiscal 2019 was primarily due to amortization of acquired intangibles from the Aerohive acquisition, partially offset by lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized. The decrease in amortization expense in fiscal 2019 from fiscal 2018 was mainly due to the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-20-042032:mdna:81]
Interest Income

[0001564590-20-042032:mdna:82]
Interest income was $1.4 million, $2.2 million and $2.8 million in fiscal years ended 2020, 2019 and 2018, respectively, representing a decrease of $0.8 million in fiscal 2020 from fiscal 2019 and a decrease of $0.6 million in fiscal 2019 from fiscal 2018. The decrease in fiscal 2020 was due to lower invested funds balances. The decrease in fiscal 2019 was due to a $1.6 million decrease in interest income from a long-term note receivable, offset by higher invested funds balances.

[0001564590-20-042032:mdna:83]
Interest Expense

[0001564590-20-042032:mdna:84]
We incurred $23.8 million, $12.6 million, and $13.9 million of interest expense for fiscal 2020, 2019 and 2018, respectively. The increase in interest expense in fiscal year ended June 30, 2020 was primarily driven by higher outstanding loan balances and other charges due to refinancing our 2018 Credit Agreement in August 2019 in connection with our acquisition of Aerohive. The decrease in interest expense in fiscal year ended June 30, 2019 was primarily due to lower imputed interest charges associated with various long-term contracts.

[0001564590-20-042032:mdna:85]
Other Income (Expense), net

[0001564590-20-042032:mdna:86]
We incurred other income of $0.7 million and $2.6 million in fiscal years ended 2020 and 2018, respectively, and other expense of $0.8 million in fiscal 2019. The other income for fiscal 2020 was primarily foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars. The other expense for fiscal 2019 was primarily losses on the sale of equity investments. The other income for fiscal 2018 was primarily driven by a gain of $4.0 million due to the sale of equity investments, partially offset by foreign exchange losses.

[0001564590-20-042032:mdna:87]
Provision (Benefit) for Income Taxes

[0001564590-20-042032:mdna:88]
We are subject to income taxes in the United States and numerous foreign jurisdictions.  Our effective tax rate differs from the U.S. federal statutory rate of 21% primarily due to the impact of i) foreign income taxes of our international subsidiaries, ii) foreign withholding taxes, iii) state taxes, and iii) the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions. For the fiscal years ended 2020 and 2018, we recorded income tax provisions of $6.4 million, and $0.1 million, respectively, and in fiscal 2019 we reflected a tax benefit of less than $0.1 million.

[0001564590-20-042032:mdna:89]
For fiscal 2020, our tax provision primarily related to taxes on our foreign operations, including foreign withholding taxes remitted to foreign tax authorities by customers on our behalf, tax expense related to the establishment of a U.S. deferred tax liability for amortizable goodwill and state taxes in states where we have exhausted available Net Operating Losses (“NOLs”) or are subject to certain franchise taxes qualifying as income tax under the relevant tax accounting guidance. In fiscal 2020 we recognized a $75 million dollar U.S. tax gain on the transfer of non-American Aerohive intellectual property (“IP”) rights which was fully offset by existing U.S. NOLs.  Given the full U.S. valuation allowance against our U.S. deferred tax assets, this transaction did not impact net tax expense or the overall tax rate.

[0001564590-20-042032:mdna:90]
For fiscal 2019, we recorded a tax benefit, offsetting the tax components detailed above, consisting of a $2.6 million release of a valuation allowance for our Australian NOL carryforwards given sufficient projected profitability for the subsidiary following the acquisitions of the Campus Fabric and Data Center businesses.  Additionally, a tax benefit of $4.7 million was recorded for the release of U.S. valuation allowances given changes introduced by the U.S. Tax Reform Act enacted in December 2017 which allows for an indefinite carryforward period for U.S. NOLs generated in tax years beginning after December 31, 2017.

[0001564590-20-042032:mdna:91]
For fiscal 2018, we recorded a net tax provision for the components detailed above, largely offset by tax benefits  resulting from application of U.S. Tax Reform and restructuring of our foreign operations. This tax benefit consisted of $3.1 million release of U.S. valuation allowance resulting from the reduction of the U.S. Federal tax rate from 35% to 21% pursuant to U.S. Tax Reform as applied to our deferred tax liability related to amortizable goodwill,  a tax benefit resulting from the impairment of a lease acquired from Avaya in Canada and a tax benefit resulting from the restructuring of our foreign operations of $3.4 million.

[0001564590-20-042032:mdna:92]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 16. Income Taxes, for additional information.

[0001564590-20-042032:mdna:93]
Critical Accounting Policies and Estimates

[0001564590-20-042032:mdna:94]
Our significant accounting policies are more fully described in Note 2 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001564590-20-042032:mdna:95]
Revenue Recognition

[0001564590-20-042032:mdna:96]
We account for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which we adopted on July 1, 2017, using the retrospective method.  We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from SAAS and service fees relating to maintenance contracts, professional services, and training for our products. We sell our products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-20-042032:mdna:97]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, we consider the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0001564590-20-042032:mdna:98]
For all of our sales including distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when our performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts and SaaS is generally recognized over time as our performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to our value-added resellers, non-stocking distributors and end-user customers, we generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits.  Sales incentives and other programs that we may make available to these customers are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the expected value method.

[0001564590-20-042032:mdna:99]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of our products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are estimated using the expected value method based on historical return rates.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices our customer or soon thereafter, the distributor submits a rebate claim to us to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After we verify that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, we consider these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends.

[0001564590-20-042032:mdna:100]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which we separately sell these products.  For items that are not sold separately, we estimate the stand-alone selling prices using the best estimated selling price approach.

[0001564590-20-042032:mdna:101]
Our performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of our product sales revenues as reflected on the consolidated statements of operations for the years ended 2020, 2019 and 2018 are recognized at a point in time. Substantially all of our service revenues are recognized over time.  For revenues recognized over time, we use an input measure, days elapsed, to measure progress.

[0001564590-20-042032:mdna:102]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under our renewable support arrangements are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually).  We sometimes receive payments from our customers in advance of services being provided, resulting in deferred revenue.  These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-20-042032:mdna:103]
Business Combinations

[0001564590-20-042032:mdna:104]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price).  Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized in the statements of operations. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-20-042032:mdna:105]
Inventory Valuation and Purchase Commitments

[0001564590-20-042032:mdna:106]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0001564590-20-042032:mdna:107]
New Accounting Pronouncements

[0001564590-20-042032:mdna:108]
See Note 2, Summary of Significant Accounting Policies, in the accompanying consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-20-042032:mdna:109]
Liquidity and Capital Resources

[0001564590-20-042032:mdna:110]
The following summarizes information regarding our cash and working capital (in thousands):

[0001564590-20-042032:mdna:111]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Cash |  | $ | 193,872 |  |  | $ | 169,607 |  |
| Working capital |  | $ | 16,386 |  |  | $ | 85,960 |  |

[0001564590-20-042032:mdna:112]
As of June 30, 2020, our principal sources of liquidity consisted of cash of $193.9 million and accounts receivable, net of $122.7 million.  We anticipate that our principal uses of cash for fiscal 2021 will be purchases of finished goods inventory from our contract manufacturers, payroll, payments under debt obligations and related interest, purchases of property and equipment, and other operating expenses related to the development and marketing of our products.  We believe that our existing cash and cash flows from operations will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-20-042032:mdna:113]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of our shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in the second quarter of fiscal 2019.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions and stock price. The repurchase program does not obligate us to acquire any shares of our common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. In November 2019, we entered into an accelerated share repurchase agreement (the “November 2019 ASR”) to repurchase shares of our common stock.  Pursuant to the November 2019 ASR, the Company paid $30.0 million for an initial delivery of 3,850,000 shares valued at $25.2 million. The remaining balance of $4.8 million was recorded as a forward contract in our common stock. The forward contract was settled on January 24, 2020, and we received an additional 381,505 shares of our common stock.

[0001564590-20-042032:mdna:114]
In connection with the acquisition of Aerohive, as discussed in Note 4 of the accompanying consolidated financial statements, as of August 9, 2019, we amended the 2018 Credit Agreement, which is no longer outstanding, and entered into the 2019 Credit Agreement, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (“2019 Revolving Facility”).  In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-20-042032:mdna:115]
At our election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s Consolidated Leverage Ratio. All Eurodollar loans are subject to a Base Rate floor of 0.00%. The 2019 Credit Agreement is secured by substantially all of our assets.

[0001564590-20-042032:mdna:116]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-042032:mdna:117]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-042032:mdna:118]
On April 8, 2020, we entered into the first amendment to our 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants effective through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we are not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and we are restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. We expect to be in compliance with the original terms of the 2019 Credit Agreement prior to June 30, 2021.

[0001564590-20-042032:mdna:119]
We have already experienced an adverse effect on our revenues and results of operations due to the coronavirus outbreak. The full extent to which the COVID-19 outbreak impacts our results and cash flows will depend on future developments, which are highly uncertain and cannot be predicted at this time, including new information which may emerge concerning the severity of the coronavirus and the actions taken to contain the virus or treat its impact, among others. Complications from the COVID-19 outbreak could have a material adverse effect on the results of our operations, financial position, and cash flows particularly if such complications have an extended duration. See also Part I, Item 1A – Risk Factors.

[0001564590-20-042032:mdna:120]
Key Components of Cash Flows and Liquidity

[0001564590-20-042032:mdna:121]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001564590-20-042032:mdna:122]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Net cash provided by operating activities |  | $ | 35,884 |  |  | $ | 104,945 |  |  | $ | 19,043 |  |
| Net cash used in investing activities |  |  | (189,477 | ) |  |  | (21,809 | ) |  |  | (132,471 | ) |
| Net cash provided by (used in) financing activities |  |  | 178,492 |  |  |  | (34,442 | ) |  |  | 104,746 |  |
| Foreign currency effect on cash |  |  | (634 | ) |  |  | (226 | ) |  |  | (629 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 24,265 |  |  | $ | 48,468 |  |  | $ | (9,311 | ) |

[0001564590-20-042032:mdna:123]
Cash was $193.9 million at June 30, 2020, representing an increase of $24.3 million from $169.6 million at June 30, 2019. This increase was primarily due to cash provided by financing activities of $178.5 million mainly as a result of borrowing under the Term Loan and the Revolving Facility and cash provided by operations of $35.9 million partially offset by cash used in investing activities of $189.5 million, mainly for the acquisition of Aerohive.

[0001564590-20-042032:mdna:124]
Cash was $169.6 million at June 30, 2019, representing an increase of $48.5 million from $121.1 million at June 30, 2018. This increase was primarily due to cash provided by operations of $104.9 million partially offset by cash used in investing activities of $21.8 million mainly for capital expenditures, and cash used in financing activities of $34.4 million mainly as a result of payments on debt obligations and repurchases of stock.

[0001564590-20-042032:mdna:125]
Net Cash Provided by Operating Activities

[0001564590-20-042032:mdna:126]
Cash provided by operating activities during fiscal year ended 2020 was $35.9 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2020 were non-cash expenses such as amortization of intangibles, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, restructuring charges, deferred income taxes and imputed interest. Other sources of cash for the period included a decrease in accounts receivables, inventory, and prepaid expenses and other current assets and increases in deferred revenue. These amounts were partially offset by our net loss of $126.8 million, decreases in accounts payable, accrued compensation, other current and long-term liabilities, and operating lease liabilities.

[0001564590-20-042032:mdna:127]
Cash provided by operating activities during fiscal year ended 2019 was $104.9 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2019 were non-cash expenses such as amortization of intangibles, stock-based compensation and depreciation, decreases in accounts receivable and increases in deferred revenue and accrued compensation and benefits.  These amounts were partially offset by our net loss of $25.9 million, decreases in accounts payable, other current and long-term liabilities, and non-cash deferred income tax liabilities and increases in prepaid expenses and other assets.

[0001564590-20-042032:mdna:128]
Cash provided by operating activities during fiscal 2018 was $19.0 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2018 were non-cash expenses such as stock-based compensation, amortization of intangibles, depreciation, a decrease in inventories, as well as increases in deferred revenue, accounts payable and accrued compensation and benefits, and other current and long-term liabilities. These sources were partially offset by net loss of $46.8 million, increases in accounts receivable, prepaid expenses and other assets, non-cash gain on bargain purchase and decreases in deferred income tax liabilities.

[0001564590-20-042032:mdna:129]
Net Cash Used in Investing Activities

[0001564590-20-042032:mdna:130]
Cash used in investing activities during fiscal year ended June 30, 2020 was $189.5 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $15.3 million, which was partially offset by proceeds of $45.2 million related to the maturity and sales of short-term investments.

[0001564590-20-042032:mdna:131]
Cash used in investing activities during fiscal year ended June 30, 2019 was $21.8 million mainly due to capital expenditures of $22.7 million

[0001564590-20-042032:mdna:132]
Cash used in investing activities during fiscal 2018 was $132.5 million mainly due to our acquisitions of the Campus Fabric and Data Center Businesses of $97.6 million and capital expenditures of $40.4 million offset by proceeds from the sale of equity investment.

[0001564590-20-042032:mdna:133]
Net cash Provided by (Used in) Financing Activities

[0001564590-20-042032:mdna:134]
Cash provided by financing activities during fiscal year ended June 30, 2020 was $178.5 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $55.0 million of borrowings under our 2019 Revolving Facility, and by $8.8 million of proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards. This was partially offset by payments on debt obligations totaling $34.5 million, payment of loan fees incurred in connection with our 2019 Credit Facility and related amendments of $12.0 million, payments of contingent consideration of $4.3 million and $4.0 million of deferred payments on acquisitions.

[0001564590-20-042032:mdna:135]
Cash flows used in financing activities for the period also included repurchasing of our common shares valued at $30.0 million during fiscal year ended June 30, 2020, in accordance with our approved share repurchase plan. The share repurchases were executed

[0001564590-20-042032:mdna:136]
48

[0001564590-20-042032:mdna:137]
through an accelerated share buyback, and future share repurchases may be completed through the combination of individually negotiated transactions, accelerated share buyback, and/or open market purchases. As of June 30, 2020, we have $55.0 million available under our share repurchase plan.

[0001564590-20-042032:mdna:138]
Cash used in financing activities during fiscal year ended June 30, 2019 was $34.4 million due primarily to payments on debt obligations totaling $19.9 million, contingent consideration payments of $6.5 million and $4.0 million of deferred payments on acquisitions. This was partially offset by $11.5 million of proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards. Cash flows used in financing activities for the period also included repurchasing of our common shares valued at $15.0 million during fiscal year ended June 30, 2019, in accordance with our approved share repurchase plan. The share repurchases were executed through open market purchases.

[0001564590-20-042032:mdna:139]
Cash provided by financing activities during fiscal 2018 was $104.7 million due primarily to additional borrowings of $100.0 million to fund our acquisitions of the Campus Fabric and Data Center Businesses, new borrowings of $200 million under the Credit Agreement to pay off the existing debt under the prior Credit Facility, $3.3 million of proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, partially offset by payments on debt obligations totaling $193.7 million, $3.2 million of loan fees incurred in connection with the Second Amendment of our Credit Facility and the Credit Agreement and $1.7 million of contingent consideration payments and deferred payments on acquisitions.

[0001564590-20-042032:mdna:140]
Foreign Currency Effect on Cash

[0001564590-20-042032:mdna:141]
Foreign currency effect on cash decreased in 2020, primarily due to changes in exchange rates between the U.S. Dollar and particularly the Indian Rupee, UK pound, and the EURO.

[0001564590-20-042032:mdna:142]
Contractual Obligations

[0001564590-20-042032:mdna:143]
The following summarizes our contractual obligations at June 30, 2020, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-20-042032:mdna:144]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 420,750 |  |  | $ | 19,000 |  |  | $ | 61,750 |  |  | $ | 340,000 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 79,462 |  |  |  | 21,462 |  |  |  | 39,272 |  |  |  | 18,728 |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 37,975 |  |  |  | 37,975 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 95,566 |  |  |  | 20,367 |  |  |  | 40,733 |  |  |  | 17,233 |  |  |  | 17,233 |  |
| Lease payments on operating leases |  |  | 76,348 |  |  |  | 21,725 |  |  |  | 35,634 |  |  |  | 10,833 |  |  |  | 8,156 |  |
| Deferred payments for an acquisition |  |  | 11,000 |  |  |  | 4,000 |  |  |  | 7,000 |  |  |  | — |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 2,167 |  |  |  | 1,636 |  |  |  | 531 |  |  |  | — |  |  |  | — |  |
| Other liabilities |  |  | 176 |  |  |  | 42 |  |  |  | 86 |  |  |  | 48 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 723,444 |  |  | $ | 126,207 |  |  | $ | 185,006 |  |  | $ | 386,842 |  |  | $ | 25,389 |  |

[0001564590-20-042032:mdna:145]
The contractual obligations referenced above are more specifically defined as follows:

[0001564590-20-042032:mdna:146]
Debt obligations relate to amounts owed under our 2019 Credit Agreement.

[0001564590-20-042032:mdna:147]
Unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast.  We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-20-042032:mdna:148]
Contractual commitments to suppliers for future services.

[0001564590-20-042032:mdna:149]
Lease payments on operating leases represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001564590-20-042032:mdna:150]
Deferred payments represent Data Center Business consideration obligation of $1.0 million per quarter.

[0001564590-20-042032:mdna:151]
Contingent consideration for the Capital Financing Business acquisition, at fair value.  Actual payments could be different.

[0001564590-20-042032:mdna:152]
Other liabilities include our commitments towards debt related fees and specific arrangements other than inventory.

[0001564590-20-042032:mdna:153]
The amounts in the table above exclude immaterial income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of the settlement.

[0001564590-20-042032:mdna:154]
We did not have any material commitments for capital expenditures as of June 30, 2020.

[0001564590-20-042032:mdna:155]
Off-Balance Sheet Arrangements

[0001564590-20-042032:mdna:156]
We did not have any off-balance sheet arrangements as of June 30, 2020.

[0001564590-20-042032:mdna:157]
50
