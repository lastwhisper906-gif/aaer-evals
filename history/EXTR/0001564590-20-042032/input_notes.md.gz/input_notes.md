# EXTR notes — 0001564590-20-042032


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-20-042032:notes:1]
Portions of the registrant's definitive proxy statement for the year ended June 30, 2020 Annual Meeting of Stockholders to be filed with the Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated herein by reference in Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-20-042032:notes:2]
1. Description of Business and Basis of Presentation

[0001564590-20-042032:notes:3]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-20-042032:notes:4]
Fiscal Year

[0001564590-20-042032:notes:5]
The Company uses a fiscal calendar year ending on June 30.  All references herein to fiscal year ended “fiscal year ended  2020” or “2020”; “fiscal 2019” or “2019”; “fiscal 2018” or “2018” represent the fiscal years ending, respectively.

[0001564590-20-042032:notes:6]
Principles of Consolidation

[0001564590-20-042032:notes:7]
The consolidated financial statements include the accounts of Extreme Networks, Inc. and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-20-042032:notes:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end exchange rates; and revenues and expenses are translated using the monthly average rate.

[0001564590-20-042032:notes:9]
Accounting Estimates

[0001564590-20-042032:notes:10]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the financial statements and the accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-20-042032:notes:11]
2. Summary of Significant Accounting Policies

[0001564590-20-042032:notes:12]
Revenue Recognition

[0001564590-20-042032:notes:13]
The Company derives revenues primarily from sales of its networking equipment, with the remaining revenues generated from software delivered as a service (“SaaS”) and service fees relating to maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0001564590-20-042032:notes:14]
See Note 3, Revenues for further discussion.

[0001564590-20-042032:notes:15]
Cash and Cash Equivalents

[0001564590-20-042032:notes:16]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents.

[0001564590-20-042032:notes:17]
Allowance for Product Returns

[0001564590-20-042032:notes:18]
The Company maintains estimates for product returns based on its historical returns, analysis of credit memos and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is shown as a reduction of accounts receivable as there is a contractual right of offset and returns are applied to accounts receivable balances outstanding as of the balance sheet date. There have not been material revisions to the estimated product returns for any periods presented.

[0001564590-20-042032:notes:19]
Allowance for Doubtful Accounts

[0001564590-20-042032:notes:20]
The Company maintains an allowance for doubtful accounts which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring some of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001564590-20-042032:notes:21]
Inventories

[0001564590-20-042032:notes:22]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory is obsolete or may be in excess of anticipated demand based upon assumptions about future demand. At the point of the loss recognition, a new lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-20-042032:notes:23]
Long-Lived Assets

[0001564590-20-042032:notes:24]
Long-lived assets include (a) property and equipment, (b) operating lease right-of-use (“ROU”) assets, (c) goodwill and intangible assets, and (d) other assets. Property and equipment, ROU assets, and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001564590-20-042032:notes:25]
(a) Property and Equipment, Net

[0001564590-20-042032:notes:26]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and purchased software. Estimated useful lives of three to seven years are used for office equipment and furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years).

[0001564590-20-042032:notes:27]
(b) ROU Assets

[0001564590-20-042032:notes:28]
ROU assets under the Company’s operating leases represent the Company’s right to use an underlying asset over the lease term. The ROU asset is reduced over a straight-line or other systematic basis representative of the pattern in which the Company expects to consume the ROU assets’ future economic benefits. The ROU asset is also adjusted for leasehold improvements paid by the lessor, lease incentives, and asset impairments, among other things.

[0001564590-20-042032:notes:29]
(c) Goodwill and Intangible Assets

[0001564590-20-042032:notes:30]
Goodwill and intangible assets are generated as a result of business combinations and are comprised of, among other things, developed technology, customer relationships, trade names, and licensing agreements.

[0001564590-20-042032:notes:31]
The remaining lives of intangibles are considered regularly along with assessments of impairment and lives are adjusted or impairment charges taken when required.

[0001564590-20-042032:notes:32]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. The Company adopted ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment in fiscal 2018, which eliminated step two from the goodwill impairment test. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceed directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Any loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. Based on the results of the goodwill impairment analyses, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0001564590-20-042032:notes:33]
Business Combinations

[0001564590-20-042032:notes:34]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, useful lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0001564590-20-042032:notes:35]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of the purchase price, a gain on bargain purchase is recognized within the consolidated statements of operations. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0001564590-20-042032:notes:36]
Deferred Revenue

[0001564590-20-042032:notes:37]
Deferred revenue represents amounts for (i) deferred maintenance, support, and SaaS revenues, and (ii) other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001564590-20-042032:notes:38]
Product Warranties and Guarantees

[0001564590-20-042032:notes:39]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-20-042032:notes:40]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-20-042032:notes:41]
Stock-based Compensation

[0001564590-20-042032:notes:42]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock options and share purchase options under the 2014 ESPP using the Black-Scholes-Merton option valuation model. The fair value of RSUs is based on the closing stock price of the Company’s common stock on the grant date.

[0001564590-20-042032:notes:43]
The Company grants certain employees performance-based stock options and RSUs. The performance metrics include company-wide financial performance and/or market conditions. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0001564590-20-042032:notes:44]
Advertising

[0001564590-20-042032:notes:45]
Advertising costs are expensed as incurred. Advertising expenses were immaterial in fiscal years 2020, 2019 and 2018.

[0001564590-20-042032:notes:46]
Income Taxes

[0001564590-20-042032:notes:47]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0001564590-20-042032:notes:48]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions.  The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.  For additional discussion, see Note 16, Income Taxes.

[0001564590-20-042032:notes:49]
Recently Adopted Accounting Pronouncements

[0001564590-20-042032:notes:50]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also requires lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

[0001564590-20-042032:notes:51]
The Company adopted the new standards beginning with its fiscal year 2020. Topic 842 is applied on the modified retrospective method, applying the new standard to all leases existing as of July 1, 2019. The Company adopted the new standard using the effective date of July 1, 2019 as the date of initial application. Consequently, financial information has not been updated, and disclosures required under the new standard will not be provided for dates and periods prior to July 1, 2019.

[0001564590-20-042032:notes:52]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and provides maintenance and support over a service period which is recognized under ASC Topic 606. See Note 9, Leases for additional information regarding the Company’s leases.

[0001564590-20-042032:notes:53]
On July 1, 2019, the Company recognized ROU assets of $64.6 million and corresponding lease liabilities of $79.5 million on the consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases.

[0001564590-20-042032:notes:54]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In

[0001564590-20-042032:notes:55]
addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption. During the third quarter of fiscal 2020, the Company entered into interest rate swap agreements to manage its exposure to fluctuations of interest rates associated with its debt.  See Note 14, Derivatives and Hedging for additional information.

[0001564590-20-042032:notes:56]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), which allows the reclassification from Additional Other Comprehensive Income (“AOCI”) to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act").  The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI.  This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-20-042032:notes:57]
In March 2020, the FASB issued ASU 2020-04, “Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by the discontinuation of the London Interbank Offered Rate (LIBOR) and other interbank offered rates. This guidance is effective upon issuance and can be applied to applicable contract modifications through December 31, 2022. The Company elected to apply the amendments in this update to eligible hedging relationships existing as of January 1, 2020 or entered into during fiscal year 2020 in accordance with the transition options available. This guidance did not have any impact upon adoption. The Company will apply this guidance to transactions or modifications of these arrangements as appropriate through transition period.

[0001564590-20-042032:notes:58]
Recently Issued Accounting Pronouncements

[0001564590-20-042032:notes:59]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2019.  The Company is currently evaluating the impact the new standard, but does not believe that it will have a material effect on its consolidated financial statements and related disclosures. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-042032:notes:60]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard, but does not believe that it will have a material effect on its consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-042032:notes:61]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard, but does not believe that it will have a material effect on its consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-042032:notes:62]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures.  This guidance is effective for the Company’s fiscal year 2022, beginning on July 1, 2021.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001564590-20-042032:notes:63]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from SaaS and service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-20-042032:notes:64]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations.  In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0001564590-20-042032:notes:65]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenues from maintenance contracts and SaaS are recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to five years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales taxes collected from customers are excluded from revenues.  Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-20-042032:notes:66]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are estimated using the expected value method based on historical return rates based on historical return rates and estimates provided by the distributors. Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price. At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-20-042032:notes:67]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-20-042032:notes:68]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time. For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-20-042032:notes:69]
At June 30, 2020, the Company had $291.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 65 percent of this amount in fiscal 2021, an additional 19 percent in fiscal 2022 and 16 percent of the balance thereafter.

[0001564590-20-042032:notes:70]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic

[0001564590-20-042032:notes:71]
intervals (e.g., quarterly or annually).  The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenue.  These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-20-042032:notes:72]
Revenue recognized for the years ended June 30, 2020 and 2019, that was included in the deferred revenue balance at the beginning of each period was $137.6 million and $126.7 million, respectively.

[0001564590-20-042032:notes:73]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals, are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $8.1 million and $6.5 million at June 30, 2020 and 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations.  Amortization recognized during the years ended 2020, 2019 and 2018 was $5.2 million, $3.0 million and $2.1 million, respectively.

[0001564590-20-042032:notes:74]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-20-042032:notes:75]
Revenues by Category: The following tables set forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-20-042032:notes:76]
|  |  | Year Ended June 30, 2020 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 218,276 |  |  | $ | 241,493 |  |  | $ | 459,769 |  |
| Other |  |  | 19,530 |  |  |  | 20,103 |  |  |  | 39,633 |  |
| Total Americas |  |  | 237,806 |  |  |  | 261,596 |  |  |  | 499,402 |  |
| EMEA: |  |  | 218,947 |  |  |  | 138,254 |  |  |  | 357,201 |  |
| APAC: |  |  | 21,554 |  |  |  | 69,862 |  |  |  | 91,416 |  |
| Total net revenues |  | $ | 478,307 |  |  | $ | 469,712 |  |  | $ | 948,019 |  |

[0001564590-20-042032:notes:77]
|  |  | Year Ended June 30, 2019 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 259,873 |  |  | $ | 238,832 |  |  | $ | 498,705 |  |
| Other |  |  | 22,264 |  |  |  | 20,632 |  |  |  | 42,896 |  |
| Total Americas |  |  | 282,137 |  |  |  | 259,464 |  |  |  | 541,601 |  |
| EMEA: |  |  | 229,223 |  |  |  | 129,104 |  |  |  | 358,327 |  |
| APAC: |  |  | 14,598 |  |  |  | 81,263 |  |  |  | 95,861 |  |
| Total net revenues |  | $ | 525,958 |  |  | $ | 469,831 |  |  | $ | 995,789 |  |

[0001564590-20-042032:notes:78]
|  |  | Year Ended June 30, 2018 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 271,975 |  |  | $ | 219,642 |  |  | $ | 491,617 |  |
| Other |  |  | 19,414 |  |  |  | 25,274 |  |  |  | 44,688 |  |
| Total Americas |  |  | 291,389 |  |  |  | 244,916 |  |  |  | 536,305 |  |
| EMEA: |  |  | 218,682 |  |  |  | 136,064 |  |  |  | 354,746 |  |
| APAC: |  |  | 15,621 |  |  |  | 76,470 |  |  |  | 92,091 |  |
| Total net revenues |  | $ | 525,692 |  |  | $ | 457,450 |  |  | $ | 983,142 |  |

[0001564590-20-042032:notes:79]
Included in the above amounts are $8.9 million, $11.2 million, and $8.9 million of leasing revenues for the years ended 2020, 2019 and 2018, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-042032:notes:80]
3. Revenues

[0001564590-20-042032:notes:81]
Concentrations

[0001564590-20-042032:notes:82]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-20-042032:notes:83]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenues:

[0001564590-20-042032:notes:84]
|  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Tech Data Corporation |  | 18% |  |  | 18% |  |  | 14% |  |
| Jenne Corporation |  | 15% |  |  | 17% |  |  | 13% |  |
| Westcon Group Inc. |  | 13% |  |  | 12% |  |  | 13% |  |

[0001564590-20-042032:notes:85]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable balance:

[0001564590-20-042032:notes:86]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 23 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 25 | % |  |  | 35 | % |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-042032:notes:87]
4. Business Combinations

[0001564590-20-042032:notes:88]
The Company completed one acquisition during the fiscal year ended June 30, 2020 and three acquisitions during the fiscal year ended June 30, 2018. The acquisitions have been accounted for using the acquisition method of accounting. The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The purchase price of each acquisition has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach. The fair value of property and equipment was determined using a cost approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount the Company would be required to pay to a third party to assume the obligation. Intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. Results of operations of the acquired entities are included in the Company’s operations beginning with the closing date of each acquisition.

[0001564590-20-042032:notes:89]
Fiscal 2020 Acquisitions

[0001564590-20-042032:notes:90]
Aerohive Acquisition

[0001564590-20-042032:notes:91]
On August 9, 2019 (the “Acquisition Date”) the Company consummated its acquisition (the “Acquisition”) of all of the outstanding common stock of Aerohive Networks, Inc. (“Aerohive”) pursuant to that certain Agreement and Plan of Merger (the “Merger Agreement”) entered into as of June 26, 2019.  Under the terms of the Acquisition, the net consideration paid by Extreme to Aerohive stockholders was $267.1 million.

[0001564590-20-042032:notes:92]
The Acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets.  The fair values were determined through established and generally accepted valuation techniques. All valuations were considered finalized as of June 30, 2020.

[0001564590-20-042032:notes:93]
The components of aggregate purchase consideration are as follows (in thousands):

[0001564590-20-042032:notes:94]
| Purchase consideration |  | August 9, 2019 |  |
| Cash paid to acquire outstanding shares |  | $ | 263,616 |  |
| Replacement of stock-based awards |  |  | 3,530 |  |
| Aggregate purchase consideration |  | $ | 267,146 |  |

[0001564590-20-042032:notes:95]
The purchase price allocation is set forth in the table below and reflects estimated fair values (in thousands).

[0001564590-20-042032:notes:96]
|  | Preliminary Allocation as of August 9, 2019 |  |  |  |  | Adjustments |  |  | Final Allocation as of June 30, 2020 |  |
| Cash and cash equivalents | $ | 44,158 |  |  |  |  | $ | — |  |  | $ | 44,158 |  |
| Short-term investments |  | 45,148 |  |  |  |  |  | — |  |  |  | 45,148 |  |
| Accounts receivable, net |  | 11,753 |  |  |  |  |  | — |  |  |  | 11,753 |  |
| Inventories |  | 16,698 |  |  | a |  |  | 2,534 |  |  |  | 19,232 |  |
| Prepaid expenses and other current assets |  | 3,980 |  |  | b |  |  | (56 | ) |  |  | 3,924 |  |
| Property and equipment |  | 2,185 |  |  | c |  |  | 179 |  |  |  | 2,364 |  |
| Operating lease right-of-use assets |  | 6,336 |  |  |  |  |  | — |  |  |  | 6,336 |  |
| Other assets |  | 2,195 |  |  |  |  |  | — |  |  |  | 2,195 |  |
| Debt |  | (20,000 | ) |  |  |  |  | — |  |  |  | (20,000 | ) |
| Accounts payable |  | (9,737 | ) |  |  |  |  | — |  |  |  | (9,737 | ) |
| Accrued compensation and benefits |  | (7,129 | ) |  |  |  |  | — |  |  |  | (7,129 | ) |
| Accrued warranty |  | (570 | ) |  |  |  |  | — |  |  |  | (570 | ) |
| Other accrued liabilities |  | (1,960 | ) |  |  |  |  | — |  |  |  | (1,960 | ) |
| Operating lease liabilities |  | (4,752 | ) |  |  |  |  | — |  |  |  | (4,752 | ) |
| Deferred revenue |  | (68,415 | ) |  |  |  |  | — |  |  |  | (68,415 | ) |
| Other liabilities |  | (408 | ) |  | e |  |  | (75 | ) |  |  | (483 | ) |
| Net tangible assets |  | 19,482 |  |  |  |  |  | 2,582 |  |  |  | 22,064 |  |
| Identifiable intangible assets |  | 53,400 |  |  | d |  |  | (900 | ) |  |  | 52,500 |  |
| Goodwill |  | 194,264 |  |  | a,b,c,d, e |  |  | (1,682 | ) |  |  | 192,582 |  |
| Total intangible assets acquired |  | 247,664 |  |  |  |  |  | (2,582 | ) |  |  | 245,082 |  |
| Total net assets acquired | $ | 267,146 |  |  |  |  | $ | — |  |  | $ | 267,146 |  |

[0001564590-20-042032:notes:97]
The changes during the period in the table above include: a) adjustment of the fair value of inventories acquired, b) write-off of an asset with no future economic value as of the Acquisition Date, c) adjustment to the value of property and equipment as of the Acquisition Date at an international location, d) adjustment to the fair value of intangibles, and e) adjustment of the fair value of certain tax related liabilities.

[0001564590-20-042032:notes:98]
The following table presents details of the identifiable intangible assets acquired as part of the Acquisition (dollars in thousands):

[0001564590-20-042032:notes:99]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 4 |  |  | $ | 39,100 |  |
| Backlog |  |  | 1 |  |  |  | 400 |  |
| Customer relationships |  |  | 7 |  |  |  | 11,400 |  |
| Trade names |  |  | 1 |  |  |  | 1,600 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 52,500 |  |

[0001564590-20-042032:notes:100]
The amortization for the developed technology and backlog is recorded in “Cost of revenues” for product and service and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statements of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Aerohive

[0001564590-20-042032:notes:101]
along with the future potential of the technology. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as the Acquisition is a nontaxable stock acquisition.

[0001564590-20-042032:notes:102]
The results of operations of Aerohive are included in the accompanying consolidated statements of operations beginning August 9, 2019.  The Aerohive revenues for the year ended June 30, 2020 was $125.1 million and was incorporated into the revenues of the Company.  Certain associated expenses of Aerohive were incorporated with the results of operations of the Company and, therefore, stand-alone operating results are not available.

[0001564590-20-042032:notes:103]
In the year ended June 30, 2020, the Company incurred acquisition and integration related expenses of $32.1 million associated with the Acquisition, including a $6.8 million compensation charge for certain Aerohive Executive stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts.  Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for terminated Aerohive employees.  Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0001564590-20-042032:notes:104]
Pro Forma Financial Information

[0001564590-20-042032:notes:105]
The following unaudited pro forma results of operations are presented as though the Acquisition had occurred as of July 1, 2018, the beginning of fiscal 2019, after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization of intangibles, acquisition and integration costs, and interest income and expense.

[0001564590-20-042032:notes:106]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2019, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-20-042032:notes:107]
The unaudited pro forma financial information for the year ended June 30, 2020 combines the historical results for Extreme for such periods, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-20-042032:notes:108]
Pro forma results of operations for the year ended June 30, 2019 combines the historical results of operations for Extreme and for Aerohive.

[0001564590-20-042032:notes:109]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0001564590-20-042032:notes:110]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Net revenues |  | $ | 962,399 |  |  | $ | 1,139,321 |  |
| Net loss |  | $ | (85,392 | ) |  | $ | (120,146 | ) |
| Net loss per share - basic and diluted |  | $ | (0.71 | ) |  | $ | (1.02 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 119,814 |  |  |  | 117,954 |  |

[0001564590-20-042032:notes:111]
Fiscal 2018 Acquisitions

[0001564590-20-042032:notes:112]
Data Center Business

[0001564590-20-042032:notes:113]
The Company completed its acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc.’s (“Brocade”) on October 27, 2017 (the “Data Center Closing Date”), pursuant to an Asset Purchase Agreement (the “Data Center Business APA”) dated as of October 3, 2017, by and between the Company and Brocade for an aggregate purchase consideration of $84.3 million. Under the terms and conditions of the Data Center Business APA, the Company acquired customers, employees, technology and other assets of the Data Center Business as well as assumed certain contracts and other liabilities of the Data Center Business.

[0001564590-20-042032:notes:114]
The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-20-042032:notes:115]
|  |  | Final Allocation |  |
| Accounts receivables |  | $ | 33,488 |  |
| Inventories |  |  | 19,934 |  |
| Prepaid expenses and other current assets |  |  | 988 |  |
| Property and equipment | (a) |  | 19,442 |  |
| Other assets |  |  | 4,734 |  |
| Accounts payable and accrued expenses |  |  | (16,494 | ) |
| Deferred revenue |  |  | (33,025 | ) |
| Net tangible assets acquired |  |  | 29,067 |  |
| Identifiable intangible assets |  |  | 32,800 |  |
| Goodwill | (a) |  | 22,470 |  |
| Total intangible assets acquired |  |  | 55,270 |  |
| Total net assets acquired |  | $ | 84,337 |  |

[0001564590-20-042032:notes:116]
|  | (a) | Includes an adjustment after the measurement period to record $0.5 million of additional property and equipment acquired at an international location. |

[0001564590-20-042032:notes:117]
Campus Fabric Business

[0001564590-20-042032:notes:118]
The Company completed its acquisition of Avaya Inc.’s (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) on July 14, 2017, (the “Campus Fabric Business Closing Date”) pursuant to an Asset Purchase Agreement (the “Campus Fabric Business APA”) dated March 7, 2017.  Under the terms and conditions of the Campus Fabric Business APA, the Company acquired the customers, employees, technology and other assets of the Campus Fabric Business, as well as assumed certain contracts and other liabilities of the Campus Fabric Business, for total consideration of $79.4 million.

[0001564590-20-042032:notes:119]
|  | Final Allocation |  |
| Accounts receivables | $ | 19,527 |  |
| Inventories |  | 14,165 |  |
| Prepaid expenses and other current assets |  | 240 |  |
| Property and equipment |  | 5,406 |  |
| Other assets |  | 7,009 |  |
| Accounts payable and accrued expenses |  | (31,670 | ) |
| Deferred revenue |  | (8,994 | ) |
| Other long-term liabilities |  | (5,849 | ) |
| Net tangible assets acquired |  | (166 | ) |
| Identifiable intangible assets |  | 41,300 |  |
| In-process research and development |  | 2,400 |  |
| Goodwill |  | 35,892 |  |
| Total intangible assets acquired |  | 79,592 |  |
| Total net assets acquired | $ | 79,426 |  |

[0001564590-20-042032:notes:120]
Capital Financing Business

[0001564590-20-042032:notes:121]
On December 1, 2017, Company completed its acquisition of a capital financing business (the “CF Business”), pursuant to a Bill of Sale and Assignment and Assumption Agreement (the “Assumption Agreement”) between the Company and Broadcom.  Under the terms and conditions of the Assumption Agreement, the Company acquired customers, employees, contracts and lease equipment of the CF Business equal to the earn out payments to Broadcom of 90% of acquired financing receivables to be collected commencing at the closing date.

[0001564590-20-042032:notes:122]
Net assets acquired included financing receivables of $13.7 million, lease equipment of $3.5 million and identifiable intangible assets of $0.8 million, and the fair value of the contingent consideration was $13.0 million. As the preliminary fair value of the net assets acquired exceeded the fair value of the purchase consideration, the Company recorded a bargain purchase gain of $5.0 million.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-042032:notes:123]
5. Balance Sheet Components

[0001564590-20-042032:notes:124]
Accounts Receivable

[0001564590-20-042032:notes:125]
The following is a summary of accounts receivable (in thousands):

[0001564590-20-042032:notes:126]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Accounts receivable |  | $ | 151,902 |  |  | $ | 201,365 |  |
| Allowance for doubtful accounts |  |  | (1,212 | ) |  |  | (1,054 | ) |
| Allowance for product returns |  |  | (27,963 | ) |  |  | (25,897 | ) |
| Accounts receivable, net |  | $ | 122,727 |  |  | $ | 174,414 |  |

[0001564590-20-042032:notes:127]
The following table is a summary of the allowance for doubtful accounts (in thousands):

[0001564590-20-042032:notes:128]
| Description |  | Balance at beginning of period |  |  | Charges to bad debt expenses |  |  | Deductions (1) |  |  | Balance at end of period |  |
| Year Ended June 30, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,054 |  |  | $ | 1,289 |  |  | $ | (1,131 | ) |  | $ | 1,212 |  |
| Year Ended June 30, 2019: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,478 |  |  | $ | 1,407 |  |  | $ | (1,831 | ) |  | $ | 1,054 |  |
| Year Ended June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 1,190 |  |  | $ | 1,687 |  |  | $ | (1,399 | ) |  | $ | 1,478 |  |

[0001564590-20-042032:notes:129]
|  | (1) | Uncollectible accounts written off, net of recoveries |

[0001564590-20-042032:notes:130]
The following table is a summary of the Company’s allowance for product returns (in thousands):

[0001564590-20-042032:notes:131]
| Description |  | Balance at beginning of period |  | Additions |  | Deductions |  | Balance at end of period |
| Year Ended June 30, 2020: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $25,897 |  | $76,802 |  | $(74,736) |  | $27,963 |
| Year Ended June 30, 2019: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $11,266 |  | $85,190 |  | $(70,559) |  | $25,897 |
| Year Ended June 30, 2018: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $7,296 |  | $38,103 |  | $(34,133) |  | $11,266 |

[0001564590-20-042032:notes:132]
The following is a summary of the Company’s inventory by category (in thousands):

[0001564590-20-042032:notes:133]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Finished goods |  | $ | 52,879 |  |  | $ | 49,492 |  |
| Raw materials |  |  | 9,710 |  |  |  | 14,097 |  |
| Total Inventories |  | $ | 62,589 |  |  | $ | 63,589 |  |

[0001564590-20-042032:notes:134]
Property and Equipment, Net

[0001564590-20-042032:notes:135]
The following is a summary of the Company’s property and equipment by category (in thousands):

[0001564590-20-042032:notes:136]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Computers and equipment |  | $ | 73,244 |  |  | $ | 72,309 |  |
| Purchased software |  |  | 34,015 |  |  |  | 29,126 |  |
| Office equipment, furniture and fixtures |  |  | 10,639 |  |  |  | 10,815 |  |
| Leasehold improvements |  |  | 52,317 |  |  |  | 51,245 |  |
| Total property and equipment |  |  | 170,215 |  |  |  | 163,495 |  |
| Less: accumulated depreciation and amortization |  |  | (111,402 | ) |  |  | (89,941 | ) |
| Property and equipment, net |  | $ | 58,813 |  |  | $ | 73,554 |  |

[0001564590-20-042032:notes:137]
The Company recognized depreciation expense of $28.6 million, $26.9 million, and $23.5 million related to property and equipment during the years ended 2020, 2019 and 2018, respectively.

[0001564590-20-042032:notes:138]
The following table summarizes contract liabilities which are shown as deferred revenue (in thousands):

[0001564590-20-042032:notes:139]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Deferred maintenance, support, and SaaS |  | $ | 279,368 |  |  | $ | 192,955 |  |
| Other deferred revenue |  |  | 11,819 |  |  |  | 10,287 |  |
| Total deferred revenue, net |  |  | 291,187 |  |  |  | 203,242 |  |
| Less: current portion |  |  | 190,226 |  |  |  | 144,230 |  |
| Non-current deferred revenue, net |  | $ | 100,961 |  |  | $ | 59,012 |  |

[0001564590-20-042032:notes:140]
Total deferred revenue increased primarily due to the acquisition of Aerohive, and extended duration period of new service contracts during fiscal 2020.

[0001564590-20-042032:notes:141]
Accrued Warranty

[0001564590-20-042032:notes:142]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0001564590-20-042032:notes:143]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Balance beginning of period |  | $ | 14,779 |  |  | $ | 12,807 |  |
| Warranties assumed due to acquisitions |  |  | 570 |  |  |  | — |  |
| New warranties issued |  |  | 19,686 |  |  |  | 22,919 |  |
| Warranty expenditures |  |  | (21,000 | ) |  |  | (20,947 | ) |
| Balance end of period |  | $ | 14,035 |  |  | $ | 14,779 |  |

[0001564590-20-042032:notes:144]
Other Long-term Liabilities

[0001564590-20-042032:notes:145]
The following is a summary of long-term liabilities (in thousands):

[0001564590-20-042032:notes:146]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Acquisition-related deferred payments, less current portion |  | $ | 5,847 |  |  | $ | 9,604 |  |
| Contingent consideration obligations, less current portion |  |  | 506 |  |  |  | 2,688 |  |
| Other contractual obligations, less current portion |  |  | 16,722 |  |  |  | 26,261 |  |
| Other |  |  | 4,676 |  |  |  | 15,597 |  |
| Total other long-term liabilities |  | $ | 27,751 |  |  | $ | 54,150 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-042032:notes:147]
6. Fair Value Measurements

[0001564590-20-042032:notes:148]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0001564590-20-042032:notes:149]
|  | • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-20-042032:notes:150]
|  | • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-20-042032:notes:151]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value. |

[0001564590-20-042032:notes:152]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-20-042032:notes:153]
| June 30, 2020 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Interest rate swaps |  | $ | — |  |  | $ | 1,769 |  |  | $ | — |  |  | $ | 1,769 |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 2,167 |  |  | $ | 2,167 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,777 |  |  | $ | 2,167 |  |  | $ | 3,944 |  |

[0001564590-20-042032:notes:154]
| June 30, 2019 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 6,298 |  |  | $ | 6,298 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 6,298 |  |  | $ | 6,298 |  |

[0001564590-20-042032:notes:155]
The Company’s financial instruments consist of cash, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0001564590-20-042032:notes:156]
The fair value of derivative instruments under our foreign currency contracts and interest rate swaps are estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.

[0001564590-20-042032:notes:157]
As of June 30, 2020, forward foreign currency contracts had a notional principal amount of $4.0 million and for the year ended June 30, 2020, there were gains of $0.1 million. These contracts have maturities of less than 30 days. Changes in the fair value of these foreign exchange forward contracts are included in other income or expense. There were no forward foreign currency contracts at June 30, 2019. See Note 14, Derivatives and Hedging for additional information.

[0001564590-20-042032:notes:158]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of June 30, 2020, the Company had entered into multiple interest rate swap contracts with the total notional amount of $200.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive income (loss). As of June 30, 2020, these contracts had an unrealized loss of $1.8 million. There were no interest rate swaps outstanding at June 30, 2019. See Note 14, Derivatives and Hedging for additional information.

[0001564590-20-042032:notes:159]
The fair value of the borrowings under the Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the limited duration until maturity of the Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $420.8 million and $180.5 million as of June 30, 2020 and 2019, respectively.  Such differences are immaterial for all periods presented.

[0001564590-20-042032:notes:160]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.

[0001564590-20-042032:notes:161]
At June 30, 2020 and June 30, 2019, the Company reflected one liability measured at fair value of $2.2 million and $6.3 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3

[0001564590-20-042032:notes:162]
measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying consolidated statements of operations.

[0001564590-20-042032:notes:163]
The change in the acquisition-related contingent consideration obligations is as follows (in thousands):

[0001564590-20-042032:notes:164]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |
| Beginning balance |  |  | 6,298 |  |
| Payments |  |  | (4,251 | ) |
| Accretion on discount |  |  | 120 |  |
| Ending balance |  | $ | 2,167 |  |

[0001564590-20-042032:notes:165]
There were no transfers of assets or liabilities between Level 1, Level 2 or Level 3 during the year ended June 30, 2020 or 2019. There were no impairments recorded for the year ended June 30, 2020 or 2019.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-20-042032:notes:166]
7. Goodwill and Intangible Assets

[0001564590-20-042032:notes:167]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-20-042032:notes:168]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Balance at beginning of period |  | $ | 138,577 |  |  | $ | 139,082 |  |
| Additions due to acquisitions (see Note 4) |  |  | 192,582 |  |  |  | — |  |
| Adjustments |  |  | — |  |  |  | (505 | ) |
| Balance at end of period |  | $ | 331,159 |  |  | $ | 138,577 |  |

[0001564590-20-042032:notes:169]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0001564590-20-042032:notes:170]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 156,100 |  |  | $ | 103,806 |  |  | $ | 52,294 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 49,598 |  |  |  | 13,441 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.4 years |  |  | 10,700 |  |  |  | 8,554 |  |  |  | 2,146 |  |
| License agreements |  | 5.8 years |  |  | 2,445 |  |  |  | 1,932 |  |  |  | 513 |  |
| Other intangibles |  | — years |  |  | 1,382 |  |  |  | 1,382 |  |  |  | — |  |
| Total intangibles, net |  |  |  | $ | 234,066 |  |  | $ | 165,672 |  |  | $ | 68,394 |  |

[0001564590-20-042032:notes:171]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 117,000 |  |  | $ | 77,449 |  |  | $ | 39,551 |  |
| Customer relationships |  | 2.0 years |  |  | 51,639 |  |  |  | 44,410 |  |  |  | 7,229 |  |
| Trade names |  | 2.4 years |  |  | 9,100 |  |  |  | 5,647 |  |  |  | 3,453 |  |
| License agreements |  | 5.4 years |  |  | 2,445 |  |  |  | 1,661 |  |  |  | 784 |  |
| Other intangibles |  | 0.6 years |  |  | 1,382 |  |  |  | 1,287 |  |  |  | 95 |  |
| Total intangibles, net |  |  |  | $ | 181,566 |  |  | $ | 130,454 |  |  | $ | 51,112 |  |

[0001564590-20-042032:notes:172]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-20-042032:notes:173]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Amortization in “Cost of revenues: Product and Service” |  | $ | 26,793 |  |  | $ | 19,638 |  |  | $ | 16,870 |  |
| Amortization of intangibles in "Operations" |  |  | 8,425 |  |  |  | 6,346 |  |  |  | 8,715 |  |
| Total amortization |  | $ | 35,218 |  |  | $ | 25,984 |  |  | $ | 25,585 |  |

[0001564590-20-042032:notes:174]
The amortization expense that is recognized in “Cost of revenues: Product and Service” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-20-042032:notes:175]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0001564590-20-042032:notes:176]
| For the fiscal year ending: |  |  |  |  |
| 2021 |  | $ | 32,356 |  |
| 2022 |  |  | 17,674 |  |
| 2023 |  |  | 12,278 |  |
| 2024 |  |  | 2,515 |  |
| 2025 |  |  | 1,700 |  |
| Thereafter |  |  | 1,871 |  |
| Total |  | $ | 68,394 |  |


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-042032:notes:177]
8. Debt

[0001564590-20-042032:notes:178]
Debt

[0001564590-20-042032:notes:179]
The Company’s debt is comprised of the following (in thousands):

[0001564590-20-042032:notes:180]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,484 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,516 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 346,750 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (7,165 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 394,585 |  |  |  | 169,739 |  |
| Total debt |  | $ | 411,101 |  |  | $ | 178,750 |  |

[0001564590-20-042032:notes:181]
On May 1, 2018, the Company entered into a Credit Agreement (the “2018 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as an administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The 2018 Credit Agreement provided for i) a $40 million five-year revolving credit facility (the “2018 Revolving Facility”), ii) a $190 million five-year term loan (the “2018 Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“2018 Incremental Facility”).

[0001564590-20-042032:notes:182]
In connection with the Acquisition as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-20-042032:notes:183]
The 2019 Credit Agreement, which replaced the 2018 Credit Agreement, provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-20-042032:notes:184]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-20-042032:notes:185]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration the payment of the outstanding balance.

[0001564590-20-042032:notes:186]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-20-042032:notes:187]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2018, in conjunction with the 2018 Credit Agreement, the Company recorded a loss from an extinguishment of debt of $1.2 million in “Interest expense” in the accompanying consolidated statements of operations. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of June 30, 2020 was 5.6%.

[0001564590-20-042032:notes:188]
Amortization of deferred financing costs is included in “Interest expense” in the accompanying consolidated statements of operations, totaled $2.5 million, $0.6 million and $0.7 million in fiscal years ended 2020, 2019 and 2018, respectively.

[0001564590-20-042032:notes:189]
The Company had $7.7 million of outstanding letters of credit as of June 30, 2020.

[0001564590-20-042032:notes:190]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0001564590-20-042032:notes:191]
| For the fiscal year ending: |  |  |  |  |
| 2021 |  | $ | 19,000 |  |
| 2022 |  |  | 26,125 |  |
| 2023 |  |  | 35,625 |  |
| 2024 |  |  | 38,000 |  |
| 2025 |  |  | 302,000 |  |
| Total |  | $ | 420,750 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-20-042032:notes:192]
9. Leases

[0001564590-20-042032:notes:193]
Lessee Considerations

[0001564590-20-042032:notes:194]
The Company leases certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2028. Its leases generally have terms that range from one year to eight years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0001564590-20-042032:notes:195]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or right-of-use (“ROU”) asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate at the commencement date because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is the rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. The biggest drivers having the greatest effect determining the incremental borrowing rate for each one of the Company’s leases are term of the lease and the currency the in which the lease obligation is satisfied. Operating lease assets also included a reclassification for previous asset impairments and associated restructuring liabilities, deferred rent, lease incentives and initial direct costs which reduced the operating lease ROU assets as of July 1, 2019.

[0001564590-20-042032:notes:196]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for non-lease costs and variable lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s consolidated statements of operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0001564590-20-042032:notes:197]
Activity and other information relating to operating leases is as follows (in thousands except for lease term and discount rate):

[0001564590-20-042032:notes:198]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |
| Operating lease costs | $ | 19,600 |  |
| Variable lease costs |  |  | 6,176 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 21,064 |  |
| ROU assets obtained for new lease obligations |  | 3,779 |  |
| ROU assets obtained from Aerohive business combination |  | 6,336 |  |

[0001564590-20-042032:notes:199]
|  |  | June 30, 2020 |  |
| Weighted average remaining lease term (in years) |  | 4.3 |  |
| Weighted Average Discount Rate |  | 4.5 | % |

[0001564590-20-042032:notes:200]
Short-term lease expense, which represents expense for leases that have terms of one year or less, was not material for the year ended June 30, 2020.

[0001564590-20-042032:notes:201]
The maturities of the Company’s operating lease liabilities as of June 30, 2020 by fiscal year are as follows:

[0001564590-20-042032:notes:202]
|  |  | Operating Leases (in thousands) |  |
| 2021 |  | $ | 21,725 |  |
| 2022 |  |  | 19,765 |  |
| 2023 |  |  | 15,869 |  |
| 2024 |  |  | 6,427 |  |
| 2025 |  |  | 4,406 |  |
| Thereafter |  |  | 8,156 |  |
| Total future minimum lease payments |  |  | 76,348 |  |
| Less amount representing interest |  |  | (6,914 | ) |
| Total operating lease liabilities |  | $ | 69,434 |  |
| Operating lease liabilities, current |  | $ | 19,196 |  |
| Operating lease liabilities, non-current |  | $ | 50,238 |  |

[0001564590-20-042032:notes:203]
As of June 30, 2019, the minimum future rentals on non-cancellable operating leases by fiscal year, based on the previous accounting standard, were as follows:

[0001564590-20-042032:notes:204]
|  |  | Operating Leases (in thousands) |  |
| 2020 |  | $ | 22,733 |  |
| 2021 |  |  | 21,174 |  |
| 2022 |  |  | 20,680 |  |
| 2023 |  |  | 17,828 |  |
| 2024 |  |  | 5,976 |  |
| Thereafter |  |  | 16,287 |  |
| Total lease payments |  | $ | 104,678 |  |

[0001564590-20-042032:notes:205]
Sublease Considerations

[0001564590-20-042032:notes:206]
The Company currently is a sublessor on several operating facility subleases that expire on various dates through fiscal 2023. The subleases have terms from five to six years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. These operating subleases include only lease components. The Company included $2.5 million of sublease income in lease expense for the year ended June 30, 2020.

[0001564590-20-042032:notes:207]
Lessor Considerations

[0001564590-20-042032:notes:208]
Although most of the Company’s revenues from its hardware business comes from sales of hardware, the Company also sells subscription contracts which contain both operating lease and non-lease components. These leases range in duration generally up to three years with payments generally collected in equal quarterly installments, do not include purchase options, and include 60-day termination rights by either party. For the years ended 2020, 2019 and 2018, respectively, $8.9 million, $11.2 million, and $8.9 million of consideration for these leases are included in product revenues in the Company’s consolidated financial statements. The accounting for these arrangements was not impacted by the Company’s adoption of ASC 842.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-042032:notes:209]
10. Commitments and Contingencies

[0001564590-20-042032:notes:210]
Purchase Commitments

[0001564590-20-042032:notes:211]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2020, the Company had non-cancelable commitments to purchase $38.0 million of inventory other services, which will be received and consumed during the first half of fiscal 2021. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0001564590-20-042032:notes:212]
Legal Proceedings

[0001564590-20-042032:notes:213]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-20-042032:notes:214]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-20-042032:notes:215]
All currency conversions in this Legal Proceedings section are as of June 30, 2020.

[0001564590-20-042032:notes:216]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-20-042032:notes:217]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is set for November 23, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-20-042032:notes:218]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-20-042032:notes:219]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents.  After a hearing on January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company.  Orckit filed a notice of appeal on March 13, 2020 and submitted their Grounds of Appeal on April 20, 2020.  Extreme filed its response to the Appeal on July 8, 2020.

[0001564590-20-042032:notes:220]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  The Company filed a nullity action with the German Federal Patent Court, seeking to invalidate the asserted patent.  Orckit has filed its substantive reasons for opposing the Company’s nullity action on June 11, 2020.   A hearing for the EP ‘077 infringement case has been scheduled for September 29, 2020.

[0001564590-20-042032:notes:221]
The Company believes that all claims in both cases are without merit and intends to defend them vigorously.

[0001564590-20-042032:notes:222]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co.

[0001564590-20-042032:notes:223]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China.  In each lawsuit, GIA has accused a number of Summit switching products of infringing one of six patents.  The parties reached a settlement in these cases, and all six cases have been dismissed.

[0001564590-20-042032:notes:224]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

[0001564590-20-042032:notes:225]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.4 million). The trial originally scheduled for November 15, 2019 has been postponed by the Court, pending the jurisdictional objections filed by Aerohive.  The Court rejected the jurisdictional challenge, and Aerohive appealed. A first hearing in the trial was held on July 30, 2020, and the Court subsequently scheduled a second hearing for September 4, 2020.

[0001564590-20-042032:notes:226]
The Company believes that the claims are without merit and intends to defend them vigorously.  The Company cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-042032:notes:227]
Proven Networks, LLC v. Extreme Networks, Inc.

[0001564590-20-042032:notes:228]
On March 24, 2020, Proven Networks, LLC (“Proven”) filed a patent infringement lawsuit against the Company in the Northern District of California. The lawsuit alleges direct and indirect infringement of three U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of Extreme Analytics Extreme XOS, and certain network devices equipped with the Extreme XOS operating system.  Proven seeks injunctive relief, unspecified damages, pre- and post-judgment interest, and attorneys’ fees.  The Company believes that the claims are without merit and intends to defend them vigorously.

[0001564590-20-042032:notes:229]
A hearing on the Company’s motion to dismiss is scheduled for October 15, 2020.  Given the uncertainty of litigation and the preliminary stage of the case, the Company cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-042032:notes:230]
DataCloud Technologies, LLC. v. Extreme Networks, Inc.

[0001564590-20-042032:notes:231]
On June 5, 2020, DataCloud Technologies, LLC. (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware.  The lawsuit alleges direct infringement of four U.S. patents based on Company’s shipping, distributing, making, using, importing, offering for sale, and/or selling of Extreme SLX Insight Architecture, Extreme Management Center, ExtremeSwitching switches, and ExtremeCloud Subscription Service.  DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-042032:notes:232]
American Patents LLC v. Extreme Networks, Inc.

[0001564590-20-042032:notes:233]
On August 14, 2020, American Patents LLC filed a patent infringement lawsuit against the Company in the Western District of Texas.  The complaint alleges direct and indirect infringement of certain U.S. patents and seeks injunctive relief, unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-042032:notes:234]
Indemnification Obligations

[0001564590-20-042032:notes:235]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-20-042032:notes:236]
11. Stockholders’ Equity

[0001564590-20-042032:notes:237]
Preferred Stock

[0001564590-20-042032:notes:238]
In April 2001, in connection with the entering into of the Company’s Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors (the “Board”) is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2020, no shares of preferred stock were outstanding.

[0001564590-20-042032:notes:239]
Stockholders’ Rights Agreement

[0001564590-20-042032:notes:240]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (as amended, the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0001564590-20-042032:notes:241]
The Company’s Board of Directors adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 8, 2020, to extend the Restated Rights Plan through May 31, 2021, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting.

[0001564590-20-042032:notes:242]
Equity Incentive Plan

[0001564590-20-042032:notes:243]
The Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan to increase the maximum number of available shares by 7.0 million shares.  The amendment was ratified by a majority of the stockholders at the Company’s annual meeting of stockholders held on November 7, 2019.

[0001564590-20-042032:notes:244]
Employee Stock Purchase Plan

[0001564590-20-042032:notes:245]
The Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares.  The amendment was ratified by a majority of the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018.

[0001564590-20-042032:notes:246]
Common Stock Repurchases

[0001564590-20-042032:notes:247]
On November 2, 2018, the Company announced that the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions.  A maximum of $35.0 million of the Company’s common stock may be repurchased in any calendar year. In February 2020, the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020.  The maximum repurchase in any year was decreased to $30.0 million.

[0001564590-20-042032:notes:248]
In November 2019, the Company entered into an accelerated share repurchase agreement (the “November 2019 ASR”) to repurchase shares of the Company’s common stock.  Pursuant to the November 2019 ASR, the Company paid $30.0 million for an initial delivery of 3.9 million shares valued at $25.2 million. The remaining balance of $4.8 million was recorded in additional paid-in-capital as a forward contract in the Company’s common stock. The forward contract was settled on January 24, 2020 and the Company received an additional 0.4 million shares of its common stock.  Total shares repurchased under the November 2019 ASR were 4.2 million shares at an average cash purchase price paid of $7.09.

[0001564590-20-042032:notes:249]
The following table summarizes the Company's shares repurchases under its stock repurchase program (in thousands, except per share amounts):

[0001564590-20-042032:notes:250]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Total number of shares repurchased |  |  | 4,232 |  |  |  | 2,366 |  |
| Average price paid per share |  | $ | 7.09 |  |  | $ | 6.34 |  |
| Dollar value of shares repurchased |  | $ | 30,000 |  |  | $ | 15,000 |  |
| Dollar value of shares that may yet be repurchased under program |  | $ | 55,000 |  |  | $ | 45,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-042032:notes:251]
12. Employee Benefit Plans

[0001564590-20-042032:notes:252]
As of June 30, 2020, the Company has the following share-based compensation plans:

[0001564590-20-042032:notes:253]
2013 Equity Incentive Plan

[0001564590-20-042032:notes:254]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, up to 12.7 million shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan.  The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting.  During the fiscal year ended 2020 an additional 7.0 million shares were authorized and made available for grant under the 2013 Plan. As of June 30, 2020, total options and awards to acquire 9.3 million shares were outstanding under the 2013 Plan and 13.1 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0001564590-20-042032:notes:255]
Enterasys 2013 Stock Plan

[0001564590-20-042032:notes:256]
Pursuant to the acquisition of Enterasys on October 31, 2013, the Company assumed the Enterasys 2013 Stock Plan (the “Enterasys Plan”).  As of June 30, 2020, total options to acquire 0.6 million shares were outstanding under the Enterasys Plan. Options granted under this plan have a contractual term of seven years. No future grants may be made from the Enterasys Plan.

[0001564590-20-042032:notes:257]
Aerohive 2014 Equity Incentive Plan

[0001564590-20-042032:notes:258]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the "Aerohive Plan").  Stock awards outstanding under the Aerohive Plan were converted into awards for Extreme shares as of the Acquisition Date at a predetermined rate pursuant to the Merger Agreement.  As of  June 30, 2020, total awards to acquire 0.5 million shares of Extreme common stock were outstanding under the Aerohive Plan.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0001564590-20-042032:notes:259]
Shares Reserved for Issuance

[0001564590-20-042032:notes:260]
The following are shares reserved for issuance (in thousands):

[0001564590-20-042032:notes:261]
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 13,118 |  |  |  | 8,462 |  |
| Employee stock options and awards outstanding |  |  | 10,396 |  |  |  | 10,455 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,364 |  |  |  | 10,085 |  |
| Total shares reserved for issuance |  |  | 30,878 |  |  |  | 29,002 |  |

[0001564590-20-042032:notes:262]
Stock Options

[0001564590-20-042032:notes:263]
The following table summarizes stock option activity under all plans (shares and intrinsic value in thousands):

[0001564590-20-042032:notes:264]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2019 |  |  | 2,719 |  |  | $ | 4.61 |  |  |  | 3.26 |  |  | $ | 5,070 |  |
| Granted |  |  | 637 |  |  |  | 6.70 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (217 | ) |  |  | 4.58 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (217 | ) |  |  | 6.07 |  |  |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2020 |  |  | 2,922 |  |  | $ | 4.95 |  |  |  | 3.09 |  |  | $ | 1,688 |  |
| Vested and expected to vest at June 30, 2020 |  |  | 2,922 |  |  | $ | 4.95 |  |  |  | 3.09 |  |  | $ | 1,688 |  |
| Exercisable at June 30, 2020 |  |  | 1,682 |  |  | $ | 3.78 |  |  |  | 1.18 |  |  | $ | 1,688 |  |

[0001564590-20-042032:notes:265]
The total intrinsic value of options exercised in fiscal years 2020, 2019 and 2018 was $0.6 million, $0.8 million and $6.3 million, respectively.

[0001564590-20-042032:notes:266]
The weighted average estimated fair value of stock options granted in fiscal year 2020 was $3.52. The weighted average estimated fair value of stock options granted in fiscal year 2019 was $2.62 per share. There were no stock options granted in fiscal 2018.  As of June 30, 2020, there was $1.8 million of total unrecognized compensation cost related to unvested stock options that will be recognized over a weighted-average period of 4.1 years.

[0001564590-20-042032:notes:267]
Stock Options – Performance Stock Options

[0001564590-20-042032:notes:268]
During the first quarter of fiscal 2019, the Company granted 851,700 Performance Stock Options (“PSOs”) to certain officers and executive vice presidents that will vest if the Company’s stock price achieves a price hurdle of $10.00 during the three-year performance period from August 29, 2018 through August 31, 2021. The price hurdle will be deemed to have been achieved if, at any time over the performance period, the Company’s stock maintains a price of $10.00 for 30 consecutive days.  If the price hurdle is achieved, the PSOs will vest and will have expense recognized (ratably based upon the time elapsed between August 31, 2018 and the date the hurdle is met) and the remainder will vest and have expense recognized quarterly through August 31, 2021.  The grant date fair value was $2.62.

[0001564590-20-042032:notes:269]
Stock Awards

[0001564590-20-042032:notes:270]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (“RSUs”), including performance-based or market-based restricted stock units (“PSUs”) which vest over a fixed period of time or based upon the satisfaction of certain performance criteria. The Company recognizes compensation expense on the awards over the vesting period based on the award’s intrinsic value as of the date of grant.

[0001564590-20-042032:notes:271]
The following table summarizes stock award activity (shares and market value in thousands):

[0001564590-20-042032:notes:272]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2019 |  |  | 7,736 |  |  | $ | 7.67 |  |  |  |  |  |
| Granted |  |  | 7,151 |  |  |  | 6.42 |  |  |  |  |  |
| Released |  |  | (3,956 | ) |  |  | 7.17 |  |  |  |  |  |
| Cancelled |  |  | (3,457 | ) |  |  | 7.58 |  |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2020 |  |  | 7,474 |  |  | $ | 6.83 |  |  | $ | 32,436 |  |
| Vested and expected to vest at June 30, 2020 |  |  | 6,793 |  |  | $ | 6.60 |  |  | $ | 29,480 |  |

[0001564590-20-042032:notes:273]
The aggregate fair value, as of the respective grant dates of awards granted during the years ended 2020, 2019 and 2018 was $45.9 million, $30.0 million and $51.2 million, respectively.

[0001564590-20-042032:notes:274]
For the fiscal years ended 2020, 2019 and 2018, the Company withheld an aggregate of 1.3 million shares, 1.3 million shares and 1.0 million shares, respectively, upon the vesting of awards, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0001564590-20-042032:notes:275]
For fiscal years ended 2020, 2019 and 2018, the Company remitted cash of $8.0 million, $8.4 million and $11.3 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0001564590-20-042032:notes:276]
As of June 30, 2020, there was $34.4 million in unrecognized compensation costs related to non-vested stock awards. This cost is expected to be recognized over a weighted-average period of 1.9 years.

[0001564590-20-042032:notes:277]
Stock Awards - Fiscal 2020

[0001564590-20-042032:notes:278]
The RSUs granted during the year ended June 30, 2020 vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company. These RSUs included 0.6 million RSUs to named executive officers and directors.

[0001564590-20-042032:notes:279]
Stock Awards - Fiscal 2019

[0001564590-20-042032:notes:280]
During fiscal 2019, the Company approved the grant of 0.9 million stock awards to its named executive officers and directors.  Of this amount, 0.2 million of these stock awards were in the form of PSUs and 0.7 million of the stock awards granted were in the form of service-based RSUs. In addition, 0.4 million PSU’s were also granted to other vice president level employees for a total to all employees of 0.6 million PSU’s, all of which had a grant date fair value of $6.40. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-20-042032:notes:281]
The PSUs referenced in the preceding paragraph will be considered earned once the Company’s U.S. GAAP earnings aggregates at least $0.20 per share over two consecutive quarters (the “2019 Performance Threshold”). During the second quarter of fiscal 2020, the compensation committee of the Board modified the Performance Thresholds of $0.20 earnings per share over two consecutive quarters for PSUs issued in fiscal 2019 and 2018, to $0.09 earnings per share over two consecutive quarters following a revision to the Company’s U.S. GAAP operating plan due to the acquisition of Aerohive. Upon satisfying the 2019 Performance Threshold, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the 2019 Performance Threshold is not met by the third anniversary of the grant date, the award is canceled.  In addition, the 2019 Performance Threshold will be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $10.00 per share. During the year ended June 30, 2020, none of the PSU grants referenced above achieved their 2019 Performance Threshold.

[0001564590-20-042032:notes:282]
Stock Awards - Fiscal 2018

[0001564590-20-042032:notes:283]
During fiscal 2018, the Company approved the grant of 1.2 million stock awards to its vice president level employees or above, including 0.6 million stock awards to its named executive officers.  Fifty percent (50%) of the stock awards granted to the executives, except the chief executive officer, were in the form of PSUs and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs.  The Company’s chief executive officer received sixty percent (60%) of his stock award grant in the form of PSUs, while forty percent (40%) of this award were in the form of RSUs. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-20-042032:notes:284]
The PSUs referenced in the preceding paragraph were originally considered to be earned once the Company’s U.S. GAAP earnings aggregates at least $0.32 per share over two consecutive quarters (the “2018 Performance Threshold”). During the third quarter of fiscal 2019, the compensation committee of the Board of Directors modified the 2018 Performance Threshold of $0.32 earnings per share over two consecutive quarters for PSUs issued in fiscal 2018, to $0.20 earnings per share over two consecutive quarters following a revision to the Company’s U.S. GAAP operating plan due to the acquisitions of the Campus Fabric and Data Center Businesses.  During the second quarter of fiscal 2020, the compensation committee of the Board of Directors modified the Performance Thresholds of $0.20 earnings per share over two consecutive quarters for PSUs issued in fiscal 2019 and 2018, to $0.09 earnings per share over two consecutive quarters following a revision to the Company’s U.S. GAAP operating plan due to the acquisition of Aerohive.  Upon satisfying the 2018 Performance Threshold, the PSUs were to vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, would vest on the same schedule as the RSUs, subject to continued service to the Company.  If the 2018 Performance Threshold is not met by the third anniversary of the grant date, the award is canceled.  None of the PSU grants referenced above achieved their 2018 Performance Threshold. These awards expired in August 2020.

[0001564590-20-042032:notes:285]
During fiscal 2018, the Company approved the grant of 0.1 million stock awards with market-based vesting criteria to certain executives with grant date fair values per share ranging from $10.61 to $12.19 determined by using the Monte-Carlo simulation model.

[0001564590-20-042032:notes:286]
Stock Awards - Performance Grant Activity

[0001564590-20-042032:notes:287]
The following table summarizes PSU’s with market or performance based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0001564590-20-042032:notes:288]
|  |  | Fiscal year 2020 |  |  | Fiscal year 2019 |  |  | Fiscal year 2018 |  |
| Performance awards granted |  |  | — |  |  |  | 635 |  |  |  | 714 |  |
| Performance awards earned |  |  | 56 |  |  |  | 342 |  |  |  | 566 |  |

[0001564590-20-042032:notes:289]
2014 Employee Stock Purchase Plan

[0001564590-20-042032:notes:290]
In August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. The Board of Directors unanimously approved an amendment to the 2014 ESPP to increase the maximum number of shares that will be available for sale by 7.5 million shares which was ratified by the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018. The 2014 ESPP replaced the 1999 Employee Stock Purchase Plan. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period had a maximum duration of six months. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. During the fiscal years ended June 30, 2020 and 2019, there were 2.7 million and 2.8 million shares issued under the 2014 ESPP.  As of June 30, 2020, there have been 12.1 million shares issued under the 2014 ESPP.

[0001564590-20-042032:notes:291]
Effective with the offering period beginning on February 1, 2016, the Company amended the 2014 ESPP to increase the maximum shares issuable for each purchase period from 1.0 million shares to 1.5 million shares. Effective with the offering period beginning on August 1, 2016, the Company amended the 2014 ESPP so that all future offering periods are limited to six months and to make certain other changes to the 2014 ESPP including adding new contribution limits for each offering period.

[0001564590-20-042032:notes:292]
Share-Based Compensation Expense

[0001564590-20-042032:notes:293]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (in thousands):

[0001564590-20-042032:notes:294]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Cost of product revenues |  | $ | 1,240 |  |  | $ | 844 |  |  | $ | 564 |  |
| Cost of service revenues |  |  | 1,620 |  |  |  | 1,639 |  |  |  | 1,131 |  |
| Research and development |  |  | 10,324 |  |  |  | 10,443 |  |  |  | 7,642 |  |
| Sales and marketing |  |  | 11,914 |  |  |  | 11,747 |  |  |  | 9,843 |  |
| General and administrative |  |  | 12,265 |  |  |  | 8,224 |  |  |  | 8,453 |  |
| Integration costs |  |  | 479 |  |  |  | — |  |  |  | — |  |
| Total share-based compensation expense |  | $ | 37,842 |  |  | $ | 32,897 |  |  | $ | 27,633 |  |

[0001564590-20-042032:notes:295]
The amount of share-based compensation expense capitalized in inventory has been immaterial for each of the periods presented.

[0001564590-20-042032:notes:296]
The Company uses the straight-line method for expense attribution, other than for the PSUs, using the accelerated attribution method. The Company does not estimate forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur.

[0001564590-20-042032:notes:297]
The fair value of each stock option grant under the Company’s 2013 Plan is estimated on the date of grant that uses the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-20-042032:notes:298]
The Company uses the simplified method to estimate the life of options and awards.  The Company uses the simplified method for all options and awards for all periods as it does not believe that historical exercise data provides a reasonable basis upon which to estimate the expected term.

[0001564590-20-042032:notes:299]
The fair value of each RSU grant with performance-based vesting criteria (“PSUs”) under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-20-042032:notes:300]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP shares is the offering period for each purchase. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-20-042032:notes:301]
The weighted-average estimated per share fair value of shares purchased under the 2014 ESPP in fiscal years 2020, 2019 and 2018, was $1.90, $2.71 and $3.25, respectively.

[0001564590-20-042032:notes:302]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 1.71 | % |  | 2.22%-2.46% |  |  | 1.15%-1.64% |  |
| Volatility |  |  | 43 | % |  |  | 70 | % |  |  | 42 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-20-042032:notes:303]
401(k) Plan

[0001564590-20-042032:notes:304]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $19,500 for calendar year 2020. Employees age 50 or over may elect to contribute an additional $6,500. The amount contributed to the Plan is on a pre-tax basis.

[0001564590-20-042032:notes:305]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately.  In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. The program during fiscal 2020 was initially established to match $0.50 for every Dollar contributed by the employee up to the first 2.5% of pay. The Company’s matching contributions to the Plan totaled $3.2 million, $4.2 million and $3.3 million, for fiscal years ended 2020, 2019 and 2018, respectively. No discretionary contributions were made in fiscal years ended 2020, 2019 and 2018.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-042032:notes:306]
13. Information about Segments of Geographic Areas

[0001564590-20-042032:notes:307]
The Company operates in one segment, the development and marketing of network infrastructure equipment.  Revenues are attributed to a geographical area based on the location of the customers.  The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan.  The Company’s chief operating decision maker (“CODM”), who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-20-042032:notes:308]
See Note 3. Revenues for the Company’s revenues by geographic regions and channel based on the customers’ ship-to location.

[0001564590-20-042032:notes:309]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-20-042032:notes:310]
| Long-lived Assets |  | June 30, 2020 |  |  | June 30, 2019 |  |
| Americas |  | $ | 177,443 |  |  | $ | 136,035 |  |
| EMEA |  |  | 39,477 |  |  |  | 28,744 |  |
| APAC |  |  | 16,802 |  |  |  | 11,529 |  |
| Total long-lived assets |  | $ | 233,722 |  |  | $ | 176,308 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-042032:notes:311]
14. Derivatives and Hedging

[0001564590-20-042032:notes:312]
Foreign Exchange Forward Contracts

[0001564590-20-042032:notes:313]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes.  The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying consolidated statements of operations. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. Gains and losses recorded in the consolidated statement of operations from these transactions during the fiscal years ended June 30, 2020, 2019, and  2018 were less than $0.1 million.

[0001564590-20-042032:notes:314]
At June 30, 2020, forward foreign currency contracts had a notional principal amount of $4.0 million. At June 30, 2019 the Company did not have any forward foreign currency contracts. These contracts had maturities of less than 30 days.  Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities. The Company recognized total foreign currency gains of $0.6 million in fiscal 2020 and $0.1 million in fiscal 2019 and losses of $1.2 million in fiscal 2018, related to the change in fair value of foreign currency denominated assets and liabilities.

[0001564590-20-042032:notes:315]
Interest Rate Swaps

[0001564590-20-042032:notes:316]
The Company is exposed to interest rate risk on its debt. The Company enters into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which has floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0001564590-20-042032:notes:317]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly

[0001564590-20-042032:notes:318]
effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive income (loss) and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0001564590-20-042032:notes:319]
During the fiscal year ended June 30, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt.  As of June 30, 2020, the total notional amount of these interest rate swaps was $200.0 million and had maturity dates through April 2023. As of June 30, 2020, these contracts had an unrealized loss of $1.8 million which is recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets and recorded in accumulated other comprehensive income (loss) in the consolidated financial statements. The Company did not have any interest rate swaps as of June 30, 2019. Realized gains and losses will be recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive income related to these cash flow hedges will be reclassified to interest expense over the life of the swap contracts. The Company estimates that $0.8 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measures.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-042032:notes:320]
15. Restructuring, Impairments, and Related Charges, Net of Reversals

[0001564590-20-042032:notes:321]
As of June 30, 2020 and June 30, 2019, restructuring liabilities were $2.2 million and $5.3 million, respectively, which are recorded in “Other accrued liabilities” and “Other long-term liabilities” in the accompanying consolidated balance sheets. The restructuring liabilities consist of obligations pertaining to the estimated future obligations for non-cancelable lease payments and severance and benefits obligations through June 30, 2019 and only severance and benefits obligations subsequent to the adoption of ASU 2016-02 Leases (Topic 842) on July 1, 2019.  During years ended 2020, 2019 and 2018, the Company recorded restructuring and impairment charges, net of reversals, of $22.0 million, $5.1 million and $8.1 million, respectively. The charges are reflected in “Restructuring, impairments, and related charges, net of reversals” in the consolidated statements of operations.

[0001564590-20-042032:notes:322]
2020 Restructuring and Impairment

[0001564590-20-042032:notes:323]
During fiscal 2020, the Company moved to reduce its operating expenses by exiting a floor in its San Jose, California headquarters facility and consolidating its workforce.  Also, the Company exited additional space in its Salem, New Hampshire facility, which includes general office and lab space. The Company continued its initiative to realign its operations resulting from the acquisition of Aerohive and consolidating its workforce and exiting the facility it acquired from Aerohive in Milpitas, California which includes general office and lab space.  The Company has the intent and ability to sub-lease these facilities which it has ceased using and as such, has considered estimated future sub-lease income based on its existing lease agreements, as well as the local real estate market conditions, in measuring the amount of asset impairment. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.

[0001564590-20-042032:notes:324]
With the global disruptions and slow-down in the demand of its products caused by the global pandemic outbreak, COVID-19, and the uncertainty around the timing of the recovery of the market, the Company initiated a reduction-in-force plan (the 2020 Plan) to reduce its operating costs and enhance financial flexibility. The plan affected approximately 320 employees primarily from the research and development and sales organizations who were located mainly in the U.S. and India. The Company recorded restructuring charges of $8.1 million during the fiscal year ended June 30, 2020 related to the 2020 Plan. The Company expects to incur additional charges related to this 2020 Plan through the first quarter of fiscal 2021. The costs associated with this restructuring plan primarily included employee severance and benefit expenses. The Company recorded additional severance and benefits charges of $5.4 million for the fiscal year ended June 30, 2020 related to the previous year’s restructuring plans.  In total the Company incurred $13.5 million in restructuring charges for the year ended June 30, 2020 which were all severance and benefit related. The Company expects the severance and benefits will be substantially paid by the end of fiscal 2021. In addition, the Company recorded facility impairment related charges of $8.5 million for the fiscal year ended June 30, 2020 which included $6.7 million for the impairment of ROU assets as referenced in the preceding paragraph, $0.9 million for impairment of long-lived assets, and $0.9 million of other charges related to previously impaired facilities.

[0001564590-20-042032:notes:325]
2019 Restructuring and Impairment

[0001564590-20-042032:notes:326]
The Company recorded a total of $5.1 million in restructuring and impairment charges during the year ended June 30, 2019. A reduction-in-force in its fourth fiscal quarter of fiscal 2019 was announced to better align its work force and operating expenses. Costs associated with the 2019 Plan are primarily comprised of employee severance and benefits expenses, relocation of personnel and equipment and exit of excess facilities. The Company recorded $3.7 million related to employee severance and benefits expenses during the year ended June 30, 2019 under the 2019 Plan. Also, $1.1 million of additional charges related to continuation of earlier actions associated with a reduction-in-force in the fourth quarter of fiscal 2018. The Company also incurred charges of $0.3 million for changes to its estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of its excess facilities.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.

[0001564590-20-042032:notes:327]
2018 Restructuring and Impairment

[0001564590-20-042032:notes:328]
The Company announced and executed a reduction-in-force in its third and fourth fiscal quarters of fiscal 2018 as a result of the acquisitions of the Campus Fabric Business and the Data Center Business. The Company recorded $7.9 million related to employee severance and benefits expenses during the year ended June 30, 2018.  The Company also incurred charges of $0.2 million for changes to its estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of its excess facilities.

[0001564590-20-042032:notes:329]
Restructuring liabilities consist of (in thousands):

[0001564590-20-042032:notes:330]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2017 |  | $ | 2,184 |  |  | $ | 1,853 |  |  | $ | 85 |  |  | $ | 4,122 |  |
| Period charges |  |  | 207 |  |  |  | 7,945 |  |  |  | — |  |  |  | 8,152 |  |
| Period reversals |  |  | — |  |  |  | — |  |  |  | (12 | ) |  |  | (12 | ) |
| Period payments |  |  | (594 | ) |  |  | (5,140 | ) |  |  | (73 | ) |  |  | (5,807 | ) |
| Balance as of June 30, 2018 |  | $ | 1,797 |  |  | $ | 4,658 |  |  | $ | — |  |  | $ | 6,455 |  |
| Period charges |  |  | 254 |  |  |  | 5,274 |  |  |  | — |  |  |  | 5,528 |  |
| Period reversals |  |  | — |  |  |  | (438 | ) |  |  | — |  |  |  | (438 | ) |
| Period payments |  |  | (287 | ) |  |  | (5,935 | ) |  |  | — |  |  |  | (6,222 | ) |
| Balance as of June 30, 2019 |  | $ | 1,764 |  |  | $ | 3,559 |  |  | $ | — |  |  | $ | 5,323 |  |
| Period charges |  |  | — |  |  |  | 14,875 |  |  |  | — |  |  |  | 14,875 |  |
| Period reversals |  |  | — |  |  |  | (1,369 | ) |  |  | — |  |  |  | (1,369 | ) |
| Reclassification to reduce operating lease assets |  |  | (1,764 | ) |  |  | — |  |  |  | — |  |  |  | (1,764 | ) |
| Period payments |  |  | — |  |  |  | (14,846 | ) |  |  | — |  |  |  | (14,846 | ) |
| Balance as of June 30, 2020 |  | $ | — |  |  | $ | 2,219 |  |  | $ | — |  |  | $ | 2,219 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-042032:notes:331]
16. Income Taxes

[0001564590-20-042032:notes:332]
Loss before income taxes is as follows (in thousands):

[0001564590-20-042032:notes:333]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | (143,651 | ) |  | $ | 22,330 |  |  | $ | (55,197 | ) |
| Foreign |  |  | 23,159 |  |  |  | (48,204 | ) |  |  | 8,550 |  |
| Loss before income taxes |  | $ | (120,492 | ) |  | $ | (25,874 | ) |  | $ | (46,647 | ) |

[0001564590-20-042032:notes:334]
The provision (benefit) for income taxes for the years ended 2020, 2019 and 2018 consisted of the following (in thousands):

[0001564590-20-042032:notes:335]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (22 | ) |  | $ | — |  |  | $ | (155 | ) |
| State |  |  | 256 |  |  |  | 655 |  |  |  | 521 |  |
| Foreign |  |  | 4,597 |  |  |  | 5,100 |  |  |  | 4,456 |  |
| Total current |  |  | 4,831 |  |  |  | 5,755 |  |  |  | 4,822 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 333 |  |  |  | (3,691 | ) |  |  | (6,358 | ) |
| State |  |  | 44 |  |  |  | (488 | ) |  |  | 294 |  |
| Foreign |  |  | 1,145 |  |  |  | (1,597 | ) |  |  | 1,387 |  |
| Total deferred |  |  | 1,522 |  |  |  | (5,776 | ) |  |  | (4,677 | ) |
| Provision (benefit) for income taxes |  | $ | 6,353 |  |  | $ | (21 | ) |  | $ | 145 |  |

[0001564590-20-042032:notes:336]
The difference between the provision (benefit) for income taxes and the amount computed by applying the federal statutory income tax rate (21 percent) to loss before taxes is explained below (in thousands):

[0001564590-20-042032:notes:337]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Tax at federal statutory rate |  | $ | (25,303 | ) |  | $ | (5,433 | ) |  | $ | (13,061 | ) |
| State income tax, net of federal benefit |  |  | 202 |  |  |  | 517 |  |  |  | 521 |  |
| Release of foreign valuation allowance |  |  | — |  |  |  | (2,794 | ) |  |  | — |  |
| Release of US valuation allowance – Tax reform |  |  | — |  |  |  | (4,680 | ) |  |  | — |  |
| Establishment of Irish valuation allowance |  |  | — |  |  |  | 8,642 |  |  |  | — |  |
| US valuation allowance change – deferred tax movement |  |  | 2,414 |  |  |  | (4,444 | ) |  |  | 25,302 |  |
| Research and development credits |  |  | (4,947 | ) |  |  | (6,598 | ) |  |  | (7,311 | ) |
| Tax impact of foreign earnings |  |  | 7,687 |  |  |  | 10,562 |  |  |  | (1,065 | ) |
| Stock based compensation |  |  | 4,349 |  |  |  | 2,436 |  |  |  | (5,901 | ) |
| Goodwill amortization |  |  | 331 |  |  |  | 834 |  |  |  | 2,004 |  |
| Nondeductible officer compensation |  |  | 862 |  |  |  | 713 |  |  |  | 1,927 |  |
| Nondeductible meals and entertainment |  |  | 364 |  |  |  | 517 |  |  |  | 510 |  |
| AMT credit monetization |  |  | (22 | ) |  |  | — |  |  |  | (155 | ) |
| Deferred tax liability release - Tax reform |  |  | — |  |  |  | — |  |  |  | (2,482 | ) |
| Gain on transfer of intellectual property ("IP") |  |  | 19,819 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 597 |  |  |  | (293 | ) |  |  | (144 | ) |
| Provision (benefit) for income taxes |  | $ | 6,353 |  |  | $ | (21 | ) |  | $ | 145 |  |

[0001564590-20-042032:notes:338]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001564590-20-042032:notes:339]
|  |  | June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2018 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 74,548 |  |  | $ | 36,514 |  |  | $ | 49,429 |  |
| Tax credit carry-forwards |  |  | 67,364 |  |  |  | 54,745 |  |  |  | 48,093 |  |
| Depreciation |  |  | 2,755 |  |  |  | 2,168 |  |  |  | 1,422 |  |
| Intangible amortization |  |  | 32,642 |  |  |  | 36,882 |  |  |  | 35,107 |  |
| Deferred revenue, net |  |  | 7,610 |  |  |  | 1,887 |  |  |  | 159 |  |
| Inventory write-downs |  |  | 13,014 |  |  |  | 10,277 |  |  |  | 13,682 |  |
| Other allowances and accruals |  |  | 32,318 |  |  |  | 30,210 |  |  |  | 25,700 |  |
| Stock based compensation |  |  | 3,169 |  |  |  | 4,114 |  |  |  | 4,872 |  |
| Deferred intercompany gain |  |  | 3,693 |  |  |  | 3,693 |  |  |  | — |  |
| Irish goodwill amortization |  |  | 7,132 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 888 |  |  |  | 673 |  |  |  | 3,219 |  |
| Total deferred tax assets |  |  | 245,133 |  |  |  | 181,163 |  |  |  | 181,683 |  |
| Valuation allowance |  |  | (232,862 | ) |  |  | (169,343 | ) |  |  | (177,869 | ) |
| Total net deferred tax assets |  |  | 12,271 |  |  |  | 11,820 |  |  |  | 3,814 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill amortization |  |  | (6,691 | ) |  |  | (4,904 | ) |  |  | (3,363 | ) |
| Prepaid commissions |  |  | (1,958 | ) |  |  | (1,585 | ) |  |  | (1,034 | ) |
| Deferred tax liability on foreign withholdings |  |  | (551 | ) |  |  | (505 | ) |  |  | (357 | ) |
| Total deferred tax liabilities |  |  | (9,200 | ) |  |  | (6,994 | ) |  |  | (4,754 | ) |
| Net deferred tax assets (liabilities) |  | $ | 3,071 |  |  | $ | 4,826 |  |  | $ | (940 | ) |
| Recorded as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net non-current deferred tax assets |  |  | 5,405 |  |  |  | 6,783 |  |  |  | 5,195 |  |
| Net non-current deferred tax liabilities |  |  | (2,334 | ) |  |  | (1,957 | ) |  |  | (6,135 | ) |
| Net deferred tax assets (liabilities) |  | $ | 3,071 |  |  | $ | 4,826 |  |  | $ | (940 | ) |

[0001564590-20-042032:notes:340]
The Company’s global valuation allowance increased by $63.5 million in the fiscal year ended June 30, 2020 and decreased by $8.5 million in the fiscal year ended June 30, 2019. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against certain non-U.S. deferred tax assets in Ireland and Brazil.  The valuation allowance is determined by assessing both negative and positive available evidence to assess whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends and the cyclical nature of the Company's business provides sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001564590-20-042032:notes:341]
As of June 30, 2020, the Company had net operating loss carry-forwards for U.S. federal and state tax purposes of $287.5 million and $156.4 million, respectively.  As of June 30, 2020, the Company also had foreign net operating loss carry-forwards in Ireland, Australia and Brazil of $21.0 million, $7.6 million and $0.7 million, respectively.  As of June 30, 2020, the Company also had federal and state tax credit carry-forwards of $43.8 million and $29.8 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits.  The U.S. federal net operating loss carry-forwards of $287.5 million will begin to expire in the fiscal year ending June 30, 2027 and state net operating losses of $156.4 million will begin to partially expire in the fiscal year ending June 30, 2021. The foreign net operating losses can generally be carried forward indefinitely.  Federal research and development tax credits of $32.9 million will expire beginning in fiscal 2021, if not utilized and foreign tax credits of $10.9 million will expire beginning in fiscal 2021.  North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2024, if not utilized. California state research and development tax credits of $28.9 million do not expire and can be carried forward indefinitely.

[0001564590-20-042032:notes:342]
In May 2020, the Company performed an Internal Revenue Code (“IRC”) section 382 analysis with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2019, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes. The Company also performed in June 2020 a separate IRC section 382 analysis with respect to the NOLs and tax credits acquired from Aerohive and have determined that while the Company will be subject to an annual limitation, the Company should not be limited on the full utilization of the losses and credits during the statutory allowable carryforward period of the NOLs and credits.

[0001564590-20-042032:notes:343]
As of June 30, 2020, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $9.1 million.  It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the U.S.  The Company is reviewing its prior position on the reinvestment of earnings of certain foreign subsidiaries but has recorded a deferred tax liability of $0.6 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential withholding tax associated with repatriation of these earnings as well as the deemed repatriation related to Tax Reform is $4.8 million.

[0001564590-20-042032:notes:344]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business, the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire, Texas and North Carolina. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.

[0001564590-20-042032:notes:345]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in the United States.  The CARES Act, among other things, includes modifications to net operating loss carryforward provisions and net interest expense deductions, and allows deferment of employer social security tax payments.  The Company has evaluated the provisions of the CARES Act and how certain elections may impact our financial position and results of operations, and have determined the enactment of the CARES Act did not have a material impact to our income tax provision for the fiscal year ended June 30, 2020, or to our net deferred tax assets as of June 30, 2020.

[0001564590-20-042032:notes:346]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, was effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, the provisions impacted the fiscal years ending June 30, 2019 and forward. The TCJA introduced significant changes to U.S. income tax law including a reduction in the U.S. federal corporate income tax rate from 35% to 21%, limitations on the deductibility of interest expense and executive compensation, implementation of a modified territorial tax regime, and imposition of a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.

[0001564590-20-042032:notes:347]
The TCJA created new minimum taxes including the Base-Erosion and Anti-abuse Tax (“BEAT”) and the Global Intangible Low Taxed Income (“GILTI”).  The BEAT provisions eliminate the deduction of certain base-erosion payments made to related foreign corporations, and impose a minimum tax if greater than regular tax. The Company was not subject to the BEAT provisions during the fiscal year ended June 30, 2020. The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred. In fiscal year 2020, under the GILTI provisions, the Company did recognize income related to its foreign subsidiaries, though it was fully offset by existing net operating loss carryforwards.

[0001564590-20-042032:notes:348]
In the first quarter of fiscal 2020, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs. In the fourth quarter of fiscal 2019, the Company recognized a deferred tax asset relating to a transfer of certain assets from the U.S. parent company to its wholly-owned Irish subsidiary of $7.2 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to the Company’s consolidated statement of operations.

[0001564590-20-042032:notes:349]
During the fiscal year ended June 30, 2014, the Company acquired the stock of Enterasys Networks, Inc. and as such they became a wholly owned subsidiary of Extreme Networks.  With respect to this acquisition, the Company made an election under Internal Revenue Code section 338(h)(10) to treat the acquisition as an asset purchase from a tax perspective.  Under this election the tax basis of all assets is effectively reset to that of fair market value and therefore the transaction did not result in the recording of an opening net deferred tax position as the Company's tax basis in the acquired assets equaled its book basis. The resulting intangible assets and goodwill are being amortized for tax purposes over 15 years.

[0001564590-20-042032:notes:350]
Additionally, the Company completed the acquisitions of the WLAN Business, the Campus Fabric Business and the Data Center Business in October 2016, July 2017 and October 2017, respectively, and treats the acquisitions as asset purchases from a tax perspective. The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.

[0001564590-20-042032:notes:351]
On August 9, 2019, the Company completed its acquisition of Aerohive. This acquisition was treated as a non-taxable stock acquisition and therefore Extreme Networks has carryover tax basis in the assets and liabilities acquired.  During the fourth quarter of fiscal 2020 following the acquisition of Aerohive, the Company realigned the Aerohive related non-American intellectual property (“IP”) rights to correspond with the Company’s global operating model.  This transaction resulted in recognition of a $75 million U.S. tax gain which was fully consumed by existing NOLs and the intangibles transferred are being amortized over 10 years for Irish statutory purposes.

[0001564590-20-042032:notes:352]
During the twelve months ended June 30, 2020, the Company deducted $7.6 million of tax amortization expense related to capitalized goodwill resulting from the above acquisitions.

[0001564590-20-042032:notes:353]
As of June 30, 2020, the Company had $23.9 million of unrecognized tax benefits.  If fully recognized in the future, $0.5 million would impact the effective tax rate, and $23.4 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance.  The Company does not reasonably expect the amount of unrealized tax benefits to decrease during the next twelve months. The increase for fiscal year 2020 relates substantially to the acquisition of Aerohive.

[0001564590-20-042032:notes:354]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001564590-20-042032:notes:355]
| Balance at June 30, 2017 |  | $ | 18,913 |  |
| Decrease related to prior year tax positions |  |  | (1,407 | ) |
| Balance at June 30, 2018 |  |  | 17,506 |  |
| Increase related to prior year tax positions |  |  | 26 |  |
| Lapse of statute of limitations |  |  | (364 | ) |
| Balance at June 30, 2019 |  |  | 17,168 |  |
| Increase related to prior year tax positions |  |  | 8,906 |  |
| Increase related to current year tax positions |  |  | 44 |  |
| Decrease related to prior year tax positions |  |  | (1,800 | ) |
| Lapse of statute of limitations |  |  | (421 | ) |
| Balance at June 30, 2020 |  | $ | 23,897 |  |

[0001564590-20-042032:notes:356]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of tax expense in the consolidated statements of operations and totaled less than $0.1 million for each of the years ended 2020, 2019 and 2018.


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-042032:notes:357]
17. Net Loss Per Share

[0001564590-20-042032:notes:358]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to options and unvested restricted stock.

[0001564590-20-042032:notes:359]
The following table presents the calculation of basic and diluted net loss per share (in thousands, except per share data):

[0001564590-20-042032:notes:360]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Net loss |  | $ | (126,845 | ) |  | $ | (25,853 | ) |  | $ | (46,792 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 119,814 |  |  |  | 117,954 |  |  |  | 114,221 |  |
| Net loss per share - basic and diluted |  | $ | (1.06 | ) |  | $ | (0.22 | ) |  | $ | (0.41 | ) |

[0001564590-20-042032:notes:361]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.  Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net loss per share since the effect of including them would have been anti-dilutive due to the net loss position of the Company during the periods presented.

[0001564590-20-042032:notes:362]
The following securities were excluded from the computation of outstanding diluted earnings per common share because they would have been anti-dilutive (in thousands):

[0001564590-20-042032:notes:363]
|  |  | Year Ended |  |
|  |  | June 30, 2020 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Options to purchase common stock |  |  | 3,036 |  |  |  | 2,693 |  |  |  | 2,547 |  |
| Restricted stock units |  |  | 8,103 |  |  |  | 8,337 |  |  |  | 7,822 |  |
| Employee Stock Purchase Plan shares |  |  | 553 |  |  |  | 612 |  |  |  | 1,294 |  |
| Total shares excluded |  |  | 11,692 |  |  |  | 11,642 |  |  |  | 11,663 |  |
