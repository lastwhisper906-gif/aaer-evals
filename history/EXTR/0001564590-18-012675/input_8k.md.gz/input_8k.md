# EXTR 8-K — 0001564590-18-011817 filed 2018-05-08

## item codes, every 8-K on or before 2018-05-10

- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2018-05-10

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-011817:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-18-011817:8k_2_02:2]
extr-ex991_6.htm

[0001564590-18-011817:8k_2_02:3]
Exhibit 99.1

[0001564590-18-011817:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-18-011817:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Stan Kovler |  | Media Contact Christi Nicolacopoulos |
| 919/595-4196 |  | 603/952-5005 |
| Investor relations@extremenetworks.com |  | pr@extremenetworks.com |

[0001564590-18-011817:8k_2_02:6]
Extreme Networks Reports Third Quarter Fiscal Year 2018 Financial Results

[0001564590-18-011817:8k_2_02:7]
SAN JOSE, Calif., May 8, 2018 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal third quarter ended March 31, 2018.

[0001564590-18-011817:8k_2_02:8]
Third Quarter Results:

[0001564590-18-011817:8k_2_02:9]
|  | • | Third quarter revenue was $262.0 million, an increase of 76% year-over-year. |

[0001564590-18-011817:8k_2_02:10]
|  | • | GAAP gross margin for the third fiscal quarter was 54.6%, a decrease of 90 basis points year-over-year, and non-GAAP gross margin was 57.9% year-over-year, an increase of 70 basis points year-over-year. |

[0001564590-18-011817:8k_2_02:11]
|  | • | GAAP operating margin for the third fiscal quarter was (3.1) % and non-GAAP operating margin was 9.3%, compared to (1.8) % and 9.8% , respectively, year-over-year. |

[0001564590-18-011817:8k_2_02:12]
|  | • | GAAP net loss for the third fiscal quarter was $13.6 million, or $0.12 per basic share, a decrease of $8.6 million and $0.07 per basic share, respectively, year-over-year. Non-GAAP net income was $19.0 million, or $0.16 per diluted share, an increase of $6.8 million and $0.05 per diluted share, respectively, year-over-year. |

[0001564590-18-011817:8k_2_02:13]
“We made significant progress continuing to build the “new” Extreme in the third fiscal quarter with year-over-year revenue growth and non-gaap gross margin improvement, hitting all of our critical milestones associated with the systems integration of our newly acquired assets,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-18-011817:8k_2_02:14]
“We achieved organic growth of 8% in core Extreme revenue, driven by strength in our wireless business, and 10% sequential growth in our acquired Campus Fabric revenue. Given strong demand, we built our order backlog by over $7M during the quarter. We expect improvement in our gross margins in our last fiscal quarter of 2018 as we continue to approach our 60% target in addition to significant sequential and year-over-year quarterly revenue growth.”

[0001564590-18-011817:8k_2_02:15]
"On January 15th we successfully completed the migration of the data and IT systems of the acquired Data Center assets and on April 9th, we completed a similar migration of the acquired Campus Fabric assets.  The migration was on schedule with orders being booked, billed, and shipped on the first day of the cut-

[0001564590-18-011817:8k_2_02:16]
over.  And we relocated approximately 265 employees into our newly renovated San Jose campus as planned on April 30th.  This completed our IT integration efforts following our recent acquisitions and we are now tracking and operating in one instance of our ERP system and procurement systems. Our teams have done an outstanding job driving our business while managing these large and complex integration initiatives."

[0001564590-18-011817:8k_2_02:17]
“Finally, Meyercord added, our recent acquisitions are meaningfully strengthening our brand, our competitive position and our technology differentiation in the market evidenced by significant growth in our pipeline, which includes many cross-selling opportunities. In our fourth fiscal quarter, we expect to deliver continued year-over-year organic growth in our core Extreme business with less seasonality in our fourth fiscal quarter than prior years due to revenue trends from our acquired assets.  After reviewing our pipeline we anticipate we will remain on track to meet or exceed our annual target of $430 million of newly acquired revenue from our recent acquisitions.  Looking out into fiscal 2019, we remain on track to grow revenue 3 to 5% in the combined portfolio as compared to our second-half 2018 run-rate” Meyercord added.

[0001564590-18-011817:8k_2_02:18]
Recent Key Highlights:

[0001564590-18-011817:8k_2_02:19]
|  | • | Concord Hospital a large regional hospital system, serves half a million patients and over 5,000 network users across 30 locations. Concord deployed Extreme Networks Fabric Connect to achieve the self-networking benefits of MPLS without the cost and complexity. Extreme’s Fabric Connect gives Concord the ability to secure and protect sensitive data with network segmentation and run as many as 3,000 IoT devices on the network at any one time. |

[0001564590-18-011817:8k_2_02:20]
|  | • | MetLife Stadium, part of the Meadowlands Sports Complex, serves as the home stadium for two National Football League (NFL) franchises: the New York Giants and the New York Jets, with a capacity of 82,500 seats. Metlife deployed Extreme Ethernet switches running XOS with Extreme Management Center (XMC) and ExtremeAnalytics to support an upgraded audio network and additional services. Extreme’s switches continue to support 3rd party technologies such as Wi-Fi, VoIP and distributed video and content. |

[0001564590-18-011817:8k_2_02:21]
|  | • | Oral Roberts University, a leading college in Tulsa, Oklahoma, relies on Extreme Networks educational networking solutions. to power extraordinary social, academic and cultural experiences for students, faculty and staff that can be accessed via smartphones while on campus. Exceptional service is ensured via the use of ExtremeAnalytics™, which allows network managers to see campus-wide traffic patterns, dwell times and more, via a single dashboard, and make adjustments in real-time. ORU has leveraged Extreme solutions to offer cutting-edge digital learning initiatives since 2017, and has since landed seven awards for technology design and effectiveness, including the Campus Technology 2017 Impact Award and 2018 Ellucian Technology Award for Global Impact. |

[0001564590-18-011817:8k_2_02:22]
|  | • | Extreme Networks introduced ExtremeLocation™, a solution that allows retailers to identify, engage and provide personalized guest experiences in-store via shoppers' mobile devices. This offering brings a new level of insight to retail customers by collecting contextual analytics from both Wi-Fi and BLE beacon technology. |

[0001564590-18-011817:8k_2_02:23]
|  | • | Extreme Networks completed its Extreme Now world tour bringing its leadership team directly to customers in 55 cities in 22 countries. The Now tour culminated in Extreme’s global user conference, Extreme Connect, held in Scottsdale, Arizona in late April. At Connect, over 350 customers and partners across industries became Extreme Networks Certified Insider community members, networked with peers, and received technical training across Extreme’s edge, campus and data center solutions portfolio. |

[0001564590-18-011817:8k_2_02:24]
|  | • | On May 1, 2018, Extreme Networks, Inc. entered into a Credit Agreement that provides for a $40 million five-year revolving credit facility and a $190 million five-year term loan. On May 1, 2018, the Company borrowed approximately $200 million under the Senior Secured Credit Facilities in order to pay off existing debt and for general corporate purposes and to refinance at a 1.0% lower rate. The Senior Secured Credit Facilities will bear interest, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio. |

[0001564590-18-011817:8k_2_02:25]
Fiscal Q3 2018 Financial Metrics:

[0001564590-18-011817:8k_2_02:26]
(in millions, except percentages ad per share information)

[0001564590-18-011817:8k_2_02:27]
|  |  | Q3 FY'18 |  |  | Q3 FY'17 |  |  | Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 203.5 |  |  | $ | 111.3 |  |  | $ | 92.2 |  |  |  | 83 | % |
| Service |  |  | 58.5 |  |  |  | 37.9 |  |  |  | 20.6 |  |  |  | 54 | % |
| Total Net Revenue |  | $ | 262.0 |  |  | $ | 149.2 |  |  | $ | 112.8 |  |  |  | 76 | % |
| Gross Margin |  |  | 54.6 | % |  |  | 55.5 | % |  | -90 bps |  |  |  | (2 | )% |
| Operating Margin |  |  | (3.1 | )% |  |  | (1.8 | )% |  | -134 bps |  |  |  | (74 | )% |
| Net Loss |  | $ | (13.6 | ) |  | $ | (5.0 | ) |  | $ | (8.6 | ) |  |  | (172 | )% |
| Loss per basic and diluted share |  | $ | (0.12 | ) |  | $ | (0.05 | ) |  | $ | (0.07 | ) |  |  | (140 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 203.5 |  |  | $ | 111.3 |  |  | $ | 92.2 |  |  |  | 83 | % |
| Service |  |  | 58.5 |  |  |  | 37.9 |  |  |  | 20.6 |  |  |  | 54 | % |
| Total Net Revenue |  | $ | 262.0 |  |  | $ | 149.2 |  |  | $ | 112.8 |  |  |  | 76 | % |
| Gross Margin |  |  | 57.9 | % |  |  | 57.2 | % |  | 70 bps |  |  |  | 1 | % |
| Operating Margin |  |  | 9.3 | % |  |  | 9.8 | % |  | -50 bps |  |  |  | (5 | )% |
| Net Income |  | $ | 19.0 |  |  | $ | 12.2 |  |  | $ | 6.8 |  |  |  | 55 | % |
| Earnings per diluted share |  | $ | 0.16 |  |  | $ | 0.11 |  |  | $ | 0.05 |  |  |  | 45 | % |

[0001564590-18-011817:8k_2_02:28]
|  | • | With the adoption of new revenue recognition accounting guidance (“ASC 606”) since July 1, FY’18, we have adjusted prior periods. The impact of these adjustments to the balance sheet and income statement, are noted with “as adjusted”. |

[0001564590-18-011817:8k_2_02:29]
|  | • | Cash and investments ended the quarter at $105.3 million, a decrease of $22.9 million from Q2 and a decrease of $12.0 million from Q3 last year, driven primarily by the funding of the acquisition of the Campus Fabric and Data Center businesses. |

[0001564590-18-011817:8k_2_02:30]
|  | • | Accounts receivable balance ending Q3 was $188.4 million, with days sales outstanding (“DSO”) of 65. |

[0001564590-18-011817:8k_2_02:31]
|  | • | Q3 ending inventory was $77.8 million, a decrease of $5.6 million from the prior quarter and an increase of $28.1 million from Q3 last year. |

[0001564590-18-011817:8k_2_02:32]
|  | • | Q3 ending debt was $178.7 million, a decrease of $4.5 million from Q2 and an increase of $83.8 million from Q3 last year, driven primarily by borrowings to fund Extreme's acquisitions of the Campus Fabric and Data Center businesses. |

[0001564590-18-011817:8k_2_02:33]
Business Outlook:

[0001564590-18-011817:8k_2_02:34]
For its fourth quarter of fiscal 2018, ending June 30, 2018, the Company is targeting revenue in a range of $277.0 million to $287.0 million.  GAAP gross margin is targeted between 56.0% and 58.1% and non-GAAP gross margin is targeted between 58.0% and 60.0%. Operating expenses are targeted to be between $148.6 million and $152.2 million on a GAAP basis and $136.5 million to $139.5 million on a non-GAAP basis. GAAP earnings are targeted to be between net income of $1.5 million to $9.6 million or a net income of $0.01 to $0.08 per diluted share.  Non-GAAP earnings are targeted in a range of net income of $19.2 million to $27.9 million, or $0.16 to $0.23 per diluted share. The GAAP and non-GAAP per share targets are based on 121.5 million average outstanding shares.

[0001564590-18-011817:8k_2_02:35]
The following table shows the GAAP to non-GAAP reconciliation for Q4 FY’18 guidance:

[0001564590-18-011817:8k_2_02:36]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 56.0% - 58.1% |  |  | 2.3% - 5.1% |  |  | $0.01-$0.08 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.7% |  |  | 1.7% |  |  | $ | 0.04 |  |
| Stock based compensation | 0.2% |  |  | 2.9% |  |  | $ | 0.07 |  |
| Amortization of non product intangibles | - |  |  | 0.6% |  |  | $ | 0.01 |  |
| Acquisition and integration costs | 0.1% |  |  | 1.2% |  |  | $ | 0.03 |  |
| Non-GAAP | 58.0% - 60.0% |  |  | 8.7% - 11.4% |  |  | $0.16 - $0.23 |  |

[0001564590-18-011817:8k_2_02:37]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-18-011817:8k_2_02:38]
Conference Call:

[0001564590-18-011817:8k_2_02:39]
Extreme will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the third fiscal quarter results as well as the fourth fiscal quarter ended June 30, 2018 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through May 7, 2019.  The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-

[0001564590-18-011817:8k_2_02:40]
GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406   Conference ID # 7777378.

[0001564590-18-011817:8k_2_02:41]
About Extreme Networks:

[0001564590-18-011817:8k_2_02:42]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, on premise or through the cloud, we go to extreme measures for our customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-18-011817:8k_2_02:43]
Extreme Networks and the Extreme Networks logo, Extreme Management Center, ExtremeWireless, ExtremeWireless WiNG, Extreme Secure Automated Campus, ExtremeControl, ExtremeAnalytics, and ExtremeCloud are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-18-011817:8k_2_02:44]
Non-GAAP Financial Measures:

[0001564590-18-011817:8k_2_02:45]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, executive transition costs, litigation expenses, other income and income tax.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-18-011817:8k_2_02:46]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-18-011817:8k_2_02:47]
Forward Looking Statements:

[0001564590-18-011817:8k_2_02:48]
forward-looking statements speak only as of the date of this release. Actual results or events could differ materially from those anticipated in those forward-looking statements as a result of certain factors, including: our ability to realize the anticipated benefits of the acquisition of the networking business from Avaya and the data center switching, routing and analytics business assets from Brocade; our ability to successfully integrate the acquired technologies and operations from Avaya and Brocade assets into our business and operations;  failure to achieve targeted revenues and forecasted demand from end customers; a highly competitive business environment for network switching equipment; our effectiveness in controlling expenses; the possibility that we might experience delays in the development or introduction of new technology and products; customer response to our new technology and products; risks related to pending or future litigation; and a dependency on third parties for certain components and for the manufacturing of our products.

[0001564590-18-011817:8k_2_02:49]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-18-011817:8k_2_02:50]
EXTREME NETWORKS, INC.

[0001564590-18-011817:8k_2_02:51]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-011817:8k_2_02:52]
(In thousands)

[0001564590-18-011817:8k_2_02:53]
(Unaudited)

[0001564590-18-011817:8k_2_02:54]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 103,177 |  |  | $ | 130,450 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,796 at March 31, 2018 and $1,190 at June 30, 2017 |  |  | 188,408 |  |  |  | 93,115 |  |
| Inventories |  |  | 77,756 |  |  |  | 47,410 |  |
| Prepaid expenses and other current assets |  |  | 26,659 |  |  |  | 27,867 |  |
| Total current assets |  |  | 396,000 |  |  |  | 298,842 |  |
| Property and equipment, net |  |  | 86,487 |  |  |  | 30,240 |  |
| Intangible assets, net |  |  | 85,406 |  |  |  | 25,337 |  |
| Goodwill |  |  | 129,244 |  |  |  | 80,216 |  |
| Other assets |  |  | 43,348 |  |  |  | 25,065 |  |
| Total assets |  | $ | 740,485 |  |  | $ | 459,700 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 24,720 |  |  | $ | 12,280 |  |
| Accounts payable |  |  | 90,800 |  |  |  | 31,587 |  |
| Accrued compensation and benefits |  |  | 40,591 |  |  |  | 42,662 |  |
| Accrued warranty |  |  | 12,812 |  |  |  | 10,584 |  |
| Deferred revenue, net |  |  | 117,741 |  |  |  | 79,048 |  |
| Other accrued liabilities |  |  | 77,042 |  |  |  | 37,044 |  |
| Total current liabilities |  |  | 363,706 |  |  |  | 213,205 |  |
| Deferred revenue, less current portion |  |  | 38,828 |  |  |  | 25,293 |  |
| Long-term debt, less current portion |  |  | 153,958 |  |  |  | 80,422 |  |
| Deferred income taxes |  |  | 5,628 |  |  |  | 6,576 |  |
| Other long-term liabilities |  |  | 65,440 |  |  |  | 8,526 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity |  |  | 112,925 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity |  | $ | 740,485 |  |  | $ | 459,700 |  |

[0001564590-18-011817:8k_2_02:55]
EXTREME NETWORKS, INC.

[0001564590-18-011817:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-011817:8k_2_02:57]
(In thousands, except per share amounts)

[0001564590-18-011817:8k_2_02:58]
(Unaudited)

[0001564590-18-011817:8k_2_02:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 203,527 |  |  | $ | 111,321 |  |  | $ | 543,151 |  |  | $ | 319,469 |  |
| Service |  |  | 58,477 |  |  |  | 37,875 |  |  |  | 161,691 |  |  |  | 108,708 |  |
| Total net revenues |  |  | 262,004 |  |  |  | 149,196 |  |  |  | 704,842 |  |  |  | 428,177 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 94,485 |  |  |  | 52,275 |  |  |  | 253,002 |  |  |  | 159,151 |  |
| Service |  |  | 24,536 |  |  |  | 14,117 |  |  |  | 67,490 |  |  |  | 40,684 |  |
| Total cost of revenues |  |  | 119,021 |  |  |  | 66,392 |  |  |  | 320,492 |  |  |  | 199,835 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 109,042 |  |  |  | 59,046 |  |  |  | 290,149 |  |  |  | 160,318 |  |
| Service |  |  | 33,941 |  |  |  | 23,758 |  |  |  | 94,201 |  |  |  | 68,024 |  |
| Total gross profit |  |  | 142,983 |  |  |  | 82,804 |  |  |  | 384,350 |  |  |  | 228,342 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 50,920 |  |  |  | 24,691 |  |  |  | 131,112 |  |  |  | 67,003 |  |
| Sales and marketing |  |  | 72,240 |  |  |  | 38,790 |  |  |  | 193,460 |  |  |  | 116,674 |  |
| General and administrative |  |  | 11,707 |  |  |  | 9,612 |  |  |  | 35,561 |  |  |  | 27,296 |  |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 9,316 |  |  |  | 3,418 |  |  |  | 47,675 |  |  |  | 9,908 |  |
| Restructuring and related charges, net of reversals |  |  | 4,920 |  |  |  | 7,719 |  |  |  | 4,920 |  |  |  | 9,572 |  |
| Amortization of intangibles |  |  | 2,101 |  |  |  | 1,193 |  |  |  | 6,461 |  |  |  | 7,510 |  |
| Total operating expenses |  |  | 151,204 |  |  |  | 85,423 |  |  |  | 419,189 |  |  |  | 237,963 |  |
| Operating loss |  |  | (8,221 | ) |  |  | (2,619 | ) |  |  | (34,839 | ) |  |  | (9,621 | ) |
| Interest income |  |  | 740 |  |  |  | 236 |  |  |  | 2,104 |  |  |  | 374 |  |
| Interest expense |  |  | (4,044 | ) |  |  | (1,177 | ) |  |  | (8,763 | ) |  |  | (3,000 | ) |
| Other income (expense), net |  |  | (359 | ) |  |  | (251 | ) |  |  | 2,125 |  |  |  | 551 |  |
| Loss before income taxes |  |  | (11,884 | ) |  |  | (3,811 | ) |  |  | (39,373 | ) |  |  | (11,696 | ) |
| Provision for income taxes |  |  | 1,729 |  |  |  | 1,166 |  |  |  | 1,787 |  |  |  | 3,252 |  |
| Net loss |  | $ | (13,613 | ) |  | $ | (4,977 | ) |  | $ | (41,160 | ) |  | $ | (14,948 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.12 | ) |  | $ | (0.05 | ) |  | $ | (0.36 | ) |  | $ | (0.14 | ) |
| Net loss per share - diluted |  | $ | (0.12 | ) |  | $ | (0.05 | ) |  | $ | (0.36 | ) |  | $ | (0.14 | ) |
| Shares used in per share calculation - basic |  |  | 115,059 |  |  |  | 109,213 |  |  |  | 113,641 |  |  |  | 107,531 |  |
| Shares used in per share calculation - diluted |  |  | 115,059 |  |  |  | 109,213 |  |  |  | 113,641 |  |  |  | 107,531 |  |

[0001564590-18-011817:8k_2_02:60]
EXTREME NETWORKS, INC.

[0001564590-18-011817:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-011817:8k_2_02:62]
(In thousands)

[0001564590-18-011817:8k_2_02:63]
(Unaudited)

[0001564590-18-011817:8k_2_02:64]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| Net cash (used in) provided by operating activities |  | $ | (1,730 | ) |  | $ | 43,961 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (21,999 | ) |  |  | (7,832 | ) |
| Business acquisitions |  |  | (97,581 | ) |  |  | (51,088 | ) |
| Proceeds from sale of non-marketable equity investment |  |  | 4,922 |  |  |  | — |  |
| Deposit related to an acquisition |  |  | — |  |  |  | (10,239 | ) |
| Net cash used in investing activities |  |  | (114,658 | ) |  |  | (69,159 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | 100,000 |  |  |  | 48,250 |  |
| Loan fees on borrowings |  |  | (1,494 | ) |  |  | (1,327 | ) |
| Repayments of debt |  |  | (13,278 | ) |  |  | (7,775 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 4,657 |  |  |  | 9,180 |  |
| Payments of contingent consideration |  |  | (671 | ) |  |  | — |  |
| Net cash provided by financing activities |  |  | 89,214 |  |  |  | 48,328 |  |
| Foreign currency effect on cash |  |  | (99 | ) |  |  | 28 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (27,273 | ) |  |  | 23,158 |  |
| Cash and cash equivalents at beginning of period |  |  | 130,450 |  |  |  | 94,122 |  |
| Cash and cash equivalents at end of period |  | $ | 103,177 |  |  | $ | 117,280 |  |

[0001564590-18-011817:8k_2_02:65]
Extreme Networks, Inc.

[0001564590-18-011817:8k_2_02:66]
Non-GAAP Measures of Financial Performance

[0001564590-18-011817:8k_2_02:67]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-18-011817:8k_2_02:68]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, restructuring charges, executive transition costs, litigation, amortization of acquired intangibles, other income and income tax.

[0001564590-18-011817:8k_2_02:69]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-18-011817:8k_2_02:70]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures to enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-18-011817:8k_2_02:71]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustment, amortization of intangibles, restructuring charges, executive transition costs, litigation, other income and income tax.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-18-011817:8k_2_02:72]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-18-011817:8k_2_02:73]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-18-011817:8k_2_02:74]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Wireless LAN business, b) Campus Fabric business, c) Data Center business and d) the bargain purchase gain for the capital financing business; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-18-011817:8k_2_02:75]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-18-011817:8k_2_02:76]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-18-011817:8k_2_02:77]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-18-011817:8k_2_02:78]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-18-011817:8k_2_02:79]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits.  The expenses are incurred through execution of pre-established employment contracts with senior executives.

[0001564590-18-011817:8k_2_02:80]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going litigation matters.

[0001564590-18-011817:8k_2_02:81]
Other income. Other income consists of the gain on the sale of our equity investment in a private company.

[0001564590-18-011817:8k_2_02:82]
Income tax.   Income tax adjustments relate to the tax impact of reducing the US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation as well as the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada.

[0001564590-18-011817:8k_2_02:83]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in

[0001564590-18-011817:8k_2_02:84]
Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-18-011817:8k_2_02:85]
EXTREME NETWORKS, INC.

[0001564590-18-011817:8k_2_02:86]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-011817:8k_2_02:87]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-18-011817:8k_2_02:88]
(In thousands, except percentages and per share amounts)

[0001564590-18-011817:8k_2_02:89]
(Unaudited)

[0001564590-18-011817:8k_2_02:90]
| Non-GAAP Revenue | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Revenue - GAAP Basis | $ | 262,004 |  |  | $ | 149,196 |  |  | $ | 704,842 |  |  | $ | 428,177 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Revenue - Non-GAAP Basis | $ | 262,004 |  |  | $ | 149,196 |  |  | $ | 704,842 |  |  | $ | 428,310 |  |

[0001564590-18-011817:8k_2_02:91]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Gross profit - GAAP Basis | $ | 142,983 |  |  | $ | 82,804 |  |  | $ | 384,350 |  |  | $ | 228,342 |  |
| Gross margin - GAAP Basis percentage |  | 54.6 | % |  |  | 55.5 | % |  |  | 54.5 | % |  |  | 53.3 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 517 |  |  |  | 129 |  |  |  | 1,172 |  |  |  | 737 |  |
| Purchase accounting adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Acquired inventory adjustments |  | 597 |  |  |  | 1,963 |  |  |  | 4,784 |  |  |  | 4,263 |  |
| Acquisition and integration costs |  | 3,068 |  |  |  | (413 | ) |  |  | 7,586 |  |  |  | 5,104 |  |
| Amortization of intangibles |  | 4,581 |  |  |  | 891 |  |  |  | 11,109 |  |  |  | 6,027 |  |
| Total adjustments to GAAP gross profit | $ | 8,763 |  |  | $ | 2,570 |  |  | $ | 24,651 |  |  | $ | 16,264 |  |
| Gross profit - Non-GAAP | $ | 151,746 |  |  | $ | 85,374 |  |  | $ | 409,001 |  |  | $ | 244,606 |  |
| Gross margin - Non-GAAP percentage |  | 57.9 | % |  |  | 57.2 | % |  |  | 58.0 | % |  |  | 57.1 | % |

[0001564590-18-011817:8k_2_02:92]
| Non-GAAP Operating Income | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| GAAP operating loss | $ | (8,221 | ) |  | $ | (2,619 | ) |  | $ | (34,839 | ) |  | $ | (9,621 | ) |
| GAAP operating loss percentage |  | (3.1 | )% |  |  | (1.8 | )% |  |  | (4.9 | )% |  |  | (2.2 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 7,818 |  |  |  | 2,474 |  |  |  | 19,646 |  |  |  | 9,328 |  |
| Acquisition and integration costs, net of bargain purchase gain |  | 12,384 |  |  |  | 3,005 |  |  |  | 55,261 |  |  |  | 15,012 |  |
| Restructuring charge, net of reversal |  | 4,920 |  |  |  | 7,719 |  |  |  | 4,920 |  |  |  | 9,572 |  |
| Acquired inventory adjustments |  | 597 |  |  |  | 1,963 |  |  |  | 4,784 |  |  |  | 4,263 |  |
| Amortization of intangibles |  | 6,682 |  |  |  | 2,084 |  |  |  | 17,570 |  |  |  | 13,537 |  |
| Purchase accounting adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Executive transition costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |
| Litigation |  | 207 |  |  |  | (44 | ) |  |  | (158 | ) |  |  | 219 |  |
| Total adjustments to GAAP operating income | $ | 32,608 |  |  | $ | 17,201 |  |  | $ | 102,023 |  |  | $ | 52,098 |  |
| Non-GAAP operating income | $ | 24,387 |  |  | $ | 14,582 |  |  | $ | 67,184 |  |  | $ | 42,477 |  |
| Non-GAAP operating income percentage |  | 9.3 | % |  |  | 9.8 | % |  |  | 9.5 | % |  |  | 9.9 | % |

[0001564590-18-011817:8k_2_02:93]
| Non-GAAP Net Income | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| GAAP net loss | $ | (13,613 | ) |  | $ | (4,977 | ) |  | $ | (41,160 | ) |  | $ | (14,948 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 7,818 |  |  |  | 2,474 |  |  |  | 19,646 |  |  |  | 9,328 |  |
| Acquisition and integration costs, net of bargain purchase gain |  | 12,384 |  |  |  | 3,005 |  |  |  | 55,261 |  |  |  | 15,012 |  |
| Restructuring charge, net of reversal |  | 4,920 |  |  |  | 7,719 |  |  |  | 4,920 |  |  |  | 9,572 |  |
| Acquired inventory adjustments |  | 597 |  |  |  | 1,963 |  |  |  | 4,784 |  |  |  | 4,263 |  |
| Amortization of intangibles |  | 6,682 |  |  |  | 2,084 |  |  |  | 17,570 |  |  |  | 13,537 |  |
| Purchase accounting adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Executive transition costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |
| Litigation |  | 207 |  |  |  | (44 | ) |  |  | (158 | ) |  |  | 219 |  |
| Gain on sale of non-marketable equity investment |  | — |  |  |  | — |  |  |  | (3,757 | ) |  |  | — |  |
| Income tax |  | — |  |  |  | — |  |  |  | (3,102 | ) |  |  | — |  |
| Total adjustments to GAAP net loss | $ | 32,608 |  |  | $ | 17,201 |  |  | $ | 95,164 |  |  | $ | 52,098 |  |
| Non-GAAP net income | $ | 18,995 |  |  | $ | 12,224 |  |  | $ | 54,004 |  |  | $ | 37,150 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.16 |  |  | $ | 0.11 |  |  | $ | 0.45 |  |  | $ | 0.34 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 120,688 |  |  |  | 112,576 |  |  |  | 119,588 |  |  |  | 110,455 |  |

[0001564590-18-011817:8k_2_02:94]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| Cash flow (used in) provided by operations | $ | (15,978 | ) |  | $ | 24,673 |  |  | $ | (1,730 | ) |  | $ | 43,961 |  |
| Less: PP&E CapEx spending |  | (8,690 | ) |  |  | (3,170 | ) |  |  | (21,999 | ) |  |  | (7,832 | ) |
| Total free cash flow | $ | (24,668 | ) |  | $ | 21,503 |  |  | $ | (23,729 | ) |  | $ | 36,129 |  |
