# EXTR MD&A — 0001564590-18-012675


## mdna

[0001564590-18-012675:mdna:1]
[same as prior period, unchanged from 0001564590-18-001677:mdna:1]

[0001564590-18-012675:mdna:2]
[same as prior period, unchanged from 0001564590-18-001677:mdna:2]

[0001564590-18-012675:mdna:3]
[same as prior period, unchanged from 0001564590-18-001677:mdna:3]

[0001564590-18-012675:mdna:4]
[same as prior period, unchanged from 0001564590-18-001677:mdna:4]

[0001564590-18-012675:mdna:5]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended March 31, 2018.

[0001564590-18-012675:mdna:6]
[same as prior period, unchanged from 0001564590-18-001677:mdna:6]

[0001564590-18-012675:mdna:7]
[same as prior period, unchanged from 0001564590-18-001677:mdna:7]

[0001564590-18-012675:mdna:8]
[same as prior period, unchanged from 0001564590-18-001677:mdna:8]

[0001564590-18-012675:mdna:9]
[same as prior period, unchanged from 0001564590-18-001677:mdna:9]

[0001564590-18-012675:mdna:10]
[same as prior period, unchanged from 0001564590-18-001677:mdna:10]

[0001564590-18-012675:mdna:11]
[same as prior period, unchanged from 0001564590-18-001677:mdna:11]

[0001564590-18-012675:mdna:12]
[same as prior period, unchanged from 0001564590-18-001677:mdna:12]

[0001564590-18-012675:mdna:13]
[same as prior period, unchanged from 0001564590-18-001677:mdna:13]

[0001564590-18-012675:mdna:14]
[same as prior period, unchanged from 0001564590-18-001677:mdna:14]

[0001564590-18-012675:mdna:15]
[same as prior period, unchanged from 0001564590-18-001677:mdna:15]

[0001564590-18-012675:mdna:16]
[same as prior period, unchanged from 0001564590-18-001677:mdna:16]

[0001564590-18-012675:mdna:17]
[same as prior period, unchanged from 0001564590-18-001677:mdna:17]

[0001564590-18-012675:mdna:18]
[same as prior period, unchanged from 0001564590-18-001677:mdna:18]

[0001564590-18-012675:mdna:19]
[same as prior period, unchanged from 0001564590-18-001677:mdna:19]

[0001564590-18-012675:mdna:20]
[same as prior period, unchanged from 0001564590-18-001677:mdna:20]

[0001564590-18-012675:mdna:21]
[same as prior period, unchanged from 0001564590-18-001677:mdna:21]

[0001564590-18-012675:mdna:22]
[same as prior period, unchanged from 0001564590-18-001677:mdna:22]

[0001564590-18-012675:mdna:23]
[same as prior period, unchanged from 0001564590-18-001677:mdna:23]

[0001564590-18-012675:mdna:24]
Campus Fabric Business

[0001564590-18-012675:mdna:25]
We completed the acquisition of Avaya Inc’s. (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) on July 14, 2017 (“Campus Fabric Business Closing Date”) pursuant to the Campus Fabric Business Purchase Agreement dated March 7, 2017 between Avaya and Extreme Networks.  We acquired customers, employees, technology and other assets, as well as assumed contracts and other liabilities of the Campus Fabric Business, for purchase consideration of $79.8 million, including all adjustments.  See Note 2. Business Combination for additional information.

[0001564590-18-012675:mdna:26]
36

[0001564590-18-012675:mdna:27]
The business combination was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Campus Fabric Business are recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Campus Fabric Business are included in our operations beginning with the Campus Fabric Business Closing Date.

[0001564590-18-012675:mdna:28]
During the three and nine months ended March 31, 2018, we recognized acquisition and integration costs of $4.4 million and $13.9 million, respectively, related to the Campus Fabric Business which is included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations.

[0001564590-18-012675:mdna:29]
[same as prior period, unchanged from 0001564590-18-001677:mdna:30]

[0001564590-18-012675:mdna:30]
We completed our acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc.’s (“Brocade”) on October 27, 2017 (“Data Center Business Closing Date”) dated as of October 3, 2017.  Upon the terms and subject to the conditions of the Data Center Business Asset Purchase Agreement (“Data Center Business APA”), we acquired customers, employees, technology and other assets of the Data Center Business, as well as assumed certain contracts and other liabilities of the Data Center Business, for an upfront cash closing payment equal to $23.0 million, plus deferred payments of $20.0 million to be paid $1.0 million per quarter for 20 full quarters following the Data Center Business Closing Date, plus quarterly earn out payments equal to 50% of profits of the Data Center Business for the five-year period commencing at the end of our first full fiscal quarter following the Data Center Business Closing Date.  See Note 2. Business Combination for additional information.

[0001564590-18-012675:mdna:31]
The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Data Center Business are recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Data Center Business are included in our operations beginning with the Data Center Business Closing Date.

[0001564590-18-012675:mdna:32]
During the three and nine months ended March 31, 2018, we recognized acquisition costs of $5.0 million and $38.8 million, respectively, including a $25.0 million consent fee paid to Broadcom Corporation (“Broadcom”), to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade. Acquisitions costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations.

[0001564590-18-012675:mdna:33]
[same as prior period, unchanged from 0001564590-18-001677:mdna:34]

[0001564590-18-012675:mdna:34]
During the third quarter of fiscal 2018, we reflected the following results:

[0001564590-18-012675:mdna:35]
|  | • | Net revenues of $262.0 million compared to $149.2 million in the third quarter of fiscal 2017. |

[0001564590-18-012675:mdna:36]
|  | • | Product revenue of $203.5 million compared to $111.3 million in the third quarter of fiscal 2017. |

[0001564590-18-012675:mdna:37]
|  | • | Service revenue of $58.5 million compared to $37.9 million in the third quarter of fiscal 2017. |

[0001564590-18-012675:mdna:38]
|  | • | Total gross margin of 54.6% of net revenues compared to 55.5% of net revenues in the third quarter of fiscal 2017. |

[0001564590-18-012675:mdna:39]
|  | • | Operating loss of $8.2 million compared to operating loss $2.6 million in the third quarter of fiscal 2017. |

[0001564590-18-012675:mdna:40]
|  | • | Net loss of $13.6 million compared to a net loss of $5.0 million in the third quarter of fiscal 2017. |

[0001564590-18-012675:mdna:41]
|  | • | Cash flow used in operating activities of $1.7 million compared to cash flow provided by operating activities of $44.0 million in the nine months ended March 31, 2017. Cash, cash equivalents and marketable securities of $105.3 million compared to $130.5 million as of June 30, 2017. |

[0001564590-18-012675:mdna:42]
[same as prior period, unchanged from 0001564590-18-001677:mdna:44]

[0001564590-18-012675:mdna:43]
[same as prior period, unchanged from 0001564590-18-001677:mdna:45]

[0001564590-18-012675:mdna:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | $ Change |  |  | % Change |  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 203,527 |  |  | $ | 111,321 |  |  | $ | 92,206 |  |  |  | 82.8 | % |  | $ | 543,151 |  |  | $ | 319,469 |  |  | $ | 223,682 |  |  |  | 70.0 | % |
| Percentage of net revenue |  |  | 77.7 | % |  |  | 74.6 | % |  |  |  |  |  |  |  |  |  |  | 77.1 | % |  |  | 74.6 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 58,477 |  |  |  | 37,875 |  |  |  | 20,602 |  |  |  | 54.4 | % |  |  | 161,691 |  |  |  | 108,708 |  |  |  | 52,983 |  |  |  | 48.7 | % |
| Percentage of net revenue |  |  | 22.3 | % |  |  | 25.4 | % |  |  |  |  |  |  |  |  |  |  | 22.9 | % |  |  | 25.4 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 262,004 |  |  | $ | 149,196 |  |  | $ | 112,808 |  |  |  | 75.6 | % |  | $ | 704,842 |  |  | $ | 428,177 |  |  | $ | 276,665 |  |  |  | 64.6 | % |

[0001564590-18-012675:mdna:45]
Product revenue increased $92.2 million or 82.8% for the three months ended March 31, 2018 as compared to the corresponding period of fiscal 2017. The increase in product revenues was attributable to growth related to the acquisitions of the Campus Fabric and the Data Center Businesses and to a lesser extent, organic growth of legacy revenues.

[0001564590-18-012675:mdna:46]
Product revenue increased $223.7 million or 70.0% for the nine months ended March 31, 2018 as compared to the corresponding period of fiscal 2017. The increase in product revenues was attributable to growth related to the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses and to a lesser extent, organic growth of legacy revenues.

[0001564590-18-012675:mdna:47]
Service revenue increased $20.6 million, or 54.4% for the three months ended March 31, 2018 as compared to the corresponding period of fiscal 2017. The increase in service revenue was due to the increased number of service contracts acquired as a result of the acquisitions of the Campus Fabric and the Data Center Businesses.

[0001564590-18-012675:mdna:48]
Service revenue increased $53.0 million or 48.7% for the nine months ended March 31, 2018 as compared to the corresponding period of fiscal 2017. The increase in service revenue was due to the increased number of service contracts acquired as a result of the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses.

[0001564590-18-012675:mdna:49]
[same as prior period, unchanged from 0001564590-18-001677:mdna:49]

[0001564590-18-012675:mdna:50]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | $ Change |  |  | % Change |  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 109,042 |  |  | $ | 59,046 |  |  | $ | 49,996 |  |  |  | 84.7 | % |  | $ | 290,149 |  |  | $ | 160,318 |  |  | $ | 129,831 |  |  |  | 81.0 | % |
| Percentage of product revenue |  |  | 53.6 | % |  |  | 53.0 | % |  |  |  |  |  |  |  |  |  |  | 53.4 | % |  |  | 50.2 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 33,941 |  |  |  | 23,758 |  |  |  | 10,183 |  |  |  | 42.9 | % |  |  | 94,201 |  |  |  | 68,024 |  |  |  | 26,177 |  |  |  | 38.5 | % |
| Percentage of service revenue |  |  | 58.0 | % |  |  | 62.7 | % |  |  |  |  |  |  |  |  |  |  | 58.3 | % |  |  | 62.6 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 142,983 |  |  | $ | 82,804 |  |  | $ | 60,179 |  |  |  | 72.7 | % |  | $ | 384,350 |  |  | $ | 228,342 |  |  | $ | 156,008 |  |  |  | 68.3 | % |
| Percentage of net revenues |  |  | 54.6 | % |  |  | 55.5 | % |  |  |  |  |  |  |  |  |  |  | 54.5 | % |  |  | 53.3 | % |  |  |  |  |  |  |  |  |

[0001564590-18-012675:mdna:51]
Product gross profit increased $50.0 million or 84.7% for the three months ended March 31, 2018 as compared to the corresponding period in fiscal 2017, primarily due to higher revenues attributed to the acquisitions of the Campus Fabric and Data Center Businesses and to lower production costs due to cost reduction efforts, partially offset by increases in amortization of developed technology intangibles of $3.7 million, warranty charges of $2.1 million and acquisition and integration related costs of $1.7 million.

[0001564590-18-012675:mdna:52]
Product gross profit increased $129.8 million or 81.0% for the nine months ended March 31, 2018 as compared to the corresponding period of fiscal 2017, primarily due to higher revenues attributed to the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses and lower production costs due to cost reduction efforts. The increases in product gross profit were partially offset by increases in amortization of developed technology intangibles of $5.1 million, warranty charges of $4.8 million, royalty charges of $2.1 million and acquisition and integration related costs of $2.1 million including excess inventory charges related to the discontinuance of certain product lines due to the acquisitions of the Campus Fabric and the Data Center Businesses as opposed to the same charges incurred related to the acquisition of the WLAN Business in the corresponding period in fiscal 2017.

[0001564590-18-012675:mdna:53]
Service gross profit increased $10.2 million and $26.2 million or 42.9% and 38.5% for the three and nine months ended March 31, 2018 as compared to the corresponding period in fiscal 2017, primarily due to the acquisitions of the WLAN, Campus Fabric and Data Center Businesses as a result of a higher number of maintenance contracts.

[0001564590-18-012675:mdna:54]
[same as prior period, unchanged from 0001564590-18-001677:mdna:55]

[0001564590-18-012675:mdna:55]
[same as prior period, unchanged from 0001564590-18-001677:mdna:56]

[0001564590-18-012675:mdna:56]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | $ Change |  |  | % Change |  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 50,920 |  |  | $ | 24,691 |  |  | $ | 26,229 |  |  |  | 106.2 | % |  | $ | 131,112 |  |  | $ | 67,003 |  |  | $ | 64,109 |  |  |  | 95.7 | % |
| Sales and marketing |  |  | 72,240 |  |  |  | 38,790 |  |  |  | 33,450 |  |  |  | 86.2 | % |  |  | 193,460 |  |  |  | 116,674 |  |  |  | 76,786 |  |  |  | 65.8 | % |
| General and administrative |  |  | 11,707 |  |  |  | 9,612 |  |  |  | 2,095 |  |  |  | 21.8 | % |  |  | 35,561 |  |  |  | 27,296 |  |  |  | 8,265 |  |  |  | 30.3 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 9,316 |  |  |  | 3,418 |  |  |  | 5,898 |  |  |  | 172.6 | % |  |  | 47,675 |  |  |  | 9,908 |  |  |  | 37,767 |  |  |  | 381.2 | % |
| Restructuring and related charges, net of reversals |  |  | 4,920 |  |  |  | 7,719 |  |  |  | (2,799 | ) |  |  | (36.3 | )% |  |  | 4,920 |  |  |  | 9,572 |  |  |  | (4,652 | ) |  |  | (48.6 | )% |
| Amortization of intangibles |  |  | 2,101 |  |  |  | 1,193 |  |  |  | 908 |  |  |  | 76.1 | % |  |  | 6,461 |  |  |  | 7,510 |  |  |  | (1,049 | ) |  |  | (14.0 | )% |
| Total operating expenses |  | $ | 151,204 |  |  | $ | 85,423 |  |  | $ | 65,781 |  |  |  | 77.0 | % |  | $ | 419,189 |  |  | $ | 237,963 |  |  | $ | 181,226 |  |  |  | 76.2 | % |

[0001564590-18-012675:mdna:57]
[same as prior period, unchanged from 0001564590-18-001677:mdna:58]

[0001564590-18-012675:mdna:58]
Research and development expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-18-012675:mdna:59]
Research and development expenses increased by $26.2 million or 106.2% for the three months ended March 31, 2018 as compared to the corresponding period of fiscal 2017.  The increase in research and development expenses was due to higher personnel costs of $19.7 million due to increased headcount related to the acquisitions of the Campus Fabric and Data Center Businesses, $3.4 million in increased facility and information technology costs, $2.8 million in increased supplies and equipment costs and $0.3 million in increased travel and other costs.

[0001564590-18-012675:mdna:60]
Research and development expenses increased by $64.1 million or 95.7% for the nine months ended March 31, 2018 as compared to the corresponding period of fiscal 2017.  The increase in research and development expenses was due to higher personnel costs of $49.8 million due to increased headcount related to the acquisitions of the WLAN, Campus Fabric and Data Center Businesses, $8.7 million in increased facility and information technology costs, $4.6 million in increased supplies and equipment costs and $1.0 million in increased travel and other costs.

[0001564590-18-012675:mdna:61]
[same as prior period, unchanged from 0001564590-18-001677:mdna:62]

[0001564590-18-012675:mdna:62]
Sales and marketing expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), as well as trade shows and promotional expenses.

[0001564590-18-012675:mdna:63]
Sales and marketing expenses increased by $33.5 million or 86.2% for the three months ended March 31, 2018 as compared to the corresponding period of fiscal 2017 primarily as a result of the acquisitions of the Campus Fabric and Data Center Businesses.  The increase consisted of higher personnel costs of $25.1 million, $4.0 million in increased travel, meeting and conference costs, $1.9 million in increased facility and information technology costs, $1.4 million in additional professional fees and $0.9 million in supplies and equipment costs.

[0001564590-18-012675:mdna:64]
Sales and marketing expenses increased by $76.8 million or 65.8% for the nine months ended March 31, 2018 as compared to the corresponding period of fiscal 2017 primarily as a result of the acquisitions of the WLAN, Campus Fabric and Data Center Businesses.  The increase consisted of higher personnel costs of $55.9 million, $10.7 million in increased travel, meeting and conference costs, $5.3 million in increased facility and information technology costs, $3.6 million in additional professional fees and $1.3 million in supplies and equipment costs.

[0001564590-18-012675:mdna:65]
[same as prior period, unchanged from 0001564590-18-001677:mdna:66]

[0001564590-18-012675:mdna:66]
General and administrative expense consists primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001564590-18-012675:mdna:67]
General and administrative expenses increased by $2.1 million or 21.8% for the three months ended March 31, 2018 as compared to the corresponding period of fiscal 2017 primarily due to $2.3 million in higher personnel costs, $1.0 million in higher professional fees, $0.3 million in higher bad debts provision, partially offset by a change of $1.3 million in fair value of contingent consideration obligations and $0.2 million in reduced facility and information technology costs.

[0001564590-18-012675:mdna:68]
General and administrative expenses increased by $8.3 million or 30.3% for the nine months ended March 31, 2018 as compared to the corresponding period of fiscal 2017 primarily due to $6.0 million in higher personnel costs, $2.2 million in higher professional fees and $1.4 million in higher bad debts provision, partially offset by a change of $1.3 million in fair value of contingent consideration obligations.

[0001564590-18-012675:mdna:69]
[same as prior period, unchanged from 0001564590-18-001677:mdna:70]

[0001564590-18-012675:mdna:70]
During the three months ended March 31, 2018 and 2017, we recorded $9.3 million and $3.4 million, respectively, of acquisition and integration costs.

[0001564590-18-012675:mdna:71]
For the three months ended March 31, 2018, we incurred $3.1 million of acquisition and $1.3 million of integration costs related to the acquisition of the Campus Fabric Business and $3.5 million of acquisition and $1.5 million of integration costs related to the acquisition of the Data Center Business.

[0001564590-18-012675:mdna:72]
Expenses for the three months ended March 31, 2017 consisted primarily of legal and accounting services associated with the acquisition of the WLAN Business.

[0001564590-18-012675:mdna:73]
During the nine months ended March 31, 2018 and 2017, we recorded $47.7 million and $9.9 million, respectively, of acquisition and integration costs.

[0001564590-18-012675:mdna:74]
For the nine months ended March 31, 2018, we incurred $9.0 million of acquisition and $4.9 million of integration costs related to the acquisition of the Campus Fabric Business and $35.1 million of acquisition and $3.7 million of integration costs related to the acquisition of the Data Center Business. The Data Center Business acquisition costs includes a $25.0 million consent fee paid to Broadcom, to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade. We also recorded a gain on bargain purchase of $5.0 million related to the acquisition of the Capital Financing business.

[0001564590-18-012675:mdna:75]
Expenses for the nine months ended March 31, 2017 consisted of acquisition and integration costs associated with the acquisition of the WLAN Business of $7.6 million, acquisition costs associated with the acquisition of the Campus Fabric Business of $1.3 million and acquisition costs associated with the acquisition of the Data Center Business of $1.0 million.

[0001564590-18-012675:mdna:76]
[same as prior period, unchanged from 0001564590-18-001677:mdna:77]

[0001564590-18-012675:mdna:77]
For the three and nine months ended March 31, 2018, we recorded restructuring charges of $4.9 million related to a reduction in force.  The charges are comprised of employee severance and benefits expenses.

[0001564590-18-012675:mdna:78]
During the three months ended March 31, 2017, we incurred $7.7 million in restructuring and other charges.  The significant charges during the quarter were related to a reduction in force totaling $5.3 million.  Additionally, we entered into an agreement to sublease our Rio Robles site in San Jose, California during the third quarter of fiscal 2017. The sublease is for the remaining duration of the lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease.   The adjustments to sub-lease income to be received related to the future obligations for non-cancelable lease payments in the amount of $1.5 million and accelerated depreciation of leasehold improvements and fixed assets in the amount of $0.9 million.

[0001564590-18-012675:mdna:79]
During the nine months ended March 31, 2017, we incurred $9.6 million in restructuring and other charges.  The significant charges during the period was related to a reduction in force totaling $5.3 million.  Additionally, there were adjustments to estimated sub-lease income to be received related to the future obligations for non-cancelable lease payments in the amount of $1.7 million and accelerated depreciation of leasehold improvements and fixed assets in the amount of $2.6 million.

[0001564590-18-012675:mdna:80]
[same as prior period, unchanged from 0001564590-18-001677:mdna:80]

[0001564590-18-012675:mdna:81]
During the three months ended March 31, 2018 and 2017, we recorded $2.1 million and $1.2 million, respectively, of amortization expense as operating expenses in the accompanying condensed consolidated statements of operations.  The increase was mainly due to additional amortization related to the acquired intangibles from the Campus Fabric and the Data Center Businesses, partially offset by the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-18-012675:mdna:82]
During the nine months ended March 31, 2018 and 2017, we recorded $6.5 million and $7.5 million, respectively of amortization expense as operating expenses in the accompanying condensed consolidated statements of operations.  The reduction was due to the acquired intangibles from the Enterasys acquisition becoming fully amortized, partially offset by additional amortization related to the acquired intangibles from the WLAN, Campus Fabric and Data Center Businesses.

[0001564590-18-012675:mdna:83]
[same as prior period, unchanged from 0001564590-18-001677:mdna:83]

[0001564590-18-012675:mdna:84]
During the three months ended March 31, 2018 and 2017, we recorded $4.0 million and $1.2 million, respectively, in interest expense.  The increase in interest expense was primarily in connection with the increased balance of our Credit Facility due to the acquisitions of the Campus Fabric Business and the Data Center Business and accretion of interest expense of $1.4 million associated with the Data Center Business contingent consideration obligation.

[0001564590-18-012675:mdna:85]
During the nine months ended March 31, 2018 and 2017, we recorded $8.8 million and $3.0 million, respectively, in interest expense.  The increase in interest expense was primarily in connection with the increased balance of our Credit Facility due to the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses and accretion of interest expense of $1.4 million associated with the Data Center Business contingent consideration obligation.

[0001564590-18-012675:mdna:86]
[same as prior period, unchanged from 0001564590-18-001677:mdna:86]

[0001564590-18-012675:mdna:87]
During the three months ended March 31, 2018 and 2017, we recorded expense of $0.4 million and income of $0.3 million, respectively, in other income (expense), net. The change was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-18-012675:mdna:88]
During the nine months ended March 31, 2018 and 2017, we recorded income of 2.1 million and $0.6 million, respectively, in other income (expense), net. The income for fiscal 2018 period was primarily driven by a gain of $3.8 million due to the sale of non-marketable equity investment, partially offset by foreign exchange losses.  The income for fiscal 2017 period was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-18-012675:mdna:89]
Provision for Income Taxes

[0001564590-18-012675:mdna:90]
For the three months ended March 31, 2018 and 2017, we recorded an income tax provision of $1.7 million and $1.2 million, respectively, which consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys, the WLAN Business and the Campus Fabric Business.  The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended March 31, 2018 and 2017, and therefore may not reflect the annual effective tax rate.

[0001564590-18-012675:mdna:91]
For the nine months ended March 31, 2018 and 2017, we recorded an income tax provision of $1.8 million and $3.3 million, respectively, which consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisitions referenced above.  The tax provision for the nine months ended March 31, 2018 is offset by a tax benefit resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to our deferred tax liability related to amortizable goodwill as required by the recently enacted U.S. tax legislation discussed in Note 10 of the accompanying condensed consolidated financial statements.

[0001564590-18-012675:mdna:92]
[same as prior period, unchanged from 0001564590-18-001677:mdna:92]

[0001564590-18-012675:mdna:93]
[same as prior period, unchanged from 0001564590-18-001677:mdna:93]

[0001564590-18-012675:mdna:94]
[same as prior period, unchanged from 0001564590-18-001677:mdna:94]

[0001564590-18-012675:mdna:95]
[same as prior period, unchanged from 0001564590-18-001677:mdna:95]

[0001564590-18-012675:mdna:96]
[same as prior period, unchanged from 0001564590-18-001677:mdna:96]

[0001564590-18-012675:mdna:97]
[same as prior period, unchanged from 0001564590-18-001677:mdna:97]

[0001564590-18-012675:mdna:98]
[same as prior period, unchanged from 0001564590-18-001677:mdna:98]

[0001564590-18-012675:mdna:99]
[same as prior period, unchanged from 0001564590-18-001677:mdna:99]

[0001564590-18-012675:mdna:100]
[same as prior period, unchanged from 0001564590-18-001677:mdna:100]

[0001564590-18-012675:mdna:101]
[same as prior period, unchanged from 0001564590-18-001677:mdna:101]

[0001564590-18-012675:mdna:102]
[same as prior period, unchanged from 0001564590-18-001677:mdna:102]

[0001564590-18-012675:mdna:103]
[same as prior period, unchanged from 0001564590-18-001677:mdna:103]

[0001564590-18-012675:mdna:104]
[same as prior period, unchanged from 0001564590-18-001677:mdna:104]

[0001564590-18-012675:mdna:105]
[same as prior period, unchanged from 0001564590-18-001677:mdna:105]

[0001564590-18-012675:mdna:106]
[same as prior period, unchanged from 0001564590-18-001677:mdna:106]

[0001564590-18-012675:mdna:107]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor. Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submits rebate requests for Company pre-approval prior to selling the product through at the discounted price. At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods. For additional information, see Note 3, Summary of Significant Accounting Policies.

[0001564590-18-012675:mdna:108]
[same as prior period, unchanged from 0001564590-18-001677:mdna:108]

[0001564590-18-012675:mdna:109]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates

[0001564590-18-012675:mdna:110]
and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized in the statements of operations. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-18-012675:mdna:111]
[same as prior period, unchanged from 0001564590-18-001677:mdna:111]

[0001564590-18-012675:mdna:112]
[same as prior period, unchanged from 0001564590-18-001677:mdna:112]

[0001564590-18-012675:mdna:113]
[same as prior period, unchanged from 0001564590-18-001677:mdna:113]

[0001564590-18-012675:mdna:114]
The following summarizes information regarding our cash, cash equivalents, marketable securities and working capital (in thousands):

[0001564590-18-012675:mdna:115]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Cash and cash equivalents |  | $ | 103,177 |  |  | $ | 130,450 |  |
| Marketable securities |  |  | 2,091 |  |  |  | — |  |
| Total cash, cash equivalent and marketable securities |  | $ | 105,268 |  |  | $ | 130,450 |  |
| Working capital |  | $ | 32,294 |  |  | $ | 85,637 |  |

[0001564590-18-012675:mdna:116]
As of March 31, 2018, our principal sources of liquidity consisted of cash, cash equivalents and marketable securities of $105.3 million, accounts receivable, net of $188.4 million and availability of borrowings from the five-year revolving credit facility (“Revolver”) of $48.8 million. Our principal uses of cash will purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products, purchases of property and equipment and include repayments of debt and related interest. We believe that our $105.3 million of cash, cash equivalents and marketable securities at March 31, 2018 and the availability of borrowings from the Revolver will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-18-012675:mdna:117]
On July 14, 2017, in connection with the closing of the acquisition of the Campus Fabric Business, we entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amends the Amended and Restated Credit Agreement, dated as of October 28, 2016 (as amended, the “Credit Facility”), by and among us, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and Lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, consisted of (a) the five-year term loan (“Term Loan”) facilities in a principal amount of up to $183.7 million and (b) the Revolver  in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver until July 2022, (iii) provides for an uncommitted additional incremental loan facility in a principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as Lenders pursuant to the terms of the Credit Facility.  On July 14, 2017, we borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.

[0001564590-18-012675:mdna:118]
On October 26, 2017, we entered into the Third Amendment to the Credit Facility (the “Third Amendment”).  Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for our fiscal year ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Data Center Business APA.  On October 27, 2017, we borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.

[0001564590-18-012675:mdna:119]
[same as prior period, unchanged from 0001564590-18-001677:mdna:119]

[0001564590-18-012675:mdna:120]
If not repaid earlier, the borrowings on the Revolver shall be repaid on the termination date. The Credit Facility is secured by substantially all of our assets and is jointly and severally guaranteed by us and certain of our subsidiaries.

[0001564590-18-012675:mdna:121]
The Credit Facility contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.  These covenants, are subject to certain exceptions.  At March 31, 2018, we were in compliance with the covenants of the Credit Facility and they are not expected to impact our liquidity or capital resources.

[0001564590-18-012675:mdna:122]
On May 1, 2018, we terminated the Credit Facility and entered into a Credit Agreement (the “New Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The New Credit Agreement provides for a $40 million five-year revolving credit facility (the “New Revolver”) and a $190 million five-year term loan (the “New Term Loan” and together with the New Revolver, the “New Senior Secured Credit Facilities”). On May 1, 2018, we borrowed $200 million under the New Senior Secured Credit Facilities in order to pay off the existing debt, as noted above and for general corporate purposes.

[0001564590-18-012675:mdna:123]
See Note 14 (Subsequent Events) to the condensed consolidated financial statements for more information on the New Credit Agreement.

[0001564590-18-012675:mdna:124]
[same as prior period, unchanged from 0001564590-18-001677:mdna:123]

[0001564590-18-012675:mdna:125]
[same as prior period, unchanged from 0001564590-18-001677:mdna:124]

[0001564590-18-012675:mdna:126]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| Net cash (used in) provided by operating activities |  | $ | (1,730 | ) |  | $ | 43,961 |  |
| Net cash used in investing activities |  |  | (114,658 | ) |  |  | (69,159 | ) |
| Net cash provided by financing activities |  |  | 89,214 |  |  |  | 48,328 |  |
| Foreign currency effect on cash |  |  | (99 | ) |  |  | 28 |  |
| Net (decrease) increase in cash and cash equivalents |  | $ | (27,273 | ) |  | $ | 23,158 |  |

[0001564590-18-012675:mdna:127]
Net Cash (Used in) Provided by Operating Activities

[0001564590-18-012675:mdna:128]
Cash flows used in operations in the nine months ended March 31, 2018 were $1.7 million, including net loss of $41.2 million and non-cash expenses of $46.2 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes, gain on bargain purchase and gain on sale of non-marketable equity investment as well as increases in accounts receivables, prepaid expenses and decreases in accrued compensation and benefits. This was partially offset by a decrease in inventories and increases in accounts payable, deferred revenue and other current and long-term liabilities.

[0001564590-18-012675:mdna:129]
Cash flows provided by operations in the nine months ended March 31, 2017 were $44.0 million including net loss of $14.9 million and non-cash expenses of $35.4 million for items such as amortization of intangibles, stock-based compensation expense and depreciation as well as decreases in accounts receivable, inventories, prepaid expenses and other assets and increases in accounts payable and other current and long-term liabilities.  This was partially offset by decreases in deferred revenue and accrued compensation and benefits.

[0001564590-18-012675:mdna:130]
[same as prior period, unchanged from 0001564590-18-001677:mdna:129]

[0001564590-18-012675:mdna:131]
Cash flows used in investing activities in the nine months ended March 31, 2018 were $114.7 million which consisted of expenditures for acquisitions of $97.6 million consisting of $69.6 million for the acquisition of the Campus Fabric Business and $29.5 million for the acquisition of the Data Center Business, less receipt of $1.6 million as final settlement of a working capital adjustment related to the WLAN Business acquisition, purchases of property and equipment of $22.0 million and proceeds of $4.9 million related to the sale of non-marketable equity investment.

[0001564590-18-012675:mdna:132]
Cash flows used in investing activities in the nine months ended March 31, 2017 were $69.2 million which consisted of expenditures of $51.1 million for the WLAN Business acquisition, $10.2 million in deposits in conjunction with the acquisition of the Campus Fabric Business and $7.8 million of purchases of property and equipment.

[0001564590-18-012675:mdna:133]
[same as prior period, unchanged from 0001564590-18-001677:mdna:132]

[0001564590-18-012675:mdna:134]
Cash flows provided by financing activities in the nine months ended March 31, 2018 were $89.2 million, including new borrowings of $100.0 million to fund our acquisitions of the Campus Fabric Business and the Data Center Business, $4.7 million proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, partially offset by repayments of debt totaling $13.3 million and $1.5 million of loan fees incurred in connection with the Second Amendment of our Credit Facility.

[0001564590-18-012675:mdna:135]
Cash flows provided by financing activities in the nine months ended March 31, 2017 were $48.3 million which consisted of new borrowings of $48.3 million under our Credit Facility, $9.2 million proceeds from the issuance of shares of our common stock under our ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by repayment of debt totaling $7.8 million and $1.3 million of loan fees incurred in connection with the Credit Facility.

[0001564590-18-012675:mdna:136]
[same as prior period, unchanged from 0001564590-18-001677:mdna:136]

[0001564590-18-012675:mdna:137]
Foreign currency effect on cash increased in the three and nine months ended March 31, 2018, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-18-012675:mdna:138]
[same as prior period, unchanged from 0001564590-18-001677:mdna:138]

[0001564590-18-012675:mdna:139]
The following summarizes our contractual obligations as of March 31, 2018, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-18-012675:mdna:140]
|  |  | Total |  |  | Less than 1 Year |  |  |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 180,434 |  |  | $ | 25,260 |  |  |  |  | $ | 74,328 |  |  | $ | 80,846 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 24,958 |  |  |  | 8,585 |  |  |  |  |  | 12,478 |  |  |  | 3,895 |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 151,483 |  |  |  | 151,483 |  |  |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable purchase commitments |  |  | 17,500 |  |  |  | 5,000 |  |  |  |  |  | 11,000 |  |  |  | 1,500 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 105,094 |  |  |  | 21,046 |  |  |  |  |  | 34,369 |  |  |  | 27,468 |  |  |  | 22,211 |  |
| Deferred payments for an acquisition |  |  | 19,000 |  |  |  | 4,000 |  |  |  |  |  | 12,000 |  |  |  | 3,000 |  |  |  | — |  |
| Contingent consideration for acquisitions |  |  | 46,526 |  |  |  | 13,270 |  |  |  |  |  | 17,305 |  |  |  | 15,951 |  |  |  | — |  |
| Other liabilities |  |  | 1,046 |  |  |  | 244 |  |  |  |  |  | 488 |  |  |  | 314 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 546,041 |  |  | $ | 228,888 |  |  |  |  | $ | 161,968 |  |  | $ | 132,974 |  |  | $ | 22,211 |  |

[0001564590-18-012675:mdna:141]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $151.5 million as of March 31, 2018. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-18-012675:mdna:142]
[same as prior period, unchanged from 0001564590-18-001677:mdna:142]

[0001564590-18-012675:mdna:143]
[same as prior period, unchanged from 0001564590-18-001677:mdna:143]

[0001564590-18-012675:mdna:144]
Deferred payments for the acquisition of the Data Center Business represent a $1.0 million per quarter for our next twenty full fiscal quarters following the acquisition date of October 27, 2017.

[0001564590-18-012675:mdna:145]
[same as prior period, unchanged from 0001564590-18-001677:mdna:145]

[0001564590-18-012675:mdna:146]
[same as prior period, unchanged from 0001564590-18-001677:mdna:146]

[0001564590-18-012675:mdna:147]
[same as prior period, unchanged from 0001564590-18-001677:mdna:147]

[0001564590-18-012675:mdna:148]
We did not have any material commitments for capital expenditures as of March 31, 2018.

[0001564590-18-012675:mdna:149]
[same as prior period, unchanged from 0001564590-18-001677:mdna:149]

[0001564590-18-012675:mdna:150]
We did not have any off-balance sheet arrangements as of March 31, 2018.
