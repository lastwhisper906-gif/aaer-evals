# EXTR note change history — 0001564590-18-001677 → 0001564590-18-012675


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-10):
[0001564590-18-012675:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2018, the Company had non-cancelable commitments to purchase $151.5 million of such inventory.  As of March 31, 2018 the Company had non-cancelable software and maintenance support commitments to purchase $17.5 million of software and support services.
  (was, 2018-02-08, similarity 0.9835):
[0001564590-18-001677:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2017, the Company had non-cancelable commitments to purchase $145.3 million of such inventory.  As of December 31, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $19.0 million of software and support services.

- changed (2018-05-10):
[0001564590-18-012675:note_history:2]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (approximately U.S. $1.0 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of March 31, 2018.
  (was, 2018-02-08, similarity 0.9917):
[0001564590-18-001677:note_history:2]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (approximately U.S. $1.0 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of December 31, 2017.

- changed (2018-05-10):
[0001564590-18-012675:note_history:3]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.8 million (approximately U.S. $5.1 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of March 31, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.
  (was, 2018-02-08, similarity 0.9472):
[0001564590-18-001677:note_history:3]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.7 million (approximately U.S. $5.1 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 31, 2017.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, has appealed the lower court’s decision and has requested a stay of execution.

- changed (2018-05-10):
[0001564590-18-012675:note_history:4]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The Company believes plaintiffs’ claims are without merit, and intends to defend them vigorously.
  (was, 2018-02-08, similarity 0.8316):
[0001564590-18-001677:note_history:4]
On October 23 and 29, 2015, putative class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  The Court held a hearing on Defendants’ motion to dismiss on December 14, 2017, and a ruling is expected in the next few months. The Company believes plaintiffs’ claims are without merit and intends to defend them vigorously.

- changed (2018-05-10):
[0001564590-18-012675:note_history:5]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation now has ended.
  (was, 2018-02-08, similarity 0.7476):
[0001564590-18-001677:note_history:5]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.

- changed (2018-05-10):
[0001564590-18-012675:note_history:6]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In an order dated April 10, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board of inter partes review petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date), and scheduled a status conference on October 22, 2018.  The Company believes the claims are without merit, and intends to defend them vigorously.
  (was, 2018-02-08, similarity 0.6339):
[0001564590-18-001677:note_history:6]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) sued the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In an order entered on October 23, 2017, the court scheduled a claim construction hearing for April 10, 2018, and ordered any trial of this matter to commence no earlier than March 19, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.

- added (2018-05-10):
[0001564590-18-012675:note_history:7]
DIFF Scale Operation Research, LLC v. Extreme Networks, Inc.

- added (2018-05-10):
[0001564590-18-012675:note_history:8]
On March 15, 2018, DIFF Scale Operation Research, LLC (“DIFF”) filed a patent infringement lawsuit against the Company in the United States District Court for the Southern District of New York (DIFF Scale Operation Research, LLC v. Extreme Networks, Inc., No. 18-cv-2324-KBF).  The complaint alleges infringement of seven patents (four expired) generally directed to virtual connection networking, and accuses a variety of products, including: (1) SLX router and switch products, and NetIron and MLX products; (2) Extreme Management Center versions 7.0.9, 7.1.3, 8.0, and 8.1; (3) ExtremeSwitching and Summit Series switches; and (4) ERS 3000 Series, 4000 Series, and 5000 Series switches.  DIFF seeks unspecified and enhanced damages, pre- and post-judgment interest, attorneys’ fees and costs (but no injunction).  The Company believes the claims are without merit, and intends to defend them vigorously.

- added (2018-05-10):
[0001564590-18-012675:note_history:9]
Be Labs, Inc. v. Extreme Networks, Inc.

- added (2018-05-10):
[0001564590-18-012675:note_history:10]
On April 25, 2018, Be Labs, Inc. (“Be Labs”) filed a patent infringement lawsuit against the Company in the United States District Court for the District of Delaware (Be Labs, Inc. v. Extreme Networks, Inc., No. 1:18-cv-00626).  The complaint alleges direct and indirect infringement of two patents generally directed to a multimedia wireless distribution system for home or office use, and appears to accuse the Company’s 802.11ac- and 802.11n-compliant ExtremeWireless products.  Be Labs seeks damages, pre- and post-judgment interest, attorneys’ fees, costs, and a permanent injunction.  The Company believes the claims are without merit, and intends to defend them vigorously.

- added (2018-05-10):
[0001564590-18-012675:note_history:11]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

- added (2018-05-10):
[0001564590-18-012675:note_history:12]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and our Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit, and intends to defend them vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-10):
[0001564590-18-012675:note_history:13]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”), is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.
  (was, 2018-02-08, similarity 0.9988):
[0001564590-18-001677:note_history:13]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

- changed (2018-05-10):
[0001564590-18-012675:note_history:14]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2018. The results of operations for the three and nine months ended March 31, 2018 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.
  (was, 2018-02-08, similarity 0.9404):
[0001564590-18-001677:note_history:14]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2017. The results of operations for the three and six months ended December 31, 2017 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.

- changed (2018-05-10):
[0001564590-18-012675:note_history:15]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606). All amounts and disclosures set forth in this Form 10-Q have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.
  (was, 2018-02-08, similarity 0.9832):
[0001564590-18-001677:note_history:15]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers. All amounts and disclosures set forth in this Form 10-Q have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.

- changed (2018-05-10):
[0001564590-18-012675:note_history:16]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2018” or “2018” represent the fiscal year ending June 30, 2018.  All references herein to “fiscal 2017” or “2017” represent the fiscal year ended June 30, 2017.
  (was, 2018-02-08, similarity 0.9889):
[0001564590-18-001677:note_history:16]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2018” or “2018” represent the fiscal year ending June 30, 2018.  All references herein to “fiscal 2017” or “2017” represent the fiscal year ending June 30, 2017.

- changed (2018-05-10):
[0001564590-18-012675:note_history:17]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes.  Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs, measurements of contingent consideration and income taxes. Actual results could differ from these estimates.
  (was, 2018-02-08, similarity 0.9742):
[0001564590-18-001677:note_history:17]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes.  Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ from these estimates.

- removed (2018-05-10):
[0001564590-18-001677:note_history:18]
Reclassification

- removed (2018-05-10):
[0001564590-18-001677:note_history:19]
Certain amounts from prior years have been reclassified to conform to the current year’s presentation in the accompanying condensed consolidated statements of cash flow. The reclassification had no impact on previously reported net loss or accumulated deficit.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-10):
[0001564590-18-012675:note_history:20]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.
  (was, 2018-02-08, similarity 0.9977):
[0001564590-18-001677:note_history:20]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- changed (2018-05-10):
[0001564590-18-012675:note_history:21]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.
  (was, 2018-02-08, similarity 0.9935):
[0001564590-18-001677:note_history:21]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve-month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- changed (2018-05-10):
[0001564590-18-012675:note_history:22]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.
  (was, 2018-02-08, similarity 0.998):
[0001564590-18-001677:note_history:22]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- changed (2018-05-10):
[0001564590-18-012675:note_history:23]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and nine months ended March 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2018-02-08, similarity 0.8225):
[0001564590-18-001677:note_history:23]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month and six-month periods ended December 31, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2018-05-10):
[0001564590-18-012675:note_history:24]
On March 31, 2018, the Company had $156.6 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 33 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 48 percent in fiscal 2019 and 19 percent of the balance thereafter.
  (was, 2018-02-08, similarity 0.9764):
[0001564590-18-001677:note_history:24]
On December 31, 2017, the Company had $152.4 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 54 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 31 percent by fiscal 2019 and 15 percent of the balance thereafter.

- changed (2018-05-10):
[0001564590-18-012675:note_history:25]
Revenue recognized for the nine months ended March 31, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $66.7 million and $61.4 million, respectively. Revenue recognized for the three months ended March 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $31.3 million, respectively.
  (was, 2018-02-08, similarity 0.8649):
[0001564590-18-001677:note_history:25]
Revenue recognized for the six-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $53.1 million and $49.7 million respectively. Revenue recognized for the three-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $36.9 million and $33.5 million, respectively.

- changed (2018-05-10):
[0001564590-18-012675:note_history:26]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.1 million and $2.5 million at March 31, 2018 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2018 and 2017, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the nine months ended March 31, 2018 and 2017 was $1.4 million and $1.1 million, respectively.  There was no impairment loss in relation to the costs capitalized.
  (was, 2018-02-08, similarity 0.947):
[0001564590-18-001677:note_history:26]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.0 million and $2.5 million at December 31, 2017 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three-month period ended December 31, 2017 and 2016, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the six-month period ended December 31, 2017 and 2016, was $0.9 million and $0.7 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- changed (2018-05-10):
[0001564590-18-012675:note_history:27]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands, unaudited):
  (was, 2018-02-08, similarity 0.8889):
[0001564590-18-001677:note_history:27]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands, unaudited):

- changed (2018-05-10):
[0001564590-18-012675:note_history:28]
|  |  | Three Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |  | $ | 31,972 |  | $ | 47,367 |  | $ | 79,339 |  |
| Other |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |  |  | 1,559 |  |  | 1,901 |  |  | 3,460 |  |
| Total Americas |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |  |  | 33,531 |  |  | 49,268 |  |  | 82,799 |  |
| EMEA: |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |  |  | 32,090 |  |  | 20,136 |  |  | 52,226 |  |
| APAC: |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |  |  | 2,399 |  |  | 11,772 |  |  | 14,171 |  |
| Total net revenues |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |  | $ | 68,020 |  | $ | 81,176 |  | $ | 149,196 |  |
  (was, 2018-02-08, similarity 0.9688):
[0001564590-18-001677:note_history:28]
|  |  | Three Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |  | $ | 39,063 |  | $ | 38,396 |  | $ | 77,459 |  |
| Other |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |  |  | 2,827 |  |  | 3,243 |  |  | 6,070 |  |
| Total Americas |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |  |  | 41,890 |  |  | 41,639 |  |  | 83,529 |  |
| EMEA: |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |  |  | 36,070 |  |  | 24,361 |  |  | 60,431 |  |
| APAC: |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |  |  | 1,613 |  |  | 10,804 |  |  | 12,417 |  |
| Total net revenues |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |  | $ | 79,573 |  | $ | 76,804 |  | $ | 156,377 |  |

- changed (2018-05-10):
[0001564590-18-012675:note_history:29]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |  | $ | 98,026 |  | $ | 112,592 |  | $ | 210,618 |  |
| Other |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |  |  | 5,779 |  |  | 14,772 |  |  | 20,551 |  |
| Total Americas |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |  |  | 103,805 |  |  | 127,364 |  |  | 231,169 |  |
| EMEA: |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |  |  | 99,459 |  |  | 61,026 |  |  | 160,485 |  |
| APAC: |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |  |  | 5,464 |  |  | 31,059 |  |  | 36,523 |  |
| Total net revenues |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |  | $ | 208,728 |  | $ | 219,449 |  | $ | 428,177 |  |
  (was, 2018-02-08, similarity 0.9293):
[0001564590-18-001677:note_history:29]
|  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |  | $ | 66,054 |  | $ | 65,225 |  | $ | 131,279 |  |
| Other |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |  |  | 4,220 |  |  | 12,871 |  |  | 17,091 |  |
| Total Americas |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |  |  | 70,274 |  |  | 78,096 |  |  | 148,370 |  |
| EMEA: |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |  |  | 67,369 |  |  | 40,890 |  |  | 108,259 |  |
| APAC: |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |  |  | 3,065 |  |  | 19,287 |  |  | 22,352 |  |
| Total net revenues |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |  | $ | 140,708 |  | $ | 138,273 |  | $ | 278,981 |  |

- added (2018-05-10):
[0001564590-18-012675:note_history:30]
Business Combinations

- added (2018-05-10):
[0001564590-18-012675:note_history:31]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

- added (2018-05-10):
[0001564590-18-012675:note_history:32]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized in the statements of operations. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-10):
[0001564590-18-012675:note_history:33]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 25,260 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (540 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 24,720 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 145,173 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,215 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 153,958 |  |  |  | 80,422 |  |
| Total debt |  | $ | 178,678 |  |  | $ | 92,702 |  |
  (was, 2018-02-08, similarity 0.9884):
[0001564590-18-001677:note_history:33]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,964 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (538 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 22,426 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 152,062 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,350 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 160,712 |  |  |  | 80,422 |  |
| Total debt |  | $ | 183,138 |  |  | $ | 92,702 |  |

- changed (2018-05-10):
[0001564590-18-012675:note_history:34]
In connection with the closing of Campus Fabric Business discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility.  On July 14, 2017, the Company borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.
  (was, 2018-02-08, similarity 0.9908):
[0001564590-18-001677:note_history:34]
In connection with the closing of Campus Fabric Business discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.

- changed (2018-05-10):
[0001564590-18-012675:note_history:35]
In connection with the closing of the acquisition of the Data Center Business discussed in Note 2, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”) on October 26, 2017. Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Data Center Business Purchase Agreement (as defined above). On the Data Center Business Closing Date, the Company borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.
  (was, 2018-02-08, similarity 0.9605):
[0001564590-18-001677:note_history:35]
In connection with the closing of the acquisition of the Data Center Business discussed in Note 2, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”) on October 26, 2017. Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement (as defined above). On the Brocade Closing Date, the Company borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.

- changed (2018-05-10):
[0001564590-18-012675:note_history:36]
The Company had $1.2 million of outstanding letters of credit and $48.8 million of availability under the Revolver as of March 31, 2018.
  (was, 2018-02-08, similarity 0.9644):
[0001564590-18-001677:note_history:36]
The Company had $1.2 million of outstanding letters of credit and $48.8 million of availability under the Revolver as of December 31, 2017.

- added (2018-05-10):
[0001564590-18-012675:note_history:37]
On May 1, 2018, the Company terminated the Credit Facility.

- added (2018-05-10):
[0001564590-18-012675:note_history:38]
On May 1, 2018, the Company entered into a Credit Agreement (the “New Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The New Credit Agreement provides for a $40 million five-year revolving credit facility (the “New Revolver”) and a $190 million five-year term loan (the “New Term Loan” and together with the New Revolver, the “New Senior Secured Credit Facilities”). On May 1, 2018, the Company borrowed $200 million under the New Senior Secured Credit Facilities in order to pay off existing debt and for general corporate purposes.

- added (2018-05-10):
[0001564590-18-012675:note_history:39]
See Note 14 (Subsequent Events) to the condensed consolidated financial statements for more information on the New Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-10):
[0001564590-18-012675:note_history:40]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 25,260 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (540 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 24,720 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 145,173 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,215 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 153,958 |  |  |  | 80,422 |  |
| Total debt |  | $ | 178,678 |  |  | $ | 92,702 |  |
  (was, 2018-02-08, similarity 0.9884):
[0001564590-18-001677:note_history:40]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,964 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (538 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 22,426 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 152,062 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,350 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 160,712 |  |  |  | 80,422 |  |
| Total debt |  | $ | 183,138 |  |  | $ | 92,702 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-05-10):
[0001564590-18-012675:note_history:41]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.
  (was, 2018-02-08, similarity 0.9977):
[0001564590-18-001677:note_history:41]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- changed (2018-05-10):
[0001564590-18-012675:note_history:42]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.
  (was, 2018-02-08, similarity 0.9935):
[0001564590-18-001677:note_history:42]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve-month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- changed (2018-05-10):
[0001564590-18-012675:note_history:43]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.
  (was, 2018-02-08, similarity 0.998):
[0001564590-18-001677:note_history:43]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- changed (2018-05-10):
[0001564590-18-012675:note_history:44]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and nine months ended March 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2018-02-08, similarity 0.8225):
[0001564590-18-001677:note_history:44]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month and six-month periods ended December 31, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2018-05-10):
[0001564590-18-012675:note_history:45]
On March 31, 2018, the Company had $156.6 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 33 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 48 percent in fiscal 2019 and 19 percent of the balance thereafter.
  (was, 2018-02-08, similarity 0.9764):
[0001564590-18-001677:note_history:45]
On December 31, 2017, the Company had $152.4 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 54 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 31 percent by fiscal 2019 and 15 percent of the balance thereafter.

- changed (2018-05-10):
[0001564590-18-012675:note_history:46]
Revenue recognized for the nine months ended March 31, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $66.7 million and $61.4 million, respectively. Revenue recognized for the three months ended March 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $31.3 million, respectively.
  (was, 2018-02-08, similarity 0.8649):
[0001564590-18-001677:note_history:46]
Revenue recognized for the six-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $53.1 million and $49.7 million respectively. Revenue recognized for the three-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $36.9 million and $33.5 million, respectively.

- changed (2018-05-10):
[0001564590-18-012675:note_history:47]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.1 million and $2.5 million at March 31, 2018 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2018 and 2017, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the nine months ended March 31, 2018 and 2017 was $1.4 million and $1.1 million, respectively.  There was no impairment loss in relation to the costs capitalized.
  (was, 2018-02-08, similarity 0.947):
[0001564590-18-001677:note_history:47]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.0 million and $2.5 million at December 31, 2017 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three-month period ended December 31, 2017 and 2016, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the six-month period ended December 31, 2017 and 2016, was $0.9 million and $0.7 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- changed (2018-05-10):
[0001564590-18-012675:note_history:48]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands, unaudited):
  (was, 2018-02-08, similarity 0.8889):
[0001564590-18-001677:note_history:48]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands, unaudited):

- changed (2018-05-10):
[0001564590-18-012675:note_history:49]
|  |  | Three Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |  | $ | 31,972 |  | $ | 47,367 |  | $ | 79,339 |  |
| Other |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |  |  | 1,559 |  |  | 1,901 |  |  | 3,460 |  |
| Total Americas |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |  |  | 33,531 |  |  | 49,268 |  |  | 82,799 |  |
| EMEA: |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |  |  | 32,090 |  |  | 20,136 |  |  | 52,226 |  |
| APAC: |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |  |  | 2,399 |  |  | 11,772 |  |  | 14,171 |  |
| Total net revenues |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |  | $ | 68,020 |  | $ | 81,176 |  | $ | 149,196 |  |
  (was, 2018-02-08, similarity 0.9688):
[0001564590-18-001677:note_history:49]
|  |  | Three Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |  | $ | 39,063 |  | $ | 38,396 |  | $ | 77,459 |  |
| Other |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |  |  | 2,827 |  |  | 3,243 |  |  | 6,070 |  |
| Total Americas |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |  |  | 41,890 |  |  | 41,639 |  |  | 83,529 |  |
| EMEA: |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |  |  | 36,070 |  |  | 24,361 |  |  | 60,431 |  |
| APAC: |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |  |  | 1,613 |  |  | 10,804 |  |  | 12,417 |  |
| Total net revenues |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |  | $ | 79,573 |  | $ | 76,804 |  | $ | 156,377 |  |

- changed (2018-05-10):
[0001564590-18-012675:note_history:50]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |  | $ | 98,026 |  | $ | 112,592 |  | $ | 210,618 |  |
| Other |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |  |  | 5,779 |  |  | 14,772 |  |  | 20,551 |  |
| Total Americas |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |  |  | 103,805 |  |  | 127,364 |  |  | 231,169 |  |
| EMEA: |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |  |  | 99,459 |  |  | 61,026 |  |  | 160,485 |  |
| APAC: |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |  |  | 5,464 |  |  | 31,059 |  |  | 36,523 |  |
| Total net revenues |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |  | $ | 208,728 |  | $ | 219,449 |  | $ | 428,177 |  |
  (was, 2018-02-08, similarity 0.9293):
[0001564590-18-001677:note_history:50]
|  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |  | $ | 66,054 |  | $ | 65,225 |  | $ | 131,279 |  |
| Other |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |  |  | 4,220 |  |  | 12,871 |  |  | 17,091 |  |
| Total Americas |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |  |  | 70,274 |  |  | 78,096 |  |  | 148,370 |  |
| EMEA: |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |  |  | 67,369 |  |  | 40,890 |  |  | 108,259 |  |
| APAC: |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |  |  | 3,065 |  |  | 19,287 |  |  | 22,352 |  |
| Total net revenues |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |  | $ | 140,708 |  | $ | 138,273 |  | $ | 278,981 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-05-10):
[0001564590-18-012675:note_history:51]
On May 1, 2018, the Company terminated the Amended and Restated Credit Agreement dated October 28, 2016, by and among the Company, as borrower, Silicon Valley Bank, as administrative agent, and the financial institutions that were a party thereto as lenders.

- added (2018-05-10):
[0001564590-18-012675:note_history:52]
On May 1, 2018, the Company entered into a Credit Agreement (the “New Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The New Credit Agreement provides for a $40 million five-year revolving credit facility (the “New Revolver”) and a $190 million five-year term loan (the “New Term Loan” and together with the New Revolver, the “New Senior Secured Credit Facilities”). On May 1, 2018, the Company borrowed $200 million under the New Senior Secured Credit Facilities in order to pay off the existing debt, as noted above and for general corporate purposes.

- added (2018-05-10):
[0001564590-18-012675:note_history:53]
Borrowings under the New Senior Secured Credit Facilities will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolver, also based on the Company’s Consolidated Leverage Ratio. Principal installments are payable on the New Term Loan in varying percentages quarterly starting June 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The New Senior Secured Credit Facilities are secured by substantially all of the Company’s assets.

- added (2018-05-10):
[0001564590-18-012675:note_history:54]
Financial covenants under the New Credit Agreement require the Company to maintain a minimum consolidated fixed charge coverage ratio of at least 1.25:1.00 at the end of each fiscal quarter. In addition, the Company’s Consolidated Leverage Ratio shall not be greater than (i) 3.00:1.00 at the end of the fiscal quarters ending March 31, 2018 through September 30, 2019, (ii) 2.75:1.00 at the end of the fiscal quarters ending December 31, 2019 through March 31, 2021, and (iii) 2.50:1.00 at the end of the fiscal quarters ending June 30, 2021 and thereafter. The New Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets.

- added (2018-05-10):
[0001564590-18-012675:note_history:55]
The New Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, the material breach of any of representations and warranties, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company. The amounts outstanding under the New Senior Secured Credit Facilities may be accelerated upon certain events of default.

- removed (2018-05-10):
[0001564590-18-001677:note_history:56]
On January 31, 2018, the Company approved and on February 2, 2018 began executing a reduction-in-force (the “Plan”) to re-align the Company’s resources as a result of the Company’s recent acquisitions of the Campus Fabric Business and the Data Center Business. The Plan is expected to reduce the overall costs of the Company and to accelerate the achievement of the Company’s operating margin target objectives. The Company expects to incur charges of approximately $4.0 million in connection with the Plan. Upon completion of the Plan, the potential savings expected to be achieved as a result of reduced employee related expenses and lower operating costs will yield annualized savings of $7.0 - $9.0 million. The costs associated with this Plan primarily include employee severance and benefits expenses.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.
