# EXTR notes — 0001564590-18-012675


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-012675:notes:1]
[same as prior period, unchanged from 0001564590-18-001677:notes:1]

[0001564590-18-012675:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”), is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-18-012675:notes:3]
[same as prior period, unchanged from 0001564590-18-001677:notes:3]

[0001564590-18-012675:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2018. The results of operations for the three and nine months ended March 31, 2018 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.

[0001564590-18-012675:notes:5]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606). All amounts and disclosures set forth in this Form 10-Q have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.

[0001564590-18-012675:notes:6]
[same as prior period, unchanged from 0001564590-18-001677:notes:6]

[0001564590-18-012675:notes:7]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2018” or “2018” represent the fiscal year ending June 30, 2018.  All references herein to “fiscal 2017” or “2017” represent the fiscal year ended June 30, 2017.

[0001564590-18-012675:notes:8]
[same as prior period, unchanged from 0001564590-18-001677:notes:8]

[0001564590-18-012675:notes:9]
[same as prior period, unchanged from 0001564590-18-001677:notes:9]

[0001564590-18-012675:notes:10]
[same as prior period, unchanged from 0001564590-18-001677:notes:10]

[0001564590-18-012675:notes:11]
[same as prior period, unchanged from 0001564590-18-001677:notes:11]

[0001564590-18-012675:notes:12]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes.  Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs, measurements of contingent consideration and income taxes. Actual results could differ from these estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-012675:notes:13]
[same as prior period, unchanged from 0001564590-18-001677:notes:15]

[0001564590-18-012675:notes:14]
The Company completed three acquisitions during the nine months ended March 31, 2018. The acquisitions have been accounted for using the acquisition method of accounting.  The purchase price has been allocated on a preliminary basis to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach.  The fair value of property and equipment was determined using a cost approach.  The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay to a third party to assume the obligation.  Valuations of the intangible assets were valued using income approaches based on management projections, which we consider to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition.

[0001564590-18-012675:notes:15]
The final purchase price allocation for all assets acquired and liabilities assumed is pending the finalization of valuations as additional information is gathered surrounding events that existed as of the acquisition date, which may result in an adjustment to the preliminary purchase price allocation. Also, additional information which existed as of the acquisition dates, but was unknown to the Company at that time, may become known to the Company during the remainder of the measurement period (up to one year from the acquisition dates), and may result in a change in the purchase price allocation.  While management believes that its preliminary estimates and assumptions underlying the valuations are reasonable, different estimates and assumptions could result in different valuations assigned to the individual assets acquired and liabilities assumed, and the resulting amount of goodwill. Results of operations of the acquired entities are included in the Company’s operations beginning with the closing date of each acquisition.

[0001564590-18-012675:notes:16]
[same as prior period, unchanged from 0001564590-18-001677:notes:18]

[0001564590-18-012675:notes:17]
[same as prior period, unchanged from 0001564590-18-001677:notes:19]

[0001564590-18-012675:notes:18]
The Company completed its acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc.’s (“Brocade”) on October 27, 2017 (the “Data Center Closing Date”), pursuant to an Asset Purchase Agreement (the “Data Center Business APA”) dated as of October 3, 2017, by and between the Company and Brocade. Under the terms and conditions of the Data Center Business APA, the Company acquired customers, employees, technology and other assets of the Data Center Business as well as assumed certain contracts and other liabilities of the Data Center Business.

[0001564590-18-012675:notes:19]
The fair value of consideration transferred on the Data Center Business Closing Date includes:

[0001564590-18-012675:notes:20]
[same as prior period, unchanged from 0001564590-18-001677:notes:22]

[0001564590-18-012675:notes:21]
[same as prior period, unchanged from 0001564590-18-001677:notes:23]

[0001564590-18-012675:notes:22]
[same as prior period, unchanged from 0001564590-18-001677:notes:24]

[0001564590-18-012675:notes:23]
|  | • | an amount payable due to the excess working capital acquired over the target working capital agreed upon in the Data Center Business APA, and, |

[0001564590-18-012675:notes:24]
|  | • | portion of the fair value of replacement stock awards granted to employees assumed from Brocade for which their services were provided prior to the Data Center Business Closing Date. |

[0001564590-18-012675:notes:25]
[same as prior period, unchanged from 0001564590-18-001677:notes:27]

[0001564590-18-012675:notes:26]
[same as prior period, unchanged from 0001564590-18-001677:notes:28]

[0001564590-18-012675:notes:27]
The following table below summarizes the preliminary allocation as of March 31, 2018 of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-18-012675:notes:28]
|  | Preliminary Allocation as of December 31, 2017 |  |  | Change during three months ended March 31, 2018 |  |  | Preliminary Allocation as of March 31, 2018 |  |
| Accounts receivables | $ | 33,488 |  |  | $ | — |  |  | $ | 33,488 |  |
| Inventories |  | 19,973 |  |  |  | (39 | ) | (a) |  | 19,934 |  |
| Prepaid expenses and other current assets |  | 988 |  |  |  | — |  |  |  | 988 |  |
| Property and equipment |  | 29,160 |  |  |  | — |  |  |  | 29,160 |  |
| Other assets |  | 4,734 |  |  |  | — |  |  |  | 4,734 |  |
| Accounts payable and accrued expenses |  | (15,850 | ) |  |  | 113 |  | (b) |  | (15,737 | ) |
| Deferred revenue |  | (33,519 | ) |  |  | 494 |  | (c) |  | (33,025 | ) |
| Net tangible assets acquired |  | 38,974 |  |  |  | 568 |  |  |  | 39,542 |  |
| Identifiable intangible assets |  | 28,600 |  |  |  | 3,600 |  | (d) |  | 32,200 |  |
| Goodwill |  | 16,763 |  |  |  | (4,168 | ) |  |  | 12,595 |  |
| Total intangible assets acquired |  | 45,363 |  |  |  | (568 | ) |  |  | 44,795 |  |
| Total net assets acquired | $ | 84,337 |  |  | $ | — |  |  | $ | 84,337 |  |

[0001564590-18-012675:notes:29]
The changes during the period in the table above include: a) additional information regarding the existence of inventories and unpaid invoices as of the acquisition date, b) additional information on unpaid invoices as of the acquisition date, c) an adjustment of the fair value of deferred maintenance revenue and d) revised fair value based on adjustments to discount rate used in the models for usefulness of identifiable intangible assets.

[0001564590-18-012675:notes:30]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (dollars in thousands):

[0001564590-18-012675:notes:31]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  | 2 - 5 |  |  | $ | 25,400 |  |
| Customer relationships |  |  | 5 |  |  |  | 5,400 |  |
| Trade names |  |  | 4 |  |  |  | 1,400 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 32,200 |  |

[0001564590-18-012675:notes:32]
[same as prior period, unchanged from 0001564590-18-001677:notes:33]

[0001564590-18-012675:notes:33]
The results of operations of the Data Center Business are included with those of the Company beginning October 28, 2017.  The Data Center Business revenue for the nine months ended March 31, 2018 was $90.2 million and has been incorporated into the revenue of the Company.  The associated expenses of the Data Center Business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available.  In the three and nine months ended March 31, 2018 the Company incurred $5.0 million and $38.8 million, respectively, of acquisition and integration related expenses associated with the acquisition of the Data Center Business, including a $25.0 million consent fee paid to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom Corporation, in anticipation of Broadcom’s proposed acquisition of Brocade. The fee was paid to allow the Company to buy the Data Center Business directly from Brocade.  Such acquisition-related costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations. The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants.

[0001564590-18-012675:notes:34]
[same as prior period, unchanged from 0001564590-18-001677:notes:35]

[0001564590-18-012675:notes:35]
The Company completed its acquisition of Avaya Inc.’s. (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) on July 14, 2017, (the “Campus Fabric Business Closing Date”) pursuant to an Asset Purchase Agreement (the “Campus Fabric Business APA”) dated March 7, 2017.  Under the terms and conditions of the Campus Fabric Business APA, the Company acquired the customers, employees, technology and other assets of the Campus Fabric Business, as well as assumed certain contracts and other liabilities of the Campus Fabric Business, for total provisional consideration of $79.8 million, calculated as $100.0 million, less adjustments set forth in the Campus Fabric Business APA related to net working capital, deferred revenue, certain assumed lease obligations and certain assumed pension obligations for transferring employees of the Campus Fabric Business.  Pursuant to certain ancillary agreements, Avaya will also provide the Company with transition services for a period of time following the Campus Fabric Business Closing Date.

[0001564590-18-012675:notes:36]
|  | Preliminary Allocation as of December 31, 2017 |  |  | Change during three months ended March 31, 2018 |  |  | Preliminary Allocation as of March 31, 2018 |  |
| Accounts receivables | $ | 18,295 |  |  | $ | 417 |  | (a) | $ | 18,712 |  |
| Inventories |  | 15,545 |  |  |  | — |  |  |  | 15,545 |  |
| Prepaid expenses and other current assets |  | 673 |  |  |  | (24 | ) | (b) |  | 649 |  |
| Property and equipment |  | 3,768 |  |  |  | 1,638 |  | (c) |  | 5,406 |  |
| Other assets |  | 5,311 |  |  |  | (517 | ) | (d) |  | 4,794 |  |
| Accounts payable and accrued expenses |  | (31,919 | ) |  |  | (395 | ) | (c) |  | (32,314 | ) |
| Deferred revenue |  | (10,051 | ) |  |  | 1,057 |  | (e) |  | (8,994 | ) |
| Other long-term liabilities |  | (5,205 | ) |  |  | — |  |  |  | (5,205 | ) |
| Net tangible assets acquired |  | (3,583 | ) |  |  | 2,176 |  |  |  | (1,407 | ) |
| Identifiable intangible assets |  | 46,900 |  |  |  | (4,700 | ) | (f) |  | 42,200 |  |
| In-process research and development |  | 2,500 |  |  |  | 100 |  | (f) |  | 2,600 |  |
| Goodwill |  | 34,009 |  |  |  | 2,424 |  |  |  | 36,433 |  |
| Total intangible assets acquired |  | 83,409 |  |  |  | (2,176 | ) |  |  | 81,233 |  |
| Total net assets acquired | $ | 79,826 |  |  | $ | — |  |  | $ | 79,826 |  |

[0001564590-18-012675:notes:37]
The changes during the period in the table above include: a) additional information on accounts receivable as of the acquisition date, b) additional information on prepaid expenses as of the acquisition date, c) update on preliminary estimate of the fair value of property and equipment which led to an increase, d) an adjustment of the fair value of deferred maintenance revenue and associated deferred cost of revenue, e) additional information on unpaid invoices as of the acquisition date, and f) revised fair value based on revisions to estimated useful life of identifiable intangible assets and in-process research and development acquired.

[0001564590-18-012675:notes:38]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  | 2 - 4 |  |  | $ | 32,700 |  |
| Customer relationships |  |  | 4 |  |  |  | 5,100 |  |
| Trade names |  | 4 - 5 |  |  |  | 2,600 |  |
| Backlog |  |  | 1 |  |  |  | 1,800 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 42,200 |  |

[0001564590-18-012675:notes:39]
[same as prior period, unchanged from 0001564590-18-001677:notes:41]

[0001564590-18-012675:notes:40]
The Company also acquired an indefinite lived asset of $2.6 million which represents the fair value of in-process research and development activities.  During the three months ended March 31, 2018, the related research and development efforts were completed and the Company reclassified the in-process research and development of $2.6 million to developed technology and began recognizing amortization expense over its estimated useful life.

[0001564590-18-012675:notes:41]
The results of operations of the Campus Fabric Business are included in the accompanying condensed consolidated results of operations beginning July 14, 2017.  The Campus Fabric Business revenue for the nine months ended March 31, 2018 was $127.7 million and has been incorporated into the revenue of the Company. The associated expenses of the Campus Fabric Business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available. In the three and nine months ended March 31, 2018, the Company incurred $4.4 million and $13.9 million, respectively, of acquisition and integration related expenses associated with the acquisition of the Campus Fabric Business.  Such acquisition-related costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants and companies.

[0001564590-18-012675:notes:42]
[same as prior period, unchanged from 0001564590-18-001677:notes:44]

[0001564590-18-012675:notes:43]
[same as prior period, unchanged from 0001564590-18-001677:notes:45]

[0001564590-18-012675:notes:44]
Net assets acquired included financing receivables of $13.7 million, lease equipment of $3.5 million and identifiable intangible assets of $0.8 million, and the fair value of the contingent consideration was $13.0 million. As the preliminary fair value of the net assets acquired exceeded the fair value of the purchase consideration, the Company recorded a bargain purchase gain of $5.0 million which is included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations.  Acquisition and integration related expenses associated with the acquisition of the CF Business were immaterial.

[0001564590-18-012675:notes:45]
[same as prior period, unchanged from 0001564590-18-001677:notes:47]

[0001564590-18-012675:notes:46]
On October 28, 2016, the Company completed its acquisition of the wireless local area network business (“WLAN Business”) from Zebra Technologies Corporation.  Under the terms of the WLAN Asset Purchase Agreement, the Company acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for a net cash consideration to $49.5 million.  The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-18-012675:notes:47]
[same as prior period, unchanged from 0001564590-18-001677:notes:49]

[0001564590-18-012675:notes:48]
[same as prior period, unchanged from 0001564590-18-001677:notes:50]

[0001564590-18-012675:notes:49]
[same as prior period, unchanged from 0001564590-18-001677:notes:51]

[0001564590-18-012675:notes:50]
[same as prior period, unchanged from 0001564590-18-001677:notes:52]

[0001564590-18-012675:notes:51]
The unaudited pro forma financial information for the three and nine months ended March 31, 2018, combines the results for Extreme for the three and nine months ended March 31, 2018, which include the results of the Data Center Business, CF Business and Campus Fabric Business subsequent to their acquisition dates and their historical results up to the acquisition date.

[0001564590-18-012675:notes:52]
The unaudited pro forma financial information for the three and nine months ended March 31, 2017, combines the historical results for Extreme for those periods, as adjusted for the adoption of Topic 606, with the historical results of the Data Center Business, CF Business and Campus Fabric Business for the three and nine months ended March 31, 2017, as well as the historical results of the WLAN Business prior to the WLAN Business acquisition date.

[0001564590-18-012675:notes:53]
Pro forma results of operations from the Data Center Business, CF Business, Campus Fabric Business and WLAN Business acquisitions included in the pro forma results of operations for the three and nine months ended March 31, 2017 have not been adjusted for the adoption of Topic 606 because the Company determined that it is impractical to estimate the impact of the adoption.

[0001564590-18-012675:notes:54]
[same as prior period, unchanged from 0001564590-18-001677:notes:56]

[0001564590-18-012675:notes:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Net revenues |  | $ | 262,004 |  |  | $ | 267,176 |  |  | $ | 799,044 |  |  | $ | 911,611 |  |
| Net loss |  | $ | (13,613 | ) |  | $ | (40,235 | ) |  | $ | (21,235 | ) |  | $ | (136,207 | ) |
| Net loss per share - basic |  | $ | (0.12 | ) |  | $ | (0.37 | ) |  | $ | (0.19 | ) |  | $ | (1.27 | ) |
| Net loss per share - diluted |  | $ | (0.12 | ) |  | $ | (0.37 | ) |  | $ | (0.19 | ) |  | $ | (1.27 | ) |
| Shares used in per share calculation - basic |  |  | 115,059 |  |  |  | 109,213 |  |  |  | 113,641 |  |  |  | 107,531 |  |
| Shares used in per share calculation - diluted |  |  | 115,059 |  |  |  | 109,213 |  |  |  | 113,641 |  |  |  | 107,531 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-012675:notes:56]
[same as prior period, unchanged from 0001564590-18-001677:notes:58]

[0001564590-18-012675:notes:57]
[same as prior period, unchanged from 0001564590-18-001677:notes:59]

[0001564590-18-012675:notes:58]
[same as prior period, unchanged from 0001564590-18-001677:notes:60]

[0001564590-18-012675:notes:59]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-18-012675:notes:60]
[same as prior period, unchanged from 0001564590-18-001677:notes:62]

[0001564590-18-012675:notes:61]
[same as prior period, unchanged from 0001564590-18-001677:notes:63]

[0001564590-18-012675:notes:62]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-18-012675:notes:63]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-18-012675:notes:64]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and nine months ended March 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-18-012675:notes:65]
On March 31, 2018, the Company had $156.6 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 33 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 48 percent in fiscal 2019 and 19 percent of the balance thereafter.

[0001564590-18-012675:notes:66]
[same as prior period, unchanged from 0001564590-18-001677:notes:68]

[0001564590-18-012675:notes:67]
Revenue recognized for the nine months ended March 31, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $66.7 million and $61.4 million, respectively. Revenue recognized for the three months ended March 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $31.3 million, respectively.

[0001564590-18-012675:notes:68]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.1 million and $2.5 million at March 31, 2018 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2018 and 2017, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the nine months ended March 31, 2018 and 2017 was $1.4 million and $1.1 million, respectively.  There was no impairment loss in relation to the costs capitalized.

[0001564590-18-012675:notes:69]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands, unaudited):

[0001564590-18-012675:notes:70]
|  |  | Three Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |  | $ | 31,972 |  | $ | 47,367 |  | $ | 79,339 |  |
| Other |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |  |  | 1,559 |  |  | 1,901 |  |  | 3,460 |  |
| Total Americas |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |  |  | 33,531 |  |  | 49,268 |  |  | 82,799 |  |
| EMEA: |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |  |  | 32,090 |  |  | 20,136 |  |  | 52,226 |  |
| APAC: |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |  |  | 2,399 |  |  | 11,772 |  |  | 14,171 |  |
| Total net revenues |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |  | $ | 68,020 |  | $ | 81,176 |  | $ | 149,196 |  |

[0001564590-18-012675:notes:71]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |  | $ | 98,026 |  | $ | 112,592 |  | $ | 210,618 |  |
| Other |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |  |  | 5,779 |  |  | 14,772 |  |  | 20,551 |  |
| Total Americas |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |  |  | 103,805 |  |  | 127,364 |  |  | 231,169 |  |
| EMEA: |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |  |  | 99,459 |  |  | 61,026 |  |  | 160,485 |  |
| APAC: |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |  |  | 5,464 |  |  | 31,059 |  |  | 36,523 |  |
| Total net revenues |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |  | $ | 208,728 |  | $ | 219,449 |  | $ | 428,177 |  |

[0001564590-18-012675:notes:72]
Business Combinations

[0001564590-18-012675:notes:73]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0001564590-18-012675:notes:74]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized in the statements of operations. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-18-012675:notes:75]
4.Recent Accounting Pronouncements

[0001564590-18-012675:notes:76]
Recently Issued Accounting Pronouncements

[0001564590-18-012675:notes:77]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718. Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The guidance is effective prospectively for fiscal years beginning after December 15, 2017, and interim periods within that reporting period. Early adoption is permitted, including adoption in any interim period. The Company does not expect the adoption of this guidance to have a material effect on its financial statements. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-18-012675:notes:78]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice.  The new guidance is effective for fiscal years beginning after December 15, 2017, and interim periods within that reporting period. The amendments in this update should be applied using a retrospective transition method to each period presented. If impracticable to apply the amendments retrospectively for some of the issues, the amendments for those issues would be applied prospectively as of the earliest date practicable. The Company does not expect the adoption of this guidance to have a material effect on its presentation of cash flows. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-18-012675:notes:79]
In January 2016, the FASB issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities.  The Company does not expect ASU 2016-01 will have a material effect on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2019.

[0001564590-18-012675:notes:80]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The guidance is effective for fiscal years beginning after December 15, 2018. The Company is evaluating the accounting, transition and disclosure requirements of the standard and cannot currently estimate the financial statement impact of adoption. This guidance is effective for the Company beginning with its fiscal year 2020.

[0001564590-18-012675:notes:81]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, Topic 842 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2020.

[0001564590-18-012675:notes:82]
Recently Adopted Accounting Pronouncements

[0001564590-18-012675:notes:83]
Revenues Recognition

[0001564590-18-012675:notes:84]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), to clarify the principles of recognizing revenue and create common revenue recognition guidance between U.S. GAAP and International Financial Reporting Standards. Under Topic 606, revenue is recognized when a customer obtains control of promised goods or services and is recognized at an amount that reflects the consideration expected to be received in exchange for such goods or services.  In addition, Topic 606 requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers.

[0001564590-18-012675:notes:85]
The Company adopted Topic 606 on July 1, 2017, using the full retrospective method. This adoption primarily affected the Company’s accounting for distributor and resellers revenues from a primarily “sell-through” model, where revenue is recognized upon the sale from the distribution channel to the end customer, to the “sell-in” method where revenue is recognized upon transfer of control to its customers, including distributors. Under the sell-in method, the Company is required to make estimates at the time of shipment to its distributors of variable consideration as well as estimated returns under stock rotation rights granted to the distributors.  Additionally, the Company capitalizes contract acquisition costs such as commissions paid for maintenance services contracts in excess of one year.  Following the adoption of Topic 606, the revenue recognition for the Company’s other sales arrangements remained materially consistent with our historical practice.

[0001564590-18-012675:notes:86]
Upon adoption of Topic 606, we applied the standard’s practical expedients that allows a) an entity to use the transaction price at the date the contract was completed rather than estimating variable consideration amounts in the comparative reporting periods, b) that permits the omission of prior-period information about our performance obligations, and c) that allows the Company to reflect the aggregate effect of all modifications that occur before the beginning of the earliest period presented when identifying the satisfied and unsatisfied performance obligations, determining the transaction price and allocating the transaction price to the satisfied and unsatisfied performance obligations.

[0001564590-18-012675:notes:87]
See the tables at the end of this note for the effects of the adoption of Topic 606 on our condensed consolidated financial statements as of June 30, 2017, and for the three and nine months ended March 31, 2018 and 2017.  See Note 3. “Summary of Significant Accounting Policies” to our condensed consolidated financial statements for further discussion of the effects of the adoption of Topic 606 on our significant accounting policies.

[0001564590-18-012675:notes:88]
Adjustments to Previously Reported Financial Statements from the Adoption of Accounting Pronouncements

[0001564590-18-012675:notes:89]
The following table presents the effect of the adoption of Topic 606 on our condensed consolidated balance sheet (unaudited) as of June 30, 2017, (in thousands):

[0001564590-18-012675:notes:90]
|  | As of June 30, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Accounts receivable, net | $ | 120,770 |  |  | $ | (27,655 | ) |  | $ | 93,115 |  |
| Inventories |  | 45,880 |  |  |  | 1,530 |  |  |  | 47,410 |  |
| Total current assets |  | 324,967 |  |  |  | (26,125 | ) |  |  | 298,842 |  |
| Other assets |  | 22,586 |  |  |  | 2,479 |  |  |  | 25,065 |  |
| Total assets |  | 483,346 |  |  |  | (23,646 | ) |  |  | 459,700 |  |
| Accrued warranty |  | 10,007 |  |  |  | 577 |  |  |  | 10,584 |  |
| Other accrued liabilities |  | 36,713 |  |  |  | 331 |  |  |  | 37,044 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 43,525 |  |  |  | (43,525 | ) |  |  | — |  |
| Total current liabilities |  | 255,822 |  |  |  | (42,617 | ) |  |  | 213,205 |  |
| Accumulated deficit |  | (800,257 | ) |  |  | 18,971 |  |  |  | (781,286 | ) |
| Total stockholders’ equity |  | 106,707 |  |  |  | 18,971 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity | $ | 483,346 |  |  | $ | (23,646 | ) |  | $ | 459,700 |  |

[0001564590-18-012675:notes:91]
The following tables present the effect of the adoption of Topic 606 on our condensed consolidated statements of operations (unaudited) for the three and nine months ended March 31, 2017 (in thousands, except per share amounts):

[0001564590-18-012675:notes:92]
|  | Three Months Ended March 31, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 110,789 |  |  | $ | 532 |  |  | $ | 111,321 |  |
| Service |  | 37,875 |  |  |  | — |  |  |  | 37,875 |  |
| Total net revenues |  | 148,664 |  |  |  | 532 |  |  |  | 149,196 |  |
| Cost of revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 52,401 |  |  |  | (126 | ) |  |  | 52,275 |  |
| Service |  | 14,117 |  |  |  | — |  |  |  | 14,117 |  |
| Total cost of revenues |  | 66,518 |  |  |  | (126 | ) |  |  | 66,392 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 58,388 |  |  |  | 658 |  |  |  | 59,046 |  |
| Service |  | 23,758 |  |  |  | — |  |  |  | 23,758 |  |
| Total Gross profit |  | 82,146 |  |  |  | 658 |  |  |  | 82,804 |  |
| Sales and marketing expenses |  | 38,759 |  |  |  | 31 |  |  |  | 38,790 |  |
| Operating loss |  | (3,246 | ) |  |  | 627 |  |  |  | (2,619 | ) |
| Net loss before tax |  | (4,438 | ) |  |  | 627 |  |  |  | (3,811 | ) |
| Net loss | $ | (5,604 | ) |  | $ | 627 |  |  | $ | (4,977 | ) |
| Basic and diluted net loss per share |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.05 | ) |  |  |  |  |  | $ | (0.05 | ) |
| Net loss per share - diluted | $ | (0.05 | ) |  |  |  |  |  | $ | (0.05 | ) |
| Shares used in per share calculation - basic |  | 109,213 |  |  |  |  |  |  |  | 109,213 |  |
| Shares used in per share calculation - diluted |  | 109,213 |  |  |  |  |  |  |  | 109,213 |  |

[0001564590-18-012675:notes:93]
|  | Nine Months Ended March 31, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 310,709 |  |  | $ | 8,760 |  |  | $ | 319,469 |  |
| Service |  | 108,708 |  |  |  | — |  |  |  | 108,708 |  |
| Total net revenues |  | 419,417 |  |  |  | 8,760 |  |  |  | 428,177 |  |
| Cost of revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 155,987 |  |  |  | 3,164 |  |  |  | 159,151 |  |
| Service |  | 40,684 |  |  |  | — |  |  |  | 40,684 |  |
| Total cost of revenues |  | 196,671 |  |  |  | 3,164 |  |  |  | 199,835 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 154,722 |  |  |  | 5,596 |  |  |  | 160,318 |  |
| Service |  | 68,024 |  |  |  | — |  |  |  | 68,024 |  |
| Total Gross profit |  | 222,746 |  |  |  | 5,596 |  |  |  | 228,342 |  |
| Sales and marketing expenses |  | 116,824 |  |  |  | (150 | ) |  |  | 116,674 |  |
| Operating loss |  | (15,367 | ) |  |  | 5,746 |  |  |  | (9,621 | ) |
| Net loss before tax |  | (17,442 | ) |  |  | 5,746 |  |  |  | (11,696 | ) |
| Net loss | $ | (20,694 | ) |  | $ | 5,746 |  |  | $ | (14,948 | ) |
| Basic and diluted net loss per share |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.19 | ) |  |  |  |  |  | $ | (0.14 | ) |
| Net loss per share - diluted | $ | (0.19 | ) |  |  |  |  |  | $ | (0.14 | ) |
| Shares used in per share calculation - basic |  | 107,531 |  |  |  |  |  |  |  | 107,531 |  |
| Shares used in per share calculation - diluted |  | 107,531 |  |  |  |  |  |  |  | 107,531 |  |

[0001564590-18-012675:notes:94]
The following tables present the effect of the adoption of Topic 606 on our condensed consolidated statement of cash flows (unaudited) for the nine months ended March 31, 2017 (in thousands):

[0001564590-18-012675:notes:95]
|  | Nine Months Ended March 31, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (20,694 | ) |  | $ | 5,746 |  |  | $ | (14,948 | ) |
| Changes in operating assets and liabilities, net |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | (5,926 | ) |  |  | 13,158 |  |  |  | 7,232 |  |
| Inventories |  | 6,344 |  |  |  | (1,620 | ) |  |  | 4,724 |  |
| Prepaid expenses and other assets |  | 8,181 |  |  |  | (150 | ) |  |  | 8,031 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 17,441 |  |  |  | (17,441 | ) |  |  | — |  |
| Other current and long-term liabilities |  | 5,887 |  |  |  | 307 |  |  |  | 6,194 |  |
| Net cash provided by operating activities |  | 43,961 |  |  |  | — |  |  |  | 43,961 |  |
| Cash flows from investing activities |  | (69,159 | ) |  |  | — |  |  |  | (69,159 | ) |
| Cash flows from financing activities |  | 48,328 |  |  |  | — |  |  |  | 48,328 |  |
| Foreign currency effect on cash |  | 28 |  |  |  | — |  |  |  | 28 |  |
| Net increase in cash and cash equivalents | $ | 23,158 |  |  | $ | — |  |  | $ | 23,158 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-012675:notes:96]
[same as prior period, unchanged from 0001564590-18-001677:notes:93]

[0001564590-18-012675:notes:97]
[same as prior period, unchanged from 0001564590-18-001677:notes:94]

[0001564590-18-012675:notes:98]
[same as prior period, unchanged from 0001564590-18-001677:notes:95]

[0001564590-18-012675:notes:99]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Cash |  | $ | 98,677 |  |  | $ | 126,159 |  |
| Cash equivalents |  |  | 4,500 |  |  |  | 4,291 |  |
| Total cash and cash equivalents |  |  | 103,177 |  |  |  | 130,450 |  |
| Marketable securities (consisting of available-for-sale securities) |  |  | 2,091 |  |  |  | — |  |
| Total cash, cash equivalents and marketable securities |  | $ | 105,268 |  |  | $ | 130,450 |  |

[0001564590-18-012675:notes:100]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Marketable securities are recorded in “Prepaid expense and other current assets” in the accompanying condensed consolidated balance sheet as these are publicly-traded equity securities. Marketable securities are classified as available-for-sale and reported at fair value with unrealized gains and losses included in “Accumulated other comprehensive loss” in the accompanying condensed consolidated balance sheets.

[0001564590-18-012675:notes:101]
[same as prior period, unchanged from 0001564590-18-001677:notes:98]

[0001564590-18-012675:notes:102]
[same as prior period, unchanged from 0001564590-18-001677:notes:99]

[0001564590-18-012675:notes:103]
[same as prior period, unchanged from 0001564590-18-001677:notes:100]

[0001564590-18-012675:notes:104]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As Adjusted) |  |
| Finished goods |  | $ | 63,306 |  |  | $ | 46,620 |  |
| Raw materials |  |  | 14,450 |  |  |  | 790 |  |
| Total Inventories |  | $ | 77,756 |  |  | $ | 47,410 |  |

[0001564590-18-012675:notes:105]
[same as prior period, unchanged from 0001564590-18-001677:notes:102]

[0001564590-18-012675:notes:106]
[same as prior period, unchanged from 0001564590-18-001677:notes:103]

[0001564590-18-012675:notes:107]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Computers and equipment |  | $ | 69,712 |  |  | $ | 34,716 |  |
| Purchased software |  |  | 16,908 |  |  |  | 11,785 |  |
| Office equipment, furniture and fixtures |  |  | 18,143 |  |  |  | 10,852 |  |
| Leasehold improvements |  |  | 47,039 |  |  |  | 23,046 |  |
| Total property and equipment |  |  | 151,802 |  |  |  | 80,399 |  |
| Less: accumulated depreciation and amortization |  |  | (65,315 | ) |  |  | (50,159 | ) |
| Property and equipment, net |  | $ | 86,487 |  |  | $ | 30,240 |  |

[0001564590-18-012675:notes:108]
[same as prior period, unchanged from 0001564590-18-001677:notes:105]

[0001564590-18-012675:notes:109]
[same as prior period, unchanged from 0001564590-18-001677:notes:106]

[0001564590-18-012675:notes:110]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.8 years |  | $ | 117,500 |  |  | $ | 52,860 |  |  | $ | 64,640 |  |
| Customer relationships |  | 3.7 years |  |  | 51,639 |  |  |  | 39,577 |  |  |  | 12,062 |  |
| Maintenance contracts |  | 0.6 years |  |  | 17,000 |  |  |  | 15,016 |  |  |  | 1,984 |  |
| Trade names |  | 3.7 years |  |  | 9,100 |  |  |  | 3,776 |  |  |  | 5,324 |  |
| Backlogs |  | — years |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |
| License agreements |  | 5.9 years |  |  | 2,445 |  |  |  | 1,323 |  |  |  | 1,122 |  |
| Other intangibles |  | 1.9 years |  |  | 1,382 |  |  |  | 1,108 |  |  |  | 274 |  |
| Total intangibles, net |  |  |  | $ | 200,866 |  |  | $ | 115,460 |  |  | $ | 85,406 |  |

[0001564590-18-012675:notes:111]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 5.3 years |  | $ | 55,400 |  |  | $ | 42,689 |  |  | $ | 12,711 |  |
| Customer relationships |  | 3.3 years |  |  | 40,300 |  |  |  | 37,567 |  |  |  | 2,733 |  |
| Maintenance contracts |  | 1.3 years |  |  | 17,000 |  |  |  | 12,467 |  |  |  | 4,533 |  |
| Trade names |  | 4.3 years |  |  | 5,100 |  |  |  | 2,846 |  |  |  | 2,254 |  |
| License agreements |  | 6.4 years |  |  | 2,445 |  |  |  | 1,120 |  |  |  | 1,325 |  |
| Other intangibles |  | 2.7 years |  |  | 1,382 |  |  |  | 1,001 |  |  |  | 381 |  |
| Total intangibles, net with finite lives |  |  |  |  | 121,627 |  |  |  | 97,690 |  |  |  | 23,937 |  |
| In-process research and development, with indefinite life |  |  |  |  | 1,400 |  |  |  | — |  |  |  | 1,400 |  |
| Total intangibles, net |  |  |  | $ | 123,027 |  |  | $ | 97,690 |  |  | $ | 25,337 |  |

[0001564590-18-012675:notes:112]
During the three months ended September 30, 2017, in-process research and development of $1.4 million included in the above table was reclassified to developed technology upon completion of the project and is being amortized over its estimated useful life.

[0001564590-18-012675:notes:113]
[same as prior period, unchanged from 0001564590-18-001677:notes:110]

[0001564590-18-012675:notes:114]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 4,647 |  |  | $ | 995 |  |  | $ | 11,310 |  |  | $ | 6,271 |  |
| Amortization of intangibles |  |  | 2,101 |  |  |  | 1,193 |  |  |  | 6,461 |  |  |  | 7,510 |  |
| Total amortization |  | $ | 6,748 |  |  | $ | 2,188 |  |  | $ | 17,771 |  |  | $ | 13,781 |  |

[0001564590-18-012675:notes:115]
[same as prior period, unchanged from 0001564590-18-001677:notes:112]

[0001564590-18-012675:notes:116]
[same as prior period, unchanged from 0001564590-18-001677:notes:113]

[0001564590-18-012675:notes:117]
[same as prior period, unchanged from 0001564590-18-001677:notes:114]

[0001564590-18-012675:notes:118]
|  |  | March 31, 2018 |  |
| Balance as of June 30, 2017 |  | $ | 80,216 |  |
| Additions due to acquisitions |  |  | 49,028 |  |
| Balance at end of period |  | $ | 129,244 |  |

[0001564590-18-012675:notes:119]
During the nine months ended March 31, 2018, the Company completed acquisitions of the Campus Fabric Business and the Data Center Business, resulting in an additional goodwill of $36.4 million and $12.6 million, respectively.  See Note 2 for additional information related to the acquisitions.

[0001564590-18-012675:notes:120]
[same as prior period, unchanged from 0001564590-18-001677:notes:117]

[0001564590-18-012675:notes:121]
The Company offers for sale to its customers, renewable support arrangements that range from one to five years as well as professional and training services, which results in deferred revenue.

[0001564590-18-012675:notes:122]
[same as prior period, unchanged from 0001564590-18-001677:notes:119]

[0001564590-18-012675:notes:123]
[same as prior period, unchanged from 0001564590-18-001677:notes:120]

[0001564590-18-012675:notes:124]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 25,260 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (540 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 24,720 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 145,173 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,215 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 153,958 |  |  |  | 80,422 |  |
| Total debt |  | $ | 178,678 |  |  | $ | 92,702 |  |

[0001564590-18-012675:notes:125]
In connection with the closing of Campus Fabric Business discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility.  On July 14, 2017, the Company borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.

[0001564590-18-012675:notes:126]
In connection with the closing of the acquisition of the Data Center Business discussed in Note 2, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”) on October 26, 2017. Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Data Center Business Purchase Agreement (as defined above). On the Data Center Business Closing Date, the Company borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.

[0001564590-18-012675:notes:127]
[same as prior period, unchanged from 0001564590-18-001677:notes:124]

[0001564590-18-012675:notes:128]
The Company had $1.2 million of outstanding letters of credit and $48.8 million of availability under the Revolver as of March 31, 2018.

[0001564590-18-012675:notes:129]
On May 1, 2018, the Company terminated the Credit Facility.

[0001564590-18-012675:notes:130]
On May 1, 2018, the Company entered into a Credit Agreement (the “New Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The New Credit Agreement provides for a $40 million five-year revolving credit facility (the “New Revolver”) and a $190 million five-year term loan (the “New Term Loan” and together with the New Revolver, the “New Senior Secured Credit Facilities”). On May 1, 2018, the Company borrowed $200 million under the New Senior Secured Credit Facilities in order to pay off existing debt and for general corporate purposes.

[0001564590-18-012675:notes:131]
See Note 14 (Subsequent Events) to the condensed consolidated financial statements for more information on the New Credit Agreement.

[0001564590-18-012675:notes:132]
[same as prior period, unchanged from 0001564590-18-001677:notes:126]

[0001564590-18-012675:notes:133]
[same as prior period, unchanged from 0001564590-18-001677:notes:127]

[0001564590-18-012675:notes:134]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2018 and 2017 (in thousands):

[0001564590-18-012675:notes:135]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Balance beginning of period |  | $ | 13,010 |  |  | $ | 10,790 |  |  | $ | 10,584 |  |  | $ | 9,998 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | — |  |  |  | 3,682 |  |  |  | 2,034 |  |
| New warranties issued |  |  | 2,872 |  |  |  | 1,893 |  |  |  | 6,801 |  |  |  | 3,997 |  |
| Warranty expenditures |  |  | (3,070 | ) |  |  | (2,080 | ) |  |  | (8,255 | ) |  |  | (5,426 | ) |
| Balance end of period |  | $ | 12,812 |  |  | $ | 10,603 |  |  | $ | 12,812 |  |  | $ | 10,603 |  |

[0001564590-18-012675:notes:136]
To facilitate sales of its products in the normal course of business, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.  It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-18-012675:notes:137]
[same as prior period, unchanged from 0001564590-18-001677:notes:131]

[0001564590-18-012675:notes:138]
[same as prior period, unchanged from 0001564590-18-001677:notes:132]

[0001564590-18-012675:notes:139]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Acquisition related deferred payments, less current portion |  | $ | 14,147 |  |  | $ | — |  |
| Acquisition-related contingent consideration obligations, less current portion |  |  | 33,256 |  |  |  | — |  |
| Other |  |  | 18,037 |  |  |  | 8,526 |  |
| Total other long-term liabilities |  | $ | 65,440 |  |  | $ | 8,526 |  |

[0001564590-18-012675:notes:140]
[same as prior period, unchanged from 0001564590-18-001677:notes:134]

[0001564590-18-012675:notes:141]
All advertising costs are expensed as incurred.  Advertising expenses for three and nine months ended March 31, 2018 and 2017, were immaterial.

[0001564590-18-012675:notes:142]
[same as prior period, unchanged from 0001564590-18-001677:notes:136]

[0001564590-18-012675:notes:143]
[same as prior period, unchanged from 0001564590-18-001677:notes:137]

[0001564590-18-012675:notes:144]
[same as prior period, unchanged from 0001564590-18-001677:notes:138]

[0001564590-18-012675:notes:145]
The following table sets forth major customers accounting for 10% or more of our net revenues:

[0001564590-18-012675:notes:146]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Westcon Group Inc. |  | 14% |  |  | 10% |  |  | 14% |  |  | 11% |  |
| Tech Data Corporation |  | 14% |  |  | 13% |  |  | 13% |  |  | 15% |  |
| Jenne Corporation |  | 13% |  |  | 14% |  |  | 11% |  |  | 14% |  |

[0001564590-18-012675:notes:147]
The following customers account for more than 10% of the Company’s accounts receivable outstanding as of March 31, 2018, Tech Data 18% and Westcon Group 14%


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-18-012675:notes:148]
[same as prior period, unchanged from 0001564590-18-001677:notes:143]

[0001564590-18-012675:notes:149]
[same as prior period, unchanged from 0001564590-18-001677:notes:144]

[0001564590-18-012675:notes:150]
[same as prior period, unchanged from 0001564590-18-001677:notes:145]

[0001564590-18-012675:notes:151]
[same as prior period, unchanged from 0001564590-18-001677:notes:146]

[0001564590-18-012675:notes:152]
[same as prior period, unchanged from 0001564590-18-001677:notes:147]

[0001564590-18-012675:notes:153]
[same as prior period, unchanged from 0001564590-18-001677:notes:148]

[0001564590-18-012675:notes:154]
| March 31, 2018 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,500 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,500 |  |
| Marketable securities |  |  | 2,091 |  |  |  | — |  |  |  | — |  |  |  | 2,091 |  |
| Total assets measured at fair value |  | $ | 6,591 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,591 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 46,526 |  |  | $ | 46,526 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 46,526 |  |  | $ | 46,526 |  |

[0001564590-18-012675:notes:155]
[same as prior period, unchanged from 0001564590-18-001677:notes:150]

[0001564590-18-012675:notes:156]
[same as prior period, unchanged from 0001564590-18-001677:notes:151]

[0001564590-18-012675:notes:157]
The Company holds investments in equity securities acquired from the sale of an investment in non-marketable equity securities during the first quarter of fiscal 2018, which is classified as available-for-sale marketable securities at Level 1 as the investments have readily determinable fair value (see below, Level 3 investments). An unrealized holding gain on the investments was $0.7 million as of March 31, 2018.

[0001564590-18-012675:notes:158]
Level 2 assets and liabilities:

[0001564590-18-012675:notes:159]
[same as prior period, unchanged from 0001564590-18-001677:notes:154]

[0001564590-18-012675:notes:160]
The fair value of the borrowings under the Credit Facility is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the face amount of the Company’s indebtedness of $178.7 million and $93.7 million as of March 31, 2018 and June 30, 2017, respectively. Such differences are immaterial for all periods presented.

[0001564590-18-012675:notes:161]
Level 3 assets and liabilities:

[0001564590-18-012675:notes:162]
[same as prior period, unchanged from 0001564590-18-001677:notes:157]

[0001564590-18-012675:notes:163]
As of June 30, 2017, the Company reflected its non-marketable equity investment as Level 3 in the fair value hierarchy as it is based on unobservable inputs that market participants would use in pricing this asset due to the absence of recent comparable market transactions and inherent lack of liquidity.  During fiscal 2015, the Company purchased a $3.0 million equity interest in a company that operated in the enterprise software platform industry.  The Company did not enter into any other transactions with the investee during fiscal 2017 or the first quarter of fiscal 2018.   During the three months ended September 30, 2017, the investee was acquired by a third party.  The Company received $6.8 million as consideration for its equity interest in the investee, including $5.4 million in cash and 65,937 shares of the third party’s publicly-traded common stock with a market value of $1.4 million. During the first quarter of fiscal 2018, the Company received $5.8 million of the consideration, consisting of $4.9 million in cash and 41,685 shares with a market value of $0.9 million. The remainder of the consideration consisting of $0.5 million of cash and $0.5 million of shares will remain in escrow for a period of 18 months from the date of sales for general representations and warranties. A gain of $3.8 million related to this sale was recorded in “Other income (expense), net” in the accompanying condensed consolidated statement of operations for the nine months ended March 31, 2018. The 41,685 shares received and 23,252 shares held in escrow as of March 31, 2018 were considered Level 1 investments as these have readily determinable fair value and quoted prices in active markets.

[0001564590-18-012675:notes:164]
During the quarter ended December 31, 2017, the Company recorded a liability for contingent consideration related to its acquisitions of the Data Center Business and the CF Business (see Note 2 for additional information related to the acquisitions). The fair value measurement of the contingent consideration obligations is determined using Level 3 inputs. The fair value of contingent consideration obligations is based on a discounted cash flow model.  These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations would be recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-18-012675:notes:165]
[same as prior period, unchanged from 0001564590-18-001677:notes:160]

[0001564590-18-012675:notes:166]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2018 |  |
| Beginning balance |  | $ | 47,030 |  |  | $ | — |  |
| Initial fair value measurements |  |  | — |  |  |  | 47,030 |  |
| Payments |  |  | (671 | ) |  |  | (671 | ) |
| Accretion on discount |  |  | 1,401 |  |  |  | 1,401 |  |
| Change in fair value |  |  | (1,234 | ) |  |  | (1,234 | ) |
| Ending balance |  | $ | 46,526 |  |  | $ | 46,526 |  |

[0001564590-18-012675:notes:167]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the first nine months of fiscal year 2018 or 2017. There were no impairments recorded for the first nine months of fiscal 2018 or 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-012675:notes:168]
[same as prior period, unchanged from 0001564590-18-001677:notes:163]

[0001564590-18-012675:notes:169]
[same as prior period, unchanged from 0001564590-18-001677:notes:164]

[0001564590-18-012675:notes:170]
[same as prior period, unchanged from 0001564590-18-001677:notes:165]

[0001564590-18-012675:notes:171]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| 2014 Employee Stock Purchase Plan |  |  | 5,365 |  |  |  | 7,785 |  |
| Employee stock options and awards outstanding |  |  | 10,405 |  |  |  | 9,726 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 11,944 |  |  |  | 7,629 |  |
| Total shares reserved for issuance |  |  | 27,714 |  |  |  | 25,140 |  |

[0001564590-18-012675:notes:172]
[same as prior period, unchanged from 0001564590-18-001677:notes:167]

[0001564590-18-012675:notes:173]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| Cost of product revenue |  | $ | 163 |  |  | $ | 73 |  |  | $ | 389 |  |  | $ | 262 |  |
| Cost of service revenue |  |  | 354 |  |  |  | 56 |  |  |  | 783 |  |  |  | 475 |  |
| Research and development |  |  | 2,367 |  |  |  | 625 |  |  |  | 5,247 |  |  |  | 2,593 |  |
| Sales and marketing |  |  | 2,735 |  |  |  | 809 |  |  |  | 7,077 |  |  |  | 3,129 |  |
| General and administrative |  |  | 2,199 |  |  |  | 911 |  |  |  | 6,150 |  |  |  | 2,869 |  |
| Total share-based compensation expense |  | $ | 7,818 |  |  | $ | 2,474 |  |  | $ | 19,646 |  |  | $ | 9,328 |  |

[0001564590-18-012675:notes:174]
During the nine months ended March 31, 2018 or 2017, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-18-012675:notes:175]
[same as prior period, unchanged from 0001564590-18-001677:notes:170]

[0001564590-18-012675:notes:176]
[same as prior period, unchanged from 0001564590-18-001677:notes:171]

[0001564590-18-012675:notes:177]
The following table summarizes stock award activity for the nine months ended March 31, 2018 (in thousands, except grant date fair value):

[0001564590-18-012675:notes:178]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2017 |  |  | 6,664 |  |  | $ | 4.66 |  |  | $ | 61,440 |  |
| Granted |  |  | 4,335 |  |  |  | 11.26 |  |  |  |  |  |
| Vested |  |  | (2,488 | ) |  |  | 3.75 |  |  |  |  |  |
| Cancelled |  |  | (374 | ) |  |  | 7.23 |  |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2018 |  |  | 8,137 |  |  | $ | 8.34 |  |  | $ | 90,084 |  |

[0001564590-18-012675:notes:179]
The following table summarizes stock option activity for the nine months ended March 31, 2018 (in thousands, except per share and contractual term):

[0001564590-18-012675:notes:180]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2017 |  |  | 3,062 |  |  | $ | 4.06 |  |  |  | 4.19 |  |  | $ | 15,868 |  |
| Exercised |  |  | (779 | ) |  |  | 4.56 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (15 | ) |  |  | 4.25 |  |  |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2018 |  |  | 2,268 |  |  | $ | 3.89 |  |  |  | 3.11 |  |  | $ | 16,283 |  |
| Vested and expected to vest at March 31, 2018 |  |  | 2,268 |  |  | $ | 3.89 |  |  |  | 3.11 |  |  | $ | 16,283 |  |
| Exercisable at March 31, 2018 |  |  | 1,961 |  |  | $ | 4.10 |  |  |  | 2.95 |  |  | $ | 13,670 |  |

[0001564590-18-012675:notes:181]
[same as prior period, unchanged from 0001564590-18-001677:notes:176]

[0001564590-18-012675:notes:182]
[same as prior period, unchanged from 0001564590-18-001677:notes:177]

[0001564590-18-012675:notes:183]
During the first quarter of fiscal 2018, the Company approved the grant of 1,154,014 stock awards to its vice president level employees or above (“VPs”), including 560,344 stock awards to its Executive Officers, and 939,925 stock awards to its other employees.  Fifty percent (50%) of the stock awards granted to the VPs, except the chief executive officer, were in the form of PSUs, with grant date fair values of $10.90, and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs. The Company’s chief executive officer received sixty percent (60%) of his stock award grant in the form of PSUs, while forty percent (40%) of this award were in the form of RSUs, with a grant date fair value of $10.90.  The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.   No PSUs were granted during the second quarter of fiscal 2018.

[0001564590-18-012675:notes:184]
For the PSUs referenced in the preceding paragraph, they will be considered earned once the Company’s combined earnings per share equals or exceeds $0.32 for two consecutive quarters (the “FY18 Performance Threshold”).  Upon satisfying the FY18 Performance Threshold, the PSUs shall vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, shall vest on the same schedule as the RSUs, subject to continued service to the Company.  If the FY18 Performance Threshold is not met by the third anniversary of the grant date the award is canceled.  In addition, the FY18 Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $16.00 per share.

[0001564590-18-012675:notes:185]
During the three and nine months ended March 31, 2018, none of the PSU grants referenced above achieved their FY18 Performance Threshold.

[0001564590-18-012675:notes:186]
During the third quarter of fiscal 2018, the Company approved the grant of 100,000 stock awards with market-based vesting criteria to certain VPs with grant date fair values ranging from $10.61 to $12.19 determined by using the Monte-Carlo simulation model.

[0001564590-18-012675:notes:187]
During the first quarter of fiscal 2017, the Company approved the grant of 1,505,120 stock awards to its VPs, including 680,000 stock awards to its Executive Officers, and 1,053,300 stock awards to other Company employees.  Fifty percent (50%) of the stock awards granted to the VPs were in the form of PSUs, with grant date fair values ranging from $3.02 to $3.09, and fifty percent (50%) of the stock awards granted were in the form of RSUs.   The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.  No PSUs were granted during the second quarter of fiscal 2017.

[0001564590-18-012675:notes:188]
[same as prior period, unchanged from 0001564590-18-001677:notes:182]

[0001564590-18-012675:notes:189]
[same as prior period, unchanged from 0001564590-18-001677:notes:183]

[0001564590-18-012675:notes:190]
The fair value of each share purchase option under the Company’s 2014 Employee Stock Purchase Plan (“ESPP”) is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of the ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-18-012675:notes:191]
There were 1,151,759 and 1,114,707 shares issued under the ESPP during the three months ended March 31, 2018 and 2017, respectively.  There were 2,419,689 and 2,218,306 shares issued under the ESPP during the nine months ended March 31, 2018 and 2017, respectively. The following assumptions were used to calculate the fair value of shares granted under the ESPP during the following periods:

[0001564590-18-012675:notes:192]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 1.15 | % |  |  | 0.40 | % |  | 1.64%–1.15% |  |  |  | 0.40 | % |
| Volatility |  |  | 42 | % |  |  | 37 | % |  |  | 42 | % |  | 40%–37% |  |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-18-012675:notes:193]
The weighted-average fair value of shares granted under the ESPP during the three months ended March 31, 2018 and 2017 was $4.00 and $1.34, respectively. The weighted-average fair value of shares granted under the ESPP during the nine months ended March 31, 2018 and 2017 was $3.26 and $1.24, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-012675:notes:194]
[same as prior period, unchanged from 0001564590-18-001677:notes:187]

[0001564590-18-012675:notes:195]
2018 Restructuring

[0001564590-18-012675:notes:196]
In the third quarter of fiscal 2018, the Company announced and began executing a reduction-in-force (the “2018 Restructuring”) to re-align the Company’s resources as a result of the Company’s recent acquisitions of the Campus Fabric Business and the Data Center Business. The Company recorded $4.9 million related to employee severance and benefits expenses during the three months ended March 31, 2018.

[0001564590-18-012675:notes:197]
2017 Restructuring

[0001564590-18-012675:notes:198]
The Company recorded restructuring charges, net of $7.7 million and $9.6 million for the three and nine months ended March 31, 2017, respectively.  Pursuant with the WLAN Business acquisition from Zebra, the Company assumed a facility lease located at and transferred its headquarters to 6480 Via del Oro, San Jose, California.  The Company consolidated its existing workforce from the Company’s previous headquarters location on Rio Robles Drive in San Jose, California, with employees assumed from Zebra at the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to the Company’s cease use of the Rio Robles facility and abandonment of all leasehold improvements, it accelerated the amortization of the remaining leasehold improvements balance for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  The Company recorded accelerated amortization expense for the three and nine months ended March 31, 2017 of $0.9 million and $2.6 million respectively, and it is reflected in “Restructuring and related charges, net of reversals” in the condensed consolidated statements of operations.

[0001564590-18-012675:notes:199]
The Company entered into an agreement to sublease its Rio Robles California site during the third quarter of fiscal 2017.  The sublease is for the remaining duration of the Company’s lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease.  The net adjustments resulted in a charge of $1.5 million during the third quarter of fiscal 2017.   Previously, in the second quarter of fiscal 2017, the Company had modified its estimated future obligations for non-cancelable lease payments and related future sub-leasing income and recorded charges of $0.1 million.  The excess facilities payments will continue through fiscal year 2023, due to the length of the lease agreements.

[0001564590-18-012675:notes:200]
In conjunction with the above noted actions, the Company announced a reduction-in-force during the quarter ended March 31, 2017 affecting 90 employees.  The Company recorded $5.3 million in severance and benefits charges during the period.

[0001564590-18-012675:notes:201]
[same as prior period, unchanged from 0001564590-18-001677:notes:190]

[0001564590-18-012675:notes:202]
[same as prior period, unchanged from 0001564590-18-001677:notes:192]

[0001564590-18-012675:notes:203]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2017 |  | $ | 2,184 |  |  | $ | 1,853 |  |  | $ | 85 |  |  | $ | 4,122 |  |
| Period charges |  |  | — |  |  |  | 4,920 |  |  |  | — |  |  |  | 4,920 |  |
| Period payments |  |  | (516 | ) |  |  | (4,198 | ) |  |  | (73 | ) |  |  | (4,787 | ) |
| Balance as of March 31, 2018 |  | $ | 1,668 |  |  | $ | 2,575 |  |  | $ | 12 |  |  | $ | 4,255 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,920 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,335 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-012675:notes:204]
| 9. | Commitments and Contingencies |

[0001564590-18-012675:notes:205]
Purchase Commitments

[0001564590-18-012675:notes:206]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2018, the Company had non-cancelable commitments to purchase $151.5 million of such inventory.  As of March 31, 2018 the Company had non-cancelable software and maintenance support commitments to purchase $17.5 million of software and support services.

[0001564590-18-012675:notes:207]
Legal Proceedings

[0001564590-18-012675:notes:208]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-18-012675:notes:209]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-18-012675:notes:210]
Brazilian Tax Assessment Matter

[0001564590-18-012675:notes:211]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (approximately U.S. $1.0 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of March 31, 2018.

[0001564590-18-012675:notes:212]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.8 million (approximately U.S. $5.1 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of March 31, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

[0001564590-18-012675:notes:213]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (approximately U.S. $2.8 million) as of the date the Company acquired Enterasys Networks.

[0001564590-18-012675:notes:214]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-18-012675:notes:215]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-18-012675:notes:216]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The Company believes plaintiffs’ claims are without merit, and intends to defend them vigorously.

[0001564590-18-012675:notes:217]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation now has ended.

[0001564590-18-012675:notes:218]
XR Communications, LLC d/b/a Vivato Technologies, LLC v. Extreme Networks, Inc.

[0001564590-18-012675:notes:219]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In an order dated April 10, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board of inter partes review petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date), and scheduled a status conference on October 22, 2018.  The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-012675:notes:220]
DIFF Scale Operation Research, LLC v. Extreme Networks, Inc.

[0001564590-18-012675:notes:221]
On March 15, 2018, DIFF Scale Operation Research, LLC (“DIFF”) filed a patent infringement lawsuit against the Company in the United States District Court for the Southern District of New York (DIFF Scale Operation Research, LLC v. Extreme Networks, Inc., No. 18-cv-2324-KBF).  The complaint alleges infringement of seven patents (four expired) generally directed to virtual connection networking, and accuses a variety of products, including: (1) SLX router and switch products, and NetIron and MLX products; (2) Extreme Management Center versions 7.0.9, 7.1.3, 8.0, and 8.1; (3) ExtremeSwitching and Summit Series switches; and (4) ERS 3000 Series, 4000 Series, and 5000 Series switches.  DIFF seeks unspecified and enhanced damages, pre- and post-judgment interest, attorneys’ fees and costs (but no injunction).  The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-012675:notes:222]
Be Labs, Inc. v. Extreme Networks, Inc.

[0001564590-18-012675:notes:223]
On April 25, 2018, Be Labs, Inc. (“Be Labs”) filed a patent infringement lawsuit against the Company in the United States District Court for the District of Delaware (Be Labs, Inc. v. Extreme Networks, Inc., No. 1:18-cv-00626).  The complaint alleges direct and indirect infringement of two patents generally directed to a multimedia wireless distribution system for home or office use, and appears to accuse the Company’s 802.11ac- and 802.11n-compliant ExtremeWireless products.  Be Labs seeks damages, pre- and post-judgment interest, attorneys’ fees, costs, and a permanent injunction.  The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-012675:notes:224]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-18-012675:notes:225]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and our Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-012675:notes:226]
Indemnification Obligations

[0001564590-18-012675:notes:227]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-012675:notes:228]
[same as prior period, unchanged from 0001564590-18-001677:notes:212]

[0001564590-18-012675:notes:229]
For the three months ended March 31, 2018 and 2017, the Company recorded income tax provision of $1.7 million and $1.2 million, respectively.  For the nine months ended March 31, 2018 and 2017, the Company recorded income tax provision of $1.8 million and $3.3 million, respectively.

[0001564590-18-012675:notes:230]
The income tax provisions for the three months ended March 31, 2018 and 2017, consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the Zebra WLAN Business and the Campus Fabric Business. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended March 31, 2018 and 2017, and therefore may not reflect the annual effective tax rate.

[0001564590-18-012675:notes:231]
The income tax provisions for the nine months ended March 31, 2018 and 2017 consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisitions referenced above.  The income tax provision for the nine months ended March 31, 2018 is offset by a tax benefit of $2.5 million resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to our deferred tax liability related to amortizable goodwill as required by the recently enacted U.S. tax legislation discussed below.

[0001564590-18-012675:notes:232]
[same as prior period, unchanged from 0001564590-18-001677:notes:216]

[0001564590-18-012675:notes:233]
The TCJA’s primary change is a reduction in the U.S. Federal statutory corporate tax rate from 35% to 21%, including a pro rata reduction from 35% to 28% for the Company in fiscal 2018.  As a result, the Company has recognized a tax benefit in the amount of $2.5 million in the second quarter of fiscal 2018 due to the revaluation of the Company's deferred tax liability related to amortizable goodwill to reflect the lower statutory rate.  Because the U.S. deferred tax assets are offset by a full valuation allowance, the reduction in deferred tax assets for the lower rate was fully offset by a corresponding reduction in valuation allowance resulting in no additional tax provision.

[0001564590-18-012675:notes:234]
[same as prior period, unchanged from 0001564590-18-001677:notes:218]

[0001564590-18-012675:notes:235]
[same as prior period, unchanged from 0001564590-18-001677:notes:219]

[0001564590-18-012675:notes:236]
Amounts recorded where accounting is complete in the nine months ended March 31, 2018 principally relate to the reduction in the U.S. federal tax rate to 21 percent, which resulted in the Company reporting an income tax benefit of $2.5 million to remeasure deferred tax liabilities associated with indefinitely lived intangible assets that will reverse at the new 21% rate. Absent this deferred tax liability, the Company is in a net deferred tax asset position that is offset by a full valuation allowance.  Though the impact of the rate change related to net deferred tax assets has a net tax effect of zero, the accounting to determine the gross change in the deferred tax position and the offsetting valuation is not yet complete.  In accordance with Staff Accounting Bulletin (“SAB”) 118, the estimated income tax impact associated with the Transition Tax of zero represents our best estimate based on interpretation of the U.S. legislation as we are still accumulating data to finalize the underlying calculation. In accordance with SAB 118, estimated income tax impact associated with the Transition Tax is considered provisional and will be finalized prior to the end of the measurement period. The ultimate impact may differ from these provisional amounts, due to, among other things, additional analysis, changes in interpretations and assumptions the Company has made, additional regulatory guidance that may be issued, and actions the Company may take as a result of the TCJA.

[0001564590-18-012675:notes:237]
With respect to provisions of the TCJA effective for tax years beginning on or after January 1, 2018, the company anticipates several new provisions may potentially impact tax provisions in future periods including limitations on the deductibility of interest expense and certain executive compensation, a minimum tax on certain foreign earnings (i.e., global intangible low-taxed income or “GILTI”), as well as a base-erosion and anti-abuse tax (“BEAT”).  The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. Based on initial assessment and interpretation of the new provision, the Company expects that it will be subject to incremental U.S. tax on GILTI income beginning in fiscal 2019. The Company may elect to account for GILTI tax as a component of tax expense in the period in which it is incurred or account for the GILTI tax in the measurement of deferred taxes. The Company is continuing to evaluate this particular provision and therefore has not yet elected a method but will do so once our analysis is complete. The BEAT provisions in the Tax Reform Act eliminate the deduction of certain base-erosion payments made to related foreign corporations, and impose a minimum tax if greater than regular tax.  There is a reasonable amount of uncertainty surrounding the interpretation of this new provision, however, based on initial assessment and a conservative interpretation of the new provision, the Company expects that it will be subject to the incremental U.S. tax on BEAT income beginning in fiscal 2019.

[0001564590-18-012675:notes:238]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as the deferred tax assets in Australia and Brazil. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions.  This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-18-012675:notes:239]
The acquisition of Enterasys in October 2013 included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  Additionally, the Company completed asset purchases of the Zebra WLAN Business, the Campus Fabric Business and the Brocade Data Center Business in October 2016, July 2017 and October 2017, respectively.  The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.  During the three and nine months ended March 31, 2018, the Company deducted $1.8 million and $5.5 million of tax amortization expense respectively, for each period related to capitalized goodwill resulting from these acquisitions. As of March 31, 2018, the Company recorded a deferred tax liability of $5.3 million related to this goodwill amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-18-012675:notes:240]
The Company had $18.5 million of unrecognized tax benefits as of March 31, 2018.  The future impact of the unrecognized tax benefit of $18.5 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-18-012675:notes:241]
[same as prior period, unchanged from 0001564590-18-001677:notes:225]

[0001564590-18-012675:notes:242]
[same as prior period, unchanged from 0001564590-18-001677:notes:226]


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-012675:notes:243]
[same as prior period, unchanged from 0001564590-18-001677:notes:227]

[0001564590-18-012675:notes:244]
[same as prior period, unchanged from 0001564590-18-001677:notes:228]

[0001564590-18-012675:notes:245]
[same as prior period, unchanged from 0001564590-18-001677:notes:229]

[0001564590-18-012675:notes:246]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Net loss |  | $ | (13,613 | ) |  | $ | (4,977 | ) |  | $ | (41,160 | ) |  | $ | (14,948 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 115,059 |  |  |  | 109,213 |  |  |  | 113,641 |  |  |  | 107,531 |  |
| Net loss per share - basic and diluted |  | $ | (0.12 | ) |  | $ | (0.05 | ) |  | $ | (0.36 | ) |  | $ | (0.14 | ) |

[0001564590-18-012675:notes:247]
[same as prior period, unchanged from 0001564590-18-001677:notes:231]

[0001564590-18-012675:notes:248]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |  | March 31, 2018 |  |  | March 31, 2017 |  |
| Options to purchase common stock |  |  | 2,379 |  |  |  | — |  |  |  | 2,649 |  |  |  | 398 |  |
| Restricted stock units |  |  | 8,213 |  |  |  | 4 |  |  |  | 7,670 |  |  |  | 7 |  |
| Employee Stock Purchase Plan shares |  |  | 972 |  |  |  | 269 |  |  |  | 1,101 |  |  |  | 269 |  |
| Total shares excluded |  |  | 11,564 |  |  |  | 273 |  |  |  | 11,420 |  |  |  | 674 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-012675:notes:249]
[same as prior period, unchanged from 0001564590-18-001677:notes:233]

[0001564590-18-012675:notes:250]
[same as prior period, unchanged from 0001564590-18-001677:notes:234]

[0001564590-18-012675:notes:251]
As of March 31, 2018, forward foreign currency contracts had a notional principal amount of $6.7 million and an immaterial unrealized gain. These contracts have maturities of less than 90 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. As of March 31, 2017, the Company did not have any derivative instruments outstanding.

[0001564590-18-012675:notes:252]
Foreign currency transactions gains and losses from operations was a loss of $0.3 million and a gain of $0.8 million for the three months ended March 31, 2018 and 2017, respectively. Foreign currency transactions gains and losses from operations was a loss of $1.5 million and a gain of less than $0.1 million for the nine months ended March 31, 2018 and 2017, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-012675:notes:253]
[same as prior period, unchanged from 0001564590-18-001677:notes:237]

[0001564590-18-012675:notes:254]
[same as prior period, unchanged from 0001564590-18-001677:notes:238]

[0001564590-18-012675:notes:255]
[same as prior period, unchanged from 0001564590-18-001677:notes:239]

[0001564590-18-012675:notes:256]
[same as prior period, unchanged from 0001564590-18-001677:notes:240]

[0001564590-18-012675:notes:257]
| Long-lived Assets |  | March 31, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Americas |  | $ | 189,321 |  |  | $ | 67,369 |  |
| EMEA |  |  | 15,586 |  |  |  | 8,998 |  |
| APAC |  |  | 10,334 |  |  |  | 4,275 |  |
| Total long-lived assets |  | $ | 215,241 |  |  | $ | 80,642 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-012675:notes:258]
14.Subsequent Event

[0001564590-18-012675:notes:259]
On May 1, 2018, the Company terminated the Amended and Restated Credit Agreement dated October 28, 2016, by and among the Company, as borrower, Silicon Valley Bank, as administrative agent, and the financial institutions that were a party thereto as lenders.

[0001564590-18-012675:notes:260]
On May 1, 2018, the Company entered into a Credit Agreement (the “New Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The New Credit Agreement provides for a $40 million five-year revolving credit facility (the “New Revolver”) and a $190 million five-year term loan (the “New Term Loan” and together with the New Revolver, the “New Senior Secured Credit Facilities”). On May 1, 2018, the Company borrowed $200 million under the New Senior Secured Credit Facilities in order to pay off the existing debt, as noted above and for general corporate purposes.

[0001564590-18-012675:notes:261]
Borrowings under the New Senior Secured Credit Facilities will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolver, also based on the Company’s Consolidated Leverage Ratio. Principal installments are payable on the New Term Loan in varying percentages quarterly starting June 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The New Senior Secured Credit Facilities are secured by substantially all of the Company’s assets.

[0001564590-18-012675:notes:262]
Financial covenants under the New Credit Agreement require the Company to maintain a minimum consolidated fixed charge coverage ratio of at least 1.25:1.00 at the end of each fiscal quarter. In addition, the Company’s Consolidated Leverage Ratio shall not be greater than (i) 3.00:1.00 at the end of the fiscal quarters ending March 31, 2018 through September 30, 2019, (ii) 2.75:1.00 at the end of the fiscal quarters ending December 31, 2019 through March 31, 2021, and (iii) 2.50:1.00 at the end of the fiscal quarters ending June 30, 2021 and thereafter. The New Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets.

[0001564590-18-012675:notes:263]
The New Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, the material breach of any of representations and warranties, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company. The amounts outstanding under the New Senior Secured Credit Facilities may be accelerated upon certain events of default.
