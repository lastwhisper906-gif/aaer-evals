# EXTR notes — 0001078271-14-000020


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-14-000020:notes:1]
[same as prior period, unchanged from 0001078271-14-000008:notes:1]

[0001078271-14-000020:notes:2]
[same as prior period, unchanged from 0001078271-14-000008:notes:2]

[0001078271-14-000020:notes:3]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| March 31, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 687 |  |  | $ | 687 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 34,579 |  |  | 34,700 |  |  | 121 |  |  | — |  |
|  | $ | 35,266 |  |  | $ | 35,387 |  |  | $ | 121 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 687 |  |  | $ | 687 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 34,579 |  |  | 34,700 |  |  | 121 |  |  | — |  |
|  | $ | 35,266 |  |  | $ | 35,387 |  |  | $ | 121 |  |  | $ | — |  |
| June 30, 2013 |  |  |  |  |  |  |  |
| Money market funds | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 110,078 |  |  | 109,810 |  |  | 126 |  |  | (394 | ) |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 42,994 |  |  | 43,034 |  |  | 44 |  |  | (4 | ) |
| Marketable securities | 67,084 |  |  | 66,776 |  |  | 82 |  |  | (390 | ) |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |

[0001078271-14-000020:notes:4]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at March 31, 2014, by contractual maturity, were as follows (in thousands):

[0001078271-14-000020:notes:5]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 24,697 |  |  | $ | 24,803 |  |
| Due in 1-2 years | 7,553 |  |  | 7,568 |  |
| Due in 2-5 years | 3,016 |  |  | 3,016 |  |
| Total investments in available for sale debt securities | $ | 35,266 |  |  | $ | 35,387 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001078271-14-000020:notes:6]
[same as prior period, unchanged from 0001078271-14-000008:notes:6]

[0001078271-14-000020:notes:7]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, 2013 |  | March 31, 2014 |  |  | March 31, 2013 |  |
| Net revenues |  | $ | 137,936 |  |  | $ | 463,600 |  |  | $ | 465,535 |  |
| Net loss |  | $ | (21,166 | ) |  | $ | (63,410 | ) |  | $ | (35,999 | ) |
| Net loss per share – basic and diluted |  | $ | (0.23 | ) |  | $ | (0.66 | ) |  | $ | (0.38 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001078271-14-000020:notes:8]
[same as prior period, unchanged from 0001078271-14-000008:notes:8]

[0001078271-14-000020:notes:9]
On October 31, 2013 (the “Acquisition Date”), the Company completed the acquisition of Enterasys, a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired. The purchase price consideration was finalized in the quarter ended March 31, 2014.  The Company also assumed outstanding options and restricted stock units of Enterasys at the Acquisition Date, all of which were unvested.

[0001078271-14-000020:notes:10]
The acquisition has been accounted for using the acquisition method of accounting.   The purchase price has been allocated on a preliminary basis to tangible and intangible assets acquired and liabilities assumed.  The final purchase price allocation is pending the finalization of valuations, which may result in an adjustment to the preliminary purchase price allocation. Also, additional information which existed as of the acquisition date but was unknown to the Company at that time, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date, and may result in a change in the purchase price allocation.  While management believes that its preliminary estimates and assumptions underlying the valuations are reasonable, different estimates and assumptions could result in different valuations assigned to the individual assets acquired and liabilities assumed, and the resulting amount of goodwill.

[0001078271-14-000020:notes:11]
The Company is in the process of finalizing the purchase price allocation and may make adjustments to the allocation during the period up to the date the allocation is finalized ("measurement period").  The following table below summarizes the preliminary allocation of the tangible and identifiable intangible assets acquired and liabilities assumed as of October 31, 2013, as well as the adjustments made in the quarter ended March 31, 2014 (in thousands):

[0001078271-14-000020:notes:12]
|  |  | Preliminary Allocation as of December 31, 2013 |  | Change during three months ended March 31, 2014 |  | Preliminary Allocation as of March 31, 2014 |
| Cash |  | $ | 4,969 |  |  | $ | 2,428 |  | a | $ | 7,397 |  |
| Receivables |  | 25,699 |  |  | (2,428 | ) | a | 23,271 |  |
| Inventory |  | 33,662 |  |  | — |  |  | 33,662 |  |
| Other current assets |  | 8,888 |  |  | — |  |  | 8,888 |  |
| Property and equipment |  | 23,122 |  |  | (1,829 | ) | b | 21,293 |  |
| Identifiable intangible assets |  | 108,900 |  |  | — |  | c | 108,900 |  |
| In-process research and development |  | 3,000 |  |  | — |  |  | 3,000 |  |
| Deferred tax assets |  | 9 |  |  | — |  |  | 9 |  |
| Other assets |  | 7,343 |  |  | — |  |  | 7,343 |  |
| Goodwill |  | 57,922 |  |  | 6,615 |  |  | 64,537 |  |
| Current liabilities |  | (75,394 | ) |  | (1,315 | ) | b,d,e | (76,709 | ) |
| Other long-term liabilities |  | (13,151 | ) |  | (1,043 | ) | b | (14,194 | ) |
| Total purchase price allocation |  | $ | 184,969 |  |  | $ | 2,428 |  |  | $ | 187,397 |  |
| Less: Cash acquired from acquisition |  | (4,969 | ) |  | (2,428 | ) | a | (7,397 | ) |
| Total purchase price consideration, net of cash acquired |  | $ | 180,000 |  |  | $ | — |  |  | $ | 180,000 |  |

[0001078271-14-000020:notes:13]
a.The Company finalized the working capital adjustment during the three months ended March 31, 2014, which led to a decrease of $2.4 million in receivables and a corresponding increase in cash.  As a result of this adjustment, the total cash acquired from the acquisition also increased by the same amount.  The net effect of this adjustment is an increase in goodwill of $2.4 million.

[0001078271-14-000020:notes:14]
b.The Company updated its preliminary estimate of the fair value of property and equipment which led to a decrease of $3.0 million in property and equipment with a corresponding increase in goodwill.  The Company also updated the fair values of the asset retirement obligations and the related asset retirement assets which led to an increase in the fair value of property and equipment of $1.2 million and a corresponding increase in current liabilities and other long-term liabilities of $0.2 million and $1.0 million, respectively.   The decrease in depreciation expense due to the change in fair value of property and equipment was immaterial for the quarter ended December 31, 2013.

[0001078271-14-000020:notes:15]
c.During the three months ended March 31, 2014, there were no changes to the fair value of the identifiable intangible assets acquired.  However, the Company revised the estimated useful life of Order backlog from 1.5 years to 1 year, which would have increased the amortization expense for the three months ended December 31, 2013 by $0.8 million to a total of $4.6 million amortization expense upon retrospective adjustment for such change in estimate.

[0001078271-14-000020:notes:16]
d.The Company obtained new information regarding accruals for litigation and statutory tax assessment as of the acquisition date which led to an increase in the fair value of current liabilities of $0.7 million and a corresponding increase in goodwill.

[0001078271-14-000020:notes:17]
e.The Company obtained new information regarding the existence of accrued liabilities as of the acquisition date which led to an increase in the fair value of accrued liabilities by $0.5 million with a corresponding increase in goodwill.  The change in the fair value measurement for such accrued liabilities would have decreased operating expenses for three months ended December 31, 2013 by $0.5 million.

[0001078271-14-000020:notes:18]
The measurement period adjustments above would have increased the reported net loss for the three month ended and six months ended December 31, 2013 by $0.4 million to $16.4 million. The Company does not believe that the measurement period adjustments have a significant impact on the condensed consolidated statement of operations, balance sheet or cash flows in any period and, therefore, we have not retrospectively adjusted our financial statements.

[0001078271-14-000020:notes:19]
The purchase price has been allocated based on the preliminary estimates of the fair value of assets acquired and liabilities assumed as of the acquisition date.  The Company also continues to analyze accounts receivables, inventory, other assets, current and long term liabilities and the tax implications of the acquisition of Enterasys which may ultimately impact the overall level of goodwill associated with the acquisition.

[0001078271-14-000020:notes:20]
[same as prior period, unchanged from 0001078271-14-000008:notes:15]

[0001078271-14-000020:notes:21]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |
| Developed technology |  | 3 |  | $ | 45,000 |  |
| Customer relationships |  | 3 |  | 37,000 |  |
| Maintenance contracts |  | 5 |  | 17,000 |  |
| Trademarks |  | 3 |  | 2,500 |  |
| Order backlog |  | 1 |  | 7,400 |  |
| Total identifiable intangible assets |  | 3 |  | $ | 108,900 |  |

[0001078271-14-000020:notes:22]
[same as prior period, unchanged from 0001078271-14-000008:notes:17]

[0001078271-14-000020:notes:23]
The Company also has an indefinite-lived asset of $3.0 million which represents the fair value of in-process research and development activities.  The Company expects to complete such research and development efforts in the fourth quarter of fiscal 2014.  Once the related research and development efforts are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.

[0001078271-14-000020:notes:24]
The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013. For the nine months ended March 31, 2014, $148.3 million of revenue and $27.5 million of operating income from Enterasys are included in the condensed consolidated statement of operations.  The Company incurred $5.9 million of acquisition-related expenses for the nine months ended March 31, 2014.   Such acquisition-related costs are included in "Acquisition-integration expenses" on the condensed consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees payable to financial and legal advisors.

[0001078271-14-000020:notes:25]
[same as prior period, unchanged from 0001078271-14-000008:notes:20]

[0001078271-14-000020:notes:26]
[same as prior period, unchanged from 0001078271-14-000008:notes:21]

[0001078271-14-000020:notes:27]
The unaudited pro forma financial information for the nine months ended March 31, 2014 combines the results for Extreme for the nine months ended March 31, 2014, which include the results of Enterasys subsequent to the acquisition date, and the historical results for Enterasys for the three months ended September 30, 2013 and the month ended October 31, 2013. The unaudited pro forma financial information for the three and nine months ended March 31, 2013 combines the historical results for Extreme for those periods, with the historical results for Enterasys for the three and nine months ended March 31, 2013. The following table summarizes the pro forma financial information (in thousands, except per share amounts):


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-14-000020:notes:28]
Commitments and Contingencies

[0001078271-14-000020:notes:29]
Purchase Commitments

[0001078271-14-000020:notes:30]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2014, the Company had non-cancelable commitments to purchase approximately $52.5 million of such inventory.

[0001078271-14-000020:notes:31]
Legal Proceedings

[0001078271-14-000020:notes:32]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-14-000020:notes:33]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-14-000020:notes:34]
Intellectual Property Litigation

[0001078271-14-000020:notes:35]
Relay IP Inc.

[0001078271-14-000020:notes:36]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775 (Extreme Case). Further on May 6, 2013 they also filed a similar suit against Enterasys in the same court, Civil Action case number 13-774.The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on both cases in July, 2013. The suit is one of approximately 40 nearly simultaneous suits filed by Relay IP against numerous networking equipment manufacturers, suppliers, operators, and users including Cisco Systems, Hewlett-Packard, Juniper Networks, Avaya, Extreme and Enterasys.  The Company denies the claims and intends to vigorously defend itself in both cases.

[0001078271-14-000020:notes:37]
ReefEdge

[0001078271-14-000020:notes:38]
On September 17, 2012, ReefEdge filed suit against Enterasys in the United States District Court for the District of Delaware alleging certain of the company's products (wireless controllers and wireless access points), infringe three ReefEdge U.S. patents (6633761, 6975864, 7197308).  ReefEdge, a non-practicing entity, sought injunctive relief as well as monetary damages, costs, expenses and attorney fees, although there was no quantified amount sought.  Extreme assumed this litigation as part of the acquisition of Enterasys.  As of the date of this filing, the parties reached a settlement which required the Company to pay an immaterial amount.

[0001078271-14-000020:notes:39]
Indemnification Obligations

[0001078271-14-000020:notes:40]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of March 31, 2014, the Company had no outstanding indemnification claims.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-14-000020:notes:41]
The following table summarizes deferred revenue, net at March 31, 2014 and June 30, 2013, respectively (in thousands):

[0001078271-14-000020:notes:42]
|  | March 31, 2014 |  | June 30, 2013 |
| Deferred services | $ | 84,206 |  |  | $ | 38,003 |  |
| Deferred product and other revenue | 6,644 |  |  | 3,451 |  |
| Total deferred revenue | 90,850 |  |  | 41,454 |  |
| Less: current portion | 71,183 |  |  | 33,184 |  |
| Non-current deferred revenue, net | $ | 19,667 |  |  | $ | 8,270 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-14-000020:notes:43]
[same as prior period, unchanged from 0001078271-14-000008:notes:38]

[0001078271-14-000020:notes:44]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. At March 31, 2014, these forward foreign currency contracts had a notional principal amount of $7.2 million and an immaterial unrealized gain on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-14-000020:notes:45]
Foreign currency transaction gains and losses from operations were a $0.1 million loss and a $1.2 million loss for the three and nine months ended March 31, 2014, respectively.  Foreign currency transaction gains and losses from operations were a $0.1 million loss and an immaterial gain for the three and nine months ended March 31, 2013, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-14-000020:notes:46]
[same as prior period, unchanged from 0001078271-14-000008:notes:41]

[0001078271-14-000020:notes:47]
[same as prior period, unchanged from 0001078271-14-000008:notes:42]

[0001078271-14-000020:notes:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Cost of product revenue | $ | 268 |  |  | $ | 118 |  |  | $ | 568 |  |  | $ | 413 |  |
| Cost of service revenue | 420 |  |  | 61 |  |  | 623 |  |  | 304 |  |
| Research and development | 1,419 |  |  | 268 |  |  | 2,559 |  |  | 988 |  |
| Sales and marketing | 1,765 |  |  | 756 |  |  | 3,614 |  |  | 2,051 |  |
| General and administrative | 970 |  |  | 638 |  |  | 2,510 |  |  | 1,869 |  |
| Total share-based compensation expense | $ | 4,842 |  |  | $ | 1,841 |  |  | $ | 9,874 |  |  | $ | 5,625 |  |

[0001078271-14-000020:notes:49]
During the three and nine months ended March 31, 2014 and 2013, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial. The income tax benefit for share-based compensation expense was immaterial in the three and nine months ended March 31, 2014 and 2013.

[0001078271-14-000020:notes:50]
The weighted-average grant-date per share fair value of options granted during the three months ended March 31, 2014 and 2013 was $2.71 and $1.72, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended March 31, 2014 and 2013 was $1.62 and $0.86, respectively.

[0001078271-14-000020:notes:51]
The weighted-average grant-date per share fair value of options granted during the nine months ended March 31, 2014 and 2013 was $2.39 and $2.71, respectively. The weighted-average estimated per share fair value of shares purchased under the ESPP during the nine months ended March 31, 2014 and 2013 was $1.44 and $0.88, respectively.

[0001078271-14-000020:notes:52]
The following table summarizes stock option activity under all plans for the nine months ended March 31, 2014:

[0001078271-14-000020:notes:53]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2013 | 9,145 |  |  | $ | 3.66 |  |  |  |  |  |
| Granted | 6,097 |  |  | $ | 5.22 |  |  |  |  |  |
| Exercised | (1,676 | ) |  | $ | 3.60 |  |  |  |  | $ | 1,036 |  |
| Cancelled | (1,323 | ) |  | $ | 4.92 |  |  |  |  |  |
| Options outstanding at March 31, 2014 | 12,243 |  |  | $ | 4.31 |  |  | 5.50 |  | $ | 18,367 |  |
| Exercisable at March 31, 2014 | 3,926 |  |  | $ | 3.78 |  |  | 3.80 |  | $ | 8,040 |  |
| Vested and expected to vest at March 31, 2014 | 11,247 |  |  | $ | 4.28 |  |  | 5.42 |  | $ | 17,301 |  |

[0001078271-14-000020:notes:54]
Included in the options granted above are 4.2 million options, assumed in connection with the acquisition of Enterasys on October 31, 2013, with an exercise price of $5.30.

[0001078271-14-000020:notes:55]
[same as prior period, unchanged from 0001078271-14-000008:notes:50]

[0001078271-14-000020:notes:56]
[same as prior period, unchanged from 0001078271-14-000008:notes:51]

[0001078271-14-000020:notes:57]
The following table summarizes stock award activity for the nine months ended March 31, 2014:

[0001078271-14-000020:notes:58]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2013 | 2,686 |  |  | $ | 3.09 |  |  |  |
| Granted | 5,037 |  |  | $ | 5.56 |  |  |  |
| Vested | 852 |  |  | $ | 3.51 |  |  | $ | 4,982 |  |
| Cancelled | 515 |  |  | $ | 2.62 |  |  |  |
| Non-vested stock outstanding at March 31, 2014 | 9,090 |  |  | $ | 4.47 |  |  |  |

[0001078271-14-000020:notes:59]
Included in the restricted stock units granted above are 2.7 million restricted stock units assumed in connection with the acquisition of Enterasys on October 31, 2013, with an acquisition-date fair value of $5.30.

[0001078271-14-000020:notes:60]
Excluding the options assumed as part of the Enterasys acquisition, the fair value of each option award and share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.

[0001078271-14-000020:notes:61]
The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of performance-based option awards, with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-14-000020:notes:62]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Expected life | 5 years |  |  | 4 years |  |  | 0.25 years |  |  | 0.25 years |  |  | 4 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.41 | % |  | 0.72 | % |  | 0.09 | % |  | 0.10 | % |  | 1.23 | % |  | 0.71 | % |  | 0.10 | % |  | 0.07 | % |
| Volatility | 57 | % |  | 62 | % |  | 57 | % |  | 42 | % |  | 56 | % |  | 60 | % |  | 51 | % |  | 53 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |

[0001078271-14-000020:notes:63]
[same as prior period, unchanged from 0001078271-14-000008:notes:57]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-14-000020:notes:64]
[same as prior period, unchanged from 0001078271-14-000008:notes:58]

[0001078271-14-000020:notes:65]
[same as prior period, unchanged from 0001078271-14-000008:notes:59]


## us-gaap:EarningsPerShareTextBlock

[0001078271-14-000020:notes:66]
[same as prior period, unchanged from 0001078271-14-000008:notes:60]

[0001078271-14-000020:notes:67]
[same as prior period, unchanged from 0001078271-14-000008:notes:61]

[0001078271-14-000020:notes:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Net (loss) income | $ | (25,058 | ) |  | $ | (2,220 | ) |  | $ | (41,079 | ) |  | $ | 6,489 |  |
| Weighted-average shares used in per share calculation – basic | 96,069 |  |  | 92,968 |  |  | 95,116 |  |  | 94,069 |  |
| Incremental shares using the treasury stock method: |  |  |  |  |  |  |  |
| Stock options | — |  |  | — |  |  | — |  |  | 391 |  |
| Restricted stock units | — |  |  | — |  |  | — |  |  | 526 |  |
| Employee Stock Purchase Plan | — |  |  | — |  |  | — |  |  | 108 |  |
| Weighted -average share used in per share calculation – diluted | 96,069 |  |  | 92,968 |  |  | 95,116 |  |  | 95,094 |  |
| Net (loss) income per share – basic | $ | (0.26 | ) |  | $ | (0.02 | ) |  | (0.43 | ) |  | 0.07 |  |
| Net (loss) income per share – diluted | $ | (0.26 | ) |  | $ | (0.02 | ) |  | (0.43 | ) |  | 0.07 |  |

[0001078271-14-000020:notes:69]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For the three months ended March 31, 2014 and 2013, the Company excluded 4.4 million and 7.1 million outstanding weighted average stock options and awards, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.  For the nine months ended March 31, 2014 and 2013, the Company excluded 3.6 million and  7.2 million outstanding weighted average stock options and awards, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-14-000020:notes:70]
[same as prior period, unchanged from 0001078271-14-000008:notes:64]

[0001078271-14-000020:notes:71]
[same as prior period, unchanged from 0001078271-14-000008:notes:65]

[0001078271-14-000020:notes:72]
| March 31, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 687 |  |  | $ | — |  |  | $ | — |  |  | $ | 687 |  |
| Corporate notes/bonds | — |  |  | 34,700 |  |  | — |  |  | 34,700 |  |
| Foreign currency forward contracts | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Total | $ | 687 |  |  | $ | 34,707 |  |  | $ | — |  |  | $ | 35,394 |  |

[0001078271-14-000020:notes:73]
[same as prior period, unchanged from 0001078271-14-000008:notes:67]

[0001078271-14-000020:notes:74]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three and nine months ended March 31, 2014. There were no liabilities as of March 31, 2014 that were being measured using fair value on a recurring basis.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-14-000020:notes:75]
[same as prior period, unchanged from 0001078271-14-000008:notes:69]

[0001078271-14-000020:notes:76]
[same as prior period, unchanged from 0001078271-14-000008:notes:70]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-14-000020:notes:77]
[same as prior period, unchanged from 0001078271-14-000008:notes:71]

[0001078271-14-000020:notes:78]
For the three and nine months ended March 31, 2014, the Company recorded an income tax provision of $0.9 million and $2.3 million, respectively.  For the three and nine months ended March 31, 2013, the Company recorded an income tax provision of $0.4 million and 1.4 million, respectively.

[0001078271-14-000020:notes:79]
The income tax provisions for the three and nine months ended March 31, 2014 and 2013 consisted primarily of taxes on the income of our foreign subsidiaries as well as .U.S. state income taxes. The income tax provision for the three and nine months ended March 31, 2014 also includes an expense related to a deferred tax liability for the amortization of goodwill recorded as a result of the acquisition of Enterasys.  The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and nine months ended March 31, 2014 and 2013, and therefore do not reflect the annual effective tax rate.

[0001078271-14-000020:notes:80]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as substantially all of the acquired Enterasys foreign entities’ deferred tax assets.  No valuation allowance has been established against the non-U.S. deferred tax assets of the legacy Extreme Networks, Inc. foreign subsidiaries. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis. The Company's inconsistent earnings in recent periods, coupled with the Company's inability to forecast greater than one quarter in advance and the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions. This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001078271-14-000020:notes:81]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries.  The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has preliminarily estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  During the current period, the Company deducted $1.7 million of tax amortization expense related to capitalized goodwill.  As of March 31, 2014, the Company recorded a deferred tax liability of $0.6 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets.

[0001078271-14-000020:notes:82]
The Company had $10.9 million of unrecognized tax benefits as of March 31, 2014. The future impact of the unrecognized tax benefit of $10.9 million, if recognized, is as follows: approximately $0.3 million would impact the effective tax rate, and approximately $10.6 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.1 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-14-000020:notes:83]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Condensed Consolidated Statements of Operations and were immaterial for the three and nine months ended March 31, 2014 and 2013. Accrued interest and penalties were $0.1 million and $0.1 million as of March 31, 2014 and 2013, respectively.

[0001078271-14-000020:notes:84]
[same as prior period, unchanged from 0001078271-14-000008:notes:78]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-14-000020:notes:85]
[same as prior period, unchanged from 0001078271-14-000008:notes:79]

[0001078271-14-000020:notes:86]
[same as prior period, unchanged from 0001078271-14-000008:notes:80]

[0001078271-14-000020:notes:87]
[same as prior period, unchanged from 0001078271-14-000008:notes:81]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-14-000020:notes:88]
Recently Issued Accounting Pronouncements

[0001078271-14-000020:notes:89]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013. The Company intends to adopt this standard prospectively in the first quarter of its fiscal year ending June 30, 2015. The Company does not believe this updated standard will have a material impact on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-14-000020:notes:90]
[same as prior period, unchanged from 0001078271-14-000008:notes:84]

[0001078271-14-000020:notes:91]
[same as prior period, unchanged from 0001078271-14-000008:notes:85]

[0001078271-14-000020:notes:92]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2014. The results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.

[0001078271-14-000020:notes:93]
On October 31, 2013, the Company completed the acquisition of Enterasys Networks, Inc., a Delaware corporation ("Enterasys"), whereby Enterasys became a wholly-owned subsidiary of the Company (see Note 2: Summary of Significant Accounting Policies - Business Combinations" and Note 4: "Business Combinations" for further discussion).  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-14-000020:notes:94]
[same as prior period, unchanged from 0001078271-14-000008:notes:88]

[0001078271-14-000020:notes:95]
As part of the Company's on-going restructuring efforts, during the second quarter of fiscal year 2013, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. Restructuring expense was $0.0 million and $0.5 million in the three and nine months ended March 31, 2014.  Restructuring expense was $1.1 million and $6.2 million in the three and nine months ended March 31, 2013.

[0001078271-14-000020:notes:96]
The following table summarizes restructuring activities for the nine months ended March 31, 2014:

[0001078271-14-000020:notes:97]
|  |  | Termination Benefits (1) |  | Contract Termination |  | Other Cost |  | Total |
| Balance at June 30, 2013 |  | $ | 1,217 |  |  | $ | — |  |  | $ | 249 |  |  | $ | 1,466 |  |
| Assumed from acquisition |  | — |  |  | 127 |  |  | — |  |  | 127 |  |
| Period charges |  | 110 |  |  | 628 |  |  | 82 |  |  | 820 |  |
| Period reversals |  | (309 | ) |  | (11 | ) |  | (1 | ) |  | (321 | ) |
| Period payments |  | (949 | ) |  | (275 | ) |  | (331 | ) |  | (1,555 | ) |
| Restructuring liabilities at March 31, 2014 |  | $ | 69 |  |  | $ | 469 |  |  | $ | (1 | ) |  | $ | 537 |  |

[0001078271-14-000020:notes:98]
[same as prior period, unchanged from 0001078271-14-000008:notes:92]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-14-000020:notes:99]
[same as prior period, unchanged from 0001078271-14-000008:notes:93]

[0001078271-14-000020:notes:100]
[same as prior period, unchanged from 0001078271-14-000008:notes:94]

[0001078271-14-000020:notes:101]
[same as prior period, unchanged from 0001078271-14-000008:notes:95]

[0001078271-14-000020:notes:102]
[same as prior period, unchanged from 0001078271-14-000008:notes:96]


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-14-000020:notes:103]
[same as prior period, unchanged from 0001078271-14-000008:notes:97]

[0001078271-14-000020:notes:104]
[same as prior period, unchanged from 0001078271-14-000008:notes:98]

[0001078271-14-000020:notes:105]
|  | March 31, 2014 |  | June 30, 2013 |
| Cash | $ | 70,668 |  |  | $ | 41,518 |  |
| Cash equivalents | $ | 687 |  |  | $ | 54,285 |  |
| Short-term investments | 34,700 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total available-for-sale | $ | 35,387 |  |  | $ | 164,095 |  |
| Total cash, cash equivalents and available for sale securities | $ | 106,055 |  |  | $ | 205,613 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-14-000020:notes:106]
The Company's debt is comprised of the following:

[0001078271-14-000020:notes:107]
|  |  | March 31, 2014 |
| Current portion of long-term debt: |  |  |
| Term Loan |  | 4,875 |  |
| Revolving Facility |  | 24,000 |  |
| Current portion of long-term debt |  | 28,875 |  |
| Long-term debt, less current portion: |  |  |
| Term Loan |  | 58,500 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt, less current portion |  | 93,500 |  |
| Total debt |  | 122,375 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001078271-14-000020:notes:108]
[same as prior period, unchanged from 0001078271-14-000008:notes:102]

[0001078271-14-000020:notes:109]
| March 31, 2014 |  | Weighted average remaining amortization period |  | Gross |  | Accumulated amortization |  | Net |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 45,000 |  |  | $ | 6,736 |  |  | $ | 38,264 |  |
| Customer relationships |  | 2.6 years |  | 37,000 |  |  | 5,139 |  |  | 31,861 |  |
| Maintenance contracts |  | 4.6 years |  | 17,000 |  |  | 1,417 |  |  | 15,583 |  |
| Trademarks |  | 2.6 years |  | 2,500 |  |  | 347 |  |  | 2,153 |  |
| Order backlog |  | 1.0 year |  | 7,400 |  |  | 4,542 |  |  | 2,858 |  |
| License agreements |  | 10.9 years |  | 10,447 |  |  | 7,971 |  |  | 2,476 |  |
| Other intangibles |  | 5.2 years |  | 2,459 |  |  | 1,449 |  |  | 1,010 |  |
| Total intangible assets with finite lives |  |  |  | 121,806 |  |  | 27,601 |  |  | 94,205 |  |
| In-process research and development, with indefinite life |  |  |  | 3,000 |  |  | — |  |  | 3,000 |  |
| Total |  |  |  | $ | 124,806 |  |  | $ | 27,601 |  |  | $ | 97,205 |  |

[0001078271-14-000020:notes:110]
| June 30, 2013 |  | Weighted average remaining amortization period |  | Gross |  | Accumulated amortization |  | Net |
| Intangible assets with finite lives: |  |  |  |  |  |  |  |  |
| License agreements |  | 10.3 years |  | 10,447 |  |  | 7,407 |  |  | 3,040 |  |
| Other intangibles |  | 5.8 years |  | 2,459 |  |  | 1,256 |  |  | 1,203 |  |
| Total intangible assets with finite lives |  |  |  | 12,906 |  |  | 8,663 |  |  | 4,243 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001078271-14-000020:notes:111]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001078271-14-000020:notes:112]
|  |  | Total |
| Balance as of September 30, 2013 |  | $ | — |  |
| Addition due to acquisition of Enterasys (Note 4) |  | 57,922 |  |
| Balance as of December 31, 2013 |  | $ | 57,922 |  |
| Purchase price allocation adjustments |  | 6,615 |  |
| Balance as of March 31, 2014 |  | $ | 64,537 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-14-000020:notes:113]
The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2014 and 2013:

[0001078271-14-000020:notes:114]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Balance beginning of period | $ | 7,479 |  |  | $ | 2,971 |  |  | $ | 3,296 |  |  | $ | 2,871 |  |
| Assumed from acquisition | — |  |  | — |  |  | 3,732 |  |  | — |  |
| New warranties issued | 1,824 |  |  | 1,257 |  |  | 4,782 |  |  | 4,761 |  |
| Warranty expenditures | (1,478 | ) |  | (1,332 | ) |  | (3,985 | ) |  | (4,736 | ) |
| Balance end of period | $ | 7,825 |  |  | $ | 2,896 |  |  | $ | 7,825 |  |  | $ | 2,896 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-14-000020:notes:115]
[same as prior period, unchanged from 0001078271-14-000008:notes:107]

[0001078271-14-000020:notes:116]
|  | Three Months Ended |  | Nine Months Ended |
| Net Revenues: | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 59,896 |  |  | $ | 21,609 |  |  | $ | 141,576 |  |  | $ | 69,545 |  |
| Other | 12,082 |  |  | 6,414 |  |  | 37,816 |  |  | 26,959 |  |
| Total Americas | 71,978 |  |  | 28,023 |  |  | 179,392 |  |  | 96,504 |  |
| EMEA | 54,113 |  |  | 28,481 |  |  | 146,175 |  |  | 85,700 |  |
| APAC | 15,671 |  |  | 11,699 |  |  | 38,694 |  |  | 37,677 |  |
| Total net revenues | $ | 141,762 |  |  | $ | 68,203 |  |  | $ | 364,261 |  |  | $ | 219,881 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001078271-14-000020:notes:117]
[same as prior period, unchanged from 0001078271-14-000008:notes:109]

[0001078271-14-000020:notes:118]
| Fiscal year |  | Amount |
| 2014 (remaining 3 months) |  | $ | 9,540 |  |
| 2015 |  | 34,648 |  |
| 2016 |  | 31,286 |  |
| 2017 |  | 12,379 |  |
| 2018 |  | 3,682 |  |
| 2019 |  | 1,415 |  |
| Thereafter |  | 1,255 |  |
| Total |  | $ | 94,205 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-14-000020:notes:119]
[same as prior period, unchanged from 0001078271-14-000008:notes:111]

[0001078271-14-000020:notes:120]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Tech Data |  | 16 | % |  | 11 | % |  | 12 | % |  | * |  |
| Westcon Group Inc. |  | 14 | % |  | 19 | % |  | 13 | % |  | 10 | % |
| Scansource, Inc. |  | * |  |  | 10 | % |  | * |  |  | * |  |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-14-000020:notes:121]
[same as prior period, unchanged from 0001078271-14-000008:notes:113]

[0001078271-14-000020:notes:122]
[same as prior period, unchanged from 0001078271-14-000008:notes:114]

[0001078271-14-000020:notes:123]
[same as prior period, unchanged from 0001078271-14-000008:notes:115]

[0001078271-14-000020:notes:124]
Substantially all of the Company’s assets were attributable to North America operations at March 31, 2014 and June 30, 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-14-000020:notes:125]
[same as prior period, unchanged from 0001078271-14-000008:notes:117]

[0001078271-14-000020:notes:126]
[same as prior period, unchanged from 0001078271-14-000008:notes:118]

[0001078271-14-000020:notes:127]
The Company applies the acquisition method of accounting for business combinations, including its acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.

[0001078271-14-000020:notes:128]
[same as prior period, unchanged from 0001078271-14-000008:notes:120]

[0001078271-14-000020:notes:129]
[same as prior period, unchanged from 0001078271-14-000008:notes:121]

[0001078271-14-000020:notes:130]
[same as prior period, unchanged from 0001078271-14-000008:notes:122]

[0001078271-14-000020:notes:131]
Intangibles assets are reviewed for impairment annually or more frequently when an event occurs or circumstances change that would more likely than not reduce the fair value of the asset below its carrying value.  License agreements are presented at cost, net of accumulated amortization and are amortized over their estimated useful life.  The in-process research and development efforts are monitored regularly for completion and once they are completed, the Company will determine whether the asset will continue to be an indefinite-lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.  The Company determines that its in-process research and development project is complete when all material research and development costs have been incurred and no significant risks remain. The Company reviews the carrying value of indefinite-lived intangible assets for impairment at least annually during the last quarter of the fiscal year, or more frequently if it believes indicators of impairment exist.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-14-000020:notes:132]
[same as prior period, unchanged from 0001078271-14-000008:notes:124]

[0001078271-14-000020:notes:133]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income (loss) into earnings using the specific identification method. As of March 31, 2014, five out of twenty investment securities had unrealized losses.  For investments that were in an unrealized loss position as of March 31, 2014, the Company recorded an other-than-temporary impairment loss of $10,000 during the three months ended March 31, 2014 as the Company intends to sell such securities.   The Company had previously recorded an other-than-temporary impairment loss of $148,000 during the six months ended December 31, 2013, accordingly the total impairments recorded during the nine months ended March 31, 2014 is $158,000 as compared to none for the nine months ended March 31, 2013.

[0001078271-14-000020:notes:134]
[same as prior period, unchanged from 0001078271-14-000008:notes:126]

[0001078271-14-000020:notes:135]
[same as prior period, unchanged from 0001078271-14-000008:notes:127]

[0001078271-14-000020:notes:136]
As part of the acquisition of Enterasys, the Company acquired $64.5 million in goodwill which has been allocated to the Company's only reportable segment, the development and marketing of network infrastructure equipment.

[0001078271-14-000020:notes:137]
Amortization expense was $11.9 million and $18.9 million respectively, for the three and nine months ended March 31, 2014.  Amortization expense was $0.4 million and $1.2 million respectively, for the three and nine months ended March 31, 2013. Of the total amount recognized, $4.4 million and $7.3 million for the three and nine months ended March 31, 2014 and $0.3 million and $1.0 million respectively for the three and nine months ended March 31, 2013, is included in "Cost of revenues for products" on the condensed consolidated statements of operations, while the remainder of the amortization expense is included in "Amortization of intangibles" on the condensed consolidated statement of operations.  The amortization expense for developed technology, patents, license agreements and other intangibles is recognized in "Cost of revenues for products" on the condensed consolidated statement of operations.  The estimated future amortization expense for finite lived intangibles to be recorded for each of the next five years is as follows (in thousands):

[0001078271-14-000020:notes:138]
[same as prior period, unchanged from 0001078271-14-000008:notes:130]

[0001078271-14-000020:notes:139]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net at March 31, 2014 and June 30, 2013, respectively (in thousands):

[0001078271-14-000020:notes:140]
The Company offers for sale to its customers, renewable support arrangements, including extended warranty contracts that range from one to five years. Deferred support revenue is included within deferred revenue, net within the services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-14-000020:notes:141]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Balance beginning of period | $ | 81,485 |  |  | $ | 35,797 |  |  | $ | 38,003 |  |  | $ | 37,461 |  |
| Assumed from acquisition | — |  |  | — |  |  | 35,879 |  |  | — |  |
| New support arrangements | 30,986 |  |  | 14,431 |  |  | 77,475 |  |  | 41,745 |  |
| Recognition of support revenue | (28,265 | ) |  | (13,420 | ) |  | (67,151 | ) |  | (42,398 | ) |
| Balance end of period | 84,206 |  |  | 36,808 |  |  | 84,206 |  |  | 36,808 |  |
| Less: current portion | 64,539 |  |  | 28,801 |  |  | 64,539 |  |  | 28,801 |  |
| Non-current deferred revenue | $ | 19,667 |  |  | $ | 8,007 |  |  | $ | 19,667 |  |  | $ | 8,007 |  |

[0001078271-14-000020:notes:142]
[same as prior period, unchanged from 0001078271-14-000008:notes:134]

[0001078271-14-000020:notes:143]
[same as prior period, unchanged from 0001078271-14-000008:notes:135]

[0001078271-14-000020:notes:144]
[same as prior period, unchanged from 0001078271-14-000008:notes:136]

[0001078271-14-000020:notes:145]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at March 31, 2014 and June 30, 2013, respectively (in thousands):

[0001078271-14-000020:notes:146]
|  | March 31, 2014 |  | June 30, 2013 |
| Deferred distributors revenue | $ | 31,070 |  |  | $ | 22,411 |  |
| Deferred cost of sales to distributors | (6,853 | ) |  | (5,023 | ) |
| Deferred distributors revenue, net of cost of sales to distributors | $ | 24,217 |  |  | $ | 17,388 |  |

[0001078271-14-000020:notes:147]
[same as prior period, unchanged from 0001078271-14-000008:notes:139]

[0001078271-14-000020:notes:148]
On October 31, 2013, the Company entered into a Credit Agreement (the “Credit Agreement”) which provides for a $60 million five-year revolving credit facility (the “Revolving Facility”) and a $65 million five-year term loan (the “Term Loan”) and together with the Revolving Facility (the “Senior Secured Credit Facilities”).  The proceeds from the Term Loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The company also drew $35 million of the Revolving Facility to pay a portion of the purchase price and subsequently drew $24 million in the third quarter of fiscal 2014 to fund working capital requirements.  Such additional draw of $24 million was repaid as of the filing date of this Form 10-Q.

[0001078271-14-000020:notes:149]
Borrowings under the Senior Secured Credit Facilities bear interest, at the Company's election, at a rate per annum equal to an agreed to applicable margin plus (a) the higher of (x) the prime rate in effect on such day or (y) the federal funds effective rate in effect on such day plus 0.50%, or (b) an adjusted Libor rate. In addition, the Company is required to pay a commitment fee of between 0.375% and 0.50% quarterly (currently 0.50%) on the unused portion of the Revolving Facility, also based on the Company’s Consolidated Leverage Ratio.  Principal installments are payable on the Term Loan in varying percentages quarterly starting December 31, 2013 and to the extent not previously paid, all outstanding balance to be paid at maturity. If not repaid before maturity, the draws on the Revolving Facility shall be repaid on the maturity date. The Senior Secured Credit Facilities are secured by substantially all of the Company’s assets and are jointly and severally guaranteed by the Company and certain of its subsidiaries.

[0001078271-14-000020:notes:150]
The Credit Agreement contains financial covenants that require the Company to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other covenants and restrictions that limit the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets, etc.  These covenants, which are described more fully in the Credit Agreement, to which reference is made for a complete statement of the covenants, are subject to certain exceptions. The Company currently is in compliance with its covenants.

[0001078271-14-000020:notes:151]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by the Company is false or misleading in any material respect, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company.  The amounts outstanding under the Senior Secured Credit Facilities may be accelerated upon certain events of default.

[0001078271-14-000020:notes:152]
[same as prior period, unchanged from 0001078271-14-000008:notes:144]

[0001078271-14-000020:notes:153]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2014 and 2013:

[0001078271-14-000020:notes:154]
[same as prior period, unchanged from 0001078271-14-000008:notes:147]

[0001078271-14-000020:notes:155]
[same as prior period, unchanged from 0001078271-14-000008:notes:148]

[0001078271-14-000020:notes:156]
[same as prior period, unchanged from 0001078271-14-000008:notes:149]

[0001078271-14-000020:notes:157]
[same as prior period, unchanged from 0001078271-14-000008:notes:150]


## us-gaap:TreasuryStockTextBlock

[0001078271-14-000020:notes:158]
[same as prior period, unchanged from 0001078271-14-000008:notes:151]

[0001078271-14-000020:notes:159]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which may be purchased over a three year period in the open market or in privately negotiated transactions. Since the inception of the program, 4.1 million shares have been repurchased for a total purchase price of $14.5 million and $60.5 million of the authorized amount is remaining. All repurchased shares will be retired and included in the Company's authorized but unissued shares. During the three and nine months ended March 31, 2014, the Company did not repurchase any shares of common stock.
