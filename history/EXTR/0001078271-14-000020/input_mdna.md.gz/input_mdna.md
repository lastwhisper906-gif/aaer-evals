# EXTR MD&A — 0001078271-14-000020


## mdna

[0001078271-14-000020:mdna:1]
[same as prior period, unchanged from 0001078271-14-000008:mdna:1]

[0001078271-14-000020:mdna:2]
[same as prior period, unchanged from 0001078271-14-000008:mdna:2]

[0001078271-14-000020:mdna:3]
We are a leading provider of network infrastructure equipment and services for enterprises, data centers, and service providers. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. The shares of Extreme Networks, Inc. (EXTR) began trading on NASDAQ on April 1999.  Our corporate headquarters are located in San Jose, California. We develop and sell network infrastructure equipment to our enterprise, data center and telecommunications service provider customers.

[0001078271-14-000020:mdna:4]
[same as prior period, unchanged from 0001078271-14-000008:mdna:4]

[0001078271-14-000020:mdna:5]
Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center networking, switching and routing, Software-Defined Networking (SDN), wired and wireless LAN access, network management and security. This broader solutions portfolio can be leveraged to better serve existing and new customers. We will continue to enhance and support the product roadmaps of both companies going forward to protect the investments of customers and avoid any disruption to their businesses. We intend to significantly increase research and development to accelerate our vision for high-performance, modular, open networking.

[0001078271-14-000020:mdna:6]
Leading customer service and support: We are working to augment our current outsourced support model by integrating Enterasys' in-sourced expertise, building on Enterasys' award-winning heritage and strong commitment to exceptional customer experience. As a result, our expanded global network of channel partners and distributors will benefit from expanded services and support capabilities.

[0001078271-14-000020:mdna:7]
Strong Channels and Strategic Partners: Our focus will be to leverage the capabilities of the combined company and expand existing partnerships as well as continue to add new strategic partnerships in the future. Additionally, we will increase our focus on partnering with distributors and channel partners globally. The goal will be to develop and enhance relationships that grow our revenue and profits as well as the revenue and profits of our alliance and channel partners. At the same time, we are investing in infrastructure to make doing business with us easier and more efficient.

[0001078271-14-000020:mdna:8]
[same as prior period, unchanged from 0001078271-14-000008:mdna:8]

[0001078271-14-000020:mdna:9]
We outsource the majority of our manufacturing and supply chain management operations as part of our strategy to maintain global manufacturing capabilities and to reduce our costs. We conduct quality assurance, manufacturing engineering, document control and test development at engineering facilities in or near Research Triangle Park, North Carolina, Salem,

[0001078271-14-000020:mdna:10]
New Hampshire, Chennai, India and Toronto, Canada. This approach enables us to attract talent in our selected regions and quickly respond to changes in market demand.

[0001078271-14-000020:mdna:11]
[same as prior period, unchanged from 0001078271-14-000008:mdna:10]

[0001078271-14-000020:mdna:12]
[same as prior period, unchanged from 0001078271-14-000008:mdna:11]

[0001078271-14-000020:mdna:13]
[same as prior period, unchanged from 0001078271-14-000008:mdna:12]

[0001078271-14-000020:mdna:14]
During the third quarter of fiscal 2014, we achieved the following results:

[0001078271-14-000020:mdna:15]
| • | Net revenues of $141.8 million compared to net revenues of $68.2 million in the third quarter of fiscal 2013. |

[0001078271-14-000020:mdna:16]
| • | Product revenues of $109.9 million compared to product revenues of $54.1 million in the third quarter of fiscal 2013. |

[0001078271-14-000020:mdna:17]
| • | Service revenues of $31.9 million compared to service revenues of $14.1 million in the third quarter of fiscal 2013. |

[0001078271-14-000020:mdna:18]
| • | Total gross margin of 50% of net revenues compared to total gross margin of 56% of net revenues in the third quarter of fiscal 2013. |

[0001078271-14-000020:mdna:19]
| • | Operating loss of $23.4 million compared to operating loss of $1.9 million in the third quarter of fiscal 2013. |

[0001078271-14-000020:mdna:20]
| • | Net loss of $25.1 million compared to net loss of $2.2 million in the third quarter of fiscal 2013. |

[0001078271-14-000020:mdna:21]
| • | Cash flow used in operating activities of $30.6 million in the nine months ended March 31, 2014 compared to cash flow provided by operating activities of $7.0 million in the nine months ended March 31, 2013. |

[0001078271-14-000020:mdna:22]
| • | Cash and cash equivalents, short-term investments and marketable securities decreased by $99.6 million to $106.1 million as of March 31, 2014 from $205.6 million as of June 30, 2013, primarily due to cash used to fund a portion of the acquisition of Enterasys offset by $24 million additional borrowings from the Revolving Facility. |

[0001078271-14-000020:mdna:23]
[same as prior period, unchanged from 0001078271-14-000008:mdna:22]

[0001078271-14-000020:mdna:24]
The following table presents the total net revenue geographically for the three and nine months ended March 31, 2014 and March 31, 2013, respectively (dollars in thousands):

[0001078271-14-000020:mdna:25]
|  | Three Months Ended |  | Nine Months Ended |
| Net Revenues | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |  | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 59,896 |  |  | $ | 21,609 |  |  | $ | 38,287 |  |  | 177.2 | % |  | $ | 141,576 |  |  | $ | 69,545 |  |  | $ | 72,031 |  |  | 103.6 | % |
| Other | 12,082 |  |  | 6,414 |  |  | 5,668 |  |  | 88.4 | % |  | 37,816 |  |  | 26,959 |  |  | 10,857 |  |  | 40.3 | % |
| Total Americas | 71,978 |  |  | 28,023 |  |  | 43,955 |  |  | 156.9 | % |  | 179,392 |  |  | 96,504 |  |  | 82,888 |  |  | 85.9 | % |
| Percentage of net revenue | 51.0 | % |  | 41.1 | % |  |  |  |  |  | 49.2 | % |  | 43.9 | % |  |  |  |  |  |  |
| EMEA | 54,113 |  |  | 28,481 |  |  | 25,632 |  |  | 90.0 | % |  | 146,175 |  |  | 85,700 |  |  | 60,475 |  |  | 70.6 | % |
| Percentage of net revenue | 38.2 | % |  | 41.8 | % |  |  |  |  |  | 40.1 | % |  | 39.0 | % |  |  |  |  |  |  |
| APAC | 15,671 |  |  | 11,699 |  |  | 3,972 |  |  | 34.0 | % |  | 38,694 |  |  | 37,677 |  |  | 1,017 |  |  | 2.7 | % |
| Percentage of net revenue | 11.1 | % |  | 17.2 | % |  |  |  |  |  | 10.6 | % |  | 17.1 | % |  |  |  |  |
| Total net revenues | $ | 141,762 |  |  | $ | 68,203 |  |  | $ | 73,559 |  |  | 107.9 | % |  | $ | 364,261 |  |  | $ | 219,881 |  |  | $ | 144,380 |  |  | 65.7 | % |

[0001078271-14-000020:mdna:26]
[same as prior period, unchanged from 0001078271-14-000008:mdna:25]

[0001078271-14-000020:mdna:27]
The following table presents net product and service revenue for the three and nine months ended March 31, 2014 and March 31, 2013, respectively (dollars in thousands):

[0001078271-14-000020:mdna:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |  | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 109,891 |  |  | $ | 54,072 |  |  | $ | 55,819 |  |  | 103.2 | % |  | $ | 290,001 |  |  | $ | 175,450 |  |  | $ | 114,551 |  |  | 65.3 | % |
| Percentage of net revenue | 77.5 | % |  | 79.3 | % |  |  |  |  |  | 79.6 | % |  | 79.8 | % |  |  |  |  |
| Service | 31,871 |  |  | 14,131 |  |  | 17,740 |  |  | 125.5 | % |  | 74,260 |  |  | 44,431 |  |  | 29,829 |  |  | 67.1 | % |
| Percentage of net revenue | 22.5 | % |  | 20.7 | % |  |  |  |  |  | 20.4 | % |  | 20.2 | % |  |  |  |  |
| Total net revenues | $ | 141,762 |  |  | $ | 68,203 |  |  | $ | 73,559 |  |  | 107.9 | % |  | $ | 364,261 |  |  | $ | 219,881 |  |  | $ | 144,380 |  |  | 65.7 | % |

[0001078271-14-000020:mdna:29]
Product revenue increased $55.8 million or 103.2% in the third quarter of fiscal 2014 compared to the corresponding period of fiscal 2013. Product revenue increased $114.6 million or 65.3% in the nine months ending March 31, 2014 compared to the corresponding period of fiscal 2013. In the three and nine months ending March 31, 2014, there was a significant increase in the number of customers and products sold during the period due to our acquisition of Enterasys in the second quarter of fiscal 2014.  This resulted in a significant increase in our product revenue in all regions.

[0001078271-14-000020:mdna:30]
Service revenue increased $17.7 million or 125.5% in the third quarter of fiscal 2014 and $29.8 million or 67.1% in the nine months ended March 31, 2014 compared to the corresponding period of fiscal 2013. The increase in service revenue for the three and nine months ended March 31, 2014 was due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000020:mdna:31]
[same as prior period, unchanged from 0001078271-14-000008:mdna:31]

[0001078271-14-000020:mdna:32]
The following table presents the gross profit on product and service revenue and the gross profit percentage of product and service revenue for the three and nine months ended March 31, 2014 and 2013 (in thousands):

[0001078271-14-000020:mdna:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |  | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 51,188 |  |  | $ | 28,866 |  |  | $ | 22,322 |  |  | 77.3 | % |  | $ | 136,889 |  |  | $ | 90,391 |  |  | $ | 46,498 |  |  | 51.4 | % |
| Percentage of product revenue | 46.6 | % |  | 53.4 | % |  |  |  |  |  | 47.2 | % |  | 51.5 | % |  |  |  |  |
| Service | 19,667 |  |  | 9,071 |  |  | 10,596 |  |  | 116.8 | % |  | 47,518 |  |  | 28,260 |  |  | 19,258 |  |  | 68.1 | % |
| Percentage of service revenue | 61.7 | % |  | 64.2 | % |  |  |  |  |  | 64.0 | % |  | 63.6 | % |  |  |  |  |
| Total gross profit | $ | 70,855 |  |  | $ | 37,937 |  |  | $ | 32,918 |  |  | 86.8 | % |  | $ | 184,407 |  |  | $ | 118,651 |  |  | $ | 65,756 |  |  | 55.4 | % |
| Percentage of net revenue | 50.0 | % |  | 55.6 | % |  |  |  |  |  | 50.6 | % |  | 54.0 | % |  |  |  |  |

[0001078271-14-000020:mdna:34]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, amortization expense for developed technology, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution in San Jose, California; Salem, New Hampshire; China, and Taiwan.

[0001078271-14-000020:mdna:35]
Product gross margin decreased to 46.6% in the third quarter of fiscal 2014 from 53.4% in the third quarter of fiscal 2013 and decreased to 47.2% in the nine months ended March 31, 2014 from 51.5% in the nine months ended March 31, 2013.  The decrease in product gross margin for the three and nine months ended March 31, 2014 was primarily due to a $1.9 million and

[0001078271-14-000020:mdna:36]
$11.1 million charge for three and nine months ended March 31, 2014, respectively, related to a portion of the release of the step-up value for inventory as required by business combination accounting, $9.0 million and $12.8 million increase for the three and nine months ended March 31, 2014, respectively, in the amortization of the developed technology intangibles from the acquisition of Enterasys during the second quarter of fiscal 2014 and increased stock compensation expenses for the quarter ended March 31, 2014 as compared to the corresponding periods of fiscal 2013.  Such increases for the nine months ended March 31, 2014 were offset by lower excess and obsolete inventory charges as compared to corresponding period of fiscal 2013.

[0001078271-14-000020:mdna:37]
Our cost of service revenue consists primarily of personnel, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross margin decreased to 61.7% from 64.2% in the third quarter of fiscal 2014 and increased to 64.0% from 63.6% during the nine months ended March 31, 2014 as compared to the corresponding periods of fiscal 2013.  The service gross margin for the three ended March 31, 2014 decreased primarily due to higher personnel, overhead and travel cost as a result of our acquisition of Enterasys during the second quarter of fiscal 2014.  The service gross margin for the nine months ended March 31, 2014, increased primarily due to cost reduction initiatives partially offset by the increased cost of revenues from the acquisition of Enterasys.

[0001078271-14-000020:mdna:38]
[same as prior period, unchanged from 0001078271-14-000008:mdna:37]

[0001078271-14-000020:mdna:39]
[same as prior period, unchanged from 0001078271-14-000008:mdna:38]

[0001078271-14-000020:mdna:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |  | March 31, 2014 |  | March 31, 2013 |  | $Change |  | %Change |
| Research and development | $ | 24,265 |  |  | $ | 9,381 |  |  | $ | 14,884 |  |  | 158.7 | % |  | $ | 53,098 |  |  | $ | 30,954 |  |  | $ | 22,144 |  |  | 71.5 | % |
| Sales and marketing | 44,703 |  |  | 20,644 |  |  | 24,059 |  |  | 116.5 | % |  | 108,033 |  |  | 64,764 |  |  | 43,269 |  |  | 66.8 | % |
| General and administrative | 11,278 |  |  | 6,288 |  |  | 4,990 |  |  | 79.4 | % |  | 29,401 |  |  | 18,292 |  |  | 11,109 |  |  | 60.7 | % |
| Acquisition and integration costs | 6,443 |  |  | — |  |  | 6,443 |  |  | 100.0 | % |  | 18,826 |  |  | — |  |  | 18,826 |  |  | 100.0 | % |
| Restructuring (credit) charge, net of reversals | (6 | ) |  | 1,076 |  |  | (1,082 | ) |  | 100.6 | % |  | 499 |  |  | 6,242 |  |  | (5,743 | ) |  | (92.0 | )% |
| Amortization of intangibles | 7,666 |  |  | — |  |  | 7,666 |  |  | 100.0 | % |  | 11,444 |  |  | — |  |  | 11,444 |  |  | 100.0 | % |
| Litigation settlement (income) expense | (100 | ) |  | 2,450 |  |  | (2,550 | ) |  | 104.1 | % |  | (100 | ) |  | 2,029 |  |  | (2,129 | ) |  | 104.9 | % |
| Gain on sale of facilities | — |  |  | — |  |  | — |  |  | — | % |  | — |  |  | (11,539 | ) |  | 11,539 |  |  | (100.0 | )% |
| Total operating expenses | $ | 94,249 |  |  | $ | 39,839 |  |  | $ | 54,410 |  |  | 136.6 | % |  | $ | 221,201 |  |  | $ | 110,742 |  |  | $ | 110,459 |  |  | 99.7 | % |
| Operating income (loss) | $ | (23,394 | ) |  | $ | (1,902 | ) |  | $ | (21,492 | ) |  | 1,130.0 | % |  | $ | (36,794 | ) |  | $ | 7,909 |  |  | $ | (44,703 | ) |  | (565.2 | )% |

[0001078271-14-000020:mdna:41]
27

[0001078271-14-000020:mdna:42]
[same as prior period, unchanged from 0001078271-14-000008:mdna:40]

[0001078271-14-000020:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Research and development | 17.1 | % |  | 13.8 | % |  | 14.6 | % |  | 14.1 | % |
| Sales and marketing | 31.5 | % |  | 30.3 | % |  | 29.7 | % |  | 29.5 | % |
| General and administrative | 8.0 | % |  | 9.2 | % |  | 8.1 | % |  | 8.3 | % |
| Acquisition and integration costs | 4.5 | % |  | — | % |  | 5.2 | % |  | — | % |
| Restructuring (credit) charge, net of reversals | — | % |  | 1.6 | % |  | 0.1 | % |  | 2.8 | % |
| Amortization of intangibles | 5.4 | % |  | — | % |  | 3.1 | % |  | — | % |
| Litigation settlement (income) expense | (0.07 | )% |  | 3.6 | % |  | (0.03 | )% |  | 0.9 | % |
| Gain on sale of facilities | — | % |  | — | % |  | — | % |  | (5.3 | )% |
| Total operating expenses | 66.4 | % |  | 58.5 | % |  | 60.8 | % |  | 50.3 | % |
| Operating income (loss) | (16.5 | )% |  | (2.8 | )% |  | (10.1 | )% |  | 3.6 | % |

[0001078271-14-000020:mdna:44]
[same as prior period, unchanged from 0001078271-14-000008:mdna:42]

[0001078271-14-000020:mdna:45]
[same as prior period, unchanged from 0001078271-14-000008:mdna:43]

[0001078271-14-000020:mdna:46]
Research and development expenses increased by $14.9 million, or 158.7% in the third quarter of fiscal 2014 and $22.1 million or 71.5% for the nine months ended March 31, 2014 as compared to the corresponding periods of fiscal 2013. The increase in research and development expenses for the three and nine months ended March 31, 2014 was primarily due to increased personnel costs and higher occupancy costs as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000020:mdna:47]
[same as prior period, unchanged from 0001078271-14-000008:mdna:45]

[0001078271-14-000020:mdna:48]
[same as prior period, unchanged from 0001078271-14-000008:mdna:46]

[0001078271-14-000020:mdna:49]
Sales and marketing expenses increased by $24.1 million, or 116.5% in the third quarter of fiscal 2014 and $43.3 million or 66.8% for the nine months ended March 31, 2014 as compared to the corresponding periods of fiscal 2013. The increase in sales and marketing expenses for the three and nine months ended March 31, 2014 was primarily due to increased personnel costs  as well as spending on additional sales and marketing programs, each as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000020:mdna:50]
[same as prior period, unchanged from 0001078271-14-000008:mdna:48]

[0001078271-14-000020:mdna:51]
General and administrative expenses increased by $5.0 million, or 79.4% in the third quarter of fiscal 2014 and $11.1 million or 60.7% for the nine months ended March 31, 2014, compared to the corresponding periods of fiscal 2013. The increase in general and administrative expenses during the three and nine months ending March 31, 2014, compared to the corresponding periods of fiscal 2013, was primarily due to higher personnel and travel costs and higher occupancy costs as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000020:mdna:52]
Acquisition and Integration Costs

[0001078271-14-000020:mdna:53]
As a result of our acquisition of Enterasys, we incurred $6.4 million and $18.8 million of acquisition and integration costs during the third quarter and nine months ended March 31, 2014.  Of the total $6.4 million expense during the three months ended March 31, 2014, $6.3 million were related to integration costs and the remaining $0.1 million expense was related to acquisition costs.  Of the total $18.8 million expense for the nine months ended March 31, 2014, $12.9 million expense related to integration costs and the remaining $5.9 million expense related to acquisition costs. The Company expects to incur integration costs for the next two years.

[0001078271-14-000020:mdna:54]
Restructuring (Credit) Charge, Net of Reversals

[0001078271-14-000020:mdna:55]
Restructuring charges decreased by $1.1 million in the third quarter of fiscal 2014 and by $5.7 million in the nine months ended March 31, 2014 compared to the corresponding periods of fiscal 2013.  During the second quarter of fiscal 2013, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. The Company has substantially expensed all of the costs

[0001078271-14-000020:mdna:56]
associated with this initiative.  As of March 31, 2014, we had restructuring liabilities of $0.5 million, which we anticipate paying by the end of fiscal 2015.

[0001078271-14-000020:mdna:57]
[same as prior period, unchanged from 0001078271-14-000008:mdna:54]

[0001078271-14-000020:mdna:58]
During the three and nine months ended March 31, 2014, we recorded $7.7 million and $11.4 million of amortization, primarily for certain intangibles related to the acquisition of Enterasys.

[0001078271-14-000020:mdna:59]
Litigation Settlement (Income) Expense

[0001078271-14-000020:mdna:60]
During the third quarter of fiscal 2014, the Company received $0.1 million from the settlement of a property lease litigation matter.

[0001078271-14-000020:mdna:61]
During the third quarter of fiscal 2013, we recognized a litigation charge of $2.5 million related to a settlement agreement with Enterasys entered into prior to the acquisition.

[0001078271-14-000020:mdna:62]
Gain on Sale of Facilities

[0001078271-14-000020:mdna:63]
[same as prior period, unchanged from 0001078271-14-000008:mdna:59]

[0001078271-14-000020:mdna:64]
Interest Expense

[0001078271-14-000020:mdna:65]
During the three and nine months ended March 31, 2014 we recorded $0.8 million and $1.3 million interest expense related to the Credit Facility that the Company entered into on October 31, 2013 to fund the acquisition of Enterasys.

[0001078271-14-000020:mdna:66]
[same as prior period, unchanged from 0001078271-14-000008:mdna:60]

[0001078271-14-000020:mdna:67]
Other expense, net increased by $0.0 million in the third quarter of fiscal 2014 and by $0.5 million for the nine months ended March 31, 2014 compared to the corresponding periods of fiscal 2013.  The increase in other expense, net was primarily due to losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.  For the nine months ended March 31, 2014, we had an additional increase from an other-than-temporary impairment loss of $158,000, recorded as the Company intends to sell its investments in the near future.

[0001078271-14-000020:mdna:68]
[same as prior period, unchanged from 0001078271-14-000008:mdna:62]

[0001078271-14-000020:mdna:69]
For the three and nine months ended March 31, 2014, we recorded an income tax provision of $0.9 million and $2.3 million, respectively.  For the three and nine months ended March 31, 2013, we recorded an income tax provision of $0.4 million and $1.4 million, respectively.

[0001078271-14-000020:mdna:70]
The income tax provisions for the three and nine months ended March 31, 2014 and 2013 consisted primarily of taxes on the income of our foreign subsidiaries as well as U.S. state income taxes. The income tax provision for the three and nine months ended March 31, 2014 also includes an expense related to a deferred tax liability for the amortization of goodwill recorded as a result of the acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000020:mdna:71]
[same as prior period, unchanged from 0001078271-14-000008:mdna:65]

[0001078271-14-000020:mdna:72]
[same as prior period, unchanged from 0001078271-14-000008:mdna:66]

[0001078271-14-000020:mdna:73]
As discussed in Part II, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2013, we consider the following accounting

[0001078271-14-000020:mdna:74]
policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001078271-14-000020:mdna:75]
[same as prior period, unchanged from 0001078271-14-000008:mdna:68]

[0001078271-14-000020:mdna:76]
[same as prior period, unchanged from 0001078271-14-000008:mdna:69]

[0001078271-14-000020:mdna:77]
[same as prior period, unchanged from 0001078271-14-000008:mdna:70]

[0001078271-14-000020:mdna:78]
[same as prior period, unchanged from 0001078271-14-000008:mdna:71]

[0001078271-14-000020:mdna:79]
[same as prior period, unchanged from 0001078271-14-000008:mdna:72]

[0001078271-14-000020:mdna:80]
[same as prior period, unchanged from 0001078271-14-000008:mdna:73]

[0001078271-14-000020:mdna:81]
[same as prior period, unchanged from 0001078271-14-000008:mdna:74]

[0001078271-14-000020:mdna:82]
| • | Legal Contingencies |

[0001078271-14-000020:mdna:83]
[same as prior period, unchanged from 0001078271-14-000008:mdna:76]

[0001078271-14-000020:mdna:84]
[same as prior period, unchanged from 0001078271-14-000008:mdna:77]

[0001078271-14-000020:mdna:85]
[same as prior period, unchanged from 0001078271-14-000008:mdna:78]

[0001078271-14-000020:mdna:86]
We apply the acquisition method of accounting for business combinations, including our acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of each transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001078271-14-000020:mdna:87]
[same as prior period, unchanged from 0001078271-14-000008:mdna:80]

[0001078271-14-000020:mdna:88]
Goodwill is assessed for impairment annually or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. Goodwill is tested for impairment at the reporting unit level at adoption and at least annually thereafter.  To test goodwill for impairment, we first perform a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, we will then perform the two-step goodwill impairment test. Otherwise, the two-step goodwill impairment test is not required.  Under the two-step goodwill impairment test, we would, in the first step, compare the estimated fair value of a reporting unit to its carrying value. If the fair value of the reporting unit exceeds the carrying value, no impairment loss would be recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which we determine the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

[0001078271-14-000020:mdna:89]
[same as prior period, unchanged from 0001078271-14-000008:mdna:83]

[0001078271-14-000020:mdna:90]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss,

[0001078271-14-000020:mdna:91]
or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013. We intend to adopt this standard prospectively in the first quarter of its fiscal year ending June 30, 2015. We do not believe this updated standard will have a material impact on our consolidated financial statements.

[0001078271-14-000020:mdna:92]
[same as prior period, unchanged from 0001078271-14-000008:mdna:85]

[0001078271-14-000020:mdna:93]
[same as prior period, unchanged from 0001078271-14-000008:mdna:86]

[0001078271-14-000020:mdna:94]
|  | March 31, 2014 |  | June 30, 2013 |
| Cash and cash equivalent | $ | 71,355 |  |  | $ | 95,803 |  |
| Short-term investments | 34,700 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total cash and investments | $ | 106,055 |  |  | $ | 205,613 |  |
| Working capital | $ | 60,198 |  |  | $ | 96,279 |  |

[0001078271-14-000020:mdna:95]
As of March 31, 2014, our principal sources of liquidity consisted of cash, cash equivalents and investments of $106.1 million, net accounts receivable of $94.2 million and borrowings from the Revolving Facility under which the Company had $1.0 million of availability at March 31, 2014.  Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products, purchases of property and equipment and repurchases of our common stock. We believe that our $106.1 million of cash and cash equivalents and investments at March 31, 2014 along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months including the repayment of the additional borrowings of $24 million from the Revolving Facility.

[0001078271-14-000020:mdna:96]
Our Credit Agreement contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum a Consolidated Leverage Ratio and several other covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001078271-14-000020:mdna:97]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Agreement may be accelerated upon certain events of default.  We believe we are in compliance and expect to remain in compliance with our Credit Agreement covenants and they are not expected to impact our liquidity or capital resources.

[0001078271-14-000020:mdna:98]
[same as prior period, unchanged from 0001078271-14-000008:mdna:91]

[0001078271-14-000020:mdna:99]
[same as prior period, unchanged from 0001078271-14-000008:mdna:92]

[0001078271-14-000020:mdna:100]
|  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Net cash (used in) provided by operating activities | $ | (30,617 | ) |  | $ | 7,003 |  |
| Net cash (used in) provided by investing activities | $ | (123,113 | ) |  | $ | 24,134 |  |
| Net cash provided by (used in) financing activities | $ | 128,671 |  |  | $ | (8,434 | ) |
| Foreign currency effect on cash | $ | 611 |  |  | $ | 293 |  |
| Net (decrease) increase in cash and cash equivalents | $ | (24,448 | ) |  | $ | 22,996 |  |

[0001078271-14-000020:mdna:101]
[same as prior period, unchanged from 0001078271-14-000008:mdna:94]

[0001078271-14-000020:mdna:102]
Cash flows from operations decreased by $37.6 million in the nine months ending March 31, 2014 compared to the corresponding period of fiscal 2013 primarily due to the post acquisition increase in accounts receivables, increase in inventory balances and timing of inventory receipts to bring the inventory levels in line with the near term demand and an increase in post-acquisition accounts payable balance and the timing of payments.  Such decreases were partially offset by $4.9 million

[0001078271-14-000020:mdna:103]
cash received as tenant incentives from the landlords of existing leased facilities which the Company used towards leasehold improvements.

[0001078271-14-000020:mdna:104]
[same as prior period, unchanged from 0001078271-14-000008:mdna:96]

[0001078271-14-000020:mdna:105]
Cash flow used in investing activities in the nine months ending March 31, 2014 was $123.1 million, comprised of $180.0 million net cash used for the acquisition of Enterasys, purchases of investments of $9.0 million, $17.4 million used to purchase property and equipment offset by proceeds of $26.7 million from the maturities of investments and proceeds of $56.6 million from the sale of investments.

[0001078271-14-000020:mdna:106]
[same as prior period, unchanged from 0001078271-14-000008:mdna:98]

[0001078271-14-000020:mdna:107]
Cash flow provided by financing activities in the nine months ending March 31, 2014 was $128.7 million, comprised of issuance of Term Loan of $65.0 million and a draw on the Revolving Facility of $35 million used for the acquisition of Enterasys, an additional draw of $24 million on the Revolving Facility during the quarter ended March 31, 2014 for working capital requirements, $6.3 million proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards offset by $1.6 million of cash used for repayment of debt.

[0001078271-14-000020:mdna:108]
[same as prior period, unchanged from 0001078271-14-000008:mdna:100]

[0001078271-14-000020:mdna:109]
The following summarizes our contractual obligations at March 31, 2014, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-14-000020:mdna:110]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 122,375 |  |  | $ | 28,875 |  |  | $ | 26,000 |  |  | $ | 67,500 |  |  | $ | — |  |
| Interest on debt obligations | 9,371 |  |  | 2,598 |  |  | 4,505 |  |  | 2,268 |  |  | — |  |
| Non-cancellable inventory purchase commitments | 52,451 |  |  | 52,451 |  |  | — |  |  | — |  |  | — |  |
| Non-cancellable operating lease obligations | 39,861 |  |  | 8,269 |  |  | 10,374 |  |  | 8,267 |  |  | 12,951 |  |
| Other liabilities | 6,236 |  |  | 2,698 |  |  | 3,325 |  |  | 213 |  |  | — |  |
| Total contractual cash obligations | $ | 230,294 |  |  | $ | 94,891 |  |  | $ | 44,204 |  |  | $ | 78,248 |  |  | $ | 12,951 |  |

[0001078271-14-000020:mdna:111]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $52.5 million as of March 31, 2014, an increase of $1.4 million from $50.1 million as of June 30, 2013. We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-14-000020:mdna:112]
[same as prior period, unchanged from 0001078271-14-000008:mdna:104]

[0001078271-14-000020:mdna:113]
[same as prior period, unchanged from 0001078271-14-000008:mdna:105]

[0001078271-14-000020:mdna:114]
[same as prior period, unchanged from 0001078271-14-000008:mdna:106]

[0001078271-14-000020:mdna:115]
We did not have any material commitments for capital expenditures as of March 31, 2014.

[0001078271-14-000020:mdna:116]
[same as prior period, unchanged from 0001078271-14-000008:mdna:108]

[0001078271-14-000020:mdna:117]
We did not have any off-balance sheet arrangements as of March 31, 2014.
