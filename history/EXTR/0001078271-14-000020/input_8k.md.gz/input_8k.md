# EXTR 8-K — 0001078271-14-000016 filed 2014-05-06

## item codes, every 8-K on or before 2014-05-07

- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment of 0001078271-14-000016
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2014-05-07

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-14-000016:8k_2_02:1]
EX-99.1
2
extr8kq314ex991.htm
EARNINGS PRESS RELEASE

[0001078271-14-000016:8k_2_02:2]
EXTR 8K Q3'14 EX 99.1

[0001078271-14-000016:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-14-000016:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-14-000016:8k_2_02:5]
Extreme Networks Reports Third Quarter Fiscal Year 2014 Financial Results

[0001078271-14-000016:8k_2_02:6]
GAAP Revenue: $141.8 million & non-GAAP Revenue: $143.7 million

[0001078271-14-000016:8k_2_02:7]
GAAP EPS: Loss of $0.26 & Non-GAAP EPS: $0.02

[0001078271-14-000016:8k_2_02:8]
Announces Transition of CFO

[0001078271-14-000016:8k_2_02:9]
SAN JOSE, Calif., May 6, 2014 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for the third quarter of fiscal year 2014, ended March 31, 2014.  GAAP revenue was $141.8 million and non-GAAP revenue was $143.7 million.  GAAP net loss for the third fiscal quarter was $25.1 million, or $0.26 per share, and non-GAAP net income of $1.6 million, or $0.02 per diluted share.  This is the first quarter that Extreme Networks is reporting full quarter results which include the Enterasys acquisition.

[0001078271-14-000016:8k_2_02:10]
“Revenues of the combined Company grew three percent on a pro forma basis when compared to the prior year, with growth across all four sales regions.  During the quarter we also had a number of product introductions including the release of our 802.11ac wireless products and our 100GbE blade for the Black Diamond BDX8. Net Sight 6.0 was also released bringing network control and visibility, long enjoyed by the Enterasys installed base, to Extreme products.  We also expanded our relationship with the NFL announcing that Extreme Networks was selected as the Official Wi-Fi Analytics Provider of the NFL.  During the quarter we also signed an agreement with the Tennessee Titans to provide Wi-Fi infrastructure at LP Stadium,” said Chuck Berger, president and CEO of Extreme Networks.

[0001078271-14-000016:8k_2_02:11]
Berger added, “The integration efforts following the acquisition of Enterasys continue ahead of plan with the next major milestone, combining our ERP onto a single platform, on target to occur early in the first fiscal quarter of 2015. Once completed, we will be able to truly operate as a single Company and realize further cost synergies from the acquisition.”

[0001078271-14-000016:8k_2_02:12]
Fiscal Q3 2014 Financial Metrics:

[0001078271-14-000016:8k_2_02:13]
|  |  | Third Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2014 |  | 2013 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 109.9 |  |  | $ | 54.1 |  |  | $ | 55.8 |  |  | 103 | % |
| Service |  | $ | 31.9 |  |  | $ | 14.1 |  |  | $ | 17.8 |  |  | 126 | % |
| Total Net Revenue |  | $ | 141.8 |  |  | $ | 68.2 |  |  | $ | 73.6 |  |  | 108 | % |
| Gross Margin |  | 50 | % |  | 56 | % |  | (6 | )% |  |  |
| Operating Margin/Loss |  | (17 | )% |  | (3 | )% |  | (14 | )% |  |  |
| Net Income |  | $ | (25.1 | ) |  | $ | (2.2 | ) |  | $ | (22.9 | ) |  |  |
| Earnings per diluted share |  | $ | (0.26 | ) |  | $ | (0.02 | ) |  | $ | (0.24 | ) |  |  |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 109.9 |  |  | $ | 54.1 |  |  | $ | 55.8 |  |  | 103 | % |
| Service |  | $ | 33.8 |  |  | $ | 14.1 |  |  | $ | 19.7 |  |  | 140 | % |
| Total Net Revenue |  | $ | 143.7 |  |  | $ | 68.2 |  |  | $ | 75.5 |  |  | 111 | % |
| Gross Margin |  | 55 | % |  | 56 | % |  | (1 | )% |  |  |
| Operating Margin |  | 2 | % |  | 5 | % |  | (3 | )% |  |  |
| Net Income |  | $ | 1.6 |  |  | $ | 3.3 |  |  | $ | (1.7 | ) |  |  |
| Earnings per diluted share |  | $ | 0.02 |  |  | $ | 0.04 |  |  | $ | (0.02 | ) |  |  |

[0001078271-14-000016:8k_2_02:14]
| • | Non-GAAP Revenue of $143.7 million increased three percent compared to $139.5 million from the pro forma combined company year over year. |

[0001078271-14-000016:8k_2_02:15]
| • | Non-GAAP Gross margin for Q3 was 55.3%, a decrease of 1 percentage point from the prior quarter. |

[0001078271-14-000016:8k_2_02:16]
| • | Cash and investments ended the quarter at $106.1 million, as compared to $112.0 million from the prior quarter |

[0001078271-14-000016:8k_2_02:17]
| • | Accounts receivable balance ending Q3 was $94.2 million, flat with the prior quarter, with non-GAAP days sales outstanding (DSO) of 59, an increase of 1 day from the prior quarter. |

[0001078271-14-000016:8k_2_02:18]
| • | Inventory ending Q3 was $63.1 million, flat with the prior quarter and represents 104 non-GAAP days of inventory (DOI), an increase of 16 days from the prior quarter. |

[0001078271-14-000016:8k_2_02:19]
Recent Business Highlights:

[0001078271-14-000016:8k_2_02:20]
| • | Won the 2014 Gold Stevie Award for Contact Service Center of the Year. |

[0001078271-14-000016:8k_2_02:21]
| • | Unveiled new high performance enterprise wireless solutions featuring wireless 802.11ac, and new BlackDiamond® X8 100GbE IO modules for the data center. Both products are now generally available and have begun shipping. |

[0001078271-14-000016:8k_2_02:22]
| • | Released NetSight 6.0 Centralized management and is Extreme Networks primary network management software solution providing automated provisioning leading to rapid problem identification and resolution across the entire network. |

[0001078271-14-000016:8k_2_02:23]
| • | Purview, an application analytics application intelligence gathering tool at Layer 7 directly enables rapid decisions for better business outcomes and was selected as a finalist for Best of Interop 2014 Awards. |

[0001078271-14-000016:8k_2_02:24]
| • | IdentiFi™ Wireless LAN Wins Network Computing Magazine's Wireless Product of the Year. |

[0001078271-14-000016:8k_2_02:25]
Business Outlook:

[0001078271-14-000016:8k_2_02:26]
For its fourth quarter of fiscal 2014 ending June 30, 2014, the Company is targeting GAAP revenue in a range of $143 million to $148 million with non-GAAP revenue in a range of $145 million to $150 million.  GAAP gross margin is targeted at 50% and non-GAAP gross margin targeted at 55%. Operating expenses are targeted to be between $89 million and $92 million on a GAAP basis and $76 million to $78 million on a non-GAAP basis. GAAP net income is targeted to be between $16 million to $19 million, or $0.16 to $0.20 per diluted share.  Non-GAAP net income is targeted in a range of $2 million to $4 million, or $0.02 to $0.04 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 96 million and 100 million average outstanding shares respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses and the purchase accounting value related to deferred service revenue.

[0001078271-14-000016:8k_2_02:27]
CFO Transition

[0001078271-14-000016:8k_2_02:28]
Extreme Networks today also announced that John Kurtzweil, the company`s chief financial officer, will transition his duties and become a special assistant to the CEO beginning June 2, 2014 and will stay with the company until the end of September 2014 to ensure a seamless transition of his responsibilities.  Kurtzweil has served as the company`s CFO since 2012.

[0001078271-14-000016:8k_2_02:29]
The Company also announced that Ken Arola is joining Extreme Networks as senior vice president and CFO, effective June 2, 2014.

[0001078271-14-000016:8k_2_02:30]
Ken Arola brings more than 25 years of finance experience to Extreme Networks and most recently served as chief financial officer of Align Technology (Nasdaq: ALGN), where he was awarded Bay Area CFO of the Year in 2012.  Mr. Arola has broad financial experience in medical device and technology companies. Prior to joining Align, he spent 14 years at Adaptec. Mr. Arola holds an MBA degree from Santa Clara University and a Bachelor of Science from the University of the Pacific.

[0001078271-14-000016:8k_2_02:31]
"I am very pleased that Ken will be joining the team.  He is an experienced CFO, a seasoned leader, and has a solid track record to build on the great work we have done to take Extreme Networks to the next level," said Chuck Berger, CEO of Extreme Networks. "With his extensive experience, Ken will hit the ground running and I expect him to contribute immediately to our continued progress.

[0001078271-14-000016:8k_2_02:32]
"I want to thank John for his many contributions to Extreme Networks including his leadership around completing the acquisition of Enterasys Networks and effecting two significant restructurings. He is leaving the Company on a much stronger basis than when he joined, and he has been a key contributor that helped position us for further revenue growth and margin expansion well into the future,” continued Berger.

[0001078271-14-000016:8k_2_02:33]
"Working at Extreme Networks has been an extraordinary experience and I feel privileged to have been able to contribute to the Company`s turnaround." said Kurtzweil. "I know I am leaving the Company in good hands and on solid footing with a remarkable team of professionals that will continue to build on Extreme Networks’ achievements."

[0001078271-14-000016:8k_2_02:34]
Conference Call:

[0001078271-14-000016:8k_2_02:35]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the highlights of the third fiscal quarter 2014 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through May 12th, 2014.  The conference call may also be heard by dialing 1-877-303-9826 (international callers' dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. "The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #: 27181675"

[0001078271-14-000016:8k_2_02:36]
About Extreme Networks:

[0001078271-14-000016:8k_2_02:37]
Extreme Networks, Inc. (NASDAQ: EXTR) is setting a new standard for superior customer experience by delivering network-powered innovation and marketing leading service and support. Extreme Networks delivers high-performance switching and routing products for data center and core-to-edge networks, wired/wireless LAN access, and unified network management and control.  Its award-winning solutions include software-defined networking (SDN), cloud and high-density Wi-Fi, BYOD and enterprise mobility, identity access management and security.  Extreme Networks is headquartered in San Jose, CA and has more than 12,000 customers in over 80 countries. For more information, visit the Company's website at http://www.extremenetworks.com.

[0001078271-14-000016:8k_2_02:38]
Non-GAAP Financial Measures:

[0001078271-14-000016:8k_2_02:39]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). To supplement its consolidated financial statements presented in accordance with GAAP, the Company is also providing with this press release non-GAAP net income/(loss) and non-GAAP operating income/(loss). In preparing non-GAAP information, the company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, share-based compensation, gain on sale of facilities and litigation settlements.  The company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the company and the company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the company's operating activities with the company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the Company’s historical performance and in planning its future business activities. Please note that the company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the company presents should be considered in conjunction with, and not as a substitute for, the company’s financial information presented in accordance with GAAP.  The Company has provided a non-GAAP reconciliation of the Condensed Consolidated Statement of Operations for the periods presented in this release, which are adjusted to exclude acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, share-based compensation expense and gain on sale of facilities for these periods. These measures should only be used to evaluate the company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-14-000016:8k_2_02:40]
Forward Looking Statements:

[0001078271-14-000016:8k_2_02:41]
Actual results, including with respect to the Company’s financial targets and general business prospects, could differ materially due to a number of factors, including the risks that:

[0001078271-14-000016:8k_2_02:42]
| • | The Company may not achieve targeted revenues for the Company's products and services given increasing price competition and product technology developments in key network switching equipment markets; |

[0001078271-14-000016:8k_2_02:43]
| • | The Company may be unable to effectively integrate the businesses of Extreme Networks and Enterasys Networks, both in terms of customer acceptance of combined product lines as well as the need to align the Company’s cost structure to meet the company’s financial goals, including controlling expenses, and meet financial covenants as part of the Company’s debt financing used to acquire Enterasys Networks; |

[0001078271-14-000016:8k_2_02:44]
| • | The Company may not accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; |

[0001078271-14-000016:8k_2_02:45]
| • | The Company is dependent on third parties to manufacture its products and any potential production delays could preclude the Company from shipping sufficient quantities to meet customer orders or could result in higher production costs and lower margins; |

[0001078271-14-000016:8k_2_02:46]
| • | Ongoing uncertainty in global economic conditions, infrastructure development or customer demand could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; |

[0001078271-14-000016:8k_2_02:47]
| • | The Company’s may be unable to complete development and commercialization of products under development, such as its pipeline of new network switches and related software |

[0001078271-14-000016:8k_2_02:48]
| • | The Company may be adversely affected by ongoing litigation. |

[0001078271-14-000016:8k_2_02:49]
More information about potential factors that could affect the Company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission.  Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-14-000016:8k_2_02:50]
EXTREME NETWORKS, INC.

[0001078271-14-000016:8k_2_02:51]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-14-000016:8k_2_02:52]
(In thousands, except share and per share amounts)

[0001078271-14-000016:8k_2_02:53]
(Unaudited)

[0001078271-14-000016:8k_2_02:54]
|  | March 31, 2014 |  | June 30, 2013 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 71,355 |  |  | $ | 95,803 |  |
| Short-term investments | 34,700 |  |  | 43,034 |  |
| Accounts receivable, net of allowances of $2,150 at March 31, 2014 and $1,252 at June 30, 2013 | 94,187 |  |  | 47,642 |  |
| Inventories | 63,142 |  |  | 16,167 |  |
| Deferred income taxes | 846 |  |  | 386 |  |
| Prepaid expenses and other current assets | 16,552 |  |  | 5,749 |  |
| Total current assets | 280,782 |  |  | 208,781 |  |
| Property and equipment, net | 47,209 |  |  | 23,644 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Intangible assets, net | 97,205 |  |  | 4,243 |  |
| Goodwill | 64,537 |  |  | — |  |
| Other assets | 18,061 |  |  | 7,980 |  |
| Total assets | $ | 507,794 |  |  | $ | 311,424 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 28,875 |  |  | $ | — |  |
| Accounts payable | 36,138 |  |  | 27,163 |  |
| Accrued compensation and benefits | 25,483 |  |  | 13,503 |  |
| Restructuring liabilities | 537 |  |  | 1,466 |  |
| Accrued warranty | 7,825 |  |  | 3,296 |  |
| Deferred revenue, net | 71,183 |  |  | 33,184 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 24,217 |  |  | 17,388 |  |
| Other accrued liabilities | 26,326 |  |  | 16,502 |  |
| Total current liabilities | 220,584 |  |  | 112,502 |  |
| Deferred revenue, less current portion | 19,667 |  |  | 8,270 |  |
| Long-term debt, less current portion | 93,500 |  |  | — |  |
| Other long-term liabilities | 8,506 |  |  | 1,507 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 165,537 |  |  | 189,145 |  |
| Total liabilities and stockholders’ equity | $ | 507,794 |  |  | $ | 311,424 |  |

[0001078271-14-000016:8k_2_02:55]
EXTREME NETWORKS, INC.

[0001078271-14-000016:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000016:8k_2_02:57]
(In thousands, except per share amounts)

[0001078271-14-000016:8k_2_02:58]
(Unaudited)

[0001078271-14-000016:8k_2_02:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 109,891 |  |  | $ | 54,072 |  |  | $ | 290,001 |  |  | $ | 175,450 |  |
| Service | 31,871 |  |  | 14,131 |  |  | 74,260 |  |  | 44,431 |  |
| Total net revenues | 141,762 |  |  | 68,203 |  |  | 364,261 |  |  | 219,881 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 58,703 |  |  | 25,206 |  |  | 153,112 |  |  | 85,059 |  |
| Service | 12,204 |  |  | 5,060 |  |  | 26,742 |  |  | 16,171 |  |
| Total cost of revenues | 70,907 |  |  | 30,266 |  |  | 179,854 |  |  | 101,230 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 51,188 |  |  | 28,866 |  |  | 136,889 |  |  | 90,391 |  |
| Service | 19,667 |  |  | 9,071 |  |  | 47,518 |  |  | 28,260 |  |
| Total gross profit | 70,855 |  |  | 37,937 |  |  | 184,407 |  |  | 118,651 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 24,265 |  |  | 9,381 |  |  | 53,098 |  |  | 30,954 |  |
| Sales and marketing | 44,703 |  |  | 20,644 |  |  | 108,033 |  |  | 64,764 |  |
| General and administrative | 11,278 |  |  | 6,288 |  |  | 29,401 |  |  | 18,292 |  |
| Acquisition and integration costs | 6,443 |  |  | — |  |  | 18,826 |  |  | — |  |
| Restructuring (credit) charge, net of reversals | (6 | ) |  | 1,076 |  |  | 499 |  |  | 6,242 |  |
| Amortization of intangibles | 7,666 |  |  | — |  |  | 11,444 |  |  | — |  |
| Litigation settlement (income) expense | (100 | ) |  | 2,450 |  |  | (100 | ) |  | 2,029 |  |
| Gain on sale of facilities | — |  |  | — |  |  | — |  |  | (11,539 | ) |
| Total operating expenses | 94,249 |  |  | 39,839 |  |  | 221,201 |  |  | 110,742 |  |
| Operating (loss) income | (23,394 | ) |  | (1,902 | ) |  | (36,794 | ) |  | 7,909 |  |
| Interest income | 156 |  |  | 256 |  |  | 603 |  |  | 786 |  |
| Interest expense | (764 | ) |  | — |  |  | (1,288 | ) |  | — |  |
| Other expense, net | (146 | ) |  | (165 | ) |  | (1,338 | ) |  | (814 | ) |
| (Loss) income before income taxes | (24,148 | ) |  | (1,811 | ) |  | (38,817 | ) |  | 7,881 |  |
| Provision for income taxes | 910 |  |  | 409 |  |  | 2,262 |  |  | 1,392 |  |
| Net (loss) income | $ | (25,058 | ) |  | $ | (2,220 | ) |  | $ | (41,079 | ) |  | $ | 6,489 |  |
| Basic and diluted net (loss) income per share: |  |  |  |  |  |  |  |
| Net (loss) income per share - basic | $ | (0.26 | ) |  | $ | (0.02 | ) |  | $ | (0.43 | ) |  | $ | 0.07 |  |
| Net (loss) income per share - diluted | $ | (0.26 | ) |  | $ | (0.02 | ) |  | $ | (0.43 | ) |  | $ | 0.07 |  |
| Shares used in per share calculation - basic | 96,069 |  |  | 92,968 |  |  | 95,116 |  |  | 94,069 |  |
| Shares used in per share calculation - diluted | 96,069 |  |  | 92,968 |  |  | 95,116 |  |  | 95,094 |  |

[0001078271-14-000016:8k_2_02:60]
EXTREME NETWORKS, INC.

[0001078271-14-000016:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-14-000016:8k_2_02:62]
(In thousands)

[0001078271-14-000016:8k_2_02:63]
(Unaudited)

[0001078271-14-000016:8k_2_02:64]
|  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |
| Net cash (used in) provided by operating activities | $ | (30,617 | ) |  | $ | 7,003 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (17,384 | ) |  | (4,422 | ) |
| Acquisition, net of cash acquired | (180,000 | ) |  | — |  |
| Purchases of investments | (9,045 | ) |  | (40,113 | ) |
| Proceeds from maturities of investments and marketable securities | 26,722 |  |  | 13,867 |  |
| Proceeds from sales of investments and marketable securities | 56,594 |  |  | 12,478 |  |
| Purchases of intangible assets | — |  |  | (335 | ) |
| Proceeds from sales of facilities | — |  |  | 42,659 |  |
| Net cash (used in) provided by investing activities | (123,113 | ) |  | 24,134 |  |
| Cash flows from financing activities: |  |  |  |
| Borrowings under Revolving Facility | 59,000 |  |  | — |  |
| Borrowings under Term Loan | 65,000 |  |  | — |  |
| Repayment of Term Loan | (1,625 | ) |  | — |  |
| Proceeds from issuance of common stock | 6,296 |  |  | 2,539 |  |
| Repurchase of common stock | — |  |  | (10,973 | ) |
| Net cash provided by (used in) financing activities | 128,671 |  |  | (8,434 | ) |
| Foreign currency effect on cash | 611 |  |  | 293 |  |
| Net (decrease) increase in cash and cash equivalents | (24,448 | ) |  | 22,996 |  |
| Cash and cash equivalents at beginning of period | 95,803 |  |  | 54,596 |  |
| Cash and cash equivalents at end of period | $ | 71,355 |  |  | $ | 77,592 |  |

[0001078271-14-000016:8k_2_02:65]
Extreme Networks, Inc.

[0001078271-14-000016:8k_2_02:66]
Non-GAAP Measures of Financial Performance

[0001078271-14-000016:8k_2_02:67]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-14-000016:8k_2_02:68]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring expenses and gains related to the sale of the Santa Clara campus.

[0001078271-14-000016:8k_2_02:69]
Non-GAAP measures presented in this press release are not in accordance with or an alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-14-000016:8k_2_02:70]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-14-000016:8k_2_02:71]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring expenses and gains related to the sale of the Santa Clara campus.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-14-000016:8k_2_02:72]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-14-000016:8k_2_02:73]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-14-000016:8k_2_02:74]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-14-000016:8k_2_02:75]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-14-000016:8k_2_02:76]
Purchase accounting adjustments relating to inventory and deferred revenue.  Purchase accounting adjustments consists of adjustments to the carrying value of deferred revenue and the step up of the carrying value for finished goods inventory.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.   The carrying value of the finished goods inventories acquired was adjusted to reflect only a selling profit margin that a market

[0001078271-14-000016:8k_2_02:77]
participant would incur to fulfill an order.  However, we have excluded the step up adjustment since we believe it is not reflective of the normal profit margin we expect on similar types of transactions with 3rd party customers.

[0001078271-14-000016:8k_2_02:78]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-14-000016:8k_2_02:79]
Gains related to the sale of facilities.  The one-time net gain related to the sale of the Santa Clara campus consists of the gross proceeds of the sale less the expenses directly related to the sale such as commissions, closing costs and legal fees.  Extreme Networks excludes this gain because it is a one-time event and does not believe that the gain is reflective of ongoing operations.

[0001078271-14-000016:8k_2_02:80]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the Company's cash balance for the period.

[0001078271-14-000016:8k_2_02:81]
EXTREME NETWORKS, INC.

[0001078271-14-000016:8k_2_02:82]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000016:8k_2_02:83]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-14-000016:8k_2_02:84]
(In thousands, except per share amounts)

[0001078271-14-000016:8k_2_02:85]
(Unaudited)

[0001078271-14-000016:8k_2_02:86]
| Non-GAAP Revenue | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Revenue - GAAP Basis | $ | 141,762 |  |  | $ | 68,203 |  |  | $ | 364,261 |  |  | $ | 219,881 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Purchase accounting adjustments | $ | 1,912 |  |  | $ | — |  |  | $ | 3,676 |  |  | $ | — |  |
| Revenue - Non-GAAP Basis | $ | 143,674 |  |  | $ | 68,203 |  |  | $ | 367,937 |  |  | $ | 219,881 |  |
| Non-GAAP Gross Margin | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Gross profit - GAAP Basis | $ | 70,855 |  |  | $ | 37,937 |  |  | $ | 184,407 |  |  | $ | 118,651 |  |
| Gross margin - GAAP Basis percentage | 50 | % |  | 55.6 | % |  | 50.6 | % |  | 54.0 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 688 |  |  | $ | 179 |  |  | $ | 1,190 |  |  | $ | 717 |  |
| Purchase accounting adjustments | $ | 3,803 |  |  | $ | — |  |  | $ | 14,803 |  |  | $ | — |  |
| Amortization of intangibles | $ | 4,042 |  |  | $ | — |  |  | $ | 6,736 |  |  | $ | — |  |
| Gross profit - Non-GAAP Basis | $ | 79,388 |  |  | $ | 38,116 |  |  | $ | 207,136 |  |  | $ | 119,368 |  |
| Gross margin - Non-GAAP Basis percentage | 55.3 | % |  | 55.9 | % |  | 56.3 | % |  | 54.3 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| GAAP operating (loss) income | $ | (23,394 | ) |  | $ | (1,902 | ) |  | $ | (36,794 | ) |  | $ | 7,909 |  |
| GAAP operating (loss) income percentage | (16.5 | )% |  | (2.8 | )% |  | (10.1 | )% |  | 3.6 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 4,841 |  |  | $ | 1,841 |  |  | $ | 9,874 |  |  | $ | 5,625 |  |
| Acquisition and integration costs | $ | 6,443 |  |  | $ | — |  |  | $ | 18,826 |  |  | $ | — |  |
| Restructuring (credit) charge, net of reversal | $ | (6 | ) |  | $ | 1,076 |  |  | $ | 499 |  |  | $ | 6,242 |  |
| Amortization of intangibles | $ | 11,708 |  |  | $ | — |  |  | $ | 18,180 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 3,803 |  |  | $ | — |  |  | $ | 14,803 |  |  | $ | — |  |
| Litigation settlement (income) expense | $ | (100 | ) |  | $ | 2,618 |  |  | $ | (100 | ) |  | $ | 2,197 |  |
| Gain of sale of facilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |
| Total adjustments to GAAP operating income | $ | 26,689 |  |  | $ | 5,535 |  |  | $ | 62,082 |  |  | $ | 2,525 |  |
| Non-GAAP operating income | $ | 3,295 |  |  | $ | 3,633 |  |  | $ | 25,288 |  |  | $ | 10,434 |  |
| Non-GAAP operating income percentage | 2.3 | % |  | 5.3 | % |  | 6.9 | % |  | 4.7 | % |
| Non-GAAP Net Income | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |

[0001078271-14-000016:8k_2_02:87]
| GAAP net (loss) income | $ | (25,058 | ) |  | $ | (2,220 | ) |  | $ | (41,079 | ) |  | $ | 6,489 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 4,841 |  |  | $ | 1,841 |  |  | $ | 9,874 |  |  | $ | 5,625 |  |
| Acquisition and integration costs | $ | 6,443 |  |  | $ | — |  |  | $ | 18,826 |  |  | $ | — |  |
| Restructuring (credit) charge, net of reversal | $ | (6 | ) |  | $ | 1,076 |  |  | $ | 499 |  |  | $ | 6,242 |  |
| Amortization of intangibles | $ | 11,708 |  |  | $ | — |  |  | $ | 18,180 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 3,803 |  |  | $ | — |  |  | $ | 14,803 |  |  | $ | — |  |
| Litigation settlement (income) expense | $ | (100 | ) |  | $ | 2,618 |  |  | $ | (100 | ) |  | $ | 2,197 |  |
| Gain of sale of facilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |
| Currency loss from closing of a foreign subsidiary | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 465 |  |
| Total adjustments to GAAP net income | $ | 26,689 |  |  | $ | 5,535 |  |  | $ | 62,082 |  |  | $ | 2,990 |  |
| Non-GAAP net income | $ | 1,631 |  |  | $ | 3,315 |  |  | $ | 21,003 |  |  | $ | 9,479 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.02 |  |  | $ | 0.04 |  |  | $ | 0.21 |  |  | $ | 0.10 |  |
| Shares used in diluted net income per share calculation | 99,512 |  |  | 94,600 |  |  | 97,853 |  |  | 95,094 |  |
| Free Cash Flow | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2014 |  | March 31, 2013 |  | March 31, 2014 |  | March 31, 2013 |
| Cash flow used in operations | $ | (25,747 | ) |  | $ | (1,075 | ) |  | $ | (30,617 | ) |  | $ | 7,003 |  |
| Add: PP&E CapEx spending | (4,822 | ) |  | (1,396 | ) |  | (17,384 | ) |  | (4,422 | ) |
| Total free cash flow | $ | (30,569 | ) |  | $ | (2,471 | ) |  | $ | (48,001 | ) |  | $ | 2,581 |  |
