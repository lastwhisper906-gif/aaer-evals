# EXTR 8-K — 0001193125-26-188948 filed 2026-04-29

## item codes, every 8-K on or before 2026-04-30

- 2026-04-29 0001193125-26-188948 — 2.02, 9.01
- 2026-01-28 0001193125-26-025650 — 2.02, 9.01
- 2026-01-07 0001193125-26-005441 — 5.02
- 2025-11-13 0001193125-25-280277 — 5.07, 9.01
- 2025-11-10 0001193125-25-273961 — 7.01, 9.01
- 2025-10-29 0001193125-25-254626 — 2.02, 9.01
- 2025-08-06 0000950170-25-103531 — 2.02, 9.01
- 2025-04-30 0000950170-25-060571 — 2.02, 9.01
- 2025-02-18 0000950170-25-021808 — 8.01, 9.01
- 2025-01-29 0000950170-25-010203 — 2.02, 9.01
- 2024-11-15 0000950170-24-127573 — 5.07, 9.01
- 2024-10-30 0000950170-24-118589 — 2.02, 9.01
- 2024-08-07 0000950170-24-092273 — 2.02, 9.01
- 2024-05-01 0000950170-24-050891 — 2.02, 9.01
- 2024-01-31 0000950170-24-009144 — 2.02, 9.01
- 2024-01-08 0001193125-24-004497 — 5.02
- 2024-01-08 0000950170-24-002958 — 2.02, 9.01
- 2023-11-09 0000950170-23-062050 — 5.03, 5.07, 9.01
- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2026-04-30

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001193125-26-188948:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0001193125-26-188948:8k_2_02:2]
EX-99.1

[0001193125-26-188948:8k_2_02:3]
Exhibit 99.1

[0001193125-26-188948:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001193125-26-188948:8k_2_02:5]
Extreme Networks Reports Third Quarter Fiscal Year 2026 Financial Results

[0001193125-26-188948:8k_2_02:6]
Revenue up 11% and SaaS ARR Growth Accelerates to 29% YoY on Extreme Platform ONE Growth

[0001193125-26-188948:8k_2_02:7]
Secured Forward Supply Chain to Meet Demand and Stabilize Gross Margins

[0001193125-26-188948:8k_2_02:8]
Morrisville, NC, April 29, 2026 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its third quarter of fiscal 2026 ended March 31, 2026.

[0001193125-26-188948:8k_2_02:9]
“Our fifth straight quarter of double-digit growth highlights strong momentum, fueled by disciplined execution, differentiated technology, and rising demand for our AI-powered platform. We’ve fully addressed our current and longer-term supply chain needs, including memory, through targeted sourcing strategies, product redesign, and strategic purchase commitments. These actions position us for continued share gains and growth. This quarter’s results reflect not just our performance today, but the strength and scalability of our strategy going forward,” said Ed Meyercord, President and CEO of Extreme.

[0001193125-26-188948:8k_2_02:10]
“SaaS ARR growth accelerated, reflecting rising adoption and deeper customer engagement with Extreme Platform ONE. This momentum underscores the power of our platform approach and the shift toward a more predictable, recurring revenue model. It’s a clear signal that customers are standardizing on our platform to drive automation, boost productivity, and scale their operations,” said Meyercord.

[0001193125-26-188948:8k_2_02:11]
Kevin Rhodes, Executive Vice President and Chief Financial Officer, noted, “The third quarter marked our eighth consecutive quarter of sequential product revenue growth, reflecting continued execution and share gains. Enterprise networking demand remains resilient, and the targeted pricing actions we implemented are successfully offsetting the incremental supply chain costs we have incurred. Together, these actions underpin our gross margin results and outlook. In addition, we returned $50 million to shareholders through an accelerated share repurchase, underscoring our confidence in the durability of our operating model and cash flow generation.”

[0001193125-26-188948:8k_2_02:12]
Fiscal Third Quarter Results:

[0001193125-26-188948:8k_2_02:13]
•
Revenue $316.9 million, up 11% year-over-year and relatively flat quarter-over-quarter

[0001193125-26-188948:8k_2_02:14]
•
SaaS ARR $236.4 million, up 28.6% year-over-year and 4.2% quarter-over-quarter

[0001193125-26-188948:8k_2_02:15]
•
GAAP diluted EPS $0.08, compared to $0.03 last year and $0.06 last quarter

[0001193125-26-188948:8k_2_02:16]
•
Non-GAAP diluted EPS $0.26, compared to $0.21 last year and $0.26 last quarter

[0001193125-26-188948:8k_2_02:17]
•
GAAP gross margin 61.7%, compared to 61.7% last year and 61.4% last quarter

[0001193125-26-188948:8k_2_02:18]
•
Non-GAAP gross margin 62.3%, compared to 62.3% last year and 62.0% last quarter

[0001193125-26-188948:8k_2_02:19]
•
GAAP operating margin 5.5%, compared to 3.6% last year and 4.1% last quarter

[0001193125-26-188948:8k_2_02:20]
•
Non-GAAP operating margin 15.2%, compared to 14.1% last year and 15.0% last quarter

[0001193125-26-188948:8k_2_02:21]
•
Share repurchases of $50.0 million during the quarter

[0001193125-26-188948:8k_2_02:22]
Liquidity:

[0001193125-26-188948:8k_2_02:23]
•
Q3 ending cash balance was $210.1 million, a decrease of $9.7 million from the end of Q2 2026 and an increase of $24.6 million from the end of Q3 in the prior year.

[0001193125-26-188948:8k_2_02:24]
•
Q3 net cash was $11.3 million, as compared to net cash of $47.3 million at the end of Q2 2026 and net cash of $3.0 million at the end of Q3 in the prior year.

[0001193125-26-188948:8k_2_02:25]
Recent Key Highlights:

[0001193125-26-188948:8k_2_02:26]
•
Extreme supported Lucas Oil Stadium in Indianapolis for the NCAA Men’s Final Four and rapidly modernized connectivity by removing legacy access points and deploying temporary infrastructure to ensure the venue was fully game-ready on an accelerated timeline. With Wi-Fi 7 from Extreme coming in time for the upcoming Indianapolis Colts season, this upgrade will enhance stadium operations through faster, more reliable network performance for ticketing, security, and concessions, while elevating the fan experience with seamless high-speed connectivity for streaming and mobile engagement.

[0001193125-26-188948:8k_2_02:27]
•
Extreme secured several new Extreme Platform ONE wins during the quarter, including Asiana Airlines, Atlantic Food Distributors, Bridgeport Public Schools, City of Prescott (AZ), Johnstone Supply, Nissha Medical Technologies, and the University of Buckingham. These customers are leveraging AI-powered automation to reduce manual tasks, streamline operations, minimize network complexity, and enable faster execution at lower cost.

[0001193125-26-188948:8k_2_02:28]
•
Extreme continues to gain share within the UK National Health Service, with a new win at South London and Maudsley NHS Foundation Trust, where Extreme displaced a larger Chinese competitor. Fabric played a key role by delivering secure segmentation to protect patient data and devices. NHS selected Extreme’s one-license, one-device model for its simplicity and predictable cost.

[0001193125-26-188948:8k_2_02:29]
•
London Business School is deploying a full-stack Extreme solution to modernize networking across a complex urban campus spanning historic and modern academic buildings. The solution includes Extreme Platform ONE and wired and wireless platforms. Using Extreme Fabric, the school is automating and unifying the network across dorms, labs, and academic buildings, simplifying deployment while ensuring consistent security policies. Extreme Platform ONE provides unified management and security, while high-performance Wi-Fi 7 enables secure, seamless connectivity for students, faculty, and staff across campus.

[0001193125-26-188948:8k_2_02:30]
•
Extreme is enhancing the fan experience for the Carolina Hurricanes at the Lenovo Center with a full Wi-Fi 7 upgrade, replacing legacy Wi-Fi 5 to deliver faster, more reliable connectivity throughout the arena.

[0001193125-26-188948:8k_2_02:31]
Fiscal Q3 2026 Financial Results:

[0001193125-26-188948:8k_2_02:32]
(in millions, except percentages and per share information)

[0001193125-26-188948:8k_2_02:33]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | Change |  |
| Product |  | $ | 199.4 |  |  | $ | 178.1 |  |  | $ | 21.3 |  |
| Subscription and support |  |  | 117.5 |  |  |  | 106.4 |  |  |  | 11.1 |  |
| Total net revenue |  | $ | 316.9 |  |  | $ | 284.5 |  |  | $ | 32.4 |  |
| Gross margin |  |  | 61.7 | % |  |  | 61.7 | % |  |  | 0.0 | % |
| Operating margin |  |  | 5.5 | % |  |  | 3.6 | % |  |  | 1.9 | % |
| Net income |  | $ | 10.6 |  |  | $ | 3.5 |  |  | $ | 7.1 |  |
| Net income per diluted share |  | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.05 |  |

[0001193125-26-188948:8k_2_02:34]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | Change |  |
| Product |  | $ | 199.4 |  |  | $ | 178.1 |  |  | $ | 21.3 |  |
| Subscription and support |  |  | 117.5 |  |  |  | 106.4 |  |  |  | 11.1 |  |
| Total net revenue |  | $ | 316.9 |  |  | $ | 284.5 |  |  | $ | 32.4 |  |
| Gross margin |  |  | 62.3 | % |  |  | 62.3 | % |  |  | 0.0 | % |
| Operating margin |  |  | 15.2 | % |  |  | 14.1 | % |  |  | 1.1 | % |
| Net income |  | $ | 34.8 |  |  | $ | 28.0 |  |  | $ | 6.8 |  |
| Net income per diluted share |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.05 |  |

[0001193125-26-188948:8k_2_02:35]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, equipment and capitalized software development costs. Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, equipment and capitalized software development costs, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company’s cash balance for the period. The following table shows the non-GAAP free cash flow calculation (in millions):

[0001193125-26-188948:8k_2_02:36]
| Free Cash Flow | Three Months Ended |  |
|  | March 31, 2026 |  |  | March 31, 2025 |  |
| Cash flow provided by operations | $ | 14.2 |  |  | $ | 30.0 |  |
| Less: Capital expenditures for property, equipment and capitalized software development costs |  | (6.4 | ) |  |  | (5.8 | ) |
| Total free cash flow | $ | 7.8 |  |  | $ | 24.2 |  |

[0001193125-26-188948:8k_2_02:37]
SaaS ARR: SaaS annual recurring revenue (“SaaS ARR”) represents the annualized value of our subscription offerings and the renewable, term-based license portion of software license arrangements. SaaS ARR excludes perpetual licenses, upfront license fees, variable or non-recurring revenue, professional services revenue, support revenue from maintenance contracts, and other non-subscription revenue. SaaS ARR reflects the annual recurring revenue associated with Extreme Platform ONE (which includes embedded support), ExtremeCloud IQ, and other subscription revenue, based on the annualized value of quarterly subscription revenue and the trailing twelve months of term-based license revenue. Management uses SaaS ARR to evaluate the scale and trajectory of the Company’s subscription-based offerings and progress against customer adoption initiatives. We believe this metric is useful to investors for the same reasons, as it provides insight into our ability to acquire new customers and to maintain and

[0001193125-26-188948:8k_2_02:38]
expand our existing customer relationships. SaaS ARR is an operating metric and should be considered independently of revenue or deferred revenue determined in accordance with U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for, or a forecast of, revenue.

[0001193125-26-188948:8k_2_02:39]
Gross debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0001193125-26-188948:8k_2_02:40]
Net cash: is defined as cash and cash equivalents minus gross debt, as shown in the table below (in millions):

[0001193125-26-188948:8k_2_02:41]
| Cash and cash equivalents |  |  | Gross debt |  |  | Net cash |  |
| $ | 210.1 |  |  | $ | 198.8 |  |  | $ | 11.3 |  |

[0001193125-26-188948:8k_2_02:42]
Business Outlook:

[0001193125-26-188948:8k_2_02:43]
For its fourth quarter fiscal 2026, ending June 30, 2026, the Company is targeting:

[0001193125-26-188948:8k_2_02:44]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ4'26 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 330.0 |  |  | $ | 335.0 |  |
| Gross margin |  | 61.2 | % |  |  | 61.6 | % |
| Operating margin |  | 6.1 | % |  |  | 7.1 | % |
| Earnings per share | $ | 0.12 |  |  | $ | 0.15 |  |
| Diluted shares outstanding used in calculating GAAP EPS |  | 131.8 |  |  |  | 131.8 |  |
| FQ4'26 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 330.0 |  |  | $ | 335.0 |  |
| Gross margin |  | 61.8 | % |  |  | 62.2 | % |
| Operating margin |  | 15.2 | % |  |  | 16.1 | % |
| Earnings per share | $ | 0.28 |  |  | $ | 0.30 |  |
| Diluted shares outstanding used in calculating non-GAAP EPS |  | 131.8 |  |  |  | 131.8 |  |

[0001193125-26-188948:8k_2_02:45]
The following table shows the GAAP to non-GAAP reconciliation for Q4 FY'26 guidance:

[0001193125-26-188948:8k_2_02:46]
|  | FQ4'26 |
|  | Gross Margin |  | Operating Margin |  | Earnings per Share |
| GAAP | 61.2% - 61.6% |  | 6.1% - 7.1% |  | $0.12 - $0.15 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.5% |  | 7.0% - 7.1% |  | 0.18 |
| Amortization of product intangibles | 0.1% |  | 0.1% |  | 0.00 |
| Amortization of non-product intangibles | — |  | 0.1% |  | 0.00 |
| Litigation charges | — |  | 0.9% |  | 0.02 |
| System transition costs | — |  | 0.9% |  | 0.02 |
| Tax adjustment | — |  | — |  | (0.07) - (0.06) |
| Non-GAAP | 61.8% - 62.2% |  | 15.2% - 16.1% |  | $0.28 - $0.30 |

[0001193125-26-188948:8k_2_02:47]
The total percentage rate changes may not equal the total change in all cases due to rounding.

[0001193125-26-188948:8k_2_02:48]
For the full year fiscal 2026, ending June 30, 2026, the Company is targeting:

[0001193125-26-188948:8k_2_02:49]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FY'26 Guidance |  |  |  |  |  |
| Total net revenue | $ | 1,275.0 |  |  | $ | 1,280.0 |  |
| Gross margin |  | 61.2 | % |  |  | 61.3 | % |
| Operating margin |  | 4.8 | % |  |  | 5.1 | % |
| Earnings per share | $ | 0.30 |  |  | $ | 0.33 |  |
| Diluted shares outstanding used in calculating GAAP EPS |  | 133.9 |  |  |  | 133.9 |  |
| FY'26 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 1,275.0 |  |  | $ | 1,280.0 |  |
| Gross margin |  | 61.8 | % |  |  | 61.9 | % |
| Operating margin |  | 14.7 | % |  |  | 14.9 | % |
| Earnings per share | $ | 1.02 |  |  | $ | 1.04 |  |
| Diluted shares outstanding used in calculating non-GAAP EPS |  | 133.9 |  |  |  | 133.9 |  |

[0001193125-26-188948:8k_2_02:50]
The following table shows the GAAP to non-GAAP reconciliation for FY'26 guidance:

[0001193125-26-188948:8k_2_02:51]
|  | FY'26 |
|  | Gross Margin |  | Operating Margin |  | Earnings per Share |
| GAAP | 61.2% - 61.3% |  | 4.8% - 5.1% |  | $0.30 - $0.33 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.5% |  | 7.1% - 7.2% |  | 0.67 |
| Amortization of product intangibles | 0.1% |  | 0.1% |  | 0.01 |
| Amortization of non-product intangibles | — |  | 0.1% |  | 0.01 |
| Other non-recurring costs | — |  | 0.3% |  | 0.03 |
| Litigation charges | — |  | 0.5% |  | 0.05 |
| System transition costs | — |  | 1.7% |  | 0.16 |
| Tax adjustment | — |  | — |  | (0.22) - (0.21) |
| Non-GAAP | 61.8% - 61.9% |  | 14.7% - 14.9% |  | $1.02 - $1.04 |

[0001193125-26-188948:8k_2_02:52]
The total percentage rate changes may not equal the total change in all cases due to rounding.

[0001193125-26-188948:8k_2_02:53]
Conference Call:

[0001193125-26-188948:8k_2_02:54]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the third quarter results of fiscal 2026 as well as the business outlook for the fourth quarter of fiscal 2026 and the full year fiscal 2026, ending June 30, 2026, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Registration Link) and you will be provided with dial in details. If you would like to participate in the Q&A, please register here: Q&A Registration Link. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0001193125-26-188948:8k_2_02:55]
About Extreme:

[0001193125-26-188948:8k_2_02:56]
Extreme Networks, Inc. (EXTR) is a leader in AI-powered cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence, analytics, and automation. Tens of thousands of customers globally trust our AI-driven cloud networking solutions and industry-leading support to enable businesses to drive value, foster innovation, and overcome extreme challenges. For more information, visit Extreme’s website at https://www.extremenetworks.com/ or LinkedIn, YouTube, X (Formerly Twitter), Facebook or Instagram

[0001193125-26-188948:8k_2_02:57]
Extreme Networks, ExtremeCloud, Extreme Platform ONE, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001193125-26-188948:8k_2_02:58]
Non-GAAP Financial Measures:

[0001193125-26-188948:8k_2_02:59]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, adjusted EBITDA, net cash and free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, other non-recurring costs, debt refinancing charges and the tax effect of non-GAAP adjustments. The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company’s marketplace performance, and the Company’s ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0001193125-26-188948:8k_2_02:60]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated. These measures should only be used to evaluate the Company’s results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001193125-26-188948:8k_2_02:61]
Forward-Looking Statements:

[0001193125-26-188948:8k_2_02:62]
For more information about factors that could cause actual results and other future events to differ materially from those suggested or indicated by such forward-looking statements, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K, Quarterly Reports on Form 10-Q, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov). As a result of these risks and others, actual results could vary significantly from those anticipated in this press

[0001193125-26-188948:8k_2_02:63]
release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001193125-26-188948:8k_2_02:64]
###

[0001193125-26-188948:8k_2_02:65]
EXTREME NETWORKS, INC.

[0001193125-26-188948:8k_2_02:66]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-26-188948:8k_2_02:67]
(In thousands, except per share amounts)

[0001193125-26-188948:8k_2_02:68]
(Unaudited)

[0001193125-26-188948:8k_2_02:69]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 210,113 |  |  | $ | 231,745 |  |
| Accounts receivable, net |  |  | 162,710 |  |  |  | 126,708 |  |
| Inventories |  |  | 76,634 |  |  |  | 102,578 |  |
| Prepaid expenses and other current assets |  |  | 92,345 |  |  |  | 74,265 |  |
| Total current assets |  |  | 541,802 |  |  |  | 535,296 |  |
| Property and equipment, net |  |  | 53,544 |  |  |  | 44,366 |  |
| Operating lease right-of-use assets, net |  |  | 32,508 |  |  |  | 38,655 |  |
| Goodwill |  |  | 398,211 |  |  |  | 399,574 |  |
| Intangible assets, net |  |  | 3,840 |  |  |  | 6,541 |  |
| Other assets |  |  | 140,155 |  |  |  | 128,786 |  |
| Total assets |  | $ | 1,170,060 |  |  | $ | 1,153,218 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 81,157 |  |  | $ | 63,939 |  |
| Accrued compensation and benefits |  |  | 48,669 |  |  |  | 62,895 |  |
| Accrued warranty |  |  | 10,139 |  |  |  | 9,684 |  |
| Current portion of deferred revenue |  |  | 334,598 |  |  |  | 325,078 |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $679 and $729, respectively |  |  | 48,071 |  |  |  | 14,271 |  |
| Current portion of operating lease liabilities |  |  | 12,275 |  |  |  | 11,456 |  |
| Other accrued liabilities |  |  | 58,356 |  |  |  | 100,552 |  |
| Total current liabilities |  |  | 593,265 |  |  |  | 587,875 |  |
| Deferred revenue, less current portion |  |  | 312,515 |  |  |  | 292,415 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $777 and $1,276, respectively |  |  | 149,223 |  |  |  | 163,724 |  |
| Operating lease liabilities, less current portion |  |  | 26,170 |  |  |  | 33,991 |  |
| Deferred income taxes |  |  | 7,343 |  |  |  | 7,033 |  |
| Other long-term liabilities |  |  | 2,579 |  |  |  | 2,596 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 156,657 and 152,673 shares issued, respectively; 132,513 and 132,064 shares outstanding, respectively |  |  | 157 |  |  |  | 153 |  |
| Additional paid-in capital |  |  | 1,350,759 |  |  |  | 1,298,791 |  |
| Accumulated other comprehensive loss |  |  | (15,684 | ) |  |  | (8,137 | ) |
| Accumulated deficit |  |  | (925,352 | ) |  |  | (949,429 | ) |
| Treasury stock at cost, 24,144 shares and 20,609 shares, respectively |  |  | (330,915 | ) |  |  | (275,794 | ) |
| Total stockholders’ equity |  |  | 78,965 |  |  |  | 65,584 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,170,060 |  |  | $ | 1,153,218 |  |

[0001193125-26-188948:8k_2_02:70]
EXTREME NETWORKS, INC.

[0001193125-26-188948:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-26-188948:8k_2_02:72]
(In thousands, except per share amounts)

[0001193125-26-188948:8k_2_02:73]
(Unaudited)

[0001193125-26-188948:8k_2_02:74]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 199,345 |  |  | $ | 178,060 |  |  | $ | 591,151 |  |  | $ | 512,605 |  |
| Subscription and support |  |  | 117,529 |  |  |  | 106,445 |  |  |  | 353,893 |  |  |  | 320,459 |  |
| Total net revenues |  |  | 316,874 |  |  |  | 284,505 |  |  |  | 945,044 |  |  |  | 833,064 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 86,206 |  |  |  | 76,059 |  |  |  | 259,334 |  |  |  | 218,065 |  |
| Subscription and support |  |  | 35,124 |  |  |  | 33,037 |  |  |  | 107,057 |  |  |  | 94,960 |  |
| Total cost of revenues |  |  | 121,330 |  |  |  | 109,096 |  |  |  | 366,391 |  |  |  | 313,025 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 113,139 |  |  |  | 102,001 |  |  |  | 331,817 |  |  |  | 294,540 |  |
| Subscription and support |  |  | 82,405 |  |  |  | 73,408 |  |  |  | 246,836 |  |  |  | 225,499 |  |
| Total gross profit |  |  | 195,544 |  |  |  | 175,409 |  |  |  | 578,653 |  |  |  | 520,039 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 59,184 |  |  |  | 55,656 |  |  |  | 174,459 |  |  |  | 164,990 |  |
| Sales and marketing |  |  | 88,979 |  |  |  | 79,773 |  |  |  | 267,295 |  |  |  | 241,123 |  |
| General and administrative |  |  | 29,634 |  |  |  | 29,537 |  |  |  | 93,420 |  |  |  | 92,202 |  |
| Restructuring and related charges (benefit) |  |  | — |  |  |  | (441 | ) |  |  | 538 |  |  |  | 1,871 |  |
| Amortization of intangible assets |  |  | 407 |  |  |  | 507 |  |  |  | 1,314 |  |  |  | 1,528 |  |
| Total operating expenses |  |  | 178,204 |  |  |  | 165,032 |  |  |  | 537,026 |  |  |  | 501,714 |  |
| Operating income |  |  | 17,340 |  |  |  | 10,377 |  |  |  | 41,627 |  |  |  | 18,325 |  |
| Interest income |  |  | 983 |  |  |  | 972 |  |  |  | 3,312 |  |  |  | 2,657 |  |
| Interest expense |  |  | (3,249 | ) |  |  | (3,797 | ) |  |  | (10,262 | ) |  |  | (12,398 | ) |
| Other expense, net |  |  | (263 | ) |  |  | (385 | ) |  |  | (1,110 | ) |  |  | (445 | ) |
| Income before income taxes |  |  | 14,811 |  |  |  | 7,167 |  |  |  | 33,567 |  |  |  | 8,139 |  |
| Provision for income taxes |  |  | 4,221 |  |  |  | 3,709 |  |  |  | 9,490 |  |  |  | 7,803 |  |
| Net income |  | $ | 10,590 |  |  | $ | 3,458 |  |  | $ | 24,077 |  |  | $ | 336 |  |
| Basic and diluted income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.18 |  |  | $ | 0.00 |  |
| Net income per share – diluted |  | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.18 |  |  | $ | 0.00 |  |
| Shares used in per share calculation – basic |  |  | 132,931 |  |  |  | 132,979 |  |  |  | 133,275 |  |  |  | 132,173 |  |
| Shares used in per share calculation – diluted |  |  | 133,591 |  |  |  | 134,590 |  |  |  | 134,917 |  |  |  | 133,770 |  |

[0001193125-26-188948:8k_2_02:75]
EXTREME NETWORKS, INC.

[0001193125-26-188948:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-26-188948:8k_2_02:77]
(In thousands)

[0001193125-26-188948:8k_2_02:78]
(Unaudited)

[0001193125-26-188948:8k_2_02:79]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 24,077 |  |  | $ | 336 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 11,600 |  |  |  | 11,261 |  |
| Amortization of intangible assets |  |  | 2,631 |  |  |  | 3,356 |  |
| Amortization of cloud computing implementation costs |  |  | 2,848 |  |  |  | — |  |
| Reduction in carrying amount of right-of-use asset |  |  | 7,710 |  |  |  | 7,386 |  |
| Provision for credit losses |  |  | 430 |  |  |  | 85 |  |
| Share-based compensation |  |  | 66,447 |  |  |  | 61,573 |  |
| Deferred income taxes |  |  | 658 |  |  |  | (879 | ) |
| Provision for excess and obsolete inventory |  |  | 4,639 |  |  |  | 1,616 |  |
| Non-cash interest expense |  |  | 907 |  |  |  | 902 |  |
| Other |  |  | 1,393 |  |  |  | 703 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (36,432 | ) |  |  | (10,113 | ) |
| Inventories |  |  | 19,012 |  |  |  | 14,445 |  |
| Prepaid expenses and other assets |  |  | (38,488 | ) |  |  | (20,331 | ) |
| Accounts payable |  |  | 16,388 |  |  |  | (3,982 | ) |
| Accrued compensation and benefits |  |  | (15,927 | ) |  |  | 1,302 |  |
| Operating lease liabilities |  |  | (8,532 | ) |  |  | (8,060 | ) |
| Deferred revenue |  |  | 33,299 |  |  |  | 17,746 |  |
| Other current and long-term liabilities |  |  | (42,327 | ) |  |  | (7,254 | ) |
| Net cash provided by operating activities |  |  | 50,333 |  |  |  | 70,092 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures for property, equipment and capitalized software development costs |  |  | (20,364 | ) |  |  | (18,067 | ) |
| Net cash used in investing activities |  |  | (20,364 | ) |  |  | (18,067 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Borrowings under revolving facility |  |  | 55,000 |  |  |  | — |  |
| Payments on revolving facility |  |  | (25,000 | ) |  |  | — |  |
| Payments on debt obligations |  |  | (11,250 | ) |  |  | (7,500 | ) |
| Payments on debt financing costs |  |  | — |  |  |  | (695 | ) |
| Repurchase of common stock including accelerated share repurchases |  |  | (62,000 | ) |  |  | (13,000 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (7,596 | ) |  |  | (1,907 | ) |
| Net cash used in financing activities |  |  | (50,846 | ) |  |  | (23,102 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (755 | ) |  |  | (142 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (21,632 | ) |  |  | 28,781 |  |
| Cash and cash equivalents at beginning of period |  |  | 231,745 |  |  |  | 156,699 |  |
| Cash and cash equivalents at end of period |  | $ | 210,113 |  |  | $ | 185,480 |  |

[0001193125-26-188948:8k_2_02:80]
Extreme Networks, Inc.

[0001193125-26-188948:8k_2_02:81]
Non-GAAP Measures of Financial Performance

[0001193125-26-188948:8k_2_02:82]
To supplement the Company’s consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, adjusted EBITDA (calculated as GAAP net income excluding interest, income taxes, depreciation and amortization as well as costs or benefits that are not reflective of the Company’s ongoing or expected future operational performance as noted below), net cash and free cash flow.

[0001193125-26-188948:8k_2_02:83]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001193125-26-188948:8k_2_02:84]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP. These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-26-188948:8k_2_02:85]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors’ and management’s overall understanding of the Company’s current financial performance and the Company’s prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value. In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company’s financial reporting.

[0001193125-26-188948:8k_2_02:86]
For its internal planning process, and as discussed further below, Extreme’s management uses financial statements that do not include share-based compensation expense, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, other non-recurring costs, debt refinancing charges, and the tax effect of non-GAAP adjustments. Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company’s financial results.

[0001193125-26-188948:8k_2_02:87]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001193125-26-188948:8k_2_02:88]
Share-based compensation. Share-based compensation consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan. Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001193125-26-188948:8k_2_02:89]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships and trademarks. The amortization of the developed technology are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses. Extreme excludes these expenses since they result from an

[0001193125-26-188948:8k_2_02:90]
intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001193125-26-188948:8k_2_02:91]
Restructuring and related charges. Restructuring and related charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001193125-26-188948:8k_2_02:92]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution, our configure, price, quote solution and our enterprise resource planning tools that were not capitalizable. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0001193125-26-188948:8k_2_02:93]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for non-recurring litigations offset by any proceeds received or expected to be received from insurance.

[0001193125-26-188948:8k_2_02:94]
Debt refinancing charges. Debt refinancing charges consist of costs that were not capitalizable and are included in other expense, net, that occurred in conjunction with the amendments related to our outstanding credit facility.

[0001193125-26-188948:8k_2_02:95]
Other non-recurring costs. Other non-recurring costs consist of certain external advisory and professional fees incurred for various non-recurring transactions and activities that occur outside of the normal course of business. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0001193125-26-188948:8k_2_02:96]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0001193125-26-188948:8k_2_02:97]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0001193125-26-188948:8k_2_02:98]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Canadian, German and Indian subsidiaries which perform research and development and sales and marketing activities for the Company, as well as the Company’s Irish trading subsidiaries.

[0001193125-26-188948:8k_2_02:99]
EXTREME NETWORKS, INC.

[0001193125-26-188948:8k_2_02:100]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-26-188948:8k_2_02:101]
GAAP TO NON-GAAP RECONCILIATION

[0001193125-26-188948:8k_2_02:102]
(In thousands, except percentages and per share amounts)

[0001193125-26-188948:8k_2_02:103]
(Unaudited)

[0001193125-26-188948:8k_2_02:104]
| Revenues | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Revenues – GAAP | $ | 316,874 |  |  | $ | 284,505 |  |  | $ | 945,044 |  |  | $ | 833,064 |  |

[0001193125-26-188948:8k_2_02:105]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Gross profit – GAAP | $ | 195,544 |  |  | $ | 175,409 |  |  | $ | 578,653 |  |  | $ | 520,039 |  |
| Gross margin – GAAP percentage |  | 61.7 | % |  |  | 61.7 | % |  |  | 61.2 | % |  |  | 62.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 755 |  |  |  | 663 |  |  |  | 2,303 |  |  |  | 1,961 |  |
| Share-based compensation expense, Subscription and support |  | 723 |  |  |  | 706 |  |  |  | 2,209 |  |  |  | 2,193 |  |
| Amortization of intangibles, Product |  | 336 |  |  |  | 580 |  |  |  | 1,264 |  |  |  | 1,775 |  |
| Total adjustments to GAAP gross profit | $ | 1,814 |  |  | $ | 1,949 |  |  | $ | 5,776 |  |  | $ | 5,929 |  |
| Gross profit – non-GAAP | $ | 197,358 |  |  | $ | 177,358 |  |  | $ | 584,429 |  |  | $ | 525,968 |  |
| Gross margin – non-GAAP percentage |  | 62.3 | % |  |  | 62.3 | % |  |  | 61.8 | % |  |  | 63.1 | % |

[0001193125-26-188948:8k_2_02:106]
| Non-GAAP Operating Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| GAAP operating income | $ | 17,340 |  |  | $ | 10,377 |  |  | $ | 41,627 |  |  | $ | 18,325 |  |
| GAAP operating margin |  | 5.5 | % |  |  | 3.6 | % |  |  | 4.4 | % |  |  | 2.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,478 |  |  |  | 1,369 |  |  |  | 4,512 |  |  |  | 4,154 |  |
| Share-based compensation expense, R&D |  | 4,267 |  |  |  | 4,178 |  |  |  | 13,353 |  |  |  | 12,858 |  |
| Share-based compensation expense, S&M |  | 7,564 |  |  |  | 6,963 |  |  |  | 23,086 |  |  |  | 21,441 |  |
| Share-based compensation expense, G&A |  | 8,459 |  |  |  | 7,844 |  |  |  | 25,496 |  |  |  | 23,120 |  |
| Restructuring and related charges (benefit) |  | — |  |  |  | (441 | ) |  |  | 538 |  |  |  | 1,871 |  |
| Litigation charges |  | 376 |  |  |  | 1,123 |  |  |  | 3,135 |  |  |  | 12,716 |  |
| System transition costs |  | 7,556 |  |  |  | 7,548 |  |  |  | 18,948 |  |  |  | 16,919 |  |
| Amortization of intangibles |  | 743 |  |  |  | 1,087 |  |  |  | 2,578 |  |  |  | 3,303 |  |
| Other non-recurring costs |  | 231 |  |  |  | — |  |  |  | 3,879 |  |  |  | — |  |
| Total adjustments to GAAP operating income | $ | 30,674 |  |  | $ | 29,671 |  |  | $ | 95,525 |  |  | $ | 96,382 |  |
| Non-GAAP operating income | $ | 48,014 |  |  | $ | 40,048 |  |  | $ | 137,152 |  |  | $ | 114,707 |  |
| Non-GAAP operating margin |  | 15.2 | % |  |  | 14.1 | % |  |  | 14.5 | % |  |  | 13.8 | % |

[0001193125-26-188948:8k_2_02:107]
| Non-GAAP Net Income | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| GAAP net income | $ | 10,590 |  |  | $ | 3,458 |  |  | $ | 24,077 |  |  | $ | 336 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 21,768 |  |  |  | 20,354 |  |  |  | 66,447 |  |  |  | 61,573 |  |
| Restructuring and related charges (benefit) |  | — |  |  |  | (441 | ) |  |  | 538 |  |  |  | 1,871 |  |
| Litigation charges |  | 376 |  |  |  | 1,123 |  |  |  | 3,135 |  |  |  | 12,716 |  |
| System transition costs |  | 7,556 |  |  |  | 7,548 |  |  |  | 18,948 |  |  |  | 16,919 |  |
| Amortization of intangibles |  | 743 |  |  |  | 1,087 |  |  |  | 2,578 |  |  |  | 3,303 |  |
| Other non-recurring costs |  | 231 |  |  |  | — |  |  |  | 3,879 |  |  |  | — |  |
| Debt refinancing charges |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |
| Tax effect of non-GAAP adjustments |  | (6,419 | ) |  |  | (5,171 | ) |  |  | (19,888 | ) |  |  | (17,866 | ) |
| Total non-GAAP adjustments to GAAP net income | $ | 24,255 |  |  | $ | 24,500 |  |  | $ | 75,637 |  |  | $ | 78,595 |  |
| Non-GAAP net income | $ | 34,845 |  |  | $ | 27,958 |  |  | $ | 99,714 |  |  | $ | 78,931 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share – diluted | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.18 |  |  | $ | 0.00 |  |
| Non-GAAP net income per share – diluted | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.74 |  |  | $ | 0.59 |  |
| Shares used in net income per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP shares used in per share calculation – basic |  | 132,931 |  |  |  | 132,979 |  |  |  | 133,275 |  |  |  | 132,173 |  |
| Potentially dilutive equity awards |  | 660 |  |  |  | 1,611 |  |  |  | 1,642 |  |  |  | 1,597 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 133,591 |  |  |  | 134,590 |  |  |  | 134,917 |  |  |  | 133,770 |  |

[0001193125-26-188948:8k_2_02:108]
| Adjusted EBITDA | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| GAAP net income | $ | 10,590 |  |  | $ | 3,458 |  |  | $ | 24,077 |  |  | $ | 336 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation expense |  | 3,807 |  |  |  | 3,456 |  |  |  | 11,600 |  |  |  | 11,261 |  |
| Amortization expense |  | 2,584 |  |  |  | 1,105 |  |  |  | 5,479 |  |  |  | 3,356 |  |
| Share-based compensation expense |  | 21,768 |  |  |  | 20,354 |  |  |  | 66,447 |  |  |  | 61,573 |  |
| Restructuring and related charges (benefit) |  | — |  |  |  | (441 | ) |  |  | 538 |  |  |  | 1,871 |  |
| Litigation charges |  | 376 |  |  |  | 1,123 |  |  |  | 3,135 |  |  |  | 12,716 |  |
| System transition costs |  | 7,556 |  |  |  | 7,548 |  |  |  | 18,948 |  |  |  | 16,919 |  |
| Other non-recurring costs |  | 231 |  |  |  | — |  |  |  | 3,879 |  |  |  | — |  |
| Debt refinancing charges |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |
| Interest income |  | (983 | ) |  |  | (972 | ) |  |  | (3,312 | ) |  |  | (2,657 | ) |
| Interest expense |  | 3,249 |  |  |  | 3,797 |  |  |  | 10,262 |  |  |  | 12,398 |  |
| Provision for income taxes |  | 4,221 |  |  |  | 3,709 |  |  |  | 9,490 |  |  |  | 7,803 |  |
| Total adjustments to GAAP net income |  | 42,809 |  |  |  | 39,679 |  |  |  | 126,466 |  |  |  | 125,319 |  |
| Adjusted EBITDA | $ | 53,399 |  |  | $ | 43,137 |  |  | $ | 150,543 |  |  | $ | 125,655 |  |
