# EXTR MD&A — 0001193125-26-197200


## mdna

[0001193125-26-197200:mdna:1]
[same as prior period, unchanged from 0001193125-26-029334:mdna:1]

[0001193125-26-197200:mdna:2]
[same as prior period, unchanged from 0001193125-26-029334:mdna:2]

[0001193125-26-197200:mdna:3]
The following discussion is based upon our unaudited condensed consolidated financial statements included elsewhere in this Report. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors, including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see the “Critical Accounting Policies and Estimates” section included in this “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”

[0001193125-26-197200:mdna:4]
Extreme Networks, Inc. (“Extreme,” “Company,” “we,” “us” and “our”) is a leader in AI-powered cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence (“AI”), analytics, and automation and have industry-leading support services. Tens of thousands of customers globally trust Extreme to drive value, foster innovation, and overcome extreme challenges. Extreme also designs, develops, and manufactures wired, wireless, and software-defined wide area network (“SD-WAN”) infrastructure equipment. Our Extreme Platform ONETM solution, announced in December 2024 and made generally available in July 2025, is a technology platform that is designed to reduce the complexity for enterprises by seamlessly integrating networking, security and AI solutions into a single platform. AI-powered automation includes conversational, interactive and autonomous AI agents—to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex tasks.

[0001193125-26-197200:mdna:5]
[same as prior period, unchanged from 0001193125-26-029334:mdna:5]

[0001193125-26-197200:mdna:6]
[same as prior period, unchanged from 0001193125-26-029334:mdna:6]

[0001193125-26-197200:mdna:7]
Enterprises across every industry are going through unprecedented changes, such as digital transformation initiatives, migrating their workloads to cloud-based environments, modernizing applications, finding new ways to leverage generative, multimodal and agentic AI technology, and adapting to a distributed workforce. To accomplish this, they are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. As networks become more complex and more distributed in nature, we believe IT teams in every industry will need more control and better insights than ever before to deliver secure, distributed connectivity and comprehensive centralized visibility. Networking is mission critical and touches all elements of how services are delivered to customers, employees, students, and patients. Managing networks from a single platform that integrates AI networking and security is critical to help reduce complexity and minimize the time it takes to complete tasks. A new category has emerged in the industry to address challenges related to managing the breadth and depth of complexities related to network administration, deployment and ongoing management termed AI for networking. This new category is defined by innovation in generative, multimodal and agentic AI technology.

[0001193125-26-197200:mdna:8]
[same as prior period, unchanged from 0001193125-26-029334:mdna:8]

[0001193125-26-197200:mdna:9]
[same as prior period, unchanged from 0001193125-26-029334:mdna:9]

[0001193125-26-197200:mdna:10]
[same as prior period, unchanged from 0001193125-26-029334:mdna:10]

[0001193125-26-197200:mdna:11]
[same as prior period, unchanged from 0001193125-26-029334:mdna:11]

[0001193125-26-197200:mdna:12]
[same as prior period, unchanged from 0001193125-26-029334:mdna:12]

[0001193125-26-197200:mdna:13]
[same as prior period, unchanged from 0001193125-26-029334:mdna:13]

[0001193125-26-197200:mdna:14]
We estimate the total addressable market (“TAM”) for our networking solutions, consisting of cloud networking, wireless local area networks (“WLAN”), campus local area networks (“LAN”), Ethernet switching, data center networking, SD-WAN solutions, and elements of the Secure Access Service Edge (“SASE”), exceeded $42 billion in calendar year 2024. Based on data from 650 Group, Gartner, IDC, and Dell’Oro Group, demand is projected to grow at a five-year compound annual growth rate (“CAGR”) of approximately 7%, reaching $59 billion by 2029. Within this market, cloud-managed networking solutions are expected to grow at a CAGR of approximately 15% through 2029. And with Extreme Platform ONE, we are addressing AI Networking for the Campus, a high-growth segment forecasted to grow at a 72% CAGR over the next five years.

[0001193125-26-197200:mdna:15]
[same as prior period, unchanged from 0001193125-26-029334:mdna:15]

[0001193125-26-197200:mdna:16]
Extreme is committed to empowering organizations with new ways to simply and securely connect with Extreme’s intelligent technology platform that help move their organizations forward.

[0001193125-26-197200:mdna:17]
Extreme Platform ONE is designed to reduce complexity for enterprises by seamlessly integrating networking, security and AI solutions. The platform’s AI-powered automation includes conversational, interactive and autonomous AI agents, to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex tasks. Extreme Platform ONE is also designed to offer the industry’s simplest licensing.

[0001193125-26-197200:mdna:18]
[same as prior period, unchanged from 0001193125-26-029334:mdna:18]

[0001193125-26-197200:mdna:19]
[same as prior period, unchanged from 0001193125-26-029334:mdna:19]

[0001193125-26-197200:mdna:20]
[same as prior period, unchanged from 0001193125-26-029334:mdna:20]

[0001193125-26-197200:mdna:21]
[same as prior period, unchanged from 0001193125-26-029334:mdna:21]

[0001193125-26-197200:mdna:22]
[same as prior period, unchanged from 0001193125-26-029334:mdna:22]

[0001193125-26-197200:mdna:23]
[same as prior period, unchanged from 0001193125-26-029334:mdna:23]

[0001193125-26-197200:mdna:24]
[same as prior period, unchanged from 0001193125-26-029334:mdna:24]

[0001193125-26-197200:mdna:25]
•
Provide a differentiated end-to-end cloud networking architecture. Cloud networking is estimated to be a $15 billion segment of the networking market comprising cloud-managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at 15% annually over the next five years, according to data from the 650 Group, Gartner, IDC and Dell’Oro. Cloud management technology has evolved significantly over the past decade. Extreme offers:

[0001193125-26-197200:mdna:26]
[same as prior period, unchanged from 0001193125-26-029334:mdna:26]

[0001193125-26-197200:mdna:27]
[same as prior period, unchanged from 0001193125-26-029334:mdna:27]

[0001193125-26-197200:mdna:28]
[same as prior period, unchanged from 0001193125-26-029334:mdna:28]

[0001193125-26-197200:mdna:29]
[same as prior period, unchanged from 0001193125-26-029334:mdna:29]

[0001193125-26-197200:mdna:30]
[same as prior period, unchanged from 0001193125-26-029334:mdna:30]

[0001193125-26-197200:mdna:31]
[same as prior period, unchanged from 0001193125-26-029334:mdna:31]

[0001193125-26-197200:mdna:32]
[same as prior period, unchanged from 0001193125-26-029334:mdna:32]

[0001193125-26-197200:mdna:33]
o
Universal switches (8000 Series / 7000 Series / 5000 Series / 4000 Series / Industrial and other) support fabric or traditional networking with a choice of cloud or on-premises (air-gapped or cloud connected) management.

[0001193125-26-197200:mdna:34]
o
Universal Wi-Fi 6 / 6E / 7 APs (300 / 400, 4000 and 5000 series) support campus or distributed deployments with a choice of cloud or on-premises (air-gapped or cloud connected) management.

[0001193125-26-197200:mdna:35]
[same as prior period, unchanged from 0001193125-26-029334:mdna:35]

[0001193125-26-197200:mdna:36]
[same as prior period, unchanged from 0001193125-26-029334:mdna:36]

[0001193125-26-197200:mdna:37]
[same as prior period, unchanged from 0001193125-26-029334:mdna:37]

[0001193125-26-197200:mdna:38]
[same as prior period, unchanged from 0001193125-26-029334:mdna:38]

[0001193125-26-197200:mdna:39]
[same as prior period, unchanged from 0001193125-26-029334:mdna:39]

[0001193125-26-197200:mdna:40]
[same as prior period, unchanged from 0001193125-26-029334:mdna:40]

[0001193125-26-197200:mdna:41]
[same as prior period, unchanged from 0001193125-26-029334:mdna:41]

[0001193125-26-197200:mdna:42]
[same as prior period, unchanged from 0001193125-26-029334:mdna:42]

[0001193125-26-197200:mdna:43]
[same as prior period, unchanged from 0001193125-26-029334:mdna:43]

[0001193125-26-197200:mdna:44]
[same as prior period, unchanged from 0001193125-26-029334:mdna:44]

[0001193125-26-197200:mdna:45]
[same as prior period, unchanged from 0001193125-26-029334:mdna:45]

[0001193125-26-197200:mdna:46]
[same as prior period, unchanged from 0001193125-26-029334:mdna:46]

[0001193125-26-197200:mdna:47]
[same as prior period, unchanged from 0001193125-26-029334:mdna:47]

[0001193125-26-197200:mdna:48]
[same as prior period, unchanged from 0001193125-26-029334:mdna:48]

[0001193125-26-197200:mdna:49]
Key Business Metrics

[0001193125-26-197200:mdna:50]
Management uses certain supplemental operational metrics, including SaaS annual recurring revenue (“SaaS ARR”), to provide insight into trends in customer relationships over time, including customer acquisition, retention, and expansion of subscription offerings.

[0001193125-26-197200:mdna:51]
SaaS Annual Recurring Revenue (“SaaS ARR”)

[0001193125-26-197200:mdna:52]
SaaS ARR represents the annualized value of our subscription offerings and the renewable, term-based license portion of software license arrangements. SaaS ARR excludes perpetual licenses, upfront license fees, variable or non-recurring revenue, professional services revenue, support revenue from maintenance contracts, and other non-subscription revenue. SaaS ARR reflects the annual recurring revenue associated with Extreme Platform ONE (which includes embedded support), ExtremeCloud IQ, and other subscription revenue, based on the annualized value of quarterly subscription revenue and the trailing twelve months of term-based license revenue. Management uses SaaS ARR to evaluate the scale and trajectory of the Company’s subscription-based offerings and progress against customer adoption initiatives. We believe this metric is useful to investors for the same reasons, as it provides insight into our ability to acquire new customers and to maintain and expand our existing customer relationships. SaaS ARR is an operating metric and should be considered independently of revenue or deferred revenue determined in accordance with U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for, or a forecast of, revenue.

[0001193125-26-197200:mdna:53]
As of March 31, 2026, our SaaS ARR was $236.4 million, which was 28.6% higher than SaaS ARR of $184.0 million as of March 31, 2025. The increase in SaaS ARR was primarily due to increased adoption of our cloud network management solutions and continued growth in our subscription business.

[0001193125-26-197200:mdna:54]
[same as prior period, unchanged from 0001193125-26-029334:mdna:49]

[0001193125-26-197200:mdna:55]
During the third quarter of fiscal 2026, we achieved the following results:

[0001193125-26-197200:mdna:56]
•
Net revenues of $316.9 million compared to $284.5 million in the third quarter of fiscal 2025.

[0001193125-26-197200:mdna:57]
•
Product revenues of $199.3 million compared to $178.1 million in the third quarter of fiscal 2025.

[0001193125-26-197200:mdna:58]
•
Subscription and support revenues of $117.5 million compared to $106.4 million in the third quarter of fiscal 2025.

[0001193125-26-197200:mdna:59]
•
Total gross margin of 61.7% of net revenues compared to 61.7% of net revenues in the third quarter of fiscal 2025.

[0001193125-26-197200:mdna:60]
•
Operating income of $17.3 million compared to $10.4 million in the third quarter of fiscal 2025.

[0001193125-26-197200:mdna:61]
•
Net income of $10.6 million compared to $3.5 million in the third quarter of fiscal 2025.

[0001193125-26-197200:mdna:62]
During the first nine months of fiscal 2026, we reported the following results:

[0001193125-26-197200:mdna:63]
•
Cash flows provided by operating activities of $50.3 million compared to $70.1 million in the nine months ended March 31, 2025.

[0001193125-26-197200:mdna:64]
•
Cash and cash equivalents of $210.1 million as of March 31, 2026 compared to $231.7 million as of June 30, 2025.

[0001193125-26-197200:mdna:65]
[same as prior period, unchanged from 0001193125-26-029334:mdna:60]

[0001193125-26-197200:mdna:66]
[same as prior period, unchanged from 0001193125-26-029334:mdna:61]

[0001193125-26-197200:mdna:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | $Change |  |  | %Change |  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | $Change |  |  | %Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 199,345 |  |  | $ | 178,060 |  |  | $ | 21,285 |  |  |  | 12.0 | % |  | $ | 591,151 |  |  | $ | 512,605 |  |  | $ | 78,546 |  |  |  | 15.3 | % |
| Percentage of net revenues |  |  | 62.9 | % |  |  | 62.6 | % |  |  |  |  |  |  |  |  | 62.6 | % |  |  | 61.5 | % |  |  |  |  |  |  |
| Subscription and support |  |  | 117,529 |  |  |  | 106,445 |  |  |  | 11,084 |  |  |  | 10.4 | % |  |  | 353,893 |  |  |  | 320,459 |  |  |  | 33,434 |  |  |  | 10.4 | % |
| Percentage of net revenues |  |  | 37.1 | % |  |  | 37.4 | % |  |  |  |  |  |  |  |  | 37.4 | % |  |  | 38.5 | % |  |  |  |  |  |  |
| Total net revenues |  | $ | 316,874 |  |  | $ | 284,505 |  |  | $ | 32,369 |  |  |  | 11.4 | % |  | $ | 945,044 |  |  | $ | 833,064 |  |  | $ | 111,980 |  |  |  | 13.4 | % |

[0001193125-26-197200:mdna:68]
We generate product revenues primarily from sales of our networking equipment. We derive subscription and support revenues primarily from sales of our subscription and support offerings, which include SaaS subscription offerings, maintenance contracts, professional services and training for our products.

[0001193125-26-197200:mdna:69]
Product revenues increased $21.3 million or 12.0% for the three months ended March 31, 2026 as compared to the corresponding period in fiscal 2025.  The increase in product revenues was attributed to average selling price improvements as a result of price increases implemented during fiscal 2026. Product revenues increased $78.5 million or 15.3% for the nine months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in product revenues was due to higher shipments and increases in average selling price.

[0001193125-26-197200:mdna:70]
Subscription and support revenues increased $11.1 million or 10.4% for the three months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. Subscription and support revenues increased $33.4 million or 10.4% for the nine months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in subscription and support revenues was driven by increased adoption of our cloud network management solutions, including Platform ONE.

[0001193125-26-197200:mdna:71]
[same as prior period, unchanged from 0001193125-26-029334:mdna:66]

[0001193125-26-197200:mdna:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | $Change |  |  | %Change |  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | $Change |  |  | %Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 113,139 |  |  | $ | 102,001 |  |  | $ | 11,138 |  |  |  | 10.9 | % |  | $ | 331,817 |  |  | $ | 294,540 |  |  | $ | 37,277 |  |  |  | 12.7 | % |
| Percentage of product revenues |  |  | 56.8 | % |  |  | 57.3 | % |  |  |  |  |  |  |  |  | 56.1 | % |  |  | 57.5 | % |  |  |  |  |  |  |
| Subscription and support |  |  | 82,405 |  |  |  | 73,408 |  |  |  | 8,997 |  |  |  | 12.3 | % |  |  | 246,836 |  |  |  | 225,499 |  |  |  | 21,337 |  |  |  | 9.5 | % |
| Percentage of subscription and support revenues |  |  | 70.1 | % |  |  | 69.0 | % |  |  |  |  |  |  |  |  | 69.7 | % |  |  | 70.4 | % |  |  |  |  |  |  |
| Total gross profit |  | $ | 195,544 |  |  | $ | 175,409 |  |  | $ | 20,135 |  |  |  | 11.5 | % |  | $ | 578,653 |  |  | $ | 520,039 |  |  | $ | 58,614 |  |  |  | 11.3 | % |
| Percentage of net revenues |  |  | 61.7 | % |  |  | 61.7 | % |  |  |  |  |  |  |  |  | 61.2 | % |  |  | 62.4 | % |  |  |  |  |  |  |

[0001193125-26-197200:mdna:73]
Product gross profit increased $11.1 million or 10.9% for the three months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in product gross profit was primarily due to the increase in product revenues of $21.3 million, partially offset by a corresponding increase in direct product costs and increased distribution costs of $1.4 million driven by higher shipments and an increase in purchase price variances of $4.2 million driven by higher memory component costs.

[0001193125-26-197200:mdna:74]
Product gross profit increased $37.3 million or 12.7% for the nine months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in product gross profit was primarily due to the increase in product revenues of $78.6 million, partially offset by a corresponding increase in direct product costs and increased distribution costs of $7.9 million driven by higher shipments and an increase in purchase price variances of $7.5 million driven by higher memory component costs.

[0001193125-26-197200:mdna:75]
Subscription and support gross profit increased $9.0 million or 12.3% for the three months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in subscription and support gross profit was primarily due to higher subscription revenues of $11.1 million related to increased adoption of the Company’s Platform ONE subscription, partially offset by $2.6 million of higher subscription hosting costs.

[0001193125-26-197200:mdna:76]
Subscription and support gross profit increased $21.3 million or 9.5% for the nine months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in subscription and support gross profit was primarily due to higher subscription revenues of $33.4 million related to increased adoption of the Company’s Platform ONE subscription, partially offset by $8.4 million of higher subscription hosting costs and $3.1 of personnel costs related to the fulfillment of support contracts.

[0001193125-26-197200:mdna:77]
[same as prior period, unchanged from 0001193125-26-029334:mdna:70]

[0001193125-26-197200:mdna:78]
[same as prior period, unchanged from 0001193125-26-029334:mdna:71]

[0001193125-26-197200:mdna:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | $Change |  |  | %Change |  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | $Change |  |  | %Change |  |
| Research and development |  | $ | 59,184 |  |  | $ | 55,656 |  |  | $ | 3,528 |  |  |  | 6.3 | % |  | $ | 174,459 |  |  | $ | 164,990 |  |  | $ | 9,469 |  |  |  | 5.7 | % |
| Sales and marketing |  |  | 88,979 |  |  |  | 79,773 |  |  |  | 9,206 |  |  |  | 11.5 | % |  |  | 267,295 |  |  |  | 241,123 |  |  |  | 26,172 |  |  |  | 10.9 | % |
| General and administrative |  |  | 29,634 |  |  |  | 29,537 |  |  |  | 97 |  |  |  | 0.3 | % |  |  | 93,420 |  |  |  | 92,202 |  |  |  | 1,218 |  |  |  | 1.3 | % |
| Restructuring and related charges (benefits) |  |  | — |  |  |  | (441 | ) |  |  | 441 |  |  |  | (100.0 | )% |  |  | 538 |  |  |  | 1,871 |  |  |  | (1,333 | ) |  |  | (71.2 | )% |
| Amortization of intangible assets |  |  | 407 |  |  |  | 507 |  |  |  | (100 | ) |  |  | (19.7 | )% |  |  | 1,314 |  |  |  | 1,528 |  |  |  | (214 | ) |  |  | (14.0 | )% |
| Total operating expenses |  | $ | 178,204 |  |  | $ | 165,032 |  |  | $ | 13,172 |  |  |  | 8.0 | % |  | $ | 537,026 |  |  | $ | 501,714 |  |  | $ | 35,312 |  |  |  | 7.0 | % |

[0001193125-26-197200:mdna:80]
[same as prior period, unchanged from 0001193125-26-029334:mdna:73]

[0001193125-26-197200:mdna:81]
[same as prior period, unchanged from 0001193125-26-029334:mdna:74]

[0001193125-26-197200:mdna:82]
Research and development expenses increased by $3.5 million or 6.3% for the three months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in research and development expenses was primarily due to a $1.5 million increase in personnel costs due to higher compensation and benefits costs, a $1.0 million increase in information technology and equipment costs, and a $1.0 million increase in other expenses primarily consisting of engineering project costs and depreciation costs.

[0001193125-26-197200:mdna:83]
Research and development expenses increased by $9.5 million or 5.7% for the nine months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in research and development expenses was primarily due to a $4.9 million increase in personnel costs due to higher compensation and benefits costs, a $2.6 million increase in engineering project costs, and a $2.0 million increase in information technology and equipment costs.

[0001193125-26-197200:mdna:84]
[same as prior period, unchanged from 0001193125-26-029334:mdna:77]

[0001193125-26-197200:mdna:85]
[same as prior period, unchanged from 0001193125-26-029334:mdna:78]

[0001193125-26-197200:mdna:86]
Sales and marketing expenses increased by $9.2 million or 11.5% for the three months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in sales and marketing expenses was primarily due to a $4.9 million increase in personnel costs due to higher compensation and benefits costs, a $2.0 million increase in sales commissions, a $1.5 million increase in information technology and equipment costs, and a $0.8 million increase in other expenses primarily related to professional fees and travel costs.

[0001193125-26-197200:mdna:87]
Sales and marketing expenses increased by $26.2 million or 10.9% for the nine months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in sales and marketing expenses was primarily due to a $13.1 million increase in personnel costs due to higher compensation and benefits costs, a $7.3 million increase in sales commissions, a $3.3 million increase in information technology and equipment costs, a $1.7 million increase in professional fees, and a $0.8 million increase in travel expenses.

[0001193125-26-197200:mdna:88]
[same as prior period, unchanged from 0001193125-26-029334:mdna:81]

[0001193125-26-197200:mdna:89]
[same as prior period, unchanged from 0001193125-26-029334:mdna:82]

[0001193125-26-197200:mdna:90]
General and administrative expenses remained relatively flat year over year with an increase of less than $0.1 million or 0.3% for the three months ended March 31, 2026 as compared to the corresponding period in fiscal 2025.

[0001193125-26-197200:mdna:91]
General and administrative expenses increased by $1.2 million or 1.3% for the nine months ended March 31, 2026 as compared to the corresponding period in fiscal 2025. The increase in general and administrative expenses was primarily due to a $5.9 million increase in personnel costs due to higher salaries and benefits costs, a $2.9 million increase in amortization expense related to cloud computing implementation costs, and a $2.0 million increase in system transition costs, partially offset by a $9.6 million decrease in legal costs related to litigation matters, net of insurance recoveries.

[0001193125-26-197200:mdna:92]
Restructuring and Related Charges (Benefits)

[0001193125-26-197200:mdna:93]
For the nine months ended March 31, 2026, we recorded restructuring charges of $0.5 million, which primarily consisted of severance and benefit costs and asset disposal costs related to the restructuring plans executed in prior years, as described in Note 13, Restructuring and Related Charges (Benefits), in the Notes to Condensed Consolidated Financial Statements included elsewhere in this Report.

[0001193125-26-197200:mdna:94]
For the three and nine months ended March 31, 2025, we recorded a restructuring benefit of $0.4 million and restructuring charges of $1.9 million, respectively, which primarily consisted of additions to severance and benefits costs and professional services fees as well as reversals of previously established accruals related to unused severance benefits associated with the reduction-in-force actions related to the “Q2 2024 Plan,” and “Q3 2024 Plan,” each as described in Note 13, Restructuring and Related Charges (Benefits), in Notes to Condensed Consolidated Financial Statements included elsewhere in this Report.

[0001193125-26-197200:mdna:95]
[same as prior period, unchanged from 0001193125-26-029334:mdna:88]

[0001193125-26-197200:mdna:96]
During the three months ended March 31, 2026 and 2025, we recorded $0.4 million and $0.5 million of operating expenses, respectively, related to the amortization of intangible assets.

[0001193125-26-197200:mdna:97]
During the nine months ended March 31, 2026 and 2025, we recorded $1.3 million and $1.5 million of operating expenses, respectively, related to the amortization of intangible assets.

[0001193125-26-197200:mdna:98]
[same as prior period, unchanged from 0001193125-26-029334:mdna:91]

[0001193125-26-197200:mdna:99]
During each of the three months ended March 31, 2026 and 2025, we recorded $1.0 million in interest income.

[0001193125-26-197200:mdna:100]
During the nine months ended March 31, 2026 and 2025, we recorded $3.3 million and $2.7 million, respectively, in interest income. The increase in interest income was primarily related to the higher interest earned on our cash accounts due to interest rates as well as higher cash and cash equivalents balances held during fiscal 2026.

[0001193125-26-197200:mdna:101]
[same as prior period, unchanged from 0001193125-26-029334:mdna:94]

[0001193125-26-197200:mdna:102]
During the three months ended March 31, 2026 and 2025, we recorded $3.2 million and $3.8 million, respectively, in interest expense related to the debt obligations held under our Amended Credit Agreement. The decrease in interest expense was primarily due to lower average interest rates under the Amended Credit Agreement.

[0001193125-26-197200:mdna:103]
During the nine months ended March 31, 2026 and 2025, we recorded $10.3 million and $12.4 million, respectively, in interest expense related to the debt obligations held under our Amended Credit Agreement. The decrease in interest expense was primarily due to lower average interest rates under the Amended Credit Agreement.

[0001193125-26-197200:mdna:104]
Other Expense, Net

[0001193125-26-197200:mdna:105]
During the three months ended March 31, 2026 and 2025, we recorded other expense, net of $0.3 million and $0.4 million, respectively. The other expense, net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001193125-26-197200:mdna:106]
During the nine months ended March 31, 2026 and 2025, we recorded other expense, net of $1.1 million and $0.4 million, respectively. The other expense, net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001193125-26-197200:mdna:107]
[same as prior period, unchanged from 0001193125-26-029334:mdna:100]

[0001193125-26-197200:mdna:108]
For the three months ended March 31, 2026 and 2025, we recorded an income tax provision of $4.2 million and $3.7 million, respectively.

[0001193125-26-197200:mdna:109]
For the nine months ended March 31, 2026 and 2025, we recorded an income tax provision of $9.5 million and $7.8 million, respectively.

[0001193125-26-197200:mdna:110]
The income tax provisions for the three and nine months ended March 31, 2026 and 2025 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications Systems.

[0001193125-26-197200:mdna:111]
[same as prior period, unchanged from 0001193125-26-029334:mdna:104]

[0001193125-26-197200:mdna:112]
[same as prior period, unchanged from 0001193125-26-029334:mdna:105]

[0001193125-26-197200:mdna:113]
[same as prior period, unchanged from 0001193125-26-029334:mdna:106]

[0001193125-26-197200:mdna:114]
[same as prior period, unchanged from 0001193125-26-029334:mdna:107]

[0001193125-26-197200:mdna:115]
[same as prior period, unchanged from 0001193125-26-029334:mdna:108]

[0001193125-26-197200:mdna:116]
[same as prior period, unchanged from 0001193125-26-029334:mdna:109]

[0001193125-26-197200:mdna:117]
[same as prior period, unchanged from 0001193125-26-029334:mdna:110]

[0001193125-26-197200:mdna:118]
[same as prior period, unchanged from 0001193125-26-029334:mdna:111]

[0001193125-26-197200:mdna:119]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| Cash and cash equivalents |  | $ | 210,113 |  |  | $ | 231,745 |  |

[0001193125-26-197200:mdna:120]
As of March 31, 2026, our principal sources of liquidity consisted of cash and cash equivalents of $210.1 million, accounts receivable, net of $162.7 million, and available borrowings under our 2023 Revolving Facility of $105.8 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, repayments of debt and related interest and share repurchases. We believe that our $210.1 million of cash and cash equivalents as of March 31, 2026, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0001193125-26-197200:mdna:121]
On February 18, 2025, we announced that our Board had authorized management to repurchase up to $200 million of shares of the Company’s common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”). Under this repurchase program, purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on its evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The 2025 Repurchase Program does not obligate us to acquire any shares of our common stock, and it may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations.

[0001193125-26-197200:mdna:122]
On January 30, 2026, the Company entered into an accelerated share repurchase agreement (the “2026 ASR”) to repurchase shares of the Company’s common stock as part of the 2025 Repurchase Program. Pursuant to the 2026 ASR and during the three months ended March 31, 2026, the Company paid $50 million for an initial delivery of 2,957,550 shares valued at $43.1 million with an average price of $14.58 per share. The remaining balance of $6.9 million was recorded in “Additional paid-in capital” as a forward contract in the Company’s common stock. The forward contract was settled on April 24, 2026 and the Company received an additional 342,257 shares of its common stock.

[0001193125-26-197200:mdna:123]
During the nine months ended March 31, 2026, we repurchased a total of 3,534,831 shares of its common stock, including the 2,957,550 shares purchased as part of the 2026 ASR, at a total cost of $55.1 million, excluding the $6.9 million included in additional paid-in capital in the condensed consolidated balance sheet as of March 31, 2026 for the unsettled portion, with an average price of $15.59 per share. As of March 31, 2026, the Company had $138.0 million available under the 2025 Repurchase Program.

[0001193125-26-197200:mdna:124]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an

[0001193125-26-197200:mdna:125]
aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use the proceeds of the loans for working capital and general corporate purposes.

[0001193125-26-197200:mdna:126]
[same as prior period, unchanged from 0001193125-26-029334:mdna:116]

[0001193125-26-197200:mdna:127]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001193125-26-197200:mdna:128]
On August 14, 2024, we entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, “Amended Credit Agreement”). Under the Amended Credit Agreement, we modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the Amended Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with our operations and activities.

[0001193125-26-197200:mdna:129]
As of March 31, 2026, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0001193125-26-197200:mdna:130]
[same as prior period, unchanged from 0001193125-26-029334:mdna:120]

[0001193125-26-197200:mdna:131]
[same as prior period, unchanged from 0001193125-26-029334:mdna:121]

[0001193125-26-197200:mdna:132]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Net cash provided by operating activities |  | $ | 50,333 |  |  | $ | 70,092 |  |
| Net cash used in investing activities |  |  | (20,364 | ) |  |  | (18,067 | ) |
| Net cash used in financing activities |  |  | (50,846 | ) |  |  | (23,102 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (755 | ) |  |  | (142 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (21,632 | ) |  | $ | 28,781 |  |

[0001193125-26-197200:mdna:133]
[same as prior period, unchanged from 0001193125-26-029334:mdna:123]

[0001193125-26-197200:mdna:134]
Cash flows provided by operations in the nine months ended March 31, 2026 were $50.3 million, including net income of $24.1 million and non-cash expenses of $99.3 million for items such as amortization of intangible assets, amortization of cloud computing implementation costs, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory, provision for credit losses and interest. Other sources of cash for the period included a decrease in inventories and increases in accounts payable, and deferred revenue. This was partially offset by increases in accounts receivable and prepaid and other assets as well as decreases in operating lease liabilities, accrued compensation and benefits and other liabilities.

[0001193125-26-197200:mdna:135]
Cash flows provided by operations in the nine months ended March 31, 2025 were $70.1 million, including net income of $0.3 million and non-cash expenses of $86.0 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in inventories and increases in deferred revenue and accrued compensation and benefits. This was partially offset by increases in accounts receivable and prepaid expenses and other assets as well as decreases in accounts payable, operating lease liabilities and other liabilities.

[0001193125-26-197200:mdna:136]
[same as prior period, unchanged from 0001193125-26-029334:mdna:126]

[0001193125-26-197200:mdna:137]
Cash flows used in investing activities in the nine months ended March 31, 2026 were $20.4 million for the purchases of property and equipment and capitalized software development costs.

[0001193125-26-197200:mdna:138]
Cash flows used in investing activities in the nine months ended March 31, 2025 were $18.1 million for the purchases of property and equipment and capitalized software development costs.

[0001193125-26-197200:mdna:139]
[same as prior period, unchanged from 0001193125-26-029334:mdna:129]

[0001193125-26-197200:mdna:140]
Cash flows used in financing activities in the nine months ended March 31, 2026 were $50.8 million primarily due to share repurchases of $62.0 million under the 2025 Repurchase Program, payments of $7.6 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options and debt repayments of $11.3 million.

[0001193125-26-197200:mdna:141]
Cash flows used in financing activities in the nine months ended March 31, 2025 were $23.1 million primarily due to share repurchases of $13.0 million, payments of $1.9 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, a payment of $0.7 million for debt financing costs related to the Amended Credit Agreement, and debt repayments of $7.5 million.

[0001193125-26-197200:mdna:142]
Foreign Currency Effect on Cash and Cash Equivalents

[0001193125-26-197200:mdna:143]
Foreign currency effect on cash and cash equivalents increased in the nine months ended March 31, 2026, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the Euro.

[0001193125-26-197200:mdna:144]
[same as prior period, unchanged from 0001193125-26-029334:mdna:134]

[0001193125-26-197200:mdna:145]
As of March 31, 2026, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0001193125-26-197200:mdna:146]
Our debt obligations relate to amounts owed under our Amended Credit Agreement. As of March 31, 2026, we had $198.8 million of debt outstanding, which is payable in quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and an unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0001193125-26-197200:mdna:147]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of March 31, 2026, we had non-cancelable commitments to purchase $101.6 million of inventory, including commitments for semiconductor components. These obligations reflect our ongoing effort to secure component supply and reduce supply chain risk given continued constraints in the global semiconductor market. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0001193125-26-197200:mdna:148]
We have contractual commitments to our suppliers which represent commitments for future services. As of March 31, 2026, we had contractual commitments of $10.8 million that are due through fiscal year 2027.

[0001193125-26-197200:mdna:149]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of March 31, 2026, the value of our obligations under operating leases was $44.5 million.

[0001193125-26-197200:mdna:150]
[same as prior period, unchanged from 0001193125-26-029334:mdna:140]

[0001193125-26-197200:mdna:151]
We did not have any material commitments for capital expenditures as of March 31, 2026.

[0001193125-26-197200:mdna:152]
[same as prior period, unchanged from 0001193125-26-029334:mdna:142]

[0001193125-26-197200:mdna:153]
We did not have any off-balance sheet arrangements as of March 31, 2026.
