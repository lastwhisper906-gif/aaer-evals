# EXTR notes — 0001193125-26-197200


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-26-197200:notes:1]
[same as prior period, unchanged from 0001193125-26-029334:notes:1]

[0001193125-26-197200:notes:2]
[same as prior period, unchanged from 0001193125-26-029334:notes:2]

[0001193125-26-197200:notes:3]
[same as prior period, unchanged from 0001193125-26-029334:notes:3]

[0001193125-26-197200:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2026. The results of operations for the three and nine months ended March 31, 2026 are not necessarily indicative of the results that may be expected for fiscal 2026 or any future periods.

[0001193125-26-197200:notes:5]
[same as prior period, unchanged from 0001193125-26-029334:notes:5]

[0001193125-26-197200:notes:6]
[same as prior period, unchanged from 0001193125-26-029334:notes:6]

[0001193125-26-197200:notes:7]
[same as prior period, unchanged from 0001193125-26-029334:notes:7]

[0001193125-26-197200:notes:8]
[same as prior period, unchanged from 0001193125-26-029334:notes:8]

[0001193125-26-197200:notes:9]
[same as prior period, unchanged from 0001193125-26-029334:notes:9]

[0001193125-26-197200:notes:10]
[same as prior period, unchanged from 0001193125-26-029334:notes:10]

[0001193125-26-197200:notes:11]
[same as prior period, unchanged from 0001193125-26-029334:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-26-197200:notes:12]
[same as prior period, unchanged from 0001193125-26-029334:notes:12]

[0001193125-26-197200:notes:13]
[same as prior period, unchanged from 0001193125-26-029334:notes:13]

[0001193125-26-197200:notes:14]
Recently Adopted Accounting Pronouncements

[0001193125-26-197200:notes:15]
There were no recently adopted accounting standards which would have a material effect on the Company’s condensed consolidated financial statements and accompanying disclosures.

[0001193125-26-197200:notes:16]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0001193125-26-197200:notes:17]
In December 2025, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2025-11, Interim Reporting (Topic 270): Narrow-Scope Improvements. This ASU provides clarifications intended to improve the consistency and usability of interim disclosure requirements, including a comprehensive listing of required interim disclosures. The standard introduces a new disclosure principle for interim reporting to help entities determine whether disclosures not specified in Topic 270 should be provided in interim periods. ASU 2025-11 is effective for fiscal years beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-11 on its consolidated financial statements and related disclosures.

[0001193125-26-197200:notes:18]
In November 2025, the FASB issued ASU 2025-09, Derivatives and Hedging (Topic 815): Hedge Accounting Improvements. This ASU amends certain aspects of existing guidance to more closely align hedge accounting with the economics of the Company’s risk management activities. ASU 2025-09 is effective for fiscal years beginning after December 15, 2026, and interim periods within those annual reporting periods and should be applied on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-09 on its consolidated financial statements and related disclosures.

[0001193125-26-197200:notes:19]
In September 2025, the FASB issued ASU 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. This ASU removes all references to prescriptive and sequential software development stages and requires entities to begin capitalizing software costs when management authorizes and commits to funding the software project, and it is probable that the project will be completed, and the software will be used for its intended purpose. The amendments in this ASU are effective for fiscal years beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-06 on its consolidated financial statements and related disclosures.

[0001193125-26-197200:notes:20]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets to address challenges encountered when applying the guidance in Topic 326, Financial Instruments—Credit Losses, to current accounts receivable and current contract assets arising from transactions accounted for under Topic 606, Revenue from Contracts with Customers. ASU 2025-05 is effective for fiscal years beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2025-05 on its consolidated financial statements and related disclosures.

[0001193125-26-197200:notes:21]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.

[0001193125-26-197200:notes:22]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. The Company will be adopting ASU 2023-09 for fiscal year ended June 30, 2026.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-26-197200:notes:23]
[same as prior period, unchanged from 0001193125-26-029334:notes:23]

[0001193125-26-197200:notes:24]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts to customers and partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company’s products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell primarily to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0001193125-26-197200:notes:25]
[same as prior period, unchanged from 0001193125-26-029334:notes:25]

[0001193125-26-197200:notes:26]
[same as prior period, unchanged from 0001193125-26-029334:notes:26]

[0001193125-26-197200:notes:27]
[same as prior period, unchanged from 0001193125-26-029334:notes:27]

[0001193125-26-197200:notes:28]
As of March 31, 2026, the Company had $647.1 million of remaining performance obligations, which is primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 17% of its deferred revenue as revenue in the remainder of fiscal 2026, an additional 42% in fiscal 2027, and the remaining 41% of the balance thereafter.

[0001193125-26-197200:notes:29]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable SaaS subscription and support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are billed fully at the inception of contract. The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001193125-26-197200:notes:30]
Revenue recognized for the three months ended March 31, 2026 and 2025 that was included in the deferred revenue balance at the beginning of each period was $104.9 million and $96.9 million, respectively. Revenue recognized for the nine months ended March 31, 2026 and 2025 that was included in the deferred revenue balance at the beginning of each period was $262.5 million and $245.5 million, respectively.

[0001193125-26-197200:notes:31]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $29.7 million and $26.9 million as of March 31, 2026 and June 30, 2025, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2026 and 2025 was $3.6 million and $3.2 million, respectively. Amortization recognized during the nine months ended March 31, 2026 and 2025 was $10.5 million and $9.3 million, respectively.

[0001193125-26-197200:notes:32]
[same as prior period, unchanged from 0001193125-26-029334:notes:32]

[0001193125-26-197200:notes:33]
[same as prior period, unchanged from 0001193125-26-029334:notes:33]

[0001193125-26-197200:notes:34]
[same as prior period, unchanged from 0001193125-26-029334:notes:34]

[0001193125-26-197200:notes:35]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 128,424 |  |  | $ | 145,426 |  |  | $ | 399,981 |  |  | $ | 418,356 |  |
| Other |  |  | 10,589 |  |  |  | 14,126 |  |  |  | 36,682 |  |  |  | 38,018 |  |
| Total Americas |  |  | 139,013 |  |  |  | 159,552 |  |  |  | 436,663 |  |  |  | 456,374 |  |
| EMEA |  |  | 152,966 |  |  |  | 107,132 |  |  |  | 414,601 |  |  |  | 320,307 |  |
| APAC |  |  | 24,895 |  |  |  | 17,821 |  |  |  | 93,780 |  |  |  | 56,383 |  |
| Total net revenues |  | $ | 316,874 |  |  | $ | 284,505 |  |  | $ | 945,044 |  |  | $ | 833,064 |  |

[0001193125-26-197200:notes:36]
[same as prior period, unchanged from 0001193125-26-029334:notes:36]

[0001193125-26-197200:notes:37]
For the three and nine months ended March 31, 2026 the Company generated 15% and 13% of its net revenues from the Netherlands, respectively. For the three and nine months ended March 31, 2025, the Company generated 10% and 11% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of the Company’s net revenues for the three and nine months ended March 31, 2026 and 2025.

[0001193125-26-197200:notes:38]
[same as prior period, unchanged from 0001193125-26-029334:notes:38]

[0001193125-26-197200:notes:39]
[same as prior period, unchanged from 0001193125-26-029334:notes:39]

[0001193125-26-197200:notes:40]
[same as prior period, unchanged from 0001193125-26-029334:notes:40]

[0001193125-26-197200:notes:41]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, 2026 |  | March 31, 2025 |  | March 31, 2026 |  | March 31, 2025 |
| Westcon Group, Inc. |  | 20% |  | 16% |  | 19% |  | 17% |
| TD Synnex Corporation |  | 15% |  | 18% |  | 16% |  | 19% |
| Jenne, Inc. |  | 12% |  | 21% |  | 15% |  | 19% |

[0001193125-26-197200:notes:42]
[same as prior period, unchanged from 0001193125-26-029334:notes:42]

[0001193125-26-197200:notes:43]
|  |  | March 31, 2026 |  | June 30, 2025 |
| Westcon Group, Inc. |  | 18% |  | * |
| Jenne, Inc. |  | 14% |  | 22% |
| Scansource, Inc. |  | 11% |  | * |
| Ericsson, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001193125-26-197200:notes:44]
[same as prior period, unchanged from 0001193125-26-029334:notes:44]

[0001193125-26-197200:notes:45]
[same as prior period, unchanged from 0001193125-26-029334:notes:45]

[0001193125-26-197200:notes:46]
[same as prior period, unchanged from 0001193125-26-029334:notes:46]

[0001193125-26-197200:notes:47]
The following table summarizes the Company’s cash and cash equivalents (in thousands):

[0001193125-26-197200:notes:48]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| Cash |  | $ | 199,628 |  |  | $ | 225,656 |  |
| Cash equivalents |  |  | 10,485 |  |  |  | 6,089 |  |
| Total cash and cash equivalents |  | $ | 210,113 |  |  | $ | 231,745 |  |

[0001193125-26-197200:notes:49]
[same as prior period, unchanged from 0001193125-26-029334:notes:49]

[0001193125-26-197200:notes:50]
The following table summarizes the Company’s inventory by category (in thousands):

[0001193125-26-197200:notes:51]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| Finished goods |  | $ | 47,007 |  |  | $ | 57,770 |  |
| Raw materials |  |  | 29,627 |  |  |  | 44,808 |  |
| Total inventories |  | $ | 76,634 |  |  | $ | 102,578 |  |

[0001193125-26-197200:notes:52]
[same as prior period, unchanged from 0001193125-26-029334:notes:52]

[0001193125-26-197200:notes:53]
The following table summarizes the Company’s property and equipment, net by category (in thousands):

[0001193125-26-197200:notes:54]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| Computers and equipment |  | $ | 81,033 |  |  | $ | 80,782 |  |
| Software |  |  | 68,548 |  |  |  | 62,089 |  |
| Office equipment, furniture and fixtures |  |  | 8,078 |  |  |  | 8,031 |  |
| Leasehold improvements |  |  | 54,858 |  |  |  | 47,962 |  |
| Total property and equipment |  |  | 212,517 |  |  |  | 198,864 |  |
| Less: accumulated depreciation and amortization |  |  | (158,973 | ) |  |  | (154,498 | ) |
| Property and equipment, net |  | $ | 53,544 |  |  | $ | 44,366 |  |

[0001193125-26-197200:notes:55]
[same as prior period, unchanged from 0001193125-26-029334:notes:55]

[0001193125-26-197200:notes:56]
[same as prior period, unchanged from 0001193125-26-029334:notes:56]

[0001193125-26-197200:notes:57]
[same as prior period, unchanged from 0001193125-26-029334:notes:57]

[0001193125-26-197200:notes:58]
[same as prior period, unchanged from 0001193125-26-029334:notes:58]

[0001193125-26-197200:notes:59]
[same as prior period, unchanged from 0001193125-26-029334:notes:59]

[0001193125-26-197200:notes:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Balance at beginning of period |  | $ | 9,628 |  |  | $ | 10,036 |  |  | $ | 9,684 |  |  | $ | 10,942 |  |
| New warranties issued |  |  | 3,422 |  |  |  | 2,855 |  |  |  | 9,214 |  |  |  | 8,387 |  |
| Warranty expenditures |  |  | (2,911 | ) |  |  | (3,418 | ) |  |  | (8,759 | ) |  |  | (9,856 | ) |
| Balance at end of period |  | $ | 10,139 |  |  | $ | 9,473 |  |  | $ | 10,139 |  |  | $ | 9,473 |  |

[0001193125-26-197200:notes:61]
[same as prior period, unchanged from 0001193125-26-029334:notes:61]

[0001193125-26-197200:notes:62]
[same as prior period, unchanged from 0001193125-26-029334:notes:62]

[0001193125-26-197200:notes:63]
[same as prior period, unchanged from 0001193125-26-029334:notes:63]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-26-197200:notes:64]
[same as prior period, unchanged from 0001193125-26-029334:notes:64]

[0001193125-26-197200:notes:65]
[same as prior period, unchanged from 0001193125-26-029334:notes:65]

[0001193125-26-197200:notes:66]
[same as prior period, unchanged from 0001193125-26-029334:notes:66]

[0001193125-26-197200:notes:67]
[same as prior period, unchanged from 0001193125-26-029334:notes:67]

[0001193125-26-197200:notes:68]
[same as prior period, unchanged from 0001193125-26-029334:notes:68]

[0001193125-26-197200:notes:69]
[same as prior period, unchanged from 0001193125-26-029334:notes:69]

[0001193125-26-197200:notes:70]
| March 31, 2026 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 10,485 |  |  | $ | — |  |  | $ | 10,485 |  |
| Foreign currency derivatives not designated as hedging instruments |  |  | — |  |  |  | 7 |  |  |  | — |  |  |  | 7 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 10,492 |  |  | $ | — |  |  | $ | 10,492 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives not designated as hedging instruments |  | $ | — |  |  | $ | 326 |  |  | $ | — |  |  | $ | 326 |  |
| Foreign currency derivatives designated as hedging instruments |  |  | — |  |  |  | 2,152 |  |  |  | — |  |  |  | 2,152 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 2,478 |  |  | $ | — |  |  | $ | 2,478 |  |

[0001193125-26-197200:notes:71]
[same as prior period, unchanged from 0001193125-26-029334:notes:71]

[0001193125-26-197200:notes:72]
[same as prior period, unchanged from 0001193125-26-029334:notes:72]

[0001193125-26-197200:notes:73]
The Company’s level 2 assets consist of certificates of deposit and derivative instruments. Certificates of deposit do not have regular market pricing and are considered Level 2. The fair value of derivative instruments under the Company’s foreign exchange forward contracts and zero-cost collar contracts are estimated based on valuations provided by alternative pricing sources supported by observable inputs, which is considered Level 2.

[0001193125-26-197200:notes:74]
As of March 31, 2026 and June 30, 2025, the Company had investment in certificates of deposit of $10.5 million and $6.1 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed consolidated

[0001193125-26-197200:notes:75]
balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of March 31, 2026 and June 30, 2025, their fair value approximated their amortized cost.

[0001193125-26-197200:notes:76]
As of March 31, 2026 and June 30, 2025, the Company had foreign exchange forward contracts that were not designated as hedging instruments with a total notional principal amount of $65.9 million and $57.2 million, respectively. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in “Other expense, net” in the condensed consolidated statements of operations. For the three months ended March 31, 2026 and 2025, the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $2.2 million and net gains of $0.6 million, respectively. For the nine months ended March 31, 2026 and 2025, the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $3.9 million and $0.7 million, respectively. See Note 12, Derivatives and Hedging, for additional information.

[0001193125-26-197200:notes:77]
As of March 31, 2026, the Company had zero-cost collar contracts that were designated as hedging instruments with a total notional principal amount of $80.4 million. As of June 30, 2025, there were no outstanding zero-cost collar contracts that were designated as hedging instruments. The changes in fair value of these zero-cost collar contracts designated as hedging instruments are included in “Accumulated other comprehensive loss” in the condensed consolidated balance sheets. Amounts recorded in “Accumulated other comprehensive loss” related to the changes in the fair value of the zero-cost collar contracts are reclassified into the condensed consolidated statement of operations in the period that the hedged item impacts earnings. As of March 31, 2026, these contracts had unrealized losses of $2.2 million, which are recorded as a component of “Accumulated other comprehensive loss”. See Note 12, Derivatives and Hedging, for additional information.

[0001193125-26-197200:notes:78]
The fair value of borrowings under the Amended Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the Amended Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $198.8 million and $180.0 million as of March 31, 2026 and June 30, 2025, respectively.

[0001193125-26-197200:notes:79]
[same as prior period, unchanged from 0001193125-26-029334:notes:79]

[0001193125-26-197200:notes:80]
As of March 31, 2026 and June 30, 2025, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2, or Level 3 during the three and nine months ended March 31, 2026 and 2025. There were no impairments recorded for the three and nine months ended March 31, 2026 and 2025.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-26-197200:notes:81]
[same as prior period, unchanged from 0001193125-26-029334:notes:81]

[0001193125-26-197200:notes:82]
[same as prior period, unchanged from 0001193125-26-029334:notes:82]

[0001193125-26-197200:notes:83]
[same as prior period, unchanged from 0001193125-26-029334:notes:83]

[0001193125-26-197200:notes:84]
|  |  | Weighted Average Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2026 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 170,194 |  |  | $ | 166,950 |  |  | $ | 3,244 |  |
| Customer relationships |  | 0.3 years |  |  | 64,788 |  |  |  | 64,246 |  |  |  | 542 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 0.8 years |  |  | 1,282 |  |  |  | 1,228 |  |  |  | 54 |  |
| Total intangible assets, net* |  |  |  | $ | 246,964 |  |  | $ | 243,124 |  |  | $ | 3,840 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation. |  |  |  |  |

[0001193125-26-197200:notes:85]
[same as prior period, unchanged from 0001193125-26-029334:notes:85]

[0001193125-26-197200:notes:86]
[same as prior period, unchanged from 0001193125-26-029334:notes:86]

[0001193125-26-197200:notes:87]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 354 |  |  | $ | 598 |  |  | $ | 1,317 |  |  | $ | 1,828 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 407 |  |  |  | 507 |  |  |  | 1,314 |  |  |  | 1,528 |  |
| Total amortization expense |  | $ | 761 |  |  | $ | 1,105 |  |  | $ | 2,631 |  |  | $ | 3,356 |  |

[0001193125-26-197200:notes:88]
[same as prior period, unchanged from 0001193125-26-029334:notes:88]

[0001193125-26-197200:notes:89]
[same as prior period, unchanged from 0001193125-26-029334:notes:89]

[0001193125-26-197200:notes:90]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2026 (the remainder of fiscal 2026) |  | $ | 746 |  |
| 2027 |  |  | 1,493 |  |
| 2028 |  |  | 1,325 |  |
| 2029 |  |  | 276 |  |
| Total |  | $ | 3,840 |  |

[0001193125-26-197200:notes:91]
[same as prior period, unchanged from 0001193125-26-029334:notes:91]

[0001193125-26-197200:notes:92]
The Company had goodwill in the amount of $398.2 million and $399.6 million as of March 31, 2026 and June 30, 2025, respectively. The change in goodwill during the nine months ended March 31, 2026 is primarily due to foreign currency translation adjustments which are recorded as a component of “Accumulated other comprehensive loss” in the condensed consolidated balance sheets.


## us-gaap:DebtDisclosureTextBlock

[0001193125-26-197200:notes:93]
7.
Debt

[0001193125-26-197200:notes:94]
The Company’s debt is comprised of the following (in thousands):

[0001193125-26-197200:notes:95]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term loan |  | $ | 18,750 |  |  | $ | 15,000 |  |
| Revolving facility |  |  | 30,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (679 | ) |  |  | (729 | ) |
| Current portion of long-term debt |  | $ | 48,071 |  |  | $ | 14,271 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term loan |  | $ | 150,000 |  |  | $ | 165,000 |  |
| Less: unamortized debt issuance costs |  |  | (777 | ) |  |  | (1,276 | ) |
| Total long-term debt, less current portion |  |  | 149,223 |  |  |  | 163,724 |  |
| Total debt |  | $ | 197,294 |  |  | $ | 177,995 |  |

[0001193125-26-197200:notes:96]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the Amended and Restated Credit Agreement, dated August 9, 2019, by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

[0001193125-26-197200:notes:97]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the

[0001193125-26-197200:notes:98]
Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0001193125-26-197200:notes:99]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001193125-26-197200:notes:100]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company’s operations and activities. Further, the Amended Credit Agreement provided a waiver for the Company’s compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024. As of March 31, 2026, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0001193125-26-197200:notes:101]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each of the three months ended March 31, 2026 and 2025, and was $0.9 million for each of the nine months ended March 31, 2026 and 2025. The interest rate was 5.77% and 6.41% as of March 31, 2026 and 2025, respectively.

[0001193125-26-197200:notes:102]
During the three months ended March 31, 2026, the Company borrowed $30.0 million against the 2023 Revolving Facility which was subsequently paid out in April 2026. As of March 31, 2026, the Company had $105.8 million of availability for borrowing under the 2023 Revolving Facility. During the three and nine months ended March 31, 2026 and 2025, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

[0001193125-26-197200:notes:103]
The Company had $14.2 million of outstanding letters of credit as of March 31, 2026.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-26-197200:notes:104]
8.
Commitments and Contingencies

[0001193125-26-197200:notes:105]
Purchase Commitments

[0001193125-26-197200:notes:106]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2026, the Company had commitments to purchase $101.6 million of inventory.

[0001193125-26-197200:notes:107]
Legal Proceedings

[0001193125-26-197200:notes:108]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001193125-26-197200:notes:109]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company’s results of operations in a particular quarter or fiscal year.

[0001193125-26-197200:notes:110]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0001193125-26-197200:notes:111]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.

[0001193125-26-197200:notes:112]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. Mala appealed the decision on March 3, 2025, and filed its Grounds of Appeal on June 5, 2025. The Company filed its response to the Grounds of Appeal on October 6, 2025. A hearing on the appeal is scheduled for February 9, 2027.

[0001193125-26-197200:notes:113]
Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al.

[0001193125-26-197200:notes:114]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company’s business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Firefighters Pension and Retirement System, Oklahoma Police Pension and Retirement System, Oakland County Voluntary Employees’ Beneficiary Association, Oakland County Employees’ Retirement System as the lead plaintiffs. The Company’s Motion to Dismiss was granted on August 15, 2025, but the plaintiffs were granted leave to file a second amended complaint. Plaintiffs filed a second amended complaint on September 9, 2025. The Company filed a motion to dismiss the second amended complaint on October 3, 2025. Following a hearing on March 3, 2026, the Court denied the Company’s motion to dismiss.

[0001193125-26-197200:notes:115]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these shareholder derivative cases names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. Plaintiffs filed an amended complaint in the two California shareholder derivative cases on December 1, 2025.  The Company filed a motion to dismiss the amended complaint on December 19, 2025, and a hearing on the motion to dismiss took place on March 31, 2026. Plaintiffs filed a second amended complaint on April 28, 2026. The North Carolina case remains stayed pending a final decision on the motion to dismiss in the California cases.

[0001193125-26-197200:notes:116]
Indemnification Obligations

[0001193125-26-197200:notes:117]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-26-197200:notes:118]
[same as prior period, unchanged from 0001193125-26-029334:notes:118]

[0001193125-26-197200:notes:119]
[same as prior period, unchanged from 0001193125-26-029334:notes:119]

[0001193125-26-197200:notes:120]
[same as prior period, unchanged from 0001193125-26-029334:notes:120]

[0001193125-26-197200:notes:121]
[same as prior period, unchanged from 0001193125-26-029334:notes:121]

[0001193125-26-197200:notes:122]
On February 18, 2025, the Company announced that the Board had authorized management to repurchase up to $200.0 million of shares of the Company’s common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”). Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0001193125-26-197200:notes:123]
On January 30, 2026, the Company entered into an accelerated share repurchase agreement (the “2026 ASR”) to repurchase shares of the Company’s common stock as part of the 2025 Repurchase Program.  Pursuant to the 2026 ASR and during the three months ended March 31, 2026, the Company paid $50.0 million for an initial delivery of 2,957,550 shares valued at $43.1 million with an average price of $14.58 per share. The remaining balance of $6.9 million was recorded in “Additional paid-in capital” as a forward contract in the Company’s common stock. The forward contract was settled on April 24, 2026 and the Company received an additional 342,257 shares of its common stock.

[0001193125-26-197200:notes:124]
During the nine months ended March 31, 2026, the Company repurchased a total of 3,534,831 shares of its common stock, including the 2,957,550 shares purchased as part of the 2026 ASR, at a total cost of $55.1 million, excluding the $6.9 million included in additional paid-in capital in the condensed consolidated balance sheet as of March 31, 2026 for the unsettled portion, with an average price of $15.59 per share. As of March 31, 2026, approximately $138.0 million remains available for share repurchases under the 2025 Repurchase Program.

[0001193125-26-197200:notes:125]
[same as prior period, unchanged from 0001193125-26-029334:notes:124]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-26-197200:notes:126]
[same as prior period, unchanged from 0001193125-26-029334:notes:125]

[0001193125-26-197200:notes:127]
[same as prior period, unchanged from 0001193125-26-029334:notes:126]

[0001193125-26-197200:notes:128]
[same as prior period, unchanged from 0001193125-26-029334:notes:127]

[0001193125-26-197200:notes:129]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 13,292 |  |  |  | 10,935 |  |
| Employee stock options and awards outstanding |  |  | 7,872 |  |  |  | 7,566 |  |
| 2014 Employee Stock Purchase Plan |  |  | 4,643 |  |  |  | 5,952 |  |
| Total shares reserved for issuance |  |  | 25,807 |  |  |  | 24,453 |  |

[0001193125-26-197200:notes:130]
[same as prior period, unchanged from 0001193125-26-029334:notes:129]

[0001193125-26-197200:notes:131]
[same as prior period, unchanged from 0001193125-26-029334:notes:130]

[0001193125-26-197200:notes:132]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Cost of product revenues |  | $ | 755 |  |  | $ | 663 |  |  | $ | 2,303 |  |  | $ | 1,961 |  |
| Cost of subscription and support revenues |  |  | 723 |  |  |  | 706 |  |  |  | 2,209 |  |  |  | 2,193 |  |
| Research and development |  |  | 4,267 |  |  |  | 4,178 |  |  |  | 13,353 |  |  |  | 12,858 |  |
| Sales and marketing |  |  | 7,564 |  |  |  | 6,963 |  |  |  | 23,086 |  |  |  | 21,441 |  |
| General and administrative |  |  | 8,459 |  |  |  | 7,844 |  |  |  | 25,496 |  |  |  | 23,120 |  |
| Total share-based compensation expense |  | $ | 21,768 |  |  | $ | 20,354 |  |  | $ | 66,447 |  |  | $ | 61,573 |  |

[0001193125-26-197200:notes:133]
[same as prior period, unchanged from 0001193125-26-029334:notes:132]

[0001193125-26-197200:notes:134]
The following table summarizes stock option activity for the nine months ended March 31, 2026 (in thousands, except per share amount and contractual term):

[0001193125-26-197200:notes:135]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2025 |  |  | 496 |  |  | $ | 6.70 |  |  |  | 1.16 |  |  | $ | 5,580 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (271 | ) |  |  | 6.70 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2026 |  |  | 225 |  |  | $ | 6.70 |  |  |  | 0.41 |  |  | $ | 1,882 |  |
| Vested and expected to vest at March 31, 2026 |  |  | 225 |  |  | $ | 6.70 |  |  |  | 0.41 |  |  | $ | 1,882 |  |
| Exercisable at March 31, 2026 |  |  | 225 |  |  | $ | 6.70 |  |  |  | 0.41 |  |  | $ | 1,882 |  |

[0001193125-26-197200:notes:136]
There were no stock options granted during the three and nine months ended March 31, 2026 and 2025.

[0001193125-26-197200:notes:137]
[same as prior period, unchanged from 0001193125-26-029334:notes:136]

[0001193125-26-197200:notes:138]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance-condition or market-condition RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the stock awards over the vesting period based on the awards’ fair value as of the date of grant. The Company does not estimate forfeitures, but accounts for them as incurred.

[0001193125-26-197200:notes:139]
The following table summarizes stock award activity for the nine months ended March 31, 2026 (in thousands, except grant date fair value):

[0001193125-26-197200:notes:140]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2025 |  |  | 7,070 |  |  | $ | 19.53 |  |  |  |  |
| Granted |  |  | 4,551 |  |  |  | 20.65 |  |  |  |  |
| Released |  |  | (3,825 | ) |  |  | 18.86 |  |  |  |  |
| Canceled |  |  | (149 | ) |  |  | 19.78 |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2026 |  |  | 7,647 |  |  | $ | 20.55 |  |  |  |  |
| Stock awards expected to vest at March 31, 2026 |  |  | 7,647 |  |  | $ | 20.55 |  |  | $ | 157,134 |  |

[0001193125-26-197200:notes:141]
[same as prior period, unchanged from 0001193125-26-029334:notes:141]

[0001193125-26-197200:notes:142]
During the nine months ended March 31, 2026, the Company granted approximately 0.8 million stock awards with vesting based on market conditions (“MSU”) to certain of the Company’s employees. The MSUs vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”). The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0001193125-26-197200:notes:143]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the nine months ended March 31, 2026 and 2025 was $22.23 per share and $17.10 per share, respectively. The following assumptions used to determine the grant-date fair values of the MSU during the following periods:

[0001193125-26-197200:notes:144]
|  |  | Equity Incentive Plan |  |  |
|  |  | Nine Months Ended |  |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  |
| Expected term |  | 3.0 years |  |  | 3.0 years |  |  |
| Risk-free interest rate |  |  | 3.70 | % |  |  | 3.87 | % |  |
| Volatility |  |  | 45 | % |  |  | 48 | % |  |
| Dividend yield |  |  | — | % |  |  | — | % |  |

[0001193125-26-197200:notes:145]
As of March 31, 2026, there was $102.4 million in unrecognized compensation cost related to non-vested stock awards, including performance and market condition awards. This cost is expected to be recognized over a weighted average period of 1.66 years.

[0001193125-26-197200:notes:146]
[same as prior period, unchanged from 0001193125-26-029334:notes:146]

[0001193125-26-197200:notes:147]
There were approximately 0.8 million and 0.7 million shares issued under the ESPP during the three months ended March 31, 2026 and 2025, respectively. There were approximately 1.3 million and 1.2 million shares issued under the ESPP during the nine months ended March 31, 2026 and 2025, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001193125-26-197200:notes:148]
|  |  | Employee Stock Purchase Plan |  |  | Employee Stock Purchase Plan |  |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  |
| Risk-free interest rate |  | 3.59% |  |  |  | 4.32 | % |  | 3.86% |  |  |  | 4.73 | % |  |
| Volatility |  |  | 41 | % |  |  | 39 | % |  |  | 46 | % |  |  | 37 | % |  |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |

[0001193125-26-197200:notes:149]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended March 31, 2026 and 2025 was $3.91 and $4.32 per share, respectively. The weighted-average grant-date fair value of shares under the ESPP during the nine months ended March 31, 2026 and 2025 was $4.88 and $3.99 per share, respectively.


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001193125-26-197200:notes:150]
[same as prior period, unchanged from 0001193125-26-029334:notes:150]

[0001193125-26-197200:notes:151]
[same as prior period, unchanged from 0001193125-26-029334:notes:151]

[0001193125-26-197200:notes:152]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended March 31, 2026 and 2025 was $3.91 and $4.32 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-26-197200:notes:153]
[same as prior period, unchanged from 0001193125-26-029334:notes:152]

[0001193125-26-197200:notes:154]
The Company operates as a single reportable segment focused on the development, marketing, and sale of network infrastructure equipment and related software. The Company conducts business globally.

[0001193125-26-197200:notes:155]
[same as prior period, unchanged from 0001193125-26-029334:notes:154]

[0001193125-26-197200:notes:156]
The Company’s chief operating decision maker (“CODM”), who is its Chief Executive Officer, reviews financial information presented on a consolidated basis and uses consolidated net income (loss), as reflected in the consolidated statements of operations, to assess performance and decide how to allocate resources within the business. Consolidated net income (loss) is also used in the Company’s annual budgeting and forecasting processes to establish goals and compare actual results against both budgeted targets and historical performance.

[0001193125-26-197200:notes:157]
Significant segment expenses that are regularly provided to and reviewed by the CODM are those presented in the consolidated statements of operations: costs of revenue, research and development, sales and marketing, and general and administrative. Other segment items included in consolidated net income are restructuring and related charges, amortization of intangible assets, interest income, interest expense, other expense, net, and the provision for income taxes, which are also presented in the consolidated statements of operations.

[0001193125-26-197200:notes:158]
[same as prior period, unchanged from 0001193125-26-029334:notes:162]

[0001193125-26-197200:notes:159]
The measure of segment assets that is reviewed by the CODM is reported within the condensed consolidated balance sheets as “Total assets.” Depreciation expense recorded for the three months ended March 31, 2026 and 2025 was $3.8 million and $3.4 million, respectively. Depreciation expense recorded for the nine months ended March 31, 2026 and 2025 was $11.4 million and $11.1 million, respectively.

[0001193125-26-197200:notes:160]
Total expenditures for additions to property, plant and equipment recorded for each of the three months ended March 31, 2026 and 2025 was $6.4 million and $5.7 million, respectively. Total expenditures for additions to property, plant and equipment recorded for the nine months ended March 31, 2026 and 2025 was $20.4 million and $18.1 million, respectively.

[0001193125-26-197200:notes:161]
[same as prior period, unchanged from 0001193125-26-029334:notes:165]

[0001193125-26-197200:notes:162]
|  |  | March 31, 2026 |  |  | June 30, 2025 |  |
| Segment long-lived assets: |  |  |  |  |  |  |
| Americas |  | $ | 184,420 |  |  | $ | 167,499 |  |
| EMEA |  |  | 36,713 |  |  |  | 40,299 |  |
| APAC |  |  | 8,914 |  |  |  | 10,550 |  |
| Total segment long-lived assets |  | $ | 230,047 |  |  | $ | 218,348 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-26-197200:notes:163]
[same as prior period, unchanged from 0001193125-26-029334:notes:167]

[0001193125-26-197200:notes:164]
[same as prior period, unchanged from 0001193125-26-029334:notes:168]

[0001193125-26-197200:notes:165]
[same as prior period, unchanged from 0001193125-26-029334:notes:169]

[0001193125-26-197200:notes:166]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other expense, net” in the accompanying condensed consolidated statements of operations. As of March 31, 2026 and June 30, 2025, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $65.9 million and $57.2 million, respectively. For the three months ended March 31, 2026 and 2025, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net losses of $2.2 million and net gains of $0.6 million, respectively. For the nine months ended March 31, 2026 and 2025, the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $3.9 million and $0.7 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001193125-26-197200:notes:167]
[same as prior period, unchanged from 0001193125-26-029334:notes:171]

[0001193125-26-197200:notes:168]
The Company uses zero-cost collar contracts, designated as cash flow hedges, to hedge the foreign currency risk associated with forecasted foreign currency denominated operating expenses. The changes in fair value of these derivatives are recorded as a component of “Accumulated other comprehensive loss” in the condensed consolidated balance sheets. Amounts recorded in “Accumulated other comprehensive loss” related to the changes in the fair value of these derivatives are reclassified to the condensed consolidated statement of operations in the same period in which the underlying hedged transaction affects earnings.

[0001193125-26-197200:notes:169]
As of March 31, 2026, the Company had zero-cost collar contracts that were designated as hedging instruments with a total notional principal amount of $80.4 million and had maturities of less than twelve months. As of June 30, 2025, there were no outstanding zero-cost collar contracts that were designated as hedging instruments. As of March 31, 2026, these contracts had unrealized losses of $2.2 million, which are recorded as a component of “Accumulated other comprehensive loss”. For each of the three and nine months ended March, 31 2026, these contracts had realized net losses of $0.1 million reclassified to the condensed consolidated statement of operations.

[0001193125-26-197200:notes:170]
Foreign Currency Transactions
For the three months ended March 31, 2026 and 2025, the Company recognized foreign currency transaction net gains of $1.9 million and foreign currency transaction net losses of $0.9 million, respectively, and for the nine months ended March 31, 2026 and 2025, the Company recognized foreign currency transaction net gains of $2.9 million and $0.5 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-26-197200:notes:171]
13.
Restructuring and Related Charges (Benefits)

[0001193125-26-197200:notes:172]
The Company had no significant restructuring activities during the three and nine months ended March 31, 2026. The Company recorded a restructuring benefit of $0.4 million during the three months ended March 31, 2025. The Company recorded restructuring charges of $0.5 million and $1.9 million during the nine months ended March 31, 2026 and 2025, respectively. These charges primarily included severance and benefits costs and professional fees as well as asset disposal costs related to the restructuring plans executed in prior years which are all substantially completed as of March 31, 2026.

[0001193125-26-197200:notes:173]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company’s research and development and sales and marketing functions to align the Company’s workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”), which was completed as of December 31, 2025. During the nine months ended March 31, 2026, the Company recorded restructuring charges of $0.4 million related to the Q3 2024 Plan, which primarily consisted of severance and benefits expenses, legal and consulting fees. During the three and nine months ended March 31, 2025, the Company recorded restructuring benefit of $0.2 million and restructuring charges of $1.3 million, respectively, related to the Q3 2024 Plan. These charges primarily consisted of severance and benefits expenses, legal and consulting fees.

[0001193125-26-197200:notes:174]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company’s business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”), which was substantially completed as of March 31, 2026. During the nine months ended March 31, 2026, the Company recorded restructuring benefits of $0.2 million, respectively, related to the Q2 2024 Plan due to reversals of previously established accruals related to unused severance benefits. During the three and nine months ended March 31, 2025, the Company recorded a restructuring benefit of $0.2 million and restructuring charges of $0.4 million, respectively, related to the Q2 2024 Plan, which primarily consisted of severance and benefits expenses, legal and consulting fees and reversals of previously established accruals related to unused severance benefits.

[0001193125-26-197200:notes:175]
Through March 31, 2026, the Company incurred $28.6 million in restructuring charges under the Q2 2024 Plan and Q3 2024 Plan which primarily related to severance and benefits costs.

[0001193125-26-197200:notes:176]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company moved engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company’s labs. The plan was completed as of December 31, 2025. During the nine months ended March 31, 2026, the Company recorded charges of $0.3 million for asset disposals related to the 2023 Plan. During the nine months ended March 31, 2025, the Company recorded restructuring charges of $0.1 million related to the 2023 Plan.

[0001193125-26-197200:notes:177]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of March 31, 2026 and June 30, 2025, the restructuring liability was less than $0.1 million and $0.7 million, respectively, related to these restructuring plans.

[0001193125-26-197200:notes:178]
[same as prior period, unchanged from 0001193125-26-029334:notes:182]

[0001193125-26-197200:notes:179]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Balance at beginning of period |  |  | $ | 3,398 |  |  | $ | 693 |  |  | $ | 11,469 |  |
| Period charges |  |  |  | 557 |  |  |  | 437 |  |  |  | 3,264 |  |
| Period reversals |  |  |  | (996 | ) |  |  | (180 | ) |  |  | (1,389 | ) |
| Period payments |  |  |  | (903 | ) |  |  | (882 | ) |  |  | (11,288 | ) |
| Balance at end of period |  |  | $ | 2,056 |  |  | $ | 68 |  |  | $ | 2,056 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-26-197200:notes:180]
[same as prior period, unchanged from 0001193125-26-029334:notes:184]

[0001193125-26-197200:notes:181]
For the three months ended March 31, 2026 and 2025, the Company recorded an income tax provision of $4.2 million and $3.7 million, respectively. For the nine months ended March 31, 2026 and 2025, the Company recorded an income tax provision of $9.5 million and $7.8 million, respectively.

[0001193125-26-197200:notes:182]
The income tax provisions for the three and nine months ended March 31, 2026 and 2025, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three and nine months ended March 31, 2026 and 2025 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis. The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001193125-26-197200:notes:183]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, the Company considers all available positive and negative evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable including past operating results, estimates of future taxable income, changes to enacted tax laws, and the feasibility of tax planning strategies; such assessment is required on a jurisdiction-by-jurisdiction basis. The Company’s inconsistent earnings in recent periods, including historical losses, tax attributes expiring unutilized in recent years and the cyclical nature of the Company’s business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.

[0001193125-26-197200:notes:184]
These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company’s deferred tax assets. In the event the Company changes its determination as to the amount of deferred tax assets that can be realized, it will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001193125-26-197200:notes:185]
The Company had $18.2 million of unrecognized tax benefits as of March 31, 2026. If fully recognized in the future, $0.2 million would impact the effective tax rate and $18.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0001193125-26-197200:notes:186]
[same as prior period, unchanged from 0001193125-26-029334:notes:190]

[0001193125-26-197200:notes:187]
[same as prior period, unchanged from 0001193125-26-029334:notes:191]

[0001193125-26-197200:notes:188]
[same as prior period, unchanged from 0001193125-26-029334:notes:192]

[0001193125-26-197200:notes:189]
On July 4, 2025, federal legislation commonly referred to as the One Big Beautiful Bill Act (“OBBBA”) was enacted in the U.S. The OBBBA includes numerous changes to existing tax law including provisions providing current deductibility of domestic research and development costs, modifications to the limitation on deductibility of business interest expense and modifications to the international tax framework. This legislation has multiple effective dates, with certain provisions effective for the Company's fiscal year ended June 30, 2026 and others for the Company’s fiscal year ended June 30, 2027. ASC 740, Income Taxes, requires the effects of changes in tax rates and laws to be recognized in the period in which the legislation is enacted. The effects of the new legislation are reflected in the condensed consolidated financial statements for the period ended March 31, 2026.


## us-gaap:EarningsPerShareTextBlock

[0001193125-26-197200:notes:190]
15.
Net Income Per Share

[0001193125-26-197200:notes:191]
Basic net income per share is calculated by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is calculated by dividing net income by the weighted-average number of shares of common stock used in the basic net income per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0001193125-26-197200:notes:192]
The following table presents the calculation of net income per share of basic and diluted (in thousands, except per share data):

[0001193125-26-197200:notes:193]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Net income |  | $ | 10,590 |  |  | $ | 3,458 |  |  | $ | 24,077 |  |  | $ | 336 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 132,931 |  |  |  | 132,979 |  |  |  | 133,275 |  |  |  | 132,173 |  |
| Options to purchase common stock |  |  | 152 |  |  |  | 452 |  |  |  | 233 |  |  |  | 528 |  |
| Restricted stock units |  |  | 468 |  |  |  | 1,155 |  |  |  | 1,342 |  |  |  | 1,069 |  |
| Employee Stock Purchase Plan shares |  |  | 40 |  |  |  | 4 |  |  |  | 67 |  |  |  | — |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 133,591 |  |  |  | 134,590 |  |  |  | 134,917 |  |  |  | 133,770 |  |
| Net income per share – basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.18 |  |  | $ | 0.00 |  |
| Net income per share – diluted |  | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.18 |  |  | $ | 0.00 |  |

[0001193125-26-197200:notes:194]
The following securities were excluded from the computation of net income per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001193125-26-197200:notes:195]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| Restricted stock units |  |  | 3,280 |  |  |  | 1,349 |  |  |  | 519 |  |  |  | 1,258 |  |
| Employee Stock Purchase Plan shares |  |  | 276 |  |  |  | 345 |  |  |  | 80 |  |  |  | 114 |  |
| Total shares excluded |  |  | 3,556 |  |  |  | 1,694 |  |  |  | 599 |  |  |  | 1,372 |  |
