# EXTR MD&A — 0001564590-21-021969


## mdna

[0001564590-21-021969:mdna:1]
[same as prior period, unchanged from 0001564590-21-005006:mdna:1]

[0001564590-21-021969:mdna:2]
[same as prior period, unchanged from 0001564590-21-005006:mdna:2]

[0001564590-21-021969:mdna:3]
[same as prior period, unchanged from 0001564590-21-005006:mdna:3]

[0001564590-21-021969:mdna:4]
[same as prior period, unchanged from 0001564590-21-005006:mdna:4]

[0001564590-21-021969:mdna:5]
[same as prior period, unchanged from 0001564590-21-005006:mdna:5]

[0001564590-21-021969:mdna:6]
[same as prior period, unchanged from 0001564590-21-005006:mdna:6]

[0001564590-21-021969:mdna:7]
[same as prior period, unchanged from 0001564590-21-005006:mdna:7]

[0001564590-21-021969:mdna:8]
[same as prior period, unchanged from 0001564590-21-005006:mdna:8]

[0001564590-21-021969:mdna:9]
|  | o | Cloud Choice for customers: solution available on all major cloud providers (Amazon Web Services (“AWS”), Google Cloud Platform (“GCP”) and Microsoft Azure). |

[0001564590-21-021969:mdna:10]
[same as prior period, unchanged from 0001564590-21-005006:mdna:10]

[0001564590-21-021969:mdna:11]
[same as prior period, unchanged from 0001564590-21-005006:mdna:11]

[0001564590-21-021969:mdna:12]
|  | o | “No 9s” Reliability and Resiliency to ensure business continuity for our customers. |

[0001564590-21-021969:mdna:13]
|  | o | Zero-Trust Security (ISO 27001 Information Security Management Certified). |

[0001564590-21-021969:mdna:14]
[same as prior period, unchanged from 0001564590-21-005006:mdna:14]

[0001564590-21-021969:mdna:15]
|  | • | End-to-End Portfolio. Our cloud-driven solutions provide visibility, control and strategic intelligence from the edge to the data center, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points, Wireless Local Area Network (“WLAN”) controllers, routers, and an extensive portfolio of software applications that deliver AI-enhanced access control, network and application analytics, as well as network management. All can be managed, assessed and controlled from a single pane of glass on premises or from the cloud. |

[0001564590-21-021969:mdna:16]
|  | • | Offer customers choice: cloud or on-premises. We leverage the cloud where it makes sense for our customers and provide on-premises solutions where customers need it and also have a solution for those that want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what is going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for bring your own device (“BYOD”) and IoT usage. |

[0001564590-21-021969:mdna:17]
[same as prior period, unchanged from 0001564590-21-005006:mdna:17]

[0001564590-21-021969:mdna:18]
[same as prior period, unchanged from 0001564590-21-005006:mdna:18]

[0001564590-21-021969:mdna:19]
[same as prior period, unchanged from 0001564590-21-005006:mdna:19]

[0001564590-21-021969:mdna:20]
[same as prior period, unchanged from 0001564590-21-005006:mdna:20]

[0001564590-21-021969:mdna:21]
|  | • | Expand market penetration by targeting high-growth market segments. Within the campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our data center approach leverages our product portfolio to address the needs of public and private cloud data center providers. We believe that the cloud networking compound annual growth rate will continue to outpace the compound annual growth rate for on-premises managed networking. Our focus is on expanding our technology foothold in the critical cloud networking segment to accelerate not only cloud management adoption, but also subscription-based licensing (SaaS) consumption. |

[0001564590-21-021969:mdna:22]
[same as prior period, unchanged from 0001564590-21-005006:mdna:22]

[0001564590-21-021969:mdna:23]
[same as prior period, unchanged from 0001564590-21-005006:mdna:23]

[0001564590-21-021969:mdna:24]
[same as prior period, unchanged from 0001564590-21-005006:mdna:24]

[0001564590-21-021969:mdna:25]
During the third quarter of fiscal 2021, we achieved the following results:

[0001564590-21-021969:mdna:26]
|  | • | Net revenues of $253.4 million compared to $209.5 million in the third quarter of fiscal 2020. |

[0001564590-21-021969:mdna:27]
28

[0001564590-21-021969:mdna:28]
|  | • | Product revenues of $176.3 million compared to $136.5 million in the third quarter of fiscal 2020. |

[0001564590-21-021969:mdna:29]
|  | • | Service and subscription revenues of $77.1 million compared to $73.0 million in the third quarter of fiscal 2020. |

[0001564590-21-021969:mdna:30]
|  | • | Total gross margin of 58.7% of net revenues compared to 53.1% of net revenues in the third quarter of fiscal 2020. |

[0001564590-21-021969:mdna:31]
|  | • | Operating income of $11.2 million compared to operating loss of $38.4 million in the third quarter of fiscal 2020. |

[0001564590-21-021969:mdna:32]
|  | • | Net income of $3.5 million compared to net loss of $44.4 million in the third quarter of fiscal 2020. |

[0001564590-21-021969:mdna:33]
During the first nine months of fiscal 2021, we reflected the following results:

[0001564590-21-021969:mdna:34]
|  | • | Cash flows provided by operating activities of $87.5 million compared to $27.1 million in the nine months ended March 31, 2020. |

[0001564590-21-021969:mdna:35]
|  | • | Cash of $203.1 million as of March 31, 2021 compared to $193.9 million as of June 30, 2020. |

[0001564590-21-021969:mdna:36]
[same as prior period, unchanged from 0001564590-21-005006:mdna:36]

[0001564590-21-021969:mdna:37]
A novel strain of coronavirus emerged in December 2019. This coronavirus, now known as COVID-19, spread around the world and resulted in authorities implementing numerous measures to try to contain the virus, such as travel bans and restrictions, quarantines, shelter-in-place orders and shutdowns and was declared a pandemic in March 2020. COVID-19 has had and we expect will continue to have an adverse effect on our results of operations due to supply chain disruptions and reduced demand for our products. Because of this, we realigned our operations and recorded severance and benefits charges of $5.8 million during the third quarter of our fiscal 2020. Although we expect to have reduced research and development and sales and marketing costs for the year ended June 30, 2021 compared to the year ended June 30, 2020, given the uncertainty around the extent and timing of the potential future spread or mitigation of COVID-19 and around the imposition or relaxation of protective measures, we cannot further reasonably estimate the impact of the COVID-19 pandemic on our future results of operations or financial position. See also Part II, Item 1A – Risk Factors.

[0001564590-21-021969:mdna:38]
[same as prior period, unchanged from 0001564590-21-005006:mdna:38]

[0001564590-21-021969:mdna:39]
[same as prior period, unchanged from 0001564590-21-005006:mdna:39]

[0001564590-21-021969:mdna:40]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | $ Change |  |  | % Change |  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | $ Change |  |  | % Change |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 176,334 |  |  | $ | 136,547 |  |  | $ | 39,787 |  |  |  | 29.1 | % |  | $ | 503,575 |  |  | $ | 512,173 |  |  | $ | (8,598 | ) |  |  | (1.7 | )% |  |
| Percentage of net revenues |  |  | 69.6 | % |  |  | 65.2 | % |  |  |  |  |  |  |  |  |  |  | 68.9 | % |  |  | 69.9 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 77,066 |  |  |  | 72,972 |  |  |  | 4,094 |  |  |  | 5.6 | % |  |  | 227,755 |  |  |  | 220,324 |  |  |  | 7,431 |  |  |  | 3.4 | % |  |
| Percentage of net revenues |  |  | 30.4 | % |  |  | 34.8 | % |  |  |  |  |  |  |  |  |  |  | 31.1 | % |  |  | 30.1 | % |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 253,400 |  |  | $ | 209,519 |  |  | $ | 43,881 |  |  |  | 20.9 | % |  | $ | 731,330 |  |  | $ | 732,497 |  |  | $ | (1,167 | ) |  |  | (0.2 | )% |  |

[0001564590-21-021969:mdna:41]
Product revenues increased $39.8 million or 29.1% for the three months ended March 31, 2021, as compared to the corresponding period of fiscal 2020. Product revenues decreased $8.6 million or 1.7% for the nine months ended March 31, 2021, as compared to the corresponding period of fiscal 2020. The product revenues increase for the three months ended March 31, 2021 was primarily due to the material slow-down in global demand during the corresponding period of fiscal 2020 due to the global outbreak of COVID-19. The product revenues decline for the nine months ended March 31, 2021 as compared to the corresponding period of fiscal 2020 was due to the impact of COVID-19 on global demand across all geographies primarily during the first two quarters of fiscal 2021.

[0001564590-21-021969:mdna:42]
Service and subscription revenues increased $4.1 million, or 5.6% for the three months ended March 31, 2021 as compared to the corresponding period in fiscal 2020. Service and subscription revenues increased $7.4 million, or 3.4% for the nine months ended March 31, 2021 as compared to the corresponding period in fiscal 2020.  The increase in service and subscription revenues for the three and nine months ended March 31, 2021 as compared to the corresponding periods of fiscal 2020 was primarily due to the growth in subscription revenues.

[0001564590-21-021969:mdna:43]
[same as prior period, unchanged from 0001564590-21-005006:mdna:43]

[0001564590-21-021969:mdna:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | $ Change |  |  | % Change |  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 99,892 |  |  | $ | 64,620 |  |  | $ | 35,272 |  |  |  | 54.6 | % |  | $ | 279,733 |  |  | $ | 257,468 |  |  | $ | 22,265 |  |  |  | 8.6 | % |  |
| Percentage of product revenues |  |  | 56.6 | % |  |  | 47.3 | % |  |  |  |  |  |  |  |  |  |  | 55.5 | % |  |  | 50.3 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 48,921 |  |  |  | 46,715 |  |  |  | 2,206 |  |  |  | 4.7 | % |  |  | 144,290 |  |  |  | 139,781 |  |  |  | 4,509 |  |  |  | 3.2 | % |  |
| Percentage of service and subscription revenues |  |  | 63.5 | % |  |  | 64.0 | % |  |  |  |  |  |  |  |  |  |  | 63.4 | % |  |  | 63.4 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 148,813 |  |  | $ | 111,335 |  |  | $ | 37,478 |  |  |  | 33.7 | % |  | $ | 424,023 |  |  | $ | 397,249 |  |  | $ | 26,774 |  |  |  | 6.7 | % |  |
| Percentage of net revenues |  |  | 58.7 | % |  |  | 53.1 | % |  |  |  |  |  |  |  |  |  |  | 58.0 | % |  |  | 54.2 | % |  |  |  |  |  |  |  |  |  |

[0001564590-21-021969:mdna:45]
Product gross profit increased $35.3 million or 54.6% for the three months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The increase in product gross profit was primarily due to increased revenues along with lower distribution charges of $4.9 million, which were mainly due to decreased tariffs, lower excess and obsolete inventory charges of $3.9 million, and lower warranty costs of $1.8 million.

[0001564590-21-021969:mdna:46]
Product gross profit increased $22.3 million or 8.6% for the nine months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The increase in product gross profit was primarily due to increased revenues along with lower excess and obsolete inventory charges of $8.4 million, lower expensing of the fair value step-up of inventories acquired from Aerohive of $7.3 million, lower warranty costs of $7.2 million, lower distribution charges of $5.3 million, which were mainly due to decreased tariffs, and more favorable manufacturing costs due to product cost reduction efforts.

[0001564590-21-021969:mdna:47]
Service and subscription gross profit increased $2.2 million or 4.7% for the three months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The increase was primarily due to increased service and subscription revenues, partially offset by higher personnel costs and increased cloud service costs.

[0001564590-21-021969:mdna:48]
Service and subscription gross profit increased $4.5 million or 3.2% for nine months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The increase was primarily due to higher service and subscription revenues and reduced repair costs, partially offset by higher personnel costs and increased cloud service costs.

[0001564590-21-021969:mdna:49]
[same as prior period, unchanged from 0001564590-21-005006:mdna:49]

[0001564590-21-021969:mdna:50]
[same as prior period, unchanged from 0001564590-21-005006:mdna:50]

[0001564590-21-021969:mdna:51]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | $ Change |  |  | % Change |  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | $ Change |  |  | % Change |  |  |
| Research and development |  | $ | 48,909 |  |  | $ | 50,577 |  |  | $ | (1,668 | ) |  |  | (3.3 | )% |  | $ | 147,619 |  |  | $ | 165,073 |  |  | $ | (17,454 | ) |  |  | (10.6 | )% |  |
| Sales and marketing |  |  | 70,898 |  |  |  | 70,132 |  |  |  | 766 |  |  |  | 1.1 | % |  |  | 201,955 |  |  |  | 216,925 |  |  |  | (14,970 | ) |  |  | (6.9 | )% |  |
| General and administrative |  |  | 16,023 |  |  |  | 15,119 |  |  |  | 904 |  |  |  | 6.0 | % |  |  | 48,844 |  |  |  | 45,199 |  |  |  | 3,645 |  |  |  | 8.1 | % |  |
| Acquisition and integration costs |  |  | — |  |  |  | 5,156 |  |  |  | (5,156 | ) |  |  | (100.0 | )% |  |  | 1,975 |  |  |  | 30,075 |  |  |  | (28,100 | ) |  |  | (93.4 | )% |  |
| Restructuring and related charges, net of reversals |  |  | 425 |  |  |  | 6,648 |  |  |  | (6,223 | ) |  |  | (93.6 | )% |  |  | 2,121 |  |  |  | 19,407 |  |  |  | (17,286 | ) |  |  | (89.1 | )% |  |
| Amortization of intangibles |  |  | 1,406 |  |  |  | 2,059 |  |  |  | (653 | ) |  |  | (31.7 | )% |  |  | 4,704 |  |  |  | 6,366 |  |  |  | (1,662 | ) |  |  | (26.1 | )% |  |
| Total operating expenses |  | $ | 137,661 |  |  | $ | 149,691 |  |  | $ | (12,030 | ) |  |  | (8.0 | )% |  | $ | 407,218 |  |  | $ | 483,045 |  |  | $ | (75,827 | ) |  |  | (15.7 | )% |  |

[0001564590-21-021969:mdna:52]
[same as prior period, unchanged from 0001564590-21-005006:mdna:52]

[0001564590-21-021969:mdna:53]
[same as prior period, unchanged from 0001564590-21-005006:mdna:53]

[0001564590-21-021969:mdna:54]
Research and development expenses decreased by $1.7 million or 3.3% for the three months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The decrease in research and development expenses was due to a $2.9 million decrease in personnel costs primarily due to lower headcount as a result of the cost reduction actions taken in fiscal 2020, a $1.3 million decrease in facility and information technology costs, a $0.7 million decrease in software licenses and engineering project costs and a $0.7 million decrease in travel and other expenses, partially offset by a $3.9 million increase in professional and contractor fees.

[0001564590-21-021969:mdna:55]
Research and development expenses decreased by $17.5 million or 10.6% for the nine months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The decrease in research and development expenses was due to a $19.0 million decrease in personnel costs primarily due to lower headcount as a result of the cost reduction actions taken in fiscal 2020, a $4.2 million decrease in facility and information technology costs, a $3.3 million decrease in software licenses and engineering project costs and a $1.6 million decrease in travel and other expenses, partially offset by a $10.6 million increase in professional and contractor fees.

[0001564590-21-021969:mdna:56]
[same as prior period, unchanged from 0001564590-21-005006:mdna:56]

[0001564590-21-021969:mdna:57]
[same as prior period, unchanged from 0001564590-21-005006:mdna:57]

[0001564590-21-021969:mdna:58]
Sales and marketing expenses increased by $0.8 million or 1.1% for the three months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The increase in sales and marketing expenses was primarily due to a $5.4 million increase in personnel costs primarily commission and benefits and a $0.8 million increase in other expenses primarily marketing and sales promotions costs, partially offset by a $2.7 million decrease in travel costs due to COVID-19, a $1.5 million decrease in professional and recruiting fees and a $1.2 million decrease in software and equipment related costs.

[0001564590-21-021969:mdna:59]
Sales and marketing expenses decreased by $15.0 million or 6.9% for the nine months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The decrease in sales and marketing expenses was primarily due to a $9.3 million decrease in travel costs due to COVID-19, a $4.0 million decrease in professional and recruiting fees, a $2.3 million decrease in software and equipment related costs and a $0.7 million decrease in other expenses primarily sales promotions costs, partially offset by a $1.3 million increase in personnel costs.

[0001564590-21-021969:mdna:60]
[same as prior period, unchanged from 0001564590-21-005006:mdna:60]

[0001564590-21-021969:mdna:61]
[same as prior period, unchanged from 0001564590-21-005006:mdna:61]

[0001564590-21-021969:mdna:62]
General and administrative expenses increased by $0.9 million or 6.0% for the three months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The increase in general and administrative expenses was primarily due to a $2.1 million increase in personnel costs primarily compensation expenses and a $0.4 million increase in legal and professional fees, partially offset by a $0.7 million decrease in software and equipment related costs and a $0.9 million decrease in travel and other expenses.

[0001564590-21-021969:mdna:63]
General and administrative expenses increased by $3.6 million or 8.1% for the nine months ended March 31, 2021, as compared to the corresponding period in fiscal 2020. The increase in general and administrative expenses was primarily due to a $5.1 million increase in personnel costs primarily compensation expenses and a $2.0 million increase in facility and information technology costs, partially offset by a $1.7 million decrease in software and equipment related costs and a $1.8 million decrease in travel and other expenses.

[0001564590-21-021969:mdna:64]
[same as prior period, unchanged from 0001564590-21-005006:mdna:64]

[0001564590-21-021969:mdna:65]
During the three months ended March 31, 2021, we did not incur any acquisition and integration costs.  During the nine months ended March 31, 2021, we incurred $2.0 million of integration costs which consisted primarily of additional professional fees for system integration and financial services related to the Aerohive acquisition which are now complete.

[0001564590-21-021969:mdna:66]
During the three and nine months ended March 31, 2020, we incurred $5.2 million and $30.1 million, respectively of acquisition and integration costs which consisted primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees. The acquisition and integration costs for the nine months ended March 31, 2020 also included a $6.8 million compensation charge for certain Aerohive Executives’ stock awards that were accelerated due to change-in-control and termination provisions included in the executives’ employment contracts.

[0001564590-21-021969:mdna:67]
[same as prior period, unchanged from 0001564590-21-005006:mdna:67]

[0001564590-21-021969:mdna:68]
For the three and nine months ended March 31, 2021, we recorded restructuring charges of $0.4 million and $2.1 million, respectively.  We continued our cost reduction initiative began in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of less than $0.1 million and $1.2 million, respectively, related to the 2020 Plan.  In addition, we had facility-related charges of $0.3 million and $0.9 million, respectively, related to our previously impaired facilities.

[0001564590-21-021969:mdna:69]
For the three months ended March 31, 2020 we recorded restructuring charges of $6.6 million.  In connection with our plan of action to reduce operating costs due to the COVID-19 global pandemic, we realigned our operations and recorded severance and benefits charges of $5.8 million for the third fiscal quarter of 2020.  We also continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and recorded related severance and benefits charges of $0.5 million for the third fiscal quarter of 2020.  In addition, we also had facility restructuring charges of $0.3 million for the third fiscal quarter of 2020. For the nine months ended March 31, 2020 we recorded restructuring charges of $19.4 million. The charges consisted primarily of excess facility charges of $8.2 million for impairment of right-of-use assets related to our Milpitas, California, South San Jose, California, and Salem, New Hampshire facilities.  Additionally, we initiated reduction-in-force procedures during the nine months ended March 31, 2020 and recorded severance and benefits charges of $11.2 million.

[0001564590-21-021969:mdna:70]
[same as prior period, unchanged from 0001564590-21-005006:mdna:70]

[0001564590-21-021969:mdna:71]
During the three months ended March 31, 2021 and 2020, we recorded $1.4 million and $2.1 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The decrease was primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-21-021969:mdna:72]
During the nine months ended March 31, 2021 and 2020, we recorded $4.7 million and $6.4 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The decrease was primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized, partially offset by an increase from full period amortization of acquired intangibles from the Aerohive acquisition.

[0001564590-21-021969:mdna:73]
[same as prior period, unchanged from 0001564590-21-005006:mdna:73]

[0001564590-21-021969:mdna:74]
During the three months ended March 31, 2021 and 2020, we recorded $5.6 million and $6.0 million, respectively, in interest expense.  The decreases in interest expense were primarily driven by lower average loan balances and lower average rates for the three months ended March 31, 2021 under our 2019 Credit Agreement.

[0001564590-21-021969:mdna:75]
During the nine months ended March 31, 2021 and 2020, we recorded $18.3 million and $17.4 million, respectively, in interest expense. The increases in interest expense were primarily driven by higher average loan balances partially offset by lower average rates for the nine months ended March 31, 2021 under our 2019 Credit Agreement.

[0001564590-21-021969:mdna:76]
Other Income (Expense), Net

[0001564590-21-021969:mdna:77]
During the three months ended March 31, 2021 and 2020, we recorded other income, net of $0.3 million and other income, net of $1.3 million, respectively. During the nine months ended March 31, 2021 and 2020, we recorded other expense, net of $1.6 million and other income, net of $1.1 million, respectively. The changes for the three and nine months ended March 31, 2021 was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-21-021969:mdna:78]
[same as prior period, unchanged from 0001564590-21-005006:mdna:78]

[0001564590-21-021969:mdna:79]
For the three months ended March 31, 2021 and 2020, we recorded an income tax provision of $2.4 million and $1.6 million, respectively.  For the nine months ended March 31, 2021 and 2020, we recorded an income tax provision of $5.6 million and $4.9 million, respectively.

[0001564590-21-021969:mdna:80]
The income tax provisions for the three and nine months ended March 31, 2021 and 2020 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where we have no remaining state net operating losses and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0001564590-21-021969:mdna:81]
[same as prior period, unchanged from 0001564590-21-005006:mdna:81]

[0001564590-21-021969:mdna:82]
[same as prior period, unchanged from 0001564590-21-005006:mdna:82]

[0001564590-21-021969:mdna:83]
[same as prior period, unchanged from 0001564590-21-005006:mdna:83]

[0001564590-21-021969:mdna:84]
[same as prior period, unchanged from 0001564590-21-005006:mdna:84]

[0001564590-21-021969:mdna:85]
[same as prior period, unchanged from 0001564590-21-005006:mdna:85]

[0001564590-21-021969:mdna:86]
[same as prior period, unchanged from 0001564590-21-005006:mdna:86]

[0001564590-21-021969:mdna:87]
[same as prior period, unchanged from 0001564590-21-005006:mdna:87]

[0001564590-21-021969:mdna:88]
[same as prior period, unchanged from 0001564590-21-005006:mdna:88]

[0001564590-21-021969:mdna:89]
[same as prior period, unchanged from 0001564590-21-005006:mdna:89]

[0001564590-21-021969:mdna:90]
[same as prior period, unchanged from 0001564590-21-005006:mdna:90]

[0001564590-21-021969:mdna:91]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Cash |  | $ | 203,139 |  |  | $ | 193,872 |  |

[0001564590-21-021969:mdna:92]
As of March 31, 2021, our principal sources of liquidity consisted of cash of $203.1 million and accounts receivable, net of $130.6 million, and available borrowings under our five-year 2019 Revolving Facility of $55.0 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $203.1 million of cash at March 31, 2021, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-21-021969:mdna:93]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in fiscal 2019 and $30.0 million was used for repurchases in fiscal 2020. In February 2020 the Board increased the authorization  to repurchase by $40.0 million to $100.0 million and extended the period for repurchases for three years from February 5, 2020.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. There were no repurchases in the three and nine months ended March 31, 2021.

[0001564590-21-021969:mdna:94]
[same as prior period, unchanged from 0001564590-21-005006:mdna:94]

[0001564590-21-021969:mdna:95]
[same as prior period, unchanged from 0001564590-21-005006:mdna:95]

[0001564590-21-021969:mdna:96]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-21-021969:mdna:97]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-21-021969:mdna:98]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the Second Amendment which supersedes the First Amendment and provides certain revised terms and financial covenants effective through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we are not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and we are restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the Fourth amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-21-021969:mdna:99]
The Second Amendment provides for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance.  For the 12 month period ended March 31, 2021 our financial performance is in compliance with the original covenants defined in the 2019 Credit Agreement and as such we will file a Suspension Early Termination Notice and Covenant Certificate with the loan administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021.  Returning to compliance will result in our Eurodollar loan spread to decrease from 4.5% suspension period rate, to 2.75% and unused facility commitment fee will decrease from 0.4% to 0.35%, and the limitation on revolver borrowings will be removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-21-021969:mdna:100]
[same as prior period, unchanged from 0001564590-21-005006:mdna:99]

[0001564590-21-021969:mdna:101]
[same as prior period, unchanged from 0001564590-21-005006:mdna:100]

[0001564590-21-021969:mdna:102]
[same as prior period, unchanged from 0001564590-21-005006:mdna:101]

[0001564590-21-021969:mdna:103]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Net cash provided by operating activities |  | $ | 87,496 |  |  | $ | 27,061 |  |
| Net cash used in investing activities |  |  | (12,318 | ) |  |  | (186,839 | ) |
| Net cash (used in) provided by financing activities |  |  | (66,381 | ) |  |  | 187,262 |  |
| Foreign currency effect on cash |  |  | 470 |  |  |  | (741 | ) |
| Net increase in cash |  | $ | 9,267 |  |  | $ | 26,743 |  |

[0001564590-21-021969:mdna:104]
[same as prior period, unchanged from 0001564590-21-005006:mdna:103]

[0001564590-21-021969:mdna:105]
Cash flows provided by operations in the nine months ended March 31, 2021, were $87.5 million, including our net loss of $8.4 million and non-cash expenses of $89.0 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and imputed interest.  Other sources of cash for the period included a decrease in inventory and increases in accounts payable, accrued compensation, and deferred revenues. This was partially offset by decreases in other current and long-term liabilities, and operating lease liabilities and increases in accounts receivables and prepaid expenses and other current assets.

[0001564590-21-021969:mdna:106]
Cash flows provided by operations in the nine months ended March 31, 2020, were $27.1 million, including our net loss of $105.6 million and non-cash expenses of $100.4 million for items such as amortization of intangibles, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, restructuring charges, deferred income taxes, and imputed interest.  Other sources of cash for the period included a decrease in accounts receivables, inventory, and prepaid expenses and other current assets. This was partially offset by decreases in accounts payable, accrued compensation, other current and long-term liabilities, and operating lease liabilities.

[0001564590-21-021969:mdna:107]
[same as prior period, unchanged from 0001564590-21-005006:mdna:106]

[0001564590-21-021969:mdna:108]
Cash flows used in investing activities in the nine months ended March 31, 2021 were $12.3 million for the purchases of property and equipment.

[0001564590-21-021969:mdna:109]
Cash flows used in investing activities in the nine months ended March 31, 2020 were $186.8 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $12.6 million, which was partially offset by proceeds of $45.2 million related to the maturity and sales of short-term investments.

[0001564590-21-021969:mdna:110]
[same as prior period, unchanged from 0001564590-21-005006:mdna:109]

[0001564590-21-021969:mdna:111]
Cash flows used in financing activities in the nine months ended March 31, 2021 were $66.4 million due primarily to debt repayments of $69.3 million, payment of contingent consideration of $1.3 million, and $3.0 million for deferred payments on acquisitions. This was partially offset by $7.2 million of proceeds from the issuance of shares of our common stock under our ESPP, exercise of stock options, net of taxes paid on vested, and released stock awards.

[0001564590-21-021969:mdna:112]
Cash flows provided by financing activities in the nine months ended March 31, 2020 were $187.3 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $55.0 million of borrowings under our 2019 Revolving Facility, $9.5 million of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, net of taxes paid on vested and released stock awards. This was partially offset by debt repayments of $29.8 million, payment of loan fees of $10.5 million, contingent consideration of $3.4 million, and $3.0 million for deferred payments on acquisitions. Cash flows provided by financing activities also included repurchasing of our common shares of $30.0 million during the nine months ended March 31, 2020, in accordance with our approved share repurchase plan.

[0001564590-21-021969:mdna:113]
[same as prior period, unchanged from 0001564590-21-005006:mdna:112]

[0001564590-21-021969:mdna:114]
Foreign currency effect on cash increased in the nine months ended March 31, 2021 and 2020, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-21-021969:mdna:115]
[same as prior period, unchanged from 0001564590-21-005006:mdna:114]

[0001564590-21-021969:mdna:116]
The following summarizes our contractual obligations as of March 31, 2021, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-21-021969:mdna:117]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 351,500 |  |  | $ | 23,750 |  |  | $ | 71,250 |  |  | $ | 256,500 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 49,514 |  |  |  | 16,443 |  |  |  | 28,680 |  |  |  | 4,391 |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 32,988 |  |  |  | 32,988 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 80,292 |  |  |  | 20,367 |  |  |  | 31,921 |  |  |  | 17,233 |  |  |  | 10,771 |  |
| Lease payments on operating leases |  |  | 61,641 |  |  |  | 21,211 |  |  |  | 26,433 |  |  |  | 8,995 |  |  |  | 5,002 |  |
| Deferred payments for an acquisition |  |  | 8,000 |  |  |  | 4,000 |  |  |  | 4,000 |  |  |  | — |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 902 |  |  |  | 759 |  |  |  | 143 |  |  |  | — |  |  |  | — |  |
| Other liabilities |  |  | 890 |  |  |  | 265 |  |  |  | 529 |  |  |  | 96 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 585,727 |  |  | $ | 119,783 |  |  | $ | 162,956 |  |  | $ | 287,215 |  |  | $ | 15,773 |  |

[0001564590-21-021969:mdna:118]
[same as prior period, unchanged from 0001564590-21-005006:mdna:117]

[0001564590-21-021969:mdna:119]
[same as prior period, unchanged from 0001564590-21-005006:mdna:118]

[0001564590-21-021969:mdna:120]
[same as prior period, unchanged from 0001564590-21-005006:mdna:119]

[0001564590-21-021969:mdna:121]
[same as prior period, unchanged from 0001564590-21-005006:mdna:120]

[0001564590-21-021969:mdna:122]
[same as prior period, unchanged from 0001564590-21-005006:mdna:121]

[0001564590-21-021969:mdna:123]
[same as prior period, unchanged from 0001564590-21-005006:mdna:122]

[0001564590-21-021969:mdna:124]
[same as prior period, unchanged from 0001564590-21-005006:mdna:123]

[0001564590-21-021969:mdna:125]
[same as prior period, unchanged from 0001564590-21-005006:mdna:124]

[0001564590-21-021969:mdna:126]
[same as prior period, unchanged from 0001564590-21-005006:mdna:125]

[0001564590-21-021969:mdna:127]
We did not have any material commitments for capital expenditures as of March 31, 2021.

[0001564590-21-021969:mdna:128]
[same as prior period, unchanged from 0001564590-21-005006:mdna:127]

[0001564590-21-021969:mdna:129]
We did not have any off-balance sheet arrangements as of March 31, 2021.
