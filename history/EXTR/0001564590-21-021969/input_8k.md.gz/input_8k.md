# EXTR 8-K — 0001564590-21-021102 filed 2021-04-28

## item codes, every 8-K on or before 2021-04-29

- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2021-04-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-021102:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-21-021102:8k_2_02:2]
extr-ex991_6.htm

[0001564590-21-021102:8k_2_02:3]
Exhibit 99.1

[0001564590-21-021102:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-21-021102:8k_2_02:5]
Extreme Networks Reports Third Quarter Fiscal Year 2021 Financial Results

[0001564590-21-021102:8k_2_02:6]
Achieved 21% Year-Over-Year Revenue Growth and Double-Digit Non-GAAP Operating Margin

[0001564590-21-021102:8k_2_02:7]
SAN JOSE, Calif., April 28, 2021 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its third fiscal quarter ended March 31, 2021.

[0001564590-21-021102:8k_2_02:8]
Fiscal Third Quarter Results:

[0001564590-21-021102:8k_2_02:9]
|  | • | Revenue $253.4 million, up 21% year-over-year and up 5% quarter-over-quarter |

[0001564590-21-021102:8k_2_02:10]
|  | • | GAAP EPS $0.03, up from ($0.37) in Q3 last year |

[0001564590-21-021102:8k_2_02:11]
|  | • | Non-GAAP EPS $0.16, up from ($0.09) in Q3 last year |

[0001564590-21-021102:8k_2_02:12]
|  | • | GAAP gross margin 58.7% compared to 53.1% in Q3 last year |

[0001564590-21-021102:8k_2_02:13]
|  | • | Non-GAAP gross margin 61.5% compared to 56.7% in Q3 last year |

[0001564590-21-021102:8k_2_02:14]
|  | • | GAAP operating margin 4.4% compared to (18.3)% in Q3 last year |

[0001564590-21-021102:8k_2_02:15]
|  | • | Non-GAAP operating margin 11.3%, compared to (5.1)% in Q3 last year |

[0001564590-21-021102:8k_2_02:16]
|  | • | Net cash provided by operating activities of $24.7 million |

[0001564590-21-021102:8k_2_02:17]
|  | • | Free Cash Flow of $20.4 million |

[0001564590-21-021102:8k_2_02:18]
“Our Q3 results represent the fourth consecutive quarter of sequential revenue growth and double-digit growth year-over-year across all our geographies. Extreme is coming out of COVID in a stronger position than ever before and enterprise customers are turning to Extreme’s industry-leading cloud solutions to meet the new demands of the distributed enterprise. This is highlighted by ExtremeCloud IQ new subscription growth of 122% year-over-year, which in turn fueled product revenue growth of 29% year-over-year,” stated Ed Meyercord, President and CEO of Extreme.

[0001564590-21-021102:8k_2_02:19]
“Looking ahead at Q4, we continue to expect double-digit year-over-year revenue growth as demand for our differentiated cloud-driven networking solutions continues to build. The pace of our cloud innovation for enterprise solutions is accelerating and also underpins the success of our new cloud-native infrastructure solutions in the 5G space,” concluded Meyercord.

[0001564590-21-021102:8k_2_02:20]
“The operating leverage of our model enabled us to achieve a second consecutive quarter of non-GAAP double-digit operating margins. The combination of our strong operating performance and the reduction in inventory resulted in strong cash flow generation. Today, we are fully compliant with our bank covenants ahead of expectations and will realize meaningful interest expense savings beginning in Q4,” stated Rémi Thomas, CFO of Extreme.

[0001564590-21-021102:8k_2_02:21]
Recent Key Highlights:

[0001564590-21-021102:8k_2_02:22]
|  | • | Extreme was named the Official Wi-Fi Solutions Provider of Major League Baseball (MLB). Extreme will provide fan-facing Wi-Fi in 16 stadiums and connectivity in bullpens and dugouts in all 30 league ballparks. Installations are scheduled through 2026. As part of the partnership, Extreme will also power the network at MLB's Jackie Robinson Training Complex in Vero Beach, Florida. |

[0001564590-21-021102:8k_2_02:23]
|  | • | Through Extreme’s partnership with Verizon, Darlington Raceway will deploy Extreme’s wired, Wi-Fi, and analytics solutions, as well as its network management software, to provide reliable connectivity for the track which previously had no outdoor connection. Extreme installed high-density Wi-Fi 6 access points throughout the venue, enabling Darlington Raceway to enhance fan experiences and ensure all fans in the 60,000-seat venue can connect simultaneously during events. |

[0001564590-21-021102:8k_2_02:24]
|  | • | Belgium's Federal Public Service Justice refreshed its wired network infrastructure with Extreme, allowing it to offer high-speed connectivity across 240 buildings that is 20 times faster than the previous network. The new network supports the digitization of the justice system's services, including court hearings and other services to be offered remotely. |

[0001564590-21-021102:8k_2_02:25]
|  | • | Novant Health of North Carolina used Extreme's cloud-managed Wi-Fi solutions to power a COVID-19 mass vaccination event that saw over 2,220 vaccines administered in a single day. ExtremeWireless access points were activated in just one hour via ExtremeCloud IQ, enabling quick access to patient records and allowing clinic workers to simultaneously administer vaccines to 120 patients at a time. |

[0001564590-21-021102:8k_2_02:26]
|  | • | Lincoln University of Pennsylvania, a top 20 historically black college and university (HBCU) in 2021 according to U.S. News & World Report, and the nation's first degree-granting HBCU, deployed Extreme wireless access points and ExtremeCloud IQ network management solution to provide high-speed, Wi-Fi 6 connectivity throughout its 422-acre main campus and off-campus graduate center. The deployment has enabled students, faculty, and staff to easily connect with digital education resources from any device, anywhere – a need that became more pronounced with the COVID-19 pandemic and the additional requirement to offer a mix of in-person and remote instruction. |

[0001564590-21-021102:8k_2_02:27]
|  | • | Extreme will hold its annual Connect User Conference virtually on May 26-27, broadcasting over 30 unique sessions for customers, partners, and industry leaders worldwide. The online event is free to attend and will include keynote presentations from Extreme’s leadership team, IT strategy breakouts, and practical how-to workshops. Register for Connect at connect.extremenetworks.com. |

[0001564590-21-021102:8k_2_02:28]
Fiscal Q3 2021 Financial Metrics:

[0001564590-21-021102:8k_2_02:29]
(in millions, except percentages and per share information)

[0001564590-21-021102:8k_2_02:30]
|  |  | Q3 FY'21 |  |  | Q3 FY'20 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 176.3 |  |  | $ | 136.5 |  |  | $ | 39.8 |  |  |  | 29 | % |
| Service and subscription |  |  | 77.1 |  |  |  | 73.0 |  |  |  | 4.1 |  |  |  | 6 | % |
| Total net revenue |  | $ | 253.4 |  |  | $ | 209.5 |  |  | $ | 43.9 |  |  |  | 21 | % |
| Gross margin |  |  | 58.7 | % |  |  | 53.1 | % |  | 560 bps |  |  | - |  |
| Operating margin |  |  | 4.4 | % |  |  | (18.3 | )% |  | 2271 bps |  |  | - |  |
| Net income (loss) |  | $ | 3.5 |  |  | $ | (44.4 | ) |  | $ | 47.9 |  |  |  | 108 | % |
| Net income (loss) per diluted share |  | $ | 0.03 |  |  | $ | (0.37 | ) |  | $ | 0.40 |  |  |  | 108 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 176.3 |  |  | $ | 136.5 |  |  | $ | 39.8 |  |  |  | 29 | % |
| Service and subscription |  |  | 77.1 |  |  |  | 73.0 |  |  |  | 4.1 |  |  |  | 6 | % |
| Total net revenue |  | $ | 253.4 |  |  | $ | 209.5 |  |  | $ | 43.9 |  |  |  | 21 | % |
| Gross margin |  |  | 61.5 | % |  |  | 56.7 | % |  | 480 bps |  |  | - |  |
| Operating margin |  |  | 11.3 | % |  |  | (5.1 | )% |  | 1640 bps |  |  | - |  |
| Net income (loss) |  | $ | 20.7 |  |  | $ | (11.2 | ) |  | $ | 31.9 |  |  |  | 284 | % |
| Net income (loss) per diluted share |  | $ | 0.16 |  |  | $ | (0.09 | ) |  | $ | 0.25 |  |  |  | 278 | % |

[0001564590-21-021102:8k_2_02:31]
|  | • | Q3 ending cash balance was $203.1 million, an increase of $19.2 million from the end of Q2. This was primarily driven by operating cash flow generation of $24.7 million, partially offset by cash usage of $1.1 million for financing activities, along with $4.3 million for capital expenditures. |

[0001564590-21-021102:8k_2_02:32]
|  | • | Q3 accounts receivable balance was $130.6 million, with days sales outstanding of 46, a decrease of 3 days from Q2 and an increase of 4 days from Q3 last year. |

[0001564590-21-021102:8k_2_02:33]
|  | • | Q3 ending inventory was $43.9 million, a decrease of $5.9 million from Q2 and a decrease of $22.3 million from Q3 last year. The year-over-year and quarter-over-quarter decreases in inventory largely reflect improved demand planning, SKU rationalization and higher inventory turnover. |

[0001564590-21-021102:8k_2_02:34]
|  | • | Q3 ending gross debt* was $351.5 million, a decrease of $4.8 million from the prior quarter. The $74.0 million decrease from Q3 last year resulted primarily from principal payments and payments on our revolver loan. Net debt* of $148.4 million decreased by $23.9 million from $172.3 million in Q2. |

[0001564590-21-021102:8k_2_02:35]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-21-021102:8k_2_02:36]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Cash flow provided by operations | $ | 24,725 |  |  | $ | 5,150 |  |  | $ | 87,496 |  |  | $ | 27,061 |  |
| Less: Property and equipment capital expenditures |  | (4,279 | ) |  |  | (3,192 | ) |  |  | (12,318 | ) |  |  | (12,630 | ) |
| Total free cash flow | $ | 20,446 |  |  | $ | 1,958 |  |  | $ | 75,178 |  |  | $ | 14,431 |  |

[0001564590-21-021102:8k_2_02:37]
*Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs. Net debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-21-021102:8k_2_02:38]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 351.5 |  |  | $ | 203.1 |  |  | $ | 148.4 |  |

[0001564590-21-021102:8k_2_02:39]
Business Outlook:

[0001564590-21-021102:8k_2_02:40]
For its fourth quarter of fiscal 2021, ending June 30, 2021, the Company is targeting:

[0001564590-21-021102:8k_2_02:41]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ4'21 Guidance – GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 260.0 |  |  | $ | 270.0 |  |
| Gross Margin |  | 57.8 | % |  |  | 58.9 | % |
| Operating Expenses | $ | 141.0 |  |  | $ | 143.0 |  |
| Operating Margin |  | 3.5 | % |  |  | 5.9 | % |
| Net Income | $ | 2.6 |  |  | $ | 9.4 |  |
| Net Income per diluted share | $ | 0.02 |  |  | $ | 0.07 |  |
| Shares outstanding used in calculating GAAP EPS | 131.1 |  |  | 131.1 |  |
| FQ 4’21 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 260.0 |  |  | $ | 270.0 |  |
| Gross Margin |  | 60.5 | % |  |  | 61.5 | % |
| Operating Expenses | $ | 131.0 |  |  | $ | 133.0 |  |
| Operating Margin |  | 10.1 | % |  |  | 12.2 | % |
| Net Income | $ | 20.4 |  |  | $ | 25.7 |  |
| Net Income per diluted share | $ | 0.16 |  |  | $ | 0.20 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 131.1 |  |  |  | 131.1 |  |

[0001564590-21-021102:8k_2_02:42]
The following table shows the GAAP to non-GAAP reconciliation for Q4 FY’21 guidance:

[0001564590-21-021102:8k_2_02:43]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 57.8% - 58.9% |  |  | 3.5% - 5.9% |  |  | $0.02 - $0.07 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.1% |  |  | 2.1% |  |  |  | $0.04 |  |
| Share-based compensation | 0.3% |  |  | 3.3% |  |  |  | $0.07 |  |
| Restructuring |  | — |  |  | 0.2% |  |  |  | — |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.8% |  |  |  | $0.02 |  |
| Non-GAAP | 60.5% - 61.5% |  |  | 10.1% - 12.2% |  |  | $0.16- $0.20 |  |

[0001564590-21-021102:8k_2_02:44]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-21-021102:8k_2_02:45]
Conference Call:

[0001564590-21-021102:8k_2_02:46]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the third fiscal quarter results as well as the business outlook for fourth fiscal quarter ending June 30, 2021, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. The conference call may also be heard by dialing 1 (877) 303-9826 or international 1 (224) 357-2194 with Conference ID # 7695159. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 7695159. The encore recording will be available for at least 7 days following the call.

[0001564590-21-021102:8k_2_02:47]
About Extreme:

[0001564590-21-021102:8k_2_02:48]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-21-021102:8k_2_02:49]
Extreme Networks, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001564590-21-021102:8k_2_02:50]
Non-GAAP Financial Measures:

[0001564590-21-021102:8k_2_02:51]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of intangibles, inventory valuation adjustment, and restructuring charges.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the

[0001564590-21-021102:8k_2_02:52]
Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-21-021102:8k_2_02:53]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-21-021102:8k_2_02:54]
Forward-Looking Statements:

[0001564590-21-021102:8k_2_02:55]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2020, Quarterly Report on Form 10-Q for the quarter ended December 31, 2020, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-21-021102:8k_2_02:56]
###

[0001564590-21-021102:8k_2_02:57]
EXTREME NETWORKS, INC.

[0001564590-21-021102:8k_2_02:58]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-21-021102:8k_2_02:59]
(In thousands, except per share amounts)

[0001564590-21-021102:8k_2_02:60]
(Unaudited)

[0001564590-21-021102:8k_2_02:61]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 203,139 |  |  | $ | 193,872 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,259 and $1,212, respectively |  |  | 130,558 |  |  |  | 122,727 |  |
| Inventories |  |  | 43,924 |  |  |  | 62,589 |  |
| Prepaid expenses and other current assets |  |  | 43,259 |  |  |  | 35,019 |  |
| Total current assets |  |  | 420,880 |  |  |  | 414,207 |  |
| Property and equipment, net |  |  | 56,116 |  |  |  | 58,813 |  |
| Operating lease right-of-use assets, net |  |  | 41,295 |  |  |  | 51,274 |  |
| Intangible assets, net |  |  | 43,893 |  |  |  | 68,394 |  |
| Goodwill |  |  | 331,159 |  |  |  | 331,159 |  |
| Other assets |  |  | 60,333 |  |  |  | 55,241 |  |
| Total assets |  | $ | 953,676 |  |  | $ | 979,088 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,436 and $2,484, respectively |  | $ | 21,314 |  |  | $ | 16,516 |  |
| Accounts payable |  |  | 57,165 |  |  |  | 48,439 |  |
| Accrued compensation and benefits |  |  | 51,382 |  |  |  | 50,884 |  |
| Accrued warranty |  |  | 12,317 |  |  |  | 14,035 |  |
| Current portion, operating lease liabilities |  |  | 19,176 |  |  |  | 19,196 |  |
| Current portion, deferred revenue |  |  | 195,500 |  |  |  | 190,226 |  |
| Other accrued liabilities |  |  | 58,041 |  |  |  | 58,525 |  |
| Total current liabilities |  |  | 414,895 |  |  |  | 397,821 |  |
| Deferred revenue, less current portion |  |  | 122,919 |  |  |  | 100,961 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $5,348 and $7,165, respectively |  |  | 322,402 |  |  |  | 394,585 |  |
| Operating lease liabilities, less current portion |  |  | 37,504 |  |  |  | 50,238 |  |
| Deferred income taxes |  |  | 2,815 |  |  |  | 2,334 |  |
| Other long-term liabilities |  |  | 18,005 |  |  |  | 27,751 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 132,508 and 127,114 shares issued, respectively; 125,911 and 120,517 shares outstanding, respectively |  |  | 133 |  |  |  | 127 |  |
| Additional paid-in-capital |  |  | 1,069,797 |  |  |  | 1,035,041 |  |
| Accumulated other comprehensive loss |  |  | (3,012 | ) |  |  | (6,378 | ) |
| Accumulated deficit |  |  | (988,669 | ) |  |  | (980,279 | ) |
| Treasury stock at cost: 6,597 and 6,597 shares, respectively |  |  | (43,113 | ) |  |  | (43,113 | ) |
| Total stockholders’ equity |  |  | 35,136 |  |  |  | 5,398 |  |
| Total liabilities and stockholders’ equity |  | $ | 953,676 |  |  | $ | 979,088 |  |

[0001564590-21-021102:8k_2_02:62]
EXTREME NETWORKS, INC.

[0001564590-21-021102:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-021102:8k_2_02:64]
(In thousands, except per share amounts)

[0001564590-21-021102:8k_2_02:65]
(Unaudited)

[0001564590-21-021102:8k_2_02:66]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 176,334 |  |  | $ | 136,547 |  |  | $ | 503,575 |  |  | $ | 512,173 |  |
| Service and subscription |  |  | 77,066 |  |  |  | 72,972 |  |  |  | 227,755 |  |  |  | 220,324 |  |
| Total net revenues |  |  | 253,400 |  |  |  | 209,519 |  |  |  | 731,330 |  |  |  | 732,497 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 76,442 |  |  |  | 71,927 |  |  |  | 223,842 |  |  |  | 254,705 |  |
| Service and subscription |  |  | 28,145 |  |  |  | 26,257 |  |  |  | 83,465 |  |  |  | 80,543 |  |
| Total cost of revenues |  |  | 104,587 |  |  |  | 98,184 |  |  |  | 307,307 |  |  |  | 335,248 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 99,892 |  |  |  | 64,620 |  |  |  | 279,733 |  |  |  | 257,468 |  |
| Service and subscription |  |  | 48,921 |  |  |  | 46,715 |  |  |  | 144,290 |  |  |  | 139,781 |  |
| Total gross profit |  |  | 148,813 |  |  |  | 111,335 |  |  |  | 424,023 |  |  |  | 397,249 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 48,909 |  |  |  | 50,577 |  |  |  | 147,619 |  |  |  | 165,073 |  |
| Sales and marketing |  |  | 70,898 |  |  |  | 70,132 |  |  |  | 201,955 |  |  |  | 216,925 |  |
| General and administrative |  |  | 16,023 |  |  |  | 15,119 |  |  |  | 48,844 |  |  |  | 45,199 |  |
| Acquisition and integration costs |  |  | — |  |  |  | 5,156 |  |  |  | 1,975 |  |  |  | 30,075 |  |
| Restructuring and related charges, net of reversals |  |  | 425 |  |  |  | 6,648 |  |  |  | 2,121 |  |  |  | 19,407 |  |
| Amortization of intangibles |  |  | 1,406 |  |  |  | 2,059 |  |  |  | 4,704 |  |  |  | 6,366 |  |
| Total operating expenses |  |  | 137,661 |  |  |  | 149,691 |  |  |  | 407,218 |  |  |  | 483,045 |  |
| Operating income (loss) |  |  | 11,152 |  |  |  | (38,356 | ) |  |  | 16,805 |  |  |  | (85,796 | ) |
| Interest income |  |  | 81 |  |  |  | 222 |  |  |  | 281 |  |  |  | 1,366 |  |
| Interest expense |  |  | (5,594 | ) |  |  | (5,979 | ) |  |  | (18,325 | ) |  |  | (17,377 | ) |
| Other income (expense), net |  |  | 269 |  |  |  | 1,318 |  |  |  | (1,572 | ) |  |  | 1,128 |  |
| Income (loss) before income taxes |  |  | 5,908 |  |  |  | (42,795 | ) |  |  | (2,811 | ) |  |  | (100,679 | ) |
| Provision for income taxes |  |  | 2,436 |  |  |  | 1,557 |  |  |  | 5,579 |  |  |  | 4,949 |  |
| Net income (loss) |  | $ | 3,472 |  |  | $ | (44,352 | ) |  | $ | (8,390 | ) |  | $ | (105,628 | ) |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.03 |  |  | $ | (0.37 | ) |  | $ | (0.07 | ) |  | $ | (0.88 | ) |
| Net income (loss) per share - diluted |  | $ | 0.03 |  |  | $ | (0.37 | ) |  | $ | (0.07 | ) |  | $ | (0.88 | ) |
| Shares used in per share calculation - basic |  |  | 124,788 |  |  |  | 119,162 |  |  |  | 123,252 |  |  |  | 119,648 |  |
| Shares used in per share calculation - diluted |  |  | 129,988 |  |  |  | 119,162 |  |  |  | 123,252 |  |  |  | 119,648 |  |

[0001564590-21-021102:8k_2_02:67]
EXTREME NETWORKS, INC.

[0001564590-21-021102:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-21-021102:8k_2_02:69]
(In thousands)

[0001564590-21-021102:8k_2_02:70]
(Unaudited)

[0001564590-21-021102:8k_2_02:71]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (8,390 | ) |  | $ | (105,628 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 17,801 |  |  |  | 21,719 |  |
| Amortization of intangible assets |  |  | 24,501 |  |  |  | 26,460 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 12,129 |  |  |  | 12,469 |  |
| Provision for doubtful accounts |  |  | 270 |  |  |  | 1,267 |  |
| Share-based compensation |  |  | 27,595 |  |  |  | 26,935 |  |
| Deferred income taxes |  |  | 741 |  |  |  | 1,293 |  |
| Non-cash restructuring and impairment charges |  |  | - |  |  |  | 7,622 |  |
| Non-cash interest expense |  |  | 3,195 |  |  |  | 3,070 |  |
| Other |  |  | 2,770 |  |  |  | (395 | ) |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (8,101 | ) |  |  | 88,688 |  |
| Inventories |  |  | 11,869 |  |  |  | 16,373 |  |
| Prepaid expenses and other assets |  |  | (7,908 | ) |  |  | 438 |  |
| Accounts payable |  |  | 7,900 |  |  |  | (21,530 | ) |
| Accrued compensation and benefits |  |  | 351 |  |  |  | (24,009 | ) |
| Operating lease liabilities |  |  | (14,983 | ) |  |  | (13,222 | ) |
| Deferred revenue |  |  | 27,233 |  |  |  | 43 |  |
| Other current and long-term liabilities |  |  | (9,477 | ) |  |  | (14,532 | ) |
| Net cash provided by operating activities |  |  | 87,496 |  |  |  | 27,061 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (12,318 | ) |  |  | (12,630 | ) |
| Business acquisitions, net of cash acquired |  |  | — |  |  |  | (219,458 | ) |
| Maturities and sales of investments |  |  | — |  |  |  | 45,249 |  |
| Net cash used in investing activities |  |  | (12,318 | ) |  |  | (186,839 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 199,500 |  |
| Payments on debt obligations |  |  | (69,250 | ) |  |  | (29,767 | ) |
| Loan fees on borrowings |  |  | — |  |  |  | (10,514 | ) |
| Repurchase of common stock |  |  | — |  |  |  | (30,000 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 7,167 |  |  |  | 9,491 |  |
| Payment of contingent consideration obligations |  |  | (1,298 | ) |  |  | (3,448 | ) |
| Deferred payments on an acquisition |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Net cash (used in) provided by financing activities |  |  | (66,381 | ) |  |  | 187,262 |  |
| Foreign currency effect on cash |  |  | 470 |  |  |  | (741 | ) |
| Net increase in cash |  |  | 9,267 |  |  |  | 26,743 |  |
| Cash at beginning of period |  |  | 193,872 |  |  |  | 169,607 |  |
| Cash at end of period |  | $ | 203,139 |  |  | $ | 196,350 |  |

[0001564590-21-021102:8k_2_02:72]
Extreme Networks, Inc.

[0001564590-21-021102:8k_2_02:73]
Non-GAAP Measures of Financial Performance

[0001564590-21-021102:8k_2_02:74]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share and non-GAAP free cash flow.

[0001564590-21-021102:8k_2_02:75]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme also presents its range for projected non-GAAP operating expenses, which is operating expenses less share-based compensation expense, restructuring charges and amortization of intangibles.

[0001564590-21-021102:8k_2_02:76]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-21-021102:8k_2_02:77]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-21-021102:8k_2_02:78]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquired inventory adjustments, acquisition and integration costs, amortization of intangibles, inventory valuation adjustments, restructuring charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-21-021102:8k_2_02:79]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-21-021102:8k_2_02:80]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-21-021102:8k_2_02:81]
Acquired inventory adjustments. Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-21-021102:8k_2_02:82]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-21-021102:8k_2_02:83]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-21-021102:8k_2_02:84]
Inventory valuation adjustments. Adjustments relating to the mark down of inventory due to duplication of products lines with acquisition of Aerohive net of recoveries on the sale of inventory marked down in previous quarters.

[0001564590-21-021102:8k_2_02:85]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-21-021102:8k_2_02:86]
Tax effect on non-GAAP adjustments. Beginning with our first quarter of fiscal 2021, we changed how we calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.   Previously, the non-GAAP tax provision consisted of current and deferred income tax expense on a GAAP basis as if our carryforward net operating losses were sufficient to offset our non-GAAP adjustments.  Beginning with our first quarter of fiscal 2021, we have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits which were previously not utilizable.  The non-GAAP tax provision now consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.  We have adjusted the fiscal 2020 non-GAAP tax provision to reflect the 2020 non-GAAP operating results to be comparable with fiscal 2021 results.  As a result of this change, the non-GAAP net loss for the three months ended March 31, 2020 changed from $0.14 per diluted share as previously reported to $0.09 net loss per diluted share and the non-GAAP net income for the nine months ended March 31, 2020 changed from $0.08 per diluted share as previously reported to $0.09 net income per diluted share.

[0001564590-21-021102:8k_2_02:87]
This change will not affect our non-GAAP income (loss) before income taxes, actual cash tax payments or cash flows, but will result in a higher or lower non-GAAP provision for income taxes depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of June 30, 2020, we had U.S. federal net operating loss carryforwards of $310 million and state net operating loss carryforwards of $181 million.  We do not expect to pay substantial taxes on a GAAP basis in the U.S. for the foreseeable future due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Irish operating company which has fully utilized available net operating loss carryforwards as of the

[0001564590-21-021102:8k_2_02:88]
second quarter of fiscal 2021.  We also believe our long-term effective GAAP tax rate will be lower than the U.S. statutory rate based upon our established tax structure.

[0001564590-21-021102:8k_2_02:89]
EXTREME NETWORKS, INC.

[0001564590-21-021102:8k_2_02:90]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-21-021102:8k_2_02:91]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-21-021102:8k_2_02:92]
(In thousands, except percentages and per share amounts)

[0001564590-21-021102:8k_2_02:93]
(Unaudited)

[0001564590-21-021102:8k_2_02:94]
| Revenues | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Revenues - GAAP | $ | 253,400 |  |  | $ | 209,519 |  |  | $ | 731,330 |  |  | $ | 732,497 |  |

[0001564590-21-021102:8k_2_02:95]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Gross profit - GAAP | $ | 148,813 |  |  | $ | 111,335 |  |  | $ | 424,023 |  |  | $ | 397,249 |  |
| Gross margin - GAAP percentage |  | 58.7 | % |  |  | 53.1 | % |  |  | 58.0 | % |  |  | 54.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 709 |  |  |  | 648 |  |  |  | 2,092 |  |  |  | 2,152 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 7,303 |  |
| Acquisition and integration costs |  | — |  |  |  | 187 |  |  |  | 10 |  |  |  | 2,071 |  |
| Amortization of intangibles |  | 6,431 |  |  |  | 6,538 |  |  |  | 19,697 |  |  |  | 19,797 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,677 |  |
| Total adjustments to GAAP gross profit | $ | 7,140 |  |  | $ | 7,373 |  |  | $ | 21,799 |  |  | $ | 35,000 |  |
| Gross profit - non-GAAP | $ | 155,953 |  |  | $ | 118,708 |  |  | $ | 445,822 |  |  | $ | 432,249 |  |
| Gross margin - non-GAAP percentage |  | 61.5 | % |  |  | 56.7 | % |  |  | 61.0 | % |  |  | 59.0 | % |

[0001564590-21-021102:8k_2_02:96]
| Non-GAAP Operating Income (Loss) | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| GAAP operating income (loss) | $ | 11,152 |  |  | $ | (38,356 | ) |  | $ | 16,805 |  |  | $ | (85,796 | ) |
| GAAP operating income (loss) percentage |  | 4.4 | % |  |  | (18.3 | )% |  |  | 2.3 | % |  |  | (11.7 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 709 |  |  |  | 648 |  |  |  | 2,092 |  |  |  | 2,152 |  |
| Share-based compensation expense, R&D |  | 2,414 |  |  |  | 2,518 |  |  |  | 7,380 |  |  |  | 8,213 |  |
| Share-based compensation expense, S&M |  | 3,150 |  |  |  | 1,338 |  |  |  | 9,036 |  |  |  | 8,568 |  |
| Share-based compensation expense, G&A |  | 2,925 |  |  |  | 2,639 |  |  |  | 9,087 |  |  |  | 7,523 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,677 |  |
| Acquisition and integration costs |  | — |  |  |  | 5,343 |  |  |  | 1,985 |  |  |  | 32,146 |  |
| Restructuring charges, net of reversals |  | 425 |  |  |  | 6,648 |  |  |  | 2,121 |  |  |  | 19,407 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 7,303 |  |
| Amortization of intangibles |  | 7,837 |  |  |  | 8,597 |  |  |  | 24,401 |  |  |  | 26,163 |  |
| Total adjustments to GAAP operating income (loss) | $ | 17,460 |  |  | $ | 27,731 |  |  | $ | 56,102 |  |  | $ | 115,152 |  |
| Non-GAAP operating income (loss) | $ | 28,612 |  |  | $ | (10,625 | ) |  | $ | 72,907 |  |  | $ | 29,356 |  |
| Non-GAAP operating income (loss) percentage |  | 11.3 | % |  |  | (5.1 | )% |  |  | 10.0 | % |  |  | 4.0 | % |

[0001564590-21-021102:8k_2_02:97]
| Non-GAAP net income (loss) | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| GAAP net income (loss) | $ | 3,472 |  |  | $ | (44,352 | ) |  | $ | (8,390 | ) |  | $ | (105,628 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 9,198 |  |  |  | 7,143 |  |  |  | 27,595 |  |  |  | 26,456 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,677 |  |
| Acquisition and integration costs |  | — |  |  |  | 5,343 |  |  |  | 1,985 |  |  |  | 32,146 |  |
| Restructuring charge, net of reversal |  | 425 |  |  |  | 6,648 |  |  |  | 2,121 |  |  |  | 19,407 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 7,303 |  |
| Amortization of intangibles |  | 7,837 |  |  |  | 8,597 |  |  |  | 24,401 |  |  |  | 26,163 |  |
| Tax effect of non-GAAP adjustments |  | (259 | ) |  |  | 5,380 |  |  |  | (94 | ) |  |  | 1,276 |  |
| Total adjustments to GAAP net income (loss) | $ | 17,201 |  |  | $ | 33,111 |  |  | $ | 56,008 |  |  | $ | 116,428 |  |
| Non-GAAP net income (loss) | $ | 20,673 |  |  | $ | (11,241 | ) |  | $ | 47,618 |  |  | $ | 10,800 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income (loss) per share-diluted | $ | 0.16 |  |  | $ | (0.09 | ) |  | $ | 0.38 |  |  | $ | 0.09 |  |
| Shares used in net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation - basic |  | 124,788 |  |  |  | 119,162 |  |  |  | 123,252 |  |  |  | 119,648 |  |
| Potentially dilutive equity awards |  | 5,200 |  |  |  | 0 |  |  |  | 2,855 |  |  |  | 3,063 |  |
| GAAP and Non-GAAP shares used in per share calculation - diluted |  | 129,988 |  |  |  | 119,162 |  |  |  | 126,107 |  |  |  | 122,711 |  |
