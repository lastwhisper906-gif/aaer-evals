# EXTR notes — 0001564590-21-021969


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-21-021969:notes:1]
[same as prior period, unchanged from 0001564590-21-005006:notes:1]

[0001564590-21-021969:notes:2]
[same as prior period, unchanged from 0001564590-21-005006:notes:2]

[0001564590-21-021969:notes:3]
[same as prior period, unchanged from 0001564590-21-005006:notes:3]

[0001564590-21-021969:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2021. The results of operations for the three and nine months ended March 31, 2021 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.

[0001564590-21-021969:notes:5]
[same as prior period, unchanged from 0001564590-21-005006:notes:5]

[0001564590-21-021969:notes:6]
[same as prior period, unchanged from 0001564590-21-005006:notes:6]

[0001564590-21-021969:notes:7]
[same as prior period, unchanged from 0001564590-21-005006:notes:7]

[0001564590-21-021969:notes:8]
[same as prior period, unchanged from 0001564590-21-005006:notes:8]

[0001564590-21-021969:notes:9]
[same as prior period, unchanged from 0001564590-21-005006:notes:9]

[0001564590-21-021969:notes:10]
[same as prior period, unchanged from 0001564590-21-005006:notes:10]

[0001564590-21-021969:notes:11]
[same as prior period, unchanged from 0001564590-21-005006:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-21-021969:notes:12]
[same as prior period, unchanged from 0001564590-21-005006:notes:12]

[0001564590-21-021969:notes:13]
[same as prior period, unchanged from 0001564590-21-005006:notes:13]

[0001564590-21-021969:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-21-021969:notes:15]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 was effective for fiscal years beginning after December 15, 2019.  The Company adopted the standard on July 1, 2020 and the impact of the adoption was not material to the Company's condensed consolidated financial statements as credit losses are not expected to be significant based on historical collection trends, the financial condition of payment partners, and external market factors.

[0001564590-21-021969:notes:16]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-21-021969:notes:17]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-21-021969:notes:18]
Recently Issued Accounting Pronouncements

[0001564590-21-021969:notes:19]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures but does not believe there will be a material impact on the Company’s financial statements outside of potentially the change to recognition of state income and franchise taxes under the new Accounting Standard.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-021969:notes:20]
[same as prior period, unchanged from 0001564590-21-005006:notes:20]

[0001564590-21-021969:notes:21]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-21-021969:notes:22]
[same as prior period, unchanged from 0001564590-21-005006:notes:22]

[0001564590-21-021969:notes:23]
[same as prior period, unchanged from 0001564590-21-005006:notes:23]

[0001564590-21-021969:notes:24]
[same as prior period, unchanged from 0001564590-21-005006:notes:24]

[0001564590-21-021969:notes:25]
On March 31, 2021, the Company had $318.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 22 percent of its deferred revenue as revenue in fiscal 2021, an additional 44 percent in fiscal 2022 and 34 percent of the balance thereafter.

[0001564590-21-021969:notes:26]
[same as prior period, unchanged from 0001564590-21-005006:notes:26]

[0001564590-21-021969:notes:27]
Revenue recognized for the three months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $67.9 million and $64.3 million, respectively. Revenue recognized for the nine months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $158.7 million and $116.7 million, respectively.

[0001564590-21-021969:notes:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $10.2 million and $8.1 million at March 31, 2021 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2021 and 2020, was $1.4 million and $1.1 million, respectively. Amortization recognized during the nine months ended March 31, 2021 and 2020, was $3.9 million and $4.1 million, respectively.

[0001564590-21-021969:notes:29]
[same as prior period, unchanged from 0001564590-21-005006:notes:29]

[0001564590-21-021969:notes:30]
[same as prior period, unchanged from 0001564590-21-005006:notes:30]

[0001564590-21-021969:notes:31]
[same as prior period, unchanged from 0001564590-21-005006:notes:31]

[0001564590-21-021969:notes:32]
|  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |
| Other |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |
| Total Americas |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |
| EMEA |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |
| APAC |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |
| Total net revenues |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |

[0001564590-21-021969:notes:33]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |
| Other |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |
| Total Americas |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |
| EMEA |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |
| APAC |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |
| Total net revenues |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |

[0001564590-21-021969:notes:34]
For the three months ended March 31, 2021 the Company reflected 11% of its revenues from the Netherlands. For the nine months ended March 31, 2021 the Company reflected 10% of its revenues from the Netherlands.  No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2021 or 2020.

[0001564590-21-021969:notes:35]
[same as prior period, unchanged from 0001564590-21-005006:notes:35]

[0001564590-21-021969:notes:36]
[same as prior period, unchanged from 0001564590-21-005006:notes:36]

[0001564590-21-021969:notes:37]
[same as prior period, unchanged from 0001564590-21-005006:notes:37]

[0001564590-21-021969:notes:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Tech Data Corporation |  | 15% |  |  | 19% |  |  | 21% |  |  | 16% |  |
| Jenne Corporation |  | 16% |  |  | * |  |  | 14% |  |  | 13% |  |
| Westcon Group Inc. |  | 19% |  |  | 19% |  |  | 17% |  |  | 14% |  |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001564590-21-021969:notes:39]
[same as prior period, unchanged from 0001564590-21-005006:notes:39]

[0001564590-21-021969:notes:40]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  | * |  |  | 23% |  |
| Jenne Corporation |  | 19% |  |  | 25% |  |
| Westcon Group Inc. |  | 16% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-21-021969:notes:41]
[same as prior period, unchanged from 0001564590-21-005006:notes:41]

[0001564590-21-021969:notes:42]
[same as prior period, unchanged from 0001564590-21-005006:notes:42]

[0001564590-21-021969:notes:43]
[same as prior period, unchanged from 0001564590-21-005006:notes:43]

[0001564590-21-021969:notes:44]
[same as prior period, unchanged from 0001564590-21-005006:notes:44]

[0001564590-21-021969:notes:45]
[same as prior period, unchanged from 0001564590-21-005006:notes:45]

[0001564590-21-021969:notes:46]
[same as prior period, unchanged from 0001564590-21-005006:notes:46]

[0001564590-21-021969:notes:47]
[same as prior period, unchanged from 0001564590-21-005006:notes:47]

[0001564590-21-021969:notes:48]
The unaudited pro forma financial information for the three and nine months ended March 31, 2020 combines the historical results for Extreme for such periods assuming the transaction closed on July 1, 2018, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-21-021969:notes:49]
[same as prior period, unchanged from 0001564590-21-005006:notes:49]

[0001564590-21-021969:notes:50]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2020 |  |
| Net revenues |  | $ | 210,255 |  |  | $ | 746,301 |  |
| Net loss |  | $ | (37,873 | ) |  | $ | (66,720 | ) |
| Net loss per share - basic and diluted |  | $ | (0.32 | ) |  | $ | (0.56 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 119,162 |  |  |  | 119,648 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-21-021969:notes:51]
[same as prior period, unchanged from 0001564590-21-005006:notes:51]

[0001564590-21-021969:notes:52]
[same as prior period, unchanged from 0001564590-21-005006:notes:52]

[0001564590-21-021969:notes:53]
[same as prior period, unchanged from 0001564590-21-005006:notes:53]

[0001564590-21-021969:notes:54]
[same as prior period, unchanged from 0001564590-21-005006:notes:54]

[0001564590-21-021969:notes:55]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Finished goods |  | $ | 37,870 |  |  | $ | 52,879 |  |
| Raw materials |  |  | 6,054 |  |  |  | 9,710 |  |
| Total Inventories |  | $ | 43,924 |  |  | $ | 62,589 |  |

[0001564590-21-021969:notes:56]
[same as prior period, unchanged from 0001564590-21-005006:notes:56]

[0001564590-21-021969:notes:57]
[same as prior period, unchanged from 0001564590-21-005006:notes:57]

[0001564590-21-021969:notes:58]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Computers and equipment |  | $ | 77,770 |  |  | $ | 73,244 |  |
| Purchased software |  |  | 41,239 |  |  |  | 34,015 |  |
| Office equipment, furniture and fixtures |  |  | 10,769 |  |  |  | 10,639 |  |
| Leasehold improvements |  |  | 53,339 |  |  |  | 52,317 |  |
| Total property and equipment |  |  | 183,117 |  |  |  | 170,215 |  |
| Less: accumulated depreciation and amortization |  |  | (127,001 | ) |  |  | (111,402 | ) |
| Property and equipment, net |  | $ | 56,116 |  |  | $ | 58,813 |  |

[0001564590-21-021969:notes:59]
[same as prior period, unchanged from 0001564590-21-005006:notes:59]

[0001564590-21-021969:notes:60]
[same as prior period, unchanged from 0001564590-21-005006:notes:60]

[0001564590-21-021969:notes:61]
[same as prior period, unchanged from 0001564590-21-005006:notes:61]

[0001564590-21-021969:notes:62]
[same as prior period, unchanged from 0001564590-21-005006:notes:62]

[0001564590-21-021969:notes:63]
The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2021 and 2020 (in thousands):

[0001564590-21-021969:notes:64]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Balance beginning of period |  | $ | 13,073 |  |  | $ | 16,209 |  |  | $ | 14,035 |  |  | $ | 14,779 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 570 |  |
| New warranties issued |  |  | 2,969 |  |  |  | 4,810 |  |  |  | 9,105 |  |  |  | 16,271 |  |
| Warranty expenditures |  |  | (3,725 | ) |  |  | (5,797 | ) |  |  | (10,823 | ) |  |  | (16,398 | ) |
| Balance end of period |  | $ | 12,317 |  |  | $ | 15,222 |  |  | $ | 12,317 |  |  | $ | 15,222 |  |

[0001564590-21-021969:notes:65]
[same as prior period, unchanged from 0001564590-21-005006:notes:65]

[0001564590-21-021969:notes:66]
[same as prior period, unchanged from 0001564590-21-005006:notes:66]

[0001564590-21-021969:notes:67]
[same as prior period, unchanged from 0001564590-21-005006:notes:67]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-21-021969:notes:68]
[same as prior period, unchanged from 0001564590-21-005006:notes:68]

[0001564590-21-021969:notes:69]
[same as prior period, unchanged from 0001564590-21-005006:notes:69]

[0001564590-21-021969:notes:70]
[same as prior period, unchanged from 0001564590-21-005006:notes:70]

[0001564590-21-021969:notes:71]
[same as prior period, unchanged from 0001564590-21-005006:notes:71]

[0001564590-21-021969:notes:72]
[same as prior period, unchanged from 0001564590-21-005006:notes:72]

[0001564590-21-021969:notes:73]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at March 31, 2021 and June 30, 2020 (in thousands).

[0001564590-21-021969:notes:74]
| March 31, 2021 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 226 |  |  | $ | — |  |  | $ | 226 |  |
| Interest rate swaps |  |  | — |  |  |  | 1,288 |  |  |  | — |  |  |  | 1,288 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 902 |  |  |  | 902 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,514 |  |  | $ | 902 |  |  | $ | 2,416 |  |

[0001564590-21-021969:notes:75]
[same as prior period, unchanged from 0001564590-21-005006:notes:75]

[0001564590-21-021969:notes:76]
[same as prior period, unchanged from 0001564590-21-005006:notes:76]

[0001564590-21-021969:notes:77]
[same as prior period, unchanged from 0001564590-21-005006:notes:77]

[0001564590-21-021969:notes:78]
As of March 31, 2021 and June 30, 2020, the Company had foreign exchange forward contracts with notional principal amount of $26.7 million and $4.0 million, respectively. For the three and nine months ended March 31, 2021, there were unrealized gains (losses) of $(0.2) million and $0.1 million, respectively. For the three and nine months ended March 31, 2021, there were realized gains (losses) of less than $(0.1) million and $0.4 million, respectively. For the three and nine months ended March 31, 2020, there were unrealized gains of $0.1 million and $0.1 million, respectively. For the three and nine months ended March 31, 2020, there were realized gains of $0.1 million and $0.1 million, respectively. These contracts have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts are included in other income (expense), net. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-21-021969:notes:79]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of March 31, 2021 and as of June 30, 2020, the Company had interest rate swap contracts with the total notional amount of $200.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive loss. As of March 31, 2021 and as of June 30, 2020, these contracts had an unrealized loss of $1.3 million and $1.8 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-21-021969:notes:80]
The fair value of the borrowings under the 2019 Credit Agreement (as defined below) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Since the interest rate is variable in the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $351.5 million and $420.8 million as of March 31, 2021, and June 30, 2020, respectively.

[0001564590-21-021969:notes:81]
[same as prior period, unchanged from 0001564590-21-005006:notes:81]

[0001564590-21-021969:notes:82]
At March 31, 2021 and June 30, 2020, the Company reflected one liability measured at fair value of $0.9 million and $2.2 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-21-021969:notes:83]
[same as prior period, unchanged from 0001564590-21-005006:notes:83]

[0001564590-21-021969:notes:84]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Beginning balance |  |  | 2,167 |  |  |  | 6,298 |  |
| Payments |  |  | (1,298 | ) |  |  | (3,448 | ) |
| Accretion on discount |  |  | 33 |  |  |  | 90 |  |
| Ending balance |  | $ | 902 |  |  | $ | 2,940 |  |

[0001564590-21-021969:notes:85]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three and nine months ended March 31, 2021 and 2020. There were no impairments recorded for the three and nine months ended March 31, 2021 and 2020.

[0001564590-21-021969:notes:86]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive loss into earnings using the specific identification method.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-021969:notes:87]
[same as prior period, unchanged from 0001564590-21-005006:notes:87]

[0001564590-21-021969:notes:88]
[same as prior period, unchanged from 0001564590-21-005006:notes:88]

[0001564590-21-021969:notes:89]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 1.9 years |  | $ | 156,100 |  |  | $ | 123,448 |  |  | $ | 32,652 |  |
| Customer relationships |  | 4.7 years |  |  | 63,039 |  |  |  | 53,141 |  |  |  | 9,898 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 0.8 years |  |  | 10,700 |  |  |  | 9,767 |  |  |  | 933 |  |
| License agreements |  | 5.7 years |  |  | 2,445 |  |  |  | 2,035 |  |  |  | 410 |  |
| Other intangibles |  | — years |  |  | 1,382 |  |  |  | 1,382 |  |  |  | — |  |
| Total intangibles, net |  |  |  | $ | 234,066 |  |  | $ | 190,173 |  |  | $ | 43,893 |  |

[0001564590-21-021969:notes:90]
[same as prior period, unchanged from 0001564590-21-005006:notes:90]

[0001564590-21-021969:notes:91]
[same as prior period, unchanged from 0001564590-21-005006:notes:91]

[0001564590-21-021969:notes:92]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Amortization in “Cost of revenues: Product and Service and subscription” |  | $ | 6,449 |  |  | $ | 6,629 |  |  | $ | 19,797 |  |  | $ | 20,094 |  |
| Amortization of intangibles in "Operations" |  |  | 1,406 |  |  |  | 2,059 |  |  |  | 4,704 |  |  |  | 6,366 |  |
| Total amortization expense |  | $ | 7,855 |  |  | $ | 8,688 |  |  | $ | 24,501 |  |  | $ | 26,460 |  |

[0001564590-21-021969:notes:93]
[same as prior period, unchanged from 0001564590-21-005006:notes:93]


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-021969:notes:94]
| 8. | Debt |

[0001564590-21-021969:notes:95]
The Company’s debt is comprised of the following (in thousands):

[0001564590-21-021969:notes:96]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 23,750 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,436 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 21,314 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 327,750 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,348 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 322,402 |  |  |  | 394,585 |  |
| Total debt |  | $ | 343,716 |  |  | $ | 411,101 |  |

[0001564590-21-021969:notes:97]
In connection with the Acquisition discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-21-021969:notes:98]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380 million and a five-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-21-021969:notes:99]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.40%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-21-021969:notes:100]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-21-021969:notes:101]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment

[0001564590-21-021969:notes:102]
and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirements and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5%, and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-21-021969:notes:103]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-21-021969:notes:104]
The Second Amendment provides for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the 12 month period ended March 31, 2021 the Company’s financial performance is in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company will file a Suspension Early Termination Notice and Covenant Certificate with the loan administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance will result in the Company’s Eurodollar loan spread to decrease from 4.5% suspension period rate, to 2.75% and unused facility commitment fee will decrease from 0.4% to 0.35%, and the limitation on revolver borrowings will be removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-21-021969:notes:105]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of March 31, 2021 was 4.6%.

[0001564590-21-021969:notes:106]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.6 million for the three months ended March 31, 2021 and 2020, and totaled $2.3 million and $1.8 million for the nine months ended March 31, 2021 and 2020.

[0001564590-21-021969:notes:107]
During the six months ended December 31, 2020, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at March 31, 2021. The Company has $55.0 million of availability under the 2019 Revolving Facility as of March 31, 2021.

[0001564590-21-021969:notes:108]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-021969:notes:109]
| 9. | Commitments and Contingencies |

[0001564590-21-021969:notes:110]
Purchase Commitments

[0001564590-21-021969:notes:111]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2021, the Company had commitments to purchase $33.0 million of inventory and other services.

[0001564590-21-021969:notes:112]
Legal Proceedings

[0001564590-21-021969:notes:113]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-21-021969:notes:114]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material,

[0001564590-21-021969:notes:115]
then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-21-021969:notes:116]
All currency conversions in this Legal Proceedings section are as of March 31, 2021.

[0001564590-21-021969:notes:117]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-21-021969:notes:118]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The Federal Circuit Court ruled for XR on November 25, 2020 in Cisco’s appeal of the ‘231 PTAB decision, and the stay of the District Court case has been lifted.

[0001564590-21-021969:notes:119]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-21-021969:notes:120]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process, pursuant to the appeal filed by Orckit on March 13, 2020.

[0001564590-21-021969:notes:121]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce an injunction against the Company. The Company filed a notice of appeal on November 12, 2020 and the matter is proceeding through the appellate process.

[0001564590-21-021969:notes:122]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019. Both cases were filed in the Federal Patent Court in Munich and seek to invalidate the asserted patents. Both nullity actions are proceeding.

[0001564590-21-021969:notes:123]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

[0001564590-21-021969:notes:124]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). The parties have reached a tentative agreement to settle the matter for an immaterial amount.

[0001564590-21-021969:notes:125]
DataCloud Technologies, LLC. v. Extreme Networks, Inc.

[0001564590-21-021969:notes:126]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware. The lawsuit alleges direct infringement of four U.S. patents. DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees. DataCloud amended the complaint on November 13, 2020, asserting claims of direct, induced, and willful infringement of four new patents, and filed a second amended complaint on February 12, 2021. The parties settled this case on March 31, 2021 for an immaterial amount and the matter was dismissed in the District Court on April 9, 2021.

[0001564590-21-021969:notes:127]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-21-021969:notes:128]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a petition to transfer the case to the Northern District of California. This motion is pending.

[0001564590-21-021969:notes:129]
Hanger Solutions, LLC v. Extreme Networks, Inc.

[0001564590-21-021969:notes:130]
On January 14, 2021, Hanger Solutions, LLC (“Hanger”) filed a patent infringement lawsuit against the Company in the District of Delaware. The complaint alleges infringement of three U.S. patents. The parties settled this case on March 31, 2021 for an immaterial amount and the matter was dismissed in the District Court on April 12, 2021.

[0001564590-21-021969:notes:131]
Indemnification Obligations

[0001564590-21-021969:notes:132]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-21-021969:notes:133]
[same as prior period, unchanged from 0001564590-21-005006:notes:134]

[0001564590-21-021969:notes:134]
[same as prior period, unchanged from 0001564590-21-005006:notes:135]

[0001564590-21-021969:notes:135]
[same as prior period, unchanged from 0001564590-21-005006:notes:136]

[0001564590-21-021969:notes:136]
[same as prior period, unchanged from 0001564590-21-005006:notes:137]

[0001564590-21-021969:notes:137]
[same as prior period, unchanged from 0001564590-21-005006:notes:138]

[0001564590-21-021969:notes:138]
[same as prior period, unchanged from 0001564590-21-005006:notes:139]

[0001564590-21-021969:notes:139]
[same as prior period, unchanged from 0001564590-21-005006:notes:140]

[0001564590-21-021969:notes:140]
[same as prior period, unchanged from 0001564590-21-005006:notes:141]

[0001564590-21-021969:notes:141]
[same as prior period, unchanged from 0001564590-21-005006:notes:142]

[0001564590-21-021969:notes:142]
On November 2, 2018, the Company announced the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions. In February 2020, the Board

[0001564590-21-021969:notes:143]
increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020. A maximum of $30.0 million of the Company’s common stock may be repurchased in any calendar year.

[0001564590-21-021969:notes:144]
There were no shares repurchased during the three and nine months ended March 31, 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-021969:notes:145]
[same as prior period, unchanged from 0001564590-21-005006:notes:145]

[0001564590-21-021969:notes:146]
[same as prior period, unchanged from 0001564590-21-005006:notes:146]

[0001564590-21-021969:notes:147]
[same as prior period, unchanged from 0001564590-21-005006:notes:147]

[0001564590-21-021969:notes:148]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 6,518 |  |  |  | 13,118 |  |
| Employee stock options and awards outstanding |  |  | 11,327 |  |  |  | 10,396 |  |
| 2014 Employee Stock Purchase Plan |  |  | 4,414 |  |  |  | 7,364 |  |
| Total shares reserved for issuance |  |  | 22,259 |  |  |  | 30,878 |  |

[0001564590-21-021969:notes:149]
[same as prior period, unchanged from 0001564590-21-005006:notes:149]

[0001564590-21-021969:notes:150]
[same as prior period, unchanged from 0001564590-21-005006:notes:150]

[0001564590-21-021969:notes:151]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Cost of product revenues |  | $ | 297 |  |  | $ | 280 |  |  | $ | 869 |  |  | $ | 932 |  |
| Cost of service and subscription revenues |  |  | 412 |  |  |  | 368 |  |  |  | 1,223 |  |  |  | 1,220 |  |
| Research and development |  |  | 2,414 |  |  |  | 2,518 |  |  |  | 7,380 |  |  |  | 8,213 |  |
| Sales and marketing |  |  | 3,150 |  |  |  | 1,338 |  |  |  | 9,036 |  |  |  | 8,568 |  |
| General and administrative |  |  | 2,925 |  |  |  | 2,639 |  |  |  | 9,087 |  |  |  | 7,523 |  |
| Integration costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 479 |  |
| Total share-based compensation expense |  | $ | 9,198 |  |  | $ | 7,143 |  |  | $ | 27,595 |  |  | $ | 26,935 |  |

[0001564590-21-021969:notes:152]
[same as prior period, unchanged from 0001564590-21-005006:notes:152]

[0001564590-21-021969:notes:153]
The following table summarizes stock option activity for the nine months ended March 31, 2021 (in thousands, except per share and contractual term):

[0001564590-21-021969:notes:154]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2020 |  |  | 2,922 |  |  | $ | 4.95 |  |  |  | 3.09 |  |  | $ | 1,688 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (415 | ) |  |  | 3.44 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (655 | ) |  |  | 5.39 |  |  |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2021 |  |  | 1,852 |  |  | $ | 5.14 |  |  |  | 3.55 |  |  | $ | 6,687 |  |
| Vested and expected to vest at March 31, 2021 |  |  | 1,852 |  |  | $ | 5.14 |  |  |  | 3.55 |  |  | $ | 6,687 |  |
| Exercisable at March 31, 2021 |  |  | 903 |  |  | $ | 3.69 |  |  |  | 2.21 |  |  | $ | 4,577 |  |

[0001564590-21-021969:notes:155]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the nine months ended March 31, 2021. The average fair value of the stock options granted during the nine months ended March 31, 2020 was $3.52.

[0001564590-21-021969:notes:156]
[same as prior period, unchanged from 0001564590-21-005006:notes:156]

[0001564590-21-021969:notes:157]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance or market-condition RSUs which

[0001564590-21-021969:notes:158]
vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the awards’ fair value as of the date of grant.  The Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-21-021969:notes:159]
The following table summarizes stock award activity for the nine months ended March 31, 2021 (in thousands, except grant date fair value):

[0001564590-21-021969:notes:160]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2020 |  |  | 7,474 |  |  | $ | 6.83 |  |  |  |  |  |
| Granted |  |  | 6,015 |  |  |  | 4.87 |  |  |  |  |  |
| Released |  |  | (3,047 | ) |  |  | 7.16 |  |  |  |  |  |
| Cancelled |  |  | (967 | ) |  |  | 8.13 |  |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2021 |  |  | 9,475 |  |  | $ | 5.36 |  |  | $ | 82,907 |  |
| Vested and expected to vest at March 31, 2021 |  |  | 9,032 |  |  | $ | 5.29 |  |  | $ | 78,993 |  |

[0001564590-21-021969:notes:161]
The RSU's granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company. The stock awards granted during the nine months ended March 31, 2021 included 1.6 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0001564590-21-021969:notes:162]
[same as prior period, unchanged from 0001564590-21-005006:notes:161]

[0001564590-21-021969:notes:163]
On July 27, 2020, the Compensation Committee of the Board granted 0.5 million RSUs with vesting based on market conditions (“MSU”) to certain of the Company’s named executive officers. These MSUs will vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods from August 15, 2020 through August 15, 2023, subject to the grantees’ continued service through the certification of performance.

[0001564590-21-021969:notes:164]
[same as prior period, unchanged from 0001564590-21-005006:notes:163]

[0001564590-21-021969:notes:165]
[same as prior period, unchanged from 0001564590-21-005006:notes:164]

[0001564590-21-021969:notes:166]
[same as prior period, unchanged from 0001564590-21-005006:notes:165]

[0001564590-21-021969:notes:167]
[same as prior period, unchanged from 0001564590-21-005006:notes:166]

[0001564590-21-021969:notes:168]
During fiscal 2019 and 2018, the Company approved the grant of 0.6 million shares underlying stock awards each year in the form of restricted stock units with certain performance conditions (“PSUs”) to named executive officers and other vice president level employees. These PSUs would vest once the Company’s earnings as determined under U.S. generally accepted accounting principles aggregates at least $0.09 per share over two consecutive quarters exclusive of the PSU related share-based compensation expense (the “Performance Thresholds”). Upon satisfying the Performance Thresholds, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter will vest on the same schedule as the RSUs, subject to continued service to the Company.  The PSUs will expire if the Performance Thresholds are not met by the third anniversary of their respective grant dates.  The PSUs issued in fiscal 2018 expired in August 2020 without achieving the Performance Threshold.  During the three and nine months ended March 31, 2021 and 2020 the Performance Thresholds for outstanding performance PSUs issued in fiscal 2019 were not deemed probable to be achieved and, as such, no compensation expense was recorded in either reporting period.

[0001564590-21-021969:notes:169]
[same as prior period, unchanged from 0001564590-21-005006:notes:168]

[0001564590-21-021969:notes:170]
There were 1.5 million and 1.5 million shares issued under the ESPP during the three months ended March 31, 2021 and 2020, respectively. There were 2.9 million and 2.7 million shares issued under the ESPP during the nine months ended March 31, 2021 and 2020, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001564590-21-021969:notes:171]
|  |  | Employee Stock Purchase Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 0.05 | % |  |  | 1.56 | % |  |  | 0.09 | % |  |  | 1.71 | % |
| Volatility |  |  | 55 | % |  |  | 43 | % |  |  | 95 | % |  |  | 43 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-21-021969:notes:172]
The weighted-average grant-date fair value of shares issued under the ESPP during the three months ended March 31, 2021 and 2020 was $2.87 and $1.90, respectively. The weighted-average grant-date fair value of shares issued under the ESPP during the nine months ended March 31, 2021 and 2020 was $2.47 and $1.76, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-021969:notes:173]
[same as prior period, unchanged from 0001564590-21-005006:notes:172]

[0001564590-21-021969:notes:174]
[same as prior period, unchanged from 0001564590-21-005006:notes:173]

[0001564590-21-021969:notes:175]
[same as prior period, unchanged from 0001564590-21-005006:notes:174]

[0001564590-21-021969:notes:176]
[same as prior period, unchanged from 0001564590-21-005006:notes:175]

[0001564590-21-021969:notes:177]
| Long-lived Assets |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Americas |  | $ | 155,970 |  |  | $ | 177,443 |  |
| EMEA |  |  | 29,478 |  |  |  | 39,477 |  |
| APAC |  |  | 16,189 |  |  |  | 16,802 |  |
| Total long-lived assets |  | $ | 201,637 |  |  | $ | 233,722 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-21-021969:notes:178]
[same as prior period, unchanged from 0001564590-21-005006:notes:177]

[0001564590-21-021969:notes:179]
[same as prior period, unchanged from 0001564590-21-005006:notes:178]

[0001564590-21-021969:notes:180]
[same as prior period, unchanged from 0001564590-21-005006:notes:179]

[0001564590-21-021969:notes:181]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly

[0001564590-21-021969:notes:182]
effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive loss and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0001564590-21-021969:notes:183]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt.  As of March 31, 2021, the total notional amount of these interest rate swaps was $200.0 million and had maturity dates through April 2023. As of March 31, 2021, these contracts had an unrealized loss of $1.3 million which is recorded in “Accumulated other comprehensive loss” with the associated liability in “Other accrued liabilities” in the condensed consolidated balance sheet. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. As of March 31, 2020, the Company had interest rate swaps with a total notional amount of $200.0 million which had maturity dates through April 2023. As of March 31, 2020, these contracts had an unrealized loss of $1.0 million. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive loss related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $1.0 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0001564590-21-021969:notes:184]
[same as prior period, unchanged from 0001564590-21-005006:notes:182]

[0001564590-21-021969:notes:185]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. Unrealized gains (losses) recorded in the condensed consolidated statement of operations from these transactions during the three and nine months ended March 31, 2021 were $(0.2) million and $0.1 million, respectively. Realized gains (losses) recorded in the condensed consolidated statement of operations from these transactions during the three and nine months ended March 31, 2021 were less than $(0.1) million and $0.4 million, respectively. Unrealized gains from these transactions during the three and nine months ended March 31, 2020, were $0.1 million and $0.1 million, respectively. Realized gains from these transactions for the three and nine months ended March 31, 2020, were $0.1 million and $0.1 million, respectively.

[0001564590-21-021969:notes:186]
As of March 31, 2021, foreign exchange forward contracts had a notional principal amount of $26.7 million. These contracts have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001564590-21-021969:notes:187]
The Company recognized total foreign currency gains of $0.6 million and $0.9 million for the three months ended March 31, 2021 and 2020, respectively related to the change in fair value of foreign currency denominated assets and liabilities. The Company recognized total foreign currency gains (losses) of $(1.9) million and $(1.1) million for the nine months ended March 31, 2021 and 2020, respectively related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-021969:notes:188]
[same as prior period, unchanged from 0001564590-21-005006:notes:186]

[0001564590-21-021969:notes:189]
The Company recorded $0.4 million and $2.1 million of restructuring charges, net of reversals and impairments during the three and nine months ended March 31, 2021, respectively. Total restructuring charges included severance, benefits, and equipment relocation charges of $0.1 million and $1.2 million, as well as facility related charges of $0.3 million and $0.9 million for the three and nine months ended March 31, 2021, respectively. Severance and benefit restructuring charges consisted primarily of additional employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under the 2020 Plan, the Company is relocating certain of its lab test equipment to third-party consulting companies. The Company has incurred $9.3 million of charges under the 2020 Plan through March 31, 2021. The Company expects to incur additional equipment related relocation expenses of $0.7 million and expects to substantially complete these activities by the first half of fiscal 2022. The facility restructuring charges included additional facilities expenses related to previously impaired facilities.

[0001564590-21-021969:notes:190]
The Company recorded $6.6 million and $19.4 million of restructuring charges, net of reversals and impairment during the three and nine months ended March 31, 2020, respectively. The charges included $0.3 million and $8.2 million, respectively, for the impairment of right-of-use assets related to facilities which the Company has exited, and $6.3 million and $11.2 million, respectively for employee severance and benefit expenses incurred under the Company’s restructuring plans.

[0001564590-21-021969:notes:191]
Restructuring liabilities related to severance, benefits, and equipment relocation obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. The following table summarizes the activity related to the severance, benefits, and equipment relocation liabilities during the three and nine months ended March 31, 2021 (in thousands):

[0001564590-21-021969:notes:192]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Severance and Other |  |  | Severance and Other |  |
| Balance at beginning of period |  | $ | 181 |  |  | $ | 868 |  |  | $ | 2,219 |  |  | $ | 3,559 |  |
| Period charges |  |  | 119 |  |  |  | 6,378 |  |  |  | 1,366 |  |  |  | 12,257 |  |
| Period reversals |  |  | — |  |  |  | (39 | ) |  |  | (128 | ) |  |  | (1,044 | ) |
| Period payments |  |  | (286 | ) |  |  | (1,003 | ) |  |  | (3,443 | ) |  |  | (8,568 | ) |
| Balance at end of period |  | $ | 14 |  |  | $ | 6,204 |  |  | $ | 14 |  |  | $ | 6,204 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-021969:notes:193]
[same as prior period, unchanged from 0001564590-21-005006:notes:191]

[0001564590-21-021969:notes:194]
For the three months ended March 31, 2021 and 2020, the Company recorded an income tax provision of $2.4 million and $1.6 million, respectively. For the nine months ended March 31, 2021 and 2020, the Company recorded an income tax provision of $5.6 and $4.9 million, respectively.

[0001564590-21-021969:notes:195]
The income tax provisions for the three and nine months ended March 31, 2021 and 2020, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”) and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three and nine months ended March 31, 2021 and 2020 were calculated using the discrete effective tax rate method as allowed by Accounting Standards Codification (“ASC”) 740-270-30-18, “Income Taxes – Interim Reporting.”  The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate.  The discrete method treats the year to date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001564590-21-021969:notes:196]
On December 27, 2020, the Consolidated Appropriations Act (“CAA”), 2021 was signed into law in the United States.  Along with providing funding for normal government operations, the bill provides for additional COVID-19 focused relief in part, in the form of modification and extension of certain CARES Act provisions (discussed below) as well as modification and extension of other traditional tax provisions.  The Company has reviewed the provisions of the CAA and has determined there is no material impact on the Company’s current or deferred tax position.

[0001564590-21-021969:notes:197]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in the United States.  The CARES Act, among other things, includes modifications to net operating loss carryforward provisions and the net interest expense deduction, and deferment of employer social security tax payments.  The Company has evaluated the provisions of the CARES Act and how certain elections may impact its financial position and results of operations, and determined the enactment of the CARES Act did not have a material impact to the Company’s income tax provision for the three and nine months ended March 31, 2021, or to the Company’s net deferred tax assets as of March 31, 2021.

[0001564590-21-021969:notes:198]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-21-021969:notes:199]
[same as prior period, unchanged from 0001564590-21-005006:notes:198]

[0001564590-21-021969:notes:200]
The Company had $23.6 million of unrecognized tax benefits as of March 31, 2021.  If fully recognized in the future, $0.5 million would impact the effective tax rate and $23.1 million, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-21-021969:notes:201]
[same as prior period, unchanged from 0001564590-21-005006:notes:200]

[0001564590-21-021969:notes:202]
[same as prior period, unchanged from 0001564590-21-005006:notes:201]


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-021969:notes:203]
| 16. | Net Income (Loss) Per Share |

[0001564590-21-021969:notes:204]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock outstanding during the period. Dilutive income per share is calculated by dividing net income by the weighted average number of shares of common stock used in the basic net income (loss) per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0001564590-21-021969:notes:205]
The following table presents the calculation of net income (loss) per share of basic and diluted (in thousands, except per share data):

[0001564590-21-021969:notes:206]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Net income (loss) |  | $ | 3,472 |  |  | $ | (44,352 | ) |  | $ | (8,390 | ) |  | $ | (105,628 | ) |
| Weighted-average shares used in per share calculation - basic |  |  | 124,788 |  |  |  | 119,162 |  |  |  | 123,252 |  |  |  | 119,648 |  |
| Options to purchase common stock |  |  | 549 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Restricted stock units |  |  | 4,651 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted-average shares used in per share calculation - diluted |  |  | 129,988 |  |  |  | 119,162 |  |  |  | 123,252 |  |  |  | 119,648 |  |
| Net income (loss) per share - basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.03 |  |  | $ | (0.37 | ) |  | $ | (0.07 | ) |  | $ | (0.88 | ) |
| Net income (loss) per share - diluted |  | $ | 0.03 |  |  | $ | (0.37 | ) |  | $ | (0.07 | ) |  | $ | (0.88 | ) |

[0001564590-21-021969:notes:207]
The following securities were excluded from the computation of net income (loss) per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001564590-21-021969:notes:208]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Options to purchase common stock |  |  | 637 |  |  |  | 3,090 |  |  |  | 1,864 |  |  |  | 3,055 |  |
| Restricted stock units |  |  | 17 |  |  |  | 9,204 |  |  |  | 8,994 |  |  |  | 9,676 |  |
| Employee Stock Purchase Plan shares |  |  | 480 |  |  |  | 742 |  |  |  | 158 |  |  |  | 742 |  |
| Total shares excluded |  |  | 1,134 |  |  |  | 13,036 |  |  |  | 11,016 |  |  |  | 13,473 |  |
