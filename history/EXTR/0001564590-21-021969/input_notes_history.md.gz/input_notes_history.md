# EXTR note change history — 0001564590-21-005006 → 0001564590-21-021969


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001564590-21-021969:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2021, the Company had commitments to purchase $33.0 million of inventory and other services.
  (was, 2021-02-09, similarity 0.9896):
[0001564590-21-005006:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2020, the Company had commitments to purchase $38.0 million of inventory and other services.

- added (2021-04-29):
[0001564590-21-021969:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material,

- added (2021-04-29):
[0001564590-21-021969:note_history:3]
then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. An adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2021-04-29):
[0001564590-21-021969:note_history:4]
All currency conversions in this Legal Proceedings section are as of March 31, 2021.
  (was, 2021-02-09, similarity 0.9434):
[0001564590-21-005006:note_history:4]
All currency conversions in this Legal Proceedings section are as of December 31, 2020.

- changed (2021-04-29):
[0001564590-21-021969:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The Federal Circuit Court ruled for XR on November 25, 2020 in Cisco’s appeal of the ‘231 PTAB decision, and the stay of the District Court case has been lifted.
  (was, 2021-02-09, similarity 0.9285):
[0001564590-21-005006:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The Federal Circuit Court ruled for XR on November 25, 2020 in Cisco’s appeal of the ‘231 PTAB decision, and a status conference has been set for February 22, 2021. The Company believes the claims are without merit and intends to defend them vigorously.

- changed (2021-04-29):
[0001564590-21-021969:note_history:6]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce an injunction against the Company. The Company filed a notice of appeal on November 12, 2020 and the matter is proceeding through the appellate process.
  (was, 2021-02-09, similarity 0.9977):
[0001564590-21-005006:note_history:6]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, and the Court issued an infringement decision against the Company and granted to Orckit the right to enforce an injunction against the Company. The Company filed a notice of appeal on November 12, 2020 and the matter is proceeding through the appellate process.

- added (2021-04-29):
[0001564590-21-021969:note_history:7]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). The parties have reached a tentative agreement to settle the matter for an immaterial amount.

- changed (2021-04-29):
[0001564590-21-021969:note_history:8]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware. The lawsuit alleges direct infringement of four U.S. patents. DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees. DataCloud amended the complaint on November 13, 2020, asserting claims of direct, induced, and willful infringement of four new patents, and filed a second amended complaint on February 12, 2021. The parties settled this case on March 31, 2021 for an immaterial amount and the matter was dismissed in the District Court on April 9, 2021.
  (was, 2021-02-09, similarity 0.6809):
[0001564590-21-005006:note_history:8]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware. The lawsuit alleges direct infringement of four U.S. patents. DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees. DataCloud amended the complaint on November 13, 2020, asserting claims of direct, induced, and willful infringement of four new patents, and has petitioned to file a second amended complaint by February 12, 2021. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- changed (2021-04-29):
[0001564590-21-021969:note_history:9]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a petition to transfer the case to the Northern District of California. This motion is pending.
  (was, 2021-02-09, similarity 0.7188):
[0001564590-21-005006:note_history:9]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- added (2021-04-29):
[0001564590-21-021969:note_history:10]
On January 14, 2021, Hanger Solutions, LLC (“Hanger”) filed a patent infringement lawsuit against the Company in the District of Delaware. The complaint alleges infringement of three U.S. patents. The parties settled this case on March 31, 2021 for an immaterial amount and the matter was dismissed in the District Court on April 12, 2021.

- changed (2021-04-29):
[0001564590-21-021969:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.
  (was, 2021-02-09, similarity 0.7159):
[0001564590-21-005006:note_history:11]
liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- removed (2021-04-29):
[0001564590-21-005006:note_history:12]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- removed (2021-04-29):
[0001564590-21-005006:note_history:13]
The Company believes that all claims in both cases filed by Orckit are without merit and intends to defend them vigorously.

- removed (2021-04-29):
[0001564590-21-005006:note_history:14]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). A first and second hearing in the trial were held and the Court subsequently ordered the parties to retain a third-party appraisal center to analyze and report to the Court on various technical aspects of the case and has set out the scope of the appraisal.  The appraisal has not been conducted yet, and the Court has not issued a decision.  The Company believes that the claims are without merit and intends to defend them vigorously.

- removed (2021-04-29):
[0001564590-21-005006:note_history:15]
American Patents LLC v. Extreme Networks, Inc.

- removed (2021-04-29):
[0001564590-21-005006:note_history:16]
On August 14, 2020, American Patents LLC filed a patent infringement lawsuit against the Company in the Western District of Texas. The complaint alleged direct and indirect infringement of certain U.S. patents and seeks injunctive relief, unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The parties have settled the case for a non-material amount, and the case was dismissed on November 16, 2020.

- removed (2021-04-29):
[0001564590-21-005006:note_history:17]
On January 14, 2021, Hanger Solutions, LLC (“Hanger”) filed a patent infringement lawsuit against the Company in the District of Delaware. The complaint alleges infringement of three U.S. patents. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- removed (2021-04-29):
[0001564590-21-005006:note_history:18]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001564590-21-021969:note_history:19]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2021. The results of operations for the three and nine months ended March 31, 2021 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.
  (was, 2021-02-09, similarity 0.9404):
[0001564590-21-005006:note_history:19]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2020. The results of operations for the three and six months ended December 31, 2020 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001564590-21-021969:note_history:20]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures but does not believe there will be a material impact on the Company’s financial statements outside of potentially the change to recognition of state income and franchise taxes under the new Accounting Standard.
  (was, 2021-02-09, similarity 0.8716):
[0001564590-21-005006:note_history:20]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001564590-21-021969:note_history:21]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 23,750 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,436 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 21,314 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 327,750 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,348 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 322,402 |  |  |  | 394,585 |  |
| Total debt |  | $ | 343,716 |  |  | $ | 411,101 |  |
  (was, 2021-02-09, similarity 0.9886):
[0001564590-21-005006:note_history:21]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 21,375 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,463 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 18,912 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 334,875 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,934 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 328,941 |  |  |  | 394,585 |  |
| Total debt |  | $ | 347,853 |  |  | $ | 411,101 |  |

- added (2021-04-29):
[0001564590-21-021969:note_history:22]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment

- changed (2021-04-29):
[0001564590-21-021969:note_history:23]
and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirements and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5%, and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.
  (was, 2021-02-09, similarity 0.8272):
[0001564590-21-005006:note_history:23]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirements and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5%, and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.

- added (2021-04-29):
[0001564590-21-021969:note_history:24]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

- added (2021-04-29):
[0001564590-21-021969:note_history:25]
The Second Amendment provides for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the 12 month period ended March 31, 2021 the Company’s financial performance is in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company will file a Suspension Early Termination Notice and Covenant Certificate with the loan administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance will result in the Company’s Eurodollar loan spread to decrease from 4.5% suspension period rate, to 2.75% and unused facility commitment fee will decrease from 0.4% to 0.35%, and the limitation on revolver borrowings will be removed effective May 1, 2021 after filing of the certificate with the administrative agent.

- changed (2021-04-29):
[0001564590-21-021969:note_history:26]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of March 31, 2021 was 4.6%.
  (was, 2021-02-09, similarity 0.9877):
[0001564590-21-005006:note_history:26]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of December 31, 2020 was 4.65%.

- changed (2021-04-29):
[0001564590-21-021969:note_history:27]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.6 million for the three months ended March 31, 2021 and 2020, and totaled $2.3 million and $1.8 million for the nine months ended March 31, 2021 and 2020.
  (was, 2021-02-09, similarity 0.8643):
[0001564590-21-005006:note_history:27]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.7 million for the three months ended December 31, 2020 and 2019, and totaled $1.5 million and $1.1 million for the six months ended December 31, 2020 and 2019.

- changed (2021-04-29):
[0001564590-21-021969:note_history:28]
During the six months ended December 31, 2020, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at March 31, 2021. The Company has $55.0 million of availability under the 2019 Revolving Facility as of March 31, 2021.
  (was, 2021-02-09, similarity 0.9406):
[0001564590-21-005006:note_history:28]
During the six months ended December 31, 2020, the Company repaid $55.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million and has no remaining outstanding balance at December 31, 2020.   The Company has $55.0 million of availability under the 2019 Revolving Facility as of December 31, 2020.

- changed (2021-04-29):
[0001564590-21-021969:note_history:29]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2021.
  (was, 2021-02-09, similarity 0.9412):
[0001564590-21-005006:note_history:29]
The Company had $8.8 million of outstanding letters of credit as of December 31, 2020.

- removed (2021-04-29):
[0001564590-21-005006:note_history:30]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001564590-21-021969:note_history:31]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 23,750 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,436 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 21,314 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 327,750 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,348 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 322,402 |  |  |  | 394,585 |  |
| Total debt |  | $ | 343,716 |  |  | $ | 411,101 |  |
  (was, 2021-02-09, similarity 0.9886):
[0001564590-21-005006:note_history:31]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 21,375 |  |  | $ | 19,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,463 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 18,912 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 334,875 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (5,934 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 328,941 |  |  |  | 394,585 |  |
| Total debt |  | $ | 347,853 |  |  | $ | 411,101 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001564590-21-021969:note_history:32]
|  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |
| Other |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |
| Total Americas |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |
| EMEA |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |
| APAC |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |
| Total net revenues |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |
  (was, 2021-02-09, similarity 0.9665):
[0001564590-21-005006:note_history:32]
|  |  | Three Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |
| Other |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |
| Total Americas |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |
| EMEA |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |
| APAC |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |
| Total net revenues |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |

- changed (2021-04-29):
[0001564590-21-021969:note_history:33]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |
| Other |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |
| Total Americas |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |
| EMEA |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |
| APAC |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |
| Total net revenues |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |
  (was, 2021-02-09, similarity 0.9241):
[0001564590-21-005006:note_history:33]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |
| Other |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |
| Total Americas |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |
| EMEA |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |
| APAC |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |
| Total net revenues |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |

- changed (2021-04-29):
[0001564590-21-021969:note_history:34]
For the three months ended March 31, 2021 the Company reflected 11% of its revenues from the Netherlands. For the nine months ended March 31, 2021 the Company reflected 10% of its revenues from the Netherlands.  No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2021 or 2020.
  (was, 2021-02-09, similarity 0.7163):
[0001564590-21-005006:note_history:34]
For the three months ended December 31, 2020 the Company reflected 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020 the Company reflected 10% of its revenues from the Netherlands and 10% of its revenue from Germany.  No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2020 or 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001564590-21-021969:note_history:35]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- changed (2021-04-29):
[0001564590-21-021969:note_history:36]
On March 31, 2021, the Company had $318.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 22 percent of its deferred revenue as revenue in fiscal 2021, an additional 44 percent in fiscal 2022 and 34 percent of the balance thereafter.
  (was, 2021-02-09, similarity 0.9805):
[0001564590-21-005006:note_history:36]
On December 31, 2020, the Company had $309.1 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 40 percent of its deferred revenue as revenue in fiscal 2021, an additional 34 percent in fiscal 2022 and 26 percent of the balance thereafter.

- changed (2021-04-29):
[0001564590-21-021969:note_history:37]
Revenue recognized for the three months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $67.9 million and $64.3 million, respectively. Revenue recognized for the nine months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $158.7 million and $116.7 million, respectively.
  (was, 2021-02-09, similarity 0.9194):
[0001564590-21-005006:note_history:37]
Revenue recognized for the three months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $68.8 million and $67.2 million, respectively. Revenue recognized for the six months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $120.5 million and $90.9 million, respectively.

- changed (2021-04-29):
[0001564590-21-021969:note_history:38]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $10.2 million and $8.1 million at March 31, 2021 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2021 and 2020, was $1.4 million and $1.1 million, respectively. Amortization recognized during the nine months ended March 31, 2021 and 2020, was $3.9 million and $4.1 million, respectively.
  (was, 2021-02-09, similarity 0.9644):
[0001564590-21-005006:note_history:38]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $9.2 million and $8.1 million at December 31, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2020 and 2019, was $1.2 million and $1.5 million, respectively. Amortization recognized during the six months ended December 31, 2020 and 2019, was $2.5 million and $3.0 million, respectively.

- changed (2021-04-29):
[0001564590-21-021969:note_history:39]
|  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |
| Other |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |
| Total Americas |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |
| EMEA |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |
| APAC |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |
| Total net revenues |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |
  (was, 2021-02-09, similarity 0.9665):
[0001564590-21-005006:note_history:39]
|  |  | Three Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |
| Other |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |
| Total Americas |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |
| EMEA |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |
| APAC |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |
| Total net revenues |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |

- changed (2021-04-29):
[0001564590-21-021969:note_history:40]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |
| Other |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |
| Total Americas |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |
| EMEA |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |
| APAC |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |
| Total net revenues |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |
  (was, 2021-02-09, similarity 0.9241):
[0001564590-21-005006:note_history:40]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |
| Other |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |
| Total Americas |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |
| EMEA |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |
| APAC |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |
| Total net revenues |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |

- changed (2021-04-29):
[0001564590-21-021969:note_history:41]
For the three months ended March 31, 2021 the Company reflected 11% of its revenues from the Netherlands. For the nine months ended March 31, 2021 the Company reflected 10% of its revenues from the Netherlands.  No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2021 or 2020.
  (was, 2021-02-09, similarity 0.7163):
[0001564590-21-005006:note_history:41]
For the three months ended December 31, 2020 the Company reflected 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020 the Company reflected 10% of its revenues from the Netherlands and 10% of its revenue from Germany.  No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2020 or 2019.

- added (2021-04-29):
[0001564590-21-021969:note_history:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| Tech Data Corporation |  | 15% |  |  | 19% |  |  | 21% |  |  | 16% |  |
| Jenne Corporation |  | 16% |  |  | * |  |  | 14% |  |  | 13% |  |
| Westcon Group Inc. |  | 19% |  |  | 19% |  |  | 17% |  |  | 14% |  |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

- changed (2021-04-29):
[0001564590-21-021969:note_history:43]
|  |  | March 31, 2021 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  | * |  |  | 23% |  |
| Jenne Corporation |  | 19% |  |  | 25% |  |
| Westcon Group Inc. |  | 16% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |
  (was, 2021-02-09, similarity 0.9679):
[0001564590-21-005006:note_history:43]
|  |  | December 31, 2020 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  | 20% |  |  | 23% |  |
| Jenne Corporation |  | 16% |  |  | 25% |  |
| Westcon Group Inc. |  | 18% |  |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |

- removed (2021-04-29):
[0001564590-21-005006:note_history:44]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- removed (2021-04-29):
[0001564590-21-005006:note_history:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |  | December 31, 2020 |  |  | December 31, 2019 |  |
| Tech Data Corporation |  | 21% |  |  | 14% |  |  | 24% |  |  | 15% |  |
| Jenne Corporation |  | 11% |  |  | 18% |  |  | 13% |  |  | 16% |  |
| Westcon Group Inc. |  | 19% |  |  | 15% |  |  | 16% |  |  | 13% |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001564590-21-021969:note_history:46]
On March 31, 2021, the Company had $318.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 22 percent of its deferred revenue as revenue in fiscal 2021, an additional 44 percent in fiscal 2022 and 34 percent of the balance thereafter.
  (was, 2021-02-09, similarity 0.9805):
[0001564590-21-005006:note_history:46]
On December 31, 2020, the Company had $309.1 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 40 percent of its deferred revenue as revenue in fiscal 2021, an additional 34 percent in fiscal 2022 and 26 percent of the balance thereafter.

- changed (2021-04-29):
[0001564590-21-021969:note_history:47]
Revenue recognized for the three months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $67.9 million and $64.3 million, respectively. Revenue recognized for the nine months ended March 31, 2021 and 2020 that was included in the deferred revenue balance at the beginning of each period was $158.7 million and $116.7 million, respectively.
  (was, 2021-02-09, similarity 0.9194):
[0001564590-21-005006:note_history:47]
Revenue recognized for the three months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $68.8 million and $67.2 million, respectively. Revenue recognized for the six months ended December 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $120.5 million and $90.9 million, respectively.

- changed (2021-04-29):
[0001564590-21-021969:note_history:48]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $10.2 million and $8.1 million at March 31, 2021 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2021 and 2020, was $1.4 million and $1.1 million, respectively. Amortization recognized during the nine months ended March 31, 2021 and 2020, was $3.9 million and $4.1 million, respectively.
  (was, 2021-02-09, similarity 0.9644):
[0001564590-21-005006:note_history:48]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $9.2 million and $8.1 million at December 31, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2020 and 2019, was $1.2 million and $1.5 million, respectively. Amortization recognized during the six months ended December 31, 2020 and 2019, was $2.5 million and $3.0 million, respectively.

- changed (2021-04-29):
[0001564590-21-021969:note_history:49]
|  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,873 |  | $ | 62,172 |  | $ | 117,045 |  |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |
| Other |  |  | 8,926 |  |  | 3,730 |  |  | 12,656 |  |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |
| Total Americas |  |  | 63,799 |  |  | 65,902 |  |  | 129,701 |  |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |
| EMEA |  |  | 65,210 |  |  | 34,127 |  |  | 99,337 |  |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |
| APAC |  |  | 3,569 |  |  | 20,793 |  |  | 24,362 |  |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |
| Total net revenues |  | $ | 132,578 |  | $ | 120,822 |  | $ | 253,400 |  |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |
  (was, 2021-02-09, similarity 0.9665):
[0001564590-21-005006:note_history:49]
|  |  | Three Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 46,506 |  | $ | 58,744 |  | $ | 105,250 |  |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |
| Other |  |  | 8,950 |  |  | 3,648 |  |  | 12,598 |  |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |
| Total Americas |  |  | 55,456 |  |  | 62,392 |  |  | 117,848 |  |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |
| EMEA |  |  | 69,602 |  |  | 34,220 |  |  | 103,822 |  |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |
| APAC |  |  | 2,793 |  |  | 17,665 |  |  | 20,458 |  |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |
| Total net revenues |  | $ | 127,851 |  | $ | 114,277 |  | $ | 242,128 |  |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |

- changed (2021-04-29):
[0001564590-21-021969:note_history:50]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 162,049 |  | $ | 178,263 |  | $ | 340,312 |  |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |
| Other |  |  | 26,117 |  |  | 11,468 |  |  | 37,585 |  |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |
| Total Americas |  |  | 188,166 |  |  | 189,731 |  |  | 377,897 |  |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |
| EMEA |  |  | 182,341 |  |  | 101,923 |  |  | 284,264 |  |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |
| APAC |  |  | 11,413 |  |  | 57,756 |  |  | 69,169 |  |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |
| Total net revenues |  | $ | 381,920 |  | $ | 349,410 |  | $ | 731,330 |  |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |
  (was, 2021-02-09, similarity 0.9241):
[0001564590-21-005006:note_history:50]
|  |  | Six Months Ended |  |
|  |  | December 31, 2020 |  |  | December 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 107,176 |  | $ | 116,091 |  | $ | 223,267 |  |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |
| Other |  |  | 17,191 |  |  | 7,738 |  |  | 24,929 |  |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |
| Total Americas |  |  | 124,367 |  |  | 123,829 |  |  | 248,196 |  |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |
| EMEA |  |  | 117,131 |  |  | 67,796 |  |  | 184,927 |  |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |
| APAC |  |  | 7,844 |  |  | 36,963 |  |  | 44,807 |  |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |
| Total net revenues |  | $ | 249,342 |  | $ | 228,588 |  | $ | 477,930 |  |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |

- changed (2021-04-29):
[0001564590-21-021969:note_history:51]
For the three months ended March 31, 2021 the Company reflected 11% of its revenues from the Netherlands. For the nine months ended March 31, 2021 the Company reflected 10% of its revenues from the Netherlands.  No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2021 or 2020.
  (was, 2021-02-09, similarity 0.7163):
[0001564590-21-005006:note_history:51]
For the three months ended December 31, 2020 the Company reflected 11% of its revenues from the Netherlands and 11% of its revenues from Germany. For the six months ended December 31, 2020 the Company reflected 10% of its revenues from the Netherlands and 10% of its revenue from Germany.  No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2020 or 2019.
