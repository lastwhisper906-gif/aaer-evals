# EXTR 8-K — 0001564590-22-026574 filed 2022-07-27

## item codes, every 8-K on or before 2022-08-29

- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2022-08-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-22-026574:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-22-026574:8k_2_02:2]
extr-ex991_6.htm

[0001564590-22-026574:8k_2_02:3]
Exhibit 99.1

[0001564590-22-026574:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-22-026574:8k_2_02:5]
Extreme Networks Reports Fiscal Year and Fourth Quarter 2022 Financial Results

[0001564590-22-026574:8k_2_02:6]
Record Bookings and Double-Digit Revenue Growth in FY22

[0001564590-22-026574:8k_2_02:7]
Reiterates FY23 Revenue Growth of 10-15%

[0001564590-22-026574:8k_2_02:8]
Morrisville, NC, July 27, 2022 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal year and fourth fiscal quarter ended June 30, 2022.

[0001564590-22-026574:8k_2_02:9]
Fiscal Year 2022 Results:

[0001564590-22-026574:8k_2_02:10]
|  | • | Revenue $1.1 billion, up 10% from $1.0 billion in fiscal 2021 |

[0001564590-22-026574:8k_2_02:11]
|  | • | GAAP EPS $0.33, up from $0.02 in fiscal 2021 |

[0001564590-22-026574:8k_2_02:12]
|  | • | Non-GAAP EPS $0.77, up from $0.57 in fiscal 2021 |

[0001564590-22-026574:8k_2_02:13]
|  | • | GAAP operating margin 5.8% up from 3.4% in fiscal 2021 |

[0001564590-22-026574:8k_2_02:14]
|  | • | Non-GAAP operating margin 12.2% up from 10.9% in fiscal 2021 |

[0001564590-22-026574:8k_2_02:15]
|  | • | Executed $45.0 million in share repurchase during the year |

[0001564590-22-026574:8k_2_02:16]
Fiscal Fourth Quarter Results:

[0001564590-22-026574:8k_2_02:17]
|  | • | Revenue $278.2 million, flat year-over-year, and down 3% quarter-over-quarter |

[0001564590-22-026574:8k_2_02:18]
|  | • | SaaS ARR* $103 million, up 47% year-over-year, and up 8% quarter-over-quarter |

[0001564590-22-026574:8k_2_02:19]
|  | • | GAAP EPS $0.04, compared to $0.08 in Q4 last year |

[0001564590-22-026574:8k_2_02:20]
|  | • | Non-GAAP EPS $0.15, compared to $0.19 in Q4 last year |

[0001564590-22-026574:8k_2_02:21]
|  | • | GAAP gross margin 55.4% compared to 57.9% in Q4 last year |

[0001564590-22-026574:8k_2_02:22]
|  | • | Non-GAAP gross margin 57.0% compared to 60.5% in Q4 last year |

[0001564590-22-026574:8k_2_02:23]
|  | • | GAAP operating margin 3.8% compared to 6.3% in Q4 last year |

[0001564590-22-026574:8k_2_02:24]
|  | • | Non-GAAP operating margin 9.6% compared to 13.4% in Q4 last year |

[0001564590-22-026574:8k_2_02:25]
|  | • | Net cash provided by operating activities of $64.1 million |

[0001564590-22-026574:8k_2_02:26]
|  | • | Free cash flow of $59.8 million |

[0001564590-22-026574:8k_2_02:27]
“For FY22 we achieved double-digit growth in both bookings and revenue due to strong demand for our differentiated enterprise networking and 5G infrastructure solutions. Bookings grew 24%, revenue exceeded $1.1 billion for the first time, and we exited the year with a record product backlog of $513 million. We continue to take market share based on our industry-leading cloud innovation with new AIOps and ExtremeCloud SD-WAN solutions that greatly simplify network

[0001564590-22-026574:8k_2_02:28]
management for customers. I am proud of the hard work and tenacity and of our teams that produced these outstanding results,” stated Ed Meyercord, President and CEO of Extreme.

[0001564590-22-026574:8k_2_02:29]
“Our teams continue to see unabated market demand, as networking projects remain a priority for our global customers. This is evidenced by our FY23 funnel of new projects, which is up double-digits from last year. Our differentiated Cloud and Fabric solutions are driving more competitive wins today than ever before. Our new ExtremeCloud SD-WAN and AIOps solutions provide us new ways to drive long-term subscription growth,” concluded Meyercord.

[0001564590-22-026574:8k_2_02:30]
Extreme’s Chief Financial Officer Remi Thomas, added, “After another quarter of solid execution, we achieved double-digit growth for the year and improved operating margins, even in the current supply chain environment. We crossed the $100 million mark in SaaS ARR driven by the strength of our Cloud offerings. Finally, our strong cash flow performance during the quarter allowed us to return another $20 million to shareholders in the form of share buybacks.”

[0001564590-22-026574:8k_2_02:31]
“As we enter FY23, our record backlog, combined with the expected improvement in the supply chain environment through the course of the year gives us further confidence that we can grow the topline between 10-15%, improve our gross margin to exit the year above 60%, and deliver an operating margin between 10-15%,” concluded Thomas.

[0001564590-22-026574:8k_2_02:32]
Recent Key Highlights:

[0001564590-22-026574:8k_2_02:33]
|  | • | In the fourth quarter we introduced a suite of solutions designed to make networking more intelligent, flexible and secure. |

[0001564590-22-026574:8k_2_02:34]
|  | • | The Universal 5720 switch is the latest in a line of universal platforms, which makes it easy for customers to run their networking operating system of choice while preserving hardware and associated licenses. |

[0001564590-22-026574:8k_2_02:35]
|  | • | ExtremeCloud SD-WAN helps customers connect applications in the cloud while simplifying management, enhancing security and improving application performance. |

[0001564590-22-026574:8k_2_02:36]
|  | • | Finally, AIOps with the industry’s First Networking Digital Twin and Explainable AI/ML helps customers dramatically simplify the staging, validation and deployment of switches and access points across their network. |

[0001564590-22-026574:8k_2_02:37]
|  | • | We continue to make significant progress with professional sports organizations and venues. In May, we announced Liverpool Football Club (Liverpool FC) selected Extreme as its Official Wi-Fi Network Solutions Provider and Official Wi-Fi Analytics Provider in a multiyear partnership. Further, Verizon Business named Extreme Networks as a technology partner within Verizon’s international stadium partner ecosystem where the two companies will deliver High-Density (HD) Wi-Fi to future event venues. |

[0001564590-22-026574:8k_2_02:38]
|  | • | Higher education organizations including Chipola College, North Carolina A&T State, and St. Petersburg College selected Extreme to provide a secure, resilient network. Extreme makes it easy for these schools to support students both online and within the physical classroom without complicating network management, impacting security or requiring additional IT headcount. |

[0001564590-22-026574:8k_2_02:39]
|  | • | The City of Breda in the Netherlands is using Extreme solutions to improve digital government services and leverage network analytics to make data-driven decisions regarding the needs of its |

[0001564590-22-026574:8k_2_02:40]
|  |  | citizens. The city’s datacenter run entirely on Extreme Fabric Connect and is managed through ExtremeCloud, enabling the city to easily deploy both temporary and permanent network infrastructure and simplify network management for the IT team. |

[0001564590-22-026574:8k_2_02:41]
|  | • | LG Electronics, a global manufacturer of consumer electronic and home appliances, chose Extreme Networks to upgrade its end-to-end network at its headquarters in the Republic of Korea. With high-performance Wi-Fi 6E throughout the building as well as easy-to-deploy Fabric and Universal switching solutions, LG can ensure a next-generation connectivity experience for all employees and users as well as future-proof its network for further upgrades and expansions. |

[0001564590-22-026574:8k_2_02:42]
|  | • | In FY22, Extreme completed MLB stadium network deployments for the Boston Red Sox, Chicago White Sox, Detroit Tigers, Kansas City Royals, New York Mets, Pittsburgh Pirates and Seattle Mariners. Each stadium is equipped with new Wi-Fi 6 access points, delivering an improved fan-facing Wi-Fi experience, and network analytics that will help to customize in-stadium experiences and streamline stadium operations. During Extreme’s recent Investor Day hosted at the MLB HQ in New York City, MLB Chief Operations and Strategy Officer Chris Marinak said, “The infrastructure we have from Extreme really fuels the backend of what happens in a ballpark and fan engagement.” |

[0001564590-22-026574:8k_2_02:43]
|  | • | Italian retailer Unicoop Firenze deployed ExtremeCloud SD-WAN to deliver a superior in-store experience for customers at over 100 of its stores. Unicoop Firenze can now prioritize critical traffic like point-of-sales transactions and other applications, making it easy for customers to check in and out and seamlessly throughout the shopping experience. Additionally, IT teams have a single view into the network, making it easy to manage and troubleshoot issues before they become disruptive. |

[0001564590-22-026574:8k_2_02:44]
Fiscal Q4 2022 Financial Metrics:

[0001564590-22-026574:8k_2_02:45]
(in millions, except percentages and per share information)

[0001564590-22-026574:8k_2_02:46]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | Change |  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | Change |  |
| Product |  | $ | 187.1 |  |  | $ | 195.8 |  |  | $ | (8.7 | ) |  | $ | 761.7 |  |  | $ | 699.4 |  |  | $ | 62.3 |  |
| Service and subscription |  |  | 91.1 |  |  |  | 82.3 |  |  |  | 8.8 |  |  |  | 350.6 |  |  |  | 310.0 |  |  |  | 40.6 |  |
| Total net revenue |  | $ | 278.2 |  |  | $ | 278.1 |  |  | $ | 0.1 |  |  | $ | 1,112.3 |  |  | $ | 1,009.4 |  |  | $ | 102.9 |  |
| Gross margin |  |  | 55.4 | % |  |  | 57.9 | % |  |  | (2.5 | )% |  |  | 56.6 | % |  |  | 58.0 | % |  |  | (1.4 | )% |
| Operating margin |  |  | 3.8 | % |  |  | 6.3 | % |  |  | (2.6 | )% |  |  | 5.8 | % |  |  | 3.4 | % |  |  | 2.4 | % |
| Net income |  | $ | 5.4 |  |  | $ | 10.3 |  |  | $ | (4.9 | ) |  | $ | 44.3 |  |  | $ | 1.9 |  |  | $ | 42.4 |  |
| Net income per diluted share |  | $ | 0.04 |  |  | $ | 0.08 |  |  | $ | (0.04 | ) |  | $ | 0.33 |  |  | $ | 0.02 |  |  | $ | 0.31 |  |

[0001564590-22-026574:8k_2_02:47]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | Change |  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | Change |  |
| Product |  | $ | 187.1 |  |  | $ | 195.8 |  |  | $ | (8.7 | ) |  | $ | 761.7 |  |  | $ | 699.4 |  |  | $ | 62.3 |  |
| Service and subscription |  |  | 91.1 |  |  |  | 82.3 |  |  |  | 8.8 |  |  |  | 350.6 |  |  |  | 310.0 |  |  |  | 40.6 |  |
| Total net revenue |  | $ | 278.2 |  |  | $ | 278.1 |  |  | $ | 0.1 |  |  | $ | 1,112.3 |  |  | $ | 1,009.4 |  |  | $ | 102.9 |  |
| Gross margin |  |  | 57.0 | % |  |  | 60.5 | % |  |  | (3.5 | )% |  |  | 58.4 | % |  |  | 60.8 | % |  |  | (2.4 | )% |
| Operating margin |  |  | 9.6 | % |  |  | 13.4 | % |  |  | (3.8 | )% |  |  | 12.2 | % |  |  | 10.9 | % |  |  | 1.3 | % |
| Net income |  | $ | 19.6 |  |  | $ | 24.6 |  |  | $ | (5.0 | ) |  | $ | 103.5 |  |  | $ | 72.2 |  |  | $ | 31.2 |  |
| Net income per diluted share |  | $ | 0.15 |  |  | $ | 0.19 |  |  | $ | (0.04 | ) |  | $ | 0.77 |  |  | $ | 0.57 |  |  | $ | 0.20 |  |

[0001564590-22-026574:8k_2_02:48]
|  | • | Q4 ending cash balance was $194.5 million, an increase of $27.9 million from the end of Q3. This was primarily driven by operating cash flow generation of $64.1 million, partially offset by cash usage of $31.5 million for financing activities, which were primarily share repurchases, payments against our term loan, and $4.3 million for capital expenditures. |

[0001564590-22-026574:8k_2_02:49]
|  | • | During Q4, we repurchased a total of 2.05 million shares of our common stock on the open market at a total cost of $20.0 million with a weighted average price of $9.74 per share. In May 2022, Extreme’s Board of Directors authorized an increase to our share repurchase authorization to $200.0 million over a three-year period commencing July 1, 2022. |

[0001564590-22-026574:8k_2_02:50]
|  | • | Q4 accounts receivable balance was $184.1 million, an increase of $21.1 million from the end of Q3 and an increase of $27.6 million from Q4 last year. Days sales outstanding was 60 days, an increase of 9 days from Q3 and Q4 last year. |

[0001564590-22-026574:8k_2_02:51]
|  | • | Q4 ending inventory was $49.2 million, an increase of $11.5 million from Q3 and an increase of $16.3 million from Q4 last year. The quarter-over-quarter increase was primarily driven by an increase in finished goods inventory. |

[0001564590-22-026574:8k_2_02:52]
|  | • | Q4 ending gross debt** was $308.6 million, a decrease of $7.1 million from the prior quarter. The $38.1 million decrease from Q4 last year resulted primarily from principal payments on our term loan. Q4 ending net debt*** was $114.1 million, a decrease of $35.1 million from $149.2 million in Q3. |

[0001564590-22-026574:8k_2_02:53]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-22-026574:8k_2_02:54]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Cash flow provided by operations | $ | 64,122 |  |  | $ | 57,039 |  |  | $ | 128,177 |  |  | $ | 144,535 |  |
| Less: Property and equipment capital expenditures |  | (4,303 | ) |  |  | (4,858 | ) |  |  | (15,433 | ) |  |  | (17,176 | ) |
| Total free cash flow | $ | 59,819 |  |  | $ | 52,181 |  |  | $ | 112,744 |  |  | $ | 127,359 |  |

[0001564590-22-026574:8k_2_02:55]
*SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud™ IQ (XIQ) and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. This is a change to our methodology from last quarter which was based on the annualized value of all active contracts as of the end of the quarter. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationship with existing customers. SaaS ARR should be viewed independently of revenue, deferred revenue and other U.S. GAAP accounting. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0001564590-22-026574:8k_2_02:56]
**Gross Debt: Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0001564590-22-026574:8k_2_02:57]
***Net Debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-22-026574:8k_2_02:58]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 308.6 |  |  | $ | 194.5 |  |  | $ | 114.1 |  |

[0001564590-22-026574:8k_2_02:59]
Business Outlook:

[0001564590-22-026574:8k_2_02:60]
For its first quarter of fiscal 2023, ending September 30, 2022, the Company is targeting:

[0001564590-22-026574:8k_2_02:61]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ1'23 Guidance – GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 279.0 |  |  | $ | 289.0 |  |
| Gross margin |  | 55.4 | % |  |  | 57.4 | % |
| Operating expenses | $ | 141.7 |  |  | $ | 145.6 |  |
| Operating margin |  | 4.6 | % |  |  | 7.0 | % |
| Net income | $ | 6.3 |  |  | $ | 13.8 |  |
| Net income per diluted share | $ | 0.05 |  |  | $ | 0.10 |  |
| Shares outstanding used in calculating GAAP EPS |  | 132.0 |  |  |  | 132.0 |  |
| FQ1’23 Guidance – Non–GAAP |  |  |  |  |  |  |  |
| Total net revenue | $ | 279.0 |  |  | $ | 289.0 |  |
| Gross margin |  | 57.0 | % |  |  | 59.0 | % |
| Operating expenses | $ | 130.7 |  |  | $ | 134.2 |  |
| Operating margin |  | 10.1 | % |  |  | 12.6 | % |
| Net income | $ | 19.9 |  |  | $ | 26.5 |  |
| Net income per diluted share | $ | 0.15 |  |  | $ | 0.20 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 132.0 |  |  |  | 132.0 |  |

[0001564590-22-026574:8k_2_02:62]
The following table shows the GAAP to non-GAAP reconciliation for Q1 FY’23 guidance:

[0001564590-22-026574:8k_2_02:63]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.4% - 57.4% |  |  | 4.6% - 7.0% |  |  | $0.05 - $0.10 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.0% |  |  | 1.1% |  |  |  | 0.02 |  |
| Share-based compensation | 0.2% |  |  | 3.7% |  |  |  | 0.08 |  |
| Restructuring | - |  |  | 0.1% |  |  |  | 0.00 |  |
| Amortization of non-product intangibles | 0.4% |  |  | 0.6% |  |  |  | 0.01 |  |
| Tax effect of non-GAAP adjustments | - |  |  | - |  |  |  | (0.01) |  |
| Non-GAAP | 57.0% - 59.0% |  |  | 10.1% - 12.6% |  |  | $0.15 - $0.20 |  |

[0001564590-22-026574:8k_2_02:64]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-22-026574:8k_2_02:65]
Conference Call:

[0001564590-22-026574:8k_2_02:66]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the fourth fiscal quarter results as well as the business outlook for the first quarter ending September 30, 2022, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call by phone, please go to this link (Extreme Networks Q4'22 Earnings Registration Link) and you will be provided with dial in details. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time. The encore recording will be available for at least 7 days following the call.

[0001564590-22-026574:8k_2_02:67]
About Extreme:

[0001564590-22-026574:8k_2_02:68]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0001564590-22-026574:8k_2_02:69]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0001564590-22-026574:8k_2_02:70]
Non-GAAP Financial Measures:

[0001564590-22-026574:8k_2_02:71]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, and restructuring charges.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's

[0001564590-22-026574:8k_2_02:72]
marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-22-026574:8k_2_02:73]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-22-026574:8k_2_02:74]
Forward-Looking Statements:

[0001564590-22-026574:8k_2_02:75]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2021, Quarterly Reports on Form 10-Q for the quarters ended September 30, 2021, December 31, 2021, and March 31, 2022 , and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-22-026574:8k_2_02:76]
###

[0001564590-22-026574:8k_2_02:77]
EXTREME NETWORKS, INC.

[0001564590-22-026574:8k_2_02:78]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-22-026574:8k_2_02:79]
(In thousands, except per share amounts)

[0001564590-22-026574:8k_2_02:80]
(Unaudited)

[0001564590-22-026574:8k_2_02:81]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 194,522 |  |  | $ | 246,894 |  |
| Accounts receivable, net |  |  | 184,097 |  |  |  | 156,476 |  |
| Inventories |  |  | 49,231 |  |  |  | 32,885 |  |
| Prepaid expenses and other current assets |  |  | 61,239 |  |  |  | 51,340 |  |
| Total current assets |  |  | 489,089 |  |  |  | 487,595 |  |
| Property and equipment, net |  |  | 49,578 |  |  |  | 55,004 |  |
| Operating lease right-of-use assets, net |  |  | 36,454 |  |  |  | 36,927 |  |
| Intangible assets, net |  |  | 32,515 |  |  |  | 36,038 |  |
| Goodwill |  |  | 400,144 |  |  |  | 331,159 |  |
| Other assets |  |  | 60,730 |  |  |  | 63,370 |  |
| Total assets |  | $ | 1,068,510 |  |  | $ | 1,010,093 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,305 and $2,404, respectively |  | $ | 33,349 |  |  | $ | 23,721 |  |
| Accounts payable |  |  | 84,338 |  |  |  | 60,142 |  |
| Accrued compensation and benefits |  |  | 53,710 |  |  |  | 71,610 |  |
| Accrued warranty |  |  | 10,852 |  |  |  | 11,623 |  |
| Current portion, operating lease liabilities |  |  | 13,956 |  |  |  | 18,743 |  |
| Current portion, deferred revenue |  |  | 238,262 |  |  |  | 212,412 |  |
| Other accrued liabilities |  |  | 65,714 |  |  |  | 57,449 |  |
| Total current liabilities |  |  | 500,181 |  |  |  | 455,700 |  |
| Deferred revenue, less current portion |  |  | 163,357 |  |  |  | 133,172 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $2,986 and $4,760, respectively |  |  | 270,570 |  |  |  | 315,865 |  |
| Operating lease liabilities, less current portion |  |  | 33,256 |  |  |  | 32,515 |  |
| Deferred income taxes |  |  | 7,717 |  |  |  | 3,828 |  |
| Other long-term liabilities |  |  | 3,086 |  |  |  | 14,545 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 139,742 and 133,279 shares issued, respectively; 129,263 and 126,682 shares outstanding, respectively |  |  | 140 |  |  |  | 133 |  |
| Additional paid-in-capital |  |  | 1,115,416 |  |  |  | 1,078,602 |  |
| Accumulated other comprehensive loss |  |  | (3,055 | ) |  |  | (2,811 | ) |
| Accumulated deficit |  |  | (934,072 | ) |  |  | (978,343 | ) |
| Treasury stock at cost, 10,479 and 6,597 shares, respectively |  |  | (88,086 | ) |  |  | (43,113 | ) |
| Total stockholders’ equity |  |  | 90,343 |  |  |  | 54,468 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,068,510 |  |  | $ | 1,010,093 |  |

[0001564590-22-026574:8k_2_02:82]
EXTREME NETWORKS, INC.

[0001564590-22-026574:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-22-026574:8k_2_02:84]
(In thousands, except per share amounts)

[0001564590-22-026574:8k_2_02:85]
(Unaudited)

[0001564590-22-026574:8k_2_02:86]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 187,085 |  |  | $ | 195,821 |  |  | $ | 761,721 |  |  | $ | 699,396 |  |
| Service and subscription |  |  | 91,111 |  |  |  | 82,267 |  |  |  | 350,600 |  |  |  | 310,022 |  |
| Total net revenues |  |  | 278,196 |  |  |  | 278,088 |  |  |  | 1,112,321 |  |  |  | 1,009,418 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 96,103 |  |  |  | 86,116 |  |  |  | 360,562 |  |  |  | 309,958 |  |
| Service and subscription |  |  | 27,902 |  |  |  | 30,872 |  |  |  | 121,821 |  |  |  | 114,337 |  |
| Total cost of revenues |  |  | 124,005 |  |  |  | 116,988 |  |  |  | 482,383 |  |  |  | 424,295 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 90,982 |  |  |  | 109,705 |  |  |  | 401,159 |  |  |  | 389,438 |  |
| Service and subscription |  |  | 63,209 |  |  |  | 51,395 |  |  |  | 228,779 |  |  |  | 195,685 |  |
| Total gross profit |  |  | 154,191 |  |  |  | 161,100 |  |  |  | 629,938 |  |  |  | 585,123 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 45,130 |  |  |  | 49,376 |  |  |  | 190,591 |  |  |  | 196,995 |  |
| Sales and marketing |  |  | 80,538 |  |  |  | 74,886 |  |  |  | 294,470 |  |  |  | 276,841 |  |
| General and administrative |  |  | 16,103 |  |  |  | 17,357 |  |  |  | 68,697 |  |  |  | 66,201 |  |
| Acquisition and integration costs |  |  | 553 |  |  |  | — |  |  |  | 7,009 |  |  |  | 1,975 |  |
| Restructuring and related charges |  |  | 770 |  |  |  | 504 |  |  |  | 1,748 |  |  |  | 2,625 |  |
| Amortization of intangibles |  |  | 639 |  |  |  | 1,406 |  |  |  | 3,235 |  |  |  | 6,110 |  |
| Total operating expenses |  |  | 143,733 |  |  |  | 143,529 |  |  |  | 565,750 |  |  |  | 550,747 |  |
| Operating income |  |  | 10,458 |  |  |  | 17,571 |  |  |  | 64,188 |  |  |  | 34,376 |  |
| Interest income |  |  | 110 |  |  |  | 71 |  |  |  | 412 |  |  |  | 352 |  |
| Interest expense |  |  | (3,039 | ) |  |  | (4,531 | ) |  |  | (12,789 | ) |  |  | (22,856 | ) |
| Other income (expense), net |  |  | 86 |  |  |  | (115 | ) |  |  | 383 |  |  |  | (1,687 | ) |
| Income before income taxes |  |  | 7,615 |  |  |  | 12,996 |  |  |  | 52,194 |  |  |  | 10,185 |  |
| Provision for income taxes |  |  | 2,205 |  |  |  | 2,670 |  |  |  | 7,923 |  |  |  | 8,249 |  |
| Net income |  | $ | 5,410 |  |  | $ | 10,326 |  |  | $ | 44,271 |  |  | $ | 1,936 |  |
| Basic and diluted income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share - basic |  | $ | 0.04 |  |  | $ | 0.08 |  |  | $ | 0.34 |  |  | $ | 0.02 |  |
| Net income per share - diluted |  | $ | 0.04 |  |  | $ | 0.08 |  |  | $ | 0.33 |  |  | $ | 0.02 |  |
| Shares used in per share calculation - basic |  |  | 129,788 |  |  |  | 126,318 |  |  |  | 129,437 |  |  |  | 124,019 |  |
| Shares used in per share calculation - diluted |  |  | 132,304 |  |  |  | 132,355 |  |  |  | 133,494 |  |  |  | 127,669 |  |

[0001564590-22-026574:8k_2_02:87]
EXTREME NETWORKS, INC.

[0001564590-22-026574:8k_2_02:88]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-22-026574:8k_2_02:89]
(In thousands)

[0001564590-22-026574:8k_2_02:90]
(Unaudited)

[0001564590-22-026574:8k_2_02:91]
|  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 44,271 |  |  | $ | 1,936 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 20,215 |  |  |  | 22,961 |  |
| Amortization of intangible assets |  |  | 19,946 |  |  |  | 32,356 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 14,929 |  |  |  | 16,134 |  |
| Provision for doubtful accounts |  |  | 29 |  |  |  | 409 |  |
| Share-based compensation |  |  | 43,362 |  |  |  | 39,051 |  |
| Deferred income taxes |  |  | 682 |  |  |  | 1,785 |  |
| Non-cash interest expense |  |  | 4,443 |  |  |  | 5,055 |  |
| Other |  |  | 423 |  |  |  | 3,989 |  |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (26,231 | ) |  |  | (34,158 | ) |
| Inventories |  |  | (16,722 | ) |  |  | 22,729 |  |
| Prepaid expenses and other assets |  |  | (4,469 | ) |  |  | (18,979 | ) |
| Accounts payable |  |  | 23,810 |  |  |  | 10,810 |  |
| Accrued compensation and benefits |  |  | (20,709 | ) |  |  | 20,088 |  |
| Operating lease liabilities |  |  | (18,949 | ) |  |  | (19,986 | ) |
| Deferred revenue |  |  | 44,635 |  |  |  | 54,398 |  |
| Other current and long-term liabilities |  |  | (1,488 | ) |  |  | (14,043 | ) |
| Net cash provided by operating activities |  |  | 128,177 |  |  |  | 144,535 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (15,433 | ) |  |  | (17,176 | ) |
| Business acquisition, net of cash acquired |  |  | (69,517 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (84,950 | ) |  |  | (17,176 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payments on debt obligations |  |  | (38,125 | ) |  |  | (74,000 | ) |
| Repurchase of common stock |  |  | (44,973 | ) |  |  | — |  |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (6,541 | ) |  |  | 4,516 |  |
| Payment of contingent consideration obligations |  |  | (1,024 | ) |  |  | (1,298 | ) |
| Deferred payments on an acquisition |  |  | (4,000 | ) |  |  | (4,000 | ) |
| Net cash used in financing activities |  |  | (94,663 | ) |  |  | (74,782 | ) |
| Foreign currency effect on cash |  |  | (936 | ) |  |  | 445 |  |
| Net (decrease) increase in cash |  |  | (52,372 | ) |  |  | 53,022 |  |
| Cash at beginning of period |  |  | 246,894 |  |  |  | 193,872 |  |
| Cash at end of period |  | $ | 194,522 |  |  | $ | 246,894 |  |

[0001564590-22-026574:8k_2_02:92]
Extreme Networks, Inc.

[0001564590-22-026574:8k_2_02:93]
Non-GAAP Measures of Financial Performance

[0001564590-22-026574:8k_2_02:94]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, non-GAAP free cash flow.

[0001564590-22-026574:8k_2_02:95]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0001564590-22-026574:8k_2_02:96]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-22-026574:8k_2_02:97]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-22-026574:8k_2_02:98]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-22-026574:8k_2_02:99]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-22-026574:8k_2_02:100]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-22-026574:8k_2_02:101]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive Networks and Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-22-026574:8k_2_02:102]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-22-026574:8k_2_02:103]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-22-026574:8k_2_02:104]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.  We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits.  The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.

[0001564590-22-026574:8k_2_02:105]
Non-GAAP provision for income taxes may be higher or lower depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of the tax year ended June 30, 2022, we have U.S. federal net operating loss carryforwards of $184.5 million, state net operating loss carryforwards of $162.8 million and Irish net operating losses of $8.9 million.  These amounts will be reflected in our requisite tax filings for each jurisdiction for the tax year ended June 30, 2022. We anticipate utilization of a portion of these net operating losses in each of the jurisdiction for the tax year ended June 30, 2023; however, we do not expect to pay substantial taxes on a GAAP basis in the U.S. in the near term due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which primarily performs research and development activities, as well as the Company’s Irish operating company which fully utilized available net operating loss carryforwards during the tax year ended June 30, 2021.

[0001564590-22-026574:8k_2_02:106]
EXTREME NETWORKS, INC.

[0001564590-22-026574:8k_2_02:107]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-22-026574:8k_2_02:108]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-22-026574:8k_2_02:109]
(In thousands, except percentages and per share amounts)

[0001564590-22-026574:8k_2_02:110]
(Unaudited)

[0001564590-22-026574:8k_2_02:111]
| Revenues | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Revenues - GAAP | $ | 278,196 |  |  | $ | 278,088 |  |  | $ | 1,112,321 |  |  | $ | 1,009,418 |  |

[0001564590-22-026574:8k_2_02:112]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Gross profit - GAAP | $ | 154,191 |  |  | $ | 161,100 |  |  | $ | 629,938 |  |  | $ | 585,123 |  |
| Gross margin - GAAP percentage |  | 55.4 | % |  |  | 57.9 | % |  |  | 56.6 | % |  |  | 58.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 646 |  |  |  | 779 |  |  |  | 2,607 |  |  |  | 2,871 |  |
| Acquisition and integration costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 10 |  |
| Amortization of intangibles |  | 3,619 |  |  |  | 6,432 |  |  |  | 16,640 |  |  |  | 26,129 |  |
| Total adjustments to GAAP gross profit | $ | 4,265 |  |  | $ | 7,211 |  |  | $ | 19,247 |  |  | $ | 29,010 |  |
| Gross profit - non-GAAP | $ | 158,456 |  |  | $ | 168,311 |  |  | $ | 649,185 |  |  | $ | 614,133 |  |
| Gross margin - non-GAAP percentage |  | 57.0 | % |  |  | 60.5 | % |  |  | 58.4 | % |  |  | 60.8 | % |

[0001564590-22-026574:8k_2_02:113]
| Non-GAAP Operating Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| GAAP operating income | $ | 10,458 |  |  | $ | 17,571 |  |  | $ | 64,188 |  |  | $ | 34,376 |  |
| GAAP operating income percentage |  | 3.8 | % |  |  | 6.3 | % |  |  | 5.8 | % |  |  | 3.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 646 |  |  |  | 779 |  |  |  | 2,607 |  |  |  | 2,871 |  |
| Share-based compensation expense, R&D |  | 2,427 |  |  |  | 2,589 |  |  |  | 9,995 |  |  |  | 9,969 |  |
| Share-based compensation expense, S&M |  | 3,733 |  |  |  | 3,469 |  |  |  | 15,000 |  |  |  | 12,505 |  |
| Share-based compensation expense, G&A |  | 3,925 |  |  |  | 4,619 |  |  |  | 15,760 |  |  |  | 13,706 |  |
| Acquisition and integration costs |  | 553 |  |  |  | — |  |  |  | 7,009 |  |  |  | 1,985 |  |
| Restructuring charges, net of reversals |  | 770 |  |  |  | 504 |  |  |  | 1,748 |  |  |  | 2,625 |  |
| Amortization of intangibles |  | 4,258 |  |  |  | 7,838 |  |  |  | 19,875 |  |  |  | 32,239 |  |
| Total adjustments to GAAP operating income | $ | 16,312 |  |  | $ | 19,798 |  |  | $ | 71,994 |  |  | $ | 75,900 |  |
| Non-GAAP operating income | $ | 26,770 |  |  | $ | 37,369 |  |  | $ | 136,182 |  |  | $ | 110,276 |  |
| Non-GAAP operating income percentage |  | 9.6 | % |  |  | 13.4 | % |  |  | 12.2 | % |  |  | 10.9 | % |

[0001564590-22-026574:8k_2_02:114]
| Non-GAAP net income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| GAAP net income | $ | 5,410 |  |  | $ | 10,326 |  |  | $ | 44,271 |  |  | $ | 1,936 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 10,731 |  |  |  | 11,456 |  |  |  | 43,362 |  |  |  | 39,051 |  |
| Acquisition and integration costs |  | 553 |  |  |  | — |  |  |  | 7,009 |  |  |  | 1,985 |  |
| Restructuring charge, net of reversal |  | 770 |  |  |  | 504 |  |  |  | 1,748 |  |  |  | 2,625 |  |
| Amortization of intangibles |  | 4,258 |  |  |  | 7,838 |  |  |  | 19,875 |  |  |  | 32,239 |  |
| Tax effect of non-GAAP adjustments |  | (2,074 | ) |  |  | (5,514 | ) |  |  | (12,814 | ) |  |  | (5,608 | ) |
| Total adjustments to GAAP net income | $ | 14,238 |  |  | $ | 14,284 |  |  | $ | 59,180 |  |  | $ | 70,292 |  |
| Non-GAAP net income | $ | 19,648 |  |  | $ | 24,610 |  |  | $ | 103,451 |  |  | $ | 72,228 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.15 |  |  | $ | 0.19 |  |  | $ | 0.77 |  |  | $ | 0.57 |  |
| Shares used in net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation - basic |  | 129,788 |  |  |  | 126,318 |  |  |  | 129,437 |  |  |  | 124,019 |  |
| Potentially dilutive equity awards |  | 2,516 |  |  |  | 6,037 |  |  |  | 4,057 |  |  |  | 3,650 |  |
| GAAP and Non-GAAP shares used in per share calculation - diluted |  | 132,304 |  |  |  | 132,355 |  |  |  | 133,494 |  |  |  | 127,669 |  |
