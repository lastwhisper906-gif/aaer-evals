# EXTR MD&A — 0001564590-22-030248


## mdna

[0001564590-22-030248:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-22-030248:mdna:2]
Business Overview

[0001564590-22-030248:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Part II, Item 8 of this Report.

[0001564590-22-030248:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles, or U.S. GAAP. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-22-030248:mdna:5]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leading provider of networking software, hardware and services and offers related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. We recently changed our corporate headquarters from San Jose, California to Morrisville, North Carolina. We derive substantially all of our revenues from the sale of our networking software, hardware and services, and related maintenance contracts.

[0001564590-22-030248:mdna:6]
Extreme is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from enterprise edge to the cloud, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. Extreme gives customers and partners the power to mix and match this broad array of software, hardware, and services (including third-party applications) to tailor a solution that can be managed and automated from end-to-end.

[0001564590-22-030248:mdna:7]
Enterprise network administrators need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security. Accelerators such as Internet of Things (“IoT”), artificial intelligence (“AI”), bring your own device, machine learning, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-22-030248:mdna:8]
A direction affecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud, and third-party, public cloud services with orchestration between multiple platforms. We introduced our Cloud offering in 2016 and in August 2019 acquired Aerohive Networks, Inc to enhance our Cloud strategy with a 3rd generation Cloud platform and to accelerate adoption of hybrid cloud networking solutions in the Enterprise. Extreme’s enhanced Cloud solution is the only offering in the market that seamlessly integrates the cloud with on-premises infrastructures and enables visibility from the edge to everywhere. See Part 1, Item 1. Business, for additional discussion of our business.

[0001564590-22-030248:mdna:9]
Acquisitions

[0001564590-22-030248:mdna:10]
Ipanematech SAS

[0001564590-22-030248:mdna:11]
On September 14, 2021 (the “Acquisition Date”), we completed our acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of InfoVista pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million. The primary reason for the Acquisition was to acquire the talent and the technology to allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers. The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanematech were recorded at their respective fair values including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets. Results of operations of Ipanematech are included in our operations beginning with the Acquisition Date. During the fiscal year ended June 30, 2022, we recognized transaction costs related to this acquisition of $7.0 million, which is included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0001564590-22-030248:mdna:12]
Aerohive Networks, Inc

[0001564590-22-030248:mdna:13]
On August 9, 2019 (the “Closing Date”), we completed our acquisition of Aerohive Networks, Inc. (“Aerohive”), a publicly held network company, for $263.6 million in cash consideration and assumption of certain employee equity awards.

[0001564590-22-030248:mdna:14]
The business combination was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive were recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets. Results of operations

[0001564590-22-030248:mdna:15]
of Aerohive are included in our operations beginning with the Closing Date. During the fiscal year ended June 30, 2021 and 2020, we recognized related transaction costs of $2.0 million and $32.1 million, respectively, which is included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0001564590-22-030248:mdna:16]
Results of Operations

[0001564590-22-030248:mdna:17]
The following is a summary of our results of operations during fiscal year ended June 30, 2022:

[0001564590-22-030248:mdna:18]
|  | • | Net revenues of $1,112.3 million, increased 10.2% from fiscal 2021 net revenues of $1,009.4 million. |

[0001564590-22-030248:mdna:19]
|  | • | Product revenues of $761.7 million, increased 8.9% from fiscal 2021 product revenues of $699.4 million. |

[0001564590-22-030248:mdna:20]
|  | • | Service revenues of $350.6 million, increased 13.1% from fiscal 2021 service revenues of $310.0 million. |

[0001564590-22-030248:mdna:21]
|  | • | Total gross margin of 56.6% of net revenues in fiscal 2022, compared to 58.0% in fiscal 2021. |

[0001564590-22-030248:mdna:22]
|  | • | Operating income of $64.2 million, compared to operating income of $34.4 million in fiscal 2021. |

[0001564590-22-030248:mdna:23]
|  | • | Net income was $44.3 million in fiscal 2022, compared to net income of $1.9 million in fiscal 2021. |

[0001564590-22-030248:mdna:24]
|  | • | Cash flow provided by operating activities of $128.2 million, compared to cash flow provided by operating activities of $144.5 million in fiscal 2021, a decrease of $16.3 million. Cash was $194.5 million as of June 30, 2022, a decrease of $52.4 million, compared to $246.9 million at the end of fiscal 2021. |

[0001564590-22-030248:mdna:25]
Net Revenues

[0001564590-22-030248:mdna:26]
The following table presents net product and service revenues for the fiscal years ended June 30, 2022, 2021 and 2020 (dollars in thousands):

[0001564590-22-030248:mdna:27]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | $ Change |  |  | % Change |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | $ Change |  |  | % Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 761,721 |  |  | $ | 699,396 |  |  | $ | 62,325 |  |  |  | 8.9 | % |  | $ | 699,396 |  |  | $ | 653,651 |  |  | $ | 45,745 |  |  |  | 7.0 | % |
| Percentage of net revenues |  |  | 68.5 | % |  |  | 69.3 | % |  |  |  |  |  |  |  |  |  |  | 69.3 | % |  |  | 68.9 | % |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 350,600 |  |  |  | 310,022 |  |  |  | 40,578 |  |  |  | 13.1 | % |  |  | 310,022 |  |  |  | 294,368 |  |  |  | 15,654 |  |  |  | 5.3 | % |
| Percentage of net revenues |  |  | 31.5 | % |  |  | 30.7 | % |  |  |  |  |  |  |  |  |  |  | 30.7 | % |  |  | 31.1 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 1,112,321 |  |  | $ | 1,009,418 |  |  | $ | 102,903 |  |  |  | 10.2 | % |  | $ | 1,009,418 |  |  | $ | 948,019 |  |  | $ | 61,399 |  |  |  | 6.5 | % |

[0001564590-22-030248:mdna:28]
Product revenues increased $62.3 million or 8.9% for the year ended June 30, 2022, compared to fiscal 2021. The product revenues increase for the year ended June 30, 2022 as compared to fiscal 2021 was primarily due to strong demand for our products partially offset by supply chain constraints which impacted our ability to fulfill the demand for our products during fiscal 2022. Additionally, the first half of fiscal 2021 product revenue was impacted by the material slow-down in global demand due to the global outbreak of COVID-19.

[0001564590-22-030248:mdna:29]
Product revenues increased $45.7 million or 7.0% for the year ended June 30, 2021, compared to fiscal 2020. The product revenues increase for the year ended June 30, 2021 as compared to fiscal 2020 was primarily due to the lower revenue in fiscal 2020 which was due to the impact of COVID-19 on global demand across all geographies, which began in the second half of fiscal 2020 and continued to impact through the first two quarters in fiscal 2021. We saw growth in our product revenues starting in the third quarter of fiscal 2021 as the economy started to recover from the impact of COVID-19 with the availability of vaccinations and loosening of restrictions.

[0001564590-22-030248:mdna:30]
Service and subscription revenues increased $40.6 million or 13.1% for the year ended June 30, 2022, compared to fiscal 2021. The increase in service and subscription revenues was primarily due to the growth in subscription revenues and partially due to the acquisition of Ipanema.

[0001564590-22-030248:mdna:31]
Service and subscription revenues increased $15.7 million or 5.3% for the year ended June 30, 2021, compared to fiscal 2020. The increase in service and subscription revenues was primarily due to the growth in subscription revenues.

[0001564590-22-030248:mdna:32]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenues geographically for the fiscal years ended June 30, 2022, 2021 and 2020 (dollars in thousands):

[0001564590-22-030248:mdna:33]
|  |  | Year Ended |  |  | Year Ended |  |
| Net Revenues |  | June 30, 2022 |  |  | June 30, 2021 |  |  | $ Change |  |  | % Change |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | $ Change |  |  | % Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 503,635 |  |  | $ | 485,471 |  |  | $ | 18,164 |  |  |  | 3.7 | % |  | $ | 485,471 |  |  | $ | 459,769 |  |  | $ | 25,702 |  |  |  | 5.6 | % |
| Other |  |  | 44,608 |  |  |  | 48,049 |  |  |  | (3,441 | ) |  |  | (7.2 | )% |  |  | 48,049 |  |  |  | 39,633 |  |  |  | 8,416 |  |  |  | 21.2 | % |
| Total Americas |  |  | 548,243 |  |  |  | 533,520 |  |  |  | 14,723 |  |  |  | 2.8 | % |  |  | 533,520 |  |  |  | 499,402 |  |  |  | 34,118 |  |  |  | 6.8 | % |
| Percentage of net revenues |  |  | 49.3 | % |  |  | 52.9 | % |  |  |  |  |  |  |  |  |  |  | 52.9 | % |  |  | 52.7 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 477,081 |  |  |  | 387,545 |  |  |  | 89,536 |  |  |  | 23.1 | % |  |  | 387,545 |  |  |  | 357,201 |  |  |  | 30,344 |  |  |  | 8.5 | % |
| Percentage of net revenues |  |  | 42.9 | % |  |  | 38.4 | % |  |  |  |  |  |  |  |  |  |  | 38.4 | % |  |  | 37.7 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 86,997 |  |  |  | 88,353 |  |  |  | (1,356 | ) |  |  | (1.5 | )% |  |  | 88,353 |  |  |  | 91,416 |  |  |  | (3,063 | ) |  |  | (3.4 | )% |
| Percentage of net revenues |  |  | 7.8 | % |  |  | 8.8 | % |  |  |  |  |  |  |  |  |  |  | 8.8 | % |  |  | 9.6 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 1,112,321 |  |  | $ | 1,009,418 |  |  | $ | 102,903 |  |  |  | 10.2 | % |  | $ | 1,009,418 |  |  | $ | 948,019 |  |  | $ | 61,399 |  |  |  | 6.5 | % |

[0001564590-22-030248:mdna:34]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEMs and direct sales. Revenues through our distributor channel were 80% of total product revenues in fiscal 2022, 77% of total product revenues in fiscal 2021 and 73% of total product revenue in fiscal 2020.

[0001564590-22-030248:mdna:35]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001564590-22-030248:mdna:36]
Cost of Revenues and Gross Profit

[0001564590-22-030248:mdna:37]
The following table presents the gross profit on product and service revenues and the gross profit percentage of net revenues for the fiscal years ended June 30, 2022, 2021 and 2020 (dollars in thousands):

[0001564590-22-030248:mdna:38]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | $ Change |  |  | % Change |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 401,159 |  |  | $ | 389,438 |  |  | $ | 11,721 |  |  |  | 3.0 | % |  | $ | 389,438 |  |  | $ | 327,318 |  |  | $ | 62,120 |  |  |  | 19.0 | % |
| Percentage of product revenues |  |  | 52.7 | % |  |  | 55.7 | % |  |  |  |  |  |  |  |  |  |  | 55.7 | % |  |  | 50.1 | % |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 228,779 |  |  |  | 195,685 |  |  |  | 33,094 |  |  |  | 16.9 | % |  |  | 195,685 |  |  |  | 190,521 |  |  |  | 5,164 |  |  |  | 2.7 | % |
| Percentage of service and subscription revenues |  |  | 65.3 | % |  |  | 63.1 | % |  |  |  |  |  |  |  |  |  |  | 63.1 | % |  |  | 64.7 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 629,938 |  |  | $ | 585,123 |  |  | $ | 44,815 |  |  |  | 7.7 | % |  | $ | 585,123 |  |  | $ | 517,839 |  |  | $ | 67,284 |  |  |  | 13.0 | % |
| Percentage of net revenues |  |  | 56.6 | % |  |  | 58.0 | % |  |  |  |  |  |  |  |  |  |  | 58.0 | % |  |  | 54.6 | % |  |  |  |  |  |  |  |  |

[0001564590-22-030248:mdna:39]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing, engineering, and document control at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001564590-22-030248:mdna:40]
Product gross profit increased to $401.2 million for the year ended June 30, 2022, from $389.4 million in fiscal 2021, primarily due to increased revenues along with lower amortization of intangibles of $9.5 million due to certain intangibles being fully amortized, and lower excess and obsolete inventory charges of $3.0 million, partially offset by higher direct product costs and higher distribution cost of $18.5 million.

[0001564590-22-030248:mdna:41]
Product gross profit increased to $389.4 million for the year ended June 30, 2021, from $327.3 million in fiscal 2020, primarily due to increased revenues along with lower distribution charges of $11.4 million, which were mainly due to decreased tariffs on manufactured products imported from China and sold to U.S. customers, lower excess and obsolete inventory charges of $9.9 million, lower warranty costs of $7.9 million, and lower expensing of the fair value step-up of inventories acquired from Aerohive of $7.3 million.

[0001564590-22-030248:mdna:42]
Our cost of service revenues consist primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts.

[0001564590-22-030248:mdna:43]
Service and subscription gross profit increased to $228.8 million for the year ended June 30, 2022, from $195.7 million in fiscal 2021, primarily due to higher service and subscription revenues partially offset by higher professional fees and increased cloud service costs.

[0001564590-22-030248:mdna:44]
Service and subscription gross profit increased to $195.7 million for the year ended June 30, 2021, from $190.5 million in fiscal 2020, primarily due to higher service and subscription revenues partially offset by higher personnel costs and increased cloud service costs.

[0001564590-22-030248:mdna:45]
Operating Expenses

[0001564590-22-030248:mdna:46]
The following table presents operating expenses and operating income for the fiscal years ended June 30, 2022, 2021 and 2020 (dollars in thousands):

[0001564590-22-030248:mdna:47]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | $ Change |  |  | % Change |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 190,591 |  |  | $ | 196,995 |  |  | $ | (6,404 | ) |  |  | (3.3 | )% |  | $ | 196,995 |  |  | $ | 209,606 |  |  | $ | (12,611 | ) |  |  | (6.0 | )% |
| Sales and marketing |  |  | 294,470 |  |  |  | 276,841 |  |  |  | 17,629 |  |  |  | 6.4 | % |  |  | 276,841 |  |  |  | 283,632 |  |  |  | (6,791 | ) |  |  | (2.4 | )% |
| General and administrative |  |  | 68,697 |  |  |  | 66,201 |  |  |  | 2,496 |  |  |  | 3.8 | % |  |  | 66,201 |  |  |  | 60,991 |  |  |  | 5,210 |  |  |  | 8.5 | % |
| Acquisition and integration costs |  |  | 7,009 |  |  |  | 1,975 |  |  |  | 5,034 |  |  |  | 254.9 | % |  |  | 1,975 |  |  |  | 32,073 |  |  |  | (30,098 | ) |  |  | (93.8 | )% |
| Restructuring and related charges |  |  | 1,748 |  |  |  | 2,625 |  |  |  | (877 | ) |  |  | (33.4 | )% |  |  | 2,625 |  |  |  | 22,011 |  |  |  | (19,386 | ) |  |  | (88.1 | )% |
| Amortization of intangibles |  |  | 3,235 |  |  |  | 6,110 |  |  |  | (2,875 | ) |  |  | (47.1 | )% |  |  | 6,110 |  |  |  | 8,425 |  |  |  | (2,315 | ) |  |  | (27.5 | )% |
| Total operating expenses |  | $ | 565,750 |  |  | $ | 550,747 |  |  | $ | 15,003 |  |  |  | 2.7 | % |  | $ | 550,747 |  |  | $ | 616,738 |  |  | $ | (65,991 | ) |  |  | (10.7 | )% |

[0001564590-22-030248:mdna:48]
The following table highlights our operating expenses and operating income (loss) as a percentage of net revenues for the fiscal years ended June 30, 2022, 2021 and 2020:

[0001564590-22-030248:mdna:49]
|  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Research and development |  |  | 17.1 | % |  |  | 19.5 | % |  |  | 22.1 | % |
| Sales and marketing |  |  | 26.5 | % |  |  | 27.4 | % |  |  | 29.9 | % |
| General and administrative |  |  | 6.2 | % |  |  | 6.6 | % |  |  | 6.4 | % |
| Acquisition and integration costs |  |  | 0.6 | % |  |  | 0.2 | % |  |  | 3.4 | % |
| Restructuring and related charges |  |  | 0.2 | % |  |  | 0.3 | % |  |  | 2.3 | % |
| Amortization of intangibles |  |  | 0.3 | % |  |  | 0.6 | % |  |  | 0.9 | % |
| Total operating expenses |  |  | 50.9 | % |  |  | 54.6 | % |  |  | 65.1 | % |
| Operating income (loss) |  |  | 5.8 | % |  |  | 3.4 | % |  |  | (10.4 | )% |

[0001564590-22-030248:mdna:50]
Research and Development Expenses

[0001564590-22-030248:mdna:51]
Research and development expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-22-030248:mdna:52]
Research and development expenses decreased by $6.4 million or 3.25% for the year ended June 30, 2022 as compared to fiscal 2021. The decrease in research and development expenses was due to a $0.7 million decrease in personnel costs, a $3.8 million decrease in facility and information technology costs, a $1.2 million decrease in third-party software licenses and engineering project costs and a $1.0 million decrease in other expenses, partially offset by a $0.3 million increase in travel expenses.

[0001564590-22-030248:mdna:53]
Research and development expenses decreased by $12.6 million or 6.0% for the year ended June 30, 2021 as compared to fiscal 2020. The decrease in research and development expenses was due to a $16.5 million decrease in personnel costs primarily due to lower headcount as a result of the cost reduction actions taken in fiscal 2020, a $5.2 million decrease in facility and information technology costs, a $2.6 million decrease in third-party software licenses and engineering project costs and a $2.0 million decrease in travel due to COVID-19, decrease in equipment costs and decrease in other expenses, partially offset by a $13.7 million increase in professional and contractor fees.

[0001564590-22-030248:mdna:54]
Sales and Marketing Expenses

[0001564590-22-030248:mdna:55]
Sales and marketing expenses consist of personnel costs (which consists of compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001564590-22-030248:mdna:56]
Sales and marketing expenses increased by $17.6 million or 6.4% for the year ended June 30, 2022, as compared to fiscal 2021. The increase was primarily due to a $6.6 million increase in personnel costs primarily due to higher headcount, a $7.0 million increase in marketing sales and promotional costs, a $5.5 million increase in travel expenses due to loosening of COVID-19 restrictions, partially offset by a $1.5 million decrease in professional fees and equipment related costs.

[0001564590-22-030248:mdna:57]
Sales and marketing expenses decreased by $6.8 million or 2.4% for the year ended June 30, 2021, as compared to fiscal 2020. The decrease was primarily due to a $8.7 million decrease in travel costs due to COVID-19, a $4.9 million decrease in professional and recruiting fees, a $3.2 million decrease in third-party software and equipment related costs, partially offset by a $8.4 million increase in personnel costs primarily commissions and benefits and a $1.6 million increase in facility and information technology costs.

[0001564590-22-030248:mdna:58]
General and Administrative Expenses

[0001564590-22-030248:mdna:59]
General and administrative expense consists primarily of personnel costs (which consists of compensation, benefits and share-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001564590-22-030248:mdna:60]
General and administrative expenses increased by $2.5 million or 3.8% for the year ended June 30, 2022, as compared to fiscal 2021. The increase in general and administrative expenses during fiscal 2022 was primarily due to a $1.4 million increase in third party software and equipment related costs, a $1.9 increase in facilities and related costs, partially offset by a $0.2 million decrease in personnel costs and a $0.6 decrease in travel and professional fees.

[0001564590-22-030248:mdna:61]
General and administrative expenses increased by $5.2 million or 8.5% for the year ended June 30, 2021, as compared to fiscal 2020. The increase in general and administrative expenses during fiscal 2021 was primarily due to a $7.4 million increase in personnel costs primarily compensation benefits and stock-based compensation expenses, partially offset by a $2.2 million decrease in third-party software and equipment related costs.

[0001564590-22-030248:mdna:62]
Acquisition and Integration Costs

[0001564590-22-030248:mdna:63]
As a result of our acquisitions of Ipanema in fiscal 2022, and Aerohive in fiscal 2020, we incurred $7.0 million, $2.0 million and $32.1 million of acquisition and integration costs in fiscal years ended June 30, 2022, 2021 and 2020, respectively.

[0001564590-22-030248:mdna:64]
For fiscal 2022, we incurred $7.0 million of acquisition and integration costs which consisted primarily of professional fees for product integration, system integration, financial, legal and advisory services related to the Ipanema acquisition.

[0001564590-22-030248:mdna:65]
For fiscal 2021, we incurred $2.0 million of integration costs which consisted primarily of additional professional fees for system integration and financial services related to the Aerohive acquisition.

[0001564590-22-030248:mdna:66]
For fiscal 2020, we incurred $32.1 million of operating integration costs related to the Aerohive acquisition which consisted primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees. The acquisition and integration costs also included a $6.8 million compensation charge for certain Aerohive executives’ stock awards that were accelerated due to change-in-control and termination provisions included in the executives’ employment contracts.

[0001564590-22-030248:mdna:67]
Restructuring and Related Charges

[0001564590-22-030248:mdna:68]
During fiscal years ended June 30, 2022, 2021 and 2020, we recorded restructuring and related charges of $1.7 million, $2.6 million and $22.0 million, respectively.

[0001564590-22-030248:mdna:69]
Fiscal year ended 2022

[0001564590-22-030248:mdna:70]
During fiscal 2022, the Company recorded $1.7 million of restructuring charges which primarily comprised of facility related charges. The facility restructuring charges included some impairment charges and additional facilities expenses related to previously impaired facilities. During fiscal 2022, the Company completed the reduction-in-force action initiated in the third quarter of fiscal 2020.

[0001564590-22-030248:mdna:71]
Fiscal year ended 2021

[0001564590-22-030248:mdna:72]
During fiscal 2021, we continued our cost reduction initiative that began in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of $1.5 million, related to the 2020 Plan. In addition, we had facility-related charges of $1.1 million, related to our previously impaired facilities.

[0001564590-22-030248:mdna:73]
Fiscal year ended 2020

[0001564590-22-030248:mdna:74]
During fiscal 2020, we reduced our current and future operating expenses by exiting a floor of a building in our San Jose, California facility and consolidating our workforce. Also, we exited additional space in our Salem, New Hampshire facility, which includes general office and lab space. We continued our initiative to realign our operations resulting from the acquisition of Aerohive by consolidating our workforce and exiting the facility acquired from Aerohive in Milpitas, California which included general office and lab space.

[0001564590-22-030248:mdna:75]
With the global disruptions and slow-down in the demand of our products caused by the global pandemic outbreak, COVID-19, and the uncertainty around the timing of the recovery of the market, we initiated a reduction-in-force plan (the 2020 Plan) to reduce our operating costs and enhance financial flexibility. The plan affected approximately 320 employees primarily from the research and development and sales organizations who were located mainly in the United States and India. We recorded restructuring charges of $8.1 million during the fiscal year ended June 30, 2020 related to the 2020 Plan. The costs associated with this restructuring plan primarily included employee severance and benefit expenses. We recorded additional severance and benefits charges of $5.4 million for the fiscal year ended June 30, 2020 related to the prior period restructuring plans. In total we incurred $13.5 million in restructuring charges for the year ended June 30, 2020 which were all severance and benefit related. In addition, we recorded facility impairment related charges of $8.5 million for the fiscal year ended June 30, 2020 which included $6.7 million for the impairment of certain operating leases right-of-use assets as discussed in the preceding paragraph, $0.9 million for impairment of long-lived assets, and $0.9 million of other charges related to previously impaired facilities.

[0001564590-22-030248:mdna:76]
Amortization of Intangibles

[0001564590-22-030248:mdna:77]
During fiscal years ended June 30, 2022, 2021 and 2020, we recorded $3.2 million, $6.1 million and $8.4 million, respectively, of amortization expense in operating expenses primarily for certain intangibles related to the acquisitions of the Ipanema, Aerohive, Campus Fabric, Data Center and WLAN Businesses. The decrease in amortization expense in fiscal 2022 from fiscal 2021 was primarily due to certain acquired intangibles from previous acquisitions becoming fully amortized, partially offset by an increase from the amortization of acquired intangibles from the Ipanema acquisition. The decrease in amortization expense in fiscal 2021 from fiscal 2020 was primarily due to certain acquired intangibles from previous acquisitions becoming fully amortized, partially offset by an increase from full period amortization of acquired intangibles from the Aerohive acquisition.

[0001564590-22-030248:mdna:78]
Interest Income

[0001564590-22-030248:mdna:79]
Interest income was $0.4 million, $0.4 million and $1.4 million in fiscal years ended June 30, 2022, 2021 and 2020, respectively. Interest income remained flat in fiscal 2022 as compared to fiscal 2021 and decreased $1.0 million in fiscal 2021 from fiscal 2020. The decrease in fiscal 2021 from 2020 was due to lower interest rates and lower invested fund balances.

[0001564590-22-030248:mdna:80]
Interest Expense

[0001564590-22-030248:mdna:81]
We incurred $12.8 million, $22.9 million, and $23.8 million of interest expense for fiscal years ended June 30, 2022, 2021 and 2020, respectively. The decrease in interest expense in fiscal year ended June 30, 2022 was primarily driven by lower average loan balances and lower average rates under our 2019 Credit Agreement. The decrease in interest expense in fiscal year ended June 30, 2021 was primarily driven by lower average loan balances and lower average rates under our 2019 Credit Agreement.

[0001564590-22-030248:mdna:82]
Other Income (Expense), net

[0001564590-22-030248:mdna:83]
We had other income of $0.4 million and $0.7 million in fiscal years ended June 30, 2022 and 2020, respectively, and other expense of $1.7 million in fiscal 2021. The other income for fiscal 2022 and 2020 was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars. The other expense for fiscal 2021 was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-22-030248:mdna:84]
Provision for Income Taxes

[0001564590-22-030248:mdna:85]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rate differs from the U.S. federal statutory rate of 21% primarily due to the impact of (i) foreign income taxes of our international subsidiaries, (ii) foreign withholding taxes, (iii) state taxes, and (iv) the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions. For the fiscal years ended June 30, 2022, 2021 and 2020, we recorded income tax provisions of $7.9 million, $8.2 million, and $6.4 million respectively.

[0001564590-22-030248:mdna:86]
For fiscal 2022, 2021 and 2020, our tax provision primarily related to taxes on our foreign operations, including foreign withholding taxes remitted to foreign tax authorities by customers on our behalf, tax expense related to the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business and state taxes in states where we have exhausted available Net Operating Losses (“NOLs”) or are subject to certain franchise taxes qualifying as income tax under the relevant tax accounting guidance.

[0001564590-22-030248:mdna:87]
In fiscal 2020, we recognized a $75.0 million U.S. tax gain on the transfer of non-American Aerohive intellectual property rights which was fully offset by existing U.S. NOLs. Given the full U.S. valuation allowance against our U.S. deferred tax assets, this transaction did not impact net tax expense or the overall tax rate.

[0001564590-22-030248:mdna:88]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 16, Income Taxes, in notes to Consolidated Financial Statements for additional information.

[0001564590-22-030248:mdna:89]
Critical Accounting Policies and Estimates

[0001564590-22-030248:mdna:90]
Our significant accounting policies are more fully described in Note 2, Summary of Significant Accounting Policies, in Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0001564590-22-030248:mdna:91]
Revenue Recognition

[0001564590-22-030248:mdna:92]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from SaaS and service fees relating to maintenance contracts, professional services, and training for our products. We sell our products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers. The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0001564590-22-030248:mdna:93]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, we consider the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0001564590-22-030248:mdna:94]
We generally do not grant return privileges and pricing credits to our value-added resellers, non-stocking distributors and end-user customers, except for defective products during the warranty period. We may provide sales incentives and other programs to these customers which are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the historical actuals.

[0001564590-22-030248:mdna:95]
Our stocking distributors are allowed to certain price adjustments in the form of rebates and limited stock rotation rights. In determining the transaction price, we consider these rebate adjustments to be variable consideration which are estimated based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are estimated based on an analysis of historical return rates.

[0001564590-22-030248:mdna:96]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price. The stand-alone selling prices are determined based on the prices at which we separately sell these products. For items that are not sold separately, we estimate the stand-alone selling prices using other observable inputs.

[0001564590-22-030248:mdna:97]
Our performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of our product sales revenues are recognized at a point in time and our service and subscription revenues are recognized over time. For revenues recognized over time, we use an input measure, days elapsed, to measure progress.

[0001564590-22-030248:mdna:98]
See Note 3, Revenues, in notes to Consolidated Financial Statements for additional information.

[0001564590-22-030248:mdna:99]
Business Combinations

[0001564590-22-030248:mdna:100]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all tangible and intangible assets acquired and liabilities assumed are recorded at their respective fair values at the acquisition date. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to expected future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001564590-22-030248:mdna:101]
Inventory Valuation and Purchase Commitments

[0001564590-22-030248:mdna:102]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0001564590-22-030248:mdna:103]
New Accounting Pronouncements

[0001564590-22-030248:mdna:104]
See Note 2, Summary of Significant Accounting Policies, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-22-030248:mdna:105]
Liquidity and Capital Resources

[0001564590-22-030248:mdna:106]
The following summarizes information regarding our cash (in thousands):

[0001564590-22-030248:mdna:107]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Cash |  | $ | 194,522 |  |  | $ | 246,894 |  |

[0001564590-22-030248:mdna:108]
As of June 30, 2022, our principal sources of liquidity consisted of cash of $194.5 million, accounts receivable, net of $184.1 million and available borrowings under our five-year 2019 Revolving Facility (as defined below) of $60.2 million. We anticipate our principal uses of cash for fiscal 2023 will be purchases of finished goods inventory from our contract manufacturers, payroll, payments under debt obligations and related interest, payments under lease obligations, purchases of property and equipment and other operating expenses related to the development and marketing of our products. We believe that our existing cash, cash flows from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months. We are not currently aware of any material cash requirements beyond the next 12 months other than those described above for fiscal 2023 and our known contractual obligations. See the section titled “Contractual Obligations” below.

[0001564590-22-030248:mdna:109]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of our shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in the second quarter of fiscal 2019 and $30.0 million was used for repurchases in fiscal 2020. In February 2020 the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchases for three years from February 5, 2020. On May 18, 2022, our Board of Directors authorized an increase to our share repurchase authorization to $200.0 million over a three-year period beginning in our fiscal year commencing July 1, 2022. Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, and Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate us to acquire any shares of our common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the year ended June 30, 2022 we repurchased a total of 3,881,683 shares of common stock on the open market at a total cost of $45.0 million.

[0001564590-22-030248:mdna:110]
In connection with the acquisition of Aerohive, as discussed in Note 4, Business Combinations, in Notes to Consolidated Financial Statements, as of August 9, 2019, we amended the 2018 Credit Agreement, which is no longer outstanding, and entered into the Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an

[0001564590-22-030248:mdna:111]
Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380.0 million and a 5-year revolving loan facility in an aggregate principal amount of $75.0 million (“2019 Revolving Facility”). In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-22-030248:mdna:112]
At our election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s Consolidated Leverage Ratio. All Eurodollar loans are subject to a Base Rate floor of 0.00%. The 2019 Credit Agreement is secured by substantially all of our assets.

[0001564590-22-030248:mdna:113]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-22-030248:mdna:114]
On April 8, 2020, we entered into the first amendment to our 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which superseded the First Amendment and provided certain revised terms and financial covenants effective through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed effect. The Second Amendment required us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, we were not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5% and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we came back into compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into the Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into the Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-22-030248:mdna:115]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in our Eurodollar loan spread decreasing from 4.5% during the Suspension Period to 2.75%, the unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-22-030248:mdna:116]
Key Components of Cash Flows and Liquidity

[0001564590-22-030248:mdna:117]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands) for the fiscal years ended June 30, 2022, 2021, and 2020:

[0001564590-22-030248:mdna:118]
|  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Net cash provided by operating activities | $ | 128,177 |  |  | $ | 144,535 |  |  | $ | 35,884 |  |
| Net cash used in investing activities |  | (84,950 | ) |  |  | (17,176 | ) |  |  | (189,477 | ) |
| Net cash (used in) provided by financing activities |  | (94,663 | ) |  |  | (74,782 | ) |  |  | 178,492 |  |
| Foreign currency effect on cash |  | (936 | ) |  |  | 445 |  |  |  | (634 | ) |
| Net (decrease) increase in cash | $ | (52,372 | ) |  | $ | 53,022 |  |  | $ | 24,265 |  |

[0001564590-22-030248:mdna:119]
Cash was $194.5 million at June 30, 2022, representing a decrease of $52.4 million from $246.9 million at June 30, 2021. This decrease was primarily due to cash used in financing activities of $94.7 million mainly as a result of payments on the Term Loan and share repurchases and cash used in investing activities of $85.0 million, mainly for acquisition of Ipanema partially offset by cash provided by operations of $128.2 million.

[0001564590-22-030248:mdna:120]
Cash was $246.9 million at June 30, 2021, representing an increase of $53.0 million from $193.9 million at June 30, 2020. This increase was primarily due to cash provided by operations of $144.5 million partially offset by cash used in financing activities of $74.8 million mainly as a result of payments on the Term Loan and the Revolving Facility and cash used in investing activities of $17.2 million, mainly for capital expenditures.

[0001564590-22-030248:mdna:121]
Net Cash Provided by Operating Activities

[0001564590-22-030248:mdna:122]
Cash provided by operating activities during fiscal year ended June 30, 2022 was $128.2 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2022 were net income of $44.3 million, non-cash expenses of $104.0 million for items such as amortization of intangibles, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included increases in accounts payable and deferred revenue. These amounts were partially offset by increases in accounts receivable, inventories and prepaid expenses and other assets and decreases in accrued compensation, current and long-term liabilities and operating lease liabilities.

[0001564590-22-030248:mdna:123]
Cash provided by operating activities during fiscal year ended June 30, 2021 was $144.5 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2021 were net income of $1.9 million, non-cash expenses of $121.7 million for items such as amortization of intangibles, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and imputed interest. Other sources of cash for the period included a decrease in inventory and increases in accounts payable, accrued compensation and deferred revenue. These amounts were partially offset by increases in accounts receivable and prepaid expenses and other current assets and decreases in the current and long-term liabilities and operating lease liabilities.

[0001564590-22-030248:mdna:124]
Cash provided by operating activities during fiscal year ended June 30, 2020 was $35.9 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2020 were non-cash expenses such as amortization of intangibles, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, restructuring charges, deferred income taxes and imputed interest. Other sources of cash for the period included a decrease in accounts receivables, inventory, and prepaid expenses and other current assets and increases in deferred revenue. These amounts were partially offset by our net loss of $126.8 million, decreases in accounts payable, accrued compensation, other current and long-term liabilities, and operating lease liabilities.

[0001564590-22-030248:mdna:125]
Net Cash Used in Investing Activities

[0001564590-22-030248:mdna:126]
Cash used in investing activities during fiscal year ended June 30, 2022 was $85.0 million, primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $15.4 million for purchases of property and equipment.

[0001564590-22-030248:mdna:127]
Cash used in investing activities during fiscal year ended June 30, 2021 was $17.2 million for the purchases of property and equipment.

[0001564590-22-030248:mdna:128]
Cash used in investing activities during fiscal year ended June 30, 2020 was $189.5 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $15.3 million, which was partially offset by proceeds of $45.2 million related to the maturity and sales of short-term investments.

[0001564590-22-030248:mdna:129]
Net cash (Used in) Provided by Financing Activities

[0001564590-22-030248:mdna:130]
Cash used in financing activities during fiscal year ended June 30, 2022 was $94.7 million due primarily to share repurchases of $45.0 million, debt repayments of $38.1 million, payments of contingent consideration of $1.0 million and $4.0 million of deferred payments on acquisitions and a $6.5 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options.

[0001564590-22-030248:mdna:131]
Cash used in financing activities during fiscal year ended June 30, 2021 was $74.8 million due primarily to debt repayments of $74.0 million, payments of contingent consideration of $1.3 million and $4.0 million of deferred payments on acquisitions. This was partially offset by $4.5 million of proceeds from issuance of shares of our common stock under our ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards.

[0001564590-22-030248:mdna:132]
Cash provided by financing activities during fiscal year ended June 30, 2020 was $178.5 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $55.0 million of borrowings under our 2019 Revolving Facility, and by $8.8 million of proceeds from issuance of shares of our common stock under our ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards. This was partially offset by payments on debt obligations totaling $34.5 million, payment of loan fees incurred in connection with our 2019 Credit Facility and related amendments of $12.0 million, payments of contingent consideration of $4.3 million and $4.0 million of deferred payments on acquisitions. Cash provided by financing activities for the period also included repurchasing of our common shares of $30.0 million during the fiscal year ended June 30, 2020, in accordance with our approved share repurchase plan.

[0001564590-22-030248:mdna:133]
Foreign Currency Effect on Cash

[0001564590-22-030248:mdna:134]
Foreign currency effect on cash increased in 2022, primarily due to changes in exchange rates between the U.S. Dollar and particularly the Indian Rupee, U.K. Pound, and the Euro.

[0001564590-22-030248:mdna:135]
Contractual Obligations

[0001564590-22-030248:mdna:136]
As of June 30, 2022, we have contractual obligations for debt obligations, purchase obligations, lease obligations and other obligations.

[0001564590-22-030248:mdna:137]
Our debt obligations relate to amounts owed under our 2019 Credit Agreement. As of June 30, 2022, we have $308.6 million of debt outstanding which are payable on quarterly installments through our fiscal year 2025. We are subject to interest rate on our debt obligations and unused commitment fee. See Note 8, Debt, in the Notes to Consolidated Financial Statements for additional information regarding our debt obligations.

[0001564590-22-030248:mdna:138]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of June 30, 2022, we have non-cancelable commitments to purchase $60.3 million of inventory. See Note 10, Commitments and Contingencies, in the Notes to Consolidated Financial Statements for additional information regarding our purchase obligations.

[0001564590-22-030248:mdna:139]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2032. As of June 30, 2022, the value of our obligations under operating leases was $53.3 million. See Note 8, Debt, in the Notes to Consolidated Financial Statements for additional information regarding our lease obligations.

[0001564590-22-030248:mdna:140]
We have contractual commitments to our suppliers which represent commitments for future services. As of June 30, 2022, we have contractual commitments of $54.8 million that are due through our fiscal year 2027.

[0001564590-22-030248:mdna:141]
We have deferred payments related to Data Center Business consideration obligation of $3.0 as of June 30, 2022 which are paid at $1.0 million per quarter.

[0001564590-22-030248:mdna:142]
We have immaterial income tax liabilities related to uncertain tax positions and we are unable to reasonably estimate the timing of the settlement of those liabilities.

[0001564590-22-030248:mdna:143]
We do not have any material commitments for capital expenditures as of June 30, 2022.

[0001564590-22-030248:mdna:144]
Off-Balance Sheet Arrangements

[0001564590-22-030248:mdna:145]
We did not have any off-balance sheet arrangements as of June 30, 2022.
