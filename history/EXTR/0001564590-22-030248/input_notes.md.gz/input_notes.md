# EXTR notes — 0001564590-22-030248


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001564590-22-030248:notes:1]
Portions of the registrant's definitive proxy statement for the year ended June 30, 2022 Annual Meeting of Stockholders to be filed with the Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated herein by reference in Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-22-030248:notes:2]
1. Description of Business and Basis of Presentation

[0001564590-22-030248:notes:3]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-22-030248:notes:4]
Fiscal Year

[0001564590-22-030248:notes:5]
The Company uses a fiscal calendar year ending on June 30. All references herein to fiscal year ended “fiscal year ended 2022” or “2022”; “fiscal 2021” or “2021”; “fiscal 2020” or “2020” represent the fiscal years ending, respectively.

[0001564590-22-030248:notes:6]
Principles of Consolidation

[0001564590-22-030248:notes:7]
The consolidated financial statements include the accounts of Extreme Networks, Inc. and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-22-030248:notes:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end exchange rates; and revenues and expenses are translated using the monthly average rate.

[0001564590-22-030248:notes:9]
Accounting Estimates

[0001564590-22-030248:notes:10]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the financial statements and the accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-22-030248:notes:11]
2. Summary of Significant Accounting Policies

[0001564590-22-030248:notes:12]
Revenue Recognition

[0001564590-22-030248:notes:13]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers. The Company derives revenues primarily from sales of its networking equipment, with the remaining revenues generated from software delivered as a service (“SaaS”) and service fees relating to maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0001564590-22-030248:notes:14]
See Note 3, Revenues, for further discussion.

[0001564590-22-030248:notes:15]
Cash and Cash Equivalents

[0001564590-22-030248:notes:16]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents.

[0001564590-22-030248:notes:17]
Allowance for Product Returns

[0001564590-22-030248:notes:18]
The Company maintains estimates for product returns based on its historical returns, analysis of credit memos and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is shown as a reduction of accounts receivable as there is a contractual right of offset and returns are applied to accounts receivable balances outstanding as of the balance sheet date. There have not been material revisions to the estimated product returns for any periods presented.

[0001564590-22-030248:notes:19]
Allowance for Credit Losses

[0001564590-22-030248:notes:20]
The Company maintains an allowance for credit losses which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring certain of its customers in the Asia-Pacific region to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001564590-22-030248:notes:21]
Inventories

[0001564590-22-030248:notes:22]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory is obsolete or may be in excess of anticipated demand based upon assumptions about future demand. At the point of the loss recognition, a new lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-22-030248:notes:23]
Long-Lived Assets

[0001564590-22-030248:notes:24]
Long-lived assets include (a) property and equipment, (b) operating lease right-of-use (“ROU”) assets, (c) goodwill and intangible assets, and (d) other assets. Property and equipment, ROU assets, and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001564590-22-030248:notes:25]
(a) Property and Equipment, Net

[0001564590-22-030248:notes:26]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and purchased software. Estimated useful lives of three to seven years are used for office equipment and furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms.

[0001564590-22-030248:notes:27]
(b) Leases

[0001564590-22-030248:notes:28]
The Company leases facilities, equipment and vehicles under operating leases that expire on various dates through fiscal 2028. The Company determines if an arrangement is a lease at inception. We evaluate the classification of leases at commencement date and as necessary, at modification. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as ROU assets with associated operating lease liabilities on the consolidated balance sheets.

[0001564590-22-030248:notes:29]
ROU assets under the Company’s operating leases represent the Company’s right to use an underlying asset over the lease term. Operating lease liabilities represent the Company’s obligation to make payments arising from the lease. The ROU asset is reduced over a straight-line or other systematic basis representative of the pattern in which the Company expects to consume the ROU assets’ future economic benefits. The ROU asset is also adjusted for leasehold improvements paid by the lessor, lease incentives, and asset impairments, among other things.

[0001564590-22-030248:notes:30]
See Note 9, Leases, for further discussion.

[0001564590-22-030248:notes:31]
(c) Goodwill and Intangible Assets

[0001564590-22-030248:notes:32]
Goodwill and intangible assets are generated as a result of business combinations and are comprised of, among other things, developed technology, customer relationships, trade names, and licensing agreements.

[0001564590-22-030248:notes:33]
The remaining lives of intangibles are considered regularly along with assessments of impairment and lives are adjusted or impairment charges taken when required.

[0001564590-22-030248:notes:34]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company has one reporting unit and performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceed directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Any loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. Based on the results of the goodwill impairment analysis, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0001564590-22-030248:notes:35]
Business Combinations

[0001564590-22-030248:notes:36]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, useful lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0001564590-22-030248:notes:37]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0001564590-22-030248:notes:38]
Deferred Revenue

[0001564590-22-030248:notes:39]
Deferred revenue represents amounts for (i) deferred maintenance, support, and SaaS revenues, and (ii) other deferred revenue including professional services when the revenue recognition criteria have not been met.

[0001564590-22-030248:notes:40]
Product Warranties and Guarantees

[0001564590-22-030248:notes:41]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-22-030248:notes:42]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-22-030248:notes:43]
Stock-based Compensation

[0001564590-22-030248:notes:44]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock options and share purchase options under the 2014 ESPP using the Black-Scholes-Merton option valuation model. The fair value of RSUs is based on the closing stock price of the Company’s common stock on the grant date.

[0001564590-22-030248:notes:45]
The Company grants certain employees performance-based stock options and RSUs. The performance metrics include company-wide financial performance and/or market conditions. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0001564590-22-030248:notes:46]
Advertising

[0001564590-22-030248:notes:47]
Advertising costs are expensed as incurred. Advertising expenses were immaterial in fiscal years 2022, 2021 and 2020.

[0001564590-22-030248:notes:48]
Income Taxes

[0001564590-22-030248:notes:49]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0001564590-22-030248:notes:50]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions. The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes. For additional discussion, see Note 16, Income Taxes.

[0001564590-22-030248:notes:51]
Recently Adopted Accounting Pronouncements

[0001564590-22-030248:notes:52]
In December 2019, the Financial Accounting Standards Board (“the FASB”) issued ASU 2019-12, Income Taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of Accounting Standards Codification (“ASC”) 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The standard was adopted on July 1, 2021 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-22-030248:notes:53]
Recently Issued and Adopted Accounting Pronouncements

[0001564590-22-030248:notes:54]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 and interim periods within those annual periods, with early adoption permitted, including adoption in an interim period. The Company elected to early adopt the standard in the quarter ended December 31, 2021 and retrospectively applied the standard to the acquisition that happened in the current fiscal year beginning July 1, 2021. The application of the guidance increased the deferred revenue balance acquired through the acquisition of Ipanema by $7.1 million as of the acquisition date.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001564590-22-030248:notes:55]
The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts, and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0001564590-22-030248:notes:56]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0001564590-22-030248:notes:57]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenues from maintenance contracts and SaaS are recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which generally ranges from one to five years. For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Sales taxes collected from customers are excluded from revenues. Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the historical actuals. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-22-030248:notes:58]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price. At the time the distributor invoices its end customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation adjustments are an additional form of variable consideration and are estimated based on historical return rates and estimates provided by the distributors. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-22-030248:notes:59]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using the other observable inputs.

[0001564590-22-030248:notes:60]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenue recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.

[0001564590-22-030248:notes:61]
At June 30, 2022, the Company had $401.6 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 59% of this amount in fiscal 2023, an additional 21% percent in fiscal 2024 and 20% of the balance thereafter.

[0001564590-22-030248:notes:62]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenue. These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-22-030248:notes:63]
Revenue recognized for the years ended June 30, 2022 and 2021, that was included in the deferred revenue balance at the beginning of each period was $208.4 million and $188.4 million, respectively.

[0001564590-22-030248:notes:64]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals, are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $16.3 million and $13.1 million at June 30, 2022 and 2021, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations. Amortization recognized during the years ended June 30, 2022, 2021 and 2020 was $7.5 million, $5.6 million and $5.2 million, respectively.

[0001564590-22-030248:notes:65]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-22-030248:notes:66]
Disaggregation of Revenues: The Company operates in three geographic regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan. The following tables set forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-22-030248:notes:67]
|  |  | Year Ended June 30, 2022 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 237,163 |  |  | $ | 266,472 |  |  | $ | 503,635 |  |
| Other |  |  | 27,018 |  |  |  | 17,590 |  |  |  | 44,608 |  |
| Total Americas |  |  | 264,181 |  |  |  | 284,062 |  |  |  | 548,243 |  |
| EMEA |  |  | 325,290 |  |  |  | 151,791 |  |  |  | 477,081 |  |
| APAC |  |  | 17,517 |  |  |  | 69,480 |  |  |  | 86,997 |  |
| Total net revenues |  | $ | 606,988 |  |  | $ | 505,333 |  |  | $ | 1,112,321 |  |

[0001564590-22-030248:notes:68]
|  |  | Year Ended June 30, 2021 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 244,851 |  |  | $ | 240,620 |  |  | $ | 485,471 |  |
| Other |  |  | 31,583 |  |  |  | 16,466 |  |  |  | 48,049 |  |
| Total Americas |  |  | 276,434 |  |  |  | 257,086 |  |  |  | 533,520 |  |
| EMEA |  |  | 250,897 |  |  |  | 136,648 |  |  |  | 387,545 |  |
| APAC |  |  | 14,280 |  |  |  | 74,073 |  |  |  | 88,353 |  |
| Total net revenues |  | $ | 541,611 |  |  | $ | 467,807 |  |  | $ | 1,009,418 |  |

[0001564590-22-030248:notes:69]
|  |  | Year Ended June 30, 2020 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 218,276 |  |  | $ | 241,493 |  |  | $ | 459,769 |  |
| Other |  |  | 19,530 |  |  |  | 20,103 |  |  |  | 39,633 |  |
| Total Americas |  |  | 237,806 |  |  |  | 261,596 |  |  |  | 499,402 |  |
| EMEA |  |  | 218,947 |  |  |  | 138,254 |  |  |  | 357,201 |  |
| APAC |  |  | 21,554 |  |  |  | 69,862 |  |  |  | 91,416 |  |
| Total net revenues |  | $ | 478,307 |  |  | $ | 469,712 |  |  | $ | 948,019 |  |

[0001564590-22-030248:notes:70]
For the year ended June 30, 2022 and 2021, the Company generated 12% and 11%, respectively, of its revenue from the Netherlands. No other foreign country accounted for 10% or more of the Company’s net revenue for the years ended June 30, 2022, 2021 and 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-22-030248:notes:71]
3. Revenues

[0001564590-22-030248:notes:72]
Concentrations

[0001564590-22-030248:notes:73]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-22-030248:notes:74]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenues:

[0001564590-22-030248:notes:75]
|  |  |  |  |  | Year Ended |  |  |  |  |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| TD Synnex Corporation | 20% |  |  | 19% |  |  | 18% |  |
| Westcon Group Inc. | 18% |  |  | 16% |  |  | 13% |  |
| Jenne Inc. | 16% |  |  | 18% |  |  | 15% |  |

[0001564590-22-030248:notes:76]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable, net as of June 30, 2022 and June 30, 2021:

[0001564590-22-030248:notes:77]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Jenne Inc. |  | 28% |  |  | 24% |  |
| TD Synnex Corporation |  | 11% |  |  | 19% |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-22-030248:notes:78]
4. Business Combinations

[0001564590-22-030248:notes:79]
The Company completed one acquisition during the fiscal year ended June 30, 2022 and one acquisition during the fiscal year ended June 30, 2020. The acquisitions were accounted for using the acquisition method of accounting. The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The purchase price of each acquisition has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition. Inventories were valued at fair value using the net realizable value approach. The fair value of property and equipment was determined using a cost approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount the Company would be required to pay to a third party to assume the obligation. Intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. Results of operations of the acquired entity is included in the Company’s operations beginning with the closing date of each acquisition.

[0001564590-22-030248:notes:80]
Fiscal 2022 Acquisition

[0001564590-22-030248:notes:81]
Ipanema Acquisition

[0001564590-22-030248:notes:82]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of InfoVista pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million, which was funded from existing cash on hand. The primary reason for the acquisition was to acquire the talent and the technology to allow the Company to expand its portfolio with new cloud-managed SD-WAN and security offerings to support its enterprise customers.

[0001564590-22-030248:notes:83]
The acquired assets and liabilities of Ipanema have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets. The fair value of the acquired deferred revenue was estimated using the cost build-up approach which was subsequently remeasured in accordance with ASC Topic 606 based on the recently issued and adopted guidance ASU 2021-08. The Company has completed its analysis of the tax implications of the acquisition of the intangible assets and a deferred tax liability has been established for the non-deductible intangible amortization, increasing the overall level of goodwill associated with the Acquisition. All valuations are finalized as of June 30, 2022. Results of operations of Ipanema have been included in the operations of the Company beginning with the Acquisition Date.

[0001564590-22-030248:notes:84]
The purchase price allocation is set forth in the table below and reflects estimated fair values (in thousands):

[0001564590-22-030248:notes:85]
|  | Preliminary Allocation as of September 14, 2021 |  |  |  |  | Adjustments |  |  | Final Allocation as of June 30, 2022 |  |
| Cash and cash equivalents | $ | 1,364 |  |  |  |  | $ | — |  |  | $ | 1,364 |  |
| Accounts receivable, net |  | 1,440 |  |  |  |  |  | (6 | ) | a |  | 1,434 |  |
| Inventories |  | 337 |  |  |  |  |  | (63 | ) | a |  | 274 |  |
| Prepaid expenses and other current assets |  | 1,841 |  |  |  |  |  | (1,231 | ) | a |  | 610 |  |
| Property and equipment |  | 46 |  |  |  |  |  | — |  |  |  | 46 |  |
| Other assets |  | 21 |  |  |  |  |  | — |  |  |  | 21 |  |
| Accounts payable |  | (1,220 | ) |  |  |  |  | 244 |  | a |  | (976 | ) |
| Accrued compensation and benefits |  | (2,304 | ) |  |  |  |  | 467 |  | a |  | (1,837 | ) |
| Accrued warranty |  | (41 | ) |  |  |  |  | — |  |  |  | (41 | ) |
| Other accrued liabilities |  | (71 | ) |  |  |  |  | (51 | ) | a |  | (122 | ) |
| Deferred revenue |  | (2,758 | ) |  |  |  |  | (7,376 | ) | a,b |  | (10,134 | ) |
| Deferred taxes |  | - |  |  |  |  |  | (4,320 | ) | c |  | (4,320 | ) |
| Other liabilities |  | (723 | ) |  |  |  |  | — |  |  |  | (723 | ) |
| Net tangible liabilities |  | (2,068 | ) |  |  |  |  | (12,336 | ) |  |  | (14,404 | ) |
| Identifiable intangible assets |  | 16,300 |  |  |  |  |  | — |  |  |  | 16,300 |  |
| Goodwill |  | 56,649 |  |  |  |  |  | 12,336 |  | a,b,c |  | 68,985 |  |
| Total intangible assets acquired |  | 72,949 |  |  |  |  |  | 12,336 |  |  |  | 85,285 |  |
| Total net assets acquired | $ | 70,881 |  |  |  |  | $ | — |  |  | $ | 70,881 |  |

[0001564590-22-030248:notes:86]
The changes made during the period in the table above include: (a) measurement period adjustments attributable to the Company’s review of the additional information being obtained on preacquisition assets and liabilities, (b) the increase in deferred revenue (and the corresponding increase to Goodwill by the same amount) is the result of the adoption of ASU 2021-08 in the period ended December 31, 2021, and (c) establishment of deferred tax liability.

[0001564590-22-030248:notes:87]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001564590-22-030248:notes:88]
| Intangible Assets |  | Weighted Average Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technologies |  |  | 6 |  |  | $ | 14,500 |  |
| Customer relationships |  |  | 4 |  |  |  | 1,800 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 16,300 |  |

[0001564590-22-030248:notes:89]
The amortization for the developed technologies is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Ipanema. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as this acquisition is a nontaxable stock acquisition.

[0001564590-22-030248:notes:90]
The results of operations of Ipanema are included in the accompanying consolidated results of operations beginning September 15, 2021. The overall results of Operations of Ipanema were not material to the consolidated financial statements of Extreme.

[0001564590-22-030248:notes:91]
For the period ended June 30, 2022, the Company incurred acquisition and integration related expenses of $7.0 million associated with the acquisition of Ipanema. Acquisition and integration costs consisted primarily of professional fees for financial and legal advisory services. Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0001564590-22-030248:notes:92]
Pro forma financial information

[0001564590-22-030248:notes:93]
The following unaudited pro forma results of operations are presented as though the Acquisition had occurred as of the beginning of the earliest period presented, July 1, 2020, the beginning of fiscal 2021, after giving effect to purchase accounting adjustments relating to deferred revenue, depreciation and amortization of intangibles and acquisition and integration costs.

[0001564590-22-030248:notes:94]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2021, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions, which could alter the unaudited pro forma results.

[0001564590-22-030248:notes:95]
The unaudited pro forma financial information for the year ended June 30, 2022 combines the results for Extreme for such periods assuming the transaction closed on July 1, 2020, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s historical results up to the Acquisition Date. The unaudited pro forma financial information for the year ended June 30, 2021 combines the historical results of operations for Extreme assuming the transaction closed on July 1, 2020 and historical results for Ipanema.

[0001564590-22-030248:notes:96]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0001564590-22-030248:notes:97]
|  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |
| Net revenues | $ | 1,115,942 |  |  | $ | 1,031,825 |  |
| Net income (loss) | $ | 53,659 |  |  | $ | (6,755 | ) |
| Net income (loss) per share - basic | $ | 0.41 |  |  | $ | (0.05 | ) |
| Net income (loss) per share - diluted | $ | 0.40 |  |  | $ | (0.05 | ) |
| Shares used in per share calculation - basic |  | 129,437 |  |  |  | 124,019 |  |
| Shares used in per share calculation - diluted |  | 133,494 |  |  |  | 124,019 |  |

[0001564590-22-030248:notes:98]
Fiscal 2020 Acquisition

[0001564590-22-030248:notes:99]
Aerohive Acquisition

[0001564590-22-030248:notes:100]
On August 9, 2019, the Company consummated its acquisition of all of the outstanding common stock of Aerohive Networks, Inc. (“Aerohive”) pursuant to that certain Agreement and Plan of Merger entered into as of June 26, 2019. Under the terms of the Aerohive acquisition, the net consideration paid by Extreme to Aerohive stockholders was $267.1 million. The acquired assets and liabilities of Aerohive were recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets.

[0001564590-22-030248:notes:101]
The components of aggregate purchase consideration are as follows (in thousands):

[0001564590-22-030248:notes:102]
| Purchase consideration |  | August 9, 2019 |  |
| Cash paid to acquire outstanding shares |  | $ | 263,616 |  |
| Replacement of stock-based awards |  |  | 3,530 |  |
| Aggregate purchase consideration |  | $ | 267,146 |  |

[0001564590-22-030248:notes:103]
The purchase price allocation is set forth in the table below and reflects estimated fair values (in thousands).

[0001564590-22-030248:notes:104]
|  | Final Allocation as of June 30, 2020 |  |
| Cash and cash equivalents | $ | 44,158 |  |
| Short-term investments |  | 45,148 |  |
| Accounts receivable, net |  | 11,753 |  |
| Inventories |  | 19,232 |  |
| Prepaid expenses and other current assets |  | 3,924 |  |
| Property and equipment |  | 2,364 |  |
| Operating lease right-of-use assets |  | 6,336 |  |
| Other assets |  | 2,195 |  |
| Debt |  | (20,000 | ) |
| Accounts payable |  | (9,737 | ) |
| Accrued compensation and benefits |  | (7,129 | ) |
| Accrued warranty |  | (570 | ) |
| Other accrued liabilities |  | (1,960 | ) |
| Operating lease liabilities |  | (4,752 | ) |
| Deferred revenue |  | (68,415 | ) |
| Other liabilities |  | (483 | ) |
| Net tangible assets |  | 22,064 |  |
| Identifiable intangible assets |  | 52,500 |  |
| Goodwill |  | 192,582 |  |
| Total intangible assets acquired |  | 245,082 |  |
| Total net assets acquired | $ | 267,146 |  |

[0001564590-22-030248:notes:105]
The following table presents details of the identifiable intangible assets acquired as part of the Aerohive acquisition (dollars in thousands):

[0001564590-22-030248:notes:106]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 4 |  |  | $ | 39,100 |  |
| Backlog |  |  | 1 |  |  |  | 400 |  |
| Customer relationships |  |  | 7 |  |  |  | 11,400 |  |
| Trade names |  |  | 1 |  |  |  | 1,600 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 52,500 |  |

[0001564590-22-030248:notes:107]
The amortization for the developed technology and backlog is recorded in “Cost of revenues” for product and service and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Aerohive along with the future potential of the technology. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as the Acquisition is a nontaxable stock acquisition.

[0001564590-22-030248:notes:108]
The results of operations of Aerohive are included in the accompanying consolidated statements of operations beginning August 9, 2019. The Aerohive revenues for the year ended June 30, 2020 were $125.1 million and were incorporated into the revenues of the Company. Certain associated expenses of Aerohive were incorporated with the results of operations of the Company and, therefore, stand-alone operating results are not available for the year ended June 30, 2020.

[0001564590-22-030248:notes:109]
In the year ended June 30, 2020, the Company incurred acquisition and integration related expenses of $32.1 million associated with the Aerohive acquisition, including a $6.8 million compensation charge for certain Aerohive Executive stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts. Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for terminated Aerohive employees. Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-22-030248:notes:110]
5. Balance Sheet Components

[0001564590-22-030248:notes:111]
Accounts Receivable

[0001564590-22-030248:notes:112]
The following is a summary of accounts receivable (in thousands):

[0001564590-22-030248:notes:113]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Accounts receivable |  | $ | 368,778 |  |  | $ | 324,343 |  |
| Customer rebates |  |  | (163,953 | ) |  |  | (149,510 | ) |
| Allowance for credit losses |  |  | (695 | ) |  |  | (986 | ) |
| Allowance for product returns |  |  | (20,033 | ) |  |  | (17,371 | ) |
| Accounts receivable, net |  | $ | 184,097 |  |  | $ | 156,476 |  |

[0001564590-22-030248:notes:114]
The following table is a summary of the allowance for credit losses (in thousands):

[0001564590-22-030248:notes:115]
| Description |  | Balance at beginning of period |  |  | Provision for expected credit losses |  |  | Deductions (1) |  |  | Balance at end of period |  |
| Year Ended June 30, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 986 |  |  | $ | 39 |  |  | $ | (330 | ) |  | $ | 695 |  |
| Year Ended June 30, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 1,212 |  |  | $ | 409 |  |  | $ | (635 | ) |  | $ | 986 |  |
| Year Ended June 30, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 1,054 |  |  | $ | 1,289 |  |  | $ | (1,131 | ) |  | $ | 1,212 |  |

[0001564590-22-030248:notes:116]
|  | (1) | Uncollectible accounts written off, net of recoveries |

[0001564590-22-030248:notes:117]
The following table is a summary of the Company’s allowance for product returns (in thousands):

[0001564590-22-030248:notes:118]
| Description |  | Balance at beginning of period |  |  | Additions |  |  | Deductions |  |  | Balance at end of period |  |
| Year Ended June 30, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 17,371 |  |  | $ | 67,407 |  |  | $ | (64,745 | ) |  | $ | 20,033 |  |
| Year Ended June 30, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 27,963 |  |  | $ | 67,113 |  |  | $ | (77,705 | ) |  | $ | 17,371 |  |
| Year Ended June 30, 2020: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 25,897 |  |  | $ | 76,802 |  |  | $ | (74,736 | ) |  | $ | 27,963 |  |

[0001564590-22-030248:notes:119]
The following is a summary of the Company’s inventory by category (in thousands):

[0001564590-22-030248:notes:120]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Finished goods |  | $ | 40,733 |  |  | $ | 27,901 |  |
| Raw materials |  |  | 8,498 |  |  |  | 4,984 |  |
| Total inventories |  | $ | 49,231 |  |  | $ | 32,885 |  |

[0001564590-22-030248:notes:121]
Property and Equipment, Net

[0001564590-22-030248:notes:122]
The following is a summary of the Company’s property and equipment by category (in thousands):

[0001564590-22-030248:notes:123]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Computers and equipment |  | $ | 75,387 |  |  | $ | 75,866 |  |
| Purchased software |  |  | 47,161 |  |  |  | 40,037 |  |
| Office equipment, furniture and fixtures |  |  | 9,463 |  |  |  | 10,201 |  |
| Leasehold improvements |  |  | 52,564 |  |  |  | 53,329 |  |
| Total property and equipment |  |  | 184,575 |  |  |  | 179,433 |  |
| Less: accumulated depreciation and amortization |  |  | (134,997 | ) |  |  | (124,429 | ) |
| Property and equipment, net |  | $ | 49,578 |  |  | $ | 55,004 |  |

[0001564590-22-030248:notes:124]
The Company recognized depreciation expense of $19.8 million, $23.0 million, and $28.6 million related to property and equipment during the years ended June 30, 2022, 2021 and 2020, respectively.

[0001564590-22-030248:notes:125]
The following table summarizes contract liabilities which are shown as deferred revenue (in thousands):

[0001564590-22-030248:notes:126]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Deferred maintenance, support, and SaaS |  | $ | 393,289 |  |  | $ | 328,797 |  |
| Other deferred revenue |  |  | 8,330 |  |  |  | 16,787 |  |
| Total deferred revenue |  |  | 401,619 |  |  |  | 345,584 |  |
| Less: current portion |  |  | 238,262 |  |  |  | 212,412 |  |
| Non-current deferred revenue |  | $ | 163,357 |  |  | $ | 133,172 |  |

[0001564590-22-030248:notes:127]
Accrued Warranty

[0001564590-22-030248:notes:128]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0001564590-22-030248:notes:129]
|  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Balance beginning of period |  | $ | 11,623 |  |  | $ | 14,035 |  |  | $ | 14,779 |  |
| Warranties assumed due to acquisition |  |  | 41 |  |  |  | — |  |  |  | 570 |  |
| New warranties issued |  |  | 13,314 |  |  |  | 11,760 |  |  |  | 19,686 |  |
| Warranty expenditures |  |  | (14,126 | ) |  |  | (14,172 | ) |  |  | (21,000 | ) |
| Balance end of period |  | $ | 10,852 |  |  | $ | 11,623 |  |  | $ | 14,035 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-22-030248:notes:130]
6. Fair Value Measurements

[0001564590-22-030248:notes:131]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0001564590-22-030248:notes:132]
|  | • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-22-030248:notes:133]
|  | • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-22-030248:notes:134]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value. |

[0001564590-22-030248:notes:135]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-22-030248:notes:136]
| June 30, 2022 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0001564590-22-030248:notes:137]
| June 30, 2021 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 560 |  |  | $ | — |  |  | $ | 560 |  |
| Interest rate swaps |  |  | — |  |  |  | 1,133 |  |  |  | — |  |  |  | 1,133 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 913 |  |  |  | 913 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,693 |  |  | $ | 913 |  |  | $ | 2,606 |  |

[0001564590-22-030248:notes:138]
The Company’s financial instruments consist of cash, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0001564590-22-030248:notes:139]
The fair value of derivative instruments under the Company’s foreign exchange forward contracts and interest rate swaps are estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.

[0001564590-22-030248:notes:140]
As of June 30, 2022 and 2021, foreign exchange forward currency contracts not designated as hedging instruments had a notional amount of $9.6 million and $23.0 million, respectively. These contracts have maturities of less than 40 days. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income or expense. For the year ended June 30, 2022, the net loss recorded in the consolidated statement of operations from these contracts was $1.4 million. For the years ended June 30, 2021 and 2020, the net gains recorded in the consolidated statements of operations related to these contracts were $0.5 million and $0.1 million, respectively. As of June 30, 2021, foreign exchange forward currency contracts designated as hedging instruments had a notional amount of $21.8 million. These contracts have maturities of less than twelve months. Gains and losses arising from contracts designated as hedging instruments are recorded as a component of accumulated other comprehensive income (loss). As of June 30, 2021 these contracts had unrealized loss of $0.2 million. There were no outstanding foreign exchange forward contracts that were designated as hedging instruments at June 30, 2022 and at June 30, 2020. See Note 14, Derivatives and Hedging, for additional information.

[0001564590-22-030248:notes:141]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of June 30, 2022 and 2021, the Company had interest rate swap contracts, designated as cash flow hedges, with the total notional amount of $75.0 million and $200.0 million, respectively. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive income (loss). As of June 30, 2022 and 2021, these contracts had unrealized gain of $1.3 million and unrealized loss of $1.1 million, respectively. See Note 14, Derivatives and Hedging, for additional information.

[0001564590-22-030248:notes:142]
The fair value of the borrowings under the 2019 Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $308.6 million and $346.7 million as of June 30, 2022 and 2021, respectively.

[0001564590-22-030248:notes:143]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.

[0001564590-22-030248:notes:144]
At June 30, 2021, the Company reflected one liability measured at fair value of $0.9 million for contingent consideration related to a certain acquisition completed in fiscal 2018. There was no outstanding liability at June 30, 2022. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent

[0001564590-22-030248:notes:145]
consideration obligations is recorded in general and administrative expenses in the accompanying consolidated statements of operations.

[0001564590-22-030248:notes:146]
The change in the acquisition-related contingent consideration obligations is as follows (in thousands):

[0001564590-22-030248:notes:147]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Beginning balance |  | $ | 913 |  |  | $ | 2,167 |  |  | $ | 6,298 |  |
| Payments |  |  | (1,024 | ) |  |  | (1,298 | ) |  |  | (4,251 | ) |
| Accretion on discount |  |  | 111 |  |  |  | 44 |  |  |  | 120 |  |
| Ending balance |  | $ | — |  |  | $ | 913 |  |  | $ | 2,167 |  |

[0001564590-22-030248:notes:148]
There were no transfers of assets or liabilities between Level 1, Level 2 or Level 3 during the years ended June 30, 2022 and 2021. There were no impairments recorded during the years ended June 30, 2022 and 2021.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-22-030248:notes:149]
7. Goodwill and Intangible Assets

[0001564590-22-030248:notes:150]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-22-030248:notes:151]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Balance at beginning of period |  |  | 331,159 |  |  | $ | 331,159 |  |
| Additions due to acquisitions (see Note 4) |  |  | 68,985 |  |  |  | — |  |
| Balance at end of period |  | $ | 400,144 |  |  | $ | 331,159 |  |

[0001564590-22-030248:notes:152]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0001564590-22-030248:notes:153]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 170,600 |  |  | $ | 146,560 |  |  | $ | 24,040 |  |
| Customer relationships |  | 3.9 years |  |  | 64,839 |  |  |  | 56,704 |  |  |  | 8,135 |  |
| Trade names |  | 0.1 years |  |  | 10,700 |  |  |  | 10,680 |  |  |  | 20 |  |
| License agreements |  | 4.4 years |  |  | 2,445 |  |  |  | 2,125 |  |  |  | 320 |  |
| Total intangibles, net |  |  |  | $ | 248,584 |  |  | $ | 216,069 |  |  | $ | 32,515 |  |

[0001564590-22-030248:notes:154]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 1.8 years |  | $ | 156,100 |  |  | $ | 129,861 |  |  | $ | 26,239 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 54,204 |  |  |  | 8,835 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 0.7 years |  |  | 10,700 |  |  |  | 10,128 |  |  |  | 572 |  |
| License agreements |  | 5.4 years |  |  | 2,445 |  |  |  | 2,053 |  |  |  | 392 |  |
| Total intangibles, net |  |  |  | $ | 232,684 |  |  | $ | 196,646 |  |  | $ | 36,038 |  |

[0001564590-22-030248:notes:155]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-22-030248:notes:156]
|  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Amortization of intangibles in “Total cost of revenues” | $ | 16,711 |  |  | $ | 26,246 |  |  | $ | 26,793 |  |
| Amortization of intangibles in "Operations" |  | 3,235 |  |  |  | 6,110 |  |  |  | 8,425 |  |
| Total amortization expense | $ | 19,946 |  |  | $ | 32,356 |  |  | $ | 35,218 |  |

[0001564590-22-030248:notes:157]
The amortization expense that is recognized in “Total cost of revenues” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-22-030248:notes:158]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0001564590-22-030248:notes:159]
| For the fiscal year ending: |  |  |  |  |
| 2023 |  | $ | 15,513 |  |
| 2024 |  |  | 5,571 |  |
| 2025 |  |  | 4,757 |  |
| 2026 |  |  | 3,411 |  |
| 2027 |  |  | 1,528 |  |
| Thereafter |  |  | 1,735 |  |
| Total |  | $ | 32,515 |  |


## us-gaap:DebtDisclosureTextBlock

[0001564590-22-030248:notes:160]
8. Debt

[0001564590-22-030248:notes:161]
The Company’s debt is comprised of the following (in thousands):

[0001564590-22-030248:notes:162]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 35,625 |  |  | $ | 26,125 |  |
| Less: unamortized debt issuance costs |  |  | (2,276 | ) |  |  | (2,404 | ) |
| Current portion of long-term debt |  | $ | 33,349 |  |  | $ | 23,721 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 273,000 |  |  | $ | 320,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,430 | ) |  |  | (4,760 | ) |
| Total long-term debt, less current portion |  |  | 270,570 |  |  |  | 315,865 |  |
| Total debt |  | $ | 303,919 |  |  | $ | 339,586 |  |

[0001564590-22-030248:notes:163]
On May 1, 2018, the Company entered into a Credit Agreement (the “2018 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as an administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders. The 2018 Credit Agreement provided for (i) a $40 million five-year revolving credit facility (the “2018 Revolving Facility”), (ii) a $190 million five-year term loan (the “2018 Term Loan”) and, (iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“2018 Incremental Facility”).

[0001564590-22-030248:notes:164]
In connection with the Aerohive Acquisition as discussed in Note 4, on August 9, 2019, the Company entered into the 2019 Credit Agreement.

[0001564590-22-030248:notes:165]
The 2019 Credit Agreement, which replaced the 2018 Credit Agreement, provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Aerohive Acquisition and for working capital and general corporate purposes.

[0001564590-22-030248:notes:166]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-22-030248:notes:167]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-22-030248:notes:168]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5% and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-22-030248:notes:169]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0001564590-22-030248:notes:170]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing its Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement dated August 9, 2019 resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the Suspension Period to 2.75%, and the unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0001564590-22-030248:notes:171]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of June 30, 2022 was 2.9% and as of June 30, 2021 was 2.8%.

[0001564590-22-030248:notes:172]
Amortization of deferred financing costs is included in “Interest expense” in the accompanying consolidated statements of operations, totaled $3.0 million, $3.0 million and $2.5 million in fiscal years ended 2022, 2021 and 2020, respectively.

[0001564590-22-030248:notes:173]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility that was outstanding as of June 30, 2020 and had no outstanding balance as of June 30, 2022 and 2021. The Company has $60.2 million availability under the 2019 Revolving Facility as of June 30, 2022. During the fiscal year ended June 30, 2022, the Company made an additional payment of $12.0 million against its term loan facility.

[0001564590-22-030248:notes:174]
The Company had $14.8 million of outstanding letters of credit as of June 30, 2022.

[0001564590-22-030248:notes:175]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0001564590-22-030248:notes:176]
| For the fiscal year ending: |  |  |  |  |
| 2023 |  | $ | 35,625 |  |
| 2024 |  |  | 38,000 |  |
| 2025 |  |  | 235,000 |  |
| Total |  | $ | 308,625 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-22-030248:notes:177]
9. Leases

[0001564590-22-030248:notes:178]
Lessee Considerations

[0001564590-22-030248:notes:179]
The Company leases certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2032. Its leases generally have terms that range from one year to ten years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0001564590-22-030248:notes:180]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or right-of-use (“ROU”) asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate at the commencement date because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is the rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. The biggest drivers having the greatest effect determining the incremental borrowing rate for each one of the Company’s leases are term of the lease and the currency in which the lease obligation is satisfied. Operating lease assets also included a reclassification for previous asset impairments and associated restructuring liabilities, deferred rent, lease incentives and initial direct costs which reduced the operating lease ROU assets as of July 1, 2019.

[0001564590-22-030248:notes:181]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for non-lease costs and variable lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s consolidated statements of operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0001564590-22-030248:notes:182]
Activity and other information relating to operating leases is as follows (in thousands, except for lease term and discount rate):

[0001564590-22-030248:notes:183]
|  |  | Year Ended |  |
|  |  | June 30, 2022 |  | June 30, 2021 |  |
| Operating lease costs | $ | 16,852 |  | $ | 18,840 |  |
| Variable lease costs |  |  | 6,921 |  |  | 6,487 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 20,890 |  |  | 22,676 |  |
| ROU assets obtained for new lease obligations |  | 18,641 |  |  | 2,162 |  |

[0001564590-22-030248:notes:184]
|  |  | June 30, 2022 |  | June 30, 2021 |  |
| Weighted average remaining lease term (in years) |  | 4.8 |  |  | 3.7 |  |
| Weighted Average Discount Rate |  | 4.7 | % |  | 4.5 | % |

[0001564590-22-030248:notes:185]
Short-term lease expense, which represents expense for leases with terms of one year or less, was not material for the years ended June 30, 2022 and 2021.

[0001564590-22-030248:notes:186]
The maturities of the Company’s operating lease liabilities as of June 30, 2022 by fiscal year are as follows:

[0001564590-22-030248:notes:187]
|  |  | Operating Leases (in thousands) |  |
| 2023 |  | $ | 14,460 |  |
| 2024 |  |  | 10,430 |  |
| 2025 |  |  | 7,769 |  |
| 2026 |  |  | 7,521 |  |
| 2027 |  |  | 6,673 |  |
| Thereafter |  |  | 6,404 |  |
| Total future minimum lease payments |  |  | 53,257 |  |
| Less amount representing interest |  |  | (6,045 | ) |
| Total operating lease liabilities |  | $ | 47,212 |  |
| Operating lease liabilities, current |  | $ | 13,956 |  |
| Operating lease liabilities, non-current |  | $ | 33,256 |  |

[0001564590-22-030248:notes:188]
Sublease Considerations

[0001564590-22-030248:notes:189]
The Company currently is a sublessor on several operating facility subleases that expire on various dates through fiscal 2023. The subleases have original terms ranging from two to six years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. These operating subleases include only lease components. The Company included $2.7 million and $2.9 million of sublease income in lease expense for the years ended June 30, 2022 and 2021, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-22-030248:notes:190]
10. Commitments and Contingencies

[0001564590-22-030248:notes:191]
Purchase Commitments

[0001564590-22-030248:notes:192]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2022, the Company had non-cancelable commitments to purchase $60.3 million of inventory and other services, which will be received and consumed during fiscal 2023. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0001564590-22-030248:notes:193]
Legal Proceedings

[0001564590-22-030248:notes:194]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual

[0001564590-22-030248:notes:195]
property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-22-030248:notes:196]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-22-030248:notes:197]
All currency conversions in this Legal Proceedings section are as of June 30, 2022.

[0001564590-22-030248:notes:198]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

[0001564590-22-030248:notes:199]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR has appealed.

[0001564590-22-030248:notes:200]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-22-030248:notes:201]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0001564590-22-030248:notes:202]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted to Orckit the right to enforce the judgment against the Company. Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0001564590-22-030248:notes:203]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019. Both cases were filed in the Federal Patent Court in Munich. The court found the EP ‘364 patent to be valid and the Company has filed an appeal. The case filed to seek to invalidate the EP ‘077 patent is proceeding, with a preliminary opinion that the EP ‘077 patent is likely invalid and a final decision from expected later this year.

[0001564590-22-030248:notes:204]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-22-030248:notes:205]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly

[0001564590-22-030248:notes:206]
licensed to use their software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company has filed a motion to dismiss and a motion to transfer the case to the Northern District of California. Both motions are pending. The trial date set for February 2023 has been rescheduled to January 2024.

[0001564590-22-030248:notes:207]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0001564590-22-030248:notes:208]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. The hearing date set for July 14, 2022 has been postponed until November 22, 2022. The Company filed a nullity action related to the EP’498 patent on September 24, 2021 in the German Federal Patent Court.

[0001564590-22-030248:notes:209]
Indemnification Obligations

[0001564590-22-030248:notes:210]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-22-030248:notes:211]
11. Stockholders’ Equity

[0001564590-22-030248:notes:212]
Preferred Stock

[0001564590-22-030248:notes:213]
In April 2001, in connection with entering into the Company’s Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors (the “Board”) is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2022, no shares of preferred stock were outstanding.

[0001564590-22-030248:notes:214]
Stockholders’ Rights Agreement

[0001564590-22-030248:notes:215]
On April 26, 2012, the Company entered into the “Restated Rights Plan,” which governed the terms of each right (“Right”) that had been issued with respect to each share of common stock of Extreme Networks. Each Right initially represented the right to purchase one one-thousandth of a share of the Company’s Preferred Stock. From 2013 through 2020, the Board and stockholders approved amendments providing for one-year extensions of the term of the Restated Rights Plan.

[0001564590-22-030248:notes:216]
On May 17, 2021, the Company entered into the Amended and Restated Tax Benefit Preservation Plan (the “2021 Tax Benefit Preservation Plan”), which amended and restated the Restated Rights Agreement between the Company and Computershare Shareholder Services LLC, as the rights agent. The 2021 Tax Benefit Preservation Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock. The Company’s Board of Directors adopted the 2021 Tax Benefit Preservation Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of shares of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the 2021 Tax Benefit Preservation Plan. The 2021 Tax Benefit Preservation Plan was approved for a period of three years by stockholders of the Company at the annual meeting of stockholders on November 4, 2021.

[0001564590-22-030248:notes:217]
Equity Incentive Plan

[0001564590-22-030248:notes:218]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on August 11, 2021 to update tax withholding obligations. The Compensation Committee of the Board unanimously approved an amendment to the 2013 Plan on September 10, 2021 to increase the maximum number of available shares by 7.9 million shares, which amendment was approved by the stockholders at the Company’s annual meeting of the stockholders held on November 4, 2021.

[0001564590-22-030248:notes:219]
Employee Stock Purchase Plan

[0001564590-22-030248:notes:220]
The Compensation Committee of the Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan (the “ESPP”) on September 9, 2021 to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares. The amendment was ratified by a majority of the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021.

[0001564590-22-030248:notes:221]
Common Stock Repurchases

[0001564590-22-030248:notes:222]
On November 2, 2018, the Company announced that the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions. In February 2020, the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020. A maximum of $30.0 million may be repurchased in any calendar year. In May 2022, the Board authorized an increase to the share repurchase authorization to $200.0 million over a three-year period commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. This authorization replaces the previous authorization effective July 1, 2022.

[0001564590-22-030248:notes:223]
In fiscal year 2022, the Company repurchased a total of 3.9 million shares of its common stock on the open market at a total cost of $45.0 million with an average price of $11.59 per share. There were no shares repurchased during the year ended June 30, 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-22-030248:notes:224]
12. Employee Benefit Plans

[0001564590-22-030248:notes:225]
As of June 30, 2022, the Company has the following share-based compensation plans:

[0001564590-22-030248:notes:226]
2013 Equity Incentive Plan

[0001564590-22-030248:notes:227]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, up to 12.7 million shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan. The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting. During the year ended June 30, 2022 an additional 7.9 million shares were authorized and made available for grant under the 2013 Plan. As of June 30, 2022, total options and awards to acquire 7.6 million shares were outstanding under the 2013 Plan and 11.4 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0001564590-22-030248:notes:228]
Aerohive 2014 Equity Incentive Plan

[0001564590-22-030248:notes:229]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the “Aerohive Plan”). Stock awards outstanding under the Aerohive Plan were converted into awards for Extreme shares as of the Acquisition Date at a predetermined rate pursuant to the Merger Agreement. As of June 30, 2022, total awards to acquire 2,578 shares of Extreme common stock were outstanding under the Aerohive Plan. If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0001564590-22-030248:notes:230]
Shares Reserved for Issuance

[0001564590-22-030248:notes:231]
The following are shares reserved for issuance (in thousands):

[0001564590-22-030248:notes:232]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 11,430 |  |  |  | 6,753 |  |
| Employee stock options and awards outstanding |  |  | 7,616 |  |  |  | 10,359 |  |
| 2014 Employee Stock Purchase Plan |  |  | 9,961 |  |  |  | 4,414 |  |
| Total shares reserved for issuance |  |  | 29,007 |  |  |  | 21,526 |  |

[0001564590-22-030248:notes:233]
Stock Options

[0001564590-22-030248:notes:234]
The following table summarizes stock option activity under all plans (shares and intrinsic value in thousands):

[0001564590-22-030248:notes:235]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2021 |  |  | 1,645 |  |  | $ | 5.44 |  |  |  | 3.62 |  |  | $ | 9,404 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (458 | ) |  |  | 2.54 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.70 |  |  | $ | 2,801 |  |
| Vested and expected to vest at June 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.70 |  |  | $ | 2,801 |  |
| Exercisable at June 30, 2022 |  |  | 988 |  |  | $ | 6.53 |  |  |  | 3.60 |  |  | $ | 2,359 |  |

[0001564590-22-030248:notes:236]
The total intrinsic value of options exercised in fiscal years 2022, 2021 and 2020 was $4.9 million, $3.9 million and $0.6 million, respectively.

[0001564590-22-030248:notes:237]
There were no stock options granted during the fiscal years 2022 and 2021. The weighted average estimated fair value of stock options granted in fiscal year 2020 was $3.52 per share. As of June 30, 2022, there was $0.7 million of total unrecognized compensation cost related to unvested stock options that will be recognized over a weighted-average period of 1.2 years.

[0001564590-22-030248:notes:238]
Stock Options – Performance Stock Options

[0001564590-22-030248:notes:239]
During the first quarter of fiscal 2019, the Company granted 851,700 Performance Stock Options (“PSOs”) to certain officers and executive vice presidents that will vest if the Company’s stock price achieves a price hurdle of $10.00 during the three-year performance period from August 29, 2018 through August 31, 2021. The price hurdle will be deemed to have been achieved if, at any time over the performance period, the Company’s stock maintains a price of $10.00 for 30 consecutive days. If the price hurdle is achieved, the PSOs will vest (ratably based upon the time elapsed between August 31, 2018 and the date the hurdle is met) and the remainder will vest quarterly through August 31, 2021. The grant date fair value of these PSOs was $2.62.

[0001564590-22-030248:notes:240]
During the fourth quarter of fiscal 2021, the price hurdle was achieved and 550,300 PSOs remain outstanding as of June 30, 2022 and 2021.

[0001564590-22-030248:notes:241]
Stock Awards

[0001564590-22-030248:notes:242]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (“RSUs”), including performance-based or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the award’s intrinsic value as of the date of grant.

[0001564590-22-030248:notes:243]
The following table summarizes stock award activity (shares and market value in thousands):

[0001564590-22-030248:notes:244]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2021 |  |  | 8,714 |  |  | $ | 5.51 |  |  |  |  |  |
| Granted |  |  | 4,448 |  |  |  | 11.39 |  |  |  |  |  |
| Released |  |  | (6,235 | ) |  |  | 5.38 |  |  |  |  |  |
| Cancelled |  |  | (498 | ) |  |  | 7.22 |  |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2022 |  |  | 6,429 |  |  | $ | 9.57 |  |  | $ | 57,347 |  |
| Stock awards expected to vest at June 30, 2022 |  |  | 6,429 |  |  | $ | 9.57 |  |  | $ | 57,347 |  |

[0001564590-22-030248:notes:245]
The RSUs granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company.

[0001564590-22-030248:notes:246]
The aggregate fair value, as of the respective grant dates of awards granted during the fiscal years ended 2022, 2021 and 2020 was $50.7 million, $32.9 million and $45.9 million, respectively.

[0001564590-22-030248:notes:247]
For fiscal years ended 2022, 2021 and 2020, the Company withheld an aggregate of 2.2 million shares, 1.3 million shares, and 1.3 million shares, respectively, upon the vesting of awards, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0001564590-22-030248:notes:248]
For fiscal years ended 2022, 2021 and 2020, the Company remitted cash of $24.5 million, $9.2 million and $8.0 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0001564590-22-030248:notes:249]
As of June 30, 2022, there was $42.9 million in unrecognized compensation costs related to non-vested stock awards which includes the performance and market condition awards as discussed below. This cost is expected to be recognized over a weighted-average period of 1.6 years.

[0001564590-22-030248:notes:250]
Stock Awards – Officers and Directors

[0001564590-22-030248:notes:251]
RSUs granted during fiscal 2022 and 2021 to named executive officers and directors totaled 1.0 million awards and 1.6 million awards, respectively which included awards with market conditions as discussed below. RSUs granted during fiscal 2020 included 0.6 million RSUs to named executive officers and directors.

[0001564590-22-030248:notes:252]
Stock Awards - Performance Awards

[0001564590-22-030248:notes:253]
During fiscal 2022 and 2021, the Compensation Committee of the Board granted 0.7 million and 0.5 million RSUs, respectively with vesting based on market conditions (“MSUs”) to certain of the Company’s named executive officers. These MSUs will vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”). The MSU award represents the right to receive a target number of shares of common stock up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods from August 15, 2020 through August 15, 2023, subject to the grantees’ continued service through the certification of performance.

[0001564590-22-030248:notes:254]
| Level | Relative TSR | Shares Vested |  |
| Below Threshold | TSR is less than the Index by more than 37.5 percentage points | 0% |  |
| Threshold | TSR is less than the Index by 37.5 percentage points | 25% |  |
| Target | TSR equals the Index | 100% |  |
| Maximum | TSR is greater than the Index by 25 percentage points or more | 150% |  |

[0001564590-22-030248:notes:255]
Total shareholder return is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years 1 and 2 and the ability for up to the maximum of the full award to vest based on the full 3-year TSR less any shares vested based on 1- and 2- year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0001564590-22-030248:notes:256]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the MSUs granted during the year ended June 30, 2022 was $12.69 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of 3 years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0001564590-22-030248:notes:257]
The weighted-average grant-date fair value of the MSUs granted during the year ended June 30, 2021 was $5.32 per share. The assumptions used in the Monte-Carlo simulation included the expected volatility of 69%, risk-free rate of 0.18%, no expected dividend yield, expected term of 3 years and possible future stock prices over the performance period based on the historical stock and market prices.

[0001564590-22-030248:notes:258]
Stock Awards - Performance Awards Activity

[0001564590-22-030248:notes:259]
The following table summarizes stock awards with market or performance-based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0001564590-22-030248:notes:260]
|  |  | Fiscal year 2022 |  |  | Fiscal year 2021 |  |  | Fiscal year 2020 |  |
| Performance awards granted |  |  | 727 |  |  |  | 475 |  |  |  | — |  |
| Performance awards earned |  |  | 158 |  |  |  | — |  |  |  | 56 |  |

[0001564590-22-030248:notes:261]
2014 Employee Stock Purchase Plan

[0001564590-22-030248:notes:262]
On August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. During the fiscal year ended June 30, 2022, the Board of Directors unanimously approved an amendment to the 2014 ESPP to increase the maximum number of shares that will be available for sale by 7.5 million shares, which was ratified by the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021. The 2014 ESPP replaced the 1999 Employee Stock Purchase Plan. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period has a maximum duration of six months and the maximum shares issuable for each purchase period is 1.5 million shares. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.

[0001564590-22-030248:notes:263]
During the fiscal years ended June 30, 2022 and 2021, there were 2.0 million and 2.9 million shares issued under the 2014 ESPP. As of June 30, 2022, there have been an aggregate 17.0 million shares issued under the 2014 ESPP.

[0001564590-22-030248:notes:264]
Share-Based Compensation Expense

[0001564590-22-030248:notes:265]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (in thousands):

[0001564590-22-030248:notes:266]
|  | Year Ended |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Cost of product revenues | $ | 1,186 |  |  | $ | 1,209 |  |  | $ | 1,240 |  |
| Cost of service and subscription revenues |  | 1,421 |  |  |  | 1,662 |  |  |  | 1,620 |  |
| Research and development |  | 9,995 |  |  |  | 9,969 |  |  |  | 10,324 |  |
| Sales and marketing |  | 15,000 |  |  |  | 12,505 |  |  |  | 11,914 |  |
| General and administrative |  | 15,760 |  |  |  | 13,706 |  |  |  | 12,265 |  |
| Total share-based compensation expense | $ | 43,362 |  |  | $ | 39,051 |  |  | $ | 37,842 |  |

[0001564590-22-030248:notes:267]
The Company uses the straight-line method for expense attribution, other than for the PSUs and MSUs, which may use the accelerated attribution method. The Company does not estimate forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur.

[0001564590-22-030248:notes:268]
The fair value of each stock option grant under the Company’s 2013 Plan is estimated on the date of grant that uses the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-22-030248:notes:269]
The fair value of each RSU grant with market-based vesting criteria under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-22-030248:notes:270]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP shares is the offering period for each purchase. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-22-030248:notes:271]
The weighted-average estimated per share fair value of shares under the 2014 ESPP in fiscal years 2022, 2021 and 2020, was $3.32, $2.47 and $1.90, respectively.

[0001564590-22-030248:notes:272]
|  | Employee Stock Purchase Plan |  |  |
|  | Year Ended |  |  |
|  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |  |
| Expected life | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  |
| Risk-free interest rate |  | 0.33 | % |  |  | 0.09 | % |  |  | 1.71 | % |  |
| Volatility |  | 49 | % |  |  | 95 | % |  |  | 43 | % |  |
| Dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |

[0001564590-22-030248:notes:273]
401(k) Plan

[0001564590-22-030248:notes:274]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $20,500 for calendar year 2022. Employees aged 50 or over may elect to contribute an additional $6,500. The amount contributed to the Plan is on a pre-tax basis.

[0001564590-22-030248:notes:275]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. The program effective during fiscal 2022 was established to match $0.50 for every Dollar contributed by the employee up to the first 6.0% of pay with annual cap of $4,000. The Company’s matching contributions to the Plan totaled $4.6 million, $4.2 million and $3.2 million, for fiscal years ended 2022, 2021 and 2020, respectively. No discretionary contributions were made in fiscal years ended 2022, 2021 and 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-22-030248:notes:276]
13. Information about Segments of Geographic Areas

[0001564590-22-030248:notes:277]
The Company operates in one segment, which develops and markets network infrastructure equipment. Revenues are attributed to a geographical area based on the location of the customers. The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan. The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-22-030248:notes:278]
See Note 3, Revenues, for the Company’s revenues by geographic regions and channel based on the customers’ billing address.

[0001564590-22-030248:notes:279]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-22-030248:notes:280]
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |
| Americas |  | $ | 130,715 |  |  | $ | 151,839 |  |
| EMEA |  |  | 36,792 |  |  |  | 25,940 |  |
| APAC |  |  | 11,770 |  |  |  | 13,560 |  |
| Total long-lived assets |  | $ | 179,277 |  |  | $ | 191,339 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-22-030248:notes:281]
14. Derivatives and Hedging

[0001564590-22-030248:notes:282]
Interest Rate Swaps

[0001564590-22-030248:notes:283]
The Company is exposed to interest rate risk on its debt. The Company enters into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which has floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0001564590-22-030248:notes:284]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive income (loss) and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0001564590-22-030248:notes:285]
During the fiscal year ended June 30, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of June 30, 2022 and June 30, 2021, the total notional amount of these interest rate swaps were $75.0 million and $200.0 million, respectively, and had maturity dates through April 2023. As of June 30, 2022 and June 30, 2021, these contracts had unrealized gain of $1.3 million and unrealized loss of $1.1 million, respectively, which are recorded in “Accumulated other comprehensive income (loss)” with the associated asset in “Prepaid expenses and other current assets” and with the associated liability in “Other accrued liabilities”, respectively in the consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the consolidated statements of cash flows. Realized gains and losses are recognized as incurred into interest expense. Amounts reported in accumulated other comprehensive income related to these cash flow hedges will be reclassified to interest income (expense) over the life of the swap contracts. The Company estimates that $1.3 million will be reclassified to interest income over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0001564590-22-030248:notes:286]
Foreign Exchange Forward Contracts

[0001564590-22-030248:notes:287]
The Company uses derivative financial instruments to manage exposures to foreign currency that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies.

[0001564590-22-030248:notes:288]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying consolidated statements of operations. As of June 30, 2022 and 2021 foreign exchange forward currency contracts not designated as hedging instruments had the total notional amount of $9.6 million and, $23.0 million, respectively. These contracts had maturities of less than 40 days. For the years ended June 30, 2022 the net loss recorded in the consolidated statement of operations from these contracts was $1.4 million. For the years ended June 30, 2021 and 2020 the net gains recorded in the consolidated statement of operations from these contracts were $0.5 million and $0.1 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001564590-22-030248:notes:289]
For foreign exchange forward contracts designated as hedging instruments, gains and losses arising from these contracts are recorded as a component of accumulated other comprehensive income (loss) on the consolidated balance sheets. The hedging gains and losses in accumulated other comprehensive income are subsequently reclassified to expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. As of June 30, 2021, foreign exchange forward contracts designated as hedging instruments had the notional amount of $21.8 million. These contracts have maturities of less than twelve months. As of June 30, 2021 these contracts had unrealized losses of $0.2 million, which are recorded in accumulated other comprehensive income (loss) with the associated liability in other accrued liabilities in the accompanying consolidated balance sheets. There were no outstanding foreign exchange forward contracts that were designated as hedging instruments at June 30, 2022 and June 30, 2020.

[0001564590-22-030248:notes:290]
Foreign currency transaction gains and losses from operations had a gain of $1.7 million in fiscal year ended June 30, 2022, a loss of $2.2 million in fiscal year ended June 30, 2021 and a gain of $0.6 million in fiscal year ended June 30, 2020.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-22-030248:notes:291]
15. Restructuring, Impairments, and Related Charges

[0001564590-22-030248:notes:292]
The Company does not have any restructuring liability as of June 30, 2022. As of June 30, 2021, restructuring liabilities were $0.3 million, which were recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. The restructuring liabilities consist of obligations pertaining to the estimated future obligations for non-cancelable lease payments and severance and benefits obligations through June 30, 2019 and only severance, benefits and other related obligations subsequent to the adoption of ASU 2016-02 Leases (Topic 842) on July 1, 2019.

[0001564590-22-030248:notes:293]
During fiscal years ended 2022, 2021 and 2020, the Company recorded restructuring, impairments and related charges of $1.7 million, $2.6 million and $22.0 million, respectively. The charges are reflected in “Restructuring and related charges” in the consolidated statements of operations.

[0001564590-22-030248:notes:294]
2022 Restructuring

[0001564590-22-030248:notes:295]
During fiscal 2022, the Company recorded $1.7 million of restructuring charges which primarily comprised of facility related charges. The facility restructuring charges included some impairment charges and additional facilities expenses related to previously impaired facilities. In addition, during fiscal 2022, the Company completed the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”). The Company had incurred $9.6 million of charges under the 2020 Plan through June 30, 2022.

[0001564590-22-030248:notes:296]
2021 Restructuring

[0001564590-22-030248:notes:297]
During fiscal 2021, the Company continued its cost reduction initiative begun in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of $1.5 million, related to the 2020 Plan. In addition, the Company incurred facility-related charges of $1.1 million, which represented additional expenses related to previously impaired facilities. Severance and benefits charges consisted primarily of additional employee severance and benefit expenses incurred under the 2020 Plan. With the reduction and realignment of the headcount under the 2020 Plan, the Company relocated certain of its lab equipment to third-party consulting companies. The Company had incurred $9.6 million of charges under the 2020 Plan through June 30, 2021.

[0001564590-22-030248:notes:298]
2020 Restructuring and Impairment

[0001564590-22-030248:notes:299]
During fiscal 2020, the Company moved to reduce its operating expenses by exiting a floor in its San Jose, California facility and consolidating its workforce. Also, the Company exited additional space in its Salem, New Hampshire facility, which includes general office and lab space. The Company continued its initiative to realign its operations resulting from the acquisition of Aerohive and consolidating its workforce and exiting the facility it acquired from Aerohive in Milpitas, California which includes general office and lab space. The Company had the intent and ability to sub-lease these facilities which it had ceased using and as such, had considered estimated future sub-lease income based on its existing lease agreements, as well as the local real estate market conditions, in measuring the amount of asset impairment. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.

[0001564590-22-030248:notes:300]
With the global disruptions and slow-down in the demand of its products caused by the global pandemic outbreak, COVID-19, and the uncertainty around the timing of the recovery of the market, the Company initiated a reduction-in-force plan (the 2020 Plan) to reduce its operating costs and enhance financial flexibility. The plan affected approximately 320 employees primarily from the research and development and sales organizations who were located mainly in the U.S. and India. The Company recorded restructuring charges of $8.1 million during the fiscal year ended June 30, 2020 related to the 2020 Plan. The Company incurred additional charges related to this 2020 Plan through the first quarter of fiscal 2021, which primarily included employee severance and benefit expenses. The Company recorded additional severance and benefits charges of $5.4 million for the fiscal year ended June 30, 2020 related to the previous year’s restructuring plans. In total the Company incurred $13.5 million in restructuring charges for the year ended June 30, 2020 which were all severance and benefit related. In addition, the Company recorded facility impairment related charges of $8.5 million for the fiscal year ended June 30, 2020 which included $6.7 million for the impairment of ROU assets as referenced in the preceding paragraph, $0.9 million for impairment of long-lived assets, and $0.9 million of other charges related to previously impaired facilities.

[0001564590-22-030248:notes:301]
Restructuring liabilities consist of (in thousands):

[0001564590-22-030248:notes:302]
|  |  | Excess Facilities |  |  | Severance and Other |  |  | Total |  |
| Balance as of June 30, 2019 |  | $ | 1,764 |  |  | $ | 3,559 |  |  | $ | 5,323 |  |
| Period charges |  |  | — |  |  |  | 14,875 |  |  |  | 14,875 |  |
| Period reversals |  |  | — |  |  |  | (1,369 | ) |  |  | (1,369 | ) |
| Reclassification to reduce operating lease assets |  |  | (1,764 | ) |  |  | — |  |  |  | (1,764 | ) |
| Period payments |  |  | — |  |  |  | (14,846 | ) |  |  | (14,846 | ) |
| Balance at June 30, 2020 |  | $ | — |  |  | $ | 2,219 |  |  | $ | 2,219 |  |
| Period charges |  |  | — |  |  |  | 1,597 |  |  |  | 1,597 |  |
| Period reversals |  |  | — |  |  |  | (128 | ) |  |  | (128 | ) |
| Period payments |  |  | — |  |  |  | (3,417 | ) |  |  | (3,417 | ) |
| Balance at June 30, 2021 |  | $ | — |  |  | $ | 271 |  |  | $ | 271 |  |
| Period charges |  |  | — |  |  |  | 12 |  |  |  | 12 |  |
| Period reversals |  |  | — |  |  |  | (41 | ) |  |  | (41 | ) |
| Period payments |  |  | — |  |  |  | (242 | ) |  |  | (242 | ) |
| Balance at June 30, 2022 |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-22-030248:notes:303]
16. Income Taxes

[0001564590-22-030248:notes:304]
Income (loss) before income taxes is as follows (in thousands):

[0001564590-22-030248:notes:305]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | (1,204 | ) |  | $ | (4,194 | ) |  | $ | (143,651 | ) |
| Foreign |  |  | 53,398 |  |  |  | 14,379 |  |  |  | 23,159 |  |
| Income (loss) before income taxes |  | $ | 52,194 |  |  | $ | 10,185 |  |  | $ | (120,492 | ) |

[0001564590-22-030248:notes:306]
The provision for income taxes for the years ended June 30, 2022, 2021 and 2020 consisted of the following (in thousands):

[0001564590-22-030248:notes:307]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | — |  |  | $ | — |  |  | $ | (22 | ) |
| State |  |  | 1,069 |  |  |  | 1,160 |  |  |  | 256 |  |
| Foreign |  |  | 6,460 |  |  |  | 5,334 |  |  |  | 4,597 |  |
| Total current |  |  | 7,529 |  |  |  | 6,494 |  |  |  | 4,831 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 396 |  |  |  | 324 |  |  |  | 333 |  |
| State |  |  | 227 |  |  |  | 1,169 |  |  |  | 44 |  |
| Foreign |  |  | (229 | ) |  |  | 262 |  |  |  | 1,145 |  |
| Total deferred |  |  | 394 |  |  |  | 1,755 |  |  |  | 1,522 |  |
| Provision for income taxes |  | $ | 7,923 |  |  | $ | 8,249 |  |  | $ | 6,353 |  |

[0001564590-22-030248:notes:308]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (21 percent) to income (loss) before income taxes is explained below (in thousands):

[0001564590-22-030248:notes:309]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Tax at federal statutory rate |  | $ | 10,960 |  |  | $ | 2,139 |  |  | $ | (25,303 | ) |
| State income tax, net of federal benefit |  |  | 844 |  |  |  | 917 |  |  |  | 202 |  |
| Global Intangible Low-Taxed Income (GILTI) |  |  | 15,470 |  |  |  | — |  |  |  | 4,094 |  |
| US valuation allowance change – deferred tax movement |  |  | (13,795 | ) |  |  | (9,387 | ) |  |  | 2,414 |  |
| Research and development credits |  |  | (3,122 | ) |  |  | (2,423 | ) |  |  | (4,947 | ) |
| Tax impact of foreign earnings |  |  | (3,762 | ) |  |  | 11,979 |  |  |  | 2,831 |  |
| Foreign withholding taxes |  |  | 1,032 |  |  |  | 828 |  |  |  | 762 |  |
| Stock based compensation |  |  | (5,011 | ) |  |  | 1,162 |  |  |  | 4,349 |  |
| Goodwill amortization |  |  | 525 |  |  |  | 1,467 |  |  |  | 331 |  |
| Nondeductible officer compensation |  |  | 4,589 |  |  |  | 1,496 |  |  |  | 862 |  |
| Nondeductible meals and entertainment |  |  | 193 |  |  |  | 71 |  |  |  | 364 |  |
| AMT credit monetization |  |  | — |  |  |  | — |  |  |  | (22 | ) |
| Gain on transfer of intellectual property |  |  | — |  |  |  | — |  |  |  | 19,819 |  |
| Other |  |  | — |  |  |  | — |  |  |  | 597 |  |
| Provision for income taxes |  | $ | 7,923 |  |  | $ | 8,249 |  |  | $ | 6,353 |  |

[0001564590-22-030248:notes:310]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001564590-22-030248:notes:311]
|  |  | June 30, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 51,494 |  |  | $ | 69,126 |  |  | $ | 74,548 |  |
| Tax credit carry-forwards |  |  | 70,683 |  |  |  | 68,003 |  |  |  | 67,364 |  |
| Depreciation |  |  | 2,093 |  |  |  | 3,113 |  |  |  | 2,755 |  |
| Intangible amortization |  |  | 29,538 |  |  |  | 35,340 |  |  |  | 32,642 |  |
| Deferred revenue |  |  | 15,928 |  |  |  | 11,625 |  |  |  | 7,610 |  |
| Inventory write-downs |  |  | 13,121 |  |  |  | 14,501 |  |  |  | 13,014 |  |
| Other allowances and accruals |  |  | 26,508 |  |  |  | 28,899 |  |  |  | 32,318 |  |
| Stock based compensation |  |  | 2,746 |  |  |  | 2,792 |  |  |  | 3,169 |  |
| Deferred intercompany gain |  |  | 3,693 |  |  |  | 3,693 |  |  |  | 3,693 |  |
| Ireland goodwill amortization |  |  | 5,583 |  |  |  | 6,303 |  |  |  | 7,132 |  |
| Other |  |  | 244 |  |  |  | 1,175 |  |  |  | 888 |  |
| Total deferred tax assets |  |  | 221,631 |  |  |  | 244,570 |  |  |  | 245,133 |  |
| Valuation allowance |  |  | (209,727 | ) |  |  | (230,588 | ) |  |  | (232,862 | ) |
| Total net deferred tax assets |  |  | 11,904 |  |  |  | 13,982 |  |  |  | 12,271 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill amortization |  |  | (10,415 | ) |  |  | (8,575 | ) |  |  | (6,691 | ) |
| Prepaid commissions |  |  | (3,931 | ) |  |  | (3,166 | ) |  |  | (1,958 | ) |
| Deferred tax liability on foreign withholdings |  |  | (676 | ) |  |  | (578 | ) |  |  | (551 | ) |
| Total deferred tax liabilities |  |  | (15,022 | ) |  |  | (12,319 | ) |  |  | (9,200 | ) |
| Net deferred tax assets |  | $ | (3,118 | ) |  | $ | 1,663 |  |  | $ | 3,071 |  |
| Recorded as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net non-current deferred tax assets |  |  | 4,599 |  |  |  | 5,491 |  |  |  | 5,405 |  |
| Net non-current deferred tax liabilities |  |  | (7,717 | ) |  |  | (3,828 | ) |  |  | (2,334 | ) |
| Net deferred tax assets |  | $ | (3,118 | ) |  | $ | 1,663 |  |  | $ | 3,071 |  |

[0001564590-22-030248:notes:312]
The Company’s global valuation allowance decreased by $20.9 million in the fiscal year ended June 30, 2022 and decreased by $2.2 million in the fiscal year ended June 30, 2021. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against certain non-U.S. deferred tax assets in Ireland and Brazil. The valuation allowance is determined by assessing both negative and positive available evidence to determine whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years and the cyclical nature of the Company's business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001564590-22-030248:notes:313]
As of June 30, 2022, the Company had net operating loss carry-forwards (“NOLs”) for U.S. federal and state tax purposes of $184.5 million and $162.8 million, respectively. As of June 30, 2022, the Company also had foreign net operating loss carry-forwards in Ireland, Australia and Brazil of $8.9 million, $6.9 million and $15.2 million, respectively. As of June 30, 2022, the Company also had federal and state tax credit carry-forwards of $44.0 million and $33.7 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits. Of the $184.5 million U.S. federal net operating loss carry-forwards, $87.4 million will begin to expire in the fiscal year ending June 30, 2035 and $97.1 million have an indefinite carryforward life. The state net operating losses of $162.8 million will begin to partially expire in the fiscal year ending June 30, 2024. The foreign net operating losses can generally be carried forward indefinitely. Federal research and development tax credits of $35.3 million will expire beginning in fiscal 2023, if not utilized and foreign tax credits of $8.7 million will expire beginning in fiscal 2023. North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2024, if not utilized. California state research and development tax credits of $32.8 million do not expire and can be carried forward indefinitely.

[0001564590-22-030248:notes:314]
In May 2022, the Company performed an analysis under Section 382 of the Internal Revenue Code (“IRC”) with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of these U.S. tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2020, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes. The Company also performed in June 2020 a separate IRC section 382 analysis with respect to the NOLs and tax credits acquired from Aerohive and have determined that while the Company will be subject to an annual limitation, the Company should not be limited on the full utilization of the losses and credits during the statutory allowable carryforward period for the NOLs and credits.

[0001564590-22-030248:notes:315]
As of June 30, 2022, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $33.1 million. It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the U.S. The Company has reviewed its prior position on the reinvestment of earnings of certain foreign subsidiaries and has recorded a deferred tax liability of $0.7 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential tax associated with repatriation of these earnings as well as the deemed repatriation related to U.S. tax reform enacted in 2017 is $6.2 million.

[0001564590-22-030248:notes:316]
On August 16, 2022, President Biden signed the Inflation Reduction Act which includes a new minimum tax on certain large corporations and an excise tax on stock buybacks. We do not anticipate this legislation will have a material impact for the Company.

[0001564590-22-030248:notes:317]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world. Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire, Texas and North Carolina. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years ended June 2003 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years ended June 2002 forward due to net operating losses. Statutes related to material foreign jurisdictions are generally open for fiscal years ended June 2018 forward for Ireland and for tax year ended March 2018 forward for India.

[0001564590-22-030248:notes:318]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in the United States. The CARES Act, among other things, includes modifications to net operating loss carryforward provisions and net interest expense deductions, and allows deferment of employer social security tax payments. The Company evaluated the provisions of the CARES Act and how certain elections may impact its financial position and results of operations, and have determined the enactment of the CARES Act did not have a material impact to the income tax provision for the fiscal year ended June 30, 2020, or to the net deferred tax assets as of June 30, 2020.

[0001564590-22-030248:notes:319]
The U.S. tax rules require U.S. tax on foreign earnings, known as Global Intangible Low Taxed Income (“GILTI”). Under U.S. GAAP, taxpayers are allowed to make an accounting policy election of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes. The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred under the period cost method.

[0001564590-22-030248:notes:320]
On August 9, 2019, the Company completed its acquisition of Aerohive. This acquisition was treated as a non-taxable stock acquisition and therefore Extreme Networks has carryover tax basis in the assets and liabilities acquired. During the fourth quarter of fiscal 2020 following the acquisition of Aerohive, the Company realigned the Aerohive related non-American intellectual property rights to correspond with the Company’s global operating model. This transaction resulted in recognition of a $75.0 million U.S. tax gain which was fully consumed by existing NOLs and the intangibles transferred are being amortized over 10 years for Irish statutory purposes.

[0001564590-22-030248:notes:321]
As of June 30, 2022, the Company had $18.4 million of unrecognized tax benefits. If fully recognized in the future, $0.3 million would impact the effective tax rate, and $18.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not reasonably expect the amount of unrealized tax benefits to materially decrease during the next twelve months. The decrease in the current year related to prior year tax positions relates to the reclassification of an unrecognized tax benefit to a valuation allowance with no net impact to the financial statements.

[0001564590-22-030248:notes:322]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001564590-22-030248:notes:323]
| Balance at June 30, 2019 |  | $ | 17,168 |  |
| Increase related to prior year tax positions |  |  | 8,906 |  |
| Increase related to current year tax positions |  |  | 44 |  |
| Decrease related to prior year tax positions |  |  | (1,800 | ) |
| Lapse of statute of limitations |  |  | (421 | ) |
| Balance at June 30, 2020 |  |  | 23,897 |  |
| Decrease related to prior year tax positions |  |  | (4,296 | ) |
| Increase related to prior year tax positions |  |  | 28 |  |
| Increase related to current year tax positions |  |  | 72 |  |
| Lapse of statute of limitations |  |  | (637 | ) |
| Balance at June 30, 2021 |  | $ | 19,064 |  |
| Decrease related to prior year tax positions |  |  | (34 | ) |
| Increase related to prior year tax positions |  |  | - |  |
| Increase related to current year tax positions |  |  | 11 |  |
| Lapse of statute of limitations |  |  | (674 | ) |
| Balance at June 30, 2022 |  | $ | 18,367 |  |

[0001564590-22-030248:notes:324]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of tax expense in the consolidated statements of operations and totaled less than $0.1 million for each of the years ended June 30, 2022, 2021 and 2020.


## us-gaap:EarningsPerShareTextBlock

[0001564590-22-030248:notes:325]
17. Net Income (Loss) Per Share

[0001564590-22-030248:notes:326]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock outstanding during the period. Diluted income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock used in the basic net income (loss) per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested restricted stock.

[0001564590-22-030248:notes:327]
The following table presents the calculation of basic and diluted net income (loss) per share (in thousands, except per share data):

[0001564590-22-030248:notes:328]
|  |  | Year Ended |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Net income (loss) |  | $ | 44,271 |  |  | $ | 1,936 |  |  | $ | (126,845 | ) |
| Weighted-average shares used in per share calculation - basic |  |  | 129,437 |  |  |  | 124,019 |  |  |  | 119,814 |  |
| Options to purchase common stock |  |  | 567 |  |  |  | 542 |  |  |  | — |  |
| Restricted stock units |  |  | 3,490 |  |  |  | 3,047 |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | — |  |  |  | 61 |  |  |  | — |  |
| Weighted-average shares used in per share calculation - diluted |  |  | 133,494 |  |  |  | 127,669 |  |  |  | 119,814 |  |
| Net income (loss) per share - basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | 0.34 |  |  | $ | 0.02 |  |  | $ | (1.06 | ) |
| Net income (loss) per share - diluted |  | $ | 0.33 |  |  | $ | 0.02 |  |  | $ | (1.06 | ) |

[0001564590-22-030248:notes:329]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net loss per share since the effect of including them would have been anti-dilutive due to the net loss position of the Company during the periods presented.

[0001564590-22-030248:notes:330]
The following securities were excluded from the computation of net income (loss) per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001564590-22-030248:notes:331]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2022 |  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| Options to purchase common stock |  |  | — |  |  |  | 637 |  |  |  | 3,036 |  |
| Restricted stock units |  |  | 99 |  |  |  | 80 |  |  |  | 8,103 |  |
| Employee Stock Purchase Plan shares |  |  | 400 |  |  |  | 334 |  |  |  | 553 |  |
| Total shares excluded |  |  | 499 |  |  |  | 1,051 |  |  |  | 11,692 |  |
