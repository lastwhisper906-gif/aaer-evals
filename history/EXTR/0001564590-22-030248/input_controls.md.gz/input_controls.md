# EXTR 10-K controls and the auditor's report


## auditors_report

[0001564590-22-030248:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001564590-22-030248:auditors_report:2]
Board of Directors and Stockholders

[0001564590-22-030248:auditors_report:3]
Extreme Networks, Inc.

[0001564590-22-030248:auditors_report:4]
Opinion on the financial statements

[0001564590-22-030248:auditors_report:5]
We have audited the accompanying consolidated balance sheet of Extreme Networks, Inc. (a Delaware corporation) and subsidiaries (the “Company”) as of June 30, 2022, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for the year ended June 30, 2022, and the related notes (collectively referred to as the “financial statements”). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2022, and the results of its operations and its cash flows for the year ended June 30, 2022, in conformity with accounting principles generally accepted in the United States of America.

[0001564590-22-030248:auditors_report:6]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the Company’s internal control over financial reporting as of June 30, 2022, based on criteria established in the 2013 Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”), and our report dated August 26, 2022 expressed an unqualified opinion.

[0001564590-22-030248:auditors_report:7]
Basis for opinion

[0001564590-22-030248:auditors_report:8]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-22-030248:auditors_report:9]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001564590-22-030248:auditors_report:10]
Critical audit matter

[0001564590-22-030248:auditors_report:11]
The critical audit matter communicated below is a matter arising from the current period audit of the financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001564590-22-030248:auditors_report:12]
Revenue Recognition – Rebate Adjustments Determined to be Variable Consideration

[0001564590-22-030248:auditors_report:13]
As described further in note 3 to the financial statements, sales to stocking distributors are made under terms allowing certain price adjustments in the form of rebates. Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price. At the time the distributor invoices its end customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated based on an analysis of actual claims at the distributor level over a period of time considered adequate to account for current pricing and business trends.

[0001564590-22-030248:auditors_report:14]
The principal consideration for our determination that rebate adjustments determined to be variable consideration is a critical audit matter is that the estimates made in determining the rebate adjustments involve significant judgments.  Evaluating the appropriateness of these estimates requires a high degree of auditor judgment and increased audit effort.

[0001564590-22-030248:auditors_report:15]
Our audit procedures related to the rebate adjustments determined to be variable consideration included the following, among others:

[0001564590-22-030248:auditors_report:16]
|  | • | Obtained an understanding, evaluated the design, and tested the operating effectiveness of the Company’s internal controls over the estimation of variable consideration for stocking distributor rebates, including: |

[0001564590-22-030248:auditors_report:17]
|  | o | Historical actual rebate claims |

[0001564590-22-030248:auditors_report:18]
|  | o | Estimates of future rebate claims |

[0001564590-22-030248:auditors_report:19]
|  | o | End customer pricing |

[0001564590-22-030248:auditors_report:20]
|  | o | Channel inventory |

[0001564590-22-030248:auditors_report:21]
|  | • | Identified the sources of data and factors that management used in forming the assumptions, and considered whether such data and factors are relevant, reliable, and sufficient. |

[0001564590-22-030248:auditors_report:22]
|  | • | Evaluated potential contrary evidence, including the historical accuracy of management’s estimates by comparing the estimated reserve rate to the actual reserve rate in subsequent periods. |

[0001564590-22-030248:auditors_report:23]
|  | • | Assessed the appropriateness of the related disclosures in the consolidated financial statements. |

[0001564590-22-030248:auditors_report:24]
/s/ Grant Thornton LLP

[0001564590-22-030248:auditors_report:25]
We have served as the Company’s auditor since 2021.

[0001564590-22-030248:auditors_report:26]
San Francisco, California

[0001564590-22-030248:auditors_report:27]
August 26, 2022

[0001564590-22-030248:auditors_report:28]
46

[0001564590-22-030248:auditors_report:29]
Report of Independent Registered Public Accounting Firm

[0001564590-22-030248:auditors_report:30]
Board of Directors and Stockholders

[0001564590-22-030248:auditors_report:31]
Extreme Networks, Inc.

[0001564590-22-030248:auditors_report:32]
Opinion on internal control over financial reporting

[0001564590-22-030248:auditors_report:33]
We have audited the internal control over financial reporting of Extreme Networks, Inc. (a Delaware corporation) and subsidiaries (the “Company”) as of June 30, 2022, based on criteria established in the 2013 Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2022, based on criteria established in the 2013 Internal Control—Integrated Framework issued by COSO.

[0001564590-22-030248:auditors_report:34]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the consolidated financial statements of the Company as of and for the year ended June 30, 2022, and our report dated August 26, 2022 expressed an unqualified opinion on those financial statements.

[0001564590-22-030248:auditors_report:35]
Basis for opinion

[0001564590-22-030248:auditors_report:36]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-22-030248:auditors_report:37]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001564590-22-030248:auditors_report:38]
Definition and limitations of internal control over financial reporting

[0001564590-22-030248:auditors_report:39]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001564590-22-030248:auditors_report:40]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001564590-22-030248:auditors_report:41]
/s/ Grant Thornton LLP

[0001564590-22-030248:auditors_report:42]
San Francisco, California

[0001564590-22-030248:auditors_report:43]
August 26, 2022

[0001564590-22-030248:auditors_report:44]
Report of Independent Registered Public Accounting Firm

[0001564590-22-030248:auditors_report:45]
To the Stockholders and the Board of Directors of Extreme Networks, Inc.

[0001564590-22-030248:auditors_report:46]
Opinion on the Financial Statements

[0001564590-22-030248:auditors_report:47]
We have audited the accompanying consolidated balance sheet of Extreme Networks, Inc. (the Company) as of June 30, 2021, the related consolidated statements of operations, comprehensive income, stockholders' equity and cash flows for the year ended June 30, 2021, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at June 30, 2021, and the results of its operations and its cash flows for the year ended June 30, 2021, in conformity with U.S. generally accepted accounting principles.

[0001564590-22-030248:auditors_report:48]
Basis for Opinion

[0001564590-22-030248:auditors_report:49]
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company’s financial statements based on our audit. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-22-030248:auditors_report:50]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001564590-22-030248:auditors_report:51]
/s/ Ernst & Young LLP

[0001564590-22-030248:auditors_report:52]
We served as the Company’s auditor from 2020 to 2021.

[0001564590-22-030248:auditors_report:53]
San Jose, California

[0001564590-22-030248:auditors_report:54]
August 27, 2021

[0001564590-22-030248:auditors_report:55]
Report of Independent Registered Public Accounting Firm

[0001564590-22-030248:auditors_report:56]
To the Stockholders and Board of Directors

[0001564590-22-030248:auditors_report:57]
Extreme Networks, Inc.:

[0001564590-22-030248:auditors_report:58]
Opinion on the Consolidated Financial Statements

[0001564590-22-030248:auditors_report:59]
We have audited the accompanying consolidated statements of operations, comprehensive loss, stockholders’ equity, and cash flows of Extreme Networks, Inc. and subsidiaries (the Company) for the year ended June 30, 2020, and the related notes (collectively, the consolidated financial statements). In our opinion, the consolidated financial statements present fairly, in all material respects, the results of its operations and its cash flows for the year ended June 30, 2020, in conformity with U.S. generally accepted accounting principles.

[0001564590-22-030248:auditors_report:60]
Change in Accounting Principle

[0001564590-22-030248:auditors_report:61]
As discussed in Note 2 to the consolidated financial statements, the Company has changed its method of accounting for leases as of July 1, 2019 due to the adoption of Accounting Standards Update 2016-02, Leases, and several related amendments, as issued by the Financial Accounting Standards Board.

[0001564590-22-030248:auditors_report:62]
Basis for Opinion

[0001564590-22-030248:auditors_report:63]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on these consolidated financial statements based on our audit. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001564590-22-030248:auditors_report:64]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audit included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audit also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audit provides a reasonable basis for our opinion.

[0001564590-22-030248:auditors_report:65]
/s/KPMG LLP

[0001564590-22-030248:auditors_report:66]
We served as the Company’s auditor from 2010 to 2020.

[0001564590-22-030248:auditors_report:67]
Raleigh, North Carolina

[0001564590-22-030248:auditors_report:68]
August 31, 2020

[0001564590-22-030248:auditors_report:69]
EXTREME NETWORKS, INC.


## item_9a

[0001564590-22-030248:item_9a:1]
Item 9A. Controls and Procedures

[0001564590-22-030248:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-22-030248:item_9a:3]
Disclosure controls and procedures are controls and procedures designed to reasonably assure that information required to be disclosed in our reports filed under the Securities Exchange Act of 1934 as amended, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and to reasonably assure that such information is accumulated and communicated to our management, including the Chief Executive Officer (“CEO”) and the Chief Financial Officer (“CFO”), as appropriate to allow timely decisions regarding required disclosure.

[0001564590-22-030248:item_9a:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we evaluated the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO concluded that our disclosure controls and procedures were effective as of June 30, 2022.

[0001564590-22-030248:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001564590-22-030248:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over our financial reporting. There are inherent limitations in the effectiveness of any system of internal control, including the possibility of human error and the circumvention or overriding of controls. Accordingly, even effective internal controls can provide only reasonable assurances with respect to financial statement preparation. Further because of changes in conditions, the effectiveness of internal control may vary over time.

[0001564590-22-030248:item_9a:7]
We assessed the effectiveness of our internal control over financial reporting as of June 30, 2022. In making this assessment, we used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in Internal Control-Integrated Framework (2013). Based on our assessment using those criteria, we concluded that, as of June 30, 2022, our internal control over financial reporting is effective.

[0001564590-22-030248:item_9a:8]
During the year ended June 30, 2022, we completed our acquisitions of Ipanema SAS (“Ipanema”). In conducting our evaluation of the effectiveness of our internal controls over financial reporting as of June 30, 2022, we have elected to exclude the Ipanema business from our evaluation for fiscal 2022 as permitted under current Securities and Exchange Commission rules and regulations. As of and for the year ended June 30, 2022, the assets and revenues of the acquired businesses not included in our evaluation represented less than 1% of consolidated assets and 1% of consolidated revenues. We are currently in the process of integrating and assessing the internal controls over financial reporting of the acquired businesses with the rest of our Company. The integration may lead to changes in future periods, but we do not expect these changes to materially affect our internal controls over financial reporting. We expect to complete this integration in fiscal 2023.

[0001564590-22-030248:item_9a:9]
Our independent registered public accounting firm, Grant Thornton, LLP, has audited the consolidated financial statements as of and for the year ended June 30, 2022 included in this Annual Report on Form 10-K and has issued its report on our internal control over financial reporting as of June 30, 2022.

[0001564590-22-030248:item_9a:10]
Changes in Internal Control over Financial Reporting

[0001564590-22-030248:item_9a:11]
There were no changes in our internal control over financial reporting (as defined in Rules 13a – 15(f) and 15d – 15(f) under the Securities Exchange Act of 1934, as amended) during the fourth quarter of 2022 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-22-030248:item_9a:12]
88

[0001564590-22-030248:item_9a:13]
EXTREME NETWORKS, INC.

[0001564590-22-030248:item_9a:14]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS—(Continued)

[0001564590-22-030248:item_9a:15]
Inherent Limitations on Effectiveness of Controls

[0001564590-22-030248:item_9a:16]
Our management, including the CEO and CFO, does not expect that our disclosure controls or our internal control over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. Our controls and procedures are designed to provide reasonable assurance that our control system’s objective will be met, and our CEO and CFO have concluded that our disclosure controls and procedures are effective at the reasonable assurance level. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within Extreme have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events. Projections of any evaluation of the effectiveness of controls in future periods are subject to risks. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Notwithstanding these limitations, our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives. Our CEO and CFO have concluded that our disclosure controls and procedures are, in fact, effective at the “reasonable assurance” level.
