# EXTR notes — 0001564590-16-017216


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-16-017216:notes:1]
[same as prior period, unchanged from 0001564590-16-012196:notes:1]

[0001564590-16-017216:notes:2]
[same as prior period, unchanged from 0001564590-16-012196:notes:2]

[0001564590-16-017216:notes:3]
The unaudited condensed consolidated financial statements of Extreme Networks included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2015 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2015.

[0001564590-16-017216:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2016  The results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results that may be expected for fiscal 2016 or any future periods.

[0001564590-16-017216:notes:5]
[same as prior period, unchanged from 0001564590-16-012196:notes:5]

[0001564590-16-017216:notes:6]
The Company uses a fiscal calendar year ending on June 30.  All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.

[0001564590-16-017216:notes:7]
[same as prior period, unchanged from 0001564590-16-012196:notes:7]

[0001564590-16-017216:notes:8]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries.  All inter-company accounts and transactions have been eliminated.

[0001564590-16-017216:notes:9]
[same as prior period, unchanged from 0001564590-16-012196:notes:9]

[0001564590-16-017216:notes:10]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes.  Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.

[0001564590-16-017216:notes:11]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-16-017216:notes:12]
[same as prior period, unchanged from 0001564590-16-012196:notes:13]

[0001564590-16-017216:notes:13]
[same as prior period, unchanged from 0001564590-16-012196:notes:14]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-017216:notes:14]
[same as prior period, unchanged from 0001564590-16-012196:notes:18]

[0001564590-16-017216:notes:15]
[same as prior period, unchanged from 0001564590-16-012196:notes:19]

[0001564590-16-017216:notes:16]
[same as prior period, unchanged from 0001564590-16-012196:notes:20]

[0001564590-16-017216:notes:17]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Cash |  | $ | 83,564 |  |  | $ | 71,455 |  |
| Cash equivalents |  | $ | 4,770 |  |  | $ | 4,770 |  |
| Total available-for-sale |  | $ | 4,770 |  |  | $ | 4,770 |  |
| Total cash, cash equivalents and available for sale securities |  | $ | 88,334 |  |  | $ | 76,225 |  |

[0001564590-16-017216:notes:18]
[same as prior period, unchanged from 0001564590-16-012196:notes:22]

[0001564590-16-017216:notes:19]
[same as prior period, unchanged from 0001564590-16-012196:notes:23]

[0001564590-16-017216:notes:20]
The Company’s inventory balances as of March 31, 2016 and June 30, 2015 were $$52.8 million and $58.0 million, respectively. The Company values its inventory at lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-16-017216:notes:21]
[same as prior period, unchanged from 0001564590-16-012196:notes:25]

[0001564590-16-017216:notes:22]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Finished goods |  | $ | 50,027 |  |  | $ | 55,301 |  |
| Raw materials |  |  | 2,728 |  |  |  | 2,713 |  |
| Total Inventory |  | $ | 52,755 |  |  | $ | 58,014 |  |

[0001564590-16-017216:notes:23]
[same as prior period, unchanged from 0001564590-16-012196:notes:27]

[0001564590-16-017216:notes:24]
[same as prior period, unchanged from 0001564590-16-012196:notes:28]

[0001564590-16-017216:notes:25]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Computer equipment |  | $ | 33,983 |  |  | $ | 32,753 |  |
| Purchased software |  |  | 5,941 |  |  |  | 5,425 |  |
| Office equipment, furniture and fixtures |  |  | 10,827 |  |  |  | 10,908 |  |
| Leasehold improvements |  |  | 19,110 |  |  |  | 24,293 |  |
| Total property and equipment |  |  | 69,861 |  |  |  | 73,379 |  |
| Less: accumulated depreciation and amortization |  |  | (39,422 | ) |  |  | (33,517 | ) |
| Property and equipment, net |  | $ | 30,439 |  |  | $ | 39,862 |  |

[0001564590-16-017216:notes:26]
[same as prior period, unchanged from 0001564590-16-012196:notes:30]

[0001564590-16-017216:notes:27]
The following tables summarize the components of gross and net intangible asset balances (dollars in thousands):

[0001564590-16-017216:notes:28]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 0.40 years |  | $ | 48,000 |  |  | $ | 39,611 |  |  | $ | 8,389 |  |
| Customer relationships |  | 0.50 years |  |  | 37,000 |  |  |  | 29,806 |  |  |  | 7,194 |  |
| Maintenance contracts |  | 2.50 years |  |  | 17,000 |  |  |  | 8,217 |  |  |  | 8,783 |  |
| Trademarks |  | 0.50 years |  |  | 2,500 |  |  |  | 2,014 |  |  |  | 486 |  |
| License agreements |  | 9.80 years |  |  | 3,596 |  |  |  | 1,583 |  |  |  | 2,013 |  |
| Other intangibles |  | 3.92 years |  |  | 1,426 |  |  |  | 866 |  |  |  | 560 |  |
| Total intangibles, net |  |  |  | $ | 109,522 |  |  | $ | 82,097 |  |  | $ | 27,425 |  |

[0001564590-16-017216:notes:29]
[same as prior period, unchanged from 0001564590-16-012196:notes:33]

[0001564590-16-017216:notes:30]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-16-017216:notes:31]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Amortization in "Cost of revenue for products" |  | $ | 3,572 |  |  | $ | 4,513 |  |  | $ | 11,847 |  |  | $ | 13,575 |  |
| Amortization of intangibles |  |  | 4,142 |  |  |  | 4,467 |  |  |  | 12,860 |  |  |  | 13,402 |  |
| Total amortization |  | $ | 7,714 |  |  | $ | 8,980 |  |  | $ | 24,707 |  |  | $ | 26,977 |  |

[0001564590-16-017216:notes:32]
The amortization expense that is recognized in “Cost of revenues for products” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-16-017216:notes:33]
[same as prior period, unchanged from 0001564590-16-012196:notes:35]

[0001564590-16-017216:notes:34]
[same as prior period, unchanged from 0001564590-16-012196:notes:36]

[0001564590-16-017216:notes:35]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Accrued general and administrative costs |  | $ | 4,287 |  |  | $ | 1,204 |  |
| Restructuring |  |  | 2,199 |  |  |  | 5,854 |  |
| Other accrued liabilities |  |  | 23,696 |  |  |  | 25,565 |  |
| Total other accrued liabilities |  | $ | 30,182 |  |  | $ | 32,623 |  |

[0001564590-16-017216:notes:36]
[same as prior period, unchanged from 0001564590-16-012196:notes:38]

[0001564590-16-017216:notes:37]
[same as prior period, unchanged from 0001564590-16-012196:notes:39]

[0001564590-16-017216:notes:38]
[same as prior period, unchanged from 0001564590-16-012196:notes:40]

[0001564590-16-017216:notes:39]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Deferred services |  | $ | 85,069 |  |  | $ | 87,441 |  |
| Deferred product and other revenue |  |  | 13,870 |  |  |  | 12,341 |  |
| Total deferred revenue |  |  | 98,939 |  |  |  | 99,782 |  |
| Less: current portion |  |  | 76,712 |  |  |  | 76,551 |  |
| Non-current deferred revenue, net |  | $ | 22,227 |  |  | $ | 23,231 |  |

[0001564590-16-017216:notes:40]
[same as prior period, unchanged from 0001564590-16-012196:notes:42]

[0001564590-16-017216:notes:41]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Balance beginning of period |  | $ | 84,706 |  |  | $ | 91,373 |  |  | $ | 87,441 |  |  | $ | 89,657 |  |
| New support arrangements |  |  | 27,683 |  |  |  | 27,198 |  |  |  | 84,502 |  |  |  | 91,254 |  |
| Recognition of support revenue |  |  | (27,320 | ) |  |  | (29,834 | ) |  |  | (86,874 | ) |  |  | (92,174 | ) |
| Balance end of period |  |  | 85,069 |  |  |  | 88,737 |  |  |  | 85,069 |  |  |  | 88,737 |  |
| Less: current portion |  |  | 62,842 |  |  |  | 65,596 |  |  |  | 62,842 |  |  |  | 65,596 |  |
| Non-current deferred revenue |  | $ | 22,227 |  |  | $ | 23,141 |  |  | $ | 22,227 |  |  | $ | 23,141 |  |

[0001564590-16-017216:notes:42]
[same as prior period, unchanged from 0001564590-16-012196:notes:44]

[0001564590-16-017216:notes:43]
The Company records revenue from its distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to its distributors in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its condensed consolidated balance sheets. The amount shown as “Deferred distributors revenue, net of cost of sales to distributors” represents the deferred gross profit on sales to distributors based on contractual pricing.

[0001564590-16-017216:notes:44]
[same as prior period, unchanged from 0001564590-16-012196:notes:46]

[0001564590-16-017216:notes:45]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Deferred distributors revenue |  | $ | 31,367 |  |  | $ | 53,366 |  |
| Deferred cost of sales to distributors |  |  | (7,434 | ) |  |  | (12,491 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | $ | 23,933 |  |  | $ | 40,875 |  |

[0001564590-16-017216:notes:46]
[same as prior period, unchanged from 0001564590-16-012196:notes:48]

[0001564590-16-017216:notes:47]
The Company’s debt is comprised of the following (in thousands):

[0001564590-16-017216:notes:48]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 16,250 |  |  | $ | 11,375 |  |
| Current portion of long-term debt |  | $ | 16,250 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 32,500 |  |  | $ | 45,500 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 42,500 |  |  |  | 55,500 |  |
| Total debt |  | $ | 58,750 |  |  | $ | 66,875 |  |

[0001564590-16-017216:notes:49]
During fiscal 2015, the Company amended its credit agreement which provides for a five-year revolving credit facility for up to $50.0 million (the “Revolving Facility”) and a $65.0 million five-year term loan (the “Term Loan”) and together with the Revolving Facility the (“Senior Secured Credit Facilities, as amended”).

[0001564590-16-017216:notes:50]
The Senior Secured Credit Facilities, as amended contains, among others, certain financial covenants that require the Company to maintain defined minimum financial ratios which may limit the Company’s availability to borrowings under the Revolving Facility. As of  March 31, 2016, the Company had $39.0 million of availability under the Revolving Facility and is in compliance with its covenants.

[0001564590-16-017216:notes:51]
The Company had $1.0 million of outstanding letters of credit as of March 31, 2016

[0001564590-16-017216:notes:52]
[same as prior period, unchanged from 0001564590-16-012196:notes:54]

[0001564590-16-017216:notes:53]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates. The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-16-017216:notes:54]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2016 and 2015 (in thousands):

[0001564590-16-017216:notes:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Balance beginning of period |  | $ | 10,415 |  |  | $ | 7,845 |  |  | $ | 8,676 |  |  | $ | 7,551 |  |
| New warranties issued |  |  | 1,638 |  |  |  | 1,751 |  |  |  | 7,158 |  |  |  | 5,699 |  |
| Warranty expenditures |  |  | (1,773 | ) |  |  | (1,717 | ) |  |  | (5,554 | ) |  |  | (5,371 | ) |
| Balance end of period |  | $ | 10,280 |  |  | $ | 7,879 |  |  | $ | 10,280 |  |  | $ | 7,879 |  |

[0001564590-16-017216:notes:56]
[same as prior period, unchanged from 0001564590-16-012196:notes:58]

[0001564590-16-017216:notes:57]
[same as prior period, unchanged from 0001564590-16-012196:notes:59]

[0001564590-16-017216:notes:58]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue. All other advertising costs are expensed as incurred.  Advertising expenses for three and nine months ended March 31, 2016 and 2015, were immaterial.

[0001564590-16-017216:notes:59]
[same as prior period, unchanged from 0001564590-16-012196:notes:61]

[0001564590-16-017216:notes:60]
[same as prior period, unchanged from 0001564590-16-012196:notes:62]

[0001564590-16-017216:notes:61]
[same as prior period, unchanged from 0001564590-16-012196:notes:63]

[0001564590-16-017216:notes:62]
[same as prior period, unchanged from 0001564590-16-012196:notes:64]

[0001564590-16-017216:notes:63]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Jenne |  |  | 17% |  |  | * |  |  |  | 13% |  |  | * |  |
| Tech Data Corporation |  |  | 16% |  |  | * |  |  |  | 16% |  |  |  | 12% |  |
| Westcon Group Inc. |  |  | 13% |  |  |  | 16% |  |  |  | 15% |  |  |  | 13% |  |
| Scansource, Inc. |  | * |  |  |  | 13% |  |  | * |  |  | * |  |

[0001564590-16-017216:notes:64]
[same as prior period, unchanged from 0001564590-16-012196:notes:66]

[0001564590-16-017216:notes:65]
The following customers account for more than 10% of our accounts receivable outstanding as of March 31, 2016, Westcon Group Inc. 17% and Tech Data Corporation 11%.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-16-017216:notes:66]
[same as prior period, unchanged from 0001564590-16-012196:notes:67]

[0001564590-16-017216:notes:67]
[same as prior period, unchanged from 0001564590-16-012196:notes:68]

[0001564590-16-017216:notes:68]
[same as prior period, unchanged from 0001564590-16-012196:notes:69]

[0001564590-16-017216:notes:69]
[same as prior period, unchanged from 0001564590-16-012196:notes:70]

[0001564590-16-017216:notes:70]
[same as prior period, unchanged from 0001564590-16-012196:notes:71]

[0001564590-16-017216:notes:71]
[same as prior period, unchanged from 0001564590-16-012196:notes:72]

[0001564590-16-017216:notes:72]
| March 31, 2016 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |
| Total |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |

[0001564590-16-017216:notes:73]
| June 30, 2015 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |
| Total |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |

[0001564590-16-017216:notes:74]
Level 2 investments: The Company does not hold any level 2 investments.

[0001564590-16-017216:notes:75]
The Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2. There were no transfers of assets or liabilities between Level 1 and Level 2 for the periods presented.

[0001564590-16-017216:notes:76]
The fair value of the borrowings under the Senior Secured Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the carrying amount of the Company’s indebtedness of $58.8 million and $66.9 million as of March 31, 2016 and June 30, 2015, respectively.

[0001564590-16-017216:notes:77]
[same as prior period, unchanged from 0001564590-16-012196:notes:77]

[0001564590-16-017216:notes:78]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. There were no impairments recorded for the three and nine months ended March 31, 2016 or 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-017216:notes:79]
[same as prior period, unchanged from 0001564590-16-012196:notes:79]

[0001564590-16-017216:notes:80]
[same as prior period, unchanged from 0001564590-16-012196:notes:80]

[0001564590-16-017216:notes:81]
As of March 31, 2016, the Company had reserved for issuance (in thousands):

[0001564590-16-017216:notes:82]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| 2014 Employee Stock Purchase Plan |  |  | 10,001 |  |  |  | 12,000 |  |
| Employee stock options and awards outstanding |  |  | 11,174 |  |  |  | 15,273 |  |
| Employee stock options and awards available for grant |  |  | 5,140 |  |  |  | 5,450 |  |
| Total shares reserved for issuance |  |  | 26,315 |  |  |  | 32,723 |  |

[0001564590-16-017216:notes:83]
[same as prior period, unchanged from 0001564590-16-012196:notes:83]

[0001564590-16-017216:notes:84]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Cost of product revenue |  | $ | 205 |  |  | $ | 265 |  |  | $ | 777 |  |  | $ | 823 |  |
| Cost of service revenue |  |  | 223 |  |  |  | 254 |  |  |  | 867 |  |  |  | 816 |  |
| Research and development |  |  | 1,137 |  |  |  | 1,423 |  |  |  | 3,857 |  |  |  | 4,611 |  |
| Sales and marketing |  |  | 996 |  |  |  | 1,291 |  |  |  | 3,791 |  |  |  | 4,414 |  |
| General and administrative |  |  | 942 |  |  |  | 1,139 |  |  |  | 2,828 |  |  |  | 3,271 |  |
| Total share-based compensation expense |  | $ | 3,503 |  |  | $ | 4,372 |  |  | $ | 12,120 |  |  | $ | 13,935 |  |

[0001564590-16-017216:notes:85]
During the three and nine months ended March 31, 2016 and 2015, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-16-017216:notes:86]
[same as prior period, unchanged from 0001564590-16-012196:notes:86]

[0001564590-16-017216:notes:87]
Stock awards may be granted under the 2013 Equity Incentive Plan (the “2013 Plan”) on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (including performance or market-based restricted stock units) which vest over a fixed period of time or based upon the satisfaction of certain ;performance criteria.

[0001564590-16-017216:notes:88]
The following table summarizes stock award activity for the nine months ended March 31, 2016  (in thousands, except grant date fair value):

[0001564590-16-017216:notes:89]
|  |  | Number of |  |  | Weighted- |  |  |  |  |  |
|  |  | Shares |  |  | Average Grant- |  |  | Aggregate Fair |  |
|  |  | (000’s) |  |  | Date Fair Value |  |  | Market Value ($000’s) |  |
| Non-vested stock awards outstanding at June 30, 2015 |  |  | 4,597 |  |  | $ | 3.82 |  |  |  |  |  |
| Granted |  |  | 3,010 |  |  | $ | 3.12 |  |  |  |  |  |
| Vested |  |  | (2,198 | ) |  | $ | 4.30 |  |  |  |  |  |
| Cancelled |  |  | (992 | ) |  | $ | 2.84 |  |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2016 |  |  | 4,417 |  |  | $ | 3.33 |  |  | $ | 21,113 |  |

[0001564590-16-017216:notes:90]
The following table summarizes stock option activity for the nine months ended March 31, 2016 (in thousands, except per share and contractual term):

[0001564590-16-017216:notes:91]
|  |  |  |  |  |  | Weighted- |  |  | Weighted- |  |  |  |  |  |
|  |  |  |  |  |  | Average |  |  | Average |  |  | Aggregate |  |
|  |  | Number of |  |  | Exercise |  |  | Remaining |  |  | Intrinsic |  |
|  |  | Shares |  |  | Price |  |  | Contractual |  |  | Value |  |
|  |  | (000’s) |  |  | Per Share |  |  | Term (years) |  |  | (000’s) |  |
| Options outstanding at June 30, 2015 |  |  | 10,604 |  |  | $ | 4.03 |  |  |  | 3.79 |  |  | $ | 410 |  |
| Granted |  |  | 5 |  |  | $ | 3.79 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (276 | ) |  | $ | 3.12 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (3,576 | ) |  | $ | 3.91 |  |  |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2016 |  |  | 6,757 |  |  | $ | 4.13 |  |  |  | 4.25 |  |  | $ | 936 |  |
| Exercisable at March 31, 2016 |  |  | 4,560 |  |  | $ | 4.25 |  |  |  | 3.16 |  |  | $ | 361 |  |
| Vested and expected to vest at March 31, 2016 |  |  | 6,393 |  |  | $ | 4.17 |  |  |  | 4.09 |  |  | $ | 807 |  |

[0001564590-16-017216:notes:92]
The weighted-average grant-date fair value of options granted during the nine months ended March 31, 2016 was $1.59. The weighted-average grant-date fair value of options granted during the three and nine months ended March 31, 2015 was $1.34 and $1.91, respectively.

[0001564590-16-017216:notes:93]
The weighted-average fair value of shares granted under the Company’s 2014 ESPP during the three and nine months ended March 31, 2016 was $1.88  and $1.93, respectively. The weighted-average fair value of shares granted under the Company’s 2014 ESPP and 1999 ESPP during the three and nine months ended March 31, 2015 was $0.59 and $1.02, respectively.

[0001564590-16-017216:notes:94]
[same as prior period, unchanged from 0001564590-16-012196:notes:94]

[0001564590-16-017216:notes:95]
[same as prior period, unchanged from 0001564590-16-012196:notes:95]

[0001564590-16-017216:notes:96]
[same as prior period, unchanged from 0001564590-16-012196:notes:96]

[0001564590-16-017216:notes:97]
|  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Expected life |  |  | - |  |  | 4.6 years |  |  | 1.45 years |  |  | 0.50 years |  |  | 4.0 years |  |  | 4.7 years |  |  | 1.25 |  |  | 0.33 years |  |
| Risk-free interest rate |  |  | — | % |  |  | 1.49 | % |  |  | 0.52 | % |  |  | 0.07 | % |  |  | 1.78 | % |  |  | 1.60 | % |  |  | 0.44 | % |  |  | 0.04 | % |
| Volatility |  |  | — | % |  |  | 54 | % |  |  | 57 | % |  |  | 58 | % |  |  | 52 | % |  |  | 54 | % |  |  | 57 | % |  |  | 58 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-017216:notes:98]
[same as prior period, unchanged from 0001564590-16-012196:notes:98]

[0001564590-16-017216:notes:99]
As of March 31, 2016, restructuring liabilities were $4.2 million and consisted of obligations for severance benefits, contract termination and other expenses.  During the three and nine months ended March 31, 2016, the Company recorded restructuring charges of $1.4 million and $10.0 million, respectively. Included in the restructuring charges were offsets for future sub-leasing income. The Company has estimated the sub-lease income based on its existing leases agreement, as well the real estate market conditions at the respective locations. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements. The Company will reevaluate any sub-lease income on a regular basis and adjust the accrual as necessary if and when facts should change.

[0001564590-16-017216:notes:100]
Fiscal 2015 Restructuring:  Phase One

[0001564590-16-017216:notes:101]
During the fourth quarter of fiscal 2015, we reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing, as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions in the United States, among other actions.

[0001564590-16-017216:notes:102]
[same as prior period, unchanged from 0001564590-16-012196:notes:102]

[0001564590-16-017216:notes:103]
During fiscal 2016, we continued our initiative to realign our operations with a second phase by abandoning excess facilities, primarily in San Jose, California; Salem, New Hampshire; Research Triangle Park, North Carolina and Shannon, Ireland. The abandoned facilities represented approximately 29% of the floor space in the aggregate at these locations and included general office and warehouse space. There may be additional abandonments of excess facilities in future periods as we further align our organization to our business and operational needs.

[0001564590-16-017216:notes:104]
During the first quarter of fiscal 2016, in conjunction with the exiting of facilities noted above, the Company recorded restructuring charges of $5.6 million including $5.4 million for excess facility charges and adjustments to service benefits of $0.2 million.  Excess facilities charges included $4.1 million of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and accelerated depreciation of leasehold improvements in the amount of $1.3 million. This charge is reflected in "Restructuring charge, net of reversals" in the condensed consolidated statements of operations.

[0001564590-16-017216:notes:105]
During the second quarter of fiscal 2016, in conjunction with the exiting of the facilities noted above, the Company incurred restructuring charges of $3.0 million including $2.9 million in excess facilities charges related to amending its lease in North Carolina, thereby reducing it floor space by 36%, and adjustments to severance benefits of $0.2 million. Excess facilities charges included accelerated depreciation of leasehold improvements in the amount of $1.9 million and contract termination charges and professional fees of $1.0 million. This charge is reflected in "Restructuring charge, net of reversals" in the condensed consolidated statements of operations.

[0001564590-16-017216:notes:106]
During the third quarter of fiscal 2016, in conjunction with the exiting of facilities noted above, the Company incurred restructuring charges of $1.4 million.  Excess facilities charges included accelerated depreciation of leasehold improvements in the amount of $1.2 million associated with the North Carolina facility, $0.2 million related to a change in the accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for our San Jose, California facility and the reversal of $0.2 million of estimated severance benefits.  This charge is reflected in “Restructuring charge, net of reversals” in the condensed consolidated statements of operations. The excess facilities payments will continue through fiscal year 2023, due to the length of the lease agreements.

[0001564590-16-017216:notes:107]
[same as prior period, unchanged from 0001564590-16-012196:notes:107]

[0001564590-16-017216:notes:108]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2015 |  | $ | — |  |  | $ | 5,737 |  |  | $ | 117 |  |  | $ | 5,854 |  |
| Period charges |  |  | 5,409 |  |  |  | 321 |  |  |  | 178 |  |  |  | 5,908 |  |
| Period reversals |  |  | — |  |  |  | (235 | ) |  |  | (70 | ) |  |  | (305 | ) |
| Non cash adjustments |  |  | (1,344 | ) |  |  | — |  |  |  | — |  |  |  | (1,344 | ) |
| Period payments |  |  | (42 | ) |  |  | (4,207 | ) |  |  | (125 | ) |  |  | (4,374 | ) |
| Balance as of September 30, 2015 |  |  | 4,023 |  |  |  | 1,616 |  |  |  | 100 |  |  |  | 5,739 |  |
| Period charges |  |  | 2,874 |  |  |  | 347 |  |  |  | 53 |  |  |  | 3,274 |  |
| Period reversals |  |  | (14 | ) |  |  | (209 | ) |  |  | (20 | ) |  |  | (243 | ) |
| Non cash adjustments |  |  | (1,876 | ) |  |  | — |  |  |  | — |  |  |  | (1,876 | ) |
| Period payments |  |  | (653 | ) |  |  | (1,365 | ) |  |  | (133 | ) |  |  | (2,151 | ) |
| Balance as of December 31, 2015 |  |  | 4,354 |  |  |  | 389 |  |  |  | — |  |  |  | 4,743 |  |
| Period charges |  |  | 1,540 |  |  |  | — |  |  |  | 6 |  |  |  | 1,546 |  |
| Period reversals |  |  | (14 | ) |  |  | (174 | ) |  |  | — |  |  |  | (188 | ) |
| Non cash adjustments |  |  | (1,243 | ) |  |  | — |  |  |  | — |  |  |  | (1,243 | ) |
| Period payments |  |  | (440 | ) |  |  | (215 | ) |  |  | (6 | ) |  |  | (661 | ) |
| Balance as of March 31, 2016 |  | $ | 4,197 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,197 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,199 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,998 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-017216:notes:109]
| 8. | Commitments and Contingencies |

[0001564590-16-017216:notes:110]
Purchase Commitments

[0001564590-16-017216:notes:111]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2016, the Company had non-cancelable commitments to purchase $$68.5 million of such inventory.

[0001564590-16-017216:notes:112]
Legal Proceedings

[0001564590-16-017216:notes:113]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-16-017216:notes:114]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for the proceedings listed below, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  Based on its own investigations, the Company believes the ultimate outcome of any current legal proceedings, individually and in the aggregate, will not have a material adverse effect on its financial position, results of operation or cash flows. However, because of the nature and inherent uncertainties of the litigation, should the outcome of such actions be unfavorable, the Company's business, financial condition, results of operations or cash flows could be materially and adversely affected.

[0001564590-16-017216:notes:115]
Brazilian Tax Assessment Matters

[0001564590-16-017216:notes:116]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BR 3.4 million (US $0.9 million), plus interest and penalties BR 16.6 million (US $4.6 million).  Possible court fees are estimated to be BR 4.0 million (US $1.1 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

[0001564590-16-017216:notes:117]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits are expected to cover the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company changed its ICMS procedures effective May 2009 and a similar tax assessment is not anticipated.  The Company has provided the requested information for these tax years to the Brazilian tax authorities, but has received no further response from the Brazilian tax authorities.

[0001564590-16-017216:notes:118]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BR 23.4 million (US $6.4 million).  The Company does not expect a final judicial determination for several years.  The Company believes BR 9.4 million (US $2.6 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

[0001564590-16-017216:notes:119]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from the Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

[0001564590-16-017216:notes:120]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-16-017216:notes:121]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its current or former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from November 4, 2013 through April 9, 2015.  Motions for appointment of lead plaintiff have been filed, and are scheduled to be heard on May 5, 2016.  The Company believes the claims are without merit and intends to vigorously defend the claims.

[0001564590-16-017216:notes:122]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County.  Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and\ or members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and have submitted a stipulation to that effect to the court.

[0001564590-16-017216:notes:123]
Indemnification Obligations

[0001564590-16-017216:notes:124]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain.  As of March 31, 2016, the Company had no outstanding indemnification claims.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-017216:notes:125]
[same as prior period, unchanged from 0001564590-16-012196:notes:124]

[0001564590-16-017216:notes:126]
For the three and nine months ended March 31, 2016, the Company recorded an income tax provision of $0.9 million and $3.0 million, respectively. For the three and nine months ended March 31, 2015, the Company recorded an income tax provision of $1.1 million and $3.5 million, respectively.

[0001564590-16-017216:notes:127]
The income tax provisions for the three and nine months ended March 31, 2016 and 2015, consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and nine months ended March 31, 2016 and 2015, and therefore may not reflect the annual effective tax rate.

[0001564590-16-017216:notes:128]
[same as prior period, unchanged from 0001564590-16-012196:notes:127]

[0001564590-16-017216:notes:129]
[same as prior period, unchanged from 0001564590-16-012196:notes:128]

[0001564590-16-017216:notes:130]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10). The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes. During the three and nine months ended March 31, 2016, the Company deducted $1.1 million and $3.4 million of tax amortization expense, respectively related to capitalized goodwill. As of March 31, 2016, the Company recorded a deferred tax liability of $3.6 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets.

[0001564590-16-017216:notes:131]
The Company had $11.6 million of unrecognized tax benefits as of March 31, 2016. The future impact of the unrecognized tax benefit of $11.6 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-16-017216:notes:132]
[same as prior period, unchanged from 0001564590-16-012196:notes:131]

[0001564590-16-017216:notes:133]
[same as prior period, unchanged from 0001564590-16-012196:notes:132]


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-017216:notes:134]
[same as prior period, unchanged from 0001564590-16-012196:notes:133]

[0001564590-16-017216:notes:135]
[same as prior period, unchanged from 0001564590-16-012196:notes:134]

[0001564590-16-017216:notes:136]
[same as prior period, unchanged from 0001564590-16-012196:notes:135]

[0001564590-16-017216:notes:137]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Net loss |  | $ | (10,784 | ) |  | $ | (23,548 | ) |  | $ | (29,544 | ) |  | $ | (55,983 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 104,104 |  |  |  | 99,783 |  |  |  | 102,486 |  |  |  | 98,591 |  |
| Net loss per share - basic and diluted |  | $ | (0.10 | ) |  | $ | (0.24 | ) |  | $ | (0.29 | ) |  | $ | (0.57 | ) |

[0001564590-16-017216:notes:138]
[same as prior period, unchanged from 0001564590-16-012196:notes:137]

[0001564590-16-017216:notes:139]
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Options to purchase common stock |  |  | 4,827 |  |  |  | 9,839 |  |
| Restricted stock units |  |  | 1,478 |  |  |  | 1,694 |  |
| Employee Stock Purchase Plan shares |  |  | 185 |  |  |  | 0 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-017216:notes:140]
[same as prior period, unchanged from 0001564590-16-012196:notes:139]

[0001564590-16-017216:notes:141]
The Company from time to time enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. At March 31, 2016, we did not have any forward foreign currency contracts.

[0001564590-16-017216:notes:142]
Foreign currency transaction gains and losses from operations was a loss of $0.3 million and gain of $1.1 million for the three and nine months ended March 31, 2016, respectively. Foreign currency transaction gains and losses from operations was a loss of $0.5 million and a loss of $0.9 million for the three and nine months ended March 31, 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-017216:notes:143]
[same as prior period, unchanged from 0001564590-16-012196:notes:142]

[0001564590-16-017216:notes:144]
[same as prior period, unchanged from 0001564590-16-012196:notes:143]

[0001564590-16-017216:notes:145]
[same as prior period, unchanged from 0001564590-16-012196:notes:144]

[0001564590-16-017216:notes:146]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Net Revenues: |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 58,205 |  |  | $ | 49,353 |  |  | $ | 173,298 |  |  | $ | 166,001 |  |
| Other |  |  | 5,398 |  |  |  | 7,073 |  |  |  | 18,983 |  |  |  | 26,990 |  |
| Total Americas |  |  | 63,603 |  |  |  | 56,426 |  |  |  | 192,281 |  |  |  | 192,991 |  |
| EMEA |  |  | 50,358 |  |  |  | 50,006 |  |  |  | 161,486 |  |  |  | 166,515 |  |
| APAC |  |  | 10,925 |  |  |  | 13,158 |  |  |  | 35,005 |  |  |  | 43,566 |  |
| Total net revenues |  | $ | 124,886 |  |  | $ | 119,590 |  |  | $ | 388,772 |  |  | $ | 403,072 |  |

[0001564590-16-017216:notes:147]
| Long Lived Assets: |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Americas |  | $ | 64,452 |  |  | $ | 87,071 |  |
| EMEA |  |  | 17,321 |  |  |  | 29,610 |  |
| APAC |  |  | 2,295 |  |  |  | 3,108 |  |
| Total long lived assets |  | $ | 84,068 |  |  | $ | 119,789 |  |
