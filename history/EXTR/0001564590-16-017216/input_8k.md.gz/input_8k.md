# EXTR 8-K — 0001564590-16-016754 filed 2016-04-27

## item codes, every 8-K on or before 2016-04-29

- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2016-04-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-16-016754:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-16-016754:8k_2_02:2]
extr-ex991_6.htm

[0001564590-16-016754:8k_2_02:3]
Exhibit 99.1

[0001564590-16-016754:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-16-016754:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations |  | Media Contact |
| 408/579-3456 |  | 617/624-3231 |
| fyoshino@extremenetworks.com |  | ExtremeUS@racepointglobal.com |

[0001564590-16-016754:8k_2_02:6]
Extreme Networks Reports Third Quarter Fiscal Year 2016 Financial Results

[0001564590-16-016754:8k_2_02:7]
Q3 GAAP Revenue of $124.9 Million & Non-GAAP Revenue of $125.3 Million

[0001564590-16-016754:8k_2_02:8]
Q3 GAAP EPS Loss of $0.10 & Non-GAAP EPS Income of $0.03

[0001564590-16-016754:8k_2_02:9]
SAN JOSE, Calif., April 27, 2016 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for its fiscal third quarter ended March 31, 2016.  Third quarter GAAP revenue was $124.9 million and non-GAAP revenue was $125.3 million.  GAAP net loss for the third fiscal quarter was $10.8 million, or $0.10 per basic share, and non-GAAP net income was $3.5 million, or $0.03 per diluted share.

[0001564590-16-016754:8k_2_02:10]
“We posted solid performance for the quarter, achieving 4% year-over-year organic growth and significantly improved non-GAAP profitability, while also strengthening the balance sheet,” stated Ed Meyercord, President and CEO of Extreme Networks.  “Growth was driven by continued penetration of targeted education and hospitality/public venue enterprise customers in North America, and successful execution of our software-driven solutions selling approach for wireless and wired enterprise campus networking.

[0001564590-16-016754:8k_2_02:11]
“Despite the challenging macro environment for enterprise campus switching, which included seasonal pricing pressure, our team made consistent progress in selling the ExtremeManagement, ExtremeControl and ExtremeAnalytics software portfolio combined with our Wave 2 access points and next generation end-to-end switch portfolio powered by Broadcom.  We are encouraged by the growing number of customers who recognize the important benefits of adopting our integrated software and hardware solution, which include lower total cost of ownership, improved network performance and security, and more efficient network management,” Meyercord added.

[0001564590-16-016754:8k_2_02:12]
Recent Key Events:

[0001564590-16-016754:8k_2_02:13]
|  | · | Unveiled Wireless Specialization Program. During the quarter, we introduced the ExtremeWireless specialization program to further enable global channel partners to deliver the wireless solutions customers require in order to increase productivity and responsiveness and extend applications beyond the wired network. |

[0001564590-16-016754:8k_2_02:14]
|  | · | Strengthened the Sales Leadership Team. We announced the appointment of John Morrison to the position of vice president, EMEA sales and services. Morrison will oversee EMEA sales, services and strategy. In addition, we announced the appointment of Gordon Mackintosh to the position of senior director of worldwide partner program and sales business development. In this role, Mackintosh is responsible for the ongoing development of the Extreme Partner Network to provide the company’s global partner ecosystem with new revenue streams and growth opportunities. |

[0001564590-16-016754:8k_2_02:15]
|  | · | Partnership with the NFL. To further measure and analyze the fan experience, the NFL leveraged ExtremeAnalytics as part of Extreme Networks’ role as the Official Wi-Fi Analytics Provider of Super Bowl 50. We also provided our ExtremeWireless solution to Super Bowl City in the San Francisco Bay area, where over 100 Wi-Fi Coaches assisted fans with their wireless needs to enhance their game day digital experience. |

[0001564590-16-016754:8k_2_02:16]
|  | · | Key Customer Wins in Focus Markets. Extreme Networks continued to showcase customer momentum. Notable customer wins in key vertical markets include: |

[0001564590-16-016754:8k_2_02:17]
|  | · | Education: Sinclair Community College, Slippery Rock University, Letcher County Schools, Grant County Schools, Valdosta City School District |

[0001564590-16-016754:8k_2_02:18]
|  | · | Healthcare: Hunterdon Healthcare System, Basildon & Thurrock University Hospitals NHS Trust, Charitè Universitätsmedizin Berlin, Barco |

[0001564590-16-016754:8k_2_02:19]
|  | · | Manufacturing: Volkswagen, Schneider Electric |

[0001564590-16-016754:8k_2_02:20]
|  | · | Hospitality: UOA Vertical Hotel Bangsar, The Kraft Group – New England Patriots, Carolina Panthers, Buffalo Sabres, Chicago Cubs |

[0001564590-16-016754:8k_2_02:21]
|  | · | Government: The United States Department of Health and Human Services, Commonwealth of Massachusetts – Port Authority, Perth & Kinross Council, Republic of Turkey – Ministry of Interior, Ankara Metropolitan Municipality Water and Sewerage, City of Memphis |

[0001564590-16-016754:8k_2_02:22]
|  | · | Additional customers include: SAK Holding, Reed Smith Shaw & McClay, GasLINE GmbH & Co. KG, Nokia |

[0001564590-16-016754:8k_2_02:23]
Fiscal Q3 2016 Financial Metrics:

[0001564590-16-016754:8k_2_02:24]
|  |  | 2016 |  |  | 2015 |  |  | Change |  |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 92.7 |  |  | $ | 86.5 |  |  | $ | 6.2 |  |  |  | 7 | % |
| Service |  |  | 32.2 |  |  |  | 33.1 |  |  |  | (0.9 | ) |  |  | (3 | )% |
| Total Net Revenue |  | $ | 124.9 |  |  | $ | 119.6 |  |  | $ | 5.3 |  |  |  | 4 | % |
| Gross Margin |  |  | 50.2 | % |  |  | 48.3 | % |  |  | 1.9 | % |  |  | 4 | % |
| Operating Margin |  |  | (7.1 | )% |  |  | (17.8 | )% |  |  | 10.7 | % |  |  | 60 | % |
| Net Loss |  | $ | (10.8 | ) |  | $ | (23.5 | ) |  | $ | 12.7 |  |  |  | 54 | % |
| Loss per basic share |  | $ | (0.10 | ) |  | $ | (0.24 | ) |  | $ | 0.14 |  |  |  | 58 | % |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 92.7 |  |  | $ | 86.5 |  |  | $ | 6.2 |  |  |  | 7 | % |
| Service |  |  | 32.6 |  |  |  | 33.9 |  |  |  | (1.3 | ) |  |  | (4 | )% |
| Total Net Revenue |  | $ | 125.3 |  |  | $ | 120.4 |  |  | $ | 4.9 |  |  |  | 4 | % |
| Gross Margin |  |  | 53.4 | % |  |  | 52.6 | % |  |  | 0.8 | % |  |  | 2 | % |
| Operating Margin |  |  | 4.3 | % |  |  | (4.7 | )% |  |  | 9.0 | % |  |  | 191 | % |
| Net Income (Loss) |  | $ | 3.5 |  |  | $ | (7.9 | ) |  | $ | 11.4 |  |  |  | 144 | % |
| Earnings (loss) per diluted share |  | $ | 0.03 |  |  | $ | (0.08 | ) |  | $ | 0.11 |  |  |  | 138 | % |

[0001564590-16-016754:8k_2_02:25]
|  | · | Cash and investments ended the quarter at $88.3 million, as compared to $85.9 million from the prior quarter. |

[0001564590-16-016754:8k_2_02:26]
|  | · | Accounts receivable balance ending Q3 was $62.7 million, with days sales outstanding (DSO) of 46. |

[0001564590-16-016754:8k_2_02:27]
|  | · | Inventory ending Q3 was $52.8 million, a decrease of $3.8 million from the prior quarter. |

[0001564590-16-016754:8k_2_02:28]
Business Outlook:

[0001564590-16-016754:8k_2_02:29]
For its fourth quarter of fiscal 2016 ending June 30, 2016, the Company is targeting GAAP revenue in a range of $136.6 million to $146.6 million with non-GAAP revenue in a range of $137.0 million to $147.0 million. GAAP gross margin is targeted between 50.5% and 52.3% and non-GAAP gross margin is targeted between 53.5% and 55.0%. Operating expenses are targeted to be between $71.6 million and $73.6 million on a GAAP basis and $63.5 million to $65.5 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $4.2 million to net income of $1.0 million, or a loss of $0.04 to net income of $0.01 per share.  Non-GAAP earnings are targeted in a range of net income of $8.1 million to $13.3 million, or $0.08 to $0.12 per diluted share. The GAAP and non-GAAP net income (loss) targets are based on an estimated 105 million and 107 million average outstanding shares, respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses, litigation expenses, overhead adjustments and the purchase accounting adjustment related to deferred service revenue.

[0001564590-16-016754:8k_2_02:30]
Conference Call:

[0001564590-16-016754:8k_2_02:31]
Extreme Networks will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the third fiscal quarter results and fourth fiscal quarter 2016 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through April 27, 2017.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406   Conference ID # 87958911.

[0001564590-16-016754:8k_2_02:32]
About Extreme Networks:

[0001564590-16-016754:8k_2_02:33]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, we go to extreme measures for our 20,000-plus customers in more than 80 countries, delivering 100% insourced support to organizations large and small, including some of the world’s leading names in business, education, government, healthcare, manufacturing and hospitality. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-16-016754:8k_2_02:34]
Extreme Networks and the Extreme Networks logo, ExtremeManagement, ExtremeWireless, ExtremeControl and ExtremeAnalytics are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-16-016754:8k_2_02:35]
Non-GAAP Financial Measures:

[0001564590-16-016754:8k_2_02:36]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income (loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, litigation expenses, executive transition expenses and overhead adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-16-016754:8k_2_02:37]
Forward Looking Statements:

[0001564590-16-016754:8k_2_02:38]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-16-016754:8k_2_02:39]
EXTREME NETWORKS, INC.

[0001564590-16-016754:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-16-016754:8k_2_02:41]
(In thousands)

[0001564590-16-016754:8k_2_02:42]
(Unaudited)

[0001564590-16-016754:8k_2_02:43]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 88,334 |  |  | $ | 76,225 |  |
| Accounts receivable, net of allowances of $5,090 at March 31, 2016 and $2,396 at June 30, 2015 |  |  | 62,670 |  |  |  | 92,737 |  |
| Inventories |  |  | 52,755 |  |  |  | 58,014 |  |
| Deferred income taxes |  |  | 577 |  |  |  | 760 |  |
| Prepaid expenses and other current assets |  |  | 9,710 |  |  |  | 10,258 |  |
| Total current assets |  |  | 214,046 |  |  |  | 237,994 |  |
| Property and equipment, net |  |  | 30,439 |  |  |  | 39,862 |  |
| Intangible assets, net |  |  | 27,425 |  |  |  | 52,132 |  |
| Goodwill |  |  | 70,877 |  |  |  | 70,877 |  |
| Other assets |  |  | 26,204 |  |  |  | 27,795 |  |
| Total assets |  | $ | 368,991 |  |  | $ | 428,660 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 16,250 |  |  | $ | 11,375 |  |
| Accounts payable |  |  | 21,127 |  |  |  | 40,135 |  |
| Accrued compensation and benefits |  |  | 22,920 |  |  |  | 25,195 |  |
| Accrued warranty |  |  | 10,280 |  |  |  | 8,676 |  |
| Deferred revenue, net |  |  | 76,712 |  |  |  | 76,551 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  |  | 23,933 |  |  |  | 40,875 |  |
| Other accrued liabilities |  |  | 30,182 |  |  |  | 32,623 |  |
| Total current liabilities |  |  | 201,404 |  |  |  | 235,430 |  |
| Deferred revenue, less current portion |  |  | 22,227 |  |  |  | 23,231 |  |
| Long-term debt, less current portion |  |  | 42,500 |  |  |  | 55,500 |  |
| Deferred income taxes |  |  | 3,941 |  |  |  | 2,979 |  |
| Other long-term liabilities |  |  | 8,634 |  |  |  | 7,285 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 90,285 |  |  |  | 104,235 |  |
| Total liabilities and stockholders’ equity |  | $ | 368,991 |  |  | $ | 428,660 |  |

[0001564590-16-016754:8k_2_02:44]
EXTREME NETWORKS, INC.

[0001564590-16-016754:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-016754:8k_2_02:46]
(In thousands, except per share amounts)

[0001564590-16-016754:8k_2_02:47]
(Unaudited)

[0001564590-16-016754:8k_2_02:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 92,711 |  |  | $ | 86,527 |  |  | $ | 289,447 |  |  | $ | 301,700 |  |
| Service |  |  | 32,175 |  |  |  | 33,063 |  |  |  | 99,325 |  |  |  | 101,372 |  |
| Total net revenues |  |  | 124,886 |  |  |  | 119,590 |  |  |  | 388,772 |  |  |  | 403,072 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 50,240 |  |  |  | 49,761 |  |  |  | 154,277 |  |  |  | 164,282 |  |
| Service |  |  | 11,926 |  |  |  | 12,105 |  |  |  | 36,382 |  |  |  | 35,377 |  |
| Total cost of revenues |  |  | 62,166 |  |  |  | 61,866 |  |  |  | 190,659 |  |  |  | 199,659 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 42,471 |  |  |  | 36,766 |  |  |  | 135,170 |  |  |  | 137,418 |  |
| Service |  |  | 20,249 |  |  |  | 20,958 |  |  |  | 62,943 |  |  |  | 65,995 |  |
| Total gross profit |  |  | 62,720 |  |  |  | 57,724 |  |  |  | 198,113 |  |  |  | 203,413 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 18,852 |  |  |  | 23,858 |  |  |  | 59,836 |  |  |  | 71,205 |  |
| Sales and marketing |  |  | 38,322 |  |  |  | 39,226 |  |  |  | 111,442 |  |  |  | 127,976 |  |
| General and administrative |  |  | 8,957 |  |  |  | 9,711 |  |  |  | 27,908 |  |  |  | 31,091 |  |
| Acquisition and integration costs |  |  | - |  |  |  | 1,725 |  |  |  | 1,145 |  |  |  | 9,283 |  |
| Restructuring charge, net of reversals |  |  | 1,358 |  |  |  | - |  |  |  | 9,992 |  |  |  | - |  |
| Amortization of intangibles |  |  | 4,142 |  |  |  | 4,467 |  |  |  | 12,860 |  |  |  | 13,402 |  |
| Total operating expenses |  |  | 71,631 |  |  |  | 78,987 |  |  |  | 223,183 |  |  |  | 252,957 |  |
| Operating loss |  |  | (8,911 | ) |  |  | (21,263 | ) |  |  | (25,070 | ) |  |  | (49,544 | ) |
| Interest income |  |  | 28 |  |  |  | 129 |  |  |  | 84 |  |  |  | 471 |  |
| Interest expense |  |  | (769 | ) |  |  | (758 | ) |  |  | (2,404 | ) |  |  | (2,419 | ) |
| Other income (expense), net |  |  | (266 | ) |  |  | (535 | ) |  |  | 813 |  |  |  | (1,033 | ) |
| Loss before income taxes |  |  | (9,918 | ) |  |  | (22,427 | ) |  |  | (26,577 | ) |  |  | (52,525 | ) |
| Provision for income taxes |  |  | 866 |  |  |  | 1,121 |  |  |  | 2,967 |  |  |  | 3,458 |  |
| Net loss |  | $ | (10,784 | ) |  | $ | (23,548 | ) |  | $ | (29,544 | ) |  | $ | (55,983 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.10 | ) |  | $ | (0.24 | ) |  | $ | (0.29 | ) |  | $ | (0.57 | ) |
| Net loss per share - diluted |  | $ | (0.10 | ) |  | $ | (0.24 | ) |  | $ | (0.29 | ) |  | $ | (0.57 | ) |
| Shares used in per share calculation - basic |  |  | 104,104 |  |  |  | 99,783 |  |  |  | 102,486 |  |  |  | 98,591 |  |
| Shares used in per share calculation - diluted |  |  | 104,104 |  |  |  | 99,783 |  |  |  | 102,486 |  |  |  | 98,591 |  |

[0001564590-16-016754:8k_2_02:49]
EXTREME NETWORKS, INC.

[0001564590-16-016754:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-16-016754:8k_2_02:51]
(In thousands)

[0001564590-16-016754:8k_2_02:52]
(Unaudited)

[0001564590-16-016754:8k_2_02:53]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Net cash provided by operating activities |  | $ | 18,913 |  |  | $ | 33,564 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (2,797 | ) |  |  | (5,610 | ) |
| Purchases of non-marketable equity investments |  |  | - |  |  |  | (3,000 | ) |
| Proceeds from maturities of investments and marketable securities |  |  | - |  |  |  | 21,815 |  |
| Proceeds from sales of investments and marketable securities |  |  | - |  |  |  | 9,051 |  |
| Purchases of intangible assets |  |  | - |  |  |  | (569 | ) |
| Net cash (used in) provided by investing activities |  |  | (2,797 | ) |  |  | 21,687 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | 15,000 |  |  |  | 24,000 |  |
| Repayment of debt |  |  | (23,125 | ) |  |  | (77,062 | ) |
| Proceeds from issuance of common stock |  |  | 4,460 |  |  |  | 2,455 |  |
| Net cash used in financing activities |  |  | (3,665 | ) |  |  | (50,607 | ) |
| Foreign currency effect on cash |  |  | (342 | ) |  |  | (3,767 | ) |
| Net increase in cash and cash equivalents |  |  | 12,109 |  |  |  | 877 |  |
| Cash and cash equivalents at beginning of period |  |  | 76,225 |  |  |  | 73,190 |  |
| Cash and cash equivalents at end of period |  | $ | 88,334 |  |  | $ | 74,067 |  |

[0001564590-16-016754:8k_2_02:54]
Extreme Networks, Inc.

[0001564590-16-016754:8k_2_02:55]
Non-GAAP Measures of Financial Performance

[0001564590-16-016754:8k_2_02:56]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-16-016754:8k_2_02:57]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring expenses, litigation expenses, executive transition and overhead adjustments.

[0001564590-16-016754:8k_2_02:58]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-16-016754:8k_2_02:59]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-16-016754:8k_2_02:60]
For its internal planning process, and as discussed further below, Extreme Networks' management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, restructuring expenses, litigation expenses, executive transition expenses and overhead adjustments.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-16-016754:8k_2_02:61]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-16-016754:8k_2_02:62]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-16-016754:8k_2_02:63]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-16-016754:8k_2_02:64]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-16-016754:8k_2_02:65]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-16-016754:8k_2_02:66]
Restructuring expenses. Restructuring expenses primarily consist of accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur

[0001564590-16-016754:8k_2_02:67]
outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001564590-16-016754:8k_2_02:68]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matter as a result of a securities laws class action lawsuit.

[0001564590-16-016754:8k_2_02:69]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits.  The expenses are incurred through execution of pre-established employment contracts with senior executives.  The severance and termination benefits are cash transactions, while the share-based compensation are non-cash expenses the Company does not believe these expenses are reflective of ongoing cash requirements related to its operating results.

[0001564590-16-016754:8k_2_02:70]
Overhead adjustments. Overhead adjustment relate to service inventory overhead capitalization, this was a one-time event and was non-cash in nature.

[0001564590-16-016754:8k_2_02:71]
In addition to the non-GAAP measures discussed above, Extreme Networks uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-16-016754:8k_2_02:72]
EXTREME NETWORKS, INC.

[0001564590-16-016754:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-016754:8k_2_02:74]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-16-016754:8k_2_02:75]
(In thousands, except per share amounts)

[0001564590-16-016754:8k_2_02:76]
(Unaudited)

[0001564590-16-016754:8k_2_02:77]
| Non-GAAP Revenue | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Revenue - GAAP Basis | $ | 124,886 |  |  | $ | 119,590 |  |  | $ | 388,772 |  |  | $ | 403,072 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | 377 |  |  |  | 766 |  |  |  | 1,131 |  |  |  | 2,299 |  |
| Revenue - Non-GAAP Basis | $ | 125,263 |  |  | $ | 120,356 |  |  | $ | 389,903 |  |  | $ | 405,371 |  |

[0001564590-16-016754:8k_2_02:78]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Gross profit - GAAP Basis | $ | 62,720 |  |  | $ | 57,724 |  |  | $ | 198,113 |  |  | $ | 203,413 |  |
| Gross margin - GAAP Basis percentage |  | 50.2 | % |  |  | 48.3 | % |  |  | 51.0 | % |  |  | 50.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 428 |  |  |  | 519 |  |  |  | 1,644 |  |  |  | 1,639 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 1,131 |  |  |  | 2,299 |  |
| Amortization of intangibles |  | 3,417 |  |  |  | 4,292 |  |  |  | 11,416 |  |  |  | 12,875 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Gross profit - Non-GAAP Basis | $ | 66,942 |  |  | $ | 63,301 |  |  | $ | 210,811 |  |  | $ | 220,226 |  |
| Gross margin - Non-GAAP Basis percentage |  | 53.4 | % |  |  | 52.6 | % |  |  | 54.1 | % |  |  | 54.3 | % |

[0001564590-16-016754:8k_2_02:79]
| Non-GAAP Operating Income (Loss) | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| GAAP operating loss | $ | (8,911 | ) |  | $ | (21,263 | ) |  | $ | (25,070 | ) |  | $ | (49,544 | ) |
| GAAP operating loss percentage |  | (7.1 | )% |  |  | (17.8 | )% |  |  | (6.4 | )% |  |  | (12.3 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,503 |  |  |  | 4,372 |  |  |  | 12,120 |  |  |  | 13,935 |  |
| Acquisition and integration costs |  | - |  |  |  | 1,725 |  |  |  | 1,145 |  |  |  | 9,283 |  |
| Restructuring charge, net of reversal |  | 1,358 |  |  |  | - |  |  |  | 9,992 |  |  |  | - |  |
| Amortization of intangibles |  | 7,559 |  |  |  | 8,759 |  |  |  | 24,276 |  |  |  | 26,277 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 1,131 |  |  |  | 2,299 |  |
| Executive transition costs |  | 1,395 |  |  |  | - |  |  |  | 1,395 |  |  |  | - |  |
| Litigation |  | 85 |  |  |  | - |  |  |  | 164 |  |  |  | - |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Total adjustments to GAAP operating loss | $ | 14,277 |  |  | $ | 15,622 |  |  | $ | 48,730 |  |  | $ | 51,794 |  |
| Non-GAAP operating income (loss) | $ | 5,366 |  |  | $ | (5,641 | ) |  | $ | 23,660 |  |  | $ | 2,250 |  |
| Non-GAAP operating income (loss) percentage |  | 4.3 | % |  |  | (4.7 | )% |  |  | 6.1 | % |  |  | 0.6 | % |

[0001564590-16-016754:8k_2_02:80]
| Non-GAAP Net Income (Loss) | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| GAAP net loss | $ | (10,784 | ) |  | $ | (23,548 | ) |  | $ | (29,544 | ) |  | $ | (55,983 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,503 |  |  |  | 4,372 |  |  |  | 12,120 |  |  |  | 13,935 |  |
| Acquisition and integration costs |  | - |  |  |  | 1,725 |  |  |  | 1,145 |  |  |  | 9,283 |  |
| Restructuring charge, net of reversal |  | 1,358 |  |  |  | - |  |  |  | 9,992 |  |  |  | - |  |
| Amortization of intangibles |  | 7,559 |  |  |  | 8,759 |  |  |  | 24,276 |  |  |  | 26,277 |  |
| Purchase accounting adjustments |  | 377 |  |  |  | 766 |  |  |  | 1,131 |  |  |  | 2,299 |  |
| Executive transition costs |  | 1,395 |  |  |  | - |  |  |  | 1,395 |  |  |  | - |  |
| Litigation |  | 85 |  |  |  | - |  |  |  | 164 |  |  |  | - |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | (1,493 | ) |  |  | - |  |
| Total adjustments to GAAP net loss | $ | 14,277 |  |  | $ | 15,622 |  |  | $ | 48,730 |  |  | $ | 51,794 |  |
| Non-GAAP net income (loss) | $ | 3,493 |  |  | $ | (7,926 | ) |  | $ | 19,186 |  |  | $ | (4,189 | ) |
| Earnings (loss) per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income (loss) per share | $ | 0.03 |  |  | $ | (0.08 | ) |  | $ | 0.18 |  |  | $ | (0.04 | ) |
| Shares used in diluted net income (loss) per share calculation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 105,955 |  |  |  | 99,783 |  |  |  | 104,650 |  |  |  | 98,591 |  |

[0001564590-16-016754:8k_2_02:81]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2016 |  |  | March 31, 2015 |  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Cash flow provided by / (used in) operations | $ | 4,946 |  |  | $ | (7,889 | ) |  | $ | 18,913 |  |  | $ | 33,564 |  |
| Add: PP&E CapEx spending |  | (1,388 | ) |  | $ | (1,648 | ) |  |  | (2,797 | ) |  |  | (5,610 | ) |
| Total free cash flow | $ | 3,558 |  |  | $ | (9,537 | ) |  | $ | 16,116 |  |  | $ | 27,954 |  |
