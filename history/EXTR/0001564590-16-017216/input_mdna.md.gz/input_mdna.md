# EXTR MD&A — 0001564590-16-017216


## mdna

[0001564590-16-017216:mdna:1]
[same as prior period, unchanged from 0001564590-16-012196:mdna:1]

[0001564590-16-017216:mdna:2]
[same as prior period, unchanged from 0001564590-16-012196:mdna:2]

[0001564590-16-017216:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended March 31, 2016.

[0001564590-16-017216:mdna:4]
[same as prior period, unchanged from 0001564590-16-012196:mdna:4]

[0001564590-16-017216:mdna:5]
[same as prior period, unchanged from 0001564590-16-012196:mdna:5]

[0001564590-16-017216:mdna:6]
[same as prior period, unchanged from 0001564590-16-012196:mdna:6]

[0001564590-16-017216:mdna:7]
[same as prior period, unchanged from 0001564590-16-012196:mdna:7]

[0001564590-16-017216:mdna:8]
[same as prior period, unchanged from 0001564590-16-012196:mdna:8]

[0001564590-16-017216:mdna:9]
[same as prior period, unchanged from 0001564590-16-012196:mdna:9]

[0001564590-16-017216:mdna:10]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan. Sales in APAC and some European countries have continued to be impacted as a result of the soft global economy. We believe that conservative purchasing patterns and delays or cancellation of IT infrastructure plans in the face of continued uncertainty regarding the global economy, may continue to negatively impact overall demand for networking solutions, including Ethernet equipment. Additionally, the continuation of the strong U.S. Dollar compared to most other currency, particularly on a year over year basis, has contributed to the conservative purchasing trends in many international locations.

[0001564590-16-017216:mdna:11]
[same as prior period, unchanged from 0001564590-16-012196:mdna:11]

[0001564590-16-017216:mdna:12]
[same as prior period, unchanged from 0001564590-16-012196:mdna:12]

[0001564590-16-017216:mdna:13]
[same as prior period, unchanged from 0001564590-16-012196:mdna:13]

[0001564590-16-017216:mdna:14]
[same as prior period, unchanged from 0001564590-16-012196:mdna:14]

[0001564590-16-017216:mdna:15]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but are not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology. New software and hardware introductions during fiscal 2015 included a Summit X770 switch supporting industry’s highest density performing top of rack switching, Purview - a network-powered application analytics and optimization solution, identiFi 38xx WiFi Access Points supporting 802.11ac, SDN 2.0 - an open, standards-based (based on OpenDaylight) and comprehensive SDN solution, 100GbE support for the BDX8 and NetSight 6.0 a consolidated management across the expanded portfolio. ​

[0001564590-16-017216:mdna:16]
[same as prior period, unchanged from 0001564590-16-012196:mdna:16]

[0001564590-16-017216:mdna:17]
[same as prior period, unchanged from 0001564590-16-012196:mdna:17]

[0001564590-16-017216:mdna:18]
[same as prior period, unchanged from 0001564590-16-012196:mdna:18]

[0001564590-16-017216:mdna:19]
During the third quarter of fiscal 2016, we achieved the following results:

[0001564590-16-017216:mdna:20]
|  | · | Net revenues of $124.9 million compared to $119.6 million in the third quarter of fiscal 2015. |

[0001564590-16-017216:mdna:21]
|  | · | Product revenues of $92.7 million compared to $86.5 million in the third quarter of fiscal 2015. |

[0001564590-16-017216:mdna:22]
|  | · | Service revenues of $32.2 million compared to $33.1 million in the third quarter of fiscal 2015. |

[0001564590-16-017216:mdna:23]
|  | · | Total gross margin of 50% of net revenues compared to 48% of net revenues in the third quarter of fiscal 2015. |

[0001564590-16-017216:mdna:24]
|  | · | Operating loss of $8.9 million compared to an operating loss of $21.3 million in the third quarter of fiscal 2015. |

[0001564590-16-017216:mdna:25]
|  | · | Net loss of $10.8 million compared to a net loss of $23.5 million in the third quarter of fiscal 2015. |

[0001564590-16-017216:mdna:26]
|  | · | Cash flow provided by operating activities of $18.9 million in the nine months ended March 31, 2016 compared to cash flow provided by operating activities of $33.6 million in the nine months ended March 31, 2015. |

[0001564590-16-017216:mdna:27]
|  | · | Cash and cash equivalents of $88.3 million as of March 31, 2016 compared to $76.2 million as of June 30, 2015. |

[0001564590-16-017216:mdna:28]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan.

[0001564590-16-017216:mdna:29]
The following table presents the total net revenue geographically for the three and nine months ended March 31, 2016 and 2015 (dollars in thousands):

[0001564590-16-017216:mdna:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Net Revenues |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 58,205 |  |  | $ | 49,353 |  |  | $ | 8,852 |  |  |  | 17.9 | % |  | $ | 173,298 |  |  | $ | 166,001 |  |  | $ | 7,297 |  |  |  | 4.4 | % |
| Other |  |  | 5,398 |  |  |  | 7,073 |  |  |  | (1,675 | ) |  |  | (23.7 | )% |  |  | 18,983 |  |  |  | 26,990 |  |  |  | (8,007 | ) |  |  | (29.7 | )% |
| Total Americas |  |  | 63,603 |  |  |  | 56,426 |  |  |  | 7,177 |  |  |  | 12.7 | % |  |  | 192,281 |  |  |  | 192,991 |  |  |  | (710 | ) |  |  | (.4 | )% |
| Percentage of net revenue |  |  | 50.9 | % |  |  | 47.2 | % |  |  |  |  |  |  |  |  |  |  | 49.5 | % |  |  | 47.9 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 50,358 |  |  |  | 50,006 |  |  |  | 352 |  |  |  | 0.7 | % |  |  | 161,486 |  |  |  | 166,515 |  |  |  | (5,029 | ) |  |  | (3.0 | )% |
| Percentage of net revenue |  |  | 40.3 | % |  |  | 41.8 | % |  |  |  |  |  |  |  |  |  |  | 41.5 | % |  |  | 41.3 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 10,925 |  |  |  | 13,158 |  |  |  | (2,233 | ) |  |  | (17.0 | )% |  |  | 35,005 |  |  |  | 43,566 |  |  |  | (8,561 | ) |  |  | (19.7 | )% |
| Percentage of net revenue |  |  | 8.7 | % |  |  | 11.0 | % |  |  |  |  |  |  |  |  |  |  | 9.0 | % |  |  | 10.8 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 124,886 |  |  | $ | 119,590 |  |  | $ | 5,296 |  |  |  | 4.4 | % |  | $ | 388,772 |  |  | $ | 403,072 |  |  | $ | (14,300 | ) |  |  | (3.5 | )% |

[0001564590-16-017216:mdna:31]
[same as prior period, unchanged from 0001564590-16-012196:mdna:31]

[0001564590-16-017216:mdna:32]
The following table presents net product and service revenue for the three and nine months ended March 31, 2016 and 2015 (dollars in thousands):

[0001564590-16-017216:mdna:33]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 92,711 |  |  | $ | 86,527 |  |  | $ | 6,184 |  |  |  | 7.1 | % |  | $ | 289,447 |  |  | $ | 301,700 |  |  | $ | (12,253 | ) |  |  | (4.1 | )% |
| Percentage of net revenue |  |  | 74.2 | % |  |  | 72.4 | % |  |  |  |  |  |  |  |  |  |  | 74.5 | % |  |  | 74.9 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 32,175 |  |  |  | 33,063 |  |  |  | (888 | ) |  |  | (2.7 | )% |  |  | 99,325 |  |  |  | 101,372 |  |  |  | (2,047 | ) |  |  | (2.0 | )% |
| Percentage of net revenue |  |  | 25.8 | % |  |  | 27.6 | % |  |  |  |  |  |  |  |  |  |  | 25.5 | % |  |  | 25.1 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 124,886 |  |  | $ | 119,590 |  |  | $ | 5,296 |  |  |  | 4.4 | % |  | $ | 388,772 |  |  | $ | 403,072 |  |  | $ | (14,300 | ) |  |  | (3.5 | )% |

[0001564590-16-017216:mdna:34]
Product revenues increased by $6.2 million or 7.1% for the three month period ended March 31, 2016 as compared to the corresponding period of fiscal 2015.  The increase in product revenues during the quarter reflects our strong performance in the United States, especially in the education market, as compared to the third quarter of fiscal 2015.  However we continue to experience declines in international sales due to increased price competition and the continuing strong U.S. Dollar.

[0001564590-16-017216:mdna:35]
Product revenues decreased $12.3 million or 4.1% for the nine month period ended March 31, 2016 as compared to the corresponding period of fiscal 2015.  The decrease in product revenues during the first nine months was due to the continuing strong U.S. Dollar and increased price competition.

[0001564590-16-017216:mdna:36]
Service revenues decreased $0.9 million or 2.7% in the third quarter of fiscal 2016, compared to the corresponding period of fiscal 2015.  Service revenues declined $1.3 million due to lower maintenance revenues partially offset by lower purchase accounting charges related to deferred service revenues of $0.4 million in third quarter of fiscal 2016 as compared to $0.8 million in the third quarter of fiscal 2015.

[0001564590-16-017216:mdna:37]
Service revenues decreased $2.0 million or 2.0% in the nine months ended March 31, 2016, compared to the corresponding period of fiscal 2015.  Service revenues declined $3.2 million due to lower maintenance revenues partially offset by lower purchase accounting charges related to deferred service revenues of $1.1 million in the first three quarters of fiscal 2016 as compared to $2.3 million in the first three quarters of fiscal 2015.

[0001564590-16-017216:mdna:38]
The following table presents the product and service revenue gross profit and the respective gross profit percentages for the three and nine months ended March 31, 2016 and 2015 (dollars in thousands):

[0001564590-16-017216:mdna:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 42,471 |  |  | $ | 36,766 |  |  | $ | 5,705 |  |  |  | 15.5 | % |  | $ | 135,170 |  |  | $ | 137,418 |  |  | $ | (2,248 | ) |  |  | (1.6 | )% |
| Percentage of product revenue |  |  | 45.8 | % |  |  | 42.5 | % |  |  |  |  |  |  |  |  |  |  | 46.7 | % |  |  | 45.5 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 20,249 |  |  |  | 20,958 |  |  |  | (709 | ) |  |  | (3.4 | )% |  |  | 62,943 |  |  |  | 65,995 |  |  |  | (3,052 | ) |  |  | (4.6 | )% |
| Percentage of service revenue |  |  | 62.9 | % |  |  | 63.4 | % |  |  |  |  |  |  |  |  |  |  | 63.4 | % |  |  | 65.1 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 62,720 |  |  | $ | 57,724 |  |  | $ | 4,996 |  |  |  | 8.7 | % |  | $ | 198,113 |  |  | $ | 203,413 |  |  | $ | (5,300 | ) |  |  | (2.6 | )% |
| Percentage of net revenue |  |  | 50.2 | % |  |  | 48.3 | % |  |  |  |  |  |  |  |  |  |  | 51.0 | % |  |  | 50.5 | % |  |  |  |  |  |  |  |  |

[0001564590-16-017216:mdna:40]
Product gross profit increased $5.7 million or 15.5% in the third quarter of fiscal 2016 as compared to the corresponding period in fiscal 2015. Gross profit was impacted during the third quarter of fiscal 2016 by an increase in product revenue of $6.2 million, lower excess inventory and scrap charges of $1.9 million, lower distribution charges of $1.0 million and lower amortization of intangibles of $0.6 million as compared to the corresponding period of fiscal 2015.  This was partially offset with higher overhead charges of $0.7 million.

[0001564590-16-017216:mdna:41]
Product gross profit decreased $2.2 million or 1.6% in the nine months ended March 31, 2016 as compared to the corresponding period in fiscal 2015. Gross profit was impacted during the first three quarters of fiscal 2016 by a decrease in product revenue of $12.3 million, higher warranty charges of $1.4 million and higher overhead costs of $1.2 million as compared to the corresponding period of fiscal 2015.  This was offset with lower amortization of intangibles of $2.4 million and royalty expense of $1.5 million on older products which have been discontinued.

[0001564590-16-017216:mdna:42]
Service gross profit decreased $0.7 million or 3.4% to $20.2 million in the third quarter of fiscal 2016 from $21.0 million in the third quarter of fiscal 2015.  The decrease was primarily due to lower service revenues of $0.9 million as compared to the third quarter of fiscal 2015.

[0001564590-16-017216:mdna:43]
Service gross profit decreased $3.1 million or 4.6% to $62.9 million for the nine months ended March 31, 2016 from $66.0 million.  The decrease was due to lower service revenues of $2.0 million, higher material costs to service maintenance contracts of $0.6 million and excess inventory charges of $0.4 million for the first nine months of fiscal 2016.

[0001564590-16-017216:mdna:44]
[same as prior period, unchanged from 0001564590-16-012196:mdna:43]

[0001564590-16-017216:mdna:45]
[same as prior period, unchanged from 0001564590-16-012196:mdna:44]

[0001564590-16-017216:mdna:46]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |  | March 31, 2016 |  |  | March 31, 2015 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 18,852 |  |  | $ | 23,858 |  |  | $ | (5,006 | ) |  |  | (21.0 | )% |  | $ | 59,836 |  |  | $ | 71,205 |  |  | $ | (11,369 | ) |  |  | (16.0 | )% |
| Sales and marketing |  |  | 38,322 |  |  |  | 39,226 |  |  |  | (904 | ) |  |  | (2.3 | )% |  |  | 111,442 |  |  |  | 127,976 |  |  |  | (16,534 | ) |  |  | (12.9 | )% |
| General and administrative |  |  | 8,957 |  |  |  | 9,711 |  |  |  | (754 | ) |  |  | (7.8 | )% |  |  | 27,908 |  |  |  | 31,091 |  |  |  | (3,183 | ) |  |  | (10.2 | )% |
| Acquisition and integration costs |  |  | - |  |  |  | 1,725 |  |  |  | (1,725 | ) |  |  | (100.0 | )% |  |  | 1,145 |  |  |  | 9,283 |  |  |  | (8,138 | ) |  |  | (87.7 | )% |
| Restructuring charge, net of reversals |  |  | 1,358 |  |  |  | - |  |  |  | 1,358 |  |  |  | 100.0 | % |  |  | 9,992 |  |  |  | - |  |  |  | 9,992 |  |  |  | 100.0 | % |
| Amortization of intangibles |  |  | 4,142 |  |  |  | 4,467 |  |  |  | (325 | ) |  |  | (7.3 | )% |  |  | 12,860 |  |  |  | 13,402 |  |  |  | (542 | ) |  |  | (4.0 | )% |
| Total operating expenses |  | $ | 71,631 |  |  | $ | 78,987 |  |  | $ | (7,356 | ) |  |  | (9.3 | )% |  | $ | 223,183 |  |  | $ | 252,957 |  |  | $ | (29,774 | ) |  |  | (11.8 | )% |
| Operating loss |  | $ | (8,911 | ) |  | $ | (21,263 | ) |  | $ | 12,352 |  |  |  | 58.1 | % |  | $ | (25,070 | ) |  | $ | (49,544 | ) |  | $ | 24,474 |  |  |  | 49.4 | % |

[0001564590-16-017216:mdna:47]
[same as prior period, unchanged from 0001564590-16-012196:mdna:46]

[0001564590-16-017216:mdna:48]
[same as prior period, unchanged from 0001564590-16-012196:mdna:47]

[0001564590-16-017216:mdna:49]
Research and development expenses decreased by $5.0 million, or 21.0% for the three months ended March 31, 2016 as compared to the corresponding period of fiscal 2015. The decrease in research and development expenses was due to lower personnel costs of $4.4 million primarily driven by the reduction-in-force (“RIF”) during the fourth quarter of fiscal 2015 and lower professional fees and IT costs of $0.3 million.  This was partially offset with higher engineering project spending of $0.3 million

[0001564590-16-017216:mdna:50]
Research and development expenses decreased by $11.4 million, or 16.0% for the nine months ended March 31, 2016 as compared to the corresponding period of fiscal 2015. The decrease in research and development expenses was due to lower personnel costs of $11.9 million primarily driven by the RIF during the fourth quarter of fiscal 2015, reduced software tools and maintenance of $1.3 million and lower depreciation of $0.9 million. This was partially offset with higher engineering project spending of $1.3 million and recruiting of $0.2 million.

[0001564590-16-017216:mdna:51]
[same as prior period, unchanged from 0001564590-16-012196:mdna:50]

[0001564590-16-017216:mdna:52]
[same as prior period, unchanged from 0001564590-16-012196:mdna:51]

[0001564590-16-017216:mdna:53]
Sales and marketing expenses decreased by $0.9 million or 2.3% for the three months ended March 31, 2016 as compared to the corresponding period of fiscal 2015. The decrease in sales and marketing expenses was primarily due to lower personnel costs (which includes benefits and stock based compensation) of $1.4 million, facility expense of $0.6 million as a result of the RIF during the fourth quarter of fiscal 2015, as well as lower professional fees of $0.4 million.   This was partially offset with higher marketing costs of $0.3 million and supplies of $0.2 million.

[0001564590-16-017216:mdna:54]
Sales and marketing expenses decreased by $16.5 million or 12.9% for the nine months ended March 31, 2016 as compared to the corresponding period of fiscal 2015. The decrease in sales and marketing expenses was primarily due to lower personnel costs of $11.7 million, travel and entertainment related expenses of $2.7 million and facilities expense of $2.1 million as a result of the RIF during the fourth quarter of fiscal 2015.  This was partially offset with higher marketing costs of $0.5 million.

[0001564590-16-017216:mdna:55]
[same as prior period, unchanged from 0001564590-16-012196:mdna:54]

[0001564590-16-017216:mdna:56]
[same as prior period, unchanged from 0001564590-16-012196:mdna:55]

[0001564590-16-017216:mdna:57]
General and administrative expenses decreased by $0.8 million or 7.8% for the three months ended March 31, 2016 as compared to the corresponding period of fiscal 2015.  The decrease in general and administrative expenses was due to reduced professional fees and lower personnel costs of $0.4 million as a result of the RIF during the fourth quarter of fiscal 2015.

[0001564590-16-017216:mdna:58]
General and administrative expenses decreased by $3.2 million or 10.3% for the nine months ended March 31, 2016 as compared to the corresponding period of fiscal 2015. The decrease in general and administrative expenses was due primarily to lower professional fees of $2.0 million, reduced recruiting costs of $0.4 million and bad debt expense of $0.2 million.

[0001564590-16-017216:mdna:59]
[same as prior period, unchanged from 0001564590-16-012196:mdna:58]

[0001564590-16-017216:mdna:60]
[same as prior period, unchanged from 0001564590-16-012196:mdna:59]

[0001564590-16-017216:mdna:61]
During the three months ended March 31, 2016 and 2015, we recorded zero and $1.7 million, respectively of integration costs primarily for IT and sales integration costs.

[0001564590-16-017216:mdna:62]
During the nine months ended March 31, 2016 and 2015, we recorded $1.1 million and $9.3 million, respectively of integration costs primarily for IT, warehouse, and sales integration and severance costs.

[0001564590-16-017216:mdna:63]
[same as prior period, unchanged from 0001564590-16-012196:mdna:62]

[0001564590-16-017216:mdna:64]
During the three and nine months ended March 31, 2016, we recorded $1.4 million and $10.0 million in restructuring charges, respectively, primarily for excess facilities, net of future sub-lease income. There were no restructuring charges during the corresponding period in fiscal 2015. During the first three quarters of fiscal 2016, we continued our initiative begun in the fourth quarter of fiscal 2015 to realign our operations by abandoning excess facilities, primarily in San Jose California; Salem, New Hampshire; Research Triangle Park, North Carolina and Shannon, Ireland. The abandoned facilities represented approximately 29% of our original total space, and included general office and warehouse space. There may be additional activities in abandonments of excess facilities in future periods as we further align our organization to our business and operational needs.

[0001564590-16-017216:mdna:65]
During the third quarter of fiscal 2016, in conjunction with the exiting of the facilities noted above, we incurred $1.4 million in charges related to our restructuring activities.  Excess facilities charges included the acceleration of depreciation of leasehold

[0001564590-16-017216:mdna:66]
improvements in our facility in North Carolina of $1.2 million, adjustment to the estimated future sublease income to be derived from the San Jose California facility of $0.3 million and reversal of severance benefits of $0.2 million.

[0001564590-16-017216:mdna:67]
During the nine months ended March 31, 2016, in conjunction with the exiting of the facilities noted above, we incurred $10.0 of restructuring charges. Excess facilities charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and contract termination charges of $4.4 million, acceleration of depreciation of leasehold improvements of $4.5 million, professional fees of $1.0 million and other of $0.1 million.

[0001564590-16-017216:mdna:68]
[same as prior period, unchanged from 0001564590-16-012196:mdna:66]

[0001564590-16-017216:mdna:69]
During the three months ended March 31, 2016 and 2015, we recorded $4.1 million and $4.5 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.

[0001564590-16-017216:mdna:70]
During the nine months ended March 31, 2016 and 2015, we recorded $12.9 million and $13.4 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.

[0001564590-16-017216:mdna:71]
[same as prior period, unchanged from 0001564590-16-012196:mdna:69]

[0001564590-16-017216:mdna:72]
During the three months ended March 31, 2016 and 2015 we recorded $0.8 million and $0.8 million, respectively, in interest expense. During the nine months ended March 31, 2016 and 2015 we recorded $2.4 million and $2.4 million, respectively, in interest expense.

[0001564590-16-017216:mdna:73]
[same as prior period, unchanged from 0001564590-16-012196:mdna:71]

[0001564590-16-017216:mdna:74]
During the three months ended March 31, 2016 and 2015 we recorded $0.3 million and $0.5 million of losses, respectively, in other income (expense), net. The improvement was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-16-017216:mdna:75]
During the nine months ended March 31, 2016 and 2015 we recorded $0.8 million of gains and $1.0 million of losses, respectively, in other income (expense), net. The improvement was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-16-017216:mdna:76]
[same as prior period, unchanged from 0001564590-16-012196:mdna:74]

[0001564590-16-017216:mdna:77]
For the three months ended March 31, 2016 and 2015, we recorded an income tax provision of $0.9 million and $1.1 million, respectively.  For the nine months ended March 31, 2016 and 2015, we recorded an income tax provision of $3.0 million and $3.5 million, respectively.

[0001564590-16-017216:mdna:78]
The income tax provisions for the three and nine months ended March 31, 2016 and 2015, consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.

[0001564590-16-017216:mdna:79]
[same as prior period, unchanged from 0001564590-16-012196:mdna:77]

[0001564590-16-017216:mdna:80]
[same as prior period, unchanged from 0001564590-16-012196:mdna:78]

[0001564590-16-017216:mdna:81]
[same as prior period, unchanged from 0001564590-16-012196:mdna:79]

[0001564590-16-017216:mdna:82]
[same as prior period, unchanged from 0001564590-16-012196:mdna:80]

[0001564590-16-017216:mdna:83]
[same as prior period, unchanged from 0001564590-16-012196:mdna:81]

[0001564590-16-017216:mdna:84]
[same as prior period, unchanged from 0001564590-16-012196:mdna:82]

[0001564590-16-017216:mdna:85]
[same as prior period, unchanged from 0001564590-16-012196:mdna:83]

[0001564590-16-017216:mdna:86]
[same as prior period, unchanged from 0001564590-16-012196:mdna:84]

[0001564590-16-017216:mdna:87]
[same as prior period, unchanged from 0001564590-16-012196:mdna:85]

[0001564590-16-017216:mdna:88]
[same as prior period, unchanged from 0001564590-16-012196:mdna:86]

[0001564590-16-017216:mdna:89]
[same as prior period, unchanged from 0001564590-16-012196:mdna:87]

[0001564590-16-017216:mdna:90]
[same as prior period, unchanged from 0001564590-16-012196:mdna:88]

[0001564590-16-017216:mdna:91]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Cash and cash equivalent |  | $ | 88,334 |  |  | $ | 76,225 |  |
| Total cash and investments |  | $ | 88,334 |  |  | $ | 76,225 |  |
| Working capital |  | $ | 12,642 |  |  | $ | 2,564 |  |

[0001564590-16-017216:mdna:92]
As of March 31, 2016, our principal sources of liquidity consisted of cash and cash equivalents of $88.3 million, accounts receivable, net of $62.7 million and availability of borrowings from the Revolving Facility of $39.0 million. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment. We believe that our $88.3 million of cash and cash equivalents at March 31, 2016, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-16-017216:mdna:93]
The Senior Secured Credit Facilities, as amended, contain financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001564590-16-017216:mdna:94]
The Senior Secured Credit Facilities, as amended, also include customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended, may be accelerated upon certain events of default. At March 31, 2016, we are in compliance and expect to remain in compliance with the covenants of the Senior Secured Credit Facilities, as amended, and they are not expected to impact our liquidity or capital resources.

[0001564590-16-017216:mdna:95]
[same as prior period, unchanged from 0001564590-16-012196:mdna:93]

[0001564590-16-017216:mdna:96]
[same as prior period, unchanged from 0001564590-16-012196:mdna:94]

[0001564590-16-017216:mdna:97]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2016 |  |  | March 31, 2015 |  |
| Net cash provided by operating activities |  | $ | 18,913 |  |  | $ | 33,564 |  |
| Net cash (used in) provided by investing activities |  |  | (2,797 | ) |  |  | 21,687 |  |
| Net cash used in financing activities |  |  | (3,665 | ) |  |  | (50,607 | ) |
| Foreign currency effect on cash |  |  | (342 | ) |  |  | (3,767 | ) |
| Net increase in cash and cash equivalents |  | $ | 12,109 |  |  | $ | 877 |  |

[0001564590-16-017216:mdna:98]
[same as prior period, unchanged from 0001564590-16-012196:mdna:96]

[0001564590-16-017216:mdna:99]
Cash flows provided by operations in the nine months ended March 31, 2016 was $18.9 million and was generated from non-cash expenses of $50.9 million such as amortization of intangibles, stock-based compensation expense and depreciation. Decreases in accounts receivables due to lower revenue during the quarter combined with higher collections and decreases in inventories due to the timing of inventory receipts were partially offset by the current period's net loss of $29.5 million along with decreases in accounts payable, accrued compensation and deferred revenues.

[0001564590-16-017216:mdna:100]
Cash flows provided by operations was $33.6 million in the nine months ending March 31, 2015. Current period's net loss was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation. Accounts receivables decreased primarily due to lower sales during the current quarter and to our higher collections efforts. Inventories increased primarily due to the reduced sales during the third quarter. Accounts payable increased due to timing of payments. The increases in cash inflows were offset by decreases in accrued compensation due to lower commissions and bonus accruals.

[0001564590-16-017216:mdna:101]
[same as prior period, unchanged from 0001564590-16-012196:mdna:99]

[0001564590-16-017216:mdna:102]
Cash flows used in investing activities in the nine months ended March 31, 2016 was $2.8 million and was consisted of purchases of property and equipment.

[0001564590-16-017216:mdna:103]
Cash flow provided by investing activities was $21.7 million, in the nine months ending March 31, 2015, primarily consisted of proceeds from the sale and maturities of investments of $9.1 million and $21.8 million of investments, respectively, offset by $5.6 million used to purchase property and equipment and $3.0 million used to acquire a non-marketable equity interest.

[0001564590-16-017216:mdna:104]
[same as prior period, unchanged from 0001564590-16-012196:mdna:102]

[0001564590-16-017216:mdna:105]
Cash flows used in financing activities in the nine months ended March 31, 2016 was $3.7 million which was consisted of $4.5 million proceeds from the issuance of shares of our common stock under the ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by a net repayment of debt of $8.1 million.

[0001564590-16-017216:mdna:106]
Cash flow used in financing activities was $50.6 million in the nine months ending March 31, 2015, consisting of $77.1 million of cash used for repayment of debt offset by a draw on the Revolving Facility of $24 million during the nine months ended March 31, 2015, for working capital requirements, $2.5 million proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001564590-16-017216:mdna:107]
[same as prior period, unchanged from 0001564590-16-012196:mdna:105]

[0001564590-16-017216:mdna:108]
Foreign currency effect on cash increased in the nine months ended March 31, 2016, primarily due to changes in foreign currency exchange rates between US Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-16-017216:mdna:109]
[same as prior period, unchanged from 0001564590-16-012196:mdna:107]

[0001564590-16-017216:mdna:110]
The following summarizes our contractual obligations at nine months ended March 31, 2016, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-16-017216:mdna:111]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 58,750 |  |  | $ | 16,250 |  |  | $ | 42,500 |  |  | $ | — |  |  | $ | — |  |
| Interest on debt obligations |  |  | 3,917 |  |  |  | 2,102 |  |  |  | 1,815 |  |  |  | — |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 68,459 |  |  |  | 68,459 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 58,534 |  |  |  | 10,275 |  |  |  | 17,605 |  |  |  | 10,167 |  |  |  | 20,487 |  |
| Other liabilities |  |  | 4,286 |  |  |  | 3,977 |  |  |  | 309 |  |  |  | — |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 193,946 |  |  | $ | 101,063 |  |  | $ | 62,229 |  |  | $ | 10,167 |  |  | $ | 20,487 |  |

[0001564590-16-017216:mdna:112]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $$68.5 million as of   March 31, 2016. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-16-017216:mdna:113]
[same as prior period, unchanged from 0001564590-16-012196:mdna:111]

[0001564590-16-017216:mdna:114]
Other liabilities include our commitments towards debt related fees and specific arrangements other than inventory.

[0001564590-16-017216:mdna:115]
[same as prior period, unchanged from 0001564590-16-012196:mdna:113]

[0001564590-16-017216:mdna:116]
We did not have any material commitments for capital expenditures as of March 31, 2016.

[0001564590-16-017216:mdna:117]
[same as prior period, unchanged from 0001564590-16-012196:mdna:115]

[0001564590-16-017216:mdna:118]
We did not have any off-balance sheet arrangements as of March 31, 2016.
