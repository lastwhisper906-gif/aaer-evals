# EXTR notes — 0000950170-25-109742


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-25-109742:notes:1]
Portions of the registrant's definitive proxy statement for the year ended June 30, 2025 Annual Meeting of Stockholders to be filed with the Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated herein by reference in Part III of this Annual Report on Form 10-K.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000950170-25-109742:notes:2]
Item 1C. Cybersecurity

[0000950170-25-109742:notes:3]
Cybersecurity Risk Management and Strategy

[0000950170-25-109742:notes:4]
We have developed and implemented a cybersecurity risk management program intended to protect the confidentiality, integrity, and availability of our critical systems and information.

[0000950170-25-109742:notes:5]
We design and assess our program based on the National Institute of Standards and Technology Cybersecurity Framework (“NIST CSF”). This does not imply that we meet any particular technical standards, specifications, or requirements, only that we use the NIST CSF as a guide to help us identify, assess, and manage cybersecurity risks relevant to our business.

[0000950170-25-109742:notes:6]
Our cybersecurity risk management program is integrated into our overall enterprise risk management program, and shares common methodologies, reporting channels and governance processes that apply across the enterprise risk management program to other legal, compliance, strategic, operational, and financial risk areas.

[0000950170-25-109742:notes:7]
Key elements of our cybersecurity risk management program, include, but are not limited to the following:

[0000950170-25-109742:notes:8]
•
risk assessments designed to help identify material cybersecurity risks to our critical systems, information, products, services, and our broader enterprise IT environment;

[0000950170-25-109742:notes:9]
•
a security team principally responsible for managing (1) our cybersecurity risk assessment processes, (2) our security controls, and (3) our response to cybersecurity incidents;

[0000950170-25-109742:notes:10]
•
the use of external service providers, where appropriate, to assess, test or otherwise assist with aspects of our security controls;

[0000950170-25-109742:notes:11]
•
cybersecurity awareness training of our employees;

[0000950170-25-109742:notes:12]
•
a cybersecurity incident response plan that includes procedures for responding to cybersecurity incidents; and

[0000950170-25-109742:notes:13]
•
a third-party risk management process for key service providers, suppliers, and vendors based on our assessment of their criticality to our operations and respective risk profile.

[0000950170-25-109742:notes:14]
We have not identified risks from known cybersecurity threats, including as a result of any prior cybersecurity incidents, that have materially affected or are reasonably likely to materially affect us, including our operations, business strategy, results of operations, or financial condition. We face risks from cybersecurity threats that, if realized, are reasonably likely to materially affect us, including our operations, business strategy, results of operations, or financial condition. See “Risk Factors – System security risks, data breaches, and cyberattacks could compromise our proprietary information, disrupt our internal operations, impact services to customers, and harm public perception of our products, which could materially adversely affect our business, financial condition, operating results, and future growth prospects”.

[0000950170-25-109742:notes:15]
Cybersecurity Governance

[0000950170-25-109742:notes:16]
Our Board considers cybersecurity risk as part of its risk oversight function and has delegated to the Audit Committee oversight of cybersecurity and other information technology risks. The Audit Committee oversees management’s implementation of our cybersecurity risk management program.

[0000950170-25-109742:notes:17]
The Audit Committee receives regular reports from our Chief Information Security Officer (“CISO”) regarding any significant cybersecurity incidents, as well as any incidents with lesser impact potential. The Chief Information and Customer Officer (“CICO”) and CISO periodically report to the full Board regarding cybersecurity risks and our cyber risk management program. Board members periodically receive presentations on cybersecurity topics from our CICO, our CISO, or external experts as part of the Board’s continuing education on topics that impact public companies.

[0000950170-25-109742:notes:18]
Our management team, including our CICO and our CISO, is responsible for assessing and managing our material risks from cybersecurity threats. The team has primary responsibility for our overall cybersecurity risk management program and supervises both our internal cybersecurity personnel and our retained external cybersecurity consultants. Our CICO and CISO collectively have decades of IT and cybersecurity experience in technology companies, including significant experience in senior-level leadership roles. Additionally, our CISO holds Certified Information Security Manager and Certified in Risk and Information Systems Control certifications. Our CICO and CISO are assisted by a cross-functional Information Security Steering Committee.

[0000950170-25-109742:notes:19]
Our management team takes steps to stay informed about and monitor efforts to prevent, detect, mitigate, and remediate cybersecurity risks and incidents through various means, which may include briefings from internal security personnel; threat intelligence and other information obtained from governmental, public or private sources, including external consultants engaged by us; and alerts and reports produced by security tools deployed in the IT environment.


## dei:AuditorOpinionTextBlock

[0000950170-25-109742:notes:20]
Opinion on the financial statements

[0000950170-25-109742:notes:21]
We have audited the accompanying consolidated balance sheets of Extreme Networks, Inc. (a Delaware corporation) and subsidiaries (the “Company”) as of June 30, 2025 and 2024, the related consolidated statements of operations, comprehensive income (loss), stockholders’ equity, and cash flows for each of the three years in the period ended June 30, 2025, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of June 30, 2025 and 2024, and the results of its operations and its cash flows for each of the three years in the period ended June 30, 2025, in conformity with accounting principles generally accepted in the United States of America.

[0000950170-25-109742:notes:22]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the Company’s internal control over financial reporting as of June 30, 2025, based on criteria established in the 2013 Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”), and our report dated August 18, 2025 expressed an unqualified opinion.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-25-109742:notes:23]
1. Description of Business and Basis of Presentation

[0000950170-25-109742:notes:24]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”) is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0000950170-25-109742:notes:25]
Fiscal Year

[0000950170-25-109742:notes:26]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2025” or “ 2025”; “fiscal 2024” or “2024”; “fiscal 2023” or “2023” represent the fiscal years ending, respectively.

[0000950170-25-109742:notes:27]
Principles of Consolidation

[0000950170-25-109742:notes:28]
The consolidated financial statements include the accounts of Extreme Networks, Inc. and its wholly-owned subsidiaries. All inter-company balances and transactions have been eliminated on consolidation.

[0000950170-25-109742:notes:29]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month-end exchange rates; and revenues and expenses are translated using the monthly average rate.

[0000950170-25-109742:notes:30]
Accounting Estimates

[0000950170-25-109742:notes:31]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the financial statements and the accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-25-109742:notes:32]
2. Summary of Significant Accounting Policies

[0000950170-25-109742:notes:33]
Revenue Recognition

[0000950170-25-109742:notes:34]
The Company accounts for revenue in accordance with Accounting Standards Codification (“ASC”) Topic 606, Revenue from Contracts with Customers. The Company derives revenues primarily from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0000950170-25-109742:notes:35]
See Note 3, Revenues, for further discussion.

[0000950170-25-109742:notes:36]
Cash and Cash Equivalents

[0000950170-25-109742:notes:37]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with several financial institutions. These are financial institutions with reputable credit and therefore bear minimal credit risk.  Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0000950170-25-109742:notes:38]
Allowance for Product Returns

[0000950170-25-109742:notes:39]
The Company maintains estimates for product returns based on its historical returns, analysis of credit memos and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is shown as a reduction of accounts receivable as there is a contractual right of offset and returns are applied to accounts receivable balances outstanding as of the balance sheet date. There have not been material changes to the estimated product returns for any periods presented.

[0000950170-25-109742:notes:40]
Allowance for Credit Losses

[0000950170-25-109742:notes:41]
The Company maintains an allowance for credit losses which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring certain of its customers in the Asia-Pacific region to pay cash in advance or secure letters of credit when placing an order with the Company.

[0000950170-25-109742:notes:42]
Inventories

[0000950170-25-109742:notes:43]
The Company values its inventory at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Adjustments to reduce the cost of inventory to its net realizable value are made, if required, when conditions exist that suggest that inventory is obsolete or may be in excess of anticipated demand based upon assumptions about future demand. At the point of the loss recognition, a new lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0000950170-25-109742:notes:44]
Long-Lived Assets

[0000950170-25-109742:notes:45]
Long-lived assets include (a) property and equipment, (b) operating lease right-of-use (“ROU”) assets, (c) capitalized software development costs (d) goodwill and intangible assets, and (e) other assets. Property and equipment, ROU assets, and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0000950170-25-109742:notes:46]
(a) Property and Equipment, Net

[0000950170-25-109742:notes:47]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and purchased software. Estimated useful lives of three to seven years are used for office equipment and furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms.

[0000950170-25-109742:notes:48]
(b) Leases

[0000950170-25-109742:notes:49]
The Company leases facilities, equipment and vehicles under operating leases that expire on various dates through fiscal 2033. The Company determines if an arrangement is a lease at inception. Management evaluates the classification of leases at commencement date and as necessary, at modification. In general, lease arrangements exceeding a twelve-month term, are recognized as ROU assets with associated operating lease liabilities on the consolidated balance sheets.

[0000950170-25-109742:notes:50]
ROU assets under the Company’s operating leases represent the Company’s right to use an underlying asset over the lease term. Operating lease liabilities represent the Company’s obligation to make payments arising from the lease. The ROU asset is reduced over a straight-line or other systematic basis representative of the pattern in which the Company expects to consume the ROU assets’ future economic benefits. The ROU assets are also adjusted for leasehold improvements paid by the lessor, lease incentives, and asset impairments, among other things.

[0000950170-25-109742:notes:51]
See Note 8, Leases, for further discussion.

[0000950170-25-109742:notes:52]
(c) Capitalized Software Development Costs

[0000950170-25-109742:notes:53]
Software to be Marketed, Leased, or Sold

[0000950170-25-109742:notes:54]
Capitalization of software development costs for software to be sold, leased, or otherwise marketed begins when a product's technological feasibility has been established and ends when a product is available for general release to customers. Generally, the Company's products are released soon after technological feasibility has been established. As a result, costs incurred between achieving technological feasibility and product general availability have not been significant.

[0000950170-25-109742:notes:55]
Internal-Use Software

[0000950170-25-109742:notes:56]
The Company capitalizes costs associated with internal-use software applications and systems during the application development stage. Such capitalized costs include external direct costs incurred in developing or obtaining software applications and payroll and payroll-related costs for employees, who are directly associated with the development of the application. The Company includes such internal-use software costs in the software category in property and equipment and amortizes these costs on a straight-line basis over an estimated useful life of three to seven years. The Company capitalized approximately $10.2 million in software development costs for the fiscal year ended June 30, 2025. The software development costs that the Company capitalized for the fiscal years ended June 30, 2024 and 2023 were not material.

[0000950170-25-109742:notes:57]
Cloud Computing Software Implementation Costs

[0000950170-25-109742:notes:58]
Cloud computing software implementation costs incurred in hosting arrangements are capitalized and reported as a component of prepaid expenses and other current assets, and other assets. Once available for their intended use, these costs are amortized on a straight-line basis over their respective contract service periods, including periods covered by any reasonably probable options to extend, ranging from three to seven years. The Company capitalized approximately $39.6 million cloud computing implementation costs for the fiscal years ended June 30, 2025. Capitalized cloud computing implementation costs for the fiscal year ended June 30, 2024 and 2023 were not material.

[0000950170-25-109742:notes:59]
(d) Goodwill and Intangible Assets

[0000950170-25-109742:notes:60]
Goodwill and intangible assets are generated as a result of business combinations and are comprised of, among other things, developed technology, customer relationships, trade names, and licensing agreements.

[0000950170-25-109742:notes:61]
The remaining lives of intangible assets are considered regularly along with assessments of impairment and lives are adjusted or impairment charges taken when required.

[0000950170-25-109742:notes:62]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company has one reporting unit and performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceeds directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Based on the results of the goodwill impairment analysis, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0000950170-25-109742:notes:63]
Business Combinations

[0000950170-25-109742:notes:64]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, useful lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0000950170-25-109742:notes:65]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0000950170-25-109742:notes:66]
Deferred Revenue

[0000950170-25-109742:notes:67]
Deferred revenue represents amounts for (i) deferred subscription and support, and (ii) other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0000950170-25-109742:notes:68]
Product Warranties and Guarantees

[0000950170-25-109742:notes:69]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0000950170-25-109742:notes:70]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0000950170-25-109742:notes:71]
Stock-based Compensation

[0000950170-25-109742:notes:72]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) under the 2013 Equity Incentive Plan and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock options and stock purchase options using the Black-Scholes-Merton option valuation model. The fair value of RSUs is based on the closing stock price of the Company’s common stock on the grant date.

[0000950170-25-109742:notes:73]
The Company grants certain employees with stock options and RSUs that are tied to either company-wide financial performance metrics or certain market metrics. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0000950170-25-109742:notes:74]
Advertising

[0000950170-25-109742:notes:75]
Advertising costs are expensed as incurred. Advertising expenses were immaterial in fiscal years 2025, 2024 and 2023.

[0000950170-25-109742:notes:76]
Income Taxes

[0000950170-25-109742:notes:77]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0000950170-25-109742:notes:78]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions. The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes. For additional discussion, see Note 15, Income Taxes.

[0000950170-25-109742:notes:79]
Recently Adopted Accounting Pronouncements

[0000950170-25-109742:notes:80]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities

[0000950170-25-109742:notes:81]
with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company has adopted this standard for the fiscal year 2025 annual consolidated financial statements and has applied this standard retrospectively for all prior periods presented in the consolidated financial statements. See Note 12, Information about Segments and Geographic Areas, for further information.

[0000950170-25-109742:notes:82]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000950170-25-109742:notes:83]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.

[0000950170-25-109742:notes:84]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-25-109742:notes:85]
3. Revenues

[0000950170-25-109742:notes:86]
The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell primarily to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0000950170-25-109742:notes:87]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0000950170-25-109742:notes:88]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenues from SaaS and maintenance contracts are recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which generally ranges from one to five years. For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Sales taxes collected from customers are excluded from revenues. Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the historical actuals. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-25-109742:notes:89]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotations are variable consideration and are estimated based on historical return rates and estimates provided by the distributors. Additionally, distributors often need to sell at a price lower than the contractual distribution price in order to win business and will submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price. At the time the distributor invoices its end customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these customer rebates to be variable consideration. Such price adjustments are estimated based on an analysis of historical

[0000950170-25-109742:notes:90]
claims at the distributor level. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-25-109742:notes:91]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in ASC Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

[0000950170-25-109742:notes:92]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenue recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.

[0000950170-25-109742:notes:93]
At June 30, 2025, the Company had $617.5 million of remaining performance obligations, which are primarily comprised of deferred subscription and deferred support revenues. The Company expects to recognize approximately 53% of this deferred revenue amount as revenue in fiscal 2026, an additional 23% in fiscal 2027 and the remaining 24% of the balance thereafter.

[0000950170-25-109742:notes:94]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable SaaS subscription and support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenue. These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0000950170-25-109742:notes:95]
The Company's total deferred revenue balances at June 30, 2025, 2024 and 2023 were $617.5 million, $575.0 million, and $501.5 million, respectively. Revenue recognized for the years ended June 30, 2025, 2024 and 2023, that was included in the deferred revenue balance at the beginning of each period was $296.3 million, $275.7 million, and $232.9 million, respectively.

[0000950170-25-109742:notes:96]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals, are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $26.9 million and $24.7 million at June 30, 2025 and 2024, respectively. Capitalized commissions are included within the “Other assets” in the consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations. Amortization recognized during the years ended June 30, 2025, 2024 and 2023 was $12.5 million, $10.9 million and $9.1 million, respectively.

[0000950170-25-109742:notes:97]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-25-109742:notes:98]
Disaggregation of Revenues: The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following tables set forth the Company’s net revenues disaggregated by geographic region based on the billing addresses of its customers (in thousands):

[0000950170-25-109742:notes:99]
|  |  | Year Ended |  |
| Net Revenues |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 547,658 |  |  | $ | 581,141 |  |  | $ | 572,927 |  |
| Other |  |  | 49,047 |  |  |  | 46,578 |  |  |  | 84,108 |  |
| Total Americas |  |  | 596,705 |  |  |  | 627,719 |  |  |  | 657,035 |  |
| EMEA |  |  | 451,649 |  |  |  | 421,966 |  |  |  | 559,669 |  |
| APAC |  |  | 91,713 |  |  |  | 67,518 |  |  |  | 95,750 |  |
| Total net revenues |  | $ | 1,140,067 |  |  | $ | 1,117,203 |  |  | $ | 1,312,454 |  |

[0000950170-25-109742:notes:100]
For the years ended June 30, 2025, 2024 and 2023, the Company generated 11%, 11% and 13%, respectively, of its revenue from the Netherlands. No other foreign country accounted for 10% or more of the Company’s net revenue for the years ended June 30, 2025, 2024 and 2023.

[0000950170-25-109742:notes:101]
Concentrations

[0000950170-25-109742:notes:102]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0000950170-25-109742:notes:103]
The following table sets forth customers accounting for 10% or more of the Company’s net revenues:

[0000950170-25-109742:notes:104]
|  |  |  |  |  | Year Ended |  |  |
|  |  |  | June 30,2025 |  | June 30,2024 |  | June 30, 2023 |
| Jenne, Inc. |  |  | 18% |  | 22% |  | 15% |
| Westcon Group, Inc. |  |  | 18% |  | 16% |  | 20% |
| TD Synnex Corporation |  |  | 18% |  | 21% |  | 18% |

[0000950170-25-109742:notes:105]
The following table sets forth major customers accounting for 10% or more of the Company’s net accounts receivable, as of June 30, 2025 and June 30, 2024:

[0000950170-25-109742:notes:106]
|  |  | June 30,2025 |  | June 30,2024 |
| Jenne, Inc. |  | 22% |  | 64% |
| Ericsson Inc. |  | 11% |  | * |
| ScanSource, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-25-109742:notes:107]
4. Balance Sheet Components

[0000950170-25-109742:notes:108]
The following table summarizes the Company's cash and cash equivalents (in thousands):

[0000950170-25-109742:notes:109]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Cash |  | $ | 225,656 |  |  | $ | 153,483 |  |
| Cash equivalents |  |  | 6,089 |  |  |  | 3,216 |  |
| Total cash and cash equivalents |  | $ | 231,745 |  |  | $ | 156,699 |  |

[0000950170-25-109742:notes:110]
Accounts Receivable, Net

[0000950170-25-109742:notes:111]
The following table summarizes the Company's accounts receivable (in thousands):

[0000950170-25-109742:notes:112]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Accounts receivable |  | $ | 327,067 |  |  | $ | 327,859 |  |
| Customer rebates |  |  | (176,002 | ) |  |  | (185,090 | ) |
| Allowance for credit losses |  |  | (691 | ) |  |  | (915 | ) |
| Allowance for product returns |  |  | (23,666 | ) |  |  | (52,336 | ) |
| Accounts receivable, net |  | $ | 126,708 |  |  | $ | 89,518 |  |

[0000950170-25-109742:notes:113]
The following table summarizes the Company's allowance for credit losses (in thousands):

[0000950170-25-109742:notes:114]
| Description |  | Balance atbeginning ofperiod |  |  | Provision for expected credit losses |  |  | Deductions (1) |  |  | Balance atend of period |  |
| Year Ended June 30, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 915 |  |  | $ | 157 |  |  | $ | (381 | ) |  | $ | 691 |  |
| Year Ended June 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 882 |  |  | $ | 210 |  |  | $ | (177 | ) |  | $ | 915 |  |
| Year Ended June 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 695 |  |  | $ | 464 |  |  | $ | (277 | ) |  | $ | 882 |  |

[0000950170-25-109742:notes:115]
(1)
Uncollectible accounts written off, net of recoveries.

[0000950170-25-109742:notes:116]
The following table summarizes the Company’s allowance for product returns (in thousands):

[0000950170-25-109742:notes:117]
| Description |  | Balance atbeginning ofperiod |  |  | Additions |  |  | Deductions |  |  | Balance atend of period |  |
| Year Ended June 30, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 52,336 |  |  | $ | 23,716 |  |  | $ | (52,386 | ) |  | $ | 23,666 |  |
| Year Ended June 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 35,125 |  |  | $ | 149,161 |  |  | $ | (131,950 | ) |  | $ | 52,336 |  |
| Year Ended June 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 20,033 |  |  | $ | 104,028 |  |  | $ | (88,936 | ) |  | $ | 35,125 |  |

[0000950170-25-109742:notes:118]
The following table summarizes the Company’s inventory by category (in thousands):

[0000950170-25-109742:notes:119]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Finished goods |  | $ | 57,770 |  |  | $ | 115,813 |  |
| Raw materials |  |  | 44,808 |  |  |  | 25,219 |  |
| Total inventories |  | $ | 102,578 |  |  | $ | 141,032 |  |

[0000950170-25-109742:notes:120]
Property and Equipment, Net

[0000950170-25-109742:notes:121]
The following table summarizes the Company’s property and equipment by category (in thousands):

[0000950170-25-109742:notes:122]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Computers and equipment |  | $ | 80,782 |  |  | $ | 77,224 |  |
| Software |  |  | 62,089 |  |  |  | 60,717 |  |
| Office equipment, furniture and fixtures |  |  | 8,031 |  |  |  | 8,134 |  |
| Leasehold improvements |  |  | 47,962 |  |  |  | 47,880 |  |
| Total property and equipment |  |  | 198,864 |  |  |  | 193,955 |  |
| Less: accumulated depreciation and amortization |  |  | (154,498 | ) |  |  | (150,211 | ) |
| Property and equipment, net |  | $ | 44,366 |  |  | $ | 43,744 |  |

[0000950170-25-109742:notes:123]
The Company recognized depreciation expense of $14.5 million, $23.9 million and $19.5 million related to property and equipment during the years ended June 30, 2025, 2024 and 2023, respectively. The Company recognized depreciation expense of $23.9 million during the fiscal year ended June 30, 2024, of which $5.9 million was recorded as restructuring and related charges in the consolidated statement of operations. Refer to Note 14, Restructuring and Related Charges, for further discussion.

[0000950170-25-109742:notes:124]
The following table summarizes the Company's contract liabilities which are shown as deferred revenue (in thousands):

[0000950170-25-109742:notes:125]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Deferred subscription and support |  | $ | 603,363 |  |  | $ | 554,661 |  |
| Other deferred revenue |  |  | 14,130 |  |  |  | 20,362 |  |
| Total deferred revenue |  | $ | 617,493 |  |  | $ | 575,023 |  |
| Less: current portion |  | $ | 325,078 |  |  | $ | 306,114 |  |
| Non-current deferred revenue |  | $ | 292,415 |  |  | $ | 268,909 |  |

[0000950170-25-109742:notes:126]
Accrued Warranty

[0000950170-25-109742:notes:127]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0000950170-25-109742:notes:128]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| Balance at beginning of period |  | $ | 10,942 |  |  | $ | 12,322 |  |  | $ | 10,852 |  |
| New warranties issued |  |  | 11,540 |  |  |  | 13,010 |  |  |  | 15,463 |  |
| Warranty expenditures |  |  | (12,798 | ) |  |  | (14,390 | ) |  |  | (13,993 | ) |
| Balance at end of period |  | $ | 9,684 |  |  | $ | 10,942 |  |  | $ | 12,322 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-25-109742:notes:129]
5. Fair Value Measurements

[0000950170-25-109742:notes:130]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0000950170-25-109742:notes:131]
•
Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities;

[0000950170-25-109742:notes:132]
•
Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000950170-25-109742:notes:133]
•
Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value.

[0000950170-25-109742:notes:134]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0000950170-25-109742:notes:135]
| June 30, 2025 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 6,089 |  |  | $ | — |  |  | $ | 6,089 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 298 |  |  |  | — |  |  |  | 298 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 6,387 |  |  | $ | — |  |  | $ | 6,387 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 11 |  |

[0000950170-25-109742:notes:136]
| June 30, 2024 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 3,216 |  |  | $ | — |  |  | $ | 3,216 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 18 |  |  |  | — |  |  |  | 18 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 3,234 |  |  | $ | — |  |  | $ | 3,234 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |

[0000950170-25-109742:notes:137]
The Company’s financial instruments consist of cash and cash equivalents, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0000950170-25-109742:notes:138]
The Company's level 2 assets consist of certificates of deposit and derivative instruments. Certificates of deposit do not have regular market pricing and are considered Level 2. The fair value of derivative instruments under the Company’s foreign exchange forward contracts and interest rate swaps are estimated based on valuations provided by alternative pricing sources supported by observable inputs which are considered Level 2.

[0000950170-25-109742:notes:139]
As of June 30, 2025 and June 30, 2024 the Company had investment in certificates of deposit of $6.1 million and $3.2 million, respectively,  with maturity of three months at the date of purchase, which are recorded as cash equivalents in the consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of June 30, 2025 and June 30, 2024, their fair value approximated their amortized cost.

[0000950170-25-109742:notes:140]
As of June 30, 2025 and June 30, 2024, foreign exchange forward currency contracts not designated as hedging instruments had total notional principal amounts of $57.2 million and $31.3 million, respectively. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in “Other income (expense), net” in the consolidated statements of operations. For the years ended June 30, 2025, 2024 and 2023 the consolidated statements of operations included net gains of $1.0 million, net losses of $0.3 million, and net losses of $0.4 million, respectively from these contracts. There were no outstanding foreign exchange forward contracts that were designated as hedging instruments at June 30, 2025 and 2024. See Note 13, Derivatives and Hedging, for additional information.

[0000950170-25-109742:notes:141]
The fair value of the borrowings under the Amended Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the Amended Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $180.0 million and $190.0 million as of June 30, 2025 and 2024, respectively.

[0000950170-25-109742:notes:142]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. As of June 30, 2025 and June 30, 2024 the Company did not have any assets or liabilities that were considered Level 3.

[0000950170-25-109742:notes:143]
There were no transfers of assets or liabilities between Level 1, Level 2 or Level 3 during the years ended June 30, 2025 and 2024. There were no impairments recorded during the years ended June 30, 2025, 2024, or 2023.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-25-109742:notes:144]
6. Goodwill and Intangible Assets

[0000950170-25-109742:notes:145]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0000950170-25-109742:notes:146]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Balance at beginning of period |  | $ | 393,709 |  |  | $ | 394,755 |  |
| Foreign currency translation |  |  | 5,865 |  |  |  | (1,046 | ) |
| Balance at end of period |  | $ | 399,574 |  |  | $ | 393,709 |  |

[0000950170-25-109742:notes:147]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0000950170-25-109742:notes:148]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2025 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 170,480 |  |  | $ | 165,908 |  |  | $ | 4,572 |  |
| Customer relationships |  | 1.0 years |  |  | 64,824 |  |  |  | 62,961 |  |  |  | 1,863 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 1.4 years |  |  | 1,282 |  |  |  | 1,176 |  |  |  | 106 |  |
| Total intangible assets, net* |  |  |  | $ | 247,286 |  |  | $ | 240,745 |  |  | $ | 6,541 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-25-109742:notes:149]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 169,247 |  |  | $ | 162,708 |  |  | $ | 6,539 |  |
| Customer relationships |  | 2.0 years |  |  | 64,671 |  |  |  | 60,776 |  |  |  | 3,896 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 2.4 years |  |  | 1,282 |  |  |  | 1,104 |  |  |  | 178 |  |
| Total intangible assets, net* |  |  |  | $ | 245,901 |  |  | $ | 235,288 |  |  | $ | 10,613 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-25-109742:notes:150]
The following table summarizes the amortization expense of intangible assets for the periods presented (in thousands):

[0000950170-25-109742:notes:151]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 2,471 |  |  | $ | 3,272 |  |  | $ | 12,941 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 2,043 |  |  |  | 2,041 |  |  |  | 2,047 |  |
| Total amortization expense |  | $ | 4,514 |  |  | $ | 5,313 |  |  | $ | 14,988 |  |

[0000950170-25-109742:notes:152]
The amortization expense that is recognized in “Total cost of revenues” primarily consists of amortization related to developed technology, license agreements and other intangibles.

[0000950170-25-109742:notes:153]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0000950170-25-109742:notes:154]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2026 |  | $ | 3,391 |  |
| 2027 |  |  | 1,520 |  |
| 2028 |  |  | 1,349 |  |
| 2029 |  |  | 281 |  |
| Total |  | $ | 6,541 |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-25-109742:notes:155]
7. Debt

[0000950170-25-109742:notes:156]
The Company’s debt is comprised of the following (in thousands):

[0000950170-25-109742:notes:157]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 15,000 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (729 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 14,271 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 165,000 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,276 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 163,724 |  |  |  | 178,265 |  |
| Total debt |  | $ | 177,995 |  |  | $ | 187,591 |  |

[0000950170-25-109742:notes:158]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-25-109742:notes:159]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which

[0000950170-25-109742:notes:160]
amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

[0000950170-25-109742:notes:161]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-25-109742:notes:162]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-25-109742:notes:163]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provided a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024. As of June 30, 2025, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

[0000950170-25-109742:notes:164]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2025, the Company capitalized approximately $0.7 million of debt cost related to the Amended Credit Agreement. The remaining unamortized debt issuance cost related to the prior arrangement and the newly capitalized costs are amortized over the remaining term of the loan arrangement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying consolidated statements of operations and were $1.2 million, $1.1 million and $2.6 million for the fiscal years ended June 30, 2025, 2024 and 2023, respectively. The Company's interest rate was 6.43% and 7.44% as of June 30, 2025 and 2024, respectively.

[0000950170-25-109742:notes:165]
As of June 30, 2025, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of June 30, 2025. During the fiscal years ended June 30, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

[0000950170-25-109742:notes:166]
The Company had $14.2 million of outstanding letters of credit as of June 30, 2025.

[0000950170-25-109742:notes:167]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0000950170-25-109742:notes:168]
|  |  | Amount |  |
| For the fiscal year ending June 30, |  |  |  |
| 2026 |  | $ | 15,000 |  |
| 2027 |  |  | 20,000 |  |
| 2028 |  |  | 145,000 |  |
| Total |  | $ | 180,000 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-25-109742:notes:169]
8. Leases

[0000950170-25-109742:notes:170]
Lessee Considerations

[0000950170-25-109742:notes:171]
The Company leases certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2033. Its leases generally have terms that range from one year to ten years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0000950170-25-109742:notes:172]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or ROU asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate at the commencement date because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is the rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. The biggest drivers having the greatest effect in determining the incremental borrowing rate for each one of the Company’s leases are the term of the lease and the currency in which the lease obligation is satisfied.

[0000950170-25-109742:notes:173]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for variable lease and non-lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s consolidated statements of operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0000950170-25-109742:notes:174]
The following table presents additional information relating to the Company's operating leases (in thousands, except for lease term and discount rate):

[0000950170-25-109742:notes:175]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  | June 30,2024 |  | June 30, 2023 |  |
| Operating lease costs | $ | 12,724 |  | $ | 14,398 |  | $ | 14,416 |  |
| Variable lease costs |  |  | 3,810 |  |  | 4,325 |  |  | 6,920 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 13,871 |  |  | 14,487 |  |  | 17,396 |  |
| ROU assets obtained for new lease obligations |  | 4,057 |  |  | 21,082 |  |  | 10,972 |  |

[0000950170-25-109742:notes:176]
|  |  | June 30,2025 |  | June 30,2024 |  |
| Weighted average remaining lease term | 5.2 years |  | 5.8 years |  |
| Weighted average discount rate |  | 6.0 | % |  | 5.8 | % |

[0000950170-25-109742:notes:177]
Short-term lease expense, which represents expense for leases with terms of one year or less, was not material for each of the years ended June 30, 2025, 2024, or 2023.

[0000950170-25-109742:notes:178]
The following table presents maturities of the Company’s operating lease liabilities as of June 30, 2025 (in thousands):

[0000950170-25-109742:notes:179]
|  |  | Amount |  |
| For the fiscal year ending June 30, |  |  |  |
| 2026 |  | $ | 13,341 |  |
| 2027 |  |  | 12,158 |  |
| 2028 |  |  | 6,226 |  |
| 2029 |  |  | 5,802 |  |
| 2030 |  |  | 5,505 |  |
| Thereafter |  |  | 10,205 |  |
| Total future minimum lease payments |  |  | 53,237 |  |
| Less amount representing interest |  |  | (7,790 | ) |
| Total operating lease liabilities |  | $ | 45,447 |  |
| Operating lease liabilities, current |  | $ | 11,456 |  |
| Operating lease liabilities, non-current |  | $ | 33,991 |  |

[0000950170-25-109742:notes:180]
Sublease Considerations

[0000950170-25-109742:notes:181]
As of June 30, 2025, the Company did not have any material subleases. The Company included less than $0.1 million, $0.1 million and $0.5 million of sublease income in lease expense for the years ended June 30, 2025, 2024, and 2023, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-109742:notes:182]
9. Commitments and Contingencies

[0000950170-25-109742:notes:183]
Purchase Commitments

[0000950170-25-109742:notes:184]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2025, the Company had non-cancelable commitments to purchase $45.4 million of inventory, which will be received and consumed during fiscal 2026. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0000950170-25-109742:notes:185]
Legal Proceedings

[0000950170-25-109742:notes:186]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-25-109742:notes:187]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year. As of June 30, 2025, the total estimated litigation expense accrual included in the “Other accrued liabilities” in the consolidated balance sheets was $47.5 million for various ongoing litigation matters with probable losses that can be reasonably estimated.

[0000950170-25-109742:notes:188]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-25-109742:notes:189]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP sought actual damages and profits attributed to the infringement, as well as equitable relief. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. The parties reached a settlement, and on July 29, 2025, the case was dismissed with prejudice.

[0000950170-25-109742:notes:190]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-25-109742:notes:191]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.

[0000950170-25-109742:notes:192]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. Mala appealed the decision on March 3, 2025, and the Company will defend the appeal.

[0000950170-25-109742:notes:193]
Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al.

[0000950170-25-109742:notes:194]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Firefighters Pension and Retirement System, Oklahoma Police Pension and Retirement System, Oakland County Voluntary Employees’ Beneficiary Association, Oakland County Employees’ Retirement System as the lead plaintiffs. The Company's Motion to Dismiss was granted on August 15, 2025, but the plaintiffs were granted leave to file an amended complaint by September 9, 2025.

[0000950170-25-109742:notes:195]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these cases (collectively, the “Derivative Cases”) names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. These cases  remain stayed pending a potential filing of an amended complaint in the Class Action.

[0000950170-25-109742:notes:196]
Indemnification Obligations

[0000950170-25-109742:notes:197]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-25-109742:notes:198]
10. Stockholders’ Equity

[0000950170-25-109742:notes:199]
Preferred Stock

[0000950170-25-109742:notes:200]
In April 2001, in connection with entering into a rights agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors (the “Board”) is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2025, no shares of preferred stock were outstanding.

[0000950170-25-109742:notes:201]
Equity Incentive Plan

[0000950170-25-109742:notes:202]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 14, 2024 to increase the maximum number of available shares by 2.3 million shares. The amendment was approved by the stockholders of the Company at the annual meeting of the stockholders held on November 14, 2024.

[0000950170-25-109742:notes:203]
Employee Stock Purchase Plan

[0000950170-25-109742:notes:204]
The Compensation Committee of the Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan (the “ESPP”) on September 9, 2021 to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares. The amendment was approved by a majority of the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021.

[0000950170-25-109742:notes:205]
Common Stock Repurchases

[0000950170-25-109742:notes:206]
On May 18, 2022, the Company announced that the Board had authorized management to repurchase up to $200.0 million shares of the Company’s common stock over a three-year period commencing July 1, 2022 (as amended, the “2022 Repurchase Program”). Under the 2022 Repurchase Program, a maximum of $25.0 million of shares was authorized to be repurchased in any quarter. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The 2022 Repurchase Program expired on June 30, 2025.

[0000950170-25-109742:notes:207]
During fiscal year 2025, the Company repurchased a total of 2.4 million shares of its common stock on the open market at a total cost of $38.0 million with an average price of $15.89 per share. During fiscal year 2024, the Company repurchased a total of 2.4 million shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. During fiscal year 2023, the Company repurchased a total of 5.4 million shares of its common stock on the open market at a total cost of $99.9 million with an average price of $18.58 per share.

[0000950170-25-109742:notes:208]
On February 18, 2025, the Company announced that the Board had authorized management to repurchase up to $200.0 million shares of the Company's common stock over a three-year period, commencing July 1, 2025 (the "2025 Repurchase Program"). Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0000950170-25-109742:notes:209]
As provision of the Inflation Reduction Act enacted in the U.S., the Company is subject to an excise tax on corporate stock repurchases, which is assessed as one percent of the fair market value of net corporate stock repurchases after December 31, 2022. The  excise tax's effect on net corporate stock repurchases was not material for the fiscal years ended June 30, 2025 and 2024.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-25-109742:notes:210]
11. Employee Benefit Plans

[0000950170-25-109742:notes:211]
As of June 30, 2025, the Company has the following share-based compensation plans and the 401(k) Plan discussed below:

[0000950170-25-109742:notes:212]
2013 Equity Incentive Plan

[0000950170-25-109742:notes:213]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units ("RSUs") (including performance-based or market-based RSUs), performance shares, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and RSUs to non-employee members of the Board and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, 6.6 million shares of the Company's common stock under the 2005 Plan were transferred to the 2013 Stock Plan and were added to the number of shares available for future grant under the 2013 Plan. Prior to fiscal 2025, stockholders approved the issuance of an additional 43.7 million shares of the Company's common stock. During the year ended June 30, 2025, an additional 2.3 million shares were authorized and made available for grant under the 2013 Plan. The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting. As of June 30, 2025, total options and awards to acquire 7.6 million shares were outstanding under the 2013 Plan and 10.9 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0000950170-25-109742:notes:214]
Shares Reserved for Issuance

[0000950170-25-109742:notes:215]
The Company had the following reserved shares of the Company's common stock for future issuance as of the dates noted (in thousands):

[0000950170-25-109742:notes:216]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 10,935 |  |  |  | 13,414 |  |
| Employee stock options and awards outstanding |  |  | 7,566 |  |  |  | 7,562 |  |
| 2014 Employee Stock Purchase Plan |  |  | 5,952 |  |  |  | 7,130 |  |
| Total shares reserved for issuance |  |  | 24,453 |  |  |  | 28,106 |  |

[0000950170-25-109742:notes:217]
Stock Options

[0000950170-25-109742:notes:218]
The following table summarizes stock option activity under all plans for the year ended June 30, 2025 (in thousands except per share amount and contractual term):

[0000950170-25-109742:notes:219]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 1.75 |  |  | $ | 7,376 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (577 | ) |  |  | 6.47 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2025 |  |  | 496 |  |  | $ | 6.70 |  |  |  | 1.16 |  |  | $ | 5,580 |  |
| Vested and expected to vest at June 30, 2025 |  |  | 496 |  |  | $ | 6.70 |  |  |  | 1.16 |  |  | $ | 5,580 |  |
| Exercisable at June 30, 2025 |  |  | 496 |  |  | $ | 6.70 |  |  |  | 1.16 |  |  | $ | 5,580 |  |

[0000950170-25-109742:notes:220]
The total intrinsic value of options exercised in fiscal years 2025 and 2024 was $5.0 million and $1.1 million, respectively. There were no options exercised during the fiscal year 2023.

[0000950170-25-109742:notes:221]
There were no stock options granted during the fiscal years 2025 and 2024. As of June 30, 2025, all outstanding options are fully vested and compensation cost related to stock options has been fully recognized.

[0000950170-25-109742:notes:222]
Stock Awards

[0000950170-25-109742:notes:223]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of RSUs, including performance-based or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the award’s fair value as of the date of grant. The Company does not estimate forfeitures, but accounts for them as incurred.

[0000950170-25-109742:notes:224]
The following table summarizes stock award activity for the year ended June 30, 2025 (in thousands, except grant date fair value):

[0000950170-25-109742:notes:225]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2024 |  |  | 6,489 |  |  | $ | 22.65 |  |  |  |  |
| Granted |  |  | 4,857 |  |  |  | 15.78 |  |  |  |  |
| Released |  |  | (3,807 | ) |  |  | 20.02 |  |  |  |  |
| Canceled |  |  | (469 | ) |  |  | 20.27 |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2025 |  |  | 7,070 |  |  | $ | 19.53 |  |  | $ | 126,907 |  |
| Stock awards expected to vest at June 30, 2025 |  |  | 7,070 |  |  | $ | 19.53 |  |  | $ | 126,907 |  |

[0000950170-25-109742:notes:226]
The RSUs granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company.

[0000950170-25-109742:notes:227]
The aggregate fair value, as of the respective grant dates of awards granted during the fiscal years ended June 30, 2025, 2024 and 2023 was $76.6 million, $110.5 million and $106.8 million, respectively.

[0000950170-25-109742:notes:228]
For fiscal years ended June 30, 2025, 2024, and 2023, the Company withheld an aggregate of 1.4 million shares, 1.9 million shares, and 1.4 million shares, respectively, upon the vesting of awards, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0000950170-25-109742:notes:229]
For fiscal years ended June 30, 2025, 2024 and 2023, the Company remitted cash of $21.2 million, $47.9 million, $21.9 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Payments for tax withholdings, net of proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0000950170-25-109742:notes:230]
As of June 30, 2025, there was $82.6 million in unrecognized compensation costs related to non-vested stock awards which includes the performance and market condition awards as discussed below. This cost is expected to be recognized over a weighted-average period of 1.4 years.

[0000950170-25-109742:notes:231]
Stock Awards – Officers and Directors

[0000950170-25-109742:notes:232]
RSUs granted during fiscal 2025, 2024 and 2023 to named executive officers and directors totaled 1.3 million awards, 0.7 million awards and 1.8 million awards, respectively which included awards with market-based conditions as discussed below.

[0000950170-25-109742:notes:233]
Stock Awards - Performance Awards

[0000950170-25-109742:notes:234]
During fiscal 2025, 2024, and 2023, the Compensation Committee of the Board granted 1.0 million, 0.8 million and 1.2 million  RSUs, respectively with vesting based on market conditions (“MSUs”) to certain of the Company’s employees. The MSUs granted during fiscal 2025 and 2023 were subject to total shareholder return (“TSR”). The MSUs granted during fiscal 2024 included 0.5 million MSUs subject to TSR and 0.3 million MSUs subject to certain stock price targets.

[0000950170-25-109742:notes:235]
The TSR MSUs vest based on the Company’s TSR relative to the TSR of the Russell 2000 Index (“Index”). The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant, as indicated in the table below. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0000950170-25-109742:notes:236]
| Level | Relative TSR | Shares Vested |
| Below Threshold | TSR is less than the Index by more than 37.5 percentage points | 0% |
| Threshold | TSR is less than the Index by 37.5 percentage points | 25% |
| Target | TSR equals the Index | 100% |
| Maximum | TSR is greater than the Index by 25 percentage points or more | 150% |

[0000950170-25-109742:notes:237]
TSR is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years 1 and 2 and the ability for up to the maximum of the full award to vest based on the full 3-year TSR less any shares vested based on 1- and 2- year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0000950170-25-109742:notes:238]
The stock price target MSUs vest upon the achievement of a certain stock price target over the defined performance period. The stock price target shall be deemed as achieved if the average closing stock price over any thirty consecutive trading days during the period from grant date through the third anniversary of the grant date equals or exceeds the price target of $41.38 for the initial performance period. Upon satisfaction of the initial stock price target, 50% of the target shares will vest on the 3rd anniversary of the grant date and the remaining 50% will vest on the 4th anniversary of the grant date, subject to employees continued service through the applicable vesting dates. If the units are not earned on the last day of initial performance period, the units will remain outstanding and be eligible to be earned if the average closing stock price over any thirty consecutive trading days equals or exceeds the price target of $46.96.

[0000950170-25-109742:notes:239]
On February 15, 2024, the Company modified certain terms and conditions of the stock price target MSUs for certain executive officers. Under the modified agreement, the stock price target over the initial and fourth year performance periods were revised to $23.00 and $26.00, respectively. All other contractual terms remained unchanged. The incremental compensation cost recognized during fiscal 2024 and ratably over the remaining requisite service period is not material.

[0000950170-25-109742:notes:240]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during fiscal 2025 was $17.10 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 48%, risk-free interest rate of 3.89%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-25-109742:notes:241]
The weighted-average grant-date fair value of the MSUs granted during fiscal 2024 was $32.66 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free rate of 4.43%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-25-109742:notes:242]
The weighted-average grant-date fair value of the MSUs granted during fiscal 2023 was $17.62 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 65%, risk-free rate of 3.27%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-25-109742:notes:243]
The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-25-109742:notes:244]
The following table summarizes stock awards with market or performance-based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0000950170-25-109742:notes:245]
|  |  | Fiscal Year 2025 |  |  | Fiscal Year 2024 |  |  | Fiscal Year 2023 |  |
| Performance awards granted |  |  | 1,037 |  |  |  | 841 |  |  |  | 1,221 |  |
| Performance awards earned |  |  | 899 |  |  |  | 846 |  |  |  | 400 |  |

[0000950170-25-109742:notes:246]
2014 Employee Stock Purchase Plan

[0000950170-25-109742:notes:247]
On August 27, 2014, the Board approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. During the fiscal year ended June 30, 2022, the Board of Directors unanimously approved an amendment to the 2014 ESPP to increase the maximum number of shares that will be available for sale by 7.5 million shares, which was approved by the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period has a maximum duration of six months and the maximum shares issuable for each purchase period is 1.5 million shares. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.

[0000950170-25-109742:notes:248]
During the fiscal years ended June 30, 2025 and 2024, there were 1.2 million and 1.3 million shares issued under the 2014 ESPP. As of June 30, 2025, there have been an aggregate 21.0 million shares issued under the 2014 ESPP.

[0000950170-25-109742:notes:249]
Share-Based Compensation Expense

[0000950170-25-109742:notes:250]
Share-based compensation expense recognized in the financial statements by line-item caption is as follows (in thousands):

[0000950170-25-109742:notes:251]
|  |  |  | Year Ended |  |
|  |  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| Cost of product revenues |  |  | $ | 2,661 |  |  | $ | 1,899 |  |  | $ | 1,856 |  |
| Cost of subscription and support revenues |  |  |  | 2,912 |  |  |  | 2,994 |  |  |  | 3,513 |  |
| Research and development |  |  |  | 17,154 |  |  |  | 16,686 |  |  |  | 14,824 |  |
| Sales and marketing |  |  |  | 28,393 |  |  |  | 26,524 |  |  |  | 22,250 |  |
| General and administrative |  |  |  | 31,194 |  |  |  | 28,660 |  |  |  | 21,029 |  |
| Total share-based compensation expense |  |  | $ | 82,314 |  |  | $ | 76,763 |  |  | $ | 63,472 |  |

[0000950170-25-109742:notes:252]
The Company uses the straight-line method for expense attribution, other than for the PSUs and MSUs, which may use the accelerated attribution method. The Company does not estimate forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur.

[0000950170-25-109742:notes:253]
The fair value of each RSU grant with market-based vesting criteria under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0000950170-25-109742:notes:254]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP shares is the offering period for each purchase. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility of the Company’s stock.

[0000950170-25-109742:notes:255]
The weighted-average estimated per share fair value of shares under the 2014 ESPP in fiscal years 2025, 2024 and 2023, was $3.99, $5.73 and $4.87, respectively.

[0000950170-25-109742:notes:256]
|  |  | Employee Stock Purchase Plan |  |  |
|  |  | Year Ended |  |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  |
| Risk-free interest rate |  |  | 4.73 | % |  |  | 5.42 | % |  |  | 3.84 | % |  |
| Volatility |  |  | 37 | % |  |  | 47 | % |  |  | 55 | % |  |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |

[0000950170-25-109742:notes:257]
401(k) Plan

[0000950170-25-109742:notes:258]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to contribute a portion of their current compensation up to the IRS annual contribution limit of $23,500 for the calendar year 2025. Employees aged 50 or over may elect to contribute an additional $7,500 and employees aged 60-63 may elect to contribute an additional $11,250. The amount contributed to the Plan is on a pre-tax or post-tax basis.

[0000950170-25-109742:notes:259]
The Company provides for discretionary matching contributions as determined by the Board for each calendar year. All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board each year. The program effective during fiscal 2025 was established to match $0.50 for every dollar contributed by the employee up to the first 6.0% of pay. The Company’s matching contributions to the Plan totaled $5.7 million, $5.2 million and $5.2 million, for fiscal years ended June 30, 2025, 2024 and 2023, respectively. No discretionary contributions were made in fiscal years ended June 30, 2025, 2024 and 2023.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-109742:notes:260]
12. Information about Segments and Geographic Areas

[0000950170-25-109742:notes:261]
The Company has one reportable segment, the development, marketing, and sale of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area. The Company operates in three geographical areas: Americas, EMEA, and APAC. See Note 3, Revenues, for additional information on the Company's revenues by geographic region.

[0000950170-25-109742:notes:262]
Measure of segment profit or loss:

[0000950170-25-109742:notes:263]
The Company’s chief operating decision maker (“CODM”), who is its Chief Executive Officer, reviews financial information presented on a consolidated basis and uses consolidated non-GAAP net income to measure segment profit or loss and to monitor period-over-period results to decide where to allocate and invest additional resources within the business.

[0000950170-25-109742:notes:264]
Consolidated non-GAAP net income is exclusive of certain items that are non-recurring or not consistent with the Company's operations. The CODM reviews and utilizes functional expenses (costs of revenue, research and development, sales and marketing, and general and administrative) at the consolidated level to manage and assess the Company's operations. Other segment items included in consolidated non-GAAP net income are interest income, interest expense, other income (expense), net, and the provision for (benefit from) income taxes, which are reflected in the consolidated statements of operations.

[0000950170-25-109742:notes:265]
A reconciliation of consolidated GAAP net income (loss) to consolidated non-GAAP net income is shown in the table below:

[0000950170-25-109742:notes:266]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| GAAP net income (loss) |  | $ | (7,467 | ) |  | $ | (85,964 | ) |  | $ | 78,074 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 82,314 |  |  |  | 76,763 |  |  |  | 63,472 |  |
| Acquisition and integration costs |  |  | — |  |  |  | — |  |  |  | 390 |  |
| Restructuring and related charges |  |  | 1,492 |  |  |  | 36,321 |  |  |  | 2,860 |  |
| Litigation charges(1) |  |  | 34,722 |  |  |  | 10,545 |  |  |  | 8,026 |  |
| System transition costs |  |  | 21,550 |  |  |  | 5,262 |  |  |  | 957 |  |
| Amortization of intangibles |  |  | 4,443 |  |  |  | 5,243 |  |  |  | 14,916 |  |
| Debt refinancing charges, Other income (expense) |  |  | 79 |  |  |  | — |  |  |  | 1,543 |  |
| Tax effect of non-GAAP adjustments |  |  | (24,709 | ) |  |  | (4,815 | ) |  |  | (23,933 | ) |
| Total adjustments to GAAP net income (loss) |  | $ | 119,891 |  |  | $ | 129,319 |  |  | $ | 68,231 |  |
| Non-GAAP net income |  | $ | 112,424 |  |  | $ | 43,355 |  |  | $ | 146,305 |  |

[0000950170-25-109742:notes:267]
(1)Litigation charges consist of estimated settlement and related legal expenses for non-recurring litigation offset by any proceeds received or expected to be received from insurance.

[0000950170-25-109742:notes:268]
Measure of segment assets:

[0000950170-25-109742:notes:269]
The measure of segment assets that is reviewed by the CODM is reported within the consolidated balance sheets as “Total assets”. Depreciation expense recorded for fiscal years ended June 30, 2025, 2024, and 2023 was $14.5 million, $23.9 million and $19.5 million, respectively. Total expenditures for additions to property, plant and equipment recorded for fiscal years ended June 30, 2025, 2024 and 2023 were $24.7 million, $18.1 million, and $13.8 million respectively.

[0000950170-25-109742:notes:270]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0000950170-25-109742:notes:271]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Segment long-lived assets: |  |  |  |  |  |  |
| Americas |  | $ | 167,499 |  |  | $ | 136,745 |  |
| EMEA |  |  | 40,299 |  |  |  | 33,715 |  |
| APAC |  |  | 10,550 |  |  |  | 11,499 |  |
| Total segment long-lived assets |  | $ | 218,348 |  |  | $ | 181,959 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-25-109742:notes:272]
13. Derivatives and Hedging

[0000950170-25-109742:notes:273]
Foreign Exchange Forward Contracts

[0000950170-25-109742:notes:274]
The Company uses derivative financial instruments to manage exposures to foreign currency that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts primarily to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies.

[0000950170-25-109742:notes:275]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying consolidated statements of operations. As of June 30, 2025 and 2024, foreign exchange forward currency contracts not designated as hedging instruments had total notional principal amounts of $57.2 million and $31.3 million, respectively. For the years ended June 30, 2025, 2024 and 2023 the net gains and losses recorded in the consolidated statements of operations from these contracts were net gains of $1.0 million, net losses of $0.3 million, and net losses of $0.4 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0000950170-25-109742:notes:276]
There were no foreign exchange forward currency contracts that were designated as hedging instruments at June 30, 2025 and 2024.

[0000950170-25-109742:notes:277]
For the fiscal years ended June 30, 2025, 2024 and 2023 the Company recognized foreign currency transaction net losses of $1.8 million, net gains of $0.6 million and net gains of $0.8 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-109742:notes:278]
14. Restructuring and Related Charges

[0000950170-25-109742:notes:279]
During fiscal years ended June 30, 2025, 2024 and 2023, the Company recorded restructuring and related charges of $1.5 million, $36.3 million and $2.9 million, respectively. The charges are reflected in “Restructuring and related charges” in the consolidated statements of operations.

[0000950170-25-109742:notes:280]
2025 Restructuring

[0000950170-25-109742:notes:281]
During fiscal 2025, the Company continued to execute the restructuring plans initiated in prior years and primarily incurred restructuring charges related to severance and benefits costs.

[0000950170-25-109742:notes:282]
2024 Restructuring

[0000950170-25-109742:notes:283]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company's research and development and sales and marketing functions to align the Company's workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”). During the fiscal years ended June 30, 2025, and 2024 the Company recorded restructuring charges of approximately $1.2 and  $11.0 million, respectively related to the Q3 2024 Plan, which primarily consisted of severance and benefits expenses, legal and consulting fees.

[0000950170-25-109742:notes:284]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the fiscal years ended June 30, 2025 and 2024, the Company recorded restructuring charges of approximately $0.1 million and $15.9 million, respectively, related to the Q2 2024 Plan, which primarily consisted of employee severance and benefits expenses, legal and consulting fees.

[0000950170-25-109742:notes:285]
Through June 30, 2025, the Company has incurred $28.3 million in restructuring charges under the Q2 2024 Plan and Q3 2024 Plan which primarily related to severance and benefits costs. The Company expects to substantially complete these ongoing restructuring plans by the end of calendar year 2025 and does not expect to incur any significant additional charges for the Q2 2024 Plan and the Q3 2024 Plan.

[0000950170-25-109742:notes:286]
During the first quarter of fiscal 2024, the Company initiated a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with the Company's business and strategic priorities (the “Q1 2024 Plan”). It consisted primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general and administrative functions. During the fiscal year ended June 30, 2024, the Company incurred charges of approximately $2.9 million related to the Q1 2024 Plan. As of June 30, 2024, the plan was completed.

[0000950170-25-109742:notes:287]
2023 Restructuring

[0000950170-25-109742:notes:288]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company moved engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move was to help reduce the cost of operating the Company's labs. During the fiscal year ended June 30, 2025, the Company recorded restructuring charges of $0.1 million related to the 2023 Plan. During the fiscal year ended June 30, 2024, the Company incurred restructuring charges of approximately $6.6 million primarily for moving costs and including accelerated depreciation on lab leasehold improvements of approximately $5.9 million. The

[0000950170-25-109742:notes:289]
Company expects to complete the 2023 Plan by the end of fiscal year 2026 and expects the charges related to the completion to be immaterial.

[0000950170-25-109742:notes:290]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. As of June 30, 2025 and 2024 the restructuring liability was approximately $0.7 million and $11.5 million, respectively.

[0000950170-25-109742:notes:291]
The following table summarizes the activity related to the Company’s restructuring and related liabilities during the following periods (in thousands):

[0000950170-25-109742:notes:292]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Balance at beginning of period |  | $ | 11,469 |  |  | $ | — |  |
| Period charges |  |  | 3,336 |  |  |  | 37,622 |  |
| Period reversals |  |  | (1,842 | ) |  |  | (1,301 | ) |
| Period non-cash adjustments |  |  | — |  |  |  | (5,940 | ) |
| Period payments |  |  | (12,270 | ) |  |  | (18,912 | ) |
| Balance at end of period |  | $ | 693 |  |  | $ | 11,469 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-109742:notes:293]
15. Income Taxes

[0000950170-25-109742:notes:294]
Income (loss) before income taxes is as follows (in thousands):

[0000950170-25-109742:notes:295]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | (38,551 | ) |  | $ | (72,684 | ) |  | $ | (2,179 | ) |
| Foreign |  |  | 42,824 |  |  |  | (4,815 | ) |  |  | 96,285 |  |
| Income (loss) before income taxes |  | $ | 4,273 |  |  | $ | (77,499 | ) |  | $ | 94,106 |  |

[0000950170-25-109742:notes:296]
The provision for income taxes for the years ended June 30, 2025, 2024 and 2023 consisted of the following (in thousands):

[0000950170-25-109742:notes:297]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Current: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 2,921 |  |  | $ | 1,340 |  |  | $ | 3,221 |  |
| State |  |  | 1,066 |  |  |  | 246 |  |  |  | 3,640 |  |
| Foreign |  |  | 8,932 |  |  |  | 6,843 |  |  |  | 9,086 |  |
| Total current |  |  | 12,919 |  |  |  | 8,429 |  |  |  | 15,947 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 412 |  |  |  | 404 |  |  |  | 368 |  |
| State |  |  | 251 |  |  |  | 252 |  |  |  | 433 |  |
| Foreign |  |  | (1,842 | ) |  |  | (620 | ) |  |  | (716 | ) |
| Total deferred |  |  | (1,179 | ) |  |  | 36 |  |  |  | 85 |  |
| Provision for income taxes |  | $ | 11,740 |  |  | $ | 8,465 |  |  | $ | 16,032 |  |

[0000950170-25-109742:notes:298]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (21 percent) to income before income taxes is explained below (in thousands):

[0000950170-25-109742:notes:299]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Tax at federal statutory rate |  | $ | 898 |  |  | $ | (16,275 | ) |  | $ | 19,762 |  |
| State income tax, net of federal benefit |  |  | 842 |  |  |  | 194 |  |  |  | 3,003 |  |
| Global intangible low-taxed income |  |  | 13,183 |  |  |  | 10,595 |  |  |  | 22,721 |  |
| US valuation allowance change – deferred tax movement |  |  | (10,417 | ) |  |  | 18,199 |  |  |  | (24,682 | ) |
| Research and development credits |  |  | (5,359 | ) |  |  | (7,746 | ) |  |  | (1,503 | ) |
| Tax impact of foreign earnings |  |  | 911 |  |  |  | 4,399 |  |  |  | (5,627 | ) |
| Foreign withholding taxes |  |  | 1,844 |  |  |  | 2,943 |  |  |  | 1,082 |  |
| Stock based compensation |  |  | 3,000 |  |  |  | (8,551 | ) |  |  | (1,980 | ) |
| Goodwill amortization |  |  | 549 |  |  |  | 549 |  |  |  | 730 |  |
| Nondeductible officer compensation |  |  | 10,629 |  |  |  | 8,667 |  |  |  | 4,582 |  |
| Nondeductible meals and entertainment |  |  | 256 |  |  |  | 319 |  |  |  | 324 |  |
| Foreign tax credits |  |  | (4,596 | ) |  |  | (4,828 | ) |  |  | (2,380 | ) |
| Provision for income taxes |  | $ | 11,740 |  |  | $ | 8,465 |  |  | $ | 16,032 |  |

[0000950170-25-109742:notes:300]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0000950170-25-109742:notes:301]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 16,561 |  |  | $ | 19,634 |  |
| Tax credit carry-forwards |  |  | 53,347 |  |  |  | 62,936 |  |
| Depreciation |  |  | 3,335 |  |  |  | 3,477 |  |
| Intangible amortization |  |  | 16,337 |  |  |  | 19,846 |  |
| Deferred revenue |  |  | 31,341 |  |  |  | 25,171 |  |
| Inventory write-downs |  |  | 8,048 |  |  |  | 13,819 |  |
| Other allowances and accruals |  |  | 40,835 |  |  |  | 33,031 |  |
| Stock based compensation |  |  | 4,800 |  |  |  | 7,445 |  |
| Deferred intercompany gain |  |  | 3,690 |  |  |  | 3,690 |  |
| Ireland goodwill amortization |  |  | 3,422 |  |  |  | 4,142 |  |
| Capitalization of research and development |  |  | 46,008 |  |  |  | 37,912 |  |
| Operating lease liability |  |  | 7,667 |  |  |  | 8,560 |  |
| Other |  |  | 911 |  |  |  | 858 |  |
| Total deferred tax assets |  |  | 236,302 |  |  |  | 240,521 |  |
| Valuation allowance |  |  | (207,313 | ) |  |  | (218,375 | ) |
| Total net deferred tax assets |  |  | 28,989 |  |  |  | 22,146 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Goodwill amortization |  |  | (16,335 | ) |  |  | (14,403 | ) |
| GAAP capitalized development costs |  |  | (3,787 | ) |  |  | — |  |
| Operating lease right of use asset |  |  | (6,264 | ) |  |  | (6,906 | ) |
| Prepaid commissions |  |  | (4,017 | ) |  |  | (3,499 | ) |
| Deferred tax liability on foreign withholdings |  |  | (969 | ) |  |  | (854 | ) |
| Total deferred tax liabilities |  |  | (31,372 | ) |  |  | (25,662 | ) |
| Net deferred tax liabilities |  | $ | (2,383 | ) |  | $ | (3,516 | ) |
| Recorded as: |  |  |  |  |  |  |
| Net non-current deferred tax assets |  |  | 4,650 |  |  |  | 4,462 |  |
| Net non-current deferred tax liabilities |  |  | (7,033 | ) |  |  | (7,978 | ) |
| Net deferred tax liabilities |  | $ | (2,383 | ) |  | $ | (3,516 | ) |

[0000950170-25-109742:notes:302]
The Company’s global valuation allowance decreased by $11.1 million in the fiscal year ended June 30, 2025 and increased by $23.1 million in the fiscal year ended June 30, 2024. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against certain non-U.S. deferred tax assets in Ireland and Brazil. The valuation allowance is determined by assessing both negative and positive available evidence to determine whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including historical losses, tax attributes expiring unutilized in recent years and the cyclical nature of the Company's business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as a portion of its Irish net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0000950170-25-109742:notes:303]
As of June 30, 2025, the Company had net operating loss carry-forwards (“NOLs”) for U.S. federal and state tax purposes of $8.7 million and $121.1million, respectively. As of June 30, 2025, the Company also had foreign NOLs in Australia, Brazil, France and Ireland of $4.2 million, $12.9 million, $2.9 million and $9.0 million respectively. As of June 30, 2025, the Company also had federal and state tax credit carry-forwards of $23.3 million and $38.0 million, respectively. These credit carry-forwards consist of research and development tax credits. The $8.7 million U.S. federal NOL carry-forwards are the remaining legacy Aerohive NOLs subject to an annual section 382 limitation, however, they have an indefinite carry-forward life. The state net operating losses of $121.1 million will begin to partially expire in the fiscal year ending June 30, 2026. The foreign net operating losses can generally be carried forward indefinitely. Federal research and development tax credits of $23.3 million will expire beginning in fiscal 2027, if not utilized. North Carolina state research and development tax credits of $0.8 million will expire beginning in the fiscal year ending June 30, 2026, if not utilized. California state research and development tax credits of $37.2 million do not expire and can be carried forward indefinitely.

[0000950170-25-109742:notes:304]
In June 2025, the Company performed an analysis under Section 382 of the IRC with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of these U.S. tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2024, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes. The Company also performed, in June 2020, a separate IRC section 382 analysis with respect to the NOLs and tax credits acquired from Aerohive and have determined that while the Company will be subject to an annual limitation, the Company should not be limited on the full utilization of the losses and credits during the statutory allowable carryforward period for the NOLs and credits.

[0000950170-25-109742:notes:305]
As of June 30, 2025, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $47.0 million. It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the U.S. The Company has reviewed its prior position on the reinvestment of earnings of certain foreign subsidiaries and has recorded a deferred tax liability of $1.0 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential taxes associated with repatriation of these earnings is $9.0 million.

[0000950170-25-109742:notes:306]
The Company is currently assessing the impact of the One Big Beautiful Bill Act (“OBBBA”) which was enacted on July 4, 2025. OBBBA includes significant provisions, including modification of certain provisions of the Tax Cuts and Jobs Act of 2017, the restoration of favorable tax treatment of domestic research expenditures and interest expenses and modification to the international tax framework. The legislation has multiple effective dates with certain provisions effective for fiscal year 2026 and others to be implemented in fiscal year 2027.

[0000950170-25-109742:notes:307]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world. Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire, Texas and North Carolina. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years ended June 2013 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years ended June 2003 forward due to net operating losses. Statutes related to material foreign jurisdictions are generally open for fiscal years ended June 2021 forward for Ireland and for tax year ended March 2021 forward for India.

[0000950170-25-109742:notes:308]
The U.S. tax rules require U.S. tax on foreign earnings, known as Global Intangible Low Taxed Income (“GILTI”). Under U.S. Generally Accepted Accounting Principles, taxpayers are allowed to make an accounting policy election of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes. The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred under the period cost method.

[0000950170-25-109742:notes:309]
As of June 30, 2025, the Company had $18.1 million of unrecognized tax benefits. If fully recognized in the future, $0.1 million would impact the effective tax rate, and $18.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not reasonably expect the amount of unrealized tax benefits to materially decrease during the next twelve months.

[0000950170-25-109742:notes:310]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0000950170-25-109742:notes:311]
| Balance at June 30, 2024 |  | $ | 18,217 |  |
| Decrease related to prior year tax positions |  |  | — |  |
| Increase related to prior year tax positions |  |  | 2 |  |
| Increase related to current year tax positions |  |  | 22 |  |
| Lapse of statute of limitations |  |  | (127 | ) |
| Balance at June 30, 2025 |  | $ | 18,114 |  |

[0000950170-25-109742:notes:312]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of income tax expense in the consolidated statements of operations and totaled less than $0.1 million for each of the years ended 2025, 2024 and 2023.


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-109742:notes:313]
16. Net Income (Loss) Per Share

[0000950170-25-109742:notes:314]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock outstanding during the period. Diluted income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock used in the basic net income (loss) per share calculation plus the dilutive effect of any shares subject to repurchase, options and unvested RSUs.

[0000950170-25-109742:notes:315]
The following table presents the calculation of basic and diluted net income (loss) per share (in thousands, except per share data):

[0000950170-25-109742:notes:316]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| Net income (loss) |  | $ | (7,467 | ) |  | $ | (85,964 | ) |  | $ | 78,074 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 132,331 |  |  |  | 129,288 |  |  |  | 129,473 |  |
| Options to purchase common stock |  |  | — |  |  |  | — |  |  |  | 708 |  |
| Restricted stock units |  |  | — |  |  |  | — |  |  |  | 3,468 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 132,331 |  |  |  | 129,288 |  |  |  | 133,649 |  |
| Net income (loss) per share – basic and diluted |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | (0.06 | ) |  | $ | (0.66 | ) |  | $ | 0.60 |  |
| Net income (loss) per share – diluted |  | $ | (0.06 | ) |  | $ | (0.66 | ) |  | $ | 0.58 |  |

[0000950170-25-109742:notes:317]
Potentially dilutive shares of common stock from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding RSUs, and the assumed issuance of common stock under the ESPP.

[0000950170-25-109742:notes:318]
The following securities were excluded from the computation of net income (loss) per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0000950170-25-109742:notes:319]
|  |  |  |  |  | Year Ended |  |  |  |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| Options to purchase common stock |  |  | 841 |  |  |  | 1,126 |  |  |  | — |  |
| Restricted stock units |  |  | 5,419 |  |  |  | 5,946 |  |  |  | 153 |  |
| Employee Stock Purchase Plan shares |  |  | 216 |  |  |  | 193 |  |  |  | 181 |  |
| Total shares excluded |  |  | 6,476 |  |  |  | 7,265 |  |  |  | 334 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-25-109742:notes:320]
On May 23, 2025, Kevin Rhodes, the Company's Executive Vice President and Chief Financial Officer adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 26,410 shares of the Company's common stock until May 30, 2026.
