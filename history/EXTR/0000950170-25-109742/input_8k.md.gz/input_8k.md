# EXTR 8-K — 0000950170-25-103531 filed 2025-08-06

## item codes, every 8-K on or before 2025-08-18

- 2025-08-06 0000950170-25-103531 — 2.02, 9.01
- 2025-04-30 0000950170-25-060571 — 2.02, 9.01
- 2025-02-18 0000950170-25-021808 — 8.01, 9.01
- 2025-01-29 0000950170-25-010203 — 2.02, 9.01
- 2024-11-15 0000950170-24-127573 — 5.07, 9.01
- 2024-10-30 0000950170-24-118589 — 2.02, 9.01
- 2024-08-07 0000950170-24-092273 — 2.02, 9.01
- 2024-05-01 0000950170-24-050891 — 2.02, 9.01
- 2024-01-31 0000950170-24-009144 — 2.02, 9.01
- 2024-01-08 0001193125-24-004497 — 5.02
- 2024-01-08 0000950170-24-002958 — 2.02, 9.01
- 2023-11-09 0000950170-23-062050 — 5.03, 5.07, 9.01
- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2025-08-18

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-25-103531:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0000950170-25-103531:8k_2_02:2]
EX-99.1

[0000950170-25-103531:8k_2_02:3]
Exhibit 99.1

[0000950170-25-103531:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0000950170-25-103531:8k_2_02:5]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2025 Financial Results

[0000950170-25-103531:8k_2_02:6]
Q4 revenue up 20% year-over-year, marking fifth consecutive quarter of sequential growth

[0000950170-25-103531:8k_2_02:7]
SaaS ARR up 24% YoY

[0000950170-25-103531:8k_2_02:8]
Morrisville, NC, August 6, 2025 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fourth quarter and fiscal year ended June 30, 2025. Q4 revenue grew 20 percent year-over-year and SaaS ARR by 24 percent, year-over-year.

[0000950170-25-103531:8k_2_02:9]
“We closed the fourth quarter with significant momentum, driven by sharp execution and growing demand for our solutions and services,” said Ed Meyercord, President and CEO of Extreme. “Five consecutive quarters of revenue growth and ARR jumping 24 percent year-over-year are clear indicators that our subscription model is gaining traction. Increased customer engagement in EMEA and APAC underscores our global momentum, highlighted by sizeable wins this quarter.”

[0000950170-25-103531:8k_2_02:10]
Meyercord continued, “I’m proud of our team for putting Extreme at the forefront of AI innovation in networking. Platform ONE is the first generally available AI for networking platform that provides a fundamentally advanced customer experience achieved through a mix of conversational and agentic AI capabilities. With Extreme Platform ONE we’re intent to redefine enterprise networking with end-to-end visibility, AI-powered automation, and the industry’s most intuitive and simplified licensing model. We are well-positioned to accelerate growth, gain market share, and lead this next wave of AI-driven innovation.”

[0000950170-25-103531:8k_2_02:11]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, “Fourth quarter results were driven by continuous sequential growth in revenue and prudent expense management leading to a strong cash flow quarter. Heading into the new fiscal year, our outlook is for a re-acceleration of overall revenue growth on a full-year basis, which we expect to translate to higher earnings and cash flow.”

[0000950170-25-103531:8k_2_02:12]
Fiscal Fourth Quarter Results:

[0000950170-25-103531:8k_2_02:13]
•
Revenue $307.0 million, up 19.6% year-over-year and up 7.9% quarter-over-quarter

[0000950170-25-103531:8k_2_02:14]
•
SaaS ARR $207.6 million, up 24.4% year-over-year and 13.0% quarter-over-quarter

[0000950170-25-103531:8k_2_02:15]
•
GAAP diluted loss per share $0.06, compared to GAAP diluted loss per share $0.42 last year and GAAP diluted EPS $0.03 last quarter

[0000950170-25-103531:8k_2_02:16]
•
Non-GAAP diluted EPS $0.25, compared to Non-GAAP diluted loss per share $0.08 last year and Non-GAAP diluted EPS $0.21 last quarter

[0000950170-25-103531:8k_2_02:17]
•
GAAP gross margin 61.6%, compared to 44.7% last year and 61.7% last quarter

[0000950170-25-103531:8k_2_02:18]
•
Non-GAAP gross margin 62.3%, compared to 45.4% last year and 62.3% last quarter

[0000950170-25-103531:8k_2_02:19]
•
GAAP operating loss margin 0.4%, compared to GAAP operating loss margin 19.1% last year and GAAP operating profit margin 3.6% last quarter

[0000950170-25-103531:8k_2_02:20]
•
Non-GAAP operating profit margin 15.2%, compared to Non-GAAP operating loss margin 4.6% last year and Non-GAAP operating profit margin 14.1% last quarter

[0000950170-25-103531:8k_2_02:21]
•
Shares repurchases amounted to $25.0 million during the quarter for a total of approximately 1.5 million shares

[0000950170-25-103531:8k_2_02:22]
Fiscal Year 2025 Results:

[0000950170-25-103531:8k_2_02:23]
•
Revenue $1,140.1 million, up 2% year-over-year

[0000950170-25-103531:8k_2_02:24]
•
GAAP diluted loss per share $0.06, compared to GAAP diluted loss per share $0.66 last year

[0000950170-25-103531:8k_2_02:25]
•
Non-GAAP diluted EPS $0.84, compared to Non-GAAP diluted EPS $0.33 last year

[0000950170-25-103531:8k_2_02:26]
•
GAAP gross margin 62.2%, compared to GAAP gross margin 56.5% last year

[0000950170-25-103531:8k_2_02:27]
•
Non-GAAP gross margin 62.9%, compared to Non-GAAP gross margin 57.2% last year

[0000950170-25-103531:8k_2_02:28]
•
GAAP operating profit margin 1.5%, compared to GAAP operating loss margin 5.8% last year

[0000950170-25-103531:8k_2_02:29]
•
Non-GAAP operating profit margin 14.2%, compared to Non-GAAP operating profit margin 6.2% in the prior year

[0000950170-25-103531:8k_2_02:30]
Liquidity:

[0000950170-25-103531:8k_2_02:31]
•
Q4 ending cash balance was $231.7 million, an increase of $46.2 million from the end of Q3 2025 and an increase of $75.0 million from the end of Q4 in the prior year.

[0000950170-25-103531:8k_2_02:32]
•
Q4 net cash was $51.7 million, an increase of $48.7 million from net cash of $3.0 million at the end of Q3 2025 and an increase of $85.0 million from net debt of $33.3 million at the end of Q4 in the prior year.

[0000950170-25-103531:8k_2_02:33]
Recent Key Highlights:

[0000950170-25-103531:8k_2_02:34]
•
Extreme is now the first and only networking vendor to deliver conversational, multimodal, and agentic AI fully integrated into the networking experience with Extreme Platform ONE™, which was made generally available last month. Interest in the platform has been strong.

[0000950170-25-103531:8k_2_02:35]
•
Extreme Connect 2025 in Paris, France, was the company’s largest user event to date, attracting nearly 1,000 in-person attendees and thousands of livestream viewers. Attendees experienced live demos of Extreme Platform ONE in action, gained insights from top industry leaders—including executives from Microsoft and Intel—and participated in hands-on technical breakouts.

[0000950170-25-103531:8k_2_02:36]
•
Extreme continued to extend its footprint within the Japanese government with two new multimillion dollar deals. Extreme and partners will deploy Extreme Fabric from core to the branch using ExtremeCloud SD-WAN devices, managed from ExtremeCloud IQ. This can improve the efficiency of the government employees by making it convenient to securely connect to the network anywhere across the country.

[0000950170-25-103531:8k_2_02:37]
•
MetLife Stadium selected Extreme to displace a large incumbent provider and replace its legacy wireless infrastructure. This builds on MetLife's existing Extreme wired network to deliver a modernized, high-density Wi-Fi 6E experience. The upgrade enhances overhead and under-seat wireless connectivity to support major events like NFL games, concerts, and high-profile international soccer games.

[0000950170-25-103531:8k_2_02:38]
•
ENAIRE, the fourth largest air navigation service provider in Europe, which provides services for more than 2.3 million aircraft movements across Spain each year, recently deployed

[0000950170-25-103531:8k_2_02:39]
Extreme's wired solutions to improve connectivity and network performance for its mission-critical operations.

[0000950170-25-103531:8k_2_02:40]
•
Pinnacle Bank Arena, owned by the City of Lincoln, Nebraska, and managed by ASM Global, is home to year-round concerts and events - including the University of Nebraska men’s and women’s basketball teams – is now fully supported by Extreme's wired and wireless solutions. The arena selected Extreme’s 6 GHz under-seat and overhead Wi-Fi solutions to power a more modern fan and operational experience, including digital ticketing, concessions, Audio Visual, and IP-based TV improvements.

[0000950170-25-103531:8k_2_02:41]
•
Hendrick Motorsports has deployed wired and wireless solutions from Extreme to upgrade and replace legacy hardware across its 150-acre campus. The leading professional race team will now have the improved coverage, connectivity, and security necessary for onsite team operations, and Extreme Fabric will deliver the security, flexibility, and visibility necessary for Hendrick’s separate R&D facilities.

[0000950170-25-103531:8k_2_02:42]
•
Surrey & Sussex Healthcare NHS Trust (“SASH”) is a network of healthcare facilities that supports a population of 740,000+ in southern England. It deployed Extreme to improve the Wi-Fi connectivity that is essential to delivering continuity of patient care. The healthcare network will also leverage ExtremeCloud IQ and Extreme Fabric for flexible, centralized and secure network management, enforcement and visualization.

[0000950170-25-103531:8k_2_02:43]
•
Extreme was named one of Newsweek’s World’s Greenest Companies in 2025, based on research of publicly available data provided by GIST Impact as available through March 1, 2025. Extreme was also a winner in the 2025 Newsweek AI Impact Awards for innovation of its internal Marketing and Sales AI Assistant, which has significantly boosted productivity for sales and marketing teams as well as Extreme partners.

[0000950170-25-103531:8k_2_02:44]
Fiscal Q4 2025 and Full Year 2025 Financial Results:

[0000950170-25-103531:8k_2_02:45]
(in millions, except percentages and per share information)

[0000950170-25-103531:8k_2_02:46]
|  |  | GAAP Results |
|  |  | Three Months Ended |  |  | Year Ended |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | Change |  |  | June 30,2025 |  |  | June 30,2024 |  |  | Change |
| Product |  | $ | 191.9 |  |  | $ | 152.8 |  |  | $ | 39.1 |  |  | $ | 704.5 |  |  | $ | 699.3 |  |  | $ | 5.2 |  |  |
| Subscription and support |  |  | 115.1 |  |  |  | 103.9 |  |  |  | 11.2 |  |  |  | 435.6 |  |  |  | 417.9 |  |  |  | 17.7 |  |  |
| Total net revenue |  | $ | 307.0 |  |  | $ | 256.7 |  |  | $ | 50.3 |  |  | $ | 1,140.1 |  |  | $ | 1,117.2 |  |  | $ | 22.9 |  |  |
| Gross margin |  |  | 61.6 | % |  |  | 44.7 | % |  |  | 16.9 | % |  |  | 62.2 | % |  |  | 56.5 | % |  |  | 5.7 | % |  |
| Operating margin |  |  | (0.4 | )% |  |  | (19.1 | )% |  |  | 18.6 | % |  |  | 1.5 | % |  |  | (5.8 | )% |  |  | 7.3 | % |  |
| Net loss |  | $ | (7.8 | ) |  | $ | (54.2 | ) |  | $ | 46.4 |  |  | $ | (7.5 | ) |  | $ | (86.0 | ) |  | $ | 78.5 |  |  |
| Net loss per diluted share |  | $ | (0.06 | ) |  | $ | (0.42 | ) |  | $ | 0.36 |  |  | $ | (0.06 | ) |  | $ | (0.66 | ) |  | $ | 0.60 |  |  |

[0000950170-25-103531:8k_2_02:47]
|  |  | Non-GAAP Results |
|  |  | Three Months Ended |  |  | Year Ended |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | Change |  |  | June 30,2025 |  |  | June 30,2024 |  |  | Change |
| Product |  | $ | 191.9 |  |  | $ | 152.8 |  |  | $ | 39.1 |  |  | $ | 704.5 |  |  | $ | 699.3 |  |  | $ | 5.2 |  |  |
| Subscription and support |  |  | 115.1 |  |  |  | 103.9 |  |  |  | 11.2 |  |  |  | 435.6 |  |  |  | 417.9 |  |  |  | 17.7 |  |  |
| Total net revenue |  | $ | 307.0 |  |  | $ | 256.7 |  |  | $ | 50.3 |  |  | $ | 1,140.1 |  |  | $ | 1,117.2 |  |  | $ | 22.9 |  |  |
| Gross margin |  |  | 62.3 | % |  |  | 45.4 | % |  |  | 16.9 | % |  |  | 62.9 | % |  |  | 57.2 | % |  |  | 5.7 | % |  |
| Operating margin |  |  | 15.2 | % |  |  | (4.6 | )% |  |  | 19.8 | % |  |  | 14.2 | % |  |  | 6.2 | % |  |  | 8.0 | % |  |
| Net income (loss) |  | $ | 33.5 |  |  | $ | (9.9 | ) |  | $ | 43.4 |  |  | $ | 112.4 |  |  | $ | 43.4 |  |  | $ | 69.1 |  |  |
| Net income (loss) per diluted share |  | $ | 0.25 |  |  | $ | (0.08 | ) |  | $ | 0.33 |  |  | $ | 0.84 |  |  | $ | 0.33 |  |  | $ | 0.51 |  |  |

[0000950170-25-103531:8k_2_02:48]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by (used in) operating activities, less purchases of property, equipment and capitalized software development costs.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, equipment and capitalized software development costs, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in millions):

[0000950170-25-103531:8k_2_02:49]
| Free Cash Flow | Three Months Ended | Year Ended |  |
|  | June 30,2025 |  |  | June 30,2024 |  |  | June 30,2025 |  |  | June 30,2024 |  |
| Cash flow provided by operations | $ | 81.9 |  |  | $ | 15.4 |  |  | $ | 152.0 |  |  | $ | 55.5 |  |
| Less: Capital expenditures for property, equipment and capitalized software development costs |  | (6.6 | ) |  |  | (4.5 | ) |  |  | (24.7 | ) |  |  | (18.1 | ) |
| Total free cash flow | $ | 75.3 |  |  | $ | 10.9 |  |  | $ | 127.3 |  |  | $ | 37.4 |  |

[0000950170-25-103531:8k_2_02:50]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud IQ and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue or deferred revenue that are accounted for under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0000950170-25-103531:8k_2_02:51]
Gross debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0000950170-25-103531:8k_2_02:52]
Net cash (debt): is defined as cash and cash equivalents minus gross debt, as shown in the table below (in millions):

[0000950170-25-103531:8k_2_02:53]
| Cash and cash equivalents |  |  | Gross debt |  |  | Net cash (debt) |  |
| $ | 231.7 |  |  | $ | 180.0 |  |  | $ | 51.7 |  |

[0000950170-25-103531:8k_2_02:54]
Business Outlook:

[0000950170-25-103531:8k_2_02:55]
For its first quarter fiscal 2026, ending September 30, 2025, the Company is targeting:

[0000950170-25-103531:8k_2_02:56]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ1'26 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 292.0 |  |  | $ | 300.0 |  |
| Gross margin |  | 61.1 | % |  |  | 61.6 | % |
| Operating margin |  | 0.2 | % |  |  | 2.2 | % |
| Earnings (loss) per share | $ | (0.03 | ) |  | $ | 0.02 |  |
| Shares outstanding used in calculating GAAP EPS |  | 133.2 |  |  |  | 134.7 |  |
| FQ1'26 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 292.0 |  |  | $ | 300.0 |  |
| Gross margin |  | 61.9 | % |  |  | 62.3 | % |
| Operating margin |  | 12.7 | % |  |  | 14.5 | % |
| Earnings per share | $ | 0.20 |  |  | $ | 0.23 |  |
| Diluted Shares outstanding used in calculating non-GAAP EPS |  | 134.7 |  |  |  | 134.7 |  |

[0000950170-25-103531:8k_2_02:57]
The following table shows the GAAP to non-GAAP reconciliation for Q1 FY'26 guidance:

[0000950170-25-103531:8k_2_02:58]
|  | FQ1'26 |  |
|  | Gross Margin |  | Operating Margin |  | Earnings per Share |  |
| GAAP | 61.1% - 61.6% |  | 0.2% - 2.2% |  | ($0.03) - $0.02 |  |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation | 0.5% - 0.6% |  | 7.2% - 7.4% |  | 0.16 - 0.17 |  |
| Amortization of product intangibles | 0.2% |  | 0.2% |  | — |  |
| Amortization of non-product intangibles | — |  | 0.2% |  | — |  |
| Litigation charges | — |  | 2.7% |  | 0.06 |  |
| System transition cost | — |  | 2.0% |  | 0.04 |  |
| Tax adjustment | — |  | — |  | (0.05) - (0.04) |  |
| Non-GAAP | 61.9% - 62.3% |  | 12.7% - 14.5% |  | $0.20 - $0.23 |  |

[0000950170-25-103531:8k_2_02:59]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0000950170-25-103531:8k_2_02:60]
For the full year fiscal 2026, ending June 30, 2026, the Company is targeting (in millions):

[0000950170-25-103531:8k_2_02:61]
|  | Low-End |  |  | High-End |  |
| FY'26 Guidance |  |  |  |  |  |
| Total net revenue | $ | 1,228.0 |  |  | $ | 1,238.0 |  |

[0000950170-25-103531:8k_2_02:62]
Conference Call:

[0000950170-25-103531:8k_2_02:63]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the fourth quarter and fiscal year 2025 results as well as the business outlook for the first quarter of fiscal 2026 ending September 30, 2025, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Registration Link) and you will be provided with dial in details. If you would like to participate in the Q&A, please register here: Q&A Registration Link. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0000950170-25-103531:8k_2_02:64]
About Extreme:

[0000950170-25-103531:8k_2_02:65]
Extreme Networks, Inc. (EXTR) is a leader in AI-driven cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence, analytics, and automation. Tens of thousands of customers globally trust our AI-driven cloud networking solutions and industry-leading support to enable businesses to drive value, foster innovation, and overcome extreme challenges.  For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, X (Formerly Twitter), Facebook or Instagram

[0000950170-25-103531:8k_2_02:66]
Extreme Networks, ExtremeCloud, Extreme Platform ONE, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0000950170-25-103531:8k_2_02:67]
Non-GAAP Financial Measures:

[0000950170-25-103531:8k_2_02:68]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income (loss), non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, debt refinancing charges and the tax effect of non-GAAP adjustments. The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0000950170-25-103531:8k_2_02:69]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated. These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0000950170-25-103531:8k_2_02:70]
Forward-Looking Statements:

[0000950170-25-103531:8k_2_02:71]
For more information about factors that could cause actual results and other future events to differ materially from those suggested or indicated by such forward-looking statements, see “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2024, Quarterly Reports on Form 10-Q for the quarters ended September 30, 2024, December 31, 2024 and March 31, 2025 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov). As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0000950170-25-103531:8k_2_02:72]
###

[0000950170-25-103531:8k_2_02:73]
EXTREME NETWORKS, INC.

[0000950170-25-103531:8k_2_02:74]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-25-103531:8k_2_02:75]
(In thousands, except per share amounts)

[0000950170-25-103531:8k_2_02:76]
(Unaudited)

[0000950170-25-103531:8k_2_02:77]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 231,745 |  |  | $ | 156,699 |  |
| Accounts receivable, net |  |  | 126,708 |  |  |  | 89,518 |  |
| Inventories |  |  | 102,578 |  |  |  | 141,032 |  |
| Prepaid expenses and other current assets |  |  | 74,265 |  |  |  | 79,677 |  |
| Total current assets |  |  | 535,296 |  |  |  | 466,926 |  |
| Property and equipment, net |  |  | 44,366 |  |  |  | 43,744 |  |
| Operating lease right-of-use assets, net |  |  | 38,655 |  |  |  | 44,145 |  |
| Goodwill |  |  | 399,574 |  |  |  | 393,709 |  |
| Intangible assets, net |  |  | 6,541 |  |  |  | 10,613 |  |
| Other assets |  |  | 128,786 |  |  |  | 83,457 |  |
| Total assets |  | $ | 1,153,218 |  |  | $ | 1,042,594 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 63,939 |  |  | $ | 51,423 |  |
| Accrued compensation and benefits |  |  | 62,895 |  |  |  | 42,064 |  |
| Accrued warranty |  |  | 9,684 |  |  |  | 10,942 |  |
| Current portion of deferred revenue |  |  | 325,078 |  |  |  | 306,114 |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $729 and $674, respectively |  |  | 14,271 |  |  |  | 9,326 |  |
| Current portion, operating lease liabilities |  |  | 11,456 |  |  |  | 10,547 |  |
| Other accrued liabilities |  |  | 100,552 |  |  |  | 87,172 |  |
| Total current liabilities |  |  | 587,875 |  |  |  | 517,588 |  |
| Deferred revenue, less current portion |  |  | 292,415 |  |  |  | 268,909 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $1,276 and $1,735, respectively |  |  | 163,724 |  |  |  | 178,265 |  |
| Operating lease liabilities, less current portion |  |  | 33,991 |  |  |  | 41,466 |  |
| Deferred income taxes |  |  | 7,033 |  |  |  | 7,978 |  |
| Other long-term liabilities |  |  | 2,596 |  |  |  | 3,106 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 152,673 and 148,503 shares issued, respectively; 132,064 and 130,284 shares outstanding, respectively |  |  | 153 |  |  |  | 149 |  |
| Additional paid-in-capital |  |  | 1,298,791 |  |  |  | 1,220,379 |  |
| Accumulated other comprehensive loss |  |  | (8,137 | ) |  |  | (15,483 | ) |
| Accumulated deficit |  |  | (949,429 | ) |  |  | (941,962 | ) |
| Treasury stock at cost, 20,609 and 18,219 shares, respectively |  |  | (275,794 | ) |  |  | (237,801 | ) |
| Total stockholders’ equity |  |  | 65,584 |  |  |  | 25,282 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,153,218 |  |  | $ | 1,042,594 |  |

[0000950170-25-103531:8k_2_02:78]
EXTREME NETWORKS, INC.

[0000950170-25-103531:8k_2_02:79]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-25-103531:8k_2_02:80]
(In thousands, except per share amounts)

[0000950170-25-103531:8k_2_02:81]
(Unaudited)

[0000950170-25-103531:8k_2_02:82]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30,2025 |  |  | June 30,2024 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 191,857 |  |  | $ | 152,721 |  |  | $ | 704,462 |  |  | $ | 699,257 |  |
| Subscription and support |  |  | 115,146 |  |  |  | 103,932 |  |  |  | 435,605 |  |  |  | 417,946 |  |
| Total net revenues |  |  | 307,003 |  |  |  | 256,653 |  |  |  | 1,140,067 |  |  |  | 1,117,203 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 82,766 |  |  |  | 114,893 |  |  |  | 300,831 |  |  |  | 365,759 |  |
| Subscription and support |  |  | 35,149 |  |  |  | 27,136 |  |  |  | 130,109 |  |  |  | 120,613 |  |
| Total cost of revenues |  |  | 117,915 |  |  |  | 142,029 |  |  |  | 430,940 |  |  |  | 486,372 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 109,091 |  |  |  | 37,828 |  |  |  | 403,631 |  |  |  | 333,498 |  |
| Subscription and support |  |  | 79,997 |  |  |  | 76,796 |  |  |  | 305,496 |  |  |  | 297,333 |  |
| Total gross profit |  |  | 189,088 |  |  |  | 114,624 |  |  |  | 709,127 |  |  |  | 630,831 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 56,469 |  |  |  | 46,565 |  |  |  | 221,459 |  |  |  | 211,931 |  |
| Sales and marketing |  |  | 86,440 |  |  |  | 81,020 |  |  |  | 327,563 |  |  |  | 345,802 |  |
| General and administrative |  |  | 47,419 |  |  |  | 25,468 |  |  |  | 139,621 |  |  |  | 99,938 |  |
| Restructuring and related charges (benefits) |  |  | (379 | ) |  |  | 10,009 |  |  |  | 1,492 |  |  |  | 36,321 |  |
| Amortization of intangible assets |  |  | 515 |  |  |  | 510 |  |  |  | 2,043 |  |  |  | 2,041 |  |
| Total operating expenses |  |  | 190,464 |  |  |  | 163,572 |  |  |  | 692,178 |  |  |  | 696,033 |  |
| Operating income (loss) |  |  | (1,376 | ) |  |  | (48,948 | ) |  |  | 16,949 |  |  |  | (65,202 | ) |
| Interest income |  |  | 1,656 |  |  |  | 661 |  |  |  | 4,313 |  |  |  | 4,556 |  |
| Interest expense |  |  | (3,530 | ) |  |  | (4,220 | ) |  |  | (15,928 | ) |  |  | (16,986 | ) |
| Other income (expense), net |  |  | (616 | ) |  |  | (240 | ) |  |  | (1,061 | ) |  |  | 133 |  |
| Income (loss) before income taxes |  |  | (3,866 | ) |  |  | (52,747 | ) |  |  | 4,273 |  |  |  | (77,499 | ) |
| Provision for income taxes |  |  | 3,937 |  |  |  | 1,456 |  |  |  | 11,740 |  |  |  | 8,465 |  |
| Net loss |  | $ | (7,803 | ) |  | $ | (54,203 | ) |  | $ | (7,467 | ) |  | $ | (85,964 | ) |
| Basic and diluted loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share – basic |  | $ | (0.06 | ) |  | $ | (0.42 | ) |  | $ | (0.06 | ) |  | $ | (0.66 | ) |
| Net loss per share – diluted |  | $ | (0.06 | ) |  | $ | (0.42 | ) |  | $ | (0.06 | ) |  | $ | (0.66 | ) |
| Shares used in per share calculation – basic |  |  | 132,808 |  |  |  | 130,093 |  |  |  | 132,331 |  |  |  | 129,288 |  |
| Shares used in per share calculation – diluted |  |  | 132,808 |  |  |  | 130,093 |  |  |  | 132,331 |  |  |  | 129,288 |  |

[0000950170-25-103531:8k_2_02:83]
EXTREME NETWORKS, INC.

[0000950170-25-103531:8k_2_02:84]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-25-103531:8k_2_02:85]
(In thousands)

[0000950170-25-103531:8k_2_02:86]
(Unaudited)

[0000950170-25-103531:8k_2_02:87]
|  |  | Year Ended |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (7,467 | ) |  | $ | (85,964 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 14,704 |  |  |  | 24,134 |  |
| Amortization of intangible assets |  |  | 4,514 |  |  |  | 5,313 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 9,887 |  |  |  | 11,455 |  |
| Provision for credit losses |  |  | 157 |  |  |  | 210 |  |
| Share-based compensation |  |  | 82,314 |  |  |  | 76,763 |  |
| Deferred income taxes |  |  | (820 | ) |  |  | 80 |  |
| Provision for excess and obsolete inventory |  |  | 2,618 |  |  |  | 71,068 |  |
| Non-cash interest expense |  |  | 1,214 |  |  |  | 1,060 |  |
| Other |  |  | 3,532 |  |  |  | (2,496 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (37,347 | ) |  |  | 92,316 |  |
| Inventories |  |  | 27,181 |  |  |  | (116,434 | ) |
| Prepaid expenses and other assets |  |  | (23,118 | ) |  |  | (21,212 | ) |
| Accounts payable |  |  | 12,709 |  |  |  | (48,012 | ) |
| Accrued compensation and benefits |  |  | 18,685 |  |  |  | (29,136 | ) |
| Operating lease liabilities |  |  | (11,056 | ) |  |  | (11,528 | ) |
| Deferred revenue |  |  | 37,722 |  |  |  | 76,240 |  |
| Other current and long-term liabilities |  |  | 16,602 |  |  |  | 11,629 |  |
| Net cash provided by operating activities |  |  | 152,031 |  |  |  | 55,486 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures for property, equipment and capitalized software development costs |  |  | (24,713 | ) |  |  | (18,121 | ) |
| Net cash used in investing activities |  |  | (24,713 | ) |  |  | (18,121 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Net payments on revolving facility |  |  | — |  |  |  | (55,000 | ) |
| Payments on debt obligations |  |  | (10,000 | ) |  |  | (10,000 | ) |
| Payments on debt financing costs |  |  | (695 | ) |  |  | — |  |
| Repurchase of common stock |  |  | (37,993 | ) |  |  | (49,855 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (3,898 | ) |  |  | (30,123 | ) |
| Net cash used in financing activities |  |  | (52,586 | ) |  |  | (114,978 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | 314 |  |  |  | (514 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 75,046 |  |  |  | (78,127 | ) |
| Cash and cash equivalents at beginning of period |  |  | 156,699 |  |  |  | 234,826 |  |
| Cash and cash equivalents at end of period |  | $ | 231,745 |  |  | $ | 156,699 |  |

[0000950170-25-103531:8k_2_02:88]
Extreme Networks, Inc.

[0000950170-25-103531:8k_2_02:89]
Non-GAAP Measures of Financial Performance

[0000950170-25-103531:8k_2_02:90]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income (loss), non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and free cash flow.

[0000950170-25-103531:8k_2_02:91]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0000950170-25-103531:8k_2_02:92]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0000950170-25-103531:8k_2_02:93]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0000950170-25-103531:8k_2_02:94]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, debt refinancing charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0000950170-25-103531:8k_2_02:95]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0000950170-25-103531:8k_2_02:96]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0000950170-25-103531:8k_2_02:97]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0000950170-25-103531:8k_2_02:98]
Restructuring and related charges. Restructuring and related charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0000950170-25-103531:8k_2_02:99]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution and our configure, price, quote solution. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0000950170-25-103531:8k_2_02:100]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for non-recurring litigations offset by any proceeds received or expected to be received from insurance.

[0000950170-25-103531:8k_2_02:101]
Debt refinancing charges. Debt refinancing charges consist of costs that were not capitalizable and are included in other income (expense), that occurred in conjunction with the amendments related to our outstanding credit facility.

[0000950170-25-103531:8k_2_02:102]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0000950170-25-103531:8k_2_02:103]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0000950170-25-103531:8k_2_02:104]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Canadian, German and Indian subsidiaries which perform research and development and sales and marketing activities for the Company, as well as the Company’s Irish trading subsidiaries.

[0000950170-25-103531:8k_2_02:105]
EXTREME NETWORKS, INC.

[0000950170-25-103531:8k_2_02:106]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-25-103531:8k_2_02:107]
GAAP TO NON-GAAP RECONCILIATION

[0000950170-25-103531:8k_2_02:108]
(In thousands, except percentages and per share amounts)

[0000950170-25-103531:8k_2_02:109]
(Unaudited)

[0000950170-25-103531:8k_2_02:110]
| Revenues | Three Months Ended | Year Ended |  |
|  | June 30,2025 |  |  | June 30,2024 |  |  | June 30,2025 |  |  | June 30,2024 |  |
| Revenues – GAAP | $ | 307,003 |  |  | $ | 256,653 |  |  | $ | 1,140,067 |  |  | $ | 1,117,203 |  |

[0000950170-25-103531:8k_2_02:111]
| Non-GAAP Gross Margin | Three Months Ended | Year Ended |  |
|  | June 30,2025 |  |  | June 30,2024 |  |  | June 30,2025 |  |  | June 30,2024 |  |
| Gross profit – GAAP | $ | 189,088 |  |  | $ | 114,624 |  |  | $ | 709,127 |  |  | $ | 630,831 |  |
| Gross margin – GAAP percentage |  | 61.6 | % |  |  | 44.7 | % |  |  | 62.2 | % |  |  | 56.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 700 |  |  |  | 547 |  |  |  | 2,661 |  |  |  | 1,899 |  |
| Share-based compensation expense, Subscription and support |  | 719 |  |  |  | 700 |  |  |  | 2,912 |  |  |  | 2,994 |  |
| Amortization of intangibles, Product |  | 625 |  |  |  | 594 |  |  |  | 2,400 |  |  |  | 2,930 |  |
| Amortization of intangibles, Subscription and support |  | — |  |  |  | — |  |  |  | — |  |  |  | 272 |  |
| Total adjustments to GAAP gross profit | $ | 2,044 |  |  | $ | 1,841 |  |  | $ | 7,973 |  |  | $ | 8,095 |  |
| Gross profit – non-GAAP | $ | 191,132 |  |  | $ | 116,465 |  |  | $ | 717,100 |  |  | $ | 638,926 |  |
| Gross margin – non-GAAP percentage |  | 62.3 | % |  |  | 45.4 | % |  |  | 62.9 | % |  |  | 57.2 | % |

[0000950170-25-103531:8k_2_02:112]
| Non-GAAP Operating Margin | Three Months Ended | Year Ended |  |
|  | June 30,2025 |  |  | June 30,2024 |  |  | June 30,2025 |  |  | June 30,2024 |  |
| GAAP operating income (loss) | $ | (1,376 | ) |  | $ | (48,948 | ) |  | $ | 16,949 |  |  | $ | (65,202 | ) |
| GAAP operating margin |  | (0.4 | )% |  |  | (19.1 | )% |  |  | 1.5 | % |  |  | (5.8 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,419 |  |  |  | 1,247 |  |  |  | 5,573 |  |  |  | 4,893 |  |
| Share-based compensation expense, R&D |  | 4,296 |  |  |  | 3,648 |  |  |  | 17,154 |  |  |  | 16,686 |  |
| Share-based compensation expense, S&M |  | 6,952 |  |  |  | 6,318 |  |  |  | 28,393 |  |  |  | 26,524 |  |
| Share-based compensation expense, G&A |  | 8,074 |  |  |  | 6,841 |  |  |  | 31,194 |  |  |  | 28,660 |  |
| Restructuring and related (benefit) charges |  | (379 | ) |  |  | 10,009 |  |  |  | 1,492 |  |  |  | 36,321 |  |
| Litigation charges |  | 22,006 |  |  |  | 5,127 |  |  |  | 34,722 |  |  |  | 10,545 |  |
| System transition costs |  | 4,631 |  |  |  | 2,816 |  |  |  | 21,550 |  |  |  | 5,262 |  |
| Amortization of intangibles |  | 1,140 |  |  |  | 1,104 |  |  |  | 4,443 |  |  |  | 5,243 |  |
| Total adjustments to GAAP operating income (loss) | $ | 48,139 |  |  | $ | 37,110 |  |  | $ | 144,521 |  |  | $ | 134,134 |  |
| Non-GAAP operating income (loss) | $ | 46,763 |  |  | $ | (11,838 | ) |  | $ | 161,470 |  |  | $ | 68,932 |  |
| Non-GAAP operating margin |  | 15.2 | % |  |  | (4.6 | )% |  |  | 14.2 | % |  |  | 6.2 | % |

[0000950170-25-103531:8k_2_02:113]
| Non-GAAP Net Income (Loss) | Three Months Ended | Year Ended |  |
|  | June 30,2025 |  |  | June 30,2024 |  |  | June 30,2025 |  |  | June 30,2024 |  |
| GAAP net loss | $ | (7,803 | ) |  | $ | (54,203 | ) |  | $ | (7,467 | ) |  | $ | (85,964 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 20,741 |  |  |  | 18,054 |  |  |  | 82,314 |  |  |  | 76,763 |  |
| Restructuring and related (benefit) charges |  | (379 | ) |  |  | 10,009 |  |  |  | 1,492 |  |  |  | 36,321 |  |
| Litigation charges |  | 22,006 |  |  |  | 5,127 |  |  |  | 34,722 |  |  |  | 10,545 |  |
| System transition costs |  | 4,631 |  |  |  | 2,816 |  |  |  | 21,550 |  |  |  | 5,262 |  |
| Amortization of intangibles |  | 1,140 |  |  |  | 1,104 |  |  |  | 4,443 |  |  |  | 5,243 |  |
| Debt refinancing charges, Other income (expense) |  | — |  |  |  | — |  |  |  | 79 |  |  |  | — |  |
| Tax effect of non-GAAP adjustments |  | (6,843 | ) |  |  | 7,230 |  |  |  | (24,709 | ) |  |  | (4,815 | ) |
| Total adjustments to GAAP net loss | $ | 41,296 |  |  | $ | 44,340 |  |  | $ | 119,891 |  |  | $ | 129,319 |  |
| Non-GAAP net income (loss) | $ | 33,493 |  |  | $ | (9,863 | ) |  | $ | 112,424 |  |  | $ | 43,355 |  |
| Earnings (loss) per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net loss per share – diluted | $ | (0.06 | ) |  | $ | (0.42 | ) |  | $ | (0.06 | ) |  | $ | (0.66 | ) |
| Non-GAAP net income (loss) per share – diluted | $ | 0.25 |  |  | $ | (0.08 | ) |  | $ | 0.84 |  |  | $ | 0.33 |  |
| Shares used in net income (loss) per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP shares used in per share calculation – basic |  | 132,808 |  |  |  | 130,093 |  |  |  | 132,331 |  |  |  | 129,288 |  |
| Potentially dilutive equity awards |  | 1,492 |  |  |  | 0 |  |  |  | 1,676 |  |  |  | 2,816 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 134,300 |  |  |  | 130,093 |  |  |  | 134,007 |  |  |  | 132,104 |  |
