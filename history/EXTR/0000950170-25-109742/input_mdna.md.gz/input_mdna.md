# EXTR MD&A — 0000950170-25-109742


## mdna

[0000950170-25-109742:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-25-109742:mdna:2]
Business Overview

[0000950170-25-109742:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Part II, Item 8 of this Annual Report on Form 10-K.

[0000950170-25-109742:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Annual Report on Form 10-K, which have been prepared in accordance with U.S. generally accepted accounting principles. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0000950170-25-109742:mdna:5]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we,” “us” and “our”) is a leading provider of cloud networking solutions and industry leading services and support. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. Our corporate headquarters are located in Morrisville, North Carolina. We derive a majority of our revenues from the sale of our networking equipment, software subscriptions and services, and related maintenance contracts.

[0000950170-25-109742:mdna:6]
Extreme is a leader in AI-powered cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence, analytics, and automation and have industry leading support services. Tens of thousands of customers globally trust Extreme to drive value, foster innovation, and overcome extreme challenges. Extreme also designs, develops, and manufactures wired, wireless, and SD-WAN infrastructure equipment. Our Extreme Platform ONE solution, announced in December 2024 and made generally available in July 2025, is a technology platform that reduces the complexity for enterprises by seamlessly integrating networking, security and AI solutions into a single platform. AI-powered automation includes conversational, interactive and autonomous AI agents—to assist, advise and accelerate the productivity of networking, security and business teams—designed to reduce the time to complete complex tasks.

[0000950170-25-109742:mdna:7]
Our global footprint provides service to some of the world’s leading names in business across verticals such as large sports and entertainment venues, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0000950170-25-109742:mdna:8]
Fiscal Year

[0000950170-25-109742:mdna:9]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2025” or “2025"; “fiscal 2024” or “2024”; “fiscal 2023” or “2023” represent the fiscal years ended, respectively.

[0000950170-25-109742:mdna:10]
Results of Operations

[0000950170-25-109742:mdna:11]
The following is a summary of our results of operations during the fiscal year ended June 30, 2025:

[0000950170-25-109742:mdna:12]
•
Net revenues of $1,140.1 million, increased 2.0% from fiscal 2024 net revenues of $1,117.2 million.

[0000950170-25-109742:mdna:13]
•
Product revenues of $704.5 million, increased 0.7% from fiscal 2024 product revenues of $699.3 million.

[0000950170-25-109742:mdna:14]
•
Subscription and support revenues of $435.6 million, increased 4.2% from fiscal 2024 subscription and support revenues of $417.9 million.

[0000950170-25-109742:mdna:15]
•
Total gross margin of 62.2% of net revenues in fiscal 2025, compared to 56.5% in fiscal 2024.

[0000950170-25-109742:mdna:16]
•
Operating income of $35.9 million in fiscal 2025, compared to operating loss of $65.2 million in fiscal 2024.

[0000950170-25-109742:mdna:17]
•
Net loss was $7.5 million in fiscal 2025, compared to net loss of $86.0 million in fiscal 2024.

[0000950170-25-109742:mdna:18]
•
Cash flow provided by operating activities of $152.0 million, compared to cash flow provided by operating activities of $55.5 million in fiscal 2024, an increase of $96.5 million. Cash and cash equivalents were $231.7 million as of June 30, 2025, an increase of $75.0 million, compared to $156.7 million at the end of fiscal 2024.

[0000950170-25-109742:mdna:19]
Net Revenues

[0000950170-25-109742:mdna:20]
The following table presents net product and subscription and support revenues for the fiscal years ended June 30, 2025, 2024 and 2023 (in thousands, except percentages):

[0000950170-25-109742:mdna:21]
|  |  |  | Year Ended |  | Year Ended |
|  |  |  | June 30,2025 |  | June 30,2024 |  | $Change |  | %Change |  | June 30,2024 |  | June 30, 2023 |  | $Change |  | %Change |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | $704,462 |  | $699,257 |  | $5,205 |  | 0.7 % |  | $699,257 |  | $932,454 |  | $(233,197) |  | (25.0)% |
| Percentage of net revenues |  |  | 61.8% |  | 62.6% |  |  |  |  |  | 62.6% |  | 71.0% |  |  |  |  |
| Subscription and support |  |  | 435,605 |  | 417,946 |  | 17,659 |  | 4.2 % |  | 417,946 |  | 380,000 |  | 37,946 |  | 10.0 % |
| Percentage of net revenues |  |  | 38.2% |  | 37.4% |  |  |  |  |  | 37.4% |  | 29.0% |  |  |  |  |
| Total net revenues |  |  | $1,140,067 |  | $1,117,203 |  | $22,864 |  | 2.0 % |  | $1,117,203 |  | $1,312,454 |  | $(195,251) |  | (14.9)% |

[0000950170-25-109742:mdna:22]
We generate product revenues primarily from sales of our networking equipment. We derive subscription and support revenues primarily from sales of our subscription and support offerings which includes SaaS offerings, maintenance contracts, professional services and training for our products. Prior to fiscal 2024, we referred to subscription and support revenue as “service and subscription revenue;” however, the composition of subscription and support revenue has not been modified.

[0000950170-25-109742:mdna:23]
Product revenues increased $5.2 million or 0.7% for the year ended June 30, 2025, compared to fiscal 2024. The product revenues increase for the year ended June 30, 2025 as compared to fiscal 2024 was primarily driven by higher bookings and shipments in the second half of fiscal 2025 than in the corresponding period in fiscal 2024 which was impacted by elongated sales cycles to end customers and lower channel sell-through caused by macroeconomic conditions.

[0000950170-25-109742:mdna:24]
Product revenues decreased $233.2 million or 25.0% for the year ended June 30, 2024, compared to fiscal 2023. The product revenues decrease for the year ended June 30, 2024 as compared to fiscal 2023 was primarily driven by lower bookings and shipments as well as elongated sales cycles to end customers and lower channel sell-through caused by easing of supply chain constraints and macroeconomic conditions

[0000950170-25-109742:mdna:25]
Subscription and support revenues increased $17.7 million or 4.2% for the year ended June 30, 2025, compared to fiscal 2024. The increase in subscription and support revenues was primarily due to increased adoption of our cloud network management solutions and continued growth in our subscription business.

[0000950170-25-109742:mdna:26]
Subscription and support revenues increased $37.9 million or 10.0% for the year ended June 30, 2024, compared to fiscal 2023. The increase in subscription and support revenues was primarily due to increased adoption of our cloud network management solutions, higher attachment rates of cloud support services on product sales, and continued growth in our subscription business.

[0000950170-25-109742:mdna:27]
We operate in three regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table presents the total net revenues geographically for the fiscal years ended June 30, 2025, 2024 and 2023 (in thousands, except percentages):

[0000950170-25-109742:mdna:28]
|  |  | Year Ended | Year Ended |
| Net Revenues |  | June 30,2025 |  | June 30,2024 |  | $Change |  | %Change | June 30,2024 |  | June 30, 2023 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $547,658 |  | $581,141 |  | $(33,483) |  | (5.8)% | $581,141 |  | $572,927 |  | $8,214 |  | 1.4 % |
| Other |  | 49,047 |  | 46,578 |  | 2,469 |  | 5.3 % | 46,578 |  | 84,108 |  | (37,530) |  | (44.6)% |
| Total Americas |  | 596,705 |  | 627,719 |  | (31,014) |  | (4.9)% | 627,719 |  | 657,035 |  | (29,316) |  | (4.5)% |
| Percentage of net revenues |  | 52.3% |  | 56.2% |  |  |  |  | 56.2% |  | 50.1% |  |  |  |  |
| EMEA |  | 451,649 |  | $421,966 |  | 29,683 |  | 7.0 % | 421,966 |  | 559,669 |  | (137,703) |  | (24.6)% |
| Percentage of net revenues |  | 39.6% |  | 37.8% |  |  |  |  | 37.8% |  | 42.6% |  |  |  |  |
| APAC |  | 91,713 |  | $67,518 |  | 24,195 |  | 35.8 % | 67,518 |  | 95,750 |  | (28,232) |  | (29.5)% |
| Percentage of net revenues |  | 8.1% |  | 6.0% |  |  |  |  | 6.0% |  | 7.3% |  |  |  |  |
| Total net revenues |  | $1,140,067 |  | $1,117,203 |  | $22,864 |  | 2.0 % | $1,117,203 |  | $1,312,454 |  | $(195,251) |  | (14.9)% |

[0000950170-25-109742:mdna:29]
Cost of Revenues and Gross Profit

[0000950170-25-109742:mdna:30]
The following table presents the gross profit on product and subscription and support revenues and the gross profit percentage of net revenues for the fiscal years ended June 30, 2025, 2024 and 2023 (in thousands, except percentages):

[0000950170-25-109742:mdna:31]
|  |  | Year Ended |  | Year Ended |
|  |  | June 30,2025 |  | June 30,2024 |  | $Change |  | %Change |  | June 30,2024 |  | June 30, 2023 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $403,631 |  | $333,498 |  | $70,133 |  | 21.0 % |  | $333,498 |  | $506,159 |  | $(172,661) |  | (34.1)% |
| Percentage of product revenues |  | 57.3% |  | 47.7% |  |  |  |  |  | 47.7% |  | 54.3% |  |  |  |  |
| Subscription and support |  | 305,496 |  | 297,333 |  | 8,163 |  | 2.7 % |  | 297,333 |  | 248,561 |  | 48,772 |  | 19.6 % |
| Percentage of subscription and support revenues |  | 70.1% |  | 71.1% |  |  |  |  |  | 71.1% |  | 65.4% |  |  |  |  |
| Total gross profit |  | $709,127 |  | $630,831 |  | $78,296 |  | 12.4 % |  | $630,831 |  | $754,720 |  | $(123,889) |  | (16.4)% |
| Percentage of net revenues |  | 62.2% |  | 56.5% |  |  |  |  |  | 56.5% |  | 57.5% |  |  |  |  |

[0000950170-25-109742:mdna:32]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing, engineering, and document control at our facilities in San Jose, California, Salem, New Hampshire, Taiwan, Vietnam and the Philippines.

[0000950170-25-109742:mdna:33]
Product gross profit increased to $403.6 million for the year ended June 30, 2025, from $333.5 million in fiscal 2024, primarily due to higher product revenues as well as lower provisions for excess and obsolete inventory and lower warranty costs, partially offset by higher overhead and distribution costs related to increased purchases of inventory.

[0000950170-25-109742:mdna:34]
Product gross profit decreased to $333.5 million for the year ended June 30, 2024, from $506.2 million in fiscal 2023, primarily due to lower product revenues as well as an additional provision for excess and obsolete inventory and loss on supplier commitments of $64.5 million partially offset by lower amortization of intangibles due to certain intangibles being fully amortized, lower distribution costs due to easing of supply chain constraints, lower warranty reserves cost, and lower overhead costs. The increase in the provisions for excess and obsolete inventory and loss on supplier commitments during fiscal 2024 was primarily for certain of our older products which were scheduled to go end of sale during the Company’s fiscal year 2025 and for which excess of such inventories was beyond the demand forecast.

[0000950170-25-109742:mdna:35]
Our cost of subscription and support revenues consist primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts as well as third-party professional services costs, data center costs and cloud hosting service costs.

[0000950170-25-109742:mdna:36]
Subscription and support gross profit increased to $305.5 million for the year ended June 30, 2025, from $297.3 million in fiscal 2024, primarily due to higher subscription revenues, partially offset by higher personnel costs and increased cloud service costs.

[0000950170-25-109742:mdna:37]
Subscription and support gross profit increased to $297.3 million for the year ended June 30, 2024, from $248.6 million in fiscal 2023, primarily due to higher subscription and support revenues and lower headcount partially offset by higher professional services fees and increased cloud service costs.

[0000950170-25-109742:mdna:38]
Operating Expenses

[0000950170-25-109742:mdna:39]
The following table presents operating expenses for the fiscal years ended June 30, 2025, 2024 and 2023 (in thousands, except percentages):

[0000950170-25-109742:mdna:40]
|  |  | Year Ended |  | Year Ended |  |
|  |  | June 30,2025 |  | June 30,2024 |  | $Change |  | %Change |  | June 30,2024 |  | June 30, 2023 |  | $Change |  | %Change |  |
| Research and development |  | $221,459 |  | $211,931 |  | $9,528 |  | 4.5 % |  | $211,931 |  | $214,270 |  | $(2,339) |  | (1.1)% |  |
| Sales and marketing |  | 327,563 |  | 345,802 |  | (18,239) |  | (5.3)% |  | 345,802 |  | 336,906 |  | 8,896 |  | 2.6 % |  |
| General and administrative |  | 139,621 |  | 99,938 |  | 39,683 |  | 39.7 % |  | 99,938 |  | 89,934 |  | 10,004 |  | 11.1 % |  |
| Acquisition and integration costs |  | — |  | — |  | — |  | — |  | — |  | 390 |  | (390) |  | (100.0)% |  |
| Restructuring and related charges (benefits) |  | 1,492 |  | 36,321 |  | (34,829) |  | (95.9)% |  | 36,321 |  | 2,860 |  | 33,461 |  | 1,170.0 % |  |
| Amortization of intangible assets |  | 2,043 |  | 2,041 |  | 2 |  | 0.1 % |  | 2,041 |  | 2,047 |  | (6) |  | (0.3)% |  |
| Total operating expenses |  | $692,178 |  | $696,033 |  | $(3,855) |  | (.6)% |  | $696,033 |  | $646,407 |  | $49,626 |  | 7.7 % |  |

[0000950170-25-109742:mdna:41]
The following table highlights our operating expenses and operating income as a percentage of net revenues for the fiscal years ended June 30, 2025, 2024 and 2023:

[0000950170-25-109742:mdna:42]
|  |  | Year Ended |  |  |
|  |  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |  |
| Research and development |  |  | 19.4 | % |  |  | 19.0 | % |  |  | 16.3 | % |  |
| Sales and marketing |  |  | 28.7 | % |  |  | 31.0 | % |  |  | 25.7 | % |  |
| General and administrative |  |  | 12.2 | % |  |  | 8.9 | % |  |  | 6.9 | % |  |
| Acquisition and integration costs |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Restructuring and related charges (benefits) |  |  | 0.1 | % |  |  | 3.3 | % |  |  | 0.2 | % |  |
| Amortization of intangible assets |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 0.2 | % |  |
| Total operating expenses |  |  | 60.7 | % |  |  | 62.3 | % |  |  | 49.2 | % |  |
| Operating income (loss) |  |  | 1.5 | % |  |  | (5.8 | )% |  |  | 8.3 | % |  |

[0000950170-25-109742:mdna:43]
Research and Development Expenses

[0000950170-25-109742:mdna:44]
Research and development expenses consist primarily of personnel costs (which includes compensation, benefits and stock-based compensation), consultant fees and engineering expenses related to the design, development, and testing of our products.

[0000950170-25-109742:mdna:45]
Research and development expenses increased by $9.5 million or 4.5% for the year ended June 30, 2025 as compared to fiscal 2024, primarily due to a $10.5 million increase in personnel costs due to increased compensation and benefits costs, a $2.9 million increase in other costs primarily related to software costs, professional service fees, non-recurring engineering project costs and travel costs and a $2.6 million increase in information technology costs, offset by a $6.5 million decrease in contractor costs.

[0000950170-25-109742:mdna:46]
Research and development expenses decreased by $2.3 million or 1.1% for the year ended June 30, 2024 as compared to fiscal 2023, primarily due to a $2.8 million decrease in personnel costs due to lower compensation and benefits costs and a $2.9 million decrease in non-recurring engineering project costs, offset by a $3.4 million increase in contractor costs.

[0000950170-25-109742:mdna:47]
Sales and Marketing Expenses

[0000950170-25-109742:mdna:48]
Sales and marketing expenses consist of personnel costs (which includes compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0000950170-25-109742:mdna:49]
Sales and marketing expenses decreased by $18.2 million or 5.3% for the year ended June 30, 2025, as compared to fiscal 2024, primarily due to a $9.8 million decrease in personnel costs due to lower head count, a $3.1 million decrease in contractor costs and professional fees, a $2.6 million decrease in information technology and facilities costs, a $2.3 million decrease in travel costs, and $0.4 million in other expenses primarily related to lower depreciation expense.

[0000950170-25-109742:mdna:50]
Sales and marketing expenses increased by $8.9 million or 2.6% for the year ended June 30, 2024, as compared to fiscal 2023, primarily due to a $1.5 million increase in personnel costs due to higher salaries and benefits costs, a $7.2 million increase in sales promotions and marketing related expenses, and a $1.2 million increase in professional fees, offset by a $1.0 million decrease in other costs primarily related to contractor costs and travel costs.

[0000950170-25-109742:mdna:51]
General and Administrative Expenses

[0000950170-25-109742:mdna:52]
General and administrative expenses consist primarily of personnel costs (which includes compensation, benefits and share-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0000950170-25-109742:mdna:53]
General and administrative expenses increased by $39.7 million or 39.7% for the year ended June 30, 2025, as compared to fiscal 2024, primarily due to a $16.3 million increase in system transition costs, a $6.8 million increase in personnel costs due to higher compensation and benefits costs, a $24.2 million increase in expense for legal costs related to litigation matters and a $1.5 million increase in other costs primarily related to third-party licensing fees, information technology and travel costs, partially offset by a $5.2 million decrease in professional service fees and a $4.0 million decrease in depreciation expense.

[0000950170-25-109742:mdna:54]
General and administrative expenses increased by $10.0 million or 11.1% for the year ended June 30, 2024, as compared to fiscal 2023, primarily due to a $2.5 million increase in personnel costs due to higher salaries and benefits costs, a $3.4 million increase in professional fees primarily related to legal and litigation matters, a  $4.3 million increase in system transition costs, and a $2.4 million increase in third-party licensing fees, partially offset by a $2.6 million decrease in other expenses primarily for depreciation expense.

[0000950170-25-109742:mdna:55]
Restructuring and Related Charges

[0000950170-25-109742:mdna:56]
During the fiscal years ended June 30, 2025, 2024 and 2023, we recorded restructuring and related charges of $1.5 million, $36.3 million and $2.9 million, respectively.

[0000950170-25-109742:mdna:57]
Fiscal year 2025

[0000950170-25-109742:mdna:58]
During fiscal 2025, the Company recorded $1.5 million of restructuring charges which were primarily related to severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q2 2024 Plan” and “Q3 2024 Plan”, each as described in Note 14, Restructuring and Related Charges, in Notes to the Consolidated Financial Statements included elsewhere in this Report.

[0000950170-25-109742:mdna:59]
Fiscal year 2024

[0000950170-25-109742:mdna:60]
During fiscal 2024, the Company recorded $36.3 million of restructuring charges which were primarily related to severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q1 2024 Plan”, “Q2 2024 Plan”, and “Q3 2024 Plan”, each as described in Note 14, Restructuring and Related Charges, in Notes to the Consolidated Financial Statements included elsewhere in this Report.

[0000950170-25-109742:mdna:61]
Fiscal year 2023

[0000950170-25-109742:mdna:62]
During fiscal 2023, the Company recorded $2.9 million of restructuring charges which was primarily comprised of $2.0 million of facility related charges related to our previously impaired facilities and $0.9 million in charges associated with our restructuring plan initiated in the third quarter of fiscal 2023 to transform our business and facilities infrastructure.

[0000950170-25-109742:mdna:63]
Amortization of Intangible Assets

[0000950170-25-109742:mdna:64]
We recorded $2.0 million of amortization expense for each of the fiscal years ended June 30, 2025, 2024 and 2023 in operating expenses primarily for certain intangibles related to previous acquisitions. There were no acquisitions or impairments of intangible assets during fiscal years 2025, 2024 or 2023.

[0000950170-25-109742:mdna:65]
Interest Income

[0000950170-25-109742:mdna:66]
Interest income was $4.3 million, $4.6 million and $3.2 million in fiscal years ended June 30, 2025, 2024 and 2023, respectively. The decrease in interest income in the fiscal year ended June 30, 2025 as compared to fiscal 2024 was primarily driven by lower interest earned on cash deposits. The increase in interest income in the fiscal year ended June 30, 2024 as compared to fiscal 2023 was primarily driven by higher interest earned on cash deposits.

[0000950170-25-109742:mdna:67]
Interest Expense

[0000950170-25-109742:mdna:68]
We recorded $15.9 million, $17.0 million, and $17.4 million of interest expense for fiscal years ended June 30, 2025, 2024 and 2023, respectively. The decrease in interest expense in fiscal year ended June 30, 2025 as compared to fiscal 2024 was primarily driven by lower interest rates on lower outstanding balances under the 2023 Credit Agreement. The decrease in interest expense in fiscal year ended June 30, 2024 as compared to fiscal 2023 was primarily driven by lower carrying balances under the 2023 Credit Agreement.

[0000950170-25-109742:mdna:69]
Other Income (Expense), net

[0000950170-25-109742:mdna:70]
We had other expense, net of $1.1 million and other income, net of less than $0.1 million and $0.1 million in fiscal years ended June 30, 2025, 2024 and 2023, respectively. The other income (expense), net for fiscal years ended June 30, 2025, 2024 and 2023 was primarily due to foreign exchange gains or losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-25-109742:mdna:71]
Provision for Income Taxes

[0000950170-25-109742:mdna:72]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rate differs from the U.S. federal statutory rate of 21% primarily due to the impact of (i) GILTI, (ii) the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions, (iii) foreign income taxes of our international subsidiaries, and (iv) U.S. state taxes. For the fiscal years ended June 30, 2025, 2024 and 2023, we recorded income tax provisions of $11.7 million, $8.5 million, and $16.0 million respectively.

[0000950170-25-109742:mdna:73]
For fiscal 2025, 2024 and 2023, our tax provision is primarily related to (i) taxes on our foreign operations, including foreign withholding taxes remitted to foreign tax authorities by customers on our behalf, (ii) US federal taxes resulting from our US operations, (iii) tax expense related to the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business and (iv) state taxes in states where we have exhausted available Net Operating Losses or are subject to certain franchise taxes qualifying as income tax under the relevant tax accounting guidance.

[0000950170-25-109742:mdna:74]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 15, Income Taxes, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K.

[0000950170-25-109742:mdna:75]
Critical Accounting Policies and Estimates

[0000950170-25-109742:mdna:76]
Our significant accounting policies are more fully described in Note 2, Summary of Significant Accounting Policies, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0000950170-25-109742:mdna:77]
Revenue Recognition

[0000950170-25-109742:mdna:78]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for the products we offer. We sell our products and SaaS and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell primarily to end-users. Products and services may be sold separately or in bundled packages.

[0000950170-25-109742:mdna:79]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, we consider the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0000950170-25-109742:mdna:80]
We generally do not grant return privileges and pricing credits to our value-added resellers, non-stocking distributors and end-user customers, except for defective products during the warranty period. We may provide sales incentives and other programs to these customers which are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the historical actuals.

[0000950170-25-109742:mdna:81]
Our stocking distributors are allowed certain price adjustments in the form of rebates and limited stock rotation rights. In determining the transaction price, we consider these rebates to be variable consideration which are estimated based on an analysis of historical claims at the distributor level. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotations are an additional form of variable consideration and are estimated based on an analysis of historical return rates.

[0000950170-25-109742:mdna:82]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price. The stand-alone selling prices are determined based on the prices at which we separately sell these products. For items that are not sold separately, we estimate the stand-alone selling prices using other observable inputs.

[0000950170-25-109742:mdna:83]
Our performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of our product sales revenues are recognized at a point in time and our subscription and support revenues are recognized over time. For revenues recognized over time, we use an input measure, days elapsed, to measure progress.

[0000950170-25-109742:mdna:84]
See Note 3, Revenues, in Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information.

[0000950170-25-109742:mdna:85]
Business Combinations

[0000950170-25-109742:mdna:86]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all tangible and intangible assets acquired and liabilities assumed are recorded at their respective fair values at the acquisition date. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to expected future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0000950170-25-109742:mdna:87]
Inventory Valuation and Purchase Commitments

[0000950170-25-109742:mdna:88]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0000950170-25-109742:mdna:89]
New Accounting Pronouncements

[0000950170-25-109742:mdna:90]
See Note 2, Summary of Significant Accounting Policies, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0000950170-25-109742:mdna:91]
Liquidity and Capital Resources

[0000950170-25-109742:mdna:92]
The following summarizes information regarding our cash and cash equivalents (in thousands):

[0000950170-25-109742:mdna:93]
|  |  | June 30,2025 |  |  | June 30,2024 |  |
| Cash and cash equivalents |  | $ | 231,745 |  |  | $ | 156,699 |  |

[0000950170-25-109742:mdna:94]
As of June 30, 2025, our principal sources of liquidity consisted of cash and cash equivalents of $231.7 million, accounts receivable, net of $126.7 million and available borrowings under our five-year 2023 Revolving Facility (as defined below) of $135.8 million. We anticipate our principal uses of cash and cash equivalents for fiscal 2026 will be purchases of finished goods inventory from our contract manufacturers, payroll, share repurchases, payments under debt obligations and related interest, payments under lease obligations, payments for litigation settlement, purchases of property and equipment and other operating expenses related to the development and marketing of our products. We believe that our existing cash and cash equivalents, cash flows from operations, and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months. We are not currently aware of any material cash requirements beyond the next 12 months other than those described above for fiscal 2025 and our known contractual obligations. See the section titled “Contractual Obligations” below.

[0000950170-25-109742:mdna:95]
On February 18, 2025, we announced that our Board had authorized management to repurchase up to $200.0 million shares of the Company's common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”). As of June 30, 2025, the 2022 Repurchase Program expired. Under these repurchase programs, purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The 2025 Repurchase Program does not obligate us to acquire any shares of our common stock, and they may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the year ended June 30, 2025, we repurchased a total of approximately 2.4 million shares of our common stock on the open market at a total cost of $38.0 million with an average price of $15.89 per share under the 2022 Repurchase Program.

[0000950170-25-109742:mdna:96]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among Extreme, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0000950170-25-109742:mdna:97]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use proceeds of the loans for working capital and general corporate purposes.

[0000950170-25-109742:mdna:98]
At our election, the initial term loan (the “Initial Term Loan”) under the 2023 Credit Agreement may be made as either a base rate loan or a Secured Overnight Financing Data Rate (“SOFR loan”). The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s Consolidated Leverage Ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company also agrees to pay other closing fees, arrangement fees, and administration fees.

[0000950170-25-109742:mdna:99]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-25-109742:mdna:100]
On August 14, 2024, we entered into an Amendment Number One to the 2023 Credit Agreement the (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, we modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the Amended Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with our operations and activities.

[0000950170-25-109742:mdna:101]
As of the year ended June 30, 2025, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0000950170-25-109742:mdna:102]
Key Components of Cash Flows and Liquidity

[0000950170-25-109742:mdna:103]
A summary of the sources and uses of cash and cash equivalents is as follows for the fiscal years ended June 30, 2025, 2024 and 2023 (in thousands):

[0000950170-25-109742:mdna:104]
|  | Year Ended |  |
|  | June 30,2025 |  |  | June 30,2024 |  |  | June 30, 2023 |  |
| Net cash provided by operating activities | $ | 152,031 |  |  | $ | 55,486 |  |  | $ | 249,212 |  |
| Net cash used in investing activities |  | (24,713 | ) |  |  | (18,121 | ) |  |  | (13,800 | ) |
| Net cash used in financing activities |  | (52,586 | ) |  |  | (114,978 | ) |  |  | (194,783 | ) |
| Foreign currency effect on cash and cash equivalents |  | 314 |  |  |  | (514 | ) |  |  | (325 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 75,046 |  |  | $ | (78,127 | ) |  | $ | 40,304 |  |

[0000950170-25-109742:mdna:105]
Cash and cash equivalents were $231.7 million at June 30, 2025, representing a increase of $75.0 million from $156.7 million at June 30, 2024. This increase was primarily due to cash provided by operating activities of $152.0 million, offset by cash used in financing activities of $52.6 million mainly as a result of payments for borrowings under the Amended Credit Agreement and share repurchases as well as cash used in investing activities of $24.7 million primarily for the purchase of property and equipment.

[0000950170-25-109742:mdna:106]
Cash and cash equivalents were $156.7 million at June 30, 2024, representing a decrease of $78.1 million from $234.8 million at June 30, 2023. This decrease was primarily due to cash used in financing activities of $115.0 million mainly as a result of payments for borrowings under the 2023 Credit Agreement and share repurchases as well as cash used in investing activities of $18.1 million primarily for the purchase of property and equipment, which is offset by cash provided by operating activities of $55.5 million.

[0000950170-25-109742:mdna:107]
Net Cash Provided by Operating Activities

[0000950170-25-109742:mdna:108]
Cash provided by operating activities during the fiscal year ended June 30, 2025 was $152.0 million. Factors contributing to cash provided by operating activities were the net loss of $7.5 million and non-cash expenses of $118.1 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in inventories and increases in accounts payable, accrued compensation and benefits, deferred revenue and other accrued liabilities. This was partially offset by increases in net accounts receivable and prepaid expenses and other assets, and a decrease in operating lease liabilities.

[0000950170-25-109742:mdna:109]
Cash provided by operating activities during the fiscal year ended June 30, 2024 was $55.5 million. Factors contributing to cash provided by operating activities were the net loss of $86.0 million and non-cash expenses of $187.6 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in account receivable and increases in deferred revenue and other current liabilities. These amounts were partially offset by increases in inventories and prepaid expenses and other assets and decreases in accounts payable, accrued compensation and benefits, and operating lease liabilities.

[0000950170-25-109742:mdna:110]
Cash provided by operating activities during the fiscal year ended June 30, 2023 was $249.2 million. Factors contributing to cash provided by operating activities were net income of $78.1 million, non-cash expenses of $104.6 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included decrease in account receivable and increases in accounts payable, accrued compensation and deferred revenue. These amounts were partially offset by increases in inventories and prepaid expenses and other assets and decreases in operating lease liabilities.

[0000950170-25-109742:mdna:111]
Net Cash Used in Investing Activities

[0000950170-25-109742:mdna:112]
Cash used in investing activities during the fiscal year ended June 30, 2025 was $24.7 million for the purchases of property and equipment.

[0000950170-25-109742:mdna:113]
Cash used in investing activities during the fiscal year ended June 30, 2024 was $18.1 million for the purchases of property and equipment.

[0000950170-25-109742:mdna:114]
Cash used in investing activities during the fiscal year ended June 30, 2023 was $13.8 million for the purchases of property and equipment.

[0000950170-25-109742:mdna:115]
Net Cash Used in Financing Activities

[0000950170-25-109742:mdna:116]
Cash used in financing activities during the fiscal year ended June 30, 2025 was $52.6 million due primarily to share repurchases of $38.0 million, debt repayments of $10.0 million and $3.9 million in payments for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and through the exercise of stock options.

[0000950170-25-109742:mdna:117]
Cash used in financing activities during the fiscal year ended June 30, 2024 was $115.0 million due primarily to share repurchases of $49.9 million, payments on the 2023 Revolving Facility of $55.0 million, debt repayments of $10.0 million and a $30.1 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP. The amounts were partially offset by cash received of $30.0 million from borrowings under the 2023 Revolving Facility.

[0000950170-25-109742:mdna:118]
Cash used in financing activities during the fiscal year ended June 30, 2023 was $194.8 million due primarily to share repurchases of $99.9 million, debt repayments of $108.6 million, payments of debt financing cost of $3.2 million, $3.0 million of deferred payments on acquisitions and a $5.1 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP. The amounts were partially offset by cash received of $25.0 million from the 2023 Revolving Facility.

[0000950170-25-109742:mdna:119]
Foreign Currency Effect on Cash and cash equivalents

[0000950170-25-109742:mdna:120]
Foreign currency effect on cash and cash equivalents increased in 2025, primarily due to changes in exchange rates between the U.S. Dollar and particularly the Indian Rupee, U.K. Pound, and the Euro.

[0000950170-25-109742:mdna:121]
Contractual Obligations

[0000950170-25-109742:mdna:122]
As of June 30, 2025, we have contractual obligations for debt obligations, purchase obligations, lease obligations and other obligations.

[0000950170-25-109742:mdna:123]
Our debt obligations relate to amounts owed under our Amended Credit Agreement. As of June 30, 2025, we have $180.0 million of debt outstanding which is payable in quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our debt obligations.

[0000950170-25-109742:mdna:124]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of June 30, 2025, we have non-cancelable commitments to purchase $45.4 million of inventory. See Note 9, Commitments and Contingencies, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our purchase obligations.

[0000950170-25-109742:mdna:125]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of June 30, 2025, the value of our obligations under operating leases was $53.2 million. See Note 8, Leases, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our lease obligations.

[0000950170-25-109742:mdna:126]
We have contractual commitments with our suppliers which represent commitments for future services. As of June 30, 2025, we have contractual commitments of $17.2 million that are due through our fiscal year 2027.

[0000950170-25-109742:mdna:127]
We have immaterial income tax liabilities related to uncertain tax positions and we are unable to reasonably estimate the timing of the settlement of those liabilities.

[0000950170-25-109742:mdna:128]
We do not have any material commitments for capital expenditures as of June 30, 2025.

[0000950170-25-109742:mdna:129]
Off-Balance Sheet Arrangements

[0000950170-25-109742:mdna:130]
We did not have any off-balance sheet arrangements as of June 30, 2025.
