# EXTR note change history — 0001564590-20-002754 → 0001564590-20-024274


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001564590-20-024274:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2020, the Company had commitments to purchase $37.1 million of inventory and other services.
  (was, 2020-01-30, similarity 0.9896):
[0001564590-20-002754:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2019, the Company had commitments to purchase $47.7 million of inventory and other services.

- changed (2020-05-11):
[0001564590-20-024274:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2020-01-30, similarity 0.899):
[0001564590-20-002754:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss,

- changed (2020-05-11):
[0001564590-20-024274:note_history:3]
All currency conversions in this Legal Proceedings section are as of March 31, 2020.
  (was, 2020-01-30, similarity 0.9434):
[0001564590-20-002754:note_history:3]
All currency conversions in this Legal Proceedings section are as of December 31, 2019.

- changed (2020-05-11):
[0001564590-20-024274:note_history:4]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims
  (was, 2020-01-30, similarity 0.8382):
[0001564590-20-002754:note_history:4]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims of the ’296 patent and ’728 patent, and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is set for March 17, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

- added (2020-05-11):
[0001564590-20-024274:note_history:5]
of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is set for June 8, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

- changed (2020-05-11):
[0001564590-20-024274:note_history:6]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  After a hearing on January 28, 2020, the Court rendered a decision in favor of the Company fully dismissing Orckit’s complaint.  Orckit  filed a notice of appeal on March 13, 2020.
  (was, 2020-01-30, similarity 0.7545):
[0001564590-20-002754:note_history:6]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents.  The District Court Düsseldorf held a hearing in this case on January 28, 2020 and a decision is expected in a few weeks.

- changed (2020-05-11):
[0001564590-20-024274:note_history:7]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  The Company filed a nullity action with the German Federal Patent Court, seeking to invalidate the asserted patent.  Orckit has filed its formal opposition to the Company’s nullity action on March 11, 2020.  No hearing has been scheduled yet in this case, which was split from the original.
  (was, 2020-01-30, similarity 0.6841):
[0001564590-20-002754:note_history:7]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  Extreme filed a nullity action with the German Federal Patent Court on or before that date, seeking to invalidate the asserted patent.  No hearing has been scheduled yet in this case, which was split from the original action involving the first patent in suit.

- changed (2020-05-11):
[0001564590-20-024274:note_history:8]
The Company believes that all claims in both cases are without merit and intends to defend them vigorously.
  (was, 2020-01-30, similarity 0.9412):
[0001564590-20-002754:note_history:8]
The Company believes that all claims in both cases are without merit and defends them vigorously.

- changed (2020-05-11):
[0001564590-20-024274:note_history:9]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China.  In each lawsuit, GIA has accused a number of Summit switching products of infringing one of six patents (the “Asserted Patents”). One trial has been postponed, and the trials for the rest of the cases have not yet been scheduled. Additionally, the Company has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of five of the Asserted Patents.  The Company has appealed three of these rulings.  All the claims in one case have been fully invalidated.
  (was, 2020-01-30, similarity 0.6143):
[0001564590-20-002754:note_history:9]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1 (“ZL ‘028.1”), ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2 (“ZL ‘486.2”), and ZL200610060686.9 (“ZL ‘686.9”) (collectively, the “Asserted Patents”). GIA has accused a number of Summit switching products of infringing the Asserted Patents. Each patent was asserted in a separate lawsuit.  The trial related to the ZL ‘4862 patent has been postponed, and the trials for the rest of the cases have not yet been scheduled. Extreme disputes GIA’s claims and intends to defend the matter vigorously.  Additionally, Extreme has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of the ZL ‘028.1 and ZL ‘486.2 patents, and Extreme has appealed these two rulings.  All the claims in ZL ‘686.9 have been fully invalidated.  Decisions have not yet been issued for the remaining three patents.

- changed (2020-05-11):
[0001564590-20-024274:note_history:10]
The Company disputes GIA’s claims and intends to defend the matter vigorously. Given the uncertainty of litigation and the preliminary stage of the case, the Company cannot estimate at this time the possible loss or range of loss that may result from this action.
  (was, 2020-01-30, similarity 0.7946):
[0001564590-20-002754:note_history:10]
Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- changed (2020-05-11):
[0001564590-20-024274:note_history:11]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.4 million). The trial originally scheduled for November 15, 2019 has been postponed by the Court, pending the jurisdictional objections filed by Aerohive, and has not yet been rescheduled.  The Court rejected the jurisdictional challenge, which Aerohive is appealing. The Company cannot estimate at this time the possible loss or range of loss that may result from this action.
  (was, 2020-01-30, similarity 0.6914):
[0001564590-20-002754:note_history:11]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of Chinese patent ZL02123502.3 and seeks damages of RMB 10.0 million (USD $1.4 million). The trial originally scheduled for November 15, 2019 has been postponed by the Court, pending the jurisdictional objections filed by Aerohive and has not yet been rescheduled.  The Court rejected the jurisdictional challenge, which Aerohive is appealing. The Company cannot estimate at this time the possible loss or range of loss that may result from this action.

- added (2020-05-11):
[0001564590-20-024274:note_history:12]
Proven Networks, LLC v. Extreme Networks, Inc.

- added (2020-05-11):
[0001564590-20-024274:note_history:13]
On March 24, 2020, Proven Networks, LLC (“Proven”) filed a patent infringement lawsuit against the Company in the Northern District of California. The lawsuit alleges direct and indirect infringement of three U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of Extreme Analytics Extreme XOS, and certain network devices equipped with the Extreme XOS operating system.  Proven seeks injunctive relief, unspecified damages, pre- and post-judgment interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, the Company cannot estimate at this time the possible loss or range of loss that may result from this action.

- changed (2020-05-11):
[0001564590-20-024274:note_history:14]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.
  (was, 2020-01-30, similarity 0.7671):
[0001564590-20-002754:note_history:14]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- removed (2020-05-11):
[0001564590-20-002754:note_history:15]
fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- removed (2020-05-11):
[0001564590-20-002754:note_history:16]
Brazilian Tax Assessment Matter

- removed (2020-05-11):
[0001564590-20-002754:note_history:17]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes due to denial of presumed tax credits from 2003 to 2004 (the “ICMS Tax Assessment”).  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties.

- removed (2020-05-11):
[0001564590-20-002754:note_history:18]
On October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. A decision in 2017 would require Enterasys Brasil to pay a total of BRL 20.2 million (USD $5.0 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 1, 2019. Enterasys Brasil recorded an accrual of BRL 9.4 million (USD $2.3 million) as of the date the Company acquired Enterasys Networks. The Company has appealed the lower court’s decision.

- removed (2020-05-11):
[0001564590-20-002754:note_history:19]
On December 12, 2019, Enterasys Brasil participated in an amnesty program called the Programa Especial de Parcelamento offered by the Brazilian government to reach a resolution to this issue.  On December 18, 2019, Enterasys Brasil paid BRL 8.692 million (USD $2.2 million) to settle the ICMS Tax Assessment.  The Company will dismiss the pending appellate suit and has accrued for payment of the government’s legal fees of approximately BRL 0.632 million (USD $0.157 million).


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001564590-20-024274:note_history:20]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2020. The results of operations for the three and nine months ended March 31, 2020 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.
  (was, 2020-01-30, similarity 0.9404):
[0001564590-20-002754:note_history:20]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2019. The results of operations for the three and six months ended December 31, 2019 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.

- changed (2020-05-11):
[0001564590-20-024274:note_history:21]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenue and expenses are translated using the monthly average rate.
  (was, 2020-01-30, similarity 0.9988):
[0001564590-20-002754:note_history:21]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001564590-20-024274:note_history:22]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K, except for the adoption of the new lease guidance, new derivatives and hedging guidance and related policies as discussed within these financial statements.
  (was, 2020-01-30, similarity 0.8941):
[0001564590-20-002754:note_history:22]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K, except for the adoption of the new lease guidance and related policies as discussed within these financial statements.

- changed (2020-05-11):
[0001564590-20-024274:note_history:23]
On July 1, 2019, the Company recognized ROU assets of $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases.
  (was, 2020-01-30, similarity 0.9769):
[0001564590-20-002754:note_history:23]
On July 1, 2019, the Company recognized ROU assets of approximately $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases.

- changed (2020-05-11):
[0001564590-20-024274:note_history:24]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption. During the third quarter of fiscal 2020, the Company entered into interest rate swap agreements to manage its exposure to fluctuations of interest rates associated with its debt.  See Note 14, Derivatives and Hedging, for additional information.
  (was, 2020-01-30, similarity 0.8707):
[0001564590-20-002754:note_history:24]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. This guidance was effective for the Company beginning with its fiscal year 2020. It did not have a material impact on the Company’s financial statements upon adoption.

- changed (2020-05-11):
[0001564590-20-024274:note_history:25]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), which allows the reclassification from Additional Other Comprehensive Income (“AOCI”) to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act").  The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI.  This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.
  (was, 2020-01-30, similarity 0.9265):
[0001564590-20-002754:note_history:25]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.

- added (2020-05-11):
[0001564590-20-024274:note_history:26]
In March 2020, the FASB issued ASU 2020-04, “Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by the discontinuation of the London Interbank Offered Rate (LIBOR) and other interbank offered rates. This guidance is

- added (2020-05-11):
[0001564590-20-024274:note_history:27]
effective upon issuance and can be applied to applicable contract modifications through December 31, 2022. The Company elected to apply the amendments in this update to eligible hedging relationships existing as of January 1, 2020 or entered into during the three months ended March 31, 2020 in accordance with the transition options available. This guidance did not have any impact upon adoption. The Company will apply this guidance to transactions or modifications of these arrangements as appropriate through transition period.

- changed (2020-05-11):
[0001564590-20-024274:note_history:28]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.
  (was, 2020-01-30, similarity 0.6223):
[0001564590-20-002754:note_history:28]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

- added (2020-05-11):
[0001564590-20-024274:note_history:29]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.

- changed (2020-05-11):
[0001564590-20-024274:note_history:30]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures.  This guidance is effective for the Company’s fiscal year 2022, beginning on July 1, 2021.
  (was, 2020-01-30, similarity 0.6685):
[0001564590-20-002754:note_history:30]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for interim and annual reporting periods beginning after December 15, 2020, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2022, beginning on July 1, 2021.

- removed (2020-05-11):
[0001564590-20-002754:note_history:31]
In January 2017, the FASB issued ASU 2017-04, Simplifying the Test for Goodwill Impairment (Topic 350), which removes Step 2 of the goodwill impairment test, which requires a hypothetical purchase price allocation. An impairment charge will now be the amount by which a reporting unit’s carrying value exceeds the fair value, not to exceed the carrying amount of goodwill.  This standard is effective for fiscal years beginning after December 15, 2019, with early adoption permitted The Company does not expect the adoption to have a material impact on the condensed consolidated financial statements. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

- removed (2020-05-11):
[0001564590-20-002754:note_history:32]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001564590-20-024274:note_history:33]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,819 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 351,500 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (6,796 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 399,704 |  |  |  | 169,739 |  |
| Total debt |  | $ | 416,523 |  |  | $ | 178,750 |  |
  (was, 2020-01-30, similarity 0.9491):
[0001564590-20-002754:note_history:33]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,186 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,814 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 356,250 |  |  | $ | 171,000 |  |
| Less: unamortized debt issuance costs |  |  | (7,334 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 348,916 |  |  |  | 169,739 |  |
| Total debt |  | $ | 365,730 |  |  | $ | 178,750 |  |

- changed (2020-05-11):
[0001564590-20-024274:note_history:34]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the Acquisition and for working capital and general corporate purposes.
  (was, 2020-01-30, similarity 0.9844):
[0001564590-20-002754:note_history:34]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the Acquisition and for working capital and general corporate purposes.

- changed (2020-05-11):
[0001564590-20-024274:note_history:35]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.
  (was, 2020-01-30, similarity 0.9856):
[0001564590-20-002754:note_history:35]
At the Company’s election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

- changed (2020-05-11):
[0001564590-20-024274:note_history:36]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $10.5 million of deferred financing costs in conjunction with this modification of the debt and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of March 31, 2020 was 5.1%.
  (was, 2020-01-30, similarity 0.9797):
[0001564590-20-002754:note_history:36]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $10.5 million of deferred financing costs in conjunction which this modification of the debt and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of December 31, 2019 was 5.0%.

- changed (2020-05-11):
[0001564590-20-024274:note_history:37]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.6 million and $0.2 million for the three months ended March 31, 2020 and 2019, and totaled $1.8 million and $0.5 million for the nine months ended March 31, 2020 and 2019, respectively.
  (was, 2020-01-30, similarity 0.9024):
[0001564590-20-002754:note_history:37]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.7 million and $0.2 million for the three months ended December 31, 2019 and 2018, and totaled $1.1 million and $0.3 million for the six months ended December 31, 2019 and 2018, respectively.

- added (2020-05-11):
[0001564590-20-024274:note_history:38]
The Company had $7.7 million of outstanding letters of credit as of March 31, 2020.

- added (2020-05-11):
[0001564590-20-024274:note_history:39]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and the Company is restricted  from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company 
is in compliance with the original covenants of the 2019 Credit Agreement.

- removed (2020-05-11):
[0001564590-20-002754:note_history:40]
The Company had $60.3 million of availability under the 2019 Revolving Facility as of December 31, 2019.  The Company had $7.7 million of outstanding letters of credit as of December 31, 2019.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001564590-20-024274:note_history:41]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,819 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 351,500 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (6,796 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 399,704 |  |  |  | 169,739 |  |
| Total debt |  | $ | 416,523 |  |  | $ | 178,750 |  |
  (was, 2020-01-30, similarity 0.9491):
[0001564590-20-002754:note_history:41]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,186 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,814 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 356,250 |  |  | $ | 171,000 |  |
| Less: unamortized debt issuance costs |  |  | (7,334 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 348,916 |  |  |  | 169,739 |  |
| Total debt |  | $ | 365,730 |  |  | $ | 178,750 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001564590-20-024274:note_history:42]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |
| Other |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |
| Total Americas |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |
| EMEA |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |
| APAC |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |
| Total net revenues |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |
  (was, 2020-01-30, similarity 0.9665):
[0001564590-20-002754:note_history:42]
|  |  | Three Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |
| Other |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |
| Total Americas |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |
| EMEA |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |
| APAC |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |
| Total net revenues |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |

- changed (2020-05-11):
[0001564590-20-024274:note_history:43]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |
| Other |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |
| Total Americas |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |
| EMEA |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |
| APAC |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |
| Total net revenues |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |
  (was, 2020-01-30, similarity 0.9233):
[0001564590-20-002754:note_history:43]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |
| Other |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |
| Total Americas |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |
| EMEA |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |
| APAC: |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |
| Total net revenues |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-11):
[0001564590-20-024274:note_history:44]
3.Revenues
  (was, 2020-01-30, similarity 0.72):
[0001564590-20-002754:note_history:44]
| 3. | Revenues |

- added (2020-05-11):
[0001564590-20-024274:note_history:45]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time. For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2020-05-11):
[0001564590-20-024274:note_history:46]
On March 31, 2020, the Company had $271.7 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 24 percent of its deferred revenue as revenue in fiscal 2020, an additional 46 percent in fiscal 2021 and 30 percent of the balance thereafter.
  (was, 2020-01-30, similarity 0.9742):
[0001564590-20-002754:note_history:46]
On December 31, 2019, the Company had $277.8 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 42 percent of its deferred revenue as revenue in fiscal 2020, an additional 34 percent in fiscal 2021 and 24 percent of the balance thereafter.

- changed (2020-05-11):
[0001564590-20-024274:note_history:47]
Revenue recognized for the three months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $64.3 million and $54.8 million, respectively. Revenue recognized for the nine months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $116.7 million and $110.8 million, respectively.
  (was, 2020-01-30, similarity 0.9194):
[0001564590-20-002754:note_history:47]
Revenue recognized for the three months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $67.2 million and $59.9 million, respectively. Revenue recognized for the six months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $90.9 million and $88.8 million, respectively.

- changed (2020-05-11):
[0001564590-20-024274:note_history:48]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.4 million and $6.5 million at March 31, 2020 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2020 and 2019, was $1.1 million and $0.8 million, respectively. Amortization recognized during the nine months ended March 31, 2020 and 2019 was $4.1 million and $2.2 million, respectively.
  (was, 2020-01-30, similarity 0.9342):
[0001564590-20-002754:note_history:48]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.3 million and $6.5 million at December 31, 2019 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2019 and 2018, was $1.5 million and $0.7 million, respectively. Amortization recognized during the six months ended December 31, 2019 and 2018 was $3.0 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2020-05-11):
[0001564590-20-024274:note_history:49]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |
| Other |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |
| Total Americas |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |
| EMEA |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |
| APAC |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |
| Total net revenues |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |
  (was, 2020-01-30, similarity 0.9665):
[0001564590-20-002754:note_history:49]
|  |  | Three Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |
| Other |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |
| Total Americas |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |
| EMEA |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |
| APAC |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |
| Total net revenues |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |

- changed (2020-05-11):
[0001564590-20-024274:note_history:50]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |
| Other |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |
| Total Americas |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |
| EMEA |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |
| APAC |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |
| Total net revenues |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |
  (was, 2020-01-30, similarity 0.9233):
[0001564590-20-002754:note_history:50]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |
| Other |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |
| Total Americas |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |
| EMEA |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |
| APAC: |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |
| Total net revenues |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |

- changed (2020-05-11):
[0001564590-20-024274:note_history:51]
Included in the above amounts are $2.2 million and $6.9 million of leasing revenue for the three and nine months ended March 31, 2020, respectively.  Included in the above amounts are $2.7 million and $8.6 million of leasing revenue for the three and nine months ended March 31, 2019, respectively.
  (was, 2020-01-30, similarity 0.828):
[0001564590-20-002754:note_history:51]
Included in the above amounts are $2.3 million and $4.7 million of leasing revenue for the three and six months ended December 31, 2019, respectively.  Included in the above amounts are $3.2 million and $5.9 million of leasing revenue for the three and six months ended December 31, 2018, respectively.

- added (2020-05-11):
[0001564590-20-024274:note_history:52]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Tech Data Corporation |  | 19% |  |  | 14% |  |  | 16% |  |  | 17% |  |
| Jenne Corporation |  | * |  |  | 21% |  |  | 13% |  |  | 15% |  |
| Westcon Group Inc. |  | 19% |  |  | 12% |  |  | 14% |  |  | 13% |  |

- added (2020-05-11):
[0001564590-20-024274:note_history:53]
* Less than 10% of net revenue.

- changed (2020-05-11):
[0001564590-20-024274:note_history:54]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 11 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 10 | % |  |  | 35 | % |
| Westcon Group Inc. |  |  | 14 | % |  | * |  |
  (was, 2020-01-30, similarity 0.8301):
[0001564590-20-002754:note_history:54]
|  |  | December 31, 2019 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 20 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 23 | % |  |  | 35 | % |

- added (2020-05-11):
[0001564590-20-024274:note_history:55]
* Less than 10% of accounts receivable.

- removed (2020-05-11):
[0001564590-20-002754:note_history:56]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- removed (2020-05-11):
[0001564590-20-002754:note_history:57]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |  | December 31, 2019 |  |  | December 31, 2018 |  |
| Tech Data Corporation |  | 14% |  |  | 22% |  |  | 15% |  |  | 19% |  |
| Jenne Corporation |  | 18% |  |  | 12% |  |  | 16% |  |  | 12% |  |
| Westcon Group Inc. |  | 15% |  |  | 15% |  |  | 13% |  |  | 14% |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-05-11):
[0001564590-20-024274:note_history:58]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time. For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2020-05-11):
[0001564590-20-024274:note_history:59]
On March 31, 2020, the Company had $271.7 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 24 percent of its deferred revenue as revenue in fiscal 2020, an additional 46 percent in fiscal 2021 and 30 percent of the balance thereafter.
  (was, 2020-01-30, similarity 0.9742):
[0001564590-20-002754:note_history:59]
On December 31, 2019, the Company had $277.8 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 42 percent of its deferred revenue as revenue in fiscal 2020, an additional 34 percent in fiscal 2021 and 24 percent of the balance thereafter.

- changed (2020-05-11):
[0001564590-20-024274:note_history:60]
Revenue recognized for the three months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $64.3 million and $54.8 million, respectively. Revenue recognized for the nine months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $116.7 million and $110.8 million, respectively.
  (was, 2020-01-30, similarity 0.9194):
[0001564590-20-002754:note_history:60]
Revenue recognized for the three months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $67.2 million and $59.9 million, respectively. Revenue recognized for the six months ended December 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $90.9 million and $88.8 million, respectively.

- changed (2020-05-11):
[0001564590-20-024274:note_history:61]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.4 million and $6.5 million at March 31, 2020 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2020 and 2019, was $1.1 million and $0.8 million, respectively. Amortization recognized during the nine months ended March 31, 2020 and 2019 was $4.1 million and $2.2 million, respectively.
  (was, 2020-01-30, similarity 0.9342):
[0001564590-20-002754:note_history:61]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.3 million and $6.5 million at December 31, 2019 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2019 and 2018, was $1.5 million and $0.7 million, respectively. Amortization recognized during the six months ended December 31, 2019 and 2018 was $3.0 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2020-05-11):
[0001564590-20-024274:note_history:62]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |
| Other |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |
| Total Americas |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |
| EMEA |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |
| APAC |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |
| Total net revenues |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |
  (was, 2020-01-30, similarity 0.9665):
[0001564590-20-002754:note_history:62]
|  |  | Three Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,111 |  | $ | 61,622 |  | $ | 121,733 |  |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |
| Other |  |  | 8,204 |  |  | 5,563 |  |  | 13,767 |  |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |
| Total Americas |  |  | 68,315 |  |  | 67,185 |  |  | 135,500 |  |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |
| EMEA |  |  | 64,717 |  |  | 44,257 |  |  | 108,974 |  |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |
| APAC |  |  | 6,007 |  |  | 16,991 |  |  | 22,998 |  |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |
| Total net revenues |  | $ | 139,039 |  | $ | 128,433 |  | $ | 267,472 |  |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |

- changed (2020-05-11):
[0001564590-20-024274:note_history:63]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |
| Other |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |
| Total Americas |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |
| EMEA |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |
| APAC |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |
| Total net revenues |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |
  (was, 2020-01-30, similarity 0.9233):
[0001564590-20-002754:note_history:63]
|  |  | Six Months Ended |  |
|  |  | December 31, 2019 |  |  | December 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 130,089 |  | $ | 123,967 |  | $ | 254,056 |  |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |
| Other |  |  | 12,219 |  |  | 10,562 |  |  | 22,781 |  |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |
| Total Americas |  |  | 142,308 |  |  | 134,529 |  |  | 276,837 |  |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |
| EMEA |  |  | 123,846 |  |  | 73,891 |  |  | 197,737 |  |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |
| APAC: |  |  | 15,120 |  |  | 33,284 |  |  | 48,404 |  |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |
| Total net revenues |  | $ | 281,274 |  | $ | 241,704 |  | $ | 522,978 |  |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |

- removed (2020-05-11):
[0001564590-20-002754:note_history:64]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
