# EXTR notes — 0001564590-20-024274


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-20-024274:notes:1]
[same as prior period, unchanged from 0001564590-20-002754:notes:1]

[0001564590-20-024274:notes:2]
[same as prior period, unchanged from 0001564590-20-002754:notes:2]

[0001564590-20-024274:notes:3]
[same as prior period, unchanged from 0001564590-20-002754:notes:3]

[0001564590-20-024274:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2020. The results of operations for the three and nine months ended March 31, 2020 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.

[0001564590-20-024274:notes:5]
[same as prior period, unchanged from 0001564590-20-002754:notes:5]

[0001564590-20-024274:notes:6]
[same as prior period, unchanged from 0001564590-20-002754:notes:6]

[0001564590-20-024274:notes:7]
[same as prior period, unchanged from 0001564590-20-002754:notes:7]

[0001564590-20-024274:notes:8]
[same as prior period, unchanged from 0001564590-20-002754:notes:8]

[0001564590-20-024274:notes:9]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenue and expenses are translated using the monthly average rate.

[0001564590-20-024274:notes:10]
[same as prior period, unchanged from 0001564590-20-002754:notes:10]

[0001564590-20-024274:notes:11]
[same as prior period, unchanged from 0001564590-20-002754:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-20-024274:notes:12]
[same as prior period, unchanged from 0001564590-20-002754:notes:12]

[0001564590-20-024274:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K, except for the adoption of the new lease guidance, new derivatives and hedging guidance and related policies as discussed within these financial statements.

[0001564590-20-024274:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-20-024274:notes:15]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also requires lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

[0001564590-20-024274:notes:16]
[same as prior period, unchanged from 0001564590-20-002754:notes:16]

[0001564590-20-024274:notes:17]
[same as prior period, unchanged from 0001564590-20-002754:notes:17]

[0001564590-20-024274:notes:18]
On July 1, 2019, the Company recognized ROU assets of $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases.

[0001564590-20-024274:notes:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption. During the third quarter of fiscal 2020, the Company entered into interest rate swap agreements to manage its exposure to fluctuations of interest rates associated with its debt.  See Note 14, Derivatives and Hedging, for additional information.

[0001564590-20-024274:notes:20]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), which allows the reclassification from Additional Other Comprehensive Income (“AOCI”) to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act").  The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI.  This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-20-024274:notes:21]
In March 2020, the FASB issued ASU 2020-04, “Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by the discontinuation of the London Interbank Offered Rate (LIBOR) and other interbank offered rates. This guidance is

[0001564590-20-024274:notes:22]
effective upon issuance and can be applied to applicable contract modifications through December 31, 2022. The Company elected to apply the amendments in this update to eligible hedging relationships existing as of January 1, 2020 or entered into during the three months ended March 31, 2020 in accordance with the transition options available. This guidance did not have any impact upon adoption. The Company will apply this guidance to transactions or modifications of these arrangements as appropriate through transition period.

[0001564590-20-024274:notes:23]
Recently Issued Accounting Pronouncements

[0001564590-20-024274:notes:24]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2020.  The Company is currently evaluating the impact of this new standard on its condensed consolidated financial statements and related disclosures. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-024274:notes:25]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-024274:notes:26]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.

[0001564590-20-024274:notes:27]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures.  This guidance is effective for the Company’s fiscal year 2022, beginning on July 1, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-024274:notes:28]
3.Revenues

[0001564590-20-024274:notes:29]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from software delivered as a service (“SaaS”) and service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-20-024274:notes:30]
[same as prior period, unchanged from 0001564590-20-002754:notes:29]

[0001564590-20-024274:notes:31]
[same as prior period, unchanged from 0001564590-20-002754:notes:30]

[0001564590-20-024274:notes:32]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time. For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-20-024274:notes:33]
On March 31, 2020, the Company had $271.7 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 24 percent of its deferred revenue as revenue in fiscal 2020, an additional 46 percent in fiscal 2021 and 30 percent of the balance thereafter.

[0001564590-20-024274:notes:34]
[same as prior period, unchanged from 0001564590-20-002754:notes:33]

[0001564590-20-024274:notes:35]
Revenue recognized for the three months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $64.3 million and $54.8 million, respectively. Revenue recognized for the nine months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $116.7 million and $110.8 million, respectively.

[0001564590-20-024274:notes:36]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.4 million and $6.5 million at March 31, 2020 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2020 and 2019, was $1.1 million and $0.8 million, respectively. Amortization recognized during the nine months ended March 31, 2020 and 2019 was $4.1 million and $2.2 million, respectively.

[0001564590-20-024274:notes:37]
[same as prior period, unchanged from 0001564590-20-002754:notes:36]

[0001564590-20-024274:notes:38]
[same as prior period, unchanged from 0001564590-20-002754:notes:37]

[0001564590-20-024274:notes:39]
[same as prior period, unchanged from 0001564590-20-002754:notes:38]

[0001564590-20-024274:notes:40]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |
| Other |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |
| Total Americas |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |
| EMEA |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |
| APAC |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |
| Total net revenues |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |

[0001564590-20-024274:notes:41]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |
| Other |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |
| Total Americas |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |
| EMEA |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |
| APAC |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |
| Total net revenues |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |

[0001564590-20-024274:notes:42]
Included in the above amounts are $2.2 million and $6.9 million of leasing revenue for the three and nine months ended March 31, 2020, respectively.  Included in the above amounts are $2.7 million and $8.6 million of leasing revenue for the three and nine months ended March 31, 2019, respectively.

[0001564590-20-024274:notes:43]
[same as prior period, unchanged from 0001564590-20-002754:notes:42]

[0001564590-20-024274:notes:44]
[same as prior period, unchanged from 0001564590-20-002754:notes:43]

[0001564590-20-024274:notes:45]
[same as prior period, unchanged from 0001564590-20-002754:notes:44]

[0001564590-20-024274:notes:46]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Tech Data Corporation |  | 19% |  |  | 14% |  |  | 16% |  |  | 17% |  |
| Jenne Corporation |  | * |  |  | 21% |  |  | 13% |  |  | 15% |  |
| Westcon Group Inc. |  | 19% |  |  | 12% |  |  | 14% |  |  | 13% |  |

[0001564590-20-024274:notes:47]
* Less than 10% of net revenue.

[0001564590-20-024274:notes:48]
[same as prior period, unchanged from 0001564590-20-002754:notes:46]

[0001564590-20-024274:notes:49]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 11 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 10 | % |  |  | 35 | % |
| Westcon Group Inc. |  |  | 14 | % |  | * |  |

[0001564590-20-024274:notes:50]
* Less than 10% of accounts receivable.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-024274:notes:51]
[same as prior period, unchanged from 0001564590-20-002754:notes:48]

[0001564590-20-024274:notes:52]
[same as prior period, unchanged from 0001564590-20-002754:notes:49]

[0001564590-20-024274:notes:53]
[same as prior period, unchanged from 0001564590-20-002754:notes:50]

[0001564590-20-024274:notes:54]
The Acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets.  The purchase price was preliminarily allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The final purchase price allocation is pending the finalization of valuations including intangible assets, goodwill and income tax assets and liabilities that the Company is not able to finalize yet, which may result in an adjustment to the preliminary purchase price allocation.

[0001564590-20-024274:notes:55]
The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the Acquisition Date.  Inventories were valued at fair value using the net realizable value approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach.  The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate that was considered appropriate.  The resulting

[0001564590-20-024274:notes:56]
fair value approximates the amount the Company would be required to pay to a third party to assume the obligation.  Intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the Acquisition and the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition.  Results of operations of Aerohive have been included in the operations of the Company beginning with the Acquisition Date.

[0001564590-20-024274:notes:57]
The components of aggregate purchase consideration are as follows (in thousands):

[0001564590-20-024274:notes:58]
[same as prior period, unchanged from 0001564590-20-002754:notes:55]

[0001564590-20-024274:notes:59]
[same as prior period, unchanged from 0001564590-20-002754:notes:56]

[0001564590-20-024274:notes:60]
|  | Preliminary Allocation as of August 9, 2019 |  |  | Adjustments |  |  |  |  | Allocation as of March 31, 2020 |  |
| Cash and cash equivalents | $ | 44,158 |  |  | $ | — |  |  |  |  | $ | 44,158 |  |
| Short-term investments |  | 45,148 |  |  |  | — |  |  |  |  |  | 45,148 |  |
| Accounts receivable, net |  | 11,753 |  |  |  | — |  |  |  |  |  | 11,753 |  |
| Inventories |  | 16,698 |  |  |  | 2,534 |  |  | a |  |  | 19,232 |  |
| Prepaid expenses and other current assets |  | 3,980 |  |  |  | (56 | ) |  | b |  |  | 3,924 |  |
| Property and equipment |  | 2,185 |  |  |  | 179 |  |  | c |  |  | 2,364 |  |
| Operating lease right-of-use assets |  | 6,336 |  |  |  | — |  |  |  |  |  | 6,336 |  |
| Other assets |  | 2,195 |  |  |  | — |  |  |  |  |  | 2,195 |  |
| Debt |  | (20,000 | ) |  |  | — |  |  |  |  |  | (20,000 | ) |
| Accounts payable |  | (9,737 | ) |  |  | — |  |  |  |  |  | (9,737 | ) |
| Accrued compensation and benefits |  | (7,129 | ) |  |  | — |  |  |  |  |  | (7,129 | ) |
| Accrued warranty |  | (570 | ) |  |  | — |  |  |  |  |  | (570 | ) |
| Other accrued liabilities |  | (1,960 | ) |  |  | — |  |  |  |  |  | (1,960 | ) |
| Operating lease liabilities |  | (4,752 | ) |  |  | — |  |  |  |  |  | (4,752 | ) |
| Deferred revenue |  | (68,415 | ) |  |  | — |  |  |  |  |  | (68,415 | ) |
| Other liabilities |  | (408 | ) |  |  | — |  |  |  |  |  | (408 | ) |
| Net tangible assets |  | 19,482 |  |  |  | 2,657 |  |  |  |  |  | 22,139 |  |
| Identifiable intangible assets |  | 53,400 |  |  |  | (900 | ) |  | d |  |  | 52,500 |  |
| Goodwill |  | 194,264 |  |  |  | (1,757 | ) |  | a,b,c,d |  |  | 192,507 |  |
| Total intangible assets acquired |  | 247,664 |  |  |  | (2,657 | ) |  |  |  |  | 245,007 |  |
| Total net assets acquired | $ | 267,146 |  |  |  | — |  |  |  |  | $ | 267,146 |  |

[0001564590-20-024274:notes:61]
The changes during the period in the table above include: a) adjustment of the fair value of inventories acquired, b) write-off of an asset with no future economic value as of the Acquisition Date, c) adjustment to the value of property and equipment as of the Acquisition Date at an international location, and d) adjustment to the fair value of intangibles.

[0001564590-20-024274:notes:62]
[same as prior period, unchanged from 0001564590-20-002754:notes:59]

[0001564590-20-024274:notes:63]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 4 |  |  | $ | 39,100 |  |
| Backlog |  |  | 1 |  |  |  | 400 |  |
| Customer relationships |  |  | 7 |  |  |  | 11,400 |  |
| Trade names |  |  | 1 |  |  |  | 1,600 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 52,500 |  |

[0001564590-20-024274:notes:64]
The amortization for the developed technology and backlog is recorded in “Cost of revenues” for product and service and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying condensed consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of

[0001564590-20-024274:notes:65]
Aerohive. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as the Acquisition is a nontaxable stock acquisition.

[0001564590-20-024274:notes:66]
The results of operations of Aerohive are included in the accompanying condensed consolidated statements of operations beginning August 9, 2019.  The Aerohive revenue for the three and nine months ended March 31, 2020 was $27.0 million and $94.3 million, respectively, and was incorporated into the revenue of the Company.  Certain associated expenses of Aerohive were incorporated with the results of operations of the Company and, therefore, stand-alone operating results are not available.

[0001564590-20-024274:notes:67]
In the three and nine months ended March 31, 2020, the Company incurred acquisition and integration related expenses of $5.2 million and $30.1 million, respectively, associated with the Acquisition.  In the quarter ended September 30, 2019, this included a $6.8 million compensation charge for certain Aerohive Executive stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts.  Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for terminated Aerohive employees.  Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-20-024274:notes:68]
Pro Forma Financial Information

[0001564590-20-024274:notes:69]
[same as prior period, unchanged from 0001564590-20-002754:notes:65]

[0001564590-20-024274:notes:70]
[same as prior period, unchanged from 0001564590-20-002754:notes:66]

[0001564590-20-024274:notes:71]
The unaudited pro forma financial information for the three and nine months ended March 31, 2020 combines the historical results for Extreme for such periods, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-20-024274:notes:72]
Pro forma results of operations for the three and nine months ended March 31, 2019 combines the historical results of operations for Extreme and for Aerohive.

[0001564590-20-024274:notes:73]
[same as prior period, unchanged from 0001564590-20-002754:notes:69]

[0001564590-20-024274:notes:74]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Net revenues |  | $ | 210,255 |  |  | $ | 282,229 |  |  | $ | 746,301 |  |  | $ | 850,337 |  |
| Net loss |  | $ | (37,873 | ) |  | $ | (23,272 | ) |  | $ | (66,720 | ) |  | $ | (83,051 | ) |
| Net loss per share - basic and diluted |  | $ | (0.32 | ) |  | $ | (0.20 | ) |  | $ | (0.56 | ) |  | $ | (0.71 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 119,162 |  |  |  | 117,944 |  |  |  | 119,648 |  |  |  | 117,619 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-024274:notes:75]
[same as prior period, unchanged from 0001564590-20-002754:notes:71]

[0001564590-20-024274:notes:76]
[same as prior period, unchanged from 0001564590-20-002754:notes:72]

[0001564590-20-024274:notes:77]
[same as prior period, unchanged from 0001564590-20-002754:notes:73]

[0001564590-20-024274:notes:78]
[same as prior period, unchanged from 0001564590-20-002754:notes:74]

[0001564590-20-024274:notes:79]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Finished goods |  | $ | 55,790 |  |  | $ | 49,492 |  |
| Raw materials |  |  | 10,424 |  |  |  | 14,097 |  |
| Total Inventories |  | $ | 66,214 |  |  | $ | 63,589 |  |

[0001564590-20-024274:notes:80]
[same as prior period, unchanged from 0001564590-20-002754:notes:76]

[0001564590-20-024274:notes:81]
[same as prior period, unchanged from 0001564590-20-002754:notes:77]

[0001564590-20-024274:notes:82]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Computers and equipment |  | $ | 75,134 |  |  | $ | 72,309 |  |
| Purchased software |  |  | 33,467 |  |  |  | 29,126 |  |
| Office equipment, furniture and fixtures |  |  | 11,405 |  |  |  | 10,815 |  |
| Leasehold improvements |  |  | 52,167 |  |  |  | 51,245 |  |
| Total property and equipment |  |  | 172,173 |  |  |  | 163,495 |  |
| Less: accumulated depreciation and amortization |  |  | (109,212 | ) |  |  | (89,941 | ) |
| Property and equipment, net |  | $ | 62,961 |  |  | $ | 73,554 |  |

[0001564590-20-024274:notes:83]
[same as prior period, unchanged from 0001564590-20-002754:notes:79]

[0001564590-20-024274:notes:84]
Deferred revenue represents amounts for (i) deferred maintenance and support revenue, (ii) deferred SaaS revenue, and (iii) other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001564590-20-024274:notes:85]
[same as prior period, unchanged from 0001564590-20-002754:notes:81]

[0001564590-20-024274:notes:86]
The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-20-024274:notes:87]
The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2020 and 2019 (in thousands):

[0001564590-20-024274:notes:88]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Balance beginning of period |  | $ | 16,209 |  |  | $ | 12,808 |  |  | $ | 14,779 |  |  | $ | 12,807 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | — |  |  |  | 570 |  |  |  | — |  |
| New warranties issued |  |  | 4,810 |  |  |  | 4,510 |  |  |  | 16,271 |  |  |  | 12,377 |  |
| Warranty expenditures |  |  | (5,797 | ) |  |  | (4,112 | ) |  |  | (16,398 | ) |  |  | (11,978 | ) |
| Balance end of period |  | $ | 15,222 |  |  | $ | 13,206 |  |  | $ | 15,222 |  |  | $ | 13,206 |  |

[0001564590-20-024274:notes:89]
[same as prior period, unchanged from 0001564590-20-002754:notes:85]

[0001564590-20-024274:notes:90]
Other Long-term Liabilities

[0001564590-20-024274:notes:91]
[same as prior period, unchanged from 0001564590-20-002754:notes:87]

[0001564590-20-024274:notes:92]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Acquisition-related deferred payments, less current portion |  | $ | 6,797 |  |  | $ | 9,604 |  |
| Contingent consideration obligations, less current portion |  |  | 626 |  |  |  | 2,688 |  |
| Other contractual obligations, less current portion |  |  | 18,707 |  |  |  | 26,261 |  |
| Other |  |  | 3,802 |  |  |  | 15,597 |  |
| Total other long-term liabilities |  | $ | 29,932 |  |  | $ | 54,150 |  |

[0001564590-20-024274:notes:93]
[same as prior period, unchanged from 0001564590-20-002754:notes:89]

[0001564590-20-024274:notes:94]
[same as prior period, unchanged from 0001564590-20-002754:notes:90]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-024274:notes:95]
[same as prior period, unchanged from 0001564590-20-002754:notes:91]

[0001564590-20-024274:notes:96]
[same as prior period, unchanged from 0001564590-20-002754:notes:92]

[0001564590-20-024274:notes:97]
[same as prior period, unchanged from 0001564590-20-002754:notes:93]

[0001564590-20-024274:notes:98]
[same as prior period, unchanged from 0001564590-20-002754:notes:94]

[0001564590-20-024274:notes:99]
[same as prior period, unchanged from 0001564590-20-002754:notes:95]

[0001564590-20-024274:notes:100]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at March 31, 2020 (in thousands). The Company had one fair value item at June 30, 2019, a level 3 acquisition-related contingent consideration obligation of $6.3 million.

[0001564590-20-024274:notes:101]
| March 31, 2020 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 231 |  |  | $ | — |  |  | $ | 231 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 231 |  |  | $ | — |  |  | $ | 231 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 97 |  |  | $ | — |  |  | $ | 97 |  |
| Interest rate swaps |  | $ | — |  |  | $ | 958 |  |  | $ | — |  |  | $ | 958 |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 2,940 |  |  | $ | 2,940 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,055 |  |  | $ | 2,940 |  |  | $ | 3,995 |  |

[0001564590-20-024274:notes:102]
The Company has no Level 1 assets or liabilities at March 31, 2020 or June 30, 2019.

[0001564590-20-024274:notes:103]
The fair value of derivative instruments under our foreign currency contracts is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.

[0001564590-20-024274:notes:104]
As of March 31, 2020, forward foreign currency contracts had a notional principal amount of $13.3 million and for the three and nine months ended March 31, 2020, there were gains of $0.1 million. These contracts have maturities of less than 30 days. Changes in the fair value of these foreign exchange forward contracts are included in other income or expense. See Note 14, Derivatives and Hedging, for additional information.

[0001564590-20-024274:notes:105]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of March 31, 2020, the Company had entered into multiple interest rate swap contracts with the total notional amount of $200 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive income (loss). As of March 31, 2020, these contracts had an unrealized loss of $1.0 million. See Note 14, Derivatives and Hedging, for additional information.

[0001564590-20-024274:notes:106]
The fair value of the borrowings under the 2019 Credit Agreement (as defined below) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the recent establishment of the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $425.5 million and $180.5 million as of March 31, 2020, and June 30, 2019, respectively.

[0001564590-20-024274:notes:107]
At March 31, 2020 and June 30, 2019, the Company reflected one liability measured at fair value of $2.9 million and $6.3 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-20-024274:notes:108]
[same as prior period, unchanged from 0001564590-20-002754:notes:101]

[0001564590-20-024274:notes:109]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |
| Beginning balance |  |  | 6,298 |  |
| Payments |  |  | (3,448 | ) |
| Accretion on discount |  |  | 90 |  |
| Ending balance |  | $ | 2,940 |  |

[0001564590-20-024274:notes:110]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three and nine months ended March 31, 2020, or 2019. There were no impairments recorded for the three and nine months ended March 31, 2020, or 2019.

[0001564590-20-024274:notes:111]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method.  Realized gains or losses recognized on the sale of investment securities were not significant for the three and nine months ended March 31, 2020,or 2019.


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001564590-20-024274:notes:112]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at March 31, 2020 (in thousands).


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-20-024274:notes:113]
[same as prior period, unchanged from 0001564590-20-002754:notes:105]

[0001564590-20-024274:notes:114]
[same as prior period, unchanged from 0001564590-20-002754:notes:106]

[0001564590-20-024274:notes:115]
|  |  | March 31, 2020 |  |
| Balance as of June 30, 2019 |  | $ | 138,577 |  |
| Additions due to acquisition (see Note 4) |  |  | 192,507 |  |
| Balance at end of period |  | $ | 331,084 |  |

[0001564590-20-024274:notes:116]
[same as prior period, unchanged from 0001564590-20-002754:notes:108]

[0001564590-20-024274:notes:117]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.6 years |  | $ | 156,100 |  |  | $ | 97,193 |  |  | $ | 58,907 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 48,281 |  |  |  | 14,758 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.5 years |  |  | 10,700 |  |  |  | 7,794 |  |  |  | 2,906 |  |
| License agreements |  | 5.6 years |  |  | 2,445 |  |  |  | 1,864 |  |  |  | 581 |  |
| Other intangibles |  | — years |  |  | 1,382 |  |  |  | 1,382 |  |  |  | — |  |
| Total intangibles, net |  |  |  | $ | 234,066 |  |  | $ | 156,914 |  |  | $ | 77,152 |  |

[0001564590-20-024274:notes:118]
[same as prior period, unchanged from 0001564590-20-002754:notes:110]

[0001564590-20-024274:notes:119]
[same as prior period, unchanged from 0001564590-20-002754:notes:111]

[0001564590-20-024274:notes:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Amortization in “Cost of revenues: Product and Service” |  | $ | 6,629 |  |  | $ | 4,890 |  |  | $ | 20,094 |  |  | $ | 14,726 |  |
| Amortization of intangibles in "Operations" |  |  | 2,059 |  |  |  | 1,292 |  |  |  | 6,366 |  |  |  | 5,008 |  |
| Total amortization |  | $ | 8,688 |  |  | $ | 6,182 |  |  | $ | 26,460 |  |  | $ | 19,734 |  |

[0001564590-20-024274:notes:121]
The amortization expense that is recognized in “Cost of revenues: Product and Service” is comprised of amortization for developed technology, license agreements and other intangibles.


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-024274:notes:122]
| 8. | Debt |

[0001564590-20-024274:notes:123]
The Company’s debt is comprised of the following (in thousands):

[0001564590-20-024274:notes:124]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,819 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 351,500 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (6,796 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 399,704 |  |  |  | 169,739 |  |
| Total debt |  | $ | 416,523 |  |  | $ | 178,750 |  |

[0001564590-20-024274:notes:125]
In connection with the Acquisition as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-20-024274:notes:126]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-20-024274:notes:127]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-20-024274:notes:128]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-024274:notes:129]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $10.5 million of deferred financing costs in conjunction with this modification of the debt and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of March 31, 2020 was 5.1%.

[0001564590-20-024274:notes:130]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.6 million and $0.2 million for the three months ended March 31, 2020 and 2019, and totaled $1.8 million and $0.5 million for the nine months ended March 31, 2020 and 2019, respectively.

[0001564590-20-024274:notes:131]
The Company had $7.7 million of outstanding letters of credit as of March 31, 2020.

[0001564590-20-024274:notes:132]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and the Company is restricted  from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company 
is in compliance with the original covenants of the 2019 Credit Agreement.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-20-024274:notes:133]
[same as prior period, unchanged from 0001564590-20-002754:notes:124]

[0001564590-20-024274:notes:134]
[same as prior period, unchanged from 0001564590-20-002754:notes:125]

[0001564590-20-024274:notes:135]
The Company leases certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2028. Its leases generally have terms that range from one year to eight years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0001564590-20-024274:notes:136]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or right-of-use (“ROU”) asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is a hypothetical rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. Operating lease assets also included a reclassification for previous asset impairments and associated restructuring liabilities, deferred rent, lease incentives and initial direct costs which reduced the operating lease ROU assets as of July 1, 2019.

[0001564590-20-024274:notes:137]
[same as prior period, unchanged from 0001564590-20-002754:notes:128]

[0001564590-20-024274:notes:138]
[same as prior period, unchanged from 0001564590-20-002754:notes:129]

[0001564590-20-024274:notes:139]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  | March 31, 2020 |  |
| Operating lease costs | $ | 4,871 |  | $ | 14,874 |  |
| Variable lease costs |  |  | 1,613 |  |  | 4,548 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 5,328 |  |  | 16,159 |  |
| ROU assets obtained for new lease obligations |  | 1,103 |  |  | 2,525 |  |
| ROU assets obtained from Aerohive business combination |  | — |  |  | 6,336 |  |

[0001564590-20-024274:notes:140]
|  |  | March 31, 2020 |  |
| Weighted average remaining lease term (in years) |  | 4.5 |  |
| Weighted Average Discount Rate |  | 4.5 | % |

[0001564590-20-024274:notes:141]
Short-term lease expense which represents expense for leases that have terms of one year or less was not material for the three and nine months ended March 31, 2020.

[0001564590-20-024274:notes:142]
The maturities of the Company’s operating lease liabilities as of March 31, 2020 by fiscal year are as follows:

[0001564590-20-024274:notes:143]
|  |  | Operating Leases (in thousands) |  |
| 2020 (remaining three months) |  | $ | 5,356 |  |
| 2021 |  |  | 20,509 |  |
| 2022 |  |  | 19,351 |  |
| 2023 |  |  | 15,666 |  |
| 2024 |  |  | 6,333 |  |
| Thereafter |  |  | 12,396 |  |
| Total future minimum lease payments |  |  | 79,611 |  |
| Less amount representing interest |  |  | 7,559 |  |
| Total operating lease liabilities |  | $ | 72,052 |  |
| Operating lease liabilities, current |  | $ | 18,197 |  |
| Operating lease liabilities, non-current |  | $ | 53,855 |  |

[0001564590-20-024274:notes:144]
[same as prior period, unchanged from 0001564590-20-002754:notes:135]

[0001564590-20-024274:notes:145]
[same as prior period, unchanged from 0001564590-20-002754:notes:136]

[0001564590-20-024274:notes:146]
[same as prior period, unchanged from 0001564590-20-002754:notes:137]

[0001564590-20-024274:notes:147]
The Company currently is a sublessor on several operating facility subleases that expire on various dates through fiscal 2023. The subleases have terms from 5 to 6 years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. These operating subleases include only lease components. Included in lease expense, the Company had $0.6 million and $1.9 million of sublease income for the three and nine months ended March 31, 2020, respectively.

[0001564590-20-024274:notes:148]
[same as prior period, unchanged from 0001564590-20-002754:notes:139]

[0001564590-20-024274:notes:149]
Although most of the Company’s revenue from its hardware business comes from sales of hardware, the Company also sells subscription contracts which contain both operating lease and non-lease components. These leases range in duration generally up to three years with payments generally collected in equal quarterly installments, do not include purchase options, and include 60-day termination rights by either party. For the three months ended March 31, 2020 and 2019, $2.2 million and $2.7 million are included in product revenue in the Company’s condensed consolidated financial statements, respectively. For the nine months ended March 31, 2020 and 2019, $6.9 million and $8.6 million are included in product revenue in the Company’s condensed consolidated financial statements, respectively. There were no changes to the accounting treatment of these transactions from the adoption of ASC 842.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-024274:notes:150]
| 10. | Commitments and Contingencies |

[0001564590-20-024274:notes:151]
Purchase Commitments

[0001564590-20-024274:notes:152]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2020, the Company had commitments to purchase $37.1 million of inventory and other services.

[0001564590-20-024274:notes:153]
Legal Proceedings

[0001564590-20-024274:notes:154]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-20-024274:notes:155]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-20-024274:notes:156]
All currency conversions in this Legal Proceedings section are as of March 31, 2020.

[0001564590-20-024274:notes:157]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-20-024274:notes:158]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims

[0001564590-20-024274:notes:159]
of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is set for June 8, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-20-024274:notes:160]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-20-024274:notes:161]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  After a hearing on January 28, 2020, the Court rendered a decision in favor of the Company fully dismissing Orckit’s complaint.  Orckit  filed a notice of appeal on March 13, 2020.

[0001564590-20-024274:notes:162]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  The Company filed a nullity action with the German Federal Patent Court, seeking to invalidate the asserted patent.  Orckit has filed its formal opposition to the Company’s nullity action on March 11, 2020.  No hearing has been scheduled yet in this case, which was split from the original.

[0001564590-20-024274:notes:163]
The Company believes that all claims in both cases are without merit and intends to defend them vigorously.

[0001564590-20-024274:notes:164]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co.

[0001564590-20-024274:notes:165]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China.  In each lawsuit, GIA has accused a number of Summit switching products of infringing one of six patents (the “Asserted Patents”). One trial has been postponed, and the trials for the rest of the cases have not yet been scheduled. Additionally, the Company has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of five of the Asserted Patents.  The Company has appealed three of these rulings.  All the claims in one case have been fully invalidated.

[0001564590-20-024274:notes:166]
The Company disputes GIA’s claims and intends to defend the matter vigorously. Given the uncertainty of litigation and the preliminary stage of the case, the Company cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-024274:notes:167]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

[0001564590-20-024274:notes:168]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.4 million). The trial originally scheduled for November 15, 2019 has been postponed by the Court, pending the jurisdictional objections filed by Aerohive, and has not yet been rescheduled.  The Court rejected the jurisdictional challenge, which Aerohive is appealing. The Company cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-024274:notes:169]
Proven Networks, LLC v. Extreme Networks, Inc.

[0001564590-20-024274:notes:170]
On March 24, 2020, Proven Networks, LLC (“Proven”) filed a patent infringement lawsuit against the Company in the Northern District of California. The lawsuit alleges direct and indirect infringement of three U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of Extreme Analytics Extreme XOS, and certain network devices equipped with the Extreme XOS operating system.  Proven seeks injunctive relief, unspecified damages, pre- and post-judgment interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, the Company cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-024274:notes:171]
Indemnification Obligations

[0001564590-20-024274:notes:172]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-20-024274:notes:173]
[same as prior period, unchanged from 0001564590-20-002754:notes:166]

[0001564590-20-024274:notes:174]
[same as prior period, unchanged from 0001564590-20-002754:notes:167]

[0001564590-20-024274:notes:175]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (as amended, the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0001564590-20-024274:notes:176]
The Company’s Board of Directors (the “Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 8, 2020, to extend the Restated Rights Plan through May 31, 2021, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting.

[0001564590-20-024274:notes:177]
[same as prior period, unchanged from 0001564590-20-002754:notes:170]

[0001564590-20-024274:notes:178]
The Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan to increase the maximum number of available shares by 7,000,000 shares.  The amendment was ratified by a majority of the stockholders at the Company’s annual meeting of stockholders held on November 7, 2019.

[0001564590-20-024274:notes:179]
Employee Stock Purchase Plan

[0001564590-20-024274:notes:180]
The Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan to increase the maximum number of shares that will be available for sale thereunder by 7,500,000 shares.  The amendment was ratified by a majority of the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018.

[0001564590-20-024274:notes:181]
[same as prior period, unchanged from 0001564590-20-002754:notes:172]

[0001564590-20-024274:notes:182]
On November 2, 2018, the Company announced the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions.  A maximum of $35.0 million of the Company’s common stock may be repurchased in any calendar year. In February 2020, the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020.  The maximum repurchase in any year was decreased to $30.0 million.

[0001564590-20-024274:notes:183]
In November 2019, the Company entered into an accelerated share repurchase agreement (the “November 2019 ASR”) to repurchase shares of the Company’s common stock.  Pursuant to the November 2019 ASR, the Company paid $30.0 million for an initial delivery of 3,850,000 shares valued at $25.2 million. The remaining balance of $4.8 million was recorded in additional paid-in-capital as a forward contract in the Company’s common stock. The forward contract was settled on January 24, 2020 and the Company received an additional 381,505 shares of its common stock.  Total shares repurchased under the November 2019 ASR were 4,231,505 shares at an average cash purchase price paid of $7.09.

[0001564590-20-024274:notes:184]
The following table summarizes stock award activity representing the cost recorded for the three and nine months ended March 31, 2020 and 2019 (in thousands, except per share amounts).

[0001564590-20-024274:notes:185]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Total number of shares repurchased |  |  | 381 |  |  |  | — |  |  |  | 4,232 |  |  |  | 2,366 |  |
| Average price paid per share |  | $ | 12.64 |  |  | $ | — |  |  | $ | 7.09 |  |  | $ | 6.34 |  |
| Total cost of shares repurchased |  | $ | 4,821 |  |  | $ | — |  |  | $ | 30,000 |  |  | $ | 15,000 |  |
| Dollar value of shares that may yet be repurchased under program |  | $ | 55,000 |  |  | $ | 45,000 |  |  | $ | 55,000 |  |  | $ | 45,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-024274:notes:186]
[same as prior period, unchanged from 0001564590-20-002754:notes:177]

[0001564590-20-024274:notes:187]
Shares Reserved for Issuance

[0001564590-20-024274:notes:188]
The Company had reserved for issuance as of the dates noted (in thousands):

[0001564590-20-024274:notes:189]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 11,368 |  |  |  | 8,462 |  |
| Employee stock options and awards outstanding |  |  | 12,086 |  |  |  | 10,455 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,364 |  |  |  | 10,085 |  |
| Total shares reserved for issuance |  |  | 30,818 |  |  |  | 29,002 |  |

[0001564590-20-024274:notes:190]
[same as prior period, unchanged from 0001564590-20-002754:notes:181]

[0001564590-20-024274:notes:191]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the "Aerohive Plan").  Stock awards outstanding under the Aerohive Plan were converted into awards for Extreme shares as of the Acquisition Date at a predetermined rate pursuant to the Merger Agreement.  As of March 31, 2020, total awards to acquire 736,796 shares of Extreme common stock were outstanding under the Aerohive Plan.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0001564590-20-024274:notes:192]
Share-based Compensation Expense

[0001564590-20-024274:notes:193]
[same as prior period, unchanged from 0001564590-20-002754:notes:184]

[0001564590-20-024274:notes:194]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Cost of product revenue |  | $ | 280 |  |  | $ | 223 |  |  | $ | 932 |  |  | $ | 618 |  |
| Cost of service revenue |  |  | 368 |  |  |  | 648 |  |  |  | 1,220 |  |  |  | 1,670 |  |
| Research and development |  |  | 2,518 |  |  |  | 2,814 |  |  |  | 8,213 |  |  |  | 7,953 |  |
| Sales and marketing |  |  | 1,338 |  |  |  | 3,187 |  |  |  | 8,568 |  |  |  | 8,529 |  |
| General and administrative |  |  | 2,639 |  |  |  | 1,942 |  |  |  | 7,523 |  |  |  | 5,569 |  |
| Integration costs |  |  | — |  |  |  | — |  |  |  | 479 |  |  |  | — |  |
| Total share-based compensation expense |  | $ | 7,143 |  |  | $ | 8,814 |  |  | $ | 26,935 |  |  | $ | 24,339 |  |

[0001564590-20-024274:notes:195]
During the three and nine months ended March 31, 2020, and 2019, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-20-024274:notes:196]
[same as prior period, unchanged from 0001564590-20-002754:notes:187]

[0001564590-20-024274:notes:197]
[same as prior period, unchanged from 0001564590-20-002754:notes:188]

[0001564590-20-024274:notes:198]
The following table summarizes stock award activity for the nine months ended March 31, 2020 (in thousands, except grant date fair value):

[0001564590-20-024274:notes:199]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2019 |  |  | 7,736 |  |  | $ | 7.67 |  |  |  |  |  |
| Granted |  |  | 6,299 |  |  |  | 6.83 |  |  |  |  |  |
| Released |  |  | (3,365 | ) |  |  | 7.11 |  |  |  |  |  |
| Cancelled |  |  | (1,598 | ) |  |  | 7.28 |  |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2020 |  |  | 9,072 |  |  | $ | 7.40 |  |  | $ | 28,033 |  |
| Vested and expected to vest at March 31, 2020 |  |  | 6,397 |  |  | $ | 7.26 |  |  | $ | 25,947 |  |

[0001564590-20-024274:notes:200]
The following table summarizes stock option activity for the nine months ended March 31, 2020 (in thousands, except per share and contractual term):

[0001564590-20-024274:notes:201]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2019 |  |  | 2,719 |  |  | $ | 4.61 |  |  |  | 3.26 |  |  | $ | 5,070 |  |
| Granted |  |  | 637 |  |  |  | 6.70 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (217 | ) |  |  | 4.58 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (125 | ) |  |  | 6.02 |  |  |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2020 |  |  | 3,014 |  |  | $ | 4.99 |  |  |  | 3.39 |  |  | $ | 524 |  |
| Vested and expected to vest at March 31, 2020 |  |  | 3,014 |  |  | $ | 4.99 |  |  |  | 3.39 |  |  | $ | 524 |  |
| Exercisable at March 31, 2020 |  |  | 1,693 |  |  | $ | 3.78 |  |  |  | 1.43 |  |  | $ | 524 |  |

[0001564590-20-024274:notes:202]
The fair value of each stock option grant under the 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model.  The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.  The average fair value per share of the options granted during the nine months ended March 31, 2020 was $6.70.

[0001564590-20-024274:notes:203]
[same as prior period, unchanged from 0001564590-20-002754:notes:195]

[0001564590-20-024274:notes:204]
The RSUs granted during the nine months ended March 31, 2020 vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company. These RSUs included 566,038 RSUs to named executive officers and directors.

[0001564590-20-024274:notes:205]
During fiscal 2019 and 2018, the Company approved the grant of 0.6 million shares underlying stock awards each year in the form of PSU’s to named executive officers and other vice president level employees. These PSUs would be considered earned once the Company’s U.S. GAAP earnings aggregates at least $0.20 per share over two consecutive quarters (the “Performance Thresholds”). During the second quarter of fiscal 2020, the compensation committee of the Board modified the Performance Thresholds of $0.20 earnings per share over two consecutive quarters for PSUs issued in fiscal 2019 and 2018, to $0.09 earnings per share over two consecutive quarters. Upon satisfying the Performance Thresholds, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the Performance Thresholds is not met by the third anniversary of the grant date for each award, that award is canceled.  During the nine months ended March 31, 2020, the 2019 and 2018 Performance Thresholds for outstanding performance awards were not achieved.

[0001564590-20-024274:notes:206]
[same as prior period, unchanged from 0001564590-20-002754:notes:198]

[0001564590-20-024274:notes:207]
[same as prior period, unchanged from 0001564590-20-002754:notes:199]

[0001564590-20-024274:notes:208]
There were 1,498,155 and 1,499,042 shares issued under the ESPP during the three months ended March 31, 2020 and 2019, respectively. There were 2,721,699 and 2,779,750 shares issued under the ESPP during the nine months ended March 31, 2020 and 2019, respectively.  The following assumptions were used to calculate the fair value of shares issued under the ESPP during the following periods:

[0001564590-20-024274:notes:209]
|  |  | Employee Stock Purchase Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 1.56 | % |  |  | 2.46 | % |  |  | 1.71 | % |  |  | 2.35 | % |
| Volatility |  |  | 43 | % |  |  | 75 | % |  |  | 43 | % |  |  | 70 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-20-024274:notes:210]
The weighted-average fair value of shares issued under the ESPP during the nine months ended March 31, 2020 and 2019 was $1.90 and $2.71, respectively. The weighted-average fair value of shares issued under the ESPP during the three months ended March 31, 2020 and 2019 was $1.76 and $2.69, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-024274:notes:211]
[same as prior period, unchanged from 0001564590-20-002754:notes:203]

[0001564590-20-024274:notes:212]
[same as prior period, unchanged from 0001564590-20-002754:notes:204]

[0001564590-20-024274:notes:213]
See Note 3 Revenues for the Company’s revenues by geographic regions and channel based on the customer’s ship-to location.

[0001564590-20-024274:notes:214]
[same as prior period, unchanged from 0001564590-20-002754:notes:206]

[0001564590-20-024274:notes:215]
| Long-lived Assets |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Americas |  | $ | 203,865 |  |  | $ | 136,035 |  |
| EMEA |  |  | 25,417 |  |  |  | 28,744 |  |
| APAC |  |  | 17,573 |  |  |  | 11,529 |  |
| Total long-lived assets |  | $ | 246,855 |  |  | $ | 176,308 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-024274:notes:216]
| 14. | Derivativesand Hedging |

[0001564590-20-024274:notes:217]
Foreign Exchange Forward Contracts

[0001564590-20-024274:notes:218]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges.

[0001564590-20-024274:notes:219]
As of March 31, 2020, foreign exchange forward contracts had a notional principal amount of $13.3 million and as of the three and nine months ended March 31, 2020 there were gains of $0.1 million. These contracts have maturities of less than 30 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. As of March 31, 2019, the Company did not have any foreign exchange forward contracts outstanding.

[0001564590-20-024274:notes:220]
Foreign currency transactions gains and losses from operations was a gain of $0.9 million and a loss of less than $0.1 million for the three months ended March 31, 2020 and 2019, respectively. Foreign currency transactions gains and losses from operations was a loss of $1.1 million and a gain of $0.1 million for the nine months ended March 31, 2020 and 2019, respectively.

[0001564590-20-024274:notes:221]
Interest Rate Swaps

[0001564590-20-024274:notes:222]
The Company is exposed to interest rate risk on its debt. The Company enters into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which has floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0001564590-20-024274:notes:223]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive income (loss) and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0001564590-20-024274:notes:224]
During the three months ended March 31, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt.  As of March 31, 2020, the total notional amount of these interest rate swaps was $200 million and had maturity dates through April 2023. As of March 31, 2020, these contracts had an unrealized loss of $1.0 million which is recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets and recorded in accumulated other comprehensive income (loss) in the condensed consolidated financial statements. The Company did not have any interest rate swaps as of June 30, 2019. Realized gains and losses will be recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive income related to these cash flow hedges will be reclassified to interest expense as interest payments are made on our variable rate debt. The Company estimates that $0.1 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measures.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-024274:notes:225]
| 15. | Restructuring Charges, Net of Reversals, Impairment, and Related Charges. |

[0001564590-20-024274:notes:226]
The Company recorded $6.6 million and $19.4 million of restructuring charges, net of reversals and impairments during the three and nine months ended March 31, 2020, respectively. Total restructuring charges included facility related charges of $0.3 million and $8.2 million as well as charges for severance and benefits of $6.3 million and $11.2 million for the three and nine months ended March 31, 2020, respectively.

[0001564590-20-024274:notes:227]
During the first quarter of fiscal 2020, the Company moved to reduce its operating expenses by exiting a floor of its San Ignacio building in San Jose, California and consolidating its workforce.  Also, the Company exited additional space in its Salem, New Hampshire facility, which includes general office and lab space. The Company has the intent and ability to sub-lease these facilities which it has ceased using and as such, has considered estimated future sub-lease income based on its existing lease agreements, as well as the local real estate market conditions, in measuring the amount of asset impairment. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.  For the three months ended September 30, 2019, the Company recorded restructuring charges of $3.9 million related to impairment of ROU assets from exited facilities. In addition, the Company recorded severance and benefits charges of $2.2 million related to its reduction-in-force action which had begun in the fourth quarter of fiscal 2019.

[0001564590-20-024274:notes:228]
During the second quarter of fiscal 2020, the Company continued its initiative to realign its operations resulting from the acquisition of Aerohive and consolidating its workforce. The Company exited its facility in Milpitas, California which includes general office and lab space.  The Company has the intent and ability to sub-lease this facility which it has ceased using and as such has considered estimated future sub-lease income based on its existing lease agreement, as well as the local real estate market conditions in measuring the amount of asset impairment.  The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.  For the three months ended December 31, 2019, the Company recorded charges for the impairment of ROU assets of $2.8 million, long-lived assets of $0.9 million, and other charges of $0.2 million related to the exited facility.  In addition, the Company recorded severance and benefits charges of $2.7 million related to its reduction-in-force action which began in the fourth quarter of fiscal 2019.

[0001564590-20-024274:notes:229]
During the third quarter of fiscal 2020, the Company continued its initiative to reduce cost by realigning its workforce. In addition, with the global disruptions and slow-down in the demand of its products caused by the global pandemic outbreak, COVID-19, and the uncertainty around the timing of the recovery of the market, the Company initiated a reduction-in-force plan (the 2020 Plan) to reduce its operating costs and enhance financial flexibility. The plan affected approximately 300 employees primarily from the research and development and sales organizations who were located mainly in US and India. The Company recorded restructuring charges of $5.8 million during the three months ended March 31, 2020 related to the 2020 Plan. We expect to incur additional charges related to this 2020 Plan through the first quarter of fiscal 2021. The costs associated with this restructuring plan primarily included employee severance and benefit expenses. The Company recorded additional severance and benefits charges of $0.5 million for the three months ended March 31, 2020 related to the prior period restructuring plans. In addition, the Company recorded facility related charges of $0.3 million related to its previously impaired facilities for the three months ended March 31, 2020.

[0001564590-20-024274:notes:230]
[same as prior period, unchanged from 0001564590-20-002754:notes:212]

[0001564590-20-024274:notes:231]
Restructuring liabilities related to severance and benefits obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets.  Total restructuring and related liabilities as of March 31, 2020 consist of (in thousands):

[0001564590-20-024274:notes:232]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Total |  |
| Balance as of June 30, 2019 |  | $ | 1,764 |  |  | $ | 3,559 |  |  | $ | 5,323 |  |
| Period charges |  |  | — |  |  |  | 12,257 |  |  |  | 12,257 |  |
| Period reversals |  |  | — |  |  |  | (1,044 | ) |  |  | (1,044 | ) |
| Reclassification to reduce operating lease assets |  |  | (1,764 | ) |  |  | — |  |  |  | (1,764 | ) |
| Period payments |  |  | — |  |  |  | (8,568 | ) |  |  | (8,568 | ) |
| Balance as of March 31, 2020 |  | $ | — |  |  | $ | 6,204 |  |  | $ | 6,204 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-024274:notes:233]
| 16. | Income Taxes |

[0001564590-20-024274:notes:234]
For the three months ended March 31, 2020 and 2019, the Company recorded an income tax provision of $1.6 million and $1.9 million, respectively. For the nine months ended March 31, 2020 and 2019, the Company recorded an income tax provision of $4.9 million and an income tax benefit of $2.0 million, respectively.

[0001564590-20-024274:notes:235]
The income tax provisions for the three and nine months ended March 31, 2020 and 2019, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network (“WLAN”) business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade, and (4) state taxes in jurisdictions where the Company has no remaining state Net Operating Losses. In addition, the nine months ended March 31, 2019 included tax benefits associated with the release of valuation allowance resulting

[0001564590-20-024274:notes:236]
from changes introduced by US tax reform as well as the release of a valuation allowance recorded against deferred tax assets in Australia. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and nine months ended March 31, 2020 and 2019, respectively and therefore may not reflect the annual effective tax rate.

[0001564590-20-024274:notes:237]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in the United States.  The CARES Act, among other things, includes modifications to net operating loss carryforward provisions and the net interest expense deduction, and deferment of employer social security tax payments.  The Company has evaluated the provisions of the CARES Act and how certain elections may impact our financial position and results of operations, and have determined the enactment of the CARES Act did not have a material impact to our income tax provision for the three months ended March 31, 2020, or to our net deferred tax assets as of March 31, 2020.

[0001564590-20-024274:notes:238]
In the first quarter of the Company’s fiscal year ended June 30, 2019, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs. Historically, U.S. generally accepted accounting principles has prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset had been sold outside the consolidated group.  Effective July 1, 2018, the Company adopted ASU 2016-16 on a modified retrospective basis which requires an adjustment of the cumulative-effect of the adoption to retained earnings.  The adjustment was immaterial to the financial statements, and as such, no such adjustment was necessary.  As a result of adoption, the income tax consequences of future intra-entity transfer of assets will be recognized in earnings in each period rather than be deferred until the assets leave the consolidated group.  In the three months ended September 30, 2018, the Company recognized a deferred tax asset relating to a transfer of certain assets from the U.S. parent company to its wholly-owned Irish subsidiary of $3.7 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to Company’s statement of operations.

[0001564590-20-024274:notes:239]
[same as prior period, unchanged from 0001564590-20-002754:notes:220]

[0001564590-20-024274:notes:240]
On August 9, 2019, the Company completed its acquisition of Aerohive.  This acquisition was treated as a non-taxable stock acquisition and therefore Extreme Networks will have carryover tax basis in the assets and liabilities acquired.

[0001564590-20-024274:notes:241]
The Company had $24.6 million of unrecognized tax benefits as of March 31, 2020.  The future impact of the unrecognized tax benefit of $24.6 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-20-024274:notes:242]
[same as prior period, unchanged from 0001564590-20-002754:notes:223]

[0001564590-20-024274:notes:243]
[same as prior period, unchanged from 0001564590-20-002754:notes:224]


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-024274:notes:244]
| 17. | Net Loss Per Share |

[0001564590-20-024274:notes:245]
[same as prior period, unchanged from 0001564590-20-002754:notes:226]

[0001564590-20-024274:notes:246]
The following table presents the calculation of net loss per share of basic and diluted (in thousands, except per share data):

[0001564590-20-024274:notes:247]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Net loss |  | $ | (44,352 | ) |  | $ | (6,932 | ) |  | $ | (105,628 | ) |  | $ | (8,798 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 119,162 |  |  |  | 117,944 |  |  |  | 119,648 |  |  |  | 117,619 |  |
| Net loss per share - basic and diluted |  | $ | (0.37 | ) |  | $ | (0.06 | ) |  | $ | (0.88 | ) |  | $ | (0.07 | ) |

[0001564590-20-024274:notes:248]
[same as prior period, unchanged from 0001564590-20-002754:notes:229]

[0001564590-20-024274:notes:249]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Options to purchase common stock |  |  | 3,090 |  |  |  | 780 |  |  |  | 3,055 |  |  |  | 621 |  |
| Restricted stock units |  |  | 9,204 |  |  |  | 1,907 |  |  |  | 9,676 |  |  |  | 888 |  |
| Employee Stock Purchase Plan shares |  |  | 742 |  |  |  | 965 |  |  |  | 742 |  |  |  | 965 |  |
| Total shares excluded |  |  | 13,036 |  |  |  | 3,652 |  |  |  | 13,473 |  |  |  | 2,474 |  |
