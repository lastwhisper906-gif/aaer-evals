# EXTR MD&A — 0001564590-20-024274


## mdna

[0001564590-20-024274:mdna:1]
[same as prior period, unchanged from 0001564590-20-002754:mdna:1]

[0001564590-20-024274:mdna:2]
[same as prior period, unchanged from 0001564590-20-002754:mdna:2]

[0001564590-20-024274:mdna:3]
The following discussion is based upon our unaudited condensed consolidated financial statements included elsewhere in this Report.  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see the “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-20-024274:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”), is a leader in providing cloud-driven networking solutions for enterprise, data center, and service provider customers. Providing a combined end-to-end solution from the Internet of Things (“IoT”) edge to the cloud, Extreme designs, develops, and manufactures wired and wireless network infrastructure equipment and develops the software and cloud architecture for network management, policy, intelligence, analytics, security, and assurance. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. We derive substantially all of our revenue from the sale of our networking equipment, software, and related maintenance contracts.

[0001564590-20-024274:mdna:5]
Extreme delivers cloud-driven solutions from the IoT edge to the cloud that are agile, adaptive, and secure to enable autonomous enterprises of the future. We recognize that every customer environment is unique with its own requirements, which may be industry-specific or site driven. We address these distinctions with our Extreme Elements architecture. Elements gives customers and partners the power to mix and match a broad array of software, hardware, and services (including third-party applications) to create a custom network that can be managed and automated from end-to-end and enabled with intelligence and assurance from the cloud. With this strategic asset in place, organizations have the foundation needed to drive both digital transformation and the outcomes impacting each one of us.

[0001564590-20-024274:mdna:6]
[same as prior period, unchanged from 0001564590-20-002754:mdna:6]

[0001564590-20-024274:mdna:7]
Enterprise network administrators from the data center to the access layer need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security.  Accelerators such as IoT, artificial intelligence (“AI”), bring your own device (“BYOD”), machine learning (“ML”), cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-20-024274:mdna:8]
Improving the network experience for enterprises that increasingly require greater simplification at the edge or the access layer of the network to ensure business success and provide a secure, unified, wired / wireless infrastructure augmented and managed through a single pane of glass remains a key focus for Extreme. We enhanced our product portfolio in the first half of fiscal 2020 with

[0001564590-20-024274:mdna:9]
the introduction of ExtremeCloud IQ, the cloud management platform we acquired with Aerohive, and extended its reach to our portfolio of Extreme hardware, including our edge wired and wireless product families. This cloud-driven solution will be the only offering in the market that seamlessly integrates the Cloud with on premises infrastructures and spans from the IoT edge to the enterprise data center We also introduced a new line of data center spine/leaf switches, the SLX 9150 and 9250, and added ten new 802.11ax Access Points, giving our customers the broadest portfolio of Wi-Fi 6 devices in the industry. Enterprises have also migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties and are adopting new IT delivery models and applications that require fundamental network alterations and enhancements spanning from device access point to the network core.  In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments.

[0001564590-20-024274:mdna:10]
[same as prior period, unchanged from 0001564590-20-002754:mdna:10]

[0001564590-20-024274:mdna:11]
We are focused on delivering cloud-driven end-to-end networking and software solutions for today’s enterprise environments. From wireless and wired access technologies, through the campus, core, and into the datacenter, Extreme is developing solutions to deliver outstanding business outcomes for our customers. Leveraging a unified management approach, both on premises and in the cloud, we continue to accelerate adoption and delivery of new technologies in support of emerging trends in enterprise networking. We continue to execute on our growth objectives by seeking to maximize customer, partner, and stockholder value.

[0001564590-20-024274:mdna:12]
In fiscal 2017, we completed the acquisition of the Wireless Local Area Network (“WLAN”) Business from Zebra. In fiscal 2018, we completed the acquisitions of the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In August 2019, we acquired the entire Cloud Networking portfolio from Aerohive. These acquisitions support our growth strategy to lead the enterprise network equipment market with end-to-end software-driven cloud and on-premises solutions for enterprise customers from the data center to the wireless edge.  After the closing of the acquisitions of the Campus Fabric Business and Data Center Business, Extreme immediately became a networking industry leader with more than 30,000 customers. In addition, the acquisition of Aerohive brought us another 20,000+ customers and solidify our position as the third ranked networking vendor in the United States and the second ranked cloud networking provider globally.  As a network switching leader in enterprise, datacenter, and cloud, we combine and extend our world-class products and technologies to provide customers with some of the most advanced, high performance and open solutions in the market as well as a superb overall customer experience.  The combination of all the Extreme ElementsTM is significant in that it brings together distinct strengths addressing the key areas of the network, from unified wired and wireless edge, to the enterprise core, to the data center to offer a complete, unified portfolio of cloud-driven network access solutions.

[0001564590-20-024274:mdna:13]
[same as prior period, unchanged from 0001564590-20-002754:mdna:13]

[0001564590-20-024274:mdna:14]
[same as prior period, unchanged from 0001564590-20-002754:mdna:14]

[0001564590-20-024274:mdna:15]
[same as prior period, unchanged from 0001564590-20-002754:mdna:15]

[0001564590-20-024274:mdna:16]
[same as prior period, unchanged from 0001564590-20-002754:mdna:16]

[0001564590-20-024274:mdna:17]
|  | • | Creating effortless networking solutions that allow all of us to advance. We believe that progress is achieved when we connect—allowing us to learn, understand, create, and grow. We make connecting simple and easy with effortless networking experiences that enable all of us to advance how we live, work, and share. |

[0001564590-20-024274:mdna:18]
[same as prior period, unchanged from 0001564590-20-002754:mdna:17]

[0001564590-20-024274:mdna:19]
|  | • | Provide the industry’s first and only 4th generation end-to-end cloud architecture. Cloud technologies have evolved significantly over the past decade, from monolithic software images hosted remotely to microservices providing machine learning insights continuous integration and delivery of new features. We believe we deliver unrivaled innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the IoT edge to the enterprise data center. |

[0001564590-20-024274:mdna:20]
[same as prior period, unchanged from 0001564590-20-002754:mdna:19]

[0001564590-20-024274:mdna:21]
[same as prior period, unchanged from 0001564590-20-002754:mdna:46]

[0001564590-20-024274:mdna:22]
[same as prior period, unchanged from 0001564590-20-002754:mdna:20]

[0001564590-20-024274:mdna:23]
|  | • | Offer customers choice – cloud or on-premises. We leverage the cloud where it makes sense for our customers and provide on premises solutions where customers need it and have a solution for those that want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what’s going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for BYOD and IoT. |

[0001564590-20-024274:mdna:24]
[same as prior period, unchanged from 0001564590-20-002754:mdna:22]

[0001564590-20-024274:mdna:25]
[same as prior period, unchanged from 0001564590-20-002754:mdna:23]

[0001564590-20-024274:mdna:26]
[same as prior period, unchanged from 0001564590-20-002754:mdna:24]

[0001564590-20-024274:mdna:27]
[same as prior period, unchanged from 0001564590-20-002754:mdna:25]

[0001564590-20-024274:mdna:28]
[same as prior period, unchanged from 0001564590-20-002754:mdna:26]

[0001564590-20-024274:mdna:29]
|  | • | Provide high-quality customer service and support. We seek to enhance customer satisfaction and build customer loyalty through high-quality service and support. This includes a wide range of standard support programs to provide the level of service our customers require, from standard business hours to global 24-hour-a-day, 365-days-a-year real-time responsive support. |

[0001564590-20-024274:mdna:30]
[same as prior period, unchanged from 0001564590-20-002754:mdna:28]

[0001564590-20-024274:mdna:31]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The increase in demand being seen today, fueled by more users with multiple devices, increases the expectation that everything will just work. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our 4th generation cloud architecture with machine learning and AI-driven insights. |

[0001564590-20-024274:mdna:32]
[same as prior period, unchanged from 0001564590-20-002754:mdna:30]

[0001564590-20-024274:mdna:33]
[same as prior period, unchanged from 0001564590-20-002754:mdna:31]

[0001564590-20-024274:mdna:34]
[same as prior period, unchanged from 0001564590-20-002754:mdna:33]

[0001564590-20-024274:mdna:35]
Visibility into network and application performance enables our customers to pinpoint and resolve performance bottlenecks in the infrastructure whether they are caused by the network, application or server. This saves both time and money for the business and helps to ensure critical applications are running at the best possible performance.

[0001564590-20-024274:mdna:36]
[same as prior period, unchanged from 0001564590-20-002754:mdna:35]

[0001564590-20-024274:mdna:37]
|  | • | Expand market penetration by targeting high-growth market segments. Within the Campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our Data Center approach leverages our product portfolio to address the needs of public and private Cloud Data Center providers. Within the Campus we also target the high-growth physical security market, converging technologies such as Internet Protocol (“IP”) video across a common Ethernet infrastructure in conjunction with technology partners. Cloud networking compound annual growth rate will continue to outpace on premises managed networking and our focus is on expanding our technology foothold in this key segment with the acquisition of Aerohive to accelerate not only cloud management adoption, but also subscription-based licensing (SaaS) consumption. |

[0001564590-20-024274:mdna:38]
[same as prior period, unchanged from 0001564590-20-002754:mdna:37]

[0001564590-20-024274:mdna:39]
|  | • | Maintain and extend our strategic relationships. We have established strategic relationships with a number of industry-leading vendors to both provide increased and enhanced routes to market, but also to collaboratively develop unique solutions. We announced in the second quarter of our fiscal year ended June 30, 2020 that we were selected by Broadcom, the industry’s largest merchant silicon provider, as their preferred choice for enterprise campus deployments. As a Broadcom preferred provider for enterprise campus networking solutions, Extreme attempts to give enterprise customers and partners powerful security, segmentation, resiliency, policy, telemetry, and performance advantages as they pursue cloud-driven digital transformation with the industry's most simple, secure, and intelligent campus architecture. |

[0001564590-20-024274:mdna:40]
[same as prior period, unchanged from 0001564590-20-002754:mdna:39]

[0001564590-20-024274:mdna:41]
[same as prior period, unchanged from 0001564590-20-002754:mdna:40]

[0001564590-20-024274:mdna:42]
|  | • | ExtremeCloud IQTM. ExtremeCloud IQ is a robust cloud management platform that delivers visibility, intelligence, and assurance from the IoT edge to the core. The application helps organizations automate end-to-end network operations, unlock new analytics, scale faster, and secure and optimize the end user and application experience. |

[0001564590-20-024274:mdna:43]
|  | • | Extreme ElementsTM. Extreme Elements are the building blocks that enable the creation of an Autonomous Network to deliver the positive outcomes important to customer organizations, including those in education, healthcare, retail, manufacturing, transportation and logistics, and government. Combining architecture, automation, and artificial intelligence, Extreme Elements is designed to enable customers to get what they need, when and where they need it. |

[0001564590-20-024274:mdna:44]
|  | • | Cloud-Driven end-to-end networking solutions. The acquisition of Aerohive enhances our cloud offering with a 3rd generation cloud with Machine Learning/Artificial Intelligence insights and analytics that we intend to expand to all the Extreme ElementsTM. We believe this breadth of coverage from the edge to the enterprise data center will be unique in the industry, and cloud networking is projected to be the fastest growing segment of the networking industry. |

[0001564590-20-024274:mdna:45]
[same as prior period, unchanged from 0001564590-20-002754:mdna:43]

[0001564590-20-024274:mdna:46]
[same as prior period, unchanged from 0001564590-20-002754:mdna:44]

[0001564590-20-024274:mdna:47]
34

[0001564590-20-024274:mdna:48]
[same as prior period, unchanged from 0001564590-20-002754:mdna:45]

[0001564590-20-024274:mdna:49]
[same as prior period, unchanged from 0001564590-20-002754:mdna:47]

[0001564590-20-024274:mdna:50]
|  | • | Application-aware Quality of Service (“QoS”) and analytics. Extreme has innovative analytic software that enables our customers to see application usage across the network and apply policies to maximize network capabilities. This allows our customers to improve the user experience. |

[0001564590-20-024274:mdna:51]
[same as prior period, unchanged from 0001564590-20-002754:mdna:49]

[0001564590-20-024274:mdna:52]
|  | • | Easier policy assignment and Software Defined Networking (“SDN”). Our software applications allow our customers to assign policies across the entire network, and Extreme Workflow Composer improves IT agility by automating the entire network lifecycle—including initial provisioning, configuration, validation, and troubleshooting/auto-remediation—with event-driven automation. The SDN component adds versatility for implementing policies that increase network utilization. |

[0001564590-20-024274:mdna:53]
|  | • | 100% in-sourced tech support. We believe ExtremeWorks delivers best in class customer support in the industry with 92% first call resolution through a 100% in-sourced support model. |

[0001564590-20-024274:mdna:54]
|  | • | Strengthens the channel. Extreme sells products primarily through an ecosystem of channel partners which combine our portfolio elements together to create customized IT solutions for end user customers. |

[0001564590-20-024274:mdna:55]
[same as prior period, unchanged from 0001564590-20-002754:mdna:53]

[0001564590-20-024274:mdna:56]
During the third quarter of fiscal 2020, we achieved the following results:

[0001564590-20-024274:mdna:57]
|  | • | Net revenues of $209.5 million compared to $250.9 million in the third quarter of fiscal 2019. |

[0001564590-20-024274:mdna:58]
|  | • | Product revenue of $136.5 million compared to $190.8 million in the third quarter of fiscal 2019. |

[0001564590-20-024274:mdna:59]
|  | • | Service revenue of $73.0 million compared to $60.1 million in the third quarter of fiscal 2019. |

[0001564590-20-024274:mdna:60]
|  | • | Total gross margin of 53.1% of net revenues compared to 55.4% of net revenues in the third quarter of fiscal 2019. |

[0001564590-20-024274:mdna:61]
|  | • | Operating loss of $38.4 million compared to operating loss of $2.2 million in the third quarter of fiscal 2019. |

[0001564590-20-024274:mdna:62]
|  | • | Net loss of $44.4 million compared to $6.9 million in the third quarter of fiscal 2019. |

[0001564590-20-024274:mdna:63]
During the first nine months of fiscal 2020, we reflected the following results:

[0001564590-20-024274:mdna:64]
|  | • | Cash flow provided by operating activities of $27.1 million compared to cash flow provided by operating activities of $79.5 million in the nine months ended March 31, 2019. Cash of $196.4 million compared to $169.6 million as of June 30, 2019. |

[0001564590-20-024274:mdna:65]
Recent events

[0001564590-20-024274:mdna:66]
In January 2020, an outbreak of a new strain of coronavirus, COVID-19, was identified in Wuhan, China. Through the first quarter of 2020, the disease became widespread around the world, and on March 11, 2020, the World Health Organization declared a pandemic. The Coronavirus outbreak has had and we expect will continue to have an adverse effect on our results of operations due to supply chain disruptions and weakened demand for our products. For example, we recently realigned our operations and recorded severance and benefits charges of $5.8 million for the three months ended March 31, 2020. Although we expect to reduce research and development and sales and marketing costs, given the uncertainty around the extent and timing of the potential future spread or mitigation of the Coronavirus and around the imposition or relaxation of protective measures, we cannot further reasonably estimate the impact of the COVID-19 pandemic on our future results of operations or financial position. See also Part II, Item 1A – Risk Factors.

[0001564590-20-024274:mdna:67]
[same as prior period, unchanged from 0001564590-20-002754:mdna:63]

[0001564590-20-024274:mdna:68]
[same as prior period, unchanged from 0001564590-20-002754:mdna:64]

[0001564590-20-024274:mdna:69]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | $ Change |  |  | % Change |  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | $ Change |  |  | % Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 136,547 |  |  | $ | 190,740 |  |  | $ | (54,193 | ) |  |  | (28.4 | )% |  | $ | 512,173 |  |  | $ | 558,027 |  |  | $ | (45,854 | ) |  |  | (8.2 | )% |
| Percentage of net revenue |  |  | 65.2 | % |  |  | 76.0 | % |  |  |  |  |  |  |  |  |  |  | 69.9 | % |  |  | 75.1 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 72,972 |  |  |  | 60,124 |  |  |  | 12,848 |  |  |  | 21.4 | % |  |  | 220,324 |  |  |  | 185,403 |  |  |  | 34,921 |  |  |  | 18.8 | % |
| Percentage of net revenue |  |  | 34.8 | % |  |  | 24.0 | % |  |  |  |  |  |  |  |  |  |  | 30.1 | % |  |  | 24.9 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 209,519 |  |  | $ | 250,864 |  |  | $ | (41,345 | ) |  |  | (16.5 | )% |  | $ | 732,497 |  |  | $ | 743,430 |  |  | $ | (10,933 | ) |  |  | (1.5 | )% |

[0001564590-20-024274:mdna:70]
Product revenue decreased $54.2 million or 28.4% for the three months ended March 31, 2020, as compared to the corresponding period of fiscal 2019. Product revenue decreased $45.9 million or 8.2% for the nine months ended March 31, 2020, as compared to the corresponding period of fiscal 2019. Product revenue was impacted by a material slow-down in global demand in the last three weeks of March when most of Extreme's largest end markets enacted quarantine and social distancing protocols. Supply constraints, along with additional logistics related challenges in certain countries due to border closures, also contributed to the shortfall. Partially offsetting such revenue declines was growth relating to the acquisition of Aerohive.

[0001564590-20-024274:mdna:71]
Service revenue increased $12.8 million, or 21.4% for the three months ended March 31, 2020 as compared to the corresponding period in fiscal 2019. Service revenue increased $34.9 million, or 18.8% for the nine months ended March 31, 2020 as compared to the corresponding period in fiscal 2019. The increase in service revenues was primarily attributable to growth related to the acquisition of Aerohive.

[0001564590-20-024274:mdna:72]
[same as prior period, unchanged from 0001564590-20-002754:mdna:68]

[0001564590-20-024274:mdna:73]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | $ Change |  |  | % Change |  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 64,620 |  |  | $ | 103,864 |  |  | $ | (39,244 | ) |  |  | (37.8 | )% |  | $ | 257,468 |  |  | $ | 301,121 |  |  | $ | (43,653 | ) |  |  | (14.5 | )% |
| Percentage of product revenue |  |  | 47.3 | % |  |  | 54.5 | % |  |  |  |  |  |  |  |  |  |  | 50.3 | % |  |  | 54.0 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 46,715 |  |  |  | 35,055 |  |  |  | 11,660 |  |  |  | 33.3 | % |  |  | 139,781 |  |  |  | 111,168 |  |  |  | 28,613 |  |  |  | 25.7 | % |
| Percentage of service revenue |  |  | 64.0 | % |  |  | 58.3 | % |  |  |  |  |  |  |  |  |  |  | 63.4 | % |  |  | 60.0 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 111,335 |  |  | $ | 138,919 |  |  | $ | (27,584 | ) |  |  | (19.9 | )% |  | $ | 397,249 |  |  | $ | 412,289 |  |  | $ | (15,040 | ) |  |  | (3.6 | )% |
| Percentage of net revenues |  |  | 53.1 | % |  |  | 55.4 | % |  |  |  |  |  |  |  |  |  |  | 54.2 | % |  |  | 55.5 | % |  |  |  |  |  |  |  |  |

[0001564590-20-024274:mdna:74]
Product gross profit decreased $39.2 million or 37.8% for the three months ended March 31, 2020, as compared to the corresponding period in fiscal 2019. The decrease in product gross profit was primarily due to lower revenues, higher excess and obsolete inventory charges of $3.2 million, higher amortization of intangible assets of $1.0 million and higher distribution charges of $0.7 million.  This was partially offset by more favorable manufacturing costs due to cost reduction efforts and lower warranty costs.

[0001564590-20-024274:mdna:75]
Product gross profit decreased $43.7 million or 14.5% for the nine months ended March 31, 2020, as compared to the corresponding period in fiscal 2019.  The decrease in product gross profit was primarily due to lower revenues, the expensing of the fair value step-up of inventories acquired from Aerohive of $7.3 million, higher excess and obsolete inventory charges of $7.7 million, higher amortization of intangible assets of $3.2 million and higher distribution charges of $1.8 million.  This was partially offset by more favorable manufacturing costs due to cost reduction efforts.

[0001564590-20-024274:mdna:76]
Service gross profit increased $11.7 million and $28.6 million or 33.3% and 25.7% for the three and nine months ended March 31, 2020, as compared to the corresponding period in fiscal 2019. The increases were primarily due to a higher level of service revenues related to the acquisition of the Aerohive, partially offset by higher service material costs and personnel costs due to increased headcount to support acquired contracts as well as amortization of intangible assets of $0.8 million and $2.2 million for the respective three and nine months ended March 31, 2020.

[0001564590-20-024274:mdna:77]
[same as prior period, unchanged from 0001564590-20-002754:mdna:73]

[0001564590-20-024274:mdna:78]
[same as prior period, unchanged from 0001564590-20-002754:mdna:74]

[0001564590-20-024274:mdna:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | $ Change |  |  | % Change |  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 50,577 |  |  | $ | 52,081 |  |  | $ | (1,504 | ) |  |  | (2.9 | )% |  | $ | 165,073 |  |  | $ | 155,526 |  |  | $ | 9,547 |  |  |  | 6.1 | % |
| Sales and marketing |  |  | 70,132 |  |  |  | 72,321 |  |  |  | (2,189 | ) |  |  | (3.0 | )% |  |  | 216,925 |  |  |  | 208,245 |  |  |  | 8,680 |  |  |  | 4.2 | % |
| General and administrative |  |  | 15,119 |  |  |  | 15,479 |  |  |  | (360 | ) |  |  | (2.3 | )% |  |  | 45,199 |  |  |  | 42,136 |  |  |  | 3,063 |  |  |  | 7.3 | % |
| Acquisition and integration costs |  |  | 5,156 |  |  |  | — |  |  |  | 5,156 |  |  | * |  |  |  | 30,075 |  |  |  | 2,613 |  |  |  | 27,462 |  |  |  | 1,051.0 | % |
| Restructuring charges, net of reversals and impairment |  |  | 6,648 |  |  |  | — |  |  |  | 6,648 |  |  | * |  |  |  | 19,407 |  |  |  | 1,282 |  |  |  | 18,125 |  |  |  | 1,413.8 | % |
| Amortization of intangibles |  |  | 2,059 |  |  |  | 1,292 |  |  |  | 767 |  |  |  | 59.4 | % |  |  | 6,366 |  |  |  | 5,008 |  |  |  | 1,358 |  |  |  | 27.1 | % |
| Total operating expenses |  | $ | 149,691 |  |  | $ | 141,173 |  |  | $ | 8,518 |  |  |  | 6.0 | % |  | $ | 483,045 |  |  | $ | 414,810 |  |  | $ | 68,235 |  |  |  | 16.4 | % |

[0001564590-20-024274:mdna:80]
[same as prior period, unchanged from 0001564590-20-002754:mdna:76]

[0001564590-20-024274:mdna:81]
[same as prior period, unchanged from 0001564590-20-002754:mdna:77]

[0001564590-20-024274:mdna:82]
[same as prior period, unchanged from 0001564590-20-002754:mdna:78]

[0001564590-20-024274:mdna:83]
Research and development expenses decreased by $1.5 million or 2.9% for the three months ended March 31, 2020, as compared to the corresponding period in fiscal 2019. The decrease in research and development expenses was due to a $1.5 million decrease in salary and compensation costs and a $0.1 million decrease in facility and information technology costs partially offset by a $0.1 million increase in occupancy costs.

[0001564590-20-024274:mdna:84]
Research and development expenses increased by $9.5 million or 6.1% for the nine months ended March 31, 2020, as compared to the corresponding period in fiscal 2019 primarily due to the acquisition of Aerohive. The increase in research and development expenses was due to a $5.5 million increase in salary and compensation costs, $3.3 million increase in costs related to equipment, supplies and third-party design and engineering collaboration charges, $0.4 million increase in occupancy costs, and $0.5 million increase in facility and information technology costs, partially offset by a $0.2 million decrease in other operating costs.

[0001564590-20-024274:mdna:85]
[same as prior period, unchanged from 0001564590-20-002754:mdna:81]

[0001564590-20-024274:mdna:86]
[same as prior period, unchanged from 0001564590-20-002754:mdna:82]

[0001564590-20-024274:mdna:87]
Sales and marketing expenses decreased by $2.2 million or 3.0% for the three months ended March 31, 2020, as compared to the corresponding period in fiscal 2019. The decrease was primarily due to a $1.3 million decrease in personnel costs, $2.6 million decrease in travel and sales promotion costs, and $0.2 million decrease in occupancy and other costs partially offset by a $0.8 million increase in recruiting and professional fees, $0.3 million increase in facility and information technology costs and $0.8 million increase in software and equipment costs.

[0001564590-20-024274:mdna:88]
Sales and marketing expenses increased by $8.7 million or 4.2% for the nine months ended March 31, 2020, as compared to the corresponding period in fiscal 2019 primarily due to the acquisition of Aerohive. The increase was primarily due to a $7.3 million increase in personnel costs, $3.0 million increase in recruiting and professional fees, $2.0 million increase in facility and information technology costs, and $1.8 million increase in software and equipment costs, partially offset by a $5.1 million decrease in travel and sales promotion costs and a $0.3 million decrease in occupancy and other costs.

[0001564590-20-024274:mdna:89]
[same as prior period, unchanged from 0001564590-20-002754:mdna:85]

[0001564590-20-024274:mdna:90]
General and administrative expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001564590-20-024274:mdna:91]
General and administrative expenses decreased by $0.4 million or 2.3% for the three months ended March 31, 2020, as compared to the corresponding period in fiscal 2019. The decrease in general and administrative expenses was primarily due to a $1.4 million reduction in a lease liability reserve, a $0.2 million reduction in travel costs and a $0.2 million reduction in software, supplies and other costs partially offset by a $0.9 million increase in personnel costs, $0.1 million in higher facility and information technology costs, $0.1 million increase in professional fees, and $0.3 million increase in insurance premiums.

[0001564590-20-024274:mdna:92]
General and administrative expenses increased by $3.1 million or 7.3% for the nine months ended March 31, 2020, as compared to the corresponding period in fiscal 2019, primarily due to the acquisition of Aerohive. The increase in general and administrative expenses was primarily due to a $3.4 million increase in personnel costs, $0.6 million in higher facility and information technology costs, $0.2 million increase in professional fees, and $0.8 million of insurance premiums partially offset by a $1.4 million reduction in a lease liability reserve and a $0.5 million reduction in travel costs.

[0001564590-20-024274:mdna:93]
[same as prior period, unchanged from 0001564590-20-002754:mdna:89]

[0001564590-20-024274:mdna:94]
During the three and nine months ended March 31, 2020, we incurred $5.2 million and $30.1 million, respectively, of acquisition and integration costs. Acquisition and integration costs consisted primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees. The acquisition and integration costs for the nine months ended March 31, 2020 also included a $6.8 million compensation charge for certain Aerohive executives’ stock awards that were accelerated due to change-in-control and termination provisions included in the executives’ employment contracts.

[0001564590-20-024274:mdna:95]
During the three months ended March 31, 2019, we did not record any acquisition and integration costs. During the nine months ended March 31, 2019, we incurred $2.6 million of operating integration costs related to the acquisitions of the Campus Fabric Business from Avaya and Data Center Business from Brocade.

[0001564590-20-024274:mdna:96]
[same as prior period, unchanged from 0001564590-20-002754:mdna:92]

[0001564590-20-024274:mdna:97]
For the three months ended March 31, 2020 we recorded restructuring charges of $6.6 million.  In connection with our plan of action to reduce operating costs due to the global pandemic outbreak, COVID-19, we realigned our operations and recorded severance and benefits charges of $5.8 million for the third fiscal quarter of 2020.  We also continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and recorded related severance and benefits charges of $0.5 million for the third fiscal quarter of 2020.  In addition, we also had facility restructuring charges of $0.3 million for the third fiscal quarter of 2020.

[0001564590-20-024274:mdna:98]
For the nine months ended March 31, 2020 we recorded restructuring charges of $19.4 million. The charges consisted primarily of excess facility charges of $8.2 million for impairment of right-of-use assets related to our Milpitas California, South San Jose California, and Salem, New Hampshire facilities.  Additionally, we initiated reduction-in-force procedures during the nine months ended March 31, 2020 and recorded severance and benefits charges of $11.2 million.

[0001564590-20-024274:mdna:99]
For the three months ended March 31, 2019, we did not record any restructuring charges. For the nine months ended March 31, 2019, we recorded restructuring charges of $1.3 million associated with a reduction-in-force in the fourth quarter of fiscal 2018 and additional excess facility charges.

[0001564590-20-024274:mdna:100]
[same as prior period, unchanged from 0001564590-20-002754:mdna:96]

[0001564590-20-024274:mdna:101]
During the three months ended March 31, 2020 and 2019, we recorded $2.1 million and $1.3 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The increase was primarily due to amortization of acquired intangibles from the Aerohive acquisition, partially offset by lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-20-024274:mdna:102]
During the nine months ended March 31, 2020 and 2019, we recorded $6.4 million and $5.0 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The increase was primarily due to amortization of acquired intangibles from the Aerohive acquisition, partially offset by lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0001564590-20-024274:mdna:103]
[same as prior period, unchanged from 0001564590-20-002754:mdna:99]

[0001564590-20-024274:mdna:104]
During the three months ended March 31, 2020 and 2019, we recorded $6.0 million and $3.0 million, respectively, in interest expense.  The increase in interest expense was primarily driven by higher outstanding loan balances and other charges due to refinancing our 2018 Credit Agreement in August 2019.

[0001564590-20-024274:mdna:105]
During the nine months ended March 31, 2020 and 2019, we recorded $17.4 million and $9.6 million, respectively, in interest expense.  The increase in interest expense was primarily driven by higher outstanding loan balances and other charges due to refinancing our 2018 Credit Agreement in August 2019.

[0001564590-20-024274:mdna:106]
[same as prior period, unchanged from 0001564590-20-002754:mdna:102]

[0001564590-20-024274:mdna:107]
During the three months ended March 31, 2020 and 2019, we recorded other income of $1.3 million and other expense of $0.4 million, respectively, in other income (expense), net.  The change for the three months ended March 31, 2020 was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-20-024274:mdna:108]
During the nine months ended March 31, 2020 and 2019, we recorded other income of $1.1 million and other expense of $0.3 million, respectively, in other income (expense), net. The change for the nine months ended March 31, 2020 was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-20-024274:mdna:109]
[same as prior period, unchanged from 0001564590-20-002754:mdna:105]

[0001564590-20-024274:mdna:110]
For the three months ended March 31, 2020 and 2019, we recorded an income tax provision of $1.6 million and $1.9 million, respectively.  For the nine months ended March 31, 2020 and 2019, we recorded an income tax provision of $4.9 million and tax benefit of $2.0 million, respectively.

[0001564590-20-024274:mdna:111]
The income tax provisions for the three and nine months ended March 31, 2020 and 2019 consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business, and (4) state taxes in jurisdictions where the Company has no remaining state Net Operating Losses (“NOL’S”). In addition, the nine months ended March 31, 2019 included tax benefits associated with the release of valuation allowance resulting from changes introduced by U.S. tax reform as well as the release of a valuation allowance recorded against deferred tax assets in Australia.

[0001564590-20-024274:mdna:112]
[same as prior period, unchanged from 0001564590-20-002754:mdna:108]

[0001564590-20-024274:mdna:113]
Our unaudited condensed consolidated financial statements and the related notes included elsewhere in this report are prepared in accordance with accounting principles generally accepted in the United States. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under SEC rules and regulations. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. In many instances, we could have reasonably used different accounting estimates, and in other instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, actual results could differ significantly from the estimates made by our management. On an ongoing basis, we evaluate our estimates and assumptions. To the extent that there are material differences between these estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected.

[0001564590-20-024274:mdna:114]
[same as prior period, unchanged from 0001564590-20-002754:mdna:110]

[0001564590-20-024274:mdna:115]
[same as prior period, unchanged from 0001564590-20-002754:mdna:111]

[0001564590-20-024274:mdna:116]
[same as prior period, unchanged from 0001564590-20-002754:mdna:112]

[0001564590-20-024274:mdna:117]
[same as prior period, unchanged from 0001564590-20-002754:mdna:113]

[0001564590-20-024274:mdna:118]
[same as prior period, unchanged from 0001564590-20-002754:mdna:114]

[0001564590-20-024274:mdna:119]
[same as prior period, unchanged from 0001564590-20-002754:mdna:115]

[0001564590-20-024274:mdna:120]
[same as prior period, unchanged from 0001564590-20-002754:mdna:116]

[0001564590-20-024274:mdna:121]
[same as prior period, unchanged from 0001564590-20-002754:mdna:117]

[0001564590-20-024274:mdna:122]
The following table summarizes information regarding our cash and working capital (in thousands):

[0001564590-20-024274:mdna:123]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Cash |  | $ | 196,350 |  |  | $ | 169,607 |  |
| Working capital |  | $ | 20,984 |  |  | $ | 85,960 |  |

[0001564590-20-024274:mdna:124]
As of March 31, 2020, our principal sources of liquidity consisted of cash of $196.4 million and accounts receivable, net of $96.2 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, repayments of debt and related interest and repurchases of common stock outstanding. We believe that our $196.4 million of cash at March 31, 2020 and our cash flow from operations will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-20-024274:mdna:125]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in the second quarter of fiscal 2019.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. In November 2019, the Company entered into an accelerated share repurchase agreement (the “November 2019 ASR”) to repurchase shares of the Company’s common stock.  Pursuant to the November 2019 ASR, the Company paid $30.0 million for an initial delivery of 3,850,000 shares valued at $25.2 million. The remaining balance of $4.8 million was recorded as a forward contract in the Company’s common stock. The forward contract was settled on January 24, 2020, and the Company received an additional 381,505 shares of its common stock.

[0001564590-20-024274:mdna:126]
In connection with the acquisition of Aerohive as discussed in Note 4 of the accompanying condensed consolidated financial statements, as of August 9, 2019, we amended the 2018 Credit Agreement, which is no longer outstanding, and entered into the 2019 Credit Agreement, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (“2019 Revolving Facility”).  In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-20-024274:mdna:127]
[same as prior period, unchanged from 0001564590-20-002754:mdna:123]

[0001564590-20-024274:mdna:128]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-024274:mdna:129]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-024274:mdna:130]
On April 8, 2020, we entered into the first amendment to our 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants effective through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we are not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and we are restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. We expect to be in compliance with the original terms of the 2019 Credit Agreement prior to June 30, 2021.

[0001564590-20-024274:mdna:131]
We have already experienced an adverse effect on our revenues and results of operations due to the coronavirus outbreak. The full extent to which the COVID-19 outbreak impacts our results and cash flows will depend on future developments, which are highly uncertain and cannot be predicted at this time, including new information which may emerge concerning the severity of the coronavirus and the actions taken to contain the virus or treat its impact, among others. Complications from the COVID-19 outbreak could have a material adverse effect on the results of our operations, financial position, and cash flows particularly if such complications have an extended duration. See also Part II, Item 1A – Risk Factors.

[0001564590-20-024274:mdna:132]
[same as prior period, unchanged from 0001564590-20-002754:mdna:126]

[0001564590-20-024274:mdna:133]
[same as prior period, unchanged from 0001564590-20-002754:mdna:127]

[0001564590-20-024274:mdna:134]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Net cash provided by operating activities |  | $ | 27,061 |  |  | $ | 79,502 |  |
| Net cash used in investing activities |  |  | (186,839 | ) |  |  | (15,454 | ) |
| Net cash provided by (used in) financing activities |  |  | 187,262 |  |  |  | (28,178 | ) |
| Foreign currency effect on cash |  |  | (741 | ) |  |  | (196 | ) |
| Net increase in cash |  | $ | 26,743 |  |  | $ | 35,674 |  |

[0001564590-20-024274:mdna:135]
[same as prior period, unchanged from 0001564590-20-002754:mdna:129]

[0001564590-20-024274:mdna:136]
Cash flows provided by operations in the nine months ended March 31, 2020, were $27.1 million, including our net loss of $105.6 million and non-cash expenses of $100.4 million for items such as amortization of intangibles, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, restructuring charges, deferred income taxes and imputed interest.  Other sources of cash for the period included a decrease in accounts receivables, inventory and prepaid expenses and other current assets. This was partially offset by decreases in accounts payable, accrued compensation, other current and long-term liabilities, and operating lease liabilities.

[0001564590-20-024274:mdna:137]
Cash flows provided by operations in the nine months ended March 31, 2019, were $79.5 million, including our net loss of $8.8 million and non-cash expenses of $61.8 million for items such as amortization of intangibles, share-based compensation, depreciation, deferred income taxes and imputed interest. Other sources of cash for the period included a decrease in accounts receivables, and inventories and increases in deferred revenues. This was partially offset by decreases in accounts payable, accrued compensation and other current and long-term liabilities, and increases in prepaid expenses and other current assets.

[0001564590-20-024274:mdna:138]
[same as prior period, unchanged from 0001564590-20-002754:mdna:132]

[0001564590-20-024274:mdna:139]
Cash flows used in investing activities in the nine months ended March 31, 2020 were $186.8 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $12.6 million, which was partially offset by proceeds of $45.2 million related to the maturity and sales of short-term investments.

[0001564590-20-024274:mdna:140]
Cash flows used in investing activities in the nine months ended March 31, 2019 were $15.5 million which consisted of purchases of property and equipment of $16.2 million partially offset by proceeds of $0.7 million related to the sale of investments.

[0001564590-20-024274:mdna:141]
[same as prior period, unchanged from 0001564590-20-002754:mdna:135]

[0001564590-20-024274:mdna:142]
Cash flows provided by financing activities in the nine months ended March 31, 2020 were $187.3 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $55.0  million of borrowings under our 2019 Revolving Facility, $9.5 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options, net of taxes paid on vested and released stock awards. This was partially offset by debt repayments of $29.8 million, payment of loan fees of $10.5 million, contingent consideration of $3.4 million, and $3.0 million for deferred payments on acquisitions.

[0001564590-20-024274:mdna:143]
Cash flows provided by financing activities also included repurchasing of our common shares of $30.0 million during the nine months ended March 31, 2020, in accordance with our approved share repurchase plan. The share repurchases were executed through an accelerated share repurchase program, and future share repurchases may be completed through the combination of individually negotiated transactions, accelerated share repurchases, and/or open market purchases. As of March 31, 2020, we have $55.0 million available under our share repurchase plan. The 2019 Credit Agreement does not contain any restrictions on the amount of borrowings that can be used to make share repurchases, as long as we are in compliance with our financial and non-financial covenants.

[0001564590-20-024274:mdna:144]
Cash flows used in financing activities in the nine months ended March 31, 2019 were $28.2 million consisting of repayments of debt totaling $17.4 million, contingent consideration of $5.3 million, and $3.0 million for deferred payments on acquisitions.  This was partially offset by $13.0 million of proceeds from the issuance of shares of our common stock under our ESPP, the exercise of stock options and net of taxes paid on vested and released stock awards. Cash flows used in financing activities for the period also included repurchasing shares of our common stock valued at $15.0 million during the nine months ended March 31, 2019, in accordance with our approved share repurchase plan.

[0001564590-20-024274:mdna:145]
[same as prior period, unchanged from 0001564590-20-002754:mdna:139]

[0001564590-20-024274:mdna:146]
Foreign currency effect on cash decreased in the nine months ended March 31, 2020 and 2019, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, Indian Rupee and the EURO.

[0001564590-20-024274:mdna:147]
[same as prior period, unchanged from 0001564590-20-002754:mdna:141]

[0001564590-20-024274:mdna:148]
The following summarizes our contractual obligations as of March 31, 2020, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-20-024274:mdna:149]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 425,500 |  |  | $ | 19,000 |  |  |  |  | $ | 57,000 |  |  | $ | 349,500 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 84,965 |  |  |  | 21,705 |  |  |  |  |  | 40,001 |  |  |  | 23,259 |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 37,085 |  |  |  | 37,085 |  |  |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 100,658 |  |  |  | 20,367 |  |  |  |  |  | 40,733 |  |  |  | 20,171 |  |  |  | 19,387 |  |
| Lease payments on operating leases |  |  | 79,611 |  |  |  | 5,356 |  |  |  |  |  | 39,859 |  |  |  | 22,000 |  |  |  | 12,396 |  |
| Deferred payments for an acquisition |  |  | 12,000 |  |  |  | 4,000 |  |  |  |  |  | 8,000 |  |  |  | — |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 2,940 |  |  |  | 779 |  |  |  |  |  | 2,071 |  |  |  | 90 |  |  |  | — |  |
| Other liabilities |  |  | 187 |  |  |  | 43 |  |  |  |  |  | 86 |  |  |  | 58 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 742,946 |  |  | $ | 108,335 |  |  |  |  | $ | 187,750 |  |  | $ | 415,078 |  |  | $ | 31,783 |  |

[0001564590-20-024274:mdna:150]
[same as prior period, unchanged from 0001564590-20-002754:mdna:144]

[0001564590-20-024274:mdna:151]
[same as prior period, unchanged from 0001564590-20-002754:mdna:145]

[0001564590-20-024274:mdna:152]
[same as prior period, unchanged from 0001564590-20-002754:mdna:146]

[0001564590-20-024274:mdna:153]
[same as prior period, unchanged from 0001564590-20-002754:mdna:147]

[0001564590-20-024274:mdna:154]
Lease payments on operating leases represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001564590-20-024274:mdna:155]
Deferred payments for the acquisition of the Data Center Business represent payments of $1.0 million per quarter.

[0001564590-20-024274:mdna:156]
Contingent consideration for the Capital Financing Business acquisition, at the estimated fair value.  Actual payments could be different.

[0001564590-20-024274:mdna:157]
[same as prior period, unchanged from 0001564590-20-002754:mdna:151]

[0001564590-20-024274:mdna:158]
[same as prior period, unchanged from 0001564590-20-002754:mdna:152]

[0001564590-20-024274:mdna:159]
We did not have any material commitments for capital expenditures as of March 31, 2020.

[0001564590-20-024274:mdna:160]
[same as prior period, unchanged from 0001564590-20-002754:mdna:154]

[0001564590-20-024274:mdna:161]
We did not have any off-balance sheet arrangements as of March 31, 2020.
