# EXTR 8-K — 0001564590-20-024216 filed 2020-05-11

## item codes, every 8-K on or before 2020-05-11

- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2020-05-11

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-024216:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-20-024216:8k_2_02:2]
extr-ex991_6.htm

[0001564590-20-024216:8k_2_02:3]
Exhibit 99.1

[0001564590-20-024216:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-20-024216:8k_2_02:5]
Extreme Networks Reports Third Quarter Fiscal Year 2020 Financial Results

[0001564590-20-024216:8k_2_02:6]
Cloudifies edge portfolio with 4th generation platform; Application traffic on ExtremeCloud IQ grows 50% from nearly 1.2M connected devices

[0001564590-20-024216:8k_2_02:7]
SAN JOSE, Calif., May 11, 2020 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal third quarter ended March 31, 2020.

[0001564590-20-024216:8k_2_02:8]
Fiscal Third Quarter Results:

[0001564590-20-024216:8k_2_02:9]
|  | • | Revenue $209.5 million, down 16% year-over-year and down 22% quarter-over-quarter |

[0001564590-20-024216:8k_2_02:10]
|  | • | GAAP EPS $(0.37), down from $(0.06) year-over-year |

[0001564590-20-024216:8k_2_02:11]
|  | • | Non-GAAP EPS $(0.14), down from $0.08 year-over-year |

[0001564590-20-024216:8k_2_02:12]
|  | • | GAAP gross margin 53.1% compared to 55.4% in Q3 last year |

[0001564590-20-024216:8k_2_02:13]
|  | • | Non-GAAP gross margin 56.7% compared to 57.6% in Q3 last year |

[0001564590-20-024216:8k_2_02:14]
|  | • | GAAP operating margin (18.3)% compared to (0.9)% in Q3 last year |

[0001564590-20-024216:8k_2_02:15]
|  | • | Non-GAAP operating margin (5.1)%, compared to 5.6% in Q3 last year |

[0001564590-20-024216:8k_2_02:16]
|  | • | Net cash provided by operating activities of $5.2 million |

[0001564590-20-024216:8k_2_02:17]
|  | • | Free Cash Flow of $2.0 million |

[0001564590-20-024216:8k_2_02:18]
“I want to thank our employees for their dedication to our business initiatives and our customers. We reported Q3 results in-line with our earnings outlook update issued April 8. As we said then, the COVID-19 health crisis and resulting economic fallout remains an unprecedented headwind. Despite this backdrop, we are happy to say that we did not experience any material change in the competitive environment and continue to maintain large-scale deployments with improved visibility and confidence in our pipeline. We believe we will be able to execute on these opportunities in time,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-20-024216:8k_2_02:19]
“Even with these challenges, we took actions in the quarter to further strengthen our business. To address market needs, we accelerated our efforts to “cloudify” our portfolio and continued to roll out new products. Our teams executed on these initiatives ahead of schedule, despite operating in a remote work environment. With global priorities around business continuity and cloud-based networking becoming more important than ever, we believe we are well-positioned to capture the long-term market opportunity.  We will weather this challenge and I am confident Extreme will emerge from this as a stronger and more cohesive company” concluded Meyercord.

[0001564590-20-024216:8k_2_02:20]
Remi Thomas, CFO of Extreme Networks noted: “We continued to take actions to further strengthen our balance sheet. During Q3 we delivered positive operating cash flows and sequential improvement in our net debt position. As of March 31, we held nearly $200 million of cash on hand and I am also pleased to announce that we worked with our lenders to extend our covenant waiver until March 31, 2021 from July 31, 2020. During the quarter, we also took action to lower the non-GAAP breakeven point to approximately $220 million in revenue by reducing operating costs and accelerating our R&D and go-to-

[0001564590-20-024216:8k_2_02:21]
market transformations, all while further enhancing our financial flexibility.  We believe this puts us in a solid position to overcome the macroeconomic impact of COVID-19.”

[0001564590-20-024216:8k_2_02:22]
Recent Key Highlights:

[0001564590-20-024216:8k_2_02:23]
|  | • | Extreme announced the successful extension of its 4th generation cloud platform and ExtremeCloud™ IQ unified management platform with a simplified Pilot subscription model across its family of edge switches and access points. ExtremeCloud IQ adoption has grown by 40% in the trailing 12 months. Today, it manages over 1 million devices, with an average of 25,000+ administrator logins per day and ingests over 4 billion management messages daily that feed its machine learning and artificial intelligence engine. |

[0001564590-20-024216:8k_2_02:24]
|  | • | The School District of Manatee County in Florida has deployed ExtremeWireless access points in the parking lots of 52 elementary, middle, and high schools to allow students who may not have sufficient internet at home to download remote learning assignments during the COVID-19 crisis. The district provides education to over 49,000 students and employs over 7,000 people. |

[0001564590-20-024216:8k_2_02:25]
|  | • | The Lee County Sherriff’s Department in southwest Florida selected Extreme Premier professional services to design, deploy and maintain a network supporting its new Real Time Intelligence Center. The organization will deploy Extreme multi-service edge switches, access solutions and Wi-Fi technology, along with Fabric Connect network virtualization, to upgrade their entire network. The network supports approximately 1,600 sworn law enforcement personnel and civilian support staff to meet the needs of the county’s more than 700,000 residents. |

[0001564590-20-024216:8k_2_02:26]
|  | • | To support the operational vitality of its channel partners and the customers they serve through the COVID-19 pandemic, Extreme introduced LEAP - the Lending Enablement & Assistance Program - to provide preferential financial terms for qualified channel partners across the Americas and Europe through September 30, 2020. LEAP offers flexible, low interest financing, deferred payments, and free training, as well as reduced growth rebate targets, extended partner leveling requirements and training. |

[0001564590-20-024216:8k_2_02:27]
|  | • | Further demonstrating the value of cloudifying its portfolio, Extreme also introduced new Portable Branch Kits and Rapid Outdoor Connectivity Kits, enabling hospitals, schools, retail organizations, and other enterprises to use ExtremeCloud IQ to quickly and securely provision, deliver, and manage connectivity in lockstep with organizational requirements to offer secure, reliable, network access anywhere - a critical capability during this pandemic. |

[0001564590-20-024216:8k_2_02:28]
|  | • | As the Official Wi-Fi Solutions Provider to Super Bowl LIV, Extreme provided all of the Wi-Fi infrastructure and analytics for the event, held in February at the Hard Rock Stadium in Miami. Extreme "Smart Stadium" technology, co-developed with Verizon, provided a seamless transition from 5G and 4G LTE Networks to stadium Wi-Fi for Verizon customers at the event. This was the seventh consecutive season Extreme was the Official Wi-Fi Solutions Provider for the Super Bowl. |

[0001564590-20-024216:8k_2_02:29]
|  | • | Extreme announced it was named a February 2020 Gartner Peer Insights Customers' Choice for Wired and Wireless LAN Access Infrastructure. The company received a 4.9 out of 5 rating as of May 5, 2020 among customers across multiple verticals, including healthcare, education, and |

[0001564590-20-024216:8k_2_02:30]
|  |  | communications. This is the second consecutive time in which Extreme Networks was recognized by its customers as a Gartner Peer Insights Customers' Choice in this market. |

[0001564590-20-024216:8k_2_02:31]
Gartner Peer Insights Customers' Choice constitute the subjective opinions of individual end-user reviews, ratings, and data applied against a documented methodology; they neither represent the views of, nor constitute an endorsement by, Gartner or its affiliates.

[0001564590-20-024216:8k_2_02:32]
https://www.gartner.com/reviews/market/wired-wireless-lan-access-infrastructure

[0001564590-20-024216:8k_2_02:33]
Fiscal Q3 2020 Financial Metrics:

[0001564590-20-024216:8k_2_02:34]
(in millions, except percentages and per share information)

[0001564590-20-024216:8k_2_02:35]
|  |  | Q3 FY'20 |  |  | Q3 FY'19 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 136.5 |  |  | $ | 190.8 |  |  | $ | (54.3 | ) |  |  | (28 | )% |
| Service |  |  | 73.0 |  |  |  | 60.1 |  |  |  | 12.9 |  |  |  | 21 | % |
| Total net revenue |  | $ | 209.5 |  |  | $ | 250.9 |  |  | $ | (41.4 | ) |  |  | (17 | )% |
| Gross margin |  |  | 53.1 | % |  |  | 55.4 | % |  | -230 bps |  |  | - |  |
| Operating margin |  |  | (18.3 | )% |  |  | (0.9 | )% |  | -1741 bps |  |  | - |  |
| Net loss |  | $ | (44.4 | ) |  | $ | (6.9 | ) |  | $ | (37.5 | ) |  |  | (543 | )% |
| Net loss per diluted share |  | $ | (0.37 | ) |  | $ | (0.06 | ) |  | $ | (0.31 | ) |  |  | (517 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 136.5 |  |  | $ | 190.8 |  |  | $ | (54.3 | ) |  |  | (28 | )% |
| Service |  |  | 73.0 |  |  |  | 60.1 |  |  |  | 12.9 |  |  |  | 21 | % |
| Total net revenue |  | $ | 209.5 |  |  | $ | 250.9 |  |  | $ | (41.4 | ) |  |  | (17 | )% |
| Gross margin |  |  | 56.7 | % |  |  | 57.6 | % |  | -90 bps |  |  | - |  |
| Operating margin |  |  | (5.1 | )% |  |  | 5.6 | % |  | -1070 bps |  |  | - |  |
| Net income (loss) |  | $ | (16.6 | ) |  | $ | 9.3 |  |  | $ | (25.9 | ) |  |  | (280 | )% |
| Income (loss) per diluted share |  | $ | (0.14 | ) |  | $ | 0.08 |  |  | $ | (0.22 | ) |  |  | (275 | )% |

[0001564590-20-024216:8k_2_02:36]
|  | • | Q3 ending cash balance was $196.4 million, an increase of $56.0 million from Q2, this was primarily driven by cash generated of $54.5 million from financing activities including $55.0 million from our revolving facility drawdown and operating cash flow generation of $5.2 million, partially offset by investing activity cash flow usage of $3.2 million. |

[0001564590-20-024216:8k_2_02:37]
|  | • | Q3 Accounts Receivable balance was $96.2 million, with days sales outstanding of 42, a decrease of 13 days from Q2 and a decrease of 9 days from Q3 last year. |

[0001564590-20-024216:8k_2_02:38]
|  | • | Q3 ending inventory was $66.2 million, a decrease of $13.5 million from Q2 and an increase of $8.6 million from Q3 last year. The year-over-year increase in inventory largely reflects the addition of Aerohive Networks’ inventory, while the quarter-over-quarter decrease reflects supply constraints and demand planning considerations. |

[0001564590-20-024216:8k_2_02:39]
|  | • | Q3 ending gross debt* was $425.5 million, an increase of $50.2 million. The sequential increase reflects the drawdown of $55 million from our revolver, partially offset by principal debt payment of approximately $5 million. The $242.6 million increase from Q3 last year results from the acquisition of Aerohive Networks in August 2019. Net debt* of $229.1 million decreased by $5.8 million from $234.9 million in Q2. |

[0001564590-20-024216:8k_2_02:40]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. As shown in the table below (in thousands):

[0001564590-20-024216:8k_2_02:41]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Cash flow provided by operations | $ | 5,150 |  |  | $ | 17,709 |  |  | $ | 27,061 |  |  | $ | 79,502 |  |
| Less: PP&E CapEx spending |  | (3,192 | ) |  |  | (5,041 | ) |  |  | (12,630 | ) |  |  | (16,181 | ) |
| Total free cash flow | $ | 1,958 |  |  | $ | 12,668 |  |  | $ | 14,431 |  |  | $ | 63,321 |  |

[0001564590-20-024216:8k_2_02:42]
*Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs. Net debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-20-024216:8k_2_02:43]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 425.5 |  |  | $ | 196.4 |  |  | $ | 229.1 |  |

[0001564590-20-024216:8k_2_02:44]
Business Outlook:

[0001564590-20-024216:8k_2_02:45]
The company’s long-term drivers remain intact and we believe that we are well-positioned to capture the market opportunity in cloud-driven networking.  Further, bookings during the first month of Q4 were slightly above our internal expectations and are running at a slightly higher level than the first month of Q3.  However, the current market environment is fluid for everyone and Extreme Networks’ quarterly business is typically back-end loaded, with June being a key month in our Q4 2020 forecast.  Because of these factors, we are temporarily suspending our Q4 2020 outlook.  We will reassess providing quarterly guidance based on the clarity of macroeconomic recovery at the end of the fourth fiscal quarter.

[0001564590-20-024216:8k_2_02:46]
Conference Call:

[0001564590-20-024216:8k_2_02:47]
Extreme will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the third fiscal quarter results as well as the business outlook for fourth fiscal quarter ending June 30, 2020, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through May 18, 2020. The conference call may also be heard by dialing 1 (877) 303-9826 or international 1 (224) 357-2194 with Conference ID # 5793875. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 5793875. The encore recording will be available for 7 days following the call.

[0001564590-20-024216:8k_2_02:48]
About Extreme Networks:

[0001564590-20-024216:8k_2_02:49]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-20-024216:8k_2_02:50]
Extreme Networks, the Extreme Networks logo, ExtremeCloud IQ, ExtremeWireless, Extreme Fabric Connect, and ExtremeAnalytics, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries.

[0001564590-20-024216:8k_2_02:51]
Non-GAAP Financial Measures:

[0001564590-20-024216:8k_2_02:52]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income, non-GAAP earnings per share, and Non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, inventory valuation adjustment, restructuring charges, income tax and free cash flow.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-20-024216:8k_2_02:53]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-20-024216:8k_2_02:54]
Forward Looking Statements:

[0001564590-20-024216:8k_2_02:55]
and any worsening of the global business and economic environment as a result, on the Company’s business, financial condition and operating results.

[0001564590-20-024216:8k_2_02:56]
More information about potential factors that could affect the Company's business and financial results are described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" and "Risk Factors" included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2019, Form 8-K issued on April 8, 2020 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-20-024216:8k_2_02:57]
###

[0001564590-20-024216:8k_2_02:58]
EXTREME NETWORKS, INC.

[0001564590-20-024216:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-024216:8k_2_02:60]
(in thousands, except per share amounts)

[0001564590-20-024216:8k_2_02:61]
(Unaudited)

[0001564590-20-024216:8k_2_02:62]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 196,350 |  |  | $ | 169,607 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,686 and $1,054, respectively |  |  | 96,212 |  |  |  | 174,414 |  |
| Inventories |  |  | 66,214 |  |  |  | 63,589 |  |
| Prepaid expenses and other current assets |  |  | 36,737 |  |  |  | 34,379 |  |
| Total current assets |  |  | 395,513 |  |  |  | 441,989 |  |
| Property and equipment, net |  |  | 62,961 |  |  |  | 73,554 |  |
| Operating lease right-of-use assets, net |  |  | 53,015 |  |  |  | — |  |
| Intangible assets, net |  |  | 77,152 |  |  |  | 51,112 |  |
| Goodwill |  |  | 331,084 |  |  |  | 138,577 |  |
| Other assets |  |  | 53,727 |  |  |  | 51,642 |  |
| Total assets |  | $ | 973,452 |  |  | $ | 756,874 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,181 and $1,261, respectively |  | $ | 16,819 |  |  | $ | 9,011 |  |
| Accounts payable |  |  | 52,981 |  |  |  | 65,704 |  |
| Accrued compensation and benefits |  |  | 34,745 |  |  |  | 51,625 |  |
| Accrued warranty |  |  | 15,222 |  |  |  | 14,779 |  |
| Current portion, operating lease liability |  |  | 18,197 |  |  |  | — |  |
| Current portion, deferred revenue, net |  |  | 174,900 |  |  |  | 144,230 |  |
| Other accrued liabilities |  |  | 61,665 |  |  |  | 70,680 |  |
| Total current liabilities |  |  | 374,529 |  |  |  | 356,029 |  |
| Deferred revenue, less current portion |  |  | 96,799 |  |  |  | 59,012 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $6,796 and $1,251, respectively |  |  | 399,704 |  |  |  | 169,739 |  |
| Operating lease liability, less current portion |  |  | 53,855 |  |  |  | — |  |
| Deferred income taxes |  |  | 2,233 |  |  |  | 1,957 |  |
| Other long-term liabilities |  |  | 29,932 |  |  |  | 54,150 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000 shares authorized; 126,736 and 121,538 shares issued, respectively; 120,139 and 119,172 shares outstanding, respectively |  |  | 127 |  |  |  | 122 |  |
| Additional paid-in-capital |  |  | 1,024,836 |  |  |  | 986,772 |  |
| Accumulated other comprehensive loss |  |  | (6,388 | ) |  |  | (2,473 | ) |
| Accumulated deficit |  |  | (959,062 | ) |  |  | (853,434 | ) |
| Treasury stock at cost: 6,597 and 2,366 shares, respectively |  |  | (43,113 | ) |  |  | (15,000 | ) |
| Stockholders’ equity |  |  | 16,400 |  |  |  | 115,987 |  |
| Total liabilities and stockholders’ equity |  | $ | 973,452 |  |  | $ | 756,874 |  |

[0001564590-20-024216:8k_2_02:63]
EXTREME NETWORKS, INC.

[0001564590-20-024216:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-024216:8k_2_02:65]
(In thousands, except per share amounts)

[0001564590-20-024216:8k_2_02:66]
(Unaudited)

[0001564590-20-024216:8k_2_02:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 136,547 |  |  | $ | 190,740 |  |  | $ | 512,173 |  |  | $ | 558,027 |  |
| Service |  |  | 72,972 |  |  |  | 60,124 |  |  |  | 220,324 |  |  |  | 185,403 |  |
| Total net revenues |  |  | 209,519 |  |  |  | 250,864 |  |  |  | 732,497 |  |  |  | 743,430 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 71,927 |  |  |  | 86,876 |  |  |  | 254,705 |  |  |  | 256,906 |  |
| Service |  |  | 26,257 |  |  |  | 25,069 |  |  |  | 80,543 |  |  |  | 74,235 |  |
| Total cost of revenues |  |  | 98,184 |  |  |  | 111,945 |  |  |  | 335,248 |  |  |  | 331,141 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 64,620 |  |  |  | 103,864 |  |  |  | 257,468 |  |  |  | 301,121 |  |
| Service |  |  | 46,715 |  |  |  | 35,055 |  |  |  | 139,781 |  |  |  | 111,168 |  |
| Total gross profit |  |  | 111,335 |  |  |  | 138,919 |  |  |  | 397,249 |  |  |  | 412,289 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 50,577 |  |  |  | 52,081 |  |  |  | 165,073 |  |  |  | 155,526 |  |
| Sales and marketing |  |  | 70,132 |  |  |  | 72,321 |  |  |  | 216,925 |  |  |  | 208,245 |  |
| General and administrative |  |  | 15,119 |  |  |  | 15,479 |  |  |  | 45,199 |  |  |  | 42,136 |  |
| Acquisition and integration costs |  |  | 5,156 |  |  |  | — |  |  |  | 30,075 |  |  |  | 2,613 |  |
| Restructuring charges, net of reversals and impairment |  |  | 6,648 |  |  |  | — |  |  |  | 19,407 |  |  |  | 1,282 |  |
| Amortization of intangibles |  |  | 2,059 |  |  |  | 1,292 |  |  |  | 6,366 |  |  |  | 5,008 |  |
| Total operating expenses |  |  | 149,691 |  |  |  | 141,173 |  |  |  | 483,045 |  |  |  | 414,810 |  |
| Operating loss |  |  | (38,356 | ) |  |  | (2,254 | ) |  |  | (85,796 | ) |  |  | (2,521 | ) |
| Interest income |  |  | 222 |  |  |  | 628 |  |  |  | 1,366 |  |  |  | 1,665 |  |
| Interest expense |  |  | (5,979 | ) |  |  | (2,996 | ) |  |  | (17,377 | ) |  |  | (9,588 | ) |
| Other income (expense), net |  |  | 1,318 |  |  |  | (433 | ) |  |  | 1,128 |  |  |  | (345 | ) |
| Loss before income taxes |  |  | (42,795 | ) |  |  | (5,055 | ) |  |  | (100,679 | ) |  |  | (10,789 | ) |
| Provision (benefit) for income taxes |  |  | 1,557 |  |  |  | 1,877 |  |  |  | 4,949 |  |  |  | (1,991 | ) |
| Net loss |  | $ | (44,352 | ) |  | $ | (6,932 | ) |  | $ | (105,628 | ) |  | $ | (8,798 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic and diluted |  | $ | (0.37 | ) |  | $ | (0.06 | ) |  | $ | (0.88 | ) |  | $ | (0.07 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 119,162 |  |  |  | 117,944 |  |  |  | 119,648 |  |  |  | 117,619 |  |

[0001564590-20-024216:8k_2_02:68]
EXTREME NETWORKS, INC.

[0001564590-20-024216:8k_2_02:69]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-024216:8k_2_02:70]
(In thousands) (Unaudited)

[0001564590-20-024216:8k_2_02:71]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (105,628 | ) |  | $ | (8,798 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 21,719 |  |  |  | 20,026 |  |
| Amortization of intangible assets |  |  | 26,460 |  |  |  | 19,734 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 12,469 |  |  |  | - |  |
| Provision for doubtful accounts |  |  | 1,267 |  |  |  | 1,369 |  |
| Share-based compensation |  |  | 26,935 |  |  |  | 24,339 |  |
| Deferred income taxes |  |  | 1,293 |  |  |  | (6,030 | ) |
| Non-cash restructuring and impairment charges |  |  | 7,622 |  |  |  | - |  |
| Non-cash interest expense |  |  | 3,070 |  |  |  | 2,308 |  |
| Other |  |  | (395 | ) |  |  | 15 |  |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 88,688 |  |  |  | 69,328 |  |
| Inventories |  |  | 16,373 |  |  |  | 6,222 |  |
| Prepaid expenses and other assets |  |  | 438 |  |  |  | (6,993 | ) |
| Accounts payable |  |  | (21,530 | ) |  |  | (26,348 | ) |
| Accrued compensation and benefits |  |  | (24,009 | ) |  |  | (17,502 | ) |
| Operating lease liabilities |  |  | (13,222 | ) |  |  | - |  |
| Deferred revenue |  |  | 43 |  |  |  | 13,197 |  |
| Other current and long-term liabilities |  |  | (14,532 | ) |  |  | (11,365 | ) |
| Net cash provided by operating activities |  |  | 27,061 |  |  |  | 79,502 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (12,630 | ) |  |  | (16,181 | ) |
| Business acquisitions, net of cash acquired |  |  | (219,458 | ) |  |  | — |  |
| Maturities and sales of investments |  |  | 45,249 |  |  |  | 727 |  |
| Net cash used in investing activities |  |  | (186,839 | ) |  |  | (15,454 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Borrowings under Term Loan |  |  | 199,500 |  |  |  | — |  |
| Loan fees on borrowings |  |  | (10,514 | ) |  |  | (545 | ) |
| Repayments of debt |  |  | (29,767 | ) |  |  | (17,403 | ) |
| Repurchase of common stock |  |  | (30,000 | ) |  |  | (15,000 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 9,491 |  |  |  | 13,044 |  |
| Payment of contingent consideration obligations |  |  | (3,448 | ) |  |  | (5,274 | ) |
| Deferred payments on an acquisition |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Net cash provided by (used in) financing activities |  |  | 187,262 |  |  |  | (28,178 | ) |
| Foreign currency effect on cash |  |  | (741 | ) |  |  | (196 | ) |
| Net increase in cash |  |  | 26,743 |  |  |  | 35,674 |  |
| Cash at beginning of period |  |  | 169,607 |  |  |  | 121,139 |  |
| Cash at end of period |  | $ | 196,350 |  |  | $ | 156,813 |  |

[0001564590-20-024216:8k_2_02:72]
Extreme Networks, Inc.

[0001564590-20-024216:8k_2_02:73]
Non-GAAP Measures of Financial Performance

[0001564590-20-024216:8k_2_02:74]
To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP earnings per diluted share and Free Cash Flow.

[0001564590-20-024216:8k_2_02:75]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, inventory valuation adjustments, income tax and free cash flow.

[0001564590-20-024216:8k_2_02:76]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-20-024216:8k_2_02:77]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-20-024216:8k_2_02:78]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, inventory valuation adjustments, restructuring charges, leased asset impairments, income tax and free cash flow.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-20-024216:8k_2_02:79]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-20-024216:8k_2_02:80]
Stock-based compensation. Consists of associated expenses for stock options, restricted stock and the Company’s Employee Stock Purchase Plan.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-20-024216:8k_2_02:81]
Acquired inventory adjustments. Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-20-024216:8k_2_02:82]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive in fiscal 2020 and the acquisition of the Campus Fabric and Data Center Businesses in fiscal 2018.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-20-024216:8k_2_02:83]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-20-024216:8k_2_02:84]
Inventory valuation adjustments. Adjustments relating to the mark down of inventory due to duplication of products lines with acquisition of Aerohive net of recoveries on the sale of inventory marked down in previous quarters.

[0001564590-20-024216:8k_2_02:85]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-20-024216:8k_2_02:86]
Income tax. Income tax adjustment relates to a tax benefit resulting from changes introduced by Tax Reform related to US net operating losses allowing the release of US valuation allowance as well as a separate tax benefit resulting from the release of a foreign valuation allowance given anticipated future profitability.

[0001564590-20-024216:8k_2_02:87]
We do not reflect a tax effect associated with the Non-GAAP operating adjustments as the adjustments are primarily related to the US entity which has a full valuation of various loss carryforward tax attributes.

[0001564590-20-024216:8k_2_02:88]
EXTREME NETWORKS, INC.

[0001564590-20-024216:8k_2_02:89]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-024216:8k_2_02:90]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-20-024216:8k_2_02:91]
(In thousands, except percentages and per share amounts)

[0001564590-20-024216:8k_2_02:92]
(Unaudited)

[0001564590-20-024216:8k_2_02:93]
| Non-GAAP Revenues | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Revenues - GAAP Basis | $ | 209,519 |  |  | $ | 250,864 |  |  | $ | 732,497 |  |  | $ | 743,430 |  |
| Revenues - Non-GAAP Basis | $ | 209,519 |  |  | $ | 250,864 |  |  | $ | 732,497 |  |  | $ | 743,430 |  |

[0001564590-20-024216:8k_2_02:94]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Gross profit - GAAP Basis | $ | 111,335 |  |  | $ | 138,919 |  |  | $ | 397,249 |  |  | $ | 412,289 |  |
| Gross margin - GAAP Basis percentage |  | 53.1 | % |  |  | 55.4 | % |  |  | 54.2 | % |  |  | 55.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 648 |  |  |  | 871 |  |  |  | 2,152 |  |  |  | 2,288 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Acquisition and integration costs |  | 187 |  |  |  | — |  |  |  | 2,071 |  |  |  | 1,752 |  |
| Amortization of intangibles |  | 6,538 |  |  |  | 4,788 |  |  |  | 19,797 |  |  |  | 14,413 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | 3,677 |  |  |  | — |  |
| Total adjustments to GAAP gross profit | $ | 7,373 |  |  | $ | 5,659 |  |  | $ | 35,000 |  |  | $ | 18,453 |  |
| Gross profit - Non-GAAP | $ | 118,708 |  |  | $ | 144,578 |  |  | $ | 432,249 |  |  | $ | 430,742 |  |
| Gross margin - Non-GAAP percentage |  | 56.7 | % |  |  | 57.6 | % |  |  | 59.0 | % |  |  | 57.9 | % |

[0001564590-20-024216:8k_2_02:95]
| Non-GAAP Operating Income (Loss) | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| GAAP operating loss | $ | (38,356 | ) |  | $ | (2,254 | ) |  | $ | (85,796 | ) |  | $ | (2,521 | ) |
| GAAP operating loss percentage |  | (18.3 | )% |  |  | (0.9 | )% |  |  | (11.7 | )% |  |  | (0.3 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense, cost of revenues |  | 648 |  |  |  | 871 |  |  |  | 2,152 |  |  |  | 2,288 |  |
| Stock based compensation expense, R&D |  | 2,518 |  |  |  | 2,814 |  |  |  | 8,213 |  |  |  | 7,953 |  |
| Stock based compensation expense, S&M |  | 1,338 |  |  |  | 3,187 |  |  |  | 8,568 |  |  |  | 8,529 |  |
| Stock based compensation expense, G&A |  | 2,639 |  |  |  | 1,942 |  |  |  | 7,523 |  |  |  | 5,569 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | 3,677 |  |  |  | — |  |
| Acquisition and integration costs |  | 5,343 |  |  |  | — |  |  |  | 32,146 |  |  |  | 4,298 |  |
| Restructuring charges, net of reversals |  | 6,648 |  |  |  | — |  |  |  | 19,407 |  |  |  | 1,282 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Amortization of intangibles |  | 8,597 |  |  |  | 6,080 |  |  |  | 26,163 |  |  |  | 19,421 |  |
| Loss on lease contracts |  | — |  |  |  | 1,288 |  |  |  | — |  |  |  | 1,288 |  |
| Total adjustments to GAAP operating loss | $ | 27,731 |  |  | $ | 16,182 |  |  | $ | 115,152 |  |  | $ | 50,628 |  |
| Non-GAAP operating income (loss) | $ | (10,625 | ) |  | $ | 13,928 |  |  | $ | 29,356 |  |  | $ | 48,107 |  |
| Non-GAAP operating income (loss) percentage |  | (5.1 | )% |  |  | 5.6 | % |  |  | 4.0 | % |  |  | 6.5 | % |

[0001564590-20-024216:8k_2_02:96]
| Non-GAAP Net Income (Loss) | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| GAAP net loss | $ | (44,352 | ) |  | $ | (6,932 | ) |  | $ | (105,628 | ) |  | $ | (8,798 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 7,143 |  |  |  | 8,814 |  |  |  | 26,456 |  |  |  | 24,339 |  |
| Inventory valuation adjustments |  | — |  |  |  | — |  |  |  | 3,677 |  |  |  | — |  |
| Acquisition and integration costs |  | 5,343 |  |  |  | — |  |  |  | 32,146 |  |  |  | 4,298 |  |
| Restructuring charge, net of reversal |  | 6,648 |  |  |  | — |  |  |  | 19,407 |  |  |  | 1,282 |  |
| Acquired inventory adjustments |  | — |  |  |  | — |  |  |  | 7,303 |  |  |  | — |  |
| Amortization of intangibles |  | 8,597 |  |  |  | 6,080 |  |  |  | 26,163 |  |  |  | 19,421 |  |
| Loss on lease contracts |  | — |  |  |  | 1,288 |  |  |  | — |  |  |  | 1,288 |  |
| Income tax |  | — |  |  |  | — |  |  |  | — |  |  |  | (7,770 | ) |
| Total adjustments to GAAP net loss | $ | 27,731 |  |  | $ | 16,182 |  |  | $ | 115,152 |  |  | $ | 42,858 |  |
| Non-GAAP net income (loss) | $ | (16,621 | ) |  | $ | 9,250 |  |  | $ | 9,524 |  |  | $ | 34,060 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income (loss) per share-diluted | $ | (0.14 | ) |  | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | 0.28 |  |
| Shares used in net income (loss) per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 119,162 |  |  |  | 120,846 |  |  |  | 122,711 |  |  |  | 120,210 |  |
