# EXTR 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001564590-18-022453:item_9a:1]
Item 9A. Controls and Procedures

[0001564590-18-022453:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-18-022453:item_9a:3]
Disclosure controls and procedures are controls and procedures designed to reasonably assure that information required to be disclosed in our reports filed under the Securities Exchange Act of 1934 as amended, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms and to reasonably assure that such information is accumulated and communicated to our management, including the Chief Executive Officer (“CEO”) and the Chief Financial Officer (“CFO”), as appropriate to allow timely decisions regarding required disclosure.

[0001564590-18-022453:item_9a:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we evaluated the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO concluded that our disclosure controls and procedures were effective as of June 30, 2018.

[0001564590-18-022453:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001564590-18-022453:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over our financial reporting. There are inherent limitations in the effectiveness of any system of internal control, including the possibility of human error and the circumvention or overriding of controls. Accordingly, even effective internal controls can provide only reasonable assurances with respect to financial statement preparation. Further because of changes in conditions, the effectiveness of internal control may vary over time.

[0001564590-18-022453:item_9a:7]
We assessed the effectiveness of our internal control over financial reporting as of June 30, 2018.  In making this assessment, we used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”) in Internal Control-Integrated Framework (2013). Based on our assessment using those criteria, we concluded that, as of June 30, 2018, our internal control over financial reporting is effective.

[0001564590-18-022453:item_9a:8]
During the year ended June 30, 2018, we completed our acquisitions of the fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) from Avaya Inc., the data center business (the “Data Center Business”) from Brocade Communication Systems, Inc., and the capital financing business (the “CF Business”) from Broadcom Corporation. In conducting our evaluation of the effectiveness of our internal controls over financial reporting as of June 30, 2018, we have elected to exclude the Campus Fabric Business, Data Center Business and CF Business from our evaluation for fiscal 2018 as permitted under current Securities and Exchange Commission rules and regulations. As of and for the year ended June 30, 2018, the assets and revenues of the acquired businesses not included in our evaluation represented 20% of consolidated assets and 33% of consolidated revenues. We are currently in the process of integrating and assessing the internal controls over financial reporting of the acquired businesses with the rest of our Company. The integration may lead to changes in future periods, but we do not expect these changes to materially affect our internal controls over financial reporting. We expect to complete this integration in fiscal 2019.

[0001564590-18-022453:item_9a:9]
Our independent registered public accounting firm, KPMG LLP, has audited the financial statements included in this Annual Report on Form 10-K and has issued its report on our internal control over financial reporting as of June 30, 2018.

[0001564590-18-022453:item_9a:10]
Changes in Internal Control over Financial Reporting

[0001564590-18-022453:item_9a:11]
There were no changes in our internal control over financial reporting during the quarter ended June 30, 2018, that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-18-022453:item_9a:12]
97

[0001564590-18-022453:item_9a:13]
EXTREME NETWORKS, INC.

[0001564590-18-022453:item_9a:14]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS—(Continued)

[0001564590-18-022453:item_9a:15]
Inherent Limitations on Effectiveness of Controls

[0001564590-18-022453:item_9a:16]
Our management, including the CEO and CFO, does not expect that our disclosure controls or our internal control over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. Our controls and procedures are designed to provide reasonable assurance that our control system’s objective will be met and our CEO and CFO have concluded that our disclosure controls and procedures are effective at the reasonable assurance level. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within Extreme have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events. Projections of any evaluation of the effectiveness of controls in future periods are subject to risks. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Notwithstanding these limitations, our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives. Our CEO and CFO have concluded that our disclosure controls and procedures are, in fact, effective at the “reasonable assurance” level.
