# EXTR notes — 0001564590-18-022453


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-022453:notes:1]
1. Description of Business and Basis of Presentation

[0001564590-18-022453:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-18-022453:notes:3]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606). All amounts and disclosures set forth in this Form 10-K have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.

[0001564590-18-022453:notes:4]
Fiscal Year

[0001564590-18-022453:notes:5]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2018” or “2018”; “fiscal 2017” or “2017”; “fiscal 2016” or “2016” represent the fiscal years ending 2018, 2017 and 2016, respectively.

[0001564590-18-022453:notes:6]
Principles of Consolidation

[0001564590-18-022453:notes:7]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-18-022453:notes:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001564590-18-022453:notes:9]
Accounting Estimates

[0001564590-18-022453:notes:10]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-022453:notes:11]
2. Summary of Significant Accounting Policies

[0001564590-18-022453:notes:12]
Revenue Recognition

[0001564590-18-022453:notes:13]
The Company derives revenues primarily from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0001564590-18-022453:notes:14]
See Note 3. Revenues, for further discussion.

[0001564590-18-022453:notes:15]
Cash, Cash Equivalents and Marketable Securities

[0001564590-18-022453:notes:16]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Marketable securities are recorded in “Prepaid expense and other current assets” in the accompanying consolidated balance sheet as these are publicly-traded equity securities with maturities of greater than three months, but less than one year at the balance sheet date. Marketable securities are classified as available-for-sale and reported at fair value with unrealized gains and losses included, net of tax, in accumulated other comprehensive loss, a component of stockholders’ equity. Realized gains and losses and declines in the value of available-for-sale securities determined to be other than temporary are included in other income (expense), net. The cost of securities sold is determined based on the specific identification method.

[0001564590-18-022453:notes:17]
Allowance for Product Returns

[0001564590-18-022453:notes:18]
The Company provides an allowance for product returns based on its historical returns, analysis of credit memo data and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is a reduction of accounts receivable. If the historical data that the Company uses to calculate the estimated product returns and allowances does not properly reflect actual levels of product returns, these estimates will be revised, resulting in an impact on net revenue. The allowance for product returns estimate is also impacted by the timing of the actual product return from the customer.

[0001564590-18-022453:notes:19]
Allowance for Doubtful Accounts

[0001564590-18-022453:notes:20]
The Company maintains an allowance for doubtful accounts which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001564590-18-022453:notes:21]
Inventories

[0001564590-18-022453:notes:22]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory may be in excess of anticipated demand based upon assumptions about future demand or is obsolete. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-18-022453:notes:23]
Long-Lived Assets

[0001564590-18-022453:notes:24]
Long-lived assets include (a) property and equipment, (b) goodwill and intangible assets, and (c) other assets. Property and equipment and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001564590-18-022453:notes:25]
(a) Property and Equipment, Net

[0001564590-18-022453:notes:26]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and software. Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years).

[0001564590-18-022453:notes:27]
(b) Goodwill and Intangible Assets

[0001564590-18-022453:notes:28]
Goodwill and indefinite-lived intangible assets are generated as a result of business combinations. The Company’s indefinite-lived intangible assets are comprised of acquired in-process research and development (“IPR&D”), which is treated as indefinite until the completion or abandonment of the associated research and development effort. During the development period, the Company conducts an IPR&D impairment test at least annually or whenever events or changes in facts and circumstances indicate that it is more likely than not that the IPR&D is impaired. Events which might indicate impairment include, but are not limited to, adverse cost factors, deteriorating financial performance, strategic decisions made in response to economic, market, and competitive conditions, the impact of the economic environment on the Company and its customer base, and/or other relevant events such as changes in management, key personnel, litigations, or customers. Management did not identify any triggering events for any periods presented. Intangible assets other than acquired IPR&D are not considered to have an indefinite life and are amortized over their useful lives. The Company reevaluates the estimated remaining useful life of acquired intangible assets whenever events or changes in circumstances indicate a revision to the remaining period of amortization might be necessary. The carrying amounts of these assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable.

[0001564590-18-022453:notes:29]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. The Company adopted ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment in fiscal 2018, which eliminated step two from the goodwill impairment test. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceed directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Any loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. Based on the results of the goodwill impairment analyses, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0001564590-18-022453:notes:30]
(c) Other Assets

[0001564590-18-022453:notes:31]
Other assets consist primarily of service parts and long-term deposits. The Company holds service parts to support customers who have purchased service contracts with a hardware replacement element, as well as to support its warranty program. The Company reduces the carrying value of service parts to net realizable value based on expected quantities needed to satisfy contractual service requirements of customers.

[0001564590-18-022453:notes:32]
Business Combinations

[0001564590-18-022453:notes:33]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0001564590-18-022453:notes:34]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized within the statements of operations. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0001564590-18-022453:notes:35]
Deferred Revenue

[0001564590-18-022453:notes:36]
Deferred revenue represents amounts for (i) deferred maintenance and support revenue and (ii) other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001564590-18-022453:notes:37]
Product Warranties and Guarantees

[0001564590-18-022453:notes:38]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-18-022453:notes:39]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-18-022453:notes:40]
Stock-based Compensation

[0001564590-18-022453:notes:41]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock option using the Black-Scholes-Merton option valuation model. The fair value of RSUs represents the closing stock price of the Company’s common stock on the grant date. The Company calculates the fair value of share purchase option under the 2014 ESPP using the Black-Scholes-Merton option valuation model.

[0001564590-18-022453:notes:42]
The Company grants certain employees performance-based stock options and RSUs. The performance metrics include company-wide financial performance and/or market conditions. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0001564590-18-022453:notes:43]
Advertising

[0001564590-18-022453:notes:44]
Advertising costs are expensed as incurred. Advertising expenses were $0.5 million, $0.4 million and $0.3 million in fiscal years 2018, 2017 and 2016, respectively.

[0001564590-18-022453:notes:45]
Income Taxes

[0001564590-18-022453:notes:46]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0001564590-18-022453:notes:47]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions.  The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.  For additional discussion, see Note 15. Income Taxes.

[0001564590-18-022453:notes:48]
Concentrations

[0001564590-18-022453:notes:49]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-18-022453:notes:50]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenue:

[0001564590-18-022453:notes:51]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |
| Tech Data Corporation |  | 14% |  |  | 16% |  |  | 17% |  |
| Jenne Corporation |  | 13% |  |  | 15% |  |  | 14% |  |
| Westcon Group Inc. |  | 13% |  |  | 12% |  |  | 13% |  |

[0001564590-18-022453:notes:52]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable balance:

[0001564590-18-022453:notes:53]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Tech Data Corporation |  | 17% |  |  | 18% |  |
| Jenne Corporation |  | 13% |  |  | 12% |  |
| Westcon Group Inc. |  | * |  |  | 11% |  |

[0001564590-18-022453:notes:54]
*Less than 10% of accounts receivable

[0001564590-18-022453:notes:55]
Recently Issued Accounting Pronouncements

[0001564590-18-022453:notes:56]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718. Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The guidance is effective prospectively for fiscal years beginning after December 15, 2017, and interim periods within that reporting period. Early adoption is permitted, including adoption in any interim period. The adoption of this guidance will not have a material effect on the Company’s financial statements. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-18-022453:notes:57]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice. The guidance is effective for fiscal years beginning after December 15, 2017, and interim periods within that reporting period. The amendments in this update should be applied using a retrospective transition method to each period presented. If impracticable to apply the amendments retrospectively for some of the issues, the amendments for those issues would be applied prospectively as of the earliest date practicable. The adoption of this guidance will not have a material effect on the Company’s presentation of cash flows. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-18-022453:notes:58]
In October 2016, the FASB issued ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires the recognition of the income tax effects of intercompany sales and intra-entity transfers of assets, other than inventory, when the transfer occurs. ASU 2016-16 amends current U.S. GAAP that prohibits recognition of current and deferred income taxes for all types of intra-entity asset transfers until the asset has been sold to a third party or otherwise recovered through use. The guidance is effective for fiscal years beginning after December 15, 2017, and interim periods within that reporting period, and is applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company is currently evaluating the impact of the adoption of this standard will have on its consolidated financial statements. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-18-022453:notes:59]
In January 2016, the FASB issued ASU 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities. This guidance will become effective for the Company beginning with its fiscal year 2019. Upon adoption, the Company will be required to reclassify the gain related to its available-for-sale investments from accumulated other comprehensive loss to accumulated deficit as a cumulative-effect adjustment and begin recording future changes in fair value through earnings. As of June 30, 2018, the Company had $0.5 million of unrealized holding gains, net of tax, related to its available-for-sale investments recorded in accumulated other comprehensive loss in the accompanying consolidated balance sheet.  Upon adoption of ASU 2016-01 on July 1, 2018, the Company will record an adjustment to accumulated deficit of $0.5 million to eliminate the unrealized gains balance in accumulated other comprehensive loss.

[0001564590-18-022453:notes:60]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The guidance is effective for fiscal years beginning after December 15, 2018. The Company is evaluating the accounting, transition and disclosure requirements of the standard and cannot currently estimate the financial statement impact of adoption. This guidance is effective for the Company beginning with its fiscal year 2020.

[0001564590-18-022453:notes:61]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842) which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee.  Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases.  The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, Topic 842 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. The Company believes that Topic 842 will have a material impact on its financial position, as a result of recognizing right-of-use assets and lease liabilities on its consolidated balance sheets.  The Company is also evaluating the impact to the Company’s results of operations and does not believe there will be a material impact to its consolidated statements of operations or consolidated cash flow statements upon adoption of Topic 842. This guidance will be adopted by the Company beginning with its fiscal year 2020.

[0001564590-18-022453:notes:62]
Recently Adopted Accounting Pronouncements

[0001564590-18-022453:notes:63]
In May 2014, the FASB issued ASU No. 2014-09 (Topic 606) – Revenue from Contracts with Customers. Topic 606 supersedes the revenue recognition requirements in the FASB ASC 605 – Revenue Recognition (Topic 605), and requires entities to recognize revenues when control of the promised goods or services is transferred to customers at an amount that reflects the consideration to which the entity expects to be entitled to in exchange for those goods or services. The Company adopted Topic 606 as of July 1, 2017 using the full retrospective transition method. See Note 3 for further details.

[0001564590-18-022453:notes:64]
In January 2017, the FASB issued ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04), which eliminates step two from the goodwill impairment test. Under the amendments in ASU 2017-04, an entity should recognize an impairment charge for the amount by which the carrying amount of a reporting unit exceeds its fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. ASU 2017-04 is effective for annual and any interim impairment tests performed for periods beginning after December 15, 2019 on a prospective basis, and earlier adoption is permitted for goodwill impairment tests performed on testing dates after January 1, 2017. The Company’s early adoption of this accounting standard update in the fourth quarter of fiscal 2018 on a prospective basis did not have an impact on its consolidated financial statements. The adoption of this update simplified the Company’s annual goodwill impairment testing process by eliminating the need to estimate the implied fair value of a reporting unit’s goodwill if its respective carrying value exceeds fair value.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-18-022453:notes:65]
3. Revenues

[0001564590-18-022453:notes:66]
Adoption of ASC Topic 606 – Revenue from Contracts with Customers

[0001564590-18-022453:notes:67]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). Under ASU 2014-09, revenue is recognized when a customer obtains control of promised goods or services and is recognized at an amount that reflects the consideration expected to be received in exchange for such goods or services.  In addition, ASU 2014-09 requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers.

[0001564590-18-022453:notes:68]
The Company adopted Topic 606 on July 1, 2017, using the full retrospective method. This adoption primarily affected the Company’s accounting for distributor and resellers revenues from a primarily “sell-through” model, where revenue is recognized upon the sale from the distribution channel to the end customer, to the “sell-in” method where revenue is recognized upon transfer of control to the Company’s customers. Under the sell-in method, the Company is required to make estimates at the time of transfer of control to its distributors for variable consideration including estimated returns under stock rotation rights granted to stocking distributors and rebate claims.  Additionally, the Company capitalizes contract acquisition costs such as commissions paid for maintenance services contracts in excess of one year.  Following the adoption of ASU 2014-09, the revenue recognition for the Company’s other sales arrangements remained materially consistent with its historical practice.

[0001564590-18-022453:notes:69]
Upon adoption of Topic 606, the Company applied certain permissible practical expedients that allows a) an entity to use the transaction price at the date the contract was completed rather than estimating variable consideration amounts in the comparative reporting periods, b) that permits the omission of prior-period information about its performance obligations, and c) that allows the Company to reflect the aggregate effect of all modifications that occur before the beginning of the earliest period presented when identifying the satisfied and unsatisfied performance obligations, determining the transaction price and allocating the transaction price to the satisfied and unsatisfied performance obligations.

[0001564590-18-022453:notes:70]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the full retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-18-022453:notes:71]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations.  In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0001564590-18-022453:notes:72]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales taxes collected from customers are excluded from revenues.  Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-18-022453:notes:73]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are estimated using the expected value method based on historical return rates.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-18-022453:notes:74]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-18-022453:notes:75]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product revenues as reflected on the consolidated statements of operations for the years ended June 30, 2018, 2017 and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure satisfaction of the performance obligation.

[0001564590-18-022453:notes:76]
At June 30, 2018, the Company had $174.5 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 75 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 15 percent by fiscal 2020 and 10 percent of the balance thereafter.

[0001564590-18-022453:notes:77]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-18-022453:notes:78]
Revenue recognized for the years ended June 30, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $76.6 million and $70.5 million, respectively.

[0001564590-18-022453:notes:79]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals, in excess of one year, are recoverable and therefore the Company capitalized them as contract costs in the amount of $4.3 million and $2.5 million at June 30, 2018 and 2017, respectively, in “Other assets” in the accompanying consolidated balance sheets.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations.  Amortization recognized during the years ended June 30, 2018, 2017 and 2016 was $2.1 million, $1.5 million and $0.9 million, respectively.

[0001564590-18-022453:notes:80]
Revenue by Category: The following tables set forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-18-022453:notes:81]
|  |  | Year Ended June 30, 2018 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 271,975 |  |  | $ | 219,642 |  |  | $ | 491,617 |  |
| Other |  |  | 19,414 |  |  |  | 25,274 |  |  |  | 44,688 |  |
| Total Americas |  |  | 291,389 |  |  |  | 244,916 |  |  |  | 536,305 |  |
| EMEA: |  |  | 218,682 |  |  |  | 136,064 |  |  |  | 354,746 |  |
| APAC: |  |  | 15,621 |  |  |  | 76,470 |  |  |  | 92,091 |  |
| Total net revenues |  | $ | 525,692 |  |  | $ | 457,450 |  |  | $ | 983,142 |  |

[0001564590-18-022453:notes:82]
|  |  | Year Ended June 30, 2017 (As adjusted) |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 146,805 |  |  | $ | 161,175 |  |  | $ | 307,980 |  |
| Other |  |  | 11,861 |  |  |  | 13,022 |  |  |  | 24,883 |  |
| Total Americas |  |  | 158,666 |  |  |  | 174,197 |  |  |  | 332,863 |  |
| EMEA: |  |  | 135,414 |  |  |  | 84,658 |  |  |  | 220,072 |  |
| APAC: |  |  | 8,953 |  |  |  | 45,196 |  |  |  | 54,149 |  |
| Total net revenues |  | $ | 303,033 |  |  | $ | 304,051 |  |  | $ | 607,084 |  |

[0001564590-18-022453:notes:83]
|  |  | Year Ended June 30, 2016 (As adjusted) |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 113,715 |  |  | $ | 120,313 |  |  | $ | 234,028 |  |
| Other |  |  | 21,246 |  |  |  | 22,479 |  |  |  | 43,725 |  |
| Total Americas |  |  | 134,961 |  |  |  | 142,792 |  |  |  | 277,753 |  |
| EMEA: |  |  | 106,853 |  |  |  | 86,064 |  |  |  | 192,917 |  |
| APAC: |  |  | 7,251 |  |  |  | 41,913 |  |  |  | 49,164 |  |
| Total net revenues |  | $ | 249,065 |  |  | $ | 270,769 |  |  | $ | 519,834 |  |

[0001564590-18-022453:notes:84]
Adjustments to Previously Reported Financial Statements from the Adoption of Accounting Pronouncements

[0001564590-18-022453:notes:85]
The following table presents the effect of the adoption of ASU 2014-09 on the Company’s consolidated balance sheet as of June 30, 2017, (in thousands):

[0001564590-18-022453:notes:86]
|  | As of June 30, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Accounts receivable, net | $ | 120,770 |  |  | $ | (27,655 | ) |  | $ | 93,115 |  |
| Inventories |  | 45,880 |  |  |  | 1,530 |  |  |  | 47,410 |  |
| Total current assets |  | 324,967 |  |  |  | (26,125 | ) |  |  | 298,842 |  |
| Other assets |  | 22,586 |  |  |  | 2,479 |  |  |  | 25,065 |  |
| Total assets | $ | 483,346 |  |  | $ | (23,646 | ) |  | $ | 459,700 |  |
| Accrued warranty | $ | 10,007 |  |  | $ | 577 |  |  | $ | 10,584 |  |
| Other accrued liabilities |  | 36,713 |  |  |  | 331 |  |  |  | 37,044 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 43,525 |  |  |  | (43,525 | ) |  |  | — |  |
| Total current liabilities |  | 255,822 |  |  |  | (42,617 | ) |  |  | 213,205 |  |
| Accumulated deficit |  | (800,257 | ) |  |  | 18,971 |  |  |  | (781,286 | ) |
| Total stockholders’ equity |  | 106,707 |  |  |  | 18,971 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity | $ | 483,346 |  |  | $ | (23,646 | ) |  | $ | 459,700 |  |

[0001564590-18-022453:notes:87]
The following tables present the effect of the adoption of ASU 2014-09 on the Company’s consolidated statements of operations for the years ended June 30, 2017 and 2016 (in thousands, except per share amounts):

[0001564590-18-022453:notes:88]
|  | Year Ended June 30, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 451,459 |  |  | $ | 8,966 |  |  | $ | 460,425 |  |
| Service |  | 146,659 |  |  |  | — |  |  |  | 146,659 |  |
| Total net revenues |  | 598,118 |  |  |  | 8,966 |  |  |  | 607,084 |  |
| Cost of revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 217,727 |  |  |  | 2,494 |  |  |  | 220,221 |  |
| Service |  | 55,906 |  |  |  | — |  |  |  | 55,906 |  |
| Total cost of revenues |  | 273,633 |  |  |  | 2,494 |  |  |  | 276,127 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 233,732 |  |  |  | 6,472 |  |  |  | 240,204 |  |
| Service |  | 90,753 |  |  |  | — |  |  |  | 90,753 |  |
| Total Gross profit |  | 324,485 |  |  |  | 6,472 |  |  |  | 330,957 |  |
| Sales and marketing expenses |  | 167,927 |  |  |  | (301 | ) |  |  | 162,626 |  |
| Operating loss |  | (733 | ) |  |  | 6,773 |  |  |  | 6,040 |  |
| Net income (loss) before tax |  | (4,177 | ) |  |  | 6,773 |  |  |  | 2,596 |  |
| Net income (loss) | $ | (8,517 | ) |  | $ | 6,773 |  |  | $ | (1,744 | ) |
| Basic and diluted net loss per share |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.08 | ) |  | $ | 0.06 |  |  | $ | (0.02 | ) |
| Net loss per share - diluted | $ | (0.08 | ) |  | $ | 0.06 |  |  | $ | (0.02 | ) |
| Shares used in per share calculation - basic |  | 108,273 |  |  |  | 108,273 |  |  |  | 108,273 |  |
| Shares used in per share calculation - diluted |  | 108,273 |  |  |  | 108,273 |  |  |  | 108,273 |  |

[0001564590-18-022453:notes:89]
|  | Year Ended June 30, 2016 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 395,464 |  |  | $ | (8,555 | ) |  | $ | 386,909 |  |
| Service |  | 132,925 |  |  |  | — |  |  |  | 132,925 |  |
| Total net revenues |  | 528,389 |  |  |  | (8,555 | ) |  |  | 519,834 |  |
| Cost of revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 208,739 |  |  |  | (3,170 | ) |  |  | 205,569 |  |
| Service |  | 48,862 |  |  |  | — |  |  |  | 48,862 |  |
| Total cost of revenues |  | 257,601 |  |  |  | (3,170 | ) |  |  | 254,431 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 186,725 |  |  |  | (5,385 | ) |  |  | 181,340 |  |
| Service |  | 84,063 |  |  |  | — |  |  |  | 84,063 |  |
| Total Gross profit |  | 270,788 |  |  |  | (5,385 | ) |  |  | 265,403 |  |
| Sales and marketing expenses |  | 150,806 |  |  |  | (906 | ) |  |  | 149,900 |  |
| Operating loss |  | (25,550 | ) |  |  | (4,479 | ) |  |  | (30,029 | ) |
| Net loss before tax |  | (27,548 | ) |  |  | (4,479 | ) |  |  | (32,027 | ) |
| Net loss | $ | (31,884 | ) |  | $ | (4,479 | ) |  | $ | (36,363 | ) |
| Basic and diluted net loss per share |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.31 | ) |  | $ | (0.04 | ) |  | $ | (0.35 | ) |
| Net loss per share - diluted | $ | (0.31 | ) |  | $ | (0.04 | ) |  | $ | (0.35 | ) |
| Shares used in per share calculation - basic |  | 103,074 |  |  |  | 103,074 |  |  |  | 103,074 |  |
| Shares used in per share calculation - diluted |  | 103,074 |  |  |  | 103,074 |  |  |  | 103,074 |  |

[0001564590-18-022453:notes:90]
The following tables present the effect of the adoption of ASU 2014-09 on the Company’s consolidated statement of cash flows for the years ended June 30, 2017 and 2016 (in thousands):

[0001564590-18-022453:notes:91]
|  | Year Ended June 30, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (8,517 | ) |  | $ | 6,773 |  |  | $ | (1,744 | ) |
| Changes in operating assets and liabilities, net |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | (25,050 | ) |  |  | 11,099 |  |  |  | (13,951 | ) |
| Inventories |  | 8,587 |  |  |  | (1,174 | ) |  |  | 7,413 |  |
| Prepaid expenses and other assets |  | 8,018 |  |  |  | (301 | ) |  |  | 7,717 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 16,708 |  |  |  | (16,708 | ) |  |  | — |  |
| Other current and long-term liabilities |  | 5,419 |  |  |  | 311 |  |  |  | 5,730 |  |
| Net cash provided by operating activities |  | 59,283 |  |  |  | — |  |  |  | 59,283 |  |
| Net cash used in investing activities |  | (71,752 | ) |  |  | — |  |  |  | (71,752 | ) |
| Net cash provided by financing activities |  | 48,708 |  |  |  | — |  |  |  | 48,708 |  |
| Foreign currency effect on cash |  | 89 |  |  |  | — |  |  |  | 89 |  |
| Net increase in cash and cash equivalents | $ | 36,328 |  |  | $ | — |  |  | $ | 36,328 |  |

[0001564590-18-022453:notes:92]
|  | Year Ended June 30, 2016 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (31,884 | ) |  | $ | (4,479 | ) |  | $ | (36,363 | ) |
| Changes in operating assets and liabilities, net |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | 10,178 |  |  |  | (9,552 | ) |  |  | 626 |  |
| Inventories |  | 17,025 |  |  |  | 1,171 |  |  |  | 18,196 |  |
| Prepaid expenses and other assets |  | 100 |  |  |  | (906 | ) |  |  | (806 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | (14,058 | ) |  |  | 14,058 |  |  |  | — |  |
| Other current and long-term liabilities |  | (3,047 | ) |  |  | (292 | ) |  |  | (3,339 | ) |
| Net cash provided by operating activities |  | 30,366 |  |  |  | — |  |  |  | 30,366 |  |
| Net cash used in investing activities |  | (5,327 | ) |  |  | — |  |  |  | (5,327 | ) |
| Net cash used in financing activities |  | (6,738 | ) |  |  | — |  |  |  | (6,738 | ) |
| Foreign currency effect on cash |  | (404 | ) |  |  | — |  |  |  | (404 | ) |
| Net increase in cash and cash equivalents | $ | 17,897 |  |  | $ | — |  |  | $ | 17,897 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-022453:notes:93]
4. Business Combinations

[0001564590-18-022453:notes:94]
The Company completed three acquisitions during the year ended June 30, 2018 and an acquisition during the year ended June 30, 2017. The acquisitions have been accounted for using the acquisition method of accounting. The purchase price has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach. The fair value of property and equipment was determined using a cost approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay to a third party to assume the obligation. Valuations of the intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition.  Results of operations of the acquired entities are included in the Company’s operations beginning with the closing date of each acquisition.

[0001564590-18-022453:notes:95]
Fiscal 2018 Acquisitions

[0001564590-18-022453:notes:96]
Data Center Business

[0001564590-18-022453:notes:97]
The Company completed its acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc. (“Brocade”) on October 27, 2017 (the “Data Center Business Closing Date”), pursuant to an Asset Purchase Agreement (the “Data Center Business APA”) dated as of October 3, 2017, by and between the Company and Brocade. Under the terms and conditions of the Data Center Business APA, the Company acquired customers, employees, technology and other assets of the Data Center Business as well as assumed certain contracts and other liabilities of the Data Center Business.

[0001564590-18-022453:notes:98]
The fair value of consideration transferred on the Data Center Business Closing Date includes:

[0001564590-18-022453:notes:99]
|  | • | cash payment upon closing of $23.0 million, |

[0001564590-18-022453:notes:100]
|  | • | deferred payments of $1.0 million per quarter for the next twenty full fiscal quarters of the Company following the acquisition date discounted to their present value, |

[0001564590-18-022453:notes:101]
|  | • | contingent consideration in the form of quarterly earnout payments equal to 50% of the profits of the Data Center Business for the five-year period commencing at the end of the first full fiscal quarter of the Company following the acquisition of the Data Center Business discounted to their present value, |

[0001564590-18-022453:notes:102]
|  | • | an amount payable due to the excess working capital acquired over the target working capital agreed upon in the Data Center Business APA, and, |

[0001564590-18-022453:notes:103]
|  | • | a portion of the fair value of stock awards granted to employees assumed from Brocade for which their services were provided prior to the Data Center Business Closing Date. |

[0001564590-18-022453:notes:104]
The components of aggregate estimated purchase consideration are as follows (in thousands):

[0001564590-18-022453:notes:105]
| Estimated purchase consideration | October 27, 2017 |  |
| Cash paid to sellers at closing | $ | 23,000 |  |
| Deferred payments |  | 18,430 |  |
| Contingent consideration |  | 34,100 |  |
| Working capital adjustment |  | 6,534 |  |
| Replacement of stock-based awards |  | 2,273 |  |
| Aggregate estimated purchase consideration | $ | 84,337 |  |

[0001564590-18-022453:notes:106]
The purchase price allocation as of the Data Center Business Closing Date is set forth in the table below and reflects fair values. The fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of June 30, 2018 (in thousands):

[0001564590-18-022453:notes:107]
|  | Preliminary Allocation as of October 28, 2017 |  |  | Adjustments |  |  | Final Allocation as of June 30, 2018 |  |
| Accounts receivables | $ | 33,488 |  |  | $ | — |  |  | $ | 33,488 |  |
| Inventories |  | 19,973 |  |  |  | (39 | ) | (a) |  | 19,934 |  |
| Prepaid expenses and other current assets |  | 988 |  |  |  | — |  |  |  | 988 |  |
| Property and equipment |  | 29,160 |  |  |  | (10,222 | ) | (b) |  | 18,938 |  |
| Other assets |  | 4,734 |  |  |  | — |  |  |  | 4,734 |  |
| Accounts payable and accrued expenses |  | (15,850 | ) |  |  | (644 | ) | (c) |  | (16,494 | ) |
| Deferred revenue |  | (33,519 | ) |  |  | 494 |  | (d) |  | (33,025 | ) |
| Net tangible assets acquired |  | 38,974 |  |  |  | (10,411 | ) |  |  | 28,563 |  |
| Identifiable intangible assets |  | 28,600 |  |  |  | 4,200 |  | (e) |  | 32,800 |  |
| Goodwill |  | 16,763 |  |  |  | 6,211 |  |  |  | 22,974 |  |
| Total intangible assets acquired |  | 45,363 |  |  |  | 10,411 |  |  |  | 55,774 |  |
| Total net assets acquired | $ | 84,337 |  |  | $ | — |  |  | $ | 84,337 |  |

[0001564590-18-022453:notes:108]
The changes during the measurement period in the table above include: a) finalization of the fair value of existing inventories as of the acquisition date, b) finalization of valuation of assets acquired with limited future use as of the acquisition date, c) identification of additional unpaid invoices existing as of the acquisition date, d) finalization of future cash flows related to deferred revenue contracts and, e) finalization of adjustments to discount rate and future cash flows.

[0001564590-18-022453:notes:109]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (dollars in thousands):

[0001564590-18-022453:notes:110]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  | 2 - 4 |  |  | $ | 26,000 |  |
| Customer relationships |  |  | 4 |  |  |  | 5,400 |  |
| Trade names |  |  | 4 |  |  |  | 1,400 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 32,800 |  |

[0001564590-18-022453:notes:111]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the Data Center Business. The Company anticipates both the goodwill and intangible assets to be fully deductible for income tax purposes.

[0001564590-18-022453:notes:112]
Pursuant to negotiations regarding various contractual arrangements with Broadcom, in August 2018, the Company resolved its contingent consideration obligation related to the Data Center Business acquisition.  The outstanding balance was revalued to its final fair value as of June 30, 2018 resulting in a charge of $1.5 million which is included in “General and administrative” expense in the accompanying consolidated statements of operations.

[0001564590-18-022453:notes:113]
The results of operations of the Data Center Business are included with those of the Company beginning October 28, 2017. The Data Center Business revenue for the year ended June 30, 2018 was $136.3 million and has been incorporated into the revenue of the Company. The associated expenses of the Data Center Business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available. During the year ended June 30, 2018, the Company incurred acquisition and integration related expenses of $40.2 million associated with the acquisition of the Data Center Business, including a $25.0 million consent fee paid to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom Corporation, in anticipation of Broadcom’s proposed acquisition of Brocade. The fee was paid to allow the Company to buy the Data Center Business directly from Brocade. Such acquisition-related costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying consolidated statements of operations. The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants.

[0001564590-18-022453:notes:114]
Campus Fabric Business

[0001564590-18-022453:notes:115]
The Company completed its acquisition of Avaya Inc.’s. (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) on July 14, 2017, (the “Campus Fabric Business Closing Date”) pursuant to an Asset Purchase Agreement (the “Campus Fabric Business APA”) dated March 7, 2017.  Under the terms and conditions of the Campus Fabric Business APA, the Company acquired the customers, employees, technology and other assets of the Campus Fabric Business, as well as assumed certain contracts and other liabilities of the Campus Fabric Business, for total consideration of $79.4 million, calculated as $100.0 million, less adjustments set forth in the Campus Fabric Business APA related to net working capital, deferred revenue, certain assumed lease obligations and certain assumed pension obligations for transferred employees of the Campus Fabric Business.

[0001564590-18-022453:notes:116]
The acquisition has been accounted for using the acquisition method of accounting. The purchase price allocation as of the Acquisition Date is set forth in the table below and reflects fair values. The fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of June 30, 2018.

[0001564590-18-022453:notes:117]
The following table below summarizes the final allocation as of June 30, 2018 of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-18-022453:notes:118]
|  | Preliminary Allocation as of July 14, 2017 |  |  | Adjustments |  |  | Final Allocation as of June 30, 2018 |  |
| Accounts receivables | $ | 18,112 |  |  | $ | 1,415 |  | (a) | $ | 19,527 |  |
| Inventories |  | 16,605 |  |  |  | (2,440 | ) | (g)(h)(k) |  | 14,165 |  |
| Prepaid expenses and other current assets |  | 673 |  |  |  | (433 | ) | (b) |  | 240 |  |
| Property and equipment |  | 3,768 |  |  |  | 1,638 |  | (c) |  | 5,406 |  |
| Other assets |  | 2,568 |  |  |  | 4,441 |  | (d)(h) |  | 7,009 |  |
| Accounts payable and accrued expenses |  | (29,716 | ) |  |  | (1,954 | ) | (e)(i)(j) |  | (31,670 | ) |
| Deferred revenue |  | (10,214 | ) |  |  | 1,220 |  | (d)(i) |  | (8,994 | ) |
| Other long-term liabilities |  | (6,608 | ) |  |  | 759 |  | (j) |  | (5,849 | ) |
| Net tangible assets acquired |  | (4,812 | ) |  |  | 4,646 |  |  |  | (166 | ) |
| Identifiable intangible assets |  | 44,000 |  |  |  | (2,700 | ) | (f) |  | 41,300 |  |
| In-process research and development |  | 2,300 |  |  |  | 100 |  | (f) |  | 2,400 |  |
| Goodwill |  | 38,338 |  |  |  | (2,446 | ) |  |  | 35,892 |  |
| Total intangible assets acquired |  | 84,638 |  |  |  | (5,046 | ) |  |  | 79,592 |  |
| Total net assets acquired | $ | 79,826 |  |  | $ | (400 | ) |  | $ | 79,426 |  |

[0001564590-18-022453:notes:119]
Adjustments to the preliminary allocation as of the Closing Date through the final allocation during the measurement period as reflected in the table above include: a) identification of additional accounts receivable that existed as of the acquisition date, b) additional information on existing prepaid expenses as of the acquisition date, c) identification of additional property and equipment, d) adjustment to future cash flows of remaining performance obligations of certain customer contracts as of the acquisition date, e) identification of additional unpaid invoices as of the acquisition date, and f) finalization of adjustments to discount rate and future cash flows, g) additional receipts of inventory from Avaya pertaining to the Campus Fabric Business, h) reclassification of service parts to other assets, i) reclassification from deferred revenue to accounts payable, j) reclassification of long-term liabilities to short-term liabilities assumed, and k) adjustments to purchase consideration based on working capital settlement specifically related to inventory that could not be located.

[0001564590-18-022453:notes:120]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  | 2 - 4 |  |  | $ | 31,800 |  |
| Customer relationships |  |  | 4 |  |  |  | 5,100 |  |
| Trade names |  | 4 - 5 |  |  |  | 2,600 |  |
| Backlog |  |  | 1 |  |  |  | 1,800 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 41,300 |  |

[0001564590-18-022453:notes:121]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statement of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the Campus Fabric Business. The Company anticipates both the goodwill and intangible assets to be fully deductible for income tax purposes.

[0001564590-18-022453:notes:122]
The Company also acquired an indefinite lived asset of $2.4 million which represents the fair value of in-process research and development activities. During the three months ended March 31, 2018, the related research and development efforts were completed and the Company reclassified the in-process research and development of $2.4 million to developed technology and began recognizing amortization expense over its estimated useful life.

[0001564590-18-022453:notes:123]
The results of operations of the Campus Fabric Business are included in the accompanying consolidated results of operations beginning July 14, 2017. The Campus Fabric Business revenue for the year ended June 30, 2018 was $179.8 million and has been incorporated into the revenue of the Company. The associated expenses of the Campus Fabric Business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available. In the year ended June 30, 2018, the Company incurred acquisition and integration related expenses of $18.7 million associated with the acquisition of the Campus Fabric Business. Such acquisition-related costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying consolidated statements of operations. The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants and companies.

[0001564590-18-022453:notes:124]
Capital Financing Business

[0001564590-18-022453:notes:125]
On December 1, 2017, Company completed its acquisition of a capital financing business (the “CF Business”), pursuant to a Bill of Sale and Assignment and Assumption Agreement (the “Assumption Agreement”) between the Company and Broadcom. Under the terms and conditions of the Assumption Agreement, the Company acquired customers, employees, contracts and lease equipment of the CF Business for purchase consideration consisting of the earn out payments to Broadcom representing 90% of acquired financing receivables to be collected commencing at the closing date, which was determined to have a fair value of $13.0 million.

[0001564590-18-022453:notes:126]
Net assets acquired included financing receivables of $13.7 million, lease equipment of $3.5 million and identifiable intangible assets of $0.8 million.  As the fair value of the net assets acquired exceeded the fair value of the purchase consideration, the Company recorded a bargain purchase gain of $5.0 million which is included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying consolidated statements of operations. Acquisition and integration related expenses associated with the acquisition of the CF Business were immaterial.

[0001564590-18-022453:notes:127]
Fiscal 2017 Acquisition

[0001564590-18-022453:notes:128]
On October 28, 2016, the Company completed its acquisition of the wireless local area network business (“WLAN Business”) from Zebra Technologies Corporation. Under the terms of the WLAN Asset Purchase Agreement, the Company acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for a net cash consideration of $49.5 million. The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-18-022453:notes:129]
|  | Final Allocation as of October 28, 2016 |  |
| Accounts receivables, net | $ | 14,636 |  |
| Inventories |  | 13,593 |  |
| Other current assets |  | 808 |  |
| Property and equipment |  | 3,159 |  |
| Other assets |  | 7,634 |  |
| Deferred revenue |  | (14,159 | ) |
| Other liabilities |  | (7,201 | ) |
| Total tangible assets acquired and liabilities assumed |  | 18,470 |  |
| Identifiable intangible assets |  | 20,300 |  |
| In-process research and development |  | 1,400 |  |
| Goodwill |  | 9,339 |  |
| Total intangible assets acquired |  | 31,039 |  |
| Total net assets acquired | $ | 49,509 |  |

[0001564590-18-022453:notes:130]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the WLAN Business. The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001564590-18-022453:notes:131]
The Company also acquired an indefinite lived asset of $1.4 million which represents the fair value of in-process research and development activities. The in-process research and development was reclassified to developed technology upon completion of the project as of June 30, 2018 and is being amortized over its estimated useful life.

[0001564590-18-022453:notes:132]
Pro forma financial information

[0001564590-18-022453:notes:133]
The following unaudited pro forma results of operations are presented as though the acquisitions of the Data Center Business, Campus Fabric Business, CF Business and WLAN Business had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-18-022453:notes:134]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the earliest period presented, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-18-022453:notes:135]
The unaudited pro forma financial information for the year ended June 30, 2018, combines the results for Extreme for the year ended June 30, 2018, which include the results of the Data Center Business, CF Business and Campus Fabric Business subsequent to their acquisition dates and their historical results up to the acquisition date.

[0001564590-18-022453:notes:136]
The unaudited pro forma financial information for the year ended June 30, 2017, combines the historical results for Extreme for those periods, as adjusted for the adoption of Topic 606, with the historical results of the Data Center Business, CF Business and Campus Fabric Business for the year ended June 30, 2017, as well as the historical results of the WLAN Business prior to the WLAN Business acquisition date.

[0001564590-18-022453:notes:137]
Pro forma results of operations from the Data Center Business, CF Business, Campus Fabric Business and WLAN Business acquisitions included in the pro forma results of operations have not been adjusted for the adoption of Topic 606 because the Company determined that it is impractical to estimate the impact of the adoption.

[0001564590-18-022453:notes:138]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0001564590-18-022453:notes:139]
|  | Year Ended |  |
|  | June 30, 2018 |  |  | June 30, 2017 |  |
| Net revenues | $ | 1,076,988 |  |  | $ | 1,205,696 |  |
| Net loss | $ | (27,007 | ) |  | $ | (143,835 | ) |
| Net loss per share - basic | $ | (0.24 | ) |  | $ | (1.33 | ) |
| Net loss per share - diluted | $ | (0.24 | ) |  | $ | (1.33 | ) |
| Shares used in per share calculation - basic |  | 114,221 |  |  |  | 108,273 |  |
| Shares used in per share calculation - diluted |  | 114,221 |  |  |  | 108,273 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-022453:notes:140]
5. Balance Sheet Components

[0001564590-18-022453:notes:141]
The following is a summary of cash, cash equivalents and marketable securities (in thousands):

[0001564590-18-022453:notes:142]
|  |  | June 30, 2018 |  | June 30, 2017 |
| Cash |  | $121,139 |  | $126,159 |
| Cash equivalents |  | — |  | 4,291 |
| Total cash and cash equivalents |  | 121,139 |  | 130,450 |
| Marketable securities (consisting of available-for-sale securities) |  | 1,459 |  | — |
| Total cash, cash equivalents and marketable securities |  | $122,598 |  | $130,450 |

[0001564590-18-022453:notes:143]
Marketable securities are recorded in “Prepaid expenses and other current assets” in the accompanying consolidated balance sheets.

[0001564590-18-022453:notes:144]
Accounts Receivable

[0001564590-18-022453:notes:145]
The following is a summary of Accounts receivable (in thousands):

[0001564590-18-022453:notes:146]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Accounts receivable |  | $ | 225,167 |  |  | $ | 101,601 |  |
| Allowance for doubtful accounts |  |  | (1,478 | ) |  |  | (1,190 | ) |
| Allowance for product returns |  |  | (11,266 | ) |  |  | (7,296 | ) |
| Accounts receivable, net |  | $ | 212,423 |  |  | $ | 93,115 |  |

[0001564590-18-022453:notes:147]
The following table is a summary of the allowance for doubtful accounts (in thousands):

[0001564590-18-022453:notes:148]
|  |  | Balance at beginning of period |  | Charges to bad debt expenses |  | Deductions (1) |  | Balance at end of period |
| Year Ended June 30, 2018: |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $1,190 |  | $1,687 |  | $(1,399) |  | $1,478 |
| Year Ended June 30, 2017: |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $1,648 |  | $323 |  | $(781) |  | $1,190 |
| Year Ended June 30, 2016: |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $1,316 |  | $834 |  | $(502) |  | $1,648 |

[0001564590-18-022453:notes:149]
|  | (1) | Uncollectible accounts written off, net of recoveries |

[0001564590-18-022453:notes:150]
The following table is a summary of the Company’s allowance for product returns (in thousands):

[0001564590-18-022453:notes:151]
| Description |  | Balance at beginning of period |  | Additions |  | Deductions |  | Balance at end of period |
| Year Ended June 30, 2018: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $7,296 |  | $38,103 |  | $(34,133) |  | $11,266 |
| Year Ended June 30, 2017 (As adjusted): |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $3,123 |  | $31,034 |  | $(26,861) |  | $7,296 |
| Year Ended June 30, 2016 (As adjusted): |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $8,201 |  | $23,153 |  | $(28,231) |  | $3,123 |

[0001564590-18-022453:notes:152]
The following is a summary of the Company’s inventory by category (in thousands):

[0001564590-18-022453:notes:153]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Finished goods |  | $ | 49,393 |  |  | $ | 46,620 |  |
| Raw materials |  |  | 14,474 |  |  |  | 790 |  |
| Total Inventory |  | $ | 63,867 |  |  | $ | 47,410 |  |

[0001564590-18-022453:notes:154]
Property and Equipment, Net

[0001564590-18-022453:notes:155]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Computer and equipment |  | $ | 60,677 |  |  | $ | 34,716 |  |
| Purchased software |  |  | 21,389 |  |  |  | 11,785 |  |
| Office equipment, furniture and fixtures |  |  | 14,980 |  |  |  | 10,852 |  |
| Leasehold improvements |  |  | 50,070 |  |  |  | 23,046 |  |
| Total property and equipment |  |  | 147,116 |  |  |  | 80,399 |  |
| Less: accumulated depreciation and amortization |  |  | (68,597 | ) |  |  | (50,159 | ) |
| Property and equipment, net |  | $ | 78,519 |  |  | $ | 30,240 |  |

[0001564590-18-022453:notes:156]
The Company recognized depreciation expense of $23.5 million, $10.6 million, and $10.8 million related to property and equipment during the years ended June 30, 2018, 2017, and 2016, respectively.

[0001564590-18-022453:notes:157]
The following table summarizes deferred revenue (in thousands):

[0001564590-18-022453:notes:158]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Deferred maintenance and support |  | $ | 164,986 |  |  | $ | 97,310 |  |
| Deferred other revenue |  |  | 9,539 |  |  |  | 7,031 |  |
| Total deferred revenue |  |  | 174,525 |  |  |  | 104,341 |  |
| Less: current portion |  |  | 130,865 |  |  |  | 79,048 |  |
| Non-current deferred revenue |  | $ | 43,660 |  |  | $ | 25,293 |  |

[0001564590-18-022453:notes:159]
Accrued Warranty

[0001564590-18-022453:notes:160]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0001564590-18-022453:notes:161]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Balance beginning of period |  | $ | 10,584 |  |  | $ | 9,998 |  |
| Warranties assumed due to acquisition |  |  | 3,682 |  |  |  | 2,034 |  |
| New warranties issued |  |  | 10,491 |  |  |  | 6,194 |  |
| Warranty expenditures |  |  | (11,950 | ) |  |  | (7,642 | ) |
| Balance end of period |  | $ | 12,807 |  |  | $ | 10,584 |  |

[0001564590-18-022453:notes:162]
Other Long-term Liabilities

[0001564590-18-022453:notes:163]
The following is a summary of long-term liabilities (in thousands):

[0001564590-18-022453:notes:164]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Acquisition related deferred payments, less current portion |  | $ | 13,251 |  |  | $ | — |  |
| Contingent consideration obligations, less current portion |  |  | 4,898 |  |  |  | — |  |
| Other contractual obligations, less current portion |  |  | 31,200 |  |  |  | — |  |
| Other |  |  | 9,751 |  |  |  | 8,526 |  |
| Total other long-term liabilities |  | $ | 59,100 |  |  | $ | 8,526 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-18-022453:notes:165]
6. Fair Value Measurements

[0001564590-18-022453:notes:166]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0001564590-18-022453:notes:167]
|  | • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-18-022453:notes:168]
|  | • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-18-022453:notes:169]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value. |

[0001564590-18-022453:notes:170]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-18-022453:notes:171]
| June 30, 2018 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable securities |  | $ | 1,459 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,459 |  |
| Total assets measured at fair value |  | $ | 1,459 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,459 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 12,749 |  |  | $ | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 12,749 |  |  | $ | — |  |

[0001564590-18-022453:notes:172]
| June 30, 2017 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,291 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,291 |  |
| Investment in non-marketable equity |  |  | — |  |  |  | — |  |  |  | 3,000 |  |  |  | 3,000 |  |
| Total assets measured at fair value |  | $ | 4,291 |  |  | $ | — |  |  | $ | 3,000 |  |  | $ | 7,291 |  |

[0001564590-18-022453:notes:173]
Level 1 investments:

[0001564590-18-022453:notes:174]
The Company holds investments in equity securities acquired from the sale of an investment in non-marketable equity securities during the first quarter of fiscal 2018, which is classified as available-for-sale marketable securities at Level 1 as the investments have readily determinable fair value (see below, Level 3 investments). An unrealized holding gain on the investments was $0.5 million as of June 30, 2018 which will be reclassified from accumulated other comprehensive loss to accumulated deficit on July 1, 2018 upon an adoption of ASU 2016-01 (see Note 2).

[0001564590-18-022453:notes:175]
Level 2 investments:

[0001564590-18-022453:notes:176]
The Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2. There were no transfers of assets or liabilities between Level 1 and Level 2 for the periods presented.

[0001564590-18-022453:notes:177]
The fair value of the borrowings under the Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the short duration until maturity of the Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $200.0 million and $93.7 million as of June 30, 2018 and 2017, respectively.  Such differences are immaterial for all periods presented.

[0001564590-18-022453:notes:178]
Level 3 investments:

[0001564590-18-022453:notes:179]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.

[0001564590-18-022453:notes:180]
As of June 30, 2017, the Company reflected its non-marketable equity investment as Level 3 in the fair value hierarchy as it is based on unobservable inputs that market participants would use in pricing this asset due to the absence of recent comparable market transactions and inherent lack of liquidity.  During fiscal 2015, the Company purchased a $3.0 million equity interest in a company that operated in the enterprise software platform industry.  The Company did not enter into any other transactions with the investee during fiscal 2017 or the first quarter of fiscal 2018.   During the three months ended September 30, 2017, the investee was acquired by a third party.  The Company received $6.8 million as consideration for its equity interest in the investee, including $5.4 million in cash and 65,937 shares of the third party’s publicly-traded common stock (the “Acquirer’s common stock”) with a market value of $1.4 million. During the first quarter of fiscal 2018, the Company received $5.8 million of the consideration, consisting of $4.9 million in cash and 41,685 shares with a market value of $0.9 million. The remainder of the consideration consisting of $0.5 million of cash and $0.5 million of 23,252 shares of the Acquirers common stock will remain in escrow for a period of 18 months from the date of sales for general representations and warranties. A gain of $3.8 million related to this sale was recorded in “Other income (expense), net” in the accompanying consolidated statement of operations for the year ended June 30, 2018.

[0001564590-18-022453:notes:181]
During the fourth quarter of fiscal 2018, the Company sold 18,700 shares of the Acquirer’s common stock and recorded a gain of $0.2 million. The remaining 22,985 shares held by the Company and 23,252 shares to be released from escrow within one year are considered Level 1 investments as these have a readily determinable fair value and quoted prices in active markets.

[0001564590-18-022453:notes:182]
During the year ended June 30, 2018, the Company recorded a liability for contingent consideration related to its acquisition of the CF Business (see Note 4 for additional information related to the acquisition). The fair value measurement of the contingent consideration obligations is determined using Level 3 inputs. The fair value of contingent consideration obligations is based on a discounted cash flow model.  These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations would be recorded in general and administrative expenses in the accompanying consolidated statements of operations.

[0001564590-18-022453:notes:183]
The change in the acquisition-related contingent consideration obligations is as follows (in thousands):

[0001564590-18-022453:notes:184]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |
| Beginning balance |  | $ | — |  |
| Initial fair value measurements |  |  | 47,030 |  |
| Payments |  |  | (671 | ) |
| Resolution of contingency |  |  | (36,980 | ) |
| Accretion on discount |  |  | 3,134 |  |
| Change in fair value |  |  | 236 |  |
| Ending balance |  | $ | 12,749 |  |

[0001564590-18-022453:notes:185]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the year ended June 30, 2018 or 2017. There were no impairments recorded for the year ended June 30, 2018 or 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-022453:notes:186]
7. Goodwill and Intangible Assets

[0001564590-18-022453:notes:187]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-18-022453:notes:188]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Balance at beginning of period |  | $ | 80,216 |  |  | $ | 70,877 |  |
| Additions due to acquisitions |  |  | 58,866 |  |  |  | 9,339 |  |
| Balance at end of period |  | $ | 139,082 |  |  | $ | 80,216 |  |

[0001564590-18-022453:notes:189]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0001564590-18-022453:notes:190]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
| June 30, 2018 |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| Developed technology |  | 3.3 years |  | $ | 117,000 |  |  | $ | 58,299 |  |  | $ | 58,701 |  |
| Customer relationships |  | 3.0 years |  |  | 51,639 |  |  |  | 40,634 |  |  |  | 11,005 |  |
| Maintenance contracts |  | 0.3 years |  |  | 17,000 |  |  |  | 15,866 |  |  |  | 1,134 |  |
| Trade names |  | 3.4 years |  |  | 9,100 |  |  |  | 4,141 |  |  |  | 4,959 |  |
| Backlogs |  | — years |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |
| License agreements |  | 5.8 years |  |  | 2,445 |  |  |  | 1,390 |  |  |  | 1,055 |  |
| Other intangibles |  | 1.6 years |  |  | 1,382 |  |  |  | 1,144 |  |  |  | 238 |  |
| Total intangibles, net |  |  |  | $ | 200,366 |  |  | $ | 123,274 |  |  | $ | 77,092 |  |

[0001564590-18-022453:notes:191]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
| June 30, 2017 |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| Developed technology |  | 5.3 years |  | $ | 55,400 |  |  | $ | 42,689 |  |  | $ | 12,711 |  |
| Customer relationships |  | 3.3 years |  |  | 40,300 |  |  |  | 37,567 |  |  |  | 2,733 |  |
| Maintenance contracts |  | 1.3 years |  |  | 17,000 |  |  |  | 12,467 |  |  |  | 4,533 |  |
| Trade names |  | 4.3 years |  |  | 5,100 |  |  |  | 2,846 |  |  |  | 2,254 |  |
| License agreements |  | 6.4 years |  |  | 2,445 |  |  |  | 1,120 |  |  |  | 1,325 |  |
| Other intangibles |  | 2.7 years |  |  | 1,382 |  |  |  | 1,001 |  |  |  | 381 |  |
| Total intangibles, net with finite lives |  |  |  |  | 121,627 |  |  |  | 97,690 |  |  |  | 23,937 |  |
| In-process research and development, with indefinite life |  |  |  |  | 1,400 |  |  |  | — |  |  |  | 1,400 |  |
| Total intangibles, net |  |  |  | $ | 123,027 |  |  | $ | 97,690 |  |  | $ | 25,337 |  |

[0001564590-18-022453:notes:192]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-18-022453:notes:193]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 16,870 |  |  | $ | 7,020 |  |  | $ | 15,369 |  |
| Amortization of intangibles |  |  | 8,715 |  |  |  | 8,702 |  |  |  | 17,001 |  |
| Total amortization |  | $ | 25,585 |  |  | $ | 15,722 |  |  | $ | 32,370 |  |

[0001564590-18-022453:notes:194]
The amortization expense that is recognized in “Cost of revenues: Product” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-18-022453:notes:195]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0001564590-18-022453:notes:196]
| For the fiscal year ending: |  |  |  |  |
| 2019 |  | $ | 25,867 |  |
| 2020 |  |  | 22,973 |  |
| 2021 |  |  | 20,851 |  |
| 2022 |  |  | 6,277 |  |
| 2023 |  |  | 875 |  |
| Thereafter |  |  | 249 |  |
| Total |  | $ | 77,092 |  |


## us-gaap:DebtDisclosureTextBlock

[0001564590-18-022453:notes:197]
8. Debt

[0001564590-18-022453:notes:198]
Debt

[0001564590-18-022453:notes:199]
The Company’s debt is comprised of the following (in thousands):

[0001564590-18-022453:notes:200]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (493 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 9,007 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 180,500 |  |  | $ | 71,268 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,751 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 188,749 |  |  |  | 80,422 |  |
| Total debt |  | $ | 197,756 |  |  | $ | 92,702 |  |

[0001564590-18-022453:notes:201]
During the second quarter of fiscal 2017, the Company entered into an Amended and Restated Credit Agreement (the “Credit Facility”) with Silicon Valley Bank, as administrative agent and collateral agent, and the financial institutions that are a party thereto as lenders.   The Credit Facility provided for a five-year $90.5 million term loan (the “Term Loan”) and a five-year $50.0 million revolving loan facility (the “Revolving Facility”), which included a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Facility among other things, amended and restated the Company’s previous credit facility.  The borrowings under the Credit Facility during fiscal 2017 were used to acquire the WLAN Business as more fully described in Note 4. Business Combinations.

[0001564590-18-022453:notes:202]
The Credit Facility was amended on March 2, 2017, by Amendment One to such agreement, in anticipation of the acquisition of the Campus Fabric Business as more fully described in the Form 8-K filed on that date.

[0001564590-18-022453:notes:203]
In connection with the closing of Campus Fabric Business discussed in Note 4, the Company entered into the Second Amendment to the Credit Facility (the “Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016, by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) an increase to the five-year Term Loan from $90.5 million to up to $183.7 million and (b) increased the five-year Revolving Facility in a principal amount of up to $60.0 million, (ii) extends the maturity date under the Term Loan and the termination date under the Revolving Facility, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility.  On July 14, 2017, the Company borrowed $80.0 million under the Term Loan which was used to fund the purchase of the Campus Fabric Business.

[0001564590-18-022453:notes:204]
In connection with the closing of the acquisition of the Data Center Business discussed in Note 4, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”) on October 26, 2017. Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Data Center Business Purchase Agreement (as defined above). On the Data Center Business Closing Date, the Company borrowed $20.0 million on the Amended Term Loan to partially fund the acquisition of the Data Center Business.

[0001564590-18-022453:notes:205]
On May 1, 2018, the Company terminated the Credit Facility as amended and entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”), ii) a $190 million five-year term loan (the “New Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement in order to pay off existing debt and for general corporate purposes.

[0001564590-18-022453:notes:206]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting June 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-18-022453:notes:207]
The Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-18-022453:notes:208]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  During the year ended June 30, 2018, in conjunction with the Credit Agreement, as noted above, the Company recorded a loss from an extinguishment of debt of $1.2 million in “Interest expense” in the accompanying consolidated statements of operations and incurred $1.5 million of deferred financing costs.

[0001564590-18-022453:notes:209]
Amortization of deferred financing costs is included in “Interest expense” in the accompanying consolidated statements of operations, totaled $0.7 million, $0.5 million and $0.4 million in fiscal years 2018, 2017 and 2016, respectively.

[0001564590-18-022453:notes:210]
The Company had $28.7 million of availability under the New Revolving Facility as of June 30, 2018.  The Company had $1.3 million of outstanding letters of credit as of June 30, 2018.

[0001564590-18-022453:notes:211]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0001564590-18-022453:notes:212]
| For the fiscal year ending: |  |  |  |  |
| 2019 |  | $ | 9,500 |  |
| 2020 |  |  | 9,500 |  |
| 2021 |  |  | 14,250 |  |
| 2022 |  |  | 14,250 |  |
| 2023 |  |  | 152,500 |  |
| Total |  | $ | 200,000 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-022453:notes:213]
9. Commitments and Contingencies

[0001564590-18-022453:notes:214]
Leases

[0001564590-18-022453:notes:215]
The Company currently leases its current headquarters, research and development facilities and office spaces for its various United States and international operations. Certain leases contain rent escalation clauses and renewal options. As part of the Company’s existing leased facilities, the Company occasionally receives lease incentives payments from the landlord which are used to make leasehold improvements on the respective facility. The Company depreciates the leasehold improvements over the useful life of the assets or the lease term, whichever is shorter.  The lease incentives payments are deferred and amortized on a straight-line basis over the term of the lease as an offset to rent expense.

[0001564590-18-022453:notes:216]
Future annual minimum lease payments under all non-cancelable operating leases having initial or remaining lease terms in excess of one year at June 30, 2018, were as follows (in thousands):

[0001564590-18-022453:notes:217]
| For the fiscal year ending: |  | Future Lease Payments |  |
| 2019 |  | $ | 27,517 |  |
| 2020 |  |  | 18,014 |  |
| 2021 |  |  | 17,560 |  |
| 2022 |  |  | 16,632 |  |
| 2023 |  |  | 14,157 |  |
| Thereafter |  |  | 18,983 |  |
| Total minimum payments |  | $ | 112,863 |  |

[0001564590-18-022453:notes:218]
Rent expense was $12.9 million, $9.4 million and $8.5 million in fiscal years 2018, 2017 and 2016, respectively.

[0001564590-18-022453:notes:219]
Purchase Commitments

[0001564590-18-022453:notes:220]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company.  The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2018, the Company had non-cancelable commitments to purchase $144.0 million of such inventory, which will be received and consumed during the first half of fiscal 2019. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0001564590-18-022453:notes:221]
Legal Proceedings

[0001564590-18-022453:notes:222]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-18-022453:notes:223]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-18-022453:notes:224]
Brazilian Tax Assessment Matters

[0001564590-18-022453:notes:225]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (US $1.0 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of June 30, 2018.

[0001564590-18-022453:notes:226]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.9 million (approximately U.S. $5.1 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of June 30, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

[0001564590-18-022453:notes:227]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (approximately U.S. $2.9 million) as of the date the Company acquired Enterasys Networks.

[0001564590-18-022453:notes:228]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-18-022453:notes:229]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-18-022453:notes:230]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  On July 18, 2018, the parties to the litigation commenced a mediation process with the assistance of a professional mediator and the Company believes the parties have arrived at an agreement in principle which they are in the process of documenting and which is subject to court approval.

[0001564590-18-022453:notes:231]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended.  On July 18, 2018, the parties to the litigation commenced a mediation process with the assistance of a professional mediator and the Company believes the parties have arrived at an agreement in principle which they are in the process of documenting and which is subject to court approval.

[0001564590-18-022453:notes:232]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-18-022453:notes:233]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board of inter partes review petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.   Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date), and scheduled a status conference on October 22, 2018.  The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-022453:notes:234]
DIFF Scale Operation Research, LLC v. Extreme Networks, Inc.

[0001564590-18-022453:notes:235]
On March 15, 2018, DIFF Scale Operation Research, LLC (“DIFF”) filed a patent infringement lawsuit against the Company in the United States District Court for the Southern District of New York (DIFF Scale Operation Research, LLC v. Extreme Networks, Inc., No. 18-cv-2324-KBF).  The complaint alleged infringement of seven patents (four expired) generally directed to virtual connection networking.  The parties have settled this dispute, and the court signed a stipulation and order of dismissal with prejudice on June 21, 2018.

[0001564590-18-022453:notes:236]
Be Labs, Inc. v. Extreme Networks, Inc.

[0001564590-18-022453:notes:237]
On April 25, 2018, Be Labs, Inc. (“Be Labs”) filed a patent infringement lawsuit against the Company in the United States District Court for the District of Delaware (Be Labs, Inc. v. Extreme Networks, Inc., No. 1:18-cv-00626).  The complaint alleged direct and indirect infringement of two patents generally directed to a multimedia wireless distribution system for home or office use, and appears to accuse the Company’s 802.11ac- and 802.11n-compliant ExtremeWireless products.  The parties have settled this dispute, and Be Labs dismissed the case with prejudice on July 9, 2018.

[0001564590-18-022453:notes:238]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-18-022453:notes:239]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-022453:notes:240]
Indemnification Obligations

[0001564590-18-022453:notes:241]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of June 30, 2018, the Company has the outstanding indemnification claims described above.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-18-022453:notes:242]
10. Stockholders’ Equity

[0001564590-18-022453:notes:243]
Preferred Stock

[0001564590-18-022453:notes:244]
In April 2001, in connection with the entering into of the Company’s Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2018, no shares of preferred stock were outstanding.

[0001564590-18-022453:notes:245]
Stockholders’ Rights Agreement

[0001564590-18-022453:notes:246]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as subsequently amended, between the Company and Mellon Investor Services LLC (the “Prior Rights Plan”).

[0001564590-18-022453:notes:247]
The Board adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 the Board and shareholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  Our Board of Directors unanimously approved an amendment to the Restated Rights Plan on May 9, 2018 to extend the Restated Rights Plan through May 31, 2019, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting, expected to be held on November 8, 2018.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-022453:notes:248]
11. Employee Benefit Plans

[0001564590-18-022453:notes:249]
As of June 30, 2018, the Company has the following share-based compensation plans:

[0001564590-18-022453:notes:250]
2013 Equity Incentive Plan

[0001564590-18-022453:notes:251]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, up to 12.7 million shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan.  The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting.  During the fiscal years ended June 30, 2018 and 2017, an additional 9.0 million shares and 8.3 million shares, respectively, were authorized and made available for grant under the 2013 Plan. As of June 30, 2018, total options and awards to acquire 9.0 million shares were outstanding under the 2013 Plan and 12.1 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0001564590-18-022453:notes:252]
Enterasys 2013 Stock Plan

[0001564590-18-022453:notes:253]
Pursuant to the acquisition of Enterasys on October 31, 2013, the Company assumed the Enterasys 2013 Stock Plan (the “Enterasys Plan”).  As of June 30, 2018, total options to acquire 0.8 million shares were outstanding under the Enterasys Plan. Options granted under this plan have a contractual term of seven years. No future grants may be made from the Enterasys Plan.

[0001564590-18-022453:notes:254]
2005 Equity Incentive Plan

[0001564590-18-022453:notes:255]
The 2005 Plan was adopted by the Company’s Board of Directors on October 20, 2005, and approved by stockholders on December 2, 2005. The 2005 Plan replaced the Amended 1996 Stock Option Plan (the “1996 Plan”), the 2000 Non-statutory Stock Option Plan and the 2001 Non-statutory Stock Option Plan. The 2005 Plan includes provisions upon the granting of certain awards defined by the 2005 Plan as Full Value Awards in which the shares available for grant under the 2005 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2005 Plan for future issuance as was applied upon granting. Effective November 20, 2013, the 2005 Plan was replaced with the 2013 Plan, and, as of June 30, 2018, total options to acquire 0.2 million shares were outstanding under the 2005 Plan.  No future grants may be made from the 2005 Plan, however, outstanding options and awards forfeited or canceled were allowed to be transferred to the 2013 Plan until December 2, 2015, at which time, no further shares may be transferred. A total of 6.6 million shares were transferred to the 2013 Plan.

[0001564590-18-022453:notes:256]
Shares Reserved for Issuance

[0001564590-18-022453:notes:257]
The following are shares reserved for issuance (in thousands):

[0001564590-18-022453:notes:258]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Employee stock options and awards outstanding |  |  | 9,957 |  |  |  | 9,726 |  |
| 2013 Employee Plan shares available for grant |  |  | 12,060 |  |  |  | 7,629 |  |
| 2014 Employee Stock Purchase Plan |  |  | 5,365 |  |  |  | 7,785 |  |
| Total shares reserved for issuance |  |  | 27,382 |  |  |  | 25,140 |  |

[0001564590-18-022453:notes:259]
Stock Options

[0001564590-18-022453:notes:260]
The 1996 Plan was originally adopted in September 1996, and provided for the grant of options for common stock to eligible participants. Effective December 2, 2005, the 1996 Plan was terminated, and, as of June 30, 2016, no options to acquire shares remain outstanding under the 1996 Plan. No future grants may be made from the 1996 Plan.

[0001564590-18-022453:notes:261]
The following table summarizes stock option activity under all plans (shares and intrinsic value in thousands):

[0001564590-18-022453:notes:262]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2017 |  |  | 3,062 |  |  | $ | 4.06 |  |  |  | 4.19 |  |  | $ | 15,868 |  |
| Exercised |  |  | (854 | ) |  | $ | 4.52 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (15 | ) |  | $ | 4.26 |  |  |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2018 |  |  | 2,193 |  |  | $ | 3.88 |  |  |  | 2.90 |  |  | $ | 8,996 |  |
| Vested and expected to vest at June 30, 2018 |  |  | 2,193 |  |  | $ | 3.88 |  |  |  | 2.90 |  |  | $ | 8,996 |  |
| Exercisable at June 30, 2018 |  |  | 1,980 |  |  | $ | 4.03 |  |  |  | 2.80 |  |  | $ | 7,781 |  |

[0001564590-18-022453:notes:263]
The total intrinsic value of options exercised in fiscal years 2018, 2017 and 2016 was $6.3 million, $5.7 million and $0.2 million, respectively.

[0001564590-18-022453:notes:264]
There were no stock options granted in fiscal 2018 or 2017. The weighted-average estimated fair value of stock options granted in fiscal years 2016 was $1.59 per share. As of June 30, 2018, there was $0.2 million of total unrecognized compensation cost related to unvested stock options that will be fully recognized in fiscal 2019.

[0001564590-18-022453:notes:265]
Stock Awards

[0001564590-18-022453:notes:266]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (“RSUs”), including performance or market-based restricted stock units (“PSUs”) which vest over a fixed period of time or based upon the satisfaction of certain performance criteria. The Company recognizes compensation expense on the awards over the vesting period based on the award’s intrinsic value as of the date of grant.

[0001564590-18-022453:notes:267]
The following table summarizes stock award activity (shares and market value in thousands):

[0001564590-18-022453:notes:268]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2017 |  |  | 6,664 |  |  | $ | 4.66 |  |  |  |  |  |
| Granted |  |  | 4,595 |  |  | $ | 11.15 |  |  |  |  |  |
| Vested |  |  | (2,956 | ) |  | $ | 3.79 |  |  |  |  |  |
| Cancelled |  |  | (539 | ) |  | $ | 8.05 |  |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2018 |  |  | 7,764 |  |  | $ | 8.60 |  |  | $ | 61,804 |  |

[0001564590-18-022453:notes:269]
The aggregate fair value, as of the respective vesting dates of RSUs vested during the fiscal years ended June 30, 2018, 2017 and 2016 was $51.2 million, $9.1 million and $8.6 million, respectively.

[0001564590-18-022453:notes:270]
Fiscal 2018 PSU

[0001564590-18-022453:notes:271]
During fiscal 2018, the Company approved the grant of 1.2 million stock awards to its vice president level employees or above (“VPs”), including 0.6 million stock awards to its Executive Officers.  Fifty percent (50%) of the stock awards granted to the VPs, except the chief executive officer, were in the form of PSUs and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs.  The Company’s chief executive officer received sixty percent (60%) of his stock award grant in the form of PSUs, while forty percent (40%) of this award were in the form of RSUs. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-18-022453:notes:272]
The PSUs referenced in the preceding paragraph will be considered earned once the Company’s U.S. GAAP earnings aggregates at least $0.32 per share over two consecutive quarters (the “2018 Performance Threshold”).  Upon satisfying the 2018 Performance Threshold, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the 2018 Performance Threshold is not met by the third anniversary of the grant date, the award is canceled.  In addition, the 2018 Performance Threshold will be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $16.00 per share; or, in the event the consideration is less than $16.00 per share, the number of PSUs deemed to be earned will be determined by multiplying the number of PSUs by the ratio of the aggregate earnings per share of the last two quarters prior to the Change of Control to the $0.32 Performance Threshold. The grant date fair value per share of the PSUs referenced above was $10.90. During the year ended June 30, 2018, none of the PSU grants referenced above achieved their 2018 Performance Threshold.

[0001564590-18-022453:notes:273]
During fiscal 2018, the Company approved the grant of 0.1 million stock awards with market-based vesting criteria to certain VPs with grant date fair values per share ranging from $10.61 to $12.19 determined by using the Monte-Carlo simulation model.

[0001564590-18-022453:notes:274]
Fiscal 2017 PSU

[0001564590-18-022453:notes:275]
During fiscal 2017, the Company approved the grant of 1.5 million stock awards to its VPs, including 0.7 million stock awards to its Executive Officers.  Fifty percent (50%) of the stock awards granted to the VPs were in the form of PSUs and fifty percent (50%) of the stock awards granted were in the form of RSUs. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-18-022453:notes:276]
The PSUs referenced in the preceding paragraph were considered earned once the Company’s stock price equaled or exceeded $5.00 per share for 30 consecutive trading days after January 1, 2017 (the “2017 Performance Threshold”). The grant date fair values per share of the PSUs were determined by using the Monte-Carlo simulation model, ranging $3.02 to $3.09. The assumptions used in the Monte-Carlo simulation includes the expected volatility of 56%, risk-free rate of 0.9%, no expected divided yield, expected term of 3.0 years and possible future stock prices over the performance period based on historical stock and market prices. The assumptions used in the Monte-Carlo simulation includes the risk-free rate, expected divided yield, expected term, and possible future stock prices over the performance period based on historical stock and market prices. Once the 2017 Performance Threshold goal was attainted, the PSUs began to vest on the same schedule as the RSUs that were granted at the same time, subject to continued service to the Company.  During the year ended June 30, 2017, all of the PSUs referenced above achieved their 2017 Performance Threshold and as such, began vesting and will be released on the schedule as noted, subject to continued service to the Company.

[0001564590-18-022453:notes:277]
During fiscal 2017, the Company approved grants of 1.4 million stock awards in the form of PSUs to certain VPs, including 0.9 million shares to its Executive Officers. Fifty percent (50%) of the PSUs are earned based on the Company’s stock price appreciation (the “Stock Price PSUs”) and fifty percent (50%) of the PSUs are earned based on the Company’s total stockholder return relative to the S&P Small Cap 600 Capped Information Technology Index (the “TSR PSUs”).

[0001564590-18-022453:notes:278]
The Stock Price PSUs represent the right to receive a number of shares of common stock up to one and one-third of the target number of Stock Price PSUs. They are earned and vest as follows based on the average adjusted closing stock price of the Company’s common stock for the 90 days ending as of May 4, 2020, subject to the grantees’ continued service through the certification of performance:

[0001564590-18-022453:notes:279]
| Average adjusted closing stock price |  | Shares earned |
| at least $8.96 but less than $11.63 |  | One-third |
| at least $11.63 but less than $13.15 |  | Two-thirds |
| at least $13.15 but less than $16.56 |  | 100% |
| $16.56 or more |  | One and one-third |

[0001564590-18-022453:notes:280]
No PSUs are earned if such average adjusted closing stock price is less than $8.96.

[0001564590-18-022453:notes:281]
The TSR PSUs represent the right to receive a number of shares of common stock up to 130% of the target number of TSR PSUs. They are earned and vest as follows based on the positive percentage point difference between the Company’s total stockholder return and the total stockholder return for the S&P Small Cap 600 Capped Information Technology Index over the performance period from May 4, 2017 to May 4, 2020, subject to the grantees’ continued service through the certification of performance:

[0001564590-18-022453:notes:282]
| Level |  | Percentage point differencebetween Company TSR andindex TSR |  |  | Shares earned |  |
| Threshold |  |  | 0 | % |  |  | 0 | % |
| Target |  |  | + 25 | % |  |  | 100 | % |
| Maximum |  |  | + 35 | % |  |  | 130 | % |

[0001564590-18-022453:notes:283]
Total stockholder return is calculated based on the 90-day average stock price at the beginning and end of the performance period. Linear interpolation is generally used to determine the number of shares earned for achievement between threshold and target levels and between target and maximum levels. However, if the Company’s total stockholder return over the performance period is negative, the number of shares earned will be capped at 100% of the target number of TSR PSUs.

[0001564590-18-022453:notes:284]
The grant date fair values per share of the Stock Price PSUs and the TSR PSUs were determined by using the Monte-Carlo simulation model, ranging $7.01 to $8.76, respectively. The assumptions used in the Monte-Carlo simulation includes the expected volatility of 54%, risk-free rate of 1.5%, no expected divided yield, expected term of 3.0 years and possible future stock prices over the performance period based on historical stock and market prices.

[0001564590-18-022453:notes:285]
For the fiscal years ended June 30, 2018, 2017 and 2016, the Company withheld an aggregate of 1.0 million shares, 0.4 million shares and 0.1 million shares, respectively, upon the vesting of RSUs, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0001564590-18-022453:notes:286]
For fiscal years 2018, 2017 and 2016, the Company remitted cash of $11.3 million, $2.0 million and $0.2 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0001564590-18-022453:notes:287]
As of June 30, 2018, there were $41.7 million in unrecognized compensation costs related to non-vested stock awards. This cost is expected to be recognized over a weighted-average period of 1.57 years

[0001564590-18-022453:notes:288]
Performance Grant Activity

[0001564590-18-022453:notes:289]
The following table summarizes PSU’s with market or performance based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0001564590-18-022453:notes:290]
|  |  | Fiscal year 2018 |  |  | Fiscal year 2017 |  |  | Fiscal year 2016 |  |
| Performance awards granted |  |  | 714 |  |  |  | 2,106 |  |  |  | 695 |  |
| Performance awards earned |  |  | 566 |  |  |  | 839 |  |  |  | 582 |  |

[0001564590-18-022453:notes:291]
2014 Employee Stock Purchase Plan

[0001564590-18-022453:notes:292]
In August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. The 2014 ESPP replaced the 1999 Employee Stock Purchase Plan. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period has a maximum duration of six months. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. During fiscal 2018, the 2014 ESPP had offerings periods of either 6 months or 24 months, commonly referred to as “look back periods”. As of June 30, 2018, there have been 6.6 million shares issued under the 2014 ESPP.

[0001564590-18-022453:notes:293]
Effective with the offering period beginning on February 1, 2016, the Company amended the 2014 ESPP to increase the maximum shares issuable for each purchase period from 1.0 million shares to 1.5 million shares. Effective with the offering period beginning on August 1, 2016, the Company amended the 2014 ESPP so that all future offering periods are limited to six months and to make certain other changes to the 2014 ESPP including adding new contribution limits for each offering period. Existing open offering periods prior to the effective date of the changes were unaffected by the amendments to the 2014 ESPP.

[0001564590-18-022453:notes:294]
Share Based Compensation Expense

[0001564590-18-022453:notes:295]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (in thousands):

[0001564590-18-022453:notes:296]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Cost of product revenue |  | $ | 564 |  |  | $ | 333 |  |  | $ | 882 |  |
| Cost of service revenue |  |  | 1,131 |  |  |  | 589 |  |  |  | 1,041 |  |
| Research and development |  |  | 7,642 |  |  |  | 3,312 |  |  |  | 4,559 |  |
| Sales and marketing |  |  | 9,843 |  |  |  | 4,253 |  |  |  | 4,633 |  |
| General and administrative |  |  | 8,453 |  |  |  | 4,146 |  |  |  | 3,677 |  |
| Total share-based compensation expense |  | $ | 27,633 |  |  | $ | 12,633 |  |  | $ | 14,792 |  |

[0001564590-18-022453:notes:297]
The amount of stock based compensation expense capitalized in inventory has been immaterial for each of the periods presented.

[0001564590-18-022453:notes:298]
The Company uses the straight-line method for expense attribution other than the PSUs using the accelerated attribution method. Beginning in fiscal 2017, the Company no longer estimates forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur. The Company’s estimated forfeiture rate in fiscal 2016 based on the Company’s historical forfeiture experience was 13% for non-executives and 19% for executives.

[0001564590-18-022453:notes:299]
The fair value of each stock option grant under the Company’s 2013 Plan and 2005 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-18-022453:notes:300]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-18-022453:notes:301]
The weighted-average estimated per share fair value of shares purchased under the 2014 ESPP in fiscal years 2018, 2017 and 2016, was $3.25, $1.24 and $0.92, respectively.

[0001564590-18-022453:notes:302]
|  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Expected life |  | 4.0 years |  |  | 4.2 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 1.2 years |  |
| Risk-free interest rate |  |  | 1.78 | % |  |  | 1.17 | % |  | 1.64%–1.15% |  |  |  | 0.40 | % |  |  | 0.33 | % |
| Volatility |  |  | 52 | % |  |  | 50 | % |  |  | 42 | % |  | 40%–37% |  |  |  | 58 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-18-022453:notes:303]
401(k) Plan

[0001564590-18-022453:notes:304]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $18,500 for calendar year 2018. Employees age 50 or over may elect to contribute an additional $6,000. The amount contributed to the Plan is on a pre-tax basis.

[0001564590-18-022453:notes:305]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately.  In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. The program during fiscal 2018 is to match $0.50 for every Dollar contributed by the employee up to the first 2.5% of pay.  The Company’s matching contributions to the Plan totaled $3.3 million, $1.4 million and $1.2 million, for fiscal years 2018, 2017 and 2016, respectively. No discretionary contributions were made in fiscal years 2018, 2017 or 2016.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-022453:notes:306]
12. Information about Segments of Geographic Areas

[0001564590-18-022453:notes:307]
The Company operates in one segment, the development and marketing of network infrastructure equipment.  Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan. The Company’s chief operating decision maker (“CODM”), who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-18-022453:notes:308]
See Note 3. Revenues for the Company’s revenues by geographic regions and channel based on the customer’s ship-to location.

[0001564590-18-022453:notes:309]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-18-022453:notes:310]
| Long Lived Assets: |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Americas |  | $ | 178,251 |  |  | $ | 67,369 |  |
| EMEA |  |  | 15,106 |  |  |  | 8,998 |  |
| APAC |  |  | 9,896 |  |  |  | 4,275 |  |
| Total long-lived assets |  | $ | 203,253 |  |  | $ | 80,642 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-022453:notes:311]
13. Foreign Exchange Forward Contracts

[0001564590-18-022453:notes:312]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes.  The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying consolidated statements of operations; the Company recognized losses of $1.2 million and $0.7 million in fiscal 2018 and 2017, respectively, and gains of $1.3 million in fiscal 2016 related to the change in fair value. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges.

[0001564590-18-022453:notes:313]
At June 30, 2018 and 2017, forward foreign currency contracts had a notional principal amount of $5.0 million and $6.7 million, respectively. These contracts have maturities of less than 60 days.  Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-022453:notes:314]
14. Restructuring and Related Charges, Net of Reversals

[0001564590-18-022453:notes:315]
As of June 30, 2018, restructuring liabilities were $6.5 million which are recorded in “Other accrued liabilities” and “Other long-term liabilities” in the accompanying consolidated balance sheets.  The restructuring liabilities consist of obligations pertaining to the estimated future obligations for non-cancelable lease payments and severance and benefits obligations.  During fiscal years 2018, 2017 and 2016, the Company recorded restructuring charges, net of reversals, of $8.1 million, $8.9 million and $11.0 million, respectively.  The charges are reflected in “Restructuring and related charges, net of reversals” in the consolidated statements of operations.

[0001564590-18-022453:notes:316]
2018 Restructuring

[0001564590-18-022453:notes:317]
The Company announced and began executing a reduction-in-force in its third and fourth fiscal quarters as a result of the acquisitions of the Campus Fabric Business and the Data Center Business. The Company recorded $7.9 million related to employee severance and benefits expenses during the year ended June 30, 2018.  The Company also incurred charges of $0.2 million for changes to its estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of its excess facilities.

[0001564590-18-022453:notes:318]
2017 Restructuring

[0001564590-18-022453:notes:319]
In conjunction with the Company’s restructuring activities noted below, the Company incurred $8.9 million of restructuring charges, net of reversals during fiscal 2017 which is reflected in “Restructuring and related charges, net of reversals” in the consolidated statements of operations.

[0001564590-18-022453:notes:320]
Pursuant with the WLAN Business acquisition from Zebra, the Company assumed a facility lease located at 6480 Via del Oro in San Jose, California (“Via del Oro”) and transferred the Company’s headquarters from Rio Robles Drive in San Jose, California (“Rio Robles”) to Via del Oro.  The Company consolidated its existing workforce with employees assumed from Zebra at the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to the Company’s move from the Rio Robles facility and abandonment of all leasehold improvements, it accelerated the amortization of the remaining leasehold improvements balance for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  The Company recorded accelerated amortization expense for the year ended June 30, 2018 of $2.6 million.

[0001564590-18-022453:notes:321]
The Company entered into a sublease agreement for its Rio Robles facility during the third quarter of fiscal 2017.  The sublease is for the remaining duration of the Company’s lease. The net charges incurred for the remaining lease payments, real estate commissions and other related costs, net of the future sublease payments resulted in additional charges of $2.0 million during fiscal 2017. The excess facilities payments will continue through fiscal year 2023.

[0001564590-18-022453:notes:322]
In anticipation of the acquisitions of the Campus Fabric and the Data Center Businesses, the Company reoccupied the majority of its exited space at its Salem, New Hampshire location during its fiscal fourth quarter to accommodate the growth in headcount and lab facility requirements.  This action resulted in a reversal of prior accruals of $1.3 million.

[0001564590-18-022453:notes:323]
In conjunction with the consolidation actions noted above, the Company announced a reduction-in-force affecting 90 employees.  The Company recorded $5.6 million in severance and benefits charges, net during the year ended June 30, 2017.

[0001564590-18-022453:notes:324]
2016 Restructuring

[0001564590-18-022453:notes:325]
During fiscal 2016, the Company abandoned excess facilities, primarily in San Jose, California; Salem, New Hampshire; Morrisville, North Carolina and other smaller leased locations. The abandoned facilities represented approximately 32% of the floor space in the aggregate at these locations and included general office and warehouse space.

[0001564590-18-022453:notes:326]
In conjunction with the exiting of facilities noted above, the Company incurred $11.0 million of restructuring charges. Excess facilities charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and contract termination charges of $5.4 million, acceleration of depreciation of leasehold improvements of $4.5 million, professional fees of $1.0 million and other of $0.1 million.

[0001564590-18-022453:notes:327]
Significant restructuring charges incurred during 2016, by location, included $1.8 million of charges for excess facilities pertaining to the estimated future obligations for non-cancelable lease payments at Rio Robles.  This represented 39% of the San Jose leased space.  The Company amended its facility lease at its North Carolina location and exited excess space while recording $4.1 million of charges, which included $3.1 million in accelerated depreciation of leasehold improvements. This action represented 36% of the North Carolina location lease space. The Company recorded $4.4 million of charges for excess facilities at its Salem location, which included $1.3 million in accelerated depreciation of leasehold improvements.  This action represented 27% of the Salem lease space.

[0001564590-18-022453:notes:328]
Restructuring liabilities consist of (in thousands):

[0001564590-18-022453:notes:329]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2015 |  | $ | — |  |  | $ | 5,737 |  |  | $ | 117 |  |  | $ | 5,854 |  |
| Period charges |  |  | 10,811 |  |  |  | 668 |  |  |  | 237 |  |  |  | 11,716 |  |
| Period reversals |  |  | (18 | ) |  |  | (618 | ) |  |  | (90 | ) |  |  | (726 | ) |
| Non cash adjustments |  |  | (4,463 | ) |  |  | — |  |  |  | — |  |  |  | (4,463 | ) |
| Period payments |  |  | (1,686 | ) |  |  | (5,787 | ) |  |  | (264 | ) |  |  | (7,737 | ) |
| Balance as of June 30, 2016 |  |  | 4,644 |  |  |  | — |  |  |  | — |  |  |  | 4,644 |  |
| Period charges |  |  | 1,951 |  |  |  | 5,728 |  |  |  | 2,663 |  |  |  | 10,342 |  |
| Period reversals |  |  | (1,337 | ) |  |  | (109 | ) |  |  | — |  |  |  | (1,446 | ) |
| Non cash adjustments |  |  | — |  |  |  | — |  |  |  | (2,578 | ) |  |  | (2,578 | ) |
| Period payments |  |  | (3,074 | ) |  |  | (3,766 | ) |  |  | — |  |  |  | (6,840 | ) |
| Balance as of June 30, 2017 |  |  | 2,184 |  |  |  | 1,853 |  |  |  | 85 |  |  |  | 4,122 |  |
| Period charges |  |  | 207 |  |  |  | 7,945 |  |  |  | — |  |  |  | 8,152 |  |
| Period reversals |  |  | — |  |  |  | — |  |  |  | (12 | ) |  |  | (12 | ) |
| Period payments |  |  | (594 | ) |  |  | (5,140 | ) |  |  | (73 | ) |  |  | (5,807 | ) |
| Balance as of June 30, 2018 |  | $ | 1,797 |  |  | $ | 4,658 |  |  | $ | — |  |  | $ | 6,455 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 5,074 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,381 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-022453:notes:330]
15. Income Taxes

[0001564590-18-022453:notes:331]
Income before income taxes is as follows (in thousands):

[0001564590-18-022453:notes:332]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |
| Domestic |  | $ | (55,197 | ) |  | $ | (7,228 | ) |  | $ | (34,271 | ) |
| Foreign |  |  | 8,550 |  |  |  | 9,824 |  |  |  | 2,244 |  |
| Total |  | $ | (46,647 | ) |  | $ | 2,596 |  |  | $ | (32,027 | ) |

[0001564590-18-022453:notes:333]
The provision for income taxes for fiscal years 2018, 2017 and 2016 consisted of the following (in thousands):

[0001564590-18-022453:notes:334]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | (155 | ) |  | $ | (155 | ) |  | $ | 727 |  |
| State |  |  | 521 |  |  |  | 168 |  |  |  | 75 |  |
| Foreign |  |  | 4,456 |  |  |  | 2,332 |  |  |  | 1,793 |  |
| Total current |  |  | 4,822 |  |  |  | 2,345 |  |  |  | 2,595 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (6,358 | ) |  |  | 3,063 |  |  |  | 1,659 |  |
| State |  |  | 294 |  |  |  | 99 |  |  |  | 108 |  |
| Foreign |  |  | 1,387 |  |  |  | (1,167 | ) |  |  | (26 | ) |
| Total deferred |  |  | (4,677 | ) |  |  | 1,995 |  |  |  | 1,741 |  |
| Provision for income taxes |  | $ | 145 |  |  | $ | 4,340 |  |  | $ | 4,336 |  |

[0001564590-18-022453:notes:335]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (28 percent for fiscal 2018 pursuant to the recently enacted U.S. tax legislation) to income before taxes is explained below (in thousands):

[0001564590-18-022453:notes:336]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |
| Tax at federal statutory rate |  | $ | (13,061 | ) |  | $ | 909 |  |  | $ | (11,209 | ) |
| State income tax, net of federal benefit |  |  | 521 |  |  |  | 168 |  |  |  | 75 |  |
| Change in valuation allowance |  |  | 25,302 |  |  |  | 3,246 |  |  |  | 9,465 |  |
| Research and development credits |  |  | (7,311 | ) |  |  | (1,355 | ) |  |  | (1,364 | ) |
| Foreign earnings taxed at other than U.S. rates |  |  | (1,065 | ) |  |  | (492 | ) |  |  | 1,678 |  |
| Stock based compensation |  |  | (5,901 | ) |  |  | (573 | ) |  |  | 3,564 |  |
| Goodwill amortization |  |  | 2,004 |  |  |  | 1,795 |  |  |  | 1,672 |  |
| Nondeductible officer compensation |  |  | 1,927 |  |  |  | 470 |  |  |  | 77 |  |
| Nondeductible meals and entertainment |  |  | 510 |  |  |  | 391 |  |  |  | 289 |  |
| AMT credit monetization |  |  | (155 | ) |  |  | (155 | ) |  |  | — |  |
| Deferred tax liability release - Tax reform |  |  | (2,482 | ) |  |  | — |  |  |  | — |  |
| Other |  |  | (144 | ) |  |  | (64 | ) |  |  | 89 |  |
| Provision for income taxes |  | $ | 145 |  |  | $ | 4,340 |  |  | $ | 4,336 |  |

[0001564590-18-022453:notes:337]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001564590-18-022453:notes:338]
|  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 49,429 |  |  | $ | 109,170 |  |  | $ | 108,563 |  |
| Tax credit carry-forwards |  |  | 48,093 |  |  |  | 34,444 |  |  |  | 32,730 |  |
| Depreciation |  |  | 1,422 |  |  |  | 1,312 |  |  |  | — |  |
| Intangible amortization |  |  | 35,107 |  |  |  | 32,919 |  |  |  | 28,480 |  |
| Deferred revenue, net |  |  | 159 |  |  |  | 3,320 |  |  |  | 3,190 |  |
| Inventory write-downs |  |  | 13,682 |  |  |  | 11,111 |  |  |  | 6,207 |  |
| Other allowances and accruals |  |  | 25,700 |  |  |  | 13,002 |  |  |  | 10,568 |  |
| Stock based compensation |  |  | 4,872 |  |  |  | 3,545 |  |  |  | 4,048 |  |
| Other |  |  | 2,185 |  |  |  | 4,270 |  |  |  | 4,275 |  |
| Total deferred tax assets |  |  | 180,649 |  |  |  | 213,093 |  |  |  | 198,061 |  |
| Valuation allowance |  |  | (177,869 | ) |  |  | (212,111 | ) |  |  | (196,640 | ) |
| Total net deferred tax assets |  |  | 2,780 |  |  |  | 982 |  |  |  | 1,421 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation |  |  | — |  |  |  | — |  |  |  | (343 | ) |
| Goodwill amortization |  |  | (3,363 | ) |  |  | (6,254 | ) |  |  | (4,459 | ) |
| Deferred tax liability on foreign withholdings |  |  | (357 | ) |  |  | (321 | ) |  |  | (235 | ) |
| Total deferred tax liabilities |  |  | (3,720 | ) |  |  | (6,575 | ) |  |  | (5,037 | ) |
| Net deferred tax liabilities |  | $ | (940 | ) |  | $ | (5,593 | ) |  | $ | (3,616 | ) |
| Recorded as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net non-current deferred tax assets |  | $ | 5,195 |  |  | $ | 983 |  |  | $ | 1,077 |  |
| Net non-current deferred tax liabilities |  |  | (6,135 | ) |  |  | (6,576 | ) |  |  | (4,693 | ) |
| Net deferred tax liabilities |  | $ | (940 | ) |  | $ | (5,593 | ) |  | $ | (3,616 | ) |

[0001564590-18-022453:notes:339]
The Company’s global valuation allowance decreased by $34.2 million in the fiscal year ended June 30, 2018 and increased by $15.5 million in the fiscal year ended June 30, 2017. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against non-U.S. deferred tax assets in Australia and Brazil.  The valuation allowance is determined by assessing both negative and positive available evidence to assess whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of the Company's business provides sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001564590-18-022453:notes:340]
As of June 30, 2018, the Company had net operating loss carry-forwards for U.S. federal and state tax purposes of $185.6 million and $54.4 million, respectively.  As of June 30, 2018, the Company also had foreign net operating loss carry-forwards in Ireland, Australia and Brazil of $37.5 million, $9.0 million and $0.7 million, respectively.  As of June 30, 2018, the Company also had federal and state tax credit carry-forwards of $33.2 million and $18.8 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits.  The U.S. federal net operating loss carry-forwards of $185.6 million will begin to expire in the fiscal year ending June 30, 2021 and state net operating losses of $54.4 million began to partially expire in the fiscal year ending June 30, 2018. The foreign net operating losses can generally be carried forward indefinitely.  Federal research and development tax credits of $22.6 million will expire beginning in fiscal 2019, if not utilized and foreign tax credits of $10.6 million will expire beginning in fiscal 2020.  North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2024, if not utilized. California state research and development tax credits of $17.9 million do not expire and can be carried forward indefinitely.

[0001564590-18-022453:notes:341]
In September, 2017, the Company performed an Internal Revenue Code section 382 analysis with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2017, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes.

[0001564590-18-022453:notes:342]
As of June 30, 2018, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $14.1 million.  It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the US.  As discussed below, recently enacted tax reform includes a provision to move the U.S. to a modified territorial tax system by imposing a transition tax on historic foreign earnings whether or not such earnings are repatriated to the U.S. The Company has determined there will be no cash tax impact of this new provision due to existing tax attributes.  The Company is reviewing its prior position on the reinvestment of earnings of certain foreign subsidiaries but has recorded a deferred tax liability of $0.4 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential withholding tax associated with repatriation of these earnings is $2.7 million.

[0001564590-18-022453:notes:343]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business, the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire and North Carolina.  As of June 30, 2017, the Company is currently under examination by the state of North Carolina for the fiscal years ended 2014, 2015 and 2016. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.

[0001564590-18-022453:notes:344]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, is effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, the Company will not be subject to the majority of the tax law provisions until fiscal year 2019; however, there are certain significant items of impact that will be recognized in fiscal year 2018. Because a change in tax law is accounted for in the period of enactment, the effects of the TCJA, a tax benefit of $2.5 million, was reflected in the full year results for fiscal 2018.

[0001564590-18-022453:notes:345]
The TCJA’s primary change is a reduction in the U.S. Federal statutory corporate tax rate from 35% to 21%, including a pro rata reduction from 35% to 28% for the Company in fiscal 2018.  As a result, the Company recognized a tax benefit in the amount of $2.5 million in the second quarter of fiscal 2018 due to the revaluation of the Company's deferred tax liability related to amortizable goodwill to reflect the lower statutory rate.  Because the U.S. deferred tax assets are offset by a full valuation allowance, the reduction in deferred tax assets for the lower rate was fully offset by a corresponding reduction in valuation allowance resulting in no additional tax provision.

[0001564590-18-022453:notes:346]
The TCJA moves the U.S. from a global taxation regime to a modified territorial regime.  Under the territorial regime, the company’s foreign earnings will generally not be subject to tax in the US.  As part of transitioning to this new regime, U.S. companies are required to pay tax on historical earnings generated offshore that have not been repatriated to the U.S. (“Transition Tax”).  The Company has estimated there will be no incremental tax provision relating to the Transition Tax given the Company’s ability to utilize existing tax attributes to offset the impact of the deemed repatriation.

[0001564590-18-022453:notes:347]
The TCJA makes broad and complex changes to the U.S. tax code, and in certain instances, lacks clarity and is subject to interpretation until additional U.S. Treasury guidance is issued.  On December 22, 2017, the SEC issued guidance under Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (“SAB 118”), which allows registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations.  However, the measurement period is deemed to have ended earlier when the registrant has obtained, prepared and analyzed the information necessary to finalize its accounting.  During the measurement period, impacts of the law are expected to be recorded at the time a reasonable estimate for all or a portion of the effects can be made, and provisional amounts can be recognized and adjusted as information becomes available, prepared or analyzed. The SAB summarizes a three-step process to be applied at each reporting period to account for and qualitatively disclose: (1) the effects of the change in tax law for which accounting is complete; (2) provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but that a reasonable estimate has been determined; and (3) a reasonable estimate cannot yet be made and therefore taxes are reflected in accordance with law prior to the enactment of the TCJA.

[0001564590-18-022453:notes:348]
Amounts recorded where accounting is complete in the year ended June 30, 2018 principally relate to the reduction in the U.S. federal tax rate to 21 percent, which resulted in the Company reporting an income tax benefit of $2.5 million to remeasure deferred tax liabilities associated with indefinitely lived intangible assets that will reverse at the new 21% rate. Absent this deferred tax liability, the Company is in a net deferred tax asset position that is offset by a full valuation allowance.  The impact of the rate change related to net deferred tax assets has a net tax effect of zero, and as such, the accounting to determine the gross change in the deferred tax position and the offsetting valuation is considered complete.  In accordance with Staff Accounting Bulletin (“SAB”) 118, the estimated income tax impact associated with the Transition Tax of zero represents our best estimate based on interpretation of the U.S. legislation as we are still accumulating data to finalize the underlying calculation. In accordance with SAB 118, estimated income tax impact associated with the Transition Tax is considered provisional and will be finalized prior to the end of the measurement period. The ultimate impact may differ from these provisional amounts, due to, among other things, additional analysis, changes in interpretations and assumptions the Company has made, additional regulatory guidance that may be issued, and actions the Company may take as a result of the TCJA.

[0001564590-18-022453:notes:349]
With respect to provisions of the TCJA effective for tax years beginning on or after January 1, 2018, the company anticipates several new provisions may potentially impact tax provisions in future periods including limitations on the deductibility of interest expense and certain executive compensation, a minimum tax on certain foreign earnings (i.e., global intangible low-taxed income or “GILTI”), as well as a base-erosion and anti-abuse tax (“BEAT”).  The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. Based on initial assessment and interpretation of the new provision, the Company expects that it will be subject to incremental U.S. tax on GILTI income beginning in fiscal 2019. The Company may elect to account for GILTI tax as a component of tax expense in the period in which it is incurred or account for the GILTI tax in the measurement of deferred taxes. The Company is continuing to evaluate this particular provision and therefore has not yet elected a method but will do so once our analysis is complete. The BEAT provisions in the Tax Reform Act eliminate the deduction of certain base-erosion payments made to related foreign corporations, and impose a minimum tax if greater than regular tax.  There is a reasonable amount of uncertainty surrounding the interpretation of this new provision, however, based on initial assessment and a conservative interpretation of the new provision, the Company expects that it will be minimally subject to the incremental U.S. tax on BEAT income beginning in fiscal 2019.

[0001564590-18-022453:notes:350]
During the fiscal year ended June 30, 2014, the Company acquired the stock of Enterasys Networks, Inc. and as such they became a wholly owned subsidiary of Extreme Networks.  With respect to this acquisition, the Company made an election under Internal Revenue Code section 338(h)(10) to treat the acquisition as an asset purchase from a tax perspective.  Under this election the tax basis of all assets is effectively reset to that of fair market value and therefore the transaction did not result in the recording of an opening net deferred tax position as the Company's tax basis in the acquired assets equaled its book basis. The resulting intangible assets and goodwill are being amortized for tax purposes over 15 years.

[0001564590-18-022453:notes:351]
Additionally, the Company completed the acquisitions of the Zebra WLAN Business, the Avaya Campus Fabric Business and the Brocade Data Center Business in October 2016, July 2017 and October 2017, respectively, and treats the acquisitions as an asset purchase from a tax perspective. The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.

[0001564590-18-022453:notes:352]
During the twelve months ended June 30, 2018, the Company deducted $7.5 million of tax amortization expense related to capitalized goodwill resulting from the above acquisitions.

[0001564590-18-022453:notes:353]
As of June 30, 2018, the Company had $17.5 million of unrecognized tax benefits.  If fully recognized in the future, there would be no impact to the effective tax rate, and $17.5 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance.  The Company does not reasonably expect the amount of unrealized tax benefits to decrease during the next twelve months. The increase for fiscal year 2018 relates substantially to previously unrecorded foreign net operating losses.

[0001564590-18-022453:notes:354]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001564590-18-022453:notes:355]
| Balance at June 30, 2015 |  | $ | 11,359 |  |
| Increase related to prior year tax positions |  |  | 174 |  |
| Lapse of statute of limitations |  |  | 120 |  |
| Balance at June 30, 2016 |  |  | 11,653 |  |
| Increase related to prior year tax positions |  |  | 7,180 |  |
| Increase related to current year tax positions |  |  | 233 |  |
| Lapse of statute of limitations |  |  | (153 | ) |
| Balance at June 30, 2017 |  |  | 18,913 |  |
| Decrease related to prior year tax positions |  |  | (1,407 | ) |
| Balance at June 30, 2018 |  | $ | 17,506 |  |

[0001564590-18-022453:notes:356]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of tax expense in the consolidated statement of operations and totaled less than $0.1 million for each of the fiscal years 2018, 2017 and 2016.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-022453:notes:357]
16. Net Loss Per Share

[0001564590-18-022453:notes:358]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to options, warrants and unvested restricted stock.  The following table presents the calculation of basic and diluted net loss per share (in thousands, except per share data):

[0001564590-18-022453:notes:359]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
|  |  |  |  |  |  | (As Adjusted) |  |  | (As Adjusted) |  |
| Net loss |  | $ | (46,792 | ) |  | $ | (1,744 | ) |  | $ | (36,363 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 114,221 |  |  |  | 108,273 |  |  |  | 103,074 |  |
| Net loss per share - basic and diluted |  | $ | (0.41 | ) |  | $ | (0.02 | ) |  | $ | (0.35 | ) |

[0001564590-18-022453:notes:360]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.  Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net loss per share since the effect of including them would have been anti-dilutive due to the net loss position of the Company during the periods presented.

[0001564590-18-022453:notes:361]
The following securities were excluded from the computation of outstanding diluted earnings per common share because they would have been anti-dilutive (in thousands):

[0001564590-18-022453:notes:362]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Options to purchase common stock |  |  | 2,547 |  |  |  | — |  |  |  | 6,937 |  |
| Restricted stock units |  |  | 7,822 |  |  |  | 220 |  |  |  | 353 |  |
| Employee Stock Purchase Plan shares |  |  | 1,294 |  |  |  | — |  |  |  | — |  |
| Total shares excluded |  |  | 11,663 |  |  |  | 220 |  |  |  | 7,290 |  |
