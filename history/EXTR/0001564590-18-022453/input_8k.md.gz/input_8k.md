# EXTR 8-K — 0001564590-18-020191 filed 2018-08-08

## item codes, every 8-K on or before 2018-08-29

- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2018-08-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-020191:8k_2_02:1]
EX-99.1
2
extr-ex991_7.htm
EX-99.1

[0001564590-18-020191:8k_2_02:2]
extr-ex991_7.htm

[0001564590-18-020191:8k_2_02:3]
Exhibit 99.1

[0001564590-18-020191:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-18-020191:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Stan Kovler |  | Media Contact Christi Nicolacopoulos |
| 919/595-4196 |  | 603/952-5005 |
| Investor relations@extremenetworks.com |  | pr@extremenetworks.com |

[0001564590-18-020191:8k_2_02:6]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2018 Financial Results

[0001564590-18-020191:8k_2_02:7]
SAN JOSE, Calif., August 8, 2018 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal fourth quarter and full fiscal year ended June 30, 2018.

[0001564590-18-020191:8k_2_02:8]
Fourth Quarter Results:

[0001564590-18-020191:8k_2_02:9]
|  | • | Fourth quarter revenue was $278.3 million, or an increase of 56% year-over-year. |

[0001564590-18-020191:8k_2_02:10]
|  | • | GAAP gross margin for the fourth fiscal quarter was 54.0%, a reduction of 340 basis points year-over-year, and non-GAAP gross margin was 57.6%, an increase of 10 basis points year-over-year. |

[0001564590-18-020191:8k_2_02:11]
|  | • | GAAP operating margin for the fourth fiscal quarter was (1.2)% and non-GAAP operating margin was 9.8%, compared to 8.8% and 12.8%, respectively, year-over-year. |

[0001564590-18-020191:8k_2_02:12]
|  | • | GAAP net loss for the fourth fiscal quarter was $5.6 million, or $(0.05) per basic share, a decrease of $18.8 million and $0.17 per basic share, year-over-year. Non-GAAP net income was $24.0 million, or $0.20 per diluted share, an increase of $3.6 million and $0.02 per diluted share, year-over-year. |

[0001564590-18-020191:8k_2_02:13]
Fiscal Year Results:

[0001564590-18-020191:8k_2_02:14]
|  | • | Fiscal year revenue was $983.1 million, or an increase of 62% year-over-year. |

[0001564590-18-020191:8k_2_02:15]
|  | • | Fiscal year GAAP net loss for the fiscal year was $46.8 million, or $0.41 per basic share, an increase of $45.0 million and $0.39 per basic share, year-over-year. Non-GAAP net income was $78.0 million, or $0.65 per diluted share, or an increase of $20.4 million and $0.13 per diluted share, year-over-year. |

[0001564590-18-020191:8k_2_02:16]
“Our FY18 results highlight year-over-year revenue growth and non-GAAP gross margin improvement. We completed two acquisitions during the fiscal year and achieved 5% year-over-year organic revenue growth in our core Extreme wired and wireless business in our fiscal fourth quarter, the fourth quarter in a row of year-over-year organic growth.” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-18-020191:8k_2_02:17]
"On June 19, we launched our Smart OmniEdge solution for wired and wireless networks, along with validated designs for the educational, healthcare, and retail verticals. We expect to build on our network edge capabilities throughout fiscal 2019 as the industry embraces 802.11ax technology."

[0001564590-18-020191:8k_2_02:18]
“Looking out into fiscal 2019, we are entering the year with $98 million of cross-sell opportunities after closing $40 million in FY18. However, we are resetting expectations for our data center business, and are taking swift action to rebuild our sales pipeline after a disappointing fiscal fourth quarter, while celebrating some key wins. Last quarter, we completed a digital transformation initiative within our supply chain and vendor managed inventory systems, allowing us to run a much more responsive operation. We are now undertaking an initiative over the next six months to bring our portfolio together and consolidate distribution to improve channel efficiency. We expect this change to impact our revenues for the first two quarters of fiscal 2019 by approximately $30-40 million as compared with prior full-year outlook. We believe these actions will materially improve our operating efficiency and working capital. While we expect the combination of lower anticipated revenue in our data center business and our initiative to consolidate distribution to result in a challenging fiscal first quarter 2019, we expect sequential revenue improvements throughout the fiscal year, and we continue to target a 60% gross margin after fiscal Q1,” Meyercord added.

[0001564590-18-020191:8k_2_02:19]
Lastly, Meyercord added: “We have a strong team with a track record of execution. We stabilized and transformed the original Enterasys acquisition into a growth asset. We transformed the Zebra WLAN business into a growth asset with significantly higher margins. We stabilized the Avaya networking assets where we are projecting growth at significantly higher gross margins.  And now, we are focused on driving growth and higher margins in the data center business we acquired from Brocade. We are investing in our datacenter solutions portfolio and are confident we will be able to grow this business at higher margins. With a growing pipeline of cross-sell opportunities, we have more evidence now than ever before, that our end-to-end networking strategy from the wireless edge to the cloud datacenter will drive overall growth and margin expansion at Extreme.”

[0001564590-18-020191:8k_2_02:20]
Recent Key Highlights:

[0001564590-18-020191:8k_2_02:21]
|  | • | Extreme Networks named a leader for the first time in the *2018 Gartner Magic Quadrant for Wired and Wireless LAN Access Infrastructure. On July 13, Extreme Networks, Inc. announced that it is now positioned as a Leader by Gartner, Inc. in the Gartner Magic Quadrant for Wired and Wireless LAN Access Infrastructure. |

[0001564590-18-020191:8k_2_02:22]
|  | • | Extreme Networks named a challenger for the first time in the **2018 Gartner Magic Quadrant for Data Center Networking. |

[0001564590-18-020191:8k_2_02:23]
*Gartner, Magic Quadrant for the Wired and Wireless LAN Access Infrastructure, 11 July 2018. **Gartner, Magic Quadrant for Data Center Networking, 11 July 2018
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001564590-18-020191:8k_2_02:24]
|  | • | Extreme Networks introduced its new Smart OmniEdge Solution. Smart OmniEdge is a powerful artificial intelligence (AI) enabled network edge solution that offers enterprises the ability to deliver an exceptional customer-driven experience with pervasive intelligence, business adaptability and intrinsic security to accelerate their digital transformation. The solution brings |

[0001564590-18-020191:8k_2_02:25]
|  |  | intelligence, adaptability and security to campus and distributed environments via on-premise deployments or as-a-service to accelerate business transformation for enterprise customers. |

[0001564590-18-020191:8k_2_02:26]
|  | • | In our Data Center business, Extreme Networks secured wins with one of the largest corporate data centers in the world and a leading research university with 40,000 students. These customers are deploying SLX switches, part of our Agile Data Center solution, to meet requirements for deep packet buffering, leaf/spine architecture, workflow agility and programmability |

[0001564590-18-020191:8k_2_02:27]
|  | • | Seven primary and higher education institutions worldwide, including SUNY Canton, Rivier University, City University of London, Somerset College, American School of Dubai, Chungbuk National University and Manukau Institute of Technology, recently chose Extreme Networks to connect their classrooms and enable their digital learning environments. With technology from Extreme Networks’ Smart OmniEdge and Automated Campus solutions, these customers are able to offer eSports programs, expand personalized learning and increase security, among other initiatives. |

[0001564590-18-020191:8k_2_02:28]
|  | • | Melbourne’s Metro Trains, one of Australia’s largest metropolitan rail services, selected ExtremeSwitching 10G Ethernet core and edge switching solutions to deliver an agile, adaptive, and secure network supporting its system-wide, real-time CCTV and video system. With ExtremeSwitching technology, part of Extreme’s Smart OmniEdge solution, Metro Trains has real-time access to 100 TB of video traffic daily, equivalent to 20,000 high definition films streaming simultaneously. |

[0001564590-18-020191:8k_2_02:29]
|  | • | University of Florida - University Athletic Association, Inc.(UAA), a non-profit corporation responsible for maintaining the Florida Gators college sports program will deploy Extreme Networks’ Smart OmniEdge solutions, at Ben Hill Griffin Stadium (aka The Swamp). With capacity for 90,000-plus fans, it is the 12th largest football stadium in America, and Extreme’s first NCAA win in the Southeastern Conference Division. The completely under-seat deployment will include Extreme Mobility, ExtremeSwitching, solutions, powered by ExtremeApplications (including ExtremeAnalytics and ExtremeControl), ExtremeControl, and the first-ever stadium deployment of ExtremeLocation. |

[0001564590-18-020191:8k_2_02:30]
|  | • | Texas Tech University Health Sciences Center (TTUHSC), a multi-campus medical school based in Lubbock, Texas, with over 4,000 students, installed a range of Extreme Networks’ Smart OmniEdge solutions to enable IoT and to provide new medical technology for end users. ExtremeApplications provide the customer with application management, visibility and analytics. |

[0001564590-18-020191:8k_2_02:31]
Fiscal Q4 2018 Financial Metrics:

[0001564590-18-020191:8k_2_02:32]
(in millions, except percentages and per share information)

[0001564590-18-020191:8k_2_02:33]
|  |  | 2018 |  |  | 2017 |  |  | Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 221.3 |  |  | $ | 141.0 |  |  | $ | 80.3 |  |  |  | 57 | % |
| Service |  |  | 57.0 |  |  |  | 38.0 |  |  |  | 19.1 |  |  |  | 50 | % |
| Total Net Revenue |  | $ | 278.3 |  |  | $ | 178.9 |  |  | $ | 99.4 |  |  |  | 56 | % |
| Gross Margin |  |  | 54.0 | % |  |  | 57.4 | % |  | (340) bps |  |  |  | (6 | )% |
| Operating Margin |  |  | (1.2 | )% |  |  | 8.8 | % |  | (1,000) bps |  |  |  | (114 | )% |
| Net Income (Loss) |  | $ | (5.6 | ) |  | $ | 13.2 |  |  | $ | (18.8 | ) |  |  | (143 | )% |
| Income (loss) per diluted share |  | $ | (0.05 | ) |  | $ | 0.12 |  |  | $ | (0.17 | ) |  |  | (142 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 221.3 |  |  | $ | 141.0 |  |  | $ | 80.3 |  |  |  | 57 | % |
| Service |  |  | 57.0 |  |  |  | 38.0 |  |  |  | 19.1 |  |  |  | 50 | % |
| Total Net Revenue |  | $ | 278.3 |  |  | $ | 178.9 |  |  | $ | 99.4 |  |  |  | 56 | % |
| Gross Margin |  |  | 57.6 | % |  |  | 57.5 | % |  | 10 bps |  |  |  | % |  |
| Operating Margin |  |  | 9.8 | % |  |  | 12.8 | % |  | (300) bps |  |  |  | (23 | )% |
| Net Income |  | $ | 24.0 |  |  | $ | 20.4 |  |  | $ | 3.6 |  |  |  | 18 | % |
| Earnings per diluted share |  | $ | 0.20 |  |  | $ | 0.18 |  |  | $ | 0.02 |  |  |  | 11 | % |

[0001564590-18-020191:8k_2_02:34]
|  | • | With the adoption of new revenue recognition accounting guidance (“ASC 606”) since July 1, FY’18, we have adjusted prior periods. The impact of these adjustments to the balance sheet and income statement, are noted with “As adjusted”. |

[0001564590-18-020191:8k_2_02:35]
|  | • | Cash and investments ended the quarter at $122.6 million, an increase of $17.3 million from Q3 and a decrease of $7.8 million from Q4 last year. This is driven primarily by the funding and integration of the acquisition of our Campus Fabric and Data Center businesses. |

[0001564590-18-020191:8k_2_02:36]
|  | • | Accounts receivable balance ending Q4 was $212.4 million, with days sales outstanding (“DSO”) at 69. |

[0001564590-18-020191:8k_2_02:37]
|  | • | Q4 ending inventory was $63.9 million, a decrease of $13.9 million from the prior quarter and a decrease of $16.5 million from Q4 last year. |

[0001564590-18-020191:8k_2_02:38]
|  | • | Q4 ending debt was $197.8 million, up $19.1 million from Q3 and an increase of $105.1 million from Q4 last year. This was driven primarily by borrowings to fund Extreme's acquisitions of the Campus Fabric and Data Center businesses. |

[0001564590-18-020191:8k_2_02:39]
Business Outlook:

[0001564590-18-020191:8k_2_02:40]
For its first quarter of fiscal 2019, ending September 30, 2018, the Company is targeting revenue in a range of $230.0 million to $240.0 million.  GAAP gross margin is targeted between 56.6% and 58.7% and non-GAAP gross margin is targeted between 58.5% and 60.5%. Operating expenses are targeted to be between $140.8 million and $143.8 million on a GAAP basis and $130.0 million to $133.0 million on a

[0001564590-18-020191:8k_2_02:41]
non-GAAP basis. GAAP earnings are targeted to be between net loss of $14.6 million to $6.9 million or ($0.12) to ($0.06) per basic share.  Non-GAAP earnings are targeted in a range of net income of $0.6 million to $8.3 million, or $0.00 to $0.07 per diluted share. The GAAP and non-GAAP per share targets are based on 117.8 and 122.7 million average outstanding shares, respectively.

[0001564590-18-020191:8k_2_02:42]
The following table shows the GAAP to non-GAAP reconciliation for Q1 FY’19 guidance:

[0001564590-18-020191:8k_2_02:43]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 56.6% - 58.7% |  |  | (4.6)% - (1.2)% |  |  | ($0.12) - ($0.06) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.7% |  |  | 1.7% |  |  | $ | 0.03 |  |
| Stock based compensation | 0.2% |  |  | 4.1% |  |  | $ | 0.08 |  |
| Amortization of non product intangibles | - |  |  | 0.7% |  |  | $ | 0.01 |  |
| Non-GAAP | 58.5% - 60.5% |  |  | 2.0% - 5.1% |  |  | $0.00 - $0.07 |  |

[0001564590-18-020191:8k_2_02:44]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-18-020191:8k_2_02:45]
Conference Call:

[0001564590-18-020191:8k_2_02:46]
Extreme will host a conference call at 8:30 a.m. Eastern (5:30 a.m. Pacific) today to review the Fourth fiscal quarter results as well as the first fiscal quarter 2019 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August 7, 2019.  The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406   Conference ID # 5987364.

[0001564590-18-020191:8k_2_02:47]
About Extreme Networks:

[0001564590-18-020191:8k_2_02:48]
Extreme Networks, Inc. (EXTR) delivers software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable digital transformation. Our 100% in-sourced services and support are number one in the industry. Even with 30,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking™. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-18-020191:8k_2_02:49]
Extreme Networks and the Extreme Networks logo, Extreme Automated Campus, Extreme Smart OmniEdge, Extreme Agile Data Center, ExtremeAnalytics, ExtremeApplications, ExtremeControl, ExtremeLocation, ExtremeMobility and ExtremeSwitching, are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-18-020191:8k_2_02:50]
Non-GAAP Financial Measures:

[0001564590-18-020191:8k_2_02:51]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of acquired intangibles, restructuring expenses, contingent consideration liability, executive transition costs, litigation expenses, other income, interest expense and income tax.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-18-020191:8k_2_02:52]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-18-020191:8k_2_02:53]
Forward Looking Statements:

[0001564590-18-020191:8k_2_02:54]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-18-020191:8k_2_02:55]
EXTREME NETWORKS, INC.

[0001564590-18-020191:8k_2_02:56]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-020191:8k_2_02:57]
(In thousands)

[0001564590-18-020191:8k_2_02:58]
(Unaudited)

[0001564590-18-020191:8k_2_02:59]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 121,139 |  |  | $ | 130,450 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,478 and $1,190 at June 30, 2018 and 2017, respectively |  |  | 212,423 |  |  |  | 93,115 |  |
| Inventories |  |  | 63,867 |  |  |  | 47,410 |  |
| Prepaid expenses and other current assets |  |  | 30,484 |  |  |  | 27,867 |  |
| Total current assets |  |  | 427,913 |  |  |  | 298,842 |  |
| Property and equipment, net |  |  | 78,519 |  |  |  | 30,240 |  |
| Intangible assets, net |  |  | 77,092 |  |  |  | 25,337 |  |
| Goodwill |  |  | 139,082 |  |  |  | 80,216 |  |
| Other assets |  |  | 47,642 |  |  |  | 25,065 |  |
| Total assets |  | $ | 770,248 |  |  | $ | 459,700 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 9,007 |  |  | $ | 12,280 |  |
| Accounts payable |  |  | 75,689 |  |  |  | 31,587 |  |
| Accrued compensation and benefits |  |  | 50,351 |  |  |  | 42,662 |  |
| Accrued warranty |  |  | 12,807 |  |  |  | 10,584 |  |
| Deferred revenue, net |  |  | 130,865 |  |  |  | 79,048 |  |
| Other accrued liabilities |  |  | 81,153 |  |  |  | 37,044 |  |
| Total current liabilities |  |  | 359,872 |  |  |  | 213,205 |  |
| Deferred revenue, less current portion |  |  | 43,660 |  |  |  | 25,293 |  |
| Long-term debt, less current portion |  |  | 188,749 |  |  |  | 80,422 |  |
| Deferred income taxes |  |  | 6,135 |  |  |  | 6,576 |  |
| Other long-term liabilities |  |  | 59,100 |  |  |  | 8,526 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 112,732 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity |  | $ | 770,248 |  |  | $ | 459,700 |  |

[0001564590-18-020191:8k_2_02:60]
EXTREME NETWORKS, INC.

[0001564590-18-020191:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-020191:8k_2_02:62]
(In thousands, except per share amounts)

[0001564590-18-020191:8k_2_02:63]
(Unaudited)

[0001564590-18-020191:8k_2_02:64]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 221,304 |  |  | $ | 140,956 |  |  | $ | 764,455 |  |  | $ | 460,425 |  |
| Service |  |  | 56,996 |  |  |  | 37,951 |  |  |  | 218,687 |  |  |  | 146,659 |  |
| Total net revenues |  |  | 278,300 |  |  |  | 178,907 |  |  |  | 983,142 |  |  |  | 607,084 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 104,060 |  |  |  | 61,070 |  |  |  | 357,062 |  |  |  | 220,221 |  |
| Service |  |  | 24,073 |  |  |  | 15,222 |  |  |  | 91,563 |  |  |  | 55,906 |  |
| Total cost of revenues |  |  | 128,133 |  |  |  | 76,292 |  |  |  | 448,625 |  |  |  | 276,127 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 117,244 |  |  |  | 79,886 |  |  |  | 407,393 |  |  |  | 240,204 |  |
| Service |  |  | 32,923 |  |  |  | 22,729 |  |  |  | 127,124 |  |  |  | 90,753 |  |
| Total gross profit |  |  | 150,167 |  |  |  | 102,615 |  |  |  | 534,517 |  |  |  | 330,957 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 52,765 |  |  |  | 26,721 |  |  |  | 183,877 |  |  |  | 93,724 |  |
| Sales and marketing |  |  | 73,647 |  |  |  | 45,952 |  |  |  | 267,107 |  |  |  | 162,626 |  |
| General and administrative |  |  | 15,427 |  |  |  | 10,568 |  |  |  | 50,988 |  |  |  | 37,864 |  |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 6,225 |  |  |  | 3,197 |  |  |  | 53,900 |  |  |  | 13,105 |  |
| Restructuring and related charges, net of reversals |  |  | 3,220 |  |  |  | (676 | ) |  |  | 8,140 |  |  |  | 8,896 |  |
| Amortization of intangibles |  |  | 2,254 |  |  |  | 1,192 |  |  |  | 8,715 |  |  |  | 8,702 |  |
| Total operating expenses |  |  | 153,538 |  |  |  | 86,954 |  |  |  | 572,727 |  |  |  | 324,917 |  |
| Operating income (loss) |  |  | (3,371 | ) |  |  | 15,661 |  |  |  | (38,210 | ) |  |  | 6,040 |  |
| Interest income |  |  | 743 |  |  |  | 315 |  |  |  | 2,847 |  |  |  | 689 |  |
| Interest expense |  |  | (5,160 | ) |  |  | (1,086 | ) |  |  | (13,923 | ) |  |  | (4,086 | ) |
| Other income (expense), net |  |  | 514 |  |  |  | (598 | ) |  |  | 2,639 |  |  |  | (47 | ) |
| Income (loss) before income taxes |  |  | (7,274 | ) |  |  | 14,292 |  |  |  | (46,647 | ) |  |  | 2,596 |  |
| Provision for income taxes |  |  | (1,642 | ) |  |  | 1,088 |  |  |  | 145 |  |  |  | 4,340 |  |
| Net income (loss) |  | $ | (5,632 | ) |  | $ | 13,204 |  |  | $ | (46,792 | ) |  | $ | (1,744 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share - basic |  | $ | (0.05 | ) |  | $ | 0.12 |  |  | $ | (0.41 | ) |  | $ | (0.02 | ) |
| Net income (loss) per share - diluted |  | $ | (0.05 | ) |  | $ | 0.12 |  |  | $ | (0.41 | ) |  | $ | (0.02 | ) |
| Shares used in per share calculation - basic |  |  | 115,962 |  |  |  | 110,500 |  |  |  | 114,221 |  |  |  | 108,273 |  |
| Shares used in per share calculation - diluted |  |  | 115,962 |  |  |  | 114,524 |  |  |  | 114,221 |  |  |  | 108,273 |  |

[0001564590-18-020191:8k_2_02:65]
EXTREME NETWORKS, INC.

[0001564590-18-020191:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-020191:8k_2_02:67]
(In thousands)

[0001564590-18-020191:8k_2_02:68]
(Unaudited)

[0001564590-18-020191:8k_2_02:69]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (46,792 | ) |  | $ | (1,744 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 23,471 |  |  |  | 10,618 |  |
| Amortization of intangible assets |  |  | 25,585 |  |  |  | 15,722 |  |
| Provision for doubtful accounts |  |  | 1,687 |  |  |  | 335 |  |
| Stock-based compensation |  |  | 27,633 |  |  |  | 12,633 |  |
| Deferred income taxes |  |  | (4,677 | ) |  |  | 1,995 |  |
| Non-cash restructuring and related charges |  |  | - |  |  |  | 1,031 |  |
| Realized gain on sale of investments |  |  | (3,967 | ) |  |  | - |  |
| Realized gain on bargain purchase |  |  | (5,030 | ) |  |  | - |  |
| Loss on extinguishment of debt |  |  | 1,173 |  |  |  | - |  |
| Other non-cash charges |  |  | 5,933 |  |  |  | 1,339 |  |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (69,518 | ) |  |  | (13,951 | ) |
| Inventories |  |  | 17,343 |  |  |  | 7,413 |  |
| Prepaid expenses and other assets |  |  | (8,014 | ) |  |  | 7,717 |  |
| Accounts payable |  |  | 18,844 |  |  |  | 2,064 |  |
| Accrued compensation and benefits |  |  | 4,981 |  |  |  | 13,058 |  |
| Deferred revenue |  |  | 28,366 |  |  |  | (4,677 | ) |
| Other current and long-term liabilities |  |  | 2,025 |  |  |  | 5,730 |  |
| Net cash provided by operating activities |  | $ | 19,043 |  |  | $ | 59,283 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (40,411 | ) |  |  | (10,425 | ) |
| Business acquisitions |  |  | (97,581 | ) |  |  | (51,088 | ) |
| Deposits related to an acquisition |  |  | - |  |  |  | (10,239 | ) |
| Proceeds from sale of investments |  |  | 5,521 |  |  |  | - |  |
| Net cash used in investing activities |  |  | (132,471 | ) |  |  | (71,752 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | 10,000 |  |  |  | - |  |
| Borrowings under Term Loan |  |  | 290,000 |  |  |  | 48,250 |  |
| Loan fees on borrowings |  |  | (3,211 | ) |  |  | (10,038 | ) |
| Repayments of debt |  |  | (193,713 | ) |  |  | (1,326 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 3,341 |  |  |  | 11,822 |  |
| Payments of contingent consideration |  |  | (671 | ) |  |  | - |  |
| Deferred payments on an acquisition |  |  | (1,000 | ) |  |  | - |  |
| Net cash provided by (used in) financing activities |  |  | 104,746 |  |  |  | 48,708 |  |
| Foreign currency effect on cash |  |  | (629 | ) |  |  | 89 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (9,311 | ) |  |  | 36,328 |  |
| Cash and cash equivalents at beginning of period |  |  | 130,450 |  |  |  | 94,122 |  |
| Cash and cash equivalents at end of period |  | $ | 121,139 |  |  | $ | 130,450 |  |

[0001564590-18-020191:8k_2_02:70]
Extreme Networks, Inc.

[0001564590-18-020191:8k_2_02:71]
Non-GAAP Measures of Financial Performance

[0001564590-18-020191:8k_2_02:72]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-18-020191:8k_2_02:73]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, restructuring expenses, contingent consideration liability, executive transition costs, litigation, amortization of acquired intangibles, other income, interest expense and income tax.

[0001564590-18-020191:8k_2_02:74]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-18-020191:8k_2_02:75]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures to enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-18-020191:8k_2_02:76]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustment, amortization of intangibles, restructuring expenses, contingent consideration liability, executive transition costs, litigation, other income, interest expense and income tax.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-18-020191:8k_2_02:77]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-18-020191:8k_2_02:78]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-18-020191:8k_2_02:79]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Wireless LAN business, b) Campus Fabric business, c) Data Center business and d) the bargain purchase gain for the capital financing business; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-18-020191:8k_2_02:80]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-18-020191:8k_2_02:81]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-18-020191:8k_2_02:82]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-18-020191:8k_2_02:83]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-18-020191:8k_2_02:84]
Remeasurement of contingent consideration liability. Remeasurement of contingent consideration liability related to the Data Center business acquisition.

[0001564590-18-020191:8k_2_02:85]
Executive transition expenses.  Executive transition expenses consist of severance and termination benefits.  The expenses are incurred through execution of pre-established employment contracts with senior executives.

[0001564590-18-020191:8k_2_02:86]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going litigation matters.

[0001564590-18-020191:8k_2_02:87]
Other income. Other income consists of the gain on the sale of investments.

[0001564590-18-020191:8k_2_02:88]
Interest expense. Interest expense consists of the loss related to the debt extinguishment that occurred in conjunction with the new credit facility in May 2018 and noncash interest expense accretion related to the Data Center business acquisition contingent consideration liability.

[0001564590-18-020191:8k_2_02:89]
Income tax.   Income tax adjustments relate to the tax impact of reducing the US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation, as well as the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada and a tax benefit resulting from the restructuring of our foreign operations in Q4.

[0001564590-18-020191:8k_2_02:90]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-18-020191:8k_2_02:91]
EXTREME NETWORKS, INC.

[0001564590-18-020191:8k_2_02:92]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-020191:8k_2_02:93]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-18-020191:8k_2_02:94]
(In thousands, except percentages and per share amounts)

[0001564590-18-020191:8k_2_02:95]
(Unaudited)

[0001564590-18-020191:8k_2_02:96]
| Non-GAAP Revenue | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Revenue - GAAP Basis | $ | 278,300 |  |  | $ | 178,907 |  |  | $ | 983,142 |  |  | $ | 607,084 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | - |  |  |  | - |  |  |  | - |  |  |  | 133 |  |
| Revenue - Non-GAAP Basis | $ | 278,300 |  |  | $ | 178,907 |  |  | $ | 983,142 |  |  | $ | 607,217 |  |

[0001564590-18-020191:8k_2_02:97]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Gross profit - GAAP Basis | $ | 150,167 |  |  | $ | 102,615 |  |  | $ | 534,517 |  |  | $ | 330,957 |  |
| Gross margin - GAAP Basis percentage |  | 54.0 | % |  |  | 57.4 | % |  |  | 54.4 | % |  |  | 54.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 523 |  |  |  | 185 |  |  |  | 1,695 |  |  |  | 922 |  |
| Purchase accounting adjustments |  | - |  |  |  | - |  |  |  | - |  |  |  | 133 |  |
| Acquired inventory adjustments |  | 494 |  |  |  | - |  |  |  | 5,278 |  |  |  | 4,263 |  |
| Acquisition and integration costs |  | 3,626 |  |  |  | (579 | ) |  |  | 11,212 |  |  |  | 4,525 |  |
| Amortization of intangibles |  | 5,481 |  |  |  | 633 |  |  |  | 16,590 |  |  |  | 6,661 |  |
| Gross profit - Non-GAAP Basis | $ | 160,291 |  |  | $ | 102,854 |  |  | $ | 569,292 |  |  | $ | 347,461 |  |
| Gross margin - Non-GAAP Basis percentage |  | 57.6 | % |  |  | 57.5 | % |  |  | 57.9 | % |  |  | 57.2 | % |

[0001564590-18-020191:8k_2_02:98]
| Non-GAAP Operating Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| GAAP operating income (loss) | $ | (3,371 | ) |  | $ | 15,661 |  |  | $ | (38,210 | ) |  | $ | 6,040 |  |
| GAAP operating income (loss) percentage |  | (1.2 | )% |  |  | 8.8 | % |  |  | (3.9 | )% |  |  | 1.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 7,987 |  |  |  | 3,304 |  |  |  | 27,633 |  |  |  | 12,633 |  |
| Acquisition and integration costs, net of bargain purchase gain |  | 9,851 |  |  |  | 2,618 |  |  |  | 65,112 |  |  |  | 17,630 |  |
| Restructuring charge, net of reversal |  | 3,220 |  |  |  | (676 | ) |  |  | 8,140 |  |  |  | 8,896 |  |
| Acquired inventory adjustments |  | 494 |  |  |  | - |  |  |  | 5,278 |  |  |  | 4,263 |  |
| Amortization of intangibles |  | 7,735 |  |  |  | 1,825 |  |  |  | 25,305 |  |  |  | 15,363 |  |
| Purchase accounting adjustments |  | - |  |  |  | - |  |  |  | - |  |  |  | 133 |  |
| Remeasurement of contingent consideration liability |  | 1,470 |  |  |  | - |  |  |  | 1,470 |  |  |  | - |  |
| Executive transition costs |  | - |  |  |  | - |  |  |  | - |  |  |  | 34 |  |
| Litigation |  | - |  |  |  | 166 |  |  |  | (158 | ) |  |  | 385 |  |
| Total adjustments to GAAP operating income (loss) | $ | 30,757 |  |  | $ | 7,237 |  |  | $ | 132,780 |  |  | $ | 59,337 |  |
| Non-GAAP operating income | $ | 27,386 |  |  | $ | 22,898 |  |  | $ | 94,570 |  |  | $ | 65,377 |  |
| Non-GAAP operating income percentage |  | 9.8 | % |  |  | 12.8 | % |  |  | 9.6 | % |  |  | 10.8 | % |

[0001564590-18-020191:8k_2_02:99]
| Non-GAAP Net Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| GAAP net income (loss) | $ | (5,632 | ) |  | $ | 13,204 |  |  | $ | (46,792 | ) |  | $ | (1,744 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 7,987 |  |  |  | 3,304 |  |  |  | 27,633 |  |  |  | 12,633 |  |
| Acquisition and integration costs, net of bargain purchase gain |  | 9,851 |  |  |  | 2,618 |  |  |  | 65,112 |  |  |  | 17,630 |  |
| Restructuring charge, net of reversal |  | 3,220 |  |  |  | (676 | ) |  |  | 8,140 |  |  |  | 8,896 |  |
| Acquired inventory adjustments |  | 494 |  |  |  | - |  |  |  | 5,278 |  |  |  | 4,263 |  |
| Amortization of intangibles |  | 7,735 |  |  |  | 1,825 |  |  |  | 25,305 |  |  |  | 15,363 |  |
| Purchase accounting adjustments |  | - |  |  |  | - |  |  |  | - |  |  |  | 133 |  |
| Remeasurement of contingent consideration liability |  | 1,470 |  |  |  | - |  |  |  | 1,470 |  |  |  | - |  |
| Executive transition costs |  | - |  |  |  | - |  |  |  | - |  |  |  | 34 |  |
| Litigation |  | - |  |  |  | 166 |  |  |  | (158 | ) |  |  | 385 |  |
| Interest expense |  | 1,366 |  |  |  | - |  |  |  | 1,366 |  |  |  | - |  |
| Loss on extinguishment of debt |  | 1,173 |  |  |  | - |  |  |  | 1,173 |  |  |  | - |  |
| Gain on sale of investments |  | (210 | ) |  |  | - |  |  |  | (3,967 | ) |  |  | - |  |
| Income taxes |  | (3,430 | ) |  |  | - |  |  |  | (6,532 | ) |  |  | - |  |
| Total adjustments to GAAP net income (loss) | $ | 29,656 |  |  | $ | 7,237 |  |  | $ | 124,820 |  |  | $ | 59,337 |  |
| Non-GAAP net income | $ | 24,024 |  |  | $ | 20,441 |  |  | $ | 78,028 |  |  | $ | 57,593 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.20 |  |  | $ | 0.18 |  |  | $ | 0.65 |  |  | $ | 0.52 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 120,361 |  |  |  | 114,524 |  |  |  | 119,781 |  |  |  | 111,472 |  |

[0001564590-18-020191:8k_2_02:100]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Cash flow provided by operations | $ | 20,773 |  |  | $ | 15,322 |  |  | $ | 19,043 |  |  | $ | 59,283 |  |
| Less: Capital expenditures |  | (18,412 | ) |  | $ | (2,593 | ) |  |  | (40,411 | ) |  |  | (10,425 | ) |
| Total free cash flow | $ | 2,361 |  |  | $ | 12,729 |  |  | $ | (21,368 | ) |  | $ | 48,858 |  |
