# EXTR MD&A — 0001564590-18-022453


## mdna

[0001564590-18-022453:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-18-022453:mdna:2]
Business Overview

[0001564590-18-022453:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Item 8 of Part II of this Report.

[0001564590-18-022453:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles, or U.S. GAAP.  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-18-022453:mdna:5]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leading provider of network infrastructure equipment and offers related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996, and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. Substantially all of our revenue is derived from the sale of our networking equipment and related maintenance contracts.

[0001564590-18-022453:mdna:6]
Extreme is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from the data center to the access point, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. We strive to help our customers and partners Connect Beyond the Network by building world-class software and network infrastructure solutions that solve the wide range of problems faced by IT departments.

[0001564590-18-022453:mdna:7]
Enterprise network administrators from the data center to the access layer need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security.  Accelerators such as Internet of Things (“IoT”), artificial intelligence (“AI”), bring your own device (“BYOD”), machine learning, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-18-022453:mdna:8]
A trend effecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud and third-party, public cloud services with orchestration between the two platforms. We introduced our Cloud offering in 2016 and announced our enhanced cloud offering in 2017.  ExtremeCloud is the only offering in the market that seamlessly integrates the cloud with on-premise infrastructures.  (See Part 1, Item 1. Business, for additional discussion of our business)

[0001564590-18-022453:mdna:9]
Acquisitions

[0001564590-18-022453:mdna:10]
WLAN Business

[0001564590-18-022453:mdna:11]
We completed the acquisition of Zebra’s WLAN Business on October 28, 2016.  Under the terms of the purchase agreement, we acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for net cash consideration of $49.5 million.

[0001564590-18-022453:mdna:12]
The acquisition was accounted for using the acquisition method of accounting.  The purchase price allocation as of the acquisition date is set forth in Note 4. Business Combinations in our Notes to Consolidated Financial Statements and reflects fair values. The fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of June 30, 2018.

[0001564590-18-022453:mdna:13]
During the fiscal year ended June 30, 2017, we recognized acquisition and integration costs of $2.1 million and $6.6 million, respectively, which are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying consolidated statements of operations.

[0001564590-18-022453:mdna:14]
Campus Fabric Business

[0001564590-18-022453:mdna:15]
We completed the acquisition of Avaya Inc.’s (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) on July 14, 2017 (“Campus Fabric Business Closing Date”) pursuant to the Campus Fabric Business Purchase Agreement dated March 7, 2017 between Avaya and Extreme.  We acquired customers, employees, technology and other assets, as well as assumed contracts and other liabilities of the Campus Fabric Business, for purchase consideration of $79.4 million, including all adjustments.  See Note 4. Business Combinations, for additional information.

[0001564590-18-022453:mdna:16]
The business combination was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Campus Fabric Business are recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Campus Fabric Business are included in our operations beginning with the Campus Fabric Business Closing Date.

[0001564590-18-022453:mdna:17]
During the year ended June 30, 2018, we recognized acquisition and integration costs of $12.4 million and $6.3 million, respectively, related to the Campus Fabric Business which are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying consolidated statements of operations.

[0001564590-18-022453:mdna:18]
Data Center Business

[0001564590-18-022453:mdna:19]
We completed our acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc. (“Brocade”) on October 27, 2017 (“Data Center Business Closing Date”).  Upon the terms and subject to the conditions of the Data Center Business Asset Purchase Agreement (“Data Center Business APA”), we acquired customers, employees, technology and other assets of the Data Center Business, as well as assumed certain contracts and other liabilities of the Data Center Business, for an upfront cash closing payment equal to $23.0 million, plus deferred payments of $20.0 million to be paid $1.0 million per quarter for 20 full quarters following the Data Center Business Closing Date, plus quarterly earn out payments equal to 50% of profits of the Data Center Business for the five-year period commencing at the end of our first full fiscal quarter following the Data Center Business Closing Date.  See Note 4. Business Combinations, for additional information.

[0001564590-18-022453:mdna:20]
The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Data Center Business are recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Data Center Business are included in our operations beginning with the Data Center Business Closing Date.

[0001564590-18-022453:mdna:21]
During the year ended June 30, 2018, we recognized acquisition and integration costs of $36.0 million and $4.2 million, respectively, including a $25.0 million consent fee paid to Broadcom Corporation (“Broadcom”), to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade. Acquisitions costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying consolidated statements of operations.

[0001564590-18-022453:mdna:22]
Results of Operations

[0001564590-18-022453:mdna:23]
Following is a summary of our results of operations during fiscal 2018:

[0001564590-18-022453:mdna:24]
|  | • | Net revenue of $983.1 million, increased 61.9% from fiscal 2017 net revenue of $607.1 million. |

[0001564590-18-022453:mdna:25]
|  | • | Product revenue of $764.5 million, increased 66.0% from fiscal 2017 product revenue of $460.4 million. |

[0001564590-18-022453:mdna:26]
|  | • | Service revenue of $218.7 million, increased 49.1% from fiscal 2017 service revenue of $146.7 million. |

[0001564590-18-022453:mdna:27]
|  | • | Total gross margin of 54.4% of net revenue in fiscal 2018, compared to 54.5% in fiscal 2017. |

[0001564590-18-022453:mdna:28]
|  | • | Restructuring charge of $8.1 million mainly related to employee severance and benefits expenses. |

[0001564590-18-022453:mdna:29]
|  | • | Operating loss of $38.2 million, compared to operating income of $6.0 million in fiscal 2017. |

[0001564590-18-022453:mdna:30]
|  | • | Net loss was $46.8 million in fiscal 2018, compared to a net loss of $1.7 million in fiscal 2017. |

[0001564590-18-022453:mdna:31]
|  | • | Cash flow provided by operating activities of $19.0 million, compared to cash flow provided by operating activities of $59.3 million in fiscal 2017, a decrease of $40.2 million. Cash and cash equivalents were $121.1 million as of June 30, 2018, a decrease of $9.3 million compared to the end of fiscal 2017. |

[0001564590-18-022453:mdna:32]
Net Revenues

[0001564590-18-022453:mdna:33]
The following table presents net product and service revenue for the fiscal years 2018, 2017 and 2016 (dollars in thousands):

[0001564590-18-022453:mdna:34]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 764,455 |  |  | $ | 460,425 |  |  | $ | 304,030 |  |  |  | 66.0 | % |  | $ | 460,425 |  |  | $ | 386,909 |  |  | $ | 73,516 |  |  |  | 19.0 | % |
| Percentage of net revenue |  |  | 77.8 | % |  |  | 75.8 | % |  |  |  |  |  |  |  |  |  |  | 75.8 | % |  |  | 74.4 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 218,687 |  |  |  | 146,659 |  |  |  | 72,028 |  |  |  | 49.1 | % |  |  | 146,659 |  |  | $ | 132,925 |  |  |  | 13,734 |  |  |  | 10.3 | % |
| Percentage of net revenue |  |  | 22.2 | % |  |  | 24.2 | % |  |  |  |  |  |  |  |  |  |  | 24.2 | % |  |  | 25.6 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 983,142 |  |  | $ | 607,084 |  |  | $ | 376,058 |  |  |  | 61.9 | % |  | $ | 607,084 |  |  | $ | 519,834 |  |  | $ | 87,250 |  |  |  | 16.8 | % |

[0001564590-18-022453:mdna:35]
Product revenue increased $304.0 million or 66.0% for the year ended June 30, 2018, compared to the corresponding period of fiscal 2017. The increase in product revenues was attributable to growth related to the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses and to a lesser extent, organic growth of legacy revenues.

[0001564590-18-022453:mdna:36]
Product revenue increased $73.5 million or 19% for the year ended June 30, 2017, compared to the corresponding period of fiscal 2016. The increase in product revenue was primarily a result of the acquisition of the WLAN Business during fiscal 2017 and to lower discounting from list price.

[0001564590-18-022453:mdna:37]
Service revenue increased $72.0 million or 49.1% for the year ended June 30, 2018, compared to the corresponding period of fiscal 2017. The increase in service revenue was due to the increased number of service contracts acquired as a result of the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses.

[0001564590-18-022453:mdna:38]
Service revenue increased $13.7 million or 10.3% for the year ended June 30, 2017 compared to the corresponding period of fiscal 2016. The increase in service revenue was primarily a result of the acquisition of the WLAN Business during fiscal 2017 and the increased number of service contracts acquired.

[0001564590-18-022453:mdna:39]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenue geographically for the fiscal years 2018, 2017 and 2016 (dollars in thousands):

[0001564590-18-022453:mdna:40]
|  |  | Year Ended |  |  | Year Ended |  |
| Net Revenues |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 536,305 |  |  | $ | 332,863 |  |  | $ | 203,442 |  |  |  | 61.1 | % |  | $ | 332,863 |  |  | $ | 277,753 |  |  | $ | 55,110 |  |  |  | 19.8 | % |
| Percentage of net revenue |  |  | 54.6 | % |  |  | 54.8 | % |  |  |  |  |  |  |  |  |  |  | 54.8 | % |  |  | 53.4 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 354,746 |  |  |  | 220,072 |  |  |  | 134,674 |  |  |  | 61.2 | % |  |  | 220,072 |  |  |  | 192,917 |  |  |  | 27,155 |  |  |  | 14.1 | % |
| Percentage of net revenue |  |  | 36.1 | % |  |  | 36.3 | % |  |  |  |  |  |  |  |  |  |  | 36.3 | % |  |  | 37.1 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 92,091 |  |  |  | 54,149 |  |  |  | 37,942 |  |  |  | 70.1 | % |  |  | 54,149 |  |  |  | 49,164 |  |  |  | 4,985 |  |  |  | 10.1 | % |
| Percentage of net revenue |  |  | 9.4 | % |  |  | 8.9 | % |  |  |  |  |  |  |  |  |  |  | 8.9 | % |  |  | 9.5 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 983,142 |  |  | $ | 607,084 |  |  | $ | 376,058 |  |  |  | 61.9 | % |  | $ | 607,084 |  |  | $ | 519,834 |  |  | $ | 87,250 |  |  |  | 16.8 | % |

[0001564590-18-022453:mdna:41]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEMs and direct sales.  Revenue through our distributor channel was 69% of total product revenue in fiscal 2018, 66% of total product revenue in fiscal 2017 and 64% in fiscal 2016.

[0001564590-18-022453:mdna:42]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001564590-18-022453:mdna:43]
Cost of Revenues and Gross Profit

[0001564590-18-022453:mdna:44]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenues for the fiscal years 2018, 2017 and 2016 (dollars in thousands):

[0001564590-18-022453:mdna:45]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 407,393 |  |  | $ | 240,204 |  |  | $ | 167,189 |  |  |  | 69.6 | % |  | $ | 240,204 |  |  | $ | 181,340 |  |  | $ | 58,864 |  |  |  | 32.5 | % |
| Percentage of product revenue |  |  | 53.3 | % |  |  | 52.2 | % |  |  |  |  |  |  |  |  |  |  | 52.2 | % |  |  | 46.9 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 127,124 |  |  |  | 90,753 |  |  |  | 36,371 |  |  |  | 40.1 | % |  |  | 90,753 |  |  |  | 84,063 |  |  |  | 6,690 |  |  |  | 8.0 | % |
| Percentage of service revenue |  |  | 58.1 | % |  |  | 61.9 | % |  |  |  |  |  |  |  |  |  |  | 61.9 | % |  |  | 63.2 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 534,517 |  |  | $ | 330,957 |  |  | $ | 203,560 |  |  |  | 61.5 | % |  | $ | 330,957 |  |  | $ | 265,403 |  |  | $ | 65,554 |  |  |  | 24.7 | % |
| Percentage of net revenue |  |  | 54.4 | % |  |  | 54.5 | % |  |  |  |  |  |  |  |  |  |  | 54.5 | % |  |  | 51.1 | % |  |  |  |  |  |  |  |  |

[0001564590-18-022453:mdna:46]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing engineering and document control at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001564590-18-022453:mdna:47]
Product gross profit increased to $407.4 million for the year ended June 30, 2018, from $240.2 million in the corresponding period of fiscal 2017, primarily due to higher revenues attributed to the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses and lower production costs due to cost reduction efforts.  The increases in product gross profit were partially offset by increases in amortization of developed technology intangibles of $9.9 million, warranty charges of $7.2 million, royalty charges of $2.2 million and acquisition and integration related costs of $7.7 million including excess inventory charges related to the discontinuance of certain product lines due to the acquisitions of the Campus Fabric and the Data Center Businesses in excess of the same charges incurred related to the acquisition of the WLAN Business in the corresponding period in fiscal 2017.

[0001564590-18-022453:mdna:48]
Product gross profit increased to $240.2 million for the year ended June 30, 2017, from $181.3 million in the corresponding period of fiscal 2016.  Product gross profit for the year ended June 30, 2017, was favorably impacted by an increase in product revenue of $73.5 million due primarily to the acquisition of the WLAN Business, lower amortization of developed technology intangibles of $8.3 million and more favorable manufacturing costs due to cost reduction efforts and lower warranty charges of $2.2 million.  The increases in product gross profit were partially offset by integration costs of $5.0 million primarily related to excess inventory charges related to the discontinuance of certain product lines due to the WLAN Business acquisition and increased royalty charges of $2.6 million.

[0001564590-18-022453:mdna:49]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts.

[0001564590-18-022453:mdna:50]
Service gross profit increased to $127.1 million for the year-ended June 30, 2018, from $90.8 million in the corresponding period of fiscal 2017, primarily due to the acquisitions of the WLAN, Campus Fabric and Data Center Businesses as a result of a higher number of maintenance contracts.

[0001564590-18-022453:mdna:51]
Service gross profit increased to $90.8 million for the year ended June 30, 2017, from $84.1 million in the corresponding period of fiscal 2016, primarily due to an increase in service revenue of $6.7 million related to the acquisition of the WLAN Business and the increased number of service contracts acquired.

[0001564590-18-022453:mdna:52]
Operating Expenses

[0001564590-18-022453:mdna:53]
The following table presents operating expenses and operating income (dollars in thousands):

[0001564590-18-022453:mdna:54]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |  | June 30, 2017 |  |  | June 30, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 183,877 |  |  | $ | 93,724 |  |  | $ | 90,153 |  |  |  | 96.2 | % |  | $ | 93,724 |  |  | $ | 78,721 |  |  | $ | 15,003 |  |  |  | 19.1 | % |
| Sales and marketing |  |  | 267,107 |  |  |  | 162,626 |  |  |  | 104,481 |  |  |  | 64.2 | % |  |  | 162,626 |  |  |  | 149,900 |  |  |  | 12,726 |  |  |  | 8.5 | % |
| General and administrative |  |  | 50,988 |  |  |  | 37,864 |  |  |  | 13,124 |  |  |  | 34.7 | % |  |  | 37,864 |  |  |  | 37,675 |  |  |  | 189 |  |  |  | 0.5 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 53,900 |  |  |  | 13,105 |  |  |  | 40,795 |  |  |  | 311.3 | % |  |  | 13,105 |  |  |  | 1,145 |  |  |  | 11,960 |  |  |  | 1,044.5 | % |
| Restructuring and related charges, net of reversals |  |  | 8,140 |  |  |  | 8,896 |  |  |  | (756 | ) |  |  | (8.5 | )% |  |  | 8,896 |  |  |  | 10,990 |  |  |  | (2,094 | ) |  |  | (19.1 | )% |
| Amortization of intangibles |  |  | 8,715 |  |  |  | 8,702 |  |  |  | 13 |  |  |  | 0.1 | % |  |  | 8,702 |  |  |  | 17,001 |  |  |  | (8,299 | ) |  |  | (48.8 | )% |
| Total operating expenses |  | $ | 572,727 |  |  | $ | 324,917 |  |  | $ | 247,810 |  |  |  | 76.3 | % |  | $ | 324,917 |  |  | $ | 295,432 |  |  | $ | 29,485 |  |  |  | 10.0 | % |

[0001564590-18-022453:mdna:55]
The following table highlights our operating expenses and operating loss as a percentage of net revenues:

[0001564590-18-022453:mdna:56]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Research and development |  |  | 18.7 | % |  |  | 15.4 | % |  |  | 15.1 | % |
| Sales and marketing |  |  | 27.2 | % |  |  | 26.8 | % |  |  | 28.8 | % |
| General and administrative |  |  | 5.2 | % |  |  | 6.2 | % |  |  | 7.2 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 5.5 | % |  |  | 2.2 | % |  |  | 0.2 | % |
| Restructuring charge, net of reversals |  |  | 0.8 | % |  |  | 1.5 | % |  |  | 2.1 | % |
| Amortization of intangibles |  |  | 0.9 | % |  |  | 1.4 | % |  |  | 3.3 | % |
| Total operating expenses |  |  | 58.3 | % |  |  | 53.5 | % |  |  | 56.8 | % |
| Operating income (loss) |  |  | (3.9 | )% |  |  | 1.0 | % |  |  | (5.8 | )% |

[0001564590-18-022453:mdna:57]
Research and Development Expenses

[0001564590-18-022453:mdna:58]
Research and development expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-18-022453:mdna:59]
Research and development expenses increased by $90.2 million or 96.2% for fiscal 2018 as compared to fiscal 2017. The increase in research and development expenses during fiscal 2018 was due to higher personnel costs of $67.0 million due to increased headcount related to the acquisitions of the Campus Fabric and Data Center Businesses, $12.5 million in increased facility and information technology costs, $7.4 million in increased supplies and equipment costs and $3.2 million in increased travel and other costs.

[0001564590-18-022453:mdna:60]
Research and development expenses increased by $15.0 million or 19.1% for fiscal 2017 as compared to fiscal 2016. The increase in spending was primarily a result of the acquisition of the WLAN Business during fiscal 2017, and consisted of $11.7 million of personnel costs, which included compensation, benefits and non-cash stock based compensation, $1.3 million of technology and facility costs, $1.2 million of consulting and contract projects and $0.8 million of supplies and equipment costs.

[0001564590-18-022453:mdna:61]
Sales and Marketing Expenses

[0001564590-18-022453:mdna:62]
Sales and marketing expenses consist of personnel costs (which consists of compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001564590-18-022453:mdna:63]
Sales and marketing expenses increased by $104.5 million or 64.2% for the year ended June 30, 2018, as compared to the corresponding period of fiscal 2017.  The increase in sales and marketing expenses during fiscal 2018 was primarily a result of the acquisitions of the Campus Fabric and Data Center Businesses.  The increase consisted of higher personnel costs of $74.7 million, $10.8 million in additional professional fees, $7.2 million in increased facility and information technology costs, $6.4 million in increased travel, meeting and conference costs and $5.4 million in supplies and equipment costs.

[0001564590-18-022453:mdna:64]
Sales and marketing expenses increased by $12.7 million or 8.5% for the year ended June 30, 2017 as compared to the corresponding period of fiscal 2016.  The increase in sales and marketing expenses during fiscal 2017 was primarily a result of the acquisition of the WLAN Business during fiscal 2017, and consists of higher personnel costs including benefits and non-cash stock compensation of $9.8 million, $1.8 million in travel costs and $1.1 million in additional professional fees.

[0001564590-18-022453:mdna:65]
General and Administrative Expenses

[0001564590-18-022453:mdna:66]
General and administrative expense consists primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001564590-18-022453:mdna:67]
General and administrative expenses increased by $13.1 million or 34.7% for the year ended June 30, 2018, as compared to the corresponding period of fiscal 2017.  The increase in general and administrative expenses during fiscal 2018 was primarily due to $8.4 million in higher personnel costs, $3.2 million in higher professional fees, $1.4 million in higher bad debts provision and $0.8 million in higher travel and other costs, partially offset by $0.7 million in reduced facility and information technology costs.

[0001564590-18-022453:mdna:68]
General and administrative expenses increased by $0.2 million or 0.5% for the year ended June 30, 2017 as compared to the corresponding period of fiscal 2016.  The increase in general and administrative expenses during fiscal 2017 was primarily due to increases of $1.1 million in professional fees, $0.6 million in recruiting fees, and $0.2 million of taxes and franchise fees. The increase was partially offset by $0.9 million in lower personnel costs related to our reduced headcount and $0.6 million in our provision for bad debts.

[0001564590-18-022453:mdna:69]
Acquisition and Integration Costs, Net of Bargain Purchase Gain

[0001564590-18-022453:mdna:70]
As a result of our acquisitions of the Campus Fabric, Data Center and Capital Financing Businesses in fiscal 2018, the WLAN Business in fiscal 2017 and Enterasys in fiscal 2014, we incurred $53.9 million, $13.1 million and $1.1 million of acquisition and integration costs, net of bargain purchase gain in fiscal 2018, 2017 and 2016, respectively.

[0001564590-18-022453:mdna:71]
For fiscal 2018, we incurred $12.4 million of acquisition and $6.3 million of integration costs related to the acquisition of the Campus Fabric Business and $36.0 million of acquisition and $4.2 million of integration costs related to the acquisition of the Data Center Business. The Data Center Business acquisition costs includes a $25.0 million consent fee paid to Broadcom, to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade. We also recorded a gain on bargain purchase of $5.0 million related to the acquisition of the Capital Financing Business.

[0001564590-18-022453:mdna:72]
For fiscal 2017, we incurred $2.1 million of acquisition and $6.6 million of integration costs related to the WLAN Business acquisition.  We also incurred acquisition costs of $2.2 million related to our anticipated acquisition of the Campus Fabric Business and $2.2 million for the anticipated acquisition of the Data Center Business.

[0001564590-18-022453:mdna:73]
For fiscal 2016, the entire $1.1 million expense was related to integration costs of the Enterasys acquisition.

[0001564590-18-022453:mdna:74]
Restructuring and Related Charges, Net of Reversals

[0001564590-18-022453:mdna:75]
As of June 30, 2018, restructuring liabilities were $6.5 million and consisted primarily of obligations for estimated future obligations for non-cancelable lease payments for excess facilities, and for severance payments and benefits. The restructuring liability is recorded in “Other accrued liabilities” and “Other long-term liabilities” on the consolidated balance sheets. During fiscal years 2018, 2017 and 2016, we recorded restructuring charges and related charges, net of reversals, of $8.1 million, $8.9 million and $11.0 million, respectively.

[0001564590-18-022453:mdna:76]
Fiscal year 2018

[0001564590-18-022453:mdna:77]
During fiscal 2018, we announced and began executing a reduction-in-force in our third and fourth fiscal quarters as a result of the acquisitions of the Campus Fabric and the Data Center Businesses. We recorded restructuring charges of $7.9 million related to employee severance and benefits expenses during fiscal 2018. We also incurred charges of $0.2 million for changes to our estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of our excess facilities.

[0001564590-18-022453:mdna:78]
Fiscal year 2017

[0001564590-18-022453:mdna:79]
Pursuant to the WLAN Business acquisition from Zebra, we assumed a facility lease located at 6480 Via del Oro in San Jose, California (“Via del Oro”) and transferred our headquarters from Rio Robles Drive in San Jose, California (“Rio Robles”) to Via del Oro.  We consolidated our existing workforce from our previous headquarters with employees assumed from Zebra to the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to our move from the Rio Robles facility and abandonment of all leasehold improvements, we accelerated the amortization of the remaining leasehold improvements for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  We recorded accelerated amortization expense for the year ended June 30, 2017 of $2.6 million which is reflected in “Restructuring and related charges, net of reversals” in the consolidated statements of operations.

[0001564590-18-022453:mdna:80]
We entered into a sublease agreement related to our Rio Robles facility during the third quarter of fiscal 2017 for the remaining duration of the lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease. The net adjustments, including modifications to our future obligations for non-cancellable lease payments and related future subleasing income resulted in additional charges of $2.0 million during fiscal 2017. The excess facilities payments will continue through fiscal year 2023.

[0001564590-18-022453:mdna:81]
In anticipation of the acquisitions of Campus Fabric Business and Data Center Business in fiscal 2018, we reoccupied the majority of the previously exited space at our Salem, New Hampshire location during our fiscal fourth quarter to accommodate the growth in headcount and lab facility requirements. This action resulted in a reversal of prior restructuring expense accruals of $1.3 million.

[0001564590-18-022453:mdna:82]
We also implemented a reduction-in-force which affected 90 employees.  We recorded severance and benefits charges of $5.6 million during the year ended June 30, 2017.  Cash payments of $3.8 million were made by June 30, 2017 with the remainder paid by the end of the second quarter of fiscal 2018.

[0001564590-18-022453:mdna:83]
Fiscal year 2016

[0001564590-18-022453:mdna:84]
During fiscal 2016, we incurred $11.0 million of restructuring charges. Excess facilities charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and contract termination charges of $5.4 million, acceleration of depreciation of leasehold improvements of $4.5 million, professional fees of $1.0 million and other expenses of $0.1 million.

[0001564590-18-022453:mdna:85]
Significant restructuring charges incurred during 2016, by location, included $1.8 million of charges for excess facilities pertaining to the estimated future obligations for non-cancelable lease payments at Rio Robles.  This represented 39% of the San Jose leased space.  We amended our facility lease at our North Carolina location and exited excess space while recording $4.1 million of charges, which included $3.1 million in accelerated depreciation of leasehold improvements. This action represented 36% of the North Carolina location lease space. We recorded $4.4 million of charges for excess facilities at our Salem location, which included $1.3 million in accelerated depreciation of leasehold improvements.  This action represented 27% of the Salem lease space.

[0001564590-18-022453:mdna:86]
Amortization of Intangibles

[0001564590-18-022453:mdna:87]
During fiscal 2018, 2017 and 2016, we recorded $8.7 million, $8.7 million and $17.0 million, respectively, of amortization expenses in operating expenses primarily for certain intangibles related to the acquisitions of the Campus Fabric, Data Center and WLAN Businesses and Enterasys.  The lower amortization expense since fiscal 2017 was due to the Enterasys intangible assets becoming fully amortized during fiscal 2017.

[0001564590-18-022453:mdna:88]
Interest Income

[0001564590-18-022453:mdna:89]
Interest income was $2.8 million, $0.7 million and $0.1 million in fiscal years 2018, 2017 and 2016, respectively, representing an increase of $1.9 million in fiscal 2018 from fiscal 2017 and an increase of $0.6 million in fiscal 2017 from fiscal 2016. The increase in fiscal 2018 and 2017 was due to accretion of interest on a long-term note receivable acquired from the WLAN Business as well as increased interest income on cash balances due to rising market interest rates.

[0001564590-18-022453:mdna:90]
Interest Expense

[0001564590-18-022453:mdna:91]
We had $13.9 million, $4.1 million and $3.1 million of interest expense for fiscal 2018, 2017 and 2016, respectively.  The increase in interest expense in fiscal 2018 was primarily in connection with the increased balance of our Credit Facility due to the acquisitions of the WLAN, Campus Fabric and Data Center Businesses and accretion of interest expense of $3.1 million associated with the contingent consideration obligations. In addition, we recorded a loss from debt extinguishment of $1.2 million in fiscal 2018 in connection with our Credit Agreement entered on May 1, 2018.  The increase in interest expense for fiscal 2017 was related to our increased borrowings to finance the WLAN Business acquisition in October 2016.

[0001564590-18-022453:mdna:92]
Other Income (Expense), net

[0001564590-18-022453:mdna:93]
We incurred other income of $2.6 million, other expense of less than $0.1 million and other income of $1.0 million in fiscal 2018, 2017 and 2016, respectively.  The income for fiscal 2018 was primarily driven by a gain of $4.0 million due to the sale of equity investments, partially offset by foreign exchange losses.  The expense in fiscal 2017 and income in fiscal 2016 were primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-18-022453:mdna:94]
Provision for Income Taxes

[0001564590-18-022453:mdna:95]
We are subject to income taxes in the United States and numerous foreign jurisdictions.  Our effective tax rate differs from the newly enacted U.S. federal statutory rate of 21% primarily due to the impact of state taxes, foreign operations, the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions and for our fiscal year ended June 30, 2018, the phase in of the new tax rate making our U.S. rate for this particular tax year 28%.  For the fiscal years ended June 30, 2018, 2017 and 2016, we recorded income tax provisions of $0.1 million, $4.3 million and $4.3 million, respectively.

[0001564590-18-022453:mdna:96]
For fiscal 2018, our tax provision primarily related to taxes on our foreign operations offset by two significant tax benefits resulting from Tax Reform and restructuring of our foreign operations. Income tax provision of $6.7 million consisted of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill.  Partially offsetting the tax provision is a tax benefit of $3.1 million resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to our deferred tax liability related to amortizable goodwill as required by the recently enacted U.S. tax legislation as well as a tax benefit resulting from the impairment of a lease acquired from Avaya in Canada. Additionally, we recorded a tax benefit resulting from the restructuring of our foreign operations of $3.4 million.

[0001564590-18-022453:mdna:97]
For fiscal 2017 and 2016, the majority of our tax provision related to taxes on our foreign operations as well as state taxes due to the full valuation allowance on our U.S. and certain foreign deferred tax assets.

[0001564590-18-022453:mdna:98]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 15. Income Taxes, for additional information.

[0001564590-18-022453:mdna:99]
Critical Accounting Policies and Estimates

[0001564590-18-022453:mdna:100]
Our significant accounting policies are more fully described in Note 3 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001564590-18-022453:mdna:101]
Revenue Recognition

[0001564590-18-022453:mdna:102]
We account for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which we adopted on July 1, 2017, using the full retrospective method.  We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for our products. We sell our products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-18-022453:mdna:103]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, we consider the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0001564590-18-022453:mdna:104]
For all of our sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when our performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as our performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to our value-added resellers, non-stocking distributors and end-user customers, we generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits.  Sales incentives and other programs that we may make available to these customers are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the expected value method.

[0001564590-18-022453:mdna:105]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of our products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are estimated using the expected value method based on historical return rates.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices our customer or soon thereafter, the distributor submits a rebate claim to us to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After we verify that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, we consider these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends.

[0001564590-18-022453:mdna:106]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which we separately sell these products.  For items that are not sold separately, we estimate the stand-alone selling prices using the best estimated selling price approach.

[0001564590-18-022453:mdna:107]
Our performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of our product sales revenues as reflected on the consolidated statements of operations for the years ended June 30, 2018, 2017 and 2016 are recognized at a point in time. Substantially all of our service revenue is recognized over time.  For revenue recognized over time, we use an input measure, days elapsed, to measure satisfaction of the performance obligation.

[0001564590-18-022453:mdna:108]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under our renewable support arrangements are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  We sometimes receive payments from our customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-18-022453:mdna:109]
Contract Costs.  We recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore we capitalized them as contract costs.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations.

[0001564590-18-022453:mdna:110]
Business Combinations

[0001564590-18-022453:mdna:111]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized in the statements of operations. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-18-022453:mdna:112]
Inventory Valuation and Purchase Commitments

[0001564590-18-022453:mdna:113]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0001564590-18-022453:mdna:114]
New Accounting Pronouncements

[0001564590-18-022453:mdna:115]
See Note 2. Summary of Significant Accounting Policies, in the accompanying consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-18-022453:mdna:116]
Liquidity and Capital Resources

[0001564590-18-022453:mdna:117]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001564590-18-022453:mdna:118]
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Cash and cash equivalents |  | $ | 121,139 |  |  | $ | 130,450 |  |
| Marketable securities |  |  | 1,459 |  |  |  | — |  |
| Total cash and investments |  | $ | 122,598 |  |  | $ | 130,450 |  |
| Working capital |  | $ | 68,041 |  |  | $ | 85,637 |  |

[0001564590-18-022453:mdna:119]
As of June 30, 2018, our principal sources of liquidity consisted of cash, cash equivalents and investments of $122.6 million, accounts receivable, net of $212.4 million and availability of borrowings from the New Revolving Facility of $28.7 million.  We anticipate that our principal uses of cash for fiscal 2019 will be purchases of finished goods inventory from our contract manufacturers, payroll, repayments of debt and related interest, and other operating expenses related to the development, marketing of our products and purchases of property and equipment.  We believe that our cash, cash equivalents, investments and cash flows from operations along with the availability of additional borrowings from our Credit Agreement, will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-18-022453:mdna:120]
On May 1, 2018, the Company terminated the Amended and Restated Credit Agreement dated October 28, 2016, by and among the Company, as borrower, Silicon Valley Bank, as administrative agent, and the financial institutions that were a party thereto as lenders.

[0001564590-18-022453:mdna:121]
On May 1, 2018, the Company entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”), ii) a $190 million five-year term loan (the “New Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement in order to pay off the existing debt, as noted above and for general corporate purposes.

[0001564590-18-022453:mdna:122]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s consolidated leverage ratio. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting September 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The obligations under the Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-18-022453:mdna:123]
Financial covenants under the Credit Agreement require the Company to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets.  The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.  At June 30, 2018, we were in compliance with the covenants of the Credit Agreement.

[0001564590-18-022453:mdna:124]
Key Components of Cash Flows and Liquidity

[0001564590-18-022453:mdna:125]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001564590-18-022453:mdna:126]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | June 30, 2016 |  |
| Net cash provided by operating activities |  | $ | 19,043 |  |  | $ | 59,283 |  |  | $ | 30,366 |  |
| Net cash used in investing activities |  |  | (132,471 | ) |  |  | (71,752 | ) |  |  | (5,327 | ) |
| Net cash provided by (used in) financing activities |  |  | 104,746 |  |  |  | 48,708 |  |  |  | (6,738 | ) |
| Foreign currency effect on cash |  |  | (629 | ) |  |  | 89 |  |  |  | (404 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (9,311 | ) |  | $ | 36,328 |  |  | $ | 17,897 |  |

[0001564590-18-022453:mdna:127]
Cash and cash equivalents were $121.1 million at June 30, 2018, representing a decrease of $9.3 million from $130.5 million at June 30, 2017.  Cash and cash equivalents decreased primarily due to cash used in investing activities of $132.5 million mainly for the acquisitions of the Campus Fabric and Data Center Businesses and capital expenditures, partially offset by cash provided by financing activities of $104.7 million as a result of additional borrowings for the acquisitions and cash provided by operations of $19.0 million.

[0001564590-18-022453:mdna:128]
Cash and cash equivalents were $130.5 million at June 30, 2017, representing an increase of $36.4 million from $94.1 million at June 30, 2016.  Cash and cash equivalents increased primarily due to cash provided by operations of $59.3 million, and cash provided by financing activities of $48.7 million, offset by cash used in investing activities of $71.8 million.

[0001564590-18-022453:mdna:129]
Net Cash Provided by Operating Activities

[0001564590-18-022453:mdna:130]
Cash provided by operating activities during fiscal 2018 was $19.0 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2018 were net loss of $46.8 million, increases in accounts receivable, prepaid expenses and other assets and non-cash expenses such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes, gain on bargain purchase and gain on sale of non-marketable equity investment.  These amounts were partially offset by a decrease in inventories, increases in accounts payable, accrued compensation and benefits, deferred revenue, other current and long-term liabilities.

[0001564590-18-022453:mdna:131]
Cash provided by operating activities during fiscal 2017 was $59.3 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2017 were decreases in inventory and prepaid expenses, and increases to accrued compensation and benefits, deferred revenues and other liabilities in addition to non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.  These amounts were partially offset by an increase in accounts receivables and net loss of $1.7 million.

[0001564590-18-022453:mdna:132]
Cash provided by operating activities during fiscal 2016 was $30.4 million.  Factors contributing to cash provided by operating activities for the year ended June 30, 2016 were decreases in accounts receivables and inventory in addition to non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.  These amounts were partially offset by net loss of $36.4 million and decreases in deferred revenues and accounts payable.

[0001564590-18-022453:mdna:133]
Net Cash Used in Investing Activities

[0001564590-18-022453:mdna:134]
Cash used in investing activities during fiscal 2018 was $132.5 million mainly due to our acquisitions of the Campus Fabric and Data Center Businesses of $97.6 million and capital expenditures of $40.4 million.

[0001564590-18-022453:mdna:135]
Cash used in investing activities during fiscal 2017 was $71.8 million mainly due to our acquisition of the WLAN Business of $51.1 million, deposits for future acquisitions of $10.2 million and capital expenditures of $10.4 million.

[0001564590-18-022453:mdna:136]
Cash used in investing activities during fiscal 2016 was $5.3 million mainly due to capital expenditures.

[0001564590-18-022453:mdna:137]
Net cash Provided by (Used in) Financing Activities

[0001564590-18-022453:mdna:138]
Cash provided by financing activities during fiscal 2018 was $104.7 million due primarily to additional borrowings of $100.0 million to fund our acquisitions of the Campus Fabric and Data Center Businesses, new borrowings of $200 million under the Credit Agreement to pay off the existing debt under the prior Credit Facility, $3.3 million of proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, partially offset by repayments of debt totaling $193.7 million, $3.2 million of loan fees incurred in connection with the Second Amendment of our Credit Facility and the Credit Agreement and $1.7 million of contingent consideration and deferred payments on acquisitions.

[0001564590-18-022453:mdna:139]
Cash provided by financing activities during fiscal 2017 was $48.7 million due primarily to $48.3 million in borrowings of debt pursuant to our WLAN Business acquisition, $11.8 million in proceeds from the sale of our common stock, primarily through the exercise of stock options and our ESPP, partially offset by repayments of debt of $10.0 million.

[0001564590-18-022453:mdna:140]
Cash flow used in financing activities during fiscal 2016 was $6.7 million mainly due to $26.4 million in repayments of debt, offset by borrowings of $15.0 million on the Revolving Facility for working capital requirements and proceeds from the sale of common stock of $4.6 million primarily through our ESPP.

[0001564590-18-022453:mdna:141]
Contractual Obligations

[0001564590-18-022453:mdna:142]
The following summarizes our contractual obligations at June 30, 2018, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-18-022453:mdna:143]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 200,000 |  |  | $ | 9,500 |  |  | $ | 23,750 |  |  | $ | 166,750 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 32,974 |  |  |  | 8,378 |  |  |  | 15,469 |  |  |  | 9,127 |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 144,014 |  |  |  | 144,014 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 57,717 |  |  |  | 13,243 |  |  |  | 27,987 |  |  |  | 16,487 |  |  |  | — |  |
| Deferred payments for an acquisition |  |  | 19,000 |  |  |  | 5,000 |  |  |  | 8,000 |  |  |  | 6,000 |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 12,749 |  |  |  | 7,851 |  |  |  | 4,218 |  |  |  | 680 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 112,863 |  |  |  | 27,517 |  |  |  | 35,574 |  |  |  | 30,789 |  |  |  | 18,983 |  |
| Other liabilities |  |  | 406 |  |  |  | 100 |  |  |  | 201 |  |  |  | 105 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 579,723 |  |  | $ | 215,603 |  |  | $ | 115,199 |  |  | $ | 229,938 |  |  | $ | 18,983 |  |

[0001564590-18-022453:mdna:144]
Debt obligations relate to amounts owed under our Credit Agreement.

[0001564590-18-022453:mdna:145]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast.

[0001564590-18-022453:mdna:146]
Contractual commitments represent the Data Center Business consideration contingency resolution and future services.

[0001564590-18-022453:mdna:147]
Deferred payments represent Data Center Business consideration obligation of $1.0 million per quarter.

[0001564590-18-022453:mdna:148]
Contingent consideration for the Capital Financing Business acquisition, at fair value.  Actual payments could be different.

[0001564590-18-022453:mdna:149]
Non-cancelable operating lease obligations represent base rents and operating expense obligations.

[0001564590-18-022453:mdna:150]
Other liabilities include our commitments towards debt related fees and specific arrangements other than inventory.

[0001564590-18-022453:mdna:151]
The amounts in the table above exclude immaterial income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of the settlement.

[0001564590-18-022453:mdna:152]
We did not have any material commitments for capital expenditures as of June 30, 2018.

[0001564590-18-022453:mdna:153]
Off-Balance Sheet Arrangements

[0001564590-18-022453:mdna:154]
We did not have any off-balance sheet arrangements as of June 30, 2018.
