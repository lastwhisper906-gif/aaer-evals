# EXTR note change history — 0001078271-12-000006 → 0001078271-12-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2012-05-04):
[0001078271-12-000025:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory on the Company’s behalf based upon a rolling production forecast provided by it. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of April 1, 2012, the Company had non-cancelable commitments to purchase approximately $40.2 million of such inventory.
  (was, 2012-02-07, similarity 0.9906):
[0001078271-12-000006:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory on the Company’s behalf based upon a rolling production forecast provided by it. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of January 1, 2012, the Company had non-cancelable commitments to purchase approximately $32.0 million of such inventory.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2012-05-04):
[0001078271-12-000025:note_history:2]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at April 1, 2012. The results of operations for the three and nine months ended April 1, 2012 are not necessarily indicative of the results that may be expected for fiscal 2012 or any future periods.
  (was, 2012-02-07, similarity 0.9432):
[0001078271-12-000006:note_history:2]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at January 1, 2012. The results of operations for the three and six months ended January 1, 2012 are not necessarily indicative of the results that may be expected for fiscal 2012 or any future periods.

- added (2012-05-04):
[0001078271-12-000025:note_history:3]
The Company made conforming changes to its previously reported Statement of Cash Flows for the nine months ended March 27, 2011, which resulted in an increase of $4.1 million to the previously reported cash flows provided by operating activities, an increase of $4.6 million to the previously reported cash flows used in investing activities, and an increase of $0.5 million to the previously reported cash flows provided by financing activities.  These revisions had no effect on previously reported Statements of Operations or Stockholders' Equity and were not material to the Company's financial statements taken as a whole.

- removed (2012-05-04):
[0001078271-12-000006:note_history:4]
The Company revised its previously reported Statement of Cash Flows for the six month period ended December 26, 2010  to reclassify accrued interest income and amortization related to its investments, resulting in an increase of $2.9 million in cash flows provided by operating activities and an increase of $2.9 million in cash flows used in investing activities. The Company also made other conforming changes to the Statement of Cash Flows for the six months ended December 26, 2010.  These revisions had no effect on previously reported Statements of Operations or Stockholders' Equity and were not material to the Company's financial statements taken as a whole.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2012-05-04):
[0001078271-12-000025:note_history:5]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| April 1, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 33,310 |  |  | $ | 33,310 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 82,952 |  |  | 83,134 |  |  | 262 |  |  | (80 | ) |
| U.S. government agency securities | 7,997 |  |  | 7,989 |  |  | 2 |  |  | (10 | ) |
| U.S. municipal bonds | 2,802 |  |  | 2,803 |  |  | 1 |  |  | — |  |
|  | $ | 127,061 |  |  | $ | 127,236 |  |  | $ | 265 |  |  | $ | (90 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 33,310 |  |  | $ | 33,310 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 22,261 |  |  | 22,349 |  |  | 88 |  |  | — |  |
| Marketable securities | 71,490 |  |  | 71,577 |  |  | 177 |  |  | (90 | ) |
|  | $ | 127,061 |  |  | $ | 127,236 |  |  | $ | 265 |  |  | $ | (90 | ) |

- changed (2012-05-04):
[0001078271-12-000025:note_history:6]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at April 1, 2012, by contractual maturity, were as follows (in thousands):
  (was, 2012-02-07, similarity 0.976):
[0001078271-12-000006:note_history:6]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at January 1, 2012, by contractual maturity, were as follows (in thousands):

- changed (2012-05-04):
[0001078271-12-000025:note_history:7]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value. The Company accumulates unrealized gains and losses on the Company’s available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders’ equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument’s amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument’s fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income. As of April 1, 2012 and July 3, 2011, the Company did not have any other-than-temporary impairment of its investment securities.
  (was, 2012-02-07, similarity 0.9961):
[0001078271-12-000006:note_history:7]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value. The Company accumulates unrealized gains and losses on the Company’s available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders’ equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments’ amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument’s amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument’s fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income. As of January 1, 2012 and July 3, 2011, the Company did not have other-than-temporary impairment on its investment securities.

- changed (2012-05-04):
[0001078271-12-000025:note_history:8]
|  | Less than 12 months |  | 12 months or more |  | Total |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| April 1, 2012: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. corporate debt securities | $ | 23,384 |  |  | $ | (80 | ) |  | $ | — |  |  | $ | — |  |  | $ | 23,384 |  |  | $ | (80 | ) |
| U.S. government agency securities | $ | 4,246 |  |  | $ | (10 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,246 |  |  | $ | (10 | ) |
|  | $ | 27,630 |  |  | $ | (90 | ) |  | $ | — |  |  | $ | — |  |  | $ | 27,630 |  |  | $ | (90 | ) |
  (was, 2012-02-07, similarity 0.683):
[0001078271-12-000006:note_history:8]
|  | Less than 12 months |  | 12 months or more |  | Total |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| January 1, 2012: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. corporate debt securities | $ | 39,391 |  |  | $ | (249 | ) |  | $ | 7,184 |  |  | $ | (6 | ) |  | $ | 46,575 |  |  | $ | (255 | ) |
| U.S. government agency securities | $ | 4,972 |  |  | $ | (13 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,972 |  |  | $ | (13 | ) |
|  | $ | 44,363 |  |  | $ | (262 | ) |  | $ | 7,184 |  |  | $ | (6 | ) |  | $ | 51,547 |  |  | $ | (268 | ) |

- added (2012-05-04):
[0001078271-12-000025:note_history:9]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. During the three and nine months ended April 1, 2012 and March 27, 2011, realized gains or losses recognized on the sale of investments were not significant. As of April 1, 2012, there were eighteen out of fifty-two investment securities that had unrealized losses. The unrealized gains / (losses) on the Company’s investments were caused by interest rate fluctuations. Substantially all of the Company’s available-for-sale investments are investment grade government and corporate debt securities that have maturities of less than 3 years.

- changed (2012-05-04):
[0001078271-12-000025:note_history:10]
| April 1, 2012: | Level 1 |  | Level 2 |  | Total |
|  |  |  | (In thousands) |  |  |
| Assets |  |  |  |  |  |
| Investments: |  |  |  |  |  |
| Municipal bonds | $ | — |  |  | $ | 2,803 |  |  | $ | 2,803 |  |
| Federal agency notes | — |  |  | 7,989 |  |  | 7,989 |  |
| Money market funds | 33,310 |  |  | — |  |  | 33,310 |  |
| Corporate notes/bonds | — |  |  | 83,134 |  |  | 83,134 |  |
| Total | 33,310 |  |  | 93,926 |  |  | 127,236 |  |
| Liabilities |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | (13 | ) |  | (13 | ) |
| Total | $ | — |  |  | $ | (13 | ) |  | $ | (13 | ) |
| July 3, 2011: | Level 1 |  | Level 2 |  | Total |
|  |  |  | (In thousands) |  |  |
| Assets |  |  |  |  |  |
| Investments: |  |  |  |  |  |
| Federal agency notes | $ | — |  |  | $ | 7,756 |  |  | $ | 7,756 |  |
| Money market funds | 30,405 |  |  | — |  |  | 30,405 |  |
| Corporate notes/bonds | — |  |  | 89,248 |  |  | 89,248 |  |
| Total | 30,405 |  |  | 97,004 |  |  | 127,409 |  |
| Liabilities |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 37 |  |  | 37 |  |
| Total | $ | — |  |  | $ | 37 |  |  | $ | 37 |  |
  (was, 2012-02-07, similarity 0.875):
[0001078271-12-000006:note_history:10]
| January 1, 2012: | Level 1 |  | Level 2 |  | Total |
|  |  |  | (In thousands) |  |  |
| Assets |  |  |  |  |  |
| Investments: |  |  |  |  |  |
| Federal agency notes | $ | — |  |  | $ | 7,476 |  |  | $ | 7,476 |  |
| Money market funds | 29,766 |  |  | — |  |  | 29,766 |  |
| Corporate notes/bonds | — |  |  | 89,545 |  |  | 89,545 |  |
| Total | 29,766 |  |  | 97,021 |  |  | 126,787 |  |
| Liabilities |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 42 |  |  | 42 |  |
| Total | $ | — |  |  | $ | 42 |  |  | $ | 42 |  |
| July 3, 2011: | Level 1 |  | Level 2 |  | Total |
|  |  |  | (In thousands) |  |  |
| Assets |  |  |  |  |  |
| Investments: |  |  |  |  |  |
| Federal agency notes | $ | — |  |  | $ | 7,756 |  |  | $ | 7,756 |  |
| Money market funds | 30,405 |  |  | — |  |  | 30,405 |  |
| Corporate notes/bonds | — |  |  | 89,248 |  |  | 89,248 |  |
| Total | 30,405 |  |  | 97,004 |  |  | 127,409 |  |
| Liabilities |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | 37 |  |  | 37 |  |
| Total | $ | — |  |  | $ | 37 |  |  | $ | 37 |  |

- changed (2012-05-04):
[0001078271-12-000025:note_history:11]
Level 2 investment valuations are based on inputs such as quoted market prices, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. As of April 1, 2012 and July 3, 2011, the Company had no assets or liabilities classified within Level 3. There were no transfers  of assets or liabilities between Level 1 and Level 2 during the three and nine months ended April 1, 2012 and March 27, 2011.
  (was, 2012-02-07, similarity 0.8411):
[0001078271-12-000006:note_history:11]
Level 2 investment valuations are based on inputs such as quoted market prices, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. As of January 1, 2012 and July 3, 2011, the Company had no assets or liabilities classified within Level 3.

- changed (2012-05-04):
[0001078271-12-000025:note_history:12]
Inventory is stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company reduces the carrying value of inventory based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross profit for any of the periods disclosed. Inventories at April 1, 2012 and July 3, 2011, respectively, were (in thousands):
  (was, 2012-02-07, similarity 0.9922):
[0001078271-12-000006:note_history:12]
Inventory is stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company reduces the carrying value of inventory based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross profit for any of the periods disclosed. Inventories at January 1, 2012 and July 3, 2011, respectively, were (in thousands):

- changed (2012-05-04):
[0001078271-12-000025:note_history:13]
|  | April 1, 2012 |  | July 3, 2011 |
| Inventory, gross | $ | 24,245 |  |  | $ | 26,487 |  |
| Less: Write down for excess and obsolete inventory | 976 |  |  | 4,904 |  |
| Inventory, net | $ | 23,269 |  |  | $ | 21,583 |  |
  (was, 2012-02-07, similarity 0.978):
[0001078271-12-000006:note_history:13]
|  | January 1, 2012 |  | July 3, 2011 |
| Inventory, gross | $ | 22,503 |  |  | $ | 26,487 |  |
| Less: Write down for excess and obsolete inventory | 1,111 |  |  | 4,904 |  |
| Inventory, net | $ | 21,392 |  |  | $ | 21,583 |  |

- changed (2012-05-04):
[0001078271-12-000025:note_history:14]
Long-lived assets include property and equipment, intangible assets, and service inventory which the Company holds to support customers who have purchased service contracts with a hardware replacement element.   Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of the long-lived assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. There was no impairment of long-lived assets during the three and nine months ended April 1, 2012 and March 27, 2011.
  (was, 2012-02-07, similarity 0.9661):
[0001078271-12-000006:note_history:14]
Long-lived assets include property and equipment, intangible assets, and service inventory which the Company holds to support customers who have purchased service contracts with a hardware replacement element.   Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of the long-lived assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. There was no impairment of long-lived assets during the three and six months ended January 1, 2012 and December 26, 2010.

- added (2012-05-04):
[0001078271-12-000025:note_history:15]
On September 23, 2010, the Company entered into an Option Agreement with Trumark Companies LLC (“Trumark”), under which the Company granted Trumark an option (the “Option”) to purchase half of its corporate headquarters campus in Santa Clara, California (First Property), at a price of $24.0 million. On January 25, 2012, Company entered into a new Option Agreement with Trumark, under which it granted Trumark an option to purchase the remaining portion of the Company's corporate campus (Second Property), at a price of $24.5 million.  Under the agreements, Trumark will have until December 18, 2012 and December 28, 2012 to exercise the options to purchase the First Property and the Second Property, respectively, and may extend the option if they make certain payments to the Company. As of April 1, 2012, the Company had received option payments totaling $2.0 million from Trumark, which were classified as a deferred gain and included in other current liabilities on the condensed consolidated balance sheet.

- added (2012-05-04):
[0001078271-12-000025:note_history:16]
In January 2012, the Company classified the First Property as “assets held for sale” on the condensed consolidated balance at a net book value of $17.1 million, which was the lesser of the fair value (less cost to sell) or carrying amount of the assets, and ceased recognizing depreciation expense on the assets. As of April 1, 2012, the Second Property, with a net book value of $16.1 million, remains classified as “assets held for use” due to certain unresolved contingencies that may delay the completion date of this transaction, including the Company's execution of an agreement with Trumark to lease back the Second Property.

- changed (2012-05-04):
[0001078271-12-000025:note_history:17]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| April 1, 2012: |  |  |  |  |  |  |  |
| Patents | 7.5 years |  | $ | 1,800 |  |  | $ | 598 |  |  | $ | 1,202 |  |
| License Agreements | 6.5 years |  | 8,926 |  |  | 5,908 |  |  | 3,018 |  |
| Other Intangibles | 0.5 years |  | 324 |  |  | 253 |  |  | 71 |  |
|  |  |  | $ | 11,050 |  |  | $ | 6,759 |  |  | $ | 4,291 |  |
  (was, 2012-02-07, similarity 0.984):
[0001078271-12-000006:note_history:17]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| January 1, 2012: |  |  |  |  |  |  |  |
| Patents | 7.6 years |  | $ | 1,800 |  |  | $ | 528 |  |  | $ | 1,272 |  |
| License Agreements | 6.8 years |  | 8,443 |  |  | 5,630 |  |  | 2,813 |  |
| Other Intangibles | 0.7 years |  | 324 |  |  | 230 |  |  | 94 |  |
|  |  |  | $ | 10,567 |  |  | $ | 6,388 |  |  | $ | 4,179 |  |

- changed (2012-05-04):
[0001078271-12-000025:note_history:18]
Amortization expense was $0.4 million and $0.5 million for the three months ended April 1, 2012 and March 27, 2011, respectively. Amortization expense was $1.4 million and $1.6 million for the nine months ended April 1, 2012 and March 27, 2011, respectively. Amortization expense expected to be recorded for each of the next five years is as follows (in thousands):
  (was, 2012-02-07, similarity 0.8228):
[0001078271-12-000006:note_history:18]
Amortization expense was $0.5 million and $0.5 million for the three months ended January 1, 2012 and December 26, 2010, respectively. Amortization expense was $1.0 million and $1.0 million for the six months ended January 1, 2012 and December 26, 2010, respectively. Amortization expense expected to be recorded for each of the next five years is as follows (in thousands):

- changed (2012-05-04):
[0001078271-12-000025:note_history:19]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenues when the revenue recognition criteria have not been met. Product revenue includes shipments to end-users and value-add resellers. The following table summarizes deferred revenue, net at April 1, 2012 and July 3, 2011, respectively (in thousands):
  (was, 2012-02-07, similarity 0.9865):
[0001078271-12-000006:note_history:19]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenues when the revenue recognition criteria have not been met. Product revenue includes shipments to end-users and value-add resellers. The following table summarizes deferred revenue, net at January 1, 2012 and July 3, 2011, respectively (in thousands):

- changed (2012-05-04):
[0001078271-12-000025:note_history:20]
|  | April 1, 2012 |  | July 3, 2011 |
| Deferred services | $ | 38,417 |  |  | $ | 36,025 |  |
| Deferred product |  |  |  |
| Deferred revenue | 2,045 |  |  | 1,984 |  |
| Deferred cost of sales | (699 | ) |  | (1,036 | ) |
| Deferred product revenue, net | 1,346 |  |  | 948 |  |
| Balance at end of period | 39,763 |  |  | 36,973 |  |
| Less: current portion | 32,134 |  |  | 29,613 |  |
| Non-current deferred revenue, net | $ | 7,629 |  |  | $ | 7,360 |  |
  (was, 2012-02-07, similarity 0.9839):
[0001078271-12-000006:note_history:20]
|  | January 1, 2012 |  | July 3, 2011 |
| Deferred services | $ | 37,669 |  |  | $ | 36,025 |  |
| Deferred product |  |  |  |
| Deferred revenue | 1,706 |  |  | 1,984 |  |
| Deferred cost of sales | (504 | ) |  | (1,036 | ) |
| Deferred product revenue, net | 1,202 |  |  | 948 |  |
| Balance at end of period | 38,871 |  |  | 36,973 |  |
| Less: current portion | 31,308 |  |  | 29,613 |  |
| Non-current deferred revenue, net | $ | 7,563 |  |  | $ | 7,360 |  |

- changed (2012-05-04):
[0001078271-12-000025:note_history:21]
The Company offers support arrangements, including extended warranty contracts, to its customers that range generally from one to two years. Deferred support revenue is included within deferred revenue, net within the deferred services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):
  (was, 2012-02-07, similarity 0.9869):
[0001078271-12-000006:note_history:21]
The Company offers renewable support arrangements, including extended warranty contracts, to its customers that range generally from one to two years. Deferred support revenue is included within deferred revenue, net within the deferred services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

- added (2012-05-04):
[0001078271-12-000025:note_history:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2012 |  | March 27, 2011 |  | April 1, 2012 |  | March 27, 2011 |
| Balance beginning of period | $ | 37,416 |  |  | $ | 38,872 |  |  | $ | 35,802 |  |  | $ | 36,193 |  |
| New support arrangements | 15,115 |  |  | 12,231 |  |  | 45,675 |  |  | 43,961 |  |
| Recognition of support revenue | (14,364 | ) |  | (14,137 | ) |  | (43,310 | ) |  | (43,188 | ) |
| Balance end of period | 38,167 |  |  | 36,966 |  |  | 38,167 |  |  | 36,966 |  |
| Less current portion | 30,538 |  |  | 30,175 |  |  | 30,538 |  |  | 30,175 |  |
| Non-current deferred revenue | $ | 7,629 |  |  | $ | 6,791 |  |  | $ | 7,629 |  |  | $ | 6,791 |  |

- changed (2012-05-04):
[0001078271-12-000025:note_history:23]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay it currently for product delivered, the Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of deferred cost of sales to distributors” in the liability section of its consolidated balance sheets. The following table summarizes deferred distributors revenue, net of deferred cost of sales to distributors at April 1, 2012 and July 3, 2011, respectively (in thousands):
  (was, 2012-02-07, similarity 0.9918):
[0001078271-12-000006:note_history:23]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay it currently for product delivered, the Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of deferred cost of sales to distributors” in the liability section of its consolidated balance sheets. The following table summarizes deferred distributors revenue, net of deferred cost of sales to distributors at January 1, 2012 and July 3, 2011, respectively (in thousands):

- changed (2012-05-04):
[0001078271-12-000025:note_history:24]
|  | April 1, 2012 |  | July 3, 2011 |
| Deferred revenue | $ | 23,376 |  |  | $ | 22,454 |  |
| Deferred cost of sales | (5,408 | ) |  | (5,902 | ) |
| Total deferred distributors revenue, net of deferred cost of sales to distributors | $ | 17,968 |  |  | $ | 16,552 |  |
  (was, 2012-02-07, similarity 0.9254):
[0001078271-12-000006:note_history:24]
|  | January 1, 2012 |  | July 3, 2011 |
| Deferred revenue | $ | 19,156 |  |  | $ | 22,454 |  |
| Deferred cost of sales | (4,665 | ) |  | (5,902 | ) |
| Total deferred distributors revenue, net of deferred cost of sales to distributors | $ | 14,491 |  |  | $ | 16,552 |  |

- changed (2012-05-04):
[0001078271-12-000025:note_history:25]
The Company's standard hardware warranty period is typically 12 months from the date of shipment to end-users. For certain access products, the Company offers a lifetime hardware warranty commencing on the date of shipment from the Company and ending five years following the Company's announcement of the end of sale of such product. The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended April 1, 2012 and March 27, 2011, respectively (in thousands):
  (was, 2012-02-07, similarity 0.9426):
[0001078271-12-000006:note_history:25]
The Company's standard hardware warranty period is typically 12 months from the date of shipment to end-users. For certain access products, the Company offers a lifetime hardware warranty commencing on the date of shipment from the Company and ending five years following the Company's announcement of the end of sale of such product. The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended January 1, 2012 and December 26, 2010, respectively (in thousands):

- changed (2012-05-04):
[0001078271-12-000025:note_history:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2012 |  | March 27, 2011 |  | April 1, 2012 |  | March 27, 2011 |
| Balance beginning of period | $ | 2,651 |  |  | $ | 2,811 |  |  | $ | 2,640 |  |  | $ | 3,169 |  |
| New warranties issued | 1,556 |  |  | 1,369 |  |  | 4,793 |  |  | 4,313 |  |
| Warranty expenditures | (1,365 | ) |  | (1,672 | ) |  | (4,591 | ) |  | (4,974 | ) |
| Balance end of period | $ | 2,842 |  |  | $ | 2,508 |  |  | $ | 2,842 |  |  | $ | 2,508 |  |
  (was, 2012-02-07, similarity 0.8627):
[0001078271-12-000006:note_history:26]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2012 |  | December 26, 2010 |  | January 1, 2012 |  | December 26, 2010 |
| Balance beginning of period | $ | 2,702 |  |  | $ | 2,794 |  |  | $ | 2,640 |  |  | $ | 3,169 |  |
| New warranties issued | 1,589 |  |  | 1,653 |  |  | 3,237 |  |  | 2,944 |  |
| Warranty expenditures | (1,640 | ) |  | (1,636 | ) |  | (3,226 | ) |  | (3,302 | ) |
| Balance end of period | $ | 2,651 |  |  | $ | 2,811 |  |  | $ | 2,651 |  |  | $ | 2,811 |  |

- changed (2012-05-04):
[0001078271-12-000025:note_history:27]
In the normal course of business to facilitate sales of the Company's products, the Company indemnifies the Company's resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on the Company's operating results or financial position.
  (was, 2012-02-07, similarity 0.993):
[0001078271-12-000006:note_history:27]
In the normal course of business to facilitate sales of the Company's products, the Company indemnifies the Company's resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on the Company's operating results or financial position.

- changed (2012-05-04):
[0001078271-12-000025:note_history:28]
|  | April 1, 2012 |  | July 3, 2011 |
| Accrued income taxes | $ | 731 |  |  | $ | 897 |  |
| Accrued general and administrative costs | 1,927 |  |  | 5,373 |  |
| Accrued research and development costs | 737 |  |  | 1,734 |  |
| Accrued in-transit inventory and freight | 1,723 |  |  | 2,777 |  |
| Accrued marketing development funds | 2,143 |  |  | 2,492 |  |
| Deferred gain on planned sale of buildings | 2,003 |  |  | — |  |
| Other accrued liabilities | 3,031 |  |  | 5,777 |  |
| Total | $ | 12,295 |  |  | $ | 19,050 |  |
  (was, 2012-02-07, similarity 0.8555):
[0001078271-12-000006:note_history:28]
|  | January 1, 2012 |  | July 3, 2011 |
| Accrued income taxes | $ | 701 |  |  | $ | 897 |  |
| Accrued general and administrative costs | 2,001 |  |  | 5,373 |  |
| Accrued research and development costs | 1,601 |  |  | 1,734 |  |
| Accrued in-transit inventory and freight | 1,250 |  |  | 2,777 |  |
| Accrued marketing development funds | 2,459 |  |  | 2,492 |  |
| Deferred gain on assets held for sale | 1,002 |  |  | — |  |
| Other accrued liabilities | 3,262 |  |  | 5,777 |  |
| Total | $ | 12,276 |  |  | $ | 19,050 |  |

- removed (2012-05-04):
[0001078271-12-000006:note_history:29]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| January 1, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 29,766 |  |  | $ | 29,766 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 89,658 |  |  | 89,545 |  |  | 141 |  |  | (255 | ) |
| U.S. government agency securities | 7,488 |  |  | 7,476 |  |  | 1 |  |  | (13 | ) |
|  | $ | 126,912 |  |  | $ | 126,787 |  |  | $ | 142 |  |  | $ | (268 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 29,766 |  |  | $ | 29,766 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 34,207 |  |  | 34,250 |  |  | 51 |  |  | (9 | ) |
| Marketable securities | 62,939 |  |  | 62,771 |  |  | 91 |  |  | (259 | ) |
|  | $ | 126,912 |  |  | $ | 126,787 |  |  | $ | 142 |  |  | $ | (268 | ) |

- removed (2012-05-04):
[0001078271-12-000006:note_history:30]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. During the three and six months ended January 1, 2012, realized gains or losses recognized on the sale of investments were not significant. As of January 1, 2012, there were twenty-seven out of fifty-one investment securities that had unrealized losses. The unrealized gains / (losses) on the Company’s investments were caused by interest rate fluctuations. Substantially all of the Company’s available-for-sale investments are investment grade government and corporate debt securities that have maturities of less than 3 years.

- removed (2012-05-04):
[0001078271-12-000006:note_history:31]
On September 23, 2010, the Company entered into an Option Agreement with Trumark Companies LLC (“Trumark”), under which the Company granted Trumark an option (the “Option”) to purchase half of its corporate headquarters campus in Santa Clara, California (First Property), at a price of $24.0 million. The Option expires on December 18, 2012, provided that Trumark continues to make the required Option payments. As of January 1, 2012, the Company had received $1.0 million of Option payments from Trumark, which were classified as a deferred gain and included in other current liabilities on the condensed consolidated balance sheet.  If Trumark exercises the Option, the closing on this transaction will occur within thirty days after the exercise date. As of January 1, 2012, the assets associated with the proposed transaction were classified as “assets held for sale” on the condensed consolidated balance at a net book value of $17.1 million, which was the lesser of the fair value (less cost to sell) or carrying amount of the assets. In addition, as of January 1, 2012, the Company ceased recognizing depreciation expense on the assets held for sale.

- removed (2012-05-04):
[0001078271-12-000006:note_history:32]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2012 |  | December 26, 2010 |  | January 1, 2012 |  | December 26, 2010 |
| Balance beginning of period | $ | 35,730 |  |  | $ | 35,417 |  |  | $ | 35,802 |  |  | $ | 36,193 |  |
| New support arrangements | 15,960 |  |  | 18,237 |  |  | 30,560 |  |  | 31,730 |  |
| Recognition of support revenue | (14,274 | ) |  | (14,782 | ) |  | (28,946 | ) |  | (29,051 | ) |
| Balance end of period | 37,416 |  |  | 38,872 |  |  | 37,416 |  |  | 38,872 |  |
| Less current portion | 29,853 |  |  | 31,727 |  |  | 29,853 |  |  | 31,727 |  |
| Non-current deferred revenue | $ | 7,563 |  |  | $ | 7,145 |  |  | $ | 7,563 |  |  | $ | 7,145 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2012-05-04):
[0001078271-12-000006:note_history:33]
Subsequent Events

- removed (2012-05-04):
[0001078271-12-000006:note_history:34]
On January 18, 2012, the Company received an additional option payment of $0.5 million from Trumark in connection with the proposed sale of the First Property (see Note 2, “Long-Lived Assets”), bringing the total option payments received from Trumark to $1.5 million.

- removed (2012-05-04):
[0001078271-12-000006:note_history:35]
On January 25, 2012, Company entered into new agreement with Trumark, under which it granted Trumark an option to purchase the remaining portion of the Company's corporate campus (Second Property).  Under the new agreement, Trumark will have until December 28, 2012 to exercise the option to purchase the Second Property for a total purchase price of $24.5 million, and in the meantime, Trumark will make certain payments to the Company in order to keep the option in effect. If Trumark exercises the option, the closing on the Second Property transaction will occur within thirty days after such exercise.  However, Trumark has the right to extend the closing by up to six months to meet certain city regulatory requirements. The assets associated with the Second Property transaction were considered to be assets held for use and were included in property and equipment, net on the condensed consolidated balance sheet as of January 1, 2012.
