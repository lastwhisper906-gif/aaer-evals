# EXTR 8-K — 0001078271-12-000039 filed 2012-08-01

## item codes, every 8-K on or before 2012-08-23

- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2012-08-23

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-12-000039:8k_2_02:1]
EX-99.1
2
ex99-1q412earningsrelease.htm
EARNINGS PRESS RELEASE

[0001078271-12-000039:8k_2_02:2]
Ex 99-1 Q4'12 Earnings Release

[0001078271-12-000039:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-12-000039:8k_2_02:4]
| For more information, contact: |  |  |
| Extreme Networks |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-12-000039:8k_2_02:5]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2012 Financial Results

[0001078271-12-000039:8k_2_02:6]
Fiscal 2012 Annual non-GAAP Net Income Increases 189%

[0001078271-12-000039:8k_2_02:7]
SANTA CLARA, Calif., August 1, 2012 /PRNewswire/ -- Extreme Networks, Inc. (Nasdaq: EXTR) today announced financial results for its 2012 fiscal fourth quarter and total year ended June 30, 2012. For the quarter, total net revenue was $87.6 million as compared to $73.4 million in the third fiscal quarter and $89.8 million for the fourth fiscal quarter last year.  GAAP net income was $7.8 million or $0.08 per diluted share for the quarter and increased $5.4 million or $0.05 per diluted share as compared to the prior quarter and increased $9.9 million or $0.10 per diluted share when compared to one year ago. Non-GAAP net income was $7.6 million or $0.08 per diluted share for the quarter and increased $3.8 million or $0.04 per diluted share as compared to the prior quarter and increased $5.5 million or $0.06 per diluted share when compared to one year ago.

[0001078271-12-000039:8k_2_02:8]
For fiscal year 2012, Extreme Networks reported revenue of $322.7 million, compared to revenue of $334.4 million for fiscal 2011.  GAAP net income of $15.9 million, or $0.17 per diluted share, increased $13.2 million and $0.14 per diluted share, compared to $2.7 million, or $0.03 per diluted share for fiscal 2011.  On a non-GAAP basis, net income for fiscal year 2012 of $21.7 million, or $0.23 per diluted share, increased $14.2 million or $0.15 per diluted share, compared to $7.5 million, or $0.08 per diluted share, for fiscal 2011.

[0001078271-12-000039:8k_2_02:9]
“Q4 results were in-line with our targets and we are encouraged by the progress we have made in our financial results,” stated Oscar Rodriguez, President and CEO of Extreme Networks. “Over the last fiscal year, we have transformed Extreme Networks to take a leading technology position among networking vendors.  This coming year we are looking forward to building revenue from our new data center, campus and mobile backhaul product portfolios by leveraging our increased investments in key areas including Software Defined Networking and Bring Your Own Device (BYOD) applications.”

[0001078271-12-000039:8k_2_02:10]
Q4 2012 Financial Metrics:

[0001078271-12-000039:8k_2_02:11]
|  |  | Fourth Quarter |  |  |  |  |
|  |  | (in thousands, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2012 |  | 2011 |  | Change |
| Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 72,558 |  |  | $ | 73,778 |  |  | $ | (1,220 | ) |  | (2 | )% |
| Service |  | $ | 15,091 |  |  | $ | 15,983 |  |  | $ | (892 | ) |  | (6 | )% |
| Total Net Revenue |  | $ | 87,649 |  |  | $ | 89,761 |  |  | $ | (2,112 | ) |  | (2 | )% |
| GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 56 | % |  | 54 | % |  | 2 | % |  |  |
| Operating Margin/Loss |  | 6 | % |  | (2 | )% |  | 8 | % |  |  |
| Net Income |  | $ | 7,812 |  |  | $ | (2,087 | ) |  | $ | 9,899 |  |  |  |
| Earnings per diluted share |  | $ | 0.08 |  |  | $ | (0.02 | ) |  | $ | 0.10 |  |  |  |
| Non-GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 56 | % |  | 54 | % |  | 2 | % |  |  |
| Operating Margin |  | 8 | % |  | (2 | )% |  | 10 | % |  |  |
| Net Income |  | $ | 7,646 |  |  | $ | 2,145 |  |  | $ | 5,501 |  |  |  |
| Earnings per diluted share |  | $ | 0.08 |  |  | $ | 0.02 |  |  | $ | 0.06 |  |  |  |

[0001078271-12-000039:8k_2_02:12]
| • | Gross margin for Q4 was 56% and flat sequentially as compared to Q3 Fiscal 2012. |

[0001078271-12-000039:8k_2_02:13]
| • | Cash and investments ended the quarter at $153.5 million, as compared to $147.2 million from Q3 of fiscal 2012. |

[0001078271-12-000039:8k_2_02:14]
| • | Accounts receivable balance at Q4 was $41.2 million, a (net) decrease $4.6 million from Q3 of fiscal 2012, with days sales outstanding (DSO) of 42, a decrease of 15 days from Q3 of fiscal 2012. |

[0001078271-12-000039:8k_2_02:15]
| • | Inventory at Q4 was $26.6 million, a (net) increase of $3.3 million from Q3 of fiscal 2012 and represents 72 days of inventory (DOI), a decrease of 6 days from Q3 of fiscal 2012. |

[0001078271-12-000039:8k_2_02:16]
Fiscal Year 2012 Business Highlights:

[0001078271-12-000039:8k_2_02:17]
| • | We experienced growth in the number of 10G Ethernet ports shipped of 146% in fiscal 2012, while the total market for 10G Ethernet ports is estimated by Dell'Oro to grow at 66% in calendar year 2012, and we believe we will continue to grow significantly faster than the overall market for 10G ports shipped in calendar year 2012. |

[0001078271-12-000039:8k_2_02:18]
| • | Extreme Networks was ranked #1 and #2 in two key categories of 40 Gigabit Ethernet Switch Market Share for the last six months of calendar 2011, and earned a #1 rating for its BlackDiamond X8and Summit X670 product by Infotech Research in its November 2011 report for data center and cloud switching. |

[0001078271-12-000039:8k_2_02:19]
| • | Ahead of the Summer Olympics, the London Internet Exchange (LINX), one of the world's leading exchange points for Internet traffic, has become one of the first organizations to purchase the BlackDiamond® X8 switch to help meet growing network data traffic requirements. |

[0001078271-12-000039:8k_2_02:20]
| • | Developed and piloted New Software Supporting Open Flow and Software-Defined Networks (SDN) capabilities. |

[0001078271-12-000039:8k_2_02:21]
| • | Completed a transformation of the business and we believe we are now well positioned to achieve our goals to grow revenue and increase profitability. |

[0001078271-12-000039:8k_2_02:22]
Business Outlook:

[0001078271-12-000039:8k_2_02:23]
While we believe our new products, such as the high performance Black Diamond 8X, can drive higher demand over the next few quarters, our targets for the near-term reflect the uncertainty in the global economy.  Our targeted revenue for the first quarter of fiscal 2013 ending September 30, 2012, is in a range of $75 million to $82 million with GAAP and non-GAAP gross margin targeted to be in a similar range as Q4 at 56%. GAAP net income is targeted at break-even to $3.0 million, or $0.00 to $0.03 per diluted share. Non-GAAP net income is targeted in a range of $1 million to $4 million, or $0.01 to $0.05 per diluted share.  (Non-GAAP targets for the first fiscal quarter exclude stock based compensation expense.) The GAAP and non-GAAP net income targets are based on an estimated 95.7 million diluted weighted average shares.

[0001078271-12-000039:8k_2_02:24]
The schedules attached to this release are an integral part of the release.

[0001078271-12-000039:8k_2_02:25]
Conference Call:

[0001078271-12-000039:8k_2_02:26]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the highlights of the fiscal fourth quarter 2012 results and the fiscal first quarter 2013 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August10th, 2012.  The conference call may also be heard by dialing 1-877-303-9826 (international callers' dial 1-224-357 2194) and the conference call ID is 15138495. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release.

[0001078271-12-000039:8k_2_02:27]
About Extreme Networks:

[0001078271-12-000039:8k_2_02:28]
Extreme Networks is a technology leader in high-performance Ethernet switching for cloud, data center and mobile networks.  Based in Santa Clara, CA, Extreme Networks has more than 6,000 customers in over 50 countries.  Extreme Networks is a trademark or registered trademark of Extreme Networks, Inc. in the United States and/or other countries.

[0001078271-12-000039:8k_2_02:29]
For additional product and company information, please refer to www.extremenetworks.com.

[0001078271-12-000039:8k_2_02:30]
Non-GAAP Financial Measures:

[0001078271-12-000039:8k_2_02:31]
This press release highlights the company's financial results on both a GAAP and a non-GAAP basis.  The GAAP results include certain costs, charges and expenses which are excluded from non-GAAP results.  By publishing the non-GAAP measures, management intends to provide investors with additional information to further analyze the company's performance, core results and underlying trends.  Extreme's management evaluates results and makes operating decisions using both GAAP and non-GAAP measures included in this press release.  Non-GAAP results are not prepared in accordance with GAAP and non-GAAP information should be considered a supplement to, and not a substitute for, financial statements prepared in accordance with GAAP.  Investors and potential investors are encouraged to review the reconciliation of non-GAAP financial measures to their most directly comparable GAAP measures attached to this press release.

[0001078271-12-000039:8k_2_02:32]
Forward Looking Statements:

[0001078271-12-000039:8k_2_02:33]
Actual results, including with respect to our targets and prospects, could differ materially due to a number of factors, including the risk that we may not obtain sufficient orders to achieve our targeted revenues for the company's products and services given that increasing price competition in key network switching equipment markets; our effectiveness in controlling expenses, the risk that we or our distributors and other channel partners are not able to develop and expand customer bases and accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as we experience wide fluctuations in supply and demand; the risk that our results will suffer if we are unable to balance fluctuations in customer demand and capacity; risks associated with the ramp-up of production of our new products and our entry into new business channels different from those in which we have historically operated; the risk that we may experience production delays that preclude us from shipping sufficient quantities to meet customer orders or that result in higher production costs and lower margins; ongoing uncertainty in global economic conditions, infrastructure development or customer demand that could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; our ability to complete development and commercialization of products under development, such as our pipeline of new network switches and related software; our ability to lower costs; risks resulting from the concentration of our business among few customers, including the risk that customers may reduce or cancel orders or fail to honor purchase commitments; the rapid development of new technology and competing products that may impair demand or render our products obsolete; the potential lack of customer acceptance for our new products; and risks associated with ongoing litigation; a dependency on third parties for certain components and for the manufacturing of the Company's products. More information about potential factors that could affect the Company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission. Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-12-000039:8k_2_02:34]
EXTREME NETWORKS, INC.

[0001078271-12-000039:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-12-000039:8k_2_02:36]
(In thousands, except share and per share amounts)

[0001078271-12-000039:8k_2_02:37]
|  | June 30, 2012 |  | July 3, 2011 |
|  | (unaudited) |  | (1) |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 54,596 |  |  | $ | 49,972 |  |
| Short-term investments | 23,358 |  |  | 41,357 |  |
| Accounts receivable, net of allowances of $1,646 at June 30, 2012 and $1,412 at July 3, 2011 | 41,166 |  |  | 33,689 |  |
| Inventories, net | 26,609 |  |  | 21,583 |  |
| Deferred income taxes | 644 |  |  | 681 |  |
| Prepaid expenses and other current assets, net | 5,655 |  |  | 10,132 |  |
| Assets held for sale | 17,081 |  |  | — |  |
| Total current assets | 169,109 |  |  | 157,414 |  |
| Property and equipment, net | 25,180 |  |  | 41,877 |  |
| Marketable securities | 75,561 |  |  | 55,648 |  |
| Intangible assets | 5,106 |  |  | 4,906 |  |
| Other assets, net | 9,519 |  |  | 11,128 |  |
| Total assets | $ | 284,475 |  |  | $ | 270,973 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 19,437 |  |  | $ | 15,092 |  |
| Accrued compensation and benefits | 13,409 |  |  | 13,723 |  |
| Restructuring liabilities | 463 |  |  | 3,183 |  |
| Accrued warranty | 2,871 |  |  | 2,640 |  |
| Deferred revenue, net | 31,769 |  |  | 29,613 |  |
| Deferred distributors revenue, net of deferred cost of sales to distributors | 15,319 |  |  | 16,552 |  |
| Other accrued liabilities | 13,245 |  |  | 19,050 |  |
| Total current liabilities | 96,513 |  |  | 99,853 |  |
| Deferred revenue, less current portion | 7,559 |  |  | 7,360 |  |
| Deferred income taxes | 120 |  |  | 93 |  |
| Other long-term liabilities | 643 |  |  | 2,381 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 179,640 |  |  | 161,286 |  |
| Total liabilities and stockholders’ equity | $ | 284,475 |  |  | $ | 270,973 |  |

[0001078271-12-000039:8k_2_02:38]
(1) The information in this column is derived from the Company's consolidated balance sheet included in the Company's Annual Report on Form 10-K for the year ended July 3, 2011.

[0001078271-12-000039:8k_2_02:39]
EXTREME NETWORKS, INC.

[0001078271-12-000039:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-12-000039:8k_2_02:41]
(In thousands, except per share amounts)

[0001078271-12-000039:8k_2_02:42]
|  | Three Months Ended |  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 30, 2012 |  | July 3, 2011 |
|  | (unaudited) |  | (unaudited) |  | (unaudited) |  | (1) |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 72,558 |  |  | $ | 73,778 |  |  | $ | 261,873 |  |  | $ | 274,388 |  |
| Service | 15,091 |  |  | 15,983 |  |  | 60,849 |  |  | 60,040 |  |
| Total net revenues | 87,649 |  |  | 89,761 |  |  | 322,722 |  |  | 334,428 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 33,305 |  |  | 34,770 |  |  | 120,227 |  |  | 129,556 |  |
| Service | 5,511 |  |  | 6,409 |  |  | 22,648 |  |  | 24,911 |  |
| Total cost of revenues | 38,816 |  |  | 41,179 |  |  | 142,875 |  |  | 154,467 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 39,253 |  |  | 39,008 |  |  | 141,646 |  |  | 144,832 |  |
| Service | 9,580 |  |  | 9,574 |  |  | 38,201 |  |  | 35,129 |  |
| Total gross profit | 48,833 |  |  | 48,582 |  |  | 179,847 |  |  | 179,961 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Sales and marketing | 24,655 |  |  | 28,454 |  |  | 90,167 |  |  | 103,277 |  |
| Research and development | 11,774 |  |  | 13,204 |  |  | 45,640 |  |  | 49,330 |  |
| General and administrative | 6,880 |  |  | 6,068 |  |  | 28,658 |  |  | 24,683 |  |
| Restructuring charge, net of reversal | 237 |  |  | 2,764 |  |  | 1,594 |  |  | 3,806 |  |
| Litigation settlement | (121 | ) |  | — |  |  | (121 | ) |  | (4,249 | ) |
| Total operating expenses | 43,425 |  |  | 50,490 |  |  | 165,938 |  |  | 176,847 |  |
| Operating income (loss) | 5,408 |  |  | (1,908 | ) |  | 13,909 |  |  | 3,114 |  |
| Interest income | 311 |  |  | 345 |  |  | 1,239 |  |  | 1,304 |  |
| Interest expense | — |  |  | (37 | ) |  | (75 | ) |  | (132 | ) |
| Other income (expense) | 2,049 |  |  | (255 | ) |  | 1,995 |  |  | (574 | ) |
| Income (loss) before income taxes | 7,768 |  |  | (1,855 | ) |  | 17,068 |  |  | 3,712 |  |
| Provision for income taxes | (44 | ) |  | 232 |  |  | 1,196 |  |  | 999 |  |
| Net income (loss) | $ | 7,812 |  |  | $ | (2,087 | ) |  | $ | 15,872 |  |  | $ | 2,713 |  |
| Basic and diluted net income (loss) per share: |  |  |  |  |  |  |  |
| Net income (loss) per share - basic | $ | 0.08 |  |  | $ | (0.02 | ) |  | $ | 0.17 |  |  | $ | 0.03 |  |
| Net income (loss) per share - diluted | $ | 0.08 |  |  | $ | (0.02 | ) |  | $ | 0.17 |  |  | $ | 0.03 |  |
| Shares used in per share calculation - basic | 94,186 |  |  | 92,382 |  |  | 93,451 |  |  | 91,423 |  |
| Shares used in per share calculation - diluted | 95,225 |  |  | 92,382 |  |  | 94,490 |  |  | 92,795 |  |

[0001078271-12-000039:8k_2_02:43]
(1)  The information in this column is derived from the Company's consolidated statement of operations included in the Company's Annual Report on Form 10-K for the year ended July 3, 2011.

[0001078271-12-000039:8k_2_02:44]
EXTREME NETWORKS, INC.

[0001078271-12-000039:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-12-000039:8k_2_02:46]
(In thousands)

[0001078271-12-000039:8k_2_02:47]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |
|  | (unaudited) |  | (1) |
| Net cash provided by operating activities | $ | 13,813 |  |  | $ | 16,777 |  |
| Cash flows used in investing activities: |  |  |  |
| Capital expenditures | (5,237 | ) |  | (5,697 | ) |
| Purchases of investments | (75,851 | ) |  | (111,798 | ) |
| Proceeds from maturities of investments and marketable securities | 30,295 |  |  | 33,600 |  |
| Proceeds from sales of investments and marketable securities | 40,658 |  |  | 61,816 |  |
| Purchases of intangible assets | (275 | ) |  | — |  |
| Net cash used in investing activities | (10,410 | ) |  | (22,079 | ) |
| Cash flows provided by financing activities: |  |  |  |
| Proceeds from issuance of common stock | 1,392 |  |  | 1,530 |  |
| Deposit received from sale of buildings | 1,001 |  |  | 1,000 |  |
| Net cash provided by financing activities | 2,393 |  |  | 2,530 |  |
| Foreign currency effect on cash | (1,172 | ) |  | 800 |  |
| Net increase (decrease) in cash and cash equivalents | 4,624 |  |  | (1,972 | ) |
| Cash and cash equivalents at beginning of period | 49,972 |  |  | 51,944 |  |
| Cash and cash equivalents at end of period | $ | 54,596 |  |  | $ | 49,972 |  |

[0001078271-12-000039:8k_2_02:48]
(1) The information in this column is derived from the Company's statement of cash flows included in the Company's Annual Report on Form 10-K for the year ended July 3, 2011.

[0001078271-12-000039:8k_2_02:49]
EXTREME NETWORKS, INC.

[0001078271-12-000039:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-12-000039:8k_2_02:51]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-12-000039:8k_2_02:52]
(In thousands, except per share amounts)

[0001078271-12-000039:8k_2_02:53]
(Unaudited)

[0001078271-12-000039:8k_2_02:54]
|  | Three Months Ended |  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 30, 2012 |  | July 3, 2011 |
| NON-GAAP ADJUSTMENTS |  |  |  |  |  |  |  |
| Cost of product revenue | $ | 158 |  |  | $ | 117 |  |  | $ | 531 |  |  | $ | 436 |  |
| Cost of service revenue | 54 |  |  | 8 |  |  | 257 |  |  | 232 |  |
| Sales and marketing | 460 |  |  | 541 |  |  | 1,765 |  |  | 1,948 |  |
| Research and development | 322 |  |  | 373 |  |  | 1,363 |  |  | 1,113 |  |
| General and administrative | 611 |  |  | 429 |  |  | 2,341 |  |  | 1,520 |  |
| Restructuring charge, net of reversal | 237 |  |  | 2,764 |  |  | 1,594 |  |  | 3,806 |  |
| Litigation settlement | (121 | ) |  | — |  |  | (121 | ) |  | (4,249 | ) |
| CTA reclassification | (1,887 | ) |  | — |  |  | (1,887 | ) |  | — |  |
| Total non-GAAP adjustments | $ | (166 | ) |  | $ | 4,232 |  |  | $ | 5,843 |  |  | $ | 4,806 |  |
| Gross margin - GAAP Basis | $ | 48,833 |  |  | $ | 48,582 |  |  | $ | 179,847 |  |  | $ | 179,961 |  |
| Non-GAAP adjustments to gross margin | 212 |  |  | 125 |  |  | 788 |  |  | 668 |  |
| Gross margin - Non-GAAP Basis | $ | 49,045 |  |  | $ | 48,707 |  |  | $ | 180,635 |  |  | $ | 180,629 |  |
| Gross margin - Non-GAAP Basis % | 56 | % |  | 54 | % |  | 56 | % |  | 54 | % |
| Operating income (loss) - GAAP Basis | $ | 5,408 |  |  | $ | (1,908 | ) |  | $ | 13,909 |  |  | $ | 3,114 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |
| Stock-based compensation expense | $ | 1,537 |  |  | $ | 1,468 |  |  | $ | 6,189 |  |  | $ | 5,249 |  |
| Restructuring charge, net of reversal | 237 |  |  | 2,764 |  |  | 1,594 |  |  | 3,806 |  |
| Litigation settlement | (53 | ) |  | — |  |  | (53 | ) |  | (4,249 | ) |
| Total Non-GAAP adjustments | $ | 1,721 |  |  | $ | 4,232 |  |  | $ | 7,730 |  |  | $ | 4,806 |  |
| Operating income (loss) - Non-GAAP Basis | $ | 7,129 |  |  | $ | 2,324 |  |  | $ | 21,639 |  |  | $ | 7,920 |  |
| Net income (loss) - GAAP Basis | $ | 7,812 |  |  | $ | (2,087 | ) |  | $ | 15,872 |  |  | $ | 2,713 |  |
| Non-GAAP adjustments to other income/expense | (1,887 | ) |  | — |  |  | (1,887 | ) |  | — |  |
| Non-GAAP adjustments to operating income | 1,721 |  |  | 4,232 |  |  | 7,730 |  |  | 4,806 |  |
| Net income (loss) - Non-GAAP Basis | $ | 7,646 |  |  | $ | 2,145 |  |  | $ | 21,715 |  |  | $ | 7,519 |  |
| Basic and diluted Non-GAAP net income (loss) per share: |  |  |  |  |  |  |  |
| Non-GAAP Net income (loss) per share - basic | $ | 0.08 |  |  | $ | 0.02 |  |  | $ | 0.23 |  |  | $ | 0.08 |  |
| Non-GAAP Net income (loss) per share - diluted | $ | 0.08 |  |  | $ | 0.02 |  |  | $ | 0.23 |  |  | $ | 0.08 |  |
| Shares used in per share calculation - basic | 94,186 |  |  | 92,382 |  |  | 93,451 |  |  | 91,423 |  |
| Shares used in per share calculation - diluted | 95,225 |  |  | 92,382 |  |  | 94,490 |  |  | 92,795 |  |
