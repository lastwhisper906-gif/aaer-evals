# EXTR notes — 0001078271-12-000048


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001078271-12-000048:notes:1]
Advertising

[0001078271-12-000048:notes:2]
Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. All other advertising costs are expensed as incurred. Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Otherwise, such cooperative advertising obligations with customers are recorded as a reduction of revenue.


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001078271-12-000048:notes:3]
The following table presents the Company’s investments’ gross unrealized losses and fair values, aggregated by investment category and length of time that individual securities have been in a continuous unrealized loss position.

[0001078271-12-000048:notes:4]
|  | Less than 12 months |  | 12 months or more |  | Total |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| June 30, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| U.S. corporate debt securities | $ | 26,728 |  |  | $ | (81 | ) |  | $ | 1,014 |  |  | $ | — |  |  | $ | 27,742 |  |  | $ | (81 | ) |
| U.S. government agency securities | $ | 5,498 |  |  | $ | (10 | ) |  | $ | — |  |  | $ | — |  |  | $ | 5,498 |  |  | $ | (10 | ) |
| U.S. municipal bonds | $ | 2,736 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,736 |  |  | $ | (2 | ) |
|  | $ | 34,962 |  |  | $ | (93 | ) |  | $ | 1,014 |  |  | $ | — |  |  | $ | 35,976 |  |  | $ | (93 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-12-000048:notes:5]
Summary of Available-for-Sale Securities (in thousands)

[0001078271-12-000048:notes:6]
|  | June 30, 2012 |  | July 3, 2011 |
| Cash | $ | 18,455 |  |  | $ | 19,567 |  |
| Cash equivalents | $ | 36,141 |  |  | $ | 30,405 |  |
| Short-term investments | 23,358 |  |  | 41,357 |  |
| Marketable securities | 75,561 |  |  | 55,648 |  |
| Total available-for-sale | $ | 135,060 |  |  | $ | 127,410 |  |
| Total cash and available for sale securities | $ | 153,515 |  |  | $ | 146,977 |  |

[0001078271-12-000048:notes:7]
Available-for-Sale Securities

[0001078271-12-000048:notes:8]
The following is a summary of available-for-sale securities (in thousands):

[0001078271-12-000048:notes:9]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| June 30, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 84,882 |  |  | 84,949 |  |  | 148 |  |  | (81 | ) |
| U.S. government agency securities | 11,241 |  |  | 11,234 |  |  | 3 |  |  | (10 | ) |
| U.S. municipal bonds | 2,738 |  |  | 2,736 |  |  | — |  |  | (2 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 23,311 |  |  | 23,358 |  |  | 48 |  |  | (1 | ) |
| Marketable securities | 75,550 |  |  | 75,561 |  |  | 103 |  |  | (92 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |
| July 3, 2011 |  |  |  |  |  |  |  |
| Money market funds | $ | 30,405 |  |  | $ | 30,405 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 89,004 |  |  | 89,249 |  |  | 287 |  |  | (43 | ) |
| U.S. government agency securities | 7,746 |  |  | 7,756 |  |  | 13 |  |  | (3 | ) |
|  | $ | 127,155 |  |  | $ | 127,410 |  |  | $ | 300 |  |  | $ | (46 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 30,405 |  |  | $ | 30,405 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 41,245 |  |  | 41,357 |  |  | 114 |  |  | (1 | ) |
| Marketable securities | 55,505 |  |  | 55,648 |  |  | 186 |  |  | (45 | ) |
|  | $ | 127,155 |  |  | $ | 127,410 |  |  | $ | 300 |  |  | $ | (46 | ) |

[0001078271-12-000048:notes:10]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at June 30, 2012, by contractual maturity, were as follows (in thousands):

[0001078271-12-000048:notes:11]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 23,311 |  |  | $ | 23,357 |  |
| Due in 1-2 years | 52,965 |  |  | 52,994 |  |
| Due in 2-5 years | 22,585 |  |  | 22,568 |  |
| Due in more than 5 years | — |  |  | — |  |
| Total investments in available for sale debt securities | $ | 98,861 |  |  | $ | 98,919 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001078271-12-000048:notes:12]
Basis of Presentation and Summary of Significant Accounting Policies

[0001078271-12-000048:notes:13]
Fiscal Year

[0001078271-12-000048:notes:14]
Effective June 30, 2012, the Company changed their fiscal period to coincide with calendar month-end.  Previously, the Company used a fiscal 52/53 week manufacturing calendar year. Accordingly, the fiscal year ended June 30, 2012 has 52 weeks compared to 53 weeks in 2011 and 52 weeks in fiscal 2010. All references herein to “fiscal 2012” or “2012” represent the fiscal year ended June 30, 2012.

[0001078271-12-000048:notes:15]
Principles of Consolidation

[0001078271-12-000048:notes:16]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001078271-12-000048:notes:17]
The Company uses the U.S. dollar predominately as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States dollars at current rates of exchange; and revenue and expenses are translated using average rates.

[0001078271-12-000048:notes:18]
Accounting Estimates

[0001078271-12-000048:notes:19]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, estimated selling prices, inventory valuation, depreciation and amortization, impairment of long-lived assets, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.

[0001078271-12-000048:notes:20]
Revenue Recognition

[0001078271-12-000048:notes:21]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-12-000048:notes:22]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

[0001078271-12-000048:notes:23]
Pursuant to the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.

[0001078271-12-000048:notes:24]
The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance service contracts, professional services, and training for its products. The Company generally recognizes product revenue from its value-added resellers, non-stocking distributors and end-user customers at the time of shipment, provided that persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and collection of the sales proceeds is reasonably assured. In instances where the criteria for revenue recognition are not met, revenue is deferred until all criteria have been met.  The Company’s total deferred product revenue from customers other than distributors was $2.2 million and $2.0 million as of June 30, 2012 and July 3, 2011, respectively. The Company’s total deferred revenue for services, primarily from service contracts, was $37.7 million as of June 30, 2012 and $36.0 million as of July 3, 2011. Shipping costs are included in cost of product revenues. Sales taxes collected from customers that are excluded from revenues.

[0001078271-12-000048:notes:25]
The Company sells its products and maintenance service contracts to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The Company defers recognition of revenue on all sales to its stocking distributors until the distributors sell the product, as evidenced by “sales-out” reports that the distributors provide. The Company grants these distributors the right to return a portion of unsold inventory for the purpose of stock rotation and certain price protection rights. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. The Company also provides distributors with credits for changes in selling prices based on competitive conditions, and allows distributors to participate in cooperative marketing programs. The Company maintains estimated accruals and allowances for these exposures based upon the Company's historical experience. In connection with cooperative advertising programs, the Company does not meet the criteria for recognizing the expenses as marketing expenses and accordingly, the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001078271-12-000048:notes:26]
The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users. For product sales to non-stocking distributors and value-added resellers, the Company does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Accordingly, the Company recognizes revenue upon transfer of title and risk of loss or damage, generally upon shipment. The Company reduces product revenue for cooperative marketing activities and certain price protection rights that may occur under contractual arrangements with its resellers.

[0001078271-12-000048:notes:27]
The Company provides an allowance for sales returns based on its historical returns, analysis of credit memo data and its return policies. The allowance for sales returns was $1.3 million and $0.6 million as of June 30, 2012 and July 3, 2011, respectively, for estimated future returns that were recorded as a reduction of our accounts receivable. If the historical data that the Company uses to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. The Company estimates and adjusts this allowance at each balance sheet date.

[0001078271-12-000048:notes:28]
Cash Equivalents, Short-Term Investments and Marketable Securities

[0001078271-12-000048:notes:29]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with maturities of greater than three months, but less than one year at the balance sheet date are classified as Short Term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

[0001078271-12-000048:notes:30]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value. The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001078271-12-000048:notes:31]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. Realized gains or losses recognized on the sale of investments were not significant for fiscal 2012, 2011 or fiscal 2010. As of June 30, 2012, there were twenty-one out of fifty-five investment securities that had unrealized losses. The unrealized gains / (losses) on the Company’s investments were caused by interest rate fluctuations. Substantially all of the Company’s available-for-sale investments are investment grade government and corporate debt securities that have maturities of less than three years. The Company does not intend to sell the investments and it is not more likely than not that the Company will be required to sell the investments before recovery of its amortized costs.

[0001078271-12-000048:notes:32]
Fair Value of Financial Instruments

[0001078271-12-000048:notes:33]
The Company measures certain financial assets and liabilities at fair value on a recurring basis, including cash equivalents, available-for-sale securities, trading securities and foreign currency derivatives. Fair value is measured based on a fair value hierarchy following three levels of inputs, of which the first two are considered observable and the last unobservable:

[0001078271-12-000048:notes:34]
| • Level 1 |  |  | Quoted prices in active markets for identical assets or liabilities; |
| • Level 2 |  |  | Inputs other than Level 1 that are observable, either directly or indirectly, such as quoted prices for similar assets or liabilities; quoted prices in markets that are not active; or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities; and |
| • Level 3 |  |  | Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. |

[0001078271-12-000048:notes:35]
The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis:

[0001078271-12-000048:notes:36]
| June 30, 2012 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Municipal bonds | $ | — |  |  | $ | 2,736 |  |  | $ | — |  |  | $ | 2,736 |  |
| Federal agency notes | — |  |  | 11,234 |  |  | — |  |  | 11,234 |  |
| Money market funds | 36,141 |  |  | — |  |  | — |  |  | 36,141 |  |
| Corporate notes/bonds | — |  |  | 84,949 |  |  | — |  |  | 84,949 |  |
| Foreign currency forward contracts | — |  |  | 179 |  |  | — |  |  | 179 |  |
| Total | $ | 36,141 |  |  | $ | 99,098 |  |  | $ | — |  |  | $ | 135,239 |  |

[0001078271-12-000048:notes:37]
| July 3, 2011 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Federal agency notes | $ | — |  |  | $ | 7,756 |  |  | $ | — |  |  | $ | 7,756 |  |
| Money market funds | 30,405 |  |  | — |  |  | — |  |  | 30,405 |  |
| Corporate notes/bonds | — |  |  | 89,249 |  |  | — |  |  | 89,249 |  |
| Total | $ | 30,405 |  |  | $ | 97,005 |  |  | $ | — |  |  | $ | 127,410 |  |
| Liabilities |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |
| Total | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |

[0001078271-12-000048:notes:38]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. As of June 30, 2012 and July 3, 2011, the Company had no assets or liabilities classified within Level 3. There were no transfers of assets or liabilities between Level 1 and Level 2 during the fiscal 2012.

[0001078271-12-000048:notes:39]
Concentrations

[0001078271-12-000048:notes:40]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting principally of marketable investments and accounts receivable. The Company has placed its investments with high-credit quality issuers. The Company does not invest an amount exceeding 10% of its combined cash, cash equivalents, short-term investments and marketable securities in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001078271-12-000048:notes:41]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001078271-12-000048:notes:42]
The following table sets forth major customers accounting for 10% or more of our net revenue. The amounts for the fiscal year ended July 3, 2011 and June 27, 2010 have been revised to correct previously disclosed amounts:

[0001078271-12-000048:notes:43]
|  |  | Fiscal Year Ended |
|  |  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Westcon Group Inc. |  | 19 | % |  | 16 | % |  | 16 | % |
| Scansource, Inc. |  | 13 | % |  | 14 | % |  | 13 | % |
| Ericsson AB |  | 12 | % |  | 11 | % |  | * |  |
| Tech Data Corporation |  | * |  |  | 11 | % |  | 12 | % |
| * Less than 10% of revenue |  |  |  |  |  |  |

[0001078271-12-000048:notes:44]
The following table sets forth major customers accounting for 10% or more of our accounts receivable balance. The amounts for the fiscal year ended July 3, 2011 have been revised to correct previously disclosed amounts:

[0001078271-12-000048:notes:45]
|  |  | June 30, 2012 |  | July 3, 2011 |
| Ericsson AB |  | 21 | % |  | 18 | % |
| Westcon Group Inc. |  | 16 | % |  | * |  |
| Scansource, Inc. |  | * |  |  | 18 | % |
| * Less than 10% of accounts receivable |  |  |  |  |

[0001078271-12-000048:notes:46]
Accounts Receivable and Allowance for Doubtful Accounts

[0001078271-12-000048:notes:47]
Accounts receivable are recorded at the invoiced amount and do not bear interest. Substantially all receivables were trade receivables as of June 30, 2012 and July 3, 2011.

[0001078271-12-000048:notes:48]
The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. The Company records specific allowances for bad debts in general and administrative expense when the Company becomes aware of a specific customer’s inability to meet its financial obligation to it, such as in the case of bankruptcy filings or deterioration of financial position. The Company writes-off receivables to the allowance after all collection efforts are exhausted. Estimates are used in determining the Company’s allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan, to pay cash in advance or secure letters of credit when placing an order with it.

[0001078271-12-000048:notes:49]
Inventories

[0001078271-12-000048:notes:50]
Inventory is stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company reduces the carrying value of inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross profit for any of the periods disclosed.

[0001078271-12-000048:notes:51]
Inventories at June 30, 2012 and July 3, 2011, respectively, were (in thousands):

[0001078271-12-000048:notes:52]
|  | June 30, 2012 |  | July 3, 2011 |
| Inventory | $ | 27,964 |  |  | $ | 26,487 |  |
| Less: Excess and Obsolete Inventory | 1,355 |  |  | 4,904 |  |
| Inventory, net | $ | 26,609 |  |  | $ | 21,583 |  |

[0001078271-12-000048:notes:53]
Assets Held for Sale

[0001078271-12-000048:notes:54]
On September 23, 2010, the Company entered into an Option Agreement with Trumark Companies LLC (“Trumark”), under which the Company granted Trumark an option (the “Option”) to purchase half of its corporate headquarters campus in Santa Clara, California (First Property), at a price of $24.0 million. On January 25th the Company entered into a new option to purchase the remaining property.  Under the agreements, Trumark will have until December 18, 2012 to exercise the options to purchase the First Property and may extend the option if they make certain payments to the Company. In January 2012, the Company classified the First Property as “assets held for sale” on the consolidated balance sheet at a net book value of $17.1 million, which was the lesser of the fair value (less cost to sell) or carrying amount of the assets, and ceased recognizing depreciation expense on the assets. During the third quarter of fiscal 2012, Company entered into a new Option Agreement with Trumark, under which it granted Trumark an option to purchase the remaining portion of the Company's corporate campus (Second Property). The Second Property is included as part of the Property and Equipment, classified as 'assets held for use', due to certain unresolved contingencies.

[0001078271-12-000048:notes:55]
Long-Lived Assets

[0001078271-12-000048:notes:56]
Long-lived assets include (a) property and equipment, (b) intangible assets, and (c) service inventory.  Property and equipment, and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. The Company reduces the carrying value of service inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts.

[0001078271-12-000048:notes:57]
(a) Property and Equipment, Net

[0001078271-12-000048:notes:58]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets, with the exception of land, which is not depreciated. Estimated useful lives of 25 years are used for buildings. Estimated useful lives of one to four years are used for computer equipment and software. Estimated useful lives of three years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years). Property and equipment consist of the following (in thousands):

[0001078271-12-000048:notes:59]
|  | June 30, 2012 |  | July 3, 2011 |
| Computer equipment | $ | 42,771 |  |  | $ | 51,806 |  |
| Land | 10,300 |  |  | 20,600 |  |
| Buildings and improvements | 9,581 |  |  | 19,213 |  |
| Purchased software | 11,961 |  |  | 12,176 |  |
| Office equipment, furniture and fixtures | 3,201 |  |  | 3,774 |  |
| Leasehold improvements | 5,467 |  |  | 5,736 |  |
|  | 83,281 |  |  | 113,305 |  |
| Less: accumulated depreciation and amortization | (58,101 | ) |  | (71,428 | ) |
| Property and equipment, net | $ | 25,180 |  |  | $ | 41,877 |  |

[0001078271-12-000048:notes:60]
On January 25, 2012, Company entered into a new Option Agreement with Trumark, under which it granted Trumark an option to purchase the remaining portion of the Company's corporate campus (Second Property), at a price of $24.5 million.  Under the agreement, Trumark will have until December 28, 2012 to exercise the options to purchase the Second Property and may extend the option if they make certain payments to the Company. As of June 30, 2012, the Company had received option payments totaling $2.0 million from Trumark, which were classified as a deferred gain and included in other current liabilities on the consolidated balance sheet. As of June 30, 2012, the Second Property, with a net book value of $16.0 million, remains classified as “assets held for use” due to certain unresolved contingencies that may delay the completion date of this transaction, including the Company's execution of an agreement with Trumark to lease back the Second Property.

[0001078271-12-000048:notes:61]
(b) Intangible Assets

[0001078271-12-000048:notes:62]
The following tables summarize the components of gross and net intangible asset balances (in thousands):

[0001078271-12-000048:notes:63]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| June 30, 2012 |  |  |  |  |  |  |  |
| Patents | 7.4 years |  | $ | 1,800 |  |  | $ | 669 |  |  | $ | 1,131 |  |
| License Agreements | 9.3 years |  | 10,158 |  |  | 6,231 |  |  | 3,927 |  |
| Other Intangibles | 0.3 years |  | 324 |  |  | 276 |  |  | 48 |  |
|  |  |  | $ | 12,282 |  |  | $ | 7,176 |  |  | $ | 5,106 |  |

[0001078271-12-000048:notes:64]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| July 3, 2011 |  |  |  |  |  |  |  |
| Patents | 7.7 years |  | $ | 1,800 |  |  | $ | 387 |  |  | $ | 1,413 |  |
| License Agreements | 6.5 years |  | 8,140 |  |  | 4,788 |  |  | 3,352 |  |
| Other Intangibles | 1.2 years |  | 324 |  |  | 183 |  |  | 141 |  |
|  |  |  | $ | 10,264 |  |  | $ | 5,358 |  |  | $ | 4,906 |  |

[0001078271-12-000048:notes:65]
Amortization expense was $1.8 million, $2.1 million, and $1.3 million in fiscal 2012, 2011, and 2010, respectively.  Amortization expense expected to be recorded for each of the next five years is as follows (in thousands):

[0001078271-12-000048:notes:66]
| For the fiscal year ending: |  |
| 2013 | $ | 1,427 |  |
| 2014 | 834 |  |
| 2015 | 438 |  |
| 2016 | 308 |  |
| 2017 | 282 |  |
| Thereafter | 1,817 |  |
| Total | $ | 5,106 |  |

[0001078271-12-000048:notes:67]
(c) Service Inventory

[0001078271-12-000048:notes:68]
The Company holds service inventory to support customers who have purchased long term service contracts with a hardware replacement element.

[0001078271-12-000048:notes:69]
|  | June 30, 2012 |  | July 3, 2011 |
| Service Inventory | $ | 13,109 |  |  | $ | 13,555 |  |
| Less: Excess and Obsolete Inventory | 5,074 |  |  | 3,976 |  |
| Service Inventory, Net | $ | 8,035 |  |  | $ | 9,579 |  |

[0001078271-12-000048:notes:70]
Deferred Revenue, Net

[0001078271-12-000048:notes:71]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue where the revenue recognition criteria have not been met related to sales by the Company to its resellers or directly to its end-customers. Product revenue includes shipments to end-users and value-add resellers. The following table summarizes deferred revenue, net at the end of fiscal 2012 and 2011, respectively (in thousands):

[0001078271-12-000048:notes:72]
|  | June 30, 2012 |  | July 3, 2011 |
| Deferred services | $ | 37,708 |  |  | $ | 36,025 |  |
| Deferred product: |  |  |  |
| Deferred revenue | 2,236 |  |  | 1,984 |  |
| Deferred cost of sales | (616 | ) |  | (1,036 | ) |
| Deferred product revenue, net | 1,620 |  |  | 948 |  |
| Balance at end of period | 39,328 |  |  | 36,973 |  |
| Less: current portion | 31,769 |  |  | 29,613 |  |
| Non-current deferred revenue, net | $ | 7,559 |  |  | $ | 7,360 |  |

[0001078271-12-000048:notes:73]
The Company offers renewable support arrangements, including extended warranty contracts, to its customers that range generally from one to five years. Deferred support revenue is included within deferred revenue, net within the Services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-12-000048:notes:74]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |
| Balance beginning of period | $ | 35,802 |  |  | $ | 36,193 |  |
| New support arrangements | 59,313 |  |  | 58,150 |  |
| Recognition of support revenue | (57,654 | ) |  | (58,541 | ) |
| Balance end of period | 37,461 |  |  | 35,802 |  |
| Less: current portion | 29,902 |  |  | 28,442 |  |
| Non-current deferred revenue | $ | 7,559 |  |  | $ | 7,360 |  |

[0001078271-12-000048:notes:75]
Deferred Distributors Revenue, Net of Cost of Sales to Distributors

[0001078271-12-000048:notes:76]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay on a current basis for product delivered, the Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its consolidated balance sheets. Deferred distributors revenue, net of cost of sales to distributors effectively represents the gross margin on the sale to the distributor; however, the amount of gross margin the Company recognizes in future periods will frequently be less than the originally recorded deferred distributors revenue, net of cost of sales to distributors as a result of price concessions negotiated at time of sell-through to end customers. The Company sells each item in its product catalog to all of its distributors worldwide at contractually discounted prices. However, distributors resell the Company’s products to end customers at a very broad range of individually negotiated price points based on customer, product, quantity, geography, and other competitive conditions which results in the Company remitting back to the distributors a portion of their original purchase price after the resale transaction is completed. Thus, a portion of the deferred revenue balance represents a portion of distributors’ original purchase price that will be remitted back to the distributors in the future. The wide range and variability of negotiated price credits granted to distributors does not allow the Company to accurately estimate the portion of the balance in the deferred revenue that will be remitted to the distributors. Therefore, the Company does not reduce deferred revenue by anticipated future price credits; instead, price credits are recorded against revenue when incurred, which is generally at the time the distributor sells the product.

[0001078271-12-000048:notes:77]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at the end of fiscal 2012 and 2011, respectively (in thousands):

[0001078271-12-000048:notes:78]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |
| Deferred revenue | $ | 20,361 |  |  | $ | 22,454 |  |
| Deferred cost of Sales | (5,042 | ) |  | (5,902 | ) |
| Total deferred distributors revenue, net of cost of sales to distributors | $ | 15,319 |  |  | $ | 16,552 |  |

[0001078271-12-000048:notes:79]
Guarantees and Product Warranties

[0001078271-12-000048:notes:80]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during fiscal 2012 and fiscal 2011:

[0001078271-12-000048:notes:81]
|  | Year ended |
|  | June 30, 2012 |  | July 3, 2011 |
| Balance beginning of period | $ | 2,640 |  |  | $ | 3,169 |  |
| New warranties issued | 3,117 |  |  | 2,351 |  |
| Warranty expenditures | (2,886 | ) |  | (2,880 | ) |
| Balance end of period | $ | 2,871 |  |  | $ | 2,640 |  |

[0001078271-12-000048:notes:82]
The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001078271-12-000048:notes:83]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001078271-12-000048:notes:84]
Other Accrued Liabilities

[0001078271-12-000048:notes:85]
The following are the components of other accrued liabilities (in thousands):

[0001078271-12-000048:notes:86]
|  | June 30, 2012 |  | July 3, 2011 |
| Accrued general and administrative costs | $ | 1,599 |  |  | $ | 5,373 |  |
| Other accrued liabilities | 11,881 |  |  | 13,677 |  |
| Total | $ | 13,480 |  |  | $ | 19,050 |  |

[0001078271-12-000048:notes:87]
Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. All other advertising costs are expensed as incurred. Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Otherwise, such cooperative advertising obligations with customers are recorded as a reduction of revenue. Advertising expenses were $0.5 million, $0.6 million, and $0.1 million, respectively, in fiscal 2012, fiscal 2011, and fiscal 2010.

[0001078271-12-000048:notes:88]
Impact of Recently Issued Accounting Standards

[0001078271-12-000048:notes:89]
In June 2011, the FASB issued ASU 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires one of two alternatives for presenting comprehensive income and eliminates the option to report other comprehensive income and its components as a part of the Consolidated Statements of Stockholders' Equity. Additionally, ASU 2011-05 requires presentation on the face of the financial statements reclassification adjustments for items that are reclassified from other comprehensive income to net income in the statement(s) where the components of net income and the components of other comprehensive income are presented. The requirement related to the reclassification adjustments from other comprehensive income to net income was deferred in December 2011, as a result of the issuance of ASU 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update 2011-05 (Topic 220). The amendments in ASU 2011-05, as amended by ASU 2011-12, do not change the items that must be reported in other comprehensive income or when an item of other comprehensive income must be reclassified to net income. ASU 2011-05, as amended by ASU 2011-12 is effective for fiscal years and interim periods within those years beginning after December 15, 2011 and is to be applied retrospectively. We will adopt ASU 2011-05 during the first quarter of fiscal 2013. We do not expect the adoption of ASU 2011-05, as amended by ASU 2011-12 to have a material impact on our Consolidated Financial Statements.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001078271-12-000048:notes:90]
Description of Business

[0001078271-12-000048:notes:91]
Extreme Networks, Inc. (“Extreme Networks” or “the Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.


## us-gaap:CollaborativeArrangementDisclosureTextBlock

[0001078271-12-000048:notes:92]
Technology Agreements

[0001078271-12-000048:notes:93]
On March 31, 2005, the Company entered into a Patent and Cross License Agreement (“Technology Agreement”) with IBM. The agreement provides for a release of prior claims and a cross license of patents extending into the future from the effective date of the agreement. On December 22, 2008, the Company amended the Technology Agreement to extend the term of the agreement over the remaining life of the patents. The Company capitalized the cost of the amendment in other assets and continued to amortize the remaining cost of the Technology Agreement and its amendment over the remaining life of the patents.

[0001078271-12-000048:notes:94]
On July 16, 2010, the Company entered into a Memorandum of Understanding (“Network-1 MOU”) with Network-1 Security Solutions, Inc. The Network-1 MOU provides for a nonexclusive and worldwide license to certain patents of each party, and a release of claims based on any prior infringement of such patents. The license term is nine years and eight months and expires in March 2020. The release covers any potential claims arising out of the past use or practice of any of the patents. Total fees for the grant of the license under the Network-1 MOU were $2.4 million. The Company charged the estimated value of the release of prior claims of $0.2 million to Cost of Product Revenues for claims incurred in fiscal 2010 and $0.8 million to Litigation Settlement for claims incurred prior to fiscal 2010 in its fiscal 2010 consolidated financial statements. The remaining $1.4 million was recorded as other assets and is being recognized ratably over the license period in cost of product revenue.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-12-000048:notes:95]
Commitments, Contingencies and Leases

[0001078271-12-000048:notes:96]
Leases

[0001078271-12-000048:notes:97]
The Company leases office space for its various United States and international sales offices. Certain leases contain rent escalation clauses and renewal options. The Company subleases certain of its leased facilities to third party tenants. Future annual minimum lease payments under all non-cancelable operating leases having initial or remaining lease terms in excess of one year at June 30, 2012 were as follows (in thousands):

[0001078271-12-000048:notes:98]
|  | Future LeasePayments |
| Fiscal 2013 | $ | 3,528 |  |
| Fiscal 2014 | 2,267 |  |
| Fiscal 2015 | 1,298 |  |
| Fiscal 2016 | 692 |  |
| Fiscal 2017 | 506 |  |
| Thereafter | 807 |  |
| Total minimum payments | $ | 9,098 |  |

[0001078271-12-000048:notes:99]
Rent expense, was approximately $4.3 million in fiscal 2012, $4.3 million in fiscal 2011, and $4.2 million in fiscal 2010.

[0001078271-12-000048:notes:100]
Purchase Commitments

[0001078271-12-000048:notes:101]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2012, the Company had non-cancelable commitments to purchase approximately $38.8 million of such inventory during the first quarter of fiscal 2013.

[0001078271-12-000048:notes:102]
Legal Proceedings

[0001078271-12-000048:notes:103]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-12-000048:notes:104]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-12-000048:notes:105]
Intellectual Property Litigation

[0001078271-12-000048:notes:106]
Enterasys Networks

[0001078271-12-000048:notes:107]
On April 20, 2007, the Company filed suit against Enterasys Networks in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded it damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.  On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Both parties filed post-trial motions, including motions for a new trial, for judgment as a matter of law and for attorneys fees, all of which the Court denied on July 11, 2012. Enterasys did not file a notice of appeal by the August 10, 2012 deadline.  Consequently, the judgment of non-infringement is final.

[0001078271-12-000048:notes:108]
On June 21, 2005, Enterasys filed suit against Extreme and Foundry Networks, Inc. (“Foundry”) in the United States District Court for the District of Massachusetts, Civil Action No. 05-11298 DPW. The complaint alleges willful infringement of U.S. Patent Nos. 5,251,205; 5,390,173; 6,128,665; 6,147,995; 6,539,022; and 6,560,236, and seeks: a) a judgment that the Company willfully infringes each of the patents; (b) a permanent injunction from infringement, inducement of infringement and contributory infringement of each of the six patents; (c) damages and a “reasonable royalty” to be determined at trial; (d) treble damages; (e) attorneys' fees, costs and interest; and (f) equitable relief at the Court's discretion. Petitions for reexamination were filed challenging five of the patents at issue to the U.S. Patent and Trademark Office, and a stay of the case was entered. Following the reexamination proceedings, Enterasys withdrew its allegations of infringement as to two of the patents, U.S. Patent Nos. 6,539,022 and 6,560,236. The stay was lifted on May 21, 2010, and the Court held claim construction hearings in December 2010. Fact discovery is ongoing. No trial date has been set. The Company intends to defend the lawsuit vigorously, but, due to the inherent uncertainties of litigation, it cannot predict the ultimate outcome of the matter at this time.

[0001078271-12-000048:notes:109]
Chrimar Systems

[0001078271-12-000048:notes:110]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 ("the Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.

[0001078271-12-000048:notes:111]
On November 1, 2011, Chrimar filed a complaint with the International Trade Commission, pursuant to Section 337 of the Tariff Act of 1930, as amended, alleging that the Company imports into the United States, sells for importation and/or sells within the United States after importation of products and/or systems infringing U.S. Patent No. 7,457,250 patent, the same patent asserted in the Delaware action.  On December 2, 2011, the International Trade Commission instituted an investigation of these allegations ("the ITC action").  The complaint in the ITC action seeks a permanent order excluding from entry into the United States all infringing articles that are manufactured, imported or sold by the Company that infringe U.S. Patent No. 7,457,250. On July 20, 2012, Chrimar filed a motion to withdraw its complaint in the ITC and the motion was granted on August 1, 2012 by the presiding administrative law judge.  The ALJ's decision is pending review by the ITC Commissioners.

[0001078271-12-000048:notes:112]
During the fourth quarter of the fiscal 2012, the Company engaged in settlement discussions with Chrimar Systems Inc.  As part of the negotiations the Company determined that it is reasonably possible that a range of loss could be between $0.3 million and $1.4 million which is dependent on a number of factors including whether mutually acceptable settlement terms can be reached. As of June 30, 2012 the Company has recorded a charge of $0.3 million as an estimate for the probable loss in the matter.

[0001078271-12-000048:notes:113]
Other Legal Matters

[0001078271-12-000048:notes:114]
Beginning on July 6, 2001, purported securities fraud class action complaints were filed in the United States District Court for the Southern District of New York. The cases were consolidated and the litigation is now captioned as In re Extreme Networks, Inc. Initial Public Offering Securities Litigation, Civ. No. 01-6143 (SAS) (S.D.N.Y.), related to In re Initial Public Offering Securities Litigation, 21 MC 92 (SAS) (S.D.N.Y.). The operative amended complaint names us as defendants; six of the Company's present and former officers and/or directors, including its former CEO; and several investment banking firms that served as underwriters of its initial public offering and October 1999 secondary offering. The complaint alleges liability under Sections 11 and 15 of the Securities Act of 1933 and Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, on the grounds that the registration statement for the offerings did not disclose that: (1) the underwriters had agreed to allow certain customers to purchase shares in the offerings in exchange for excess commissions paid to the underwriters; and (2) the underwriters had arranged for certain customers to purchase additional shares in the after-market at predetermined prices. Similar allegations were made in other lawsuits challenging over 300 other initial public offerings and follow-on offerings conducted in 1999 and 2000. The cases were consolidated for pretrial purposes. The parties to the lawsuits have reached a settlement, which was approved by the Court on October 6, 2009. Extreme Networks is not required to make any cash payments in the settlement. The Court subsequently entered a final judgment of dismissal. Certain objectors appealed the judgment. Subsequently, the District Court ruled that all objectors lacked standing to appeal. One of the objectors appealed that ruling. In January 2012, the Court dismissed the pending appeal and the case has concluded. The Company has no financial liability associated with the settlement.

[0001078271-12-000048:notes:115]
Indemnification Obligations

[0001078271-12-000048:notes:116]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-12-000048:notes:117]
Foreign Exchange Forward Contracts

[0001078271-12-000048:notes:118]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in Japanese Yen, the Euro, the Swedish Krona, the Indian Rupee and the British Pound. These derivatives do not qualify as hedges. At June 30, 2012, these forward foreign currency contracts had a notional principal amount of $16.9 million and unrealized gains on foreign exchange contracts of $0.2 million. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-12-000048:notes:119]
Foreign currency transaction gains and losses from operations were a gain of $2.5 million in fiscal 2012, a loss of $0.6 million in fiscal 2011 and a loss of $0.4 million in fiscal 2010.  Included is the 2012 gain is the $1.9 million adjustment resulting from Japan subsidiary liquidation.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-12-000048:notes:120]
Employee Benefit Plans (including Share-based Compensation)

[0001078271-12-000048:notes:121]
As of June 30, 2012, the Company has the following share-based compensation plans:

[0001078271-12-000048:notes:122]
2005 Equity Incentive Plan

[0001078271-12-000048:notes:123]
The 2005 Equity Incentive Plan (the “2005 Plan”) was adopted by the Company’s Board of Directors on October 20, 2005, and approved by stockholders on December 2, 2005. The 2005 Plan replaces the 1996 Stock Option Plan (the “1996 Plan”), 2000 Non-statutory Stock Option Plan (the “2000 Plan”) and 2001 Non-statutory Stock Option Plan (the “2001 Plan”).

[0001078271-12-000048:notes:124]
Under the 2005 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2005 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2005 Plan authorizes the issuance of up to 12,000,000 shares of the Company’s common stock and on December 23, 2009, the Company’s shareholders approved to increase the number of shares authorized by another 4,000,000 shares. In addition, up to 11,000,000 shares subject to awards outstanding under the 1996 Plan, the 2000 Plan, and the 2001 Plan that expired have been added to the number of shares available for future grant under the 2005 Plan. As of June 30, 2012, total options and awards to acquire 10,022,770 shares were outstanding under the 2005 Plan and 9,873,560 shares are available for grant under the 2005 Plan. Options granted under this plan have a contractual term of seven years.

[0001078271-12-000048:notes:125]
Amended 1996 Stock Option Plan

[0001078271-12-000048:notes:126]
The 1996 Plan was originally adopted in September 1996, and provided for the grant of options for common stock to eligible participants. A total of 56,382,867 shares were reserved under the 1996 Plan. Options granted under this plan have a contractual term of ten years. Effective December 2, 2005, the 1996 Plan was terminated, and, as of June 30, 2012, options to acquire 1,049,308 shares were outstanding under the 1996 Plan.

[0001078271-12-000048:notes:127]
2000 Plan

[0001078271-12-000048:notes:128]
In March 2000, the Board of Directors adopted the 2000 Plan which provided for the grant of options for common stock to eligible participants. A total of 4,000,000 shares were reserved under the 2000 Plan. Options granted under this plan have a contractual term of ten years. Effective December 2, 2005, the 2000 Plan was terminated, and, as of June 30, 2012, options to acquire 74,002 shares were outstanding under the 2000 Plan.

[0001078271-12-000048:notes:129]
2001 Plan

[0001078271-12-000048:notes:130]
In May 2001, the Board of Directors adopted the 2001 Plan which provided for the grant of options for common stock to eligible participants. A total of 4,000,000 shares were reserved under the 2001 Plan. Options granted under this plan have a contractual term of ten years. Effective December 2, 2005, the 2001 Plan was terminated, and, as of June 30, 2012, options to acquire 28,740 shares were outstanding under the 2001 Plan.

[0001078271-12-000048:notes:131]
The following table summarizes stock option activity under all plans:

[0001078271-12-000048:notes:132]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value($ 000’s) |
| Options outstanding at June 28, 2009 | 17,639 |  |  | $ | 4.65 |  |  |  |  |  |
| Granted | 936 |  |  | $ | 2.31 |  |  |  |  |  |
| Exercised | (337 | ) |  | $ | 2.20 |  |  |  |  |  |
| Canceled | (8,652 | ) |  | $ | 4.94 |  |  |  |  |  |
| Options outstanding at June 27, 2010 | 9,586 |  |  | $ | 4.24 |  |  |  |  |  |
| Granted | 2,748 |  |  | $ | 3.28 |  |  |  |  |  |
| Exercised | (606 | ) |  | $ | 2.52 |  |  |  |  |  |
| Canceled | (2,596 | ) |  | $ | 4.40 |  |  |  |  |  |
| Options outstanding at July 3, 2011 | 9,132 |  |  | $ | 4.01 |  |  |  |  |  |
| Granted | 2,593 |  |  | $ | 3.30 |  |  |  |  |  |
| Exercised | (437 | ) |  | $ | 2.24 |  |  |  |  |  |
| Canceled | (2,282 | ) |  | $ | 4.85 |  |  |  |  |  |
| Options outstanding at June 30, 2012 | 9,006 |  |  | $ | 3.68 |  |  | 4.87 |  |  | 2,280 |  |
| Exercisable at June 30, 2012 | 5,538 |  |  | $ | 3.94 |  |  | 4.20 |  |  | 1,545 |  |
| Vested and expected to vest at June 30, 2012 | 8,697 |  |  | $ | 3.70 |  |  | 4.82 |  |  | 2,226 |  |

[0001078271-12-000048:notes:133]
The following table summarizes significant ranges of outstanding and exercisable options at June 30, 2012:

[0001078271-12-000048:notes:134]
| Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices | NumberOutstanding (000’s) |  | Weighted-AverageRemaining Contractual Life |  | Weighted-AverageExercise Price |  | NumberExercisable (000’s) |  | Weighted-AverageExercise Price |
|  |  |  | (In years) |  |  |  |  |  |  |
| $1.69 – $2.82 | 983 |  |  | 5.93 |  |  | $ | 2.12 |  |  | 904 |  |  | $ | 2.12 |  |
| $2.95 – $3.02 | 249 |  |  | 5.89 |  |  | $ | 2.99 |  |  | 152 |  |  | $ | 3.00 |  |
| $3.03 – $3.03 | 1,217 |  |  | 5.13 |  |  | $ | 3.03 |  |  | 567 |  |  | $ | 3.03 |  |
| $3.17 – $3.25 | 383 |  |  | 4.54 |  |  | $ | 3.21 |  |  | 140 |  |  | $ | 3.17 |  |
| $3.29 – $3.29 | 1,881 |  |  | 6.08 |  |  | $ | 3.29 |  |  | 97 |  |  | $ | 3.29 |  |
| $3.43 – $3.68 | 1,210 |  |  | 4.93 |  |  | $ | 3.61 |  |  | 735 |  |  | $ | 3.58 |  |
| $3.74 – $4.18 | 955 |  |  | 4.71 |  |  | $ | 3.86 |  |  | 864 |  |  | $ | 3.86 |  |
| $4.22 – $4.22 | 7 |  |  | 3.16 |  |  | $ | 4.22 |  |  | 7 |  |  | $ | 4.22 |  |
| $4.25 – $4.25 | 935 |  |  | 4.15 |  |  | $ | 4.25 |  |  | 886 |  |  | $ | 4.25 |  |
| $4.26 – $9.80 | 1,186 |  |  | 2.31 |  |  | $ | 6.05 |  |  | 1,186 |  |  | $ | 6.05 |  |
| $1.69 – $9.80 | 9,006 |  |  | 4.87 |  |  | $ | 3.68 |  |  | 5,538 |  |  | $ | 3.94 |  |

[0001078271-12-000048:notes:135]
The total intrinsic value of options exercised in fiscal 2012, fiscal 2011 and fiscal 2010 were $0.5 million, $0.5 million, and $0.2 million, respectively. The fair value of options vested in fiscal 2012, fiscal 2011 and fiscal 2010 were $2.3 million, $1.0 million, and $1.4 million, respectively.

[0001078271-12-000048:notes:136]
Stock Awards

[0001078271-12-000048:notes:137]
Stock awards may be granted under the 2005 Plan on terms approved by the Board of Directors. Stock awards generally provide for the issuance of restricted stock which vests over a fixed period.

[0001078271-12-000048:notes:138]
The following table summarizes stock award activity:

[0001078271-12-000048:notes:139]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |
| Non-vested stock outstanding at June 28, 2009 | 796 |  |  | $ | 3.37 |  |
| Granted | 2,965 |  |  | $ | 2.77 |  |
| Vested | (702 | ) |  | $ | 2.91 |  |
| Cancelled | (179 | ) |  | $ | 2.40 |  |
| Non-vested stock outstanding at June 27, 2010 | 2,880 |  |  | $ | 2.92 |  |
| Granted | 818 |  |  | $ | 3.18 |  |
| Vested | (1,376 | ) |  | $ | 3.21 |  |
| Cancelled | (452 | ) |  | $ | 3.03 |  |
| Non-vested stock outstanding at July 3, 2011 | 1,870 |  |  | $ | 2.79 |  |
| Granted | 739 |  |  | $ | 3.11 |  |
| Vested | (1,233 | ) |  | $ | 3.28 |  |
| Cancelled | (298 | ) |  | $ | 3.17 |  |
| Non-vested stock outstanding at June 30, 2012 | 1,078 |  |  | $ | 2.35 |  |

[0001078271-12-000048:notes:140]
The shares were placed in an escrow account and will be released to the recipients as the shares vest over periods of up to twenty-four months. If a participant terminates employment prior to the vesting dates, the unvested shares will be canceled and returned to the 2005 Plan. The Company recognizes compensation expense on the awards over the vesting period based on an intrinsic value as of the date of grant. As of June 30, 2012, there were approximately $2.2 million in unrecognized compensation costs related to non-vested stock awards. This cost is expected to be recognized over a weighted-average period of approximately 1.3 years.

[0001078271-12-000048:notes:141]
1999 Employee Stock Purchase Plan

[0001078271-12-000048:notes:142]
In January 1999, the Board of Directors approved the adoption of Extreme Network’s 1999 Employee Stock Purchase Plan (the “Purchase Plan”). On December 2, 2005, the stockholders approved an amendment to the Purchase Plan to increase the maximum number of shares of common stock that may be issued under the plan by 5,000,000 to a total of 12,000,000 shares. The Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation. No more than 625 shares may be purchased on any purchase date per employee. Each offering period has a maximum duration of 3 months. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. On January 26, 2010, the Board of Directors approved an amendment to the Purchase Plan to increase the maximum number of shares that may be purchased on any purchase date per employee from 625 shares to 1,000 shares. Through June 30, 2012, 9,428,787 shares had been purchased under the Purchase Plan.

[0001078271-12-000048:notes:143]
Share Based Compensation

[0001078271-12-000048:notes:144]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (dollars in thousands):

[0001078271-12-000048:notes:145]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Cost of product revenue | $ | 463 |  |  | $ | 435 |  |  | $ | 489 |  |
| Cost of service revenue | 257 |  |  | 232 |  |  | 523 |  |
| Sales and marketing | 1,765 |  |  | 1,948 |  |  | 1,853 |  |
| Research and development | 1,363 |  |  | 1,113 |  |  | 1,695 |  |
| General and administrative | 2,341 |  |  | 1,520 |  |  | 1,675 |  |
| Total share-based compensation expense | 6,189 |  |  | 5,248 |  |  | 6,235 |  |

[0001078271-12-000048:notes:146]
The amount of stock based compensation expense capitalized in inventory has been immaterial for each of the periods presented. As of June 30, 2012, there was $4.3 million of total unrecognized compensation cost related to unvested stock options. This cost is expected to be recognized over a weighted-average period of approximately 2.5 years.

[0001078271-12-000048:notes:147]
The weighted-average grant-date per share fair value of options granted in fiscal 2012, fiscal 2011, and fiscal 2010 were $1.67, $1.57, and $0.94, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) in fiscal 2012, fiscal 2011, and fiscal 2010 were $0.98, $0.98, and $0.66, respectively.

[0001078271-12-000048:notes:148]
The Company uses the straight-line method for expense attribution, and the Company estimates forfeitures and only recognizes expense for those shares expected to vest. The Company’s estimated forfeiture rate in fiscal 2012 based on the Company’s historical forfeiture experience is approximately 9% for non-executives and 7% for executives.

[0001078271-12-000048:notes:149]
The fair value of each option award and share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-12-000048:notes:150]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Year Ended |  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Expected life | 5.06 yrs |  |  | 4.43 yrs |  |  | 3.03 yrs |  |  | .25 yrs |  |  | .24 yrs |  |  | .25 yrs |  |
| Risk-free interest rate | 1.05 | % |  | 1.47 | % |  | 1.36 | % |  | 0.07 | % |  | 0.17 | % |  | 0.20 | % |
| Volatility | 60 | % |  | 62 | % |  | 59 | % |  | 61 | % |  | 55 | % |  | 73 | % |
| Dividend yield | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |  | 0.0 | % |

[0001078271-12-000048:notes:151]
Employee Stock Option Exchange Program

[0001078271-12-000048:notes:152]
On December 23, 2009, the Company’s stockholders approved a voluntary program (“Exchange Program”) that permitted eligible employees to exchange certain outstanding stock options that were “underwater” for a lesser number of shares of restricted stock units to be granted under the Extreme Networks, Inc. 2005 Equity Incentive Plan (the “2005 Plan”) and to exchange certain other stock options that are more substantially underwater for a cash payment. The Exchange Program was open to all of the Company’s United States employees, except for members of its Board of Directors and its executive officers. The Exchange Program commenced on February 4, 2010 and ended March 4, 2010. On March 5, 2010, the Company canceled a total of 3,058,761 tendered stock options, issued a total of 569,189 replacement restricted stock units under the 2005 Plan, and incurred a cash outlay of $8,769 which was paid out at the end of March 2010.

[0001078271-12-000048:notes:153]
401(k) Plan

[0001078271-12-000048:notes:154]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $17,000 for calendar year 2012. Effective January 1, 2005, employees age 50 or over may elect to contribute an additional $5,500. The amount contributed to the Plan is on a pre-tax basis.

[0001078271-12-000048:notes:155]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year.   All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. The program was to match $0.50 for every dollar contributed by the employee up to the first 2.5% of pay. The Company’s matching contributions to the Plan totaled $475,025, $569,825, and $0, for fiscal 2012, fiscal 2011 and fiscal 2010, respectively. No discretionary contributions were made in fiscal 2012, fiscal 2011 and fiscal 2010.


## us-gaap:EarningsPerShareTextBlock

[0001078271-12-000048:notes:156]
Net Income (Loss) Per Share

[0001078271-12-000048:notes:157]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock. The following table presents the calculation of basic and diluted net income per share (in thousands, except per share data):

[0001078271-12-000048:notes:158]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Net income | $ | 15,872 |  |  | $ | 2,713 |  |  | $ | 227 |  |
| Weighted-average shares used in per share calculation – basic | 93,451 |  |  | 91,423 |  |  | 89,281 |  |
| Incremental shares using the treasury stock method: |  |  |  |  |  |
| Stock options | 372 |  |  | 427 |  |  | 171 |  |
| Unvested restricted awards | 554 |  |  | 818 |  |  | 25 |  |
| Employee Stock Purchase Plan | 113 |  |  | 127 |  |  | — |  |
| Weighted -average share used in per share calculation – diluted | 94,490 |  |  | 92,795 |  |  | 89,477 |  |
| Net income per share – basic | 0.17 |  |  | 0.03 |  |  | $ | — |  |
| Net income per share – diluted | 0.17 |  |  | 0.03 |  |  | $ | — |  |

[0001078271-12-000048:notes:159]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For fiscal 2012, 2011, and 2010, the Company excluded 8.3 million, 8.0 million, and 12.2 million outstanding weighted average stock options, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-12-000048:notes:160]
Income Taxes

[0001078271-12-000048:notes:161]
Income (loss) before income taxes is as follows (in thousands):

[0001078271-12-000048:notes:162]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Domestic | $ | 20,839 |  |  | $ | 4,416 |  |  | $ | (10,024 | ) |
| Foreign | (3,771 | ) |  | (704 | ) |  | 9,841 |  |
| Total | $ | 17,068 |  |  | $ | 3,712 |  |  | $ | (183 | ) |

[0001078271-12-000048:notes:163]
The provision for (benefit from) income taxes for fiscal 2012, 2011 and fiscal 2010 consisted of the following (in thousands):

[0001078271-12-000048:notes:164]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Current: |  |  |  |  |  |
| Federal | $ | 114 |  |  | $ | 142 |  |  | $ | (1,062 | ) |
| State | 79 |  |  | 92 |  |  | 106 |  |
| Foreign | 916 |  |  | 1,613 |  |  | 596 |  |
| Total current | 1,109 |  |  | 1,847 |  |  | (360 | ) |
| Deferred: |  |  |  |  |  |
| Federal | 30 |  |  | (639 | ) |  | — |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | 57 |  |  | (209 | ) |  | (50 | ) |
| Total deferred | 87 |  |  | (848 | ) |  | (50 | ) |
| Provision (benefit) for income taxes | $ | 1,196 |  |  | $ | 999 |  |  | $ | (410 | ) |

[0001078271-12-000048:notes:165]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (35 percent) to income (loss) before taxes is explained below (in thousands):

[0001078271-12-000048:notes:166]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Tax at federal statutory rate (benefit) | $ | 5,974 |  |  | $ | 1,299 |  |  | $ | (64 | ) |
| State income tax, net of federal benefit | 51 |  |  | 57 |  |  | 66 |  |
| Valuation allowance | (8,035 | ) |  | (2,492 | ) |  | 607 |  |
| Foreign earnings taxed at other than U.S. rates | 3,607 |  |  | 1,576 |  |  | (3,348 | ) |
| Deferred compensation | 170 |  |  | 398 |  |  | 2,196 |  |
| Other | (571 | ) |  | 161 |  |  | 133 |  |
| Provision for income taxes | $ | 1,196 |  |  | $ | 999 |  |  | $ | (410 | ) |

[0001078271-12-000048:notes:167]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001078271-12-000048:notes:168]
|  | June 30, 2012 |  | July 3, 2011 |
| Deferred tax assets: |  |  |  |
| Net operating loss carry-forwards | $ | 73,413 |  |  | $ | 76,158 |  |
| Tax credit carry-forwards | 23,051 |  |  | 23,335 |  |
| Depreciation | 14,074 |  |  | 16,602 |  |
| Deferred revenue (net) | 8,722 |  |  | 9,160 |  |
| Warrant amortization | 5,489 |  |  | 6,854 |  |
| Inventory write-downs | 2,803 |  |  | 3,685 |  |
| Other allowances and accruals | 2,901 |  |  | 3,579 |  |
| Other | 10,895 |  |  | 11,912 |  |
| Total deferred tax assets | 141,348 |  |  | 151,285 |  |
| Valuation allowance | (140,641 | ) |  | (150,503 | ) |
| Total net deferred tax assets | 707 |  |  | 782 |  |
| Deferred tax liabilities: |  |  |  |
| Deferred tax liability on foreign withholdings | (120 | ) |  | (93 | ) |
| Total deferred tax liabilities | (120 | ) |  | (93 | ) |
| Net deferred tax assets | $ | 587 |  |  | $ | 689 |  |
| Recorded as: |  |  |  |
| Net current deferred tax assets | $ | 644 |  |  | $ | 681 |  |
| Net non-current deferred tax assets | 178 |  |  | 101 |  |
| Net current deferred tax liabilities | (235 | ) |  | — |  |
| Net non-current deferred tax liabilities | — |  |  | (93 | ) |
| Net deferred tax assets (liabilities) | $ | 587 |  |  | $ | 689 |  |

[0001078271-12-000048:notes:169]
The Company's valuation allowance decreased by $9.9 million in fiscal 2012, decreased by $4.6 million in fiscal 2011, and increased by $11.5 million in fiscal 2010. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, and no valuation allowance against any of its non-U.S. deferred tax assets. The valuation allowance is determined by assessing both negative and positive evidence to determine whether it is more likely than not that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis. The Company's U.S. losses in recent periods we believe represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001078271-12-000048:notes:170]
As of June 30, 2012, the Company had net operating loss carry-forwards for federal and state tax purposes of $254.8 million and $90.0 million, respectively, of which $53.7 million and $32.3 million, respectively, represent deductions from share-based compensation for which a benefit would be recorded in additional paid-in capital when realized. The Company also had federal and state tax credit carry-forwards of $10.9 million and $18.7 million, respectively, as of June 30, 2012. Federal net operating loss carry-forwards of $254.8 million will expire between 2020 through 2030 and state net operating losses of $90.0 million will expire between 2013 through 2031, if not utilized. Federal tax credits of $10.9 million will expire beginning in 2020, if not utilized and state tax credits of $0.8 million will expire beginning in 2013, if not utilized. The additional state tax credits of $18.0 million will carry forward indefinitely.

[0001078271-12-000048:notes:171]
As of June 30, 2012, the Company conducted an Internal Revenue Code Section 382 (“Sec. 382”) analysis with respect to its net operating loss and credit carry-forwards and determined that there was no limitation. It is possible that subsequent ownership changes may limit the utilization of these tax attributes.

[0001078271-12-000048:notes:172]
As of June 30, 2012, the Company intends to indefinitely reinvest the earnings of certain foreign corporations. If such earnings were distributed, the Company would accrue an additional income tax expense of approximately $1.0 million.

[0001078271-12-000048:notes:173]
As of June 30, 2012, the Company had $25.7 million of unrecognized tax benefits. If fully recognized in the future, $0.5 million would impact the effective tax rate, and $25.2 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-12-000048:notes:174]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001078271-12-000048:notes:175]
| Balance at June 28, 2009 | $ | 22,578 |  |
| Decrease related to prior year tax positions | (98 | ) |
| Increases related to prior year tax positions | 1,094 |  |
| Increases related to current year tax positions | 1,414 |  |
| Lapse of statute of limitations | (1,078 | ) |
| Balance at June 27, 2010 | $ | 23,910 |  |
| Increase related to prior year tax positions | 464 |  |
| Increase related to current year tax positions | 1,636 |  |
| Balance at July 3, 2011 | $ | 26,010 |  |
| Decrease related to prior year tax positions | (444 | ) |
| Increase related to current year tax positions | 729 |  |
| Lapse of statute of limitations | (549 | ) |
| Balance at June 30, 2012 | $ | 25,746 |  |

[0001078271-12-000048:notes:176]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Consolidated Statement of Operations and totaled approximately $28,000, $30,000, and $72,000 for the years ended June 30, 2012, July 3, 2011, and June 27, 2010, respectively. Accrued interest and penalties were approximately $77,000 and $222,000 as of June 30, 2012 and July 3, 2011, respectively.

[0001078271-12-000048:notes:177]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 1999 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2001 forward due to net operating losses.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001078271-12-000048:notes:178]
Quarterly Financial Data (Unaudited)

[0001078271-12-000048:notes:179]
Quarterly results for the years ended June 30, 2012 and July 3, 2011 follow:

[0001078271-12-000048:notes:180]
|  | June 30,2012(1) |  | April 1,2012(2) |  | January 1,2012(3) |  | Oct 2,2011(4) |
|  | (In thousands, except per share amounts) |
| Net revenues | $ | 87,649 |  |  | $ | 73,368 |  |  | $ | 82,812 |  |  | $ | 78,894 |  |
| Gross profit | $ | 48,833 |  |  | $ | 41,211 |  |  | $ | 46,268 |  |  | $ | 43,536 |  |
| Net income | $ | 7,812 |  |  | $ | 2,372 |  |  | $ | 4,107 |  |  | $ | 1,583 |  |
| Net income per share – basic | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.04 |  |  | $ | 0.02 |  |
| Net income per share – diluted | $ | 0.08 |  |  | $ | 0.03 |  |  | $ | 0.04 |  |  | $ | 0.02 |  |
|  | July 3,2011(5) |  | March 27,2011(6) |  | Dec 26,2010(7) |  | Sept 26,2010 |
|  | (In thousands, except per share amounts) |
| Net revenues | $ | 89,761 |  |  | $ | 75,699 |  |  | $ | 85,131 |  |  | $ | 83,837 |  |
| Gross profit | $ | 48,581 |  |  | $ | 36,563 |  |  | $ | 47,981 |  |  | $ | 46,837 |  |
| Net (loss) income | $ | (2,087 | ) |  | $ | (6,841 | ) |  | $ | 8,929 |  |  | $ | 2,712 |  |
| Net (loss) income per share – basic | $ | (0.02 | ) |  | $ | (0.07 | ) |  | $ | 0.10 |  |  | $ | 0.03 |  |
| Net (loss) income per share – diluted | $ | (0.02 | ) |  | $ | (0.07 | ) |  | $ | 0.10 |  |  | $ | 0.03 |  |

[0001078271-12-000048:notes:181]
____________________

[0001078271-12-000048:notes:182]
| (1) | Net income and net income per share include the effect of restructuring charge of $0.2 million, litigation settlement of $0.1 million and CTA gain of $1.9 million from Japan subsidiary liquidation |

[0001078271-12-000048:notes:183]
| (2) | Net income and net income per share include the effect of restructuring reversal of $35,000. |

[0001078271-12-000048:notes:184]
| (3) | Net income and net income per share include the effect of restructuring charge of $0.4 million. |

[0001078271-12-000048:notes:185]
| (4) | Net income and net income per share include the effect of restructuring charge of $1.0 million. |

[0001078271-12-000048:notes:186]
| (5) | Net loss and net loss per share include the effect of restructuring charge of $2.8 million. |

[0001078271-12-000048:notes:187]
| (6) | Net loss and net loss per share include the effect of restructuring charge of $1.0 million and litigation settlement of $49,000. |

[0001078271-12-000048:notes:188]
| (7) | Net income and net income per share include the effect of litigation settlement of $4.2 million. |

[0001078271-12-000048:notes:189]
Quarterly and year-to-date computations of per share amounts are made independently. Therefore, the sum of per share amounts for the quarters may not agree with per share amounts for the year.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-12-000048:notes:190]
Restructuring Charges

[0001078271-12-000048:notes:191]
As of June 30, 2012, restructuring liabilities were $0.5 million and consisted of obligations under excess facility operating leases, net of projected future sublease receipts and termination benefits. During fiscal 2012, 2011 and 2010, the Company recorded a restructuring charge of $1.6 million, restructuring charge of $3.8 million, and restructuring charge of $4.2 million, respectively.  A portion of this restructuring activity is related to the liquidation of the Company's Japan subsidiary with a cost of $0.5 million at June 30, 2012. The Company substantially liquidated the subsidiary in Japan in the fourth quarter or fiscal 2012, as part of the Company's broad restructuring effort. The Company will dispose the remaining immaterial assets and liabilities and complete the liquidation process by the end of fiscal 2013.

[0001078271-12-000048:notes:192]
Fiscal 2012 Restructuring

[0001078271-12-000048:notes:193]
During fiscal 2012, the Company incurred total charges of $2.2 million, including $1.8 million of related severance, $0.1 million of contract termination fees, and $0.2 million other charges. The Company also made payments of $4.3 million. The associated restructuring costs were primarily termination benefits and contract termination costs. Termination benefits primarily consist of outplacement services, health insurance coverage, and legal costs. Contract termination costs primarily consist of costs to terminate operating leases and other contracts, including rent expense (less expected sublease income) on facilities under operating leases.

[0001078271-12-000048:notes:194]
Fiscal 2011 Restructuring

[0001078271-12-000048:notes:195]
During fiscal 2011, the Company commenced a strategy to focus on growing revenue in specific market verticals and on improving operational effectiveness.  As part of the strategy, the Company reduced headcount by 139 and incurred total restructuring charges of $4.2 million, of which $1.0 million and $3.2 million were recognized in the third and fourth quarter of fiscal 2011, respectively.  During the fourth quarter of fiscal 2011, the lease term for the excess leased facilities ended.  The Company recognized a restructuring reversal of $0.4 million related to the true up of operating and rent expenses.

[0001078271-12-000048:notes:196]
Fiscal 2010 Restructuring

[0001078271-12-000048:notes:197]
During the second quarter of fiscal 2010 the Company restructured the organization, from a business unit organization to a functional organization. In connection with the restructuring, the Company had a reduction in force (“RIF”) and terminated 8% of the workforce incurring termination benefits of $4.1 million and eliminated certain redundant engineering projects of $0.5 million. Total restructuring charges related to the RIF and engineering projects recognized in fiscal 2010 was $4.6 million.

[0001078271-12-000048:notes:198]
Additionally there were $0.2 million increase in facilities operating expenses related to one of the Company's restructured facilities along with a $0.5 million reversal of restructuring expense due to higher projected sublease receipt from a sublease renewal arrangement and $0.1 million reversal of restructuring expense related to the settlement of employment termination benefits incurred in the third fiscal quarter of 2009.

[0001078271-12-000048:notes:199]
Restructuring liabilities consist of (in thousands):

[0001078271-12-000048:notes:200]
|  | ExcessFacilities |  | AssetImpairment |  | ContractTermination |  | TerminationBenefits |  | Accelerationof StockAwards |  | Other |  | Total |
| Balance at June 28, 2009 | 6,337 |  |  | — |  |  | — |  |  | 741 |  |  | — |  |  | — |  |  | 7,078 |  |
| Period charges | 260 |  |  | 449 |  |  | 86 |  |  | 3,763 |  |  | 353 |  |  | — |  |  | 4,911 |  |
| Period reversals | (529 | ) |  | — |  |  | — |  |  | (139 | ) |  | — |  |  | — |  |  | (668 | ) |
| Period impairments | — |  |  | (65 | ) |  | — |  |  | — |  |  | (353 | ) |  | — |  |  | (418 | ) |
| Period payments | (2,928 | ) |  | (384 | ) |  | (77 | ) |  | (4,144 | ) |  | — |  |  | — |  |  | (7,533 | ) |
| Balance at June 27, 2010 | 3,140 |  |  | — |  |  | 9 |  |  | 221 |  |  | — |  |  | — |  |  | 3,370 |  |
| Period charges | — |  |  | — |  |  | — |  |  | 4,146 |  |  | — |  |  | 80 |  |  | 4,226 |  |
| Period reversals | (381 | ) |  | — |  |  | — |  |  | (38 | ) |  | — |  |  | — |  |  | (419 | ) |
| Period impairments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Period payments | (2,759 | ) |  | — |  |  | (9 | ) |  | (1,226 | ) |  | — |  |  | — |  |  | (3,994 | ) |
| Balance at July 3, 2011 | — |  |  | — |  |  | — |  |  | 3,103 |  |  | — |  |  | 80 |  |  | 3,183 |  |
| Period charges | — |  |  | — |  |  | 124 |  |  | 1,832 |  |  | — |  |  | 206 |  |  | 2,162 |  |
| Period reversals | — |  |  | — |  |  | (18 | ) |  | (499 | ) |  | — |  |  | (51 | ) |  | (568 | ) |
| Period impairments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Period payments | — |  |  | — |  |  | (13 | ) |  | (4,077 | ) |  | — |  |  | (224 | ) |  | (4,314 | ) |
| Restructuring liabilities at June 30, 2012 | — |  |  | — |  |  | 93 |  |  | 359 |  |  | — |  |  | 11 |  |  | 463 |  |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0001078271-12-000048:notes:201]
The following are the components of comprehensive income, net of tax (in thousands):

[0001078271-12-000048:notes:202]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Net income | $ | 15,872 |  |  | $ | 2,713 |  |  | $ | 227 |  |
| Change in unrealized (loss) gain on investments: |  |  |  |  |  |
| Net unrealized (loss) gain on other investments | (196 | ) |  | 109 |  |  | (265 | ) |
| Foreign currency translation adjustments: |  |  |  |  |  |
| Beginning balance | 3,448 |  |  | 954 |  |  | 912 |  |
| Ending balance | (920 | ) |  | 3,448 |  |  | 954 |  |
| Foreign currency translation adjustments change | (4,368 | ) |  | 2,494 |  |  | 42 |  |
| Comprehensive income | $ | 11,308 |  |  | $ | 5,316 |  |  | $ | 4 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-12-000048:notes:203]
The Company attributes revenues to geographic regions based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001078271-12-000048:notes:204]
|  | Year Ended |
| Net Revenues: | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Americas: |  |  |  |  |  |
| United States | $ | 106,110 |  |  | $ | 103,087 |  |  | $ | 105,532 |  |
| Other | 34,970 |  |  | 30,487 |  |  | 26,632 |  |
| Total Americas | 141,080 |  |  | 133,574 |  |  | 132,164 |  |
| EMEA | 128,093 |  |  | 134,730 |  |  | 125,357 |  |
| APAC | 53,549 |  |  | 66,124 |  |  | 51,833 |  |
| Total net revenues | $ | 322,722 |  |  | $ | 334,428 |  |  | $ | 309,354 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001078271-12-000048:notes:205]
SCHEDULE II

[0001078271-12-000048:notes:206]
VALUATION AND QUALIFYING ACCOUNTS

[0001078271-12-000048:notes:207]
YEARS ENDED JUNE 30, 2012, JULY 3, 2011 and JUNE 27, 2010

[0001078271-12-000048:notes:208]
| Description | Balance atbeginningof period |  | Charges tocosts andexpenses |  | (Deductions)(1) |  | Balance atend ofperiod |
| Year Ended June 27, 2010: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 1,205 |  |  | $ | 26 |  |  | $ | (199 | ) |  | $ | 1,032 |  |
| Allowance for sales returns | $ | 930 |  |  | $ | 1,229 |  |  | $ | (1,222 | ) |  | $ | 937 |  |
| Year Ended July 3, 2011: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 1,032 |  |  | $ | (9 | ) |  | $ | (256 | ) |  | $ | 767 |  |
| Allowance for sales returns | $ | 937 |  |  | $ | 647 |  |  | $ | (939 | ) |  | $ | 645 |  |
| Year Ended June 30, 2012: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 767 |  |  | $ | 127 |  |  | $ | (510 | ) |  | $ | 384 |  |
| Allowance for sales returns | $ | 645 |  |  | $ | 1,013 |  |  | $ | (396 | ) |  | $ | 1,262 |  |

[0001078271-12-000048:notes:209]
| (1) | Uncollectible accounts written off, net of recoveries |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-12-000048:notes:210]
Disclosure about Segments of an Enterprise and Geographic Areas

[0001078271-12-000048:notes:211]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision makers with respect to the allocation of resources and performance.

[0001078271-12-000048:notes:212]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East and Africa; and APAC which includes Asia Pacific, South Asia and Japan. Prior to fiscal 2012, South America was included as part of EMEA.

[0001078271-12-000048:notes:213]
Substantially all of the Company’s assets were attributable to North America operations at June 30, 2012 and July 3, 2011.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001078271-12-000048:notes:214]
Stockholders’ Equity

[0001078271-12-000048:notes:215]
Preferred Stock

[0001078271-12-000048:notes:216]
In April 2001, in connection with the Company’s Stockholders’ Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2012, no shares of preferred stock were outstanding.

[0001078271-12-000048:notes:217]
Stockholders’ Rights Agreement

[0001078271-12-000048:notes:218]
On April 26, 2012, the Board of Directors (the “Board”) of Extreme Networks, Inc. (“Extreme Networks” or the “Company”) adopted an Amended and Restated Rights Agreement (the “Restated Rights Plan”), between Extreme Networks and Computershare Shareholder Services LLC as the rights agent (the “Rights Agent”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of Series A Preferred Stock of Extreme Networks. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as amended on June 30, 2010 and April 26, 2011, between Extreme Networks and Mellon Investor Services LLC (the “Prior Rights Plan”). The Board reviewed the necessity of the provision of the Prior Rights Plan adopted to preserve the value of Extreme Networks' deferred tax assets, including its net operating loss carry forwards, with respect to its ability to fully use its tax benefits to offset future income may be limited if it experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of Extreme Networks' common stock. Following its review, the Board decided it was necessary and in the best interests of Extreme Networks and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extends the term of the Prior Rights Plan from April 30, 2012 to April 30, 2013.

[0001078271-12-000048:notes:219]
Comprehensive Income

[0001078271-12-000048:notes:220]
Changes in the foreign currency translation adjustments during fiscal 2012 include the effect of the Japan subsidiary liquidation of $1.9 million.

[0001078271-12-000048:notes:221]
Shares Reserved for Issuance

[0001078271-12-000048:notes:222]
The following are shares reserved for issuance (in thousands):

[0001078271-12-000048:notes:223]
|  | June 30, 2012 |
| Employee stock purchase plan | 2,571 |  |
| Employee stock options | 18,524 |  |
| Total shares reserved for issuance | 21,095 |  |


## us-gaap:SubsequentEventsTextBlock

[0001078271-12-000048:notes:224]
Subsequent Events

[0001078271-12-000048:notes:225]
On September 23, 2010, the Company entered into an Option Agreement with Trumark Companies LLC (“Trumark”), under which the Company granted Trumark an option (the “Option”) to purchase half of its corporate headquarters campus in Santa Clara, California (First Property), at a price of $24.0 million.  Under the agreements, Trumark will have until December 18, 2012 to exercise the options to purchase the First Property and may extend the option if they make certain payments to the Company. In January 2012, the Company classified the First Property as “assets held for sale” on the consolidated balance sheet at a net book value of $17.1 million, which was the lesser of the fair value (less cost to sell) or carrying amount of the assets, and ceased recognizing depreciation expense on the assets.

[0001078271-12-000048:notes:226]
On January 25, 2012, Company entered into a new Option Agreement with Trumark, under which it granted Trumark an option to purchase the remaining portion of the Company's corporate campus (Second Property), at a price of $24.5 million.  Under the agreement, Trumark will have until December 28, 2012 to exercise the options to purchase the Second Property and may extend the option if they make certain payments to the Company. As of June 30, 2012, the Second Property, with a net book value of $16.0 million, remains classified as “assets held for use” due to certain unresolved contingencies that may delay the completion date of this transaction.

[0001078271-12-000048:notes:227]
As of the date of this filing, the Company had received option payments totaling $3.0 million from Trumark, which were classified as a deferred gain and included in other current liabilities on the consolidated balance sheet.

[0001078271-12-000048:notes:228]
On August 20, 2012, Company entered into amendments to both of the Option Agreements for First Property and Second Property.  These amendments are contingent on Trumark assigning on or before September 11, 2012, Trumark's interest in the Option Agreements to Catalina Investment Company, L.P.  (an entity controlled by The Irvine Company) or an entity which controls, is controlled by, or under common control with The Irvine Company (“Irvine”).  If the assignment to Irvine does not occur on or before September 11, 2012, then the amendments are of no force or effect.  If the assignment does occur on or before September 11, 2012, then the closing under the Option Agreements shall be accelerated to the date on which the assignment to Irvine occurs and the combined purchase price for the First Property and the Second Property shall be reduced to $46.0 million.
