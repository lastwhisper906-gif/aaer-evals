# EXTR MD&A — 0001078271-12-000048


## mdna

[0001078271-12-000048:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001078271-12-000048:mdna:2]
Business Overview

[0001078271-12-000048:mdna:3]
We develop and sell network infrastructure equipment and offer related services contracts for extended warranty and maintenance to our enterprise, data center and metropolitan telecommunications service provider customers. Substantially all of our revenue is derived from the sale of our networking equipment and related service contracts. In our fiscal year ended June 30, 2012, our revenue decreased $11.7 million, gross profit decreased $0.1 million, operating profit increased $10.8 million and net income increased $13.2 million as compared to fiscal 2011.

[0001078271-12-000048:mdna:4]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal year ended June 30, 2012.

[0001078271-12-000048:mdna:5]
Impact of the Global Economic Developments

[0001078271-12-000048:mdna:6]
Although our net income and earnings per share both increased in fiscal 2012, we believe that the credit market crisis, slow economic recovery in the United States, and other challenges affecting global economic conditions placed significant limitations on our financial performance. We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia and Japan. Sales in the APAC and some European countries were most impacted as a result of the soft global economy and the global credit crisis in the financial market and certain European countries. We believe that limited access to credit, conservative purchasing patterns and delays or cancellation of IT infrastructure plans in the face of continued uncertainty regarding the global economy, may continue to negatively impact overall demand for networking solutions, including Ethernet equipment.

[0001078271-12-000048:mdna:7]
We have taken and plan to continue to take other steps to manage our business in the current economic environment. For example, we have managed from time to time our contingent work force, reduced travel and other discretionary spending, realigned our product portfolio and organization to grow revenue and operating income, and controlled all hiring activities.

[0001078271-12-000048:mdna:8]
Increasing Demand for Bandwidth

[0001078271-12-000048:mdna:9]
We believe that the continued increase in demand for bandwidth will over time drive future demand for high performance Ethernet solutions. Wide-spread adoption of electronic communications in all aspects of our lives, proliferation of next generation converged mobile devices and deployment of triple-play services to residences and businesses alike, continues to generate demand for greater network performance across broader geographic locations. In parallel to these transformational forces within society and the community at large, the accelerating adoption of internet and intranet “cloud” solutions within business enterprises is enabling organizations to offer greater business scalability to improve efficiency and through more effective operations, improve profitability. In order to realize the benefits of these developments, customers require additional bandwidth and high performance from their network infrastructure at affordable prices. We are seeing the initial indications that the Ethernet segment of the networking equipment market will return to growth as enterprise, data center and carrier customers continue to recognize the performance and operating cost benefits of Ethernet technology.

[0001078271-12-000048:mdna:10]
Expanding Product Portfolio

[0001078271-12-000048:mdna:11]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but is not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology. During the past year we further extended our Ethernet product portfolio through the addition of the BlackDiamond BD-X, a highly-scalable core switch for IT and cloud data centers, the Summit X440 for the intelligent edge, the Summit X670 for data center top-of-rack deployments, the E4G Cell Site Router family for mobile backhaul, and a revamp of our RidgeLine network management platform

[0001078271-12-000048:mdna:12]
Industry Developments

[0001078271-12-000048:mdna:13]
The market for network infrastructure equipment is highly competitive and dominated by a few large companies. The current economic climate has further driven consolidation of vendors within the Ethernet networking market and with vendors from adjacent markets, including storage, security, wireless and voice applications. We believe that the underpinning technology for all of these adjacent markets is Ethernet. As a result, independent Ethernet switch vendors are being acquired or merged with larger, adjacent market vendors to enable them to deliver complete and broad solutions. As an independent Ethernet switch vendor, we must provide products that, when combined with the products of our large strategic partners, create compelling solutions for end user customers. Our approach is to focus on the intelligence and automation layer that spans our hardware products and that facilitates end-to-end solutions, as opposed to positioning Extreme Networks as a low-cost-vendor with point products. Lower overall market growth has also created an environment of declining margins due to increased competition between the remaining vendors in this space. During the last year, overall Ethernet port counts have grown, while industry revenues have decreased, signaling a decline in average selling price. Our product life cycle and operational cost reduction efforts are therefore even more

[0001078271-12-000048:mdna:14]
critical for margin preservation.

[0001078271-12-000048:mdna:15]
Realignment of Corporate Strategies

[0001078271-12-000048:mdna:16]
In fiscal 2011, we commenced a strategy to focus on growing revenue in specific market verticals and on improving operational effectiveness.  As part of this corporate realignment we recorded a charge of $1.6 million during the fiscal year ended June 30, 2012.

[0001078271-12-000048:mdna:17]
Amendment to Rights Agreement

[0001078271-12-000048:mdna:18]
On April 26, 2012, our Board of Directors of the Company adopted an Amended and Restated Rights Agreement between Extreme Networks and Computershare Shareholder Services LLC as the rights agent. The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of Series A Preferred Stock of Extreme Networks. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as amended on June 30, 2010 and April 26, 2011, between Extreme Networks and Mellon Investor services LLC (the “Prior Rights Plan”).

[0001078271-12-000048:mdna:19]
The Board reviewed the necessity of the provision of the Prior Rights Plan adopted to preserve the value of Extreme Networks' deferred tax assets, including its net operating loss carry forwards, with respect to its ability to fully use its tax benefits to offset future income may be limited if it experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of Extreme Networks' common stock. Following its review, the Board decided it was necessary and in the best interests of Extreme Networks and its stockholders to enter into the Restated Rights Plan The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extends the term of the Prior Rights Plan from April 30, 2012 to April 30, 2013.

[0001078271-12-000048:mdna:20]
Results of Operations

[0001078271-12-000048:mdna:21]
Effective June 30, 2012, we changed our fiscal period to coincide with calendar month-end.  Previously, we used a fiscal 52/53 week manufacturing calendar year. Accordingly, the fiscal year ended June 30, 2012 has 52 weeks compared to 53 weeks in 2011 and 52 weeks in fiscal 2010.

[0001078271-12-000048:mdna:22]
Our operations and financial performance have been affected by the economic factors described above, and during fiscal 2012, we achieved the following results:

[0001078271-12-000048:mdna:23]
| • | Net revenue of $322.7 million, a decrease of 4% from fiscal 2011 net revenue of $334.4 million. |

[0001078271-12-000048:mdna:24]
| • | Product revenue of $261.9 million, a decrease of 5% from fiscal 2011 product revenue of $274.4 million. |

[0001078271-12-000048:mdna:25]
| • | Service revenue of $60.8 million, roughly equal to fiscal 2011 service revenue of $60.0 million |

[0001078271-12-000048:mdna:26]
| • | Total gross margin was 55.7% of net revenue in fiscal 2012 (including share-based compensation expense of $0.7 million), compared to 53.8% in fiscal 2011. |

[0001078271-12-000048:mdna:27]
| • | Net income was $15.9 million in fiscal 2012 (including share-based compensation expense of $6.2 million and restructuring charges of $1.6 million), an increase from net income of $2.7 million in fiscal 2011. |

[0001078271-12-000048:mdna:28]
| • | Cash flow provided by operating activities was $13.8 million, compared to cash flow provided by operating activities of $16.8 million in fiscal 2011, a decrease of $3.0 million. Cash and cash equivalents, short-term investments and marketable securities were $153.5 million as of June 30, 2012, an increase of $6.5 million from fiscal 2011 was primarily due to cash provided by operating activities. |

[0001078271-12-000048:mdna:29]
Net Revenue

[0001078271-12-000048:mdna:30]
The following table presents net product and service revenue for the fiscal years 2012, 2011 and 2010 (dollars in thousands):

[0001078271-12-000048:mdna:31]
|  | Year Ended |  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |  | July 3, 2011 |  | June 27, 2010 |  | $Change |  | %Change |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 261,873 |  |  | $ | 274,388 |  |  | $ | (12,515 | ) |  | (4.6 | )% |  | $ | 274,388 |  |  | $ | 249,035 |  |  | $ | 25,353 |  |  | 10.2 | % |
| Percentage of net revenue | 81.2 | % |  | 82.1 | % |  |  |  |  |  | 82.1 | % |  | 80.5 | % |  |  |  |  |
| Service | 60,849 |  |  | 60,040 |  |  | 809 |  |  | 1.3 | % |  | 60,040 |  |  | 60,319 |  |  | (279 | ) |  | (0.5 | )% |
| Percentage of net revenue | 18.9 | % |  | 18.0 | % |  |  |  |  |  | 18.0 | % |  | 19.5 | % |  |  |  |  |
| Total net revenue | $ | 322,722 |  |  | $ | 334,428 |  |  | $ | (11,706 | ) |  | (3.5 | )% |  | $ | 334,428 |  |  | $ | 309,354 |  |  | $ | 25,074 |  |  | 8.1 | % |

[0001078271-12-000048:mdna:32]
Product revenue decreased in fiscal 2012 as compared to fiscal 2011 primarily due to increased pricing pressure on our other products and lower volumes. The decreases were also a result of elimination of certain products and product mix shift.

[0001078271-12-000048:mdna:33]
Product revenue increased in fiscal 2011 as compared to fiscal 2010 primarily due to growth in our Asia Pacific region and select strategic partners such as Ericsson AB, which accounted for 11% of our overall business, as well as increasing stability in the EMEA market. In the first quarter of fiscal 2010, we experienced supply constraint issues which resulted in the loss of business.

[0001078271-12-000048:mdna:34]
Service revenue increased in fiscal 2012 as compared to fiscal 2011 resulting from a significant one time renewal contract for a single customer and maintenance contract extensions.

[0001078271-12-000048:mdna:35]
Service revenue was flat in fiscal 2011 as compared to fiscal 2010 primarily due to the reduction of maintenance revenue for end-of-life products, offset by growth in new value-added services, coupled with maintenance service contracts attached to increased product sales.

[0001078271-12-000048:mdna:36]
As noted previously, we operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia and Japan. Prior to fiscal 2012, South America was included as part of EMEA. The following table presents the total net revenue geographically for the fiscal years 2012, 2011 and 2010 (dollars in thousands):

[0001078271-12-000048:mdna:37]
|  | Year Ended |  | Year Ended |
| Net Revenue | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |  | July 3, 2011 |  | June 27, 2010 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 106,110 |  |  | $ | 103,087 |  |  | $ | 3,023 |  |  | 2.9 | % |  | $ | 103,087 |  |  | $ | 105,532 |  |  | $ | (2,445 | ) |  | (2.3 | )% |
| Other | 34,970 |  |  | 30,487 |  |  | 4,483 |  |  | 14.7 | % |  | 30,487 |  |  | 26,632 |  |  | 3,855 |  |  | 14.5 | % |
| Total Americas | 141,080 |  |  | 133,574 |  |  | 7,506 |  |  | 5.6 | % |  | 133,574 |  |  | 132,164 |  |  | 1,410 |  |  | 1.1 | % |
| Percentage of net revenue | 43.7 | % |  | 39.9 | % |  |  |  |  |  | 39.9 | % |  | 42.7 | % |  |  |  |  |
| EMEA | 128,093 |  |  | 134,730 |  |  | (6,637 | ) |  | (4.9 | )% |  | 134,730 |  |  | 125,357 |  |  | 9,373 |  |  | 7.5 | % |
| Percentage of net revenue | 39.7 | % |  | 40.3 | % |  |  |  |  |  | 40.3 | % |  | 40.5 | % |  |  |  |  |
| APAC | 53,549 |  |  | 66,124 |  |  | (12,575 | ) |  | (19.0 | )% |  | 66,124 |  |  | 51,833 |  |  | 14,291 |  |  | 27.6 | % |
| Percentage of net revenue | 16.6 | % |  | 19.8 | % |  |  |  |  |  | 19.8 | % |  | 16.8 | % |  |  |  |  |
| Total net revenues | $ | 322,722 |  |  | $ | 334,428 |  |  | $ | (11,706 | ) |  | (3.5 | )% |  | $ | 334,428 |  |  | $ | 309,354 |  |  | $ | 25,074 |  |  | 8.1 | % |

[0001078271-12-000048:mdna:38]
Revenue in the Americas increased in 2012 as compared to fiscal 2011 primarily due to sales to several large customers. Revenue in EMEA decreased in fiscal 2012 as compared to FY 2011 due to slow economic recovery in Europe.  Revenue in APAC also decreased in fiscal 2012 as compared to fiscal 2011 due to organizational changes in 2012 and weaker sales in India, Korea, Hong Kong and Japan.

[0001078271-12-000048:mdna:39]
Revenue in the Americas remained consistent in fiscal 2011 as compared to fiscal 2010 primarily due to slow economic recovery and organizational structure changes in the United States, offset by growth in Mexico, Central America, and South America for several large strategic deals. Revenue in the United States decreased in fiscal 2011 as compared to fiscal 2010 primarily due to slow economic recovery and organizational structure changes.

[0001078271-12-000048:mdna:40]
Revenue in EMEA increased in fiscal 2011 as compared to fiscal 2010 primarily due to increasing demand in Central and Northern Europe and growth with Ericsson AB. Revenue in APAC increased in fiscal 2011 as compared to fiscal 2010 primarily due to stronger service provider and enterprise sales in China, Korea and Southeast Asia.

[0001078271-12-000048:mdna:41]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEM, and direct sales.  Revenue through our distributor channel was 42% of total product revenue in fiscal 2012, 52% of total product revenue in fiscal 2011, and 59% in fiscal 2010. The decrease in distributor channel revenue over the past three years was due to a shift in sales from distributors to our OEMs and direct resellers.

[0001078271-12-000048:mdna:42]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001078271-12-000048:mdna:43]
Cost of Revenue and Gross Profit

[0001078271-12-000048:mdna:44]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenue for the fiscal years 2012, 2011 and 2010 (dollars in thousands):

[0001078271-12-000048:mdna:45]
|  | Year Ended |  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |  | July 3, 2011 |  | June 27, 2010 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 141,646 |  |  | $ | 144,832 |  |  | $ | (3,186 | ) |  | (2.2 | )% |  | $ | 144,832 |  |  | $ | 141,037 |  |  | $ | 3,795 |  |  | 2.7 | % |
| Percentage of product revenue | 54.1 | % |  | 52.8 | % |  |  |  |  |  | 52.8 | % |  | 56.6 | % |  |  |  |  |
| Service | 38,201 |  |  | 35,129 |  |  | 3,072 |  |  | 8.7 | % |  | 35,129 |  |  | 35,456 |  |  | (327 | ) |  | (0.9 | )% |
| Percentage of service revenue | 62.8 | % |  | 58.5 | % |  |  |  |  |  | 58.5 | % |  | 58.8 | % |  |  |  |  |
| Total gross profit | $ | 179,847 |  |  | $ | 179,961 |  |  | $ | (114 | ) |  | (0.1 | )% |  | $ | 179,961 |  |  | $ | 176,493 |  |  | $ | 3,468 |  |  | 2.0 | % |
| Percentage of net revenue | 55.7 | % |  | 53.8 | % |  |  |  |  |  | 53.8 | % |  | 57.1 | % |  |  |  |  |

[0001078271-12-000048:mdna:46]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution at our facilities in Santa Clara, California, China, and Taiwan. Accordingly, a significant portion of our cost of product revenue consists of payments to our primary contract manufacturer, Alpha Networks, located in Hsinchu, Taiwan. In addition, we OEM our wireless product line from Motorola.

[0001078271-12-000048:mdna:47]
Product gross profit in fiscal 2012 decreased as compared to fiscal 2011 due to lower sales offset by lower material cost, costs associated with inventory write-down charges, and a decrease in inbound freight costs due to the Company's new Hong Kong distribution center which is located closer to our contract manufacturer Alpha Networks.

[0001078271-12-000048:mdna:48]
Product gross profit in fiscal 2011 increased as compared to fiscal 2010 primarily due to increased revenue offset by higher material cost and a $5.4 million charge associated with the write-down of inventory from our strategic realignment.

[0001078271-12-000048:mdna:49]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross profit in fiscal 2012 increased as compared to fiscal 2011 primarily due to lower RMA shipments for legacy chassis products, mix change from higher repair cost chassis products to lower repair cost stackable products.

[0001078271-12-000048:mdna:50]
Service gross profit in fiscal 2011 remained flat as compared to fiscal 2010 as revenue and costs were relatively unchanged from the prior year.

[0001078271-12-000048:mdna:51]
Operating Expenses

[0001078271-12-000048:mdna:52]
The following table presents operating expenses and operating income (in thousands, except percentages):

[0001078271-12-000048:mdna:53]
|  | Year Ended |  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | $Change |  | %Change |  | July 3, 2011 |  | June 27, 2010 |  | $Change |  | %Change |
| Sales and marketing | $ | 90,167 |  |  | $ | 103,277 |  |  | $ | (13,110 | ) |  | (12.7 | )% |  | $ | 103,277 |  |  | $ | 96,621 |  |  | $ | 6,656 |  |  | 6.9 | % |
| Research and development | 45,640 |  |  | 49,330 |  |  | (3,690 | ) |  | (7.5 | )% |  | 49,330 |  |  | 49,390 |  |  | (60 | ) |  | (0.1 | )% |
| General and administrative | 28,658 |  |  | 24,683 |  |  | 3,975 |  |  | 16.1 | % |  | 24,683 |  |  | 26,839 |  |  | (2,156 | ) |  | (8.0 | )% |
| Restructuring charge, net of reversal | 1,594 |  |  | 3,806 |  |  | (2,212 | ) |  | (58.1 | )% |  | 3,806 |  |  | 4,238 |  |  | (432 | ) |  | (10.2 | )% |
| Litigation settlement | (121 | ) |  | (4,249 | ) |  | 4,128 |  |  | (97.2 | )% |  | (4,249 | ) |  | 829 |  |  | (5,078 | ) |  | (612.5 | )% |
| Total operating expenses | $ | 165,938 |  |  | $ | 176,847 |  |  | $ | (10,909 | ) |  | (6.2 | )% |  | $ | 176,847 |  |  | $ | 177,917 |  |  | $ | (1,070 | ) |  | (0.6 | )% |
| Operating income (loss) | $ | 13,909 |  |  | 3,114 |  |  | $ | 10,795 |  |  | 346.7 | % |  | 3,114 |  |  | $ | (1,424 | ) |  | $ | 4,538 |  |  | (318.7 | )% |

[0001078271-12-000048:mdna:54]
The following table highlights our operating expenses and operating income as a percentage of net revenues:

[0001078271-12-000048:mdna:55]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Sales and marketing | 27.9 | % |  | 30.9 | % |  | 31.2 | % |
| Research and development | 14.1 | % |  | 14.8 | % |  | 16.0 | % |
| General and administrative | 8.9 | % |  | 7.4 | % |  | 8.7 | % |
| Restructuring charge, net of reversal | 0.5 | % |  | 1.1 | % |  | 1.4 | % |
| Litigation settlement | — | % |  | (1.3 | )% |  | 0.3 | % |
| Total operating expenses | 51.4 | % |  | 52.9 | % |  | 57.5 | % |
| Operating (loss) income | 4.3 | % |  | 0.9 | % |  | (0.5 | )% |

[0001078271-12-000048:mdna:56]
Sales and Marketing Expenses

[0001078271-12-000048:mdna:57]
Sales and marketing expenses consist of salaries, commissions and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses. Sales and marketing expenses decreased in fiscal 2012 as compared to fiscal 2011 primarily due to $4.5 million reduction in salaries and benefits, $3.5 million reduction in commissions due to lower revenue, $1.7 million less professional fees due to utilization of in-house services, and $1.4 million lesser travel expenses resulting from the reduction in headcount at the beginning of fiscal 2012.

[0001078271-12-000048:mdna:58]
Sales and marketing expenses increased in fiscal 2011 as compared to fiscal 2010 primarily due to $3.2 million higher salary and benefits expense resulting from increased headcount, $2.3 million higher commissions due to increased revenue, and $0.6 million increase in new marketing initiatives to improve brand awareness.

[0001078271-12-000048:mdna:59]
Research and Development Expenses

[0001078271-12-000048:mdna:60]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products. Research and development expenses decreased in fiscal 2012 as compared to fiscal 2011 primarily due to $3.5 million less in salaries and benefits expense due to a reduction in headcount and a transfer of resources to lower cost regions and $0.9 million less in small equipment expenses due to better utilization of existing test equipment, offset by $0.6 million increase in professional fees related to new product launches.

[0001078271-12-000048:mdna:61]
Research and development expenses remained flat in fiscal 2011 as compared to fiscal 2010 primarily due to a $3.5 million increase in engineering project expenses offset by a $2.4 million decrease in salaries and benefits due to a reduction in headcount, a $0.5 million decrease in professional fees related to development work, and a $0.6 million decrease in stock-based compensation expense.

[0001078271-12-000048:mdna:62]
General and Administrative Expenses

[0001078271-12-000048:mdna:63]
General and administrative expenses increased in fiscal 2012 as compared to fiscal 2011 primarily due to increased legal expense of $2.0 million, increased contract labor expense for accounting and finance of $1.0 million, increased stock based compensation expense of $0.8 million, increased international accounting fees of $0.8 million offset by lower salaries and benefits

[0001078271-12-000048:mdna:64]
expense of $0.8 million due to fewer headcount.

[0001078271-12-000048:mdna:65]
General and administrative expenses decreased in fiscal 2011 as compared to fiscal 2010 primarily due to a $1.7 million decrease in litigation expenses.

[0001078271-12-000048:mdna:66]
Restructuring Charge, Net of Reversal

[0001078271-12-000048:mdna:67]
During the fiscal 2012, 2011 and 2010, we recorded restructuring charges of $1.6 million, $3.8 million, and $4.2 million, respectively.

[0001078271-12-000048:mdna:68]
Fiscal 2012 Restructuring

[0001078271-12-000048:mdna:69]
During fiscal 2012, we incurred total charges of $2.2 million, including $1.8 million related to severance, $0.1 million of contract termination fees, and $0.2 million other charges. A portion of this restructuring activity is related to the liquidation of our Japan subsidiary with a cost of $0.5 million at June 30, 2012. We substantially liquidated the subsidiary in Japan in the fourth quarter or fiscal 2012, as part of our broad restructuring effort. We will dispose the remaining immaterial assets and liabilities and complete the liquidation process by the end of fiscal 2013.

[0001078271-12-000048:mdna:70]
Fiscal 2011 Restructuring

[0001078271-12-000048:mdna:71]
During fiscal 2011, we commenced a strategy to focus on growing revenue in specific market verticals and on improving operational effectiveness.  As part of the strategy, we reduced headcount and incurred total restructuring charges of $4.2 million, of which $1.0 million and $3.2 million were recognized in the third and fourth quarter of fiscal 2011, respectively.  During the fourth quarter of fiscal 2011, the lease term for the excess leased facilities ended. We recognized a restructuring reversal of $0.4 million related to the true up of operating and rent expenses.

[0001078271-12-000048:mdna:72]
Fiscal 2010 Restructuring

[0001078271-12-000048:mdna:73]
During fiscal 2010, we incurred charges of $4.6 million related to the restructuring or the organization from a business unit organization to a functional organization. Total termination benefits were $4.1 million.  We incurred $0.2 million increase in facilities operating expenses related to one of the facilities; $0.5 million reversal of restructuring expense due to higher projected sublease receipt from sublease renewal arrangement. $0.1 million reversal of restructuring expense related to the settlement of employment termination benefits incurred in the third fiscal quarter of 2009.

[0001078271-12-000048:mdna:74]
Litigation Settlement

[0001078271-12-000048:mdna:75]
During the fourth quarter of fiscal 2012, from a judgment related to our lawsuit with Enterasys Networks for patent infringement, we received $0.6 million from Enterasys including a first trial damage award of $0.2 million, reimbursement of legal costs from the first trial of $0.4 million, and interest.

[0001078271-12-000048:mdna:76]
Interest Income

[0001078271-12-000048:mdna:77]
Interest income was $1.2 million in fiscal 2012, $1.3 million in fiscal 2011 and $1.5 million in fiscal 2010, representing a decrease of $0.1 million in fiscal 2012 from fiscal 2011, and a decrease of $0.2 million in fiscal 2011 from fiscal 2010.  The decrease in interest income in fiscal 2012 from fiscal 2011 was due to a decrease in the average interest yield from 1.2% in fiscal 2011 to 0.95% in fiscal 2012. The decrease in interest income in fiscal 2011 from fiscal 2010 was due to a decrease in the average interest yield from 1.6% in fiscal 2010 to 1.2% in fiscal 2011.

[0001078271-12-000048:mdna:78]
Interest Expense

[0001078271-12-000048:mdna:79]
Interest expense was $0.1 million for each fiscal year 2012, 2011 and 2010. Interest expense in fiscal 2012 and fiscal 2011 were primarily related to interest amortization of technology agreements.

[0001078271-12-000048:mdna:80]
Other Income (Expense), net

[0001078271-12-000048:mdna:81]
Other income (expense) net, was income of $2.0 million in fiscal 2012, expense of $0.6 million in fiscal 2011 and expense of $0.1 million in fiscal 2010.  Other income in fiscal 2012 was primarily comprised of $1.9 million in foreign currency translation gains that were reclassified from other comprehensive income (loss) due to the substantial liquidation of our Japan subsidiary.

[0001078271-12-000048:mdna:82]
Provision (Benefit) for Income Taxes

[0001078271-12-000048:mdna:83]
We recorded an income tax provision of $1.2 million for fiscal 2012. The effective tax rate in fiscal 2012 was 7.0% which differs from the federal statutory tax rate of 35% due primarily to the tax impact of income from foreign operations and the change

[0001078271-12-000048:mdna:84]
in valuation allowance.  We recorded an income tax provision of $1.2 million for fiscal 2012 due to profits in our foreign subsidiaries, utilization of the US entity's net operating losses, and the release of foreign tax reserves.

[0001078271-12-000048:mdna:85]
The income tax provision of $1.0 million and income tax benefit of $0.4 million for fiscal 2011 and 2010, respectively, were recorded for taxes due on income generated in U.S federal, certain states and foreign tax jurisdictions. The effective tax rate was 26.9% for fiscal 2011 which differs from the federal statutory tax rate of 35% due primarily to the tax impact of income from foreign operations and the change in valuation allowance. The effective tax rate was 223.6% for fiscal 2010 which differs from the federal statutory tax rate of 35% due primarily to the benefit of U.S. net operating losses carry-forwards and the tax impact of income from foreign operations.

[0001078271-12-000048:mdna:86]
Critical Accounting Policies and Estimates

[0001078271-12-000048:mdna:87]
Our significant accounting policies are more fully described in Note 2 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001078271-12-000048:mdna:88]
Share-based Payments

[0001078271-12-000048:mdna:89]
We use the Black-Scholes option-pricing model to determine the fair value of option awards, and share purchase options under our Employee Stock Purchase Plan (“ESPP”) on the date of grant with the weighted average assumptions. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of purchase options under our ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP award is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on our stock and historical volatility on our stock. We do not currently pay cash dividends on our common stock and do not anticipate doing so in the foreseeable future. Accordingly, our expected dividend yield is zero. We are required to estimate forfeitures at the time of grant and revise those estimates in subsequent periods if actual forfeitures differ from those estimates. In fiscal 2012, our estimated forfeiture rates based on historical forfeiture experiences are 7% for executives and 9% for non-executive employees. We use the straight-line method for expense attribution, and we estimate forfeitures and only recognize expense for those shares expected to vest.

[0001078271-12-000048:mdna:90]
Revenue Recognition

[0001078271-12-000048:mdna:91]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance service contracts, professional services, and training for our products. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and the collection of the sales proceeds is reasonably assured. In instances where any of the criteria for revenue recognition are not met, we defer revenue until all criteria have been met.

[0001078271-12-000048:mdna:92]
Product revenue from our value-added resellers, non-stocking distributors and end-user customers is recognized at the time of shipment, provided that all of the foregoing revenue recognition requirements have been satisfied.  We generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits. Accordingly, we recognize revenue upon transfer of title and risk of loss to the customer, which is generally upon shipment. We maintain estimated accruals and allowances for sales incentives and other programs that we may make available to our partners, based on historical experience or applicable contractual terms. Shipping costs are included in cost of product revenues. Sales taxes collected from customers are excluded from revenues.

[0001078271-12-000048:mdna:93]
We also sell our products to distributors that stock inventory and sell to resellers. We defer recognition of revenue on all sales to our stocking distributors until the distributors have sold the products, as evidenced by sales data that the distributors provide to us. We grant stocking distributors certain price protection rights and the right to return a portion of unsold inventory for the purpose of stock rotation. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. We also provide stocking distributors with credits for changes in selling prices based on competitive conditions, and provide funding for our distributors and their resellers to perform marketing development activities. We maintain estimated accruals and allowances for these exposures based upon our contractual obligations. Our marketing

[0001078271-12-000048:mdna:94]
development channel programs do not meet the criteria for recognizing the costs as marketing expenses and therefore these costs are accrued as a reduction to revenue in the same period that the products are sold.

[0001078271-12-000048:mdna:95]
Revenue from service contracts is deferred and recognized ratably over the contractual service period, which is typically from one to two years. Professional service revenue is recognized upon delivery or completion of performance.

[0001078271-12-000048:mdna:96]
Our networking products are tangible products that contain software and non-software components that function together to deliver the tangible product's essential functionality. Our sales arrangements may contain multiple deliverables comprised of our tangible products, standalone software licenses, and service offerings depending on the distribution sales channel through which the products are sold and the requirements of our customers. We recognize revenue for our multiple deliverable arrangements in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. The industry-specific software revenue recognition guidance generally does not apply to the sales of our tangible products.  Software revenue guidance is applied to sales of our standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-12-000048:mdna:97]
Pursuant to the guidance of the accounting standard for multiple-deliverable revenue arrangements, we allocate the total arrangement consideration to each separable element of an arrangement based on the relative selling price of each element.  We determine the standalone selling price for each element based on a selling price hierarchy. Under the selling price hierarchy, the selling price for each deliverable is based on our vendor-specific objective evidence of selling price (“VSOE”), which is determined by a substantial majority of our historical standalone sales transactions for a product or service falling within a reasonable range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, we determine the best estimate of standalone selling price (“ESP”) for a product or service by considering several factors including, but not limited to, the 12-month historical median sales price, sales channels, geography, gross margin consistency, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, we apply management judgment to determine the best estimate of selling price through consultation with and formal approval by our management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of all other deliverables is determined by using ESP. We regularly review VSOE, TPE and ESP for all of our products and services and maintain internal controls over the establishment and updates of these estimates.

[0001078271-12-000048:mdna:98]
Pursuant to the software revenue recognition accounting standard, we continue to recognize revenue for software using the residual method for our sales of standalone software products, including optional software upgrades, and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the multiple deliverable arrangement, we recognize revenue in accordance with our policies for product, software, and service revenue recognition.

[0001078271-12-000048:mdna:99]
Our total deferred product revenue from customers other than distributors was $2.2 million and $2.0 million as of June 30, 2012 and July 3, 2011, respectively. Our total deferred revenue for services, primarily from service contracts, was $37.7 million as of June 30, 2012 and $36.0 million as of July 3, 2011. Service contracts typically range from one to two years. Shipping costs are included in cost of product revenues.

[0001078271-12-000048:mdna:100]
We provide an allowance for sales returns based on our historical returns, analysis of credit memo data and our return policies. The allowance for sales returns was $1.3 million and $0.6 million as of June 30, 2012 and July 3, 2011, respectively, for estimated future returns that were recorded as a reduction of our accounts receivable. If the historical data that we use to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. We estimate and adjust this allowance at each balance sheet date.

[0001078271-12-000048:mdna:101]
Inventory Valuation

[0001078271-12-000048:mdna:102]
Our inventory balance was $26.6 million as of June 30, 2012, compared with $21.6 million as of July 3, 2011. We value our inventory at lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We provide inventory allowances based on excess and obsolete inventories determined primarily by the age of inventory. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed. Inventory write-downs charged to cost of product revenue were $1.1 million in fiscal 2012, $2.2 million in fiscal 2011 and $1.9 million in fiscal 2010.

[0001078271-12-000048:mdna:103]
Long Lived Assets

[0001078271-12-000048:mdna:104]
Long-lived assets include property and equipment, intangible assets, and service inventory which we hold to support customers

[0001078271-12-000048:mdna:105]
who have purchased service contracts with a hardware replacement element.   Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, we assess the recoverability of the long-lived assets by comparing the projected un-discounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001078271-12-000048:mdna:106]
Accrued Warranty

[0001078271-12-000048:mdna:107]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates. Our standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, we offer a limited lifetime hardware warranty commencing on the date of shipment from us and ending five (5) years following the our announcement of the end of sale of such product. Upon shipment of products to our customers, including both end-users and channel partners, we estimate expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability through charges to cost of product revenue for this amount.

[0001078271-12-000048:mdna:108]
Our accrued warranty balance was $2.9 million and $2.6 million as of June 30, 2012 and July 3, 2011, respectively. The determination of our warranty requirements is based on our actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. We estimate and adjust this accrual at each balance sheet date in accordance with changes in these factors.

[0001078271-12-000048:mdna:109]
The cost of new warranties issued that was charged to cost of product revenue was $3.1 million in fiscal 2012, $2.4 million in fiscal 2011, and $2.9 million in fiscal 2010.

[0001078271-12-000048:mdna:110]
Accounts Receivable and Allowance for Doubtful Accounts

[0001078271-12-000048:mdna:111]
Our accounts receivable balance, net of allowance for doubtful accounts, was $41.2 million and $33.7 million as of June 30, 2012 and July 3, 2011, respectively. The allowance for doubtful accounts for trade accounts receivable was $0.4 million and $0.8 million as of June 30, 2012 and July 3, 2011, respectively. We continually monitor and evaluate the collectability of our trade receivables based on a combination of factors. We record specific allowances for bad debts in general and administrative expense when we become aware of a specific customer’s inability to meet its financial obligation to us, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining our allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. We mitigate some collection risk by requiring most of our customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with us. Our provision for doubtful accounts was an expense of $128,000 in fiscal 2012, benefit of $9,000 in fiscal 2011 and expense of $26,000 in fiscal 2010.

[0001078271-12-000048:mdna:112]
Deferred Tax Asset Valuation Allowance

[0001078271-12-000048:mdna:113]
We recognize deferred tax assets and liabilities based on the differences between the financial statement carrying amounts and the tax bases of assets and liabilities. Significant management judgment is required in determining our valuation allowance recorded against our net deferred tax assets. We make an assessment of the likelihood that our net deferred tax assets will be recovered from future taxable income, and to the extent that recovery is not believed to be likely, a valuation allowance is established. In fiscal 2012, the valuation allowance decreased by $9.9 million to $140.6 million, and in fiscal 2011, the valuation allowance decreased by $4.6 million to $150.5 million. We have not provided a valuation allowance against any of our non-U.S. deferred tax assets.

[0001078271-12-000048:mdna:114]
The valuation allowance requires an assessment of both negative and positive evidence when measuring the need for a valuation allowance. Evidence, such as operating results during the most recent three-year period was given more weight than our expectations of future profitability, which are inherently uncertain. Our U.S. cumulative losses during those periods represented sufficient negative evidence to require a full valuation allowance against our U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results have sufficiently improved to support realization of our deferred tax assets.

[0001078271-12-000048:mdna:115]
Accounting for Uncertainty in Income Taxes

[0001078271-12-000048:mdna:116]
We had unrecognized tax benefits of $25.7 million as of June 30, 2012. If fully recognized in the future, $0.5 million would impact our effective tax rate, and $25.2 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-12-000048:mdna:117]
Legal Contingencies

[0001078271-12-000048:mdna:118]
We are currently involved in various claims and legal proceedings, including negotiations regarding potential licenses from third parties who have notified us that they believe our products may infringe certain patents. Periodically, we review the status of each significant matter, whether litigation or licensing negotiation, and assess our potential financial exposure. If the potential loss from any claim or legal proceeding is considered probable and the amount can be estimated, we accrue a liability for the estimated loss. Because of uncertainties related to these matters, accruals, if any, are based only on the most current and dependable information available at any given time. As additional information becomes available, we may reassess the potential liability from pending claims and litigation and the probability of claims being successfully asserted against us. As a result, we may revise our estimates related to these pending claims and litigation. Such revisions in the estimates of the potential liabilities could have a material impact on our consolidated results of operations, financial position and cash flows in the future. For further detail, see Note 3 of Notes to Consolidated Financial Statements.

[0001078271-12-000048:mdna:119]
Impact of Recently Issued Accounting Standards

[0001078271-12-000048:mdna:120]
In June 2011, the FASB issued ASU 2011-05, Comprehensive Income (Topic 220): Presentation of Comprehensive Income. ASU 2011-05 requires one of two alternatives for presenting comprehensive income and eliminates the option to report other comprehensive income and its components as a part of the Consolidated Statements of Stockholders' Equity. Additionally, ASU 2011-05 requires presentation on the face of the financial statements reclassification adjustments for items that are reclassified from other comprehensive income to net income in the statement(s) where the components of net income and the components of other comprehensive income are presented. The requirement related to the reclassification adjustments from other comprehensive income to net income was deferred in December 2011, as a result of the issuance of ASU 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update 2011-05 (Topic 220). The amendments in ASU 2011-05, as amended by ASU 2011-12, do not change the items that must be reported in other comprehensive income or when an item of other comprehensive income must be reclassified to net income. ASU 2011-05, as amended by ASU 2011-12 is effective for fiscal years and interim periods within those years beginning after December 15, 2011 and is to be applied retrospectively. We will adopt ASU 2011-05 during the first quarter of fiscal 2013. We do not expect the adoption of ASU 2011-05, as amended by ASU 2011-12 to have a material impact on our Consolidated Financial Statements.

[0001078271-12-000048:mdna:121]
Liquidity and Capital Resources

[0001078271-12-000048:mdna:122]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001078271-12-000048:mdna:123]
|  | June 30, 2012 |  | July 3, 2011 |
| Cash and cash equivalent | $ | 54,596 |  |  | $ | 49,972 |  |
| Short-term investments | 23,358 |  |  | 41,357 |  |
| Marketable securities | 75,561 |  |  | 55,648 |  |
| Total cash and investments | $ | 153,515 |  |  | $ | 146,977 |  |
| Working capital | $ | 72,361 |  |  | $ | 57,561 |  |

[0001078271-12-000048:mdna:124]
Cash and cash equivalents increased by $4.6 million primarily due to cash provided by operating activities of $13.8 million and cash from financing activities of $2.4 million, offset by cash used in investing activities of $10.4 million. Refer to further discussions below under Key Components of Cash Flows and Liquidity.

[0001078271-12-000048:mdna:125]
Short-term investments decreased by $18.0 million due to the maturity of the other short-term investments. Cash was primarily invested in the long-term investments to optimize yield. Refer to further discussions below under Item 7A. Quantitative and Qualitative Disclosures About Market Risk.

[0001078271-12-000048:mdna:126]
The Company increased their holding in marketable securities by $19.9 million as compared to the prior year to optimize their yield by purchasing long term investments.

[0001078271-12-000048:mdna:127]
The increase in working capital of $14.8 million was primarily due to the assets held for sale classified as current assets.

[0001078271-12-000048:mdna:128]
Key Components of Cash Flows and Liquidity

[0001078271-12-000048:mdna:129]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001078271-12-000048:mdna:130]
|  | Year Ended |
|  | June 30, 2012 |  | July 3, 2011 |  | June 27, 2010 |
| Net cash provided by operating activities | $ | 13,813 |  |  | $ | 16,777 |  |  | $ | 10,943 |  |
| Net cash (used in) investing activities | $ | (10,410 | ) |  | $ | (22,079 | ) |  | $ | (8,774 | ) |
| Net cash provided by financing activities | $ | 2,393 |  |  | $ | 2,530 |  |  | $ | 1,085 |  |
| Foreign currency effect on cash | $ | (1,172 | ) |  | $ | 800 |  |  | $ | (543 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 4,624 |  |  | $ | (1,972 | ) |  | $ | 2,711 |  |

[0001078271-12-000048:mdna:131]
Cash and cash equivalents, short-term investments and marketable securities were $153.5 million at June 30, 2012, representing an increase of $6.5 million from $147.0 million at July 3, 2011. This increase was primarily due to cash provided by operations of $13.8 million and cash provided by financing activities of $2.4 million, offset by cash used in investing activities of $10.4 million and foreign currency impact of $1.2 million.

[0001078271-12-000048:mdna:132]
Cash provided by operating activities was $13.8 million, a decrease of $3.0 million compared to cash provided by operating activities of $16.8 million in fiscal 2011. Accounts receivable, net, increased to $41.2 million at June 30, 2012 from $33.7 million at July 3, 2011. Days sales outstanding in receivables increased to 42 days at June 30, 2012 from 38 days at July 3, 2011. The increase in accounts receivable and days sales outstanding were primarily due to increased billings during the fourth quarter of 2012 resulting in a higher receivables balance. Inventories increased to $26.6 million at June 30, 2012 from $21.6 million at July 3, 2011 as a result of us increasing quantities on hand to support our new distribution center added in Hong Kong in the second half of fiscal 2012.

[0001078271-12-000048:mdna:133]
Deferred revenue, net increased to $39.3 million at June 30, 2012 from $37.0 million at July 3, 2011. This increase was a result of higher sales of service maintenance agreements.

[0001078271-12-000048:mdna:134]
Cash flow used in investing activities was $10.4 million. Capital expenditures were $5.2 million and purchases of investments were $75.9 million, offset by proceeds from maturities of investments and marketable securities of $30.3 million and sales of investments and marketable securities of $40.7 million.

[0001078271-12-000048:mdna:135]
Cash provided by financing activities was $2.4 million resulting from $1.4 million proceeds from the issuance of common stock and $1.0 million deposit received from the sale of the building.

[0001078271-12-000048:mdna:136]
Contractual Obligations

[0001078271-12-000048:mdna:137]
The following summarizes our contractual obligations at June 30, 2012, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-12-000048:mdna:138]
|  | Total |  | Less Than1 Year |  | 1 – 3 Years |  | 3 – 5 Years |  | More ThanFive Years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Non-cancelable inventory purchase commitments | $ | 38,765 |  |  | $ | 38,765 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-cancelable operating lease obligations | 9,098 |  |  | 3,528 |  |  | 3,566 |  |  | 1,197 |  |  | 807 |  |
| Total contractual cash obligations | $ | 47,863 |  |  | $ | 42,293 |  |  | $ | 3,566 |  |  | $ | 1,197 |  |  | $ | 807 |  |

[0001078271-12-000048:mdna:139]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $38.8 million as of June 30, 2012, an increase of $12.8 million from $26.0 million as of July 3, 2011.

[0001078271-12-000048:mdna:140]
The amounts in the table above exclude $0.5 million of income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of settlement.

[0001078271-12-000048:mdna:141]
We did not have any material commitments for capital expenditures as of June 30, 2012. Other non-cancelable purchase commitments represent OEM and technology agreements.

[0001078271-12-000048:mdna:142]
Off-Balance Sheet Arrangements

[0001078271-12-000048:mdna:143]
We did not have any off-balance sheet arrangements as of June 30, 2012.

[0001078271-12-000048:mdna:144]
Capital Resources and Financial Condition

[0001078271-12-000048:mdna:145]
As of June 30, 2012, in addition to $54.6 million in cash and cash equivalents, we had $23.4 million invested in short-term investments and $75.6 million invested in long-term marketable investments for a total cash and cash equivalents, short-term investments and marketable securities of $153.5 million.

[0001078271-12-000048:mdna:146]
We believe that our current cash and cash equivalents, short-term investments, marketable securities and cash available from credit facilities and future operations will enable us to meet our working capital requirements for at least the next 12 months.
