# EXTR MD&A — 0001078271-13-000020


## mdna

[0001078271-13-000020:mdna:1]
[same as prior period, unchanged from 0001078271-13-000006:mdna:1]

[0001078271-13-000020:mdna:2]
[same as prior period, unchanged from 0001078271-13-000006:mdna:2]

[0001078271-13-000020:mdna:3]
[same as prior period, unchanged from 0001078271-13-000006:mdna:3]

[0001078271-13-000020:mdna:4]
[same as prior period, unchanged from 0001078271-13-000006:mdna:4]

[0001078271-13-000020:mdna:5]
We outsource the majority of our manufacturing and supply chain management operations as part of our strategy to maintain global manufacturing capabilities and to reduce our costs. We conduct quality assurance, manufacturing engineering, document control and test development in Santa Clara, California and Research Triangle Park, North Carolina. This approach enables us to reduce fixed costs and to flexibly respond to changes in market demand.

[0001078271-13-000020:mdna:6]
[same as prior period, unchanged from 0001078271-13-000006:mdna:6]

[0001078271-13-000020:mdna:7]
[same as prior period, unchanged from 0001078271-13-000006:mdna:7]

[0001078271-13-000020:mdna:8]
[same as prior period, unchanged from 0001078271-13-000006:mdna:8]

[0001078271-13-000020:mdna:9]
During the third quarter of fiscal 2013, we achieved the following results:

[0001078271-13-000020:mdna:10]
| • | Net revenues of $68.2 million compared to net revenues of $73.4 million in the third quarter of fiscal 2012. |

[0001078271-13-000020:mdna:11]
| • | Product revenues of $54.1 million compared to product revenues of $58.0 million in the third quarter of fiscal 2012. |

[0001078271-13-000020:mdna:12]
| • | Service revenues of $14.1 million compared to service revenues of $15.4 million in the third quarter of fiscal 2012. |

[0001078271-13-000020:mdna:13]
| • | Total gross margin of 56% of net revenues compared to total gross margin of 56% of net revenues in the third quarter of fiscal 2012. |

[0001078271-13-000020:mdna:14]
| • | Operating loss of $1.9 million (including restructuring charges of $1.1 million and $2.6 million litigation settlement and associated legal fees) compared to operating income of $2.7 million in the third quarter of fiscal 2012. |

[0001078271-13-000020:mdna:15]
| • | Net loss of $2.2 million compared to net income of $2.4 million in the third quarter of fiscal 2012. |

[0001078271-13-000020:mdna:16]
| • | Cash flow provided by operating activities of $7.0 million in the nine months ended March 31, 2013 compared to cash flow provided by operating activities of $6.4 million in the nine months ended April 1, 2012. |

[0001078271-13-000020:mdna:17]
| • | Cash and cash equivalents, short-term investments and marketable securities increased by $35.6 million to $189.1 million as of March 31, 2013 from $153.5 million as of June 30, 2012, primarily due to cash provided by operating and investing activities, including the sale of buildings and land offset by cash used for repurchase of common stock. |

[0001078271-13-000020:mdna:18]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan, and Australia. The following table presents the total net revenue geographically for the three and nine months ended March 31, 2013 and April 1, 2012, respectively (dollars in thousands):

[0001078271-13-000020:mdna:19]
|  | Three Months Ended |  | Nine Months Ended |
| Net Revenues | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |  | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 21,609 |  |  | $ | 23,452 |  |  | $ | (1,843 | ) |  | (7.9 | )% |  | $ | 69,545 |  |  | $ | 75,841 |  |  | $ | (6,296 | ) |  | (8.3 | )% |
| Other | 6,414 |  |  | 7,464 |  |  | (1,050 | ) |  | (14.1 | )% |  | 26,959 |  |  | 26,976 |  |  | (17 | ) |  | (0.1 | )% |
| Total Americas | 28,023 |  |  | 30,916 |  |  | (2,893 | ) |  | (9.4 | )% |  | 96,504 |  |  | 102,817 |  |  | (6,313 | ) |  | (6.1 | )% |
| Percentage of net revenue | 41.0 | % |  | 42.1 | % |  |  |  |  |  | 43.9 | % |  | 43.7 | % |  |  |  |  |  |  |
| EMEA | 28,481 |  |  | 30,349 |  |  | (1,868 | ) |  | (6.2 | )% |  | 85,700 |  |  | 91,164 |  |  | (5,464 | ) |  | (6.0 | )% |
| Percentage of net revenue | 41.8 | % |  | 41.4 | % |  |  |  |  |  | 39.0 | % |  | 38.8 | % |  |  |  |  |  |  |
| APAC | 11,699 |  |  | 12,103 |  |  | (404 | ) |  | (3.3 | )% |  | 37,677 |  |  | 41,093 |  |  | (3,416 | ) |  | (8.3 | )% |
| Percentage of net revenue | 17.2 | % |  | 16.5 | % |  |  |  |  |  | 17.1 | % |  | 17.5 | % |  |  |  |  |
| Total net revenues | $ | 68,203 |  |  | $ | 73,368 |  |  | $ | (5,165 | ) |  | (7.0 | )% |  | $ | 219,881 |  |  | $ | 235,074 |  |  | $ | (15,193 | ) |  | (6.5 | )% |

[0001078271-13-000020:mdna:20]
[same as prior period, unchanged from 0001078271-13-000006:mdna:20]

[0001078271-13-000020:mdna:21]
The following table presents net product and service revenue for the three and nine months ended March 31, 2013 and April 1, 2012, respectively (dollars in thousands):

[0001078271-13-000020:mdna:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |  | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 54,072 |  |  | $ | 58,009 |  |  | $ | (3,937 | ) |  | (6.8 | )% |  | $ | 175,450 |  |  | $ | 189,316 |  |  | $ | (13,866 | ) |  | (7.3 | )% |
| Percentage of net revenue | 79.3 | % |  | 79.1 | % |  |  |  |  |  | 79.8 | % |  | 80.5 | % |  |  |  |  |
| Service | 14,131 |  |  | 15,359 |  |  | (1,228 | ) |  | (8.0 | )% |  | 44,431 |  |  | 45,758 |  |  | (1,327 | ) |  | (2.9 | )% |
| Percentage of net revenue | 20.7 | % |  | 20.9 | % |  |  |  |  |  | 20.2 | % |  | 19.5 | % |  |  |  |  |
| Total net revenues | $ | 68,203 |  |  | $ | 73,368 |  |  | $ | (5,165 | ) |  | (7.0 | )% |  | $ | 219,881 |  |  | $ | 235,074 |  |  | $ | (15,193 | ) |  | (6.5 | )% |

[0001078271-13-000020:mdna:23]
Product revenue decreased by $3.9 million or 6.8% in the third quarter of fiscal 2013, and decreased by $13.9 million or 7.3% in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012 primarily due to lower sales volume in the Americas and EMEA regions.  In the nine months ending March 31, 2013, we experienced weaker than expected demand from our public sector and enterprise customers in the U.S. and we continued to experience weak demand from our public sector and strategic customers and distributors in the EMEA region attributable to the persistent macroeconomic challenges in Western Europe.

[0001078271-13-000020:mdna:24]
Service revenue decreased by $1.2 million, or 8.0% in the third quarter of fiscal 2013, and decreased $1.3 million or 2.9% in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012, reflecting slight decrease in the levels of service contract renewals.

[0001078271-13-000020:mdna:25]
21

[0001078271-13-000020:mdna:26]
[same as prior period, unchanged from 0001078271-13-000006:mdna:25]

[0001078271-13-000020:mdna:27]
The following table presents the gross profit on product and service revenue and the gross profit percentage of product and service revenue for the three and nine months ended March 31, 2013 and April 1, 2012 (in thousands):

[0001078271-13-000020:mdna:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |  | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 28,866 |  |  | $ | 31,386 |  |  | $ | (2,520 | ) |  | (8.0 | )% |  | $ | 90,391 |  |  | $ | 102,394 |  |  | $ | (12,003 | ) |  | (11.7 | )% |
| Percentage of product revenue | 53.4 | % |  | 54.1 | % |  |  |  |  |  | 51.5 | % |  | 54.1 | % |  |  |  |  |
| Service | 9,071 |  |  | 9,825 |  |  | (754 | ) |  | (7.7 | )% |  | 28,260 |  |  | 28,621 |  |  | (361 | ) |  | (1.3 | )% |
| Percentage of service revenue | 64.2 | % |  | 64.0 | % |  |  |  |  |  | 63.6 | % |  | 62.5 | % |  |  |  |  |
| Total gross profit | $ | 37,937 |  |  | $ | 41,211 |  |  | $ | (3,274 | ) |  | (7.9 | )% |  | $ | 118,651 |  |  | $ | 131,015 |  |  | $ | (12,364 | ) |  | (9.4 | )% |
| Percentage of net revenue | 55.6 | % |  | 56.2 | % |  |  |  |  |  | 54.0 | % |  | 55.7 | % |  |  |  |  |

[0001078271-13-000020:mdna:29]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution in Santa Clara, California, China, and Taiwan. Accordingly, a significant portion of our cost of product revenue consists of payments to our primary contract manufacturer located in Hsinchu, Taiwan. In addition, we OEM our wireless product line from Motorola.

[0001078271-13-000020:mdna:30]
Product gross margin decreased to 53.4% from 54.1% in the third quarter of fiscal 2013, and decreased to 51.5% from 54.1% in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012.  The decrease in product gross margin for the third quarter of fiscal 2013 was primarily due to lower product revenue offset by economic benefits realized in our manufacturing costs.  The decrease in product gross margin for the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012 was primarily due to lower product revenue and an increase in charges for excess and obsolete inventory offset by economic benefits realized in our manufacturing costs.

[0001078271-13-000020:mdna:31]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross margin increased to 64.2% from 64.0% in the third quarter of fiscal 2013 and increased to 63.6% from 62.5% in the nine months ending March 31, 2013.  The increases in service gross margin were primarily due to lower material costs.

[0001078271-13-000020:mdna:32]
[same as prior period, unchanged from 0001078271-13-000006:mdna:31]

[0001078271-13-000020:mdna:33]
[same as prior period, unchanged from 0001078271-13-000006:mdna:32]

[0001078271-13-000020:mdna:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |  | March 31, 2013 |  | April 1, 2012 |  | $Change |  | %Change |
| Research and development | $ | 9,381 |  |  | $ | 10,376 |  |  | $ | (995 | ) |  | (9.6 | )% |  | $ | 30,954 |  |  | $ | 33,866 |  |  | $ | (2,912 | ) |  | (8.6 | )% |
| Sales and marketing | 20,644 |  |  | 20,657 |  |  | (13 | ) |  | (0.1 | )% |  | 64,764 |  |  | 65,512 |  |  | (748 | ) |  | (1.1 | )% |
| General and administrative | 6,288 |  |  | 7,553 |  |  | (1,265 | ) |  | (16.7 | )% |  | 18,292 |  |  | 21,777 |  |  | (3,485 | ) |  | (16.0 | )% |
| Restructuring charge, net of reversals | 1,076 |  |  | (35 | ) |  | 1,111 |  |  | 3,174.3 | % |  | 6,242 |  |  | 1,357 |  |  | 4,885 |  |  | 360.0 | % |
| Litigation settlement | 2,450 |  |  | — |  |  | 2,450 |  |  | 100.0 | % |  | 2,029 |  |  | — |  |  | 2,029 |  |  | 100.0 | % |
| Gain on sale of campus | — |  |  | — |  |  | — |  |  | — | % |  | (11,539 | ) |  | — |  |  | (11,539 | ) |  | (100.0 | )% |
| Total operating expenses | $ | 39,839 |  |  | $ | 38,551 |  |  | $ | 1,288 |  |  | 3.3 | % |  | $ | 110,742 |  |  | $ | 122,512 |  |  | $ | (11,770 | ) |  | (9.6 | )% |
| Operating income | $ | (1,902 | ) |  | 2,660 |  |  | $ | (4,562 | ) |  | (171.5 | )% |  | $ | 7,909 |  |  | $ | 8,503 |  |  | $ | (594 | ) |  | (7.0 | )% |

[0001078271-13-000020:mdna:35]
[same as prior period, unchanged from 0001078271-13-000006:mdna:34]

[0001078271-13-000020:mdna:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Research and development | 13.8 | % |  | 14.1 | % |  | 14.1 | % |  | 14.4 | % |
| Sales and marketing | 30.3 | % |  | 28.2 | % |  | 29.5 | % |  | 27.9 | % |
| General and administrative | 9.2 | % |  | 10.3 | % |  | 8.3 | % |  | 9.3 | % |
| Restructuring charge, net of reversals | 1.6 | % |  | (0.1 | )% |  | 2.8 | % |  | 0.6 | % |
| Litigation settlement | 3.6 | % |  | — | % |  | 0.9 | % |  | — | % |
| Gain on sale of campus | — | % |  | — | % |  | (5.2 | )% |  | — | % |
| Total operating expenses | 58.5 | % |  | 52.5 | % |  | 50.4 | % |  | 52.2 | % |
| Operating income | (2.8 | )% |  | 3.6 | % |  | 3.6 | % |  | 3.6 | % |

[0001078271-13-000020:mdna:37]
[same as prior period, unchanged from 0001078271-13-000006:mdna:36]

[0001078271-13-000020:mdna:38]
[same as prior period, unchanged from 0001078271-13-000006:mdna:37]

[0001078271-13-000020:mdna:39]
Research and development expenses decreased by $1.0 million, or 9.6% in the third quarter of fiscal 2013 and decreased by $2.9 million, or 8.6% in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012. The decreases in research and development expenses primarily resulted from lower spending on engineering project expenses due to differences in the timing and pattern of planned engineering project spending in the nine months ending March 31, 2013 when compared to the same period last year.

[0001078271-13-000020:mdna:40]
[same as prior period, unchanged from 0001078271-13-000006:mdna:39]

[0001078271-13-000020:mdna:41]
[same as prior period, unchanged from 0001078271-13-000006:mdna:40]

[0001078271-13-000020:mdna:42]
Sales and marketing expenses decreased by an immaterial amount, or 0.1% in the third quarter of fiscal 2013 and decreased by $0.7 million, or 1.1% in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012. The decreases in sales and marketing expenses were primarily due to decreases in commissions in the three and nine months ended March 31, 2013.

[0001078271-13-000020:mdna:43]
[same as prior period, unchanged from 0001078271-13-000006:mdna:42]

[0001078271-13-000020:mdna:44]
General and administrative expenses decreased by $1.3 million, or 16.7% in the third quarter of fiscal 2013 and decreased by $3.5 million, or 16.0% in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012. The decreases in general and administrative expenses during the three months ending March 31, 2013, compared to the corresponding period of fiscal 2012, was primarily due to cost reduction initiatives realized as part of our restructuring plan.  The decreases in general and administrative expenses during the nine months ending March 31, 2013, compared to the corresponding period of fiscal 2012, was mainly attributable to lower legal costs due to the resolution of certain legal matters.

[0001078271-13-000020:mdna:45]
[same as prior period, unchanged from 0001078271-13-000006:mdna:44]

[0001078271-13-000020:mdna:46]
Restructuring charges increased by $1.1 million in the third quarter of fiscal 2013 and increased by $4.9 million in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012.  During the second quarter of fiscal 2013, we further reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. As part of our restructuring efforts in the second quarter, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. As of March 31, 2013, we had restructuring liabilities of $1.8 million, which we anticipate paying by the end of the first quarter of fiscal 2014. We anticipate incurring additional restructuring charges of approximately $0.6 million through the end of first quarter of fiscal 2014.

[0001078271-13-000020:mdna:47]
Litigation Settlement, Net

[0001078271-13-000020:mdna:48]
During the third quarter of fiscal 2013, we recognized a litigation charge of $2.5 million related to a settlement agreement with Enterasys Networks Inc.

[0001078271-13-000020:mdna:49]
[same as prior period, unchanged from 0001078271-13-000006:mdna:48]

[0001078271-13-000020:mdna:50]
During the first quarter of fiscal 2013, we completed the sale of our corporate campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million. We realized a gain of approximately $11.5 million in connection with this transaction.

[0001078271-13-000020:mdna:51]
Other Expense, Net

[0001078271-13-000020:mdna:52]
Other expense, net increased by $0.1 million in the third quarter of fiscal 2013 and increased by $0.8 million in the nine months ending March 31, 2013, compared to the corresponding periods of fiscal 2012.  The change in other expense, net in the third quarter of fiscal 2013, as compared to the same period in fiscal 2012, was insignificant. The increase in other expense, net in the nine months ending March 31, 2013, as compared to the same period of fiscal 2012 was primarily due to gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.

[0001078271-13-000020:mdna:53]
[same as prior period, unchanged from 0001078271-13-000006:mdna:52]

[0001078271-13-000020:mdna:54]
We recorded an income tax provision of $0.4 million and $0.5 million for the three months ended March 31, 2013 and April 1, 2012, respectively. We recorded an income tax provision of $1.4 million and $1.2 million for the nine months ended March 31, 2013 and April 1, 2012, respectively. The income tax provision for the third quarter of fiscal 2013 consisted primarily of taxes on foreign income and U.S state income taxes. The income tax provision for the third quarter of fiscal 2012 consisted primarily of taxes on foreign income and U.S. state income taxes.  The income tax provisions for both quarters were calculated based on the results of operations for the three and nine months ended March 31, 2013 and April 1, 2012, and may not reflect the annual effective rate.

[0001078271-13-000020:mdna:55]
[same as prior period, unchanged from 0001078271-13-000006:mdna:54]

[0001078271-13-000020:mdna:56]
[same as prior period, unchanged from 0001078271-13-000006:mdna:55]

[0001078271-13-000020:mdna:57]
[same as prior period, unchanged from 0001078271-13-000006:mdna:56]

[0001078271-13-000020:mdna:58]
Our unaudited condensed consolidated financial statements and the related notes included elsewhere in this report are prepared in accordance with accounting principles generally accepted in the United States. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. In many instances, we could have reasonably used different accounting estimates, and in other instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, actual results could differ significantly from the estimates made by our management. On an ongoing basis, we evaluate our estimates and assumptions. To the extent that there are material differences between these estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected.

[0001078271-13-000020:mdna:59]
[same as prior period, unchanged from 0001078271-13-000006:mdna:59]

[0001078271-13-000020:mdna:60]
[same as prior period, unchanged from 0001078271-13-000006:mdna:60]

[0001078271-13-000020:mdna:61]
[same as prior period, unchanged from 0001078271-13-000006:mdna:61]

[0001078271-13-000020:mdna:62]
[same as prior period, unchanged from 0001078271-13-000006:mdna:62]

[0001078271-13-000020:mdna:63]
[same as prior period, unchanged from 0001078271-13-000006:mdna:63]

[0001078271-13-000020:mdna:64]
[same as prior period, unchanged from 0001078271-13-000006:mdna:64]

[0001078271-13-000020:mdna:65]
[same as prior period, unchanged from 0001078271-13-000006:mdna:65]

[0001078271-13-000020:mdna:66]
[same as prior period, unchanged from 0001078271-13-000006:mdna:66]

[0001078271-13-000020:mdna:67]
| • | Legal Contingencies |

[0001078271-13-000020:mdna:68]
[same as prior period, unchanged from 0001078271-13-000006:mdna:68]

[0001078271-13-000020:mdna:69]
[same as prior period, unchanged from 0001078271-13-000006:mdna:69]

[0001078271-13-000020:mdna:70]
[same as prior period, unchanged from 0001078271-13-000006:mdna:70]

[0001078271-13-000020:mdna:71]
[same as prior period, unchanged from 0001078271-13-000006:mdna:71]

[0001078271-13-000020:mdna:72]
|  | March 31, 2013 |  | June 30, 2012 |
| Cash and cash equivalent | $ | 77,592 |  |  | $ | 54,596 |  |
| Short-term investments | 42,336 |  |  | 23,358 |  |
| Marketable securities | 69,171 |  |  | 75,561 |  |
| Total cash and investments | $ | 189,099 |  |  | $ | 153,515 |  |
| Working capital | $ | 100,572 |  |  | $ | 72,361 |  |

[0001078271-13-000020:mdna:73]
As of March 31, 2013, our principal sources of liquidity consisted of cash, cash equivalents and investments of $189.1 million and net accounts receivable of $43.6 million. Historically, our principal uses of cash have consisted of the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development, marketing of our products and purchases of property and equipment and repurchases of our common stock. We believe that our $189.1 million of cash and cash equivalents and investments at March 31, 2013 will be sufficient to fund our operating requirements, stock repurchase program, and restructuring expenses for at least the next 12 months.

[0001078271-13-000020:mdna:74]
[same as prior period, unchanged from 0001078271-13-000006:mdna:74]

[0001078271-13-000020:mdna:75]
[same as prior period, unchanged from 0001078271-13-000006:mdna:75]

[0001078271-13-000020:mdna:76]
|  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |
| Net cash provided by operating activities | $ | 7,003 |  |  | $ | 6,407 |  |
| Net cash provided by (used in) investing activities | $ | 24,134 |  |  | $ | (3,905 | ) |
| Net cash (used in) provided by financing activities | $ | (8,434 | ) |  | $ | 1,754 |  |
| Foreign currency effect on cash | $ | 293 |  |  | $ | (905 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 22,996 |  |  | $ | 3,351 |  |

[0001078271-13-000020:mdna:77]
[same as prior period, unchanged from 0001078271-13-000006:mdna:77]

[0001078271-13-000020:mdna:78]
Cash flows from operations increased by $0.6 million in the nine months ending March 31, 2013 compared to the corresponding period of fiscal 2012, primarily due to purposeful reduction of inventory spending to bring inventory levels in line with the anticipated near-term demand for our products.

[0001078271-13-000020:mdna:79]
[same as prior period, unchanged from 0001078271-13-000006:mdna:79]

[0001078271-13-000020:mdna:80]
Cash flow provided by investing activities in the nine months ending March 31, 2013 was $24.1 million, comprised of proceeds of $42.7 million from the sale of buildings and land in Santa Clara California, proceeds of $26.3 million from the sale and maturities of investments, offset by $40.1 million used to purchase investment securities and $4.8 million used to purchase property and equipment.

[0001078271-13-000020:mdna:81]
[same as prior period, unchanged from 0001078271-13-000006:mdna:81]

[0001078271-13-000020:mdna:82]
Cash flow used in financing activities in the nine months ending March 31, 2013 was $8.4 million, comprised of $11.0 million used to repurchase shares of our common stock, offset by $2.5 million of proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-13-000020:mdna:83]
[same as prior period, unchanged from 0001078271-13-000006:mdna:83]

[0001078271-13-000020:mdna:84]
The following summarizes our contractual obligations at March 31, 2013, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-13-000020:mdna:85]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Non-Cancellable Inventory purchase commitments | $ | 30,324 |  |  | $ | 30,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-cancellable operating lease obligations | 35,886 |  |  | 4,711 |  |  | 9,023 |  |  | 7,636 |  |  | 14,516 |  |
| Total contractual cash obligations | $ | 66,210 |  |  | $ | 35,035 |  |  | $ | 9,023 |  |  | $ | 7,636 |  |  | $ | 14,516 |  |

[0001078271-13-000020:mdna:86]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $30.3 million as of March 31, 2013, a decrease of $8.5 million from $38.8 million as of June 30, 2012. We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-13-000020:mdna:87]
[same as prior period, unchanged from 0001078271-13-000006:mdna:87]

[0001078271-13-000020:mdna:88]
We did not have any material commitments for capital expenditures as of March 31, 2013.

[0001078271-13-000020:mdna:89]
[same as prior period, unchanged from 0001078271-13-000006:mdna:89]

[0001078271-13-000020:mdna:90]
We did not have any off-balance sheet arrangements as of March 31, 2013.
