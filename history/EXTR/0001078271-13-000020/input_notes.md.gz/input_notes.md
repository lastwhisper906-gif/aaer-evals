# EXTR notes — 0001078271-13-000020


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001078271-13-000020:notes:1]
[same as prior period, unchanged from 0001078271-13-000006:notes:1]

[0001078271-13-000020:notes:2]
|  | Less than 12 months |  | 12 months or more |  | Total |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| March 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |
| U.S. corporate debt securities | $ | 32,942 |  |  | $ | (104 | ) |  | $ | — |  |  | $ | — |  |  | $ | 32,942 |  |  | $ | (104 | ) |
|  | $ | 32,942 |  |  | $ | (104 | ) |  | $ | — |  |  | $ | — |  |  | $ | 32,942 |  |  | $ | (104 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-13-000020:notes:3]
[same as prior period, unchanged from 0001078271-13-000006:notes:3]

[0001078271-13-000020:notes:4]
[same as prior period, unchanged from 0001078271-13-000006:notes:4]

[0001078271-13-000020:notes:5]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| March 31, 2013 |  |  |  |  |  |  |  |
| Money market funds | $ | 54,179 |  |  | $ | 54,179 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 105,853 |  |  | 105,994 |  |  | 245 |  |  | (104 | ) |
| U.S. government agency securities | 5,512 |  |  | 5,513 |  |  | 1 |  |  | — |  |
|  | $ | 165,544 |  |  | $ | 165,686 |  |  | $ | 246 |  |  | $ | (104 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 54,179 |  |  | $ | 54,179 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 42,255 |  |  | 42,336 |  |  | 81 |  |  | — |  |
| Marketable securities | 69,110 |  |  | 69,171 |  |  | 165 |  |  | (104 | ) |
|  | $ | 165,544 |  |  | $ | 165,686 |  |  | $ | 246 |  |  | $ | (104 | ) |
| June 30, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 84,882 |  |  | 84,949 |  |  | 148 |  |  | (81 | ) |
| U.S. government agency securities | 11,241 |  |  | 11,234 |  |  | 3 |  |  | (10 | ) |
| U.S. municipal bonds | 2,738 |  |  | 2,736 |  |  | — |  |  | (2 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 23,311 |  |  | 23,358 |  |  | 48 |  |  | (1 | ) |
| Marketable securities | 75,550 |  |  | 75,561 |  |  | 103 |  |  | (92 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |

[0001078271-13-000020:notes:6]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at March 31, 2013, by contractual maturity, were as follows (in thousands):

[0001078271-13-000020:notes:7]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 42,255 |  |  | $ | 42,336 |  |
| Due in 1-2 years | 39,499 |  |  | 39,652 |  |
| Due in 2-5 years | 29,611 |  |  | 29,519 |  |
| Total investments in available for sale debt securities | $ | 111,365 |  |  | $ | 111,507 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-13-000020:notes:8]
Commitments and Contingencies

[0001078271-13-000020:notes:9]
Purchase Commitments

[0001078271-13-000020:notes:10]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2013, the Company had non-cancelable commitments to purchase approximately $30.3 million of such inventory.

[0001078271-13-000020:notes:11]
Legal Proceedings

[0001078271-13-000020:notes:12]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-13-000020:notes:13]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-13-000020:notes:14]
Intellectual Property Litigation

[0001078271-13-000020:notes:15]
Enterasys Networks

[0001078271-13-000020:notes:16]
On June 21, 2005, Enterasys Networks ("Enterasys") filed suit against Extreme and Foundry Networks, Inc. (“Foundry”) in the United States District Court for the District of Massachusetts, Civil Action No. 05-11298 DPW. The complaint alleged willful infringement of U.S. Patent Nos. 5,251,205; 5,390,173; 6,128,665; 6,147,995; 6,539,022; and 6,560,236, and sought: a) a judgment that the Company willfully infringes each of the patents; (b) a permanent injunction from infringement, inducement of infringement and contributory infringement of each of the six patents; (c) damages and a “reasonable royalty” to be determined at trial; (d) treble damages; (e) attorneys' fees, costs and interest; and (f) equitable relief at the Court's discretion. Petitions for reexamination were filed challenging five of the patents at issue to the U.S. Patent and Trademark Office, and a stay of the case was entered. Following the reexamination proceedings, Enterasys withdrew its allegations of infringement as to two of the patents, U.S. Patent Nos. 6,539,022 and 6,560,236. The stay was lifted on May 21, 2010, and the Court held claim construction hearings in December 2010. Fact discovery was ongoing. No trial date was set.

[0001078271-13-000020:notes:17]
On April 20, 2007, the Company filed suit against Enterasys in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded the Company damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.

[0001078271-13-000020:notes:18]
On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Both parties filed post-trial motions, including motions for a new trial, for judgment as a matter of law and for attorneys' fees, all of which the Court denied on July 11, 2012. Enterasys did not file a notice of appeal by the August 10, 2012 deadline.  Consequently, the judgment of non-infringement in favor of the Company in the second trial is final. During the fourth quarter of fiscal 2012, Enterasys paid the Company $0.6 million related to the judgment.  During the quarter ended December 31, 2012, the Company received payments from Enterasys totaling approximately $0.4 million for the Court's award for damages, supplemental damages, pre and post judgment interests, costs from the first trial and second trial, plus the amount Enterasys agreed to release for damages held in escrow that accrued during the stay of the injunction post-trial and on appeal.

[0001078271-13-000020:notes:19]
During the third quarter of fiscal 2013, the Company and Enterasys engaged in settlement discussions. On March  29, 2013, the parties entered into a confidential settlement agreement (“Agreement”). The Agreement required a dismissal with prejudice of the Wisconsin and Massachusetts litigation, as well as cross covenants not to sue and survival of settlement rights for any acquiring party of the parties. Joint motions to dismiss were granted on April 13, 2013, and April 15, 2013 respectively.  All matters between the parties have now been resolved.

[0001078271-13-000020:notes:20]
Chrimar Systems

[0001078271-13-000020:notes:21]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 (the "Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.

[0001078271-13-000020:notes:22]
During the fourth quarter of the fiscal 2012, the Company engaged in settlement discussions with Chrimar Systems Inc.  As part of the negotiations the Company determined that it is reasonably possible that a range of loss could be between $0.3 million and $1.4 million which is dependent on a number of factors including whether mutually acceptable settlement terms can be reached. As of March 31, 2013 and through the date of the filing of this Form 10-Q, this matter was still pending.  However, during the quarter ended June 30, 2012 the Company recorded a charge of $0.3 million based on its best estimate of the probable loss.  In addition, during the quarter ending March 31, 2013, venue for the Delaware action was transferred to the United States District Court for the District of Northern California.

[0001078271-13-000020:notes:23]
Reefedge Networks

[0001078271-13-000020:notes:24]
On September 17, 2012, Reefedge Networks, LLC filed suit against the Company in the United States District Court for the District of Delaware, Civil Action No. 12-1148. The complaint alleges wrongful use, making, selling, and/or offering to sell products that infringe U.S. Patent Nos. 6,633.761; 6,975,864; and 7,197,308 and seeks unspecified monetary damages and a permanent injunction for products originating from a single supplier to which the Company has submitted an indemnification request. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome. An answer was filed on December 10, 2012. The Company believes it will be fully indemnified for any potential losses related to the suit, as all products are third party designed and manufactured, and the suit is the subject of a third party indemnity and defense agreement.

[0001078271-13-000020:notes:25]
Indemnification Obligations

[0001078271-13-000020:notes:26]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of March 31, 2013, the Company had no outstanding indemnification claims


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001078271-13-000020:notes:27]
In February 2013, the Financial Accounting Standards Board (the "FASB") issued Accounting Standards Update ("ASU") No. 2013-02, Topic 350 - Comprehensive Income ("ASU 2013-02"), which amends Topic 220 to improve the reporting of reclassifications out of accumulated other comprehensive income to the respective line items in net income. ASU 2013-02 is effective for annual reporting periods, and interim periods within those years, beginning after December 15, 2012. The Company intends to adopt this standard in the first quarter of 2014 and does not expect the adoption will have a material impact on its consolidated results of operations or financial condition.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-13-000020:notes:28]
The following table summarizes deferred revenue, net at March 31, 2013 and June 30, 2012, respectively (in thousands):

[0001078271-13-000020:notes:29]
|  | March 31, 2013 |  | June 30, 2012 |
| Deferred services | $ | 37,397 |  |  | $ | 37,708 |  |
| Deferred product: |  |  |  |
| Deferred revenue | 3,287 |  |  | 2,236 |  |
| Deferred cost of sales | (277 | ) |  | (616 | ) |
| Deferred product revenue, net | 3,010 |  |  | 1,620 |  |
| Balance at end of period | 40,407 |  |  | 39,328 |  |
| Less: current portion | 32,400 |  |  | 31,769 |  |
| Non-current deferred revenue, net | $ | 8,007 |  |  | $ | 7,559 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-13-000020:notes:30]
[same as prior period, unchanged from 0001078271-13-000006:notes:29]

[0001078271-13-000020:notes:31]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. At March 31, 2013, these forward foreign currency contracts had a notional principal amount of $7.5 million and an immaterial unrealized gain on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-13-000020:notes:32]
Foreign currency transaction gains and losses from operations were a $0.1 million  loss for the three months ended March 31, 2013 and a $0.2 million gain for the three months ended April 1, 2012.  Foreign currency transaction gains and losses were an immaterial gain for the nine months ended March 31, 2013 and a  $0.1 million gain for the nine months ended April 1, 2012.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-13-000020:notes:33]
[same as prior period, unchanged from 0001078271-13-000006:notes:32]

[0001078271-13-000020:notes:34]
[same as prior period, unchanged from 0001078271-13-000006:notes:33]

[0001078271-13-000020:notes:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Cost of product revenue | $ | 118 |  |  | $ | 81 |  |  | $ | 413 |  |  | $ | 372 |  |
| Cost of service revenue | 61 |  |  | 59 |  |  | 304 |  |  | 203 |  |
| Research and development | 268 |  |  | 289 |  |  | 988 |  |  | 1,041 |  |
| Sales and marketing | 756 |  |  | 487 |  |  | 2,051 |  |  | 1,306 |  |
| General and administrative | 638 |  |  | 560 |  |  | 1,869 |  |  | 1,730 |  |
| Total share-based compensation expense | $ | 1,841 |  |  | $ | 1,476 |  |  | $ | 5,625 |  |  | $ | 4,652 |  |

[0001078271-13-000020:notes:36]
During the three and nine months ended March 31, 2013 and April 1, 2012, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial. The income tax benefit for share-based compensation expense was immaterial in the three and nine months ended March 31, 2013 and April 1, 2012.

[0001078271-13-000020:notes:37]
The weighted-average grant-date per share fair value of options granted during the three months ended March 31, 2013 and April 1, 2012 were $1.72 and $1.58, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended March 31, 2013 and April 1, 2012 were $0.86 and $1.05, respectively.

[0001078271-13-000020:notes:38]
The weighted-average grant-date per share fair value of options granted during the nine months ended March 31, 2013 and April 1, 2012 were $2.71 and $1.65, respectively. The weighted-average estimated per share fair value of shares purchased under the ESPP during the nine months ended March 31, 2013 and April 1, 2012 were $0.88 and $1.01, respectively.

[0001078271-13-000020:notes:39]
The following table summarizes stock option activity under all plans for the nine months ended March 31, 2013:

[0001078271-13-000020:notes:40]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2012 | 9,006 |  |  | $ | 3.68 |  |  |  |  |  |
| Granted | 2,214 |  |  | $ | 3.50 |  |  |  |  |  |
| Exercised | (689 | ) |  | $ | 2.83 |  |  |  |  | $ | 499 |  |
| Cancelled | (1,113 | ) |  | $ | 3.78 |  |  |  |  |  |
| Options outstanding at March 31, 2013 | 9,418 |  |  | $ | 3.69 |  |  | 4.69 |  | $ | 1,497 |  |
| Exercisable at March 31, 2013 | 5,622 |  |  | $ | 3.88 |  |  | 3.87 |  | $ | 1,260 |  |
| Vested and expected to vest at March 31, 2013 | 8,986 |  |  | $ | 3.70 |  |  | 4.62 |  | $ | 1,478 |  |

[0001078271-13-000020:notes:41]
[same as prior period, unchanged from 0001078271-13-000006:notes:40]

[0001078271-13-000020:notes:42]
[same as prior period, unchanged from 0001078271-13-000006:notes:41]

[0001078271-13-000020:notes:43]
The following table summarizes stock award activity for the nine months ended March 31, 2013:

[0001078271-13-000020:notes:44]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2012 | 1,078 |  |  | $ | 2.35 |  |  |  |
| Granted | 3,199 |  |  | $ | 3.49 |  |  |  |
| Vested | (774 | ) |  | $ | 3.40 |  |  | $ | 2,625 |  |
| Cancelled | (273 | ) |  | $ | 3.43 |  |  |  |
| Non-vested stock outstanding at March 31, 2013 | 3,230 |  |  | $ | 3.14 |  |  |  |

[0001078271-13-000020:notes:45]
[same as prior period, unchanged from 0001078271-13-000006:notes:44]

[0001078271-13-000020:notes:46]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Expected life | 4.2 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |  | 4.5 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 0.72 | % |  | 0.88 | % |  | 0.10 | % |  | 0.13 | % |  | 0.71 | % |  | 1.07 | % |  | 0.07 | % |  | 0.07 | % |
| Volatility | 62 | % |  | 64 | % |  | 42 | % |  | 54 | % |  | 60 | % |  | 60 | % |  | 53 | % |  | 65 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |

[0001078271-13-000020:notes:47]
[same as prior period, unchanged from 0001078271-13-000006:notes:46]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-13-000020:notes:48]
[same as prior period, unchanged from 0001078271-13-000006:notes:47]

[0001078271-13-000020:notes:49]
[same as prior period, unchanged from 0001078271-13-000006:notes:48]


## us-gaap:EarningsPerShareTextBlock

[0001078271-13-000020:notes:50]
[same as prior period, unchanged from 0001078271-13-000006:notes:49]

[0001078271-13-000020:notes:51]
[same as prior period, unchanged from 0001078271-13-000006:notes:50]

[0001078271-13-000020:notes:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Net (loss) income | $ | (2,220 | ) |  | $ | 2,372 |  |  | $ | 6,489 |  |  | $ | 8,062 |  |
| Weighted-average shares used in per share calculation – basic | 92,968 |  |  | 93,659 |  |  | 94,069 |  |  | 93,205 |  |
| Incremental shares using the treasury stock method: |  |  |  |  |  |  |  |
| Stock options | — |  |  | 389 |  |  | 391 |  |  | 329 |  |
| Restricted stock units | — |  |  | 474 |  |  | 526 |  |  | 595 |  |
| Employee Stock Purchase Plan | — |  |  | 78 |  |  | 108 |  |  | 116 |  |
| Weighted -average share used in per share calculation – diluted | 92,968 |  |  | 94,600 |  |  | 95,094 |  |  | 94,245 |  |
| Net income (loss) per share – basic | (0.02 | ) |  | 0.03 |  |  | 0.07 |  |  | 0.09 |  |
| Net income (loss) per share – diluted | (0.02 | ) |  | 0.03 |  |  | 0.07 |  |  | 0.09 |  |

[0001078271-13-000020:notes:53]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For the three and nine months ended March 31, 2013, the Company excluded 7.1 million and 7.2 million outstanding weighted average stock options, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.  The Company excluded 8.2 million and 8.5 million outstanding weighted average stock options from the calculation of diluted earnings per common share in the three and nine months ended April 1, 2012 because they would have been anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-13-000020:notes:54]
[same as prior period, unchanged from 0001078271-13-000006:notes:53]

[0001078271-13-000020:notes:55]
[same as prior period, unchanged from 0001078271-13-000006:notes:54]

[0001078271-13-000020:notes:56]
[same as prior period, unchanged from 0001078271-13-000006:notes:55]

[0001078271-13-000020:notes:57]
[same as prior period, unchanged from 0001078271-13-000006:notes:56]

[0001078271-13-000020:notes:58]
| March 31, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Federal agency notes | $ | — |  |  | $ | 5,513 |  |  | $ | — |  |  | $ | 5,513 |  |
| Money market funds | 54,179 |  |  | — |  |  | — |  |  | 54,179 |  |
| Corporate notes/bonds | — |  |  | 105,994 |  |  | — |  |  | 105,994 |  |
| Foreign currency forward contracts | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Total | $ | 54,179 |  |  | $ | 111,533 |  |  | $ | — |  |  | $ | 165,712 |  |

[0001078271-13-000020:notes:59]
[same as prior period, unchanged from 0001078271-13-000006:notes:58]

[0001078271-13-000020:notes:60]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three and nine months ended March 31, 2013 and April 1, 2012.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-13-000020:notes:61]
[same as prior period, unchanged from 0001078271-13-000006:notes:60]

[0001078271-13-000020:notes:62]
[same as prior period, unchanged from 0001078271-13-000006:notes:61]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-13-000020:notes:63]
[same as prior period, unchanged from 0001078271-13-000006:notes:62]

[0001078271-13-000020:notes:64]
The Company recorded an income tax provision of $0.4 million and $0.5 million for the three months ended March 31, 2013 and April 1, 2012, respectively.  The Company recorded an income tax provision of $1.4 million and $1.2 million for the nine months ended March 31, 2013 and April 1, 2012 respectively.

[0001078271-13-000020:notes:65]
The income tax provisions for the three and nine months ended March 31, 2013 and April 1, 2012 consisted primarily of taxes on foreign income and U.S. state income taxes. The income tax provisions for both fiscal years were calculated based on the results of operations for the three and nine months ended March 31, 2013 and April 1, 2012, and may not reflect the annual effective rate.

[0001078271-13-000020:notes:66]
We have provided a full valuation allowance for our U.S. net deferred tax assets after assessing both negative and positive evidence when measuring the need for a valuation allowance. For the current quarter, negative evidence, such as the Company's current quarter financial performance, the Company's significant restructuring in the current quarter, and the unfavorable macroeconomic climate were given more weight than our expectations of future profitability, which are inherently uncertain.  Accordingly, we believe that there is sufficient negative evidence to maintain a full valuation allowance against our U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results have sufficiently improved to support realization of our U.S. deferred tax assets.

[0001078271-13-000020:notes:67]
[same as prior period, unchanged from 0001078271-13-000006:notes:67]

[0001078271-13-000020:notes:68]
The Company had $25.8 million of unrecognized tax benefits as of March 31, 2013. The future impact of the unrecognized tax benefit of $25.8 million, if recognized, is as follows: approximately $0.5 million would impact the effective tax rate, and approximately $25.3 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-13-000020:notes:69]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Consolidated Statements of Operations and were immaterial for both the three months and nine months periods ended March 31, 2013. Accrued interest and penalties were $0.1 million and $0.2 million as of March 31, 2013 and April 1, 2012, respectively.

[0001078271-13-000020:notes:70]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 1999 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2001 forward due to net operating losses.


## us-gaap:InventoryPolicyTextBlock

[0001078271-13-000020:notes:71]
[same as prior period, unchanged from 0001078271-13-000006:notes:71]

[0001078271-13-000020:notes:72]
[same as prior period, unchanged from 0001078271-13-000006:notes:72]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-13-000020:notes:73]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with original maturities of greater than three months, but less than one year at the balance sheet date are classified as Short Term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

[0001078271-13-000020:notes:74]
[same as prior period, unchanged from 0001078271-13-000006:notes:74]

[0001078271-13-000020:notes:75]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. During the three and nine months ended March 31, 2013, realized gains or losses recognized on the sale of investments were not significant. As of March 31, 2013, nineteen out of sixty-three investment securities had unrealized losses. The unrealized gains / (losses) on the Company’s investments were caused by interest rate fluctuations. Substantially all of the Company’s available-for-sale investments are investment grade government and corporate debt securities that have maturities of less than three years. The Company does not intend to sell the investments and it is not more likely than not that the Company will be required to sell the investments before recovery of its amortized costs.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-13-000020:notes:76]
Recently Issued Accounting Pronouncements


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-13-000020:notes:77]
[same as prior period, unchanged from 0001078271-13-000006:notes:76]

[0001078271-13-000020:notes:78]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2012 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2012.

[0001078271-13-000020:notes:79]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2013. The results of operations for the three and nine months ended March 31, 2013 are not necessarily indicative of the results that may be expected for fiscal 2013 or any future periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-13-000020:notes:80]
[same as prior period, unchanged from 0001078271-13-000006:notes:79]

[0001078271-13-000020:notes:81]
As part of the Company's on-going restructuring efforts, during the second quarter of fiscal year 2013, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. Restructuring expense was $1.1 million and $6.2 million in the three and nine months ended March 31, 2013.  Restructuring expense was not significant in the three months ended April 1, 2012 and was $1.4 million in the nine months ended April 1, 2012, respectively.

[0001078271-13-000020:notes:82]
The following table summarizes restructuring activities for the nine months ended March 31, 2013:

[0001078271-13-000020:notes:83]
|  |  | Termination Benefits (1) |  | Excess Facilities (2) |  | Other Cost |  | Total |
| Balance at July 1, 2012 |  | $ | 359 |  |  | $ | 93 |  |  | $ | 11 |  |  | $ | 463 |  |
| Period charges |  | 5,986 |  |  | 114 |  |  | 275 |  |  | 6,375 |  |
| Period reversals |  | (133 | ) |  | — |  |  | — |  |  | (133 | ) |
| Period payments |  | (4,464 | ) |  | (181 | ) |  | (286 | ) |  | (4,931 | ) |
| Restructuring liabilities at March 31, 2013 |  | $ | 1,748 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 1,774 |  |

[0001078271-13-000020:notes:84]
[same as prior period, unchanged from 0001078271-13-000006:notes:83]

[0001078271-13-000020:notes:85]
[same as prior period, unchanged from 0001078271-13-000006:notes:84]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-13-000020:notes:86]
[same as prior period, unchanged from 0001078271-13-000006:notes:85]

[0001078271-13-000020:notes:87]
[same as prior period, unchanged from 0001078271-13-000006:notes:86]

[0001078271-13-000020:notes:88]
[same as prior period, unchanged from 0001078271-13-000006:notes:87]

[0001078271-13-000020:notes:89]
[same as prior period, unchanged from 0001078271-13-000006:notes:88]


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-13-000020:notes:90]
[same as prior period, unchanged from 0001078271-13-000006:notes:89]

[0001078271-13-000020:notes:91]
[same as prior period, unchanged from 0001078271-13-000006:notes:90]

[0001078271-13-000020:notes:92]
|  | March 31, 2013 |  | June 30, 2012 |
| Cash | $ | 23,413 |  |  | $ | 18,455 |  |
| Cash equivalents | 54,179 |  |  | 36,141 |  |
| Short-term investments | 42,336 |  |  | 23,358 |  |
| Marketable securities | 69,171 |  |  | 75,561 |  |
| Total available-for-sale | $ | 165,686 |  |  | $ | 135,060 |  |
| Total cash and available for sale securities | $ | 189,099 |  |  | $ | 153,515 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-13-000020:notes:93]
The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2013 and April 1, 2012:

[0001078271-13-000020:notes:94]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Balance beginning of period | $ | 2,971 |  |  | $ | 2,651 |  |  | $ | 2,871 |  |  | $ | 2,640 |  |
| New warranties issued | 1,257 |  |  | 1,556 |  |  | 4,761 |  |  | 4,793 |  |
| Warranty expenditures | (1,332 | ) |  | (1,365 | ) |  | (4,736 | ) |  | (4,591 | ) |
| Balance end of period | $ | 2,896 |  |  | $ | 2,842 |  |  | $ | 2,896 |  |  | $ | 2,842 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-13-000020:notes:95]
The Company attributes revenues to geographic regions primarily based on the customer's ship-to location.  Amounts for the three and nine months ended April 1, 2012  have been revised to correct previously disclosed amounts.  Information regarding geographic areas is as follows (in thousands):

[0001078271-13-000020:notes:96]
|  | Three Months Ended |  | Nine Months Ended |
| Net Revenues: | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 21,609 |  |  | $ | 23,452 |  |  | $ | 69,545 |  |  | $ | 75,841 |  |
| Other | 6,414 |  |  | 7,464 |  |  | 26,959 |  |  | 26,976 |  |
| Total Americas | 28,023 |  |  | 30,916 |  |  | 96,504 |  |  | 102,817 |  |
| EMEA | 28,481 |  |  | 30,349 |  |  | 85,700 |  |  | 91,164 |  |
| APAC | 11,699 |  |  | 12,103 |  |  | 37,677 |  |  | 41,093 |  |
| Total net revenues | $ | 68,203 |  |  | $ | 73,368 |  |  | $ | 219,881 |  |  | $ | 235,074 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-13-000020:notes:97]
The following table sets forth major customers accounting for 10% or more of our net revenue (amounts for the three and nine months ended April 1, 2012 have been revised to correct previously disclosed amounts):

[0001078271-13-000020:notes:98]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Westcon Group Inc. |  | 19 | % |  | 20 | % |  | 10 | % |  | 19 | % |
| Tech Data |  | 11 | % |  | * |  |  | * |  |  | * |  |
| Scansource, Inc. |  | 10 | % |  | 12 | % |  | * |  |  | 13 | % |
| Ericsson AB |  | * |  |  | 11 | % |  | * |  |  | 11 | % |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-13-000020:notes:99]
[same as prior period, unchanged from 0001078271-13-000006:notes:105]

[0001078271-13-000020:notes:100]
[same as prior period, unchanged from 0001078271-13-000006:notes:106]

[0001078271-13-000020:notes:101]
[same as prior period, unchanged from 0001078271-13-000006:notes:107]

[0001078271-13-000020:notes:102]
Substantially all of the Company’s assets were attributable to North America operations at March 31, 2013 and June 30, 2012.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-13-000020:notes:103]
[same as prior period, unchanged from 0001078271-13-000006:notes:109]


## us-gaap:SubsequentEventsTextBlock

[0001078271-13-000020:notes:104]
Subsequent Events

[0001078271-13-000020:notes:105]
On April 25, 2013, the Company announced the resignation of Oscar Rodriguez as President and Chief Executive Officer of the Company as well as his resignation from the Board of Directors.   At the same time, the Company announced the appointment of  Mr. Charles W. “Chuck” Berger as its President and Chief Executive Officer, as well as elected him to the Board of Directors, effective as of April 25, 2013.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-13-000020:notes:106]
[same as prior period, unchanged from 0001078271-13-000006:notes:110]

[0001078271-13-000020:notes:107]
On September 11, 2012, the Company completed the sale of its corporate campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million and realized a gain of approximately $11.5 million.

[0001078271-13-000020:notes:108]
[same as prior period, unchanged from 0001078271-13-000006:notes:114]

[0001078271-13-000020:notes:109]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net at March 31, 2013 and June 30, 2012, respectively (in thousands):

[0001078271-13-000020:notes:110]
[same as prior period, unchanged from 0001078271-13-000006:notes:116]

[0001078271-13-000020:notes:111]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2013 |  | April 1, 2012 |  | March 31, 2013 |  | April 1, 2012 |
| Balance beginning of period | $ | 35,797 |  |  | $ | 37,416 |  |  | $ | 37,461 |  |  | $ | 35,802 |  |
| New support arrangements | 14,431 |  |  | 15,115 |  |  | 41,745 |  |  | 45,675 |  |
| Recognition of support revenue | (13,420 | ) |  | (14,364 | ) |  | (42,398 | ) |  | (43,310 | ) |
| Balance end of period | 36,808 |  |  | 38,167 |  |  | 36,808 |  |  | 38,167 |  |
| Less: current portion | 28,801 |  |  | 30,538 |  |  | 28,801 |  |  | 30,538 |  |
| Non-current deferred revenue | $ | 8,007 |  |  | $ | 7,629 |  |  | $ | 8,007 |  |  | $ | 7,629 |  |

[0001078271-13-000020:notes:112]
[same as prior period, unchanged from 0001078271-13-000006:notes:118]

[0001078271-13-000020:notes:113]
[same as prior period, unchanged from 0001078271-13-000006:notes:119]

[0001078271-13-000020:notes:114]
[same as prior period, unchanged from 0001078271-13-000006:notes:120]

[0001078271-13-000020:notes:115]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at March 31, 2013 and June 30, 2012, respectively (in thousands):

[0001078271-13-000020:notes:116]
|  | March 31, 2013 |  | June 30, 2012 |
| Deferred distributors revenue | $ | 17,562 |  |  | $ | 20,361 |  |
| Deferred cost of sales to distributors | (4,030 | ) |  | (5,042 | ) |
| Total deferred distributors revenue, net of cost of sales to distributors | $ | 13,532 |  |  | $ | 15,319 |  |

[0001078271-13-000020:notes:117]
[same as prior period, unchanged from 0001078271-13-000006:notes:123]

[0001078271-13-000020:notes:118]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2013 and April 1, 2012:

[0001078271-13-000020:notes:119]
The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001078271-13-000020:notes:120]
[same as prior period, unchanged from 0001078271-13-000006:notes:126]

[0001078271-13-000020:notes:121]
[same as prior period, unchanged from 0001078271-13-000006:notes:127]

[0001078271-13-000020:notes:122]
[same as prior period, unchanged from 0001078271-13-000006:notes:128]

[0001078271-13-000020:notes:123]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit. The Company noted the greater than 10% receivable concentration in its customer base as of March 31, 2013 is not materially different than it was as of June 30, 2012.


## us-gaap:TreasuryStockTextBlock

[0001078271-13-000020:notes:124]
[same as prior period, unchanged from 0001078271-13-000006:notes:130]

[0001078271-13-000020:notes:125]
[same as prior period, unchanged from 0001078271-13-000006:notes:131]

[0001078271-13-000020:notes:126]
[same as prior period, unchanged from 0001078271-13-000006:notes:132]

[0001078271-13-000020:notes:127]
[same as prior period, unchanged from 0001078271-13-000006:notes:133]

[0001078271-13-000020:notes:128]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which may be purchased over a three year period in the open market or in privately negotiated transactions. All repurchased shares will be retired and included in the Company's authorized but unissued shares. During the three months ended March 31, 2013, the Company repurchased 1.2 million shares of common stock at a total cost of $4.2 million.  During the nine months ended March 31, 2013, the Company repurchased 3.1 million shares of common stock at a total cost of $11.0 million.
