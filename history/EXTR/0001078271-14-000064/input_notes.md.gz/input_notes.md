# EXTR notes — 0001078271-14-000064


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-14-000064:notes:1]
[same as prior period, unchanged from 0001078271-14-000020:notes:2]

[0001078271-14-000064:notes:2]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| September 30, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 2,877 |  |  | $ | 2,877 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 30,338 |  |  | 30,395 |  |  | 57 |  |  | — |  |
|  | $ | 33,215 |  |  | $ | 33,272 |  |  | $ | 57 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,877 |  |  | $ | 2,877 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 30,338 |  |  | 30,395 |  |  | 57 |  |  | — |  |
|  | $ | 33,215 |  |  | $ | 33,272 |  |  | $ | 57 |  |  | $ | — |  |
| June 30, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
| Marketable securities | — |  |  | — |  |  | — |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |

[0001078271-14-000064:notes:3]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at September 30, 2014, by contractual maturity, were as follows (in thousands):

[0001078271-14-000064:notes:4]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 23,312 |  |  | $ | 23,363 |  |
| Due in 1-2 years | 6,024 |  |  | 6,027 |  |
| Due in 2-5 years | 1,002 |  |  | 1,005 |  |
| Total investments in available for sale debt securities | $ | 30,338 |  |  | $ | 30,395 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001078271-14-000064:notes:5]
[same as prior period, unchanged from 0001078271-14-000020:notes:8]

[0001078271-14-000064:notes:6]
On October 31, 2013 (the “Acquisition Date”), the Company completed the acquisition of Enterasys Networks, Inc. ("Enterasys"), a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired. The Company also assumed outstanding options and restricted stock units of Enterasys at the Acquisition Date, all of which were unvested.

[0001078271-14-000064:notes:7]
The acquisition was accounted for using the acquisition method of accounting. The preliminary and final purchase price allocation as of the date of the acquisition is set forth in the table below and reflects various fair value estimates.

[0001078271-14-000064:notes:8]
The following table summarizes the final allocation as of September 30, 2014 of the tangible and identifiable intangible assets acquired and liabilities assumed as compared to the allocation as of December 31, 2013, the quarter in which the transaction was completed:

[0001078271-14-000064:notes:9]
|  |  | Preliminary Allocation as of December 31, 2013 (Initial allocation) |  | Change during the measurement period |  | Final Allocation as of September 30, 2014 |
| Cash |  | $ | 4,969 |  |  | $ | 2,428 |  | a | $ | 7,397 |  |
| Receivables |  | 25,699 |  |  | (2,428 | ) | a | 23,271 |  |
| Inventory |  | 33,662 |  |  | — |  |  | 33,662 |  |
| Other current assets |  | 8,888 |  |  | (1,514 | ) | b | 7,374 |  |
| Property and equipment |  | 23,122 |  |  | (1,829 | ) | c | 21,293 |  |
| Identifiable intangible assets |  | 108,900 |  |  | — |  | d | 108,900 |  |
| In-process research and development |  | 3,000 |  |  | — |  |  | 3,000 |  |
| Deferred tax assets |  | 9 |  |  | — |  |  | 9 |  |
| Other assets |  | 7,343 |  |  | — |  |  | 7,343 |  |
| Goodwill |  | 57,922 |  |  | 12,955 |  |  | 70,877 |  |
| Current liabilities |  | (75,394 | ) |  | (6,141 | ) | c,e,f | (81,535 | ) |
| Other long-term liabilities |  | (13,151 | ) |  | (1,043 | ) | c | (14,194 | ) |
| Total purchase price allocation |  | $ | 184,969 |  |  | $ | 2,428 |  |  | $ | 187,397 |  |
| Less: Cash acquired from acquisition |  | (4,969 | ) |  | (2,428 | ) | a | (7,397 | ) |
| Total purchase price consideration, net of cash acquired |  | $ | 180,000 |  |  | $ | — |  |  | $ | 180,000 |  |

[0001078271-14-000064:notes:10]
a.The Company finalized the working capital adjustment during the nine months ended September 30, 2014, which led to a decrease of $2.4 million in receivables and a corresponding increase in cash.  As a result of this adjustment, the total cash acquired from the acquisition also increased by the same amount.  The net effect of this adjustment is an increase in goodwill of $2.4 million.

[0001078271-14-000064:notes:11]
b.The Company obtained new information regarding the existence of prepaids as of the acquisition date which led to a decrease in the fair value of current assets of $1.5 million, and a corresponding increase in goodwill.  The change in the amortization of prepaids due to the change in fair value of current assets was immaterial.

[0001078271-14-000064:notes:12]
c.The Company updated its preliminary estimate of the fair value of property and equipment which led to a decrease of $3.0 million in property and equipment with a corresponding increase in goodwill.  The Company also updated the fair values of the asset retirement obligations and the related asset retirement assets which led to an increase in the fair value of property and equipment of $1.2 million and a corresponding increase in current liabilities and other long-term liabilities of $0.2 million and $1.0 million, respectively.  The decrease in depreciation expense due to the change in fair value of property and equipment was immaterial.

[0001078271-14-000064:notes:13]
d.During the nine months ended September 30, 2014, there were no changes to the fair value of the identifiable intangible assets acquired.  However, the Company revised the estimated useful life of Order backlog from 1.5 years to 1 year.

[0001078271-14-000064:notes:14]
e.The Company obtained new information regarding accruals for litigation and statutory tax assessment as of the acquisition date which led to an increase in the fair value of current liabilities of $5.4 million and a corresponding increase in goodwill.

[0001078271-14-000064:notes:15]
f.The Company obtained new information regarding the existence of accrued liabilities as of the acquisition date which led to a net increase in the fair value of accrued liabilities by $0.5 million with a corresponding increase in goodwill.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-14-000064:notes:16]
Commitments and Contingencies

[0001078271-14-000064:notes:17]
Purchase Commitments

[0001078271-14-000064:notes:18]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2014, the Company had non-cancelable commitments to purchase approximately $90.7 million of such inventory.

[0001078271-14-000064:notes:19]
Legal Proceedings

[0001078271-14-000064:notes:20]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-14-000064:notes:21]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-14-000064:notes:22]
Intellectual Property Litigation

[0001078271-14-000064:notes:23]
Net Navigation Systems, LLC.

[0001078271-14-000064:notes:24]
On April 23, 2014, Net Navigation Systems, LLC (“Net Navigation”) filed a complaint against Extreme Networks, Inc. in the Eastern District of Texas.  In the Complaint, the plaintiff asserts infringement of U.S. Patent No. 6,625,122 (“the ’122 Patent”), entitled “Selection of Data for Network Transmission,” which issued on September 23, 2003.  Although somewhat vague, the Complaint identifies the following products as accused of infringing the ‘122 Patent:  “Networking products capable of providing priority to different data flows based on bandwidth.”  The Complaint also states that Extreme has infringed by “making, selling, and causing its customers to use networking products capable of providing priority to different data flows based on bandwidth, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.”  The Complaint also asserts infringement of U.S. Patent No. 6,434,145 (“the ’145 Patent”), entitled “Processing of Network Data by Parallel Processing Channels,” which issued on August 13, 2002.  Again, although somewhat vague, the Complaint states that Extreme has infringed by “making, using, importing, selling, and/or offering for sale in the United States, including within this judicial district, networking products that use parallel processing channels, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.” Net Navigation, a non-practicing entity, seeks injunctive relief as well as monetary damages, cost, expenses and attorney fees, although the complaint seeks no quantified amount.  The Company denies the claims and is preparing to vigorously defend our technology.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

[0001078271-14-000064:notes:25]
Selene Communication Technologies, LLC.

[0001078271-14-000064:notes:26]
On April 7, 2014, Selene Communication Technologies, LLC (“Selene”), filed a complaint in the US District Court for the District of Delaware against Extreme and Enterasys asserting a cause of action for infringement of United States Patent No. 7,143,444 (the “444 Patent”). Selene has also recently sued a number of other technology companies including Cisco for infringement of the 444 Patent.  Selene, a non-practicing entity, seeks injunctive relief as well as monetary damages, costs, expenses and attorney fees, although the complaint seeks no quantified amount.

[0001078271-14-000064:notes:27]
The Company is a member of RPX Corporation’s (“RPX”) network of clients, who procure patent risk management services from RPX.  On September 30, 2014, RPX signed an agreement on behalf of its members (including Extreme) with Selene to resolve the litigation cases against its members by Selene and to obtain a license for all RPX members to the 444 Patent and its foreign counterparts.  As a result, the Company expects this case to be dismissed shortly without any further liability to Company.

[0001078271-14-000064:notes:28]
Commonwealth of Kentucky

[0001078271-14-000064:notes:29]
On or about February 3, 2014, a class action lawsuit was filed in the Commonwealth of Kentucky against Enterasys Networks, Inc. and two other defendants.  The complaint alleges that Enterasys and its subcontractor, TJL Information Technologies, Inc., d.b.a. Unbridled Information Technologies (“Subcontractor”), violated Kentucky’s wage and hour laws and failed to pay the prevailing wage in violation of the Kentucky State Prevailing Wage Act (the “Act”) on various public works projects for a number of Kentucky government agencies since January 2010.  Plaintiffs also allege common law actions for quantum merit and unjust enrichment and they seek monetary damages, costs, expenses and attorney fees, although there was no quantified amount identified.  One of the defendants, Integrated Facility Systems, LLC (“IFS”), has also filed a cross-claim against Enterasys.  The Company denies the claims and filed answers to both the complaint and cross-claim on April 16, 2014.  In addition, the Company filed a cross-claim for indemnity against IFS.

[0001078271-14-000064:notes:30]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014 and is considering filing a cross-claim against COT.  This litigation is in the early stages of discovery.

[0001078271-14-000064:notes:31]
ICMS Tax Assessment Matters

[0001078271-14-000064:notes:32]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014 by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US$1.5 million), plus interest and penalties (that are currently estimated to be approximately US$9 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  In the first week of October, the preliminary injunction was granted with regard to the stay of execution; however, the court ruled that a cash deposit of the full amount at issue is to be made by Enterasys.  Enterasys then prepared a motion aimed at the partial reconsideration of such decision concerning the need for a deposit, which was denied on October 10, 2014.  The Company is currently considering an appeal to the Court of Appeals against such denial.

[0001078271-14-000064:notes:33]
Given the preliminary nature of the lawsuit and the uncertainty of the legal environment in Brazil, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position, cash flows or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from $0 million to $9 million, of which the Company believes $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.

[0001078271-14-000064:notes:34]
Indemnification Obligations

[0001078271-14-000064:notes:35]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of September 30, 2014, the Company had no outstanding indemnification claims.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-14-000064:notes:36]
The following table summarizes deferred revenue, net at September 30, 2014 and June 30, 2014, respectively (in thousands):

[0001078271-14-000064:notes:37]
|  | September 30, 2014 |  | June 30, 2014 |
| Deferred services | $ | 87,012 |  |  | $ | 89,657 |  |
| Deferred product and other revenue | 7,555 |  |  | 8,020 |  |
| Total deferred revenue | 94,567 |  |  | 97,677 |  |
| Less: current portion | 72,599 |  |  | 74,735 |  |
| Non-current deferred revenue, net | $ | 21,968 |  |  | $ | 22,942 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-14-000064:notes:38]
[same as prior period, unchanged from 0001078271-14-000020:notes:43]

[0001078271-14-000064:notes:39]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. At September 30, 2014, these forward foreign currency contracts had a notional principal amount of $11.4 million and an immaterial unrealized loss on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-14-000064:notes:40]
Foreign currency transaction gains and losses from operations were a $0.4 million loss and a $0.1 million loss for the three months ended September 30, 2014 and September 30, 2013, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-14-000064:notes:41]
[same as prior period, unchanged from 0001078271-14-000020:notes:46]

[0001078271-14-000064:notes:42]
[same as prior period, unchanged from 0001078271-14-000020:notes:47]

[0001078271-14-000064:notes:43]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Cost of product revenue | $ | 283 |  |  | $ | 102 |  |
| Cost of service revenue | 291 |  |  | 40 |  |
| Research and development | 1,644 |  |  | 243 |  |
| Sales and marketing | 1,557 |  |  | 570 |  |
| General and administrative | 1,038 |  |  | 620 |  |
| Total share-based compensation expense | $ | 4,813 |  |  | $ | 1,575 |  |

[0001078271-14-000064:notes:44]
During the three months ended September 30, 2014 and 2013, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial. The income tax benefit for share-based compensation expense was immaterial in the three months ended September 30, 2014 and 2013.

[0001078271-14-000064:notes:45]
The weighted-average grant-date per share fair value of options granted during the three months ended September 30, 2014 and 2013 was $2.39 and $2.24, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended September 30, 2014 and 2013 was $1.50 and $1.07, respectively.

[0001078271-14-000064:notes:46]
The following table summarizes stock option activity under all plans for the three months ended September 30, 2014:

[0001078271-14-000064:notes:47]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2014 | 11,732 |  |  | $ | 4.26 |  |  |  |  |  |
| Granted | 432 |  |  | $ | 5.21 |  |  |  |  |  |
| Exercised | (149 | ) |  | $ | 3.36 |  |  |  |  | $ | 245 |  |
| Cancelled | (785 | ) |  | $ | 4.95 |  |  |  |  |  |
| Options outstanding at September 30, 2014 | 11,230 |  |  | $ | 4.25 |  |  | 5.00 |  | $ | 8,795 |  |
| Exercisable at September 30, 2014 | 5,135 |  |  | $ | 3.85 |  |  | 3.87 |  | $ | 5,487 |  |
| Vested and expected to vest at September 30, 2014 | 10,232 |  |  | $ | 4.21 |  |  | 4.89 |  | $ | 8,329 |  |

[0001078271-14-000064:notes:48]
[same as prior period, unchanged from 0001078271-14-000020:notes:55]

[0001078271-14-000064:notes:49]
[same as prior period, unchanged from 0001078271-14-000020:notes:56]

[0001078271-14-000064:notes:50]
The following table summarizes stock award activity for the three months ended September 30, 2014:

[0001078271-14-000064:notes:51]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2014 | 6,000 |  |  | $ | 4.98 |  |  |  |
| Granted | 124 |  |  | $ | 5.21 |  |  |  |
| Vested | (88 | ) |  | $ | 3.71 |  |  | $ | 422 |  |
| Cancelled | (279 | ) |  | $ | 4.28 |  |  |  |
| Non-vested stock outstanding at September 30, 2014 | 5,757 |  |  | $ | 5.04 |  |  |  |

[0001078271-14-000064:notes:52]
.

[0001078271-14-000064:notes:53]
[same as prior period, unchanged from 0001078271-14-000020:notes:60]

[0001078271-14-000064:notes:54]
The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of performance-based option awards, with market conditions, on the date of the grant.

[0001078271-14-000064:notes:55]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | September 30, 2014 |  | September 30, 2013 |
| Expected life | 5 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.52 | % |  | 1.53 | % |  | 0.02 | % |  | 0.09 | % |
| Volatility | 54 | % |  | 64 | % |  | 53 | % |  | 32 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-14-000064:notes:56]
[same as prior period, unchanged from 0001078271-14-000020:notes:64]

[0001078271-14-000064:notes:57]
[same as prior period, unchanged from 0001078271-14-000020:notes:65]


## us-gaap:EarningsPerShareTextBlock

[0001078271-14-000064:notes:58]
[same as prior period, unchanged from 0001078271-14-000020:notes:66]

[0001078271-14-000064:notes:59]
[same as prior period, unchanged from 0001078271-14-000020:notes:67]

[0001078271-14-000064:notes:60]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Net (loss) income | $ | (19,330 | ) |  | $ | (35 | ) |
| Weighted-average shares used in per share calculation – basic | 97,314 |  |  | 94,062 |  |
| Incremental shares using the treasury stock method: |  |  |  |
| Stock options | — |  |  | — |  |
| Restricted stock units | — |  |  | — |  |
| Employee Stock Purchase Plan | — |  |  | — |  |
| Weighted -average share used in per share calculation – diluted | 97,314 |  |  | 94,062 |  |
| Net (loss) income per share – basic | $ | (0.20 | ) |  | $ | 0.00 |  |
| Net (loss) income per share – diluted | $ | (0.20 | ) |  | $ | 0.00 |  |

[0001078271-14-000064:notes:61]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For the three months ended September 30, 2014 and 2013, the Company excluded 8.6 million and 6.8 million outstanding weighted average stock options and awards, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-14-000064:notes:62]
[same as prior period, unchanged from 0001078271-14-000020:notes:70]

[0001078271-14-000064:notes:63]
The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis:

[0001078271-14-000064:notes:64]
| September 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 2,877 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,877 |  |
| Corporate notes/bonds | — |  |  | 30,395 |  |  | — |  |  | 30,395 |  |
| Foreign currency forward contracts | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Total | $ | 2,877 |  |  | $ | 30,384 |  |  | $ | — |  |  | $ | 33,261 |  |

[0001078271-14-000064:notes:65]
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | — |  |  | $ | — |  |  | $ | 567 |  |
| Corporate notes/bonds | — |  |  | 32,692 |  |  | — |  |  | 32,692 |  |
| Foreign currency forward contracts | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total | $ | 567 |  |  | $ | 32,713 |  |  | $ | — |  |  | $ | 33,280 |  |

[0001078271-14-000064:notes:66]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three months ended September 30, 2014. There were no liabilities as of September 30, 2014 that were being measured using fair value on a recurring basis.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-14-000064:notes:67]
[same as prior period, unchanged from 0001078271-14-000020:notes:77]

[0001078271-14-000064:notes:68]
For the three months ended September 30, 2014 and 2013, the Company recorded an income tax provision of $1.0 million and $0.4 million, respectively.

[0001078271-14-000064:notes:69]
The income tax provisions for the three months ended September 30, 2014 and 2013 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended September 30, 2014 and 2013, and therefore may not reflect the annual effective tax rate.

[0001078271-14-000064:notes:70]
[same as prior period, unchanged from 0001078271-14-000020:notes:80]

[0001078271-14-000064:notes:71]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries.  The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  During the current period, the Company deducted $1.1 million of tax amortization expense related to capitalized goodwill.  As of September 30, 2014, the Company recorded a deferred tax liability of $1.5 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets.

[0001078271-14-000064:notes:72]
The Company had $11.3 million of unrecognized tax benefits as of September 30, 2014. The future impact of the unrecognized tax benefit of $11.3 million, if recognized, is as follows: approximately $0.2 million would impact the effective tax rate, and approximately $11.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-14-000064:notes:73]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Condensed Consolidated Statements of Operations and were immaterial for the three month ended September 30, 2014 and 2013. Accrued interest and penalties were $23,000 and $42,000 as of September 30, 2014 and 2013, respectively.

[0001078271-14-000064:notes:74]
[same as prior period, unchanged from 0001078271-14-000020:notes:84]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-14-000064:notes:75]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with original maturities of greater than three months, but less than one year at the balance sheet date are classified as Short Term Investments. Investments with maturities of greater than one year at balance sheet date which the Company intends to hold for longer than one year are classified as Marketable Securities.

[0001078271-14-000064:notes:76]
The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income (loss) in the stockholders' equity section of its balance sheets. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists).

[0001078271-14-000064:notes:77]
[same as prior period, unchanged from 0001078271-14-000020:notes:87]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-14-000064:notes:78]
Recently Issued Accounting Pronouncements

[0001078271-14-000064:notes:79]
In May 2014, the FASB, jointly with the International Accounting Standards Board, issued Accounting Standard Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers ("ASU 2014-09"). This ASU's core principle is that a reporting entity will recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In applying this new guidance to contracts within its scope, an entity will: (1) identify the contract(s) with a customer, (2) identify the performance obligation in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, this new guidance will require significantly expanded disclosures about revenue recognition. ASU 2014-09 is effective for annual reporting periods (including interim reporting periods within those annual periods) beginning after December 15, 2016. Early application is not permitted. Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this ASU. The Company is currently evaluating the potential effect on its consolidated financial position, results of operations and cash flows from adoption of this standard.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-14-000064:notes:80]
[same as prior period, unchanged from 0001078271-14-000020:notes:90]

[0001078271-14-000064:notes:81]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2014 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2014.

[0001078271-14-000064:notes:82]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2014. The results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-14-000064:notes:83]
[same as prior period, unchanged from 0001078271-14-000020:notes:94]

[0001078271-14-000064:notes:84]
As part of the Company's on-going restructuring efforts, during the second quarter of fiscal year 2013, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. Restructuring expense was $0.1 million in the three months ended September 30, 2013.

[0001078271-14-000064:notes:85]
The following table summarizes restructuring activities for the three months ended September 30, 2014:

[0001078271-14-000064:notes:86]
|  |  | Contract Termination |  | Total |
| Balance at June 30, 2014 |  | $ | 322 |  |  | $ | 322 |  |
| Period payments |  | (136 | ) |  | (136 | ) |
| Restructuring liabilities at September 30, 2014 |  | $ | 186 |  |  | $ | 186 |  |


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-14-000064:notes:87]
[same as prior period, unchanged from 0001078271-14-000020:notes:104]

[0001078271-14-000064:notes:88]
|  | September 30, 2014 |  | June 30, 2014 |
| Cash | $ | 71,190 |  |  | $ | 72,623 |  |
| Cash equivalents | $ | 2,877 |  |  | $ | 567 |  |
| Short-term investments | 30,395 |  |  | 32,692 |  |
| Total available-for-sale | $ | 33,272 |  |  | $ | 33,259 |  |
| Total cash, cash equivalents and available for sale securities | $ | 104,462 |  |  | $ | 105,882 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-14-000064:notes:89]
The Company's debt is comprised of the following:

[0001078271-14-000064:notes:90]
|  |  | September 30, 2014 |
| Current portion of long-term debt: |  |  |
| Term Loan |  | 6,500 |  |
| Revolving Facility |  | 24,000 |  |
| Current portion of long-term debt |  | 30,500 |  |
| Long-term debt, less current portion: |  |  |
| Term Loan |  | 55,250 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt, less current portion |  | 90,250 |  |
| Total debt |  | 120,750 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-14-000064:notes:91]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2014 and 2013:

[0001078271-14-000064:notes:92]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Balance beginning of period | $ | 7,551 |  |  | $ | 3,296 |  |
| New warranties issued | 2,265 |  |  | 1,304 |  |
| Warranty expenditures | (1,927 | ) |  | (1,160 | ) |
| Balance end of period | $ | 7,889 |  |  | $ | 3,440 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-14-000064:notes:93]
[same as prior period, unchanged from 0001078271-14-000020:notes:115]

[0001078271-14-000064:notes:94]
|  | Three Months Ended |
| Net Revenues: | September 30, 2014 |  | September 30, 2013 |
| Americas: |  |  |  |
| United States | $ | 58,488 |  |  | $ | 25,389 |  |
| Other | 7,341 |  |  | 6,301 |  |
| Total Americas | 65,829 |  |  | 31,690 |  |
| EMEA | 53,934 |  |  | 30,842 |  |
| APAC | 16,511 |  |  | 13,384 |  |
| Total net revenues | $ | 136,274 |  |  | $ | 75,916 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-14-000064:notes:95]
[same as prior period, unchanged from 0001078271-14-000020:notes:119]

[0001078271-14-000064:notes:96]
|  |  | Three Months Ended |
|  |  | September 30, 2014 |  | September 30, 2013 |
| Tech Data |  | 14% |  | * |
| Westcon Group Inc. |  | 13% |  | 18% |
| Scansource, Inc. |  | * |  | 14% |
| * Less than 10% of revenue |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-14-000064:notes:97]
[same as prior period, unchanged from 0001078271-14-000020:notes:121]

[0001078271-14-000064:notes:98]
[same as prior period, unchanged from 0001078271-14-000020:notes:122]

[0001078271-14-000064:notes:99]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan.

[0001078271-14-000064:notes:100]
Of the Company’s total long-lived assets as of September 30, 2014, $98.5 million were attributable to Americas; $41.9 million were attributable to the EMEA region and the remaining to APAC.  Of the total assets as of June 30, 2014, $104.4 million were attributable to Americas, $45.2 million were attributable to the EMEA region and the remaining to APAC.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-14-000064:notes:101]
[same as prior period, unchanged from 0001078271-14-000020:notes:125]

[0001078271-14-000064:notes:102]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual report on Form 10-K for the fiscal year ended June 30, 2014. There have been no material changes to the Company's significant accounting policies since the filing of the Annual report on Form 10-K.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-14-000064:notes:103]
[same as prior period, unchanged from 0001078271-14-000020:notes:132]

[0001078271-14-000064:notes:104]
Cash, Cash Equivalents, Short-Term Investments and Marketable Securities

[0001078271-14-000064:notes:105]
Available-for-Sale Securities

[0001078271-14-000064:notes:106]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income (loss) into earnings using the specific identification method. As of September 30, 2014, four out of eighteen investment securities had unrealized losses.  For investments that were in an unrealized loss position as of September 30, 2014, the other-than-temporary impairment loss was immaterial during the three months ended September 30, 2014.  The Company did not have any other-than temporary impairment loss for the three months ended September 30, 2013.

[0001078271-14-000064:notes:107]
[same as prior period, unchanged from 0001078271-14-000020:notes:138]

[0001078271-14-000064:notes:108]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net at September 30, 2014 and June 30, 2014, respectively (in thousands):

[0001078271-14-000064:notes:109]
The Company offers for sale to its customers, renewable support arrangements that range from one to five years. Deferred support revenue is included within deferred revenue, net within the services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-14-000064:notes:110]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Balance beginning of period | $ | 89,657 |  |  | $ | 38,003 |  |
| New support arrangements | 28,539 |  |  | 13,343 |  |
| Recognition of support revenue | (31,184 | ) |  | (14,255 | ) |
| Balance end of period | 87,012 |  |  | 37,091 |  |
| Less: current portion | 65,044 |  |  | 28,935 |  |
| Non-current deferred revenue | $ | 21,968 |  |  | $ | 8,156 |  |

[0001078271-14-000064:notes:111]
[same as prior period, unchanged from 0001078271-14-000020:notes:142]

[0001078271-14-000064:notes:112]
The Company records revenue from its distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to its distributors in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its condensed consolidated balance sheet. The amount shown as “Deferred distributors revenue, net of cost of sales to distributors” represents the deferred gross margin on sales to distributors based on contractual pricing.

[0001078271-14-000064:notes:113]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at September 30, 2014 and June 30, 2014, respectively (in thousands):

[0001078271-14-000064:notes:114]
|  | September 30, 2014 |  | June 30, 2014 |
| Deferred distributors revenue | $ | 34,206 |  |  | $ | 40,715 |  |
| Deferred cost of sales to distributors | (8,146 | ) |  | (8,723 | ) |
| Deferred distributors revenue, net of cost of sales to distributors | $ | 26,060 |  |  | $ | 31,992 |  |

[0001078271-14-000064:notes:115]
[same as prior period, unchanged from 0001078271-14-000020:notes:147]

[0001078271-14-000064:notes:116]
On October 31, 2013, the Company entered into a Credit Agreement (the “Credit Agreement”) which provides for a $60 million five-year revolving credit facility (the “Revolving Facility”) and a $65 million five-year term loan (the “Term Loan”) and together with the Revolving Facility (the “Senior Secured Credit Facilities”).  The proceeds from the Term Loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The company also drew $35 million of the Revolving Facility to pay a portion of the purchase price and subsequently drew $24 million in the first quarter of fiscal 2015 to fund working capital requirements.  Such additional draw of $24 million was repaid as of the filing date of this Form 10-Q.

[0001078271-14-000064:notes:117]
[same as prior period, unchanged from 0001078271-14-000020:notes:152]

[0001078271-14-000064:notes:118]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product.  The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2014 and 2013:

[0001078271-14-000064:notes:119]
[same as prior period, unchanged from 0001078271-14-000020:notes:155]

[0001078271-14-000064:notes:120]
[same as prior period, unchanged from 0001078271-14-000020:notes:156]

[0001078271-14-000064:notes:121]
[same as prior period, unchanged from 0001078271-14-000020:notes:157]
