# EXTR MD&A — 0001078271-14-000064


## mdna

[0001078271-14-000064:mdna:1]
[same as prior period, unchanged from 0001078271-14-000020:mdna:1]

[0001078271-14-000064:mdna:2]
[same as prior period, unchanged from 0001078271-14-000020:mdna:2]

[0001078271-14-000064:mdna:3]
We are a leading provider of network infrastructure equipment and services for enterprises, data centers, and service providers. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. The shares of Extreme Networks, Inc. (EXTR) began trading on NASDAQ in April 1999.  Our corporate headquarters are located in San Jose, California. We develop and sell network infrastructure equipment to our enterprise, data center and telecommunications service provider customers.

[0001078271-14-000064:mdna:4]
[same as prior period, unchanged from 0001078271-14-000020:mdna:4]

[0001078271-14-000064:mdna:5]
Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center networking, switching and routing, Software-Defined Networking (SDN), wired and wireless LAN access, network management with analytics and integrated security features. This broader solutions portfolio can be leveraged to better serve existing and new customers. We will continue to enhance and support the product roadmaps of both companies going forward to protect the investments of customers and avoid any disruption to their businesses. We intend to increase research and development to accelerate our vision for high-performance, modular, open networking.

[0001078271-14-000064:mdna:6]
Leading customer service and support: We are working to augment our current outsourced support model by integrating Enterasys' in-sourced expertise, building on Enterasys' award-winning heritage and strong commitment to exceptional customer experience. The Company's expanded global network of channel partners and distributors will benefit from expanded services and support capabilities.

[0001078271-14-000064:mdna:7]
Strong Channels and Strategic Partners: Our focus is to leverage the capabilities of the combined Company and expand existing partnerships with Ericsson and the developing partnership with Lenovo as well as continue to add new strategic partnerships in the future. Additionally, we will increase our focus on partnering with distributors and channel partners globally. The goal is to develop and enhance relationships that grow revenue and profits for the Company and our alliance and channel partners. At the same time, we are investing in infrastructure to make doing business with the Company easier and more efficient.

[0001078271-14-000064:mdna:8]
We conduct our sales and marketing activities on a worldwide basis through a distribution channel utilizing distributors, resellers and our field sales organization. We primarily sell our products through an ecosystem of channel partners who combine our Ethernet, wireless and software analytics products with their offerings to create compelling information technology solutions for end-user customers. We utilize our field sales organization to support our channel partners and to sell direct to end-user customers, including some large global accounts.  Our customers include businesses, hospitals, hotels, universities, sports venues, telecommunications companies and government agencies around the world.

[0001078271-14-000064:mdna:9]
We outsource the majority of our manufacturing and supply chain management operations as part of our strategy to maintain global manufacturing capabilities and to reduce our costs. We conduct quality assurance, manufacturing engineering, document control and test development at engineering facilities in San Jose, California, RTP, North Carolina, Salem, New Hampshire, Toronto, Canada and Chennai, India. This approach enables us to reduce fixed costs and to flexibly respond to changes in market demand.

[0001078271-14-000064:mdna:10]
[same as prior period, unchanged from 0001078271-14-000020:mdna:11]

[0001078271-14-000064:mdna:11]
[same as prior period, unchanged from 0001078271-14-000020:mdna:12]

[0001078271-14-000064:mdna:12]
[same as prior period, unchanged from 0001078271-14-000020:mdna:13]

[0001078271-14-000064:mdna:13]
During the first quarter of fiscal 2015, we achieved the following results:

[0001078271-14-000064:mdna:14]
| • | Net revenues of $136.3 million compared to net revenues of $75.9 million in the first quarter of fiscal 2014. |

[0001078271-14-000064:mdna:15]
| • | Product revenues of $102.7 million compared to product revenues of $61.0 million in the first quarter of fiscal 2014. |

[0001078271-14-000064:mdna:16]
| • | Service revenues of $33.6 million compared to service revenues of $14.9 million in the first quarter of fiscal 2014. |

[0001078271-14-000064:mdna:17]
| • | Total gross margin of 52% of net revenues compared to total gross margin of 58% of net revenues in the first quarter of fiscal 2014. |

[0001078271-14-000064:mdna:18]
| • | Operating loss of $17.2 million compared to operating income of $0.4 million in the first quarter of fiscal 2014. |

[0001078271-14-000064:mdna:19]
| • | Net loss of $19.3 million compared to net loss of $35.0 thousand in the first quarter of fiscal 2014. |

[0001078271-14-000064:mdna:20]
| • | Cash flow provided by operating activities of $1.6 million in the three months ended September 30, 2014 compared to cash flow provided by operating activities of $1.9 million in the three months ended September 30, 2013. |

[0001078271-14-000064:mdna:21]
| • | Cash and cash equivalents, short-term investments and marketable securities decreased by $1.4 million to $104.5 million as of September 30, 2014 from $105.9 million as of June 30, 2014, primarily due to less proceeds from cash used in operations. |

[0001078271-14-000064:mdna:22]
[same as prior period, unchanged from 0001078271-14-000020:mdna:23]

[0001078271-14-000064:mdna:23]
The following table presents the total net revenue geographically for the three months ended September 30, 2014 and September 30, 2013, respectively (dollars in thousands):

[0001078271-14-000064:mdna:24]
|  | Three Months Ended |
| Net Revenues | September 30, 2014 |  | September 30, 2013 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 58,488 |  |  | $ | 25,389 |  |  | $ | 33,099 |  |  | 130.4 | % |
| Other | 7,341 |  |  | 6,301 |  |  | 1,040 |  |  | 16.5 | % |
| Total Americas | 65,829 |  |  | 31,690 |  |  | 34,139 |  |  | 107.7 | % |
| Percentage of net revenue | 48.0 | % |  | 41.7 | % |  |  |  |  |
| EMEA | 53,934 |  |  | 30,842 |  |  | 23,092 |  |  | 74.9 | % |
| Percentage of net revenue | 39.6 | % |  | 40.6 | % |  |  |  |  |
| APAC | 16,511 |  |  | 13,384 |  |  | 3,127 |  |  | 23.4 | % |
| Percentage of net revenue | 12.1 | % |  | 17.6 | % |  |  |  |  |
| Total net revenues | $ | 136,274 |  |  | $ | 75,916 |  |  | $ | 60,358 |  |  | 79.5 | % |

[0001078271-14-000064:mdna:25]
[same as prior period, unchanged from 0001078271-14-000020:mdna:26]

[0001078271-14-000064:mdna:26]
The following table presents net product and service revenue for the three months ended September 30, 2014 and September 30, 2013, respectively (dollars in thousands):

[0001078271-14-000064:mdna:27]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |
| Product | $ | 102,672 |  |  | $ | 61,045 |  |  | $ | 41,627 |  |  | 68.2 | % |
| Percentage of net revenue | 75.3 | % |  | 80.4 | % |  |  |  |  |
| Service | 33,602 |  |  | 14,871 |  |  | 18,731 |  |  | 126.0 | % |
| Percentage of net revenue | 24.7 | % |  | 19.6 | % |  |  |  |  |
| Total net revenues | $ | 136,274 |  |  | $ | 75,916 |  |  | $ | 60,358 |  |  | 79.5 | % |

[0001078271-14-000064:mdna:28]
Product revenue increased $41.6 million or 68.2% in the first quarter of fiscal 2015 compared to the corresponding period of fiscal 2014. In the three months ending September 30, 2014, there was a significant increase in the number of customers and products sold during the period due to our acquisition of Enterasys in the second quarter of fiscal 2014.  This resulted in a significant increase in our product revenue in all regions.  Such increase from the acquisition was offset by lower revenue in EMEA region during the quarter due to political and economic conditions and the weakening of the Euro and British Pound Sterling against the United States Dollar which dampened the demand for product sales in EMEA.

[0001078271-14-000064:mdna:29]
Service revenue increased $18.7 million or 126.0% in the first quarter of fiscal 2015 and $18.7 million compared to the corresponding period of fiscal 2014. The increase in service revenue for the three months ended September 30, 2014 was due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys in the second quarter of fiscal 2014 partially offset by purchase price accounting adjustments of $0.8 million.

[0001078271-14-000064:mdna:30]
[same as prior period, unchanged from 0001078271-14-000020:mdna:31]

[0001078271-14-000064:mdna:31]
The following table presents the gross profit on product and service revenue and the gross profit percentage of product and service revenue for the three months ended September 30, 2014 and 2013 (in thousands):

[0001078271-14-000064:mdna:32]
|  | Three Months Ended |  |
|  | September 30, 2014 |  | September 30, 2013 |  | $Change |  | %Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product | $ | 48,647 |  |  | $ | 33,529 |  |  | $ | 15,118 |  |  | 45.1 | % |  |
| Percentage of product revenue | 47.4 | % |  | 54.9 | % |  |  |  |  |  |
| Service | 21,880 |  |  | 10,178 |  |  | 11,702 |  |  | 115.0 | % |  |
| Percentage of service revenue | 65.1 | % |  | 68.4 | % |  |  |  |  |  |
| Total gross profit | $ | 70,527 |  |  | $ | 43,707 |  |  | $ | 26,820 |  |  | 61.4 | % |  |
| Percentage of net revenue | 51.8 | % |  | 57.6 | % |  |  |  |  |  |

[0001078271-14-000064:mdna:33]
[same as prior period, unchanged from 0001078271-14-000020:mdna:34]

[0001078271-14-000064:mdna:34]
Product gross margin percentage decreased to 47.4% in the first quarter of fiscal 2015 from 54.9% in the first quarter of fiscal 2014.  The decrease in product gross margin percentage for the three months ended September 30, 2014 was primarily due to $4.3 million increase in the amortization of the developed technology intangibles from the acquisition of Enterasys during the second quarter of fiscal 2014, increase in excess and obsolete inventory charges of $1.4 million and higher warranty costs for the products from the acquisition of Enterasys for the quarter ended September 30, 2014 as compared to the corresponding periods of fiscal 2014.

[0001078271-14-000064:mdna:35]
Our cost of service revenue consists primarily of personnel, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross margin percentage decreased to 65.1% from 68.4% in the first quarter of fiscal 2015.  The service gross margin percentage for the three ended September 30, 2014 decreased primarily due to higher personnel, overhead and travel cost as well as purchase accounting adjustments as a result of our acquisition of Enterasys during the second quarter of fiscal 2014.

[0001078271-14-000064:mdna:36]
[same as prior period, unchanged from 0001078271-14-000020:mdna:38]

[0001078271-14-000064:mdna:37]
[same as prior period, unchanged from 0001078271-14-000020:mdna:39]

[0001078271-14-000064:mdna:38]
|  | Three Months Ended |  |
|  | September 30, 2014 |  | September 30, 2013 |  | $Change |  | %Change |  |
| Research and development | $ | 23,347 |  |  | $ | 9,937 |  |  | $ | 13,410 |  |  | 135.0 | % |  |
| Sales and marketing | 44,779 |  |  | 22,694 |  |  | 22,085 |  |  | 97.3 | % |  |
| General and administrative | 11,074 |  |  | 6,934 |  |  | 4,140 |  |  | 59.7 | % |  |
| Acquisition and integration costs | 4,058 |  |  | 3,695 |  |  | 363 |  |  | 9.8 | % |  |
| Restructuring charge, net of reversals | — |  |  | 75 |  |  | (75 | ) |  | (100.0 | )% |  |
| Amortization of intangibles | 4,467 |  |  | — |  |  | 4,467 |  |  | 100.0 | % |  |
| Total operating expenses | $ | 87,725 |  |  | $ | 43,335 |  |  | $ | 44,390 |  |  | 102.4 | % |  |
| Operating income (loss) | $ | (17,198 | ) |  | $ | 372 |  |  | $ | (17,570 | ) |  | (4,723.1 | )% |  |

[0001078271-14-000064:mdna:39]
[same as prior period, unchanged from 0001078271-14-000020:mdna:44]

[0001078271-14-000064:mdna:40]
[same as prior period, unchanged from 0001078271-14-000020:mdna:45]

[0001078271-14-000064:mdna:41]
Research and development expenses increased by $13.4 million, or 135.0% in the first quarter of fiscal 2015 as compared to the corresponding period of fiscal 2014. The increase in research and development expenses for the three months ended September 30, 2014 was primarily due to increased personnel costs due to increase in headcount of approximately 300 employees and higher occupancy costs due to additional facilities primarily in Salem, New Hampshire and Toronto, Canada, as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000064:mdna:42]
[same as prior period, unchanged from 0001078271-14-000020:mdna:47]

[0001078271-14-000064:mdna:43]
[same as prior period, unchanged from 0001078271-14-000020:mdna:48]

[0001078271-14-000064:mdna:44]
Sales and marketing expenses increased by $22.1 million, or 97.3% in the first quarter of fiscal 2015 as compared to the corresponding period of fiscal 2014. The increase in sales and marketing expenses for the three months ended September 30, 2014 was primarily due to increased personnel costs as a result of an increase in headcount of approximately 330 employees as a result of our acquisition of Enterasys in the second quarter of fiscal 2014 as well as additional spending on sales and marketing programs as compared to first quarter of fiscal 2014.

[0001078271-14-000064:mdna:45]
[same as prior period, unchanged from 0001078271-14-000020:mdna:50]

[0001078271-14-000064:mdna:46]
General and administrative expenses increased by $4.1 million, or 59.7% in the first quarter of fiscal 2015 compared to the corresponding period of fiscal 2014. The increase in general and administrative expenses during the three months ending September 30, 2014, compared to the corresponding period of fiscal 2014, was primarily due to higher personnel and travel costs due to an increase in headcount of approximately 100 employees, and higher occupancy costs due to additional facilities in Salem, New Hampshire and Shannon, Ireland as a result of our acquisition of Enterasys in the second quarter of fiscal 2014 and an increase in bad debt expense as compared to the corresponding period of fiscal 2014.

[0001078271-14-000064:mdna:47]
[same as prior period, unchanged from 0001078271-14-000020:mdna:52]

[0001078271-14-000064:mdna:48]
As a result of our acquisition of Enterasys, we incurred $4.1 million of integration costs during the first quarter of fiscal 2015 primarily for IT integration and severance costs. The Company expects to incur integration costs through fiscal 2015.  The Company incurred $3.7 million of acquisition-related costs during the quarter ended September 30, 2013.

[0001078271-14-000064:mdna:49]
Restructuring Charge, Net of Reversals

[0001078271-14-000064:mdna:50]
During the second quarter of fiscal 2013, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. The Company has substantially expensed all of the costs associated with this initiative.  As of September 30, 2014, we had restructuring liabilities of $0.2 million, which we anticipate paying by the end of fiscal 2015.

[0001078271-14-000064:mdna:51]
[same as prior period, unchanged from 0001078271-14-000020:mdna:57]

[0001078271-14-000064:mdna:52]
During the three months ended September 30, 2014, we recorded $4.5 million of amortization, primarily for certain intangibles related to the acquisition of Enterasys.

[0001078271-14-000064:mdna:53]
[same as prior period, unchanged from 0001078271-14-000020:mdna:64]

[0001078271-14-000064:mdna:54]
During the three months ended September 30, 2014 we recorded $0.8 million interest expense related to the Credit Facility that the Company entered into on October 31, 2013.

[0001078271-14-000064:mdna:55]
[same as prior period, unchanged from 0001078271-14-000020:mdna:66]

[0001078271-14-000064:mdna:56]
Other expense, net increased by $0.2 million in the first quarter of fiscal 2015 compared to the corresponding period of fiscal 2014.  The increase in other expense, net was primarily due to losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.

[0001078271-14-000064:mdna:57]
[same as prior period, unchanged from 0001078271-14-000020:mdna:68]

[0001078271-14-000064:mdna:58]
For the three months ended September 30, 2014 and September 30, 2013, we recorded an income tax provision of $1.0 million and $0.4 million, respectively.

[0001078271-14-000064:mdna:59]
The income tax provisions for the three months ended September 30, 2014 and 2013 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc.

[0001078271-14-000064:mdna:60]
[same as prior period, unchanged from 0001078271-14-000020:mdna:71]

[0001078271-14-000064:mdna:61]
[same as prior period, unchanged from 0001078271-14-000020:mdna:72]

[0001078271-14-000064:mdna:62]
As discussed in Part II, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2014, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001078271-14-000064:mdna:63]
[same as prior period, unchanged from 0001078271-14-000020:mdna:75]

[0001078271-14-000064:mdna:64]
| • | Business Combinations |

[0001078271-14-000064:mdna:65]
| • | Goodwill |

[0001078271-14-000064:mdna:66]
| • | Share-based Payments |

[0001078271-14-000064:mdna:67]
[same as prior period, unchanged from 0001078271-14-000020:mdna:79]

[0001078271-14-000064:mdna:68]
[same as prior period, unchanged from 0001078271-14-000020:mdna:80]

[0001078271-14-000064:mdna:69]
There have been no changes to our critical accounting policies since the filing of our last Annual Report on Form 10-K.

[0001078271-14-000064:mdna:70]
[same as prior period, unchanged from 0001078271-14-000020:mdna:89]

[0001078271-14-000064:mdna:71]
See Note 2 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001078271-14-000064:mdna:72]
[same as prior period, unchanged from 0001078271-14-000020:mdna:92]

[0001078271-14-000064:mdna:73]
[same as prior period, unchanged from 0001078271-14-000020:mdna:93]

[0001078271-14-000064:mdna:74]
|  | September 30, 2014 |  | June 30, 2014 |
| Cash and cash equivalent | $ | 74,067 |  |  | $ | 73,190 |  |
| Short-term investments | 30,395 |  |  | 32,692 |  |
| Total cash and investments | $ | 104,462 |  |  | $ | 105,882 |  |
| Working capital | $ | 49,630 |  |  | $ | 96,279 |  |

[0001078271-14-000064:mdna:75]
As of September 30, 2014, our principal sources of liquidity consisted of cash, cash equivalents and investments of $104.5 million, net accounts receivable of $100.0 million and $0.9 million of letters of credit and borrowings from the Revolving Facility under which the Company had $0.1 million of availability at September 30, 2014.  Our principal uses of cash will include purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products, purchases of property and equipment, repayments of debt and related interest. We believe that our $104.5 million of cash and cash equivalents and investments at September 30, 2014 along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months including the repayment of the additional borrowings of $24 million from the Revolving Facility as of the filing date of this report.

[0001078271-14-000064:mdna:76]
Our Credit Agreement contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum a Consolidated Leverage Ratio and several other covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001078271-14-000064:mdna:77]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Agreement may be accelerated upon certain events of default.  We believe we are in compliance and expect to remain in compliance with our Credit Agreement covenants and they are not expected to impact our liquidity or capital resources.

[0001078271-14-000064:mdna:78]
[same as prior period, unchanged from 0001078271-14-000020:mdna:98]

[0001078271-14-000064:mdna:79]
[same as prior period, unchanged from 0001078271-14-000020:mdna:99]

[0001078271-14-000064:mdna:80]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Net cash provided by operating activities | $ | 1,632 |  |  | $ | 1,925 |  |
| Net cash (used in) provided by investing activities | $ | (1,036 | ) |  | $ | 3,254 |  |
| Net cash provided by financing activities | $ | 925 |  |  | $ | 1,799 |  |
| Foreign currency effect on cash | $ | (644 | ) |  | $ | 227 |  |
| Net increase in cash and cash equivalents | $ | 877 |  |  | $ | 7,205 |  |

[0001078271-14-000064:mdna:81]
[same as prior period, unchanged from 0001078271-14-000020:mdna:101]

[0001078271-14-000064:mdna:82]
Cash flows provided by operations was $1.6 million in the three months ending September 30, 2014.  Current year's net loss was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation expense and

[0001078271-14-000064:mdna:83]
depreciation.  Accounts receivables decreased primarily due to lower revenue during the quarter and higher collections.  Inventories decreased primarily due to the timing of inventory receipts to bring the inventory levels in line with the near term demand.  Such increases in cash inflows were offset by decrease in accounts payable due to timing of payments.

[0001078271-14-000064:mdna:84]
Cash flows provided by operations was $1.9 million for the three months ended September 30, 2013. Net loss for the quarter ended September 30, 2013 was primarily offset by non-cash expenses such as stock-based compensation expense and depreciation. Inventories increased primarily due to the timing of inventory receipts to bring the inventory levels in line with the near term demand and an increase in accounts payable balance due to the timing of payments.

[0001078271-14-000064:mdna:85]
Net Cash (Used In) Provided by Investing Activities

[0001078271-14-000064:mdna:86]
Cash flow used in investing activities in the three months ending September 30, 2014 was $1.0 million, primarily comprised of $2.8 million used to purchase property and equipment offset by proceeds of $2.0 million from the maturities of investments.

[0001078271-14-000064:mdna:87]
Cash flow provided by investing activities in the three months ending September 30, 2013 was $3.3 million, comprised of proceeds of $13.1 million from the maturities of investments, offset by $9.8 million used to purchase property and equipment.

[0001078271-14-000064:mdna:88]
[same as prior period, unchanged from 0001078271-14-000020:mdna:106]

[0001078271-14-000064:mdna:89]
Cash flow provided by financing activities in the three months ending September 30, 2014 was $0.9 million, comprised of a draw on the Revolving Facility of $24 million during the quarter ended September 30, 2014 for working capital requirements, $1.7 million proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards offset by $24.8 million of cash used for repayment of debt.

[0001078271-14-000064:mdna:90]
Cash flow provided by financing activities in the three months ending September 30, 2013 was $1.8 million, comprised of proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-14-000064:mdna:91]
[same as prior period, unchanged from 0001078271-14-000020:mdna:108]

[0001078271-14-000064:mdna:92]
The following summarizes our contractual obligations at September 30, 2014, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-14-000064:mdna:93]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 120,750 |  |  | $ | 30,500 |  |  | $ | 32,500 |  |  | $ | 57,750 |  |  | $ | — |  |
| Interest on debt obligations | 8,131 |  |  | 2,543 |  |  | 4,167 |  |  | 1,421 |  |  | — |  |
| Non-cancellable inventory purchase commitments | 90,737 |  |  | 90,737 |  |  | — |  |  | — |  |  | — |  |
| Non-cancellable operating lease obligations | 58,920 |  |  | 9,600 |  |  | 15,961 |  |  | 13,933 |  |  | 19,426 |  |
| Other liabilities | 7,032 |  |  | 4,468 |  |  | 2,433 |  |  | 131 |  |  | — |  |
| Total contractual cash obligations | $ | 285,570 |  |  | $ | 137,848 |  |  | $ | 55,061 |  |  | $ | 73,235 |  |  | $ | 19,426 |  |

[0001078271-14-000064:mdna:94]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $90.7 million as of September 30, 2014.  We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-14-000064:mdna:95]
[same as prior period, unchanged from 0001078271-14-000020:mdna:112]

[0001078271-14-000064:mdna:96]
[same as prior period, unchanged from 0001078271-14-000020:mdna:113]

[0001078271-14-000064:mdna:97]
The amounts in the table above exclude immaterial income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of settlement.

[0001078271-14-000064:mdna:98]
We did not have any material commitments for capital expenditures as of September 30, 2014.

[0001078271-14-000064:mdna:99]
[same as prior period, unchanged from 0001078271-14-000020:mdna:116]

[0001078271-14-000064:mdna:100]
We did not have any off-balance sheet arrangements as of September 30, 2014.
