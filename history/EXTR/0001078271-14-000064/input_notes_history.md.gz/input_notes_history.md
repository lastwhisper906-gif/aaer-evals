# EXTR note change history — 0001078271-14-000020 → 0001078271-14-000064


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-10-29):
[0001078271-14-000064:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2014, the Company had non-cancelable commitments to purchase approximately $90.7 million of such inventory.
  (was, 2014-05-07, similarity 0.9888):
[0001078271-14-000020:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2014, the Company had non-cancelable commitments to purchase approximately $52.5 million of such inventory.

- changed (2014-10-29):
[0001078271-14-000064:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2014-05-07, similarity 0.852):
[0001078271-14-000020:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- added (2014-10-29):
[0001078271-14-000064:note_history:3]
Net Navigation Systems, LLC.

- added (2014-10-29):
[0001078271-14-000064:note_history:4]
On April 23, 2014, Net Navigation Systems, LLC (“Net Navigation”) filed a complaint against Extreme Networks, Inc. in the Eastern District of Texas.  In the Complaint, the plaintiff asserts infringement of U.S. Patent No. 6,625,122 (“the ’122 Patent”), entitled “Selection of Data for Network Transmission,” which issued on September 23, 2003.  Although somewhat vague, the Complaint identifies the following products as accused of infringing the ‘122 Patent:  “Networking products capable of providing priority to different data flows based on bandwidth.”  The Complaint also states that Extreme has infringed by “making, selling, and causing its customers to use networking products capable of providing priority to different data flows based on bandwidth, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.”  The Complaint also asserts infringement of U.S. Patent No. 6,434,145 (“the ’145 Patent”), entitled “Processing of Network Data by Parallel Processing Channels,” which issued on August 13, 2002.  Again, although somewhat vague, the Complaint states that Extreme has infringed by “making, using, importing, selling, and/or offering for sale in the United States, including within this judicial district, networking products that use parallel processing channels, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.” Net Navigation, a non-practicing entity, seeks injunctive relief as well as monetary damages, cost, expenses and attorney fees, although the complaint seeks no quantified amount.  The Company denies the claims and is preparing to vigorously defend our technology.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

- added (2014-10-29):
[0001078271-14-000064:note_history:5]
Selene Communication Technologies, LLC.

- added (2014-10-29):
[0001078271-14-000064:note_history:6]
On April 7, 2014, Selene Communication Technologies, LLC (“Selene”), filed a complaint in the US District Court for the District of Delaware against Extreme and Enterasys asserting a cause of action for infringement of United States Patent No. 7,143,444 (the “444 Patent”). Selene has also recently sued a number of other technology companies including Cisco for infringement of the 444 Patent.  Selene, a non-practicing entity, seeks injunctive relief as well as monetary damages, costs, expenses and attorney fees, although the complaint seeks no quantified amount.

- added (2014-10-29):
[0001078271-14-000064:note_history:7]
The Company is a member of RPX Corporation’s (“RPX”) network of clients, who procure patent risk management services from RPX.  On September 30, 2014, RPX signed an agreement on behalf of its members (including Extreme) with Selene to resolve the litigation cases against its members by Selene and to obtain a license for all RPX members to the 444 Patent and its foreign counterparts.  As a result, the Company expects this case to be dismissed shortly without any further liability to Company.

- added (2014-10-29):
[0001078271-14-000064:note_history:8]
Commonwealth of Kentucky

- added (2014-10-29):
[0001078271-14-000064:note_history:9]
On or about February 3, 2014, a class action lawsuit was filed in the Commonwealth of Kentucky against Enterasys Networks, Inc. and two other defendants.  The complaint alleges that Enterasys and its subcontractor, TJL Information Technologies, Inc., d.b.a. Unbridled Information Technologies (“Subcontractor”), violated Kentucky’s wage and hour laws and failed to pay the prevailing wage in violation of the Kentucky State Prevailing Wage Act (the “Act”) on various public works projects for a number of Kentucky government agencies since January 2010.  Plaintiffs also allege common law actions for quantum merit and unjust enrichment and they seek monetary damages, costs, expenses and attorney fees, although there was no quantified amount identified.  One of the defendants, Integrated Facility Systems, LLC (“IFS”), has also filed a cross-claim against Enterasys.  The Company denies the claims and filed answers to both the complaint and cross-claim on April 16, 2014.  In addition, the Company filed a cross-claim for indemnity against IFS.

- added (2014-10-29):
[0001078271-14-000064:note_history:10]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014 and is considering filing a cross-claim against COT.  This litigation is in the early stages of discovery.

- added (2014-10-29):
[0001078271-14-000064:note_history:11]
ICMS Tax Assessment Matters

- added (2014-10-29):
[0001078271-14-000064:note_history:12]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014 by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US$1.5 million), plus interest and penalties (that are currently estimated to be approximately US$9 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  In the first week of October, the preliminary injunction was granted with regard to the stay of execution; however, the court ruled that a cash deposit of the full amount at issue is to be made by Enterasys.  Enterasys then prepared a motion aimed at the partial reconsideration of such decision concerning the need for a deposit, which was denied on October 10, 2014.  The Company is currently considering an appeal to the Court of Appeals against such denial.

- added (2014-10-29):
[0001078271-14-000064:note_history:13]
Given the preliminary nature of the lawsuit and the uncertainty of the legal environment in Brazil, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position, cash flows or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from $0 million to $9 million, of which the Company believes $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.

- changed (2014-10-29):
[0001078271-14-000064:note_history:14]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of September 30, 2014, the Company had no outstanding indemnification claims.
  (was, 2014-05-07, similarity 0.9935):
[0001078271-14-000020:note_history:14]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of March 31, 2014, the Company had no outstanding indemnification claims.

- removed (2014-10-29):
[0001078271-14-000020:note_history:15]
Relay IP Inc.

- removed (2014-10-29):
[0001078271-14-000020:note_history:16]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775 (Extreme Case). Further on May 6, 2013 they also filed a similar suit against Enterasys in the same court, Civil Action case number 13-774.The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on both cases in July, 2013. The suit is one of approximately 40 nearly simultaneous suits filed by Relay IP against numerous networking equipment manufacturers, suppliers, operators, and users including Cisco Systems, Hewlett-Packard, Juniper Networks, Avaya, Extreme and Enterasys.  The Company denies the claims and intends to vigorously defend itself in both cases.

- removed (2014-10-29):
[0001078271-14-000020:note_history:17]
ReefEdge

- removed (2014-10-29):
[0001078271-14-000020:note_history:18]
On September 17, 2012, ReefEdge filed suit against Enterasys in the United States District Court for the District of Delaware alleging certain of the company's products (wireless controllers and wireless access points), infringe three ReefEdge U.S. patents (6633761, 6975864, 7197308).  ReefEdge, a non-practicing entity, sought injunctive relief as well as monetary damages, costs, expenses and attorney fees, although there was no quantified amount sought.  Extreme assumed this litigation as part of the acquisition of Enterasys.  As of the date of this filing, the parties reached a settlement which required the Company to pay an immaterial amount.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-10-29):
[0001078271-14-000064:note_history:19]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2014. The results of operations for the three months ended September 30, 2014 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.
  (was, 2014-05-07, similarity 0.6879):
[0001078271-14-000020:note_history:19]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2014. The results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.

- removed (2014-10-29):
[0001078271-14-000020:note_history:20]
On October 31, 2013, the Company completed the acquisition of Enterasys Networks, Inc., a Delaware corporation ("Enterasys"), whereby Enterasys became a wholly-owned subsidiary of the Company (see Note 2: Summary of Significant Accounting Policies - Business Combinations" and Note 4: "Business Combinations" for further discussion).  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-10-29):
[0001078271-14-000064:note_history:21]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual report on Form 10-K for the fiscal year ended June 30, 2014. There have been no material changes to the Company's significant accounting policies since the filing of the Annual report on Form 10-K.

- removed (2014-10-29):
[0001078271-14-000020:note_history:22]
Revenue Recognition

- removed (2014-10-29):
[0001078271-14-000020:note_history:23]
The Company's revenue is primarily derived from the sale of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

- removed (2014-10-29):
[0001078271-14-000020:note_history:24]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

- removed (2014-10-29):
[0001078271-14-000020:note_history:25]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.

- removed (2014-10-29):
[0001078271-14-000020:note_history:26]
Business Combinations

- removed (2014-10-29):
[0001078271-14-000020:note_history:27]
The Company applies the acquisition method of accounting for business combinations, including its acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.

- removed (2014-10-29):
[0001078271-14-000020:note_history:28]
Goodwill

- removed (2014-10-29):
[0001078271-14-000020:note_history:29]
Goodwill is assessed for impairment annually or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. Goodwill is tested for impairment at the reporting unit level at the beginning of fourth quarter of the fiscal year and at least annually thereafter. To test goodwill for impairment, the Company first performs a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, the Company will then perform the two-step goodwill impairment test. Otherwise, the two-step goodwill impairment test is not required.  Under the two-step goodwill impairment test, the Company would, in the first step, compare the estimated fair value of a reporting unit to its carrying value.  If the fair value of the reporting unit exceeds the carrying value, no impairment loss would be recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which the Company determines the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

- removed (2014-10-29):
[0001078271-14-000020:note_history:30]
Long-Lived Assets

- removed (2014-10-29):
[0001078271-14-000020:note_history:31]
Long-lived assets include property and equipment, and service inventory.  Property and equipment assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets or asset groups. The Company reduces the carrying value of service inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts.

- removed (2014-10-29):
[0001078271-14-000020:note_history:32]
Intangible Assets

- removed (2014-10-29):
[0001078271-14-000020:note_history:33]
Intangibles assets are reviewed for impairment annually or more frequently when an event occurs or circumstances change that would more likely than not reduce the fair value of the asset below its carrying value.  License agreements are presented at cost, net of accumulated amortization and are amortized over their estimated useful life.  The in-process research and development efforts are monitored regularly for completion and once they are completed, the Company will determine whether the asset will continue to be an indefinite-lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.  The Company determines that its in-process research and development project is complete when all material research and development costs have been incurred and no significant risks remain. The Company reviews the carrying value of indefinite-lived intangible assets for impairment at least annually during the last quarter of the fiscal year, or more frequently if it believes indicators of impairment exist.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-10-29):
[0001078271-14-000064:note_history:34]
|  |  | September 30, 2014 |
| Current portion of long-term debt: |  |  |
| Term Loan |  | 6,500 |  |
| Revolving Facility |  | 24,000 |  |
| Current portion of long-term debt |  | 30,500 |  |
| Long-term debt, less current portion: |  |  |
| Term Loan |  | 55,250 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt, less current portion |  | 90,250 |  |
| Total debt |  | 120,750 |  |
  (was, 2014-05-07, similarity 0.9793):
[0001078271-14-000020:note_history:34]
|  |  | March 31, 2014 |
| Current portion of long-term debt: |  |  |
| Term Loan |  | 4,875 |  |
| Revolving Facility |  | 24,000 |  |
| Current portion of long-term debt |  | 28,875 |  |
| Long-term debt, less current portion: |  |  |
| Term Loan |  | 58,500 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt, less current portion |  | 93,500 |  |
| Total debt |  | 122,375 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2014-10-29):
[0001078271-14-000020:note_history:35]
Revenue Recognition

- removed (2014-10-29):
[0001078271-14-000020:note_history:36]
The Company's revenue is primarily derived from the sale of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

- removed (2014-10-29):
[0001078271-14-000020:note_history:37]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

- removed (2014-10-29):
[0001078271-14-000020:note_history:38]
In accordance with the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.
