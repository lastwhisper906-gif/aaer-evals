# EXTR 8-K — 0001078271-14-000062 filed 2014-10-28

## item codes, every 8-K on or before 2014-10-29

- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2014-10-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-14-000062:8k_2_02:1]
EX-99.1
2
extr8kq115ex991.htm
PRESS RELEASE DATED OCTOBER 28, 2014

[0001078271-14-000062:8k_2_02:2]
EXTR 8K Q1'15 EX 99.1

[0001078271-14-000062:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-14-000062:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-14-000062:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2015 Financial Results

[0001078271-14-000062:8k_2_02:6]
GAAP Revenue of $136.3 million & non-GAAP Revenue of $137.1 million

[0001078271-14-000062:8k_2_02:7]
GAAP EPS Loss of $0.20 & Non-GAAP EPS Loss of $0.01

[0001078271-14-000062:8k_2_02:8]
SAN JOSE, Calif., October 28, 2014 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for the first quarter of fiscal year 2015, ended September 30, 2014.  GAAP revenue was $136.3 million and non-GAAP revenue was $137.1 million.  GAAP net loss for the first fiscal quarter was $19.3 million, or $0.20 per share, and non-GAAP net loss was $0.9 million, or $0.01 per diluted share.  This is the third quarter that Extreme Networks is reporting full quarter results that include the Enterasys acquisition.

[0001078271-14-000062:8k_2_02:9]
“Our top line results were impacted by market conditions that caused customers to delay buying decisions beyond our first quarter.  Sales in Eastern Europe, Russia and the Middle East were impacted by the political and economic conditions in these markets as well as substantial local currency weakness.  Similarly, the political climate in Latin America, specifically, Brazil and Mexico, led to delays in public sector spending, our largest source of business in these markets.  A significant number of large deals that were expected to close in the quarter were delayed into future quarters in North America as well,” said Chuck Berger, president and CEO of Extreme Networks.

[0001078271-14-000062:8k_2_02:10]
"During the quarter, we made significant progress towards finalizing the integration of the acquisition of Enterasys: successfully converging on a single ERP system, closing the Illinois distribution center, selectively reducing the number of distributors globally, converting our direct distribution model in Brazil to a leveraged two tier model, and executing a unified partner program and service offering,” continued Berger.  Although these changes were well executed, they also had an impact on our revenues during the quarter as our partners and sales people had to learn a new way to do business with us.  We are on track to realize the full $30 to $40 million in cost synergies expected from the acquisition and were able to maintain strong gross margins in the first quarter, despite the top line miss.”

[0001078271-14-000062:8k_2_02:11]
“On October 1, we announced that Jeff White joined Extreme as chief revenue officer.  Jeff brings with him 20 years of sales and executive experience in the networking market, most recently at Cisco.  Lenovo also closed the acquisition of the IBM X86 server business.  The combination of strong sales leadership, the nearly completed integration and Lenovo partnership all position us well for the remainder of our fiscal year."

[0001078271-14-000062:8k_2_02:12]
Fiscal Q1 2015 Financial Metrics:

[0001078271-14-000062:8k_2_02:13]
|  |  | First Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2015 |  | 2014 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 102.7 |  |  | $ | 61.0 |  |  | $ | 41.7 |  |  | 68 | % |
| Service |  | 33.6 |  |  | $ | 14.9 |  |  | $ | 18.7 |  |  | 126 | % |
| Total Net Revenue |  | $ | 136.3 |  |  | $ | 75.9 |  |  | $ | 60.4 |  |  | 80 | % |
| Gross Margin |  | 51.8 | % |  | 57.6 | % |  | (5.8 | )% |  | (10 | )% |
| Operating (Loss) Margin |  | (12.6 | )% |  | 0.5 | % |  | (13.1 | )% |  | (2,620 | )% |
| Net Loss |  | $ | (19.3 | ) |  | $ | — |  |  | $ | (19.3 | ) |  | 100 | % |
| Loss per diluted share |  | $ | (0.20 | ) |  | $ | — |  |  | $ | (0.20 | ) |  | 100 | % |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 102.7 |  |  | $ | 61.0 |  |  | $ | 41.7 |  |  | 68 | % |
| Service |  | $ | 34.4 |  |  | $ | 14.9 |  |  | $ | 19.5 |  |  | 131 | % |
| Total Net Revenue |  | $ | 137.1 |  |  | $ | 75.9 |  |  | $ | 61.2 |  |  | 81 | % |
| Gross Margin |  | 55.6 | % |  | 57.8 | % |  | (2.2 | )% |  | (4 | )% |
| Operating Margin |  | 0.9 | % |  | 7.5 | % |  | (6.6 | )% |  | (88 | )% |
| Net (Loss) Income |  | $ | (0.9 | ) |  | $ | 5.3 |  |  | $ | (6.2 | ) |  | (117 | )% |
| (Loss) Earnings per diluted share |  | $ | (0.01 | ) |  | $ | 0.06 |  |  | $ | (0.07 | ) |  | (117 | )% |

[0001078271-14-000062:8k_2_02:14]
| • | Cash and investments ended the quarter at $104.5 million, as compared to $105.9 million from the prior quarter. |

[0001078271-14-000062:8k_2_02:15]
| • | Accounts receivable balance ending Q1 was $100 million, with days sales outstanding (DSO) of 67. |

[0001078271-14-000062:8k_2_02:16]
| • | Inventory ending Q1 was $55.3 million, a decrease of $1.8 million from the prior quarter, due to continued right-sizing of inventory. |

[0001078271-14-000062:8k_2_02:17]
Recent Business Highlights:

[0001078271-14-000062:8k_2_02:18]
| • | Extended venue business to NBA and NHL. During the quarter, we extended our venue business with our first NBA and NHL venues. We also announced wins at the Cincinnati Bengals, Jacksonville Jaguars and Tennessee Titans during the quarter as well as our first Division One football venue at Baylor University. |

[0001078271-14-000062:8k_2_02:19]
| • | Announced Microsoft Lync qualification. Extreme is the first vendor to achieve SDN and Quality of Service (QoS) qualification for both wired and wireless hardware. With the certification, Extreme’s wired and wireless hardware are now easier to deploy in increasingly popular unified communications environments. |

[0001078271-14-000062:8k_2_02:20]
| • | Unveiled high performance, high density, edge switch. Providing exceptional port density in a small form factor; Extreme’s new Summit® X460-G2 offers core-class intelligent switching and routing with high-performance cross stacking technology and options for 1/10/40 GbE uplinks. It is powered by ExtremeXOS®, our modular operating system and, like all Extreme |

[0001078271-14-000062:8k_2_02:21]
switches, the Summit X460-G2 is optimized to work with NetSight® management and Purview™ analytics applications and is SDN ready.

[0001078271-14-000062:8k_2_02:22]
| • | Launched new IdentiFi™ offering. With all of the features and functionality that are offered within Extreme’s mobility portfolio, the IdentiFi 3805 discreet access point provides customers with a low cost entry point into the IdentiFi wireless product line. |

[0001078271-14-000062:8k_2_02:23]
Business Outlook:

[0001078271-14-000062:8k_2_02:24]
For its second quarter of fiscal 2015 ending December 31, 2014, the Company is targeting GAAP revenue in a range of $139 million to $149 million with non-GAAP revenue in a range of $140 million to $150 million. GAAP gross margin is targeted between 52.0% and 52.5% and non-GAAP gross margin targeted between 55.5% and 56%. Operating expenses are targeted to be between $84 million and $86 million on a GAAP basis and $73 million to $75 million on a non-GAAP basis. GAAP net loss is targeted to be between $9.5 million to $13.5 million, or $0.10 to $0.14 per diluted share.  Non-GAAP net income is targeted in a range of $3 million to $7 million, or $0.03 to $0.07 per diluted share. The GAAP and non-GAAP net (loss) income targets are based on an estimated 97.5 million and 100.5 million, average outstanding shares respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses and the purchase accounting value related to deferred service revenue.

[0001078271-14-000062:8k_2_02:25]
Financial Model Targets:

[0001078271-14-000062:8k_2_02:26]
The Company is targeting a quarterly financial model of operating at an approximate non-GAAP operating income of 10%, exiting the fiscal year ending June 30, 2015.  To achieve this goal, the Company intends to focus on completing the integration of the two companies, achieving its synergy goals and growing its revenue.

[0001078271-14-000062:8k_2_02:27]
Conference Call:

[0001078271-14-000062:8k_2_02:28]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the first fiscal quarter results and second fiscal quarter business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through October 27, 2015.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #:19301540.

[0001078271-14-000062:8k_2_02:29]
About Extreme Networks:

[0001078271-14-000062:8k_2_02:30]
Extreme Networks, Inc. (NASDAQ: EXTR) is setting a new standard for superior customer experience by delivering network-powered innovation and marketing leading service and support. Extreme Networks delivers high-performance switching and routing products for data center and core-to-edge networks, wired/wireless LAN access, and unified network management and control. Our award-winning solutions include software-defined networking (SDN), cloud and high-density Wi-Fi, BYOD and enterprise mobility, identity access management and security.  Extreme Networks is headquartered in San Jose, CA and has more than 12,000 customers in over 80 countries. For more information, visit http://www.extremenetworks.com.

[0001078271-14-000062:8k_2_02:31]
Non-GAAP Financial Measures:

[0001078271-14-000062:8k_2_02:32]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income/(loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, and share-based compensation.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company and the Company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the Company's operating activities with the Company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the Company's historical performance and in planning its future business activities. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's financial information presented in accordance with GAAP.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring charges, net of reversals and share-based compensation expense.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-14-000062:8k_2_02:33]
Forward Looking Statements:

[0001078271-14-000062:8k_2_02:34]
Actual results, including with respect to the Company's financial targets and general business prospects, could differ materially due to a number of factors, including the risks that:

[0001078271-14-000062:8k_2_02:35]
| • | The Company may not achieve targeted revenues for the Company's products and services given increasing price competition and product technology developments in key network switching equipment markets; |

[0001078271-14-000062:8k_2_02:36]
| • | Ongoing uncertainty in global economic conditions, infrastructure development or customer demand could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; |

[0001078271-14-000062:8k_2_02:37]
| • | The Company may be unable to effectively integrate the businesses of Extreme Networks and Enterasys Networks, both in terms of customer acceptance of combined product lines as well as the need to align the Company's cost structure to meet the company's financial goals, including controlling expenses, and meeting financial covenants as part of the Company's debt financing used to acquire Enterasys Networks; |

[0001078271-14-000062:8k_2_02:38]
| • | The Company may not accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; |

[0001078271-14-000062:8k_2_02:39]
| • | The Company is dependent on third parties to manufacture its products and any potential production delays could preclude the Company from shipping sufficient quantities to meet customer orders or could result in higher production costs and lower margins; |

[0001078271-14-000062:8k_2_02:40]
| • | The Company may be unable to complete development and commercialization of products under development, such as its pipeline of new network switches and related software; |

[0001078271-14-000062:8k_2_02:41]
| • | The Company may be adversely affected by ongoing litigation. |

[0001078271-14-000062:8k_2_02:42]
statements speak only as of the date of this release. Because such statements deal with future events, they are subject to risks and uncertainties. Other important factors that could cause actual results to differ materially are contained in the Company's 10-Qs and 10-Ks that are on file with the Securities and Exchange Commission. http://www.sec.gov.  More information about potential factors that could affect the Company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors," which are on file with the Securities and Exchange Commission.  Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-14-000062:8k_2_02:43]
EXTREME NETWORKS, INC.

[0001078271-14-000062:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-14-000062:8k_2_02:45]
(In thousands, except share and per share amounts)

[0001078271-14-000062:8k_2_02:46]
(Unaudited)

[0001078271-14-000062:8k_2_02:47]
|  | September 30, 2014 |  | June 30, 2014 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 74,067 |  |  | $ | 73,190 |  |
| Short-term investments | 30,395 |  |  | 32,692 |  |
| Accounts receivable, net of allowances of $4,569 at September 30, 2014 and $3,618 at June 30, 2014 | 99,980 |  |  | 124,664 |  |
| Inventories | 55,341 |  |  | 57,109 |  |
| Deferred income taxes | 1,069 |  |  | 1,058 |  |
| Prepaid expenses and other current assets | 13,486 |  |  | 14,143 |  |
| Total current assets | 274,338 |  |  | 302,856 |  |
| Property and equipment, net | 46,258 |  |  | 46,554 |  |
| Intangible assets, net | 78,710 |  |  | 87,459 |  |
| Goodwill | 70,877 |  |  | 70,877 |  |
| Other assets | 18,867 |  |  | 18,686 |  |
| Total assets | $ | 489,050 |  |  | $ | 526,432 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 30,500 |  |  | $ | 29,688 |  |
| Accounts payable | 29,994 |  |  | 37,308 |  |
| Accrued compensation and benefits | 21,712 |  |  | 26,677 |  |
| Restructuring liabilities | 186 |  |  | 322 |  |
| Accrued warranty | 7,889 |  |  | 7,551 |  |
| Deferred revenue, net | 72,599 |  |  | 74,735 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 26,060 |  |  | 31,992 |  |
| Other accrued liabilities | 35,768 |  |  | 38,035 |  |
| Total current liabilities | 224,708 |  |  | 246,308 |  |
| Deferred revenue, less current portion | 21,968 |  |  | 22,942 |  |
| Long-term debt, less current portion | 90,250 |  |  | 91,875 |  |
| Other long-term liabilities | 9,014 |  |  | 8,595 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 143,110 |  |  | 156,712 |  |
| Total liabilities and stockholders’ equity | $ | 489,050 |  |  | $ | 526,432 |  |

[0001078271-14-000062:8k_2_02:48]
EXTREME NETWORKS, INC.

[0001078271-14-000062:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000062:8k_2_02:50]
(In thousands, except per share amounts)

[0001078271-14-000062:8k_2_02:51]
(Unaudited)

[0001078271-14-000062:8k_2_02:52]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Net revenues: |  |  |  |
| Product | $ | 102,672 |  |  | $ | 61,045 |  |
| Service | 33,602 |  |  | 14,871 |  |
| Total net revenues | 136,274 |  |  | 75,916 |  |
| Cost of revenues: |  |  |  |
| Product | 54,025 |  |  | 27,516 |  |
| Service | 11,722 |  |  | 4,693 |  |
| Total cost of revenues | 65,747 |  |  | 32,209 |  |
| Gross profit: |  |  |  |
| Product | 48,647 |  |  | 33,529 |  |
| Service | 21,880 |  |  | 10,178 |  |
| Total gross profit | 70,527 |  |  | 43,707 |  |
| Operating expenses: |  |  |  |
| Research and development | 23,347 |  |  | 9,937 |  |
| Sales and marketing | 44,779 |  |  | 22,694 |  |
| General and administrative | 11,074 |  |  | 6,934 |  |
| Acquisition and integration costs | 4,058 |  |  | 3,695 |  |
| Restructuring charge, net of reversals | — |  |  | 75 |  |
| Amortization of intangibles | 4,467 |  |  | — |  |
| Total operating expenses | 87,725 |  |  | 43,335 |  |
| Operating (loss) income | (17,198 | ) |  | 372 |  |
| Interest income | 146 |  |  | 275 |  |
| Interest expense | (836 | ) |  | — |  |
| Other expense, net | (434 | ) |  | (255 | ) |
| (Loss) income before income taxes | (18,322 | ) |  | 392 |  |
| Provision for income taxes | 1,008 |  |  | 427 |  |
| Net loss | $ | (19,330 | ) |  | $ | (35 | ) |
| Basic and diluted net (loss) income per share: |  |  |  |
| Net loss per share - basic | $ | (0.20 | ) |  | $ | — |  |
| Net loss per share - diluted | $ | (0.20 | ) |  | $ | — |  |
| Shares used in per share calculation - basic | 97,314 |  |  | 94,062 |  |
| Shares used in per share calculation - diluted | 97,314 |  |  | 94,062 |  |

[0001078271-14-000062:8k_2_02:53]
EXTREME NETWORKS, INC.

[0001078271-14-000062:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-14-000062:8k_2_02:55]
(In thousands)

[0001078271-14-000062:8k_2_02:56]
(Unaudited)

[0001078271-14-000062:8k_2_02:57]
|  | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Net cash provided by operating activities | $ | 1,632 |  |  | $ | 1,925 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (2,784 | ) |  | (9,808 | ) |
| Proceeds from maturities of investments and marketable securities | 2,000 |  |  | 13,062 |  |
| Purchases of intangible assets | (252 | ) |  | — |  |
| Net cash (used in) provided by investing activities | (1,036 | ) |  | 3,254 |  |
| Cash flows from financing activities: |  |  |  |
| Borrowings under Revolving Facility | 24,000 |  |  | — |  |
| Repayment of debt | (24,813 | ) |  | — |  |
| Proceeds from issuance of common stock | 1,738 |  |  | 1,799 |  |
| Net cash provided by financing activities | 925 |  |  | 1,799 |  |
| Foreign currency effect on cash | (644 | ) |  | 227 |  |
| Net increase in cash and cash equivalents | 877 |  |  | 7,205 |  |
| Cash and cash equivalents at beginning of period | 73,190 |  |  | 95,803 |  |
| Cash and cash equivalents at end of period | $ | 74,067 |  |  | $ | 103,008 |  |

[0001078271-14-000062:8k_2_02:58]
Extreme Networks, Inc.

[0001078271-14-000062:8k_2_02:59]
Non-GAAP Measures of Financial Performance

[0001078271-14-000062:8k_2_02:60]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-14-000062:8k_2_02:61]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles and  restructuring expenses

[0001078271-14-000062:8k_2_02:62]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-14-000062:8k_2_02:63]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-14-000062:8k_2_02:64]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, and restructuring expenses.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-14-000062:8k_2_02:65]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-14-000062:8k_2_02:66]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-14-000062:8k_2_02:67]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-14-000062:8k_2_02:68]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-14-000062:8k_2_02:69]
Purchase accounting adjustments relating to deferred revenue.  Purchase accounting adjustments consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001078271-14-000062:8k_2_02:70]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-14-000062:8k_2_02:71]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the Company's cash balance for the period.

[0001078271-14-000062:8k_2_02:72]
EXTREME NETWORKS, INC.

[0001078271-14-000062:8k_2_02:73]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000062:8k_2_02:74]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-14-000062:8k_2_02:75]
(In thousands, except per share amounts)

[0001078271-14-000062:8k_2_02:76]
(Unaudited)

[0001078271-14-000062:8k_2_02:77]
| Non-GAAP Revenue | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Revenue - GAAP Basis | $ | 136,274 |  |  | $ | 75,916 |  |
| Adjustments: |  |  |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | — |  |
| Revenue - Non-GAAP Basis | $ | 137,040 |  |  | $ | 75,916 |  |
| Non-GAAP Gross Margin | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Gross profit - GAAP Basis | $ | 70,527 |  |  | $ | 43,707 |  |
| Gross margin - GAAP Basis percentage | 51.8 | % |  | 57.6 | % |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 574 |  |  | $ | 142 |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | — |  |
| Amortization of intangibles | $ | 4,292 |  |  | $ | — |  |
| Gross profit - Non-GAAP Basis | $ | 76,159 |  |  | $ | 43,849 |  |
| Gross margin - Non-GAAP Basis percentage | 55.6 | % |  | 57.8 | % |
| Non-GAAP Operating Income | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| GAAP operating (loss) income | $ | (17,198 | ) |  | $ | 372 |  |
| GAAP operating (loss) income percentage | (12.6 | )% |  | 0.5 | % |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 4,813 |  |  | $ | 1,575 |  |
| Acquisition and integration costs | $ | 4,058 |  |  | $ | 3,695 |  |
| Restructuring charge, net of reversal | $ | — |  |  | $ | 75 |  |
| Amortization of intangibles | $ | 8,759 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | — |  |
| Total adjustments to GAAP operating income | $ | 18,396 |  |  | $ | 5,345 |  |
| Non-GAAP operating income | $ | 1,198 |  |  | $ | 5,717 |  |
| Non-GAAP operating income percentage | 0.9 | % |  | 7.5 | % |
| Non-GAAP Net Income | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| GAAP net loss | $ | (19,330 | ) |  | $ | (35 | ) |

[0001078271-14-000062:8k_2_02:78]
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 4,813 |  |  | $ | 1,575 |  |
| Acquisition and integration costs | $ | 4,058 |  |  | $ | 3,695 |  |
| Restructuring charge, net of reversal | $ | — |  |  | $ | 75 |  |
| Amortization of intangibles | $ | 8,759 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | — |  |
| Total adjustments to GAAP net income | $ | 18,396 |  |  | $ | 5,345 |  |
| Non-GAAP net (loss) income | $ | (934 | ) |  | $ | 5,310 |  |
| Earnings per share |  |  |  |
| Non-GAAP diluted net (loss) income per share | $ | (0.01 | ) |  | $ | 0.06 |  |
| Shares used in diluted net income per share calculation | 97,314 |  |  | 95,695 |  |
| Free Cash Flow | Three Months Ended |
|  | September 30, 2014 |  | September 30, 2013 |
| Cash flow provided by operations | $ | 1,632 |  |  | $ | 1,925 |  |
| Add: PP&E CapEx spending | $ | (2,784 | ) |  | $ | (9,808 | ) |
| Total free cash flow | $ | (1,152 | ) |  | $ | (7,883 | ) |
