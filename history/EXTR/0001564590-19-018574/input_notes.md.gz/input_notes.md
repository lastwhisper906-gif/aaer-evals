# EXTR notes — 0001564590-19-018574


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-19-018574:notes:1]
[same as prior period, unchanged from 0001564590-19-001400:notes:1]

[0001564590-19-018574:notes:2]
[same as prior period, unchanged from 0001564590-19-001400:notes:2]

[0001564590-19-018574:notes:3]
[same as prior period, unchanged from 0001564590-19-001400:notes:3]

[0001564590-19-018574:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2019. The results of operations for the three and nine months ended March 31, 2019 are not necessarily indicative of the results that may be expected for fiscal 2019 or any future periods.

[0001564590-19-018574:notes:5]
[same as prior period, unchanged from 0001564590-19-001400:notes:5]

[0001564590-19-018574:notes:6]
[same as prior period, unchanged from 0001564590-19-001400:notes:6]

[0001564590-19-018574:notes:7]
[same as prior period, unchanged from 0001564590-19-001400:notes:7]

[0001564590-19-018574:notes:8]
[same as prior period, unchanged from 0001564590-19-001400:notes:8]

[0001564590-19-018574:notes:9]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001564590-19-018574:notes:10]
[same as prior period, unchanged from 0001564590-19-001400:notes:10]

[0001564590-19-018574:notes:11]
[same as prior period, unchanged from 0001564590-19-001400:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-018574:notes:12]
[same as prior period, unchanged from 0001564590-19-001400:notes:12]

[0001564590-19-018574:notes:13]
[same as prior period, unchanged from 0001564590-19-001400:notes:13]

[0001564590-19-018574:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-19-018574:notes:15]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities. The guidance was adopted effective July 1, 2018 and the Company reclassified a $0.5 million unrealized gain, net of tax, related to its available-for-sale investments from accumulated other comprehensive loss to accumulated deficit as a cumulative-effect adjustment in the accompanying condensed consolidated balance sheets.  Future changes in fair value will be included in earnings in each period.

[0001564590-19-018574:notes:16]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice.  The Company adopted the new guidance effective July 1, 2018. The amendments in this update have been applied on a retrospective transition method to each period presented. The adoption of this guidance did not have a material effect on the Company’s presentation of cash flows.

[0001564590-19-018574:notes:17]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740) - Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset other than inventory when the transfer occurs. Historically GAAP had prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset has been sold outside the consolidated group.  The new guidance is effective for interim and annual reporting periods beginning after December 15, 2017. The Company adopted ASU 2016-16 effective July 1, 2018 on a modified retrospective basis. The adoption of this guidance did not have a material effect on the Company’s financial statements.

[0001564590-19-018574:notes:18]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting, which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718.  Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The Company adopted this guidance effective July 1, 2018, on a prospective basis.  The adoption of this guidance did not have a material effect on the Company’s financial statements.

[0001564590-19-018574:notes:19]
Recently Issued Accounting Pronouncements

[0001564590-19-018574:notes:20]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 is applied on the modified retrospective method through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. In addition, in December 2018 and March 2019, the FASB issued ASU No. 2018-20, Leases (Topic 842) and ASU No. 2019-01, Leases (Topic 842), respectively, which includes narrow-scope improvements for lessors to increase transparency and comparability about leasing transactions and addresses lessor implementation issues and clarifies that lessees and lessors are exempt from certain interim disclosure requirements. This guidance will become effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019. The Company‘s evaluation of the new standards are underway, and significant changes from the current guidance have been identified. The Company expects to elect certain available transitional guidance. The Company also currently expects to elect the short-term lease recognition exemption for all leases that qualify. This means, for those leases that qualify, the Company will not recognize right-of-use (“ROU”) assets or lease liabilities, and this includes not recognizing ROU assets or lease liabilities for existing short-term leases of those assets in transition. In addition, the Company currently expects to elect the practical expedient to not separate lease and non-lease components for leases of vehicles and equipment. The Company has selected, and is in the process of implementing and testing a new lease accounting system and validating its results. While the Company continues to evaluate the effect of adopting Topic 842, it expects that these new standards will have a material impact to the Company’s financial position. The Company will recognize ROU assets and lease liabilities on the consolidated balance sheets with corresponding ROU assets at the same amount as the lease liability based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases. The Company does not expect that the adoption of Topic 842 will have a material effect on operating income (loss) and net cash flows, however it will impact the classification between cash flows from operations and cash flows from financing activities.

[0001564590-19-018574:notes:21]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (“OIS”) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The Company is continuing to evaluate the accounting, transition and disclosure requirements of these standards, but does not believe it will have a material impact on the Company’s financial statements upon adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

[0001564590-19-018574:notes:22]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period, for reporting periods for which financial statements have not yet been issued. The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. Management is currently evaluating implementation options and impact on the Company's financial statements and related disclosures.  This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

[0001564590-19-018574:notes:23]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-19-018574:notes:24]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-018574:notes:25]
[same as prior period, unchanged from 0001564590-19-001400:notes:25]

[0001564590-19-018574:notes:26]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-19-018574:notes:27]
[same as prior period, unchanged from 0001564590-19-001400:notes:27]

[0001564590-19-018574:notes:28]
[same as prior period, unchanged from 0001564590-19-001400:notes:28]

[0001564590-19-018574:notes:29]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenue is recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-19-018574:notes:30]
On March 31, 2019, the Company had $187.7 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 29 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 49 percent in fiscal 2020 and 22 percent of the balance thereafter.

[0001564590-19-018574:notes:31]
[same as prior period, unchanged from 0001564590-19-001400:notes:31]

[0001564590-19-018574:notes:32]
Revenue recognized for the three months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $54.8 million and $50.6 million, respectively. Revenue recognized for the nine months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $110.8 million and $66.7 million, respectively.

[0001564590-19-018574:notes:33]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $5.6 million and $4.3 million at March 31, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2019 and 2018, was $0.8 million and $0.5 million, respectively.  Amortization recognized during the nine months ended March 31, 2019 and 2018 was $2.2 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.

[0001564590-19-018574:notes:34]
[same as prior period, unchanged from 0001564590-19-001400:notes:34]

[0001564590-19-018574:notes:35]
[same as prior period, unchanged from 0001564590-19-001400:notes:35]

[0001564590-19-018574:notes:36]
[same as prior period, unchanged from 0001564590-19-001400:notes:36]

[0001564590-19-018574:notes:37]
|  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |
| Other |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |
| Total Americas |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |
| EMEA |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |
| APAC |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |
| Total net revenues |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |

[0001564590-19-018574:notes:38]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |
| Other |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |
| Total Americas |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |
| EMEA |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |
| APAC: |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |
| Total net revenues |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |

[0001564590-19-018574:notes:39]
[same as prior period, unchanged from 0001564590-19-001400:notes:39]

[0001564590-19-018574:notes:40]
[same as prior period, unchanged from 0001564590-19-001400:notes:40]

[0001564590-19-018574:notes:41]
[same as prior period, unchanged from 0001564590-19-001400:notes:41]

[0001564590-19-018574:notes:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Tech Data Corporation |  | 14% |  |  | 14% |  |  | 17% |  |  | 13% |  |
| Westcon Group Inc. |  | 12% |  |  | 14% |  |  | 13% |  |  | 14% |  |
| Jenne Corporation |  | 21% |  |  | 13% |  |  | 15% |  |  | 11% |  |

[0001564590-19-018574:notes:43]
[same as prior period, unchanged from 0001564590-19-001400:notes:43]

[0001564590-19-018574:notes:44]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Westcon Group Inc. |  | 10% |  |  | * |  |
| Tech Data Corporation |  | * |  |  | 17% |  |
| Jenne Corporation |  | 31% |  |  | 13% |  |
| * Less than 10% of accounts receivable |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-018574:notes:45]
[same as prior period, unchanged from 0001564590-19-001400:notes:45]

[0001564590-19-018574:notes:46]
[same as prior period, unchanged from 0001564590-19-001400:notes:46]

[0001564590-19-018574:notes:47]
[same as prior period, unchanged from 0001564590-19-001400:notes:47]

[0001564590-19-018574:notes:48]
[same as prior period, unchanged from 0001564590-19-001400:notes:48]

[0001564590-19-018574:notes:49]
[same as prior period, unchanged from 0001564590-19-001400:notes:49]

[0001564590-19-018574:notes:50]
|  |  | Final Allocation |  |
| Accounts receivables |  | $ | 33,488 |  |
| Inventories |  |  | 19,934 |  |
| Prepaid expenses and other current assets |  |  | 988 |  |
| Property and equipment | (a) |  | 19,442 |  |
| Other assets |  |  | 4,734 |  |
| Accounts payable and accrued expenses |  |  | (16,494 | ) |
| Deferred revenue |  |  | (33,025 | ) |
| Net tangible assets acquired |  |  | 29,067 |  |
| Identifiable intangible assets |  |  | 32,800 |  |
| Goodwill | (a) |  | 22,470 |  |
| Total intangible assets acquired |  |  | 55,270 |  |
| Total net assets acquired |  | $ | 84,337 |  |

[0001564590-19-018574:notes:51]
|  | (a) | Includes an adjustment after the measurement period to record $0.5 million of additional property and equipment acquired at an international location. |

[0001564590-19-018574:notes:52]
[same as prior period, unchanged from 0001564590-19-001400:notes:52]

[0001564590-19-018574:notes:53]
[same as prior period, unchanged from 0001564590-19-001400:notes:53]

[0001564590-19-018574:notes:54]
[same as prior period, unchanged from 0001564590-19-001400:notes:54]

[0001564590-19-018574:notes:55]
[same as prior period, unchanged from 0001564590-19-001400:notes:55]

[0001564590-19-018574:notes:56]
[same as prior period, unchanged from 0001564590-19-001400:notes:56]

[0001564590-19-018574:notes:57]
[same as prior period, unchanged from 0001564590-19-001400:notes:57]

[0001564590-19-018574:notes:58]
[same as prior period, unchanged from 0001564590-19-001400:notes:58]

[0001564590-19-018574:notes:59]
The following unaudited pro forma results of operations are presented as though the acquisitions of the Data Center Business, CF Business and Campus Fabric Business had occurred as of the beginning of fiscal 2017, after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-19-018574:notes:60]
[same as prior period, unchanged from 0001564590-19-001400:notes:60]

[0001564590-19-018574:notes:61]
The unaudited pro forma financial information for the nine months ended March 31, 2018 combines the historical results for Extreme for those periods, which include the results of the Data Center Business, CF Business and Campus Fabric business subsequent to the acquisition date, with their historical results up to the acquisition date.

[0001564590-19-018574:notes:62]
Pro forma results of operations from the Data Center Business, CF Business and Campus Fabric Business acquisitions included in the pro forma results of operations for the three and nine months ended March 31, 2018, have not been adjusted for the adoption of Topic 606 because the Company determined it is impractical to estimate the impact of the adoption.

[0001564590-19-018574:notes:63]
[same as prior period, unchanged from 0001564590-19-001400:notes:63]

[0001564590-19-018574:notes:64]
|  | Nine Months Ended |  |
|  | March 31, 2018 |  |
| Net revenues | $ | 799,044 |  |
| Net income (loss) | $ | (21,235 | ) |
| Net income (loss) per share - basic | $ | (0.19 | ) |
| Net income (loss) per share - diluted | $ | (0.19 | ) |
| Shares used in per share calculation - basic |  | 113,641 |  |
| Shares used in per share calculation - diluted |  | 113,641 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-018574:notes:65]
[same as prior period, unchanged from 0001564590-19-001400:notes:65]

[0001564590-19-018574:notes:66]
[same as prior period, unchanged from 0001564590-19-001400:notes:66]

[0001564590-19-018574:notes:67]
[same as prior period, unchanged from 0001564590-19-001400:notes:67]

[0001564590-19-018574:notes:68]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Cash |  | $ | 156,813 |  |  | $ | 121,139 |  |
| Marketable securities (consisting of available-for-sale securities) |  |  | 262 |  |  |  | 1,459 |  |
| Total cash and marketable securities |  | $ | 157,075 |  |  | $ | 122,598 |  |

[0001564590-19-018574:notes:69]
[same as prior period, unchanged from 0001564590-19-001400:notes:69]

[0001564590-19-018574:notes:70]
[same as prior period, unchanged from 0001564590-19-001400:notes:70]

[0001564590-19-018574:notes:71]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company adjusts the carrying value of its inventory when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-19-018574:notes:72]
[same as prior period, unchanged from 0001564590-19-001400:notes:72]

[0001564590-19-018574:notes:73]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Finished goods |  | $ | 42,727 |  |  | $ | 49,393 |  |
| Raw materials |  |  | 14,918 |  |  |  | 14,474 |  |
| Total Inventories |  | $ | 57,645 |  |  | $ | 63,867 |  |

[0001564590-19-018574:notes:74]
[same as prior period, unchanged from 0001564590-19-001400:notes:74]

[0001564590-19-018574:notes:75]
[same as prior period, unchanged from 0001564590-19-001400:notes:75]

[0001564590-19-018574:notes:76]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Computers and equipment |  | $ | 72,201 |  |  | $ | 60,677 |  |
| Purchased software |  |  | 25,501 |  |  |  | 21,389 |  |
| Office equipment, furniture and fixtures |  |  | 11,710 |  |  |  | 14,980 |  |
| Leasehold improvements |  |  | 51,183 |  |  |  | 50,070 |  |
| Total property and equipment |  |  | 160,595 |  |  |  | 147,116 |  |
| Less: accumulated depreciation and amortization |  |  | (87,538 | ) |  |  | (68,597 | ) |
| Property and equipment, net |  | $ | 73,057 |  |  | $ | 78,519 |  |

[0001564590-19-018574:notes:77]
[same as prior period, unchanged from 0001564590-19-001400:notes:77]

[0001564590-19-018574:notes:78]
[same as prior period, unchanged from 0001564590-19-001400:notes:78]

[0001564590-19-018574:notes:79]
[same as prior period, unchanged from 0001564590-19-001400:notes:79]

[0001564590-19-018574:notes:80]
The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-19-018574:notes:81]
The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2019 and 2018 (in thousands):

[0001564590-19-018574:notes:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Balance beginning of period |  | $ | 12,808 |  |  | $ | 13,010 |  |  | $ | 12,807 |  |  | $ | 10,584 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,682 |  |
| New warranties issued |  |  | 4,510 |  |  |  | 2,872 |  |  |  | 12,377 |  |  |  | 6,801 |  |
| Warranty expenditures |  |  | (4,112 | ) |  |  | (3,070 | ) |  |  | (11,978 | ) |  |  | (8,255 | ) |
| Balance end of period |  | $ | 13,206 |  |  | $ | 12,812 |  |  | $ | 13,206 |  |  | $ | 12,812 |  |

[0001564590-19-018574:notes:83]
[same as prior period, unchanged from 0001564590-19-001400:notes:83]

[0001564590-19-018574:notes:84]
[same as prior period, unchanged from 0001564590-19-001400:notes:84]

[0001564590-19-018574:notes:85]
[same as prior period, unchanged from 0001564590-19-001400:notes:85]

[0001564590-19-018574:notes:86]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Acquisition related deferred payments, less current portion |  | $ | 10,526 |  |  | $ | 13,251 |  |
| Contingent consideration obligations, less current portion |  |  | 3,025 |  |  |  | 4,898 |  |
| Other contractual obligations, less current portion |  |  | 28,093 |  |  |  | 31,200 |  |
| Other |  |  | 16,045 |  |  |  | 9,751 |  |
| Total other long-term liabilities |  | $ | 57,689 |  |  | $ | 59,100 |  |

[0001564590-19-018574:notes:87]
[same as prior period, unchanged from 0001564590-19-001400:notes:87]

[0001564590-19-018574:notes:88]
[same as prior period, unchanged from 0001564590-19-001400:notes:88]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-018574:notes:89]
[same as prior period, unchanged from 0001564590-19-001400:notes:89]

[0001564590-19-018574:notes:90]
[same as prior period, unchanged from 0001564590-19-001400:notes:90]

[0001564590-19-018574:notes:91]
[same as prior period, unchanged from 0001564590-19-001400:notes:91]

[0001564590-19-018574:notes:92]
[same as prior period, unchanged from 0001564590-19-001400:notes:92]

[0001564590-19-018574:notes:93]
[same as prior period, unchanged from 0001564590-19-001400:notes:93]

[0001564590-19-018574:notes:94]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-19-018574:notes:95]
| March 31, 2019 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable securities |  | $ | 262 |  |  | $ | — |  |  | $ | — |  |  | $ | 262 |  |
| Total assets measured at fair value |  | $ | 262 |  |  | $ | — |  |  | $ | — |  |  | $ | 262 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 7,469 |  |  | $ | 7,469 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 7,469 |  |  | $ | 7,469 |  |

[0001564590-19-018574:notes:96]
[same as prior period, unchanged from 0001564590-19-001400:notes:97]

[0001564590-19-018574:notes:97]
[same as prior period, unchanged from 0001564590-19-001400:notes:98]

[0001564590-19-018574:notes:98]
The Company holds an investment in marketable equity securities which is classified as available-for-sale marketable securities at Level 1 as the investments have readily determinable fair value (see below, Level 3 investments). An unrealized holding gain on the investments of $0.5 million as of June 30, 2018 was reclassified from accumulated other comprehensive loss to accumulated deficit on July 1, 2018 upon the adoption of ASU 2016-01 (see Note 3).

[0001564590-19-018574:notes:99]
[same as prior period, unchanged from 0001564590-19-001400:notes:100]

[0001564590-19-018574:notes:100]
[same as prior period, unchanged from 0001564590-19-001400:notes:101]

[0001564590-19-018574:notes:101]
The fair value of the borrowings under the Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the short duration until maturity of the Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $182.9 million and $200.0 million as of March 31, 2019, and June 30, 2018, respectively.

[0001564590-19-018574:notes:102]
[same as prior period, unchanged from 0001564590-19-001400:notes:103]

[0001564590-19-018574:notes:103]
[same as prior period, unchanged from 0001564590-19-001400:notes:105]

[0001564590-19-018574:notes:104]
[same as prior period, unchanged from 0001564590-19-001400:notes:106]

[0001564590-19-018574:notes:105]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |
| Beginning balance |  | $ | 12,749 |  |
| Payments |  |  | (5,274 | ) |
| Accretion on discount |  |  | 183 |  |
| Adjustments |  |  | (189 | ) |
| Ending balance |  | $ | 7,469 |  |

[0001564590-19-018574:notes:106]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the three and nine months ended March 31, 2019, or 2018. There were no impairments recorded for the three and nine months ended March 31, 2019, or 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-018574:notes:107]
[same as prior period, unchanged from 0001564590-19-001400:notes:109]

[0001564590-19-018574:notes:108]
[same as prior period, unchanged from 0001564590-19-001400:notes:110]

[0001564590-19-018574:notes:109]
|  |  | March 31, 2019 |  |
| Balance as of June 30, 2018 |  | $ | 139,082 |  |
| Changes due to additional property and equipment acquired (See Note 4) |  |  | (505 | ) |
| Balance at end of period |  | $ | 138,577 |  |

[0001564590-19-018574:notes:110]
[same as prior period, unchanged from 0001564590-19-001400:notes:112]

[0001564590-19-018574:notes:111]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.6 years |  | $ | 117,000 |  |  | $ | 72,659 |  |  | $ | 44,341 |  |
| Customer relationships |  | 2.3 years |  |  | 51,639 |  |  |  | 43,466 |  |  |  | 8,173 |  |
| Maintenance contracts |  | — years |  |  | 17,000 |  |  |  | 17,000 |  |  |  | - |  |
| Trade names |  | 2.7 years |  |  | 9,100 |  |  |  | 5,236 |  |  |  | 3,864 |  |
| License agreements |  | 5.5 years |  |  | 2,232 |  |  |  | 1,380 |  |  |  | 852 |  |
| Other intangibles |  | 0.8 years |  |  | 1,382 |  |  |  | 1,250 |  |  |  | 132 |  |
| Total intangibles, net |  |  |  | $ | 198,353 |  |  | $ | 140,991 |  |  | $ | 57,362 |  |

[0001564590-19-018574:notes:112]
[same as prior period, unchanged from 0001564590-19-001400:notes:114]

[0001564590-19-018574:notes:113]
[same as prior period, unchanged from 0001564590-19-001400:notes:115]

[0001564590-19-018574:notes:114]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 4,890 |  |  | $ | 4,647 |  |  | $ | 14,726 |  |  | $ | 11,310 |  |
| Amortization of intangibles in "Operations" |  |  | 1,292 |  |  |  | 2,101 |  |  |  | 5,008 |  |  |  | 6,461 |  |
| Total amortization |  | $ | 6,182 |  |  | $ | 6,748 |  |  | $ | 19,734 |  |  | $ | 17,771 |  |

[0001564590-19-018574:notes:115]
[same as prior period, unchanged from 0001564590-19-001400:notes:117]


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-018574:notes:116]
8.Debt

[0001564590-19-018574:notes:117]
The Company’s debt is comprised of the following (in thousands):

[0001564590-19-018574:notes:118]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 173,375 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,382 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 171,993 |  |  |  | 188,749 |  |
| Total debt |  | $ | 181,002 |  |  | $ | 197,756 |  |

[0001564590-19-018574:notes:119]
On May 1, 2018, the Company entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”) ii) a $190 million five-year term loan (the “New Term Loan”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement to pay off existing debt and for general corporate purposes.

[0001564590-19-018574:notes:120]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s consolidated leverage ratio.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting September 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-19-018574:notes:121]
The Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-19-018574:notes:122]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the Credit Agreement.  Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.2 million for each of the three months ended March 31, 2019 and 2018 and totaled $0.5 million for each of the nine months ended March 31, 2019 and 2018, respectively.

[0001564590-19-018574:notes:123]
The Company had $35.5 million of availability under the New Revolving Facility as of March 31, 2019.  The Company had $4.5 million of outstanding letters of credit as of March 31, 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-018574:notes:124]
9.Commitments and Contingencies

[0001564590-19-018574:notes:125]
Purchase Commitments

[0001564590-19-018574:notes:126]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2019, the Company had commitments to purchase $194.9 million of such inventory.  As of March 31, 2019, the Company had commitments to purchase $99.9 million of software and new product support services.

[0001564590-19-018574:notes:127]
Legal Proceedings

[0001564590-19-018574:notes:128]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-19-018574:notes:129]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-19-018574:notes:130]
Brazilian Tax Assessment Matter

[0001564590-19-018574:notes:131]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.9 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of March 31, 2019.

[0001564590-19-018574:notes:132]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017, decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 19.9 million (USD $5.2 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of March 31, 2019.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

[0001564590-19-018574:notes:133]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (USD $2.4 million) as of the date the Company acquired Enterasys Networks.

[0001564590-19-018574:notes:134]
The Company made a demand on April 11, 2014, for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-19-018574:notes:135]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-19-018574:notes:136]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013, through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018, Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties have agreed to settle the litigation.   On November 30, 2018, plaintiffs filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition. The preliminary hearing took place on March 7, 2019, and the final hearing is scheduled for June 20, 2019.

[0001564590-19-018574:notes:137]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended. The parties agreed to settle the litigation.  On May 3, 2019, the Court gave final approval to the settlement and entered judgment terminating the case.

[0001564590-19-018574:notes:138]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-19-018574:notes:139]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date). During a status conference on February 11, 2019, the Court continued the stay and set a status conference for December 2, 2019. The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-19-018574:notes:140]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-19-018574:notes:141]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-19-018574:notes:142]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co., Ltd

[0001564590-19-018574:notes:143]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six lawsuits alleging patent infringement against Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1, ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2, and ZL200610060686.9. The products at issue include the Summit X440-G2 series, X450-G2 series, X460-G2 series, X620 series, X670-G2 series, X770 series, X870 series, X690 series, and X590 series. GIA is a U.S. entity established under the laws of Delaware with its principal office in Pasadena, California. Extreme disputes GIA’s claims and intends to defend them vigorously.

[0001564590-19-018574:notes:144]
Indemnification Obligations

[0001564590-19-018574:notes:145]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of March 31, 2019, the Company has the outstanding indemnification claims described above.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-19-018574:notes:146]
[same as prior period, unchanged from 0001564590-19-001400:notes:146]

[0001564590-19-018574:notes:147]
[same as prior period, unchanged from 0001564590-19-001400:notes:147]

[0001564590-19-018574:notes:148]
[same as prior period, unchanged from 0001564590-19-001400:notes:148]

[0001564590-19-018574:notes:149]
The Company’s Board of Directors (the “Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 9, 2018, to extend the Restated Rights Plan through May 31, 2019, which was ratified by the stockholders of the Company at the Company’s annual meeting of stockholders held on November 8, 2018.

[0001564590-19-018574:notes:150]
[same as prior period, unchanged from 0001564590-19-001400:notes:150]

[0001564590-19-018574:notes:151]
The Board of Directors unanimously approved an amendment to the 2014 Employee Stock Purchase Plan to increase the maximum number of shares that will be available for sale thereunder by 7,500,000 shares which was ratified by the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018.

[0001564590-19-018574:notes:152]
[same as prior period, unchanged from 0001564590-19-001400:notes:152]

[0001564590-19-018574:notes:153]
On November 2, 2018, the Company announced that the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock for two years from the date of authorization. Purchases may be made from time to time in the open market or in privately negotiated transactions.  A maximum of $35.0 million of the Company’s common stock may be repurchased in any calendar year. There were no shares repurchased for the three months ended March 31, 2019.

[0001564590-19-018574:notes:154]
[same as prior period, unchanged from 0001564590-19-001400:notes:154]

[0001564590-19-018574:notes:155]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |
| Total number of shares repurchased |  |  | 2,366 |  |
| Average price paid per share |  | $ | 6.34 |  |
| Dollar value of shares repurchased |  | $ | 15,000 |  |
| Dollar value of shares that may yet be repurchased under program |  | $ | 45,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-018574:notes:156]
[same as prior period, unchanged from 0001564590-19-001400:notes:156]

[0001564590-19-018574:notes:157]
[same as prior period, unchanged from 0001564590-19-001400:notes:157]

[0001564590-19-018574:notes:158]
[same as prior period, unchanged from 0001564590-19-001400:notes:158]

[0001564590-19-018574:notes:159]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 8,092 |  |  |  | 9,957 |  |
| Employee stock options and awards outstanding |  |  | 11,192 |  |  |  | 12,060 |  |
| 2014 Employee Stock Purchase Plan |  |  | 10,085 |  |  |  | 5,365 |  |
| Total shares reserved for issuance |  |  | 29,369 |  |  |  | 27,382 |  |

[0001564590-19-018574:notes:160]
[same as prior period, unchanged from 0001564590-19-001400:notes:160]

[0001564590-19-018574:notes:161]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Cost of product revenue |  | $ | 223 |  |  | $ | 163 |  |  | $ | 618 |  |  | $ | 389 |  |
| Cost of service revenue |  |  | 648 |  |  |  | 354 |  |  |  | 1,670 |  |  |  | 783 |  |
| Research and development |  |  | 2,814 |  |  |  | 2,367 |  |  |  | 7,953 |  |  |  | 5,247 |  |
| Sales and marketing |  |  | 3,187 |  |  |  | 2,735 |  |  |  | 8,529 |  |  |  | 7,077 |  |
| General and administrative |  |  | 1,942 |  |  |  | 2,199 |  |  |  | 5,569 |  |  |  | 6,150 |  |
| Total share-based compensation expense |  | $ | 8,814 |  |  | $ | 7,818 |  |  | $ | 24,339 |  |  | $ | 19,646 |  |

[0001564590-19-018574:notes:162]
During the three and nine months ended March 31, 2019, or 2018, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-19-018574:notes:163]
[same as prior period, unchanged from 0001564590-19-001400:notes:163]

[0001564590-19-018574:notes:164]
[same as prior period, unchanged from 0001564590-19-001400:notes:164]

[0001564590-19-018574:notes:165]
The following table summarizes stock award activity for the nine months ended March 31, 2019 (in thousands, except grant date fair value):

[0001564590-19-018574:notes:166]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2018 |  |  | 7,764 |  |  | $ | 8.60 |  |  | $ | 61,804 |  |
| Granted |  |  | 4,516 |  |  |  | 6.44 |  |  |  |  |  |
| Released |  |  | (2,909 | ) |  |  | 7.92 |  |  |  |  |  |
| Cancelled |  |  | (921 | ) |  |  | 8.74 |  |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2019 |  |  | 8,450 |  |  | $ | 7.66 |  |  | $ | 63,280 |  |

[0001564590-19-018574:notes:167]
The following table summarizes stock option activity for the nine months ended March 31, 2019 (in thousands, except per share and contractual term):

[0001564590-19-018574:notes:168]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2018 |  |  | 2,193 |  |  | $ | 3.88 |  |  |  | 2.90 |  |  | $ | 8,996 |  |
| Granted |  |  | 852 |  |  |  | 6.40 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (216 | ) |  |  | 3.73 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (87 | ) |  |  | 6.01 |  |  |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2019 |  |  | 2,742 |  |  | $ | 4.60 |  |  |  | 3.48 |  |  | $ | 7,947 |  |
| Vested and expected to vest at March 31, 2019 |  |  | 2,742 |  |  | $ | 4.60 |  |  |  | 3.48 |  |  | $ | 7,947 |  |
| Exercisable at March 31, 2019 |  |  | 1,974 |  |  | $ | 3.90 |  |  |  | 2.33 |  |  | $ | 7,097 |  |

[0001564590-19-018574:notes:169]
The fair value of each stock option grant under the 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model.  The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-19-018574:notes:170]
[same as prior period, unchanged from 0001564590-19-001400:notes:170]

[0001564590-19-018574:notes:171]
During the third quarter of fiscal 2019, the Company approved the grant of 474,016 stock awards in the form of RSUs to its employees, but did not approve any grants of stock awards to its named executive officers or directors. During the nine months ended March 31, 2019, the Company approved the grant of 4,515,899 stock awards to employees and directors of which 634,900 were PSU’s with a grant date fair value of $6.40 and 3,880,999 were RSUs. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company. These awards included 921,434 awards to named executive officers and directors, of which 209,500 were PSUs and 711,934 were RSUs.

[0001564590-19-018574:notes:172]
For the PSUs referenced in the preceding paragraph, they will be considered performance earned once the Company’s combined earnings per share equals or exceeds $0.20 over two consecutive quarters (the “FY19 Performance Threshold”).  Upon satisfying the FY19 Performance Threshold, the PSUs shall vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, shall vest on the same schedule as the RSUs, subject to continued service to the Company.  If the FY19 Performance Threshold is not met by the third anniversary of the grant date the award is canceled.  In addition, the FY19 Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $10.00 per share.

[0001564590-19-018574:notes:173]
During the third quarter of fiscal 2019, the compensation committee of the Board of Directors modified the FY18 Performance Threshold of $0.32 earnings per share over two consecutive quarters for PSUs issued in fiscal 2018, to $0.20 earnings per share over two consecutive quarters. All other terms of the FY18 PSUs remained the same.

[0001564590-19-018574:notes:174]
During the nine months ended March 31, 2019, the Performance Thresholds were not achieved for fiscal 2018 or fiscal 2019.

[0001564590-19-018574:notes:175]
[same as prior period, unchanged from 0001564590-19-001400:notes:174]

[0001564590-19-018574:notes:176]
[same as prior period, unchanged from 0001564590-19-001400:notes:175]

[0001564590-19-018574:notes:177]
[same as prior period, unchanged from 0001564590-19-001400:notes:176]

[0001564590-19-018574:notes:178]
No PSOs were granted during the third quarter of fiscal 2019.

[0001564590-19-018574:notes:179]
[same as prior period, unchanged from 0001564590-19-001400:notes:178]

[0001564590-19-018574:notes:180]
[same as prior period, unchanged from 0001564590-19-001400:notes:179]

[0001564590-19-018574:notes:181]
There were 1,499,042 and 1,151,759 shares issued under the ESPP during the three months ended March 31, 2019 and 2018, respectively. There were 2,779,750 and 2,419,689 shares issued under the ESPP during the nine months ended March 31, 2019 and 2018, respectively.  The following assumptions were used to calculate the fair value of shares granted under the ESPP during the following periods:

[0001564590-19-018574:notes:182]
|  |  | Employee Stock Purchase Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 2.46 | % |  |  | 1.15 | % |  |  | 2.35 | % |  | 1.64%-1.15% |  |
| Volatility |  |  | 75 | % |  |  | 42 | % |  |  | 70 | % |  |  | 42 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-19-018574:notes:183]
The weighted-average fair value of shares granted under the ESPP during the three months ended March 31, 2019 and 2018 was $2.69 and $4.00, respectively. The weighted-average fair value of shares granted under the ESPP during the nine months ended March 31, 2019 and 2018 was $2.71 and $3.26, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-018574:notes:184]
12.Information about Segments and Geographic Areas

[0001564590-19-018574:notes:185]
[same as prior period, unchanged from 0001564590-19-001400:notes:184]

[0001564590-19-018574:notes:186]
[same as prior period, unchanged from 0001564590-19-001400:notes:185]

[0001564590-19-018574:notes:187]
[same as prior period, unchanged from 0001564590-19-001400:notes:186]

[0001564590-19-018574:notes:188]
| Long-lived Assets |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Americas |  | $ | 138,139 |  |  | $ | 178,251 |  |
| EMEA |  |  | 32,345 |  |  |  | 15,106 |  |
| APAC |  |  | 11,852 |  |  |  | 9,896 |  |
| Total long-lived assets |  | $ | 182,336 |  |  | $ | 203,253 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-018574:notes:189]
[same as prior period, unchanged from 0001564590-19-001400:notes:188]

[0001564590-19-018574:notes:190]
[same as prior period, unchanged from 0001564590-19-001400:notes:189]

[0001564590-19-018574:notes:191]
As of March 31, 2019, the Company did not have any forward foreign currency contracts. As of March 31, 2018, forward foreign currency contracts had a notional principal amount of $6.7 million and an immaterial unrealized gain. These contracts typically have maturities of less than 90 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001564590-19-018574:notes:192]
Foreign currency transactions losses from operations was less than $0.1 million and $0.3 million for the three months ended March 31, 2019 and 2018, respectively.  Foreign currency transactions gains and losses from operations was a gain of $0.1 million and a loss of $1.5 million for the nine months ended March 31, 2019 and 2018, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-018574:notes:193]
[same as prior period, unchanged from 0001564590-19-001400:notes:192]

[0001564590-19-018574:notes:194]
[same as prior period, unchanged from 0001564590-19-001400:notes:193]

[0001564590-19-018574:notes:195]
The Company did not record any restructuring charges, net of reversals during the three months ended March 31, 2019. The Company recorded $1.3 million of restructuring charges, net of reversals during the nine months ended March 31, 2019, associated with a reduction-in-force in the fourth quarter of fiscal 2018 and additional excess facilities obligations.

[0001564590-19-018574:notes:196]
Cash payments of $5.7 million were paid during the nine months ended March 31, 2019.  The balance of the severance and benefits obligations are expected to be paid by the end of fiscal 2019.  The excess facilities obligations will continue through fiscal year 2023.

[0001564590-19-018574:notes:197]
[same as prior period, unchanged from 0001564590-19-001400:notes:196]

[0001564590-19-018574:notes:198]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Total |  |
| Balance as of June 30, 2018 |  | $ | 1,797 |  |  | $ | 4,658 |  |  | $ | 6,455 |  |
| Period charges |  |  | 104 |  |  |  | 1,544 |  |  |  | 1,648 |  |
| Period reversals |  |  | — |  |  |  | (366 | ) |  |  | (366 | ) |
| Period payments |  |  | (193 | ) |  |  | (5,506 | ) |  |  | (5,699 | ) |
| Balance as of March 31, 2019 |  | $ | 1,708 |  |  | $ | 330 |  |  | $ | 2,038 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  | 750 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  | $ | 1,288 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-018574:notes:199]
[same as prior period, unchanged from 0001564590-19-001400:notes:198]

[0001564590-19-018574:notes:200]
For the three months ended March 31, 2019 and 2018, the Company recorded an income tax provision of $1.9 million and $1.7 million, respectively. For the nine months ended March 31, 2019, and 2018, the Company recorded a tax benefit of $2.0 million and a tax provision of $1.8 million, respectively.

[0001564590-19-018574:notes:201]
The income tax provisions for the three months ended March 31, 2019 and 2018, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business the Data Center Business, (3) foreign withholding taxes and (4) state taxes in jurisdictions where the Company has no available state Net Operating Losses (“NOLs”).

[0001564590-19-018574:notes:202]
The income tax provisions for the nine months ended March 31, 2019, and 2018 consisted of the components detailed above.  Additionally, the tax provision for the nine months ended March 31, 2019, is offset by a tax benefit of $2.6 million resulting from the release of a valuation allowance for the Company’s Australian NOLs given consistent and sufficient profitability following the recent acquisitions as well as a tax benefit of $4.7 million for the release of valuation allowance given changes introduced by recently enacted U.S. tax legislation as discussed below.  This legislation changed the U.S. NOL rules to afford an indefinite carryforward period for NOLs generated in tax years beginning after December 31, 2017.  In evaluating the realizability of Deferred Tax Assets (“DTAs”), historically the Company was unable to consider the Deferred Tax Liability (“DTL”) related to amortizable goodwill as a source of future income for reversing deductible differences with fixed lives.  The change to the NOL rules creates an indefinite lived DTA and as such the indefinite lived DTL related to goodwill can now be viewed as a source of income for the newly created indefinite lived DTA.  These two indefinite lived items can now be netted in determining the amount of valuation allowance needed.

[0001564590-19-018574:notes:203]
The tax provision for the nine months ended March 31, 2018, is offset by a tax benefit of $2.5 million resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to the Company’s deferred tax liability related to amortizable goodwill as required by the U.S. tax legislation discussed below. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended March 31, 2019 and 2018, respectively and therefore may not reflect the annual effective tax rate.

[0001564590-19-018574:notes:204]
[same as prior period, unchanged from 0001564590-19-001400:notes:204]

[0001564590-19-018574:notes:205]
The TCJA’s primary change was a reduction in the U.S. Federal statutory corporate tax rate from 35% to 21%.  As a result, the Company recognized a tax benefit in the amount of $2.5 million in the second quarter of fiscal 2018, due to the revaluation of the Company's deferred tax liability related to amortizable goodwill to reflect the lower statutory rate.  Because the U.S. deferred tax assets are offset by a full valuation allowance, the reduction in deferred tax assets for the lower rate was fully offset by a corresponding reduction in valuation allowance resulting in no additional tax provision.

[0001564590-19-018574:notes:206]
The TCJA moves the U.S. from a global taxation regime to a modified territorial regime.  Under the territorial regime, the company’s foreign earnings will generally not be subject to tax in the U.S.  As part of transitioning to this new regime, U.S. companies were required to pay tax on historical earnings generated offshore that have not been repatriated to the U.S. (“Transition Tax”).  The Company has determined there was no incremental tax provision related to the Transition Tax given the Company’s ability to utilize existing tax attributes to offset the impact of the deemed repatriation.

[0001564590-19-018574:notes:207]
The TCJA made broad and complex changes to the U.S. tax code, and in certain instances, lacked clarity and was subject to interpretation until additional U.S. Treasury guidance could be issued. Additional guidance has been released since enactment and has been incorporated into the Company’s related computations.   On December 22, 2017, the SEC issued guidance under Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (“SAB 118”), which allowed registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations.  The measurement period was deemed to have ended earlier when the registrant had obtained, prepared and analyzed the information necessary to finalize its accounting.  During the measurement period, impacts of the law were expected to be recorded at the time a reasonable estimate for all or a portion of the effects could be made, and provisional amounts could be recognized and adjusted as information became available, prepared or analyzed. SAB 118 summarized a three-step process to be applied at each reporting period to account for and qualitatively disclose: (1) the effects of the change in tax law for which accounting is complete; (2) provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but that a reasonable estimate has been determined; and (3) a reasonable estimate could not yet be made and therefore taxes were reflected in accordance with law prior to the enactment of the TCJA. The measurement period ended in the Company’s fiscal quarter ended December 31, 2018 and the Company has finalized all related adjustments.

[0001564590-19-018574:notes:208]
Amounts recorded pursuant to the TCJA and the provisions of SAB 118 relate to the reduction in the U.S. federal tax rate to 21 percent, which resulted in the Company reporting an income tax benefit of $2.5 million in the fiscal year ended June 30, 2018 to remeasure deferred tax liabilities associated with indefinitely lived intangible assets that will reverse at the new 21% rate. Absent this deferred tax liability, the Company has historically been in a net deferred tax asset position that is offset by a full valuation allowance.  The Transition Tax introduced by TCJA was calculated to be zero for the Company given existing tax attributes that were utilized to offset the calculated liability. As discussed below, during the quarter ended December 31, 2018 the Company completed its evaluation of whether to treat global intangible low-taxed income (“GILTI”) as a component of tax expense in the period in which it is incurred or as a component of deferred income taxes.  In conjunction with this determination and the completion of scheduling the reversal of deferred tax assets and liabilities, the Company reduced the valuation allowance level by $4.7 million to reflect the introduction of an indefinite carryforward period for NOLs expected to be generated in tax years beginning after December 31, 2017 once deferred tax assets reverse. With respect to provisions of the TCJA effective for the Company’s fiscal year ended 2019, the Company anticipates several new provisions will impact tax provisions in future periods including limitations on the deductibility of interest expense and certain executive compensation, a minimum tax on certain foreign earnings (i.e., GILTI).  The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. Based on initial assessment and interpretation of the new provision, the Company expects that it will be subject to incremental U.S. tax on GILTI income beginning in fiscal 2019. The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred. The Base Erosion and Anti-Abuse Tax (“BEAT”) provisions in the Tax Reform Act eliminate the deduction of certain base-erosion payments made to related foreign corporations and impose a minimum tax if greater than regular tax.  There is a reasonable amount of uncertainty surrounding the interpretation of this new provision, however, based on initial assessment and a reasonable interpretation of the new provision, the Company expects that it will not be subject to the incremental U.S. tax on BEAT income beginning in fiscal 2019, due to a realignment of the Company’s international structure.

[0001564590-19-018574:notes:209]
In the three months ended September 30, 2018, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs.  Historically, GAAP has prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset had been sold outside the consolidated group.  Effective as of July 1, 2018, the Company adopted ASU 2016-16 on a modified retrospective basis which requires an adjustment of the cumulative-effect of the adoption to retained earnings.  However, the adjustment was immaterial to the financial statements and no such adjustment was necessary.  As a result of adoption, the income tax consequences of future intra-entity transfer of assets will be recognized in earnings in each period rather than be deferred until the assets leave the consolidated group.  In the three months ended September 30, 2018, the Company recognized a deferred tax asset relating to a transfer of certain assets from the U.S. parent company to its wholly-owned Irish subsidiary of $3.7 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to Company’s statement of operations.

[0001564590-19-018574:notes:210]
The Company has provided a full valuation allowance against all its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the deferred tax assets of a newly established wholly owned Irish subsidiary.  These valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-19-018574:notes:211]
The acquisition of Enterasys in October 2013, included a U.S. parent company as well as its wholly-owned foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  In addition, the Company completed asset purchases of the WLAN Business, the Campus Fabric Business and the Data Center Business in October 2016, July 2017, and October 2017, respectively.  The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts for U.S. tax purposes over 15 years. The Company’s wholly owned Irish subsidiary is amortizing the intangible portion of the transferred assets referenced above over 6 years. During the three and nine months ended March 31, 2019, the Company deducted $1.8 million and $5.8 million of U.S. tax amortization expense respectively, for each period related to capitalized goodwill resulting from these acquisitions. As of March 31, 2019, the Company recorded a U.S. deferred tax liability of $6.8 million related to this goodwill amortization which now can be partially considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-19-018574:notes:212]
The Company had $17.4 million of unrecognized tax benefits as of March 31, 2019.  The future impact of the unrecognized tax benefit of $17.4 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-19-018574:notes:213]
[same as prior period, unchanged from 0001564590-19-001400:notes:213]

[0001564590-19-018574:notes:214]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001, forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000, forward due to net operating losses. The Company recently settled an examination by the state of North Carolina for fiscal years ended 2014, 2015 and 2016. The settlement resulted in an immaterial payment to the state to close all three years.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-018574:notes:215]
[same as prior period, unchanged from 0001564590-19-001400:notes:215]

[0001564590-19-018574:notes:216]
Basic earnings per share is calculated by dividing net earnings by the weighted average number of common shares outstanding during the period. Dilutive earnings per share is calculated by dividing net earnings by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested restricted stock units.

[0001564590-19-018574:notes:217]
[same as prior period, unchanged from 0001564590-19-001400:notes:217]

[0001564590-19-018574:notes:218]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Net loss |  | $ | (6,932 | ) |  | $ | (13,613 | ) |  | $ | (8,798 | ) |  | $ | (41,160 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 117,944 |  |  |  | 115,059 |  |  |  | 117,619 |  |  |  | 113,641 |  |
| Net loss per share - basic and diluted |  | $ | (0.06 | ) |  | $ | (0.12 | ) |  | $ | (0.07 | ) |  | $ | (0.36 | ) |

[0001564590-19-018574:notes:219]
[same as prior period, unchanged from 0001564590-19-001400:notes:219]

[0001564590-19-018574:notes:220]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Options to purchase common stock |  |  | 780 |  |  |  | 2,379 |  |  |  | 621 |  |  |  | 2,649 |  |
| Restricted stock units |  |  | 1,907 |  |  |  | 8,213 |  |  |  | 888 |  |  |  | 7,670 |  |
| Employee Stock Purchase Plan shares |  |  | 965 |  |  |  | 972 |  |  |  | 965 |  |  |  | 1,101 |  |
| Total shares excluded |  |  | 3,652 |  |  |  | 11,564 |  |  |  | 2,474 |  |  |  | 11,420 |  |
