# EXTR 10-Q controls and the auditor's report


## item_4_controls

[0001564590-19-018574:item_4_controls:1]
Item 4. Controls and Procedures

[0001564590-19-018574:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-19-018574:item_4_controls:3]
Disclosure controls and procedures (as such term is defined under Rules 13a-15(e) and Rule 15d-15(e) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) are controls and procedures designed to reasonably assure that information required to be disclosed in our reports filed under the Exchange Act, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC's rules and forms and to reasonably assure that such information is accumulated and communicated to our management, including the Chief Executive Officer (“CEO”) and the Chief Financial Officer (“CFO”), as appropriate to allow timely decisions regarding required disclosure.

[0001564590-19-018574:item_4_controls:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we evaluated the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO concluded that, as of March 31, 2019, our disclosure controls and procedures were not effective as a result of the material weakness in our internal control over financial reporting described below.

[0001564590-19-018574:item_4_controls:5]
Changes in Internal Control over Financial Reporting

[0001564590-19-018574:item_4_controls:6]
During our third quarter ended March 31, 2019, management identified control deficiencies related to the ineffective design of certain process level controls addressing the accuracy of sales orders entered by the Company. These control design deficiencies arose following an enhancement, implemented during our second fiscal quarter ended December 31, 2018, to our Order Entry system.  These deficiencies resulted from inadequate risk assessment associated with the system changes and inadequate communication of those changes to Order Entry personnel.

[0001564590-19-018574:item_4_controls:7]
These control deficiencies created a reasonable possibility that a material misstatement to our consolidated financial statements would not be prevented or detected on a timely basis, and accordingly management assessed these control deficiencies as a material weakness.

[0001564590-19-018574:item_4_controls:8]
43

[0001564590-19-018574:item_4_controls:9]
These control deficiencies resulted in immaterial misstatements to our condensed consolidated financial statements as of and for the three-month period ended December 31, 2018, that were corrected in our condensed consolidated financial statements as of and for the three-month period ended March 31, 2019.

[0001564590-19-018574:item_4_controls:10]
We have initiated a plan to remediate the material weakness identified above, including (i) redesigning controls to validate all sales orders are processed accurately, and (ii) augmenting user training with respect to the enhancements to the Order Entry system.  We expect the material weakness to be fully remediated before the end of our fiscal 2019.

[0001564590-19-018574:item_4_controls:11]
Except for the foregoing, there was no change in the Company’s internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) in the most recent fiscal quarter that has materially affected, or is reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001564590-19-018574:item_4_controls:12]
Inherent Limitations on Effectiveness of Controls

[0001564590-19-018574:item_4_controls:13]
Our management, including our CEO and CFO, does not expect that our disclosure controls or our internal control over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within Extreme Networks have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events. Projections of any evaluation of the effectiveness of controls in future periods are subject to risks. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Notwithstanding these limitations, our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives.

[0001564590-19-018574:item_4_controls:14]
44
