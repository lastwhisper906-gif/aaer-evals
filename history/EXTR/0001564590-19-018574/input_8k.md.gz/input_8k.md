# EXTR 8-K — 0001564590-19-014567 filed 2019-05-01

## item codes, every 8-K on or before 2019-05-10

- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2019-05-10

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-014567:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-19-014567:8k_2_02:2]
extr-ex991_6.htm

[0001564590-19-014567:8k_2_02:3]
Exhibit 99.1

[0001564590-19-014567:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-19-014567:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Stan Kovler |  | Media Contact Christi Nicolacopoulos |
| 919/595-4196 |  | 603/952-5005 |
| Investor_relations@extremenetworks.com |  | pr@extremenetworks.com |

[0001564590-19-014567:8k_2_02:6]
Extreme Networks Reports Third Quarter Fiscal Year 2019 Financial Results

[0001564590-19-014567:8k_2_02:7]
SAN JOSE, Calif., May 1, 2019 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal third quarter ended March 31, 2019.

[0001564590-19-014567:8k_2_02:8]
Fiscal Third Quarter Results:

[0001564590-19-014567:8k_2_02:9]
|  | • | Revenue $250.9 million, down 4% year-over-year and down 1% quarter-over-quarter. |

[0001564590-19-014567:8k_2_02:10]
|  | • | GAAP gross margin 55.4% compared to 54.6%, in Q3 last year. |

[0001564590-19-014567:8k_2_02:11]
|  | • | Non-GAAP gross margin 57.6% compared to 57.9%, in Q3 last year. |

[0001564590-19-014567:8k_2_02:12]
|  | • | GAAP operating margin (0.9%) compared to (3.1)%, in Q3 last year. |

[0001564590-19-014567:8k_2_02:13]
|  | • | Non-GAAP operating margin 5.6%, compared to 9.3%, in Q3 last year. |

[0001564590-19-014567:8k_2_02:14]
|  | • | Net cash provided by operating activities $17.7 million. |

[0001564590-19-014567:8k_2_02:15]
|  | • | Free Cash Flow $12.7 million. |

[0001564590-19-014567:8k_2_02:16]
“We reported revenue towards the midpoint of our guidance range reflecting seasonality in our business following a strong second quarter. The execution of our acquisition strategy is coming together: customers are embracing the capabilities and ease of use of our software driven solutions; especially in our Automated Campus and Agile Data Center pillars. We are at the early stages of refreshing 70% of our products, which will put us in a better competitive position; our supply chain operations are running more efficiently than ever before; our digital transformation is paving the way for higher productivity; and we have a strong balance sheet resulting from consistent quarterly cash flow generation this year.” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-19-014567:8k_2_02:17]
Meyercord added, “Looking ahead, we expect FY19 revenue of approximately $1 billion. Our outlook for Q4 reflects the weakening economic environment in EMEA, lengthening sales cycles in our wireless business reflecting the introduction of WiFi6, and a lower backlog entering Q4. On a positive note, our E-Rate filings were up 50% year-over-year, the benefit of which will be realized in Q1 and Q2, FY20. We remain committed to achieving our goal of a 15% operating margin and are focused on driving greater operational efficiency to balance the near-term revenue trends we are experiencing.”

[0001564590-19-014567:8k_2_02:18]
Recent Key Highlights:

[0001564590-19-014567:8k_2_02:19]
|  | • | Brigham Young University, (BYU), deployed Extreme’s Smart OmniEdge™ solution to deliver an interactive game-day experience and provide mobile ticketing and payment at LaVell Edwards Stadium; making it the first collegiate football stadium in Utah to have an NFL-caliber, high-density Wi-Fi system. Extreme installed approximately 1,250 access points throughout the 64,000-seat arena, along with switching, management, and network access control technology Extreme |

[0001564590-19-014567:8k_2_02:20]
|  |  | analytics software enables BYU to see which applications fans are using on the Wi-Fi network, and what the response time is for each application so they can optimize the network for maximum application performance and provide a customized experience through marketing initiatives. |

[0001564590-19-014567:8k_2_02:21]
|  | • | The State of Connecticut Department of Administrative Services-Bureau of Enterprise Systems and Technology has selected Extreme’s wireless access points, switching, management and analytics technology, part of its Smart OmniEdge™ solution, as well as Extreme Professional Services, to provide secure, reliable connectivity at one of its new locations in Hartford. The network will support multiple agencies offering critical services to state employees and residents. With this solution, the State consolidated the management of multiple agency topologies onto one network, while maintaining security and operations through segmentation. |

[0001564590-19-014567:8k_2_02:22]
|  | • | Extreme Networks announced investments in software automation, and AI to help customers take the next step in their digital transformation efforts and become an autonomous enterprise. Extreme is investing 95 percent of its research and development dollars into software. We are also investing in AI this year to expand the automation capabilities across our Smart OmniEdge™, Automated Campus™, and Agile Data Center™ solutions, creating a secure, self-healing, self-driving network—from the enterprise edge to the cloud. |

[0001564590-19-014567:8k_2_02:23]
|  | • | Extreme Networks announced the general availability of Defender for IoT, part of its Smart OmniEdge™ portfolio. Defender for IoT is a simple security solution to help organizations secure unsecured IoT devices. It can be deployed on any network and is so easy to use even non-technical staff at schools, hospitals, retailers and hospitality venues can use it to isolate and protect both wired and wireless IoT devices from cyberattacks. |

[0001564590-19-014567:8k_2_02:24]
|  | • | Extreme Networks, Inc was named an April 2019 Gartner Peer Insights Customers’ Choice for Wired and Wireless LAN Access Infrastructure and an April 2019 Gartner Peer Insights Customers’ Choice for Data Center Networking. 1 Gartner defines Wired and Wireless LAN access infrastructure vendors as those supplying wired and wireless networking hardware and software that enables devices to connect to the enterprise wired LAN or Wi-Fi network. Gartner defines data center networking vendors as providers of hardware and/or software solutions to deliver connectivity primarily within enterprise data centers. This includes data center core/spine switches, access switches (top of rack [ToR], leaf), virtual switching, Ethernet fabrics, network operating systems (NOSs) and network overlays, and the requisite management, automation and orchestration of those components. The Gartner Peer Insights Customers' Choice distinction is based on feedback and ratings from end-user professionals who have experience purchasing, implementing and/or using the product or service. Users praised our advanced technology, ease of implementation and our customer support in the latest Peer Insights ranking. |

[0001564590-19-014567:8k_2_02:25]
1 Gartner Peer Insights Customers' Choice constitute the subjective opinions of individual end-user reviews, ratings, and data applied against a documented methodology; they neither represent the views of, nor constitute an endorsement by, Gartner or its affiliates.

[0001564590-19-014567:8k_2_02:26]
The Gartner Report(s) described herein, (the "Gartner Report(s)") represent(s) research opinion or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and are not representations of fact. Each Gartner Report speaks as of its original publication date (and

[0001564590-19-014567:8k_2_02:27]
not as of the date of this press release) and the opinions expressed in the Gartner Report(s) are subject to change without notice.

[0001564590-19-014567:8k_2_02:28]
Fiscal Q3 2019 Financial Metrics:

[0001564590-19-014567:8k_2_02:29]
(in millions, except percentages and per share information)

[0001564590-19-014567:8k_2_02:30]
|  |  | Q3 FY'19 |  |  | Q3 FY'18 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190.8 |  |  | $ | 203.5 |  |  | $ | (12.7 | ) |  |  | (6 | )% |
| Service |  |  | 60.1 |  |  |  | 58.5 |  |  |  | 1.6 |  |  |  | 3 | % |
| Total Net Revenue |  | $ | 250.9 |  |  | $ | 262.0 |  |  | $ | (11.1 | ) |  |  | (4 | )% |
| Gross Margin |  |  | 55.4 | % |  |  | 54.6 | % |  | 80 bps |  |  | - |  |
| Operating Margin |  |  | (0.9 | )% |  |  | (3.1 | )% |  | 220 bps |  |  | - |  |
| Net Loss |  | $ | (6.9 | ) |  | $ | (13.6 | ) |  | $ | 6.7 |  |  |  | 49 | % |
| Loss per basic share |  | $ | (0.06 | ) |  | $ | (0.12 | ) |  | $ | 0.06 |  |  |  | 50 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190.8 |  |  | $ | 203.5 |  |  | $ | (12.7 | ) |  |  | (6 | )% |
| Service |  |  | 60.1 |  |  |  | 58.5 |  |  |  | 1.6 |  |  |  | 3 | % |
| Total Net Revenue |  | $ | 250.9 |  |  | $ | 262.0 |  |  | $ | (11.1 | ) |  |  | (4 | )% |
| Gross Margin |  |  | 57.6 | % |  |  | 57.9 | % |  | -30 bps |  |  | - |  |
| Operating Margin |  |  | 5.6 | % |  |  | 9.3 | % |  | -370 bps |  |  | - |  |
| Net Income |  | $ | 9.3 |  |  | $ | 19.0 |  |  | $ | (9.7 | ) |  |  | (51 | )% |
| Income per diluted share |  | $ | 0.08 |  |  | $ | 0.16 |  |  | $ | (0.08 | ) |  |  | (50 | )% |

[0001564590-19-014567:8k_2_02:31]
|  | • | Q3 ending Cash balance was $156.8 million, an increase of $16.2 million from Q2 and an increase of $53.6 million from Q3 last year, driven primarily by higher cash flow from operations. |

[0001564590-19-014567:8k_2_02:32]
|  | • | Accounts receivable balance ending Q3 was $141.5 million, with days sales outstanding of 51. |

[0001564590-19-014567:8k_2_02:33]
|  | • | Q3 ending inventory was $57.6 million, a decrease of $0.7 million from Q2 and a decrease of $20.2 million from Q3 last year. |

[0001564590-19-014567:8k_2_02:34]
|  | • | Q3 ending gross debt was $182.9 million, a decrease of $2.4 million from Q2 and an increase of $2.4 million from Q3 last year. Net Debt* decreased to $24.2 million from $42.6 million in Q2. |

[0001564590-19-014567:8k_2_02:35]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance.  Free cash flow represents GAAP operating cash flows less purchases of property, plant and equipment.  Extreme considers free cash flow as useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of the non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.  As shown in the table below (in thousands):

[0001564590-19-014567:8k_2_02:36]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Cash flow provided by (used in) operations | $ | 17,709 |  |  | $ | (15,978 | ) |  | $ | 79,502 |  |  | $ | (1,730 | ) |
| Less: PP&E CapEx spending |  | (5,041 | ) |  |  | (8,690 | ) |  |  | (16,181 | ) |  |  | (21,999 | ) |
| Total free cash flow | $ | 12,668 |  |  | $ | (24,668 | ) |  | $ | 63,321 |  |  | $ | (23,729 | ) |

[0001564590-19-014567:8k_2_02:37]
*Net Debt is defined as gross debt minus loan fees minus cash: as shown in the table below (in millions):

[0001564590-19-014567:8k_2_02:38]
| Gross debt |  | Loan fees |  | Cash |  | Net debt |  |
| $ | 182.9 |  | $ | 1.9 |  | $ | 156.8 |  | $ | 24.2 |  |

[0001564590-19-014567:8k_2_02:39]
Business Outlook:

[0001564590-19-014567:8k_2_02:40]
For its fourth quarter of fiscal 2019, ending June 30, 2019, the Company is targeting revenue in a range of $240.0 million to $250.0 million.  GAAP gross margin is targeted between 52.9% and 55.1% and non-GAAP gross margin is targeted between 57.5% and 59.5%. Operating expenses are targeted to be between $139.8 million and $145.4 million on a GAAP basis and $130.5 million to $136.1 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $17.8 million to $12.6 million or $0.15 to $0.11 per basic share.  Non-GAAP net income earnings are targeted in a range of $2.5 million to $7.7 million, or $0.02 to $0.6 per diluted share. The GAAP and non-GAAP per share targets are based on 118.9 million and 121.6 million weighted shares outstanding, respectively.

[0001564590-19-014567:8k_2_02:41]
The following table shows the GAAP to non-GAAP reconciliation for Q4 FY’19 guidance:

[0001564590-19-014567:8k_2_02:42]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 52.9% - 55.1% |  |  | (5.4)% - (3.1)% |  |  | ($0.15) - ($0.11) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 4.2% |  |  | 4.2% |  |  | $ | 0.08 |  |
| Stock based compensation | 0.4% |  |  | 3.6% |  |  | $ | 0.07 |  |
| Amortization of non product intangibles | - |  |  | 0.6% |  |  | $ | 0.01 |  |
| Non-GAAP | 57.5% - 59.5% |  |  | 3.1% - 5.1% |  |  | $0.02 - $0.06 |  |

[0001564590-19-014567:8k_2_02:43]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-19-014567:8k_2_02:44]
Conference Call:

[0001564590-19-014567:8k_2_02:45]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the third fiscal quarter results as well as the business outlook for fourth fiscal quarter ending June 30, 2019, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at

[0001564590-19-014567:8k_2_02:46]
http://investor.extremenetworks.com and a replay of the call will be available on the website through May 7, 2019.  The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 7669229. The encore recording will be available for 7 days following the call.

[0001564590-19-014567:8k_2_02:47]
About Extreme Networks:

[0001564590-19-014567:8k_2_02:48]
Extreme Networks, Inc. (EXTR) delivers software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable digital transformation. Our 100% in-sourced services and support are number one in the industry. Even with 30,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking™. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's  website or call 1-888-257-3000.

[0001564590-19-014567:8k_2_02:49]
Extreme Networks and the Extreme Networks logo are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-19-014567:8k_2_02:50]
Non-GAAP Financial Measures:

[0001564590-19-014567:8k_2_02:51]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, gain on sale of equity investment, loss on lease contracts, income tax and free cash flow.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-19-014567:8k_2_02:52]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-19-014567:8k_2_02:53]
Forward Looking Statements:

[0001564590-19-014567:8k_2_02:54]
Statements in this release, including those concerning the Company’s business outlook, future financial and operating results, acquired technologies and operations, future price increases, changes to our supply chain, the introduction of new products, the impact of tariffs on our products, including the relocation of

[0001564590-19-014567:8k_2_02:55]
More information about potential factors that could affect the Company's business and financial results are described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" and "Risk Factors" included in the Company’s Quarterly Report on Form 10-Q for the three months ended December 31, 2018 and Annual Report on Form 10-K for the year ended June 30, 2018 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-19-014567:8k_2_02:56]
###

[0001564590-19-014567:8k_2_02:57]
EXTREME NETWORKS, INC.

[0001564590-19-014567:8k_2_02:58]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-014567:8k_2_02:59]
(In thousands)

[0001564590-19-014567:8k_2_02:60]
(Unaudited)

[0001564590-19-014567:8k_2_02:61]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 156,813 |  |  | $ | 121,139 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,761 at March 31, 2019 and $1,478 at June 30, 2018 |  |  | 141,455 |  |  |  | 212,423 |  |
| Inventories |  |  | 57,645 |  |  |  | 63,867 |  |
| Prepaid expenses and other current assets |  |  | 34,684 |  |  |  | 30,484 |  |
| Total current assets |  |  | 390,597 |  |  |  | 427,913 |  |
| Property and equipment, net |  |  | 73,057 |  |  |  | 78,519 |  |
| Intangible assets, net |  |  | 57,362 |  |  |  | 77,092 |  |
| Goodwill |  |  | 138,577 |  |  |  | 139,082 |  |
| Other assets |  |  | 51,917 |  |  |  | 47,642 |  |
| Total assets |  | $ | 711,510 |  |  | $ | 770,248 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Accounts payable |  |  | 49,143 |  |  |  | 75,689 |  |
| Accrued compensation and benefits |  |  | 32,849 |  |  |  | 50,351 |  |
| Accrued warranty |  |  | 13,206 |  |  |  | 12,807 |  |
| Current portion, deferred revenue, net |  |  | 136,452 |  |  |  | 130,865 |  |
| Other accrued liabilities |  |  | 62,088 |  |  |  | 81,153 |  |
| Total current liabilities |  |  | 302,747 |  |  |  | 359,872 |  |
| Deferred revenue, less current portion |  |  | 51,269 |  |  |  | 43,660 |  |
| Long-term debt, less current portion |  |  | 171,993 |  |  |  | 188,749 |  |
| Deferred income taxes |  |  | 1,844 |  |  |  | 6,135 |  |
| Other long-term liabilities |  |  | 57,689 |  |  |  | 59,100 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000 shares authorized; 121,035 and 116,124 shares issued, respectively; 118,669 and 116,124 shares outstanding, respectively |  |  | 121 |  |  |  | 116 |  |
| Additional paid-in-capital |  |  | 979,775 |  |  |  | 942,397 |  |
| Accumulated other comprehensive loss |  |  | (2,549 | ) |  |  | (1,703 | ) |
| Accumulated deficit |  |  | (836,379 | ) |  |  | (828,078 | ) |
| Treasury stock at cost: 2,366 and 0 shares, respectively |  |  | (15,000 | ) |  |  | — |  |
| Stockholders’ equity |  |  | 125,968 |  |  |  | 112,732 |  |
| Total liabilities and stockholders’ equity |  | $ | 711,510 |  |  | $ | 770,248 |  |

[0001564590-19-014567:8k_2_02:62]
EXTREME NETWORKS, INC.

[0001564590-19-014567:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-014567:8k_2_02:64]
(In thousands, except per share amounts)

[0001564590-19-014567:8k_2_02:65]
(Unaudited)

[0001564590-19-014567:8k_2_02:66]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190,740 |  |  | $ | 203,527 |  |  | $ | 558,027 |  |  | $ | 543,151 |  |
| Service |  |  | 60,124 |  |  |  | 58,477 |  |  |  | 185,403 |  |  |  | 161,691 |  |
| Total net revenues |  |  | 250,864 |  |  |  | 262,004 |  |  |  | 743,430 |  |  |  | 704,842 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 86,876 |  |  |  | 94,485 |  |  |  | 256,906 |  |  |  | 253,002 |  |
| Service |  |  | 25,069 |  |  |  | 24,536 |  |  |  | 74,235 |  |  |  | 67,490 |  |
| Total cost of revenues |  |  | 111,945 |  |  |  | 119,021 |  |  |  | 331,141 |  |  |  | 320,492 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 103,864 |  |  |  | 109,042 |  |  |  | 301,121 |  |  |  | 290,149 |  |
| Service |  |  | 35,055 |  |  |  | 33,941 |  |  |  | 111,168 |  |  |  | 94,201 |  |
| Total gross profit |  |  | 138,919 |  |  |  | 142,983 |  |  |  | 412,289 |  |  |  | 384,350 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 52,081 |  |  |  | 50,920 |  |  |  | 155,526 |  |  |  | 131,112 |  |
| Sales and marketing |  |  | 72,321 |  |  |  | 72,240 |  |  |  | 208,245 |  |  |  | 193,460 |  |
| General and administrative |  |  | 15,479 |  |  |  | 11,707 |  |  |  | 42,136 |  |  |  | 35,561 |  |
| Acquisition and integration costs, net of bargain purchase gain |  |  | — |  |  |  | 9,316 |  |  |  | 2,613 |  |  |  | 47,675 |  |
| Restructuring charges, net of reversals |  |  | — |  |  |  | 4,920 |  |  |  | 1,282 |  |  |  | 4,920 |  |
| Amortization of intangibles |  |  | 1,292 |  |  |  | 2,101 |  |  |  | 5,008 |  |  |  | 6,461 |  |
| Total operating expenses |  |  | 141,173 |  |  |  | 151,204 |  |  |  | 414,810 |  |  |  | 419,189 |  |
| Operating loss |  |  | (2,254 | ) |  |  | (8,221 | ) |  |  | (2,521 | ) |  |  | (34,839 | ) |
| Interest income |  |  | 628 |  |  |  | 740 |  |  |  | 1,665 |  |  |  | 2,104 |  |
| Interest expense |  |  | (2,996 | ) |  |  | (4,044 | ) |  |  | (9,588 | ) |  |  | (8,763 | ) |
| Other (expense) income, net |  |  | (433 | ) |  |  | (359 | ) |  |  | (345 | ) |  |  | 2,125 |  |
| Loss before income taxes |  |  | (5,055 | ) |  |  | (11,884 | ) |  |  | (10,789 | ) |  |  | (39,373 | ) |
| Provision (benefit) for income taxes |  |  | 1,877 |  |  |  | 1,729 |  |  |  | (1,991 | ) |  |  | 1,787 |  |
| Net loss |  | $ | (6,932 | ) |  | $ | (13,613 | ) |  | $ | (8,798 | ) |  | $ | (41,160 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.06 | ) |  | $ | (0.12 | ) |  | $ | (0.07 | ) |  | $ | (0.36 | ) |
| Net loss per share - diluted |  | $ | (0.06 | ) |  | $ | (0.12 | ) |  | $ | (0.07 | ) |  | $ | (0.36 | ) |
| Shares used in per share calculation - basic |  |  | 117,944 |  |  |  | 115,059 |  |  |  | 117,619 |  |  |  | 113,641 |  |
| Shares used in per share calculation - diluted |  |  | 117,944 |  |  |  | 115,059 |  |  |  | 117,619 |  |  |  | 113,641 |  |

[0001564590-19-014567:8k_2_02:67]
EXTREME NETWORKS, INC.

[0001564590-19-014567:8k_2_02:68]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-014567:8k_2_02:69]
(In thousands)

[0001564590-19-014567:8k_2_02:70]
(Unaudited)

[0001564590-19-014567:8k_2_02:71]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (8,798 | ) |  | $ | (41,160 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 20,026 |  |  |  | 15,417 |  |
| Amortization of intangible assets |  |  | 19,734 |  |  |  | 17,771 |  |
| Provision for doubtful accounts |  |  | 1,369 |  |  |  | 1,566 |  |
| Stock-based compensation |  |  | 24,339 |  |  |  | 19,646 |  |
| Deferred income taxes |  |  | (6,030 | ) |  |  | (1,900 | ) |
| Unrealized/realized loss (gain) on equity investment |  |  | - |  |  |  | (3,757 | ) |
| Realized gain on bargain purchase |  |  | - |  |  |  | (5,030 | ) |
| Non-cash interest |  |  | 2,308 |  |  |  | 2,113 |  |
| Other |  |  | 15 |  |  |  | 328 |  |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 69,328 |  |  |  | (45,376 | ) |
| Inventories |  |  | 6,222 |  |  |  | 5,122 |  |
| Prepaid expenses and other assets |  |  | (6,993 | ) |  |  | (3,711 | ) |
| Accounts payable |  |  | (26,348 | ) |  |  | 28,912 |  |
| Accrued compensation and benefits |  |  | (17,502 | ) |  |  | (4,779 | ) |
| Deferred revenue |  |  | 13,197 |  |  |  | 10,365 |  |
| Other current and long-term liabilities |  |  | (11,365 | ) |  |  | 2,743 |  |
| Net cash provided by (used in) operating activities |  |  | 79,502 |  |  |  | (1,730 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (16,181 | ) |  |  | (21,999 | ) |
| Business acquisitions |  |  | — |  |  |  | (97,581 | ) |
| Proceeds from sale of investment |  |  | 727 |  |  |  | 4,922 |  |
| Net cash used in investing activities |  |  | (15,454 | ) |  |  | (114,658 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 100,000 |  |
| Loan fees on borrowings |  |  | (545 | ) |  |  | (1,494 | ) |
| Repayments of debt |  |  | (17,403 | ) |  |  | (13,278 | ) |
| Repurchase of stock |  |  | (15,000 | ) |  |  | — |  |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 13,044 |  |  |  | 4,657 |  |
| Contingent consideration obligations |  |  | (5,274 | ) |  |  | (671 | ) |
| Deferred payments on an acquisition |  |  | (3,000 | ) |  |  | — |  |
| Net cash (used in) provided by financing activities |  |  | (28,178 | ) |  |  | 89,214 |  |
| Foreign currency effect on cash |  |  | (196 | ) |  |  | (99 | ) |
| Net increase (decrease) in cash |  |  | 35,674 |  |  |  | (27,273 | ) |
| Cash and cash equivalents at beginning of period |  |  | 121,139 |  |  |  | 130,450 |  |
| Cash and cash equivalents at end of period |  | $ | 156,813 |  |  | $ | 103,177 |  |

[0001564590-19-014567:8k_2_02:72]
Extreme Networks, Inc.

[0001564590-19-014567:8k_2_02:73]
Non-GAAP Measures of Financial Performance

[0001564590-19-014567:8k_2_02:74]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP gross margin, non-GAAP operating expenses non-GAAP earnings per diluted share and Free Cash Flow.

[0001564590-19-014567:8k_2_02:75]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, gain on sale of equity investment, loss on lease contracts, income tax and free cash flow.

[0001564590-19-014567:8k_2_02:76]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-19-014567:8k_2_02:77]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-19-014567:8k_2_02:78]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, restructuring charges, gain on sale of equity investment, loss on lease contracts, income tax and free cash flow.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-19-014567:8k_2_02:79]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-19-014567:8k_2_02:80]
Stock-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its Employee Stock Purchase Plan.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-19-014567:8k_2_02:81]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Campus Fabric business, b) Data Center business and c) the bargain purchase gain for the capital financing business; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-19-014567:8k_2_02:82]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-19-014567:8k_2_02:83]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-19-014567:8k_2_02:84]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-19-014567:8k_2_02:85]
Gain on sale of equity investment.  The gain on the sale of an equity investment refers to a third party acquisition that acquired a business entity in which the Company had an equity investment.

[0001564590-19-014567:8k_2_02:86]
Loss on lease contracts.  The loss on lease contracts refers to leased facilities to which the Company has a contractual obligation but will not receive a future financial benefit.

[0001564590-19-014567:8k_2_02:87]
Income tax.   Income tax adjustments relate to the tax impact of a reduced US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation, the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada, the release of a deferred tax liability for amortizable goodwill given recently enacted US tax legislation, the release of a deferred tax liability related to a restructuring of our foreign operations, and the impact of the release of our Australian valuation allowance.

[0001564590-19-014567:8k_2_02:88]
We do not reflect a tax effect associated with the Non-GAAP operating adjustments as the adjustments are primarily related to the US entity which has a full valuation of various loss carryforward tax attributes.

[0001564590-19-014567:8k_2_02:89]
EXTREME NETWORKS, INC.

[0001564590-19-014567:8k_2_02:90]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-014567:8k_2_02:91]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-19-014567:8k_2_02:92]
(In thousands, except percentages and per share amounts)

[0001564590-19-014567:8k_2_02:93]
(Unaudited)

[0001564590-19-014567:8k_2_02:94]
| Non-GAAP Revenue | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Revenue - GAAP Basis | $ | 250,864 |  |  | $ | 262,004 |  |  | $ | 743,430 |  |  | $ | 704,842 |  |
| Revenue - Non-GAAP Basis | $ | 250,864 |  |  | $ | 262,004 |  |  | $ | 743,430 |  |  | $ | 704,842 |  |

[0001564590-19-014567:8k_2_02:95]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Gross profit - GAAP Basis | $ | 138,919 |  |  | $ | 142,983 |  |  | $ | 412,289 |  |  | $ | 384,350 |  |
| Gross margin - GAAP Basis percentage |  | 55.4 | % |  |  | 54.6 | % |  |  | 55.5 | % |  |  | 54.5 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 871 |  |  |  | 517 |  |  |  | 2,288 |  |  |  | 1,172 |  |
| Acquired inventory adjustments |  | — |  |  |  | 597 |  |  |  | — |  |  |  | 4,784 |  |
| Acquisition and integration costs |  | — |  |  |  | 3,068 |  |  |  | 1,752 |  |  |  | 7,586 |  |
| Amortization of intangibles |  | 4,788 |  |  |  | 4,581 |  |  |  | 14,413 |  |  |  | 11,109 |  |
| Total adjustments to GAAP gross profit | $ | 5,659 |  |  | $ | 8,763 |  |  | $ | 18,453 |  |  | $ | 24,651 |  |
| Gross profit - Non-GAAP | $ | 144,578 |  |  | $ | 151,746 |  |  | $ | 430,742 |  |  | $ | 409,001 |  |
| Gross margin - Non-GAAP percentage |  | 57.6 | % |  |  | 57.9 | % |  |  | 57.9 | % |  |  | 58.0 | % |

[0001564590-19-014567:8k_2_02:96]
| Non-GAAP Operating Income | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| GAAP operating loss | $ | (2,254 | ) |  | $ | (8,221 | ) |  | $ | (2,521 | ) |  | $ | (34,839 | ) |
| GAAP operating loss percentage |  | (0.9 | )% |  |  | (3.1 | )% |  |  | (0.3 | )% |  |  | (4.9 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 871 |  |  |  | 517 |  |  |  | 2,288 |  |  |  | 1,172 |  |
| Stock based compensation expense, R&D |  | 2,814 |  |  |  | 2,367 |  |  |  | 7,953 |  |  |  | 5,247 |  |
| Stock based compensation expense, S&M |  | 3,187 |  |  |  | 2,735 |  |  |  | 8,529 |  |  |  | 7,077 |  |
| Stock based compensation expense, G&A |  | 1,942 |  |  |  | 2,199 |  |  |  | 5,569 |  |  |  | 6,150 |  |
| Acquisition and integration costs |  | — |  |  |  | 12,384 |  |  |  | 4,298 |  |  |  | 55,261 |  |
| Restructuring charge, net of reversal |  | — |  |  |  | 4,920 |  |  |  | 1,282 |  |  |  | 4,920 |  |
| Acquired inventory adjustments |  | — |  |  |  | 597 |  |  |  | — |  |  |  | 4,784 |  |
| Litigation |  | — |  |  |  | 207 |  |  |  | — |  |  |  | (158 | ) |
| Amortization of intangibles |  | 6,080 |  |  |  | 6,682 |  |  |  | 19,421 |  |  |  | 17,570 |  |
| Loss on lease contracts |  | 1,288 |  |  |  | — |  |  |  | 1,288 |  |  |  | — |  |
| Total adjustments to GAAP operating loss | $ | 16,182 |  |  | $ | 32,608 |  |  | $ | 50,628 |  |  | $ | 102,023 |  |
| Non-GAAP operating income | $ | 13,928 |  |  | $ | 24,387 |  |  | $ | 48,107 |  |  | $ | 67,184 |  |
| Non-GAAP operating income percentage |  | 5.6 | % |  |  | 9.3 | % |  |  | 6.5 | % |  |  | 9.5 | % |

[0001564590-19-014567:8k_2_02:97]
| Non-GAAP Net Income | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| GAAP net loss | $ | (6,932 | ) |  | $ | (13,613 | ) |  | $ | (8,798 | ) |  | $ | (41,160 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 8,814 |  |  |  | 7,818 |  |  |  | 24,339 |  |  |  | 19,646 |  |
| Acquisition and integration costs |  | — |  |  |  | 12,384 |  |  |  | 4,298 |  |  |  | 55,261 |  |
| Restructuring charge, net of reversal |  | — |  |  |  | 4,920 |  |  |  | 1,282 |  |  |  | 4,920 |  |
| Acquired inventory adjustments |  | — |  |  |  | 597 |  |  |  | — |  |  |  | 4,784 |  |
| Litigation |  | — |  |  |  | 207 |  |  |  | — |  |  |  | (158 | ) |
| Amortization of intangibles |  | 6,080 |  |  |  | 6,682 |  |  |  | 19,421 |  |  |  | 17,570 |  |
| Gain on sale of equity investment |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,757 | ) |
| Loss on lease contracts |  | 1,288 |  |  |  | — |  |  |  | 1,288 |  |  |  | — |  |
| Income tax |  | — |  |  |  | — |  |  |  | (7,770 | ) |  |  | (3,102 | ) |
| Total adjustments to GAAP net loss | $ | 16,182 |  |  | $ | 32,608 |  |  | $ | 42,858 |  |  | $ | 95,164 |  |
| Non-GAAP net income | $ | 9,250 |  |  | $ | 18,995 |  |  | $ | 34,060 |  |  | $ | 54,004 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.08 |  |  | $ | 0.16 |  |  | $ | 0.28 |  |  | $ | 0.45 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 120,846 |  |  |  | 120,688 |  |  |  | 120,210 |  |  |  | 119,588 |  |
