# EXTR MD&A — 0001564590-19-018574


## mdna

[0001564590-19-018574:mdna:1]
[same as prior period, unchanged from 0001564590-19-001400:mdna:1]

[0001564590-19-018574:mdna:2]
[same as prior period, unchanged from 0001564590-19-001400:mdna:2]

[0001564590-19-018574:mdna:3]
The following discussion is based upon our unaudited condensed consolidated financial statements included elsewhere in this Report.  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-19-018574:mdna:4]
[same as prior period, unchanged from 0001564590-19-001400:mdna:4]

[0001564590-19-018574:mdna:5]
Extreme delivers software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable autonomous enterprises of the future. Our 100% in-sourced services and support are number one in the industry. Even with over 30,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking.

[0001564590-19-018574:mdna:6]
[same as prior period, unchanged from 0001564590-19-001400:mdna:6]

[0001564590-19-018574:mdna:7]
A trend affecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN and the interest in adopting the next-generation WLAN standard, 802.11ax, in the enterprise market.

[0001564590-19-018574:mdna:8]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended March 31, 2019.

[0001564590-19-018574:mdna:9]
[same as prior period, unchanged from 0001564590-19-001400:mdna:9]

[0001564590-19-018574:mdna:10]
[same as prior period, unchanged from 0001564590-19-001400:mdna:10]

[0001564590-19-018574:mdna:11]
[same as prior period, unchanged from 0001564590-19-001400:mdna:11]

[0001564590-19-018574:mdna:12]
[same as prior period, unchanged from 0001564590-19-001400:mdna:12]

[0001564590-19-018574:mdna:13]
[same as prior period, unchanged from 0001564590-19-001400:mdna:13]

[0001564590-19-018574:mdna:14]
[same as prior period, unchanged from 0001564590-19-001400:mdna:14]

[0001564590-19-018574:mdna:15]
|  | • | Closed-Loop Automation: Enables dynamic, efficient, and software-centric networking by reducing manual intervention to improve network efficiency. |

[0001564590-19-018574:mdna:16]
[same as prior period, unchanged from 0001564590-19-001400:mdna:16]

[0001564590-19-018574:mdna:17]
[same as prior period, unchanged from 0001564590-19-001400:mdna:17]

[0001564590-19-018574:mdna:18]
[same as prior period, unchanged from 0001564590-19-001400:mdna:18]

[0001564590-19-018574:mdna:19]
[same as prior period, unchanged from 0001564590-19-001400:mdna:19]

[0001564590-19-018574:mdna:20]
|  | • | Fabric Attach: Extreme’s Fabric Attach (“FA”) fundamentally introduces autonomic/automatic attachment to network services for end user IoT devices to a network infrastructure. Fabric Attach and Fabric Connect are key building blocks of the Extreme Fabric architecture. |

[0001564590-19-018574:mdna:21]
[same as prior period, unchanged from 0001564590-19-001400:mdna:21]

[0001564590-19-018574:mdna:22]
[same as prior period, unchanged from 0001564590-19-001400:mdna:22]

[0001564590-19-018574:mdna:23]
|  | • | Hybrid Cloud: Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud, and third-party, public cloud services with orchestration between the two platforms. |

[0001564590-19-018574:mdna:24]
[same as prior period, unchanged from 0001564590-19-001400:mdna:23]

[0001564590-19-018574:mdna:25]
|  | • | Layer 3 Data Center Interconnect: A Data Center Interconnect (“DCI”) refers to the networking of two or more different data centers to achieve business or IT objectives. This interconnectivity between separate data centers enables them to work together, share resources and/or pass workloads between one another. A Layer 3 DCI refers to interconnection made through layer 3 of the commonly-referenced multilayered communication model, Open Systems Interconnection. |

[0001564590-19-018574:mdna:26]
[same as prior period, unchanged from 0001564590-19-001400:mdna:25]

[0001564590-19-018574:mdna:27]
31

[0001564590-19-018574:mdna:28]
[same as prior period, unchanged from 0001564590-19-001400:mdna:27]

[0001564590-19-018574:mdna:29]
[same as prior period, unchanged from 0001564590-19-001400:mdna:28]

[0001564590-19-018574:mdna:30]
[same as prior period, unchanged from 0001564590-19-001400:mdna:29]

[0001564590-19-018574:mdna:31]
[same as prior period, unchanged from 0001564590-19-001400:mdna:30]

[0001564590-19-018574:mdna:32]
[same as prior period, unchanged from 0001564590-19-001400:mdna:31]

[0001564590-19-018574:mdna:33]
[same as prior period, unchanged from 0001564590-19-001400:mdna:32]

[0001564590-19-018574:mdna:34]
[same as prior period, unchanged from 0001564590-19-001400:mdna:33]

[0001564590-19-018574:mdna:35]
[same as prior period, unchanged from 0001564590-19-001400:mdna:34]

[0001564590-19-018574:mdna:36]
[same as prior period, unchanged from 0001564590-19-001400:mdna:35]

[0001564590-19-018574:mdna:37]
[same as prior period, unchanged from 0001564590-19-001400:mdna:36]

[0001564590-19-018574:mdna:38]
[same as prior period, unchanged from 0001564590-19-001400:mdna:37]

[0001564590-19-018574:mdna:39]
|  | • | The mobile workforce continues to proliferate. Employees expect high-quality and secure access to corporate resources in a BYOD world across a diversity of endpoints such as laptops, tablets, smart phones and wearables, whether they are within the corporate firewall or on-the-go. With ExtremeManagement Center, IT departments focus their investment decisions on this mobile workforce, taking a unified view of wireless access, from the campus core and the data center. Extreme offers end-to-end solutions that permit IT managers to meet employee expectations and to maximize IT return on investment. |

[0001564590-19-018574:mdna:40]
[same as prior period, unchanged from 0001564590-19-001400:mdna:39]

[0001564590-19-018574:mdna:41]
|  | • | The Internet of Things. The Internet of Things is having dramatic effects on network infrastructure in healthcare, education, manufacturing, government and retail as more “smart” devices are entering the networks. These devices pose opportunities as well as threats to the network. Extreme Defender for IoT delivers security for end points which have limited or even no embedded security capabilities. It is especially targeted to aging wired devices; especially medical devices, that need to roam around a room, a building, or even a campus. |

[0001564590-19-018574:mdna:42]
|  | • | Growing usage of the cloud. Enterprises have migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. Ethernet speeds, scaling from 10 Gigabits per second ("G") to 100G, provide the infrastructure for both private and public clouds. |

[0001564590-19-018574:mdna:43]
[same as prior period, unchanged from 0001564590-19-001400:mdna:71]

[0001564590-19-018574:mdna:44]
[same as prior period, unchanged from 0001564590-19-001400:mdna:43]

[0001564590-19-018574:mdna:45]
[same as prior period, unchanged from 0001564590-19-001400:mdna:44]

[0001564590-19-018574:mdna:46]
[same as prior period, unchanged from 0001564590-19-001400:mdna:45]

[0001564590-19-018574:mdna:47]
|  | ➣ | We announced our Extreme Management Center in Fiscal 2017. This innovative software helps IT network administrators to navigate the unprecedented demands caused by the surge of IoT devices and technology. |

[0001564590-19-018574:mdna:48]
[same as prior period, unchanged from 0001564590-19-001400:mdna:47]

[0001564590-19-018574:mdna:49]
|  | ➣ | We announced cloud offerings in April 2016, and enhanced those offerings in 2017. Extreme began participation in the OpenSwitch program in May 2016, and now participates in the StackStorm community with the acquisition from Brocade in November 2017. |

[0001564590-19-018574:mdna:50]
[same as prior period, unchanged from 0001564590-19-001400:mdna:49]

[0001564590-19-018574:mdna:51]
[same as prior period, unchanged from 0001564590-19-001400:mdna:50]

[0001564590-19-018574:mdna:52]
[same as prior period, unchanged from 0001564590-19-001400:mdna:51]

[0001564590-19-018574:mdna:53]
|  | ➣ | We announced our 802.11ac Wave 2 wireless offering in late 2015, and plans to continue to advance our wireless portfolio of indoor and outdoor access points, supported by the January 2019, announcement of our Wi-Fi 6 (802.11ax) portfolio of access points. |

[0001564590-19-018574:mdna:54]
[same as prior period, unchanged from 0001564590-19-001400:mdna:53]

[0001564590-19-018574:mdna:55]
[same as prior period, unchanged from 0001564590-19-001400:mdna:54]

[0001564590-19-018574:mdna:56]
[same as prior period, unchanged from 0001564590-19-001400:mdna:55]

[0001564590-19-018574:mdna:57]
[same as prior period, unchanged from 0001564590-19-001400:mdna:56]

[0001564590-19-018574:mdna:58]
[same as prior period, unchanged from 0001564590-19-001400:mdna:57]

[0001564590-19-018574:mdna:59]
[same as prior period, unchanged from 0001564590-19-001400:mdna:58]

[0001564590-19-018574:mdna:60]
[same as prior period, unchanged from 0001564590-19-001400:mdna:59]

[0001564590-19-018574:mdna:61]
[same as prior period, unchanged from 0001564590-19-001400:mdna:60]

[0001564590-19-018574:mdna:62]
[same as prior period, unchanged from 0001564590-19-001400:mdna:61]

[0001564590-19-018574:mdna:63]
[same as prior period, unchanged from 0001564590-19-001400:mdna:62]

[0001564590-19-018574:mdna:64]
|  | • | Offer customers choice – cloud or on premises. We leverage cloud where it makes sense for our customers and provide on premise solutions where customers need it. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with one single pane of glass. Our customers can understand what’s going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for BYOD and IoT. |

[0001564590-19-018574:mdna:65]
[same as prior period, unchanged from 0001564590-19-001400:mdna:64]

[0001564590-19-018574:mdna:66]
[same as prior period, unchanged from 0001564590-19-001400:mdna:65]

[0001564590-19-018574:mdna:67]
[same as prior period, unchanged from 0001564590-19-001400:mdna:66]

[0001564590-19-018574:mdna:68]
[same as prior period, unchanged from 0001564590-19-001400:mdna:67]

[0001564590-19-018574:mdna:69]
[same as prior period, unchanged from 0001564590-19-001400:mdna:68]

[0001564590-19-018574:mdna:70]
[same as prior period, unchanged from 0001564590-19-001400:mdna:69]

[0001564590-19-018574:mdna:71]
[same as prior period, unchanged from 0001564590-19-001400:mdna:70]

[0001564590-19-018574:mdna:72]
34

[0001564590-19-018574:mdna:73]
[same as prior period, unchanged from 0001564590-19-001400:mdna:72]

[0001564590-19-018574:mdna:74]
[same as prior period, unchanged from 0001564590-19-001400:mdna:73]

[0001564590-19-018574:mdna:75]
[same as prior period, unchanged from 0001564590-19-001400:mdna:74]

[0001564590-19-018574:mdna:76]
[same as prior period, unchanged from 0001564590-19-001400:mdna:75]

[0001564590-19-018574:mdna:77]
[same as prior period, unchanged from 0001564590-19-001400:mdna:76]

[0001564590-19-018574:mdna:78]
[same as prior period, unchanged from 0001564590-19-001400:mdna:77]

[0001564590-19-018574:mdna:79]
[same as prior period, unchanged from 0001564590-19-001400:mdna:78]

[0001564590-19-018574:mdna:80]
[same as prior period, unchanged from 0001564590-19-001400:mdna:79]

[0001564590-19-018574:mdna:81]
[same as prior period, unchanged from 0001564590-19-001400:mdna:80]

[0001564590-19-018574:mdna:82]
[same as prior period, unchanged from 0001564590-19-001400:mdna:81]

[0001564590-19-018574:mdna:83]
During the third quarter of fiscal 2019, we achieved the following results:

[0001564590-19-018574:mdna:84]
|  | • | Net revenues of $250.9 million compared to $262.0 million in the third quarter of fiscal 2018. |

[0001564590-19-018574:mdna:85]
|  | • | Product revenue of $190.8 million compared to $203.5 million in the third quarter of fiscal 2018. |

[0001564590-19-018574:mdna:86]
|  | • | Service revenue of $60.1 million compared to $58.5 million in the third quarter of fiscal 2018. |

[0001564590-19-018574:mdna:87]
|  | • | Total gross margin of 55.4% of net revenues compared to 54.6% of net revenues in the third quarter of fiscal 2018. |

[0001564590-19-018574:mdna:88]
|  | • | Operating loss of $2.2 million compared to an operating loss of $8.2 million in the third quarter of fiscal 2018. |

[0001564590-19-018574:mdna:89]
|  | • | Net loss of $6.9 million compared to a net loss of $13.6 million in the third quarter of fiscal 2018. |

[0001564590-19-018574:mdna:90]
During the first nine months of fiscal 2019, we achieved the following results:

[0001564590-19-018574:mdna:91]
|  | • | Cash flow provided by operating activities of $79.5 million compared to cash flow used of $1.7 million in the nine months ended March 31, 2018. Cash and marketable securities of $156.8 million compared to $122.6 million as of June 30, 2018. |

[0001564590-19-018574:mdna:92]
[same as prior period, unchanged from 0001564590-19-001400:mdna:92]

[0001564590-19-018574:mdna:93]
[same as prior period, unchanged from 0001564590-19-001400:mdna:93]

[0001564590-19-018574:mdna:94]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | $ Change |  |  | % Change |  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 190,740 |  |  | $ | 203,527 |  |  | $ | (12,787 | ) |  |  | (6.3 | )% |  | $ | 558,027 |  |  | $ | 543,151 |  |  | $ | 14,876 |  |  |  | 2.7 | % |
| Percentage of net revenue |  |  | 76.0 | % |  |  | 77.7 | % |  |  |  |  |  |  |  |  |  |  | 75.1 | % |  |  | 77.1 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 60,124 |  |  |  | 58,477 |  |  |  | 1,647 |  |  |  | 2.8 | % |  |  | 185,403 |  |  |  | 161,691 |  |  |  | 23,712 |  |  |  | 14.7 | % |
| Percentage of net revenue |  |  | 24.0 | % |  |  | 22.3 | % |  |  |  |  |  |  |  |  |  |  | 24.9 | % |  |  | 22.9 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 250,864 |  |  | $ | 262,004 |  |  | $ | (11,140 | ) |  |  | (4.3 | )% |  | $ | 743,430 |  |  | $ | 704,842 |  |  | $ | 38,588 |  |  |  | 5.5 | % |

[0001564590-19-018574:mdna:95]
Product revenue decreased $12.7 million or 6.3% for the three months ended March 31, 2019, as compared to the corresponding period of fiscal 2018. We experienced the largest shortfall in the EMEA region, where we experienced lengthening sales cycles in certain Western European countries. To a lesser extent, we believe certain customers in North America were awaiting greater availability of our WiFi6-based access points that began to ship early in our fourth quarter.

[0001564590-19-018574:mdna:96]
Product revenue increased $14.9 million or 2.7% for the nine months ended March 31, 2019 as compared to the corresponding periods of fiscal 2018. The increase in product revenue for the period was primarily attributable to a full period of sales of the Data Center Business and increased sales in EMEA.

[0001564590-19-018574:mdna:97]
Service revenue increased $1.6 million, or 2.8% for the three months ended March 31, 2019 and increased $23.7 million or 14.7% for the nine months ended March 31, 2019as compared to the corresponding periods of fiscal 2018. The increase in service revenue was driven primarily by a higher number of maintenance contracts related to the Data Center Business acquisition.

[0001564590-19-018574:mdna:98]
[same as prior period, unchanged from 0001564590-19-001400:mdna:97]

[0001564590-19-018574:mdna:99]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | $ Change |  |  | % Change |  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 103,864 |  |  | $ | 109,042 |  |  | $ | (5,178 | ) |  |  | (4.7 | )% |  | $ | 301,121 |  |  | $ | 290,149 |  |  | $ | 10,972 |  |  |  | 3.8 | % |
| Percentage of product revenue |  |  | 54.5 | % |  |  | 53.6 | % |  |  |  |  |  |  |  |  |  |  | 54.0 | % |  |  | 53.4 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 35,055 |  |  |  | 33,941 |  |  |  | 1,114 |  |  |  | 3.3 | % |  |  | 111,168 |  |  |  | 94,201 |  |  |  | 16,967 |  |  |  | 18.0 | % |
| Percentage of service revenue |  |  | 58.3 | % |  |  | 58.0 | % |  |  |  |  |  |  |  |  |  |  | 60.0 | % |  |  | 58.3 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 138,919 |  |  | $ | 142,983 |  |  | $ | (4,064 | ) |  |  | (2.8 | )% |  | $ | 412,289 |  |  | $ | 384,350 |  |  | $ | 27,939 |  |  |  | 7.3 | % |
| Percentage of net revenues |  |  | 55.4 | % |  |  | 54.6 | % |  |  |  |  |  |  |  |  |  |  | 55.5 | % |  |  | 54.5 | % |  |  |  |  |  |  |  |  |

[0001564590-19-018574:mdna:100]
Product gross profit decrease $5.2 million or 4.7% for the three months ended March 31, 2019, as compared to the corresponding period in fiscal 2018. The decrease in product gross profit were primarily due to lower revenue levels, increased distribution costs of $2.8 million, warranty charges of $1.6 million and excess and obsolete charges of $1.5 million. These increases were partially offset by decreased integration costs from acquisitions of $3.1 million and lower production costs.

[0001564590-19-018574:mdna:101]
Product gross profit increased $11.0 million or 3.8% for the nine months ended March 31, 2019 as compared to the corresponding period in fiscal 2018.  The increase in product gross profit was primarily due to higher revenue levels and lower production costs as well as decreased integration costs from acquisitions of $5.8 million. This was offset by higher distribution costs of $9.0 million, warranty charges of $5.6 million, amortization of developed technology intangibles due to the acquisition of the Campus Fabric and Data Center Businesses of $3.4 million and additional operations costs of $3.9 million mainly driven by higher personnel costs due to additional headcount.

[0001564590-19-018574:mdna:102]
Service gross profit increased $1.1 million and $17.0 million or 3.3% and 18.0% for the three and nine months ended March 31, 2019, respectively, as compared to the corresponding periods in fiscal 2018.  The increases were primarily due to a higher number of maintenance contracts related to the acquisition of the Data Center Business, partially offset by higher service material costs and personnel costs due to increased headcount to support acquired contracts.

[0001564590-19-018574:mdna:103]
[same as prior period, unchanged from 0001564590-19-001400:mdna:102]

[0001564590-19-018574:mdna:104]
[same as prior period, unchanged from 0001564590-19-001400:mdna:103]

[0001564590-19-018574:mdna:105]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | $ Change |  |  | % Change |  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 52,081 |  |  | $ | 50,920 |  |  | $ | 1,161 |  |  |  | 2.3 | % |  | $ | 155,526 |  |  | $ | 131,112 |  |  | $ | 24,414 |  |  |  | 18.6 | % |
| Sales and marketing |  |  | 72,321 |  |  |  | 72,240 |  |  |  | 81 |  |  |  | 0.1 | % |  |  | 208,245 |  |  |  | 193,460 |  |  |  | 14,785 |  |  |  | 7.6 | % |
| General and administrative |  |  | 15,479 |  |  |  | 11,707 |  |  |  | 3,772 |  |  |  | 32.2 | % |  |  | 42,136 |  |  |  | 35,561 |  |  |  | 6,575 |  |  |  | 18.5 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | — |  |  |  | 9,316 |  |  |  | (9,316 | ) |  |  | (100.0 | )% |  |  | 2,613 |  |  |  | 47,675 |  |  |  | (45,062 | ) |  |  | (94.5 | )% |
| Restructuring charges, net of reversals |  |  | — |  |  |  | 4,920 |  |  |  | (4,920 | ) |  |  | (100.0 | )% |  |  | 1,282 |  |  |  | 4,920 |  |  |  | (3,638 | ) |  |  | (73.9 | )% |
| Amortization of intangibles |  |  | 1,292 |  |  |  | 2,101 |  |  |  | (809 | ) |  |  | (38.5 | )% |  |  | 5,008 |  |  |  | 6,461 |  |  |  | (1,453 | ) |  |  | (22.5 | )% |
| Total operating expenses |  | $ | 141,173 |  |  | $ | 151,204 |  |  | $ | (10,031 | ) |  |  | (6.6 | )% |  | $ | 414,810 |  |  | $ | 419,189 |  |  | $ | (4,379 | ) |  |  | (1.0 | )% |

[0001564590-19-018574:mdna:106]
[same as prior period, unchanged from 0001564590-19-001400:mdna:105]

[0001564590-19-018574:mdna:107]
[same as prior period, unchanged from 0001564590-19-001400:mdna:106]

[0001564590-19-018574:mdna:108]
Research and development expenses increased by $1.2 million or 2.3% for the three months ended March 31, 2019, as compared to the corresponding period of fiscal 2018.  The increased in research and development expenses was due to $3.5 million increase related to third-party design and engineering collaboration charges and $0.7 million in increased facility and information technology costs.  The quarterly expenses were partially offset by a $2.2 million reduction in personnel costs primarily due to a reduction in contractor fees and a $0.8 million reduction in supplies and equipment costs.

[0001564590-19-018574:mdna:109]
Research and development expenses increased by $24.4 million or 18.6% for the nine months ended March 31, 2019, as compared to the corresponding period of fiscal 2018.  The increase in research and development expenses was due to $10.5 million related to third-party design and engineering collaboration charges, an $8.0 million increase in personnel costs associated with the acquisition of the Data Center Business, $4.9 million in increased facility and information technology costs and $1.0 million in increased supplies and equipment costs.

[0001564590-19-018574:mdna:110]
[same as prior period, unchanged from 0001564590-19-001400:mdna:109]

[0001564590-19-018574:mdna:111]
[same as prior period, unchanged from 0001564590-19-001400:mdna:110]

[0001564590-19-018574:mdna:112]
Sales and marketing expenses increased by $0.1 million or 0.1% for the three months ended March 31, 2019, as compared to the corresponding period of fiscal 2018, primarily due to $0.4 million of increased software, supplies and equipment costs and $0.3 million of increased in travel, marketing, meeting and conference costs, partially offset by a $0.6 million reduction in personnel costs.

[0001564590-19-018574:mdna:113]
Sales and marketing expenses increased by $14.8 million or 7.6% for the nine months ended March 31, 2019, as compared to the corresponding period of fiscal 2018, primarily as a result of the acquisition of the Data Center Business.  The increase consisted of higher personnel costs of $11.4 million, $2.5 million in increased software, supplies and equipment costs, $0.4 million in increased travel, marketing, meeting and conference costs and $0.5 million in increased professional fees.

[0001564590-19-018574:mdna:114]
[same as prior period, unchanged from 0001564590-19-001400:mdna:113]

[0001564590-19-018574:mdna:115]
[same as prior period, unchanged from 0001564590-19-001400:mdna:114]

[0001564590-19-018574:mdna:116]
General and administrative expenses increased by $3.8 million or 32.2% for the three months ended March 31, 2019, as compared to the corresponding period of fiscal 2018, primarily due to $0.8 million in higher facility and information technology costs, a $1.3 million charge for lease termination costs, a $0.5 million charge for a litigation settlement, a $0.3 million increase in the bad debt provision and $0.2 million in higher personnel costs and other costs. Additionally, in the three months ended March 31, 2018 we recorded a $1.3 million credit to expense related to a change in the fair value of a contingent consideration obligation which did not repeat in the current period.  Increases in general and administrative expenses were partially offset by a $0.7 million reduction in professional fees.

[0001564590-19-018574:mdna:117]
37

[0001564590-19-018574:mdna:118]
General and administrative expenses increased by $6.6 million or 18.5% for nine months ended March 31, 2019, as compared to the corresponding period of fiscal 2018, primarily due to $2.1 million in higher personnel costs, $1.7 million in higher facility and information technology costs, a $0.5 million charge for a litigation settlement, a $1.3 million increase in lease termination costs, and a $0.6 million increase in the bad debt provision and other costs partially offset by a $1.0 million reduction in professional fees. Additionally, in the nine months ended March 31, 2018, we recorded a $1.3 million credit to expense related to a change in the fair value of a contingent consideration obligation which did not repeat in the current period.

[0001564590-19-018574:mdna:119]
[same as prior period, unchanged from 0001564590-19-001400:mdna:117]

[0001564590-19-018574:mdna:120]
During the three and nine months ended March 31, 2019, we incurred zero and $2.6 million, respectively, of operating integration costs related to the acquisitions of the Campus Fabric and Data Center Businesses.

[0001564590-19-018574:mdna:121]
For the three months ended March 31, 2018, we incurred $3.1 million of acquisition and $1.3 million of integration costs related to the acquisition of the Campus Fabric Business and $3.5 million of acquisition and $1.5 million of integration costs related to the acquisition of the Data Center Business.

[0001564590-19-018574:mdna:122]
For the nine months ended March 31, 2018, we incurred $9.0 million of acquisition and $4.9 million of integration costs related to the acquisition of the Campus Fabric Business and $35.1 million of acquisition and $3.7 million of integration costs related to the acquisition of the Data Center Business. The Data Center Business acquisition costs includes a $25.0 million consent fee paid to Broadcom, to terminate a previous asset purchase agreement we entered into to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow us to buy the Data Center Business directly from Brocade. We also recorded a gain on bargain purchase of $5.0 million related to the acquisition of the Capital Financing business.

[0001564590-19-018574:mdna:123]
[same as prior period, unchanged from 0001564590-19-001400:mdna:121]

[0001564590-19-018574:mdna:124]
For the three months ended March 31, 2019 we did not record any restructuring charges. For the nine months ended March 31, 2019, we recorded restructuring charges of $1.3 million, associated with a reduction-in-force announced in the fourth quarter of fiscal 2018 and additional excess facility charges. For the three and nine months ended March 31, 2018, we recorded restructuring charges of $4.9 million related to a reduction in force.  The charges consisted of employee severance and benefits expenses.

[0001564590-19-018574:mdna:125]
[same as prior period, unchanged from 0001564590-19-001400:mdna:123]

[0001564590-19-018574:mdna:126]
During the three months ended March 31, 2019 and 2018, we recorded $1.3 million and $2.1 million, respectively, of amortization expense as operating expenses and in the accompanying condensed consolidated statements of operations.  The decrease was mainly due to amortization related to the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-19-018574:mdna:127]
During the nine months ended March 31, 2019 and 2018, we recorded $5.0 million and $6.5 million, respectively, of amortization expense as operating expenses in the accompanying condensed consolidated statements of operations.  The decrease was mainly due to amortization related to the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-19-018574:mdna:128]
[same as prior period, unchanged from 0001564590-19-001400:mdna:126]

[0001564590-19-018574:mdna:129]
During the three months ended March 31, 2019 and 2018, we recorded $3.0 million and $4.0 million, respectively, in interest expense.  The decrease in interest expense was due to imputed interest charges associated with various long-term contracts.

[0001564590-19-018574:mdna:130]
During the nine months ended March 31, 2019 and 2018, we recorded $9.6 million and $8.8 million, respectively, in interest expense.  The increase in interest expense was due to higher outstanding loan balances and other charges on of our Credit Agreement as compared to the corresponding period of fiscal 2018, partially offset by lower imputed interest charges associated with various long-term contracts.

[0001564590-19-018574:mdna:131]
[same as prior period, unchanged from 0001564590-19-001400:mdna:129]

[0001564590-19-018574:mdna:132]
During the three months ended March 31, 2019 and 2018, we recorded expense of $0.4 million and $0.4 million, respectively, in other income (expense), net. The expense for the three months ended March 31, 2019 was primarily due to losses on equity investments.  The expense for the three months ended March 31, 2018 was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-19-018574:mdna:133]
During the nine months ended March 31, 2019 and 2018, we recorded expense of $0.3 million and income of $2.1 million, respectively, in other income (expense), net.  For fiscal 2019, the loss was primarily due to losses on equity investments, partially offset by net foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.  For fiscal 2018, other income (expense), net was primarily driven by a gain of $3.8 million related to the sale of a non-marketable equity investment, partially offset by foreign exchange losses.

[0001564590-19-018574:mdna:134]
[same as prior period, unchanged from 0001564590-19-001400:mdna:132]

[0001564590-19-018574:mdna:135]
For the three months ended March 31, 2019 and 2018, we recorded an income tax benefit of $1.9 million and $1.7 million, respectively. For the nine months ended March 31, 2019, and 2018, we recorded a tax benefit of $2.0 million and a tax provision of $1.8 million, respectively.

[0001564590-19-018574:mdna:136]
The income tax provisions for the three months ended March 31, 2019, and 2018, consisted of (1) taxes on the income of our foreign subsidiaries, (2) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business the Data Center Business, (3) foreign withholding taxes and (4) state taxes in jurisdictions where we have no available state Net Operating Losses (“NOLs”).

[0001564590-19-018574:mdna:137]
The income tax provisions for the nine months ended March 31, 2019, and 2018 consisted of the components detailed above.  Additionally, the tax provision for the nine months ended March 31, 2019, is offset by a tax benefit of $2.6 million resulting from the release of a valuation allowance for our Australian NOLs given consistent and sufficient profitability following the recent acquisitions as well as a tax benefit of $4.7 million for the release of valuation allowance given changes introduced by recently enacted U.S. tax legislation as discussed below.  This legislation changed the U.S. NOL rules to afford an indefinite carryforward period for NOLs generated in tax years beginning after December 31, 2017.  In evaluating the realizability of Deferred Tax Assets (“DTAs”), historically we were unable to consider the Deferred Tax Liability (“DTL”) related to amortizable goodwill as a source of future income for reversing deductible differences with fixed lives.  The change to the NOL rules creates an indefinite lived DTA and as such the indefinite lived DTL related to goodwill can now be viewed as a source of income for the newly created indefinite lived DTA.  These two indefinite lived items can now be netted in determining the amount of valuation allowance needed.

[0001564590-19-018574:mdna:138]
The tax provision for the nine months ended March 31, 2018, is offset by a tax benefit of $2.5 million resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to our deferred tax liability related to amortizable goodwill as required by the U.S. tax legislation discussed below. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended March 31, 2019, and 2018, respectively and therefore may not reflect the annual effective tax rate.

[0001564590-19-018574:mdna:139]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, was effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, we were not subject to the majority of the tax law provisions until fiscal year 2019; however, there were certain significant items of impact that were recognized in fiscal year 2018.  Because a change in tax law is accounted for in the period of enactment, the effects of the TCJA, a tax benefit of $2.5 million, was reflected in the second quarter of fiscal 2018. An additional impact was reflected in the second quarter of fiscal year 2019, in the amount of $4.7 million relating to a valuation allowance release in conjunction with the finalization of evaluating the impacts of the TCJA change pursuant to SAB 118. See Note 15 to the condensed consolidated financial statements which includes a detailed discussion of the various provisions of the new U.S. tax legislation.

[0001564590-19-018574:mdna:140]
[same as prior period, unchanged from 0001564590-19-001400:mdna:137]

[0001564590-19-018574:mdna:141]
[same as prior period, unchanged from 0001564590-19-001400:mdna:138]

[0001564590-19-018574:mdna:142]
[same as prior period, unchanged from 0001564590-19-001400:mdna:139]

[0001564590-19-018574:mdna:143]
[same as prior period, unchanged from 0001564590-19-001400:mdna:140]

[0001564590-19-018574:mdna:144]
[same as prior period, unchanged from 0001564590-19-001400:mdna:141]

[0001564590-19-018574:mdna:145]
[same as prior period, unchanged from 0001564590-19-001400:mdna:142]

[0001564590-19-018574:mdna:146]
[same as prior period, unchanged from 0001564590-19-001400:mdna:143]

[0001564590-19-018574:mdna:147]
[same as prior period, unchanged from 0001564590-19-001400:mdna:144]

[0001564590-19-018574:mdna:148]
[same as prior period, unchanged from 0001564590-19-001400:mdna:145]

[0001564590-19-018574:mdna:149]
[same as prior period, unchanged from 0001564590-19-001400:mdna:146]

[0001564590-19-018574:mdna:150]
The following summarizes information regarding our cash, marketable securities and working capital (in thousands):

[0001564590-19-018574:mdna:151]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Cash |  | $ | 156,813 |  |  | $ | 121,139 |  |
| Marketable securities |  |  | 262 |  |  |  | 1,459 |  |
| Total cash and marketable securities |  | $ | 157,075 |  |  | $ | 122,598 |  |
| Working capital |  | $ | 87,850 |  |  | $ | 68,041 |  |

[0001564590-19-018574:mdna:152]
As of March 31, 2019, our principal sources of liquidity consisted of cash and marketable securities of $157.1 million, accounts receivable, net of $141.5 million and availability of borrowings from our five-year New Revolving Facility of $35.5 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, stock repurchase program and repayments of debt and related interest. We believe that our $157.1 million of cash and marketable securities at March 31, 2019 and the availability of borrowings from the New Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-19-018574:mdna:153]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in the second quarter of fiscal 2019.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended March 31, 2019, we did not repurchase any shares. During the nine months ended March 31, 2019, we repurchased 2.4 million shares at an aggregate cost of $15.0 million.

[0001564590-19-018574:mdna:154]
On May 1, 2018, we entered into a Credit Agreement (the “Credit Agreement”), BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”), ii) a $190 million five-year term loan (the “New Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, we borrowed $200 million under the Credit Agreement.

[0001564590-19-018574:mdna:155]
[same as prior period, unchanged from 0001564590-19-001400:mdna:152]

[0001564590-19-018574:mdna:156]
Financial covenants under the Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.  At March 31, 2019, we were in compliance with the covenants of the Credit Agreement.

[0001564590-19-018574:mdna:157]
[same as prior period, unchanged from 0001564590-19-001400:mdna:154]

[0001564590-19-018574:mdna:158]
[same as prior period, unchanged from 0001564590-19-001400:mdna:155]

[0001564590-19-018574:mdna:159]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Net cash provided by (used in) operating activities |  | $ | 79,502 |  |  | $ | (1,730 | ) |
| Net cash used in investing activities |  |  | (15,454 | ) |  |  | (114,658 | ) |
| Net cash (used in) provided by financing activities |  |  | (28,178 | ) |  |  | 89,214 |  |
| Foreign currency effect on cash |  |  | (196 | ) |  |  | (99 | ) |
| Net increase (decrease) in cash |  | $ | 35,674 |  |  | $ | (27,273 | ) |

[0001564590-19-018574:mdna:160]
Net Cash Provided by (Used in) Operating Activities

[0001564590-19-018574:mdna:161]
Cash flows provided by operations in the nine months ended March 31, 2019, were $79.5 million, including our net loss of $8.8 million and non-cash expenses of $61.8 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes and imputed interest.  Other sources of cash for the current quarter included a decrease in accounts receivables, and inventories and increases in deferred revenues. This was partially offset by decreases in accounts payable, accrued compensation and other current and long-term liabilities, and increases in prepaid expenses and other current assets.

[0001564590-19-018574:mdna:162]
Cash flows used in operations in the nine months ended March 31, 2018, were $1.7 million, including our net loss of $41.2 million and non-cash expenses of $46.2 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes, gain on bargain purchase and gain on sale of non-marketable equity investment as well as increases in accounts receivables, prepaid expenses and decreases in accrued compensation and benefits. This was partially offset by a decrease in inventories and increases in accounts payable, deferred revenue and other current and long-term liabilities.

[0001564590-19-018574:mdna:163]
[same as prior period, unchanged from 0001564590-19-001400:mdna:160]

[0001564590-19-018574:mdna:164]
Cash flows used in investing activities in the nine months ended March 31, 2019 were $15.5 million which consisted of purchases of property and equipment of $16.2 million partially offset by proceeds of $0.7 million related to the sale of investments.

[0001564590-19-018574:mdna:165]
Cash flows used in investing activities in the nine months ended March 31, 2018, were $114.7 million which consisted of expenditures for acquisitions of $97.6 million including $69.6 million for the acquisition of the Campus Fabric Business and $29.5 million for the acquisition of the Data Center Business, less receipt of $1.6 million as final settlement of a working capital adjustment related to the WLAN Business acquisition, purchases of property and equipment of $22.0 million and proceeds of $4.9 million related to the sale of a non-marketable equity investment.

[0001564590-19-018574:mdna:166]
Net Cash Provided by (Used in) Financing Activities

[0001564590-19-018574:mdna:167]
Cash flows used in financing activities in the nine months ended March 31, 2019 were $28.2 million consisting of repayments of debt totaling $17.4 million, contingent consideration of $5.3 million, and $3.0 million for deferred payments on acquisitions.  This was partially offset by $13.0 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”), the exercise of stock options and net of taxes paid on vested and released stock awards.

[0001564590-19-018574:mdna:168]
Cash flows used in financing activities for the period also included repurchasing of our common shares valued at $15.0 million during the nine months ended March 31, 2019, in accordance with our approved share repurchase plan. The share repurchases were executed through open market purchases, and future share repurchases may be completed through the combination of individually negotiated transactions, accelerated share buyback, and/or open market purchases. As of March 31, 2019, we have $45.0 million available under our share repurchase plan. Our Credit Facility does not contain any restrictions on the amount of borrowings that can be used to make share repurchases, as long as we are in compliance with our financial and non-financial covenants.

[0001564590-19-018574:mdna:169]
Cash flows provided by financing activities in the nine months ended March 31, 2018 were $89.2 million, including new borrowings of $100.0 million to fund our acquisitions of the Campus Fabric Business and the Data Center Business, $4.7 million proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, partially offset by repayments of debt totaling $13.3 million and $1.5 million of loan fees incurred in connection with the Second Amendment of our Credit Facility.

[0001564590-19-018574:mdna:170]
[same as prior period, unchanged from 0001564590-19-001400:mdna:167]

[0001564590-19-018574:mdna:171]
Foreign currency effect on cash decreased in the nine months ended March 31, 2019 and 2018, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, Indian Rupee and the EURO.

[0001564590-19-018574:mdna:172]
[same as prior period, unchanged from 0001564590-19-001400:mdna:169]

[0001564590-19-018574:mdna:173]
The following summarizes our contractual obligations as of March 31, 2019, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-19-018574:mdna:174]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 182,875 |  |  | $ | 9,500 |  |  | $ | 27,313 |  |  | $ | 146,062 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 28,850 |  |  |  | 8,783 |  |  |  | 15,883 |  |  |  | 4,184 |  |  |  | — |  |
| Inventory purchase commitments |  |  | 194,858 |  |  |  | 194,858 |  |  |  | — |  |  |  | — |  |  |  |  |  |
| Contractual commitments |  |  | 99,875 |  |  |  | 23,500 |  |  |  | 47,000 |  |  |  | 29,375 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 104,942 |  |  |  | 22,401 |  |  |  | 40,311 |  |  |  | 25,990 |  |  |  | 16,240 |  |
| Deferred payments for an acquisition |  |  | 16,000 |  |  |  | 4,000 |  |  |  | 8,000 |  |  |  | 4,000 |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 7,469 |  |  |  | 4,514 |  |  |  | 2,458 |  |  |  | 497 |  |  |  |  |  |
| Other liabilities |  |  | 410 |  |  |  | 124 |  |  |  | 249 |  |  |  | 37 |  |  |  |  |  |
| Total contractual cash obligations |  | $ | 635,279 |  |  | $ | 267,680 |  |  | $ | 141,214 |  |  | $ | 210,145 |  |  | $ | 16,240 |  |

[0001564590-19-018574:mdna:175]
[same as prior period, unchanged from 0001564590-19-001400:mdna:172]

[0001564590-19-018574:mdna:176]
[same as prior period, unchanged from 0001564590-19-001400:mdna:173]

[0001564590-19-018574:mdna:177]
[same as prior period, unchanged from 0001564590-19-001400:mdna:174]

[0001564590-19-018574:mdna:178]
[same as prior period, unchanged from 0001564590-19-001400:mdna:175]

[0001564590-19-018574:mdna:179]
[same as prior period, unchanged from 0001564590-19-001400:mdna:176]

[0001564590-19-018574:mdna:180]
[same as prior period, unchanged from 0001564590-19-001400:mdna:177]

[0001564590-19-018574:mdna:181]
[same as prior period, unchanged from 0001564590-19-001400:mdna:178]

[0001564590-19-018574:mdna:182]
[same as prior period, unchanged from 0001564590-19-001400:mdna:179]

[0001564590-19-018574:mdna:183]
[same as prior period, unchanged from 0001564590-19-001400:mdna:180]

[0001564590-19-018574:mdna:184]
We did not have any material commitments for capital expenditures as of March 31, 2019.

[0001564590-19-018574:mdna:185]
[same as prior period, unchanged from 0001564590-19-001400:mdna:182]

[0001564590-19-018574:mdna:186]
We did not have any off-balance sheet arrangements as of March 31, 2019.
