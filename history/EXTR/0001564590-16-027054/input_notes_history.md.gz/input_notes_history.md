# EXTR note change history — 0001564590-16-017216 → 0001564590-16-027054


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-02):
[0001564590-16-027054:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2016, the Company had non-cancelable commitments to purchase $70.6 million of such inventory.
  (was, 2016-04-29, similarity 0.8736):
[0001564590-16-017216:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2016, the Company had non-cancelable commitments to purchase $$68.5 million of such inventory.

- changed (2016-11-02):
[0001564590-16-027054:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2016-04-29, similarity 0.8403):
[0001564590-16-017216:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for the proceedings listed below, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  Based on its own investigations, the Company believes the ultimate outcome of any current legal proceedings, individually and in the aggregate, will not have a material adverse effect on its financial position, results of operation or cash flows. However, because of the nature and inherent uncertainties of the litigation, should the outcome of such actions be unfavorable, the Company's business, financial condition, results of operations or cash flows could be materially and adversely affected.

- changed (2016-11-02):
[0001564590-16-027054:note_history:3]
Brazilian Tax Assessment Matters                                                                                                                                                   Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of September 30, 2016.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.1 million), plus interest and penalties BRL 17.5 million (US $5.4 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.
  (was, 2016-04-29, similarity 0.9605):
[0001564590-16-017216:note_history:3]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BR 3.4 million (US $0.9 million), plus interest and penalties BR 16.6 million (US $4.6 million).  Possible court fees are estimated to be BR 4.0 million (US $1.1 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

- changed (2016-11-02):
[0001564590-16-027054:note_history:4]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL 25.1 million (US $7.8 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $2.9 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.
  (was, 2016-04-29, similarity 0.9991):
[0001564590-16-017216:note_history:4]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BR 23.4 million (US $6.4 million).  The Company does not expect a final judicial determination for several years.  The Company believes BR 9.4 million (US $2.6 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

- changed (2016-11-02):
[0001564590-16-027054:note_history:5]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint, which the defendants will move to dismiss.  The Company believes the claims are without merit and intends to vigorously defend the claims.
  (was, 2016-04-29, similarity 0.7639):
[0001564590-16-017216:note_history:5]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its current or former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from November 4, 2013 through April 9, 2015.  Motions for appointment of lead plaintiff have been filed, and are scheduled to be heard on May 5, 2016.  The Company believes the claims are without merit and intends to vigorously defend the claims.

- changed (2016-11-02):
[0001564590-16-027054:note_history:6]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and have submitted a stipulation to that effect to the court.
  (was, 2016-04-29, similarity 0.9948):
[0001564590-16-017216:note_history:6]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County.  Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and\ or members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and have submitted a stipulation to that effect to the court.

- added (2016-11-02):
[0001564590-16-027054:note_history:7]
Dunti Network Technoligies, LLC v Extreme Networks, Inc. Patent Infringement Suit

- added (2016-11-02):
[0001564590-16-027054:note_history:8]
On September 22, 2016, the Company was served with a patent infringement complaint by Dunti Network Technologies, LLC in the U.S. District Court for the Eastern District of Texas.  The case is Dunti Network Technologies, LLC v. Extreme Networks, Inc., No. 2:16-cv-01034.  The complaint asserts infringement of U.S. Patent Nos. 6,587,462, 6,788,701, 6,804,235, 6,643,286, and 7,778,259.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s BlackDiamond-X, Summit X670, and Summit X770 series switches.  Dunti seeks damages of an unspecified amount.  The Company’s answer to the complaint is presently due November 14, 2016.  The Company believes the claims are without merit and intends to defend itself vigorously against the claims.

- changed (2016-11-02):
[0001564590-16-027054:note_history:9]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of September 30, 2016, the Company had no outstanding indemnification claims.
  (was, 2016-04-29, similarity 0.9934):
[0001564590-16-017216:note_history:9]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain.  As of March 31, 2016, the Company had no outstanding indemnification claims.

- removed (2016-11-02):
[0001564590-16-017216:note_history:10]
Brazilian Tax Assessment Matters


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-02):
[0001564590-16-027054:note_history:11]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.
  (was, 2016-04-29, similarity 0.6006):
[0001564590-16-017216:note_history:11]
Extreme Networks, Inc. (“Extreme Networks” or the “Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.

- changed (2016-11-02):
[0001564590-16-027054:note_history:12]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2016 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2016.
  (was, 2016-04-29, similarity 0.995):
[0001564590-16-017216:note_history:12]
The unaudited condensed consolidated financial statements of Extreme Networks included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2015 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2015.

- changed (2016-11-02):
[0001564590-16-027054:note_history:13]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2016  The results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.
  (was, 2016-04-29, similarity 0.6706):
[0001564590-16-017216:note_history:13]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2016  The results of operations for the three and nine months ended March 31, 2016 are not necessarily indicative of the results that may be expected for fiscal 2016 or any future periods.

- changed (2016-11-02):
[0001564590-16-027054:note_history:14]
The Company uses a fiscal calendar year ending on June 30.  All references herein to "fiscal 2017" or "2017" represent the fiscal year ending June 30, 2017.  All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.
  (was, 2016-04-29, similarity 0.7684):
[0001564590-16-017216:note_history:14]
The Company uses a fiscal calendar year ending on June 30.  All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.

- changed (2016-11-02):
[0001564590-16-027054:note_history:15]
The consolidated financial statements include the accounts of Extreme and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.
  (was, 2016-04-29, similarity 0.9742):
[0001564590-16-017216:note_history:15]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries.  All inter-company accounts and transactions have been eliminated.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-02):
[0001564590-16-027054:note_history:16]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,269 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 19,269 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,621 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 32,621 |  |  |  | 37,446 |  |
| Total debt |  | $ | 51,890 |  |  | $ | 55,074 |  |
  (was, 2016-04-29, similarity 0.9839):
[0001564590-16-017216:note_history:16]
|  |  | March 31, 2016 |  |  | June 30, 2015 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 16,250 |  |  | $ | 11,375 |  |
| Current portion of long-term debt |  | $ | 16,250 |  |  | $ | 11,375 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 32,500 |  |  | $ | 45,500 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 42,500 |  |  |  | 55,500 |  |
| Total debt |  | $ | 58,750 |  |  | $ | 66,875 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-11-02):
[0001564590-16-027054:note_history:17]
13.Subsequent Events

- added (2016-11-02):
[0001564590-16-027054:note_history:18]
On September 13, 2016, the Company entered into an Asset Purchase Agreement (the “Purchase”) with Zebra Technologies Corporation, a Delaware corporation (“Zebra”), to purchase Zebra’s wireless LAN business (the “Business”).  Under the terms of the Purchase, the Company acquired customers, employees, technology and other assets of the Business, as well as assumed certain contracts and other liabilities of the Business, for a cash purchase price of approximately $55.0 million, subject to certain adjustments related to net working capital and deferred revenue of the Business on October 28, 2016 (the “Closing”).  Pursuant to certain ancillary agreements, Zebra will also provide the Company with access to certain technology related to the Business, as well as transition services for a period of time following the Closing.

- added (2016-11-02):
[0001564590-16-027054:note_history:19]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Business will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Business will be included in the operations of the Company beginning with the Closing.

- added (2016-11-02):
[0001564590-16-027054:note_history:20]
The Company expects to include a preliminary determination of the acquisition consideration and detail of the assets acquired and liabilities assumed in the Company’s consolidated financial statements for the quarter ending December 31, 2016.

- added (2016-11-02):
[0001564590-16-027054:note_history:21]
During the three months ended September 30, 2016, the Company recognized transaction costs of $2.3 million which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

- added (2016-11-02):
[0001564590-16-027054:note_history:22]
Borrowing Facility

- added (2016-11-02):
[0001564590-16-027054:note_history:23]
Commensurate with the Closing, the Company entered into an Amended and Restated Credit Agreement (the “Credit Agreement”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Agreement provides for a five-year $90.5 million term loan and a five-year $50.0 million revolving credit facility, which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Agreement among other things, amends and restates the Company’s existing credit facility.  At the Closing, the Company incurred $100.5 million of indebtedness to pay off existing debt and to finance the acquisition of the Business.  Borrowings under the term loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on our consolidated leverage ratio).  Borrowings under the revolving credit facility bear interest, at the Company’s option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the prime lending rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The revolving credit facility has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.  The Credit Agreement is collateralized by substantially all assets of the Company.
