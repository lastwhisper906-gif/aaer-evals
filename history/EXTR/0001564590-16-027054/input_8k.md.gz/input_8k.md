# EXTR 8-K — 0001564590-16-026732 filed 2016-11-01

## item codes, every 8-K on or before 2016-11-02

- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2016-11-02

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-16-026732:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-16-026732:8k_2_02:2]
extr-ex991_6.htm

[0001564590-16-026732:8k_2_02:3]
Exhibit 99.1

[0001564590-16-026732:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-16-026732:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Frank Yoshino |  | Media Contact Ben Haber |
| 408/579-3456 |  | 617/624-3200 |
| fyoshino@extremenetworks.com |  | ExtremeUS@racepointglobal.com |

[0001564590-16-026732:8k_2_02:6]
Extreme Networks Reports First Quarter Fiscal Year 2017 Financial Results

[0001564590-16-026732:8k_2_02:7]
Q1 GAAP Revenue of $122.6 Million & Non-GAAP Revenue of $122.8 Million

[0001564590-16-026732:8k_2_02:8]
Q1 GAAP Loss Per Share of $0.06 & Non-GAAP Earnings Per Share of $0.07

[0001564590-16-026732:8k_2_02:9]
SAN JOSE, Calif., November 1, 2016 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal first quarter ended September 30, 2016.  First quarter GAAP revenue was $122.6 million and non-GAAP revenue was $122.8 million.  GAAP net loss for the first fiscal quarter was $6.5 million, or $0.06 per basic share, and non-GAAP net income was $7.1 million, or $0.07 per diluted share.

[0001564590-16-026732:8k_2_02:10]
“We are pleased to see the positive impacts of our margin initiatives in our first quarter financial results.  Our non-GAAP operating income is up 18% year over year and our product gross margins increased by 200 basis points both annually and sequentially highlighting the progress we are making,” stated Ed Meyercord, President and CEO of Extreme Networks.  “Revenue in the quarter was impacted by a more disciplined approach to our discounting policies and softness in E-Rate.”

[0001564590-16-026732:8k_2_02:11]
“With the recently completed acquisition of the WLAN business from Zebra Technologies Corporation, we have new growth opportunities across existing and new markets.  We are excited to bring Zebra’s talented employees, advanced technology portfolio and blue chip customers into Extreme,” Meyercord added.

[0001564590-16-026732:8k_2_02:12]
Recent Key Events:

[0001564590-16-026732:8k_2_02:13]
|  | • | Growth with Close of Zebra WLAN Business. |

[0001564590-16-026732:8k_2_02:14]
|  | o | Establishes Extreme as #3 in WLAN in targeted enterprise verticals. |

[0001564590-16-026732:8k_2_02:15]
|  | o | Expanded offering and network refresh opportunities with Zebra's large-scale, multi-location distributed enterprise customers such as Walmart, Kroger, FedEx and Loews. |

[0001564590-16-026732:8k_2_02:16]
|  | o | New technology offerings to Extreme customers including Zebra's Wing operating system; the industry leading wireless security offering - Air Defense; guest management platform and location based services; and new in-house managed services capabilities. |

[0001564590-16-026732:8k_2_02:17]
|  | • | Extreme New Product Introductions. Introduced the industry’s first Wave 2 Integrated Camera Access Point, White Label Cloud Management Solutions for partner enablement, Wall Plate Wireless AP and expanded Industrial switch portfolio. |

[0001564590-16-026732:8k_2_02:18]
|  | • | Industry Recognition as "Visionary" and "Champion". For the second consecutive year, Extreme is positioned the furthest to the right by Gartner, Inc. in the "Visionaries" quadrant in the Magic Quadrant for Wired and Wireless LAN Access Infrastructure. In addition, Gartner rated Extreme the third highest score of 16 vendors in the annual Critical Capabilities for Wired and |

[0001564590-16-026732:8k_2_02:19]
|  |  | Wireless Access LAN in the All-Wireless Office and IaaS/Managed Service use cases.* This quarter, Info-Tech Research Group placed Extreme as a Champion in the Vendor Landscape for Wired and Wireless LAN. |

[0001564590-16-026732:8k_2_02:20]
|  | • | Launch of Extreme Partner Network. Extreme introduced new enhancements to its Extreme Partner Network (“EPN”) program to offer new incentives that increase profitability and simplify the way Extreme's channel partners do business. It is the most competitive partner program in the industry. |

[0001564590-16-026732:8k_2_02:21]
*Gartner, Critical Capabilities for Wired and Wireless LAN Access Infrastructure, 12 September 2016

[0001564590-16-026732:8k_2_02:22]
Gartner, Magic Quadrant for the Wired and Wireless LAN Access Infrastructure, 30 August 2016

[0001564590-16-026732:8k_2_02:23]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001564590-16-026732:8k_2_02:24]
Fiscal Q1 2017 Financial Metrics:

[0001564590-16-026732:8k_2_02:25]
|  |  | 2017 |  |  | 2016 |  |  | Change |  |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 90.1 |  |  | $ | 91.4 |  |  | $ | (1.3 | ) |  |  | (1 | )% |
| Service |  |  | 32.5 |  |  |  | 33.2 |  |  |  | (0.7 | ) |  |  | (2 | )% |
| Total Net Revenue |  | $ | 122.6 |  |  | $ | 124.6 |  |  | $ | (2.0 | ) |  |  | (2 | )% |
| Gross Margin |  |  | 53.2 | % |  |  | 52.3 | % |  |  | 0.9 | % |  |  | 2 | % |
| Operating Margin |  |  | (3.9 | )% |  |  | (8.7 | )% |  |  | 4.8 | % |  |  | 55 | % |
| Net Loss |  | $ | (6.5 | ) |  | $ | (11.5 | ) |  | $ | 5.0 |  |  |  | 44 | % |
| Loss per basic share |  | $ | (0.06 | ) |  | $ | (0.11 | ) |  | $ | 0.05 |  |  |  | 45 | % |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 90.1 |  |  | $ | 91.4 |  |  | $ | (1.3 | ) |  |  | (1 | )% |
| Service |  |  | 32.7 |  |  |  | 33.6 |  |  |  | (0.9 | ) |  |  | (3 | )% |
| Total Net Revenue |  | $ | 122.8 |  |  | $ | 125.0 |  |  | $ | (2.2 | ) |  |  | (2 | )% |
| Gross Margin |  |  | 56.3 | % |  |  | 55.2 | % |  |  | 1.1 | % |  |  | 2 | % |
| Operating Margin |  |  | 7.2 | % |  |  | 6.0 | % |  |  | 1.2 | % |  |  | 20 | % |
| Net Income |  | $ | 7.1 |  |  | $ | 6.7 |  |  | $ | 0.4 |  |  |  | 7 | % |
| Earnings per diluted share |  | $ | 0.07 |  |  | $ | 0.07 |  |  | $ | - |  |  |  | — |  |

[0001564590-16-026732:8k_2_02:26]
|  | • | Cash and investments ended the quarter at $102.3 million, as compared to $94.1 million from the prior quarter and an increase of $20.2 million from the prior year amount. |

[0001564590-16-026732:8k_2_02:27]
|  | • | Accounts receivable balance ending Q1 was $68.2 million, with days sales outstanding (“DSO”) of 51. |

[0001564590-16-026732:8k_2_02:28]
|  | • | Inventory ending Q1 was $43.4 million, an increase of $2.4 million from the prior quarter and down $18.3 million from the prior year amount. |

[0001564590-16-026732:8k_2_02:29]
Business Outlook:

[0001564590-16-026732:8k_2_02:30]
For its second quarter of fiscal 2017 ending December 31, 2016, the Company is targeting GAAP and non-GAAP revenue in a range of $148.0 million to $158.0 million.  GAAP gross margin is targeted between 53.4% and 55.3% and non-GAAP gross margin is targeted between 54.5% and 55.5%. Operating expenses are targeted to be between $88.1 million and $90.5 million on a GAAP basis and $72.8 million to $76.3 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $6.4 million to $10.1 million or a loss of $0.06 to $0.09 per share.  Non-GAAP earnings are targeted in a range of net income of $5.7 million to $9.4 million, or $0.05 to $0.09 per diluted share. The GAAP and non-GAAP net income (loss) targets are based on an estimated 109 million and 110 million average outstanding shares, respectively.

[0001564590-16-026732:8k_2_02:31]
Conference Call:

[0001564590-16-026732:8k_2_02:32]
Extreme will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the first fiscal quarter results as well as the second fiscal quarter 2017 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through November 2, 2017.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406   Conference ID # 90330335.

[0001564590-16-026732:8k_2_02:33]
About Extreme Networks:

[0001564590-16-026732:8k_2_02:34]
Extreme Networks, Inc. (“EXTR”) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, we go to extreme measures for our 20,000-plus customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, education, government, healthcare, manufacturing and hospitality. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-16-026732:8k_2_02:35]
Extreme Networks and the Extreme Networks logo, ExtremeManagement, ExtremeWireless, ExtremeControl and ExtremeAnalytics are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-16-026732:8k_2_02:36]
Non-GAAP Financial Measures:

[0001564590-16-026732:8k_2_02:37]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income (loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, executive transition costs, litigation expenses and overhead adjustments.  The Company believes that excluding these items provides both management and investors

[0001564590-16-026732:8k_2_02:38]
with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Reconciliation of non-GAAP to corresponding GAAP measures with respect to our business outlook is not possible at this time due to the fact that amortization, stock compensation expense and the impact of the mark-up of inventory to fair value for purchase accounting can only be determined in connection with the post-closing valuation of the assets we acquired in connection with the closing of our transaction with Zebra Technologies Corporation and other post-closing activities of the Company.  Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-16-026732:8k_2_02:39]
Forward Looking Statements:

[0001564590-16-026732:8k_2_02:40]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-16-026732:8k_2_02:41]
EXTREME NETWORKS, INC.

[0001564590-16-026732:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-16-026732:8k_2_02:43]
(In thousands)

[0001564590-16-026732:8k_2_02:44]
(Unaudited)

[0001564590-16-026732:8k_2_02:45]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 102,265 |  |  | $ | 94,122 |  |
| Accounts receivable, net of allowances of $2,582 at September 30, 2016 and $3,257 at June 30, 2016 |  |  | 68,246 |  |  |  | 81,419 |  |
| Inventories |  |  | 43,395 |  |  |  | 40,989 |  |
| Prepaid expenses and other current assets |  |  | 11,507 |  |  |  | 12,438 |  |
| Total current assets |  |  | 225,413 |  |  |  | 228,968 |  |
| Property and equipment, net |  |  | 30,058 |  |  |  | 29,580 |  |
| Intangible assets, net |  |  | 11,707 |  |  |  | 19,762 |  |
| Goodwill |  |  | 70,877 |  |  |  | 70,877 |  |
| Other assets |  |  | 25,054 |  |  |  | 25,236 |  |
| Total assets |  | $ | 363,109 |  |  | $ | 374,423 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 19,269 |  |  | $ | 17,628 |  |
| Accounts payable |  |  | 28,332 |  |  |  | 30,711 |  |
| Accrued compensation and benefits |  |  | 19,827 |  |  |  | 27,145 |  |
| Accrued warranty |  |  | 8,620 |  |  |  | 9,600 |  |
| Deferred revenue, net |  |  | 70,697 |  |  |  | 72,934 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  |  | 30,229 |  |  |  | 26,817 |  |
| Other accrued liabilities |  |  | 27,382 |  |  |  | 26,691 |  |
| Total current liabilities |  |  | 204,356 |  |  |  | 211,526 |  |
| Deferred revenue, less current portion |  |  | 21,540 |  |  |  | 21,926 |  |
| Long-term debt, less current portion |  |  | 32,621 |  |  |  | 37,446 |  |
| Deferred income taxes |  |  | 5,129 |  |  |  | 4,693 |  |
| Other long-term liabilities |  |  | 8,728 |  |  |  | 8,635 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 90,735 |  |  |  | 90,197 |  |
| Total liabilities and stockholders’ equity |  | $ | 363,109 |  |  | $ | 374,423 |  |

[0001564590-16-026732:8k_2_02:46]
EXTREME NETWORKS, INC.

[0001564590-16-026732:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-026732:8k_2_02:48]
(In thousands, except per share amounts)

[0001564590-16-026732:8k_2_02:49]
(Unaudited)

[0001564590-16-026732:8k_2_02:50]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 90,131 |  |  | $ | 91,381 |  |
| Service |  |  | 32,511 |  |  |  | 33,200 |  |
| Total net revenues |  |  | 122,642 |  |  |  | 124,581 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 44,927 |  |  |  | 46,934 |  |
| Service |  |  | 12,469 |  |  |  | 12,529 |  |
| Total cost of revenues |  |  | 57,396 |  |  |  | 59,463 |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  |  | 45,204 |  |  |  | 44,447 |  |
| Service |  |  | 20,042 |  |  |  | 20,671 |  |
| Total gross profit |  |  | 65,246 |  |  |  | 65,118 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 18,299 |  |  |  | 20,268 |  |
| Sales and marketing |  |  | 36,956 |  |  |  | 36,062 |  |
| General and administrative |  |  | 8,287 |  |  |  | 9,176 |  |
| Acquisition and integration costs |  |  | 2,321 |  |  |  | 338 |  |
| Restructuring charge, net of reversals |  |  | - |  |  |  | 5,603 |  |
| Amortization of intangibles |  |  | 4,142 |  |  |  | 4,467 |  |
| Total operating expenses |  |  | 70,005 |  |  |  | 75,914 |  |
| Operating loss |  |  | (4,759 | ) |  |  | (10,796 | ) |
| Interest income |  |  | 57 |  |  |  | 27 |  |
| Interest expense |  |  | (647 | ) |  |  | (826 | ) |
| Other income (expense), net |  |  | (223 | ) |  |  | 967 |  |
| Loss before income taxes |  |  | (5,572 | ) |  |  | (10,628 | ) |
| Provision for income taxes |  |  | 907 |  |  |  | 898 |  |
| Net loss |  | $ | (6,479 | ) |  | $ | (11,526 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.06 | ) |  | $ | (0.11 | ) |
| Net loss per share - diluted |  | $ | (0.06 | ) |  | $ | (0.11 | ) |
| Shares used in per share calculation - basic |  |  | 105,955 |  |  |  | 100,985 |  |
| Shares used in per share calculation - diluted |  |  | 105,955 |  |  |  | 100,895 |  |

[0001564590-16-026732:8k_2_02:51]
EXTREME NETWORKS, INC.

[0001564590-16-026732:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-16-026732:8k_2_02:53]
(In thousands)

[0001564590-16-026732:8k_2_02:54]
(Unaudited)

[0001564590-16-026732:8k_2_02:55]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Net cash provided by operating activities |  | $ | 9,574 |  |  | $ | 6,526 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (1,635 | ) |  |  | (633 | ) |
| Net cash used in investing activities |  |  | (1,635 | ) |  |  | (633 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Repayment of debt |  |  | (3,250 | ) |  |  | (1,625 | ) |
| Proceeds from issuance of common stock |  |  | 3,416 |  |  |  | 1,855 |  |
| Net cash provided by financing activities |  |  | 166 |  |  |  | 230 |  |
| Foreign currency effect on cash |  |  | 38 |  |  |  | (323 | ) |
| Net increase in cash and cash equivalents |  |  | 8,143 |  |  |  | 5,800 |  |
| Cash and cash equivalents at beginning of period |  |  | 94,122 |  |  |  | 76,225 |  |
| Cash and cash equivalents at end of period |  | $ | 102,265 |  |  | $ | 82,025 |  |

[0001564590-16-026732:8k_2_02:56]
Extreme Networks, Inc.

[0001564590-16-026732:8k_2_02:57]
Non-GAAP Measures of Financial Performance

[0001564590-16-026732:8k_2_02:58]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-16-026732:8k_2_02:59]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring expenses and overhead adjustments.

[0001564590-16-026732:8k_2_02:60]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-16-026732:8k_2_02:61]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-16-026732:8k_2_02:62]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, restructuring expenses,  executive transition costs, litigation expenses and overhead adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-16-026732:8k_2_02:63]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-16-026732:8k_2_02:64]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-16-026732:8k_2_02:65]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of Zebra Technologies Corporation’s wireless LAN business.   Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-16-026732:8k_2_02:66]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-16-026732:8k_2_02:67]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-16-026732:8k_2_02:68]
Restructuring expenses. Restructuring expenses primarily consist of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-16-026732:8k_2_02:69]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits and legal transition cash transactions.  The expenses are incurred through execution of pre-established employment contracts with senior executives.  The Company does not believe these expenses are reflective of ongoing cash requirements related to its operating results.

[0001564590-16-026732:8k_2_02:70]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matter as a result of a securities laws class action lawsuit.

[0001564590-16-026732:8k_2_02:71]
Overhead adjustments. Overhead adjustment relate to service inventory overhead capitalization, this was a one-time event and was non-cash in nature.

[0001564590-16-026732:8k_2_02:72]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-16-026732:8k_2_02:73]
EXTREME NETWORKS, INC.

[0001564590-16-026732:8k_2_02:74]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-16-026732:8k_2_02:75]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-16-026732:8k_2_02:76]
(In thousands, except per share amounts)

[0001564590-16-026732:8k_2_02:77]
(Unaudited)

[0001564590-16-026732:8k_2_02:78]
| Non-GAAP Revenue | For the three months ended |  |  |
|  | September 30, 2016 |  |  | September 30, 2015 |  |  |
| Revenue - GAAP Basis | $ | 122,642 |  |  | $ | 124,581 |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | 133 |  |  |  | 377 |  |  |
| Revenue - Non-GAAP Basis | $ | 122,775 |  |  | $ | 124,958 |  |  |

[0001564590-16-026732:8k_2_02:79]
| Non-GAAP Gross Margin | For the three months ended |  |  |
|  | September 30, 2016 |  |  | September 30, 2015 |  |  |
| Gross profit - GAAP Basis | $ | 65,246 |  |  | $ | 65,118 |  |  |
| Gross margin - GAAP Basis percentage |  | 53.2 | % |  |  | 52.3 | % |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 300 |  |  |  | 663 |  |  |
| Purchase accounting adjustments |  | 133 |  |  |  | 377 |  |  |
| Amortization of intangibles |  | 3,417 |  |  |  | 4,292 |  |  |
| Service inventory overhead capitalization |  | - |  |  |  | (1,493 | ) |  |
| Gross profit - Non-GAAP Basis | $ | 69,096 |  |  | $ | 68,957 |  |  |
| Gross margin - Non-GAAP Basis percentage |  | 56.3 | % |  |  | 55.2 | % |  |

[0001564590-16-026732:8k_2_02:80]
| Non-GAAP Operating Income | For the three months ended |  |  |
|  | September 30, 2016 |  |  | September 30, 2015 |  |  |
| GAAP operating loss | $ | (4,759 | ) |  | $ | (10,796 | ) |  |
| GAAP operating loss percentage |  | (3.9 | )% |  |  | (8.7 | )% |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,475 |  |  |  | 4,671 |  |  |
| Acquisition and integration costs |  | 2,321 |  |  |  | 338 |  |  |
| Restructuring charge, net of reversal |  | - |  |  |  | 5,603 |  |  |
| Amortization of intangibles |  | 7,559 |  |  |  | 8,759 |  |  |
| Purchase accounting adjustments |  | 133 |  |  |  | 377 |  |  |
| Executive transition costs |  | 34 |  |  |  | - |  |  |
| Litigation |  | 27 |  |  |  | - |  |  |
| Service inventory overhead capitalization |  | - |  |  |  | (1,493 | ) |  |
| Total adjustments to GAAP operating loss | $ | 13,549 |  |  | $ | 18,255 |  |  |
| Non-GAAP operating income | $ | 8,790 |  |  | $ | 7,459 |  |  |
| Non-GAAP operating income percentage |  | 7.2 | % |  |  | 6.0 | % |  |

[0001564590-16-026732:8k_2_02:81]
| Non-GAAP Net Income | For the three months ended |  |  |
|  | September 30, 2016 |  |  | September 30, 2015 |  |  |
| GAAP net loss | $ | (6,479 | ) |  | $ | (11,526 | ) |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,475 |  |  |  | 4,671 |  |  |
| Acquisition and integration costs |  | 2,321 |  |  |  | 338 |  |  |
| Restructuring charge, net of reversal |  | - |  |  |  | 5,603 |  |  |
| Amortization of intangibles |  | 7,559 |  |  |  | 8,759 |  |  |
| Purchase accounting adjustments |  | 133 |  |  |  | 377 |  |  |
| Executive transition costs |  | 34 |  |  |  | - |  |  |
| Litigation |  | 27 |  |  |  | - |  |  |
| Service inventory overhead capitalization |  | - |  |  |  | (1,493 | ) |  |
| Total adjustments to GAAP net loss | $ | 13,549 |  |  | $ | 18,255 |  |  |
| Non-GAAP net income | $ | 7,070 |  |  | $ | 6,729 |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.07 |  |  | $ | 0.07 |  |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 108,637 |  |  |  | 102,907 |  |  |

[0001564590-16-026732:8k_2_02:82]
| Free Cash Flow | For the three months ended |  |  |
|  | September 30, 2016 |  |  | September 30, 2015 |  |  |
| Cash flow provided by operations | $ | 9,574 |  |  | $ | 6,526 |  |  |
| Less: PP&E CapEx spending |  | (1,635 | ) |  | $ | (633 | ) |  |
| Total free cash flow | $ | 7,939 |  |  | $ | 5,893 |  |  |
