# EXTR notes — 0001564590-16-027054


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-16-027054:notes:1]
[same as prior period, unchanged from 0001564590-16-017216:notes:1]

[0001564590-16-027054:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-16-027054:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2016 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2016.

[0001564590-16-027054:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2016  The results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.

[0001564590-16-027054:notes:5]
[same as prior period, unchanged from 0001564590-16-017216:notes:5]

[0001564590-16-027054:notes:6]
The Company uses a fiscal calendar year ending on June 30.  All references herein to "fiscal 2017" or "2017" represent the fiscal year ending June 30, 2017.  All references herein to "fiscal 2016" or "2016" represent the fiscal year ending June 30, 2016.

[0001564590-16-027054:notes:7]
[same as prior period, unchanged from 0001564590-16-017216:notes:7]

[0001564590-16-027054:notes:8]
The consolidated financial statements include the accounts of Extreme and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-16-027054:notes:9]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001564590-16-027054:notes:10]
[same as prior period, unchanged from 0001564590-16-017216:notes:9]

[0001564590-16-027054:notes:11]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-16-027054:notes:12]
[same as prior period, unchanged from 0001564590-16-017216:notes:12]

[0001564590-16-027054:notes:13]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual Report on Form 10-K for the fiscal year ended June 30, 2016. There have been no material changes to the Company's significant accounting policies since the filing of the Annual Report on Form 10-K.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-16-027054:notes:14]
| 3. | Recent Accounting Pronouncements |

[0001564590-16-027054:notes:15]
Recently Adopted Accounting Pronouncements

[0001564590-16-027054:notes:16]
In March 2016, the FASB issued Accounting Standards Update (ASU) 2016-09, Compensation – Stock Compensation (“ASU 2016-09”) which identifies areas for simplification involving several aspects of accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, an option to recognize gross stock compensation expense with actual forfeitures recognized as they occur, as well as certain classifications on the statement of cash flows.  The Company early adopted this standard beginning with its fiscal year 2017. The impact of the adoption had the following impacts:

[0001564590-16-027054:notes:17]
|  | • | In recording share-based compensation expense, the standard allows companies to make a policy election as to whether they will include an estimate of awards expected to be forfeited or whether they will account for forfeitures as they occur. The Company has elected to not include an estimated forfeiture rate in the computation of its share-based compensation expense. This election did not have a material impact on the Company’s condensed consolidated financial statements and accordingly no adjustment was made to beginning accumulated deficit to apply the modified retrospective method. |

[0001564590-16-027054:notes:18]
|  | • | The standard requires that employee taxes paid when an employer withholds shares for tax-withholding purposes be reported as financing activities in the consolidated statements of cash flows. Previously, the Company included these cash flows in financing activities and therefore the adoption of this provision had no impact. |

[0001564590-16-027054:notes:19]
|  | • | The new standard requires that the tax effects of share-based compensation be recognized in the income tax provision. Previously, these amounts were recognized in additional paid-in capital. Given the full valuation allowance against the US deferred tax assets, there will be no impact to the effective tax rate until such time as the valuation allowance may be reversed. |

[0001564590-16-027054:notes:20]
|  | • | The standard also requires previously unrecognized excess tax benefits to be recognized on a modified retrospective basis. Unrecognized tax benefits result when a deduction for stock based compensation does not actually reduce taxes payable. The Company has recorded $13.5 million and $0.9 million of previously unrecorded deferred tax assets for federal and state net operating losses, respectively, with a corresponding increase to the valuation allowance pursuant to the evidence discussed in Note 9. The cumulative net impact to accumulated deficit of early adoption of this provision was therefore zero. |

[0001564590-16-027054:notes:21]
|  | • | ASU 2016-09 also requires excess tax benefits to be presented as an operating activity on the statement of cash flows rather than as a financing activity on either a retrospective or prospective basis. The Company has elected to apply this provision of the standard on a prospective basis. |

[0001564590-16-027054:notes:22]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs (“ASU 2015-03”),  which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts.  ASU 2015-03 requires retrospective adoption and will be effective for annual and interim periods in fiscal years beginning after December 15, 2015.  This guidance became effective for the Company beginning with its fiscal year 2017.

[0001564590-16-027054:notes:23]
In connection with the Company’s adoption of ASU 2015-03 in fiscal 2017, all debt issuance costs have been presented, with the exception of those related to the revolving credit facility, as a reduction of the carrying amount of the related debt liability.  The previously reported balances in the Company’s June 30, 2016 Form 10-K for debt issuance costs listed in “Other assets” have been reclassified to “Current portion of long-term debt” in the amount of $0.2 million and “Long-term debt, less current portion” in the amount of $0.2 million to conform to the September 30, 2016 presentation.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-16-027054:notes:24]
[same as prior period, unchanged from 0001564590-16-017216:notes:14]

[0001564590-16-027054:notes:25]
[same as prior period, unchanged from 0001564590-16-017216:notes:15]

[0001564590-16-027054:notes:26]
The following is a summary of cash and cash equivalents (in thousands):

[0001564590-16-027054:notes:27]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Cash |  | $ | 97,988 |  |  | $ | 89,847 |  |
| Cash equivalents |  |  | 4,277 |  |  |  | 4,275 |  |
| Total cash and cash equivalents |  | $ | 102,265 |  |  | $ | 94,122 |  |

[0001564590-16-027054:notes:28]
[same as prior period, unchanged from 0001564590-16-017216:notes:18]

[0001564590-16-027054:notes:29]
[same as prior period, unchanged from 0001564590-16-017216:notes:19]

[0001564590-16-027054:notes:30]
The Company’s inventory balances as of September 30, 2016 and June 30, 2016 were $43.4 million and $41.0 million, respectively. The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-16-027054:notes:31]
[same as prior period, unchanged from 0001564590-16-017216:notes:21]

[0001564590-16-027054:notes:32]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Finished goods |  | $ | 41,262 |  |  | $ | 38,751 |  |
| Raw materials |  |  | 2,133 |  |  |  | 2,238 |  |
| Total Inventory |  | $ | 43,395 |  |  | $ | 40,989 |  |

[0001564590-16-027054:notes:33]
[same as prior period, unchanged from 0001564590-16-017216:notes:23]

[0001564590-16-027054:notes:34]
[same as prior period, unchanged from 0001564590-16-017216:notes:24]

[0001564590-16-027054:notes:35]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Computer equipment |  | $ | 37,618 |  |  | $ | 34,657 |  |
| Purchased software |  |  | 5,575 |  |  |  | 5,574 |  |
| Office equipment, furniture and fixtures |  |  | 10,374 |  |  |  | 10,385 |  |
| Leasehold improvements |  |  | 19,395 |  |  |  | 19,342 |  |
| Total property and equipment |  |  | 72,962 |  |  |  | 69,958 |  |
| Less: accumulated depreciation and amortization |  |  | (42,904 | ) |  |  | (40,378 | ) |
| Property and equipment, net |  | $ | 30,058 |  |  | $ | 29,580 |  |

[0001564590-16-027054:notes:36]
[same as prior period, unchanged from 0001564590-16-017216:notes:26]

[0001564590-16-027054:notes:37]
[same as prior period, unchanged from 0001564590-16-017216:notes:27]

[0001564590-16-027054:notes:38]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 0.22 years |  | $ | 48,000 |  |  | $ | 46,444 |  |  | $ | 1,556 |  |
| Customer relationships |  | 0.10 years |  |  | 37,000 |  |  |  | 35,972 |  |  |  | 1,028 |  |
| Maintenance contracts |  | 2.00 years |  |  | 17,000 |  |  |  | 9,917 |  |  |  | 7,083 |  |
| Trademarks |  | 0.10 years |  |  | 2,500 |  |  |  | 2,431 |  |  |  | 69 |  |
| License agreements |  | 7.00 years |  |  | 2,445 |  |  |  | 963 |  |  |  | 1,482 |  |
| Other intangibles |  | 3.40 years |  |  | 1,382 |  |  |  | 893 |  |  |  | 489 |  |
| Total intangibles, net |  |  |  | $ | 108,327 |  |  | $ | 96,620 |  |  | $ | 11,707 |  |

[0001564590-16-027054:notes:39]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 0.30 years |  | $ | 48,000 |  |  | $ | 43,028 |  |  | $ | 4,972 |  |
| Customer relationships |  | 0.30 years |  |  | 37,000 |  |  |  | 32,889 |  |  |  | 4,111 |  |
| Maintenance contracts |  | 2.30 years |  |  | 17,000 |  |  |  | 9,067 |  |  |  | 7,933 |  |
| Trademarks |  | 0.30 years |  |  | 2,500 |  |  |  | 2,222 |  |  |  | 278 |  |
| License agreements |  | 9.70 years |  |  | 3,413 |  |  |  | 1,473 |  |  |  | 1,940 |  |
| Other intangibles |  | 3.70 years |  |  | 1,428 |  |  |  | 900 |  |  |  | 528 |  |
| Total intangibles, net |  |  |  | $ | 109,341 |  |  | $ | 89,579 |  |  | $ | 19,762 |  |

[0001564590-16-027054:notes:40]
[same as prior period, unchanged from 0001564590-16-017216:notes:30]

[0001564590-16-027054:notes:41]
|  |  | Three Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Amortization in "Cost of revenues: Product" |  | $ | 3,498 |  |  | $ | 4,424 |  |
| Amortization of intangibles |  |  | 4,142 |  |  |  | 4,467 |  |
| Total amortization |  | $ | 7,640 |  |  | $ | 8,891 |  |

[0001564590-16-027054:notes:42]
The amortization expense that is recognized in “Cost of revenues: Product” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-16-027054:notes:43]
Goodwill

[0001564590-16-027054:notes:44]
The following table summarizes goodwill for the periods presented (in thousands):

[0001564590-16-027054:notes:45]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Balance at beginning of period |  | $ | 70,877 |  |  | $ | 70,877 |  |
| Changes during period |  |  | — |  |  |  | — |  |
| Balance at end of period |  | $ | 70,877 |  |  | $ | 70,877 |  |

[0001564590-16-027054:notes:46]
[same as prior period, unchanged from 0001564590-16-017216:notes:33]

[0001564590-16-027054:notes:47]
[same as prior period, unchanged from 0001564590-16-017216:notes:34]

[0001564590-16-027054:notes:48]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Accrued general and administrative costs |  | $ | 4,050 |  |  | $ | 4,079 |  |
| Restructuring |  |  | 1,754 |  |  |  | 2,522 |  |
| Other accrued liabilities |  |  | 21,578 |  |  |  | 20,090 |  |
| Total other accrued liabilities |  | $ | 27,382 |  |  | $ | 26,691 |  |

[0001564590-16-027054:notes:49]
[same as prior period, unchanged from 0001564590-16-017216:notes:36]

[0001564590-16-027054:notes:50]
[same as prior period, unchanged from 0001564590-16-017216:notes:37]

[0001564590-16-027054:notes:51]
[same as prior period, unchanged from 0001564590-16-017216:notes:38]

[0001564590-16-027054:notes:52]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Deferred maintenance |  | $ | 84,334 |  |  | $ | 83,419 |  |
| Deferred product and other revenue |  |  | 7,903 |  |  |  | 11,441 |  |
| Total deferred revenue, net |  |  | 92,237 |  |  |  | 94,860 |  |
| Less: current portion |  |  | 70,697 |  |  |  | 72,934 |  |
| Non-current deferred revenue, net |  | $ | 21,540 |  |  | $ | 21,926 |  |

[0001564590-16-027054:notes:53]
[same as prior period, unchanged from 0001564590-16-017216:notes:40]

[0001564590-16-027054:notes:54]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Balance beginning of period |  | $ | 83,419 |  |  | $ | 87,441 |  |
| New maintenance arrangements |  |  | 28,745 |  |  |  | 27,046 |  |
| Recognition of maintenance revenue |  |  | (27,830 | ) |  |  | (29,232 | ) |
| Balance end of period |  |  | 84,334 |  |  |  | 85,255 |  |
| Less: current portion |  |  | 62,794 |  |  |  | 63,310 |  |
| Non-current deferred revenue |  | $ | 21,540 |  |  | $ | 21,945 |  |

[0001564590-16-027054:notes:55]
[same as prior period, unchanged from 0001564590-16-017216:notes:42]

[0001564590-16-027054:notes:56]
[same as prior period, unchanged from 0001564590-16-017216:notes:43]

[0001564590-16-027054:notes:57]
[same as prior period, unchanged from 0001564590-16-017216:notes:44]

[0001564590-16-027054:notes:58]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Deferred distributors revenue |  | $ | 38,780 |  |  | $ | 35,138 |  |
| Deferred cost of sales to distributors |  |  | (8,551 | ) |  |  | (8,321 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | $ | 30,229 |  |  | $ | 26,817 |  |

[0001564590-16-027054:notes:59]
[same as prior period, unchanged from 0001564590-16-017216:notes:46]

[0001564590-16-027054:notes:60]
[same as prior period, unchanged from 0001564590-16-017216:notes:47]

[0001564590-16-027054:notes:61]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,269 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 19,269 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,621 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 32,621 |  |  |  | 37,446 |  |
| Total debt |  | $ | 51,890 |  |  | $ | 55,074 |  |

[0001564590-16-027054:notes:62]
During fiscal 2015, the Company amended its credit agreement which provides for a five-year revolving credit facility for up to $50.0 million (the “Revolving Facility”) and a $65.0 million five-year term loan (the “Term Loan”) and together with the Revolving Facility the (“Senior Secured Credit Facilities, as amended”).

[0001564590-16-027054:notes:63]
The Senior Secured Credit Facilities, as amended contains, among others, certain financial covenants that require the Company to maintain defined minimum financial ratios which may limit the Company’s availability to borrowings under the Revolving Facility. As of September 30, 2016, the Company had $27.1 million of availability under the Revolving Facility.

[0001564590-16-027054:notes:64]
The Company had $1.0 million of outstanding letters of credit as of September 30, 2016.

[0001564590-16-027054:notes:65]
On October 28, 2016 the Company entered into an Amended and Restated Credit Agreement by and among the Company, as borrower, the several banks and other financial institutions or entities party thereto as lenders, and Silicon Valley Bank, as administrative agent and collateral agent.  For information with respect to the terms of this agreement refer to Subsequent Events in Note 13 of Condensed Consolidated Financial Statements.

[0001564590-16-027054:notes:66]
[same as prior period, unchanged from 0001564590-16-017216:notes:52]

[0001564590-16-027054:notes:67]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-16-027054:notes:68]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2016 and 2015 (in thousands):

[0001564590-16-027054:notes:69]
|  |  | Three Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Balance beginning of period |  | $ | 9,600 |  |  | $ | 8,676 |  |
| New warranties issued |  |  | 928 |  |  |  | 2,564 |  |
| Warranty expenditures |  |  | (1,908 | ) |  |  | (1,996 | ) |
| Balance end of period |  | $ | 8,620 |  |  | $ | 9,244 |  |

[0001564590-16-027054:notes:70]
To facilitate sales of its products in the normal course of business, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-16-027054:notes:71]
[same as prior period, unchanged from 0001564590-16-017216:notes:57]

[0001564590-16-027054:notes:72]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue. All other advertising costs are expensed as incurred.  Advertising expenses for three months ended September 30, 2016 and 2015, were immaterial.

[0001564590-16-027054:notes:73]
[same as prior period, unchanged from 0001564590-16-017216:notes:59]

[0001564590-16-027054:notes:74]
[same as prior period, unchanged from 0001564590-16-017216:notes:60]

[0001564590-16-027054:notes:75]
[same as prior period, unchanged from 0001564590-16-017216:notes:61]

[0001564590-16-027054:notes:76]
[same as prior period, unchanged from 0001564590-16-017216:notes:62]

[0001564590-16-027054:notes:77]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Tech Data Corporation |  |  | 17% |  |  |  | 12% |  |
| Jenne |  |  | 16% |  |  |  | 11% |  |
| Avnet |  |  | 13% |  |  | * |  |
| Westcon Group Inc. |  |  | 11% |  |  |  | 16% |  |
| Scansource, Inc. |  | * |  |  |  | 13% |  |

[0001564590-16-027054:notes:78]
[same as prior period, unchanged from 0001564590-16-017216:notes:64]

[0001564590-16-027054:notes:79]
The following customers account for more than 10% of our accounts receivable outstanding as of September 30, 2016, Westcon Group Inc. 17% and Tech Data Corporation 11%.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-16-027054:notes:80]
[same as prior period, unchanged from 0001564590-16-017216:notes:66]

[0001564590-16-027054:notes:81]
[same as prior period, unchanged from 0001564590-16-017216:notes:67]

[0001564590-16-027054:notes:82]
|  | • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-16-027054:notes:83]
|  | • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-16-027054:notes:84]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company's own assumptions in measuring the asset or liability at fair value. |

[0001564590-16-027054:notes:85]
[same as prior period, unchanged from 0001564590-16-017216:notes:71]

[0001564590-16-027054:notes:86]
| September 30, 2016 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,277 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,277 |  |
| Total |  | $ | 4,277 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,277 |  |

[0001564590-16-027054:notes:87]
| June 30, 2016 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,275 |  |
| Total |  | $ | 4,275 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,275 |  |

[0001564590-16-027054:notes:88]
[same as prior period, unchanged from 0001564590-16-017216:notes:74]

[0001564590-16-027054:notes:89]
[same as prior period, unchanged from 0001564590-16-017216:notes:75]

[0001564590-16-027054:notes:90]
The fair value of the borrowings under the Senior Secured Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the carrying amount of the Company’s indebtedness of $51.9 million and $55.5 million as of September 30, 2016 and June 30, 2016, respectively.

[0001564590-16-027054:notes:91]
[same as prior period, unchanged from 0001564590-16-017216:notes:77]

[0001564590-16-027054:notes:92]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. There were no impairments recorded for the three months ended September 30, 2016 or 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-16-027054:notes:93]
6.Share-based Compensation

[0001564590-16-027054:notes:94]
[same as prior period, unchanged from 0001564590-16-017216:notes:80]

[0001564590-16-027054:notes:95]
As of September 30, 2016, the Company had reserved for issuance (in thousands):

[0001564590-16-027054:notes:96]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| 2014 Employee Stock Purchase Plan |  |  | 8,897 |  |  |  | 10,001 |  |
| Employee stock options and awards outstanding |  |  | 11,467 |  |  |  | 10,609 |  |
| Employee stock options and awards available for grant |  |  | 2,200 |  |  |  | 5,401 |  |
| Total shares reserved for issuance |  |  | 22,564 |  |  |  | 26,011 |  |

[0001564590-16-027054:notes:97]
[same as prior period, unchanged from 0001564590-16-017216:notes:83]

[0001564590-16-027054:notes:98]
|  |  | Three Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Cost of product revenue |  | $ | 68 |  |  | $ | 296 |  |
| Cost of service revenue |  |  | 232 |  |  |  | 367 |  |
| Research and development |  |  | 1,141 |  |  |  | 1,629 |  |
| Sales and marketing |  |  | 1,062 |  |  |  | 1,428 |  |
| General and administrative |  |  | 972 |  |  |  | 951 |  |
| Total share-based compensation expense |  | $ | 3,475 |  |  | $ | 4,671 |  |

[0001564590-16-027054:notes:99]
During the three months ended September 30, 2016 and 2015, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-16-027054:notes:100]
[same as prior period, unchanged from 0001564590-16-017216:notes:86]

[0001564590-16-027054:notes:101]
Stock awards may be granted under the 2013 Equity Incentive Plan (the “2013 Plan”) on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (including performance or market-based restricted stock units) which vest over a fixed period of time or based upon the satisfaction of certain performance criteria.  The Company uses the straight-line method for expense attribution, and beginning with fiscal 2017, the Company does not estimate forfeitures.

[0001564590-16-027054:notes:102]
The following table summarizes stock award activity for the three months ended September 30, 2016  (in thousands, except grant date fair value):

[0001564590-16-027054:notes:103]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2016 |  |  | 4,224 |  |  | $ | 3.36 |  |  |  |  |  |
| Granted |  |  | 2,558 |  |  | $ | 3.72 |  |  |  |  |  |
| Vested |  |  | (431 | ) |  | $ | 3.34 |  |  | $ | 1,833 |  |
| Cancelled |  |  | (255 | ) |  | $ | 2.88 |  |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2016 |  |  | 6,096 |  |  | $ | 3.53 |  |  |  |  |  |

[0001564590-16-027054:notes:104]
The following table summarizes stock option activity for the three months ended September 30, 2016 (in thousands, except per share and contractual term):

[0001564590-16-027054:notes:105]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2016 |  |  | 6,385 |  |  | $ | 4.10 |  |  |  | 3.70 |  |  | $ | 1,416 |  |
| Granted |  |  | - |  |  | $ | - |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (417 | ) |  | $ | 3.46 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (597 | ) |  | $ | 4.47 |  |  |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2016 |  |  | 5,371 |  |  | $ | 4.11 |  |  |  | 3.53 |  |  | $ | 4,117 |  |
| Exercisable at September 30, 2016 |  |  | 3,999 |  |  | $ | 4.37 |  |  |  | 2.97 |  |  | $ | 2,249 |  |
| Vested and expected to vest at September 30, 2016 |  |  | 5,371 |  |  | $ | 4.11 |  |  |  | 3.53 |  |  | $ | 4,117 |  |

[0001564590-16-027054:notes:106]
There were no stock options granted during the three months ended September 30, 2016 and 2015.

[0001564590-16-027054:notes:107]
The weighted-average fair value of shares granted under the Company’s 2014 Employee Stock Purchase Plan (“ESPP”) during the three months ended September 30, 2016 and 2015 was $1.00 and $0.99, respectively.

[0001564590-16-027054:notes:108]
The fair value of each stock option grant under the Company's 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-16-027054:notes:109]
The fair value of each restricted stock award grant with performance criteria (“PSU’s”) under the Company's 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-16-027054:notes:110]
On August 1, 2016, the Compensation Committee of the Company approved the grant of 680,000 awards of restricted stock units to the Company’s Executive Officers, with a grant date of August 15, 2016. Fifty percent (50%) of the restricted stock units granted were in the form of PSUs and fifty percent (50%) of the restricted stock units granted were in the form of service-based restricted stock units (“RSUs”).  The RSUs vest from the original grant date as to one-third (1/3) on the one year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company  The PSUs vest once the Company's stock equals or exceeds $5.00 per share for 30 consecutive trading days after January 1, 2017 ("Performance Threshold"). Once the Performance Threshold is satisfied the PSUs shall vest with respect to the number of RSUs that have vested as of the date the Performance Threshold is satisfied and thereafter shall vest on the same schedule as the RSUs, subject to continued service to the Company. If the Performance Threshold is not met by the third anniversary of the grant date the award is terminated for no consideration.  In addition, the Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $5.00 per share.

[0001564590-16-027054:notes:111]
The fair value of each share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the ESPP represents the term of the offering period of each option. The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-16-027054:notes:112]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Expected life |  | 0.5 years |  |  | 1.25 years |  |
| Risk-free interest rate |  |  | 0.40 | % |  |  | 0.29 | % |
| Volatility |  |  | 40 | % |  |  | 58 | % |
| Dividend yield |  |  | — | % |  |  | — | % |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-16-027054:notes:113]
[same as prior period, unchanged from 0001564590-16-017216:notes:98]

[0001564590-16-027054:notes:114]
As of September 30, 2016, restructuring liabilities were $4.1 million and consisted of obligations for estimated future obligations for non-cancelable lease payments for excess facilities.  There were no restructuring charges during the three months ended September 30, 2016.  During the three months ended September 30, 2015 the Company recorded restructuring charges of $5.6 million and abandoned excess facilities primarily in San Jose, California; Salem, New Hampshire; and Shannon, Ireland. The abandoned facilities represented approximately 27% of the floor space in the aggregate at these locations and included general office and warehouse space. Restructuring charges included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities of $5.4 million and accelerated depreciation of leasehold improvements in the amount of $1.3 million.

[0001564590-16-027054:notes:115]
Included in the restructuring charges were offsets for future sub-leasing income. The Company has estimated the sub-lease income based on its existing leases agreement, as well the real estate market conditions at the respective locations. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements. The Company will reevaluate any sub-lease income on a regular basis and adjust the accrual as necessary if and when facts should change.

[0001564590-16-027054:notes:116]
[same as prior period, unchanged from 0001564590-16-017216:notes:107]

[0001564590-16-027054:notes:117]
|  |  | Total |  |
| Balance as of June 30, 2016 |  |  | 4,644 |  |
| Period charges |  |  | — |  |
| Period payments |  |  | (508 | ) |
| Balance as of September 30, 2016 |  | $ | 4,136 |  |
| Less: current portion included in Other accrued liabilities |  |  | 1,754 |  |
| Restructuring accrual included in Other long-term liabilities |  | $ | 2,382 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-16-027054:notes:118]
| 8. | Commitments and Contingencies |

[0001564590-16-027054:notes:119]
Purchase Commitments

[0001564590-16-027054:notes:120]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2016, the Company had non-cancelable commitments to purchase $70.6 million of such inventory.

[0001564590-16-027054:notes:121]
Legal Proceedings

[0001564590-16-027054:notes:122]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-16-027054:notes:123]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-16-027054:notes:124]
Brazilian Tax Assessment Matters                                                                                                                                                   Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of September 30, 2016.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.1 million), plus interest and penalties BRL 17.5 million (US $5.4 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

[0001564590-16-027054:notes:125]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits are expected to cover the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company changed its ICMS procedures effective May 2009 and a similar tax assessment is not anticipated.  The Company has provided the requested information for these tax years to the Brazilian tax authorities, but has received no further response from the Brazilian tax authorities.

[0001564590-16-027054:notes:126]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL 25.1 million (US $7.8 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $2.9 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

[0001564590-16-027054:notes:127]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from the Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

[0001564590-16-027054:notes:128]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-16-027054:notes:129]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint, which the defendants will move to dismiss.  The Company believes the claims are without merit and intends to vigorously defend the claims.

[0001564590-16-027054:notes:130]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and have submitted a stipulation to that effect to the court.

[0001564590-16-027054:notes:131]
Dunti Network Technoligies, LLC v Extreme Networks, Inc. Patent Infringement Suit

[0001564590-16-027054:notes:132]
On September 22, 2016, the Company was served with a patent infringement complaint by Dunti Network Technologies, LLC in the U.S. District Court for the Eastern District of Texas.  The case is Dunti Network Technologies, LLC v. Extreme Networks, Inc., No. 2:16-cv-01034.  The complaint asserts infringement of U.S. Patent Nos. 6,587,462, 6,788,701, 6,804,235, 6,643,286, and 7,778,259.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s BlackDiamond-X, Summit X670, and Summit X770 series switches.  Dunti seeks damages of an unspecified amount.  The Company’s answer to the complaint is presently due November 14, 2016.  The Company believes the claims are without merit and intends to defend itself vigorously against the claims.

[0001564590-16-027054:notes:133]
Indemnification Obligations

[0001564590-16-027054:notes:134]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of September 30, 2016, the Company had no outstanding indemnification claims.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-16-027054:notes:135]
[same as prior period, unchanged from 0001564590-16-017216:notes:125]

[0001564590-16-027054:notes:136]
For the three months ended September 30, 2016, the Company recorded an income tax provision of $0.9 million.  For the three months ended September 30, 2015, the Company recorded an income tax provision of $0.9 million.

[0001564590-16-027054:notes:137]
The income tax provisions for the three months ended September 30, 2016 and 2015, consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc.  The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended September 30, 2016 and 2015, and therefore may not reflect the annual effective tax rate.

[0001564590-16-027054:notes:138]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as the deferred tax assets in Australia, Brazil and Japan. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions.  This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-16-027054:notes:139]
On December 18, 2015, the Protecting Americans from Tax Hikes (“PATH”) Act of 2015, became effective which includes a provision making permanent the R&D tax credit under Section 41 of the Code.  This credit previously expired on December 31, 2014.  This change has been reflected in the Company’s tax credit carryforwards with an offsetting adjustment to its U.S. valuation allowance.

[0001564590-16-027054:notes:140]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  During the three months ended September 30, 2016 and 2015, the Company deducted $1.1 million of tax amortization expense for each period related to capitalized goodwill. As of September 30, 2016, the Company recorded a deferred tax liability of $4.9 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-16-027054:notes:141]
The Company had $11.7 million of unrecognized tax benefits as of September 30, 2016.  The future impact of the unrecognized tax benefit of $11.7 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-16-027054:notes:142]
[same as prior period, unchanged from 0001564590-16-017216:notes:132]

[0001564590-16-027054:notes:143]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.


## us-gaap:EarningsPerShareTextBlock

[0001564590-16-027054:notes:144]
[same as prior period, unchanged from 0001564590-16-017216:notes:134]

[0001564590-16-027054:notes:145]
[same as prior period, unchanged from 0001564590-16-017216:notes:135]

[0001564590-16-027054:notes:146]
[same as prior period, unchanged from 0001564590-16-017216:notes:136]

[0001564590-16-027054:notes:147]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Net loss |  | $ | (6,479 | ) |  | $ | (11,526 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 105,955 |  |  |  | 100,985 |  |
| Net loss per share - basic and diluted |  | $ | (0.06 | ) |  | $ | (0.11 | ) |

[0001564590-16-027054:notes:148]
[same as prior period, unchanged from 0001564590-16-017216:notes:138]

[0001564590-16-027054:notes:149]
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Options to purchase common stock |  |  | 3,715 |  |  |  | 8,301 |  |
| Restricted stock units |  |  | 1,635 |  |  |  | 6,657 |  |
| Employee Stock Purchase Plan shares |  |  | 201 |  |  |  | 147 |  |
| Total shares excluded |  |  | 5,551 |  |  |  | 15,105 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-16-027054:notes:150]
11.Foreign Exchange Forward Contracts

[0001564590-16-027054:notes:151]
At September 30, 2016 and 2015, we did not have any forward foreign currency contracts.

[0001564590-16-027054:notes:152]
Foreign currency transaction gains and losses from operations was a loss of $0.2 million and a gain of $1.2 million for the three months ended September 30, 2016 and 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-16-027054:notes:153]
[same as prior period, unchanged from 0001564590-16-017216:notes:143]

[0001564590-16-027054:notes:154]
[same as prior period, unchanged from 0001564590-16-017216:notes:144]

[0001564590-16-027054:notes:155]
[same as prior period, unchanged from 0001564590-16-017216:notes:145]

[0001564590-16-027054:notes:156]
|  |  | For the three months ended |  |
| Net Revenues: |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 53,858 |  |  | $ | 56,343 |  |
| Other |  |  | 8,185 |  |  |  | 5,843 |  |
| Total Americas |  |  | 62,043 |  |  |  | 62,186 |  |
| EMEA: |  |  |  |  |  |  |  |  |
| Germany |  |  | 24,587 |  |  |  | 14,538 |  |
| Other |  |  | 26,062 |  |  |  | 36,488 |  |
| Total EMEA |  |  | 50,649 |  |  |  | 51,026 |  |
| APAC: |  |  | 9,950 |  |  |  | 11,369 |  |
| Total net revenues |  | $ | 122,642 |  |  | $ | 124,581 |  |

[0001564590-16-027054:notes:157]
| Long Lived Assets: |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Americas |  | $ | 54,844 |  |  | $ | 58,277 |  |
| EMEA |  |  | 9,383 |  |  |  | 14,234 |  |
| APAC |  |  | 2,592 |  |  |  | 2,493 |  |
| Total long lived assets |  | $ | 66,819 |  |  | $ | 75,004 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-16-027054:notes:158]
13.Subsequent Events

[0001564590-16-027054:notes:159]
On September 13, 2016, the Company entered into an Asset Purchase Agreement (the “Purchase”) with Zebra Technologies Corporation, a Delaware corporation (“Zebra”), to purchase Zebra’s wireless LAN business (the “Business”).  Under the terms of the Purchase, the Company acquired customers, employees, technology and other assets of the Business, as well as assumed certain contracts and other liabilities of the Business, for a cash purchase price of approximately $55.0 million, subject to certain adjustments related to net working capital and deferred revenue of the Business on October 28, 2016 (the “Closing”).  Pursuant to certain ancillary agreements, Zebra will also provide the Company with access to certain technology related to the Business, as well as transition services for a period of time following the Closing.

[0001564590-16-027054:notes:160]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Business will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Business will be included in the operations of the Company beginning with the Closing.

[0001564590-16-027054:notes:161]
The Company expects to include a preliminary determination of the acquisition consideration and detail of the assets acquired and liabilities assumed in the Company’s consolidated financial statements for the quarter ending December 31, 2016.

[0001564590-16-027054:notes:162]
During the three months ended September 30, 2016, the Company recognized transaction costs of $2.3 million which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-16-027054:notes:163]
Borrowing Facility

[0001564590-16-027054:notes:164]
Commensurate with the Closing, the Company entered into an Amended and Restated Credit Agreement (the “Credit Agreement”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Agreement provides for a five-year $90.5 million term loan and a five-year $50.0 million revolving credit facility, which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Agreement among other things, amends and restates the Company’s existing credit facility.  At the Closing, the Company incurred $100.5 million of indebtedness to pay off existing debt and to finance the acquisition of the Business.  Borrowings under the term loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on our consolidated leverage ratio).  Borrowings under the revolving credit facility bear interest, at the Company’s option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the prime lending rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The revolving credit facility has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.  The Credit Agreement is collateralized by substantially all assets of the Company.
