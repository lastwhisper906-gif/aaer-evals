# EXTR MD&A — 0001564590-16-027054


## mdna

[0001564590-16-027054:mdna:1]
[same as prior period, unchanged from 0001564590-16-017216:mdna:1]

[0001564590-16-027054:mdna:2]
[same as prior period, unchanged from 0001564590-16-017216:mdna:2]

[0001564590-16-027054:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended September 30, 2016.

[0001564590-16-027054:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from the data center to the access point, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. We strive to help our customers and partners Connect Beyond the NetworkTM by building world-class software and network infrastructure solutions that solve the wide range of problems faced by information technology (“IT”) departments.

[0001564590-16-027054:mdna:5]
The Internet of Things (“IoT”) and the evolution of the cloud have made reliable and secure Internet connections increasingly critical to business success.  In this time of rapid changes and market shifts, delivering a focused value proposition based on automation, simplicity, high quality solutions and world class customer support is vitally important. As the volume and the demands of users, applications, data and devices on networks continue to increase, Extreme stands ready to help our customers address the ever-evolving demands of the business.

[0001564590-16-027054:mdna:6]
[same as prior period, unchanged from 0001564590-16-017216:mdna:16]

[0001564590-16-027054:mdna:7]
The networking industry appears to be invigorated by a wave of technological change:

[0001564590-16-027054:mdna:8]
|  | • | Ethernet (wired and wireless) has solidified its role in both public and private networks through its scalability, adaptability and cost-effectiveness. At the same time, the enterprises and service providers expect the technology to follow a price-performance curve that mandates continued innovation by Ethernet vendors. |

[0001564590-16-027054:mdna:9]
|  | • | The mobile workforce has proliferated. Employees expect high-quality and secure access to corporate resources in a Bring Your Own Device ("BYOD") world across a diversity of endpoints such as laptops, tablets, smart phones and wearables, whether they are within the corporate firewall or on-the-go. IT departments focus their investment decisions on this mobile workforce, taking a unified view of wireless access, the campus core and the data center. Networking vendors offer end-to-end solutions that permit IT managers to meet employee expectations and to maximize IT return on investment. |

[0001564590-16-027054:mdna:10]
|  | • | Growing usage of the cloud. Deployment of server virtualization is influencing data center architecture. Enterprises have migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. Ethernet speeds, scaling from 10 Gigabits per second ("G") to 40G and even 100G, provide the infrastructure for both private and public clouds. In addition, there is growing interest in SDN approaches that may include technologies such as OpenFlow, OpenStack, and CloudStack for increased network agility. |

[0001564590-16-027054:mdna:11]
|  | • | Vendor Consolidation. We believe consolidation of vendors within the Ethernet networking market and between adjacent markets (storage, security, wireless & voice software and applications) continues to gain momentum. In 2015, the Hewlett-Packard Company (“HP”) acquired Aruba, the Dell, Inc. acquisition of EMC closed in September 2016 and Brocade |

[0001564590-16-027054:mdna:12]
|  |  | Communication Systems acquired Ruckus in May 2016. We believe these acquisitions reflect a realization that customers want end-to-end, integrated networking solutions. Extreme identified this trend in 2013 and sought to address the issue with its acquisition of Enterasys in 2013. Since that time, Extreme has rationalized the roadmap and provided an upgrade path for customers. |

[0001564590-16-027054:mdna:13]
We seek to differentiate ourselves in the market by delivering a value proposition based on a software-driven approach to network management, control and analytics.

[0001564590-16-027054:mdna:14]
Our key points of differentiation include:

[0001564590-16-027054:mdna:15]
|  | • | End-to-end, wired and wireless solutions. Extreme offers a complete, unified portfolio of software-driven network access technology. We offer the latest in wireless access points for both outdoor and indoor use plus a complete line of switches to cover the campus, right up to and including the data center. |

[0001564590-16-027054:mdna:16]
|  | • | Multi-vendor management from a “single pane of glass”. Extreme offers a single unified management system that is designed to provide visibility and control across the entire network. This can make the network easier to manage and troubleshoot, often with lower operating expenses. Our software can also manage many other vendors’ network devices, enabling our customers to potentially maximize device lifespan. |

[0001564590-16-027054:mdna:17]
|  | • | Software-driven vertical solutions. We design our software-driven solutions to be easily adaptable to vertical solutions in industries such as, healthcare, education, manufacturing, government and hospitality and to be well-suited for vertical-specific partners. |

[0001564590-16-027054:mdna:18]
|  | • | Application-aware Quality of Service (“QoS”) and analytics. Extreme has innovative analytic software that enables our customers to see application usage across the network and apply policies that maximize network capabilities. This allows our customers to improve the user experience. |

[0001564590-16-027054:mdna:19]
|  | • | Built-in identity and access control. We design our network access control and identity management with the wired and wireless hardware. This may reduce the need to add on expensive software or hardware that may require complex compatibility testing. |

[0001564590-16-027054:mdna:20]
|  | • | EZ policy assignment and software-defined networking (“SDN”). ExtremeControl and ExtremeManagement software allow our customers to assign policy across the entire network. The SDN component adds versatility for implementing policies that increase network utilization. |

[0001564590-16-027054:mdna:21]
|  | • | 100% in-sourced tech support. Extreme delivers best in class customer support in the industry with 92% first call resolution through a 100% in-sourced support model. |

[0001564590-16-027054:mdna:22]
Extreme sells products primarily through an ecosystem of channel partners which combine our Ethernet, wireless and management and software analytics products with their vertical-specific offerings to create IT solutions for end user customers.

[0001564590-16-027054:mdna:23]
Acquisition

[0001564590-16-027054:mdna:24]
On October 28, 2016, we closed the purchase of the wireless LAN business (the “Business”) of  Zebra Technologies Corporation, or Zebra, pursuant to an Asset Purchase Agreement ( the “Purchase Agreement”).  Under the terms of the Purchase Agreement, we acquired customers, employees, technology and other assets of the Business, as well as assumed certain contracts and other liabilities of the Business, for a cash purchase price of approximately $55.0 million, subject to certain adjustments related to net working capital and deferred revenue of the Business on October 28, 2016 (the “Closing”).

[0001564590-16-027054:mdna:25]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Business will be recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Business will be included in our operations beginning with the Closing.

[0001564590-16-027054:mdna:26]
We expect to include a preliminary determination of the acquisition consideration and detail of the assets acquired and liabilities assumed in the Company’s consolidated financial statements for the quarter ending December 31, 2016.

[0001564590-16-027054:mdna:27]
During the three months ended September 30, 2016, we recognized transaction costs of $2.3 million which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-16-027054:mdna:28]
Borrowing Facility

[0001564590-16-027054:mdna:29]
In connection with the Closing, we entered into an Amended and Restated  Credit Agreement (the “Credit Agreement”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Agreement provides for a five-year $90.5 million term loan and a five-year $50.0 million revolving credit facility, which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Agreement among other things, amends and restates our existing credit facility.  On October 28, 2016, we incurred $100.5 million of indebtedness to pay off existing debt and to finance the acquisition of the Business from Zebra.  Borrowings under the term loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on our consolidated leverage ratio).  Borrowings under the revolving credit facility bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the prime lending rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The revolving credit facility has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.  The Credit Agreement is collateralized by substantially all of our assets.

[0001564590-16-027054:mdna:30]
[same as prior period, unchanged from 0001564590-16-017216:mdna:18]

[0001564590-16-027054:mdna:31]
During the first quarter of fiscal 2017, we achieved the following results:

[0001564590-16-027054:mdna:32]
|  | • | Net revenues of $122.6 million compared to $124.6 million in the first quarter of fiscal 2016. |

[0001564590-16-027054:mdna:33]
|  | • | Product revenues of $90.1 million compared to $91.4 million in the first quarter of fiscal 2016. |

[0001564590-16-027054:mdna:34]
|  | • | Service revenues of $32.5 million compared to $33.2 million in the first quarter of fiscal 2016. |

[0001564590-16-027054:mdna:35]
|  | • | Total gross margin of 53% of net revenues compared to 52% of net revenues in the first quarter of fiscal 2016. |

[0001564590-16-027054:mdna:36]
|  | • | Operating loss of $4.8 million compared to $10.8 million in the first quarter of fiscal 2016. |

[0001564590-16-027054:mdna:37]
|  | • | Net loss of $6.5 million compared to a net loss of $11.5 million in the first quarter of fiscal 2016. |

[0001564590-16-027054:mdna:38]
|  | • | Cash flow provided by operating activities of $9.6 million in the three months ended September 30, 2016 compared to $6.5 million in the three months ended September 30, 2015. |

[0001564590-16-027054:mdna:39]
|  | • | Cash and cash equivalents of $102.3 million as of September 30, 2016 compared to $94.1 million as of June 30, 2016. |

[0001564590-16-027054:mdna:40]
[same as prior period, unchanged from 0001564590-16-017216:mdna:31]

[0001564590-16-027054:mdna:41]
The following table presents net product and service revenue for the three months ended September 30, 2016 and 2015 (dollars in thousands):

[0001564590-16-027054:mdna:42]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 90,131 |  |  | $ | 91,381 |  |  | $ | (1,250 | ) |  |  | (1.4 | )% |
| Percentage of net revenue |  |  | 73.5 | % |  |  | 73.4 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 32,511 |  |  |  | 33,200 |  |  |  | (689 | ) |  |  | (2.1 | )% |
| Percentage of net revenue |  |  | 26.5 | % |  |  | 26.6 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 122,642 |  |  | $ | 124,581 |  |  | $ | (1,939 | ) |  |  | (1.6 | )% |

[0001564590-16-027054:mdna:43]
Product revenues decreased by $1.3 million or 1.4% for the three months ended September 30, 2016 as compared to the corresponding period of fiscal 2016.  The decrease in product revenues during the quarter reflects lower sales in the United States, primarily in the education sector, which was partially offset with higher demand in EMEA, as compared to the first quarter of fiscal 2016.

[0001564590-16-027054:mdna:44]
Service revenues decreased $0.7 million or 2.1% in the first quarter of fiscal 2017, compared to the corresponding period of fiscal 2016.  Service revenues declined $0.7 million due to lower maintenance revenues partially offset by higher professional services and lower purchase accounting charges related to deferred service revenues of $0.1 million in first quarter of fiscal 2017 as compared to $0.2 million in the first quarter of fiscal 2016.

[0001564590-16-027054:mdna:45]
The following table presents the product and service, gross profit and the respective gross profit percentages for the three months ended September 30, 2016 and 2015 (dollars in thousands):

[0001564590-16-027054:mdna:46]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 45,204 |  |  | $ | 44,447 |  |  | $ | 757 |  |  |  | 1.7 | % |
| Percentage of product revenue |  |  | 50.2 | % |  |  | 48.6 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 20,042 |  |  |  | 20,671 |  |  |  | (629 | ) |  |  | (3.0 | )% |
| Percentage of service revenue |  |  | 61.6 | % |  |  | 62.3 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 65,246 |  |  | $ | 65,118 |  |  | $ | 128 |  |  |  | 0.2 | % |
| Percentage of net revenue |  |  | 53.2 | % |  |  | 52.3 | % |  |  |  |  |  |  |  |  |

[0001564590-16-027054:mdna:47]
Product gross profit increased $0.8 million or 1.7% in the first quarter of fiscal 2017 as compared to the corresponding period in fiscal 2016.  Gross profit increased during the first quarter of fiscal 2017 due to reduced product discounting, lower warranty charges of $1.3 million and material product costs offset by lower revenues.

[0001564590-16-027054:mdna:48]
Service gross profit decreased $0.6 million or 2.7% to $20.1 million in the first quarter of fiscal 2017 from $20.7 million in the first quarter of fiscal 2016.  The decrease was primarily due to lower service revenues of $0.7 million as compared to the first quarter of fiscal 2016.

[0001564590-16-027054:mdna:49]
[same as prior period, unchanged from 0001564590-16-017216:mdna:44]

[0001564590-16-027054:mdna:50]
The following table presents operating expenses (dollars in thousands):

[0001564590-16-027054:mdna:51]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 18,299 |  |  | $ | 20,268 |  |  | $ | (1,969 | ) |  |  | (9.7 | )% |
| Sales and marketing |  |  | 36,956 |  |  |  | 36,062 |  |  |  | 894 |  |  |  | 2.5 | % |
| General and administrative |  |  | 8,287 |  |  |  | 9,176 |  |  |  | (889 | ) |  |  | (9.7 | )% |
| Acquisition and integration costs |  |  | 2,321 |  |  |  | 338 |  |  |  | 1,983 |  |  |  | 586.7 | % |
| Restructuring charge, net of reversals |  |  | 0 |  |  |  | 5,603 |  |  |  | (5,603 | ) |  |  | (100.0 | )% |
| Amortization of intangibles |  |  | 4,142 |  |  |  | 4,467 |  |  |  | (325 | ) |  |  | (7.3 | )% |
| Total operating expenses |  | $ | 70,005 |  |  | $ | 75,914 |  |  | $ | (5,909 | ) |  |  | (7.8 | )% |

[0001564590-16-027054:mdna:52]
[same as prior period, unchanged from 0001564590-16-017216:mdna:47]

[0001564590-16-027054:mdna:53]
[same as prior period, unchanged from 0001564590-16-017216:mdna:48]

[0001564590-16-027054:mdna:54]
Research and development expenses decreased by $2.0 million, or 9.7% for the three months ended September 30, 2016 as compared to the corresponding period of fiscal 2016. The decrease in research and development expenses was due to lower personnel costs of $1.3 million and lower equipment depreciation and software license costs of $0.9 million.

[0001564590-16-027054:mdna:55]
[same as prior period, unchanged from 0001564590-16-017216:mdna:51]

[0001564590-16-027054:mdna:56]
[same as prior period, unchanged from 0001564590-16-017216:mdna:52]

[0001564590-16-027054:mdna:57]
Sales and marketing expenses increased by $0.9 million or 2.5% for the three months ended September 30, 2016 as compared to the corresponding period of fiscal 2016.  The increase in sales and marketing expenses was primarily due to higher promotional costs of $0.5 million, increases in personnel costs (which includes benefits and stock based compensation) of $0.3 million and facility expense of $0.1 million.

[0001564590-16-027054:mdna:58]
[same as prior period, unchanged from 0001564590-16-017216:mdna:55]

[0001564590-16-027054:mdna:59]
[same as prior period, unchanged from 0001564590-16-017216:mdna:56]

[0001564590-16-027054:mdna:60]
General and administrative expenses decreased by $0.9 million or 9.7% for the three months ended September 30, 2016 as compared to the corresponding period of fiscal 2016.  The decrease in general and administrative expenses was due to lower personnel costs of $0.4 million, lower facility costs of $0.2 million, reduced professional fees of $0.2 million and a $0.2 million reduction of the provision for doubtful accounts as compared to the corresponding period of 2016.

[0001564590-16-027054:mdna:61]
[same as prior period, unchanged from 0001564590-16-017216:mdna:59]

[0001564590-16-027054:mdna:62]
During the three months ended September 30, 2016, we recorded $2.3 million of acquisition costs consisting primarily of legal and accounting services associated with the acquisition of Zebra’s Business.

[0001564590-16-027054:mdna:63]
During the three months ended September 30, 2015, we recorded $0.3 million of integration costs primarily for IT and sales integration costs associated with the acquisition of Enterasys.

[0001564590-16-027054:mdna:64]
[same as prior period, unchanged from 0001564590-16-017216:mdna:63]

[0001564590-16-027054:mdna:65]
During the three months ended September 30, 2016 and 2015, we recorded zero and $5.6 million in restructuring charges, respectively, primarily for excess facilities, net of future sub-lease income.

[0001564590-16-027054:mdna:66]
During fiscal 2016, we continued our initiative begun in the fourth quarter of fiscal 2015 to realign our operations by abandoning excess facilities, primarily in San Jose California; Salem, New Hampshire; and Shannon, Ireland. The abandoned facilities represented approximately 27% of our original total space, and included general office and warehouse space.  Restructuring charges during fiscal 2016 included accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities of $5.4 million as well as accelerated depreciation of leasehold improvements in the amount of $1.3 million.

[0001564590-16-027054:mdna:67]
[same as prior period, unchanged from 0001564590-16-017216:mdna:68]

[0001564590-16-027054:mdna:68]
During the three months ended September 30, 2016 and 2015, we recorded $4.1 million and $4.5 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.

[0001564590-16-027054:mdna:69]
[same as prior period, unchanged from 0001564590-16-017216:mdna:71]

[0001564590-16-027054:mdna:70]
During the three months ended September 30, 2016 we recorded $0.6 million and $0.8 million, respectively, in interest expense primarily in connection with our Senior Secured Credit Facilities.  Our interest expense will increase in future periods due to the Senior Secured Credit Facility, as Amended.

[0001564590-16-027054:mdna:71]
[same as prior period, unchanged from 0001564590-16-017216:mdna:73]

[0001564590-16-027054:mdna:72]
During the three months ended September 30, 2016 and 2015 we recorded expense of $0.2 million and income of $1.0 million, respectively, in other income (expense), net. The reduction was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-16-027054:mdna:73]
[same as prior period, unchanged from 0001564590-16-017216:mdna:76]

[0001564590-16-027054:mdna:74]
For the three months ended September 30, 2016 and 2015, we recorded an income tax provision of $0.9 million and $0.9 million, respectively.

[0001564590-16-027054:mdna:75]
The income tax provisions for the three months ended September 30, 2016 and 2015 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.

[0001564590-16-027054:mdna:76]
[same as prior period, unchanged from 0001564590-16-017216:mdna:79]

[0001564590-16-027054:mdna:77]
[same as prior period, unchanged from 0001564590-16-017216:mdna:80]

[0001564590-16-027054:mdna:78]
As discussed in Part II, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2016, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-16-027054:mdna:79]
|  | • | Revenue Recognition |

[0001564590-16-027054:mdna:80]
|  | • | Goodwill |

[0001564590-16-027054:mdna:81]
|  | • | Share-based Payments |

[0001564590-16-027054:mdna:82]
|  | • | Restructuring Charges |

[0001564590-16-027054:mdna:83]
[same as prior period, unchanged from 0001564590-16-017216:mdna:86]

[0001564590-16-027054:mdna:84]
[same as prior period, unchanged from 0001564590-16-017216:mdna:87]

[0001564590-16-027054:mdna:85]
[same as prior period, unchanged from 0001564590-16-017216:mdna:88]

[0001564590-16-027054:mdna:86]
[same as prior period, unchanged from 0001564590-16-017216:mdna:89]

[0001564590-16-027054:mdna:87]
[same as prior period, unchanged from 0001564590-16-017216:mdna:90]

[0001564590-16-027054:mdna:88]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Cash and cash equivalent |  | $ | 102,265 |  |  | $ | 94,122 |  |
| Total cash and investments |  | $ | 102,265 |  |  | $ | 94,122 |  |
| Working capital |  | $ | 21,057 |  |  | $ | 17,442 |  |

[0001564590-16-027054:mdna:89]
As of September 30, 2016, our principal sources of liquidity consisted of cash and cash equivalents of $102.3 million, accounts receivable, net of $68.2 million and availability of borrowings from the Revolving Facility of $27.1 million. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment. We believe that our $102.3 million of cash and cash equivalents at September 30, 2016, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-16-027054:mdna:90]
The Senior Secured Credit Facilities, as amended, contain financial covenants that among other things, require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.

[0001564590-16-027054:mdna:91]
The Senior Secured Credit Facilities, as amended, also include customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended, may be accelerated upon certain events of default. At September 30, 2016, we were in compliance and expect to remain in compliance with the covenants of the Senior Secured Credit Facilities, as amended, and they are not expected to impact our liquidity or capital resources.

[0001564590-16-027054:mdna:92]
[same as prior period, unchanged from 0001564590-16-017216:mdna:95]

[0001564590-16-027054:mdna:93]
[same as prior period, unchanged from 0001564590-16-017216:mdna:96]

[0001564590-16-027054:mdna:94]
|  |  | For the three months ended |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Net cash provided by operating activities |  | $ | 9,574 |  |  | $ | 6,526 |  |
| Net cash used in investing activities |  |  | (1,635 | ) |  |  | (633 | ) |
| Net cash provided by financing activities |  |  | 166 |  |  |  | 230 |  |
| Foreign currency effect on cash |  |  | 38 |  |  |  | (323 | ) |
| Net increase in cash and cash equivalents |  | $ | 8,143 |  |  | $ | 5,800 |  |

[0001564590-16-027054:mdna:95]
[same as prior period, unchanged from 0001564590-16-017216:mdna:98]

[0001564590-16-027054:mdna:96]
Cash flows provided by operations in the three months ended September 30, 2016 were $9.6 million due to higher collections of accounts receivables during the quarter, combined with non-cash expenses of $14.5 million such as amortization of intangibles, stock-based compensation expense and depreciation.   This was partially offset by the current period's net loss of $6.5 million along with increased use of cash in inventory, accounts payable and accrued compensation.

[0001564590-16-027054:mdna:97]
Cash flows provided by operations in the three months ended September 30, 2015, were $6.5 million reflecting the impact of  non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation as well as decreases in accounts receivables and was partially offset by the current period's net loss of $19.9 million with increases in inventories and decreases in accounts payable, accrued compensation and deferred revenues.

[0001564590-16-027054:mdna:98]
Net Cash Used In Investing Activities

[0001564590-16-027054:mdna:99]
Cash flows used in investing activities in the three months ended September 30, 2016 and 2015, were $1.6 million and $0.6 million, respectively.   Amounts consisted of purchases of property and equipment.

[0001564590-16-027054:mdna:100]
Net Cash Provided by Financing Activities

[0001564590-16-027054:mdna:101]
Cash flows provided by financing activities in the three months ended September 30, 2016 were $0.2 million which consisted of $3.4 million proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by a net repayment of debt of $3.2 million.

[0001564590-16-027054:mdna:102]
Cash flow provided by financing activities in the three months ending September 30, 2015 were $0.2 million, consisting of $1.9 million proceeds from the issuance of shares of our common stock under the ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards offset by $1.6 million of cash used for repayment of debt.

[0001564590-16-027054:mdna:103]
[same as prior period, unchanged from 0001564590-16-017216:mdna:107]

[0001564590-16-027054:mdna:104]
Foreign currency effect on cash increased in the three months ended September 30, 2016, primarily due to changes in foreign currency exchange rates between the US Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-16-027054:mdna:105]
[same as prior period, unchanged from 0001564590-16-017216:mdna:109]

[0001564590-16-027054:mdna:106]
The following summarizes our contractual obligations at three months ended September 30, 2016, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-16-027054:mdna:107]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations (1) |  | $ | 52,250 |  |  | $ | 19,500 |  |  | $ | 32,750 |  |  | $ | — |  |  | $ | — |  |
| Interest on debt obligations |  |  | 2,526 |  |  |  | 1,602 |  |  |  | 924 |  |  |  | — |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 70,576 |  |  |  | 70,576 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 52,948 |  |  |  | 9,545 |  |  |  | 16,907 |  |  |  | 15,147 |  |  |  | 11,349 |  |
| Other liabilities |  |  | 305 |  |  |  | 146 |  |  |  | 159 |  |  |  | — |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 178,605 |  |  | $ | 101,369 |  |  | $ | 50,740 |  |  | $ | 15,147 |  |  | $ | 11,349 |  |

[0001564590-16-027054:mdna:108]
|  | (1) | Does not include $48.3 million borrowed on October 28, 2016 to fund the Acquisition of the Zebra Business. |

[0001564590-16-027054:mdna:109]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $70.6 million as of   September 30, 2016. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-16-027054:mdna:110]
[same as prior period, unchanged from 0001564590-16-017216:mdna:113]

[0001564590-16-027054:mdna:111]
[same as prior period, unchanged from 0001564590-16-017216:mdna:114]

[0001564590-16-027054:mdna:112]
[same as prior period, unchanged from 0001564590-16-017216:mdna:115]

[0001564590-16-027054:mdna:113]
We did not have any material commitments for capital expenditures as of September 30, 2016.

[0001564590-16-027054:mdna:114]
[same as prior period, unchanged from 0001564590-16-017216:mdna:117]

[0001564590-16-027054:mdna:115]
We did not have any off-balance sheet arrangements as of September 30, 2016.
