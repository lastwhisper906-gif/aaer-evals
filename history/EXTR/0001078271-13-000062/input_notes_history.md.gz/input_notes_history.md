# EXTR note change history — 0001078271-13-000020 → 0001078271-13-000062


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-11-04):
[0001078271-13-000062:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2013, the Company had non-cancelable commitments to purchase approximately $80.0 million of such inventory.
  (was, 2013-05-01, similarity 0.9888):
[0001078271-13-000020:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2013, the Company had non-cancelable commitments to purchase approximately $30.3 million of such inventory.

- added (2013-11-04):
[0001078271-13-000062:note_history:2]
During the quarter ending March 31, 2013, venue for the Delaware action was transferred to the United States District Court for the District of Northern California.

- added (2013-11-04):
[0001078271-13-000062:note_history:3]
On July 16, 2013, the parties entered into a confidential patent license and settlement agreement (“Agreement”). Pursuant to that Agreement, the Company paid $1.4 million on July 25, 2013 and Chrimar filed for dismissal of the Delaware Action with prejudice on July 29, 2013. All matters between the parties have now been resolved.

- added (2013-11-04):
[0001078271-13-000062:note_history:4]
Relay IP Inc.

- added (2013-11-04):
[0001078271-13-000062:note_history:5]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775. The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on July 15, 2013. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

- changed (2013-11-04):
[0001078271-13-000062:note_history:6]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of September 30, 2013, the Company had no outstanding indemnification claims.
  (was, 2013-05-01, similarity 0.993):
[0001078271-13-000020:note_history:6]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of March 31, 2013, the Company had no outstanding indemnification claims

- removed (2013-11-04):
[0001078271-13-000020:note_history:7]
Enterasys Networks

- removed (2013-11-04):
[0001078271-13-000020:note_history:8]
On June 21, 2005, Enterasys Networks ("Enterasys") filed suit against Extreme and Foundry Networks, Inc. (“Foundry”) in the United States District Court for the District of Massachusetts, Civil Action No. 05-11298 DPW. The complaint alleged willful infringement of U.S. Patent Nos. 5,251,205; 5,390,173; 6,128,665; 6,147,995; 6,539,022; and 6,560,236, and sought: a) a judgment that the Company willfully infringes each of the patents; (b) a permanent injunction from infringement, inducement of infringement and contributory infringement of each of the six patents; (c) damages and a “reasonable royalty” to be determined at trial; (d) treble damages; (e) attorneys' fees, costs and interest; and (f) equitable relief at the Court's discretion. Petitions for reexamination were filed challenging five of the patents at issue to the U.S. Patent and Trademark Office, and a stay of the case was entered. Following the reexamination proceedings, Enterasys withdrew its allegations of infringement as to two of the patents, U.S. Patent Nos. 6,539,022 and 6,560,236. The stay was lifted on May 21, 2010, and the Court held claim construction hearings in December 2010. Fact discovery was ongoing. No trial date was set.

- removed (2013-11-04):
[0001078271-13-000020:note_history:9]
On April 20, 2007, the Company filed suit against Enterasys in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded the Company damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.

- removed (2013-11-04):
[0001078271-13-000020:note_history:10]
On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Both parties filed post-trial motions, including motions for a new trial, for judgment as a matter of law and for attorneys' fees, all of which the Court denied on July 11, 2012. Enterasys did not file a notice of appeal by the August 10, 2012 deadline.  Consequently, the judgment of non-infringement in favor of the Company in the second trial is final. During the fourth quarter of fiscal 2012, Enterasys paid the Company $0.6 million related to the judgment.  During the quarter ended December 31, 2012, the Company received payments from Enterasys totaling approximately $0.4 million for the Court's award for damages, supplemental damages, pre and post judgment interests, costs from the first trial and second trial, plus the amount Enterasys agreed to release for damages held in escrow that accrued during the stay of the injunction post-trial and on appeal.

- removed (2013-11-04):
[0001078271-13-000020:note_history:11]
During the third quarter of fiscal 2013, the Company and Enterasys engaged in settlement discussions. On March  29, 2013, the parties entered into a confidential settlement agreement (“Agreement”). The Agreement required a dismissal with prejudice of the Wisconsin and Massachusetts litigation, as well as cross covenants not to sue and survival of settlement rights for any acquiring party of the parties. Joint motions to dismiss were granted on April 13, 2013, and April 15, 2013 respectively.  All matters between the parties have now been resolved.

- removed (2013-11-04):
[0001078271-13-000020:note_history:12]
During the fourth quarter of the fiscal 2012, the Company engaged in settlement discussions with Chrimar Systems Inc.  As part of the negotiations the Company determined that it is reasonably possible that a range of loss could be between $0.3 million and $1.4 million which is dependent on a number of factors including whether mutually acceptable settlement terms can be reached. As of March 31, 2013 and through the date of the filing of this Form 10-Q, this matter was still pending.  However, during the quarter ended June 30, 2012 the Company recorded a charge of $0.3 million based on its best estimate of the probable loss.  In addition, during the quarter ending March 31, 2013, venue for the Delaware action was transferred to the United States District Court for the District of Northern California.

- removed (2013-11-04):
[0001078271-13-000020:note_history:13]
Reefedge Networks

- removed (2013-11-04):
[0001078271-13-000020:note_history:14]
On September 17, 2012, Reefedge Networks, LLC filed suit against the Company in the United States District Court for the District of Delaware, Civil Action No. 12-1148. The complaint alleges wrongful use, making, selling, and/or offering to sell products that infringe U.S. Patent Nos. 6,633.761; 6,975,864; and 7,197,308 and seeks unspecified monetary damages and a permanent injunction for products originating from a single supplier to which the Company has submitted an indemnification request. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome. An answer was filed on December 10, 2012. The Company believes it will be fully indemnified for any potential losses related to the suit, as all products are third party designed and manufactured, and the suit is the subject of a third party indemnity and defense agreement.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-11-04):
[0001078271-13-000062:note_history:15]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2013. The results of operations for the three months ended September 30, 2013 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.
  (was, 2013-05-01, similarity 0.6879):
[0001078271-13-000020:note_history:15]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2013. The results of operations for the three and nine months ended March 31, 2013 are not necessarily indicative of the results that may be expected for fiscal 2013 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-11-04):
[0001078271-13-000062:note_history:16]
The Company's revenue is primarily derived from the sale of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.
  (was, 2013-05-01, similarity 0.9932):
[0001078271-13-000020:note_history:16]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2013-11-04):
[0001078271-13-000062:note_history:17]
The Company's revenue is primarily derived from the sale of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.
  (was, 2013-05-01, similarity 0.9932):
[0001078271-13-000020:note_history:17]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2013-11-04):
[0001078271-13-000062:note_history:18]
Acquisition of Enterasys Networks

- added (2013-11-04):
[0001078271-13-000062:note_history:19]
On October 31, 2013, the Company consummated the previously announced acquisition from Enterprise Networks Holdings Inc., of all of the issued and outstanding capital stock of Enterasys Networks, Inc. (“Enterasys”), a privately held provider of wired and wireless network infrastructure and security solutions based in Salem, New Hampshire.  The purchase price paid by the Company was $180 million in cash, consisting of cash on hand and borrowings under a new credit facility. We have agreed to reimburse the sellers on a dollar-for-dollar basis for any cash remaining in Enterasys at the closing.  The purchase price is subject to customary post-closing purchase price adjustments. The purchase of Enterasys has been accounted for as a business combination under the acquisition method.  Enterasys is now a wholly-owned subsidiary of the Company and the results of operations of Enterasys (beginning with the closing date of the acquisition) and the estimated fair value of assets acquired will be included in the Company’s consolidated financial statements beginning in the second quarter of fiscal 2014.

- added (2013-11-04):
[0001078271-13-000062:note_history:20]
Senior Secured Credit Agreement

- added (2013-11-04):
[0001078271-13-000062:note_history:21]
On October 31, 2013, the Company entered into a $125 million senior secured credit facilities agreement consisting of a $65 million term loan facility (“Term loan”) and a revolving credit facility of $60 million (“Revolving facility”).  Both facilities mature on October 31, 2018.  The  proceeds of the Term loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The company drew $35 million of the $60 million Revolving facility to pay fees and expenses incurred in connection with the acquisition and to provide ongoing working capital and for other general corporate purposes. Borrowings under the Term loan and Revolving facility bear interest, at the Company’s election, at a rate per annum equal to an agreed to applicable margin plus (a) the prime rate in effect on such day or (b) Libor. The credit facility contains standard events of default and financial covenants, including those that require the Company to maintain certain leverage and quick and fixed charge coverage ratios.

- removed (2013-11-04):
[0001078271-13-000020:note_history:22]
On April 25, 2013, the Company announced the resignation of Oscar Rodriguez as President and Chief Executive Officer of the Company as well as his resignation from the Board of Directors.   At the same time, the Company announced the appointment of  Mr. Charles W. “Chuck” Berger as its President and Chief Executive Officer, as well as elected him to the Board of Directors, effective as of April 25, 2013.
