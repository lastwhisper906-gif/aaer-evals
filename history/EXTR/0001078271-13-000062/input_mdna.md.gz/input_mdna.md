# EXTR MD&A — 0001078271-13-000062


## mdna

[0001078271-13-000062:mdna:1]
[same as prior period, unchanged from 0001078271-13-000020:mdna:1]

[0001078271-13-000062:mdna:2]
[same as prior period, unchanged from 0001078271-13-000020:mdna:2]

[0001078271-13-000062:mdna:3]
We are a leading provider of network infrastructure equipment and services for enterprises, data centers, and service providers. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. Our corporate headquarters are located in San Jose, California. We develop and sell network infrastructure equipment to our enterprise, data center and telecommunications service provider customers.

[0001078271-13-000062:mdna:4]
We conduct our sales and marketing activities on a worldwide basis through a distribution channel utilizing distributors, resellers and our field sales organization. We primarily sell our products through an ecosystem of channel partners who combine our Ethernet products with their offerings to create compelling information technology solutions for end user customers. We utilize our field sales organization to support our channel partners and to sell direct to end-user customers, including some large global accounts. Our customers include businesses, hospitals, universities, hotels, telecommunications companies and government agencies around the world.

[0001078271-13-000062:mdna:5]
We outsource the majority of our manufacturing and supply chain management operations as part of our strategy to maintain global manufacturing capabilities and to reduce our costs. We conduct quality assurance, manufacturing engineering, document control and test development at engineering facilities in San Jose, California, Research Triangle Park, North Carolina, and Chennai, India. This approach enables us to reduce fixed costs and to quickly respond to changes in market demand.

[0001078271-13-000062:mdna:6]
[same as prior period, unchanged from 0001078271-13-000020:mdna:6]

[0001078271-13-000062:mdna:7]
[same as prior period, unchanged from 0001078271-13-000020:mdna:7]

[0001078271-13-000062:mdna:8]
[same as prior period, unchanged from 0001078271-13-000020:mdna:8]

[0001078271-13-000062:mdna:9]
During the first quarter of fiscal 2014, we achieved the following results:

[0001078271-13-000062:mdna:10]
| • | Net revenues of $75.9 million compared to net revenues of $76.1 million in the first quarter of fiscal 2013. |

[0001078271-13-000062:mdna:11]
| • | Product revenues of $61.0 million compared to product revenues of $61.1 million in the first quarter of fiscal 2013. |

[0001078271-13-000062:mdna:12]
| • | Service revenues of $14.9 million compared to service revenues of $15.0 million in the first quarter of fiscal 2013. |

[0001078271-13-000062:mdna:13]
| • | Total gross margin of 58% of net revenues compared to total gross margin of 53% of net revenues in the first quarter of fiscal 2013. |

[0001078271-13-000062:mdna:14]
| • | Operating income of $0.4 million compared to operating income of $13.6 million in the first quarter of fiscal 2013. |

[0001078271-13-000062:mdna:15]
| • | Net loss of $35,000 compared to net income of $12.9 million in the first quarter of fiscal 2013. |

[0001078271-13-000062:mdna:16]
| • | Cash flow provided by operating activities of $1.9 million in the three months ended September 30, 2013 compared to cash flow provided by operating activities of $7.1 million in the three months ended September 30, 2012. |

[0001078271-13-000062:mdna:17]
| • | Cash and cash equivalents, short-term investments and marketable securities decreased by $6.2 million to $199.4 million as of September 30, 2013 from $205.6 million as of June 30, 2013, primarily due to cash used by operating and investing activities. |

[0001078271-13-000062:mdna:18]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, and Australia. The following table presents the total net revenue geographically for the three months ended September 30, 2013 and September 30, 2012, respectively (dollars in thousands):

[0001078271-13-000062:mdna:19]
|  | Three Months Ended |
| Net Revenues | September 30, 2013 |  | September 30, 2012 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 25,389 |  |  | $ | 25,204 |  |  | $ | 185 |  |  | 0.7 | % |
| Other | 6,301 |  |  | 9,779 |  |  | (3,478 | ) |  | (35.6 | )% |
| Total Americas | 31,690 |  |  | 34,983 |  |  | (3,293 | ) |  | (9.4 | )% |
| Percentage of net revenue | 42.0 | % |  | 46.0 | % |  |  |  |  |
| EMEA | 30,842 |  |  | 28,519 |  |  | 2,323 |  |  | 8.1 | % |
| Percentage of net revenue | 40.6 | % |  | 37.5 | % |  |  |  |  |
| APAC | 13,384 |  |  | 12,625 |  |  | 759 |  |  | 6.0 | % |
| Percentage of net revenue | 17.6 | % |  | 16.6 | % |  |  |  |  |
| Total net revenues | $ | 75,916 |  |  | $ | 76,127 |  |  | $ | (211 | ) |  | (0.3 | )% |

[0001078271-13-000062:mdna:20]
[same as prior period, unchanged from 0001078271-13-000020:mdna:20]

[0001078271-13-000062:mdna:21]
The following table presents net product and service revenue for the three months ended September 30, 2013 and September 30, 2012, respectively (dollars in thousands):

[0001078271-13-000062:mdna:22]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |
| Product | $ | 61,045 |  |  | $ | 61,119 |  |  | $ | (74 | ) |  | (0.1 | )% |
| Percentage of net revenue | 80.4 | % |  | 80.3 | % |  |  |  |  |
| Service | 14,871 |  |  | 15,008 |  |  | (137 | ) |  | (0.9 | )% |
| Percentage of net revenue | 19.6 | % |  | 19.7 | % |  |  |  |  |
| Total net revenues | $ | 75,916 |  |  | $ | 76,127 |  |  | $ | (211 | ) |  | (0.3 | )% |

[0001078271-13-000062:mdna:23]
Product revenue was flat in the first quarter of fiscal 2014 compared to the corresponding period of fiscal 2013. In the three months ending September 30, 2013, we experienced weaker than expected demand from our enterprise customers in the Americas region which was offset by increased demand from our public sector and strategic customers and distributors in the EMEA region.

[0001078271-13-000062:mdna:24]
Service revenue was flat in the first quarter of fiscal 2014 compared to the corresponding period of fiscal 2013.

[0001078271-13-000062:mdna:25]
[same as prior period, unchanged from 0001078271-13-000020:mdna:26]

[0001078271-13-000062:mdna:26]
The following table presents the gross profit on product and service revenue and the gross profit percentage of product and service revenue for the three months ended September 30, 2013 and 2012 (in thousands):

[0001078271-13-000062:mdna:27]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |
| Product | $ | 33,529 |  |  | $ | 30,643 |  |  | $ | 2,886 |  |  | 9.4 | % |
| Percentage of product revenue | 54.9 | % |  | 50.1 | % |  |  |  |  |
| Service | 10,178 |  |  | 9,332 |  |  | 846 |  |  | 9.1 | % |
| Percentage of service revenue | 68.4 | % |  | 62.2 | % |  |  |  |  |
| Total gross profit | $ | 43,707 |  |  | $ | 39,975 |  |  | $ | 3,732 |  |  | 9.3 | % |
| Percentage of net revenue | 57.6 | % |  | 52.5 | % |  |  |  |  |

[0001078271-13-000062:mdna:28]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution in San Jose, California, China, and Taiwan. Accordingly, a significant portion of our cost of product revenue consists of payments to our primary contract manufacturer located in Hsinchu, Taiwan. In addition, we OEM our wireless product line from Motorola.

[0001078271-13-000062:mdna:29]
Product gross margin increased to 54.9% from 50.1% in the first quarter of fiscal 2014 compared to the corresponding periods of fiscal 2013.  The increase in product gross margin for the first quarter of fiscal 2014 was primarily due to favorable product mix and lower excess and obsolete inventory charges as compared to first quarter of fiscal 2013.

[0001078271-13-000062:mdna:30]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross margin increased to 68.4% from 62.2% in the first quarter of fiscal 2014.  The increase in service gross margin was primarily due to lower labor costs from our cost reduction initiatives.

[0001078271-13-000062:mdna:31]
[same as prior period, unchanged from 0001078271-13-000020:mdna:32]

[0001078271-13-000062:mdna:32]
[same as prior period, unchanged from 0001078271-13-000020:mdna:33]

[0001078271-13-000062:mdna:33]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |  | $Change |  | %Change |
| Research and development | $ | 9,937 |  |  | $ | 10,566 |  |  | $ | (629 | ) |  | (6.0 | )% |
| Sales and marketing | 22,694 |  |  | 22,027 |  |  | 667 |  |  | 3.0 | % |
| General and administrative | 6,934 |  |  | 5,357 |  |  | 1,577 |  |  | 29.4 | % |
| Acquisition-related costs | 3,695 |  |  | — |  |  | 3,695 |  |  | 100.0 | % |
| Restructuring charge, net of reversals | 75 |  |  | (10 | ) |  | 85 |  |  | 850.0 | % |
| Gain on sale of campus | — |  |  | (11,537 | ) |  | 11,537 |  |  | (100.0 | )% |
| Total operating expenses | $ | 43,335 |  |  | $ | 26,403 |  |  | $ | 16,932 |  |  | 64.1 | % |
| Operating income | $ | 372 |  |  | $ | 13,572 |  |  | $ | (13,200 | ) |  | (97.3 | )% |

[0001078271-13-000062:mdna:34]
[same as prior period, unchanged from 0001078271-13-000020:mdna:25]

[0001078271-13-000062:mdna:35]
[same as prior period, unchanged from 0001078271-13-000020:mdna:35]

[0001078271-13-000062:mdna:36]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Research and development | 13.1 | % |  | 13.9 | % |
| Sales and marketing | 29.9 | % |  | 28.9 | % |
| General and administrative | 9.1 | % |  | 7.0 | % |
| Acquisition-related costs | 4.9 | % |  | — | % |
| Restructuring charge, net of reversals | 0.1 | % |  | — | % |
| Gain on sale of campus | — | % |  | (15.2 | )% |
| Total operating expenses | 57.1 | % |  | 34.6 | % |
| Operating income | 0.5 | % |  | 17.8 | % |

[0001078271-13-000062:mdna:37]
[same as prior period, unchanged from 0001078271-13-000020:mdna:37]

[0001078271-13-000062:mdna:38]
[same as prior period, unchanged from 0001078271-13-000020:mdna:38]

[0001078271-13-000062:mdna:39]
Research and development expenses decreased by $0.6 million, or 6.0% in the first quarter of fiscal 2014 compared to the corresponding period of fiscal 2013. The decrease in research and development expenses primarily resulted from lower personnel costs from our cost reduction initiatives.

[0001078271-13-000062:mdna:40]
[same as prior period, unchanged from 0001078271-13-000020:mdna:40]

[0001078271-13-000062:mdna:41]
[same as prior period, unchanged from 0001078271-13-000020:mdna:41]

[0001078271-13-000062:mdna:42]
Sales and marketing expenses increased by $0.7 million, or 3.0% in the first quarter of fiscal 2014, compared to the corresponding periods of fiscal 2013. The increase in sales and marketing expenses was primarily due to increased spending on sales and marketing programs.

[0001078271-13-000062:mdna:43]
[same as prior period, unchanged from 0001078271-13-000020:mdna:43]

[0001078271-13-000062:mdna:44]
General and administrative expenses increased by $1.6 million, or 29.4% in the first quarter of fiscal 2014, compared to the corresponding periods of fiscal 2013. The increase in general and administrative expenses during the three months ending September 30, 2013, compared to the corresponding period of fiscal 2013, was primarily due to higher rent and facilities expense of $0.9 million, higher bad debt expense, and higher travel costs in the first quarter of fiscal 2014.  The Company completed the sale of its former corporate campus during first quarter of fiscal 2013.

[0001078271-13-000062:mdna:45]
Acquisition-related Costs

[0001078271-13-000062:mdna:46]
During the first quarter of fiscal 2014, we announced that we had entered into a stock purchase agreement with Enterprise Networks Holdings Inc. to acquire all of the issued and outstanding capital stock of Enterasys Networks Inc.  We incurred $3.7 million of acquisition-related costs during the quarter ended September 30, 2013.

[0001078271-13-000062:mdna:47]
[same as prior period, unchanged from 0001078271-13-000020:mdna:45]

[0001078271-13-000062:mdna:48]
Restructuring charges increased by $0.1 million in the first quarter of fiscal 2014 compared to the corresponding period of fiscal 2013.  During the second quarter of fiscal 2013, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. The Company has substantially expensed all of the costs associated with this initiative.  As of September 30, 2013, we had restructuring liabilities of $0.6 million, which we anticipate paying by the end of fiscal 2015.

[0001078271-13-000062:mdna:49]
[same as prior period, unchanged from 0001078271-13-000020:mdna:49]

[0001078271-13-000062:mdna:50]
[same as prior period, unchanged from 0001078271-13-000020:mdna:50]

[0001078271-13-000062:mdna:51]
[same as prior period, unchanged from 0001078271-13-000020:mdna:51]

[0001078271-13-000062:mdna:52]
Other expense, net decreased by $0.1 million in the first quarter of fiscal 2014, compared to the corresponding period of fiscal 2013.  The change in other expense, net in the first quarter of fiscal 2014, as compared to the same period in fiscal 2013, was primarily due to gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars offsetting other than temporary impairment loss of $148,000, recorded in the first quarter of fiscal 2014.

[0001078271-13-000062:mdna:53]
[same as prior period, unchanged from 0001078271-13-000020:mdna:53]

[0001078271-13-000062:mdna:54]
We recorded an income tax provision of $0.4 million and $0.6 million for the three months ended September 30, 2013 and 2012, respectively.  The income tax provision for the first quarter of fiscal 2014 consisted primarily of taxes on foreign income and U.S state income taxes. The income tax provision for the first quarter of fiscal 2013 consisted primarily of taxes on foreign income and U.S. state income taxes.  The income tax provisions for both quarters were calculated based on the results of operations for the three months ended September 30, 2013 and 2012, and may not reflect the annual effective rate.

[0001078271-13-000062:mdna:55]
We have provided a full valuation allowance against all of our U.S. federal and state deferred tax assets, and no valuation allowance against any of our non-U.S. deferred tax assets. The valuation allowance is determined by assessing both negative and positive evidence to determine whether it is more likely than not that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis. Our inconsistent earnings in recent periods, coupled with our inability to forecast greater than one quarter in advance and the cyclical nature of our business represent sufficient negative evidence to require a full valuation allowance against our U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results and the economic environment have sufficiently improved to support realization of our deferred tax assets.

[0001078271-13-000062:mdna:56]
[same as prior period, unchanged from 0001078271-13-000020:mdna:57]

[0001078271-13-000062:mdna:57]
[same as prior period, unchanged from 0001078271-13-000020:mdna:58]

[0001078271-13-000062:mdna:58]
As discussed in Part II, Item 7, “Management's Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2013, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001078271-13-000062:mdna:59]
[same as prior period, unchanged from 0001078271-13-000020:mdna:60]

[0001078271-13-000062:mdna:60]
[same as prior period, unchanged from 0001078271-13-000020:mdna:61]

[0001078271-13-000062:mdna:61]
[same as prior period, unchanged from 0001078271-13-000020:mdna:62]

[0001078271-13-000062:mdna:62]
[same as prior period, unchanged from 0001078271-13-000020:mdna:63]

[0001078271-13-000062:mdna:63]
[same as prior period, unchanged from 0001078271-13-000020:mdna:64]

[0001078271-13-000062:mdna:64]
[same as prior period, unchanged from 0001078271-13-000020:mdna:65]

[0001078271-13-000062:mdna:65]
[same as prior period, unchanged from 0001078271-13-000020:mdna:66]

[0001078271-13-000062:mdna:66]
| • | Legal Contingencies |

[0001078271-13-000062:mdna:67]
[same as prior period, unchanged from 0001078271-13-000020:mdna:68]

[0001078271-13-000062:mdna:68]
[same as prior period, unchanged from 0001078271-13-000020:mdna:69]

[0001078271-13-000062:mdna:69]
New Accounting Pronouncements

[0001078271-13-000062:mdna:70]
In July 2013, the FASB issued ASU No. 2013-11, Topic 740 - Income Taxes ("ASU 2013-11") which provides guidance to the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013.  The

[0001078271-13-000062:mdna:71]
Company intends to adopt this standard in the first quarter of fiscal 2015 and does not expect the adoption will have an impact on its consolidated financial statements.

[0001078271-13-000062:mdna:72]
[same as prior period, unchanged from 0001078271-13-000020:mdna:70]

[0001078271-13-000062:mdna:73]
[same as prior period, unchanged from 0001078271-13-000020:mdna:71]

[0001078271-13-000062:mdna:74]
|  | September 30, 2013 |  | June 30, 2013 |
| Cash and cash equivalent | $ | 103,008 |  |  | $ | 95,803 |  |
| Short-term investments | 96,427 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total cash and investments | $ | 199,435 |  |  | $ | 205,613 |  |
| Working capital | $ | 170,027 |  |  | $ | 96,279 |  |

[0001078271-13-000062:mdna:75]
As of September 30, 2013, our principal sources of liquidity consisted of cash, cash equivalents and investments of $199.4 million and net accounts receivable of $39.3 million. As of September 30, 2013, we intend to sell our investments in the near term.  We have classified all of our investments as short term investments as of September 30, 2013 even though the stated maturity date may be greater than one year at the balance sheet date. Historically, our principal uses of cash have consisted of the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development, marketing of our products and purchases of property and equipment and repurchases of our common stock. We believe that our $199.4 million of cash and cash equivalents and investments at September 30, 2013 will be sufficient to fund our operating requirements, stock repurchase program, and restructuring expenses for at least the next 12 months as well as for partial payment of the purchase price for the Enterasys acquisition.

[0001078271-13-000062:mdna:76]
The Company has entered into a senior secured credit facility agreement of $125 million to partially pay the purchase price in the acquisition of Enterasys as well as to pay fees and expenses incurred in connection with the acquisition and to provide ongoing working capital and for other general corporate purposes.

[0001078271-13-000062:mdna:77]
[same as prior period, unchanged from 0001078271-13-000020:mdna:74]

[0001078271-13-000062:mdna:78]
[same as prior period, unchanged from 0001078271-13-000020:mdna:75]

[0001078271-13-000062:mdna:79]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Net cash provided by operating activities | $ | 1,925 |  |  | $ | 7,052 |  |
| Net cash provided by investing activities | $ | 3,254 |  |  | $ | 34,031 |  |
| Net cash provided by financing activities | $ | 1,799 |  |  | $ | 593 |  |
| Foreign currency effect on cash | $ | 227 |  |  | $ | 440 |  |
| Net increase in cash and cash equivalents | $ | 7,205 |  |  | $ | 42,116 |  |

[0001078271-13-000062:mdna:80]
[same as prior period, unchanged from 0001078271-13-000020:mdna:77]

[0001078271-13-000062:mdna:81]
Cash flows from operations decreased by $5.1 million in the three months ending September 30, 2013 compared to the corresponding period of fiscal 2013, primarily due to the increase in inventory balance due to timing of inventory receipts to bring the inventory levels in line with the near term demand and an increase in accounts payable balance due to the timing of payments.

[0001078271-13-000062:mdna:82]
[same as prior period, unchanged from 0001078271-13-000020:mdna:79]

[0001078271-13-000062:mdna:83]
Cash flow provided by investing activities in the three months ending September 30, 2013 was $3.3 million, comprised of proceeds of $13.1 million from the maturities of investments, offset by $9.8 million used to purchase property and equipment.

[0001078271-13-000062:mdna:84]
Net Cash Provided by Financing Activities

[0001078271-13-000062:mdna:85]
Cash flow provided by financing activities in the three months ending September 30, 2013 was $1.8 million, comprised of proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-13-000062:mdna:86]
[same as prior period, unchanged from 0001078271-13-000020:mdna:83]

[0001078271-13-000062:mdna:87]
The following summarizes our contractual obligations at September 30, 2013, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-13-000062:mdna:88]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Non-cancellable inventory purchase commitments | $ | 79,964 |  |  | $ | 79,964 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-cancellable operating lease obligations | 34,066 |  |  | 3,301 |  |  | 10,069 |  |  | 7,811 |  |  | 12,885 |  |
| Other liabilities | 3,896 |  |  | 390 |  |  | 775 |  |  | 700 |  |  | 2,031 |  |
| Total contractual cash obligations | $ | 117,926 |  |  | $ | 83,655 |  |  | $ | 10,844 |  |  | $ | 8,511 |  |  | $ | 14,916 |  |

[0001078271-13-000062:mdna:89]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $80.0 million as of September 30, 2013, an increase of $29.9 million from $50.1 million as of June 30, 2013. We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-13-000062:mdna:90]
Non-cancelable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001078271-13-000062:mdna:91]
Other liabilities include the Company's commitments towards specific arrangements other than inventory.

[0001078271-13-000062:mdna:92]
The amounts in the table above exclude $0.3 million of income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of settlement.

[0001078271-13-000062:mdna:93]
We did not have any material commitments for capital expenditures as of September 30, 2013.

[0001078271-13-000062:mdna:94]
[same as prior period, unchanged from 0001078271-13-000020:mdna:89]

[0001078271-13-000062:mdna:95]
We did not have any off-balance sheet arrangements as of September 30, 2013.
