# EXTR notes — 0001078271-13-000062


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-13-000062:notes:1]
[same as prior period, unchanged from 0001078271-13-000020:notes:3]

[0001078271-13-000062:notes:2]
[same as prior period, unchanged from 0001078271-13-000020:notes:4]

[0001078271-13-000062:notes:3]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| September 30, 2013 |  |  |  |  |  |  |  |
| Money market funds | $ | 68,154 |  |  | $ | 68,154 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 96,262 |  |  | 96,427 |  |  | 165 |  |  | — |  |
|  | $ | 164,416 |  |  | $ | 164,581 |  |  | $ | 165 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 68,154 |  |  | $ | 68,154 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 96,262 |  |  | 96,427 |  |  | 165 |  |  | — |  |
|  | $ | 164,416 |  |  | $ | 164,581 |  |  | $ | 165 |  |  | $ | — |  |
| June 30, 2013 |  |  |  |  |  |  |  |
| Money market funds | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 110,078 |  |  | 109,810 |  |  | 126 |  |  | (394 | ) |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 42,994 |  |  | 43,034 |  |  | 44 |  |  | (4 | ) |
| Marketable securities | 67,084 |  |  | 66,776 |  |  | 82 |  |  | (390 | ) |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |

[0001078271-13-000062:notes:4]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at September 30, 2013, by contractual maturity, were as follows (in thousands):

[0001078271-13-000062:notes:5]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 164,416 |  |  | $ | 164,581 |  |
| Total investments in available for sale debt securities | $ | 164,416 |  |  | $ | 164,581 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-13-000062:notes:6]
Commitments and Contingencies

[0001078271-13-000062:notes:7]
Purchase Commitments

[0001078271-13-000062:notes:8]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2013, the Company had non-cancelable commitments to purchase approximately $80.0 million of such inventory.

[0001078271-13-000062:notes:9]
Legal Proceedings

[0001078271-13-000062:notes:10]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-13-000062:notes:11]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-13-000062:notes:12]
Intellectual Property Litigation

[0001078271-13-000062:notes:13]
Chrimar Systems

[0001078271-13-000062:notes:14]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 (the "Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.

[0001078271-13-000062:notes:15]
During the quarter ending March 31, 2013, venue for the Delaware action was transferred to the United States District Court for the District of Northern California.

[0001078271-13-000062:notes:16]
On July 16, 2013, the parties entered into a confidential patent license and settlement agreement (“Agreement”). Pursuant to that Agreement, the Company paid $1.4 million on July 25, 2013 and Chrimar filed for dismissal of the Delaware Action with prejudice on July 29, 2013. All matters between the parties have now been resolved.

[0001078271-13-000062:notes:17]
Relay IP Inc.

[0001078271-13-000062:notes:18]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775. The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on July 15, 2013. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

[0001078271-13-000062:notes:19]
Indemnification Obligations

[0001078271-13-000062:notes:20]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of September 30, 2013, the Company had no outstanding indemnification claims.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-13-000062:notes:21]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net at September 30, 2013 and June 30, 2013, respectively (in thousands):

[0001078271-13-000062:notes:22]
|  | September 30, 2013 |  | June 30, 2013 |
| Deferred services | $ | 37,091 |  |  | $ | 38,003 |  |
| Deferred product and other revenue | 3,145 |  |  | 3,451 |  |
| Total deferred revenue | 40,236 |  |  | 41,454 |  |
| Less: current portion | 32,080 |  |  | 33,184 |  |
| Non-current deferred revenue, net | $ | 8,156 |  |  | $ | 8,270 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-13-000062:notes:23]
[same as prior period, unchanged from 0001078271-13-000020:notes:30]

[0001078271-13-000062:notes:24]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. At September 30, 2013, these forward foreign currency contracts had a notional principal amount of $7.2 million and an immaterial unrealized loss on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-13-000062:notes:25]
Foreign currency transaction gains and losses from operations were a $0.1 million loss for the three months ended September 30, 2013 and a $0.3 million loss for the three months ended September 30, 2012.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-13-000062:notes:26]
[same as prior period, unchanged from 0001078271-13-000020:notes:33]

[0001078271-13-000062:notes:27]
[same as prior period, unchanged from 0001078271-13-000020:notes:34]

[0001078271-13-000062:notes:28]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Cost of product revenue | $ | 102 |  |  | $ | 174 |  |
| Cost of service revenue | 40 |  |  | 159 |  |
| Research and development | 243 |  |  | 727 |  |
| Sales and marketing | 570 |  |  | 432 |  |
| General and administrative | 620 |  |  | 676 |  |
| Total share-based compensation expense | $ | 1,575 |  |  | $ | 2,168 |  |

[0001078271-13-000062:notes:29]
During the three months ended September 30, 2013 and 2012, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial. The income tax benefit for share-based compensation expense was immaterial in the three months ended September 30, 2013 and 2012.

[0001078271-13-000062:notes:30]
The weighted-average grant-date per share fair value of options granted during the three months ended September 30, 2013 and 2012 were $2.24 and $1.85, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended September 30, 2013 and 2012 were $1.07 and $0.87, respectively.

[0001078271-13-000062:notes:31]
The following table summarizes stock option activity under all plans for the three months ended September 30, 2013:

[0001078271-13-000062:notes:32]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2013 | 9,145 |  |  | $ | 3.66 |  |  |  |  |  |
| Granted | 854 |  |  | $ | 4.18 |  |  |  |  |  |
| Exercised | (524 | ) |  | $ | 3.44 |  |  |  |  | $ | 410 |  |
| Cancelled | (390 | ) |  | $ | 3.72 |  |  |  |  |  |
| Options outstanding at September 30, 2013 | 9,085 |  |  | $ | 3.72 |  |  | 4.77 |  | $ | 14,665 |  |
| Exercisable at September 30, 2013 | 4,464 |  |  | $ | 3.21 |  |  | 3.21 |  | $ | 6,550 |  |
| Vested and expected to vest at September 30, 2013 | 8,181 |  |  | $ | 4.58 |  |  | 4.58 |  | $ | 13,010 |  |

[0001078271-13-000062:notes:33]
[same as prior period, unchanged from 0001078271-13-000020:notes:41]

[0001078271-13-000062:notes:34]
[same as prior period, unchanged from 0001078271-13-000020:notes:42]

[0001078271-13-000062:notes:35]
The following table summarizes stock award activity for the three months ended September 30, 2013:

[0001078271-13-000062:notes:36]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2013 | 2,686 |  |  | $ | 3.09 |  |  |  |
| Granted | 130 |  |  | $ | 4.18 |  |  |  |
| Vested | (249 | ) |  | $ | 4.12 |  |  | $ | 1,047 |  |
| Cancelled | (137 | ) |  | $ | 3.53 |  |  |  |
| Non-vested stock outstanding at September 30, 2013 | 2,430 |  |  | $ | 3.01 |  |  |  |

[0001078271-13-000062:notes:37]
The fair value of each option award and share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of performance-based option awards, with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-13-000062:notes:38]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |  | September 30, 2013 |  | September 30, 2012 |
| Expected life | 5 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.53 | % |  | 0.90 | % |  | 0.09 | % |  | 0.06 | % |
| Volatility | 64 | % |  | 66 | % |  | 32 | % |  | 69 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |

[0001078271-13-000062:notes:39]
[same as prior period, unchanged from 0001078271-13-000020:notes:47]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-13-000062:notes:40]
Basic earnings per share is calculated by dividing net income  by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.

[0001078271-13-000062:notes:41]
[same as prior period, unchanged from 0001078271-13-000020:notes:49]


## us-gaap:EarningsPerShareTextBlock

[0001078271-13-000062:notes:42]
Net Income Per Share

[0001078271-13-000062:notes:43]
Basic earnings per share is calculated by dividing net income  by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock. The following table presents the calculation of basic and diluted net income (loss) per share (in thousands, except per share data):

[0001078271-13-000062:notes:44]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Net (loss) income | $ | (35 | ) |  | $ | 12,915 |  |
| Weighted-average shares used in per share calculation – basic | 94,062 |  |  | 94,738 |  |
| Incremental shares using the treasury stock method: |  |  |  |
| Stock options | — |  |  | 356 |  |
| Restricted stock units | — |  |  | 294 |  |
| Employee Stock Purchase Plan | — |  |  | 111 |  |
| Weighted -average share used in per share calculation – diluted | 94,062 |  |  | 95,499 |  |
| Net income per share – basic | $ | 0.00 |  |  | $ | 0.14 |  |
| Net income per share – diluted | $ | 0.00 |  |  | $ | 0.14 |  |

[0001078271-13-000062:notes:45]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For the three months ended September 30, 2013 and 2012, the Company excluded 6.8 million and 7.1 million outstanding weighted average stock options and awards, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-13-000062:notes:46]
[same as prior period, unchanged from 0001078271-13-000020:notes:54]

[0001078271-13-000062:notes:47]
[same as prior period, unchanged from 0001078271-13-000020:notes:57]

[0001078271-13-000062:notes:48]
| September 30, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 68,154 |  |  | $ | — |  |  | $ | — |  |  | $ | 68,154 |  |
| Corporate notes/bonds | — |  |  | 96,427 |  |  | — |  |  | 96,427 |  |
| Total | $ | 68,154 |  |  | $ | 96,427 |  |  | $ | — |  |  | $ | 164,581 |  |
| Liabilities |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | (7 | ) |  | $ | — |  |  | $ | (7 | ) |
| Total | $ | — |  |  | $ | (7 | ) |  | $ | — |  |  | $ | (7 | ) |

[0001078271-13-000062:notes:49]
| June 30, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |  | $ | 54,285 |  |
| Corporate notes/bonds | — |  |  | 109,810 |  |  | — |  |  | 109,810 |  |
| Foreign currency forward contracts | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total | $ | 54,285 |  |  | $ | 109,831 |  |  | $ | — |  |  | $ | 164,116 |  |

[0001078271-13-000062:notes:50]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three months ended September 30, 2013 and 2012.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-13-000062:notes:51]
[same as prior period, unchanged from 0001078271-13-000020:notes:61]

[0001078271-13-000062:notes:52]
[same as prior period, unchanged from 0001078271-13-000020:notes:62]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-13-000062:notes:53]
[same as prior period, unchanged from 0001078271-13-000020:notes:63]

[0001078271-13-000062:notes:54]
The Company recorded an income tax provision of $0.4 million and $0.6 million for the three months ended September 30, 2013 and September 30, 2012, respectively.

[0001078271-13-000062:notes:55]
The income tax provisions for the three months ended September 30, 2013 and 2012 consisted primarily of taxes on foreign income and U.S. state income taxes. The income tax provisions for both fiscal years were calculated based on the results of operations for the three months ended September 30, 2013 and 2012, and may not reflect the annual effective rate.

[0001078271-13-000062:notes:56]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, and no valuation allowance against any of its non-U.S. deferred tax assets. The valuation allowance is determined by assessing both negative and positive evidence to determine whether it is more likely than not that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis. The Company's inconsistent earnings in recent periods, coupled with the Company's inability to forecast greater than one quarter in advance and the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001078271-13-000062:notes:57]
The Company had $10.9 million of unrecognized tax benefits as of September 30, 2013. The future impact of the unrecognized tax benefit of $10.9 million, if recognized, is as follows: approximately $0.3 million would impact the effective tax rate, and approximately $10.6 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.1 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-13-000062:notes:58]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Condensed Consolidated Statements of Operations and were immaterial for both the three months ended September 30, 2013 and 2012. Accrued interest and penalties were $42,000 and $0.1 million as of September 30, 2013 and 2012, respectively.

[0001078271-13-000062:notes:59]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2003 forward due to net operating losses.


## us-gaap:InventoryPolicyTextBlock

[0001078271-13-000062:notes:60]
[same as prior period, unchanged from 0001078271-13-000020:notes:71]

[0001078271-13-000062:notes:61]
[same as prior period, unchanged from 0001078271-13-000020:notes:72]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-13-000062:notes:62]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with original maturities of greater than three months, but less than one year at the balance sheet date are classified as Short Term Investments. Investments with maturities of greater than one year at balance sheet date which the Company intends to hold for longer than one year are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

[0001078271-13-000062:notes:63]
[same as prior period, unchanged from 0001078271-13-000020:notes:74]

[0001078271-13-000062:notes:64]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. As of September 30, 2013, twenty-six out of fifty-three investment securities had unrealized losses. As of September 30, 2013, the Company intends to sell its investments in the near term. Therefore, for investments that were in an unrealized loss position as of September 30, 2013, the Company recorded an other than temporary impairment loss of $148,000 during the three months ended September 30, 2013, and the Company has classified all of its investments as short-term investments as of September 30, 2013 even though their stated maturity date may be greater than one year at the balance sheet date.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-13-000062:notes:65]
Recently Issued Accounting Pronouncements

[0001078271-13-000062:notes:66]
In July 2013, the FASB issued ASU No. 2013-11, Topic 740 - Income Taxes ("ASU 2013-11") which provides guidance to the presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 15, 2013.  The Company intends to adopt this standard in the first quarter of fiscal 2015 and does not expect the adoption will have an impact on its consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-13-000062:notes:67]
[same as prior period, unchanged from 0001078271-13-000020:notes:77]

[0001078271-13-000062:notes:68]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2013 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2013.

[0001078271-13-000062:notes:69]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at September 30, 2013. The results of operations for the three months ended September 30, 2013 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-13-000062:notes:70]
[same as prior period, unchanged from 0001078271-13-000020:notes:80]

[0001078271-13-000062:notes:71]
As part of the Company's on-going restructuring efforts, during the second quarter of fiscal year 2013, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. Restructuring expense was $0.1 million in the three months ended September 30, 2013.  Restructuring expense was not significant in the three months ended September 30, 2012.

[0001078271-13-000062:notes:72]
The following table summarizes restructuring activities for the three months ended September 30, 2013:

[0001078271-13-000062:notes:73]
|  |  | Termination Benefits (1) |  | Contract Termination |  | Other Cost |  | Total |
| Balance at June 30, 2013 |  | $ | 1,217 |  |  | $ | — |  |  | $ | 249 |  |  | $ | 1,466 |  |
| Period charges |  | 103 |  |  | 187 |  |  | 75 |  |  | 365 |  |
| Period reversals |  | (283 | ) |  | (7 | ) |  | — |  |  | (290 | ) |
| Period payments |  | (630 | ) |  | (15 | ) |  | (324 | ) |  | (969 | ) |
| Restructuring liabilities at September 30, 2013 |  | $ | 407 |  |  | $ | 165 |  |  | $ | — |  |  | $ | 572 |  |

[0001078271-13-000062:notes:74]
[same as prior period, unchanged from 0001078271-13-000020:notes:84]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-13-000062:notes:75]
[same as prior period, unchanged from 0001078271-13-000020:notes:86]

[0001078271-13-000062:notes:76]
The Company's revenue is primarily derived from the sale of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-13-000062:notes:77]
[same as prior period, unchanged from 0001078271-13-000020:notes:88]

[0001078271-13-000062:notes:78]
[same as prior period, unchanged from 0001078271-13-000020:notes:89]


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-13-000062:notes:79]
[same as prior period, unchanged from 0001078271-13-000020:notes:90]

[0001078271-13-000062:notes:80]
[same as prior period, unchanged from 0001078271-13-000020:notes:91]

[0001078271-13-000062:notes:81]
|  | September 30, 2013 |  | June 30, 2013 |
| Cash | $ | 34,854 |  |  | $ | 41,518 |  |
| Cash equivalents | $ | 68,154 |  |  | $ | 54,285 |  |
| Short-term investments | 96,427 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total available-for-sale | $ | 164,581 |  |  | $ | 164,095 |  |
| Total cash and available for sale securities | $ | 199,435 |  |  | $ | 205,613 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-13-000062:notes:82]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2013 and 2012:

[0001078271-13-000062:notes:83]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Balance beginning of period | $ | 3,296 |  |  | $ | 2,871 |  |
| New warranties issued | 1,304 |  |  | 1,561 |  |
| Warranty expenditures | (1,160 | ) |  | (1,461 | ) |
| Balance end of period | $ | 3,440 |  |  | $ | 2,971 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-13-000062:notes:84]
The Company attributes revenues to geographic regions primarily based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001078271-13-000062:notes:85]
|  | Three Months Ended |
| Net Revenues: | September 30, 2013 |  | September 30, 2012 |
| Americas: |  |  |  |
| United States | $ | 25,389 |  |  | $ | 25,204 |  |
| Other | 6,301 |  |  | 9,779 |  |
| Total Americas | 31,690 |  |  | 34,983 |  |
| EMEA | 30,842 |  |  | 28,519 |  |
| APAC | 13,384 |  |  | 12,625 |  |
| Total net revenues | $ | 75,916 |  |  | $ | 76,127 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-13-000062:notes:86]
The following table sets forth major customers accounting for 10% or more of our net revenue:

[0001078271-13-000062:notes:87]
|  |  | Three Months Ended |
|  |  | September 30, 2013 |  | September 30, 2012 |
| Westcon Group Inc. |  | 18 | % |  | 15 | % |
| Scansource, Inc. |  | 14 | % |  | 12 | % |
| Tech Data |  | * |  |  | 10 | % |
| * Less than 10% of revenue |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-13-000062:notes:88]
[same as prior period, unchanged from 0001078271-13-000020:notes:99]

[0001078271-13-000062:notes:89]
[same as prior period, unchanged from 0001078271-13-000020:notes:100]

[0001078271-13-000062:notes:90]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, and Australia.

[0001078271-13-000062:notes:91]
Substantially all of the Company’s assets were attributable to North America operations at September 30, 2013 and June 30, 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-13-000062:notes:92]
[same as prior period, unchanged from 0001078271-13-000020:notes:103]


## us-gaap:SubsequentEventsTextBlock

[0001078271-13-000062:notes:93]
Subsequent Events

[0001078271-13-000062:notes:94]
Acquisition of Enterasys Networks

[0001078271-13-000062:notes:95]
On October 31, 2013, the Company consummated the previously announced acquisition from Enterprise Networks Holdings Inc., of all of the issued and outstanding capital stock of Enterasys Networks, Inc. (“Enterasys”), a privately held provider of wired and wireless network infrastructure and security solutions based in Salem, New Hampshire.  The purchase price paid by the Company was $180 million in cash, consisting of cash on hand and borrowings under a new credit facility. We have agreed to reimburse the sellers on a dollar-for-dollar basis for any cash remaining in Enterasys at the closing.  The purchase price is subject to customary post-closing purchase price adjustments. The purchase of Enterasys has been accounted for as a business combination under the acquisition method.  Enterasys is now a wholly-owned subsidiary of the Company and the results of operations of Enterasys (beginning with the closing date of the acquisition) and the estimated fair value of assets acquired will be included in the Company’s consolidated financial statements beginning in the second quarter of fiscal 2014.

[0001078271-13-000062:notes:96]
Senior Secured Credit Agreement

[0001078271-13-000062:notes:97]
On October 31, 2013, the Company entered into a $125 million senior secured credit facilities agreement consisting of a $65 million term loan facility (“Term loan”) and a revolving credit facility of $60 million (“Revolving facility”).  Both facilities mature on October 31, 2018.  The  proceeds of the Term loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The company drew $35 million of the $60 million Revolving facility to pay fees and expenses incurred in connection with the acquisition and to provide ongoing working capital and for other general corporate purposes. Borrowings under the Term loan and Revolving facility bear interest, at the Company’s election, at a rate per annum equal to an agreed to applicable margin plus (a) the prime rate in effect on such day or (b) Libor. The credit facility contains standard events of default and financial covenants, including those that require the Company to maintain certain leverage and quick and fixed charge coverage ratios.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-13-000062:notes:98]
[same as prior period, unchanged from 0001078271-13-000020:notes:106]

[0001078271-13-000062:notes:99]
[same as prior period, unchanged from 0001078271-13-000020:notes:107]

[0001078271-13-000062:notes:100]
[same as prior period, unchanged from 0001078271-13-000020:notes:108]

[0001078271-13-000062:notes:101]
[same as prior period, unchanged from 0001078271-13-000020:notes:110]

[0001078271-13-000062:notes:102]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Balance beginning of period | $ | 38,003 |  |  | $ | 37,461 |  |
| New support arrangements | 13,343 |  |  | 12,537 |  |
| Recognition of support revenue | (14,255 | ) |  | (14,337 | ) |
| Balance end of period | 37,091 |  |  | 35,661 |  |
| Less: current portion | 28,935 |  |  | 28,377 |  |
| Non-current deferred revenue | $ | 8,156 |  |  | $ | 7,284 |  |

[0001078271-13-000062:notes:103]
[same as prior period, unchanged from 0001078271-13-000020:notes:112]

[0001078271-13-000062:notes:104]
[same as prior period, unchanged from 0001078271-13-000020:notes:113]

[0001078271-13-000062:notes:105]
The amount shown as “Deferred distributors revenue, net of cost of sales to distributors” represents the deferred gross margin on sales to distributors based on contractual pricing.  Distributors purchase products from the Company at a contractual discount based on geographic region and resell the Company's products at a very broad range of individually negotiated price points depending on competitive factors and other market conditions.  A portion of the deferred revenue balance represents an amount of the distributors' original purchase price that will be remitted back to the distributors after resale transactions are reported to the Company. Therefore, the amount of gross margin the Company will recognize in future periods from distributor sales will be less than the deferred amount recorded for the original sale to the distributor as a result of the price concessions negotiated at the time of sell-through. The wide range and variability of negotiated price credits granted to distributors do not allow the Company to accurately estimate the portion of the balance in the deferred revenue that will be credited to the distributors in the future. Therefore, the Company does not reduce deferred revenue by anticipated future price credits; instead, price credits are recorded against revenue and accounts receivable when incurred, which is generally at the time the distributor sells the product.

[0001078271-13-000062:notes:106]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at September 30, 2013 and June 30, 2013, respectively (in thousands):

[0001078271-13-000062:notes:107]
|  | September 30, 2013 |  | June 30, 2013 |
| Deferred distributors revenue | $ | 23,961 |  |  | $ | 22,411 |  |
| Deferred cost of sales to distributors | (5,361 | ) |  | (5,023 | ) |
| Deferred distributors revenue, net of cost of sales to distributors | $ | 18,600 |  |  | $ | 17,388 |  |

[0001078271-13-000062:notes:108]
[same as prior period, unchanged from 0001078271-13-000020:notes:117]

[0001078271-13-000062:notes:109]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2013 and 2012:

[0001078271-13-000062:notes:110]
[same as prior period, unchanged from 0001078271-13-000020:notes:119]

[0001078271-13-000062:notes:111]
[same as prior period, unchanged from 0001078271-13-000020:notes:120]

[0001078271-13-000062:notes:112]
[same as prior period, unchanged from 0001078271-13-000020:notes:121]

[0001078271-13-000062:notes:113]
[same as prior period, unchanged from 0001078271-13-000020:notes:122]


## us-gaap:TreasuryStockTextBlock

[0001078271-13-000062:notes:114]
[same as prior period, unchanged from 0001078271-13-000020:notes:127]

[0001078271-13-000062:notes:115]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which may be purchased over a three year period in the open market or in privately negotiated transactions. Since the inception of the program, 4.1 million shares have been repurchased and $60.5 million of the authorized amount is remaining. All repurchased shares will be retired and included in the Company's authorized but unissued shares. During the three months ended September 30, 2013, the Company did not repurchase any common stock.
