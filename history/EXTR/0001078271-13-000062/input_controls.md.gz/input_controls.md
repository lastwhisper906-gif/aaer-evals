# EXTR 10-Q controls and the auditor's report


## item_4_controls

[0001078271-13-000062:item_4_controls:1]
| Item 4. | Controls and Procedures |

[0001078271-13-000062:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001078271-13-000062:item_4_controls:3]
Disclosure controls and procedures are controls and procedures designed to reasonably assure that information required to be disclosed in our reports filed under the Securities Exchange Act of 1934 as amended, such as this Report, is recorded, processed, summarized and reported within the time periods specified in the SEC's rules and forms and to reasonably assure that such information is accumulated and communicated to our management, including the Chief Executive Officer (“CEO”) and the Chief Financial Officer (“CFO”), as appropriate to allow timely decisions regarding required disclosure.

[0001078271-13-000062:item_4_controls:4]
Under the supervision and with the participation of our management, including our CEO and CFO, we evaluated the effectiveness of the design and operation of our disclosure controls and procedures as of the end of the period covered by this Report. Based on this evaluation, our CEO and CFO concluded that our disclosure controls and procedures were effective as of the end of the period covered by this Report.

[0001078271-13-000062:item_4_controls:5]
Management's Report on Internal Control over Financial Reporting

[0001078271-13-000062:item_4_controls:6]
Our management is responsible for establishing and maintaining adequate internal control over our financial reporting. There are inherent limitations in the effectiveness of any system of internal control, including the possibility of human error and the circumvention or overriding of controls. Accordingly, even effective internal controls can provide only reasonable assurances with respect to financial statement preparation. Further because of changes in conditions, the effectiveness of internal control may vary over time.

[0001078271-13-000062:item_4_controls:7]
We assessed the effectiveness of our internal control over financial reporting as of the end of the period covered by this Report. In making this assessment, we used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control-Integrated Framework.

[0001078271-13-000062:item_4_controls:8]
Based on our assessment using those criteria, we concluded that, as of the end of the period covered by this Report, our internal control over financial reporting is effective.

[0001078271-13-000062:item_4_controls:9]
Changes in Internal Control over Financial Reporting

[0001078271-13-000062:item_4_controls:10]
There were no changes in our internal control over financial reporting during the quarter ended September 30, 2013 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001078271-13-000062:item_4_controls:11]
Inherent Limitations on Effectiveness of Controls

[0001078271-13-000062:item_4_controls:12]
Our management, including the CEO and CFO, does not expect that our disclosure controls or our internal control over financial reporting will prevent or detect all error and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system's objectives will be met. Our controls and procedures are designed to provide reasonable assurance that our control system's objective will be met and our CEO and CFO have concluded that our disclosure controls and procedures are effective at the reasonable assurance level. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs. Further, because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within Extreme Networks have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events. Projections of any evaluation of the effectiveness of controls in future periods are subject to risks. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Notwithstanding these limitations, our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives. Our CEO and CFO have concluded that our disclosure controls and procedures are, in fact, effective at the “reasonable assurance” level.

[0001078271-13-000062:item_4_controls:13]
27
