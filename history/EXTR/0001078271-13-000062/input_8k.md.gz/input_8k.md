# EXTR 8-K — 0001078271-13-000060 filed 2013-11-04

## item codes, every 8-K on or before 2013-11-04

- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2013-11-04

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-13-000060:8k_2_02:1]
EX-99.1
2
extr8kq114ex991.htm
PRESS RELEASE

[0001078271-13-000060:8k_2_02:2]
EXTR 8K Q1'14 EX 99.1

[0001078271-13-000060:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-13-000060:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-13-000060:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2014 Financial Results

[0001078271-13-000060:8k_2_02:6]
Completes Acquisition of Enterasys Networks for $180M; Immediately accretive to non-GAAP EPS

[0001078271-13-000060:8k_2_02:7]
Q1 Revenue: $75.9 million, flat compared to the prior year

[0001078271-13-000060:8k_2_02:8]
GAAP EPS: Breakeven

[0001078271-13-000060:8k_2_02:9]
Non-GAAP EPS: $0.06, increased $0.02 compared to the prior year

[0001078271-13-000060:8k_2_02:10]
SAN JOSE, Calif., November 4, 2013/PRNewswire/ -- Extreme Networks, Inc. (Nasdaq: EXTR) today announced revenue of $75.9 million for its first quarter of fiscal 2014 ending September 30, 2013. This represents a 0.3% decrease compared to revenue of $76.1 million reported for the first quarter of fiscal 2013 and a 4.5% decrease compared to the fourth quarter of fiscal 2013. GAAP net income / loss for the first quarter was approximately breakeven, which includes $3.7 million expense related to Enterasys Networks acquisition, and is a decrease year-over-year compared to GAAP net income of $12.9 million, or $0.14 per diluted share, for the first quarter of fiscal 2013.  The prior year included a $11.5 million one-time gain on the sale of facilities. On a non-GAAP basis, net income for the first quarter of fiscal 2014 was $5.3 million, or $0.06 per diluted share, compared to non-GAAP net income for the first quarter of fiscal 2013 of $3.5 million, or $0.04 per diluted share.

[0001078271-13-000060:8k_2_02:11]
“Extreme’s first quarter results were at the high end of guidance on both revenue and earnings per share,” said Chuck Berger, president and CEO for Extreme Networks.  “We are pleased with these results in light of product shortages that persisted for most of the quarter, seasonally slow July and August demand, and the announcement of our acquisition of Enterasys in mid-September.  We extended our position in the sports venue market with wins at the Philadelphia Eagles, Lincoln Financial Field and the NBA’s Carolina Bobcats, at the Time Warner Cable Arena.  The Company added alliances with Aviat Networks, who will use Extreme switches and routers in their microwave networking solutions, and Silicon Graphics Corp. who will deploy Extreme switches in their high performance data center solutions, particularly for cloud and big data applications.

[0001078271-13-000060:8k_2_02:12]
“Extreme Networks announced the completion of the acquisition of Enterasys Networks on November 1st.  The combined company ranks fourth in the Ethernet switching market share with the scale to increase investment in product development, demand generation, and industry leading customer service and support.  We have already made considerable progress towards integrating the two companies including establishing the executive leadership team.  Chris Crowell, formerly CEO of Enterasys, has accepted the position of COO and will be directly responsible for sales and marketing.  Chris brings extensive experience in the networking industry, exceptional leadership and a close relationship with the Enterasys customer base and partner community.”

[0001078271-13-000060:8k_2_02:13]
Fiscal Q1 2014 Financial Metrics:

[0001078271-13-000060:8k_2_02:14]
|  |  | First Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2014 |  | 2013 |  | Change |
| Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 61.0 |  |  | $ | 61.1 |  |  | $ | (0.1 | ) |  | (0.2 | )% |
| Service |  | $ | 14.9 |  |  | $ | 15.0 |  |  | $ | (0.1 | ) |  | (0.7 | )% |
| Total Net Revenue |  | $ | 75.9 |  |  | $ | 76.1 |  |  | $ | (0.2 | ) |  | (0.3 | )% |
| GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 58 | % |  | 53 | % |  | 5 | % |  |  |
| Operating Margin/Loss |  | 1 | % |  | 18 | % |  | (17 | )% |  |  |
| Net Income |  | $ | — |  |  | $ | 12.9 |  |  | $ | (12.9 | ) |  |  |
| Earnings per diluted share |  | $ | — |  |  | $ | 0.14 |  |  | $ | (0.14 | ) |  |  |
| Non-GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 58 | % |  | 53 | % |  | 5 | % |  |  |
| Operating Margin |  | 8 | % |  | 6 | % |  | 2 | % |  |  |
| Net Income |  | $ | 5.3 |  |  | $ | 3.5 |  |  | $ | 1.8 |  |  |  |
| Earnings per diluted share |  | $ | 0.06 |  |  | $ | 0.04 |  |  | $ | 0.02 |  |  |  |

[0001078271-13-000060:8k_2_02:15]
| • | Gross margin for Q1 was 58%, an increase of 5 percentage points year over year and 3 percentage points quarter over quarter. |

[0001078271-13-000060:8k_2_02:16]
| • | Cash and investments ended the quarter at $199.4 million, as compared to $205.6 million from Q4 of fiscal 2013. |

[0001078271-13-000060:8k_2_02:17]
| • | Accounts receivable balance ending Q1 was $39.3 million, a (net) decrease of $8.3 million from Q4 of fiscal 2013, with days sales outstanding (DSO) of 47, a decrease of 7 days from Q4 of fiscal 2013. |

[0001078271-13-000060:8k_2_02:18]
| • | Inventory ending Q1 was $30.4 million, a (net) increase of $14.2 million from Q4 of fiscal 2013 and represents 99 days of inventory (DOI), an increase of 52 days from Q4 of fiscal 2013. |

[0001078271-13-000060:8k_2_02:19]
Recent Business Highlights:

[0001078271-13-000060:8k_2_02:20]
| • | Extreme Networks completed the acquisition of Enterasys Networks for $180 million on October 31, 2013. The company also entered into a 5 year $125 million credit facility and drew $65 million in term debt and $35 million in revolver debt for the acquisition and fund general corporate obligations. |

[0001078271-13-000060:8k_2_02:21]
| • | Christopher Crowell, the Enterasys Networks CEO has joined Extreme Networks as its COO. |

[0001078271-13-000060:8k_2_02:22]
| • | Extreme Networks and Enterasys Networks’ L2/3 Ethernet switch revenues during Q2 CY13 combined for #4 in overall market share among leading vendors, according to statistics from the Dell’Oro Group’s 1Q13 L2/3 Ethernet market share report. |

[0001078271-13-000060:8k_2_02:23]
| • | Extreme will equip 12 data centers being built by the Brazilian government to support the upcoming World Cup and Summer Olympic events. |

[0001078271-13-000060:8k_2_02:24]
| • | The Philadelphia Eagles select Extreme to provide wireless access to fans at the Lincoln Financial Field. |

[0001078271-13-000060:8k_2_02:25]
| • | The USGA deployed Extreme switches to provide networking for summer golf events. |

[0001078271-13-000060:8k_2_02:26]
| • | The Carolina Bobcats select Extreme to outfit high performance connectivity at the Time Warner Arena. |

[0001078271-13-000060:8k_2_02:27]
| • | Aviat Networks signed a reseller agreement, including Extreme switches and routers in their microwave networking solutions |

[0001078271-13-000060:8k_2_02:28]
| • | Silicon Graphics (SGI) will resell Extreme switches along with their high performance datacenter solutions, focusing on cloud and big data applications. |

[0001078271-13-000060:8k_2_02:29]
| • | Analyst firm Crehan Research reported that Extreme’s growth in purpose-built datacenter switch ports (10/40/100gbe) was double that of industry (Q2 CY’13). |

[0001078271-13-000060:8k_2_02:30]
Business Outlook:

[0001078271-13-000060:8k_2_02:31]
Financial targets for the second fiscal quarter reflect the acquisition of Enterasys Networks on October 31, 2013, and will include Enterasys results for the months of November and December. For its second quarter of fiscal 2014 ending December 31, 2013, the company is targeting GAAP revenue in a range of $140 million to $155 million with non-GAAP revenue in a range of $145 million to $160 million.  GAAP gross margin is targeted in a range of 47% to 48% and non-GAAP gross margin targeted to be 54% to 56%. Operating expenses are targeted to be between $75 and $81 million on a GAAP basis and $65 million to $71 million on a non-GAAP basis. GAAP net loss is targeted to be between $6 million to $8 million, or $0.06 to $0.09 per diluted share. Non-GAAP net income is targeted in a range of $13 million to $16 million, or $0.14 to $0.16 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 96 million +/- diluted weighted average shares. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition related expenses and the step-up value of the acquired inventory and the purchase accounting value related to deferred service revenue.

[0001078271-13-000060:8k_2_02:32]
Financial Model Targets:

[0001078271-13-000060:8k_2_02:33]
The company is targeting a quarterly financial model of operating at a non-GAAP operating income of 10% +/-, by the end of fiscal 2015.  To achieve this goal, the company intends to focus on completing the integration of the two companies into one entity and growing its revenue with high performing and lower cost products and services.

[0001078271-13-000060:8k_2_02:34]
The schedules attached to this release are an integral part of the release.

[0001078271-13-000060:8k_2_02:35]
Conference Call:

[0001078271-13-000060:8k_2_02:36]
Extreme Networks will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the highlights of the first fiscal quarter 2014 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be

[0001078271-13-000060:8k_2_02:37]
available on the website through November 18th, 2013.  The conference call may also be heard by dialing 1-877-303-9826 (international callers' dial 1-224-357 2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release.

[0001078271-13-000060:8k_2_02:38]
About Extreme Networks:

[0001078271-13-000060:8k_2_02:39]
Extreme Networks, Inc. sets the new standard for superior customer experience by delivering network-powered innovation and best-in-class service and support. The company delivers high-performance switching and routing products for data center and core-to-edge networks, wired/wireless LAN access, and unified network management and control.  Our award-winning solutions include software-defined networking (SDN), cloud and high-density Wi-Fi, BYOD and enterprise mobility, identity access management and security.  Extreme Networks is headquartered in San Jose, CA and has more than 12,000 customers in over 80 countries.

[0001078271-13-000060:8k_2_02:40]
For more information, visit the company's website at http://www.extremenetworks.com.

[0001078271-13-000060:8k_2_02:41]
Non-GAAP Financial Measures:

[0001078271-13-000060:8k_2_02:42]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). To supplement its consolidated financial statements presented in accordance with GAAP, the Company is also providing with this press release non-GAAP net income/(loss) and non-GAAP operating income/(loss). In preparing non-GAAP information, the company has excluded, where applicable, the impact of restructuring charges, share-based compensation and litigation settlements.  The company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the company and the company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the company's operating activities with the company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the company’s historical performance and in planning its future business activities. Please note that the company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the company presents should be considered in conjunction with, and not as a substitute for, the company’s financial information presented in accordance with GAAP.  The company has provided a non-GAAP reconciliation of the Condensed Consolidated Statement of Operations for the periods presented in this release, which are adjusted to exclude restructuring charges, share-based compensation expense, acquisition-related costs and gain on sale of facilities for these periods. These measures should only be used to evaluate the company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-13-000060:8k_2_02:43]
Forward Looking Statements:

[0001078271-13-000060:8k_2_02:44]
Actual results, including with respect to the company’s financial targets and general business prospects, could differ materially due to a number of factors, including the risk that the company may not obtain sufficient orders to achieve targeted revenues for the company's products and services given both increasing price competition in key network switching equipment markets and the need to align the company’s cost structure to meet the company’s financial goals; the company’s effectiveness in controlling expenses, the risk that it or its distributors and other channel partners are not able to develop and expand customer bases and accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it

[0001078271-13-000060:8k_2_02:45]
experiences wide fluctuations in supply and demand; the risk that its results will suffer if it is unable to balance fluctuations in customer demand and capacity; risks associated with the ramp-up of production of its new products and its entry into new business channels different from those in which it has historically operated; the risk that it may experience production delays that preclude it from shipping sufficient quantities to meet customer orders or that result in higher production costs and lower margins; ongoing uncertainty in global economic conditions, infrastructure development or customer demand that could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; its ability to complete development and commercialization of products under development, such as its pipeline of new network switches and related software; its ability to lower costs; risks resulting from the concentration of business among few customers, including the risk that customers may reduce or cancel orders or fail to honor purchase commitments; the rapid development of new technology and competing products that may impair demand or render its products obsolete; the potential lack of customer acceptance for new products; and risks associated with ongoing litigation; a dependency on third parties for certain components and for the manufacturing of the company's products and our ability to receive the anticipated benefits of the acquisition of Enterasys; the ability to meet and effectively manage the Company’s debt obligations. More information about potential factors that could affect the company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission. Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-13-000060:8k_2_02:46]
EXTREME NETWORKS, INC.

[0001078271-13-000060:8k_2_02:47]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-13-000060:8k_2_02:48]
(In thousands, except share and per share amounts)

[0001078271-13-000060:8k_2_02:49]
(Unaudited)

[0001078271-13-000060:8k_2_02:50]
|  | September 30, 2013 |  | June 30, 2013 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 103,008 |  |  | $ | 95,803 |  |
| Short-term investments | 96,427 |  |  | 43,034 |  |
| Accounts receivable, net of allowances of $1,088 at September 30, 2013 and $1,252 at June 30, 2013 | 39,297 |  |  | 47,642 |  |
| Inventories | 30,389 |  |  | 16,167 |  |
| Deferred income taxes | 408 |  |  | 386 |  |
| Prepaid expenses and other current assets | 11,712 |  |  | 5,749 |  |
| Total current assets | 281,241 |  |  | 208,781 |  |
| Property and equipment, net | 25,807 |  |  | 23,644 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Intangible assets, net | 3,957 |  |  | 4,243 |  |
| Other assets, net | 7,965 |  |  | 7,980 |  |
| Total assets | $ | 318,970 |  |  | $ | 311,424 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 28,451 |  |  | $ | 27,163 |  |
| Accrued compensation and benefits | 12,957 |  |  | 13,503 |  |
| Restructuring liabilities | 572 |  |  | 1,466 |  |
| Accrued warranty | 3,440 |  |  | 3,296 |  |
| Deferred revenue, net | 32,080 |  |  | 33,184 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 18,600 |  |  | 17,388 |  |
| Other accrued liabilities | 15,114 |  |  | 16,502 |  |
| Total current liabilities | 111,214 |  |  | 112,502 |  |
| Deferred revenue, less current portion | 8,156 |  |  | 8,270 |  |
| Other long-term liabilities | 6,582 |  |  | 1,507 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 193,018 |  |  | 189,145 |  |
| Total liabilities and stockholders’ equity | $ | 318,970 |  |  | $ | 311,424 |  |

[0001078271-13-000060:8k_2_02:51]
EXTREME NETWORKS, INC.

[0001078271-13-000060:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-13-000060:8k_2_02:53]
(In thousands, except per share amounts)

[0001078271-13-000060:8k_2_02:54]
(Unaudited)

[0001078271-13-000060:8k_2_02:55]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Net revenues: |  |  |  |
| Product | $ | 61,045 |  |  | $ | 61,119 |  |
| Service | 14,871 |  |  | 15,008 |  |
| Total net revenues | 75,916 |  |  | 76,127 |  |
| Cost of revenues: |  |  |  |
| Product | 27,516 |  |  | 30,476 |  |
| Service | 4,693 |  |  | 5,676 |  |
| Total cost of revenues | 32,209 |  |  | 36,152 |  |
| Gross profit: |  |  |  |
| Product | 33,529 |  |  | 30,643 |  |
| Service | 10,178 |  |  | 9,332 |  |
| Total gross profit | 43,707 |  |  | 39,975 |  |
| Operating expenses: |  |  |  |
| Research and development | 9,937 |  |  | 10,566 |  |
| Sales and marketing | 22,694 |  |  | 22,027 |  |
| General and administrative | 6,934 |  |  | 5,357 |  |
| Acquisition-related costs | 3,695 |  |  | — |  |
| Restructuring charge (credit), net of reversals | 75 |  |  | (10 | ) |
| Gain on sale of facilities | — |  |  | (11,537 | ) |
| Total operating expenses | 43,335 |  |  | 26,403 |  |
| Operating income | 372 |  |  | 13,572 |  |
| Interest income | 275 |  |  | 269 |  |
| Interest expense | — |  |  | (1 | ) |
| Other expense, net | (255 | ) |  | (348 | ) |
| Income before income taxes | 392 |  |  | 13,492 |  |
| Provision for income taxes | 427 |  |  | 577 |  |
| Net (loss) income | $ | (35 | ) |  | $ | 12,915 |  |
| Basic and diluted net income per share: |  |  |  |
| Net income per share - basic | $ | — |  |  | $ | 0.14 |  |
| Net income per share - diluted | $ | — |  |  | $ | 0.14 |  |
| Shares used in per share calculation - basic | 94,062 |  |  | 94,738 |  |
| Shares used in per share calculation - diluted | 94,062 |  |  | 95,499 |  |

[0001078271-13-000060:8k_2_02:56]
EXTREME NETWORKS, INC.

[0001078271-13-000060:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-13-000060:8k_2_02:58]
(In thousands)

[0001078271-13-000060:8k_2_02:59]
(Unaudited)

[0001078271-13-000060:8k_2_02:60]
|  | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Net cash provided by operating activities | $ | 1,925 |  |  | $ | 7,052 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (9,808 | ) |  | (1,562 | ) |
| Purchases of investments | — |  |  | (7,066 | ) |
| Proceeds from maturities of investments and marketable securities | 13,062 |  |  | — |  |
| Proceeds from sales of facilities | — |  |  | 42,659 |  |
| Net cash provided by investing activities | 3,254 |  |  | 34,031 |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of common stock | 1,799 |  |  | 593 |  |
| Net cash provided by financing activities | 1,799 |  |  | 593 |  |
| Foreign currency effect on cash | 227 |  |  | 440 |  |
| Net increase in cash and cash equivalents | 7,205 |  |  | 42,116 |  |
| Cash and cash equivalents at beginning of period | 95,803 |  |  | 54,596 |  |
| Cash and cash equivalents at end of period | $ | 103,008 |  |  | $ | 96,712 |  |

[0001078271-13-000060:8k_2_02:61]
Extreme Networks, Inc.

[0001078271-13-000060:8k_2_02:62]
Non-GAAP Measures of Financial Performance

[0001078271-13-000060:8k_2_02:63]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-13-000060:8k_2_02:64]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition-related costs, restructuring expenses and gains related to the sale of the Santa Clara campus.

[0001078271-13-000060:8k_2_02:65]
Non-GAAP measures presented in this press release are not in accordance with or an alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-13-000060:8k_2_02:66]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-13-000060:8k_2_02:67]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, acquisition-related expenses,  restructuring expenses and gains related to the sale of the Santa Clara campus.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-13-000060:8k_2_02:68]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-13-000060:8k_2_02:69]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-13-000060:8k_2_02:70]
Acquisition-related costs. Acquisition-related costs primarily consist of legal and professional fees and other expenses related to the acquisition of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-13-000060:8k_2_02:71]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-13-000060:8k_2_02:72]
Gains related to the sale of facilities.  The one-time net gain related to the sale of the Santa Clara campus consists of the gross proceeds of the sale less the expenses directly related to the sale such as commissions, closing costs and legal fees.  Extreme Networks excludes this gain because it is a one-time event and does not believe that the gain is reflective of ongoing operations.

[0001078271-13-000060:8k_2_02:73]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total

[0001078271-13-000060:8k_2_02:74]
increases or decrease in the Company's cash balance for the period.

[0001078271-13-000060:8k_2_02:75]
EXTREME NETWORKS, INC.

[0001078271-13-000060:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-13-000060:8k_2_02:77]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-13-000060:8k_2_02:78]
(In thousands, except per share amounts)

[0001078271-13-000060:8k_2_02:79]
(Unaudited)

[0001078271-13-000060:8k_2_02:80]
| Non-GAAP Gross Margin | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Gross profit - GAAP Basis | $ | 43,707 |  |  | $ | 39,975 |  |
| Gross margin - GAAP Basis percentage | 57.6 | % |  | 52.5 | % |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 142 |  |  | $ | 333 |  |
| Gross profit - Non-GAAP Basis | $ | 43,849 |  |  | $ | 40,308 |  |
| Gross margin - Non-GAAP Basis percentage | 57.8 | % |  | 52.9 | % |
| Non-GAAP Operating Income | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| GAAP operating income | $ | 372 |  |  | $ | 13,572 |  |
| GAAP operating income percentage | 0.5 | % |  | 17.8 | % |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 1,575 |  |  | $ | 2,169 |  |
| Acquisition-related costs | $ | 3,695 |  |  | $ | — |  |
| Restructuring charge, net of reversals | $ | 75 |  |  | $ | (10 | ) |
| Gain on sale of facilities | $ | — |  |  | $ | (11,537 | ) |
| Total adjustments to GAAP operating income | $ | 5,345 |  |  | $ | (9,378 | ) |
| Non-GAAP operating income | $ | 5,717 |  |  | $ | 4,194 |  |
| Non-GAAP operating income percentage | 7.5 | % |  | 5.5 | % |
| Non-GAAP Net Income | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| GAAP net income | $ | (35 | ) |  | $ | 12,915 |  |
| Adjustments: |  |  |  |
| Stock based compensation expense | $ | 1,575 |  |  | $ | 2,169 |  |
| Acquisition-related costs | $ | 3,695 |  |  | $ | — |  |
| Restructuring charge, net of reversals | $ | 75 |  |  | $ | (10 | ) |
| Gain on sale of facilities | $ | — |  |  | $ | (11,537 | ) |
| Total adjustments to GAAP net income | $ | 5,345 |  |  | $ | (9,378 | ) |
| Non-GAAP net income | $ | 5,310 |  |  | $ | 3,537 |  |
| Earnings per share |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.06 |  |  | $ | 0.04 |  |
| Shares used in diluted net income per share calculation | 95,695 |  |  | 95,499 |  |

[0001078271-13-000060:8k_2_02:81]
| Free Cash Flow | Three Months Ended |
|  | September 30, 2013 |  | September 30, 2012 |
| Cash flow provided by operations | $ | 1,925 |  |  | $ | 7,052 |  |
| Add: PP&E CapEx spending | $ | (9,808 | ) |  | $ | (1,562 | ) |
| Total free cash flow | $ | (7,883 | ) |  | $ | 5,490 |  |
