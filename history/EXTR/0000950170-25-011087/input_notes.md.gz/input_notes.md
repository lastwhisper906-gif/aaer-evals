# EXTR notes — 0000950170-25-011087


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-25-011087:notes:1]
[same as prior period, unchanged from 0000950170-24-119570:notes:1]

[0000950170-25-011087:notes:2]
[same as prior period, unchanged from 0000950170-24-119570:notes:2]

[0000950170-25-011087:notes:3]
[same as prior period, unchanged from 0000950170-24-119570:notes:3]

[0000950170-25-011087:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2024. The results of operations for the three and six months ended December 31, 2024 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.

[0000950170-25-011087:notes:5]
[same as prior period, unchanged from 0000950170-24-119570:notes:5]

[0000950170-25-011087:notes:6]
[same as prior period, unchanged from 0000950170-24-119570:notes:6]

[0000950170-25-011087:notes:7]
[same as prior period, unchanged from 0000950170-24-119570:notes:7]

[0000950170-25-011087:notes:8]
[same as prior period, unchanged from 0000950170-24-119570:notes:8]

[0000950170-25-011087:notes:9]
[same as prior period, unchanged from 0000950170-24-119570:notes:9]

[0000950170-25-011087:notes:10]
[same as prior period, unchanged from 0000950170-24-119570:notes:10]

[0000950170-25-011087:notes:11]
[same as prior period, unchanged from 0000950170-24-119570:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-25-011087:notes:12]
[same as prior period, unchanged from 0000950170-24-119570:notes:12]

[0000950170-25-011087:notes:13]
[same as prior period, unchanged from 0000950170-24-119570:notes:13]

[0000950170-25-011087:notes:14]
Recently Adopted Accounting Pronouncements

[0000950170-25-011087:notes:15]
There were no recently adopted accounting standards which would have a material effect on the Company's condensed consolidated financial statements and accompanying disclosures.

[0000950170-25-011087:notes:16]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000950170-25-011087:notes:17]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted.  The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.

[0000950170-25-011087:notes:18]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.

[0000950170-25-011087:notes:19]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-25-011087:notes:20]
[same as prior period, unchanged from 0000950170-24-119570:notes:19]

[0000950170-25-011087:notes:21]
[same as prior period, unchanged from 0000950170-24-119570:notes:20]

[0000950170-25-011087:notes:22]
[same as prior period, unchanged from 0000950170-24-119570:notes:21]

[0000950170-25-011087:notes:23]
[same as prior period, unchanged from 0000950170-24-119570:notes:22]

[0000950170-25-011087:notes:24]
[same as prior period, unchanged from 0000950170-24-119570:notes:23]

[0000950170-25-011087:notes:25]
As of December 31, 2024, the Company had $589.5 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 31% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 34% in fiscal 2026, and the remaining 35% of the balance thereafter.

[0000950170-25-011087:notes:26]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable SaaS subscription and support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0000950170-25-011087:notes:27]
Revenue recognized for the three months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $101.3 million and $105.7 million, respectively. Revenue recognized for the six months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $183.3 million and $172.0 million, respectively.

[0000950170-25-011087:notes:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.7 million as of December 31, 2024 and June 30, 2024. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2024 and 2023 was $3.1 million and $2.7 million, respectively. Amortization recognized during the six months ended December 31, 2024 and 2023 was $6.1 million and $5.2 million, respectively.

[0000950170-25-011087:notes:29]
[same as prior period, unchanged from 0000950170-24-119570:notes:28]

[0000950170-25-011087:notes:30]
Revenues by Geography

[0000950170-25-011087:notes:31]
[same as prior period, unchanged from 0000950170-24-119570:notes:30]

[0000950170-25-011087:notes:32]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 119,678 |  |  | $ | 149,549 |  |  |  | 272,931 |  |  | $ | 332,301 |  |
| Other |  |  | 11,710 |  |  |  | 13,086 |  |  |  | 23,892 |  |  |  | 25,983 |  |
| Total Americas |  |  | 131,388 |  |  |  | 162,635 |  |  |  | 296,823 |  |  |  | 358,284 |  |
| EMEA |  |  | 128,257 |  |  |  | 110,605 |  |  |  | 213,175 |  |  |  | 254,208 |  |
| APAC |  |  | 19,710 |  |  |  | 23,137 |  |  |  | 38,561 |  |  |  | 37,022 |  |
| Total net revenues |  | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |

[0000950170-25-011087:notes:33]
Geographic Concentrations

[0000950170-25-011087:notes:34]
For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively. For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany and for the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and six months ended December 31, 2024 and 2023.

[0000950170-25-011087:notes:35]
[same as prior period, unchanged from 0000950170-24-119570:notes:33]

[0000950170-25-011087:notes:36]
[same as prior period, unchanged from 0000950170-24-119570:notes:34]

[0000950170-25-011087:notes:37]
[same as prior period, unchanged from 0000950170-24-119570:notes:35]

[0000950170-25-011087:notes:38]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2024 |  | December 31,2023 |  | December 31,2024 |  | December 31,2023 |
| Westcon Group, Inc. |  | 22% |  | 10% |  | 18% |  | 18% |
| TD Synnex Corporation |  | 17% |  | 24% |  | 19% |  | 21% |
| Jenne, Inc. |  | 15% |  | 23% |  | 18% |  | 25% |

[0000950170-25-011087:notes:39]
[same as prior period, unchanged from 0000950170-24-119570:notes:37]

[0000950170-25-011087:notes:40]
|  |  | December 31,2024 |  | June 30,2024 |
| Jenne, Inc. |  | 26% |  | 64% |
| ScanSource, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-25-011087:notes:41]
[same as prior period, unchanged from 0000950170-24-119570:notes:40]

[0000950170-25-011087:notes:42]
[same as prior period, unchanged from 0000950170-24-119570:notes:41]

[0000950170-25-011087:notes:43]
[same as prior period, unchanged from 0000950170-24-119570:notes:42]

[0000950170-25-011087:notes:44]
[same as prior period, unchanged from 0000950170-24-119570:notes:43]

[0000950170-25-011087:notes:45]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Cash |  | $ | 170,204 |  |  | $ | 153,483 |  |
| Cash equivalents |  |  | 118 |  |  |  | 3,216 |  |
| Total cash and cash equivalents |  | $ | 170,322 |  |  | $ | 156,699 |  |

[0000950170-25-011087:notes:46]
[same as prior period, unchanged from 0000950170-24-119570:notes:45]

[0000950170-25-011087:notes:47]
[same as prior period, unchanged from 0000950170-24-119570:notes:46]

[0000950170-25-011087:notes:48]
[same as prior period, unchanged from 0000950170-24-119570:notes:47]

[0000950170-25-011087:notes:49]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Finished goods |  | $ | 84,002 |  |  | $ | 115,813 |  |
| Raw materials |  |  | 48,276 |  |  |  | 25,219 |  |
| Total inventories |  | $ | 132,278 |  |  | $ | 141,032 |  |

[0000950170-25-011087:notes:50]
[same as prior period, unchanged from 0000950170-24-119570:notes:49]

[0000950170-25-011087:notes:51]
[same as prior period, unchanged from 0000950170-24-119570:notes:50]

[0000950170-25-011087:notes:52]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Computers and equipment |  | $ | 80,790 |  |  | $ | 77,224 |  |
| Software |  |  | 55,805 |  |  |  | 60,717 |  |
| Office equipment, furniture and fixtures |  |  | 8,103 |  |  |  | 8,134 |  |
| Leasehold improvements |  |  | 48,128 |  |  |  | 47,880 |  |
| Total property and equipment |  |  | 192,826 |  |  |  | 193,955 |  |
| Less: accumulated depreciation and amortization |  |  | (156,091 | ) |  |  | (150,211 | ) |
| Property and equipment, net |  | $ | 36,735 |  |  | $ | 43,744 |  |

[0000950170-25-011087:notes:53]
[same as prior period, unchanged from 0000950170-24-119570:notes:52]

[0000950170-25-011087:notes:54]
[same as prior period, unchanged from 0000950170-24-119570:notes:53]

[0000950170-25-011087:notes:55]
[same as prior period, unchanged from 0000950170-24-119570:notes:54]

[0000950170-25-011087:notes:56]
[same as prior period, unchanged from 0000950170-24-119570:notes:55]

[0000950170-25-011087:notes:57]
[same as prior period, unchanged from 0000950170-24-119570:notes:56]

[0000950170-25-011087:notes:58]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Balance at beginning of period |  | $ | 10,239 |  |  | $ | 12,164 |  |  | $ | 10,942 |  |  | $ | 12,322 |  |
| New warranties issued |  |  | 3,045 |  |  |  | 2,777 |  |  |  | 5,531 |  |  |  | 6,451 |  |
| Warranty expenditures |  |  | (3,248 | ) |  |  | (3,544 | ) |  |  | (6,437 | ) |  |  | (7,376 | ) |
| Balance at end of period |  | $ | 10,036 |  |  | $ | 11,397 |  |  | $ | 10,036 |  |  | $ | 11,397 |  |

[0000950170-25-011087:notes:59]
[same as prior period, unchanged from 0000950170-24-119570:notes:58]

[0000950170-25-011087:notes:60]
[same as prior period, unchanged from 0000950170-24-119570:notes:59]

[0000950170-25-011087:notes:61]
[same as prior period, unchanged from 0000950170-24-119570:notes:60]


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-25-011087:notes:62]
[same as prior period, unchanged from 0000950170-24-119570:notes:61]

[0000950170-25-011087:notes:63]
[same as prior period, unchanged from 0000950170-24-119570:notes:62]

[0000950170-25-011087:notes:64]
[same as prior period, unchanged from 0000950170-24-119570:notes:63]

[0000950170-25-011087:notes:65]
[same as prior period, unchanged from 0000950170-24-119570:notes:64]

[0000950170-25-011087:notes:66]
[same as prior period, unchanged from 0000950170-24-119570:notes:65]

[0000950170-25-011087:notes:67]
[same as prior period, unchanged from 0000950170-24-119570:notes:66]

[0000950170-25-011087:notes:68]
| December 31, 2024 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 118 |  |  | $ | — |  |  | $ | 118 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 36 |  |  |  | — |  |  |  | 36 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 154 |  |  | $ | — |  |  | $ | 154 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 342 |  |  | $ | — |  |  | $ | 342 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 342 |  |  | $ | — |  |  | $ | 342 |  |

[0000950170-25-011087:notes:69]
[same as prior period, unchanged from 0000950170-24-119570:notes:68]

[0000950170-25-011087:notes:70]
[same as prior period, unchanged from 0000950170-24-119570:notes:69]

[0000950170-25-011087:notes:71]
[same as prior period, unchanged from 0000950170-24-119570:notes:70]

[0000950170-25-011087:notes:72]
As of December 31, 2024 and June 30, 2024, the Company had investment in certificates of deposit of $0.1 million and $3.2 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of December 31, 2024 and June 30, 2024, their fair value approximated their amortized cost.

[0000950170-25-011087:notes:73]
As of December 31, 2024 and June 30, 2024, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $55.0 million and $31.3 million, respectively. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in “Other income (expense), net” in the condensed consolidated statements of operations. For the three months ended December 31, 2024 and 2023, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net losses of $2.1 million and net gains of $0.4 million, respectively. For the six months ended December 31, 2024 and 2023, the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $1.3 million and net gains of $0.3 million, respectively. As of December 31, 2024 and June 30, 2024, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 12, Derivatives and Hedging, for additional information.

[0000950170-25-011087:notes:74]
The fair value of borrowings under the 2023 Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2023 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $185.0 million and $190.0 million as of December 31, 2024 and June 30, 2024, respectively.

[0000950170-25-011087:notes:75]
[same as prior period, unchanged from 0000950170-24-119570:notes:74]

[0000950170-25-011087:notes:76]
As of December 31, 2024 and June 30, 2024, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2, or Level 3 during the three and six months ended December 31, 2024 and 2023. There were no impairments recorded for the three and six months ended December 31, 2024 and 2023.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-25-011087:notes:77]
[same as prior period, unchanged from 0000950170-24-119570:notes:76]

[0000950170-25-011087:notes:78]
[same as prior period, unchanged from 0000950170-24-119570:notes:77]

[0000950170-25-011087:notes:79]
[same as prior period, unchanged from 0000950170-24-119570:notes:78]

[0000950170-25-011087:notes:80]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.8 years |  | $ | 168,884 |  |  | $ | 163,676 |  |  | $ | 5,208 |  |
| Customer relationships |  | 1.5 years |  |  | 64,626 |  |  |  | 61,756 |  |  |  | 2,870 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 2.0 years |  |  | 1,282 |  |  |  | 1,139 |  |  |  | 143 |  |
| Total intangible assets, net* |  |  |  | $ | 245,492 |  |  | $ | 237,271 |  |  | $ | 8,221 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-25-011087:notes:81]
[same as prior period, unchanged from 0000950170-24-119570:notes:80]

[0000950170-25-011087:notes:82]
[same as prior period, unchanged from 0000950170-24-119570:notes:81]

[0000950170-25-011087:notes:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 606 |  |  | $ | 611 |  |  | $ | 1,230 |  |  | $ | 2,044 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 509 |  |  |  | 509 |  |  |  | 1,021 |  |  |  | 1,020 |  |
| Total amortization expense |  | $ | 1,115 |  |  | $ | 1,120 |  |  | $ | 2,251 |  |  | $ | 3,064 |  |

[0000950170-25-011087:notes:84]
[same as prior period, unchanged from 0000950170-24-119570:notes:83]

[0000950170-25-011087:notes:85]
[same as prior period, unchanged from 0000950170-24-119570:notes:84]

[0000950170-25-011087:notes:86]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2025 (the remainder of fiscal 2025) |  | $ | 2,183 |  |
| 2026 |  |  | 3,131 |  |
| 2027 |  |  | 1,402 |  |
| 2028 |  |  | 1,246 |  |
| 2029 |  |  | 259 |  |
| Total |  | $ | 8,221 |  |

[0000950170-25-011087:notes:87]
[same as prior period, unchanged from 0000950170-24-119570:notes:86]

[0000950170-25-011087:notes:88]
The Company had goodwill in the amount of $392.0 million and $393.7 million as of December 31, 2024 and June 30, 2024, respectively. The change in goodwill during the six months ended December 31, 2024 is due to foreign currency translation adjustments that are recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0000950170-25-011087:notes:89]
7.
Debt

[0000950170-25-011087:notes:90]
The Company’s debt is comprised of the following (in thousands):

[0000950170-25-011087:notes:91]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 12,500 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (752 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 11,748 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 172,500 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,634 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 170,866 |  |  |  | 178,265 |  |
| Total debt |  | $ | 182,614 |  |  | $ | 187,591 |  |

[0000950170-25-011087:notes:92]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-25-011087:notes:93]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

[0000950170-25-011087:notes:94]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-25-011087:notes:95]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-25-011087:notes:96]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024.

[0000950170-25-011087:notes:97]
As of December 31, 2024, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

[0000950170-25-011087:notes:98]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations and was $0.3 million for each period during the three months ended December 31, 2024 and 2023 and was $0.6 million and $0.5 million for the six months ended December 31, 2024 and 2023, respectively. The interest rate was 6.84% and 7.46% as of December 31, 2024 and 2023, respectively.

[0000950170-25-011087:notes:99]
As of December 31, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of December 31, 2024. During the three and six months ended December 31, 2024 and 2023, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

[0000950170-25-011087:notes:100]
The Company had $14.2 million of outstanding letters of credit as of December 31, 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-011087:notes:101]
8.
Commitments and Contingencies

[0000950170-25-011087:notes:102]
Purchase Commitments

[0000950170-25-011087:notes:103]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2024, the Company had commitments to purchase $29.5 million of inventory.

[0000950170-25-011087:notes:104]
Legal Proceedings

[0000950170-25-011087:notes:105]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-25-011087:notes:106]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year. As of December 31, 2024, the total estimated litigation expense accrual included in the “Other accrued liabilities” in the condensed consolidated balance sheets was $23.5 million for various ongoing litigation matters with probable losses that can be reasonably estimated.

[0000950170-25-011087:notes:107]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-25-011087:notes:108]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleged direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. On October 21, 2024, the District Court in Dusseldorf, Germany confirmed the withdrawal by Orckit of its complaint, thus concluding this action.

[0000950170-25-011087:notes:109]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleged infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. On December 23, 2024, Orckit withdrew this infringement complaint.

[0000950170-25-011087:notes:110]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On December 10, 2024, the Federal Court of Justice ruled that the ‘077 patent is invalid.

[0000950170-25-011087:notes:111]
As a result of the withdrawals and the invalidity ruling, these cases are now concluded in the Company’s favor.

[0000950170-25-011087:notes:112]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-25-011087:notes:113]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without

[0000950170-25-011087:notes:114]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. The trial is set for August 5, 2025.

[0000950170-25-011087:notes:115]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-25-011087:notes:116]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.

[0000950170-25-011087:notes:117]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. It is not yet known if Mala will appeal the ruling of the German Federal Patent Court.

[0000950170-25-011087:notes:118]
Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al.

[0000950170-25-011087:notes:119]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Fire/Police and Oakland County Employees as the lead plaintiffs. Trial has been scheduled for March 20, 2027.

[0000950170-25-011087:notes:120]
Indemnification Obligations

[0000950170-25-011087:notes:121]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-25-011087:notes:122]
[same as prior period, unchanged from 0000950170-24-119570:notes:120]

[0000950170-25-011087:notes:123]
[same as prior period, unchanged from 0000950170-24-119570:notes:121]

[0000950170-25-011087:notes:124]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 14, 2024 to increase the maximum number of available shares by 2.3 million shares, which was approved by the stockholders of the Company at the annual meeting of stockholders held on November 14, 2024.

[0000950170-25-011087:notes:125]
[same as prior period, unchanged from 0000950170-24-119570:notes:123]

[0000950170-25-011087:notes:126]
[same as prior period, unchanged from 0000950170-24-119570:notes:124]

[0000950170-25-011087:notes:127]
During the three and six months ended December 31, 2024, the Company did not repurchase any shares of its common stock.  During the three months ended December 31, 2023, the Company repurchased 1,485,005 shares of its common stock on the open market at a total cost of $25.0 million with an average price of $16.81 per share. During the six months ended December 31, 2023, the Company repurchased a total of 2,365,220 shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. As of December 31, 2024, approximately $50.3 million remains available for share repurchases under the 2022 Repurchase Program.

[0000950170-25-011087:notes:128]
[same as prior period, unchanged from 0000950170-24-119570:notes:126]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-25-011087:notes:129]
[same as prior period, unchanged from 0000950170-24-119570:notes:127]

[0000950170-25-011087:notes:130]
[same as prior period, unchanged from 0000950170-24-119570:notes:128]

[0000950170-25-011087:notes:131]
[same as prior period, unchanged from 0000950170-24-119570:notes:129]

[0000950170-25-011087:notes:132]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 11,092 |  |  |  | 13,414 |  |
| Employee stock options and awards outstanding |  |  | 8,619 |  |  |  | 7,562 |  |
| 2014 Employee Stock Purchase Plan |  |  | 6,662 |  |  |  | 7,130 |  |
| Total shares reserved for issuance |  |  | 26,373 |  |  |  | 28,106 |  |

[0000950170-25-011087:notes:133]
[same as prior period, unchanged from 0000950170-24-119570:notes:131]

[0000950170-25-011087:notes:134]
[same as prior period, unchanged from 0000950170-24-119570:notes:132]

[0000950170-25-011087:notes:135]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Cost of product revenues |  | $ | 680 |  |  | $ | 464 |  |  | $ | 1,298 |  |  | $ | 947 |  |
| Cost of subscription and support revenues |  |  | 798 |  |  |  | 749 |  |  |  | 1,487 |  |  |  | 1,615 |  |
| Research and development |  |  | 4,467 |  |  |  | 4,435 |  |  |  | 8,680 |  |  |  | 8,812 |  |
| Sales and marketing |  |  | 7,596 |  |  |  | 7,535 |  |  |  | 14,478 |  |  |  | 14,523 |  |
| General and administrative |  |  | 7,911 |  |  |  | 7,774 |  |  |  | 15,276 |  |  |  | 14,979 |  |
| Total share-based compensation expense |  | $ | 21,452 |  |  | $ | 20,957 |  |  | $ | 41,219 |  |  | $ | 40,876 |  |

[0000950170-25-011087:notes:136]
[same as prior period, unchanged from 0000950170-24-119570:notes:134]

[0000950170-25-011087:notes:137]
The following table summarizes stock option activity for the six months ended December 31, 2024 (in thousands, except per share amount and contractual term):

[0000950170-25-011087:notes:138]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 1.75 |  |  | $ | 7,376 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (195 | ) |  |  | 6.40 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2024 |  |  | 878 |  |  | $ | 6.62 |  |  |  | 1.39 |  |  | $ | 8,886 |  |
| Vested and expected to vest at December 31, 2024 |  |  | 878 |  |  | $ | 6.62 |  |  |  | 1.39 |  |  | $ | 8,886 |  |
| Exercisable at December 31, 2024 |  |  | 878 |  |  | $ | 6.62 |  |  |  | 1.39 |  |  | $ | 8,886 |  |

[0000950170-25-011087:notes:139]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based upon the estimated life of the option and the U.S. Treasury yield

[0000950170-25-011087:notes:140]
curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the three and six months ended December 31, 2024 and 2023.

[0000950170-25-011087:notes:141]
[same as prior period, unchanged from 0000950170-24-119570:notes:138]

[0000950170-25-011087:notes:142]
[same as prior period, unchanged from 0000950170-24-119570:notes:139]

[0000950170-25-011087:notes:143]
The following table summarizes stock award activity for the six months ended December 31, 2024 (in thousands, except grant date fair value):

[0000950170-25-011087:notes:144]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2024 |  |  | 6,489 |  |  | $ | 22.65 |  |  |  |  |
| Granted |  |  | 4,191 |  |  |  | 15.82 |  |  |  |  |
| Released |  |  | (2,662 | ) |  |  | 20.47 |  |  |  |  |
| Canceled |  |  | (277 | ) |  |  | 21.62 |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2024 |  |  | 7,741 |  |  | $ | 19.83 |  |  |  |  |
| Stock awards expected to vest at December 31, 2024 |  |  | 7,741 |  |  | $ | 19.83 |  |  | $ | 153,538 |  |

[0000950170-25-011087:notes:145]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the six months ended December 31, 2024 included 1.3 million RSUs including the market condition awards discussed below to the named executive officers and outside directors.

[0000950170-25-011087:notes:146]
[same as prior period, unchanged from 0000950170-24-119570:notes:143]

[0000950170-25-011087:notes:147]
During the six months ended December 31, 2024 and 2023, the Compensation Committee of the Board granted 0.9 million and 0.8 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s employees. The MSUs granted during the six months ended December 31, 2024 were subject to total stockholder return (“TSR”).  The MSUs granted during the six months ended December 31, 2023 included 0.5 million MSUs subject to TSR and 0.3 million MSUs subject to certain stock price targets.

[0000950170-25-011087:notes:148]
[same as prior period, unchanged from 0000950170-24-119570:notes:145]

[0000950170-25-011087:notes:149]
[same as prior period, unchanged from 0000950170-24-119570:notes:146]

[0000950170-25-011087:notes:150]
[same as prior period, unchanged from 0000950170-24-119570:notes:147]

[0000950170-25-011087:notes:151]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the six months ended December 31, 2024 was $17.22 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 48%, risk-free interest rate of 3.86%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The weighted-average grant-date fair value of the TSR MSUs granted during the six months ended December 31, 2023 was $34.09 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free interest rate of 4.48%, no expected dividend yield, expected term of three years, and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-25-011087:notes:152]
The stock price target MSUs vest upon the achievement of a certain stock price target over the defined performance period. The stock price target shall be deemed as achieved if the average closing stock price over any 30 consecutive trading days during the period from grant date through the third anniversary of the grant date equals or exceeds the price target of $41.38 for the initial performance period. Upon satisfaction of the initial stock price target, 50% of the target shares will vest on the third anniversary of the grant date and the remaining 50% will vest on the fourth anniversary of the grant date, subject to employees’ continued service through the applicable vesting dates. If the units are not earned on the last day of initial performance period, the units will remain outstanding and be eligible to be earned if the average closing stock price over any 30 consecutive trading days equals or exceeds the price target of $46.96.

[0000950170-25-011087:notes:153]
The grant date fair value of these stock price target MSUs was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of these stock price target MSUs granted during the six months ended December 31, 2024 was $28.80 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 63%, risk-free interest rate of 4.45%, no expected dividend yield, expected term of three years based on possible future stock prices over the performance period based on the historical stock prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-25-011087:notes:154]
On February 15, 2024 the Company modified certain terms and conditions of the stock price target MSU's for certain employees. Under the modified agreement, the stock price target over the initial and fourth year performance periods were revised to $23.00 and $26.00, respectively. All other contractual terms remained unchanged. The incremental compensation cost related to the modification was not material and will be recognized ratably over the remaining requisite service period.

[0000950170-25-011087:notes:155]
[same as prior period, unchanged from 0000950170-24-119570:notes:152]

[0000950170-25-011087:notes:156]
[same as prior period, unchanged from 0000950170-24-119570:notes:153]

[0000950170-25-011087:notes:157]
There were 0.5 million and 0.5 million shares issued under the ESPP during the six months ended December 31, 2024 and 2023, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0000950170-25-011087:notes:158]
|  |  |  | Employee Stock Purchase Plan |  |  |
|  |  |  | Six Months Ended |  |  |
|  |  |  | December 31,2024 |  |  | December 31,2023 |  |  |
| Expected term |  |  | 0.5 years |  |  | 0.5 years |  |  |
| Risk-free interest rate |  |  |  | 5.04 | % |  |  | 5.54 | % |  |
| Volatility |  |  |  | 36 | % |  |  | 42 | % |  |
| Dividend yield |  |  |  | — | % |  |  | — | % |  |

[0000950170-25-011087:notes:159]
The weighted-average grant-date fair value of shares under the ESPP during the six months ended December 31, 2024 and 2023 was $3.74 and $8.09 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-011087:notes:160]
[same as prior period, unchanged from 0000950170-24-119570:notes:157]

[0000950170-25-011087:notes:161]
[same as prior period, unchanged from 0000950170-24-119570:notes:158]

[0000950170-25-011087:notes:162]
[same as prior period, unchanged from 0000950170-24-119570:notes:159]

[0000950170-25-011087:notes:163]
[same as prior period, unchanged from 0000950170-24-119570:notes:160]

[0000950170-25-011087:notes:164]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Americas |  | $ | 142,172 |  |  | $ | 136,745 |  |
| EMEA |  |  | 41,064 |  |  |  | 33,715 |  |
| APAC |  |  | 10,438 |  |  |  | 11,499 |  |
| Total long-lived assets |  | $ | 193,674 |  |  | $ | 181,959 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-25-011087:notes:165]
[same as prior period, unchanged from 0000950170-24-119570:notes:162]

[0000950170-25-011087:notes:166]
[same as prior period, unchanged from 0000950170-24-119570:notes:163]

[0000950170-25-011087:notes:167]
[same as prior period, unchanged from 0000950170-24-119570:notes:164]

[0000950170-25-011087:notes:168]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of December 31, 2024 and June 30, 2024, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $55.0 million and $31.3 million, respectively. During the three months ended December 31, 2024 and 2023, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net losses of $2.1 million and  net gains of $0.4 million, respectively. During the six months ended December 31, 2024 and 2023 the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $1.3 million and net gains of $0.3 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0000950170-25-011087:notes:169]
There were no foreign exchange forward contracts that were designated as hedging instruments as of December 31, 2024 or June 30, 2024.
For the three months ended December 31, 2024 and 2023, the Company recognized foreign currency net gains of $2.8 million and foreign currency net losses of $0.7 million, respectively, and for the six months ended December 31, 2024 and 2023, the Company recognized foreign currency net gains of $1.4 million and foreign currency net losses of $0.3 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-011087:notes:170]
[same as prior period, unchanged from 0000950170-24-119570:notes:167]

[0000950170-25-011087:notes:171]
The Company recorded $1.0 million and $9.2 million of restructuring and related charges during the three months ended December 31, 2024 and 2023, respectively. The Company recorded $2.3 million and $11.9 million of restructuring and related charges during the six months ended December 31, 2024 and 2023, respectively. These charges primarily included severance and benefits costs and professional fees related to the restructuring plans executed in prior years.

[0000950170-25-011087:notes:172]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company's research and development and sales and marketing functions to align the Company's workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”). During the three and six months ended December 31, 2024, the Company recorded restructuring charges of $0.9 million and $1.5 million, respectively, related to the Q3 2024 Plan, which primarily consisted of additional severance and benefits expenses, legal and consulting fees.

[0000950170-25-011087:notes:173]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the three and six months ended December 31, 2024, the Company recorded restructuring charges of less than $0.1 million and $0.6 million related to the Q2 2024 Plan, which primarily consisted of additional severance and benefits expenses, legal fees and consulting fees. During the three months ended December 31, 2023, the Company recorded restructuring charges of $8.8 million related to the Q2 2024 Plan, which primarily consisted of severance and benefits expenses, legal and consulting fees.

[0000950170-25-011087:notes:174]
Through December 31, 2024, the Company has incurred $29.1 million in restructuring charges under the Q2 2024 Plan and Q3 2024 Plan which primarily related to severance and benefits costs. The Company expects to complete these ongoing restructuring plans by the end of fiscal year 2025 and expects to incur approximately $1.3 million in additional charges for the Q2 2024 Plan and the Q3 2024 Plan.

[0000950170-25-011087:notes:175]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company is moved  engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company's labs.  During the six months ended December 31, 2024, the Company recorded restructuring charges of $0.1 million related to the 2023 Plan. The Company expects to complete the 2023 Plan by the end of fiscal year 2025 and expects to incur charges of $1.6 million throughout this period, primarily for asset disposals and other fees. Through December 31, 2024, the

[0000950170-25-011087:notes:176]
Company has incurred $6.6 million of restructuring charges under the 2023 Plan, which primarily consisted of $5.9 million in accelerated depreciation on lab leasehold improvements and $0.7 million in other charges related to moving expenses and asset disposal costs.

[0000950170-25-011087:notes:177]
During the first quarter of fiscal 2024, the Company initiated a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with the Company's business and strategic priorities (the “Q1 2024 Plan”). It consisted primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general and administrative functions. During the three and six months ended December 31, 2023, the Company incurred charges of $0.2 million and $2.9 million, respectively related to the Q1 2024 Plan. As of June 30, 2024, the plan was completed.

[0000950170-25-011087:notes:178]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of December 31, 2024 and 2023, the restructuring liability was $3.4 million and $6.2 million, respectively related to these restructuring plans.

[0000950170-25-011087:notes:179]
[same as prior period, unchanged from 0000950170-24-119570:notes:176]

[0000950170-25-011087:notes:180]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  | December 31,2024 |  |  | December 31,2023 |  |
| Balance at beginning of period |  | $ | 4,393 |  |  | $ | 925 |  | $ | 11,469 |  |  | $ | — |  |
| Period charges |  |  | 1,134 |  |  |  | 9,412 |  |  | 2,707 |  |  |  | 12,188 |  |
| Period reversals |  |  | (97 | ) |  |  | (173 | ) |  | (393 | ) |  |  | (258 | ) |
| Period payments |  |  | (2,032 | ) |  |  | (3,972 | ) |  | (10,385 | ) |  |  | (5,738 | ) |
| Balance at end of period |  | $ | 3,398 |  |  | $ | 6,192 |  | $ | 3,398 |  |  | $ | 6,192 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-011087:notes:181]
[same as prior period, unchanged from 0000950170-24-119570:notes:178]

[0000950170-25-011087:notes:182]
For the three months ended December 31, 2024 and 2023, the Company recorded an income tax provision of $2.6 million and $3.1 million, respectively. For the six months ended December 31, 2024 and 2023, the Company recorded an income tax provision of $4.1 million and $7.6 million, respectively.

[0000950170-25-011087:notes:183]
The income tax provisions for the three and six months ended December 31, 2024 and 2023, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In addition, the income tax provision for the three and six months ended December 31, 2024, includes US Federal income tax expense of $1.4 million and $0.2 million, respectively. The interim income tax provisions for the three and six months ended December 31, 2024 and 2023 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0000950170-25-011087:notes:184]
[same as prior period, unchanged from 0000950170-24-119570:notes:182]

[0000950170-25-011087:notes:185]
The Company had $18.2 million of unrecognized tax benefits as of December 31, 2024. If fully recognized in the future, $0.2 million would impact the effective tax rate and $18.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur

[0000950170-25-011087:notes:186]
during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0000950170-25-011087:notes:187]
[same as prior period, unchanged from 0000950170-24-119570:notes:184]

[0000950170-25-011087:notes:188]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2004 forward due to NOLs and the Company’s state income tax returns are subject to examination for fiscal years 2005 and forward due to NOLs.


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-011087:notes:189]
[same as prior period, unchanged from 0000950170-24-119570:notes:186]

[0000950170-25-011087:notes:190]
[same as prior period, unchanged from 0000950170-24-119570:notes:187]

[0000950170-25-011087:notes:191]
[same as prior period, unchanged from 0000950170-24-119570:notes:188]

[0000950170-25-011087:notes:192]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Net income (loss) |  | $ | 7,382 |  |  | $ | 3,988 |  |  | $ | (3,122 | ) |  | $ | 32,664 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 132,381 |  |  |  | 128,987 |  |  |  | 131,778 |  |  |  | 128,885 |  |
| Options to purchase common stock |  |  | 551 |  |  |  | 757 |  |  |  | — |  |  |  | 836 |  |
| Restricted stock units |  |  | 1,100 |  |  |  | 1,579 |  |  |  | — |  |  |  | 2,951 |  |
| Employee Stock Purchase Plan shares |  |  | 75 |  |  |  | 191 |  |  |  | — |  |  |  | 114 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 134,107 |  |  |  | 131,514 |  |  |  | 131,778 |  |  |  | 132,786 |  |
| Net income (loss) per share – basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | 0.06 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |  | $ | 0.25 |  |
| Net income (loss) per share – diluted |  | $ | 0.06 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |  | $ | 0.25 |  |

[0000950170-25-011087:notes:193]
[same as prior period, unchanged from 0000950170-24-119570:notes:190]

[0000950170-25-011087:notes:194]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Options to purchase common stock |  |  | — |  |  |  | — |  |  |  | 997 |  |  |  | — |  |
| Restricted stock units |  |  | 1,295 |  |  |  | 2,336 |  |  |  | 5,638 |  |  |  | 1,623 |  |
| Employee Stock Purchase Plan shares |  |  | 695 |  |  |  | 560 |  |  |  | 545 |  |  |  | 445 |  |
| Total shares excluded |  |  | 1,990 |  |  |  | 2,896 |  |  |  | 7,180 |  |  |  | 2,068 |  |
