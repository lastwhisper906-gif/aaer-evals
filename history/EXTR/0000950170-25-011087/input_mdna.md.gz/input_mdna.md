# EXTR MD&A — 0000950170-25-011087


## mdna

[0000950170-25-011087:mdna:1]
[same as prior period, unchanged from 0000950170-24-119570:mdna:1]

[0000950170-25-011087:mdna:2]
[same as prior period, unchanged from 0000950170-24-119570:mdna:2]

[0000950170-25-011087:mdna:3]
[same as prior period, unchanged from 0000950170-24-119570:mdna:3]

[0000950170-25-011087:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of cloud networking with integrated security and Artificial Intelligence (“AI”)  solutions along with industry leading services and support. Extreme designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment, software and cloud-based network management solutions and security and AI software solutions. The Company’s Platform ONETM solution, announced in December 2024, is a technology platform that reduces the complexity for enterprises by seamlessly integrating networking, security and AI solutions into a single platform. AI-powered automation includes conversational, interactive and autonomous AI agents—to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex.

[0000950170-25-011087:mdna:5]
Our global footprint provides service to some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0000950170-25-011087:mdna:6]
[same as prior period, unchanged from 0000950170-24-119570:mdna:6]

[0000950170-25-011087:mdna:7]
Enterprises across every industry are going through unprecedented changes, such as leading digital initiatives, migrating their workloads to cloud-based environments, modernizing applications, finding new ways to leverage generative AI (“GenAI”) technology, and adapting to a distributed workforce. To accomplish this, they are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. As networks become more complex and more distributed in nature, we believe IT teams in every industry will need more control and better insights than ever before to deliver secure, distributed connectivity and comprehensive centralized visibility. Networking is mission critical and touches all elements of how services are delivered to customers, employees, students, and patients. Managing networks from a single platform that integrates AI networking and security is critical to help reduce complexity and minimize the time it takes to complete tasks.

[0000950170-25-011087:mdna:8]
[same as prior period, unchanged from 0000950170-24-119570:mdna:8]

[0000950170-25-011087:mdna:9]
[same as prior period, unchanged from 0000950170-24-119570:mdna:9]

[0000950170-25-011087:mdna:10]
[same as prior period, unchanged from 0000950170-24-119570:mdna:10]

[0000950170-25-011087:mdna:11]
[same as prior period, unchanged from 0000950170-24-119570:mdna:11]

[0000950170-25-011087:mdna:12]
[same as prior period, unchanged from 0000950170-24-119570:mdna:12]

[0000950170-25-011087:mdna:13]
We believe Extreme will continue to benefit from the use of its technology to manage distributed campus network architecture centrally from the cloud. Extreme has blended a dynamic network fabric architecture that delivers simplicity for moves and changes at the edge of the network together with corporate-wide role-based policy. This enables customers to migrate to new cloud-managed switching, Wi-Fi, and SD-WAN, agnostic of the existing switching or wireless equipment they already have installed. In the end, we expect these customers to see lower operating and capital expenditures, lower subscription costs, lower overall cost of ownership, and more flexibility, along with a more resilient network.

[0000950170-25-011087:mdna:14]
We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), SD-WAN solutions and management, automation, and elements of the Secure Access Services Edge (“SASE”) market to be over $47 billion, and growing at approximately 13% annually over the next five years based on data from the 650 Group, Gartner, IDC, and Dell'Oro. This comprises over $36 billion for networking and infrastructure spanning enterprise and service provider (largely 5G) applications, and $11 billion for networking cloud and security software, which is expected to grow to $31 billion by 2028.

[0000950170-25-011087:mdna:15]
[same as prior period, unchanged from 0000950170-24-119570:mdna:15]

[0000950170-25-011087:mdna:16]
We are driven to help our customers find new ways to deliver better outcomes. Extreme empowers organizations with new ways to simply and securely connect with Extreme's intelligent technology platform to help move their organizations forward.

[0000950170-25-011087:mdna:17]
Extreme Platform One will reduce complexity for enterprises by seamlessly integrating networking, security and AI solutions. The platform’s AI-powered automation includes conversational, interactive and autonomous AI agents, to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex tasks. Extreme Platform ONE is also designed to offer the industry's simplest licensing.

[0000950170-25-011087:mdna:18]
[same as prior period, unchanged from 0000950170-24-119570:mdna:24]

[0000950170-25-011087:mdna:19]
•
Provide a differentiated end-to-end cloud networking architecture. Cloud networking is estimated to be an $11 billion segment of the networking market comprising cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at 14% annually over the next five years, according to data from the 650 Group, Gartner, IDC, and Dell'Oro. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by machine learning (“ML”) and AI that spans from the Internet of Things (“IoT”) edge to the enterprise data center. Key characteristics of our cloud architecture include:

[0000950170-25-011087:mdna:20]
o
A robust cloud management platform that delivers visibility, intelligence, and assurance from the network edge to the core.

[0000950170-25-011087:mdna:21]
[same as prior period, unchanged from 0000950170-24-119570:mdna:28]

[0000950170-25-011087:mdna:22]
o
The ExtremeCloud IQ: Our cloud platform conforms to ISO/IEC 27017, ISO/IEC 27001 and ISO/IEC 27701 standards for data privacy and protection as set forth by the International Standards Organization (“ISO”), and is CSA STAR certified.

[0000950170-25-011087:mdna:23]
o
Cloud Continuum: Provides hosting flexibility across a range of options including public, private, and on-premises edge cloud options.

[0000950170-25-011087:mdna:24]
[same as prior period, unchanged from 0000950170-24-119570:mdna:29]

[0000950170-25-011087:mdna:25]
[same as prior period, unchanged from 0000950170-24-119570:mdna:32]

[0000950170-25-011087:mdna:26]
•
Highest value of cloud management subscriptions. ExtremeCloud IQ provides unified cloud-native management driven by AI and ML for wireless access points, wired switches, network security and SD-WAN solutions. It features intuitive configuration workflows, real-time and historical monitoring, comprehensive troubleshooting, and integrated network applications for Extreme customers. The innovative ML technologies of ExtremeCloud IQ analyze and interpret millions of network and user data points, from the edge to the data center, to power actionable business and IT insights. The platform streamlines operations by delivering new levels of network automation and intelligence. The ExtremeCloud IQ Pilot license tier streamlines every aspect of network management from deployment and maintenance to problem resolution. The Pilot license includes key capabilities for guest management, WIPS, and location services with associated services: ExtremeGuest, ExtremeAirDefense, and ExtremeLocation.

[0000950170-25-011087:mdna:27]
[same as prior period, unchanged from 0000950170-24-119570:mdna:34]

[0000950170-25-011087:mdna:28]
o
Extreme AirDefense™ is a comprehensive wireless intrusion prevention system (“WIPS”) that simplifies the protection, monitoring and security of wireless networks. With the added Bluetooth and Bluetooth low energy intrusion prevention, network administrators can address growing threats against Bluetooth and Bluetooth low energy devices.

[0000950170-25-011087:mdna:29]
[same as prior period, unchanged from 0000950170-24-119570:mdna:36]

[0000950170-25-011087:mdna:30]
•
Additional AI Capabilities. The ExtremeCloud IQ CoPilot license tier is an add-on to the Pilot license tier. It includes all the capabilities of the ExtremeCloud Pilot and Navigator license tiers. CoPilot serves as more than a centralized point of management with AIOps and other enhancements to network management and automation. It is a trusted digital advisor for your Extreme cloud-managed Wi-Fi networks that proactively reduces risk and provides the fastest time to the best experience. This includes advanced anomaly detection and capabilities to ensure the user experience of wireless and wired devices.

[0000950170-25-011087:mdna:31]
[same as prior period, unchanged from 0000950170-24-119570:mdna:38]

[0000950170-25-011087:mdna:32]
o
Universal switches (7720/5720/5520/5420/5320/4220/4120) support fabric or traditional networking with a choice of cloud or on-premises (air-gapped or cloud connected) management.

[0000950170-25-011087:mdna:33]
[same as prior period, unchanged from 0000950170-24-119570:mdna:40]

[0000950170-25-011087:mdna:34]
o
Universal licensing with one portable management license for any device and for any type of management. For switches, operating system feature licenses are portable, and bulk activated through ExtremeCloud IQ.

[0000950170-25-011087:mdna:35]
•
AI is a dynamic tool and is leveraged to drive productivity across our company and to offer security and GenAI solutions to our customers. Extreme’s journey in AI began in 2020 with the advent of machine learning and purpose-built AI. We then introduced Co-Pilot AIOps in 2022 to further enhance network performance and troubleshooting. Today we have the next exciting chapter – Extreme AI Expert – a GenAI  solution that will help optimize networks, provide better design, improve mean time to resolution for technical issues, and create cost savings in the overall design and implementation of networks. We are utilizing AI to improve mean time to resolution for customers, both through our AIOps offerings as well as internal use of Extreme AI Expert. We announced a technology preview of our Extreme AI Expert showcasing its ability to speed up documentation searches and resolution of network performance issues. This allows our customers to optimize their network performance and make it easier to focus on value-added activities.

[0000950170-25-011087:mdna:36]
There are several ways customers will be able to leverage our AI in the future as part of Extreme Platform ONE:

[0000950170-25-011087:mdna:37]
o
Knowledge queries provide the ability to answer any question in context (i.e., role, application, conversation). Questions are answered with Extreme’s product documentation, Global Technical Assistance Center knowledge base and selected training, and best practices material.

[0000950170-25-011087:mdna:38]
o
Intelligent Queries are answered with customer network data from multiple applications (ExtremeCloud IQ, SD-WAN, etc.).

[0000950170-25-011087:mdna:39]
o
“What-If” Queries give the ability for the system to work autonomously and optimize itself based on business key performance indicators (“KPIs”). These scenarios work on an on-demand, scheduled, or always-on basis. Predictive and scenario questions that are answered apply further processing to the network data, anomaly detections, pattern recognition, root cause analysis, predictive analytics and network optimization.

[0000950170-25-011087:mdna:40]
•
Provide a new enterprise connectivity platform -  Extreme Platform ONE. Expected in the second half of calendar year 2025, this will integrate networking and security with AI into one simplified experience so organizations can manage and secure the network faster and more efficiently than ever. Extreme Platform ONE will provide:

[0000950170-25-011087:mdna:41]
o
One integrated experience for everyone in an organization, from Network Operations (“NetOps”), Security Operations (“SecOps”), and business teams, to access just what they need to do their best work from a fully customizable workspace.

[0000950170-25-011087:mdna:42]
o
Automation enhanced with built-in AI. With Extreme AI Expert, Network Operations NetOps can swiftly resolve anomalies, while SecOps can easily set and update access policies, and Business teams can manage finance, procurement, and compliance. All teams accelerate learning, planning, delivery, management, analysis, and governance.

[0000950170-25-011087:mdna:43]
o
Simplified licensing - Extreme Platform ONE will be as easy to buy and renew as it is to use through co-termed contracts, industry-leading support services, and the integration of AI Expert.

[0000950170-25-011087:mdna:44]
[same as prior period, unchanged from 0000950170-24-119570:mdna:47]

[0000950170-25-011087:mdna:45]
[same as prior period, unchanged from 0000950170-24-119570:mdna:48]

[0000950170-25-011087:mdna:46]
o
ExtremeCloud Universal ZTNA. Universal ZTNA is the first network security offering to integrate network, application, and device security within a single solution. By combining Cloud Network Access Control (“NAC”) and Zero Trust Network Authentication (“ZTNA”) into a single, easy-to-use SaaS offering, we help customers ensure unified observability, frictionless user experiences and a consistent security policy for applications and devices, as well as support  secure hybrid work use cases for customers. As the virtual private network market transitions to ZTNA, the proliferation of individual applications, each with their own policy and dashboard, is adding complexity and expense for enterprise customers. We expect the broadening of our security offering to drive significant traction for our business with growth opportunities.

[0000950170-25-011087:mdna:47]
o
Extreme’s unique and highly differentiated network fabric makes it simple to orchestrate applications and policy across the entire campus, from the core to the wireless edge, and across the wide area network. We bring enhanced security, the ability to segment networks and zero touch provisioning, thus eliminating confusion, complexity and the need for additional IT staff. This is in stark contrast to our competitors’ fabric solutions, which were designed for service providers and data center networks and not meant for the campus.

[0000950170-25-011087:mdna:48]
[same as prior period, unchanged from 0000950170-24-119570:mdna:52]

[0000950170-25-011087:mdna:49]
[same as prior period, unchanged from 0000950170-24-119570:mdna:53]

[0000950170-25-011087:mdna:50]
•
Provide high-quality insourced customer service and support. We seek to enhance customer satisfaction and build customer loyalty through high-quality service and support. This includes a wide range of standard support programs to the level of service our customers require, from standard business hours to global 24-hour-a-day, 365-days-a-year real-time responsive support.

[0000950170-25-011087:mdna:51]
•
Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience, and our operating systems- the software that runs on all

[0000950170-25-011087:mdna:52]
of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud.

[0000950170-25-011087:mdna:53]
[same as prior period, unchanged from 0000950170-24-119570:mdna:56]

[0000950170-25-011087:mdna:54]
[same as prior period, unchanged from 0000950170-24-119570:mdna:57]

[0000950170-25-011087:mdna:55]
[same as prior period, unchanged from 0000950170-24-119570:mdna:58]

[0000950170-25-011087:mdna:56]
[same as prior period, unchanged from 0000950170-24-119570:mdna:59]

[0000950170-25-011087:mdna:57]
[same as prior period, unchanged from 0000950170-24-119570:mdna:60]

[0000950170-25-011087:mdna:58]
[same as prior period, unchanged from 0000950170-24-119570:mdna:61]

[0000950170-25-011087:mdna:59]
During the second quarter of fiscal 2025, we achieved the following results:

[0000950170-25-011087:mdna:60]
•
Net revenues of $279.4 million compared to $296.4 million in the second quarter of fiscal 2024.

[0000950170-25-011087:mdna:61]
•
Product revenues of $172.3 million compared to $186.6 million in the second quarter of fiscal 2024.

[0000950170-25-011087:mdna:62]
•
Subscription and support revenues of $107.1 million compared to $109.8 million in the second quarter of fiscal 2024.

[0000950170-25-011087:mdna:63]
•
Total gross margin of 62.7% of net revenues compared to 61.9% of net revenues in the second quarter of fiscal 2024.

[0000950170-25-011087:mdna:64]
•
Operating income of $12.7 million compared to $10.3 million in the second quarter of fiscal 2024.

[0000950170-25-011087:mdna:65]
•
Net income of $7.4 million compared to $4.0 million in the second quarter of fiscal 2024.

[0000950170-25-011087:mdna:66]
During the first six months of fiscal 2025, we reflected the following results:

[0000950170-25-011087:mdna:67]
•
Cash flows provided by operating activities of $40.1 million compared to $109.9 million in the six months ended December 31, 2023.

[0000950170-25-011087:mdna:68]
•
Cash and cash equivalents of $170.3 million as of December 31, 2024 compared to $156.7 million as of June 30, 2024.

[0000950170-25-011087:mdna:69]
[same as prior period, unchanged from 0000950170-24-119570:mdna:72]

[0000950170-25-011087:mdna:70]
[same as prior period, unchanged from 0000950170-24-119570:mdna:73]

[0000950170-25-011087:mdna:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2024 |  | December 31,2023 |  | $Change |  | %Change |  |  | December 31,2024 |  | December 31,2023 |  | $Change |  | %Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $172,261 |  | $186,611 |  | $(14,350) |  | (7.7)% |  |  | $334,545 |  | $440,094 |  | $(105,549) |  | (24.0)% |  |
| Percentage of net revenues |  | 61.7% |  | 63.0% |  |  |  |  |  |  | 61.0% |  | 67.8% |  |  |  |  |  |
| Subscription and support |  | 107,094 |  | 109,766 |  | (2,672) |  | (2.4)% |  |  | 214,014 |  | 209,420 |  | 4,594 |  | 2.2 % |  |
| Percentage of net revenues |  | 38.3% |  | 37.0% |  |  |  |  |  |  | 39.0% |  | 32.2% |  |  |  |  |  |
| Total net revenues |  | $279,355 |  | $296,377 |  | $(17,022) |  | (5.7)% |  |  | $548,559 |  | $649,514 |  | $(100,955) |  | (15.5)% |  |

[0000950170-25-011087:mdna:72]
We generate product revenues primarily from sales of our networking equipment. We derive subscription and support revenues primarily from sales of our subscription and support offerings which include SaaS offerings, maintenance contracts, professional services and training for our products.

[0000950170-25-011087:mdna:73]
Product revenues decreased $14.4 million or 7.7% for the three months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. Product revenues decreased $105.5 million or 24.0% for the six months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in product revenues was primarily driven by higher shipments in the corresponding period in fiscal 2024 due to the release of product backlog resulting from the easing of supply chain constraints.

[0000950170-25-011087:mdna:74]
Subscription and support revenues decreased $2.7 million or 2.4% for the three months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in subscription and support revenues was primarily due to lower support revenues, partially offset by higher subscription revenue. Subscription and support revenues increased $4.6 million or 2.2% for the six months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The increase in subscription and support revenues was primarily due to the continued growth in our subscription business.

[0000950170-25-011087:mdna:75]
[same as prior period, unchanged from 0000950170-24-119570:mdna:78]

[0000950170-25-011087:mdna:76]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2024 |  | December 31,2023 |  | $Change |  | %Change |  | December 31,2024 |  | December 31,2023 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $99,657 |  | $105,118 |  | $(5,461) |  | (5.2)% |  | $192,539 |  | $250,065 |  | $(57,526) |  | (23.0)% |
| Percentage of product revenues |  | 57.9% |  | 56.3% |  |  |  |  |  | 20.6% |  | 32.8% |  |  |  |  |
| Subscription and support |  | 75,466 |  | 78,252 |  | (2,786) |  | (3.6)% |  | 152,091 |  | 146,241 |  | 5,850 |  | 4.0 % |
| Percentage of subscription and support revenues |  | 70.5% |  | 71.3% |  |  |  |  |  | 40.0% |  | 41.7% |  |  |  |  |
| Total gross profit |  | $175,123 |  | $183,370 |  | $(8,247) |  | (4.5)% |  | $344,630 |  | $396,306 |  | $(51,676) |  | (13.0)% |
| Percentage of net revenues |  | 62.7% |  | 61.9% |  |  |  |  |  | 26.3% |  | 35.6% |  |  |  |  |

[0000950170-25-011087:mdna:77]
Product gross profit decreased $5.5 million or 5.2% for the three months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in product gross profit was primarily due to lower product revenues and higher distribution costs, partially offset by lower reserves for excess and obsolete inventories.

[0000950170-25-011087:mdna:78]
Product gross profit decreased 57.5 million or 23.0% for the six months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in product gross profit was primarily due to lower product revenues, partially offset by lower reserves for excess and obsolete inventory and lower distribution costs.

[0000950170-25-011087:mdna:79]
Subscription and support gross profit decreased $2.8 million or 3.6% for the three months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in subscription and support gross profit was primarily due to lower support revenues.

[0000950170-25-011087:mdna:80]
Subscription and support gross profit increased $5.9 million or 4.0% for the six months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The increase in subscription and support gross profit was primarily due to increased subscription revenues and lower professional fees offset by higher subscription costs.

[0000950170-25-011087:mdna:81]
[same as prior period, unchanged from 0000950170-24-119570:mdna:82]

[0000950170-25-011087:mdna:82]
[same as prior period, unchanged from 0000950170-24-119570:mdna:83]

[0000950170-25-011087:mdna:83]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31,2024 |  | December 31,2023 |  | $Change |  | %Change |  | December 31,2024 |  | December 31,2023 |  | $Change |  | %Change |
| Research and development | $54,883 |  | $52,833 |  | $2,050 |  | 3.9 % |  | $109,334 |  | $110,849 |  | $(1,515) |  | (1.4)% |
| Sales and marketing | 79,967 |  | 85,154 |  | (5,187) |  | (6.1)% |  | 161,350 |  | 177,074 |  | (15,724) |  | (8.9)% |
| General and administrative | 26,064 |  | 25,384 |  | 680 |  | 2.7 % |  | 62,665 |  | 49,257 |  | 13,408 |  | 27.2 % |
| Restructuring and related charges | 1,035 |  | 9,174 |  | (8,139) |  | (88.7)% |  | 2,312 |  | 11,891 |  | (9,579) |  | (80.6)% |
| Amortization of intangible assets | 509 |  | 509 |  | — |  | — |  | 1,021 |  | 1,020 |  | 1 |  | 0.1 % |
| Total operating expenses | $162,458 |  | $173,054 |  | $(10,596) |  | (6.1)% |  | $336,682 |  | $350,091 |  | $(13,409) |  | (3.8)% |

[0000950170-25-011087:mdna:84]
[same as prior period, unchanged from 0000950170-24-119570:mdna:85]

[0000950170-25-011087:mdna:85]
[same as prior period, unchanged from 0000950170-24-119570:mdna:86]

[0000950170-25-011087:mdna:86]
Research and development expenses increased by $2.1 million or 3.9% for the three months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The increase in research and development expenses was primarily due to a $4.6 million increase in personnel costs due to higher headcount and higher compensation and benefits costs and a $0.6 million increase in other expenses primarily consisting of recruiting fees, partially offset by a $3.1 million decrease in contractor costs.

[0000950170-25-011087:mdna:87]
Research and development expenses decreased by $1.5 million or 1.4% for the six months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in research and development expenses was primarily due to a $5.8 million decrease in contractor costs, partially offset by a $1.9 million increase in personnel costs due to higher headcount and higher compensation and benefits costs, a $1.4 million increase in information technology and facility related expenses, and a $1.0 million increase in other expenses primarily consisting of recruiting and professional fees.

[0000950170-25-011087:mdna:88]
[same as prior period, unchanged from 0000950170-24-119570:mdna:88]

[0000950170-25-011087:mdna:89]
[same as prior period, unchanged from 0000950170-24-119570:mdna:89]

[0000950170-25-011087:mdna:90]
Sales and marketing expenses decreased by $5.2 million or 6.1% for the three months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in sales and marketing expenses was primarily due to a $3.2 million decrease in personnel costs primarily due to lower headcount, a $0.4 million decrease in contractor costs and professional fees and a $1.6 million decrease in other expenses primarily related to travel and other marketing event costs.

[0000950170-25-011087:mdna:91]
Sales and marketing expenses decreased by $15.7 million or 8.9% for the six months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The decrease in sales and marketing expenses was primarily due to a $12.4 million decrease in personnel costs due to lower headcount, a $1.5 million decrease in contractor costs and professional fees, a $1.3 million decrease in travel expenses and a $0.5 million decrease in other expenses.

[0000950170-25-011087:mdna:92]
[same as prior period, unchanged from 0000950170-24-119570:mdna:91]

[0000950170-25-011087:mdna:93]
[same as prior period, unchanged from 0000950170-24-119570:mdna:92]

[0000950170-25-011087:mdna:94]
General and administrative expenses increased by $0.7 million or 2.7% for the three months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The increase in general and administrative expenses was primarily due to a $3.0 million increase in system transition costs, a $2.4 million increase in personnel costs, partially offset by a $3.1 million decrease in professional fees, a $1.1 million decrease in facilities related expenses, and a $0.5 million increase in legal costs related to litigation matters, net of insurance recoveries.

[0000950170-25-011087:mdna:95]
General and administrative expenses increased by $13.4 million or 27.2% for the six months ended December 31, 2024 as compared to the corresponding period in fiscal 2024. The increase in general and administrative expenses was primarily due to an $8.8 million increase in legal costs related to litigation matters, net of insurance recoveries, a $7.8 million increase in system transition costs, partially offset by a $2.8 million decrease in professional fees, and a $0.4 million decrease in other expenses primarily facilities related expenses.

[0000950170-25-011087:mdna:96]
[same as prior period, unchanged from 0000950170-24-119570:mdna:94]

[0000950170-25-011087:mdna:97]
For the three and six months ended December 31, 2024, we recorded restructuring and related charges of $1.0 million and $2.3 million, respectively, which primarily consisted of additional severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q2 2024 Plan”, and “Q3 2024 Plan”, each as described in Note 13, Restructuring and Related Charges, in Notes to the Condensed Consolidated Financial Statements included elsewhere in this Report.

[0000950170-25-011087:mdna:98]
For the three and six months ended December 31, 2023, we recorded restructuring and related charges of $9.2 million and $11.9 million, which primarily consisted of severance and benefits costs associated with the reduction-in-force actions related to the “Q1 2024 Plan” and the “Q2 2024 Plan”.

[0000950170-25-011087:mdna:99]
[same as prior period, unchanged from 0000950170-24-119570:mdna:97]

[0000950170-25-011087:mdna:100]
During the three months ended December 31, 2024 and 2023, we recorded $0.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-25-011087:mdna:101]
During the six months ended December 31, 2024 and 2023, we recorded $1.0 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-25-011087:mdna:102]
[same as prior period, unchanged from 0000950170-24-119570:mdna:99]

[0000950170-25-011087:mdna:103]
During the three months ended December 31, 2024 and 2023, we recorded $0.8 million and $1.4 million, respectively, in interest income. The decrease in interest income was primarily related to the lower interest earned on our cash accounts due to lower interest rates as well as lower cash and cash equivalents balances held during the second quarter in fiscal 2025.

[0000950170-25-011087:mdna:104]
During the six months ended December 31, 2024 and 2023, we recorded $1.7 million and $2.7 million, respectively, in interest income. The decrease in interest income is primarily related to the lower interest earned on our cash accounts due to lower interest rates as well as lower cash and cash equivalents balances held during the first half of fiscal 2025.

[0000950170-25-011087:mdna:105]
[same as prior period, unchanged from 0000950170-24-119570:mdna:101]

[0000950170-25-011087:mdna:106]
During the three months ended December 31, 2024 and 2023, we recorded $4.2 million and $4.3 million, respectively, in interest expense related to the debt obligations held under our Amended Credit Agreement. The decrease in interest expense was primarily due to lower average rates under the Amended Credit Agreement.

[0000950170-25-011087:mdna:107]
During each of the six months ended December 31, 2024 and 2023, we recorded $8.6 million in interest expense related to the debt obligations held under the Amended Credit Agreement.

[0000950170-25-011087:mdna:108]
[same as prior period, unchanged from 0000950170-24-119570:mdna:103]

[0000950170-25-011087:mdna:109]
During the three months ended December 31, 2024 and 2023, we recorded other income, net of $0.7 million and other expense, net of $0.4 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-25-011087:mdna:110]
During the six months ended December 31, 2024 and 2023, we recorded other expense, net of less than $0.1 million and other income, net of less than $0.1 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-25-011087:mdna:111]
[same as prior period, unchanged from 0000950170-24-119570:mdna:105]

[0000950170-25-011087:mdna:112]
For the three months ended December 31, 2024 and 2023, we recorded income tax provision of $2.6 million and $3.1 million, respectively.

[0000950170-25-011087:mdna:113]
For the six months ended December 31, 2024 and 2023, we recorded income tax provision of  $4.1 million and $7.6 million, respectively.

[0000950170-25-011087:mdna:114]
The income tax provisions for the three and six months ended December 31, 2024 and 2023 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications System. In addition, the income tax provision for the three months ended December 31, 2024 includes U.S. federal income tax expense of $1.4 million and $0.2 million, respectively.

[0000950170-25-011087:mdna:115]
[same as prior period, unchanged from 0000950170-24-119570:mdna:108]

[0000950170-25-011087:mdna:116]
[same as prior period, unchanged from 0000950170-24-119570:mdna:109]

[0000950170-25-011087:mdna:117]
[same as prior period, unchanged from 0000950170-24-119570:mdna:110]

[0000950170-25-011087:mdna:118]
[same as prior period, unchanged from 0000950170-24-119570:mdna:111]

[0000950170-25-011087:mdna:119]
[same as prior period, unchanged from 0000950170-24-119570:mdna:112]

[0000950170-25-011087:mdna:120]
[same as prior period, unchanged from 0000950170-24-119570:mdna:113]

[0000950170-25-011087:mdna:121]
[same as prior period, unchanged from 0000950170-24-119570:mdna:114]

[0000950170-25-011087:mdna:122]
[same as prior period, unchanged from 0000950170-24-119570:mdna:115]

[0000950170-25-011087:mdna:123]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Cash and cash equivalents |  | $ | 170,322 |  |  | $ | 156,699 |  |

[0000950170-25-011087:mdna:124]
As of December 31, 2024, our principal sources of liquidity consisted of cash and cash equivalents of $170.3 million, accounts receivable, net of $117.6 million, and available borrowings under our 2023 Revolving Facility of $135.8 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest and share repurchases. We believe that our $170.3 million of cash and cash equivalents at December 31, 2024, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0000950170-25-011087:mdna:125]
On May 18, 2022, our Board of Directors (the “Board”) authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022 (as amended, the “2022 Repurchase Program”). A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The 2022 Repurchase Program does not obligate us to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three and six months ended December 31, 2024, the Company did not repurchase any shares of its common stock. As of December 31, 2024, the Company had $50.3 million available for share repurchases under the 2022 Repurchase Program.

[0000950170-25-011087:mdna:126]
[same as prior period, unchanged from 0000950170-24-119570:mdna:119]

[0000950170-25-011087:mdna:127]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount

[0000950170-25-011087:mdna:128]
that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use the proceeds of the loans for working capital and general corporate purposes.

[0000950170-25-011087:mdna:129]
[same as prior period, unchanged from 0000950170-24-119570:mdna:121]

[0000950170-25-011087:mdna:130]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-25-011087:mdna:131]
On August 14, 2024, we entered into an Amendment Number One to the 2023 Credit Agreement the “Amended Credit Agreement.” Under the Amended Credit Agreement, we modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with our operations and activities.

[0000950170-25-011087:mdna:132]
During the three and six months ended December 31, 2024, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0000950170-25-011087:mdna:133]
[same as prior period, unchanged from 0000950170-24-119570:mdna:125]

[0000950170-25-011087:mdna:134]
[same as prior period, unchanged from 0000950170-24-119570:mdna:126]

[0000950170-25-011087:mdna:135]
|  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |
| Net cash provided by operating activities |  | $ | 40,118 |  |  | $ | 109,865 |  |
| Net cash used in investing activities |  |  | (12,325 | ) |  |  | (9,955 | ) |
| Net cash used in financing activities |  |  | (13,995 | ) |  |  | (113,242 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (175 | ) |  |  | (91 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 13,623 |  |  | $ | (13,423 | ) |

[0000950170-25-011087:mdna:136]
[same as prior period, unchanged from 0000950170-24-119570:mdna:128]

[0000950170-25-011087:mdna:137]
Cash flows provided by operations in the six months ended December 31, 2024 were $40.1 million, including our net loss of $3.1 million and non-cash expenses of $54.7 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in inventories and increases in accounts payable, deferred revenue and accrued compensation and benefits. This was partially offset by increases in accounts receivable and other assets as well as decreases in operating lease liabilities and other liabilities.

[0000950170-25-011087:mdna:138]
Cash flows provided by operations in the six months ended December 31, 2023 were $109.9 million, including our net income of $32.7 million and non-cash expenses of $73.4 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in accounts receivable, and increases in deferred revenue and other current and long-term liabilities. This was partially offset by increases in inventories and prepaid expenses and other assets as well as decreases in accounts payable and accrued compensation and benefits.

[0000950170-25-011087:mdna:139]
[same as prior period, unchanged from 0000950170-24-119570:mdna:131]

[0000950170-25-011087:mdna:140]
Cash flows used in investing activities in the six months ended December 31, 2024 were $12.3 million for the purchases of property and equipment and the capitalized software development costs.

[0000950170-25-011087:mdna:141]
Cash flows used in investing activities in the six months ended December 31, 2023 were $10.0 million for the purchases of property and equipment.

[0000950170-25-011087:mdna:142]
[same as prior period, unchanged from 0000950170-24-119570:mdna:134]

[0000950170-25-011087:mdna:143]
Cash flows used in financing activities in the six months ended December 31, 2024 were $14.0 million primarily due to payments of $8.3 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options, a payment of $0.7 million for debt financing costs related to the Amended Credit Agreement, and debt repayments of $5.0 million.

[0000950170-25-011087:mdna:144]
Cash flows used in financing activities in the six months ended December 31, 2023 were $113.2 million primarily due to payments of $33.4 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, share repurchases of $49.9 million under the 2022 Repurchase Program, a $25.0 million payment against our revolving facility, and debt repayments of $5.0 million.

[0000950170-25-011087:mdna:145]
[same as prior period, unchanged from 0000950170-24-119570:mdna:137]

[0000950170-25-011087:mdna:146]
Foreign currency effect on cash and cash equivalents increased in the six months ended December 31, 2024, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the Euro.

[0000950170-25-011087:mdna:147]
[same as prior period, unchanged from 0000950170-24-119570:mdna:139]

[0000950170-25-011087:mdna:148]
As of December 31, 2024, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0000950170-25-011087:mdna:149]
Our debt obligations relate to amounts owed under our Amended Credit Agreement. As of December 31, 2024, we had $185.0 million of debt outstanding, which is payable on quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0000950170-25-011087:mdna:150]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of December 31, 2024, we had non-cancelable commitments to purchase $29.5 million of inventory. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0000950170-25-011087:mdna:151]
We have contractual commitments to our suppliers which represent commitments for future services. As of December 31, 2024, we had contractual commitments of $21.5 million that are due through our fiscal year 2027.

[0000950170-25-011087:mdna:152]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of December 31, 2024, the value of our obligations under operating leases was $57.9 million.

[0000950170-25-011087:mdna:153]
[same as prior period, unchanged from 0000950170-24-119570:mdna:145]

[0000950170-25-011087:mdna:154]
We did not have any material commitments for capital expenditures as of December 31, 2024.

[0000950170-25-011087:mdna:155]
[same as prior period, unchanged from 0000950170-24-119570:mdna:147]

[0000950170-25-011087:mdna:156]
We did not have any off-balance sheet arrangements as of December 31, 2024.
