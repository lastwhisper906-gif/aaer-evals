# EXTR note change history — 0000950170-24-119570 → 0000950170-25-011087


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2024, the Company had commitments to purchase $29.5 million of inventory.
  (was, 2024-10-31, similarity 0.9942):
[0000950170-24-119570:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2024, the Company had commitments to purchase $37.3 million of inventory.

- added (2025-01-30):
[0000950170-25-011087:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year. As of December 31, 2024, the total estimated litigation expense accrual included in the “Other accrued liabilities” in the condensed consolidated balance sheets was $23.5 million for various ongoing litigation matters with probable losses that can be reasonably estimated.

- changed (2025-01-30):
[0000950170-25-011087:note_history:3]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleged direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. On October 21, 2024, the District Court in Dusseldorf, Germany confirmed the withdrawal by Orckit of its complaint, thus concluding this action.
  (was, 2024-10-31, similarity 0.7343):
[0000950170-24-119570:note_history:3]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. On October 17, 2024, Orckit informed the District Court in Dusseldorf, Germany of its intention to withdraw its complaint.

- added (2025-01-30):
[0000950170-25-011087:note_history:4]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleged infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. On December 23, 2024, Orckit withdrew this infringement complaint.

- changed (2025-01-30):
[0000950170-25-011087:note_history:5]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On December 10, 2024, the Federal Court of Justice ruled that the ‘077 patent is invalid.
  (was, 2024-10-31, similarity 0.7218):
[0000950170-24-119570:note_history:5]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals. An oral hearing has been set for December 10, 2024.

- added (2025-01-30):
[0000950170-25-011087:note_history:6]
As a result of the withdrawals and the invalidity ruling, these cases are now concluded in the Company’s favor.

- changed (2025-01-30):
[0000950170-25-011087:note_history:7]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without
  (was, 2024-10-31, similarity 0.6358):
[0000950170-24-119570:note_history:7]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint, which was denied on January 30, 2024. On March 20, 2023, the Company filed a motion to refer questions to the U.S. Copyright Office on the invalidity of SNMP’s copyrights, which was denied on March 18, 2024. The trial date and all other dates were vacated and the court ordered mandatory mediation, which took place in September 2024.

- added (2025-01-30):
[0000950170-25-011087:note_history:8]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. The trial is set for August 5, 2025.

- changed (2025-01-30):
[0000950170-25-011087:note_history:9]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.
  (was, 2024-10-31, similarity 0.9017):
[0000950170-24-119570:note_history:9]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and an oral hearing has been set for March 27, 2025.

- changed (2025-01-30):
[0000950170-25-011087:note_history:10]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. It is not yet known if Mala will appeal the ruling of the German Federal Patent Court.
  (was, 2024-10-31, similarity 0.625):
[0000950170-24-119570:note_history:10]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021 and a hearing date has been set for November 20, 2024.

- changed (2025-01-30):
[0000950170-25-011087:note_history:11]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Fire/Police and Oakland County Employees as the lead plaintiffs. Trial has been scheduled for March 20, 2027.
  (was, 2024-10-31, similarity 0.7677):
[0000950170-24-119570:note_history:11]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of our current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about our business and prospects during the Class Period. The lawsuit seeks unspecified damages. It is expected that the Court will select a lead plaintiff on or around January 7, 2025.

- removed (2025-01-30):
[0000950170-24-119570:note_history:12]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The

- removed (2025-01-30):
[0000950170-24-119570:note_history:13]
Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- removed (2025-01-30):
[0000950170-24-119570:note_history:14]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:15]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2024. The results of operations for the three and six months ended December 31, 2024 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.
  (was, 2024-10-31, similarity 0.775):
[0000950170-24-119570:note_history:15]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2024. The results of operations for the three months ended September 30, 2024 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:16]
There were no recently adopted accounting standards which would have a material effect on the Company's condensed consolidated financial statements and accompanying disclosures.
  (was, 2024-10-31, similarity 0.9593):
[0000950170-24-119570:note_history:16]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures.

- added (2025-01-30):
[0000950170-25-011087:note_history:17]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted.  The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.

- changed (2025-01-30):
[0000950170-25-011087:note_history:18]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.
  (was, 2024-10-31, similarity 0.9366):
[0000950170-24-119570:note_history:18]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:19]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 12,500 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (752 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 11,748 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 172,500 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,634 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 170,866 |  |  |  | 178,265 |  |
| Total debt |  | $ | 182,614 |  |  | $ | 187,591 |  |
  (was, 2024-10-31, similarity 0.9932):
[0000950170-24-119570:note_history:19]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 11,250 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (761 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 10,489 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 176,250 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,819 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 174,431 |  |  |  | 178,265 |  |
| Total debt |  | $ | 184,920 |  |  | $ | 187,591 |  |

- changed (2025-01-30):
[0000950170-25-011087:note_history:20]
As of December 31, 2024, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.
  (was, 2024-10-31, similarity 0.8718):
[0000950170-24-119570:note_history:20]
During the three months ended September 30, 2024, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

- added (2025-01-30):
[0000950170-25-011087:note_history:21]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations and was $0.3 million for each period during the three months ended December 31, 2024 and 2023 and was $0.6 million and $0.5 million for the six months ended December 31, 2024 and 2023, respectively. The interest rate was 6.84% and 7.46% as of December 31, 2024 and 2023, respectively.

- changed (2025-01-30):
[0000950170-25-011087:note_history:22]
As of December 31, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of December 31, 2024. During the three and six months ended December 31, 2024 and 2023, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.
  (was, 2024-10-31, similarity 0.9328):
[0000950170-24-119570:note_history:22]
As of September 30, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of September 30, 2024. During the three months ended September 30, 2024 and 2023, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

- changed (2025-01-30):
[0000950170-25-011087:note_history:23]
The Company had $14.2 million of outstanding letters of credit as of December 31, 2024.
  (was, 2024-10-31, similarity 0.9682):
[0000950170-24-119570:note_history:23]
The Company had $14.2 million of outstanding letters of credit as of September 30, 2024.

- removed (2025-01-30):
[0000950170-24-119570:note_history:24]
Financing costs incurred in connection with obtaining and modifying long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs are included in “Interest expense” in the accompanying condensed consolidated statements of operations. During the three months ended September 30, 2024, the Company capitalized approximately $0.7 million of debt cost related to the Amended Credit Agreement. The remaining unamortized debt issuance cost related to the prior arrangement and the newly capitalized costs will be amortized over the remaining term of the loan arrangement. Amortization of debt issuance costs included in “Interest expense”  were $0.3 million for each of the three months ended September 30, 2024 and 2023. The interest rate as of September 30, 2024 was 7.52% and as of September 30, 2023 was 7.45%.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:25]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 12,500 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (752 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 11,748 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 172,500 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,634 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 170,866 |  |  |  | 178,265 |  |
| Total debt |  | $ | 182,614 |  |  | $ | 187,591 |  |
  (was, 2024-10-31, similarity 0.9932):
[0000950170-24-119570:note_history:25]
|  |  | September 30,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 11,250 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (761 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 10,489 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 176,250 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,819 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 174,431 |  |  |  | 178,265 |  |
| Total debt |  | $ | 184,920 |  |  | $ | 187,591 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:26]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 119,678 |  |  | $ | 149,549 |  |  |  | 272,931 |  |  | $ | 332,301 |  |
| Other |  |  | 11,710 |  |  |  | 13,086 |  |  |  | 23,892 |  |  |  | 25,983 |  |
| Total Americas |  |  | 131,388 |  |  |  | 162,635 |  |  |  | 296,823 |  |  |  | 358,284 |  |
| EMEA |  |  | 128,257 |  |  |  | 110,605 |  |  |  | 213,175 |  |  |  | 254,208 |  |
| APAC |  |  | 19,710 |  |  |  | 23,137 |  |  |  | 38,561 |  |  |  | 37,022 |  |
| Total net revenues |  | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |
  (was, 2024-10-31, similarity 0.7205):
[0000950170-24-119570:note_history:26]
|  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 153,253 |  |  | $ | 182,752 |  |
| Other |  |  | 12,182 |  |  |  | 12,897 |  |
| Total Americas |  |  | 165,435 |  |  |  | 195,649 |  |
| EMEA |  |  | 84,918 |  |  |  | 143,603 |  |
| APAC |  |  | 18,851 |  |  |  | 13,885 |  |
| Total net revenues |  | $ | 269,204 |  |  | $ | 353,137 |  |

- added (2025-01-30):
[0000950170-25-011087:note_history:27]
Geographic Concentrations

- added (2025-01-30):
[0000950170-25-011087:note_history:28]
For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:29]
As of December 31, 2024, the Company had $589.5 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 31% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 34% in fiscal 2026, and the remaining 35% of the balance thereafter.
  (was, 2024-10-31, similarity 0.9306):
[0000950170-24-119570:note_history:29]
As of September 30, 2024, the Company had $576.9 million of remaining performance obligations, which primarily comprised deferred support and deferred SaaS subscription revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 28% in fiscal 2026, and the remaining 29% of the balance thereafter.

- changed (2025-01-30):
[0000950170-25-011087:note_history:30]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable SaaS subscription and support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.
  (was, 2024-10-31, similarity 0.9847):
[0000950170-24-119570:note_history:30]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

- changed (2025-01-30):
[0000950170-25-011087:note_history:31]
Revenue recognized for the three months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $101.3 million and $105.7 million, respectively. Revenue recognized for the six months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $183.3 million and $172.0 million, respectively.
  (was, 2024-10-31, similarity 0.6597):
[0000950170-24-119570:note_history:31]
Revenue recognized for the three months ended September 30, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $100.3 million and $89.7 million, respectively.

- changed (2025-01-30):
[0000950170-25-011087:note_history:32]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.7 million as of December 31, 2024 and June 30, 2024. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2024 and 2023 was $3.1 million and $2.7 million, respectively. Amortization recognized during the six months ended December 31, 2024 and 2023 was $6.1 million and $5.2 million, respectively.
  (was, 2024-10-31, similarity 0.9227):
[0000950170-24-119570:note_history:32]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.2 million and $24.7 million as of September 30, 2024 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2024 and 2023 was $3.0 million and $2.6 million, respectively.

- changed (2025-01-30):
[0000950170-25-011087:note_history:33]
Revenues by Geography
  (was, 2024-10-31, similarity 0.7805):
[0000950170-24-119570:note_history:33]
Revenues by Category

- changed (2025-01-30):
[0000950170-25-011087:note_history:34]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 119,678 |  |  | $ | 149,549 |  |  |  | 272,931 |  |  | $ | 332,301 |  |
| Other |  |  | 11,710 |  |  |  | 13,086 |  |  |  | 23,892 |  |  |  | 25,983 |  |
| Total Americas |  |  | 131,388 |  |  |  | 162,635 |  |  |  | 296,823 |  |  |  | 358,284 |  |
| EMEA |  |  | 128,257 |  |  |  | 110,605 |  |  |  | 213,175 |  |  |  | 254,208 |  |
| APAC |  |  | 19,710 |  |  |  | 23,137 |  |  |  | 38,561 |  |  |  | 37,022 |  |
| Total net revenues |  | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |
  (was, 2024-10-31, similarity 0.7205):
[0000950170-24-119570:note_history:34]
|  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 153,253 |  |  | $ | 182,752 |  |
| Other |  |  | 12,182 |  |  |  | 12,897 |  |
| Total Americas |  |  | 165,435 |  |  |  | 195,649 |  |
| EMEA |  |  | 84,918 |  |  |  | 143,603 |  |
| APAC |  |  | 18,851 |  |  |  | 13,885 |  |
| Total net revenues |  | $ | 269,204 |  |  | $ | 353,137 |  |

- added (2025-01-30):
[0000950170-25-011087:note_history:35]
Geographic Concentrations

- added (2025-01-30):
[0000950170-25-011087:note_history:36]
For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively. For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany and for the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and six months ended December 31, 2024 and 2023.

- changed (2025-01-30):
[0000950170-25-011087:note_history:37]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2024 |  | December 31,2023 |  | December 31,2024 |  | December 31,2023 |
| Westcon Group, Inc. |  | 22% |  | 10% |  | 18% |  | 18% |
| TD Synnex Corporation |  | 17% |  | 24% |  | 19% |  | 21% |
| Jenne, Inc. |  | 15% |  | 23% |  | 18% |  | 25% |
  (was, 2024-10-31, similarity 0.6497):
[0000950170-24-119570:note_history:37]
|  |  | Three Months Ended |
|  |  | September 30,2024 |  | September 30,2023 |
| TD Synnex Corporation |  | 22% |  | 18% |
| Jenne, Inc. |  | 21% |  | 27% |
| Westcon Group, Inc. |  | 15% |  | 25% |

- changed (2025-01-30):
[0000950170-25-011087:note_history:38]
|  |  | December 31,2024 |  | June 30,2024 |
| Jenne, Inc. |  | 26% |  | 64% |
| ScanSource, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |
  (was, 2024-10-31, similarity 0.8642):
[0000950170-24-119570:note_history:38]
|  |  | September 30,2024 |  | June 30,2024 |
| Jenne, Inc. |  | 53% |  | 64% |
| ScanSource, Inc. |  | 11% |  | 11% |
| Exclusive Networks |  | 10% |  | * |
| * Less than 10% of accounts receivable |  |  |  |  |

- removed (2025-01-30):
[0000950170-24-119570:note_history:39]
For the three months ended September 30, 2024, no foreign country accounted for 10% or more of the Company's net revenues. For the three months ended September 30, 2023, the Company generated 14% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three months ended September 30, 2023.

- removed (2025-01-30):
[0000950170-24-119570:note_history:40]
The majority of the Company's net accounts receivable balance with Jenne, Inc. as of September 30, 2024 is current and the Company expects to collect this balance by March 31, 2025.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-01-30):
[0000950170-25-011087:note_history:41]
As of December 31, 2024, the Company had $589.5 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 31% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 34% in fiscal 2026, and the remaining 35% of the balance thereafter.
  (was, 2024-10-31, similarity 0.9306):
[0000950170-24-119570:note_history:41]
As of September 30, 2024, the Company had $576.9 million of remaining performance obligations, which primarily comprised deferred support and deferred SaaS subscription revenues. The Company expects to recognize approximately 43% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 28% in fiscal 2026, and the remaining 29% of the balance thereafter.

- changed (2025-01-30):
[0000950170-25-011087:note_history:42]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable SaaS subscription and support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.
  (was, 2024-10-31, similarity 0.9847):
[0000950170-24-119570:note_history:42]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

- changed (2025-01-30):
[0000950170-25-011087:note_history:43]
Revenue recognized for the three months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $101.3 million and $105.7 million, respectively. Revenue recognized for the six months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $183.3 million and $172.0 million, respectively.
  (was, 2024-10-31, similarity 0.6597):
[0000950170-24-119570:note_history:43]
Revenue recognized for the three months ended September 30, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $100.3 million and $89.7 million, respectively.

- changed (2025-01-30):
[0000950170-25-011087:note_history:44]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.7 million as of December 31, 2024 and June 30, 2024. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2024 and 2023 was $3.1 million and $2.7 million, respectively. Amortization recognized during the six months ended December 31, 2024 and 2023 was $6.1 million and $5.2 million, respectively.
  (was, 2024-10-31, similarity 0.9227):
[0000950170-24-119570:note_history:44]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.2 million and $24.7 million as of September 30, 2024 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2024 and 2023 was $3.0 million and $2.6 million, respectively.

- changed (2025-01-30):
[0000950170-25-011087:note_history:45]
Revenues by Geography
  (was, 2024-10-31, similarity 0.7805):
[0000950170-24-119570:note_history:45]
Revenues by Category

- changed (2025-01-30):
[0000950170-25-011087:note_history:46]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 119,678 |  |  | $ | 149,549 |  |  |  | 272,931 |  |  | $ | 332,301 |  |
| Other |  |  | 11,710 |  |  |  | 13,086 |  |  |  | 23,892 |  |  |  | 25,983 |  |
| Total Americas |  |  | 131,388 |  |  |  | 162,635 |  |  |  | 296,823 |  |  |  | 358,284 |  |
| EMEA |  |  | 128,257 |  |  |  | 110,605 |  |  |  | 213,175 |  |  |  | 254,208 |  |
| APAC |  |  | 19,710 |  |  |  | 23,137 |  |  |  | 38,561 |  |  |  | 37,022 |  |
| Total net revenues |  | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |
  (was, 2024-10-31, similarity 0.7205):
[0000950170-24-119570:note_history:46]
|  | Three Months Ended |  |
|  |  | September 30,2024 |  |  | September 30,2023 |  |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 153,253 |  |  | $ | 182,752 |  |
| Other |  |  | 12,182 |  |  |  | 12,897 |  |
| Total Americas |  |  | 165,435 |  |  |  | 195,649 |  |
| EMEA |  |  | 84,918 |  |  |  | 143,603 |  |
| APAC |  |  | 18,851 |  |  |  | 13,885 |  |
| Total net revenues |  | $ | 269,204 |  |  | $ | 353,137 |  |

- added (2025-01-30):
[0000950170-25-011087:note_history:47]
Geographic Concentrations

- added (2025-01-30):
[0000950170-25-011087:note_history:48]
For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively. For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany and for the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and six months ended December 31, 2024 and 2023.

- removed (2025-01-30):
[0000950170-24-119570:note_history:49]
For the three months ended September 30, 2024, no foreign country accounted for 10% or more of the Company's net revenues. For the three months ended September 30, 2023, the Company generated 14% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three months ended September 30, 2023.
