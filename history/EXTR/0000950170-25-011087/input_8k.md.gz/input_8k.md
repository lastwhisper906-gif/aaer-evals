# EXTR 8-K — 0000950170-25-010203 filed 2025-01-29

## item codes, every 8-K on or before 2025-01-30

- 2025-01-29 0000950170-25-010203 — 2.02, 9.01
- 2024-11-15 0000950170-24-127573 — 5.07, 9.01
- 2024-10-30 0000950170-24-118589 — 2.02, 9.01
- 2024-08-07 0000950170-24-092273 — 2.02, 9.01
- 2024-05-01 0000950170-24-050891 — 2.02, 9.01
- 2024-01-31 0000950170-24-009144 — 2.02, 9.01
- 2024-01-08 0001193125-24-004497 — 5.02
- 2024-01-08 0000950170-24-002958 — 2.02, 9.01
- 2023-11-09 0000950170-23-062050 — 5.03, 5.07, 9.01
- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2025-01-30

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-25-010203:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0000950170-25-010203:8k_2_02:2]
EX-99.1

[0000950170-25-010203:8k_2_02:3]
Exhibit 99.1

[0000950170-25-010203:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0000950170-25-010203:8k_2_02:5]
Extreme Networks Reports Second Quarter Fiscal Year 2025 Financial Results

[0000950170-25-010203:8k_2_02:6]
Consistent Execution Drives Third Quarter of Sequential Revenue Growth, Powering Earnings Above Guidance

[0000950170-25-010203:8k_2_02:7]
Morrisville, NC, January 29, 2025 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its second quarter ended December 31, 2024 that highlight continued market recovery in enterprise networking, and marks Extreme's third consecutive quarter of sequential revenue growth.

[0000950170-25-010203:8k_2_02:8]
"Our competitive win rates continue to improve, especially with larger enterprise customers. Our success is based on the simplicity and feature differentiation of our cloud networking platform and unique enterprise campus fabric solution. Changes in the competitive environment and early traction with our commercial models are creating new growth opportunities for us," said Ed Meyercord, President and Chief Executive Officer.

[0000950170-25-010203:8k_2_02:9]
"In the second quarter we announced our vision for Extreme Platform ONETM, our innovative technology platform, that integrates Extreme's networking and security solutions by collapsing all of our applications into a single interface. We are introducing new AI models at the core of the platform that will drive impactful advances to the networking experience. Platform ONE will drive significant productivity gains for IT teams in network design, deployment, management and commercial operations, by reducing complex tasks from hours to minutes," concluded Meyercord.

[0000950170-25-010203:8k_2_02:10]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, "The continued sequential revenue growth in the second quarter, coupled with higher operating margin and earnings growth, demonstrates the strong operating leverage in our financial model. We expect better than seasonal revenue for third quarter, at the midpoint of our outlook, and further improvement in cash flow generation. For FY25, we expect growth in revenue, along with higher operating margins and cash flow generation, based on the ongoing recovery in our business and prudent management of our expenses."

[0000950170-25-010203:8k_2_02:11]
Fiscal Second Quarter Results:

[0000950170-25-010203:8k_2_02:12]
•
Revenue $279.4 million, down 5.7% year-over-year, and up 3.8% quarter-over-quarter

[0000950170-25-010203:8k_2_02:13]
•
SaaS ARR $181.1 million, up 14.4% year-over-year, and up 4.0% quarter-over-quarter

[0000950170-25-010203:8k_2_02:14]
•
GAAP diluted EPS $0.06, compared to GAAP diluted EPS $0.03 last year and GAAP Loss per share $0.08 last quarter

[0000950170-25-010203:8k_2_02:15]
•
Non-GAAP diluted EPS $0.21, compared to $0.24 last year and $0.17 last quarter

[0000950170-25-010203:8k_2_02:16]
•
GAAP gross margin 62.7% compared to 61.9% last year and 63.0% last quarter

[0000950170-25-010203:8k_2_02:17]
•
Non-GAAP gross margin 63.4% compared to 62.5% last year and 63.7% last quarter

[0000950170-25-010203:8k_2_02:18]
•
GAAP operating profit margin 4.5% compared to GAAP operating profit margin 3.5% last year and GAAP operating loss margin 1.8% last quarter

[0000950170-25-010203:8k_2_02:19]
•
Non-GAAP operating profit margin 14.7% compared to 14.8% last year and 12.4% last quarter

[0000950170-25-010203:8k_2_02:20]
Liquidity:

[0000950170-25-010203:8k_2_02:21]
•
Q2 ending cash balance was $170.3 million, an increase of $10.8 million from the end of Q1 2025 and a decrease of $51.1 million from the end of Q2 in the prior year.

[0000950170-25-010203:8k_2_02:22]
•
Q2 net debt was $14.7 million, a decrease of $13.3 million from net debt of $28.0 million at the end of Q1 2025 and an increase of $41.1 million from net cash of $26.4 million at the end of Q2 in the prior year.

[0000950170-25-010203:8k_2_02:23]
•
During Q2, we generated net cash flow from operations of $21.5 million and had free cash flow of $16.1 million.

[0000950170-25-010203:8k_2_02:24]
Recent Key Highlights:

[0000950170-25-010203:8k_2_02:25]
•
Extreme introduced Extreme Platform ONE, an innovative technology platform that integrates networking, security and AI to drive automation that helps customers reduce complex tasks from hours to minutes. The platform’s AI-powered automation includes conversational, interactive and autonomous AI agents—to assist, advise and accelerate the productivity of networking, security and business teams. CRN Magazine named Platform ONE one of the “Ten Hottest Networking Products of 2024.”

[0000950170-25-010203:8k_2_02:26]
•
Extreme continued its dominance in professional sports, as the Pittsburgh Steelers will deploy state-of-the-art 6GHz Wi-Fi to enhance the fan experience and optimize retail PoS systems, ensuring faster transactions and shorter concession lines. NHL teams such as the Anaheim Ducks, Calgary Flames, Columbus Blue Jackets, St. Louis Blues, and Nashville Predators have deployed Extreme Fabric and ExtremeCloud IQ, to improve in-arena Wi-Fi, deliver immersive fan experiences, support new digital services and secure IoT devices running throughout the arenas.

[0000950170-25-010203:8k_2_02:27]
•
The München Klinik, the largest hospital network in Munich and the number one emergency hospital in the region has invested in Extreme Fabric, Universal switching and ExtremeCloud IQ to provide a more robust and secure network across its five sites. The investment in Extreme will help them advance patient care, better secure patient records and improve the performance of medical devices.

[0000950170-25-010203:8k_2_02:28]
•
Philadelphia International Airport selected Extreme for core routing services as well as secure automation via Extreme Fabric and Extreme’s Network Access Control (NAC) solution. PHL serves over 12 million passengers a year and is upgrading its terminals and technology. Deploying Extreme's technology provides the network team increased agility during construction phases of the projects in addition to daily operations.

[0000950170-25-010203:8k_2_02:29]
•
UK-based law firm Taylor Wessing needed to update its legacy infrastructure across its 28 offices. With Extreme Wireless and ExtremeCloud IQ, the firm will have faster Wi-Fi for employees, streamlined network management for its IT team and a simplified licensing structure that will be easier to manage and scale as the firm continues to grow.

[0000950170-25-010203:8k_2_02:30]
•
The City of Temple, Texas needed to modernize its network infrastructure and help its IT staff better support services across multiple municipal offices for its rapidly growing population. Temple selected Extreme to fully refresh its wired and wireless network and standardize its infrastructure on Extreme Fabric, significantly improving network security, visibility and control.

[0000950170-25-010203:8k_2_02:31]
•
Extreme was recognized as one of the Great Tech Places to Work by NC TECH, and was ranked #33 on Newsweek's 2025 Excellence 1000 Index, demonstrating our commitment to innovation, ethical practices, and sustainability while prioritizing our customers, employees, and global impact. ExtremeCloud Universal ZTNA was also named a winner in the 2025 BIG Innovation Awards and in the TMCNet 2024 Cybersecurity Excellence Awards.

[0000950170-25-010203:8k_2_02:32]
Fiscal Q2 2025 Financial Metrics:

[0000950170-25-010203:8k_2_02:33]
(in millions, except percentages and per share information)

[0000950170-25-010203:8k_2_02:34]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | Change |  |
| Product |  | $ | 172.3 |  |  | $ | 186.6 |  |  | $ | (14.3 | ) |
| Subscription and support |  |  | 107.1 |  |  |  | 109.8 |  |  |  | (2.7 | ) |
| Total net revenue |  | $ | 279.4 |  |  | $ | 296.4 |  |  | $ | (17.0 | ) |
| Gross margin |  |  | 62.7 | % |  |  | 61.9 | % |  |  | 0.8 | % |
| Operating margin |  |  | 4.5 | % |  |  | 3.5 | % |  |  | 1.0 | % |
| Net income |  | $ | 7.4 |  |  | $ | 4.0 |  |  | $ | 3.4 |  |
| Net income per diluted share |  | $ | 0.06 |  |  | $ | 0.03 |  |  | $ | 0.03 |  |

[0000950170-25-010203:8k_2_02:35]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | Change |  |
| Product |  | $ | 172.3 |  |  | $ | 186.6 |  |  | $ | (14.3 | ) |
| Subscription and support |  |  | 107.1 |  |  |  | 109.8 |  |  |  | (2.7 | ) |
| Total net revenue |  | $ | 279.4 |  |  | $ | 296.4 |  |  | $ | (17.0 | ) |
| Gross margin |  |  | 63.4 | % |  |  | 62.5 | % |  |  | 0.9 | % |
| Operating margin |  |  | 14.7 | % |  |  | 14.8 | % |  |  | (0.1 | )% |
| Net income |  | $ | 28.6 |  |  | $ | 31.5 |  |  | $ | (2.9 | ) |
| Net income per diluted share |  | $ | 0.21 |  |  | $ | 0.24 |  |  | $ | (0.03 | ) |

[0000950170-25-010203:8k_2_02:36]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by (used in) operating activities, less capital expenditures for purchases of property and equipment and capitalized software development costs.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property and equipment and capitalized software development costs, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in millions):

[0000950170-25-010203:8k_2_02:37]
| Free Cash Flow | Three Months Ended | Six Months Ended |  |
|  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Cash flow provided by operations | $ | 21.5 |  |  | $ | 34.3 |  |  | $ | 40.1 |  |  | $ | 109.9 |  |
| Less: Property and equipment capital expenditures |  | (5.4 | ) |  |  | (5.7 | ) |  |  | (12.3 | ) |  |  | (10.0 | ) |
| Total free cash flow | $ | 16.1 |  |  | $ | 28.6 |  |  | $ | 27.8 |  |  | $ | 99.9 |  |

[0000950170-25-010203:8k_2_02:38]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud IQ and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue or deferred revenue that are accounted for under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0000950170-25-010203:8k_2_02:39]
Gross Debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0000950170-25-010203:8k_2_02:40]
Net Cash (Debt) is defined as cash and cash equivalents minus gross debt, as shown in the table below (in millions):

[0000950170-25-010203:8k_2_02:41]
| Cash and cash equivalents |  |  | Gross debt |  |  | Net cash (debt) |  |
| $ | 170.3 |  |  | $ | 185.0 |  |  | $ | (14.7 | ) |

[0000950170-25-010203:8k_2_02:42]
Business Outlook:

[0000950170-25-010203:8k_2_02:43]
For its third quarter of fiscal 2025, ending March 31, 2025, the Company is targeting:

[0000950170-25-010203:8k_2_02:44]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ3'25 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 276.0 |  |  | $ | 284.0 |  |
| Gross margin |  | 61.2 | % |  |  | 62.2 | % |
| Operating margin |  | 0.0 | % |  |  | 2.1 | % |
| Earnings (Loss) per share | $ | (0.04 | ) |  | $ | 0.00 |  |
| Shares outstanding used in calculating GAAP EPS |  | 133.3 |  |  |  | 134.7 |  |
| FQ3'25 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 276.0 |  |  | $ | 284.0 |  |
| Gross margin |  | 62.0 | % |  |  | 63.0 | % |
| Operating margin |  | 12.0 | % |  |  | 13.7 | % |
| Earnings per share | $ | 0.16 |  |  | $ | 0.20 |  |
| Diluted Shares outstanding used in calculating non-GAAP EPS |  | 134.7 |  |  |  | 134.7 |  |

[0000950170-25-010203:8k_2_02:45]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY'25 guidance:

[0000950170-25-010203:8k_2_02:46]
|  | FQ3'25 |  |
|  | Gross Margin |  | Operating Margin |  | Earnings (Loss) per Share |  |
| GAAP | 61.2% - 62.2% |  | 0.0% - 2.1% |  | ($0.04) - $0.00 |  |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation | 0.6% |  | 7.4% - 7.8% |  | 0.16 |  |
| Amortization of product intangibles | 0.2% |  | 0.2% |  | 0.01 |  |
| Amortization of non-product intangibles | — |  | 0.2% |  | — |  |
| Restructuring and related charges | — |  | 1.0% |  | 0.02 |  |
| Litigation charges | — |  | 0.7% |  | 0.01 |  |
| System transition cost | — |  | 2.1% |  | 0.04 |  |
| Tax adjustment | — |  | — |  | (0.04) |  |
| Non-GAAP | 62.0% - 63.0% |  | 12.0% - 13.7% |  | $0.16-$0.20 |  |

[0000950170-25-010203:8k_2_02:47]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0000950170-25-010203:8k_2_02:48]
For the full year fiscal 2025, ending June 30, 2025, the Company is targeting (in millions):

[0000950170-25-010203:8k_2_02:49]
|  | Low-End |  |  | High-End |  |
| FY'25 Guidance |  |  |  |  |  |
| Total net revenue | $ | 1,120.0 |  |  | $ | 1,138.0 |  |

[0000950170-25-010203:8k_2_02:50]
Conference Call:

[0000950170-25-010203:8k_2_02:51]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the second quarter results of fiscal 2025 as well as the business outlook for the third quarter of fiscal 2025 ending March 31, 2025, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Extreme Networks Q2'25 Earnings Registration) and you will be provided with dial in details. If you would like to participate in the Q&A, please register here: Q&A Registration Link. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0000950170-25-010203:8k_2_02:52]
About Extreme:

[0000950170-25-010203:8k_2_02:53]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Tens of thousands customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0000950170-25-010203:8k_2_02:54]
Extreme Networks, ExtremeCloud, Extreme Platform ONE, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0000950170-25-010203:8k_2_02:55]
Non-GAAP Financial Measures:

[0000950170-25-010203:8k_2_02:56]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, debt refinancing charges and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0000950170-25-010203:8k_2_02:57]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0000950170-25-010203:8k_2_02:58]
Forward-Looking Statements:

[0000950170-25-010203:8k_2_02:59]
For more information about factors that could cause actual results and other future events to differ materially from those suggested or indicated by such forward-looking statements, see “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2024, Quarterly Report on 10-Q for the quarter ended September 30, 2024 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0000950170-25-010203:8k_2_02:60]
###

[0000950170-25-010203:8k_2_02:61]
EXTREME NETWORKS, INC.

[0000950170-25-010203:8k_2_02:62]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-25-010203:8k_2_02:63]
(In thousands, except per share amounts)

[0000950170-25-010203:8k_2_02:64]
(Unaudited)

[0000950170-25-010203:8k_2_02:65]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 170,322 |  |  | $ | 156,699 |  |
| Accounts receivable, net |  |  | 117,575 |  |  |  | 89,518 |  |
| Inventories |  |  | 132,278 |  |  |  | 141,032 |  |
| Prepaid expenses and other current assets |  |  | 75,114 |  |  |  | 79,677 |  |
| Total current assets |  |  | 495,289 |  |  |  | 466,926 |  |
| Property and equipment, net |  |  | 36,735 |  |  |  | 43,744 |  |
| Operating lease right-of-use assets, net |  |  | 41,609 |  |  |  | 44,145 |  |
| Goodwill |  |  | 391,981 |  |  |  | 393,709 |  |
| Intangible assets, net |  |  | 8,221 |  |  |  | 10,613 |  |
| Other assets |  |  | 107,109 |  |  |  | 83,457 |  |
| Total assets |  | $ | 1,080,944 |  |  | $ | 1,042,594 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 52,371 |  |  | $ | 51,423 |  |
| Accrued compensation and benefits |  |  | 59,521 |  |  |  | 42,064 |  |
| Accrued warranty |  |  | 10,036 |  |  |  | 10,942 |  |
| Current portion of deferred revenue |  |  | 312,050 |  |  |  | 306,114 |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $752 and $674, respectively |  |  | 11,748 |  |  |  | 9,326 |  |
| Current portion, operating lease liabilities |  |  | 10,997 |  |  |  | 10,547 |  |
| Other accrued liabilities |  |  | 77,499 |  |  |  | 87,172 |  |
| Total current liabilities |  |  | 534,222 |  |  |  | 517,588 |  |
| Deferred revenue, less current portion |  |  | 277,419 |  |  |  | 268,909 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $1,634 and $1,735, respectively |  |  | 170,866 |  |  |  | 178,265 |  |
| Operating lease liabilities, less current portion |  |  | 37,994 |  |  |  | 41,466 |  |
| Deferred income taxes |  |  | 6,771 |  |  |  | 7,978 |  |
| Other long-term liabilities |  |  | 2,464 |  |  |  | 3,106 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 150,866 and 148,503 shares issued, respectively; 132,647 and 130,284 shares outstanding, respectively |  |  | 151 |  |  |  | 149 |  |
| Additional paid-in-capital |  |  | 1,253,296 |  |  |  | 1,220,379 |  |
| Accumulated other comprehensive loss |  |  | (19,354 | ) |  |  | (15,483 | ) |
| Accumulated deficit |  |  | (945,084 | ) |  |  | (941,962 | ) |
| Treasury stock at cost, 18,219 and 18,219 shares, respectively |  |  | (237,801 | ) |  |  | (237,801 | ) |
| Total stockholders’ equity |  |  | 51,208 |  |  |  | 25,282 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,080,944 |  |  | $ | 1,042,594 |  |

[0000950170-25-010203:8k_2_02:66]
EXTREME NETWORKS, INC.

[0000950170-25-010203:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-25-010203:8k_2_02:68]
(In thousands, except per share amounts)

[0000950170-25-010203:8k_2_02:69]
(Unaudited)

[0000950170-25-010203:8k_2_02:70]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 172,261 |  |  | $ | 186,611 |  |  | $ | 334,545 |  |  | $ | 440,094 |  |
| Subscription and support |  |  | 107,094 |  |  |  | 109,766 |  |  |  | 214,014 |  |  |  | 209,420 |  |
| Total net revenues |  |  | 279,355 |  |  |  | 296,377 |  |  |  | 548,559 |  |  |  | 649,514 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 72,604 |  |  |  | 81,493 |  |  |  | 142,006 |  |  |  | 190,029 |  |
| Subscription and support |  |  | 31,628 |  |  |  | 31,514 |  |  |  | 61,923 |  |  |  | 63,179 |  |
| Total cost of revenues |  |  | 104,232 |  |  |  | 113,007 |  |  |  | 203,929 |  |  |  | 253,208 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 99,657 |  |  |  | 105,118 |  |  |  | 192,539 |  |  |  | 250,065 |  |
| Subscription and support |  |  | 75,466 |  |  |  | 78,252 |  |  |  | 152,091 |  |  |  | 146,241 |  |
| Total gross profit |  |  | 175,123 |  |  |  | 183,370 |  |  |  | 344,630 |  |  |  | 396,306 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 54,883 |  |  |  | 52,833 |  |  |  | 109,334 |  |  |  | 110,849 |  |
| Sales and marketing |  |  | 79,967 |  |  |  | 85,154 |  |  |  | 161,350 |  |  |  | 177,074 |  |
| General and administrative |  |  | 26,064 |  |  |  | 25,384 |  |  |  | 62,665 |  |  |  | 49,257 |  |
| Restructuring and related charges |  |  | 1,035 |  |  |  | 9,174 |  |  |  | 2,312 |  |  |  | 11,891 |  |
| Amortization of intangible assets |  |  | 509 |  |  |  | 509 |  |  |  | 1,021 |  |  |  | 1,020 |  |
| Total operating expenses |  |  | 162,458 |  |  |  | 173,054 |  |  |  | 336,682 |  |  |  | 350,091 |  |
| Operating income |  |  | 12,665 |  |  |  | 10,316 |  |  |  | 7,948 |  |  |  | 46,215 |  |
| Interest income |  |  | 839 |  |  |  | 1,430 |  |  |  | 1,685 |  |  |  | 2,656 |  |
| Interest expense |  |  | (4,179 | ) |  |  | (4,269 | ) |  |  | (8,601 | ) |  |  | (8,587 | ) |
| Other income (expense), net |  |  | 661 |  |  |  | (420 | ) |  |  | (60 | ) |  |  | 12 |  |
| Income before income taxes |  |  | 9,986 |  |  |  | 7,057 |  |  |  | 972 |  |  |  | 40,296 |  |
| Provision for income taxes |  |  | 2,604 |  |  |  | 3,069 |  |  |  | 4,094 |  |  |  | 7,632 |  |
| Net income (loss) |  | $ | 7,382 |  |  | $ | 3,988 |  |  | $ | (3,122 | ) |  | $ | 32,664 |  |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | 0.06 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |  | $ | 0.25 |  |
| Net income (loss) per share – diluted |  | $ | 0.06 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |  | $ | 0.25 |  |
| Shares used in per share calculation – basic |  |  | 132,381 |  |  |  | 128,987 |  |  |  | 131,778 |  |  |  | 128,885 |  |
| Shares used in per share calculation – diluted |  |  | 134,107 |  |  |  | 131,514 |  |  |  | 131,778 |  |  |  | 132,786 |  |

[0000950170-25-010203:8k_2_02:71]
EXTREME NETWORKS, INC.

[0000950170-25-010203:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-25-010203:8k_2_02:73]
(In thousands)

[0000950170-25-010203:8k_2_02:74]
(Unaudited)

[0000950170-25-010203:8k_2_02:75]
|  |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income (loss) |  | $ | (3,122 | ) |  | $ | 32,664 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 7,804 |  |  |  | 9,485 |  |
| Amortization of intangible assets |  |  | 2,251 |  |  |  | 3,064 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 4,894 |  |  |  | 5,891 |  |
| Provision for credit losses |  |  | 27 |  |  |  | 82 |  |
| Share-based compensation |  |  | 41,219 |  |  |  | 40,876 |  |
| Deferred income taxes |  |  | (987 | ) |  |  | (21 | ) |
| Provision (Benefit) for excess and obsolete inventory(1) |  |  | (271 | ) |  |  | 16,043 |  |
| Non-cash interest expense |  |  | 594 |  |  |  | 532 |  |
| Other |  |  | (801 | ) |  |  | (2,481 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (28,083 | ) |  |  | 69,915 |  |
| Inventories(1) |  |  | 411 |  |  |  | (80,595 | ) |
| Prepaid expenses and other assets |  |  | (9,969 | ) |  |  | (7,850 | ) |
| Accounts payable |  |  | 1,177 |  |  |  | (12,263 | ) |
| Accrued compensation and benefits |  |  | 16,995 |  |  |  | (20,625 | ) |
| Operating lease liabilities |  |  | (5,375 | ) |  |  | (6,444 | ) |
| Deferred revenue |  |  | 17,421 |  |  |  | 48,272 |  |
| Other current and long-term liabilities |  |  | (4,067 | ) |  |  | 13,320 |  |
| Net cash provided by operating activities |  |  | 40,118 |  |  |  | 109,865 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures |  |  | (12,325 | ) |  |  | (9,955 | ) |
| Net cash used in investing activities |  |  | (12,325 | ) |  |  | (9,955 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Net payments on revolving facility |  |  | — |  |  |  | (25,000 | ) |
| Payments on debt obligations |  |  | (5,000 | ) |  |  | (5,000 | ) |
| Payments on debt financing costs |  |  | (695 | ) |  |  | — |  |
| Repurchase of common stock |  |  | — |  |  |  | (49,855 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (8,300 | ) |  |  | (33,387 | ) |
| Net cash used in financing activities |  |  | (13,995 | ) |  |  | (113,242 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (175 | ) |  |  | (91 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 13,623 |  |  |  | (13,423 | ) |
| Cash and cash equivalents at beginning of period |  |  | 156,699 |  |  |  | 234,826 |  |
| Cash and cash equivalents at end of period |  | $ | 170,322 |  |  | $ | 221,403 |  |
| (1) The prior period amounts have been reclassified to conform to the current period presentation |  |  |  |  |  |  |

[0000950170-25-010203:8k_2_02:76]
Extreme Networks, Inc.

[0000950170-25-010203:8k_2_02:77]
Non-GAAP Measures of Financial Performance

[0000950170-25-010203:8k_2_02:78]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and free cash flow.

[0000950170-25-010203:8k_2_02:79]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0000950170-25-010203:8k_2_02:80]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0000950170-25-010203:8k_2_02:81]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0000950170-25-010203:8k_2_02:82]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, amortization of intangibles, restructuring and related charges, system transition costs, litigation charges, debt refinancing charges and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0000950170-25-010203:8k_2_02:83]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0000950170-25-010203:8k_2_02:84]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0000950170-25-010203:8k_2_02:85]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0000950170-25-010203:8k_2_02:86]
Restructuring and related charges. Restructuring and related charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0000950170-25-010203:8k_2_02:87]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution and our configure, price, quote solution. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency, making it difficult to contribute to a meaningful evaluation of our operating performance.

[0000950170-25-010203:8k_2_02:88]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for a non-recurring pending litigation offset by any proceeds received or expected to be received from insurance.

[0000950170-25-010203:8k_2_02:89]
Debt refinancing charges. Debt refinancing charges consist of costs that were not capitalizable and are included in other income (expense), that occurred in conjunction with the amendment related to our outstanding credit facility.

[0000950170-25-010203:8k_2_02:90]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0000950170-25-010203:8k_2_02:91]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0000950170-25-010203:8k_2_02:92]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Canadian, German and Indian subsidiaries which perform research and development and sales and marketing activities for the Company, as well as the Company’s Irish trading subsidiaries.

[0000950170-25-010203:8k_2_02:93]
EXTREME NETWORKS, INC.

[0000950170-25-010203:8k_2_02:94]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-25-010203:8k_2_02:95]
GAAP TO NON-GAAP RECONCILIATION

[0000950170-25-010203:8k_2_02:96]
(In thousands, except percentages and per share amounts)

[0000950170-25-010203:8k_2_02:97]
(Unaudited)

[0000950170-25-010203:8k_2_02:98]
| Revenues | Three Months Ended | Six Months Ended |  |
|  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Revenues – GAAP | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |

[0000950170-25-010203:8k_2_02:99]
| Non-GAAP Gross Margin | Three Months Ended | Six Months Ended |  |
|  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Gross profit – GAAP | $ | 175,123 |  |  | $ | 183,370 |  |  | $ | 344,630 |  |  | $ | 396,306 |  |
| Gross margin – GAAP percentage |  | 62.7 | % |  |  | 61.9 | % |  |  | 62.8 | % |  |  | 61.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 680 |  |  |  | 464 |  |  |  | 1,298 |  |  |  | 947 |  |
| Share-based compensation expense, Subscription and support |  | 798 |  |  |  | 749 |  |  |  | 1,487 |  |  |  | 1,615 |  |
| Amortization of intangibles, Product |  | 589 |  |  |  | 593 |  |  |  | 1,195 |  |  |  | 1,737 |  |
| Amortization of intangibles, Subscription and support |  | — |  |  |  | — |  |  |  | — |  |  |  | 272 |  |
| Total adjustments to GAAP gross profit | $ | 2,067 |  |  | $ | 1,806 |  |  | $ | 3,980 |  |  | $ | 4,571 |  |
| Gross profit – non-GAAP | $ | 177,190 |  |  | $ | 185,176 |  |  | $ | 348,610 |  |  | $ | 400,877 |  |
| Gross margin – non-GAAP percentage |  | 63.4 | % |  |  | 62.5 | % |  |  | 63.6 | % |  |  | 61.7 | % |

[0000950170-25-010203:8k_2_02:100]
| Non-GAAP Operating Margin | Three Months Ended | Six Months Ended |  |
|  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| GAAP operating income | $ | 12,665 |  |  | $ | 10,316 |  |  | $ | 7,948 |  |  | $ | 46,215 |  |
| GAAP operating margin |  | 4.5 | % |  |  | 3.5 | % |  |  | 1.4 | % |  |  | 7.1 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,478 |  |  |  | 1,213 |  |  |  | 2,785 |  |  |  | 2,562 |  |
| Share-based compensation expense, R&D |  | 4,467 |  |  |  | 4,435 |  |  |  | 8,680 |  |  |  | 8,812 |  |
| Share-based compensation expense, S&M |  | 7,596 |  |  |  | 7,535 |  |  |  | 14,478 |  |  |  | 14,523 |  |
| Share-based compensation expense, G&A |  | 7,911 |  |  |  | 7,774 |  |  |  | 15,276 |  |  |  | 14,979 |  |
| Restructuring and related charges |  | 1,035 |  |  |  | 9,174 |  |  |  | 2,312 |  |  |  | 11,891 |  |
| Litigation charges |  | 877 |  |  |  | 1,353 |  |  |  | 11,593 |  |  |  | 2,813 |  |
| System transition costs |  | 4,026 |  |  |  | 1,030 |  |  |  | 9,371 |  |  |  | 1,599 |  |
| Amortization of intangibles |  | 1,098 |  |  |  | 1,102 |  |  |  | 2,216 |  |  |  | 3,029 |  |
| Total adjustments to GAAP operating income | $ | 28,488 |  |  | $ | 33,616 |  |  |  | 66,711 |  |  |  | 60,208 |  |
| Non-GAAP operating income | $ | 41,153 |  |  | $ | 43,932 |  |  | $ | 74,659 |  |  | $ | 106,423 |  |
| Non-GAAP operating margin |  | 14.7 | % |  |  | 14.8 | % |  |  | 13.6 | % |  |  | 16.4 | % |

[0000950170-25-010203:8k_2_02:101]
| Non-GAAP Net Income (Loss) | Three Months Ended | Six Months Ended |  |
|  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| GAAP net income (loss) | $ | 7,382 |  |  | $ | 3,988 |  |  | $ | (3,122 | ) |  | $ | 32,664 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 21,452 |  |  |  | 20,957 |  |  |  | 41,219 |  |  |  | 40,876 |  |
| Restructuring and related charges |  | 1,035 |  |  |  | 9,174 |  |  |  | 2,312 |  |  |  | 11,891 |  |
| Litigation charges |  | 877 |  |  |  | 1,353 |  |  |  | 11,593 |  |  |  | 2,813 |  |
| System transition costs |  | 4,026 |  |  |  | 1,030 |  |  |  | 9,371 |  |  |  | 1,599 |  |
| Amortization of intangibles |  | 1,098 |  |  |  | 1,102 |  |  |  | 2,216 |  |  |  | 3,029 |  |
| Debt refinancing charges, Other income (expense) |  | — |  |  |  | — |  |  |  | 79 |  |  |  | — |  |
| Tax effect of non-GAAP adjustments |  | (7,297 | ) |  |  | (6,129 | ) |  |  | (12,695 | ) |  |  | (14,857 | ) |
| Total adjustments to GAAP net income (loss) | $ | 21,191 |  |  | $ | 27,487 |  |  | $ | 54,095 |  |  | $ | 45,351 |  |
| Non-GAAP net income | $ | 28,573 |  |  | $ | 31,475 |  |  | $ | 50,973 |  |  | $ | 78,015 |  |
| Earnings (Loss) per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) per share – diluted | $ | 0.06 |  |  | $ | 0.03 |  |  | $ | (0.02 | ) |  | $ | 0.25 |  |
| Non-GAAP net income (loss) per share – diluted | $ | 0.21 |  |  | $ | 0.24 |  |  | $ | 0.38 |  |  | $ | 0.59 |  |
| Shares used in net income (loss) per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 132,381 |  |  |  | 128,987 |  |  |  | 131,778 |  |  |  | 128,885 |  |
| Potentially dilutive equity awards |  | 1,726 |  |  |  | 2,527 |  |  |  | 1,462 |  |  |  | 3,901 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 134,107 |  |  |  | 131,514 |  |  |  | 133,240 |  |  |  | 132,786 |  |
