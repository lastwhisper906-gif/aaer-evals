# EXTR 8-K — 0001078271-15-000050 filed 2015-05-06

## item codes, every 8-K on or before 2015-05-07

- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2015-05-07

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-15-000050:8k_2_02:1]
EX-99.1
2
extr8-kq315ex991.htm
EARNINGS PRESS RELEASE

[0001078271-15-000050:8k_2_02:2]
EXTR 8-K Q3'15 EX 99.1

[0001078271-15-000050:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-15-000050:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3456 |  | 408/579-3483 |
| fyoshino@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-15-000050:8k_2_02:5]
Extreme Networks Reports Third Quarter Fiscal Year 2015 Financial Results

[0001078271-15-000050:8k_2_02:6]
GAAP Revenue of $119.6 million

[0001078271-15-000050:8k_2_02:7]
GAAP EPS Loss of $0.24

[0001078271-15-000050:8k_2_02:8]
Non-GAAP Revenue of $120.4 million

[0001078271-15-000050:8k_2_02:9]
Non-GAAP EPS Loss of $0.08

[0001078271-15-000050:8k_2_02:10]
SAN JOSE, Calif., May 6, 2015 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for the third quarter of fiscal year 2015, ended March 31, 2015.  GAAP revenue was $119.6 million and non-GAAP revenue was $120.4 million.  GAAP net loss for the third fiscal quarter was $23.5 million, or $0.24 per share, and non-GAAP net loss was $7.9 million, or $0.08 per share.

[0001078271-15-000050:8k_2_02:11]
“Our third fiscal quarter was clearly disappointing as we saw weakness from certain higher education and venue customers as well as deferred sales in Europe due to the strong U.S. dollar,” stated Ed Meyercord, president and CEO of Extreme Networks.  “Although we see normal seasonality in fiscal Q4, the prevailing headwinds are hindering a quick rebound.  As we look out to fiscal 2016, we are encouraged by the E-Rate filings numbers, however until the schools and districts receive final approval and schedule installation, it is difficult to quantify the timing and impact to our business,” Meyercord continued.  “That said, our intention is to adopt a focused strategy that builds on our strengths and competitive position in growth sectors of our industry and is closely aligned with our structure.”

[0001078271-15-000050:8k_2_02:12]
Recent Key Events:

[0001078271-15-000050:8k_2_02:13]
| • | Extreme Networks appoints Board Chairman Ed Meyercord as its President and Chief Executive Officer effective April 19, 2015. |

[0001078271-15-000050:8k_2_02:14]
| • | Extreme extends strategic leadership and experience to R&D with the promotion of Eric Broockman to CTO and executive vice president of engineering adding to his current responsibility as CTO, a role he has served the past 14 months. Broockman holds numerous U.S. patents, is an active inventor, and was a National Science Foundation Fellow. |

[0001078271-15-000050:8k_2_02:15]
| • | Extreme strengthens management team with three new executive appointments, announcing the promotions of Bob Gault as executive vice president worldwide sales, channel and services, Eileen Brooker as executive vice president of global alliances and strategic accounts, and Norman Rice as executive vice president of global marketing and corporate development. These executives have demonstrated an unwavering commitment to customers and a passion for the highest levels of service in the networking industry throughout their careers. |

[0001078271-15-000050:8k_2_02:16]
| • | Extreme Networks wins Network Computing's new product of the year award for Purview Application Analytics. Readers voted Extreme Networks' Purview™ as the best new-to-market product, highlighting its differentiated capabilities that help transform the network into a strategic |

[0001078271-15-000050:8k_2_02:17]
business asset. Purview has been deployed by a wide variety of organizations including large universities, government agencies, healthcare organizations, and stadiums.

[0001078271-15-000050:8k_2_02:18]
| • | Extreme Networks announces No Compromise Wi-Fi package for Aruba and HP customers delivering unprecedented value and a strong and stable alternative with proven and long-standing wired and wireless integration, application analytics, advanced policy administration and over the air security that is managed from a single interface. |

[0001078271-15-000050:8k_2_02:19]
| • | Extreme Networks awarded 5-star rating in CRN's 2015 Partner Program Guide. This annual directory is the definitive listing of technology vendors that solution providers rely on to deliver products through the IT channel. The 5-Star Partner Program rating recognizes an elite subset of companies that offer solution providers the best partnering elements in their channel programs. |

[0001078271-15-000050:8k_2_02:20]
| • | Extreme Networks’ Bob Gault honored as 2015 Channel Chief and as one of CRN's 50 Most Influential Leaders. Mr. Gault has been named to the prestigious list of the 2015 CRN Channel Chiefs as well as earning the distinction as one of the 50 Most Influential Leaders. The two honors recognize top channel executives who have demonstrated leadership and accomplishments on behalf of their partners. |

[0001078271-15-000050:8k_2_02:21]
Fiscal Q3 2015 Financial Metrics:

[0001078271-15-000050:8k_2_02:22]
|  |  | Third Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2015 |  | 2014 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 86.5 |  |  | $ | 109.9 |  |  | $ | (23.4 | ) |  | (21 | )% |
| Service |  | $ | 33.1 |  |  | $ | 31.9 |  |  | $ | 1.2 |  |  | 4 | % |
| Total Net Revenue |  | $ | 119.6 |  |  | $ | 141.8 |  |  | $ | (22.2 | ) |  | (16 | )% |
| Gross Margin |  | 48.3 | % |  | 50.0 | % |  | (1.7 | )% |  | (3 | )% |
| Operating (Loss) Margin |  | (17.8 | )% |  | (16.5 | )% |  | (1.1 | )% |  | 7 | % |
| Net Loss |  | $ | (23.5 | ) |  | $ | (25.1 | ) |  | $ | 1.6 |  |  | (6 | )% |
| Loss per diluted share |  | $ | (0.24 | ) |  | $ | (0.26 | ) |  | $ | 0.02 |  |  | (8 | )% |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 86.5 |  |  | $ | 109.9 |  |  | $ | (23.4 | ) |  | (21 | )% |
| Service |  | $ | 33.9 |  |  | $ | 33.8 |  |  | $ | 0.1 |  |  | — | % |
| Total Net Revenue |  | $ | 120.4 |  |  | $ | 143.7 |  |  | $ | (23.3 | ) |  | (16 | )% |
| Gross Margin |  | 52.6 | % |  | 55.3 | % |  | (2.7 | )% |  | (5 | )% |
| Operating (Loss) Margin |  | (4.7 | )% |  | 2.3 | % |  | (7.0 | )% |  | (304 | )% |
| Net (Loss) Income |  | $ | (7.9 | ) |  | $ | 1.6 |  |  | $ | (9.6 | ) |  | (600 | )% |
| (Loss) Earnings per diluted share |  | $ | (0.08 | ) |  | $ | 0.02 |  |  | $ | (0.10 | ) |  | (500 | )% |

[0001078271-15-000050:8k_2_02:23]
| • | Cash and investments ended the quarter at $75.6 million, as compared to $109.3 million from the prior quarter. |

[0001078271-15-000050:8k_2_02:24]
| • | Accounts receivable balance ending Q3 was $78.7 million, with days sales outstanding (DSO) of 59. |

[0001078271-15-000050:8k_2_02:25]
| • | Inventory ending Q3 was $66.8 million, an increase of $12.4 million from the prior quarter. |

[0001078271-15-000050:8k_2_02:26]
Business Outlook:

[0001078271-15-000050:8k_2_02:27]
For its fourth quarter of fiscal 2015 ending June 30, 2015, the Company is targeting GAAP revenue in a range of $124.2 million to $134.2 million with non-GAAP revenue in a range of $125 million to $135 million. GAAP gross margin is targeted between 49.0% and 50.5% and non-GAAP gross margin targeted between 53.5% and 54.5%. Operating expenses are targeted to be between $77.5 million and $80.5 million on a GAAP basis and $69.0 million to $72.0 million on a non-GAAP basis. GAAP net loss is targeted to be between $14.5 million to $18.5 million, or $0.15 to $0.19 per share.  Non-GAAP earnings are targeted in a range of a net loss of $4.0 million to break even, or a loss of $0.04 to net income of $0.00 per share. The GAAP and non-GAAP net (loss) income targets are based on an estimated 100 million average outstanding shares. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses and the purchase accounting adjustment related to deferred service revenue.

[0001078271-15-000050:8k_2_02:28]
Conference Call:

[0001078271-15-000050:8k_2_02:29]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the third fiscal quarter results and fourth fiscal quarter business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through May 5, 2016.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #:20788580.

[0001078271-15-000050:8k_2_02:30]
About Extreme Networks:

[0001078271-15-000050:8k_2_02:31]
Extreme Networks, Inc. (EXTR) is a customer-focused company with advanced networking technology solutions and service platforms that address business critical challenges. Extreme Networks backs these solutions with our best-in-industry customer support model. Extreme Networks is headquartered in San Jose, CA and has more than 14,000 customers in over 80 countries. For more information, visit the company's website at http://www.extremenetworks.com

[0001078271-15-000050:8k_2_02:32]
Extreme Networks and the Extreme Networks logo are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries. All other names are the property of their respective owners.

[0001078271-15-000050:8k_2_02:33]
Non-GAAP Financial Measures:

[0001078271-15-000050:8k_2_02:34]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income/(loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, and share-based compensation.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the

[0001078271-15-000050:8k_2_02:35]
Company's marketplace performance, and the Company's ability to generate cash from operations. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-15-000050:8k_2_02:36]
Forward Looking Statements:

[0001078271-15-000050:8k_2_02:37]
Statements in this release concerning the Company’s business prospects, future financial and operating results, and overall future prospects are forward-looking statements that involve a number of uncertainties and risks. Actual results or events could differ materially from those anticipated in those forward-looking statements as a result of certain factors, including: failure to achieve targeted revenues, increased price competition, product technology developments, ongoing uncertainty in global economic conditions, infrastructure development or customer demand, collectability of receivables, the ability to integrate the business of Extreme and Enterasys effectively,  the ability to meet current financial covenants,  inability to anticipate demand from end customers, dependencies on third parties to manufacture our products, delays in development and commercialization of products under development, and ongoing litigation.

[0001078271-15-000050:8k_2_02:38]
EXTREME NETWORKS, INC.

[0001078271-15-000050:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-15-000050:8k_2_02:40]
(In thousands, except share and per share amounts)

[0001078271-15-000050:8k_2_02:41]
(Unaudited)

[0001078271-15-000050:8k_2_02:42]
|  | March 31, 2015 |  | June 30, 2014 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 74,067 |  |  | $ | 73,190 |  |
| Short-term investments | 1,506 |  |  | 32,692 |  |
| Accounts receivable, net of allowances of $4,344 at March 31, 2015 and $3,618 at June 30, 2014 | 78,727 |  |  | 124,664 |  |
| Inventories | 66,811 |  |  | 57,109 |  |
| Deferred income taxes | 797 |  |  | 1,058 |  |
| Prepaid expenses and other current assets | 10,069 |  |  | 14,143 |  |
| Total current assets | 231,977 |  |  | 302,856 |  |
| Property and equipment, net | 42,399 |  |  | 46,554 |  |
| Intangible assets, net | 61,096 |  |  | 87,459 |  |
| Goodwill | 70,877 |  |  | 70,877 |  |
| Other assets | 25,029 |  |  | 18,686 |  |
| Total assets | $ | 431,378 |  |  | $ | 526,432 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 9,750 |  |  | $ | 29,688 |  |
| Accounts payable | 46,378 |  |  | 37,308 |  |
| Accrued compensation and benefits | 20,502 |  |  | 26,677 |  |
| Accrued warranty | 7,879 |  |  | 7,551 |  |
| Deferred revenue, net | 73,206 |  |  | 74,735 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 35,687 |  |  | 31,992 |  |
| Other accrued liabilities | 29,820 |  |  | 38,357 |  |
| Total current liabilities | 223,222 |  |  | 246,308 |  |
| Deferred revenue, less current portion | 23,141 |  |  | 22,942 |  |
| Long-term debt, less current portion | 58,750 |  |  | 91,875 |  |
| Deferred income taxes | 2,572 |  |  | — |  |
| Other long-term liabilities | 7,934 |  |  | 8,595 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 115,759 |  |  | 156,712 |  |
| Total liabilities and stockholders’ equity | $ | 431,378 |  |  | $ | 526,432 |  |

[0001078271-15-000050:8k_2_02:43]
EXTREME NETWORKS, INC.

[0001078271-15-000050:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000050:8k_2_02:45]
(In thousands, except per share amounts)

[0001078271-15-000050:8k_2_02:46]
(Unaudited)

[0001078271-15-000050:8k_2_02:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 86,527 |  |  | $ | 109,891 |  |  | $ | 301,700 |  |  | $ | 290,001 |  |
| Service | 33,063 |  |  | 31,871 |  |  | 101,372 |  |  | 74,260 |  |
| Total net revenues | 119,590 |  |  | 141,762 |  |  | 403,072 |  |  | 364,261 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 49,761 |  |  | 58,703 |  |  | 164,282 |  |  | 153,112 |  |
| Service | 12,105 |  |  | 12,204 |  |  | 35,377 |  |  | 26,742 |  |
| Total cost of revenues | 61,866 |  |  | 70,907 |  |  | 199,659 |  |  | 179,854 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 36,766 |  |  | 51,188 |  |  | 137,418 |  |  | 136,889 |  |
| Service | 20,958 |  |  | 19,667 |  |  | 65,995 |  |  | 47,518 |  |
| Total gross profit | 57,724 |  |  | 70,855 |  |  | 203,413 |  |  | 184,407 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 23,858 |  |  | 24,265 |  |  | 71,205 |  |  | 53,098 |  |
| Sales and marketing | 39,226 |  |  | 44,703 |  |  | 127,976 |  |  | 108,033 |  |
| General and administrative | 9,711 |  |  | 11,178 |  |  | 31,091 |  |  | 29,301 |  |
| Acquisition and integration costs | 1,725 |  |  | 6,443 |  |  | 9,283 |  |  | 18,826 |  |
| Restructuring charge, net of reversals | — |  |  | (6 | ) |  | — |  |  | 499 |  |
| Amortization of intangibles | 4,467 |  |  | 7,666 |  |  | 13,402 |  |  | 11,444 |  |
| Total operating expenses | 78,987 |  |  | 94,249 |  |  | 252,957 |  |  | 221,201 |  |
| Operating loss | (21,263 | ) |  | (23,394 | ) |  | (49,544 | ) |  | (36,794 | ) |
| Interest income | 129 |  |  | 156 |  |  | 471 |  |  | 603 |  |
| Interest expense | (758 | ) |  | (764 | ) |  | (2,419 | ) |  | (1,288 | ) |
| Other expense, net | (535 | ) |  | (146 | ) |  | (1,033 | ) |  | (1,338 | ) |
| Loss before income taxes | (22,427 | ) |  | (24,148 | ) |  | (52,525 | ) |  | (38,817 | ) |
| Provision for income taxes | 1,121 |  |  | 910 |  |  | 3,458 |  |  | 2,262 |  |
| Net loss | $ | (23,548 | ) |  | $ | (25,058 | ) |  | $ | (55,983 | ) |  | $ | (41,079 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.24 | ) |  | $ | (0.26 | ) |  | $ | (0.57 | ) |  | $ | (0.43 | ) |
| Net loss per share - diluted | $ | (0.24 | ) |  | $ | (0.26 | ) |  | $ | (0.57 | ) |  | $ | (0.43 | ) |
| Shares used in per share calculation - basic | 99,783 |  |  | 96,069 |  |  | 98,591 |  |  | 95,116 |  |
| Shares used in per share calculation - diluted | 99,783 |  |  | 96,069 |  |  | 98,591 |  |  | 95,116 |  |

[0001078271-15-000050:8k_2_02:48]
EXTREME NETWORKS, INC.

[0001078271-15-000050:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-15-000050:8k_2_02:50]
(In thousands)

[0001078271-15-000050:8k_2_02:51]
(Unaudited)

[0001078271-15-000050:8k_2_02:52]
|  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Net cash provided by (used in) operating activities | $ | 33,564 |  |  | $ | (30,617 | ) |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (5,610 | ) |  | (17,384 | ) |
| Acquisition, net of cash acquired | — |  |  | (180,000 | ) |
| Purchases of investments | — |  |  | (9,045 | ) |
| Purchases of equity investments | (3,000 | ) |  | — |  |
| Proceeds from maturities of investments and marketable securities | 21,815 |  |  | 26,722 |  |
| Proceeds from sales of investments and marketable securities | 9,051 |  |  | 56,594 |  |
| Purchases of intangible assets | (569 | ) |  | — |  |
| Net cash provided by (used in) investing activities | 21,687 |  |  | (123,113 | ) |
| Cash flows from financing activities: |  |  |  |
| Borrowings under Revolving Facility | 24,000 |  |  | 59,000 |  |
| Issuance of Term Loan | — |  |  | 65,000 |  |
| Repayment of debt | (77,062 | ) |  | (1,625 | ) |
| Proceeds from issuance of common stock | 2,455 |  |  | 6,296 |  |
| Net cash (used in) provided by financing activities | (50,607 | ) |  | 128,671 |  |
| Foreign currency effect on cash | (3,767 | ) |  | 611 |  |
| Net increase (decrease) in cash and cash equivalents | 877 |  |  | (24,448 | ) |
| Cash and cash equivalents at beginning of period | 73,190 |  |  | 95,803 |  |
| Cash and cash equivalents at end of period | $ | 74,067 |  |  | $ | 71,355 |  |

[0001078271-15-000050:8k_2_02:53]
Extreme Networks, Inc.

[0001078271-15-000050:8k_2_02:54]
Non-GAAP Measures of Financial Performance

[0001078271-15-000050:8k_2_02:55]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-15-000050:8k_2_02:56]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles and  restructuring expenses

[0001078271-15-000050:8k_2_02:57]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-15-000050:8k_2_02:58]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-15-000050:8k_2_02:59]
For its internal planning process, and as discussed further below, Extreme Networks' management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, and restructuring expenses.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-15-000050:8k_2_02:60]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-15-000050:8k_2_02:61]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-15-000050:8k_2_02:62]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-15-000050:8k_2_02:63]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-15-000050:8k_2_02:64]
Purchase accounting adjustments relating to deferred revenue.  Purchase accounting adjustments consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001078271-15-000050:8k_2_02:65]
Purchase accounting adjustments relating to inventory.  Purchase accounting adjustments relating to inventory consists of the amortization of the step up value from the valuation of the inventory at fair value in cost of revenues as part of business

[0001078271-15-000050:8k_2_02:66]
combination accounting.  Extreme Networks excludes these expenses since they result from an event that is out the ordinary course of continuing operations.

[0001078271-15-000050:8k_2_02:67]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-15-000050:8k_2_02:68]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001078271-15-000050:8k_2_02:69]
EXTREME NETWORKS, INC.

[0001078271-15-000050:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000050:8k_2_02:71]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-15-000050:8k_2_02:72]
(In thousands, except per share amounts)

[0001078271-15-000050:8k_2_02:73]
(Unaudited)

[0001078271-15-000050:8k_2_02:74]
| Non-GAAP Revenue | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Revenue - GAAP Basis | $ | 119,590 |  |  | $ | 141,762 |  |  | $ | 403,072 |  |  | $ | 364,261 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 1,912 |  |  | $ | 2,299 |  |  | $ | 3,676 |  |
| Revenue - Non-GAAP Basis | $ | 120,356 |  |  | $ | 143,674 |  |  | $ | 405,371 |  |  | $ | 367,937 |  |
| Non-GAAP Gross Margin | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Gross profit - GAAP Basis | $ | 57,724 |  |  | $ | 70,855 |  |  | $ | 203,413 |  |  | $ | 184,407 |  |
| Gross margin - GAAP Basis percentage | 48.3 | % |  | 50.0 | % |  | 50.5 | % |  | 50.6 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 519 |  |  | $ | 688 |  |  | $ | 1,639 |  |  | $ | 1,190 |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 3,803 |  |  | $ | 2,299 |  |  | $ | 14,803 |  |
| Amortization of intangibles | $ | 4,292 |  |  | $ | 4,042 |  |  | $ | 12,875 |  |  | $ | 6,736 |  |
| Gross profit - Non-GAAP Basis | $ | 63,301 |  |  | $ | 79,388 |  |  | $ | 220,226 |  |  | $ | 207,136 |  |
| Gross margin - Non-GAAP Basis percentage | 52.6 | % |  | 55.3 | % |  | 54.3 | % |  | 56.3 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Operating loss - GAAP Basis | $ | (21,263 | ) |  | $ | (23,394 | ) |  | $ | (49,544 | ) |  | $ | (36,794 | ) |
| Operating loss - GAAP Basis percentage | (17.8 | )% |  | (16.5 | )% |  | (12.3 | )% |  | (10.1 | )% |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 4,372 |  |  | $ | 4,841 |  |  | $ | 13,935 |  |  | $ | 9,874 |  |
| Acquisition and integration costs | $ | 1,725 |  |  | $ | 6,443 |  |  | $ | 9,283 |  |  | $ | 18,826 |  |
| Restructuring charge, net of reversal | $ | — |  |  | $ | (6 | ) |  | $ | — |  |  | $ | 499 |  |
| Amortization of intangibles | $ | 8,759 |  |  | $ | 11,708 |  |  | $ | 26,277 |  |  | $ | 18,180 |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 3,803 |  |  | $ | 2,299 |  |  | $ | 14,803 |  |
| Litigation settlement (income) expense | $ | — |  |  | $ | (100 | ) |  | $ | — |  |  | $ | (100 | ) |
| Total adjustments to GAAP operating income | $ | 15,622 |  |  | $ | 26,689 |  |  | $ | 51,794 |  |  | $ | 62,082 |  |
| Operating (loss) income - Non-GAAP Basis | $ | (5,641 | ) |  | $ | 3,295 |  |  | $ | 2,250 |  |  | $ | 25,288 |  |
| Operating (loss) income - Non-GAAP Basis percentage | (4.7 | )% |  | 2.3 | % |  | 0.6 | % |  | 6.9 | % |

[0001078271-15-000050:8k_2_02:75]
| Non-GAAP Net Income | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Net loss - GAAP Basis | $ | (23,548 | ) |  | $ | (25,058 | ) |  | $ | (55,983 | ) |  | $ | (41,079 | ) |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 4,372 |  |  | $ | 4,841 |  |  | $ | 13,935 |  |  | $ | 9,874 |  |
| Acquisition and integration costs | $ | 1,725 |  |  | $ | 6,443 |  |  | $ | 9,283 |  |  | $ | 18,826 |  |
| Restructuring charge, net of reversal | $ | — |  |  | $ | (6 | ) |  | $ | — |  |  | $ | 499 |  |
| Amortization of intangibles | $ | 8,759 |  |  | $ | 11,708 |  |  | $ | 26,277 |  |  | $ | 18,180 |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 3,803 |  |  | $ | 2,299 |  |  | $ | 14,803 |  |
| Litigation settlement (income) expense | $ | — |  |  | $ | (100 | ) |  | $ | — |  |  | $ | (100 | ) |
| Total adjustments to GAAP net income | $ | 15,622 |  |  | $ | 26,689 |  |  | $ | 51,794 |  |  | $ | 62,082 |  |
| Net (loss) income - Non-GAAP Basis | $ | (7,926 | ) |  | $ | 1,631 |  |  | $ | (4,189 | ) |  | $ | 21,003 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Diluted net (loss) income per share - Non-GAAP Basis | $ | (0.08 | ) |  | $ | 0.02 |  |  | $ | (0.04 | ) |  | $ | 0.21 |  |
| Shares used in diluted net income per share calculation | 99,783 |  |  | 99,512 |  |  | 98,591 |  |  | 97,853 |  |
| Free Cash Flow | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Cash flow (used in) provided by operations | $ | (7,972 | ) |  | $ | (25,747 | ) |  | $ | 33,564 |  |  | $ | (30,617 | ) |
| Add: PP&E CapEx spending | $ | (1,648 | ) |  | $ | (4,822 | ) |  | $ | (5,610 | ) |  | $ | (17,384 | ) |
| Total free cash flow | $ | (9,620 | ) |  | $ | (30,569 | ) |  | $ | 27,954 |  |  | $ | (48,001 | ) |
