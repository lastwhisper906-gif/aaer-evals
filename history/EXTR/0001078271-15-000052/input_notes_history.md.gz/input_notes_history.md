# EXTR note change history — 0001078271-15-000007 → 0001078271-15-000052


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001078271-15-000052:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. The Company had non-cancelable commitments to purchase $100.7 million of such inventory as of March 31, 2015.
  (was, 2015-01-30, similarity 0.9704):
[0001078271-15-000007:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2014, the Company had non-cancelable commitments to purchase $102.4 million of such inventory.

- added (2015-05-07):
[0001078271-15-000052:note_history:2]
Litigation

- changed (2015-05-07):
[0001078271-15-000052:note_history:3]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014. COT then filed a motion to dismiss COT as a defendant in this lawsuit and the court granted COT’s motion. Plaintiffs filed a motion for Summary Judgment/Adjudication on the issue of whether the work performed by the defendants constitutes “construction” under the Act, which was denied on February 26, 2015.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular outcome.
  (was, 2015-01-30, similarity 0.755):
[0001078271-15-000007:note_history:3]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014. COT then filed a motion to dismiss COT as a defendant in this lawsuit and the court granted COT’s motion. Although this litigation is in the discovery stage, Plaintiffs have filed a motion for Summary Judgment/Adjudication, which will be heard on February 26, 2015, on the issue of whether the work performed by the defendants constitutes “construction” under the Act.  The Company will vigorously oppose this motion. This litigation is in the early stages of discovery.

- changed (2015-05-07):
[0001078271-15-000052:note_history:4]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US $1.5 million), plus interest and penalties (that are currently estimated to be approximately US $9.0 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by Enterasys.
  (was, 2015-01-30, similarity 0.805):
[0001078271-15-000007:note_history:4]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014 by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US$1.5 million), plus interest and penalties (that are currently estimated to be approximately US$9 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution; however, the court ruled that a cash deposit of the full amount at issue is to be made by Enterasys.  Enterasys then prepared a motion aimed at the partial reconsideration of such decision concerning the need for a deposit, which was denied on October 10, 2014.  The Company appealed this ruling on October 30, 2014 and is currently awaiting a decision from the Court of Appeals.

- changed (2015-05-07):
[0001078271-15-000052:note_history:5]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from US $0 million to US $9.0 million, of which the Company believes US $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.
  (was, 2015-01-30, similarity 0.9933):
[0001078271-15-000007:note_history:5]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from $0 million to $9 million, of which the Company believes $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.

- added (2015-05-07):
[0001078271-15-000052:note_history:6]
Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.).

- added (2015-05-07):
[0001078271-15-000052:note_history:7]
On or about April 8, 2015, Company filed a lawsuit against Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.) (“Seller”) for breach of, and indemnification by Seller under, the purchase agreement, between Seller and Company, for Company’s purchase of Enterasys Networks, Inc. and its subsidiaries (the “Purchase Agreement”).  The complaint alleges numerous claims for indemnification resulting from Seller’s violations of certain clauses in the Purchase Agreement and Seller’s failure to make accurate and proper disclosures as required by the Purchase Agreement.  The Company was compelled to file this action to perfect and preserve the Company’s right to indemnification by Seller under the Purchase Agreement.  Although the Company’s complaint has not quantified the amount being sought, the complaint seeks, among other things, monetary damages, costs, expenses and attorney fees in connection with each of the claims.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular or final outcome.

- added (2015-05-07):
[0001078271-15-000052:note_history:8]
Wetro LAN LLC

- added (2015-05-07):
[0001078271-15-000052:note_history:9]
On Mar 23, 2015, Wetro LAN LLC (Wetro), a non-practicing entity, filed a complaint against Extreme in the Eastern District of Texas asserting infringement of United States Patent No. 6,795,918 (the “ ‘918 Patent”). Wetro alleges that Extreme “makes, uses, provides, offers for sale, and sells their product entitled Extreme Networks- Altitude 4700 Series Access Points and similarly situated wireless routers” and thereby has infringed the 918 Patent. Wetro sued a number of other technology companies in January and February 2015 for the same patent.  Indications at the USPTO are that the 918 Patent has expired, limiting potential damages including all future damages in the case.  Wetro seeks monetary damages, although the complaint seeks no quantified amount.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular or final outcome.

- removed (2015-05-07):
[0001078271-15-000007:note_history:10]
Intellectual Property Litigation

- removed (2015-05-07):
[0001078271-15-000007:note_history:11]
Selene Communication Technologies, LLC.

- removed (2015-05-07):
[0001078271-15-000007:note_history:12]
On April 7, 2014, Selene Communication Technologies, LLC (“Selene”), filed a complaint in the US District Court for the District of Delaware against Extreme and Enterasys asserting a cause of action for infringement of United States Patent No. 7,143,444 (the “444 Patent”). Selene has also recently sued a number of other technology companies including Cisco for infringement of the 444 Patent.  Selene, a non-practicing entity, seeks injunctive relief as well as monetary damages, costs, expenses and attorney fees, although the complaint seeks no quantified amount.

- removed (2015-05-07):
[0001078271-15-000007:note_history:13]
The Company is a member of RPX Corporation’s (“RPX”) network of clients, who procure patent risk management services from RPX.  On September 30, 2014, RPX signed an agreement on behalf of its members (including Extreme) with Selene to resolve the litigation cases against its members by Selene and to obtain a license for all RPX members to the 444 Patent and its foreign counterparts.  As a result, a Release Agreement was finalized on November 19, 2014 and the litigation was dismissed in US District court for the District of Delaware on November 20, 2014.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001078271-15-000052:note_history:14]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2015.
  (was, 2015-01-30, similarity 0.7806):
[0001078271-15-000007:note_history:14]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2014. The results of operations for the three and six months ended December 31, 2014 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.

- added (2015-05-07):
[0001078271-15-000052:note_history:15]
The results of operations for the three and nine months ended March 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001078271-15-000052:note_history:16]
The Company's debt is comprised of the following (in thousands):
  (was, 2015-01-30, similarity 0.8673):
[0001078271-15-000007:note_history:16]
The Company's debt is comprised of the following:

- changed (2015-05-07):
[0001078271-15-000052:note_history:17]
|  |  | March 31, 2015 |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |  |  |
| Term Loan |  | $ | 9,750 |  |  | $ | 5,688 |  |
| Revolving Facility |  | — |  |  | 24,000 |  |
| Current portion of long-term debt |  | $ | 9,750 |  |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |  |  |
| Term Loan |  | $ | 48,750 |  |  | $ | 56,875 |  |
| Revolving Facility |  | 10,000 |  |  | 35,000 |  |
| Total long-term debt, less current portion |  | 58,750 |  |  | 91,875 |  |
| Total debt |  | $ | 68,500 |  |  | $ | 121,563 |  |
  (was, 2015-01-30, similarity 0.9854):
[0001078271-15-000007:note_history:17]
|  |  | December 31, 2014 |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |  |  |
| Term Loan |  | $ | 8,125 |  |  | $ | 5,688 |  |
| Revolving Facility |  | — |  |  | 24,000 |  |
| Current portion of long-term debt |  | $ | 8,125 |  |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |  |  |
| Term Loan |  | $ | 52,000 |  |  | $ | 56,875 |  |
| Revolving Facility |  | 29,000 |  |  | 35,000 |  |
| Total long-term debt, less current portion |  | 81,000 |  |  | 91,875 |  |
| Total debt |  | $ | 89,125 |  |  | $ | 121,563 |  |
