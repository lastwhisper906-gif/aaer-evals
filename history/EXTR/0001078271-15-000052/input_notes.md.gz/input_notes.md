# EXTR notes — 0001078271-15-000052


## extr:DeferredRevenueRollForwardTableTextBlock

[0001078271-15-000052:notes:1]
[same as prior period, unchanged from 0001078271-15-000007:notes:1]

[0001078271-15-000052:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Balance beginning of period | $ | 91,373 |  |  | $ | 81,485 |  |  | $ | 89,657 |  |  | $ | 38,003 |  |
| Assumed from acquisition | — |  |  | — |  |  | — |  |  | 35,879 |  |
| New support arrangements | 27,198 |  |  | 30,986 |  |  | 91,254 |  |  | 77,475 |  |
| Recognition of support revenue | (29,834 | ) |  | (28,265 | ) |  | (92,174 | ) |  | (67,151 | ) |
| Balance end of period | 88,737 |  |  | 84,206 |  |  | 88,737 |  |  | 84,206 |  |
| Less: current portion | 65,596 |  |  | 64,539 |  |  | 65,596 |  |  | 64,539 |  |
| Non-current deferred revenue | $ | 23,141 |  |  | $ | 19,667 |  |  | $ | 23,141 |  |  | $ | 19,667 |  |


## extr:ScheduleOfDeferredDistributorsRevenueTableTextBlock

[0001078271-15-000052:notes:3]
[same as prior period, unchanged from 0001078271-15-000007:notes:3]

[0001078271-15-000052:notes:4]
|  | March 31, 2015 |  | June 30, 2014 |
| Deferred distributors' revenue | $ | 46,230 |  |  | $ | 40,715 |  |
| Deferred cost of sales to distributors | (10,543 | ) |  | (8,723 | ) |
| Deferred distributors revenue, net of cost of sales to distributors | $ | 35,687 |  |  | $ | 31,992 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-15-000052:notes:5]
[same as prior period, unchanged from 0001078271-15-000007:notes:5]

[0001078271-15-000052:notes:6]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| March 31, 2015 |  |  |  |  |  |  |  |
| Money market funds | $ | 19,779 |  |  | $ | 19,779 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 1,506 |  |  | 1,506 |  |  |  |  |  | — |  |
|  | $ | 21,285 |  |  | $ | 21,285 |  |  | $ | — |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 19,779 |  |  | $ | 19,779 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 1,506 |  |  | 1,506 |  |  |  |  |  | — |  |
|  | $ | 21,285 |  |  | $ | 21,285 |  |  | $ | — |  |  | $ | — |  |
| June 30, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |

[0001078271-15-000052:notes:7]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at March 31, 2015, by contractual maturity, were as follows (in thousands):

[0001078271-15-000052:notes:8]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 21,285 |  |  | $ | 21,285 |  |
| Total investments in available-for-sale debt securities | $ | 21,285 |  |  | $ | 21,285 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001078271-15-000052:notes:9]
[same as prior period, unchanged from 0001078271-15-000007:notes:9]

[0001078271-15-000052:notes:10]
On October 31, 2013, (the “Acquisition Date”), the Company completed the acquisition of Enterasys Networks, Inc. ("Enterasys"), a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired. The Company also assumed outstanding options and restricted stock units of Enterasys at the Acquisition Date, all of which were unvested.

[0001078271-15-000052:notes:11]
[same as prior period, unchanged from 0001078271-15-000007:notes:11]

[0001078271-15-000052:notes:12]
The following table summarizes the final allocation as of September 30, 2014, of the tangible and identifiable intangible assets acquired and liabilities assumed as compared to the allocation as of December 31, 2013, the quarter in which the transaction was completed (in thousands):

[0001078271-15-000052:notes:13]
[same as prior period, unchanged from 0001078271-15-000007:notes:13]

[0001078271-15-000052:notes:14]
| a. | The Company finalized the working capital adjustment as of September 30, 2014, which led to a decrease of $2.4 million in receivables and a corresponding increase in cash. As a result of this adjustment, the total cash acquired from the acquisition also increased by the same amount. The net effect of this adjustment is an increase in goodwill of $2.4 million. |

[0001078271-15-000052:notes:15]
| b. | The Company obtained new information regarding the existence of prepaid assets as of the acquisition date which led to a decrease in the fair value of current assets of $1.5 million, and a corresponding increase in goodwill. The change in the amortization of prepaid assets due to the change in fair value of current assets was immaterial. |

[0001078271-15-000052:notes:16]
[same as prior period, unchanged from 0001078271-15-000007:notes:16]

[0001078271-15-000052:notes:17]
[same as prior period, unchanged from 0001078271-15-000007:notes:17]

[0001078271-15-000052:notes:18]
| e. | The Company obtained new information regarding accruals for litigation and statutory tax assessment as of the acquisition date which led to an increase in the fair value of current liabilities of $5.4 million and a corresponding increase in goodwill. |

[0001078271-15-000052:notes:19]
[same as prior period, unchanged from 0001078271-15-000007:notes:19]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-15-000052:notes:20]
Commitments and Contingencies

[0001078271-15-000052:notes:21]
Purchase Commitments

[0001078271-15-000052:notes:22]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. The Company had non-cancelable commitments to purchase $100.7 million of such inventory as of March 31, 2015.

[0001078271-15-000052:notes:23]
Legal Proceedings

[0001078271-15-000052:notes:24]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-15-000052:notes:25]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-15-000052:notes:26]
Litigation

[0001078271-15-000052:notes:27]
Commonwealth of Kentucky

[0001078271-15-000052:notes:28]
On or about February 3, 2014, a class action lawsuit was filed in the Commonwealth of Kentucky against Enterasys Networks, Inc. and two other defendants.  The complaint alleges that Enterasys and its subcontractor, TJL Information Technologies, Inc., d.b.a. Unbridled Information Technologies (“Subcontractor”), violated Kentucky’s wage and hour laws and failed to pay the prevailing wage in violation of the Kentucky State Prevailing Wage Act (the “Act”) on various public works projects for a number of Kentucky government agencies since January 2010.  Plaintiffs also allege common law actions for quantum merit and unjust enrichment and they seek monetary damages, costs, expenses and attorney fees, although there was no quantified amount identified.  One of the defendants, Integrated Facility Systems, LLC (“IFS”), has also filed a cross-claim against Enterasys.  The Company denies the claims and filed answers to both the complaint and cross-claim on April 16, 2014.  In addition, the Company filed a cross-claim for indemnity against IFS.

[0001078271-15-000052:notes:29]
Plaintiffs filed a first amended complaint on September 26, 2014, in which they named Commonwealth of Kentucky’s Office of Technology under the State’s Finance and Administration Cabinet (“COT”) as a defendant.  The Company filed an answer to the Plaintiffs’ first amended complaint on October 10, 2014. COT then filed a motion to dismiss COT as a defendant in this lawsuit and the court granted COT’s motion. Plaintiffs filed a motion for Summary Judgment/Adjudication on the issue of whether the work performed by the defendants constitutes “construction” under the Act, which was denied on February 26, 2015.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular outcome.

[0001078271-15-000052:notes:30]
ICMS Tax Assessment Matters

[0001078271-15-000052:notes:31]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US $1.5 million), plus interest and penalties (that are currently estimated to be approximately US $9.0 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by Enterasys.

[0001078271-15-000052:notes:32]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from US $0 million to US $9.0 million, of which the Company believes US $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.

[0001078271-15-000052:notes:33]
Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.).

[0001078271-15-000052:notes:34]
On or about April 8, 2015, Company filed a lawsuit against Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.) (“Seller”) for breach of, and indemnification by Seller under, the purchase agreement, between Seller and Company, for Company’s purchase of Enterasys Networks, Inc. and its subsidiaries (the “Purchase Agreement”).  The complaint alleges numerous claims for indemnification resulting from Seller’s violations of certain clauses in the Purchase Agreement and Seller’s failure to make accurate and proper disclosures as required by the Purchase Agreement.  The Company was compelled to file this action to perfect and preserve the Company’s right to indemnification by Seller under the Purchase Agreement.  Although the Company’s complaint has not quantified the amount being sought, the complaint seeks, among other things, monetary damages, costs, expenses and attorney fees in connection with each of the claims.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular or final outcome.

[0001078271-15-000052:notes:35]
Wetro LAN LLC

[0001078271-15-000052:notes:36]
On Mar 23, 2015, Wetro LAN LLC (Wetro), a non-practicing entity, filed a complaint against Extreme in the Eastern District of Texas asserting infringement of United States Patent No. 6,795,918 (the “ ‘918 Patent”). Wetro alleges that Extreme “makes, uses, provides, offers for sale, and sells their product entitled Extreme Networks- Altitude 4700 Series Access Points and similarly situated wireless routers” and thereby has infringed the 918 Patent. Wetro sued a number of other technology companies in January and February 2015 for the same patent.  Indications at the USPTO are that the 918 Patent has expired, limiting potential damages including all future damages in the case.  Wetro seeks monetary damages, although the complaint seeks no quantified amount.  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular or final outcome.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-15-000052:notes:37]
[same as prior period, unchanged from 0001078271-15-000007:notes:36]

[0001078271-15-000052:notes:38]
|  | March 31, 2015 |  | June 30, 2014 |
| Deferred services | $ | 88,737 |  |  | $ | 89,657 |  |
| Deferred product and other revenue | 7,610 |  |  | 8,020 |  |
| Total deferred revenue | 96,347 |  |  | 97,677 |  |
| Less: current portion | 73,206 |  |  | 74,735 |  |
| Non-current deferred revenue, net | $ | 23,141 |  |  | $ | 22,942 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-15-000052:notes:39]
[same as prior period, unchanged from 0001078271-15-000007:notes:38]

[0001078271-15-000052:notes:40]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as "Other assets" at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company from time to time enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecast transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. As of March 31, 2015, the Company did not have any foreign currency contracts.

[0001078271-15-000052:notes:41]
Foreign currency transaction gains and losses from operations was a loss of $0.5 million and $0.1 million for the three months ended March 31, 2015 and 2014, respectively. Foreign currency transaction gains and losses from operations were a loss of $0.9 million and $1.2 million for the nine months ended March 31, 2015 and 2014, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-15-000052:notes:42]
[same as prior period, unchanged from 0001078271-15-000007:notes:41]

[0001078271-15-000052:notes:43]
As of March 31, 2015, the Company had 15,578,378 shares available for issuance, of which 12,000,000 shares are available under the 2014 Employee Stock Purchase Plan ("ESPP"), which was approved by the shareholders on November 12, 2014. There are 66,382 shares available under the 1999 ESPP and 3,511,996 shares available under the 2013 Stock Plan.

[0001078271-15-000052:notes:44]
[same as prior period, unchanged from 0001078271-15-000007:notes:43]

[0001078271-15-000052:notes:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Cost of product revenue | $ | 265 |  |  | $ | 268 |  |  | $ | 823 |  |  | $ | 568 |  |
| Cost of service revenue | 254 |  |  | 420 |  |  | 816 |  |  | 623 |  |
| Research and development | 1,423 |  |  | 1,419 |  |  | 4,611 |  |  | 2,559 |  |
| Sales and marketing | 1,291 |  |  | 1,765 |  |  | 4,414 |  |  | 3,614 |  |
| General and administrative | 1,139 |  |  | 970 |  |  | 3,271 |  |  | 2,510 |  |
| Total share-based compensation expense | $ | 4,372 |  |  | $ | 4,842 |  |  | $ | 13,935 |  |  | $ | 9,874 |  |

[0001078271-15-000052:notes:46]
The Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial during the three and nine months ended March 31, 2015 and 2014, respectively.

[0001078271-15-000052:notes:47]
[same as prior period, unchanged from 0001078271-15-000007:notes:46]

[0001078271-15-000052:notes:48]
[same as prior period, unchanged from 0001078271-15-000007:notes:47]

[0001078271-15-000052:notes:49]
During the three months ended March 31, 2015, the Company began expensing market-performance based restricted stock units to senior executive officers that had been granted during the second quarter of fiscal 2015.

[0001078271-15-000052:notes:50]
The following table summarizes stock award activity for the nine months ended March 31, 2015:

[0001078271-15-000052:notes:51]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2014 | 6,000 |  |  | $ | 4.98 |  |  |  |
| Granted | 1,305 |  |  | $ | 3.45 |  |  |  |
| Vested | (2,216 | ) |  | $ | 5.09 |  |  | $ | 7,985 |  |
| Cancelled | (409 | ) |  | $ | 4.42 |  |  |  |
| Non-vested stock outstanding at March 31, 2015 | 4,680 |  |  | $ | 4.55 |  |  |  |

[0001078271-15-000052:notes:52]
Stock Options

[0001078271-15-000052:notes:53]
The following table summarizes stock option activity under all plans for the nine months ended March 31, 2015.

[0001078271-15-000052:notes:54]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2014 | 11,732 |  |  | $ | 4.26 |  |  | 5.13 |  | $ | 6,846 |  |
| Granted | 1,153 |  |  | $ | 4.11 |  |  |  |  |  |
| Exercised | (425 | ) |  | $ | 3.17 |  |  |  |  | $ | 381 |  |
| Cancelled | (1,245 | ) |  | $ | 5.12 |  |  |  |  |  |
| Options outstanding at March 31, 2015 | 11,215 |  |  | $ | 4.19 |  |  | 4.73 |  | $ | 493 |  |
| Exercisable at March 31, 2015 | 6,047 |  |  | $ | 3.95 |  |  | 3.94 |  | $ | 473 |  |
| Vested and expected to vest at March 31, 2015 | 10,441 |  |  | $ | 4.17 |  |  | 4.66 |  | $ | 489 |  |

[0001078271-15-000052:notes:55]
The weighted-average grant-date per share fair value of options granted was $1.34 and $2.71 during the three months ended March 31, 2015 and 2014, respectively.

[0001078271-15-000052:notes:56]
The weighted-average grant-date per share fair value of options granted was $1.91 and $2.39 during the nine months ended March 31, 2015 and 2014, respectively.

[0001078271-15-000052:notes:57]
The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period o performance-based option awards, with market conditions, on the date of the grant.

[0001078271-15-000052:notes:58]
ESPP

[0001078271-15-000052:notes:59]
The weighted-average estimated per share fair value of shares purchased under the Company’s ESPP was $0.59 and $1.62 during the three months ended March 31, 2015 and 2014, respectively.

[0001078271-15-000052:notes:60]
The weighted-average estimated per share fair value of shares purchased under the Company’s ESPP was $1.02 and $1.44 during the nine months ended March 31, 2015 and 2014, respectively.

[0001078271-15-000052:notes:61]
[same as prior period, unchanged from 0001078271-15-000007:notes:55]

[0001078271-15-000052:notes:62]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Expected life | 4.6 years |  |  | 5.0 years |  |  | 0.50 years |  |  | 0.25 years |  |  | 4.7 years |  |  | 4.0 years |  |  | 0.33 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.49 | % |  | 1.41 | % |  | 0.07 | % |  | 0.09 | % |  | 1.60 | % |  | 1.23 | % |  | 0.04 | % |  | 0.10 | % |
| Volatility | 54 | % |  | 57 | % |  | 58 | % |  | 57 | % |  | 54 | % |  | 56 | % |  | 58 | % |  | 51 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-15-000052:notes:63]
Basic earnings per share is calculated by dividing net earnings by the weighted average number of common shares outstanding during the period. Dilutive earnings per share is calculated by dividing net earnings by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.


## us-gaap:EarningsPerShareTextBlock

[0001078271-15-000052:notes:64]
[same as prior period, unchanged from 0001078271-15-000007:notes:58]

[0001078271-15-000052:notes:65]
[same as prior period, unchanged from 0001078271-15-000007:notes:60]

[0001078271-15-000052:notes:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Net loss | $ | (23,548 | ) |  | $ | (25,058 | ) |  | $ | (55,983 | ) |  | $ | (41,079 | ) |
| Weighted-average shares used in per share calculation – basic and diluted | 99,783 |  |  | 96,069 |  |  | 98,591 |  |  | 95,116 |  |
| Net loss per share – basic and diluted | $ | (0.24 | ) |  | $ | (0.26 | ) |  | $ | (0.57 | ) |  | $ | (0.43 | ) |

[0001078271-15-000052:notes:67]
[same as prior period, unchanged from 0001078271-15-000007:notes:62]

[0001078271-15-000052:notes:68]
|  |  | March 31, 2015 |  | March 31, 2014 |
| Options to purchase common stock |  | 9,839 |  |  | 7,171 |  |
| Restricted stock units |  | 1,694 |  |  | 1,038 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-15-000052:notes:69]
[same as prior period, unchanged from 0001078271-15-000007:notes:64]

[0001078271-15-000052:notes:70]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0001078271-15-000052:notes:71]
| • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001078271-15-000052:notes:72]
| • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001078271-15-000052:notes:73]
| • | Level 3 Inputs - unobservable inputs reflecting the Company's own assumptions in measuring the asset or liability at fair value. |

[0001078271-15-000052:notes:74]
The Company uses forward foreign currency contracts to hedge market risks relating to possible adverse changes in foreign exchange rates.

[0001078271-15-000052:notes:75]
The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis (in thousands):

[0001078271-15-000052:notes:76]
| March 31, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 19,779 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,779 |  |
| Corporate notes/bonds | — |  |  | 1,506 |  |  | — |  |  | 1,506 |  |
| Non-marketable equity investment | — |  |  | — |  |  | 3,000 |  |  | 3,000 |  |
| Total | $ | 19,779 |  |  | $ | 1,506 |  |  | $ | 3,000 |  |  | $ | 24,285 |  |

[0001078271-15-000052:notes:77]
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | — |  |  | $ | — |  |  | $ | 567 |  |
| Corporate notes/bonds | — |  |  | 32,692 |  |  | — |  |  | 32,692 |  |
| Foreign currency forward contracts | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total | $ | 567 |  |  | $ | 32,713 |  |  | $ | — |  |  | $ | 33,280 |  |

[0001078271-15-000052:notes:78]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three and nine months ended March 31, 2015.

[0001078271-15-000052:notes:79]
During the quarter, the Company obtained a $3.0 million equity interest in a Company that operates in the enterprise software platform industry.  The Company has not entered into any other transactions with the entity that are considered significant to the Company’s consolidated financial statements during the three and nine months ended March 31, 2015.

[0001078271-15-000052:notes:80]
The Company reflects a non-marketable equity investment as Level 3 in the fair value hierarchy as it is based on unobservable inputs that market participants would use in pricing this asset due to the absence of recent comparable market transactions and inherent lack of liquidity. Significant inputs and assumptions are management’s estimate of the enterprise value used to calculate the present value of the asset. Significant changes in any Level 3 input or assumption would result in increases or decreases to fair value measurements for this asset.

[0001078271-15-000052:notes:81]
There were no liabilities as of March 31, 2015 that were being measured using fair value on a recurring basis. The fair values of accounts receivable, accounts payable, and accrued liabilities, due within one year approximates their carrying values due to their short-term nature.

[0001078271-15-000052:notes:82]
The Company does not have any assets or liabilities measured at fair value on a non-recurring basis as of March 31, 2015, and June 30, 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-15-000052:notes:83]
[same as prior period, unchanged from 0001078271-15-000007:notes:69]

[0001078271-15-000052:notes:84]
The Company recorded an income tax provision of $1.1 million and $3.5 million, for the three and nine months ended March 31, 2015, respectively.  The Company recorded an income tax provision of $0.9 million and $2.3 million for the three and nine months ended March 31, 2014, respectively.

[0001078271-15-000052:notes:85]
The income tax provisions for the three and nine months ended March 31, 2015 and 2014, consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three and nine months ended March 31, 2015 and 2014, and therefore may not reflect the annual effective tax rate.

[0001078271-15-000052:notes:86]
[same as prior period, unchanged from 0001078271-15-000007:notes:72]

[0001078271-15-000052:notes:87]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries.  The Company has elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  The Company deducted $1.1 million and $3.4 million, during the three and nine months ended March 31, 2015, respectively of tax amortization expense related to capitalized goodwill.  The Company recorded a deferred tax liability of $2.4 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against our deferred tax assets as of March 31, 2015.

[0001078271-15-000052:notes:88]
The Company had $11.3 million of unrecognized tax benefits as of March 31, 2015. The future impact of the unrecognized tax benefit of $11.3 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001078271-15-000052:notes:89]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Condensed Consolidated Statements of Operations and were immaterial for the three and nine months ended March 31, 2015 and 2014. Accrued interest and penalties were $42,000 as of March 31, 2014, and have been fully reversed as of March 31, 2015.

[0001078271-15-000052:notes:90]
[same as prior period, unchanged from 0001078271-15-000007:notes:76]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-15-000052:notes:91]
[same as prior period, unchanged from 0001078271-15-000007:notes:77]

[0001078271-15-000052:notes:92]
[same as prior period, unchanged from 0001078271-15-000007:notes:78]

[0001078271-15-000052:notes:93]
[same as prior period, unchanged from 0001078271-15-000007:notes:79]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-15-000052:notes:94]
Recently Issued Accounting Pronouncements

[0001078271-15-000052:notes:95]
In May 2014, the FASB, jointly with the International Accounting Standards Board, issued Accounting Standard Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers ("ASU 2014-09"). This ASU's core principle is that a reporting entity will recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In applying this new guidance to contracts within its scope, an entity will: (1) identify the contract(s) with a customer, (2) identify the performance obligation in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, this new guidance will require significantly expanded disclosures about revenue recognition. ASU 2014-09 is effective for annual reporting periods (including interim reporting periods within those annual periods) beginning after December 15, 2016. In April 2015, the FASB approved a one-year deferral of the effective date of the new standard. The new standard will be effective for the Company’s fiscal 2019, with early adoption permitted.

[0001078271-15-000052:notes:96]
Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this ASU. The Company is currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.

[0001078271-15-000052:notes:97]
In November 2014, the FASB has issued ASU 2014-15, Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern, which provides guidance on determining when and how to disclose going-concern uncertainties in the financial statements. The new standard requires management to perform interim and annual assessments of an entity’s ability to continue as a going concern within one year of the date of issuance of the entity’s financial statements and provide certain disclosures when there is substantial doubt about the entity’s ability to continue as a going concern. This guidance applies to all entities and is effective for annual periods beginning after December 15, 2015, and interim periods thereafter, with early adoption permitted. The Company is currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.

[0001078271-15-000052:notes:98]
In January 2015, the FASB issued ASU 2015-01 which provides guidance on the elimination of the concept of extraordinary items under GAAP. This ASU is effective for annual periods ending after December 15, 2016, and interim periods within those fiscal years, with early adoption permitted. The Company is currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.

[0001078271-15-000052:notes:99]
In February 2015, the FASB issued ASU 2015-02 which provides consolidation guidance and changes the way reporting enterprises evaluate consolidation for limited partnerships, investment companies and similar entities, as well as variable interest entities. The ASU is effective for annual and interim periods in fiscal years beginning after December 15, 2015. The Company is currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.

[0001078271-15-000052:notes:100]
In April 2015, the FASB issued ASU 2015-03 – Simplifying the Presentation of Debt Issuance Costs, which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. ASU 2015-03 requires retrospective adoption and will be effective for annual and interim periods in fiscal years beginning after December 15, 2015. Early adoption is permitted. The Company is currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-15-000052:notes:101]
[same as prior period, unchanged from 0001078271-15-000007:notes:82]

[0001078271-15-000052:notes:102]
[same as prior period, unchanged from 0001078271-15-000007:notes:83]

[0001078271-15-000052:notes:103]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2015.

[0001078271-15-000052:notes:104]
The results of operations for the three and nine months ended March 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2015 or any future periods.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-15-000052:notes:105]
[same as prior period, unchanged from 0001078271-15-000007:notes:85]

[0001078271-15-000052:notes:106]
|  | March 31, 2015 |  | June 30, 2014 |
| Cash | $ | 54,288 |  |  | $ | 72,623 |  |
| Cash equivalents | 19,779 |  |  | 567 |  |
| Short-term investments | 1,506 |  |  | 32,692 |  |
| Total available-for-sale | $ | 21,285 |  |  | $ | 33,259 |  |
| Total cash, cash equivalents and available-for-sale securities | $ | 75,573 |  |  | $ | 105,882 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-15-000052:notes:107]
The Company's debt is comprised of the following (in thousands):

[0001078271-15-000052:notes:108]
|  |  | March 31, 2015 |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |  |  |
| Term Loan |  | $ | 9,750 |  |  | $ | 5,688 |  |
| Revolving Facility |  | — |  |  | 24,000 |  |
| Current portion of long-term debt |  | $ | 9,750 |  |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |  |  |
| Term Loan |  | $ | 48,750 |  |  | $ | 56,875 |  |
| Revolving Facility |  | 10,000 |  |  | 35,000 |  |
| Total long-term debt, less current portion |  | 58,750 |  |  | 91,875 |  |
| Total debt |  | $ | 68,500 |  |  | $ | 121,563 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-15-000052:notes:109]
The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2015 and 2014, (in thousands):

[0001078271-15-000052:notes:110]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Balance beginning of period | $ | 7,845 |  |  | $ | 7,479 |  |  | $ | 7,551 |  |  | $ | 3,296 |  |
| Assumed from acquisition | — |  |  | — |  |  | — |  |  | 3,732 |  |
| New warranties issued | 1,751 |  |  | 1,824 |  |  | 5,699 |  |  | 4,782 |  |
| Warranty expenditures | (1,717 | ) |  | (1,478 | ) |  | (5,371 | ) |  | (3,985 | ) |
| Balance end of period | $ | 7,879 |  |  | $ | 7,825 |  |  | $ | 7,879 |  |  | $ | 7,825 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-15-000052:notes:111]
[same as prior period, unchanged from 0001078271-15-000007:notes:91]

[0001078271-15-000052:notes:112]
|  | Three Months Ended |  | Nine Months Ended |
| Net Revenues: | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 49,353 |  |  | $ | 59,896 |  |  | $ | 166,001 |  |  | $ | 141,576 |  |
| Other | 7,073 |  |  | 12,082 |  |  | 26,990 |  |  | 37,816 |  |
| Total Americas | 56,426 |  |  | 71,978 |  |  | 192,991 |  |  | 179,392 |  |
| EMEA | 50,006 |  |  | 54,113 |  |  | 166,515 |  |  | 146,175 |  |
| APAC | 13,158 |  |  | 15,671 |  |  | 43,566 |  |  | 38,694 |  |
| Total net revenues | $ | 119,590 |  |  | $ | 141,762 |  |  | $ | 403,072 |  |  | $ | 364,261 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001078271-15-000052:notes:113]
| Long Lived Assets: |  | March 31, 2015 |  | June 30, 2014 |
| Americas |  | $ | 93,185 |  |  | $ | 104,387 |  |
| EMEA |  | 32,773 |  |  | 45,191 |  |
| APAC |  | 3,312 |  |  | 3,121 |  |
| Total long lived assets |  | $ | 129,270 |  |  | $ | 152,699 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-15-000052:notes:114]
The following table sets forth major customers accounting for 10% or more of our net revenue for the periods indicated:

[0001078271-15-000052:notes:115]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31, 2015 |  | March 31, 2014 |  | March 31, 2015 |  | March 31, 2014 |
| Westcon Group, Inc. |  | 16% |  | 14% |  | 14% |  | 13% |
| ScanSource, Inc. |  | 13% |  | * |  | * |  | * |
| Tech Data Corporation |  | * |  | 16% |  | 14% |  | 12% |
| * Less than 10% of net revenue |  |  |  |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-15-000052:notes:116]
[same as prior period, unchanged from 0001078271-15-000007:notes:96]

[0001078271-15-000052:notes:117]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of its customers. The Company operates in three geographical areas: Americas; which includes the United States, Canada, Mexico, Central America and South America; Europe, the Middle East and Africa ("EMEA"); which includes Europe, Russia, the Middle East and Africa; and APAC; which includes Asia Pacific, South Asia, India, Australia and Japan.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-15-000052:notes:118]
[same as prior period, unchanged from 0001078271-15-000007:notes:98]

[0001078271-15-000052:notes:119]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual report on Form 10-K for the fiscal year ended June 30, 2014. There have been no material changes to the Company's significant accounting policies since the filing of the Annual report on Form 10-K.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-15-000052:notes:120]
[same as prior period, unchanged from 0001078271-15-000007:notes:100]

[0001078271-15-000052:notes:121]
[same as prior period, unchanged from 0001078271-15-000007:notes:101]

[0001078271-15-000052:notes:122]
[same as prior period, unchanged from 0001078271-15-000007:notes:102]

[0001078271-15-000052:notes:123]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income (loss) into earnings using the specific identification method.  The Company recorded an other-than temporary impairment loss of $148,000 during the nine months ended March 31, 2014.

[0001078271-15-000052:notes:124]
[same as prior period, unchanged from 0001078271-15-000007:notes:104]

[0001078271-15-000052:notes:125]
[same as prior period, unchanged from 0001078271-15-000007:notes:105]

[0001078271-15-000052:notes:126]
[same as prior period, unchanged from 0001078271-15-000007:notes:106]

[0001078271-15-000052:notes:127]
[same as prior period, unchanged from 0001078271-15-000007:notes:107]

[0001078271-15-000052:notes:128]
The Company records revenue from its distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to its distributors in “Deferred distributor' revenue, net of cost of sales to distributors” in the liability section of its condensed consolidated balance sheet. The amount shown as “Deferred distributors revenue, net of cost of sales to distributors” represents the deferred gross profit on sales to distributors based on contractual pricing.

[0001078271-15-000052:notes:129]
[same as prior period, unchanged from 0001078271-15-000007:notes:109]

[0001078271-15-000052:notes:130]
On October 31, 2013, the Company entered into a Credit Agreement (the “Credit Agreement”) which provides for a five-year revolving credit facility for up to $60.0 million (the “Revolving Facility”) and a $65.0 million five-year term loan (the “Term Loan”) and together with the Revolving Facility (the “Senior Secured Credit Facilities”).   The Company drew $24.0 million in the first quarter of fiscal 2015 to fund working capital requirements.  During the three months ended December 31, 2014, the Company amended the Credit Agreement and among other things modified certain financial covenants governing quick and leverage ratios. The Company repaid $30.0 million and $19.0 million of the Revolving Facility during the second and third fiscal quarters of 2015, respectively.

[0001078271-15-000052:notes:131]
The Credit Agreement contains, among others, certain financial covenants that require the Company to maintain defined minimum financial ratios which limit the Company’s availability to borrowings under the Revolving Facility. As of March 31, 2015, the Company had $8.6 million of additional availability under the Revolving Facility, due to these financial covenants.

[0001078271-15-000052:notes:132]
The Company had $1.0 million of outstanding letters of credit as of March 31, 2015.

[0001078271-15-000052:notes:133]
[same as prior period, unchanged from 0001078271-15-000007:notes:113]

[0001078271-15-000052:notes:134]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product.  The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2015 and 2014, (in thousands):

[0001078271-15-000052:notes:135]
[same as prior period, unchanged from 0001078271-15-000007:notes:115]

[0001078271-15-000052:notes:136]
[same as prior period, unchanged from 0001078271-15-000007:notes:116]

[0001078271-15-000052:notes:137]
[same as prior period, unchanged from 0001078271-15-000007:notes:117]
