# EXTR MD&A — 0001078271-15-000052


## mdna

[0001078271-15-000052:mdna:1]
[same as prior period, unchanged from 0001078271-15-000007:mdna:1]

[0001078271-15-000052:mdna:2]
[same as prior period, unchanged from 0001078271-15-000007:mdna:2]

[0001078271-15-000052:mdna:3]
We are a leading provider of network infrastructure equipment and services for enterprises, data centers, and service providers. We were incorporated in California in May 1996, and reincorporated in Delaware in March 1999. The shares of Extreme Networks, Inc. ("EXTR") began trading on NASDAQ in April 1999.  Our corporate headquarters are located in San Jose, California. We develop and sell network infrastructure equipment to our enterprise, data center and telecommunications service provider customers.

[0001078271-15-000052:mdna:4]
On October 31, 2013 (the “Acquisition Date”), we completed the acquisition of Enterasys Networks, Inc. (“Enterasys”), a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired, whereby Enterasys became our wholly-owned subsidiary.   The combined entity immediately became a networking industry leader with more than 14,000 customers. As a combined Company, we believe we will set the standard for the networking industry with a strategic focus on three principles:

[0001078271-15-000052:mdna:5]
Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center networking, switching and routing, Software-Defined Networking ("SDN"), wired and wireless LAN access, network management with analytics and integrated security features. This broader solutions portfolio can be leveraged to better serve existing and new customers. We will continue to enhance and support the product roadmaps of both companies going forward to protect the investments of customers and avoid any disruption to their businesses. We intend to increase research and development to accelerate our vision for high-performance, modular, open networking.

[0001078271-15-000052:mdna:6]
[same as prior period, unchanged from 0001078271-15-000007:mdna:6]

[0001078271-15-000052:mdna:7]
[same as prior period, unchanged from 0001078271-15-000007:mdna:7]

[0001078271-15-000052:mdna:8]
[same as prior period, unchanged from 0001078271-15-000007:mdna:8]

[0001078271-15-000052:mdna:9]
We outsource the majority of our manufacturing and supply chain management operations as part of our strategy to maintain global manufacturing capabilities and to reduce our costs. We conduct quality assurance, manufacturing engineering, document control and test development at engineering facilities in San Jose, California; Research Triangle Park, North Carolina; Salem, New Hampshire; Toronto, Canada and Chennai, India. This approach enables us to reduce fixed costs and to flexibly respond to changes in market demand.

[0001078271-15-000052:mdna:10]
[same as prior period, unchanged from 0001078271-15-000007:mdna:10]

[0001078271-15-000052:mdna:11]
[same as prior period, unchanged from 0001078271-15-000007:mdna:11]

[0001078271-15-000052:mdna:12]
[same as prior period, unchanged from 0001078271-15-000007:mdna:62]

[0001078271-15-000052:mdna:13]
[same as prior period, unchanged from 0001078271-15-000007:mdna:63]

[0001078271-15-000052:mdna:14]
[same as prior period, unchanged from 0001078271-15-000007:mdna:64]

[0001078271-15-000052:mdna:15]
[same as prior period, unchanged from 0001078271-15-000007:mdna:65]

[0001078271-15-000052:mdna:16]
[same as prior period, unchanged from 0001078271-15-000007:mdna:66]

[0001078271-15-000052:mdna:17]
[same as prior period, unchanged from 0001078271-15-000007:mdna:67]

[0001078271-15-000052:mdna:18]
[same as prior period, unchanged from 0001078271-15-000007:mdna:68]

[0001078271-15-000052:mdna:19]
[same as prior period, unchanged from 0001078271-15-000007:mdna:69]

[0001078271-15-000052:mdna:20]
[same as prior period, unchanged from 0001078271-15-000007:mdna:70]

[0001078271-15-000052:mdna:21]
[same as prior period, unchanged from 0001078271-15-000007:mdna:71]

[0001078271-15-000052:mdna:22]
[same as prior period, unchanged from 0001078271-15-000007:mdna:72]

[0001078271-15-000052:mdna:23]
[same as prior period, unchanged from 0001078271-15-000007:mdna:73]

[0001078271-15-000052:mdna:24]
[same as prior period, unchanged from 0001078271-15-000007:mdna:74]

[0001078271-15-000052:mdna:25]
[same as prior period, unchanged from 0001078271-15-000007:mdna:75]

[0001078271-15-000052:mdna:26]
|  | March 31, 2015 |  | June 30, 2014 |
| Cash and cash equivalent | $ | 74,067 |  |  | $ | 73,190 |  |
| Investments | 1,506 |  |  | 32,692 |  |
| Total cash and investments | $ | 75,573 |  |  | $ | 105,882 |  |
| Working capital | $ | 8,755 |  |  | $ | 56,548 |  |

[0001078271-15-000052:mdna:27]
As of March 31, 2015, our principal sources of liquidity consisted of cash, cash equivalents and investments of $75.6 million, net accounts receivable of $78.7 million and $1.0 million of letters of credit and borrowings from the Revolving Facility under which we had $8.6 million of additional availability as of March 31, 2015.  Our principal uses of cash will include purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, repayments of debt and related interest. We believe that our $75.6 million of cash and cash equivalents and investments as of March 31, 2015, along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001078271-15-000052:mdna:28]
Our Credit Agreement contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio, a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio

[0001078271-15-000052:mdna:29]
and several other covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.  During the three months ended December 31, 2014, we amended the Credit Agreement and among other things modified certain financial covenants governing the Quick and Leverage ratios.

[0001078271-15-000052:mdna:30]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Agreement may be accelerated upon certain events of default.  We believe we are in compliance and expect to remain in compliance with our Credit Agreement covenants and they are not expected to impact our liquidity or capital resources.

[0001078271-15-000052:mdna:31]
[same as prior period, unchanged from 0001078271-15-000007:mdna:80]

[0001078271-15-000052:mdna:32]
[same as prior period, unchanged from 0001078271-15-000007:mdna:81]

[0001078271-15-000052:mdna:33]
|  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |
| Net cash provided by (used in) operating activities | $ | 33,564 |  |  | $ | (30,617 | ) |
| Net cash provided by (used in) investing activities | 21,687 |  |  | (123,113 | ) |
| Net cash (used in) provided by financing activities | (50,607 | ) |  | 128,671 |  |
| Foreign currency effect on cash | (3,767 | ) |  | 611 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 877 |  |  | $ | (24,448 | ) |

[0001078271-15-000052:mdna:34]
[same as prior period, unchanged from 0001078271-15-000007:mdna:83]

[0001078271-15-000052:mdna:35]
Cash flows provided by operations was $33.6 million in the nine months ending March 31, 2015.  Current period's net loss was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation.  Accounts receivables decreased primarily due to lower sales during the current quarter and to our higher collections efforts.  Inventories increased primarily due to the reduced sales during the third quarter.  Accounts payable increased due to timing of payments.  The increases in cash inflows were offset by decreases in accrued compensation due to lower commissions and bonus accruals.

[0001078271-15-000052:mdna:36]
Cash flows used in operations was $30.6 million in the nine months ending March 31, 2014.  The net loss for the period was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation.  Accounts receivables, inventory and accounts payables primarily increased due to increased activity post acquisition.

[0001078271-15-000052:mdna:37]
[same as prior period, unchanged from 0001078271-15-000007:mdna:86]

[0001078271-15-000052:mdna:38]
Cash flow provided by investing activities was $21.7 million, in the nine months ending March 31, 2015, primarily comprised of proceeds from the sale and maturities of investments of $9.1 million and $21.8 million of investments, respectively, offset by $5.6 million used to purchase property and equipment and $3.0 million used to acquire a non-marketable equity interest.

[0001078271-15-000052:mdna:39]
Cash flow used in investing activities was $127.0 million in the nine months ending March 31, 2014, comprised of $180.0 million net cash used in the acquisition of Enterasys, purchases of investments of $9.0 million, $12.6 million used to purchase property and equipment offset by proceeds of $20.1 million from the maturities of investments and proceeds of $54.6 million from the sale of investments.

[0001078271-15-000052:mdna:40]
[same as prior period, unchanged from 0001078271-15-000007:mdna:89]

[0001078271-15-000052:mdna:41]
Cash flow used in financing activities was $50.6 million in the nine months ending March 31, 2015, comprised of $77.1 million of cash used for repayment of debt offset by a draw on the Revolving Facility of $24 million during the nine months ended March 31, 2015, for working capital requirements, $2.5 million proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-15-000052:mdna:42]
Cash flow provided by financing activities was $104.0 million in the nine months ending March 31, 2014, comprised of the issuance of a Term Loan of $65.0 million and a draw on the Revolving Facility of $35 million used for the acquisition of Enterasys, $4.8 million proceeds from the exercise of stock options and issuance of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards offset by $0.8 million of cash used for repayment of debt.

[0001078271-15-000052:mdna:43]
[same as prior period, unchanged from 0001078271-15-000007:mdna:92]

[0001078271-15-000052:mdna:44]
Foreign currency effect on cash increased in the nine months ending March 31, 2015, primarily due to the strengthening US Dollar and the resulting changes in foreign currency exchange rates between the US Dollar and particularly the Euro, Great Britain Pound, Brazilian Real, Swedish Krona, Indian Rupee and Australian Dollar.

[0001078271-15-000052:mdna:45]
[same as prior period, unchanged from 0001078271-15-000007:mdna:94]

[0001078271-15-000052:mdna:46]
The following summarizes our contractual obligations as of March 31, 2015, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-15-000052:mdna:47]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 68,500 |  |  | $ | 9,750 |  |  | $ | 37,375 |  |  | $ | 21,375 |  |  | $ | — |  |
| Interest on debt obligations | 4,628 |  |  | 1,834 |  |  | 2,488 |  |  | 306 |  |  | — |  |
| Non-cancellable inventory purchase commitments | 100,693 |  |  | 100,693 |  |  | — |  |  | — |  |  | — |  |
| Non-cancellable operating lease obligations | 66,040 |  |  | 10,681 |  |  | 18,630 |  |  | 16,934 |  |  | 19,795 |  |
| Other liabilities | 8,703 |  |  | 5,859 |  |  | 2,701 |  |  | 143 |  |  | — |  |
| Total contractual cash obligations | $ | 248,564 |  |  | $ | 128,817 |  |  | $ | 61,194 |  |  | $ | 38,758 |  |  | $ | 19,795 |  |

[0001078271-15-000052:mdna:48]
Non-cancellable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $100.7 million as of March 31, 2015.  We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-15-000052:mdna:49]
Non-cancellable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001078271-15-000052:mdna:50]
Other liabilities include our commitments towards debt related fees and specific arrangements other than inventory.

[0001078271-15-000052:mdna:51]
[same as prior period, unchanged from 0001078271-15-000007:mdna:100]

[0001078271-15-000052:mdna:52]
We did not have any material commitments for capital expenditures as of March 31, 2015.

[0001078271-15-000052:mdna:53]
[same as prior period, unchanged from 0001078271-15-000007:mdna:102]

[0001078271-15-000052:mdna:54]
We did not have any off-balance sheet arrangements as of March 31, 2015.

[0001078271-15-000052:mdna:55]
[same as prior period, unchanged from 0001078271-15-000007:mdna:12]

[0001078271-15-000052:mdna:56]
During the third quarter of fiscal 2015, we experienced the following results:

[0001078271-15-000052:mdna:57]
| • | Net revenues of $119.6 million compared to net revenues of $141.8 million in the third quarter of fiscal 2014. |

[0001078271-15-000052:mdna:58]
| • | Product revenues of $86.5 million compared to product revenues of $109.9 million in the third quarter of fiscal 2014. |

[0001078271-15-000052:mdna:59]
| • | Service revenues of $33.1 million compared to service revenues of $31.9 million in the third quarter of fiscal 2014. |

[0001078271-15-000052:mdna:60]
| • | Total gross margin of 48.3% of net revenues compared to total gross margin of 50.0% of net revenues in the third quarter of fiscal 2014. |

[0001078271-15-000052:mdna:61]
| • | Operating loss of $21.3 million compared to operating loss of $23.4 million in the third quarter of fiscal 2014. |

[0001078271-15-000052:mdna:62]
| • | Net loss of $23.5 million compared to net loss of $25.1 million in the third quarter of fiscal 2014. |

[0001078271-15-000052:mdna:63]
| • | Cash flow provided by operating activities of $33.6 million in the nine months ended March 31, 2015 compared to cash flow used in operating activities of $30.6 million in the nine months ended March 31, 2014. |

[0001078271-15-000052:mdna:64]
| • | Cash and cash equivalents, short-term investments and marketable securities decreased by $30.3 million to $75.6 million as of March 31, 2015 from $105.9 million as of June 30, 2014, primarily due to repayment of debt offset by cash provided by operations and investing activities. |

[0001078271-15-000052:mdna:65]
We operate in three regions: Americas; which includes the United States, Canada, Mexico, Central America and South America; EMEA; which includes Europe, Russia, Middle East, and Africa; and APAC; which includes Asia Pacific, South Asia, India, and Australia.

[0001078271-15-000052:mdna:66]
The following table presents the total net revenue geographically for the three and nine months ended March 31, 2015 and March 31, 2014 (dollars in thousands):

[0001078271-15-000052:mdna:67]
|  | Three Months Ended |  | Nine Months Ended |
| Net Revenues | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |  | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 49,353 |  |  | $ | 59,896 |  |  | $ | (10,543 | ) |  | (17.6 | )% |  | $ | 166,001 |  |  | $ | 141,576 |  |  | $ | 24,425 |  |  | 17.3 | % |
| Other | 7,073 |  |  | 12,082 |  |  | (5,009 | ) |  | (41.5 | )% |  | 26,990 |  |  | 37,816 |  |  | (10,826 | ) |  | (28.6 | )% |
| Total Americas | 56,426 |  |  | 71,978 |  |  | (15,552 | ) |  | (21.6 | )% |  | 192,991 |  |  | 179,392 |  |  | 13,599 |  |  | 7.6 | % |
| Percentage of net revenue | 47.0 | % |  | 50.8 | % |  |  |  |  |  | 47.9 | % |  | 49.2 | % |  |  |  |  |  |  |
| EMEA | 50,006 |  |  | 54,113 |  |  | (4,107 | ) |  | (7.6 | )% |  | 166,515 |  |  | 146,175 |  |  | 20,340 |  |  | 13.9 | % |
| Percentage of net revenue | 41.8 | % |  | 38.2 | % |  |  |  |  |  | 41.3 | % |  | 40.1 | % |  |  |  |  |  |  |
| APAC | 13,158 |  |  | 15,671 |  |  | (2,513 | ) |  | (16.0 | )% |  | 43,566 |  |  | 38,694 |  |  | 4,872 |  |  | 12.6 | % |
| Percentage of net revenue | 11.0 | % |  | 11.1 | % |  |  |  |  |  | 10.8 | % |  | 10.6 | % |  |  |  |  |
| Total net revenues | $ | 119,590 |  |  | $ | 141,762 |  |  | $ | (22,172 | ) |  | (15.6 | )% |  | $ | 403,072 |  |  | $ | 364,261 |  |  | $ | 38,811 |  |  | 10.7 | % |

[0001078271-15-000052:mdna:68]
[same as prior period, unchanged from 0001078271-15-000007:mdna:25]

[0001078271-15-000052:mdna:69]
The following table presents net product and service revenue for the three and nine months ended March 31, 2015 and March 31, 2014 (dollars in thousands):

[0001078271-15-000052:mdna:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |  | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 86,527 |  |  | $ | 109,891 |  |  | $ | (23,364 | ) |  | (21.3 | )% |  | $ | 301,700 |  |  | $ | 290,001 |  |  | $ | 11,699 |  |  | 4.0 | % |
| Percentage of net revenue | 72.4 | % |  | 77.5 | % |  |  |  |  |  | 74.9 | % |  | 79.6 | % |  |  |  |  |
| Service | 33,063 |  |  | 31,871 |  |  | 1,192 |  |  | 3.7 | % |  | 101,372 |  |  | 74,260 |  |  | 27,112 |  |  | 36.5 | % |
| Percentage of net revenue | 27.7 | % |  | 22.5 | % |  |  |  |  |  | 25.1 | % |  | 20.4 | % |  |  |  |  |
| Total net revenues | $ | 119,590 |  |  | $ | 141,762 |  |  | $ | (22,172 | ) |  | (15.6 | )% |  | $ | 403,072 |  |  | $ | 364,261 |  |  | $ | 38,811 |  |  | 10.7 | % |

[0001078271-15-000052:mdna:71]
Product revenue decreased $23.4 million or 21.3% in the three months ended March 31, 2015, compared to the corresponding period of fiscal 2014. In the Americas, we experienced deferred spending in our overall customer base as well as our overall deal sizes were smaller during the 2015 period compared to corresponding period of fiscal 2014.  The strengthening United States Dollar, especially against currencies in Europe and South America, resulted in customers delaying purchases or customers executing transactions at lower than expected spending levels.

[0001078271-15-000052:mdna:72]
Product revenue increased $11.7 million or 4.0% in the nine months ended March 31, 2015, compared to the corresponding period of fiscal 2014. The fiscal 2015 period reflects increased product shipments and customers as a result of our acquisition of Enterasys for the full nine months. Whereas the fiscal 2014 period only reflects five months of sales subsequent to the October 31, 2013 acquisition date.   However, the  increase in sales was partially offset by declines of customer spending across each geographical region and an increase in customer discounts. The decline in customer spending was partially due to the significant strengthening of the United States Dollar in all geographical areas and the entrance of competitors in regions where we have a strong presence, specifically in Asia Pacific and EMEA regions.

[0001078271-15-000052:mdna:73]
Service revenue increased $1.2 million or 3.7% for the three months ended March 31, 2015 compared to the corresponding period of fiscal 2014 due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys. Additionally, purchase accounting charges related to deferred service revenues decreased $1.1 million for the three months ended March 31, 2015, as compared to the corresponding period of fiscal 2014.

[0001078271-15-000052:mdna:74]
Service revenue increased $27.1 million or 36.5% for the nine months ended March 31, 2015 compared to the corresponding period of fiscal 2014 due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys.  Purchase accounting charges related to deferred service revenues decreased $1.4 million for the nine months ended March 31, 2015 as compared to the corresponding period of fiscal 2014.

[0001078271-15-000052:mdna:75]
[same as prior period, unchanged from 0001078271-15-000007:mdna:31]

[0001078271-15-000052:mdna:76]
The following table presents our product and service revenue gross profit and the respective gross profit percentages for the three and nine months ended March 31, 2015 and 2014 (dollars in thousands):

[0001078271-15-000052:mdna:77]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |  | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 36,766 |  |  | $ | 51,188 |  |  | $ | (14,422 | ) |  | (28.2 | )% |  | $ | 137,418 |  |  | $ | 136,889 |  |  | $ | 529 |  |  | 0.4 | % |
| Percentage of product revenue | 42.5 | % |  | 46.6 | % |  |  |  |  |  | 45.5 | % |  | 47.2 | % |  |  |  |  |
| Service | 20,958 |  |  | 19,667 |  |  | 1,291 |  |  | 6.6 | % |  | 65,995 |  |  | 47,518 |  |  | 18,477 |  |  | 38.9 | % |
| Percentage of service revenue | 63.4 | % |  | 61.7 | % |  |  |  |  |  | 65.1 | % |  | 64.0 | % |  |  |  |  |
| Total gross profit | $ | 57,724 |  |  | $ | 70,855 |  |  | $ | (13,131 | ) |  | (18.5 | )% |  | $ | 203,413 |  |  | $ | 184,407 |  |  | $ | 19,006 |  |  | 10.3 | % |
| Percentage of net revenue | 48.3 | % |  | 50.0 | % |  |  |  |  |  | 50.5 | % |  | 50.6 | % |  |  |  |  |

[0001078271-15-000052:mdna:78]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, amortization expense for developed technology, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our

[0001078271-15-000052:mdna:79]
manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution in San Jose, California; Salem, New Hampshire; China, and Taiwan.

[0001078271-15-000052:mdna:80]
Product gross profit decreased $14.4 million in the three months ended March 31, 2015, as compared to the corresponding period of fiscal 2014. Gross profit was impacted during the third quarter of fiscal 2015 by a decrease of $23.4 million in product revenue and higher material costs, an  increase of $3.2 million in excess and obsolete inventory charges and $0.7 million in distribution expenses due to higher utilization of air freight charges as compared to the corresponding period of fiscal 2014.

[0001078271-15-000052:mdna:81]
Product gross profit increased to $137.4 million in the nine months ended March 31, 2015, from $136.9 million in the corresponding period of fiscal 2014.  Product gross profit for the nine months ended March 31, 2014, was favorably impacted by an increase in product revenue of $35.2 million, offset by higher material costs, an increase of $5.8 million in excess and obsolete inventory charges, $5.6 million for amortization of the developed technology intangibles from the acquisition of Enterasys, $2.3 million for distribution costs, due to higher utilization of air freight charges and $1.2 million of warranty reserves.  Gross profit for the first nine months of fiscal 2014, was negatively impacted by $11.1 million related to the sale of inventory which had been adjusted to fair value upon the Enterasys acquisition due to purchase accounting.

[0001078271-15-000052:mdna:82]
Our cost of service revenue consists primarily of personnel, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts.

[0001078271-15-000052:mdna:83]
Service gross profit increased to $21.0 million in the three months ended March 31, 2015, from $19.7 million in the corresponding of fiscal 2014. The increase in service gross profit was primarily due to lower purchase accounting charges related to deferred service revenues of $1.1 million for the three months ended March 31, 2015, as compared to the three months ended March 31, 2014.

[0001078271-15-000052:mdna:84]
Service gross profit increased to $66.0 million for the nine months ended March 31, 2015, from $47.5 million in the corresponding period of fiscal 2014, primarily due to increase in service revenue of $27.1 million partially offset by increased personnel, overhead and travel costs as a result of the acquisition of Enterasys. Additionally, purchase accounting charges related to deferred service revenues decreased $1.4 million in fiscal 2015 as compared to fiscal 2014.

[0001078271-15-000052:mdna:85]
[same as prior period, unchanged from 0001078271-15-000007:mdna:39]

[0001078271-15-000052:mdna:86]
[same as prior period, unchanged from 0001078271-15-000007:mdna:40]

[0001078271-15-000052:mdna:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |  | March 31, 2015 |  | March 31, 2014 |  | $Change |  | %Change |
| Research and development | $ | 23,858 |  |  | $ | 24,265 |  |  | $ | (407 | ) |  | (1.7 | )% |  | $ | 71,205 |  |  | $ | 53,098 |  |  | $ | 18,107 |  |  | 34.1 | % |
| Sales and marketing | 39,226 |  |  | 44,703 |  |  | (5,477 | ) |  | (12.3 | )% |  | 127,976 |  |  | 108,033 |  |  | 19,943 |  |  | 18.5 | % |
| General and administrative | 9,711 |  |  | 11,178 |  |  | (1,467 | ) |  | (13.1 | )% |  | 31,091 |  |  | 29,301 |  |  | 1,790 |  |  | 6.1 | % |
| Acquisition and integration costs | 1,725 |  |  | 6,443 |  |  | (4,718 | ) |  | (73.2 | )% |  | 9,283 |  |  | 18,826 |  |  | (9,543 | ) |  | (50.7 | )% |
| Restructuring charge, net of reversals | — |  |  | (6 | ) |  | 6 |  |  | (100.0 | )% |  | — |  |  | 499 |  |  | (499 | ) |  | (100.0 | )% |
| Amortization of intangibles | 4,467 |  |  | 7,666 |  |  | (3,199 | ) |  | (41.7 | )% |  | 13,402 |  |  | 11,444 |  |  | 1,958 |  |  | 17.1 | % |
| Total operating expenses | $ | 78,987 |  |  | $ | 94,249 |  |  | $ | (15,262 | ) |  | (16.2 | )% |  | $ | 252,957 |  |  | $ | 221,201 |  |  | $ | 31,756 |  |  | 14.4 | % |
| Operating loss | $ | (21,263 | ) |  | $ | (23,394 | ) |  | $ | 2,131 |  |  | 9.1 | % |  | $ | (49,544 | ) |  | $ | (36,794 | ) |  | $ | (12,750 | ) |  | (34.7 | )% |

[0001078271-15-000052:mdna:88]
[same as prior period, unchanged from 0001078271-15-000007:mdna:42]

[0001078271-15-000052:mdna:89]
[same as prior period, unchanged from 0001078271-15-000007:mdna:43]

[0001078271-15-000052:mdna:90]
Research and development expenses decreased by $0.4 million for the three months ended March 31, 2015 as compared to the corresponding period of fiscal 2014. The comparison for the three month period were relatively flat due to the completion

[0001078271-15-000052:mdna:91]
of the integration of Enterasys. An increase of $0.9 million in personnel costs, $0.2 million in facilities costs and $0.2 million in depreciation, were offset by $1.4 million in reductions of engineering and software expenses.

[0001078271-15-000052:mdna:92]
Research and development increased by $18.1 million or 34.1% for the nine months ended March 31, 2015.  The increase in research and development expense for the nine month period were primarily due to increased spending as a result of our acquisition of Enterasys.  The increase in spending were $17.4 million of personnel costs, which includes compensation, benefits and non-cash stock based compensation, $1.0 million in depreciation and $0.8 million for supplies and equipment.

[0001078271-15-000052:mdna:93]
[same as prior period, unchanged from 0001078271-15-000007:mdna:45]

[0001078271-15-000052:mdna:94]
[same as prior period, unchanged from 0001078271-15-000007:mdna:46]

[0001078271-15-000052:mdna:95]
Sales and marketing expenses decreased by $5.5 million, or 12.3% for the three months ended March 31, 2015, as compared to the corresponding period of fiscal 2014. The decrease in sales and marketing expense for the three month period of fiscal 2015 were primarily due to lower compensation and benefits of $3.8 million due to reduced headcount, $0.4 million in professional fees and $0.3 million in facilities expense.  The decrease in sales and marketing expenses was also partially due to the strengthening United States Dollar.

[0001078271-15-000052:mdna:96]
Sales and marketing increased by $19.9 million or 18.5% for the nine months ended March 31, 2015, as compared to the corresponding period of fiscal 2014. The increase in sales and marketing expenses during the nine month period of fiscal 2015 was primarily due to $11.4 million of higher compensation and benefits, including non-cash stock compensation, $1.7 million in facilities. $1.4 million in travel.  This was partially offset with a reduction of $1.7 million in marketing expense.  All of these factors were driven by the acquisition of Enterasys.

[0001078271-15-000052:mdna:97]
[same as prior period, unchanged from 0001078271-15-000007:mdna:48]

[0001078271-15-000052:mdna:98]
General and administrative expense consists primarily of personnel costs, legal and professional service costs, share-based compensation, travel and facilities and information technology costs.

[0001078271-15-000052:mdna:99]
General and administrative expenses decreased by $1.5 million, or 13.1% for the three months ended March 31, 2015, as compared to the corresponding period of fiscal 2014. The decrease in general and administrative expenses was primarily due to $0.4 million of personnel costs, $0.4 million of travel costs and $0.3 million of professional service fees.

[0001078271-15-000052:mdna:100]
General and administrative expenses increased by $1.8 million or 6.1% for the nine months ended March 31, 2015, as compared to the corresponding periods of fiscal 2014. The increase in general and administrative expenses was primarily due to $2.8 million in higher personnel costs, $0.9 million for professional services fees and $0.5 million for recruiting fees due to an increase in headcount of approximately 100 employees, higher occupancy costs due to additional facilities in Salem, New Hampshire and Shannon, Ireland as a result of our acquisition of Enterasys and a $1.0 million increase in bad debt expense.  This increase was partial offset by $0.6 million in lower travel costs.

[0001078271-15-000052:mdna:101]
[same as prior period, unchanged from 0001078271-15-000007:mdna:50]

[0001078271-15-000052:mdna:102]
Acquisition and Integration costs include those expenses that the company has incurred as result of the acquisition of Enterasys and the related subsequent integration of the two companies.  The Company expects to continue to incur  integration costs for the remainder of fiscal 2015.

[0001078271-15-000052:mdna:103]
We incurred $1.7 million and $9.3 million of integration costs during the three and nine months ended March 31, 2015, respectively primarily for IT, warehouse, and sales integration and severance costs. The Company incurred $6.4 million and $18.8 million of acquisition and integration costs during the three and nine months ended March 31, 2014, respectively.

[0001078271-15-000052:mdna:104]
[same as prior period, unchanged from 0001078271-15-000007:mdna:53]

[0001078271-15-000052:mdna:105]
During the three and nine months ended March 31, 2015, we recorded $4.5 million and $13.4 million, respectively of amortization expense and during the three and nine months ended March 31, 2014, we recorded $7.7 million and $11.4 million, respectively, of amortization expense, primarily for certain intangible assets related to our acquisition of Enterasys.

[0001078271-15-000052:mdna:106]
[same as prior period, unchanged from 0001078271-15-000007:mdna:55]

[0001078271-15-000052:mdna:107]
Interest expense is comprised of interest charges related to the Credit Facility we entered into on October 31, 2013. We recorded interest expense of $0.8 million in each of the three months ended March 31, 2015 and 2014.  We recorded interest expense of $2.4 million and $1.3 million during the nine months ended March 31, 2015 and 2014, respectively.

[0001078271-15-000052:mdna:108]
[same as prior period, unchanged from 0001078271-15-000007:mdna:57]

[0001078271-15-000052:mdna:109]
Other expense, net increased by $0.4 million in the third quarter of fiscal 2015, compared to the corresponding period of fiscal 2014.  The increase in other expense, net was primarily due to gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001078271-15-000052:mdna:110]
Other expense, net decreased by $0.3 million in the nine months ended March 31, 2015, compared to the corresponding period of fiscal 2014.  The decrease in other expense, net was primarily due to losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001078271-15-000052:mdna:111]
[same as prior period, unchanged from 0001078271-15-000007:mdna:59]

[0001078271-15-000052:mdna:112]
For the three and nine months ended March 31, 2015, we recorded an income tax provision of $1.1 million and $3.5 million, respectively. For the three and nine months ended March 31, 2014, we recorded an income tax provision of $0.9 million and $2.3 million, respectively.

[0001078271-15-000052:mdna:113]
The income tax provisions for the three and nine months ended March 31, 2015 and 2014, consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.
