# EXTR notes — 0001078271-13-000006


## us-gaap:AvailableForSaleSecuritiesContinuousUnrealizedLossPositionFairValueTableTextBlock

[0001078271-13-000006:notes:1]
[same as prior period, unchanged from 0001078271-12-000073:notes:1]

[0001078271-13-000006:notes:2]
|  | Less than 12 months |  | 12 months or more |  | Total |
|  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |  | Fair Value |  | UnrealizedLosses |
| December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |
| U.S. corporate debt securities | $ | 26,202 |  |  | $ | (75 | ) |  | $ | — |  |  | $ | — |  |  | $ | 26,202 |  |  | $ | (75 | ) |
|  | $ | 26,202 |  |  | $ | (75 | ) |  | $ | — |  |  | $ | — |  |  | $ | 26,202 |  |  | $ | (75 | ) |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-13-000006:notes:3]
[same as prior period, unchanged from 0001078271-12-000073:notes:3]

[0001078271-13-000006:notes:4]
[same as prior period, unchanged from 0001078271-12-000073:notes:4]

[0001078271-13-000006:notes:5]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| December 31, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 59,110 |  |  | $ | 59,110 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 98,706 |  |  | 98,899 |  |  | 268 |  |  | (75 | ) |
| U.S. government agency securities | 7,508 |  |  | 7,513 |  |  | 5 |  |  | — |  |
|  | $ | 165,324 |  |  | $ | 165,522 |  |  | $ | 273 |  |  | $ | (75 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 59,110 |  |  | $ | 59,110 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 35,125 |  |  | 35,204 |  |  | 79 |  |  | — |  |
| Marketable securities | 71,089 |  |  | 71,208 |  |  | 194 |  |  | (75 | ) |
|  | $ | 165,324 |  |  | $ | 165,522 |  |  | $ | 273 |  |  | $ | (75 | ) |
| June 30, 2012 |  |  |  |  |  |  |  |
| Money market funds | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 84,882 |  |  | 84,949 |  |  | 148 |  |  | (81 | ) |
| U.S. government agency securities | 11,241 |  |  | 11,234 |  |  | 3 |  |  | (10 | ) |
| U.S. municipal bonds | 2,738 |  |  | 2,736 |  |  | — |  |  | (2 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 36,141 |  |  | $ | 36,141 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 23,311 |  |  | 23,358 |  |  | 48 |  |  | (1 | ) |
| Marketable securities | 75,550 |  |  | 75,561 |  |  | 103 |  |  | (92 | ) |
|  | $ | 135,002 |  |  | $ | 135,060 |  |  | $ | 151 |  |  | $ | (93 | ) |

[0001078271-13-000006:notes:6]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at December 31, 2012, by contractual maturity, were as follows (in thousands):

[0001078271-13-000006:notes:7]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 35,125 |  |  | $ | 35,204 |  |
| Due in 1-2 years | 31,367 |  |  | 31,447 |  |
| Due in 2-5 years | 39,722 |  |  | 39,761 |  |
| Total investments in available for sale debt securities | $ | 106,214 |  |  | $ | 106,412 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-13-000006:notes:8]
Commitments and Contingencies

[0001078271-13-000006:notes:9]
Purchase Commitments

[0001078271-13-000006:notes:10]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2012, the Company had non-cancelable commitments to purchase approximately $21.8 million of such inventory.

[0001078271-13-000006:notes:11]
Legal Proceedings

[0001078271-13-000006:notes:12]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-13-000006:notes:13]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-13-000006:notes:14]
Intellectual Property Litigation

[0001078271-13-000006:notes:15]
Enterasys Networks

[0001078271-13-000006:notes:16]
On June 21, 2005, Enterasys Networks ("Enterasys") filed suit against Extreme and Foundry Networks, Inc. (“Foundry”) in the United States District Court for the District of Massachusetts, Civil Action No. 05-11298 DPW. The complaint alleges willful infringement of U.S. Patent Nos. 5,251,205; 5,390,173; 6,128,665; 6,147,995; 6,539,022; and 6,560,236, and seeks: a) a judgment that the Company willfully infringes each of the patents; (b) a permanent injunction from infringement, inducement of infringement and contributory infringement of each of the six patents; (c) damages and a “reasonable royalty” to be determined at trial; (d) treble damages; (e) attorneys' fees, costs and interest; and (f) equitable relief at the Court's discretion. Petitions for reexamination were filed challenging five of the patents at issue to the U.S. Patent and Trademark Office, and a stay of the case was entered. Following the reexamination proceedings, Enterasys withdrew its allegations of infringement as to two of the patents, U.S. Patent Nos. 6,539,022 and 6,560,236. The stay was lifted on May 21, 2010, and the Court held claim construction hearings in December 2010. Fact discovery is ongoing. No trial date has been set. The Company intends to defend the lawsuit vigorously, but, due to the inherent uncertainties of litigation, it cannot predict the ultimate outcome of the matter at this time.

[0001078271-13-000006:notes:17]
On April 20, 2007, the Company filed suit against Enterasys in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded the Company damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.

[0001078271-13-000006:notes:18]
On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Both parties filed post-trial motions, including motions for a new trial, for judgment as a matter of law and for attorneys' fees, all of which the Court denied on July 11, 2012. Enterasys did not file a notice of appeal by the August 10, 2012 deadline.  Consequently, the judgment of non-infringement in favor of the Company in the second trial is final. During the fourth quarter of fiscal 2012, Enterasys paid the Company $0.6 million related to the judgment.  During the quarter ended December 31, 2012, the Company received payments from Enterasys totaling approximately $0.4 million for the Court's award for damages, supplemental damages, pre and post judgment interests, costs from the first trial and second trial, plus the amount Enterasys agreed to release for damages held in escrow that accrued during the stay of the injunction post-trial and on appeal.

[0001078271-13-000006:notes:19]
Chrimar Systems

[0001078271-13-000006:notes:20]
On October 31, 2011, Chrimar Systems, Inc. dba CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 (the "Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.

[0001078271-13-000006:notes:21]
On November 1, 2011, Chrimar filed a complaint with the International Trade Commission, pursuant to Section 337 of the Tariff Act of 1930, as amended, alleging that the Company imports into the United States, sells for importation and/or sells within the United States after importation of products and/or systems infringing U.S. Patent No. 7,457,250 patent, the same patent asserted in the Delaware action.  On December 2, 2011, the International Trade Commission instituted an investigation of these allegations (the "ITC action").  The complaint in the ITC action seeks a permanent order excluding from entry into the United States all infringing articles that are manufactured, imported or sold by the Company that infringe U.S. Patent No. 7,457,250. On July 20, 2012, Chrimar filed a motion to withdraw its complaint in the ITC action and the motion was granted on August 1, 2012 by the presiding administrative law judge. On August 27, 2012, the Commission determined not to review the administrative law judge's decision, rendering that decision final.

[0001078271-13-000006:notes:22]
During the fourth quarter of the fiscal 2012, the Company engaged in settlement discussions with Chrimar Systems Inc.  As part of the negotiations the Company determined that it is reasonably possible that a range of loss could be between $0.3 million and $1.4 million which is dependent on a number of factors including whether mutually acceptable settlement terms can be reached. As of December 31, 2012 and through the date of the filing of this Form 10-Q, this matter was still pending.  However, during the quarter ended June 30, 2012 the Company recorded a charge of $0.3 million based on its best estimate of the probable loss.

[0001078271-13-000006:notes:23]
Reefedge Networks

[0001078271-13-000006:notes:24]
On September 17, 2012, Reefedge Networks, LLC filed suit against the Company in the United States District Court for the District of Delaware, Civil Action No. 12-1148. The complaint alleges wrongful use, making, selling, and/or offering to sell products that infringe U.S. Patent Nos. 6,633.761; 6,975,864; and 7,197,308 and seeks unspecified monetary damages and a permanent injunction for products originating from a single supplier to which the Company has submitted an indemnification request. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome. An answer was filed on December 10, 2012. The Company plans to vigorously defend itself.

[0001078271-13-000006:notes:25]
Indemnification Obligations

[0001078271-13-000006:notes:26]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of December 31, 2012, the Company had no outstanding indemnification claims


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-13-000006:notes:27]
The following table summarizes deferred revenue, net at December 31, 2012 and June 30, 2012, respectively (in thousands):

[0001078271-13-000006:notes:28]
|  | December 31, 2012 |  | June 30, 2012 |
| Deferred services | $ | 36,118 |  |  | $ | 37,708 |  |
| Deferred product: |  |  |  |
| Deferred revenue | 2,231 |  |  | 2,236 |  |
| Deferred cost of sales | (775 | ) |  | (616 | ) |
| Deferred product revenue, net | 1,456 |  |  | 1,620 |  |
| Balance at end of period | 37,574 |  |  | 39,328 |  |
| Less: current portion | 29,441 |  |  | 31,769 |  |
| Non-current deferred revenue, net | $ | 8,133 |  |  | $ | 7,559 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-13-000006:notes:29]
[same as prior period, unchanged from 0001078271-12-000073:notes:28]

[0001078271-13-000006:notes:30]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in Japanese Yen, the Euro, the Swedish Krona, the Indian Rupee and the British Pound. These derivatives do not qualify as hedges. At December 31, 2012, these forward foreign currency contracts had a notional principal amount of $9.5 million and an immaterial unrealized gain on foreign exchange contracts. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-13-000006:notes:31]
Foreign currency transaction gains and losses from operations were a $0.4 million gain for the three months ended December 31, 2012 and a $0.1 million loss for the three months ended January 1, 2012.  Foreign currency transaction gains and losses were a $0.1 million gain for the six months ended December 31, 2012 and an immaterial loss for the six months ended January 1, 2012.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-13-000006:notes:32]
[same as prior period, unchanged from 0001078271-12-000073:notes:31]

[0001078271-13-000006:notes:33]
[same as prior period, unchanged from 0001078271-12-000073:notes:32]

[0001078271-13-000006:notes:34]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Cost of product revenue | $ | 121 |  |  | $ | 135 |  |  | $ | 295 |  |  | $ | 291 |  |
| Cost of service revenue | 85 |  |  | 30 |  |  | 244 |  |  | 144 |  |
| Research and development | 288 |  |  | 280 |  |  | 720 |  |  | 752 |  |
| Sales and marketing | 567 |  |  | 323 |  |  | 1,295 |  |  | 819 |  |
| General and administrative | 555 |  |  | 513 |  |  | 1,230 |  |  | 1,170 |  |
| Total share-based compensation expense | $ | 1,616 |  |  | $ | 1,281 |  |  | $ | 3,784 |  |  | $ | 3,176 |  |

[0001078271-13-000006:notes:35]
During the three and six months ended December 31, 2012 and January 1, 2012, the Company did not capitalize any stock-based compensation expense in inventory, as the amounts were immaterial. The income tax benefit for share-based compensation expense was immaterial in the three and six months ended December 31, 2012 and January 1, 2012.

[0001078271-13-000006:notes:36]
The weighted-average grant-date per share fair value of options granted during the three months ended December 31, 2012 and January 1, 2012 were $1.73 and $1.54, respectively. The weighted-average estimated per share fair value of shares purchased under the Company’s 1999 Employee Stock Purchase Plan (“ESPP”) during the three months ended December 31, 2012 and January 1, 2012 were $0.91 and $1.03, respectively.

[0001078271-13-000006:notes:37]
The weighted-average grant-date per share fair value of options granted during the six months ended December 31, 2012 and January 1, 2012 were $1.81 and $1.66, respectively. The weighted-average estimated per share fair value of shares purchased under the ESPP during the six months ended December 31, 2012 and January 1, 2012 were $0.89 and $0.99, respectively.

[0001078271-13-000006:notes:38]
The following table summarizes stock option activity under all plans for the six months ended December 31, 2012:

[0001078271-13-000006:notes:39]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value(000’s) |
| Options outstanding at June 30, 2012 | 9,006 |  |  | $ | 3.68 |  |  |  |  |  |
| Granted | 1,830 |  |  | $ | 3.49 |  |  |  |  |  |
| Exercised | (454 | ) |  | $ | 2.86 |  |  |  |  | $ | 314 |  |
| Canceled | (633 | ) |  | $ | 3.69 |  |  |  |  |  |
| Options outstanding at December 31, 2012 | 9,749 |  |  | $ | 3.68 |  |  | 4.79 |  | $ | 3,104 |  |
| Exercisable at December 31, 2012 | 5,742 |  |  | $ | 3.89 |  |  | 4.03 |  | $ | 2,036 |  |
| Vested and expected to vest at December 31, 2012 | 9,257 |  |  | $ | 3.70 |  |  | 4.73 |  | $ | 2,984 |  |

[0001078271-13-000006:notes:40]
[same as prior period, unchanged from 0001078271-12-000073:notes:38]

[0001078271-13-000006:notes:41]
[same as prior period, unchanged from 0001078271-12-000073:notes:39]

[0001078271-13-000006:notes:42]
The following table summarizes stock award activity for the six months ended December 31, 2012:

[0001078271-13-000006:notes:43]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |  | Aggregate Fair Market Value ($000's) |
| Non-vested stock outstanding at June 30, 2012 | 1,078 |  |  | $ | 2.35 |  |  |  |
| Granted | 2,589 |  |  | $ | 3.47 |  |  |  |
| Vested | (647 | ) |  | $ | 3.37 |  |  | $ | 2,181 |  |
| Cancelled | (83 | ) |  | $ | 3.32 |  |  |  |
| Non-vested stock outstanding at December 31, 2012 | 2,937 |  |  | $ | 3.09 |  |  |  |

[0001078271-13-000006:notes:44]
[same as prior period, unchanged from 0001078271-12-000073:notes:42]

[0001078271-13-000006:notes:45]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Expected life | 4 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |  | 5 years |  |  | 5 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 0.57 | % |  | 1.00 | % |  | 0.04 | % |  | 0.04 | % |  | 0.71 | % |  | 1.09 | % |  | 0.05 | % |  | 0.04 | % |
| Volatility | 63 | % |  | 61 | % |  | 50 | % |  | 79 | % |  | 64 | % |  | 59 | % |  | 59 | % |  | 70 | % |
| Dividend yield | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |  | — | % |

[0001078271-13-000006:notes:46]
[same as prior period, unchanged from 0001078271-12-000073:notes:44]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001078271-13-000006:notes:47]
Basic earnings (loss) per share is calculated by dividing net income (loss) by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.

[0001078271-13-000006:notes:48]
[same as prior period, unchanged from 0001078271-12-000073:notes:46]


## us-gaap:EarningsPerShareTextBlock

[0001078271-13-000006:notes:49]
Net (Loss) Income Per Share

[0001078271-13-000006:notes:50]
Basic earnings (loss) per share is calculated by dividing net income (loss) by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock. The following table presents the calculation of basic and diluted net income(loss) per share (in thousands, except per share data):

[0001078271-13-000006:notes:51]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Net (loss) income | $ | (4,206 | ) |  | $ | 4,107 |  |  | $ | 8,709 |  |  | $ | 5,689 |  |
| Weighted-average shares used in per share calculation – basic | 94,501 |  |  | 93,247 |  |  | 94,619 |  |  | 92,978 |  |
| Incremental shares using the treasury stock method: |  |  |  |  |  |  |  |
| Stock options | — |  |  | 282 |  |  | 418 |  |  | 299 |  |
| Restricted stock units | — |  |  | 471 |  |  | 370 |  |  | 645 |  |
| Employee Stock Purchase Plan | — |  |  | 118 |  |  | 107 |  |  | 134 |  |
| Weighted -average share used in per share calculation – diluted | 94,501 |  |  | 94,118 |  |  | 95,514 |  |  | 94,056 |  |
| Net income (loss) per share – basic | (0.04 | ) |  | 0.04 |  |  | 0.09 |  |  | 0.06 |  |
| Net income (loss) per share – diluted | (0.04 | ) |  | 0.04 |  |  | 0.09 |  |  | 0.06 |  |

[0001078271-13-000006:notes:52]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the stock purchase plan. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For the three and six months ended December 31, 2012, the Company excluded 7.3 million and 7.0 million outstanding weighted average stock options, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.  The Company excluded 8.8 million and 8.7 million outstanding weighted average stock options from the calculation of diluted earnings per common share in the three and six months ended January 1, 2012 because they would have been anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001078271-13-000006:notes:53]
[same as prior period, unchanged from 0001078271-12-000073:notes:51]

[0001078271-13-000006:notes:54]
[same as prior period, unchanged from 0001078271-12-000073:notes:52]

[0001078271-13-000006:notes:55]
[same as prior period, unchanged from 0001078271-12-000073:notes:53]

[0001078271-13-000006:notes:56]
[same as prior period, unchanged from 0001078271-12-000073:notes:54]

[0001078271-13-000006:notes:57]
| December 31, 2012 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Federal agency notes | $ | — |  |  | $ | 7,513 |  |  | $ | — |  |  | $ | 7,513 |  |
| Money market funds | 59,110 |  |  | — |  |  | — |  |  | 59,110 |  |
| Corporate notes/bonds | — |  |  | 98,899 |  |  | — |  |  | 98,899 |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| Total | $ | 59,110 |  |  | $ | 106,422 |  |  | $ | — |  |  | $ | 165,532 |  |

[0001078271-13-000006:notes:58]
[same as prior period, unchanged from 0001078271-12-000073:notes:56]

[0001078271-13-000006:notes:59]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. There were no transfers of assets or liabilities between Level 1 and Level 2 during the three months ended December 31, 2012 and January 1, 2012.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-13-000006:notes:60]
[same as prior period, unchanged from 0001078271-12-000073:notes:58]

[0001078271-13-000006:notes:61]
Long-lived assets include property and equipment, intangible assets, and service inventory.  Property and equipment and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. The Company reduces the carrying value of service inventory to net realizable value based on excess and obsolete inventories which are primarily determined by age of inventory and future demand forecasts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-13-000006:notes:62]
[same as prior period, unchanged from 0001078271-12-000073:notes:60]

[0001078271-13-000006:notes:63]
The Company recorded an income tax provision of $0.4 million and $0.2 million for the three months ended December 31, 2012 and January 1, 2012, respectively.  The Company recorded an income tax provision of $1.0 million and $0.7 million for the six months ended December 31, 2012 and January 1, 2012 respectively.

[0001078271-13-000006:notes:64]
The income tax provisions for the three and six months ended December 31, 2012 and January 1, 2012 consisted primarily of taxes on foreign income and U.S. state income taxes. The income tax provisions for both fiscal years were calculated based on the results of operations for the three and six months ended December 31, 2012 and January 1, 2012, and may not reflect the annual effective rate.

[0001078271-13-000006:notes:65]
[same as prior period, unchanged from 0001078271-12-000073:notes:63]

[0001078271-13-000006:notes:66]
The Company has a full valuation allowance against its U.S. net deferred tax assets. The valuation allowance was calculated by assessing both negative and positive evidence when measuring the need for a valuation allowance. Negative evidence, such as the Company's current quarter financial performance, the Company's significant restructuring in the current quarter, and the unfavorable macroeconomic climate were given more weight than our expectations of future profitability, which are inherently uncertain.  Our current U.S. loss along with these negative factor represented sufficient negative evidence to require a full valuation allowance against our U.S. federal and state net deferred tax assets.  This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results have sufficiently improved to support realization of the Company's U.S. deferred tax assets.

[0001078271-13-000006:notes:67]
[same as prior period, unchanged from 0001078271-12-000073:notes:65]

[0001078271-13-000006:notes:68]
The Company had $25.8 million of unrecognized tax benefits as of December 31, 2012. The future impact of the unrecognized tax benefit of $25.8 million, if recognized, is as follows: approximately $0.5 million would impact the effective tax rate, and approximately $25.3 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-13-000006:notes:69]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Consolidated Statements of Income and were immaterial for both the three months and six months periods ended December 31, 2012. Accrued interest and penalties were $0.1 million and $0.2 million as of December 31, 2012 and January 1, 2012, respectively.

[0001078271-13-000006:notes:70]
[same as prior period, unchanged from 0001078271-12-000073:notes:68]


## us-gaap:InventoryPolicyTextBlock

[0001078271-13-000006:notes:71]
[same as prior period, unchanged from 0001078271-12-000073:notes:69]

[0001078271-13-000006:notes:72]
[same as prior period, unchanged from 0001078271-12-000073:notes:70]


## us-gaap:InvestmentPolicyTextBlock

[0001078271-13-000006:notes:73]
[same as prior period, unchanged from 0001078271-12-000073:notes:71]

[0001078271-13-000006:notes:74]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value. The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income (loss) in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001078271-13-000006:notes:75]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. During the three and six months ended December 31, 2012, realized gains or losses recognized on the sale of investments were not significant. As of December 31, 2012, thirteen out of sixty-four investment securities had unrealized losses. The unrealized gains / (losses) on the Company’s investments were caused by interest rate fluctuations. Substantially all of the Company’s available-for-sale investments are investment grade government and corporate debt securities that have maturities of less than three years. The Company does not intend to sell the investments and it is not more likely than not that the Company will be required to sell the investments before recovery of its amortized costs.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001078271-13-000006:notes:76]
[same as prior period, unchanged from 0001078271-12-000073:notes:76]

[0001078271-13-000006:notes:77]
The unaudited condensed consolidated financial statements of Extreme Networks, Inc. (referred to as the “Company” or “Extreme Networks”) included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at December 31, 2012 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2012.

[0001078271-13-000006:notes:78]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2012. The results of operations for the three and six months ended December 31, 2012 are not necessarily indicative of the results that may be expected for fiscal 2013 or any future periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-13-000006:notes:79]
[same as prior period, unchanged from 0001078271-12-000073:notes:79]

[0001078271-13-000006:notes:80]
As part of the Company's on-going restructuring efforts, during the three months ended December 31, 2012, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. Restructuring expense was $5.2 million in both the three and six months ended December 31, 2012 and $0.4 million and $1.4 million in the three and six months ended January 1, 2012, respectively.

[0001078271-13-000006:notes:81]
The following table summarizes restructuring activities for the six months ended December 31, 2012:

[0001078271-13-000006:notes:82]
|  |  | Termination Benefits (1) |  | Excess Facilities (2) |  | Other Cost |  | Total |
| Balance at July 1, 2012 |  | $ | 359 |  |  | $ | 93 |  |  | $ | 11 |  |  | $ | 463 |  |
| Period charges |  | 5,065 |  |  | 16 |  |  | 110 |  |  | 5,191 |  |
| Period reversals |  | (24 | ) |  | — |  |  | — |  |  | (24 | ) |
| Period payments |  | (477 | ) |  | (109 | ) |  | (12 | ) |  | (598 | ) |
| Restructuring liabilities at December 31, 2012 |  | $ | 4,923 |  |  | $ | — |  |  | $ | 109 |  |  | $ | 5,032 |  |

[0001078271-13-000006:notes:83]
(1) Termination benefits generally include severance, outplacement services and health insurance coverage.

[0001078271-13-000006:notes:84]
(2) Excess facilities costs generally include rent expense less expected sublease income, lease termination costs and asset abandonment costs.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-13-000006:notes:85]
[same as prior period, unchanged from 0001078271-12-000073:notes:81]

[0001078271-13-000006:notes:86]
[same as prior period, unchanged from 0001078271-12-000073:notes:82]

[0001078271-13-000006:notes:87]
[same as prior period, unchanged from 0001078271-12-000073:notes:83]

[0001078271-13-000006:notes:88]
[same as prior period, unchanged from 0001078271-12-000073:notes:84]


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-13-000006:notes:89]
[same as prior period, unchanged from 0001078271-12-000073:notes:85]

[0001078271-13-000006:notes:90]
[same as prior period, unchanged from 0001078271-12-000073:notes:86]

[0001078271-13-000006:notes:91]
|  | December 31, 2012 |  | June 30, 2012 |
| Cash | $ | 30,656 |  |  | $ | 18,455 |  |
| Cash equivalents | $ | 59,110 |  |  | $ | 36,141 |  |
| Short-term investments | 35,204 |  |  | 23,358 |  |
| Marketable securities | 71,208 |  |  | 75,561 |  |
| Total available-for-sale | $ | 165,522 |  |  | $ | 135,060 |  |
| Total cash and available for sale securities | $ | 196,178 |  |  | $ | 153,515 |  |


## us-gaap:ScheduleOfExpectedAmortizationExpenseTableTextBlock

[0001078271-13-000006:notes:92]
[same as prior period, unchanged from 0001078271-12-000073:notes:88]

[0001078271-13-000006:notes:93]
| For the fiscal year ending: |  |
| Remaining for fiscal 2013 | $ | 680 |  |
| 2014 | 916 |  |
| 2015 | 549 |  |
| 2016 | 375 |  |
| 2017 | 302 |  |
| Thereafter | 1,817 |  |
| Total | $ | 4,639 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001078271-13-000006:notes:94]
[same as prior period, unchanged from 0001078271-12-000073:notes:90]

[0001078271-13-000006:notes:95]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| December 31, 2012 |  |  |  |  |  |  |  |
| Patents | 7.2 years |  | $ | 1,800 |  |  | $ | 775 |  |  | $ | 1,025 |  |
| License Agreements | 10 years |  | 10,158 |  |  | 6,845 |  |  | 3,313 |  |
| Other Intangibles | 2.7 years |  | 659 |  |  | 358 |  |  | 301 |  |
|  |  |  | $ | 12,617 |  |  | $ | 7,978 |  |  | $ | 4,639 |  |

[0001078271-13-000006:notes:96]
[same as prior period, unchanged from 0001078271-12-000073:notes:92]


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-13-000006:notes:97]
The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2012 and January 1, 2012:

[0001078271-13-000006:notes:98]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Balance beginning of period | $ | 2,971 |  |  | $ | 2,702 |  |  | $ | 2,871 |  |  | $ | 2,640 |  |
| New warranties issued | 1,942 |  |  | 1,589 |  |  | 3,504 |  |  | 3,237 |  |
| Warranty expenditures | (1,942 | ) |  | (1,640 | ) |  | (3,404 | ) |  | (3,226 | ) |
| Balance end of period | $ | 2,971 |  |  | $ | 2,651 |  |  | $ | 2,971 |  |  | $ | 2,651 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-13-000006:notes:99]
[same as prior period, unchanged from 0001078271-12-000073:notes:99]

[0001078271-13-000006:notes:100]
|  | Three Months Ended |  | Six Months Ended |
| Net Revenues: | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 22,731 |  |  | $ | 26,588 |  |  | $ | 47,935 |  |  | $ | 52,389 |  |
| Other | 10,767 |  |  | 11,307 |  |  | 20,545 |  |  | 19,511 |  |
| Total Americas | 33,498 |  |  | 37,895 |  |  | 68,480 |  |  | 71,900 |  |
| EMEA | 28,700 |  |  | 31,335 |  |  | 57,220 |  |  | 60,815 |  |
| APAC | 13,353 |  |  | 13,582 |  |  | 25,978 |  |  | 28,991 |  |
| Total net revenues | $ | 75,551 |  |  | $ | 82,812 |  |  | $ | 151,678 |  |  | $ | 161,706 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001078271-13-000006:notes:101]
The following table sets forth major customers accounting for 10% or more of our net revenue (amounts for the three and six months ended January 1, 2012 have been revised to correct previously disclosed amounts):

[0001078271-13-000006:notes:102]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Westcon Group Inc. |  | 14 | % |  | 22 | % |  | 15 | % |  | 19 | % |
| Scansource, Inc. |  | 12 | % |  | * |  |  | 12 | % |  | 13 | % |
| Tech Data Corporation |  | 12 | % |  | * |  |  | 11 | % |  | * |  |
| Ericsson AB |  | 10 | % |  | 12 | % |  | 10 | % |  | 11 | % |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |

[0001078271-13-000006:notes:103]
[same as prior period, unchanged from 0001078271-12-000073:notes:103]

[0001078271-13-000006:notes:104]
|  |  | December 31, 2012 |  | June 30, 2012 |
| Ericsson AB |  | 16 | % |  | 21 | % |
| Scansource Inc. |  | 11 | % |  | * |  |
| Westcon Group Inc. |  | * |  |  | 16 | % |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-13-000006:notes:105]
[same as prior period, unchanged from 0001078271-12-000073:notes:105]

[0001078271-13-000006:notes:106]
[same as prior period, unchanged from 0001078271-12-000073:notes:106]

[0001078271-13-000006:notes:107]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, Japan, and Australia.

[0001078271-13-000006:notes:108]
Substantially all of the Company’s assets were attributable to North America operations at December 31, 2012 and January 1, 2012.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-13-000006:notes:109]
[same as prior period, unchanged from 0001078271-12-000073:notes:109]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001078271-13-000006:notes:110]
[same as prior period, unchanged from 0001078271-12-000073:notes:113]

[0001078271-13-000006:notes:111]
On September 11, 2012, the Company completed the sale of its corporate campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million and realized a gain of $11.5 million.

[0001078271-13-000006:notes:112]
[same as prior period, unchanged from 0001078271-12-000073:notes:116]

[0001078271-13-000006:notes:113]
Amortization expense was $0.4 million and $0.5 million for the three months ended December 31, 2012 and January 1, 2012, respectively.  Amortization expense was $0.8 million and $1.0 million for the six months ended December 31, 2012 and January 1, 2012, respectively.  Amortization expense expected to be recorded for each of the next five years is as follows (in thousands):

[0001078271-13-000006:notes:114]
[same as prior period, unchanged from 0001078271-12-000073:notes:119]

[0001078271-13-000006:notes:115]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met. The following table summarizes deferred revenue, net at December 31, 2012 and June 30, 2012, respectively (in thousands):

[0001078271-13-000006:notes:116]
[same as prior period, unchanged from 0001078271-12-000073:notes:121]

[0001078271-13-000006:notes:117]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Balance beginning of period | $ | 35,661 |  |  | $ | 35,730 |  |  | $ | 37,461 |  |  | $ | 35,802 |  |
| New support arrangements | 14,776 |  |  | 15,960 |  |  | 27,313 |  |  | 30,560 |  |
| Recognition of support revenue | (14,640 | ) |  | (14,274 | ) |  | (28,977 | ) |  | (28,946 | ) |
| Balance end of period | 35,797 |  |  | 37,416 |  |  | 35,797 |  |  | 37,416 |  |
| Less: current portion | 27,664 |  |  | 29,853 |  |  | 27,664 |  |  | 29,853 |  |
| Non-current deferred revenue | $ | 8,133 |  |  | $ | 7,563 |  |  | $ | 8,133 |  |  | $ | 7,563 |  |

[0001078271-13-000006:notes:118]
[same as prior period, unchanged from 0001078271-12-000073:notes:123]

[0001078271-13-000006:notes:119]
The Company records revenue from its distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to its distributors in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its condensed consolidated balance sheet.  When the Company ships products to its distributors, legal title to the products passes to its distributors, and a legally enforceable obligation is created for the distributors to pay on a current basis.  Therefore, the Company records a trade receivable at the contractual discount to the list selling price and relieves inventory for the cost of goods shipped to the distributor.

[0001078271-13-000006:notes:120]
[same as prior period, unchanged from 0001078271-12-000073:notes:125]

[0001078271-13-000006:notes:121]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at December 31, 2012 and June 30, 2012, respectively (in thousands):

[0001078271-13-000006:notes:122]
|  | December 31, 2012 |  | June 30, 2012 |
| Deferred distributors revenue | $ | 20,200 |  |  | $ | 20,361 |  |
| Deferred cost of sales to distributors | (4,796 | ) |  | (5,042 | ) |
| Total deferred distributors revenue, net of cost of sales to distributors | $ | 15,404 |  |  | $ | 15,319 |  |

[0001078271-13-000006:notes:123]
[same as prior period, unchanged from 0001078271-12-000073:notes:128]

[0001078271-13-000006:notes:124]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2012 and January 1, 2012:

[0001078271-13-000006:notes:125]
[same as prior period, unchanged from 0001078271-12-000073:notes:130]

[0001078271-13-000006:notes:126]
[same as prior period, unchanged from 0001078271-12-000073:notes:131]

[0001078271-13-000006:notes:127]
[same as prior period, unchanged from 0001078271-12-000073:notes:132]

[0001078271-13-000006:notes:128]
[same as prior period, unchanged from 0001078271-12-000073:notes:133]

[0001078271-13-000006:notes:129]
[same as prior period, unchanged from 0001078271-12-000073:notes:134]


## us-gaap:TreasuryStockTextBlock

[0001078271-13-000006:notes:130]
Common Stock Repurchases and Retirement

[0001078271-13-000006:notes:131]
Retirement of Treasury Stock

[0001078271-13-000006:notes:132]
On September 5, 2012, the Company retired 39,631,836 shares of treasury stock. The retired shares had a carrying value of approximately $149.7 million, and the Company reduced additional paid-in capital by approximately $149.7 million upon the formal retirement of the shares. The retired shares are now included in the Company's authorized but unissued shares.

[0001078271-13-000006:notes:133]
Common Stock Repurchases

[0001078271-13-000006:notes:134]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which may be purchased over a three year period in the open market or in privately negotiated transactions. All repurchased shares will be retired and included in the Company's authorized but unissued shares. During the three months ended December 31, 2012, the Company repurchased 1.9 million shares of common stock at a total cost of $6.7 million.
