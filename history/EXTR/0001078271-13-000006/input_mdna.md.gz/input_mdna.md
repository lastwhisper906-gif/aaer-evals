# EXTR MD&A — 0001078271-13-000006


## mdna

[0001078271-13-000006:mdna:1]
[same as prior period, unchanged from 0001078271-12-000073:mdna:1]

[0001078271-13-000006:mdna:2]
[same as prior period, unchanged from 0001078271-12-000073:mdna:2]

[0001078271-13-000006:mdna:3]
[same as prior period, unchanged from 0001078271-12-000073:mdna:3]

[0001078271-13-000006:mdna:4]
[same as prior period, unchanged from 0001078271-12-000073:mdna:4]

[0001078271-13-000006:mdna:5]
We outsource the majority of our manufacturing and supply chain management operations as part of our strategy to maintain global manufacturing capabilities and to reduce our costs. We conduct quality assurance, manufacturing engineering, document control and test development in Santa Clara, California and Research Triangle Park, North Carolina. This approach enables us to reduce fixed costs and to flexibly respond to changes in market demand

[0001078271-13-000006:mdna:6]
[same as prior period, unchanged from 0001078271-12-000073:mdna:6]

[0001078271-13-000006:mdna:7]
[same as prior period, unchanged from 0001078271-12-000073:mdna:7]

[0001078271-13-000006:mdna:8]
[same as prior period, unchanged from 0001078271-12-000073:mdna:8]

[0001078271-13-000006:mdna:9]
During the second quarter of fiscal 2013, we achieved the following results:

[0001078271-13-000006:mdna:10]
| • | Net revenues of $75.6 million compared to net revenues of $82.8 million in the second quarter of fiscal 2012. |

[0001078271-13-000006:mdna:11]
| • | Product revenues of $60.3 million compared to product revenues of $68.1 million in the second quarter of fiscal 2012. |

[0001078271-13-000006:mdna:12]
| • | Service revenues of $15.3 million compared to service revenues of $14.7 million in the second quarter of fiscal 2012. |

[0001078271-13-000006:mdna:13]
| • | Total gross margin of 54% of net revenues compared to total gross margin of 56% of net revenues in the second quarter of fiscal 2012. |

[0001078271-13-000006:mdna:14]
| • | Operating loss of $3.8 million (including restructuring charges of $5.2 million) compared to operating income of $4.1 million (including restructuring charges of $0.4 million) in the second quarter of fiscal 2012. |

[0001078271-13-000006:mdna:15]
| • | Net loss of $4.2 million compared to net income of $4.1 million in the second quarter of fiscal 2012. |

[0001078271-13-000006:mdna:16]
| • | Cash flow provided by operating activities of $8.1 million compared to cash flow provided by operating activities of $4.0 million in the first six months of fiscal 2012. |

[0001078271-13-000006:mdna:17]
| • | Cash and cash equivalents, short-term investments and marketable securities increased by $42.7 million to $196.2 million from $153.5 million as of June 30, 2012, primarily due to cash provided by operating and investing activities, including the sale of buildings and land. |

[0001078271-13-000006:mdna:18]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan, and Australia. The following table presents the total net revenue geographically for the three and six months ended December 31, 2012 and January 1, 2012, respectively (dollars in thousands):

[0001078271-13-000006:mdna:19]
|  | Three Months Ended |  | Six Months Ended |
| Net Revenue | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |  | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 22,731 |  |  | $ | 26,588 |  |  | $ | (3,857 | ) |  | (14.5 | )% |  | $ | 47,935 |  |  | $ | 52,389 |  |  | $ | (4,454 | ) |  | (8.5 | )% |
| Other | 10,767 |  |  | 11,307 |  |  | (540 | ) |  | (4.8 | )% |  | 20,545 |  |  | 19,511 |  |  | 1,034 |  |  | 5.3 | % |
| Total Americas | 33,498 |  |  | 37,895 |  |  | (4,397 | ) |  | (11.6 | )% |  | 68,480 |  |  | 71,900 |  |  | (3,420 | ) |  | (4.8 | )% |
| Percentage of net revenue | 44.3 | % |  | 45.8 | % |  |  |  |  |  | 45.1 | % |  | 44.5 | % |  |  |  |  |  |  |
| EMEA | 28,700 |  |  | 31,335 |  |  | (2,635 | ) |  | (8.4 | )% |  | 57,220 |  |  | 60,815 |  |  | (3,595 | ) |  | (5.9 | )% |
| Percentage of net revenue | 38.0 | % |  | 37.8 | % |  |  |  |  |  | 37.7 | % |  | 37.6 | % |  |  |  |  |  |  |
| APAC | 13,353 |  |  | 13,582 |  |  | (229 | ) |  | (1.7 | )% |  | 25,978 |  |  | 28,991 |  |  | (3,013 | ) |  | (10.4 | )% |
| Percentage of net revenue | 17.7 | % |  | 16.4 | % |  |  |  |  |  | 17.1 | % |  | 17.9 | % |  |  |  |  |
| Total net revenues | $ | 75,551 |  |  | $ | 82,812 |  |  | $ | (7,261 | ) |  | (8.8 | )% |  | $ | 151,678 |  |  | $ | 161,706 |  |  | $ | (10,028 | ) |  | (6.2 | )% |

[0001078271-13-000006:mdna:20]
[same as prior period, unchanged from 0001078271-12-000073:mdna:20]

[0001078271-13-000006:mdna:21]
The following table presents net product and service revenue for the three and six months ended December 31, 2012 and January 1, 2012, respectively (dollars in thousands):

[0001078271-13-000006:mdna:22]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |  | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 60,259 |  |  | $ | 68,094 |  |  | $ | (7,835 | ) |  | (11.5 | )% |  | $ | 121,378 |  |  | $ | 131,307 |  |  | $ | (9,929 | ) |  | (7.6 | )% |
| Percentage of net revenue | 79.8 | % |  | 82.2 | % |  |  |  |  |  | 80.0 | % |  | 81.2 | % |  |  |  |  |
| Service | 15,292 |  |  | 14,718 |  |  | 574 |  |  | 3.9 | % |  | 30,300 |  |  | 30,399 |  |  | (99 | ) |  | (0.3 | )% |
| Percentage of net revenue | 20.2 | % |  | 17.8 | % |  |  |  |  |  | 20.0 | % |  | 18.8 | % |  |  |  |  |
| Total net revenue | $ | 75,551 |  |  | $ | 82,812 |  |  | $ | (7,261 | ) |  | (8.8 | )% |  | $ | 151,678 |  |  | $ | 161,706 |  |  | $ | (10,028 | ) |  | (6.2 | )% |

[0001078271-13-000006:mdna:23]
Product revenue decreased by $7.8 million or 11.5% in the second quarter of fiscal 2013, and decreased by $9.9 million or 7.6% in the first six months of fiscal 2013, compared to the corresponding periods of fiscal 2012 primarily due to lower sales volume in the Americas and EMEA regions.  In the first two quarters of fiscal 2013, we experienced weaker than expected demand from our public sector and enterprise customers in the U.S. and we continued to experience weak demand from our strategic customers and distributors in the EMEA region attributable to the persistent macroeconomic challenges in Europe.

[0001078271-13-000006:mdna:24]
Service revenue increased by $0.6 million, or 3.9% in the second quarter of fiscal 2013, and was flat in the first six months of fiscal 2013, compared to the corresponding periods of fiscal 2012, reflecting our continued stable levels of service contract renewals.

[0001078271-13-000006:mdna:25]
[same as prior period, unchanged from 0001078271-12-000073:mdna:25]

[0001078271-13-000006:mdna:26]
The following table presents the gross profit on product and service revenue and the gross profit percentage of product and service revenue for the three and six months ended December 31, 2012 and January 1, 2012 (in thousands):

[0001078271-13-000006:mdna:27]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |  | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 30,882 |  |  | $ | 37,273 |  |  | $ | (6,391 | ) |  | (17.1 | )% |  | $ | 61,525 |  |  | $ | 71,008 |  |  | $ | (9,483 | ) |  | (13.4 | )% |
| Percentage of product revenue | 51.3 | % |  | 54.7 | % |  |  |  |  |  | 50.7 | % |  | 54.1 | % |  |  |  |  |
| Service | 9,857 |  |  | 8,995 |  |  | 862 |  |  | 9.6 | % |  | 19,189 |  |  | 18,796 |  |  | 393 |  |  | 2.1 | % |
| Percentage of service revenue | 64.5 | % |  | 61.1 | % |  |  |  |  |  | 63.3 | % |  | 61.8 | % |  |  |  |  |
| Total gross profit | $ | 40,739 |  |  | $ | 46,268 |  |  | $ | (5,529 | ) |  | (11.9 | )% |  | $ | 80,714 |  |  | $ | 89,804 |  |  | $ | (9,090 | ) |  | (10.1 | )% |
| Percentage of net revenue | 53.9 | % |  | 55.9 | % |  |  |  |  |  | 53.2 | % |  | 55.5 | % |  |  |  |  |

[0001078271-13-000006:mdna:28]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution in Santa Clara, California, China, and Taiwan. Accordingly, a significant portion of our cost of product revenue consists of payments to our primary contract manufacturer, Alpha Networks, located in Hsinchu, Taiwan. In addition, we OEM our wireless product line from Motorola.

[0001078271-13-000006:mdna:29]
Product gross margin decreased to 51.3% from 54.7% in the second quarter of fiscal 2013, and decreased to 50.7% from 54.1% in the first six months of fiscal 2013, compared to the corresponding periods of fiscal 2012.  The decreases in product gross margin were primarily due to higher discounting and an increase in charges for excess and obsolete inventory.

[0001078271-13-000006:mdna:30]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts. Service gross margin increased to 64.5% from 61.1% in the second quarter of fiscal 2013 and increased to 63.3% from 61.8% in the first six months of fiscal 2013.  The increases in service gross margin were primarily due to lower material costs.

[0001078271-13-000006:mdna:31]
[same as prior period, unchanged from 0001078271-12-000073:mdna:32]

[0001078271-13-000006:mdna:32]
[same as prior period, unchanged from 0001078271-12-000073:mdna:33]

[0001078271-13-000006:mdna:33]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |  | December 31, 2012 |  | January 1, 2012 |  | $Change |  | %Change |
| Research and development | $ | 11,007 |  |  | $ | 11,082 |  |  | $ | (75 | ) |  | (0.7 | )% |  | $ | 21,573 |  |  | $ | 23,490 |  |  | $ | (1,917 | ) |  | (8.2 | )% |
| Sales and marketing | 22,093 |  |  | 22,734 |  |  | (641 | ) |  | (2.8 | )% |  | 44,120 |  |  | 44,855 |  |  | (735 | ) |  | (1.6 | )% |
| General and administrative | 6,644 |  |  | 7,954 |  |  | (1,310 | ) |  | (16.5 | )% |  | 12,003 |  |  | 14,224 |  |  | (2,221 | ) |  | (15.6 | )% |
| Restructuring charge, net of reversals | 5,176 |  |  | 437 |  |  | 4,739 |  |  | 1,084.4 | % |  | 5,167 |  |  | 1,392 |  |  | 3,775 |  |  | 271.2 | % |
| Litigation settlement | (421 | ) |  | — |  |  | (421 | ) |  | (100.0 | )% |  | (421 | ) |  | — |  |  | (421 | ) |  | (100.0 | )% |
| Gain on sale of campus | — |  |  | — |  |  | — |  |  | — | % |  | (11,539 | ) |  | — |  |  | (11,539 | ) |  | (100.0 | )% |
| Total operating expenses | $ | 44,499 |  |  | $ | 42,207 |  |  | $ | 2,292 |  |  | 5.4 | % |  | $ | 70,903 |  |  | $ | 83,961 |  |  | $ | (13,058 | ) |  | (15.6 | )% |
| Operating income | $ | (3,760 | ) |  | 4,061 |  |  | $ | (7,821 | ) |  | (192.6 | )% |  | $ | 9,811 |  |  | $ | 5,843 |  |  | $ | 3,968 |  |  | 67.9 | % |

[0001078271-13-000006:mdna:34]
[same as prior period, unchanged from 0001078271-12-000073:mdna:35]

[0001078271-13-000006:mdna:35]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Research and development | 14.6 | % |  | 13.4 | % |  | 14.2 | % |  | 14.5 | % |
| Sales and marketing | 29.2 | % |  | 27.5 | % |  | 29.1 | % |  | 27.7 | % |
| General and administrative | 8.8 | % |  | 9.6 | % |  | 7.9 | % |  | 8.8 | % |
| Restructuring charge, net of reversals | 6.9 | % |  | 0.5 | % |  | 3.4 | % |  | 0.9 | % |
| Litigation settlement | (0.6 | )% |  | — | % |  | (0.3 | )% |  | — | % |
| Gain on sale of campus | — | % |  | — | % |  | (7.6 | )% |  | — | % |
| Total operating expenses | 58.9 | % |  | 51.0 | % |  | 46.7 | % |  | 51.9 | % |
| Operating income | (5.0 | )% |  | 4.9 | % |  | 6.5 | % |  | 3.6 | % |

[0001078271-13-000006:mdna:36]
[same as prior period, unchanged from 0001078271-12-000073:mdna:37]

[0001078271-13-000006:mdna:37]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001078271-13-000006:mdna:38]
Research and development expenses decreased by $0.1 million, or 1% in the second quarter of fiscal 2013 and decreased by $1.9 million, or 8.2% in the first six months of fiscal 2013, compared to the corresponding periods of fiscal 2012. The decreases in research and development expenses primarily resulted from lower spending on engineering project expenses due to differences in the timing and pattern of planned engineering project spending in the first two quarters of fiscal 2013 when compared to the same period last year.

[0001078271-13-000006:mdna:39]
[same as prior period, unchanged from 0001078271-12-000073:mdna:39]

[0001078271-13-000006:mdna:40]
[same as prior period, unchanged from 0001078271-12-000073:mdna:40]

[0001078271-13-000006:mdna:41]
Sales and marketing expenses decreased by $0.6 million, or 2.8% in the second quarter of fiscal 2013 and decreased by $0.7 million, or 1.6% in the first six months of fiscal 2013, compared to the corresponding periods of fiscal 2012. The decreases in sales and marketing expenses were primarily due to decreases of $1.3 million and $1.5 million in commissions in the three and six months ended December 31, 2012, respectively, partially offset by small increases in various marketing related expenses.

[0001078271-13-000006:mdna:42]
[same as prior period, unchanged from 0001078271-12-000073:mdna:42]

[0001078271-13-000006:mdna:43]
General and administrative expenses decreased by $1.3 million, or 16.5% in the second quarter of fiscal 2013 and decreased by $2.2 million, or 15.6% in the six months of fiscal 2013, compared to the corresponding periods of fiscal 2012. The decreases in general and administrative expenses were primarily due to decreases of $1.6 million and $2.7 million in legal expenses in the three and six months ended December 31, 2012, respectively, mainly attributable to the resolution of certain legal matters.

[0001078271-13-000006:mdna:44]
Restructuring Charge, Net of Reversals

[0001078271-13-000006:mdna:45]
Restructuring charges increased by $4.7 million in the second quarter of fiscal 2013 and increased by $3.8 million in the first six months of fiscal 2013, compared to the corresponding periods of fiscal 2012.  During the second quarter of fiscal 2013, we further reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. As part of our restructuring efforts in the second quarter, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. As of December 31, 2012, we had restructuring liabilities of $5.0 million, which we anticipate paying by the end of fiscal 2013. We anticipate incurring restructuring charges of approximately $1.0 million to $2.0 million in the second half of fiscal 2013.

[0001078271-13-000006:mdna:46]
Litigation Settlement

[0001078271-13-000006:mdna:47]
During the second quarter of fiscal 2013, we recognized a litigation award of $0.4 million related to a favorable verdict on a trial.

[0001078271-13-000006:mdna:48]
[same as prior period, unchanged from 0001078271-12-000073:mdna:46]

[0001078271-13-000006:mdna:49]
During the first quarter of fiscal 2013, we completed the sale of our corporate campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million. We realized a gain of $11.5 million in connection with this transaction.

[0001078271-13-000006:mdna:50]
[same as prior period, unchanged from 0001078271-12-000073:mdna:48]

[0001078271-13-000006:mdna:51]
Other expense, net increased by approximately $0.3 million in the second quarter of fiscal 2013 and increased by $0.7 million in the first six months of fiscal 2013, compared to the corresponding periods of fiscal 2012.  The changes in other income (expense), net in the first half of fiscal 2013, as compared to the same period in fiscal 2012, was insignificant. The increases in other expense, net were primarily due to gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.

[0001078271-13-000006:mdna:52]
[same as prior period, unchanged from 0001078271-12-000073:mdna:50]

[0001078271-13-000006:mdna:53]
We recorded an income tax provision of $0.4 million and $0.2 million for the three months ended December 31, 2012 and January 1, 2012, respectively. We recorded an income tax provision of $1.0 million and $0.7 million for the six months ended December 31, 2012 and January 1, 2012, respectively. The income tax provision for the second quarter of fiscal 2013 consisted primarily of taxes on foreign income and U.S state income taxes. The income tax provision for the second quarter of fiscal 2012 consisted primarily of taxes on foreign income and U.S. state income taxes.  The income tax provisions for both quarters were calculated based on the results of operations for the three and six months ended December 31, 2012 and January 1, 2012, and may not reflect the annual effective rate.

[0001078271-13-000006:mdna:54]
We have provided a full valuation allowance for our U.S. net deferred tax assets after assessing both negative and positive evidence when measuring the need for a valuation allowance. For the current quarter, negative evidence, such as the Company's current quarter financial performance, the Company's significant restructuring in the current quarter, and the unfavorable macroeconomic climate were given more weight than our expectations of future profitability, which are inherently uncertain.  Accordingly, we believe that there is sufficient negative evidence to maintain a full valuation allowance against our U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results have sufficiently improved to support realization of our U.S. deferred tax assets.

[0001078271-13-000006:mdna:55]
[same as prior period, unchanged from 0001078271-12-000073:mdna:54]

[0001078271-13-000006:mdna:56]
[same as prior period, unchanged from 0001078271-12-000073:mdna:55]

[0001078271-13-000006:mdna:57]
Our unaudited condensed consolidated financial statements and the related notes included elsewhere in this report are prepared in accordance with accounting principles generally accepted in the United States. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. In many instances, we could have reasonably used different accounting estimates, and in other instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, actual results could differ significantly from the estimates made by our management. On an ongoing basis, we evaluate our estimates and assumptions. To the extent that there are material differences

[0001078271-13-000006:mdna:58]
between these estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected.

[0001078271-13-000006:mdna:59]
[same as prior period, unchanged from 0001078271-12-000073:mdna:57]

[0001078271-13-000006:mdna:60]
[same as prior period, unchanged from 0001078271-12-000073:mdna:59]

[0001078271-13-000006:mdna:61]
[same as prior period, unchanged from 0001078271-12-000073:mdna:60]

[0001078271-13-000006:mdna:62]
[same as prior period, unchanged from 0001078271-12-000073:mdna:61]

[0001078271-13-000006:mdna:63]
[same as prior period, unchanged from 0001078271-12-000073:mdna:62]

[0001078271-13-000006:mdna:64]
[same as prior period, unchanged from 0001078271-12-000073:mdna:63]

[0001078271-13-000006:mdna:65]
[same as prior period, unchanged from 0001078271-12-000073:mdna:64]

[0001078271-13-000006:mdna:66]
[same as prior period, unchanged from 0001078271-12-000073:mdna:58]

[0001078271-13-000006:mdna:67]
| • | Legal Contingencies |

[0001078271-13-000006:mdna:68]
| • | Restructuring Costs |

[0001078271-13-000006:mdna:69]
[same as prior period, unchanged from 0001078271-12-000073:mdna:66]

[0001078271-13-000006:mdna:70]
[same as prior period, unchanged from 0001078271-12-000073:mdna:67]

[0001078271-13-000006:mdna:71]
[same as prior period, unchanged from 0001078271-12-000073:mdna:68]

[0001078271-13-000006:mdna:72]
|  | December 31, 2012 |  | June 30, 2012 |
| Cash and cash equivalent | $ | 89,766 |  |  | $ | 54,596 |  |
| Short-term investments | 35,204 |  |  | 23,358 |  |
| Marketable securities | 71,208 |  |  | 75,561 |  |
| Total cash and investments | $ | 196,178 |  |  | $ | 153,515 |  |
| Working capital | $ | 102,982 |  |  | $ | 72,361 |  |

[0001078271-13-000006:mdna:73]
As of December 31, 2012, our principal sources of liquidity consisted of cash, cash equivalents and investments of $196.2 million and net accounts receivable of $42.6 million. Historically, our principal uses of cash have consisted of the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development, marketing of our products and purchases of property and equipment and repurchases of our common stock. We believe that our $196.2 million of cash and cash equivalents and investments at December 31, 2012 will be sufficient to fund our operating requirements, stock repurchase program, and restructuring expenses for at least the next 12 months.

[0001078271-13-000006:mdna:74]
[same as prior period, unchanged from 0001078271-12-000073:mdna:71]

[0001078271-13-000006:mdna:75]
[same as prior period, unchanged from 0001078271-12-000073:mdna:72]

[0001078271-13-000006:mdna:76]
|  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |
| Net cash provided by operating activities | $ | 8,077 |  |  | $ | 3,954 |  |
| Net cash provided by (used in) investing activities | $ | 31,181 |  |  | $ | (3,945 | ) |
| Net cash (used in) provided by financing activities | $ | (4,557 | ) |  | $ | 698 |  |
| Foreign currency effect on cash | $ | 469 |  |  | $ | (1,260 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 35,170 |  |  | $ | (553 | ) |

[0001078271-13-000006:mdna:77]
[same as prior period, unchanged from 0001078271-12-000073:mdna:74]

[0001078271-13-000006:mdna:78]
Cash flows from operations increased by $4.1 million in the first six months of fiscal 2013 compared to the corresponding period of fiscal 2012, primarily due to purposeful reduction of inventory spending to bring inventory levels in line with the anticipated near-term demand for our products.

[0001078271-13-000006:mdna:79]
[same as prior period, unchanged from 0001078271-12-000073:mdna:76]

[0001078271-13-000006:mdna:80]
Cash flow provided by investing activities in the first six months of fiscal 2013 was $31.2 million, comprised of proceeds of $42.7 million from the sale of buildings and land in Santa Clara California, proceeds of $17.8 million from the sale and maturities of investments, offset by $25.9 million used to purchase investment securities and $3.0 million used to purchase property and equipment.

[0001078271-13-000006:mdna:81]
Net Cash Used in Financing Activities

[0001078271-13-000006:mdna:82]
Cash flow used in financing activities in the first six months of fiscal 2013 was $4.6 million, comprised of $6.2 used to repurchase shares of our common stock, offset by $1.6 million of proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-13-000006:mdna:83]
[same as prior period, unchanged from 0001078271-12-000073:mdna:80]

[0001078271-13-000006:mdna:84]
The following summarizes our contractual obligations at December 31, 2012, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-13-000006:mdna:85]
|  | Total |  | Less than 1 Year |  | 1-3 years |  | 3-5 years |  | More than 5 years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Non-Cancellable Inventory purchase commitments | $ | 21,823 |  |  | $ | 21,823 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Non-cancellable operating lease obligations | 36,332 |  |  | 4,224 |  |  | 9,239 |  |  | 7,593 |  |  | 15,276 |  |
| Total contractual cash obligations | $ | 58,155 |  |  | $ | 26,047 |  |  | $ | 9,239 |  |  | $ | 7,593 |  |  | $ | 15,276 |  |

[0001078271-13-000006:mdna:86]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $21.8 million as of December 31, 2012, a decrease of $17.0 million from $38.8 million as of June 30, 2012. We expect to honor the inventory purchase commitments within the next 12 months.

[0001078271-13-000006:mdna:87]
The amounts in the table above exclude $0.5 million of income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of settlement.

[0001078271-13-000006:mdna:88]
We did not have any material commitments for capital expenditures as of December 31, 2012.

[0001078271-13-000006:mdna:89]
[same as prior period, unchanged from 0001078271-12-000073:mdna:84]

[0001078271-13-000006:mdna:90]
We did not have any off-balance sheet arrangements as of December 31, 2012.
