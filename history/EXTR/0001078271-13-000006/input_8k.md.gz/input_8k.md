# EXTR 8-K — 0001078271-13-000004 filed 2013-01-30

## item codes, every 8-K on or before 2013-01-31

- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2013-01-31

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-13-000004:8k_2_02:1]
EX-99.1
2
ex99-1q213earningsrelease.htm
PRESS RELEASE

[0001078271-13-000004:8k_2_02:2]
Ex 99-1 Q2'13 Earnings Release

[0001078271-13-000004:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-13-000004:8k_2_02:4]
| For more information, contact: |  |  |
| Extreme Networks |  |  |
| Investor Relations |  | Public Relations |
| 408/579-3030 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-13-000004:8k_2_02:5]
Extreme Networks Reports Second Fiscal Quarter 2013 Financial Results

[0001078271-13-000004:8k_2_02:6]
SANTA CLARA, Calif., January 30, 2013 /PRNewswire/ -- Extreme Networks, Inc. (Nasdaq: EXTR) today announced revenue of $75.6 million for its second quarter of fiscal 2013 ending December 31, 2012. This represents a 9.0% decrease compared to revenue of $82.8 million reported for the second quarter of fiscal 2012 and a 0.7% decrease compared to the first quarter of fiscal 2013. GAAP net loss for the second quarter was $4.2 million, or $0.04 per diluted share, a decrease year-over-year compared to GAAP net income of $4.1 million, or $0.04 per diluted share, for the second quarter of fiscal 2012. On a non-GAAP basis, net income for the second quarter of fiscal 2013 was $2.8 million, or $0.03 per diluted share, compared to non-GAAP net income for the second quarter of fiscal 2012 of $5.8 million, or $0.06 per diluted share.

[0001078271-13-000004:8k_2_02:7]
“Q2 results were in-line with our revised targets and we are encouraged by the order growth in our 10G and 40G products during the quarter,” stated Oscar Rodriguez, President and CEO of Extreme Networks.  “We continued to gain a strategic footprint in the data center space.  Our flagship Open Fabric product, the BlackDiamond® X8 switch, gained traction across geographies and market verticals and had its best quarter to date and the pipeline of opportunities continues to grow, even in a very weak global economy.”

[0001078271-13-000004:8k_2_02:8]
Fiscal Q2 2013 Financial Metrics:

[0001078271-13-000004:8k_2_02:9]
|  |  | Second Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2013 |  | 2012 |  | Change |
| Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 60.3 |  |  | $ | 68.1 |  |  | $ | (7.8 | ) |  | (11.5 | )% |
| Service |  | $ | 15.3 |  |  | $ | 14.7 |  |  | $ | 0.6 |  |  | 4.1 | % |
| Total Net Revenue |  | $ | 75.6 |  |  | $ | 82.8 |  |  | $ | (7.2 | ) |  | (8.7 | )% |
| GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 53.9 | % |  | 55.9 | % |  | (2.0 | )% |  |  |
| Operating Margin/Loss |  | (5.0 | )% |  | 4.9 | % |  | (9.9 | )% |  |  |
| Net Income |  | $ | (4.2 | ) |  | $ | 4.1 |  |  | $ | (8.3 | ) |  |  |
| Earnings per diluted share |  | $ | (0.04 | ) |  | $ | 0.04 |  |  | $ | (0.08 | ) |  |  |
| Non-GAAP |  |  |  |  |  |  |  |  |
| Gross Margin |  | 54.2 | % |  | 56.1 | % |  | (1.9 | )% |  |  |
| Operating Margin |  | 3.5 | % |  | 7.0 | % |  | (3.5 | )% |  |  |
| Net Income |  | $ | 2.8 |  |  | $ | 5.8 |  |  | $ | (3.0 | ) |  |  |
| Earnings per diluted share |  | $ | 0.03 |  |  | $ | 0.06 |  |  | $ | (0.03 | ) |  |  |
| Diluted Shares |  | 94.5 |  |  | 94.1 |  |  | 0.4 |  |  |  |

[0001078271-13-000004:8k_2_02:10]
| • | GAAP operating margin includes $1.6 million of stock based compensation, a favorable litigation settlement of $0.4 million and $5.2 million of restructuring charges impacting approximately 13% of the employee base, with a plan to transition certain functions to a lower cost region and the reduction of certain facility related costs. These items are excluded from our non-GAAP operating margin. |

[0001078271-13-000004:8k_2_02:11]
| • | Cash and investments ended the quarter at $196.2 million, as compared to $202.6 million at Q1 of fiscal 2013. Cash provided by operations was $1.0 million. During the quarter, we repurchased 1.9 million shares for $6.7 million as a portion of the previously announced three year $75 million buy-back program. |

[0001078271-13-000004:8k_2_02:12]
| • | Accounts receivable balance ending Q2 was $42.6 million, a (net) increase of $7.9 million from Q1 of fiscal 2013, with days sales outstanding (DSO) of 52, an increase of 11 days from Q1 of fiscal 2013. This increase was primarily due to receipt of customer orders and related shipments later in the quarter than normal. |

[0001078271-13-000004:8k_2_02:13]
| • | Inventory ending Q2 was $17.9 million, a (net) decrease of $4.9 million from Q1 of fiscal 2013 and represents 55 days of inventory (DOI), sequentially down 12 days from Q1 of fiscal 2013. |

[0001078271-13-000004:8k_2_02:14]
Recent Business Highlights:

[0001078271-13-000004:8k_2_02:15]
| • | CRN honored Extreme Networks with its 2012 Tech Innovator Award for Industry Leading BlackDiamond X8 Data Center Fabric Switch. |

[0001078271-13-000004:8k_2_02:16]
| • | Extreme Networks, with its open and modular ExtremeXOS® operating system, continues delivering on its SDN roadmap with support of two SDN applications: Big Switch Networks' |

[0001078271-13-000004:8k_2_02:17]
Big Tap®, providing traffic monitoring and dynamic network visibility with flow filtering, and for virtualized data center networks, Big Switch Networks BVS (Big Virtual Switch).

[0001078271-13-000004:8k_2_02:18]
| • | The Company announced a restructuring plan on January 3, 2013 to streamline its operations. A significant portion of the plan has been implemented. Once the plan is fully implemented the restructuring plan is expected to reduce approximately $7.0 million in quarterly costs. Along with strengthening our long term competitive position, the actions taken will facilitate Extreme Networks achieving its' target of a quarterly 10% non-GAAP operating income margin by the end of fiscal 2013. |

[0001078271-13-000004:8k_2_02:19]
Business Outlook:

[0001078271-13-000004:8k_2_02:20]
For its third quarter of fiscal 2013 ending March 31, 2013, the Company is targeting revenue in a range of $70 million to $75 million with GAAP and non-GAAP gross margin targeted to be between 54% and 55%. GAAP operating expenses are targeted to decrease by $8 million to $9 million and by $4 million to $5 million on a non-GAAP basis. Interest Income and Other Expense is targeted to be approximately $0.2 million with Tax Expense targeted to be approximately $0.6 million. GAAP net income is targeted at $3.0 million to $5.0 million, or $0.03 to $0.06 per diluted share. Non-GAAP net income is targeted in a range of $4.0 million to $7.0 million, or $0.04 to $0.08 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 93.5 million diluted weighted average shares. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense of approximately $1.5 million and restructuring charges of approximately $0.6 million.

[0001078271-13-000004:8k_2_02:21]
The schedules attached are an integral part of the release.

[0001078271-13-000004:8k_2_02:22]
Conference Call:

[0001078271-13-000004:8k_2_02:23]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the highlights of the second fiscal quarter 2013 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through March 15th, 2013.  The conference call may also be heard by dialing 1-877-303-9826 and International callers' dial 1-224-357-2194, Conference ID: 93884800.  Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release.

[0001078271-13-000004:8k_2_02:24]
About Extreme Networks:

[0001078271-13-000004:8k_2_02:25]
Extreme Networks is a technology leader in high-performance Ethernet switching for cloud, data center and mobile networks.  Based in Santa Clara, CA, Extreme Networks has more than 6,000 customers in over 50 countries.  Extreme Networks is a trademark or registered trademark of Extreme Networks, Inc. in the United States and/or other countries.

[0001078271-13-000004:8k_2_02:26]
For additional product and Company information, please refer to www.extremenetworks.com.

[0001078271-13-000004:8k_2_02:27]
Non-GAAP Financial Measures:

[0001078271-13-000004:8k_2_02:28]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). To supplement its consolidated financial statements presented in accordance with GAAP, the Company is also providing with this press release non-GAAP net income/(loss) and non-GAAP operating income/(loss). In preparing non-GAAP information, the Company has

[0001078271-13-000004:8k_2_02:29]
excluded, where applicable, the impact of restructuring charges, share-based compensation, litigation settlements, gain on the sale of facilities and the currency loss from closing subsidiaries.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company and the Company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the Company's operating activities with the Company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the Company's historical performance and in planning its future business activities. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's financial information presented in accordance with GAAP.  The Company has provided a non-GAAP reconciliation of the Condensed Consolidated Statement of Operations for the periods presented in this release, which are adjusted to exclude restructuring charges, share-based compensation expense and litigation settlements for these periods. These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-13-000004:8k_2_02:30]
Forward Looking Statements:

[0001078271-13-000004:8k_2_02:31]
Actual results, including with respect to the Company's financial targets and general business prospects, could differ materially due to a number of factors, including the risk that the Company may not obtain sufficient orders to achieve targeted revenues for the Company's products and services given both increasing price competition in key network switching equipment markets and the need to align the Company's cost structure to meet the Company's financial goals; the Company's effectiveness in controlling expenses, including the risk that the Company's restructuring efforts may not achieve as significant a reduction in operating expenses as anticipated, the risk that it or its distributors and other channel partners are not able to develop and expand customer bases and accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; the risk that its results will suffer if it is  unable to balance fluctuations in customer demand and capacity; risks associated with the ramp-up of production of its new products and its entry into new business channels different from those in which it has historically operated; the risk that it may experience production delays that preclude it from shipping sufficient quantities to meet customer orders or that result in higher production costs and lower margins; ongoing uncertainty in global economic conditions, infrastructure development or customer demand that could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; its ability to complete development and commercialization of products under development, such as its pipeline of new network switches and related software; its ability to lower costs; risks resulting from the concentration of business among few customers, including the risk that customers may reduce or cancel orders or fail to honor purchase commitments; the rapid development of new technology and competing products that may impair demand or render its products obsolete; the potential lack of customer acceptance for new products; and risks associated with ongoing litigation; a dependency on third parties for certain components and for the manufacturing of the Company's products.

[0001078271-13-000004:8k_2_02:32]
More information about potential factors that could affect the Company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission. Except as required

[0001078271-13-000004:8k_2_02:33]
under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-13-000004:8k_2_02:34]
EXTREME NETWORKS, INC.

[0001078271-13-000004:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-13-000004:8k_2_02:36]
(In thousands, except share and per share amounts)

[0001078271-13-000004:8k_2_02:37]
(Unaudited)

[0001078271-13-000004:8k_2_02:38]
|  | December 31, 2012 |  | June 30, 2012 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 89,766 |  |  | $ | 54,596 |  |
| Short-term investments | 35,204 |  |  | 23,358 |  |
| Accounts receivable, net of allowances of $1,689 at December 31, 2012 and $1,646 at June 30, 2012 | 42,583 |  |  | 41,166 |  |
| Inventories | 17,866 |  |  | 26,609 |  |
| Deferred income taxes | 281 |  |  | 644 |  |
| Prepaid expenses and other current assets | 5,407 |  |  | 5,655 |  |
| Assets held for sale | — |  |  | 17,081 |  |
| Total current assets | 191,107 |  |  | 169,109 |  |
| Property and equipment, net | 9,510 |  |  | 25,180 |  |
| Marketable securities | 71,208 |  |  | 75,561 |  |
| Intangible assets, net | 4,639 |  |  | 5,106 |  |
| Other assets, net | 8,939 |  |  | 9,634 |  |
| Total assets | $ | 285,403 |  |  | $ | 284,590 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 11,341 |  |  | $ | 19,437 |  |
| Accrued compensation and benefits | 11,168 |  |  | 13,409 |  |
| Restructuring liabilities | 5,032 |  |  | 463 |  |
| Accrued warranty | 2,971 |  |  | 2,871 |  |
| Deferred revenue, net | 29,441 |  |  | 31,769 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 15,404 |  |  | 15,319 |  |
| Other accrued liabilities | 12,768 |  |  | 13,480 |  |
| Total current liabilities | 88,125 |  |  | 96,748 |  |
| Deferred revenue, less current portion | 8,133 |  |  | 7,559 |  |
| Other long-term liabilities | 837 |  |  | 643 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 188,308 |  |  | 179,640 |  |
| Total liabilities and stockholders’ equity | $ | 285,403 |  |  | $ | 284,590 |  |

[0001078271-13-000004:8k_2_02:39]
EXTREME NETWORKS, INC.

[0001078271-13-000004:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF INCOME (LOSS)

[0001078271-13-000004:8k_2_02:41]
(In thousands, except per share amounts)

[0001078271-13-000004:8k_2_02:42]
(Unaudited

[0001078271-13-000004:8k_2_02:43]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 60,259 |  |  | $ | 68,094 |  |  | $ | 121,378 |  |  | $ | 131,307 |  |
| Service | 15,292 |  |  | 14,718 |  |  | 30,300 |  |  | 30,399 |  |
| Total net revenues | 75,551 |  |  | 82,812 |  |  | 151,678 |  |  | 161,706 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 29,377 |  |  | 30,821 |  |  | 59,853 |  |  | 60,299 |  |
| Service | 5,435 |  |  | 5,723 |  |  | 11,111 |  |  | 11,603 |  |
| Total cost of revenues | 34,812 |  |  | 36,544 |  |  | 70,964 |  |  | 71,902 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 30,882 |  |  | 37,273 |  |  | 61,525 |  |  | 71,008 |  |
| Service | 9,857 |  |  | 8,995 |  |  | 19,189 |  |  | 18,796 |  |
| Total gross profit | 40,739 |  |  | 46,268 |  |  | 80,714 |  |  | 89,804 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11,007 |  |  | 11,082 |  |  | 21,573 |  |  | 23,490 |  |
| Sales and marketing | 22,093 |  |  | 22,734 |  |  | 44,120 |  |  | 44,855 |  |
| General and administrative | 6,644 |  |  | 7,954 |  |  | 12,003 |  |  | 14,224 |  |
| Restructuring charge, net of reversals | 5,176 |  |  | 437 |  |  | 5,167 |  |  | 1,392 |  |
| Litigation Settlement | (421 | ) |  | — |  |  | (421 | ) |  | — |  |
| Gain on sale of facilities | — |  |  | — |  |  | (11,539 | ) |  | — |  |
| Total operating expenses | 44,499 |  |  | 42,207 |  |  | 70,903 |  |  | 83,961 |  |
| Operating (loss) income | (3,760 | ) |  | 4,061 |  |  | 9,811 |  |  | 5,843 |  |
| Interest income | 261 |  |  | 342 |  |  | 531 |  |  | 635 |  |
| Interest expense | (1 | ) |  | (38 | ) |  | (1 | ) |  | (75 | ) |
| Other income (expense), net | (300 | ) |  | (39 | ) |  | (649 | ) |  | 17 |  |
| (Loss) income before income taxes | (3,800 | ) |  | 4,326 |  |  | 9,692 |  |  | 6,420 |  |
| Provision for income taxes | 406 |  |  | 219 |  |  | 983 |  |  | 731 |  |
| Net (loss) income | $ | (4,206 | ) |  | $ | 4,107 |  |  | $ | 8,709 |  |  | $ | 5,689 |  |
| Basic and diluted net income per share: |  |  |  |  |  |  |  |
| Net (loss) income per share - basic | $ | (0.04 | ) |  | $ | 0.04 |  |  | $ | 0.09 |  |  | $ | 0.06 |  |
| Net (loss) income per share - diluted | $ | (0.04 | ) |  | $ | 0.04 |  |  | $ | 0.09 |  |  | $ | 0.06 |  |
| Shares used in per share calculation - basic | 94,501 |  |  | 93,247 |  |  | 94,619 |  |  | 92,978 |  |
| Shares used in per share calculation - diluted | 94,501 |  |  | 94,118 |  |  | 95,514 |  |  | 94,056 |  |

[0001078271-13-000004:8k_2_02:44]
EXTREME NETWORKS, INC.

[0001078271-13-000004:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-13-000004:8k_2_02:46]
(In thousands)

[0001078271-13-000004:8k_2_02:47]
(Unaudited)

[0001078271-13-000004:8k_2_02:48]
|  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |
| Net cash provided by operating activities | $ | 8,077 |  |  | $ | 3,954 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (3,026 | ) |  | (2,011 | ) |
| Purchases of investments | (25,886 | ) |  | (34,015 | ) |
| Proceeds from maturities of investments and marketable securities | 9,322 |  |  | 13,889 |  |
| Proceeds from sales of investments and marketable securities | 8,447 |  |  | 18,192 |  |
| Purchase of intangible assets | (335 | ) |  | — |  |
| Proceeds from sales of facilities | 42,659 |  |  | — |  |
| Net cash provided by (used in) investing activities | 31,181 |  |  | (3,945 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of common stock | 1,614 |  |  | 698 |  |
| Repurchases of common stock | (6,171 | ) |  | — |  |
| Net cash (used in) provided by financing activities | (4,557 | ) |  | 698 |  |
| Foreign currency effect on cash | 469 |  |  | (1,260 | ) |
| Net increase (decrease) in cash and cash equivalents | 35,170 |  |  | (553 | ) |
| Cash and cash equivalents at beginning of period | 54,596 |  |  | 49,972 |  |
| Cash and cash equivalents at end of period | $ | 89,766 |  |  | $ | 49,419 |  |

[0001078271-13-000004:8k_2_02:49]
Extreme Networks, Inc.

[0001078271-13-000004:8k_2_02:50]
Non-GAAP Measures of Financial Performance

[0001078271-13-000004:8k_2_02:51]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-13-000004:8k_2_02:52]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, litigation settlements, restructuring expenses, gains related to the sale of the Santa Clara campus and currency gains or losses related to closing of certain foreign subsidiaries.

[0001078271-13-000004:8k_2_02:53]
Non-GAAP measures presented in this press release are not in accordance with or an alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-13-000004:8k_2_02:54]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-13-000004:8k_2_02:55]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, litigation settlement gains or losses, restructuring expenses , gains related to the sale of the Santa Clara campus and. currency gains or losses related to closing of certain foreign subsidiaries.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-13-000004:8k_2_02:56]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-13-000004:8k_2_02:57]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-13-000004:8k_2_02:58]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods

[0001078271-13-000004:8k_2_02:59]
Gains related to the sale of facilities.  The one-time net gain related to the sale of the Santa Clara campus consist of the gross proceeds of the sale less the expenses directly related to the sale such as commissions, closing costs and legal fees.  Extreme Networks excludes this gain because it is a one-time event and does not believe that the gain is reflective of ongoing operations.

[0001078271-13-000004:8k_2_02:60]
Currency gains or losses related to closing of certain foreign subsidiaries.  This is related to the closing of our Japanese subsidiary.  This has accumulated over time and has historically been included in Other Comprehensive Income.   Extreme Networks excludes these gains and losses as it is a one-time event and does not believe it is reflective of ongoing operations.

[0001078271-13-000004:8k_2_02:61]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase

[0001078271-13-000004:8k_2_02:62]
stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the Company's cash balance for the period.

[0001078271-13-000004:8k_2_02:63]
EXTREME NETWORKS, INC.

[0001078271-13-000004:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-13-000004:8k_2_02:65]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-13-000004:8k_2_02:66]
(In thousands, except per share amounts)

[0001078271-13-000004:8k_2_02:67]
(Unaudited)

[0001078271-13-000004:8k_2_02:68]
| Non-GAAP Gross Margin | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Gross profit - GAAP Basis | $ | 40,739 |  |  | $ | 46,268 |  |  | $ | 80,714 |  |  | $ | 89,804 |  |
| Gross margin - GAAP Basis percentage | 53.9 | % |  | 55.9 | % |  | 53.2 | % |  | 55.5 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 206 |  |  | $ | 165 |  |  | $ | 538 |  |  | $ | 435 |  |
| Gross profit - Non-GAAP Basis | $ | 40,945 |  |  | $ | 46,433 |  |  | $ | 81,252 |  |  | $ | 90,239 |  |
| Gross margin - Non-GAAP Basis percentage | 54.2 | % |  | 56.1 | % |  | 53.6 | % |  | 55.8 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| GAAP operating (loss) income | $ | (3,760 | ) |  | $ | 4,061 |  |  | $ | 9,811 |  |  | $ | 5,843 |  |
| GAAP operating income percentage | (5.0 | )% |  | 4.9 | % |  | 6.5 | % |  | 3.6 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 1,616 |  |  | $ | 1,281 |  |  | $ | 3,784 |  |  | $ | 3,176 |  |
| Restructuring charge, net of reversals | $ | 5,176 |  |  | $ | 437 |  |  | $ | 5,167 |  |  | $ | 1,392 |  |
| Litigation Settlement | $ | (421 | ) |  | $ | — |  |  | $ | (421 | ) |  | $ | — |  |
| Gain on sale of facilities | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |  | $ | — |  |
| Total adjustments to GAAP operating income | $ | 6,371 |  |  | $ | 1,718 |  |  | $ | (3,009 | ) |  | $ | 4,568 |  |
| Non-GAAP operating income | $ | 2,611 |  |  | $ | 5,779 |  |  | $ | 6,802 |  |  | $ | 10,411 |  |
| Non-GAAP operating income percentage | 3.5 | % |  | 7.0 | % |  | 4.5 | % |  | 6.4 | % |
| Non-GAAP Net Income | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| GAAP net (loss) income | $ | (4,206 | ) |  | $ | 4,107 |  |  | $ | 8,709 |  |  | $ | 5,689 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 1,616 |  |  | $ | 1,281 |  |  | $ | 3,784 |  |  | $ | 3,176 |  |
| Restructuring charge, net of reversals | $ | 5,176 |  |  | $ | 437 |  |  | $ | 5,167 |  |  | $ | 1,392 |  |
| Litigation Settlement | $ | (421 | ) |  | $ | — |  |  | $ | (421 | ) |  | $ | — |  |
| Gain on sale of facilities | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |  | $ | — |  |
| Currency loss from closing of a foreign subsidiary | $ | 616 |  |  | $ | — |  |  | $ | 465 |  |  | $ | — |  |
| Total adjustments to GAAP net income | $ | 6,987 |  |  | $ | 1,718 |  |  | $ | (2,544 | ) |  | $ | 4,568 |  |
| Non-GAAP net income | $ | 2,781 |  |  | $ | 5,825 |  |  | $ | 6,165 |  |  | $ | 10,257 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.03 |  |  | $ | 0.06 |  |  | $ | 0.06 |  |  | $ | 0.11 |  |
| Shares used in diluted net income per share calculation | 94,501 |  |  | 94,118 |  |  | 95,514 |  |  | 94,056 |  |

[0001078271-13-000004:8k_2_02:69]
| Free Cash Flow | Three Months Ended |  | Six Months Ended |
|  | December 31, 2012 |  | January 1, 2012 |  | December 31, 2012 |  | January 1, 2012 |
| Cash flow provided by operations | $ | 1,025 |  |  | $ | 7,899 |  |  | $ | 8,077 |  |  | $ | 3,954 |  |
| Add: PP&E CapEx spending | $ | (1,464 | ) |  | $ | (1,263 | ) |  | $ | (3,026 | ) |  | $ | (2,011 | ) |
| Total free cash flow | $ | (439 | ) |  | $ | 6,636 |  |  | $ | 5,051 |  |  | $ | 1,943 |  |
