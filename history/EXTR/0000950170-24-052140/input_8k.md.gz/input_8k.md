# EXTR 8-K — 0000950170-24-050891 filed 2024-05-01

## item codes, every 8-K on or before 2024-05-02

- 2024-05-01 0000950170-24-050891 — 2.02, 9.01
- 2024-01-31 0000950170-24-009144 — 2.02, 9.01
- 2024-01-08 0001193125-24-004497 — 5.02
- 2024-01-08 0000950170-24-002958 — 2.02, 9.01
- 2023-11-09 0000950170-23-062050 — 5.03, 5.07, 9.01
- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2024-05-02

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-24-050891:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0000950170-24-050891:8k_2_02:2]
EX-99.1

[0000950170-24-050891:8k_2_02:3]
Exhibit 99.1

[0000950170-24-050891:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0000950170-24-050891:8k_2_02:5]
Extreme Networks Reports Third Quarter Fiscal Year 2024 Financial Results

[0000950170-24-050891:8k_2_02:6]
Financial Results in-line With Previous Outlook

[0000950170-24-050891:8k_2_02:7]
38% Growth in SaaS ARR

[0000950170-24-050891:8k_2_02:8]
Morrisville, NC, May 1, 2024 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its third quarter ended March 31, 2024.

[0000950170-24-050891:8k_2_02:9]
"Extreme’s focus on the intersection of networking, security, and AI is creating a compelling value proposition that's resonating with customers and driving significant traction in our business. Net new logos grew double-digits this quarter, particularly in the Americas. Our SaaS ARR grew again by 38%, as we continue to deliver on our promise of creating flexibility and simplicity with One Network, One Cloud. Our competitive positioning in the market has never been stronger, as we believe key competitors are either distracted by portfolio rationalization and integration or have lost their focus on networking. Meanwhile, Extreme remains solely focused on our customers' networking needs," said Ed Meyercord, President and Chief Executive Officer.

[0000950170-24-050891:8k_2_02:10]
"Consistent with our expectations, channel inventory was significantly reduced during the quarter. Heading into the fourth quarter, we expect sequential growth in revenue, but note that the networking industry is still impacted by customers working through their prior purchases. Our expanded go to market opportunities around the integration of networking, security, and AI, give us confidence that we are positioned for a return to growth in FY25," concluded Meyercord.

[0000950170-24-050891:8k_2_02:11]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, "During the quarter we took actions to improve our operating expense profile that will once again lead to double-digit operating margins and strong cash flow. Heading into the fourth quarter, we expect to return to solid profitability and cash flow generation."

[0000950170-24-050891:8k_2_02:12]
Fiscal Third Quarter Results:

[0000950170-24-050891:8k_2_02:13]
•
Revenue $211.0 million, down 36.5% year-over-year

[0000950170-24-050891:8k_2_02:14]
•
SaaS ARR $162.0 million, up 38.0% year-over-year

[0000950170-24-050891:8k_2_02:15]
•
GAAP diluted EPS ($0.50), compared to $0.17 in the prior year quarter

[0000950170-24-050891:8k_2_02:16]
•
Non-GAAP diluted EPS ($0.19), compared to $0.29 in the prior year quarter

[0000950170-24-050891:8k_2_02:17]
•
GAAP gross margin 56.8% compared to 57.7% in the prior year quarter

[0000950170-24-050891:8k_2_02:18]
•
Non-GAAP gross margin 57.6% compared to 59.1% in the prior year quarter

[0000950170-24-050891:8k_2_02:19]
•
GAAP operating margin (29.6%) compared to 8.9% in the prior year quarter

[0000950170-24-050891:8k_2_02:20]
•
Non-GAAP operating margin (12.2%) compared to 15.6% in the prior year quarter

[0000950170-24-050891:8k_2_02:21]
Liquidity:

[0000950170-24-050891:8k_2_02:22]
•
Q3 ending cash balance was $151.0 million, a decrease of $70.4 million from the end of Q2 2024 and an increase of $52.0 million from the end of Q3 in the prior year.

[0000950170-24-050891:8k_2_02:23]
•
Q3 net debt was $41.5 million, a decrease of $67.9 million from net cash of $26.4 million at the end of Q2 2024 and an increase of $7.5 million from net debt of $34.0 million at the end of Q3 in the prior year.

[0000950170-24-050891:8k_2_02:24]
Recent Key Highlights:

[0000950170-24-050891:8k_2_02:25]
•
At Extreme Connect 2024, the company made a number of exciting announcements including:

[0000950170-24-050891:8k_2_02:26]
o
Extreme Labs: a hub for research and innovation in networking. The company provided the first tech preview from Labs: Extreme AI Expert: a Generative AI solution that creates a futuristic way to design, optimize and deploy networks.

[0000950170-24-050891:8k_2_02:27]
o
That the Company is the first vendor with significant outdoor Wi-Fi 6E deployments to receive a standard power grant, allowing customers to leverage faster speeds, increased range of coverage and expanded capacity for outdoor connectivity.

[0000950170-24-050891:8k_2_02:28]
•
During Extreme Connect 2024, Extreme recognized Kroger, Texas Tech University, the San Francisco Giants and Korean Air as 2024 X-Factor Customer Award winners. These awards recognize Extreme’s most innovative customers; nominees were evaluated and selected by Extreme Networks employees based on three areas of measure: innovation, demonstrated value, and unique problem-solving.

[0000950170-24-050891:8k_2_02:29]
•
Extreme was named as a Leader by Gartner, Inc. for the sixth consecutive year in the Gartner Magic Quadrant for Enterprise Wired and Wireless Local Access Network (LAN) Infrastructure*. Of the 12 companies in the Magic Quadrant, Extreme Networks was named a Leader for both vision and execution. Extreme continues to innovate at the intersection of AI, networking and security.

[0000950170-24-050891:8k_2_02:30]
•
Borussia Dortmund, one of the largest football clubs in Germany, will deploy Wi-Fi 6E-ready network solutions from Extreme, as well as network Fabric and ExtremeAnalytics, to modernize experiences throughout team facilities and the stadium and set the foundation for future technology like in-seat concessions ordering and in-stadium AR/VR.

[0000950170-24-050891:8k_2_02:31]
•
Bangor University has improved its wireless network across its Wales campus by deploying Extreme’s Wi-Fi access points to scale and secure high-bandwidth connectivity, more easily handle the ever-increasing load of media-rich content and devices and allow students to access educational systems and stream videos without delay from anywhere on campus.

[0000950170-24-050891:8k_2_02:32]
•
Washington University in St. Louis, one of the country’s top universities, selected Extreme to modernize its network infrastructure and create a strategic foundation for delivering innovative and secure technology-based learning.  Extreme’s fabric solutions will help the university create a simple, scalable and secure network across the campus.

[0000950170-24-050891:8k_2_02:33]
*Gartner, Magic Quadrant for Enterprise Wired and Wireless LAN Infrastructure, March 2024  GARTNER is a registered trademark and service mark of Gartner, Inc. and/or its affiliates in the U.S. and internationally, and MAGIC QUADRANT is a registered trademark of Gartner, Inc. and/or its affiliates and are used herein with permission. All rights reserved.

[0000950170-24-050891:8k_2_02:34]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0000950170-24-050891:8k_2_02:35]
The Gartner content described herein, (the "Gartner Content") represent(s) research opinion or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and are not representations of fact. Gartner Content speaks as of its original publication date (and not as of the date of this Current Report on Form 8-K) and the opinions expressed in the Gartner Content are subject to change without notice.

[0000950170-24-050891:8k_2_02:36]
Fiscal Q3 2024 Financial Metrics:

[0000950170-24-050891:8k_2_02:37]
(in millions, except percentages and per share information)

[0000950170-24-050891:8k_2_02:38]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | Change |  |
| Product |  | $ | 106.4 |  |  | $ | 241.1 |  |  | $ | (134.7 | ) |
| Subscription and support* |  |  | 104.6 |  |  |  | 91.4 |  |  |  | 13.2 |  |
| Total net revenue |  | $ | 211.0 |  |  | $ | 332.5 |  |  | $ | (121.5 | ) |
| Gross margin |  |  | 56.8 | % |  |  | 57.7 | % |  |  | (0.9 | )% |
| Operating margin |  |  | (29.6 | )% |  |  | 8.9 | % |  |  | (38.5 | )% |
| Net income (loss) |  | $ | (64.4 | ) |  | $ | 22.1 |  |  | $ | (86.5 | ) |
| Net income (loss) per diluted share |  | $ | (0.50 | ) |  | $ | 0.17 |  |  | $ | (0.67 | ) |

[0000950170-24-050891:8k_2_02:39]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | Change |  |
| Product |  | $ | 106.4 |  |  | $ | 241.1 |  |  | $ | (134.7 | ) |
| Subscription and support* |  |  | 104.6 |  |  |  | 91.4 |  |  |  | 13.2 |  |
| Total net revenue |  | $ | 211.0 |  |  | $ | 332.5 |  |  | $ | (121.5 | ) |
| Gross margin |  |  | 57.6 | % |  |  | 59.1 | % |  |  | (1.5 | )% |
| Operating margin |  |  | (12.2 | )% |  |  | 15.6 | % |  |  | (27.8 | )% |
| Net income (loss) |  | $ | (24.8 | ) |  | $ | 38.8 |  |  | $ | (63.6 | ) |
| Net income (loss) per diluted share |  | $ | (0.19 | ) |  | $ | 0.29 |  |  | $ | (0.48 | ) |

[0000950170-24-050891:8k_2_02:40]
* Prior to fiscal 2024, subscription and support revenue was referred to as service and subscription revenue, however, the composition of subscription and support revenue has not been modified.

[0000950170-24-050891:8k_2_02:41]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by (used in) operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in millions):

[0000950170-24-050891:8k_2_02:42]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Cash flow provided by (used in) operations | $ | (69.9 | ) |  | $ | 48.2 |  |  | $ | 40.0 |  |  | $ | 168.5 |  |
| Less: Property and equipment capital expenditures |  | (3.7 | ) |  |  | (2.4 | ) |  |  | (13.6 | ) |  |  | (8.6 | ) |
| Total free cash flow | $ | (73.6 | ) |  | $ | 45.8 |  |  | $ | 26.4 |  |  | $ | 159.9 |  |

[0000950170-24-050891:8k_2_02:43]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of XIQ and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue or deferred revenue that are accounted for under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0000950170-24-050891:8k_2_02:44]
Gross Debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0000950170-24-050891:8k_2_02:45]
Net Cash (Debt) is defined as cash and cash equivalents minus gross debt, as shown in the table below (in millions):

[0000950170-24-050891:8k_2_02:46]
| Cash and cash equivalents |  |  | Gross debt |  |  | Net cash (debt) |  |
| $ | 151.0 |  |  | $ | 192.5 |  |  | $ | (41.5 | ) |

[0000950170-24-050891:8k_2_02:47]
Business Outlook:

[0000950170-24-050891:8k_2_02:48]
For its fourth quarter and full year of fiscal 2024, ending June 30, 2024, the Company is targeting:

[0000950170-24-050891:8k_2_02:49]
| (in millions, except percentages and per share information) | GAAP |  | Non-GAAP |
| FQ4'24 Guidance |  |  |  |
| Total net revenue | $250.0 - $260.0 |  | $250.0 - $260.0 |
| Gross margin | 60.9% - 62.9% |  | 61.6% - 63.6% |
| Operating margin | (3.8%) - (0.9%) |  | 9.0% - 11.5% |
| Earnings per diluted share | ($0.11) - ($0.05) |  | $0.11 - $0.15 |
| Shares outstanding used in calculating diluted EPS | 130.1 |  | 131.1 |
| FY'24 Guidance |  |  |  |
| Total net revenue | $1,110.5 - $1,120.5 |  | $1,110.5 - $1,120.5 |
| Gross margin | 60.2% - 60.6% |  | 60.9% -61.4% |
| Operating margin | (2.4%) - (1.7%) |  | 9.3% - 9.9% |
| Earnings per diluted share | ($0.35) - ($0.30) |  | $0.51 - $0.55 |
| Shares outstanding used in calculating diluted EPS | 129.3 |  | 131.6 |

[0000950170-24-050891:8k_2_02:50]
The following table shows the GAAP to non-GAAP reconciliation for Q4 FY'24 and full year FY’24 guidance:

[0000950170-24-050891:8k_2_02:51]
|  | FQ4'24 |  | FY'24 |
|  | Gross Margin |  | Operating Margin |  | Earnings per Share |  | Gross Margin |  | Operating Margin |  | Earnings per Share |
| GAAP | 60.9% - 62.9% |  | (3.8%) - (0.9%) |  | ($0.11) - ($0.05) |  | 60.2% - 60.6% |  | (2.4%) - (1.7%) |  | ($0.35) - ($0.30) |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation | 0.4% |  | 7.5% - 7.8% |  | 0.15 |  | 0.5% |  | 7.0% |  | 0.60 |
| Amortization of product intangibles | 0.3% |  | 0.3% |  | 0.00 |  | 0.3% |  | 0.3% |  | 0.02 |
| Amortization of non-product intangibles | — |  | 0.2% |  | 0.00 |  | — |  | 0.2% |  | 0.01 |
| Restructuring and related charges | — |  | 2.7% - 2.8% |  | 0.05 |  | — |  | 3.0% |  | 0.26 |
| Litigation charges | — |  | 0.9% |  | 0.02 |  | — |  | 0.7% |  | 0.06 |
| System transition cost | — |  | 0.8% |  | 0.02 |  | — |  | 0.4% |  | 0.03 |
| Tax adjustment | — |  | — |  | (0.02) - (0.04) |  | — |  | — |  | (0.12) - (0.13) |
| Non-GAAP | 61.6% - 63.6% |  | 9.0% - 11.5% |  | $0.11-$0.15 |  | 60.9% - 61.4% |  | 9.3% - 9.9% |  | $0.51-$0.55 |

[0000950170-24-050891:8k_2_02:52]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0000950170-24-050891:8k_2_02:53]
Conference Call:

[0000950170-24-050891:8k_2_02:54]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the third quarter results of fiscal 2024 as well as the business outlook for the fourth quarter of fiscal 2024 ending June 30, 2024, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Extreme Networks Q3'24 Earnings Registration and you will be provided with dial in details. If you would like to participate in the Q&A, please register here:  Registration Link [Q&A]. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0000950170-24-050891:8k_2_02:55]
About Extreme:

[0000950170-24-050891:8k_2_02:56]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0000950170-24-050891:8k_2_02:57]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0000950170-24-050891:8k_2_02:58]
Non-GAAP Financial Measures:

[0000950170-24-050891:8k_2_02:59]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income (loss),

[0000950170-24-050891:8k_2_02:60]
non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges, and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0000950170-24-050891:8k_2_02:61]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0000950170-24-050891:8k_2_02:62]
Forward-Looking Statements:

[0000950170-24-050891:8k_2_02:63]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2023, Quarterly Report on Form 10-Q for the quarters ended September 30, 2023 and December 31, 2024 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0000950170-24-050891:8k_2_02:64]
###

[0000950170-24-050891:8k_2_02:65]
EXTREME NETWORKS, INC.

[0000950170-24-050891:8k_2_02:66]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-24-050891:8k_2_02:67]
(In thousands, except per share amounts)

[0000950170-24-050891:8k_2_02:68]
(Unaudited)

[0000950170-24-050891:8k_2_02:69]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 151,007 |  |  | $ | 234,826 |  |
| Accounts receivable, net |  |  | 94,438 |  |  |  | 182,045 |  |
| Inventories |  |  | 185,357 |  |  |  | 89,024 |  |
| Prepaid expenses and other current assets |  |  | 75,182 |  |  |  | 70,263 |  |
| Total current assets |  |  | 505,984 |  |  |  | 576,158 |  |
| Property and equipment, net |  |  | 47,254 |  |  |  | 46,448 |  |
| Operating lease right-of-use assets, net |  |  | 44,236 |  |  |  | 34,739 |  |
| Intangible assets, net |  |  | 11,789 |  |  |  | 16,063 |  |
| Goodwill |  |  | 394,177 |  |  |  | 394,755 |  |
| Other assets |  |  | 82,028 |  |  |  | 73,544 |  |
| Total assets |  | $ | 1,085,468 |  |  | $ | 1,141,707 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $674 and $674, respectively |  | $ | 9,326 |  |  | $ | 34,326 |  |
| Accounts payable |  |  | 81,483 |  |  |  | 99,724 |  |
| Accrued compensation and benefits |  |  | 44,053 |  |  |  | 71,367 |  |
| Accrued warranty |  |  | 11,067 |  |  |  | 12,322 |  |
| Current portion, operating lease liabilities |  |  | 9,989 |  |  |  | 10,847 |  |
| Current portion, deferred revenue |  |  | 299,580 |  |  |  | 282,475 |  |
| Other accrued liabilities |  |  | 72,804 |  |  |  | 64,440 |  |
| Total current liabilities |  |  | 528,302 |  |  |  | 575,501 |  |
| Deferred revenue, less current portion |  |  | 258,731 |  |  |  | 219,024 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $1,903 and $2,409, respectively |  |  | 180,597 |  |  |  | 187,591 |  |
| Operating lease liabilities, less current portion |  |  | 42,248 |  |  |  | 31,845 |  |
| Deferred income taxes |  |  | 7,476 |  |  |  | 7,747 |  |
| Other long-term liabilities |  |  | 3,152 |  |  |  | 3,247 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 148,105 and 143,629 shares issued, respectively; 129,886 and 127,775 shares outstanding, respectively |  |  | 148 |  |  |  | 144 |  |
| Additional paid-in-capital |  |  | 1,204,885 |  |  |  | 1,173,744 |  |
| Accumulated other comprehensive loss |  |  | (14,511 | ) |  |  | (13,192 | ) |
| Accumulated deficit |  |  | (887,759 | ) |  |  | (855,998 | ) |
| Treasury stock at cost, 18,219 and 15,854 shares, respectively |  |  | (237,801 | ) |  |  | (187,946 | ) |
| Total stockholders’ equity |  |  | 64,962 |  |  |  | 116,752 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,085,468 |  |  | $ | 1,141,707 |  |

[0000950170-24-050891:8k_2_02:70]
EXTREME NETWORKS, INC.

[0000950170-24-050891:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-24-050891:8k_2_02:72]
(In thousands, except per share amounts)

[0000950170-24-050891:8k_2_02:73]
(Unaudited)

[0000950170-24-050891:8k_2_02:74]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 106,442 |  |  | $ | 241,058 |  |  | $ | 546,536 |  |  | $ | 670,779 |  |
| Subscription and support |  |  | 104,594 |  |  |  | 91,449 |  |  |  | 314,014 |  |  |  | 277,765 |  |
| Total net revenues |  |  | 211,036 |  |  |  | 332,507 |  |  |  | 860,550 |  |  |  | 948,544 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 60,837 |  |  |  | 108,915 |  |  |  | 250,866 |  |  |  | 312,265 |  |
| Subscription and support |  |  | 30,298 |  |  |  | 31,654 |  |  |  | 93,477 |  |  |  | 95,978 |  |
| Total cost of revenues |  |  | 91,135 |  |  |  | 140,569 |  |  |  | 344,343 |  |  |  | 408,243 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 45,605 |  |  |  | 132,143 |  |  |  | 295,670 |  |  |  | 358,514 |  |
| Subscription and support |  |  | 74,296 |  |  |  | 59,795 |  |  |  | 220,537 |  |  |  | 181,787 |  |
| Total gross profit |  |  | 119,901 |  |  |  | 191,938 |  |  |  | 516,207 |  |  |  | 540,301 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 54,517 |  |  |  | 54,837 |  |  |  | 165,366 |  |  |  | 158,444 |  |
| Sales and marketing |  |  | 87,708 |  |  |  | 83,962 |  |  |  | 264,782 |  |  |  | 242,882 |  |
| General and administrative |  |  | 25,213 |  |  |  | 21,683 |  |  |  | 74,470 |  |  |  | 64,315 |  |
| Acquisition and integration costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 390 |  |
| Restructuring and related charges |  |  | 14,421 |  |  |  | 1,363 |  |  |  | 26,312 |  |  |  | 2,320 |  |
| Amortization of intangible assets |  |  | 511 |  |  |  | 510 |  |  |  | 1,531 |  |  |  | 1,537 |  |
| Total operating expenses |  |  | 182,370 |  |  |  | 162,355 |  |  |  | 532,461 |  |  |  | 469,888 |  |
| Operating income (loss) |  |  | (62,469 | ) |  |  | 29,583 |  |  |  | (16,254 | ) |  |  | 70,413 |  |
| Interest income |  |  | 1,239 |  |  |  | 774 |  |  |  | 3,895 |  |  |  | 2,055 |  |
| Interest expense |  |  | (4,179 | ) |  |  | (3,946 | ) |  |  | (12,766 | ) |  |  | (11,656 | ) |
| Other income (expense), net |  |  | 361 |  |  |  | (367 | ) |  |  | 373 |  |  |  | 142 |  |
| Income (loss) before income taxes |  |  | (65,048 | ) |  |  | 26,044 |  |  |  | (24,752 | ) |  |  | 60,954 |  |
| Provision for (benefit from) income taxes |  |  | (623 | ) |  |  | 3,913 |  |  |  | 7,009 |  |  |  | 8,307 |  |
| Net income (loss) |  | $ | (64,425 | ) |  | $ | 22,131 |  |  | $ | (31,761 | ) |  | $ | 52,647 |  |
| Basic and diluted income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | (0.50 | ) |  | $ | 0.17 |  |  | $ | (0.25 | ) |  | $ | 0.41 |  |
| Net income (loss) per share – diluted |  | $ | (0.50 | ) |  | $ | 0.17 |  |  | $ | (0.25 | ) |  | $ | 0.39 |  |
| Shares used in per share calculation – basic |  |  | 129,299 |  |  |  | 128,816 |  |  |  | 129,021 |  |  |  | 129,864 |  |
| Shares used in per share calculation – diluted |  |  | 129,299 |  |  |  | 133,025 |  |  |  | 129,021 |  |  |  | 133,716 |  |

[0000950170-24-050891:8k_2_02:75]
EXTREME NETWORKS, INC.

[0000950170-24-050891:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-24-050891:8k_2_02:77]
(In thousands)

[0000950170-24-050891:8k_2_02:78]
(Unaudited)

[0000950170-24-050891:8k_2_02:79]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income (loss) |  | $ | (31,761 | ) |  | $ | 52,647 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 13,821 |  |  |  | 15,014 |  |
| Amortization of intangible assets |  |  | 4,192 |  |  |  | 11,415 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 8,834 |  |  |  | 9,274 |  |
| Provision for credit losses |  |  | 1,770 |  |  |  | 245 |  |
| Share-based compensation |  |  | 58,709 |  |  |  | 46,561 |  |
| Deferred income taxes |  |  | (153 | ) |  |  | 338 |  |
| Non-cash interest expense |  |  | 795 |  |  |  | 756 |  |
| Other |  |  | (3,225 | ) |  |  | (6,148 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 85,837 |  |  |  | 25,216 |  |
| Inventories |  |  | (97,589 | ) |  |  | (21,989 | ) |
| Prepaid expenses and other assets |  |  | (13,855 | ) |  |  | 2,226 |  |
| Accounts payable |  |  | (17,340 | ) |  |  | 12,570 |  |
| Accrued compensation and benefits |  |  | (27,252 | ) |  |  | (6,158 | ) |
| Operating lease liabilities |  |  | (8,780 | ) |  |  | (11,172 | ) |
| Deferred revenue |  |  | 59,301 |  |  |  | 46,502 |  |
| Other current and long-term liabilities |  |  | 6,693 |  |  |  | (8,778 | ) |
| Net cash provided by operating activities |  |  | 39,997 |  |  |  | 168,519 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures |  |  | (13,632 | ) |  |  | (8,634 | ) |
| Net cash used in investing activities |  |  | (13,632 | ) |  |  | (8,634 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Payments on revolving facility |  |  | (25,000 | ) |  |  | — |  |
| Payments on debt obligations |  |  | (7,500 | ) |  |  | (71,625 | ) |
| Repurchase of common stock |  |  | (49,855 | ) |  |  | (74,807 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (27,564 | ) |  |  | (1,685 | ) |
| Deferred payments on an acquisition |  |  | — |  |  |  | (3,000 | ) |
| Net cash used in financing activities |  |  | (109,919 | ) |  |  | (151,117 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (265 | ) |  |  | (294 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (83,819 | ) |  |  | 8,474 |  |
| Cash and cash equivalents at beginning of period |  |  | 234,826 |  |  |  | 194,522 |  |
| Cash and cash equivalents at end of period |  | $ | 151,007 |  |  | $ | 202,996 |  |

[0000950170-24-050891:8k_2_02:80]
Extreme Networks, Inc.

[0000950170-24-050891:8k_2_02:81]
Non-GAAP Measures of Financial Performance

[0000950170-24-050891:8k_2_02:82]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income (loss), non-GAAP net income (loss), non-GAAP net income (loss) per diluted share, net cash (debt) and non-GAAP free cash flow.

[0000950170-24-050891:8k_2_02:83]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0000950170-24-050891:8k_2_02:84]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0000950170-24-050891:8k_2_02:85]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0000950170-24-050891:8k_2_02:86]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0000950170-24-050891:8k_2_02:87]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0000950170-24-050891:8k_2_02:88]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0000950170-24-050891:8k_2_02:89]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, and legal and professional fees related to the acquisition of Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0000950170-24-050891:8k_2_02:90]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0000950170-24-050891:8k_2_02:91]
Restructuring charges. Restructuring charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0000950170-24-050891:8k_2_02:92]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution and our configure, price, quote solution. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency making it difficult to contribute to a meaningful evaluation of our operating performance.

[0000950170-24-050891:8k_2_02:93]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for a non-recurring pending litigation.

[0000950170-24-050891:8k_2_02:94]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 26.5%.

[0000950170-24-050891:8k_2_02:95]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0000950170-24-050891:8k_2_02:96]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which performs research and development activities, as well as the Company’s Irish trading subsidiaries.

[0000950170-24-050891:8k_2_02:97]
EXTREME NETWORKS, INC.

[0000950170-24-050891:8k_2_02:98]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-24-050891:8k_2_02:99]
GAAP TO NON-GAAP RECONCILIATION

[0000950170-24-050891:8k_2_02:100]
(In thousands, except percentages and per share amounts)

[0000950170-24-050891:8k_2_02:101]
(Unaudited)

[0000950170-24-050891:8k_2_02:102]
| Revenues | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Revenues – GAAP | $ | 211,036 |  |  | $ | 332,507 |  |  | $ | 860,550 |  |  | $ | 948,544 |  |

[0000950170-24-050891:8k_2_02:103]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Gross profit – GAAP | $ | 119,901 |  |  | $ | 191,938 |  |  | $ | 516,207 |  |  | $ | 540,301 |  |
| Gross margin – GAAP percentage |  | 56.8 | % |  |  | 57.7 | % |  |  | 60.0 | % |  |  | 57.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 405 |  |  |  | 492 |  |  |  | 1,352 |  |  |  | 1,365 |  |
| Share-based compensation expense, Subscription and support |  | 679 |  |  |  | 930 |  |  |  | 2,294 |  |  |  | 2,568 |  |
| Amortization of intangibles, Product |  | 599 |  |  |  | 2,220 |  |  |  | 2,336 |  |  |  | 7,381 |  |
| Amortization of intangibles, Subscription and support |  | — |  |  |  | 815 |  |  |  | 272 |  |  |  | 2,444 |  |
| Total adjustments to GAAP gross profit | $ | 1,683 |  |  | $ | 4,457 |  |  | $ | 6,254 |  |  | $ | 13,758 |  |
| Gross profit – non-GAAP | $ | 121,584 |  |  | $ | 196,395 |  |  | $ | 522,461 |  |  | $ | 554,059 |  |
| Gross margin – non-GAAP percentage |  | 57.6 | % |  |  | 59.1 | % |  |  | 60.7 | % |  |  | 58.4 | % |

[0000950170-24-050891:8k_2_02:104]
| Non-GAAP Operating Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| GAAP operating income (loss) | $ | (62,469 | ) |  | $ | 29,583 |  |  | $ | (16,254 | ) |  | $ | 70,413 |  |
| GAAP operating margin |  | (29.6 | )% |  |  | 8.9 | % |  |  | (1.9 | )% |  |  | 7.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,084 |  |  |  | 1,422 |  |  |  | 3,646 |  |  |  | 3,933 |  |
| Share-based compensation expense, R&D |  | 4,226 |  |  |  | 3,883 |  |  |  | 13,038 |  |  |  | 10,935 |  |
| Share-based compensation expense, S&M |  | 5,683 |  |  |  | 5,777 |  |  |  | 20,206 |  |  |  | 16,326 |  |
| Share-based compensation expense, G&A |  | 6,840 |  |  |  | 4,294 |  |  |  | 21,819 |  |  |  | 15,367 |  |
| Acquisition and integration costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 390 |  |
| Restructuring and related charges |  | 14,421 |  |  |  | 1,363 |  |  |  | 26,312 |  |  |  | 2,320 |  |
| Litigation charges |  | 2,605 |  |  |  | 1,680 |  |  |  | 5,418 |  |  |  | 4,003 |  |
| System transition costs |  | 847 |  |  |  | 490 |  |  |  | 2,446 |  |  |  | 490 |  |
| Amortization of intangibles |  | 1,110 |  |  |  | 3,545 |  |  |  | 4,139 |  |  |  | 11,362 |  |
| Total adjustments to GAAP operating income (loss) |  | 36,816 |  |  |  | 22,454 |  |  |  | 97,024 |  |  |  | 65,126 |  |
| Non-GAAP operating income (loss) | $ | (25,653 | ) |  | $ | 52,037 |  |  | $ | 80,770 |  |  | $ | 135,539 |  |
| Non-GAAP operating margin |  | (12.2 | )% |  |  | 15.6 | % |  |  | 9.4 | % |  |  | 14.3 | % |

[0000950170-24-050891:8k_2_02:105]
| Non-GAAP Net Income (Loss) | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| GAAP net income (loss) | $ | (64,425 | ) |  | $ | 22,131 |  |  | $ | (31,761 | ) |  | $ | 52,647 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 17,833 |  |  |  | 15,376 |  |  |  | 58,709 |  |  |  | 46,561 |  |
| Acquisition and integration costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 390 |  |
| Restructuring and related charges |  | 14,421 |  |  |  | 1,363 |  |  |  | 26,312 |  |  |  | 2,320 |  |
| Litigation charges |  | 2,605 |  |  |  | 1,680 |  |  |  | 5,418 |  |  |  | 4,003 |  |
| System transition costs |  | 847 |  |  |  | 490 |  |  |  | 2,446 |  |  |  | 490 |  |
| Amortization of intangibles |  | 1,110 |  |  |  | 3,545 |  |  |  | 4,139 |  |  |  | 11,362 |  |
| Tax effect of non-GAAP adjustments |  | 2,812 |  |  |  | (5,737 | ) |  |  | (12,045 | ) |  |  | (15,359 | ) |
| Total adjustments to GAAP net income (loss) | $ | 39,628 |  |  | $ | 16,717 |  |  | $ | 84,979 |  |  | $ | 49,767 |  |
| Non-GAAP net income (loss) | $ | (24,797 | ) |  | $ | 38,848 |  |  | $ | 53,218 |  |  | $ | 102,414 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income (loss) per share – diluted | $ | (0.50 | ) |  | $ | 0.17 |  |  | $ | (0.24 | ) |  | $ | 0.39 |  |
| Non-GAAP net income (loss) per share – diluted | $ | (0.19 | ) |  | $ | 0.29 |  |  | $ | 0.40 |  |  | $ | 0.77 |  |
| Shares used in net income (loss) per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 129,299 |  |  |  | 128,816 |  |  |  | 129,021 |  |  |  | 129,864 |  |
| Potentially dilutive equity awards |  | — |  |  |  | 4,209 |  |  |  | 3,209 |  |  |  | 3,852 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 129,299 |  |  |  | 133,025 |  |  |  | 132,230 |  |  |  | 133,716 |  |
