# EXTR MD&A — 0000950170-24-052140


## mdna

[0000950170-24-052140:mdna:1]
[same as prior period, unchanged from 0000950170-24-009819:mdna:1]

[0000950170-24-052140:mdna:2]
[same as prior period, unchanged from 0000950170-24-009819:mdna:2]

[0000950170-24-052140:mdna:3]
[same as prior period, unchanged from 0000950170-24-009819:mdna:3]

[0000950170-24-052140:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of cloud networking solutions and industry leading services and support. Extreme designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment, software and cloud-based network management solutions. The Company’s cloud solution is a single platform that offers unified network management of wireless access points, switches, and SD-WAN. It leverages machine learning, Artificial Intelligence for Information Technology Operations ("AIOps") and analytics to help customers deliver secure connectivity at the edge of the network, speed cloud deployments, and uncover actionable insights to save time, lower costs and streamline operations.

[0000950170-24-052140:mdna:5]
Extreme has been pushing the boundaries of networking technology since 1996, driven by a higher purpose of helping our customers connect beyond the network. Extreme’s cloud networking technologies provide flexibility and scalability in deployment, management, and licensing of networks globally. Our global footprint provides service to over 50,000 customers including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0000950170-24-052140:mdna:6]
[same as prior period, unchanged from 0000950170-24-009819:mdna:6]

[0000950170-24-052140:mdna:7]
[same as prior period, unchanged from 0000950170-24-009819:mdna:7]

[0000950170-24-052140:mdna:8]
[same as prior period, unchanged from 0000950170-24-009819:mdna:8]

[0000950170-24-052140:mdna:9]
[same as prior period, unchanged from 0000950170-24-009819:mdna:9]

[0000950170-24-052140:mdna:10]
[same as prior period, unchanged from 0000950170-24-009819:mdna:10]

[0000950170-24-052140:mdna:11]
[same as prior period, unchanged from 0000950170-24-009819:mdna:11]

[0000950170-24-052140:mdna:12]
[same as prior period, unchanged from 0000950170-24-009819:mdna:12]

[0000950170-24-052140:mdna:13]
[same as prior period, unchanged from 0000950170-24-009819:mdna:13]

[0000950170-24-052140:mdna:14]
[same as prior period, unchanged from 0000950170-24-009819:mdna:14]

[0000950170-24-052140:mdna:15]
[same as prior period, unchanged from 0000950170-24-009819:mdna:15]

[0000950170-24-052140:mdna:16]
[same as prior period, unchanged from 0000950170-24-009819:mdna:16]

[0000950170-24-052140:mdna:17]
[same as prior period, unchanged from 0000950170-24-009819:mdna:17]

[0000950170-24-052140:mdna:18]
[same as prior period, unchanged from 0000950170-24-009819:mdna:18]

[0000950170-24-052140:mdna:19]
[same as prior period, unchanged from 0000950170-24-009819:mdna:19]

[0000950170-24-052140:mdna:20]
[same as prior period, unchanged from 0000950170-24-009819:mdna:20]

[0000950170-24-052140:mdna:21]
[same as prior period, unchanged from 0000950170-24-009819:mdna:21]

[0000950170-24-052140:mdna:22]
[same as prior period, unchanged from 0000950170-24-009819:mdna:22]

[0000950170-24-052140:mdna:23]
[same as prior period, unchanged from 0000950170-24-009819:mdna:23]

[0000950170-24-052140:mdna:24]
[same as prior period, unchanged from 0000950170-24-009819:mdna:24]

[0000950170-24-052140:mdna:25]
•
Creating effortless networking solutions that allow all of us to advance. We believe that progress is achieved when we connect—allowing us to learn, understand, create, and grow. We make connecting simple and easy with effortless networking experiences that enable all of us to advance how we live, work, and share.

[0000950170-24-052140:mdna:26]
•
Provide a differentiated end-to-end cloud architecture. Cloud networking is estimated to be a $8 billion segment of the networking market comprised of cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at 14% annually over the next five years, according to data from the 650 Group. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the Internet of Things (“IoT”) edge to the enterprise data center. Key characteristics of our cloud architecture include:

[0000950170-24-052140:mdna:27]
[same as prior period, unchanged from 0000950170-24-009819:mdna:27]

[0000950170-24-052140:mdna:28]
[same as prior period, unchanged from 0000950170-24-009819:mdna:28]

[0000950170-24-052140:mdna:29]
[same as prior period, unchanged from 0000950170-24-009819:mdna:29]

[0000950170-24-052140:mdna:30]
[same as prior period, unchanged from 0000950170-24-009819:mdna:30]

[0000950170-24-052140:mdna:31]
o
Extreme Cloud IQ cloud platform conforms to ISO/ IEC 27017, is certified by DQS to ISO/IEC 27001 and ISO/IEC 27701 set forth by the International Standards Organization (“ISO”), and is CSA STAR certified.

[0000950170-24-052140:mdna:32]
[same as prior period, unchanged from 0000950170-24-009819:mdna:32]

[0000950170-24-052140:mdna:33]
•
Highest value of cloud management subscriptions. ExtremeCloud IQ Pilot provides our customers with three key applications enabling organizations to eliminate overlays.

[0000950170-24-052140:mdna:34]
[same as prior period, unchanged from 0000950170-24-009819:mdna:34]

[0000950170-24-052140:mdna:35]
[same as prior period, unchanged from 0000950170-24-009819:mdna:35]

[0000950170-24-052140:mdna:36]
[same as prior period, unchanged from 0000950170-24-009819:mdna:36]

[0000950170-24-052140:mdna:37]
•
Offers universal platforms for enterprise class switching and wireless infrastructure. Extreme offers universal platforms which support multiple deployment use cases, providing flexibility and investment protection.

[0000950170-24-052140:mdna:38]
[same as prior period, unchanged from 0000950170-24-009819:mdna:39]

[0000950170-24-052140:mdna:39]
[same as prior period, unchanged from 0000950170-24-009819:mdna:40]

[0000950170-24-052140:mdna:40]
[same as prior period, unchanged from 0000950170-24-009819:mdna:41]

[0000950170-24-052140:mdna:41]
[same as prior period, unchanged from 0000950170-24-009819:mdna:42]

[0000950170-24-052140:mdna:42]
[same as prior period, unchanged from 0000950170-24-009819:mdna:43]

[0000950170-24-052140:mdna:43]
[same as prior period, unchanged from 0000950170-24-009819:mdna:44]

[0000950170-24-052140:mdna:44]
•
Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience, and our operating systems- the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud.

[0000950170-24-052140:mdna:45]
•
Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice, and every business must deal with scale, density, and BYOD challenges. Wired and wireless networks are changing as the explosion of mobile and IoT devices increase the demand for high-performance, transparent, and always-on wired to wireless services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 6 solutions to 6 GHz Wi-Fi (Wi-Fi 6E and Wi-Fi 7), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest 6 GHz indoor and outdoor wireless portfolio, providing intelligence and security for wired/wireless networks by leveraging our cloud architecture, end-to-end fabric services, Universal Zero Trust Network Access, and AIOps management platform with Explainable ML insights.

[0000950170-24-052140:mdna:46]
[same as prior period, unchanged from 0000950170-24-009819:mdna:47]

[0000950170-24-052140:mdna:47]
•
Expand market penetration by targeting high-growth market segments. Within the campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our data center approach leverages our product portfolio to address the needs of public and private cloud data center providers. We believe that the cloud networking compound annual growth rate will continue to outpace the compound annual growth rate for on-premises managed networking. Our focus is on expanding our technology foothold in the critical cloud networking segment to accelerate not only cloud management adoption, but also subscription-based licensing consumption.

[0000950170-24-052140:mdna:48]
[same as prior period, unchanged from 0000950170-24-009819:mdna:49]

[0000950170-24-052140:mdna:49]
[same as prior period, unchanged from 0000950170-24-009819:mdna:50]

[0000950170-24-052140:mdna:50]
[same as prior period, unchanged from 0000950170-24-009819:mdna:51]

[0000950170-24-052140:mdna:51]
[same as prior period, unchanged from 0000950170-24-009819:mdna:52]

[0000950170-24-052140:mdna:52]
During the third quarter of fiscal 2024, we achieved the following results:

[0000950170-24-052140:mdna:53]
•
Net revenues of $211.0 million compared to $332.5 million in the third quarter of fiscal 2023.

[0000950170-24-052140:mdna:54]
•
Product revenues of $106.4 million compared to $241.1 million in the third quarter of fiscal 2023.

[0000950170-24-052140:mdna:55]
•
Subscription and support revenues of $104.6 million compared to $91.4 million in the third quarter of fiscal 2023.

[0000950170-24-052140:mdna:56]
•
Total gross margin of 56.8% of net revenues compared to 57.7% of net revenues in the third quarter of fiscal 2023.

[0000950170-24-052140:mdna:57]
•
Operating loss of $62.5 million compared to operating income of $29.6 million in the third quarter of fiscal 2023.

[0000950170-24-052140:mdna:58]
•
Net loss of $64.4 million compared to net income of $22.1 million in the third quarter of fiscal 2023.

[0000950170-24-052140:mdna:59]
During the first nine months of fiscal 2024, we reflected the following results:

[0000950170-24-052140:mdna:60]
•
Cash flows provided by operating activities of $40.0 million compared to $168.5 million in the nine months ended March 31, 2023.

[0000950170-24-052140:mdna:61]
•
Cash and cash equivalents of $151.0 million as of March 31, 2024 compared to $234.8 million as of June 30, 2023.

[0000950170-24-052140:mdna:62]
[same as prior period, unchanged from 0000950170-24-009819:mdna:63]

[0000950170-24-052140:mdna:63]
[same as prior period, unchanged from 0000950170-24-009819:mdna:64]

[0000950170-24-052140:mdna:64]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2024 |  | March 31,2023 |  | $Change |  | %Change |  | March 31,2024 |  | March 31,2023 |  | $Change |  | %Change |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $106,442 |  | $241,058 |  | $(134,616) |  | (55.8)% |  | $546,536 |  | $670,779 |  | $(124,243) |  | (18.5)% |
| Percentage of net revenues |  | 50.4% |  | 72.5% |  |  |  |  |  | 63.5% |  | 70.7% |  |  |  |  |
| Subscription and support |  | 104,594 |  | 91,449 |  | 13,145 |  | 14.4 % |  | 314,014 |  | 277,765 |  | 36,249 |  | 13.1 % |
| Percentage of net revenues |  | 49.6% |  | 27.5% |  |  |  |  |  | 36.5% |  | 29.3% |  |  |  |  |
| Total net revenues |  | $211,036 |  | $332,507 |  | $(121,471) |  | (36.5)% |  | $860,550 |  | $948,544 |  | $(87,994) |  | (9.3)% |

[0000950170-24-052140:mdna:65]
We generate product revenues primarily from sales of our networking equipment. We derive subscription and support revenues primarily from sales of our subscription and support offerings which includes SaaS offerings, maintenance contracts, professional services and training for its products. Prior to fiscal 2024, we referred to subscription and support revenue as “service and subscription revenue”; however, the composition of subscription and support revenue has not been modified.

[0000950170-24-052140:mdna:66]
Product revenues decreased $134.6 million or 55.8% for the three months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. Product revenues decreased $124.2 million or 18.5% for the nine months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The decreases in product revenues were primarily driven by lower bookings and shipments as well as elongated sales cycles in the channel caused by current macroeconomic conditions.

[0000950170-24-052140:mdna:67]
Subscription and support revenues increased $13.1 million or 14.4% for the three months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. Subscription and support revenues increased $36.2 million or 13.1% for the nine months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The increases in subscription and support revenues were primarily due to the continued growth in our subscription business.

[0000950170-24-052140:mdna:68]
[same as prior period, unchanged from 0000950170-24-009819:mdna:69]

[0000950170-24-052140:mdna:69]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2024 |  | March 31,2023 |  | $Change |  | %Change |  | March 31,2024 |  | March 31,2023 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $45,605 |  | $132,143 |  | $(86,538) |  | (65.5)% |  | $295,670 |  | $358,514 |  | $(62,844) |  | (17.5)% |
| Percentage of product revenues |  | 42.8% |  | 54.8% |  |  |  |  |  | 54.1% |  | 53.4% |  |  |  |  |
| Subscription and support |  | 74,296 |  | 59,795 |  | 14,501 |  | 24.3 % |  | 220,537 |  | 181,787 |  | 38,750 |  | 21.3 % |
| Percentage of subscription and support revenues |  | 71.0% |  | 65.4% |  |  |  |  |  | 70.2% |  | 65.4% |  |  |  |  |
| Total gross profit |  | $119,901 |  | $191,938 |  | $(72,037) |  | (37.5)% |  | $516,207 |  | $540,301 |  | $(24,094) |  | (4.5)% |
| Percentage of net revenues |  | 56.8% |  | 57.7% |  |  |  |  |  | 60.0% |  | 57.0% |  |  |  |  |

[0000950170-24-052140:mdna:70]
Product gross profit decreased $86.5 million or 65.5% for the three months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. Product gross profit decreased $62.8 million or 17.5% for the nine months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The decreases in product gross profit were primarily due to lower product revenues and higher reserves for excess and obsolete inventory, partially offset by lower intangible asset amortization due to certain intangible assets being fully amortized, favorable purchase price variance, lower distribution costs due to easing of supply chain constraints and lower warranty reserves.

[0000950170-24-052140:mdna:71]
Subscription and support gross profit increased $14.5 million or 24.3% for the three months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. Subscription and support gross profit increased $38.8 million or 21.3% for the nine months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The increases in subscription and support gross profits were primarily due to increased subscription and support revenues as well as lower personnel costs.

[0000950170-24-052140:mdna:72]
[same as prior period, unchanged from 0000950170-24-009819:mdna:74]

[0000950170-24-052140:mdna:73]
[same as prior period, unchanged from 0000950170-24-009819:mdna:75]

[0000950170-24-052140:mdna:74]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2024 |  | March 31,2023 |  | $Change |  | %Change |  | March 31,2024 |  | March 31,2023 |  | $Change |  | %Change |
| Research and development |  | $54,517 |  | $54,837 |  | $(320) |  | (0.6)% |  | $165,366 |  | $158,444 |  | $6,922 |  | 4.4 % |
| Sales and marketing |  | 87,708 |  | 83,962 |  | 3,746 |  | 4.5 % |  | 264,782 |  | 242,882 |  | 21,900 |  | 9.0 % |
| General and administrative |  | 25,213 |  | 21,683 |  | 3,530 |  | 16.3 % |  | 74,470 |  | 64,315 |  | 10,155 |  | 15.8 % |
| Acquisition and integration costs |  | — |  | — |  | — |  | — |  | — |  | 390 |  | (390) |  | (100.0)% |
| Restructuring and related charges |  | 14,421 |  | 1,363 |  | 13,058 |  | 958.0 % |  | 26,312 |  | 2,320 |  | 23,992 |  | 1,034.1 % |
| Amortization of intangible assets |  | 511 |  | 510 |  | 1 |  | 0.2 % |  | 1,531 |  | 1,537 |  | (6) |  | (0.4)% |
| Total operating expenses |  | $182,370 |  | $162,355 |  | $20,015 |  | 12.3 % |  | $532,461 |  | $469,888 |  | $62,573 |  | 13.3 % |

[0000950170-24-052140:mdna:75]
[same as prior period, unchanged from 0000950170-24-009819:mdna:77]

[0000950170-24-052140:mdna:76]
[same as prior period, unchanged from 0000950170-24-009819:mdna:78]

[0000950170-24-052140:mdna:77]
Research and development expenses decreased by $0.3 million or 0.6% for the three months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The decrease in research and development expenses was primarily due to a $1.1 million decrease in engineering project costs, partially offset by a $0.8 million increase in personnel costs primarily related to benefits and share-based compensation costs.

[0000950170-24-052140:mdna:78]
Research and development expenses increased by $6.9 million or 4.4% for the nine months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The increase in research and development expenses was primarily due to a $5.2 million increase in personnel related costs due to higher salaries and benefits costs and higher share-based compensation expense and a $4.4 million increase in contractor costs and professional service fees, partially offset by a $1.9 million decrease in engineering project costs, a $0.5 million decrease in information technology and facility related expenses and a $0.3 million decrease in other expenses primarily due to lower recruiting fees.

[0000950170-24-052140:mdna:79]
[same as prior period, unchanged from 0000950170-24-009819:mdna:81]

[0000950170-24-052140:mdna:80]
[same as prior period, unchanged from 0000950170-24-009819:mdna:82]

[0000950170-24-052140:mdna:81]
Sales and marketing expenses increased by $3.7 million or 4.5% for the three months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The increase in sales and marketing expenses was primarily due to a $1.4 million increase in personnel cost primarily due to higher commissions and higher benefit costs, a $1.6 million increase in sales promotions and marketing related expenses and a $1.1 million increase in professional fees, partially offset by a $0.4 million decrease in other expenses primarily due to lower travel expenses.

[0000950170-24-052140:mdna:82]
Sales and marketing expenses increased by $21.9 million or 9.0% for the nine months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The increase in sales and marketing expenses was primarily due to a $14.2 million increase in personnel costs due to higher salaries and benefits costs and higher share-based compensation expense, a $6.3 million increase in sales promotions and marketing related expenses, and a $1.4 million increase in professional fees.

[0000950170-24-052140:mdna:83]
[same as prior period, unchanged from 0000950170-24-009819:mdna:85]

[0000950170-24-052140:mdna:84]
[same as prior period, unchanged from 0000950170-24-009819:mdna:86]

[0000950170-24-052140:mdna:85]
General and administrative expenses increased by $3.5 million or 16.3% for the three months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The increase in general and administrative expenses was primarily due to a $1.7 million increase in personnel costs primarily for share-based compensation, a $1.5 million increase in bad debt provision, a $0.7 million increase in professional fees, and a $0.5 million increase in software licensing costs, partially offset by a $0.9 million decrease in equipment related costs primarily due to lower depreciation expense.

[0000950170-24-052140:mdna:86]
General and administrative expenses increased by $10.2 million or 15.8% for the nine months ended March 31, 2024 as compared to the corresponding period in fiscal 2023. The increase in general and administrative expenses was primarily due to a $4.4 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $4.4 million increase in professional fees including increases in legal costs related to litigation and preliminary costs associated with the transition of our customer relationship management solution and our configure, price, quote solution, a $1.5 million increase in bad debt provision and a $1.4 million increase in software licensing costs, partially offset by a $1.7 million decrease in equipment related costs primarily due to lower depreciation expense.

[0000950170-24-052140:mdna:87]
[same as prior period, unchanged from 0000950170-24-009819:mdna:89]

[0000950170-24-052140:mdna:88]
During the three months ended March 31, 2024 and 2023, we did not incur any acquisition and integration costs.

[0000950170-24-052140:mdna:89]
During the nine months ended March 31, 2024, we did not incur any acquisition and integration costs. During the nine months ended March 31, 2023, we incurred acquisition and integration costs of $0.4 million, which primarily consisted of professional fees and certain compensation charges related to the acquisition of Ipanema Tech SAS.

[0000950170-24-052140:mdna:90]
[same as prior period, unchanged from 0000950170-24-009819:mdna:92]

[0000950170-24-052140:mdna:91]
For the three and nine months ended March 31, 2024, we recorded restructuring and related charges of $14.4 million and $26.3 million, which primarily consisted of severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q1 2024 Plan”, “Q2 2024 Plan”, and "Q3 2024 Plan", each as described in Note 13, Restructuring and Related Charges, in Notes to the Condensed Consolidated Financial Statements included elsewhere in this Report.

[0000950170-24-052140:mdna:92]
For the three and nine months ended March 31, 2023, we recorded restructuring charges of $1.4 million and $2.3 million, respectively, which primarily consisted of facility-related charges related to our previously impaired facilities and $0.8 million in charges associated with the "2023 Plan" to transform our business and facilities infrastructure, as described in Note 13, Restructuring and Related Charges, in Notes to the Condensed Consolidated Financial Statements included elsewhere in this Report.

[0000950170-24-052140:mdna:93]
[same as prior period, unchanged from 0000950170-24-009819:mdna:95]

[0000950170-24-052140:mdna:94]
During the three months ended March 31, 2024 and 2023, we recorded $0.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-24-052140:mdna:95]
During the nine months ended March 31, 2024 and 2023, we recorded $1.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-24-052140:mdna:96]
[same as prior period, unchanged from 0000950170-24-009819:mdna:98]

[0000950170-24-052140:mdna:97]
During the three months ended March 31, 2024 and 2023, we recorded $1.2 million and $0.8 million, respectively, in interest income. The increase in interest income was primarily due to higher interest earned on our cash balance due to rising interest rates.

[0000950170-24-052140:mdna:98]
During the nine months ended March 31, 2024 and 2023, we recorded $3.9 million and $2.1 million, respectively, in interest income. The increase in interest income was primarily due to higher interest earned on our cash balance due to rising interest rates.

[0000950170-24-052140:mdna:99]
[same as prior period, unchanged from 0000950170-24-009819:mdna:101]

[0000950170-24-052140:mdna:100]
During the three months ended March 31, 2024 and 2023, we recorded $4.2 million and $3.9 million, respectively, in interest expense. The increase in interest expense was primarily due to higher average rates under the new 2023 Credit Agreement.

[0000950170-24-052140:mdna:101]
During the nine months ended March 31, 2024 and 2023, we recorded $12.8 million and $11.7 million, respectively, in interest expense. The increase in interest expense was primarily due to higher average rates under the new 2023 Credit Agreement.

[0000950170-24-052140:mdna:102]
[same as prior period, unchanged from 0000950170-24-009819:mdna:104]

[0000950170-24-052140:mdna:103]
During the three months ended March 31, 2024 and 2023, we recorded other income, net of $0.4 million and other expense, net of $0.4 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-24-052140:mdna:104]
During the nine months ended March 31, 2024 and 2023, we recorded other income, net of $0.4 million and $0.1 million, respectively. The other income, net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-24-052140:mdna:105]
[same as prior period, unchanged from 0000950170-24-009819:mdna:107]

[0000950170-24-052140:mdna:106]
For the three months ended March 31, 2024 and 2023, we recorded income tax benefit of $0.6 million and income tax provision of $3.9 million, respectively.

[0000950170-24-052140:mdna:107]
For the nine months ended March 31, 2024 and 2023, we recorded income tax provision of $7.0 million and $8.3 million, respectively.

[0000950170-24-052140:mdna:108]
The income tax provision (benefit) for the three and nine months ended March 31, 2024 and 2023 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications System. In addition, the income tax provision (benefit) for the three and nine months ended March 31, 2024 includes U.S. federal income benefit of $1.6 million, fully reversing the previously recorded U.S. federal income tax expense during the first two quarters of the year, as well as a $0.3 million income tax benefit resulting from establishment of an indefinite lived deferred tax asset for nondeductible interest expense, offsetting the deferred tax liability related to amortizable goodwill.

[0000950170-24-052140:mdna:109]
[same as prior period, unchanged from 0000950170-24-009819:mdna:111]

[0000950170-24-052140:mdna:110]
[same as prior period, unchanged from 0000950170-24-009819:mdna:112]

[0000950170-24-052140:mdna:111]
[same as prior period, unchanged from 0000950170-24-009819:mdna:113]

[0000950170-24-052140:mdna:112]
[same as prior period, unchanged from 0000950170-24-009819:mdna:114]

[0000950170-24-052140:mdna:113]
[same as prior period, unchanged from 0000950170-24-009819:mdna:115]

[0000950170-24-052140:mdna:114]
[same as prior period, unchanged from 0000950170-24-009819:mdna:116]

[0000950170-24-052140:mdna:115]
[same as prior period, unchanged from 0000950170-24-009819:mdna:117]

[0000950170-24-052140:mdna:116]
[same as prior period, unchanged from 0000950170-24-009819:mdna:118]

[0000950170-24-052140:mdna:117]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Cash and cash equivalents |  | $ | 151,007 |  |  | $ | 234,826 |  |

[0000950170-24-052140:mdna:118]
As of March 31, 2024, our principal sources of liquidity consisted of cash and cash equivalents of $151.0 million, accounts receivable, net of $94.4 million, and available borrowings under our five-year 2023 Revolving Facility of $135.5 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest and share repurchases. We believe that our $151.0 million of cash and cash equivalents at March 31, 2024, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0000950170-24-052140:mdna:119]
On May 18, 2022, our Board of Directors (the “Board”) authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022 (as amended, the "2022 Repurchase Program"). A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The 2022 Repurchase Program does not obligate us to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended March 31, 2024, the Company did not repurchase any shares of its common stock. During the nine months ended March 31, 2024, the Company repurchased a total of 2,365,220 shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. As of March 31, 2024, the Company had $50.3 million available under the 2022 Repurchase Program.

[0000950170-24-052140:mdna:120]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among Extreme, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use the proceeds of the loans for working capital and general corporate purposes. On June 22, 2023, we borrowed $25.0 million against the 2023 Revolving Facility, which was subsequently paid off on July 7, 2023.

[0000950170-24-052140:mdna:121]
[same as prior period, unchanged from 0000950170-24-009819:mdna:123]

[0000950170-24-052140:mdna:122]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-24-052140:mdna:123]
During the three and nine months ended March 31, 2024, we were in compliance with all the original terms and financial covenants under the 2023 Credit Agreement.

[0000950170-24-052140:mdna:124]
[same as prior period, unchanged from 0000950170-24-009819:mdna:126]

[0000950170-24-052140:mdna:125]
[same as prior period, unchanged from 0000950170-24-009819:mdna:127]

[0000950170-24-052140:mdna:126]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
| Net cash provided by operating activities |  | $ | 39,997 |  |  | $ | 168,519 |  |
| Net cash used in investing activities |  |  | (13,632 | ) |  |  | (8,634 | ) |
| Net cash used in financing activities |  |  | (109,919 | ) |  |  | (151,117 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (265 | ) |  |  | (294 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (83,819 | ) |  | $ | 8,474 |  |

[0000950170-24-052140:mdna:127]
[same as prior period, unchanged from 0000950170-24-009819:mdna:129]

[0000950170-24-052140:mdna:128]
Cash flows provided by operations in the nine months ended March 31, 2024 were $40.0 million, including our net loss of $31.8 million and non-cash expenses of $84.7 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest. Other sources of cash for the period included a decrease in accounts receivable, and increases in deferred revenue and other current and long-term liabilities. This was partially offset by increases in inventories and prepaid expenses and other assets as well as decreases in accounts payable, operating lease liabilities and accrued compensation and benefits.

[0000950170-24-052140:mdna:129]
Cash flows provided by operations in the nine months ended March 31, 2023 were $168.5 million, including our net income of $52.6 million and non-cash expenses of $77.5 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included a decrease in accounts receivable and increases in accounts payable and deferred revenue. This was partially offset by increases in inventories and decreases in accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0000950170-24-052140:mdna:130]
[same as prior period, unchanged from 0000950170-24-009819:mdna:132]

[0000950170-24-052140:mdna:131]
Cash flows used in investing activities in the nine months ended March 31, 2024 were $13.6 million for the purchases of property and equipment.

[0000950170-24-052140:mdna:132]
Cash flows used in investing activities in the nine months ended March 31, 2023 were $8.6 million for the purchases of property and equipment.

[0000950170-24-052140:mdna:133]
[same as prior period, unchanged from 0000950170-24-009819:mdna:135]

[0000950170-24-052140:mdna:134]
Cash flows used in financing activities in the nine months ended March 31, 2024 were $109.9 million primarily due to payment of $27.6 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan ("ESPP") and exercise of stock options, share repurchase of $49.9 million under the 2022 Repurchase Program, a $25.0 million payment against our revolving facility, and debt repayments of $7.5 million.

[0000950170-24-052140:mdna:135]
Cash flows used in financing activities in the nine months ended March 31, 2023 were $151.1 million primarily due to debt repayments of $71.6 million, share repurchase of $74.8 million under the 2022 Repurchase Program, $3.0 million for deferred payments on acquisitions and $1.7 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP.

[0000950170-24-052140:mdna:136]
[same as prior period, unchanged from 0000950170-24-009819:mdna:138]

[0000950170-24-052140:mdna:137]
Foreign currency effect on cash and cash equivalents decreased in the nine months ended March 31, 2024, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the Euro.

[0000950170-24-052140:mdna:138]
[same as prior period, unchanged from 0000950170-24-009819:mdna:140]

[0000950170-24-052140:mdna:139]
As of March 31, 2024, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0000950170-24-052140:mdna:140]
Our debt obligations relate to amounts owed under our 2023 Credit Agreement. As of March 31, 2024, we had $192.5 million of debt outstanding which is payable on quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0000950170-24-052140:mdna:141]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of March 31, 2024, we had non-cancelable commitments to purchase $51.5 million of inventory. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0000950170-24-052140:mdna:142]
We have contractual commitments to our suppliers which represent commitments for future services. As of March 31, 2024, we had contractual commitments of $28.0 million that are due through our fiscal year 2027.

[0000950170-24-052140:mdna:143]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of March 31, 2024, the value of our obligations under operating leases was $62.6 million.

[0000950170-24-052140:mdna:144]
[same as prior period, unchanged from 0000950170-24-009819:mdna:146]

[0000950170-24-052140:mdna:145]
We did not have any material commitments for capital expenditures as of March 31, 2024.

[0000950170-24-052140:mdna:146]
[same as prior period, unchanged from 0000950170-24-009819:mdna:148]

[0000950170-24-052140:mdna:147]
We did not have any off-balance sheet arrangements as of March 31, 2024.
