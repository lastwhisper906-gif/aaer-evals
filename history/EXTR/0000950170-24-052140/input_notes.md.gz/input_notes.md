# EXTR notes — 0000950170-24-052140


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-24-052140:notes:1]
[same as prior period, unchanged from 0000950170-24-009819:notes:1]

[0000950170-24-052140:notes:2]
[same as prior period, unchanged from 0000950170-24-009819:notes:2]

[0000950170-24-052140:notes:3]
[same as prior period, unchanged from 0000950170-24-009819:notes:3]

[0000950170-24-052140:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2024. The results of operations for the three and nine months ended March 31, 2024 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.

[0000950170-24-052140:notes:5]
[same as prior period, unchanged from 0000950170-24-009819:notes:5]

[0000950170-24-052140:notes:6]
[same as prior period, unchanged from 0000950170-24-009819:notes:6]

[0000950170-24-052140:notes:7]
[same as prior period, unchanged from 0000950170-24-009819:notes:7]

[0000950170-24-052140:notes:8]
[same as prior period, unchanged from 0000950170-24-009819:notes:8]

[0000950170-24-052140:notes:9]
[same as prior period, unchanged from 0000950170-24-009819:notes:9]

[0000950170-24-052140:notes:10]
[same as prior period, unchanged from 0000950170-24-009819:notes:10]

[0000950170-24-052140:notes:11]
[same as prior period, unchanged from 0000950170-24-009819:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-24-052140:notes:12]
[same as prior period, unchanged from 0000950170-24-009819:notes:12]

[0000950170-24-052140:notes:13]
[same as prior period, unchanged from 0000950170-24-009819:notes:13]

[0000950170-24-052140:notes:14]
Recently Adopted Accounting Pronouncements

[0000950170-24-052140:notes:15]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures.

[0000950170-24-052140:notes:16]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000950170-24-052140:notes:17]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.

[0000950170-24-052140:notes:18]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-052140:notes:19]
[same as prior period, unchanged from 0000950170-24-009819:notes:19]

[0000950170-24-052140:notes:20]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0000950170-24-052140:notes:21]
[same as prior period, unchanged from 0000950170-24-009819:notes:21]

[0000950170-24-052140:notes:22]
[same as prior period, unchanged from 0000950170-24-009819:notes:22]

[0000950170-24-052140:notes:23]
[same as prior period, unchanged from 0000950170-24-009819:notes:23]

[0000950170-24-052140:notes:24]
On March 31, 2024, the Company had $558.3 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 18% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 42% in fiscal 2025, and 40% of the balance thereafter.

[0000950170-24-052140:notes:25]
[same as prior period, unchanged from 0000950170-24-009819:notes:25]

[0000950170-24-052140:notes:26]
Revenue recognized for the three months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $95.9 million and $81.0 million, respectively. Revenue recognized for the nine months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $230.8 million and $193.7 million, respectively.

[0000950170-24-052140:notes:27]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.7 million and $20.0 million at March 31, 2024 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three and a half years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2024 and 2023 was $2.8 million and $2.3 million, respectively. Amortization recognized during the nine months ended March 31, 2024 and 2023 was $8.0 million and $6.7 million, respectively.

[0000950170-24-052140:notes:28]
[same as prior period, unchanged from 0000950170-24-009819:notes:28]

[0000950170-24-052140:notes:29]
[same as prior period, unchanged from 0000950170-24-009819:notes:29]

[0000950170-24-052140:notes:30]
[same as prior period, unchanged from 0000950170-24-009819:notes:30]

[0000950170-24-052140:notes:31]
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 52,543 |  | $ | 71,539 |  | $ | 124,082 |  |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |
| Other |  |  | 5,934 |  |  | 4,357 |  |  | 10,291 |  |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |
| Total Americas |  |  | 58,477 |  |  | 75,896 |  |  | 134,373 |  |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |
| EMEA |  |  | 18,313 |  |  | 40,722 |  |  | 59,035 |  |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |
| APAC* |  |  | (1,464 | ) |  | 19,092 |  |  | 17,628 |  |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |
| Total net revenues |  | $ | 75,326 |  | $ | 135,710 |  | $ | 211,036 |  |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |

[0000950170-24-052140:notes:32]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 251,694 |  | $ | 204,689 |  | $ | 456,383 |  |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |
| Other |  |  | 16,709 |  |  | 19,565 |  |  | 36,274 |  |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |
| Total Americas |  |  | 268,403 |  |  | 224,254 |  |  | 492,657 |  |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |
| EMEA |  |  | 184,706 |  |  | 128,537 |  |  | 313,243 |  |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |
| APAC |  |  | 7,510 |  |  | 47,140 |  |  | 54,650 |  |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |
| Total net revenues |  | $ | 460,619 |  | $ | 399,931 |  | $ | 860,550 |  |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |

[0000950170-24-052140:notes:33]
*The distributor revenue in the APAC region for the three months ended March 31, 2024 reflects a higher level of customer rebates for the distributors, resulting from higher sell-through to end users than the Company's product sales into these distributors.

[0000950170-24-052140:notes:34]
For the nine months ended March 31, 2024, the Company generated approximately 10% of its net revenues from the Netherlands. For the three and nine months ended March 31, 2023, the Company generated 17% and 12% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of its net revenues for the three and nine months ended March 31, 2024 and 2023.

[0000950170-24-052140:notes:35]
[same as prior period, unchanged from 0000950170-24-009819:notes:34]

[0000950170-24-052140:notes:36]
[same as prior period, unchanged from 0000950170-24-009819:notes:35]

[0000950170-24-052140:notes:37]
[same as prior period, unchanged from 0000950170-24-009819:notes:36]

[0000950170-24-052140:notes:38]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2024 |  | March 31,2023 |  | March 31,2024 |  | March 31,2023 |
| TD Synnex Corporation |  | 22% |  | 19% |  | 21% |  | 19% |
| Westcon Group, Inc. |  | 13% |  | 25% |  | 17% |  | 20% |
| Jenne, Inc. |  | 12% |  | 15% |  | 22% |  | 14% |
| ScanSource, Inc. |  | 11% |  | * |  | * |  | * |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |

[0000950170-24-052140:notes:39]
[same as prior period, unchanged from 0000950170-24-009819:notes:38]

[0000950170-24-052140:notes:40]
|  |  | March 31,2024 |  | June 30,2023 |
| Jenne, Inc. |  | 38% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-24-052140:notes:41]
[same as prior period, unchanged from 0000950170-24-009819:notes:41]

[0000950170-24-052140:notes:42]
[same as prior period, unchanged from 0000950170-24-009819:notes:42]

[0000950170-24-052140:notes:43]
[same as prior period, unchanged from 0000950170-24-009819:notes:43]

[0000950170-24-052140:notes:44]
[same as prior period, unchanged from 0000950170-24-009819:notes:44]

[0000950170-24-052140:notes:45]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Cash |  | $ | 143,421 |  |  | $ | 227,675 |  |
| Cash equivalents |  |  | 7,586 |  |  |  | 7,151 |  |
| Total cash and cash equivalents |  | $ | 151,007 |  |  | $ | 234,826 |  |

[0000950170-24-052140:notes:46]
[same as prior period, unchanged from 0000950170-24-009819:notes:46]

[0000950170-24-052140:notes:47]
[same as prior period, unchanged from 0000950170-24-009819:notes:47]

[0000950170-24-052140:notes:48]
[same as prior period, unchanged from 0000950170-24-009819:notes:48]

[0000950170-24-052140:notes:49]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Finished goods |  | $ | 158,228 |  |  | $ | 78,180 |  |
| Raw materials |  |  | 27,129 |  |  |  | 10,844 |  |
| Total inventories |  | $ | 185,357 |  |  | $ | 89,024 |  |

[0000950170-24-052140:notes:50]
[same as prior period, unchanged from 0000950170-24-009819:notes:50]

[0000950170-24-052140:notes:51]
[same as prior period, unchanged from 0000950170-24-009819:notes:51]

[0000950170-24-052140:notes:52]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Computers and equipment |  | $ | 75,413 |  |  | $ | 81,612 |  |
| Purchased software |  |  | 55,853 |  |  |  | 51,444 |  |
| Office equipment, furniture and fixtures |  |  | 8,796 |  |  |  | 8,899 |  |
| Leasehold improvements |  |  | 48,301 |  |  |  | 48,943 |  |
| Total property and equipment |  |  | 188,363 |  |  |  | 190,898 |  |
| Less: accumulated depreciation and amortization |  |  | (141,109 | ) |  |  | (144,450 | ) |
| Property and equipment, net |  | $ | 47,254 |  |  | $ | 46,448 |  |

[0000950170-24-052140:notes:53]
[same as prior period, unchanged from 0000950170-24-009819:notes:53]

[0000950170-24-052140:notes:54]
[same as prior period, unchanged from 0000950170-24-009819:notes:54]

[0000950170-24-052140:notes:55]
[same as prior period, unchanged from 0000950170-24-009819:notes:55]

[0000950170-24-052140:notes:56]
[same as prior period, unchanged from 0000950170-24-009819:notes:56]

[0000950170-24-052140:notes:57]
[same as prior period, unchanged from 0000950170-24-009819:notes:57]

[0000950170-24-052140:notes:58]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Balance at beginning of period |  | $ | 11,397 |  |  | $ | 11,820 |  |  | $ | 12,322 |  |  | $ | 10,852 |  |
| New warranties issued |  |  | 3,312 |  |  |  | 4,161 |  |  |  | 9,763 |  |  |  | 11,976 |  |
| Warranty expenditures |  |  | (3,642 | ) |  |  | (3,679 | ) |  |  | (11,018 | ) |  |  | (10,526 | ) |
| Balance at end of period |  | $ | 11,067 |  |  | $ | 12,302 |  |  | $ | 11,067 |  |  | $ | 12,302 |  |

[0000950170-24-052140:notes:59]
[same as prior period, unchanged from 0000950170-24-009819:notes:59]

[0000950170-24-052140:notes:60]
[same as prior period, unchanged from 0000950170-24-009819:notes:60]

[0000950170-24-052140:notes:61]
[same as prior period, unchanged from 0000950170-24-009819:notes:61]


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-052140:notes:62]
[same as prior period, unchanged from 0000950170-24-009819:notes:62]

[0000950170-24-052140:notes:63]
[same as prior period, unchanged from 0000950170-24-009819:notes:63]

[0000950170-24-052140:notes:64]
[same as prior period, unchanged from 0000950170-24-009819:notes:64]

[0000950170-24-052140:notes:65]
[same as prior period, unchanged from 0000950170-24-009819:notes:65]

[0000950170-24-052140:notes:66]
[same as prior period, unchanged from 0000950170-24-009819:notes:66]

[0000950170-24-052140:notes:67]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at March 31, 2024 and June 30, 2023 (in thousands):

[0000950170-24-052140:notes:68]
| March 31, 2024 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 7,586 |  |  | $ | — |  |  | $ | 7,586 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 7,586 |  |  | $ | — |  |  | $ | 7,586 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 80 |  |  | $ | — |  |  | $ | 80 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 80 |  |  | $ | — |  |  | $ | 80 |  |

[0000950170-24-052140:notes:69]
[same as prior period, unchanged from 0000950170-24-009819:notes:69]

[0000950170-24-052140:notes:70]
[same as prior period, unchanged from 0000950170-24-009819:notes:70]

[0000950170-24-052140:notes:71]
[same as prior period, unchanged from 0000950170-24-009819:notes:71]

[0000950170-24-052140:notes:72]
As of March 31, 2024 and June 30, 2023, the Company had investment in certificates of deposit of $7.6 million and $7.2 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of March 31, 2024 and June 30, 2023, their fair value approximated their amortized cost.

[0000950170-24-052140:notes:73]
As of March 31, 2024 and June 30, 2023, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $15.5 million and $3.4 million, respectively. These contracts currently have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income, net in the condensed consolidated statements of operations. For the three months ended March 31, 2024 and 2023, there were net losses of $0.3 million and net gains of $0.1 million, respectively. For the nine months ended March 31, 2024 and 2023, there were net losses of less than $0.1 million and $0.3 million, respectively. As of March 31, 2024 and June 30, 2023, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 12, Derivatives and Hedging, for additional information.

[0000950170-24-052140:notes:74]
The fair value of borrowings under the 2023 Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2023 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $192.5 million and $225.0 million as of March 31, 2024 and June 30, 2023, respectively.

[0000950170-24-052140:notes:75]
[same as prior period, unchanged from 0000950170-24-009819:notes:75]

[0000950170-24-052140:notes:76]
As of March 31, 2024 and June 30, 2023, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2, and Level 3 during the three and nine months ended March 31, 2024 and 2023. There were no impairments recorded for the three and nine months ended March 31, 2024 and 2023.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-24-052140:notes:77]
[same as prior period, unchanged from 0000950170-24-009819:notes:77]

[0000950170-24-052140:notes:78]
[same as prior period, unchanged from 0000950170-24-009819:notes:78]

[0000950170-24-052140:notes:79]
[same as prior period, unchanged from 0000950170-24-009819:notes:79]

[0000950170-24-052140:notes:80]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.4 years |  | $ | 169,347 |  |  | $ | 162,163 |  |  | $ | 7,184 |  |
| Customer relationships |  | 2.2 years |  |  | 64,683 |  |  |  | 60,274 |  |  |  | 4,409 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 2.8 years |  |  | 2,445 |  |  |  | 2,249 |  |  |  | 196 |  |
| Total intangible assets, net* |  |  |  | $ | 247,175 |  |  | $ | 235,386 |  |  | $ | 11,789 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-24-052140:notes:81]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 4.1 years |  | $ | 169,460 |  |  | $ | 159,592 |  |  | $ | 9,868 |  |
| Customer relationships |  | 3.4 years |  |  | 64,839 |  |  |  | 58,894 |  |  |  | 5,945 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 3.4 years |  |  | 2,445 |  |  |  | 2,195 |  |  |  | 250 |  |
| Total intangible assets, net* |  |  |  | $ | 247,444 |  |  | $ | 231,381 |  |  | $ | 16,063 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-24-052140:notes:82]
[same as prior period, unchanged from 0000950170-24-009819:notes:82]

[0000950170-24-052140:notes:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 616 |  |  | $ | 3,052 |  |  | $ | 2,661 |  |  | $ | 9,878 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 511 |  |  |  | 510 |  |  |  | 1,531 |  |  |  | 1,537 |  |
| Total amortization expense |  | $ | 1,127 |  |  | $ | 3,562 |  |  | $ | 4,192 |  |  | $ | 11,415 |  |

[0000950170-24-052140:notes:84]
[same as prior period, unchanged from 0000950170-24-009819:notes:84]

[0000950170-24-052140:notes:85]
[same as prior period, unchanged from 0000950170-24-009819:notes:85]

[0000950170-24-052140:notes:86]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2024 (the remainder of fiscal 2024) |  | $ | 1,119 |  |
| 2025 |  |  | 4,477 |  |
| 2026 |  |  | 3,211 |  |
| 2027 |  |  | 1,439 |  |
| 2028 |  |  | 1,277 |  |
| Thereafter |  |  | 266 |  |
| Total |  | $ | 11,789 |  |

[0000950170-24-052140:notes:87]
[same as prior period, unchanged from 0000950170-24-009819:notes:87]

[0000950170-24-052140:notes:88]
The Company had Goodwill in the amount of $394.2 million and $394.8 million as of March 31, 2024 and June 30, 2023, respectively. The change in goodwill during the nine months ended March 31, 2024 is due to foreign currency translation adjustments that are recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-052140:notes:89]
7.
Debt

[0000950170-24-052140:notes:90]
The Company’s debt is comprised of the following (in thousands):

[0000950170-24-052140:notes:91]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (674 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,326 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 182,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,903 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 180,597 |  |  |  | 187,591 |  |
| Total debt |  | $ | 189,923 |  |  | $ | 221,917 |  |

[0000950170-24-052140:notes:92]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-24-052140:notes:93]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance its debt. On July 7, 2023, the Company made a payment of $25.0 million to pay off the outstanding revolving credit balance.

[0000950170-24-052140:notes:94]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-24-052140:notes:95]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the nine months ended March 31, 2024, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.

[0000950170-24-052140:notes:96]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended March 31, 2024 and 2023, respectively, and were $0.8 million and $2.2 million for the nine months ended March 31, 2024 and 2023, respectively. The interest rate as of March 31, 2024 was 7.44% and as of March 31, 2023 was 5.97%.

[0000950170-24-052140:notes:97]
As of March 31, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.5 million of availability under the 2023 Revolving Facility as of March 31, 2024. During the three and nine months ended March 31, 2024 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the nine months ended March 31, 2023, the Company made an additional payment of $45.5 million, against its term loan facility under the 2019 Credit Agreement.

[0000950170-24-052140:notes:98]
The Company had $14.5 million of outstanding letters of credit as of March 31, 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-052140:notes:99]
8.
Commitments and Contingencies

[0000950170-24-052140:notes:100]
Purchase Commitments

[0000950170-24-052140:notes:101]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2024, the Company had commitments to purchase $51.5 million of inventory.

[0000950170-24-052140:notes:102]
Legal Proceedings

[0000950170-24-052140:notes:103]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-24-052140:notes:104]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0000950170-24-052140:notes:105]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-24-052140:notes:106]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0000950170-24-052140:notes:107]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0000950170-24-052140:notes:108]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.

[0000950170-24-052140:notes:109]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-24-052140:notes:110]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without

[0000950170-24-052140:notes:111]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint, which was denied on January 30, 2024. On March 20, 2023, the Company filed a motion to refer questions to the U.S. Copyright Office on the invalidity of SNMP’s copyrights, which was denied on March 18, 2024. The trial date has been set for October 2024.

[0000950170-24-052140:notes:112]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-24-052140:notes:113]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and the matter is proceeding through the appellate process.

[0000950170-24-052140:notes:114]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021 and a hearing date has been set for November 20, 2024.

[0000950170-24-052140:notes:115]
Indemnification Obligations

[0000950170-24-052140:notes:116]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-24-052140:notes:117]
[same as prior period, unchanged from 0000950170-24-009819:notes:117]

[0000950170-24-052140:notes:118]
[same as prior period, unchanged from 0000950170-24-009819:notes:118]

[0000950170-24-052140:notes:119]
[same as prior period, unchanged from 0000950170-24-009819:notes:119]

[0000950170-24-052140:notes:120]
[same as prior period, unchanged from 0000950170-24-009819:notes:120]

[0000950170-24-052140:notes:121]
[same as prior period, unchanged from 0000950170-24-009819:notes:121]

[0000950170-24-052140:notes:122]
[same as prior period, unchanged from 0000950170-24-009819:notes:122]

[0000950170-24-052140:notes:123]
[same as prior period, unchanged from 0000950170-24-009819:notes:123]

[0000950170-24-052140:notes:124]
During the three months ended March 31, 2024, the Company did not repurchase any shares of its common stock. During the nine months ended March 31, 2024, the Company repurchased a total of 2,365,220 shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. During the three months ended March 31, 2023, the Company repurchased a total of 1,350,568 shares of its common stock on the open market at a total cost of $25.0 million with an average price of $18.51 per share. During the nine months ended March 31, 2023, the Company repurchased a total of 3,928,743 shares of its common stock on the open market at a total cost of $74.8 million with an average price of $19.04 per share. As of March 31, 2024, approximately $50.3 million remains available for share repurchases under the 2022 Repurchase Program.

[0000950170-24-052140:notes:125]
[same as prior period, unchanged from 0000950170-24-009819:notes:125]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-052140:notes:126]
[same as prior period, unchanged from 0000950170-24-009819:notes:126]

[0000950170-24-052140:notes:127]
[same as prior period, unchanged from 0000950170-24-009819:notes:127]

[0000950170-24-052140:notes:128]
[same as prior period, unchanged from 0000950170-24-009819:notes:128]

[0000950170-24-052140:notes:129]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 12,973 |  |  |  | 9,995 |  |
| Employee stock options and awards outstanding |  |  | 8,291 |  |  |  | 10,038 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,130 |  |  |  | 8,467 |  |
| Total shares reserved for issuance |  |  | 28,394 |  |  |  | 28,500 |  |

[0000950170-24-052140:notes:130]
[same as prior period, unchanged from 0000950170-24-009819:notes:130]

[0000950170-24-052140:notes:131]
[same as prior period, unchanged from 0000950170-24-009819:notes:131]

[0000950170-24-052140:notes:132]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Cost of product revenues |  | $ | 405 |  |  | $ | 492 |  |  | $ | 1,352 |  |  | $ | 1,365 |  |
| Cost of subscription and support revenues |  |  | 679 |  |  |  | 930 |  |  |  | 2,294 |  |  |  | 2,568 |  |
| Research and development |  |  | 4,226 |  |  |  | 3,883 |  |  |  | 13,038 |  |  |  | 10,935 |  |
| Sales and marketing |  |  | 5,683 |  |  |  | 5,777 |  |  |  | 20,206 |  |  |  | 16,326 |  |
| General and administrative |  |  | 6,840 |  |  |  | 4,294 |  |  |  | 21,819 |  |  |  | 15,367 |  |
| Total share-based compensation expense |  | $ | 17,833 |  |  | $ | 15,376 |  |  | $ | 58,709 |  |  | $ | 46,561 |  |

[0000950170-24-052140:notes:133]
[same as prior period, unchanged from 0000950170-24-009819:notes:133]

[0000950170-24-052140:notes:134]
The following table summarizes stock option activity for the nine months ended March 31, 2024 (in thousands, except per share amount and contractual term):

[0000950170-24-052140:notes:135]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.70 |  |  | $ | 23,136 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (114 | ) |  |  | 6.40 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 2.00 |  |  | $ | 5,326 |  |
| Vested and expected to vest at March 31, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 2.00 |  |  | $ | 5,326 |  |
| Exercisable at March 31, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 2.00 |  |  | $ | 5,326 |  |

[0000950170-24-052140:notes:136]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the three and nine months ended March 31, 2024 and 2023.

[0000950170-24-052140:notes:137]
[same as prior period, unchanged from 0000950170-24-009819:notes:137]

[0000950170-24-052140:notes:138]
[same as prior period, unchanged from 0000950170-24-009819:notes:138]

[0000950170-24-052140:notes:139]
The following table summarizes stock award activity for the nine months ended March 31, 2024 (in thousands, except grant date fair value):

[0000950170-24-052140:notes:140]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2023 |  |  | 8,851 |  |  | $ | 14.25 |  |  |  |  |
| Granted |  |  | 3,939 |  |  |  | 27.78 |  |  |  |  |
| Released |  |  | (4,735 | ) |  |  | 12.65 |  |  |  |  |
| Canceled |  |  | (837 | ) |  |  | 19.54 |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2024 |  |  | 7,218 |  |  | $ | 22.07 |  |  | $ | 159,301 |  |
| Stock awards expected to vest at March 31, 2024 |  |  | 7,218 |  |  | $ | 22.07 |  |  | $ | 159,301 |  |

[0000950170-24-052140:notes:141]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the nine months ended March 31, 2024 included 0.6 million RSUs including the market condition awards discussed below to the named executive officers and directors.

[0000950170-24-052140:notes:142]
[same as prior period, unchanged from 0000950170-24-009819:notes:142]

[0000950170-24-052140:notes:143]
During the nine months ended March 31, 2024 and 2023, the Compensation Committee of the Board granted 0.8 million and 1.0 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. The MSUs granted during the nine months ended March 31, 2024 included 0.5 million MSUs subject to total shareholder return (“TSR”) and 0.3 million MSUs subject to certain stock price targets. The MSUs granted during the nine months ended March 31, 2023 were subject to TSR.

[0000950170-24-052140:notes:144]
[same as prior period, unchanged from 0000950170-24-009819:notes:144]

[0000950170-24-052140:notes:145]
[same as prior period, unchanged from 0000950170-24-009819:notes:145]

[0000950170-24-052140:notes:146]
[same as prior period, unchanged from 0000950170-24-009819:notes:146]

[0000950170-24-052140:notes:147]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the nine months ended March 31, 2024 was $32.66 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free interest rate of 4.43%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The weighted-average grant-date fair value of the TSR MSUs granted during the nine months ended March 31, 2023 was $16.57 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 67%, risk-free interest rate of 3.12%, no expected dividend yield, expected term of three years, and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-24-052140:notes:148]
[same as prior period, unchanged from 0000950170-24-009819:notes:148]

[0000950170-24-052140:notes:149]
The grant date fair value of these stock price target MSUs was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of these stock price target MSUs granted during the nine months ended March 31, 2024 was $28.80 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 63%, risk-free interest rate of 4.45%, no expected dividend yield, expected term of three years based on possible future stock prices over the performance period based on the historical stock prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-24-052140:notes:150]
[same as prior period, unchanged from 0000950170-24-009819:notes:150]

[0000950170-24-052140:notes:151]
There were 0.8 million shares issued under the ESPP during each of the three months ended March 31, 2024 and 2023. There were 1.3 million and 1.5 million shares issued under the ESPP during the nine months ended March 31, 2024 and 2023, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0000950170-24-052140:notes:152]
|  |  | Employee Stock Purchase Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 5.31 | % |  |  | 4.98 | % |  |  | 5.42 | % |  |  | 3.84 | % |
| Volatility |  |  | 52 | % |  |  | 49 | % |  |  | 47 | % |  |  | 55 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0000950170-24-052140:notes:153]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended March 31, 2024 and 2023 was $3.68 and $5.63 per share, respectively. The weighted-average grant-date fair value of shares under the ESPP during the nine months ended March 31, 2024 and 2023 was $5.73 and $4.87 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-052140:notes:154]
[same as prior period, unchanged from 0000950170-24-009819:notes:154]

[0000950170-24-052140:notes:155]
[same as prior period, unchanged from 0000950170-24-009819:notes:155]

[0000950170-24-052140:notes:156]
[same as prior period, unchanged from 0000950170-24-009819:notes:156]

[0000950170-24-052140:notes:157]
[same as prior period, unchanged from 0000950170-24-009819:notes:157]

[0000950170-24-052140:notes:158]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Americas |  | $ | 139,483 |  |  | $ | 124,375 |  |
| EMEA |  |  | 35,286 |  |  |  | 35,175 |  |
| APAC |  |  | 10,538 |  |  |  | 11,244 |  |
| Total long-lived assets |  | $ | 185,307 |  |  | $ | 170,794 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-052140:notes:159]
[same as prior period, unchanged from 0000950170-24-009819:notes:159]

[0000950170-24-052140:notes:160]
[same as prior period, unchanged from 0000950170-24-009819:notes:160]

[0000950170-24-052140:notes:161]
The Company is exposed to interest rate risk on its debt. The Company may enter into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which may have a floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0000950170-24-052140:notes:162]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessments of whether the derivatives that are used in hedging transactions are highly effective in offsetting changes

[0000950170-24-052140:notes:163]
in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 Derivatives and Hedging, the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in “Accumulated other comprehensive loss” and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0000950170-24-052140:notes:164]
During the fiscal year ended June 30, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of March 31, 2024, the Company did not have any outstanding interest rate swaps contracts. As of March 31, 2023, the notional amount of these interest rate swaps was $75.0 million and had maturity dates through April 2023. As of March 31, 2023, these contracts had unrealized gains of $0.1 million, and were recorded in “Accumulated other comprehensive loss” with the associated asset in “Prepaid expenses and other current assets”, in the condensed consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in “Accumulated other comprehensive loss” related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts.

[0000950170-24-052140:notes:165]
[same as prior period, unchanged from 0000950170-24-009819:notes:165]

[0000950170-24-052140:notes:166]
[same as prior period, unchanged from 0000950170-24-009819:notes:166]

[0000950170-24-052140:notes:167]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of March 31, 2024 and 2023, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $15.5 million and $11.2 million, respectively. These contracts have maturities of 40 days or less. During the three months ended March 31, 2024 and 2023, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net losses of $0.3 million and net gains of $0.1 million, respectively. During the nine months ended March 31, 2024 and 2023 the net gains and losses recorded in the condensed consolidated statement of operations were net losses of less than $0.1 million and net losses of $0.3 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities. 
For the three months ended March 31, 2024 and 2023, the Company recognized total foreign currency gains of $0.7 million and total foreign currency losses of $0.3 million, respectively, and for the nine months ended March 31, 2024 and 2023, the Company recognized total foreign currency gains of $0.4 million and $0.5 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-052140:notes:168]
[same as prior period, unchanged from 0000950170-24-009819:notes:168]

[0000950170-24-052140:notes:169]
The Company recorded $14.4 million and $26.3 million of restructuring and related charges during the three and nine months ended March 31, 2024, respectively, which primarily related to the restructuring plans as noted below.

[0000950170-24-052140:notes:170]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company's research and development and sales and marketing functions to align the Company's workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”). During the three and nine months ended March 31, 2024, the Company recorded restructuring charges of approximately $9.7 million related to the Q3 2024 Plan, which primarily consisted of severance and benefits expenses.

[0000950170-24-052140:notes:171]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the three months ended March 31, 2024, the Company recorded restructuring charges of approximately $4.6 million related to the Q2 2024 Plan, which primarily consisted of additional severance, other employee benefits and legal and consulting fees. During the nine months ended March 31, 2024, the Company recorded restructuring charges of approximately $13.3 million related to the Q2 2024 Plan, which primarily consisted of employee severance and benefits expenses and legal and consulting fees.

[0000950170-24-052140:notes:172]
The Company expects to complete these ongoing restructuring plans by the end of fiscal 2024 and expects to incur between $2.0 million to $3.0 million in additional charges for the Q3 2024 Plan and the Q2 2024 Plan by the end of fiscal 2024.

[0000950170-24-052140:notes:173]
During the first quarter of fiscal 2024, the Company initiated a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with the Company's business and strategic priorities (the “Q1 2024 Plan”). It consisted primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general & administrative functions. During the three months ended March 31, 2024, the Company did not incur any charges related to the Q1 2024 Plan. During the nine months ended March 31, 2024, the Company incurred charges of approximately $2.9 million related to the Q1 2024 Plan. As of March 31, 2024, the plan was completed.

[0000950170-24-052140:notes:174]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company is moving engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company's labs. During the three months and nine months ended March 31, 2024, the Company incurred restructuring charges of approximately $0.1 million and $0.4 million, respectively, primarily for moving costs. The Company expects that the project will take about 6 to 9 months from March 31, 2024 to complete, and expects to incur charges of approximately $9.0 million throughout this period, primarily for asset disposals, contractor costs, severance, relocation, and other non-recurring fees.

[0000950170-24-052140:notes:175]
The Company recorded $1.4 million and $2.3 million of restructuring and related charges during the three and nine months ended March 31, 2023, which primarily included additional facilities expenses related to previously impaired facilities and $0.8 million in charges associated with the 2023 plan to transform the Company's business and facilities infrastructure.

[0000950170-24-052140:notes:176]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of March 31, 2024, the restructuring liability was $17.0 million, which primarily related to the Q2 2024 and Q3 2024 Plans.

[0000950170-24-052140:notes:177]
The following table summarizes the activity related to the Company’s restructuring and related liabilities during the following periods (in thousands):

[0000950170-24-052140:notes:178]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2024 |  |  | March 31, 2024 |  |
| Balance at beginning of period |  | $ | 6,192 |  |  | $ | — |  |
| Period charges |  |  | 14,937 |  |  |  | 27,113 |  |
| Period reversals |  |  | (516 | ) |  |  | (802 | ) |
| Period payments |  |  | (3,641 | ) |  |  | (9,339 | ) |
| Balance at end of period |  | $ | 16,972 |  |  | $ | 16,972 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-052140:notes:179]
[same as prior period, unchanged from 0000950170-24-009819:notes:175]

[0000950170-24-052140:notes:180]
For the three months ended March 31, 2024 and 2023, the Company recorded an income tax benefit of $0.6 million and an income tax provision of $3.9 million, respectively. For the nine months ended March 31, 2024 and 2023, the Company recorded an income tax provision of $7.0 million and $8.3 million, respectively.

[0000950170-24-052140:notes:181]
The income tax provisions (benefit) for the three and nine months ended March 31, 2024 and 2023, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In addition, the income tax provision (benefit) for the three months ended March 31, 2024, includes US Federal income tax benefit of $1.6 million, fully reversing the previously recorded U.S. federal income tax expense during the first two quarters of the year, as well as a $0.3 million income tax benefit resulting from establishment of an indefinite lived deferred tax asset for nondeductible interest expense, offsetting the deferred tax liability related to amortizable goodwill. The interim income tax provisions (benefit) for the three and nine months ended March 31, 2024 and 2023 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was

[0000950170-24-052140:notes:182]
the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0000950170-24-052140:notes:183]
[same as prior period, unchanged from 0000950170-24-009819:notes:178]

[0000950170-24-052140:notes:184]
The Company had $18.3 million of unrecognized tax benefits as of March 31, 2024. If fully recognized in the future, $0.2 million would impact the effective tax rate and $18.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0000950170-24-052140:notes:185]
[same as prior period, unchanged from 0000950170-24-009819:notes:180]

[0000950170-24-052140:notes:186]
[same as prior period, unchanged from 0000950170-24-009819:notes:181]


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-052140:notes:187]
15.
Net Income (Loss) Per Share

[0000950170-24-052140:notes:188]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted-average number of shares of common stock outstanding during the period. Diluted net income (loss) per share is calculated by dividing net income by the weighted-average number of shares of common stock used in the basic net income per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0000950170-24-052140:notes:189]
The following table presents the calculation of net income (loss) per share of basic and diluted (in thousands, except per share data):

[0000950170-24-052140:notes:190]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Net income (loss) |  | $ | (64,425 | ) |  | $ | 22,131 |  |  | $ | (31,761 | ) |  | $ | 52,647 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 129,299 |  |  |  | 128,816 |  |  |  | 129,021 |  |  |  | 129,864 |  |
| Options to purchase common stock |  |  | — |  |  |  | 748 |  |  |  | — |  |  |  | 678 |  |
| Restricted stock units |  |  | — |  |  |  | 3,461 |  |  |  | — |  |  |  | 3,174 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 129,299 |  |  |  | 133,025 |  |  |  | 129,021 |  |  |  | 133,716 |  |
| Net income (loss) per share – basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | (0.50 | ) |  | $ | 0.17 |  |  | $ | (0.25 | ) |  | $ | 0.41 |  |
| Net income (loss) per share – diluted |  | $ | (0.50 | ) |  | $ | 0.17 |  |  | $ | (0.25 | ) |  | $ | 0.39 |  |

[0000950170-24-052140:notes:191]
The following securities were excluded from the computation of net income (loss) per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0000950170-24-052140:notes:192]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |  | March 31,2024 |  |  | March 31,2023 |  |
| Options to purchase common stock |  |  | 1,083 |  |  |  | — |  |  |  | 1,144 |  |  |  | — |  |
| Restricted stock units |  |  | 5,577 |  |  |  | 143 |  |  |  | 6,269 |  |  |  | 116 |  |
| Employee Stock Purchase Plan shares |  |  | 266 |  |  |  | 238 |  |  |  | 88 |  |  |  | 78 |  |
| Total shares excluded |  |  | 6,926 |  |  |  | 381 |  |  |  | 7,501 |  |  |  | 194 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-24-052140:notes:193]
On February 16, 2024, Rajendra K. Khanna, a member of the Company's board of directors, terminated a Rule 10b5-1 trading arrangement that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) and that was originally adopted on August 14, 2023 for the sale of up to 25,000 shares of the Company’s common stock until October 30, 2024.

[0000950170-24-052140:notes:194]
On February 22, 2024, Edward B. Meyercord, the Company's President and CEO, modified a Rule 10b5-1 trading arrangement, originally adopted on August 4, 2023 to change the amount of shares to be sold under the plan and the timing of sales under the plan. The modified trading arrangement is intended to satisfy the affirmative defense of Rule 10b5-1(c) and provides for the sale of up to 728,700 shares of the Company's common stock until August 31, 2025.

[0000950170-24-052140:notes:195]
On February 23, 2024, Rajendra K. Khanna, a member of the Company's board of directors, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 25,000 shares of the Company's common stock until February 28, 2025.
