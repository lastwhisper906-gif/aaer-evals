# EXTR 8-K — 0000950170-23-057125 filed 2023-11-01

## item codes, every 8-K on or before 2023-11-02

- 2023-11-01 0000950170-23-057125 — 2.02, 9.01
- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2023-11-02

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-057125:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0000950170-23-057125:8k_2_02:2]
EX-99.1

[0000950170-23-057125:8k_2_02:3]
Exhibit 99.1

[0000950170-23-057125:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0000950170-23-057125:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2024 Financial Results

[0000950170-23-057125:8k_2_02:6]
Revenue Growth of 19% and Operating Leverage Doubles GAAP EPS

[0000950170-23-057125:8k_2_02:7]
Cloud Adoption Drives 30% Growth in SaaS ARR

[0000950170-23-057125:8k_2_02:8]
Morrisville, NC, November 1, 2023 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its first quarter ended September 30, 2023.

[0000950170-23-057125:8k_2_02:9]
"Extreme delivered another quarter of double-digit growth as we continued to increase both market and mindshare with new customers, while expanding our presence within our existing base," said Ed Meyercord, President and Chief Executive Officer. "Our funnel of new opportunities continued to grow double-digits and the value of deals over $1 million once again grew from the prior quarter. Our highly differentiated cloud solutions deliver simplicity, flexibility and actionable insights to customers, making it easier to manage and secure their networks. And our subscription bookings and SaaS ARR growth of 30% are a testament to that. We continue to focus on gaining core market share, making strategic investments, and driving go-to-market initiatives to position the company for success as we navigate potential macroeconomic headwinds in FY24. We remain committed to driving double-digit long-term growth while being prudent stewards of shareholder capital," concluded Meyercord.

[0000950170-23-057125:8k_2_02:10]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, "We are pleased with our Q1 financial and operational performance. Our topline growth and operating leverage enabled us to double our EPS from the prior year, and generate $71.3 million in free cash flow. We repurchased another $24.9 million worth of shares and our net cash position grew to $26.9 million. Looking ahead at FY24, we expect changing customer buying patterns based on macroeconomic conditions in certain geographies. Therefore, we expect revenue growth to be more tempered for the balance of the year. Despite these market conditions and slower revenue growth expectations, we expect continued growth of EPS of over 25% in FY24. We have taken recent actions to ensure we align our cost structure to the current level of revenue growth we expect to achieve. As a result, we believe we are well-positioned to deliver strong profitability and improved operating margins during the year."

[0000950170-23-057125:8k_2_02:11]
Fiscal First Quarter Results:

[0000950170-23-057125:8k_2_02:12]
•
Revenue $353.1 million, up 19% year-over-year.

[0000950170-23-057125:8k_2_02:13]
•
SaaS ARR $141.0 million, up 30% year-over-year

[0000950170-23-057125:8k_2_02:14]
•
GAAP diluted EPS $0.21, compared to $0.09 in the prior year quarter

[0000950170-23-057125:8k_2_02:15]
•
Non-GAAP diluted EPS $0.35, compared to $0.20 in the prior year quarter

[0000950170-23-057125:8k_2_02:16]
•
GAAP gross margin 60.3% compared to 56.0% in the prior year quarter

[0000950170-23-057125:8k_2_02:17]
•
Non-GAAP gross margin 61.1% compared to 57.6% in the prior year quarter

[0000950170-23-057125:8k_2_02:18]
•
GAAP operating margin 10.2 % compared to 5.8 % in the prior year quarter

[0000950170-23-057125:8k_2_02:19]
•
Non-GAAP operating margin 17.7 % compared to 12.1% in the prior year quarter

[0000950170-23-057125:8k_2_02:20]
Liquidity:

[0000950170-23-057125:8k_2_02:21]
•
During Q1, we generated net cash flow from operations of $75.6 million and free cash flow of $71.3 million.

[0000950170-23-057125:8k_2_02:22]
•
During Q1, we repurchased 0.9 million shares of our common stock on the open market at a total cost of $24.9 million with a weighted average price of $28.28 per share.

[0000950170-23-057125:8k_2_02:23]
•
Q1 ending cash balance was $224.4 million, a decrease of $10.4 million from the end of Q4 2023 and an increase of $26.1 million from the end of Q1 in the prior year.

[0000950170-23-057125:8k_2_02:24]
•
Q1 net cash was $26.9 million, an increase of $17.1 million from net cash of $9.8 million from the end of Q4 2023 and an increase of $100.1 million from net debt of $73.2 million at the end of Q1 in the prior year.

[0000950170-23-057125:8k_2_02:25]
Recent Key Highlights:

[0000950170-23-057125:8k_2_02:26]
•
Extreme Networks will host an Investor Day on Tuesday, Nov. 7 at the headquarters of Major League Baseball (MLB) in New York City. Topics will include an overview of the company, including an update on its strategic growth opportunities, customer highlights, go-to-market developments and the company’s outlook and longer-term financial targets. The in-person event will begin at 8:30 a.m. ET and will also be livestreamed for virtual attendees. For more information and to register for the in-person or livestreamed event, visit: https://cvent.me/kxXbGK?RefId=PR

[0000950170-23-057125:8k_2_02:27]
•
Extreme continues to see significant traction around our highly differentiated fabric solutions.  More than 6,000 customers around the world rely on Extreme’s network fabric solutions for simplified, secure, resilient networking benefiting from zero-touch provisioning, automation, hyper-segmentation, and simplified network management. These capabilities have helped the City of Milwaukee secure mission-critical systems, Harry Reid International Airport simplify operations, and San Diego Community College District connect 80,000 students across multiple campuses.

[0000950170-23-057125:8k_2_02:28]
•
Hosted by Dubai World Trade Center (DWTC), GITEX, the world's largest technology trade show, was and powered by Extreme's wireless, fabric and cloud solutions. DWTC supports more than 180,000 attendees, 6,000 exhibitors and 30,000 devices at this massive event. Extreme Fabric is the only solution that can quickly, simply, and securely segment 3,300 individual networks in a matter of minutes. Competitive solutions take hours and introduce a significant margin of error due to their complexity.

[0000950170-23-057125:8k_2_02:29]
•
A global leading fast food chain has selected ExtremeCloud SD-WAN to ensure consistent performance and improve guest experiences at its 1,500 locations across the UK. With Extreme, this industry leader has greater visibility and will be able to simplify network management across its locations, increase overall network security and optimize operations by improving performance for critical applications.

[0000950170-23-057125:8k_2_02:30]
•
Extreme will deploy fabric-enabled wired networks for three new BAPS temples including the BAPS Mandir in Robbinsville, New Jersey, which is the largest Hindu temple outside of Asia. The new networks will enable BAPS to support and secure technology across its temple complexes, including multimedia displays and security cameras in exhibition halls, prayer halls and offices.

[0000950170-23-057125:8k_2_02:31]
•
Sporting Clube de Portugal (Sporting CP), one of the most decorated football clubs in Portugal, chose Extreme to enhance the fan experience at its 50,000-plus seat stadium in Lisbon. With Universal Switching and Wi-Fi 6E solutions from Extreme, Sporting Club de Portugal can easily support connectivity throughout its facilities and enhance logistics and activities such as like mobile tickets, in-seat concessions sales and digital signage throughout the stadium. Extreme also completed the rollout of the highly anticipated Wi-Fi 6 network at Old Trafford Stadium for Manchester United.

[0000950170-23-057125:8k_2_02:32]
Fiscal Q1 2024  Financial Metrics:

[0000950170-23-057125:8k_2_02:33]
(in millions, except percentages and per share information)

[0000950170-23-057125:8k_2_02:34]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |  | Change |  |
| Product |  | $ | 253.5 |  |  | $ | 206.3 |  |  | $ | 47.2 |  |
| Subscription and support* |  |  | 99.6 |  |  |  | 91.4 |  |  |  | 8.2 |  |
| Total net revenue |  | $ | 353.1 |  |  | $ | 297.7 |  |  | $ | 55.4 |  |
| Gross margin |  |  | 60.3 | % |  |  | 56.0 | % |  |  | 4.3 | % |
| Operating margin |  |  | 10.2 | % |  |  | 5.8 | % |  |  | 4.3 | % |
| Net income |  | $ | 28.7 |  |  | $ | 12.6 |  |  | $ | 16.1 |  |
| Net income per diluted share |  | $ | 0.21 |  |  | $ | 0.09 |  |  | $ | 0.12 |  |

[0000950170-23-057125:8k_2_02:35]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |  | Change |  |
| Product |  | $ | 253.5 |  |  | $ | 206.3 |  |  | $ | 47.2 |  |
| Subscription and support* |  |  | 99.6 |  |  |  | 91.4 |  |  |  | 8.2 |  |
| Total net revenue |  | $ | 353.1 |  |  | $ | 297.7 |  |  | $ | 55.4 |  |
| Gross margin |  |  | 61.1 | % |  |  | 57.6 | % |  |  | 3.5 | % |
| Operating margin |  |  | 17.7 | % |  |  | 12.1 | % |  |  | 5.6 | % |
| Net income |  | $ | 46.5 |  |  | $ | 27.1 |  |  | $ | 19.5 |  |
| Net income per diluted share |  | $ | 0.35 |  |  | $ | 0.20 |  |  | $ | 0.15 |  |

[0000950170-23-057125:8k_2_02:36]
* Prior to fiscal 2023, subscription and support revenue was referred to as service and subscription revenue, however, the composition of subscription and support revenue has not been modified.

[0000950170-23-057125:8k_2_02:37]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in millions):

[0000950170-23-057125:8k_2_02:38]
| Free Cash Flow | Three Months Ended |  |
|  | September 30,2023 |  |  | September 30,2022 |  |
| Cash flow provided by operations | $ | 75.6 |  |  | $ | 49.7 |  |
| Less: Property and equipment capital expenditures |  | (4.3 | ) |  |  | (3.1 | ) |
| Total free cash flow | $ | 71.3 |  |  | $ | 46.6 |  |

[0000950170-23-057125:8k_2_02:39]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud™ IQ (XIQ) and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue or deferred revenue that are accounted for under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0000950170-23-057125:8k_2_02:40]
Gross Debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0000950170-23-057125:8k_2_02:41]
Net Cash (Debt) is defined as cash minus gross debt, as shown in the table below (in millions):

[0000950170-23-057125:8k_2_02:42]
| Cash |  |  | Gross debt |  |  | Net cash (debt) |  |
| $ | 224.4 |  |  | $ | 197.5 |  |  | $ | 26.9 |  |

[0000950170-23-057125:8k_2_02:43]
Business Outlook:

[0000950170-23-057125:8k_2_02:44]
For its second quarter of fiscal 2024, ending December 31, 2023, the Company is targeting:

[0000950170-23-057125:8k_2_02:45]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ2'24 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 312.0 |  |  | $ | 327.0 |  |
| Gross margin |  | 59.5 | % |  |  | 61.5 | % |
| Operating margin |  | 5.0 | % |  |  | 7.4 | % |
| Net income per diluted share | $ | 0.07 |  |  | $ | 0.12 |  |
| Shares outstanding used in calculating GAAP EPS |  | 134.3 |  |  |  | 134.3 |  |
| FQ2’24 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 312.0 |  |  | $ | 327.0 |  |
| Gross margin |  | 60.2 | % |  |  | 62.2 | % |
| Operating margin |  | 15.4 | % |  |  | 17.3 | % |
| Net income per diluted share | $ | 0.26 |  |  | $ | 0.31 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 134.3 |  |  |  | 134.3 |  |

[0000950170-23-057125:8k_2_02:46]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY’24 guidance:

[0000950170-23-057125:8k_2_02:47]
|  | Gross MarginRate |  | OperatingMargin Rate |  | Earnings perShare |
| GAAP | 59.5% - 61.5% |  | 5.0% - 7.4% |  | $0.07 - $0.12 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.5% |  | 6.6% - 7.0% |  | 0.16 |
| Amortization of product intangibles | 0.2% |  | 0.2% |  | 0.00 |
| Amortization of non-product intangibles | — |  | 0.2% |  | 0.00 |
| Restructuring | — |  | 2.0% - 2.1% |  | 0.05 |
| Litigation charges | — |  | 0.5% |  | 0.01 |
| System transition cost | — |  | 0.4% |  | 0.01 |
| Tax adjustment | — |  | — |  | (0.04) |
| Non-GAAP | 60.2% - 62.2% |  | 15.4% - 17.3% |  | $0.26 - $0.31 |

[0000950170-23-057125:8k_2_02:48]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0000950170-23-057125:8k_2_02:49]
For its Fiscal 2024, ending June 30, 2024, the Company is targeting:

[0000950170-23-057125:8k_2_02:50]
•
Revenue to grow mid-to-high single digits

[0000950170-23-057125:8k_2_02:51]
•
Non-GAAP operating margin to remain mid-to-high teens

[0000950170-23-057125:8k_2_02:52]
•
EPS growth of over 25% for full year Fiscal Year 24

[0000950170-23-057125:8k_2_02:53]
No reconciliation of the forward-looking non-GAAP financial measure to the most directly comparable GAAP financial measure for Extreme’s Fiscal 2024 non-GAAP operating margin target is included in this press release because, due to the high variability and difficulty in making accurate forecasts and projections of some of the excluded information, together with some of the excluded information not being ascertainable or accessible, Extreme is unable to quantify certain amounts that would be required to be included in the most directly comparable GAAP financial measure without unreasonable efforts.

[0000950170-23-057125:8k_2_02:54]
Conference Call:

[0000950170-23-057125:8k_2_02:55]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the first quarter results of fiscal 2024 as well as the business outlook for the second quarter of fiscal 2024 ending December 31, 2023, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call, please go to this link (Extreme Networks Q1'24 Earnings Registration Link) and you will be provided with dial in details. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0000950170-23-057125:8k_2_02:56]
About Extreme:

[0000950170-23-057125:8k_2_02:57]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0000950170-23-057125:8k_2_02:58]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0000950170-23-057125:8k_2_02:59]
Non-GAAP Financial Measures:

[0000950170-23-057125:8k_2_02:60]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net cash (debt) and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges, and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may

[0000950170-23-057125:8k_2_02:61]
be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0000950170-23-057125:8k_2_02:62]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0000950170-23-057125:8k_2_02:63]
Forward-Looking Statements:

[0000950170-23-057125:8k_2_02:64]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2023, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0000950170-23-057125:8k_2_02:65]
###

[0000950170-23-057125:8k_2_02:66]
EXTREME NETWORKS, INC.

[0000950170-23-057125:8k_2_02:67]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-23-057125:8k_2_02:68]
(In thousands, except per share amounts)

[0000950170-23-057125:8k_2_02:69]
(Unaudited)

[0000950170-23-057125:8k_2_02:70]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 224,434 |  |  | $ | 234,826 |  |
| Accounts receivable, net |  |  | 131,511 |  |  |  | 182,045 |  |
| Inventories |  |  | 100,823 |  |  |  | 89,024 |  |
| Prepaid expenses and other current assets |  |  | 75,688 |  |  |  | 70,263 |  |
| Total current assets |  |  | 532,456 |  |  |  | 576,158 |  |
| Property and equipment, net |  |  | 46,336 |  |  |  | 46,448 |  |
| Operating lease right-of-use assets, net |  |  | 43,942 |  |  |  | 34,739 |  |
| Intangible assets, net |  |  | 13,857 |  |  |  | 16,063 |  |
| Goodwill |  |  | 392,955 |  |  |  | 394,755 |  |
| Other assets |  |  | 76,968 |  |  |  | 73,544 |  |
| Total assets |  | $ | 1,106,514 |  |  | $ | 1,141,707 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $675 and $674, respectively |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Accounts payable |  |  | 80,003 |  |  |  | 99,724 |  |
| Accrued compensation and benefits |  |  | 51,997 |  |  |  | 71,367 |  |
| Accrued warranty |  |  | 12,164 |  |  |  | 12,322 |  |
| Current portion, operating lease liabilities |  |  | 10,783 |  |  |  | 10,847 |  |
| Current portion, deferred revenue |  |  | 292,925 |  |  |  | 282,475 |  |
| Other accrued liabilities |  |  | 71,521 |  |  |  | 64,440 |  |
| Total current liabilities |  |  | 528,718 |  |  |  | 575,501 |  |
| Deferred revenue, less current portion |  |  | 232,500 |  |  |  | 219,024 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $2,239 and $2,409, respectively |  |  | 185,261 |  |  |  | 187,591 |  |
| Operating lease liabilities, less current portion |  |  | 40,718 |  |  |  | 31,845 |  |
| Deferred income taxes |  |  | 7,673 |  |  |  | 7,747 |  |
| Other long-term liabilities |  |  | 3,162 |  |  |  | 3,247 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 146,264 and 143,629 shares issued, respectively; 129,530 and 127,775 shares outstanding, respectively |  |  | 146 |  |  |  | 144 |  |
| Additional paid-in-capital |  |  | 1,164,589 |  |  |  | 1,173,744 |  |
| Accumulated other comprehensive loss |  |  | (16,096 | ) |  |  | (13,192 | ) |
| Accumulated deficit |  |  | (827,322 | ) |  |  | (855,998 | ) |
| Treasury stock at cost, 16,734 and 15,854 shares, respectively |  |  | (212,835 | ) |  |  | (187,946 | ) |
| Total stockholders’ equity |  |  | 108,482 |  |  |  | 116,752 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,106,514 |  |  | $ | 1,141,707 |  |

[0000950170-23-057125:8k_2_02:71]
EXTREME NETWORKS, INC.

[0000950170-23-057125:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-057125:8k_2_02:73]
(In thousands, except per share amounts)

[0000950170-23-057125:8k_2_02:74]
(Unaudited)

[0000950170-23-057125:8k_2_02:75]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Net revenues: |  |  |  |  |  |  |
| Product |  | $ | 253,483 |  |  | $ | 206,276 |  |
| Subscription and support |  |  | 99,654 |  |  |  | 91,413 |  |
| Total net revenues |  |  | 353,137 |  |  |  | 297,689 |  |
| Cost of revenues: |  |  |  |  |  |  |
| Product |  |  | 108,536 |  |  |  | 99,763 |  |
| Subscription and support |  |  | 31,665 |  |  |  | 31,218 |  |
| Total cost of revenues |  |  | 140,201 |  |  |  | 130,981 |  |
| Gross profit: |  |  |  |  |  |  |
| Product |  |  | 144,947 |  |  |  | 106,513 |  |
| Subscription and support |  |  | 67,989 |  |  |  | 60,195 |  |
| Total gross profit |  |  | 212,936 |  |  |  | 166,708 |  |
| Operating expenses: |  |  |  |  |  |  |
| Research and development |  |  | 58,016 |  |  |  | 50,989 |  |
| Sales and marketing |  |  | 91,920 |  |  |  | 78,382 |  |
| General and administrative |  |  | 23,873 |  |  |  | 18,547 |  |
| Acquisition and integration costs |  |  | — |  |  |  | 390 |  |
| Restructuring and related charges |  |  | 2,717 |  |  |  | 481 |  |
| Amortization of intangible assets |  |  | 511 |  |  |  | 523 |  |
| Total operating expenses |  |  | 177,037 |  |  |  | 149,312 |  |
| Operating income |  |  | 35,899 |  |  |  | 17,396 |  |
| Interest income |  |  | 1,226 |  |  |  | 392 |  |
| Interest expense |  |  | (4,318 | ) |  |  | (3,826 | ) |
| Other income, net |  |  | 432 |  |  |  | 371 |  |
| Income before income taxes |  |  | 33,239 |  |  |  | 14,333 |  |
| Provision for income taxes |  |  | 4,563 |  |  |  | 1,748 |  |
| Net income |  | $ | 28,676 |  |  | $ | 12,585 |  |
| Basic and diluted income per share: |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.22 |  |  | $ | 0.10 |  |
| Net income per share – diluted |  | $ | 0.21 |  |  | $ | 0.09 |  |
| Shares used in per share calculation – basic |  |  | 128,782 |  |  |  | 130,289 |  |
| Shares used in per share calculation – diluted |  |  | 133,463 |  |  |  | 132,933 |  |

[0000950170-23-057125:8k_2_02:76]
EXTREME NETWORKS, INC.

[0000950170-23-057125:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-23-057125:8k_2_02:78]
(In thousands)

[0000950170-23-057125:8k_2_02:79]
(Unaudited)

[0000950170-23-057125:8k_2_02:80]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 28,676 |  |  | $ | 12,585 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 4,865 |  |  |  | 4,953 |  |
| Amortization of intangible assets |  |  | 1,944 |  |  |  | 4,128 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 2,931 |  |  |  | 3,063 |  |
| Provision for doubtful accounts |  |  | 75 |  |  |  | 23 |  |
| Share-based compensation |  |  | 19,919 |  |  |  | 13,789 |  |
| Deferred income taxes |  |  | (65 | ) |  |  | (85 | ) |
| Non-cash interest expense |  |  | 266 |  |  |  | 552 |  |
| Other |  |  | (144 | ) |  |  | (3,595 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable |  |  | 50,459 |  |  |  | 25,347 |  |
| Inventories |  |  | (11,946 | ) |  |  | (2,671 | ) |
| Prepaid expenses and other assets |  |  | (6,841 | ) |  |  | (318 | ) |
| Accounts payable |  |  | (20,097 | ) |  |  | (591 | ) |
| Accrued compensation and benefits |  |  | (19,488 | ) |  |  | (6,564 | ) |
| Operating lease liabilities |  |  | (3,297 | ) |  |  | (3,952 | ) |
| Deferred revenue |  |  | 21,978 |  |  |  | 9,699 |  |
| Other current and long-term liabilities |  |  | 6,400 |  |  |  | (6,629 | ) |
| Net cash provided by operating activities |  |  | 75,635 |  |  |  | 49,734 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures |  |  | (4,314 | ) |  |  | (3,139 | ) |
| Net cash used in investing activities |  |  | (4,314 | ) |  |  | (3,139 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Payments on revolving facility |  |  | (25,000 | ) |  |  | — |  |
| Payments on debt obligations |  |  | (2,500 | ) |  |  | (37,125 | ) |
| Repurchase of common stock |  |  | (24,889 | ) |  |  | — |  |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (29,072 | ) |  |  | (3,999 | ) |
| Deferred payments on an acquisition |  |  | — |  |  |  | (1,000 | ) |
| Net cash used in financing activities |  |  | (81,461 | ) |  |  | (42,124 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (252 | ) |  |  | (649 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (10,392 | ) |  |  | 3,822 |  |
| Cash and cash equivalents at beginning of period |  |  | 234,826 |  |  |  | 194,522 |  |
| Cash and cash equivalents at end of period |  | $ | 224,434 |  |  | $ | 198,344 |  |

[0000950170-23-057125:8k_2_02:81]
Extreme Networks, Inc.

[0000950170-23-057125:8k_2_02:82]
Non-GAAP Measures of Financial Performance

[0000950170-23-057125:8k_2_02:83]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net cash (debt) and non-GAAP free cash flow.

[0000950170-23-057125:8k_2_02:84]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0000950170-23-057125:8k_2_02:85]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0000950170-23-057125:8k_2_02:86]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0000950170-23-057125:8k_2_02:87]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0000950170-23-057125:8k_2_02:88]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0000950170-23-057125:8k_2_02:89]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0000950170-23-057125:8k_2_02:90]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, and legal and professional fees related to the acquisition of Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0000950170-23-057125:8k_2_02:91]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0000950170-23-057125:8k_2_02:92]
Restructuring charges. Restructuring charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0000950170-23-057125:8k_2_02:93]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution and our configure, price, quote solution. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency making it difficult to contribute to a meaningful evaluation of our operating performance.

[0000950170-23-057125:8k_2_02:94]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for a non-recurring pending litigation.

[0000950170-23-057125:8k_2_02:95]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0000950170-23-057125:8k_2_02:96]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0000950170-23-057125:8k_2_02:97]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries, which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which performs research and development activities, as well as the Company’s Irish trading subsidiaries.

[0000950170-23-057125:8k_2_02:98]
EXTREME NETWORKS, INC.

[0000950170-23-057125:8k_2_02:99]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-057125:8k_2_02:100]
GAAP TO NON-GAAP RECONCILIATION

[0000950170-23-057125:8k_2_02:101]
(In thousands, except percentages and per share amounts)

[0000950170-23-057125:8k_2_02:102]
(Unaudited)

[0000950170-23-057125:8k_2_02:103]
| Revenues | Three Months Ended |
|  | September 30,2023 |  | September 30,2022 |  |
| Revenues – GAAP | $353,137 |  | $297,689 |  |

[0000950170-23-057125:8k_2_02:104]
| Non-GAAP Gross Margin | Three Months Ended |
|  | September 30,2023 |  |  | September 30,2022 |  |  |
| Gross profit – GAAP | $ | 212,936 |  |  | $ | 166,708 |  |  |
| Gross margin – GAAP percentage |  | 60.3 | % |  |  | 56.0 | % |  |
| Adjustments: |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 483 |  |  |  | 374 |  |  |
| Share-based compensation expense, Subscription and support |  | 866 |  |  |  | 672 |  |  |
| Amortization of intangibles, Product |  | 1,144 |  |  |  | 2,772 |  |  |
| Amortization of intangibles, Subscription and support |  | 272 |  |  |  | 815 |  |  |
| Total adjustments to GAAP gross profit | $ | 2,765 |  |  | $ | 4,633 |  |  |
| Gross profit – non-GAAP | $ | 215,701 |  |  | $ | 171,341 |  |  |
| Gross margin – non-GAAP percentage |  | 61.1 | % |  |  | 57.6 | % |  |

[0000950170-23-057125:8k_2_02:105]
| Non-GAAP Operating Income | Three Months Ended |
|  | September 30,2023 |  |  | September 30,2022 |  |  |
| GAAP operating income | $ | 35,899 |  |  | $ | 17,396 |  |  |
| GAAP operating income percentage |  | 10.2 | % |  |  | 5.8 | % |  |
| Adjustments: |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,349 |  |  |  | 1,046 |  |  |
| Share-based compensation expense, R&D |  | 4,377 |  |  |  | 3,090 |  |  |
| Share-based compensation expense, S&M |  | 6,988 |  |  |  | 4,639 |  |  |
| Share-based compensation expense, G&A |  | 7,205 |  |  |  | 5,014 |  |  |
| Acquisition and integration costs |  | — |  |  |  | 390 |  |  |
| Restructuring charges |  | 2,717 |  |  |  | 481 |  |  |
| Litigation charges |  | 1,460 |  |  |  | — |  |  |
| System transition costs |  | 569 |  |  |  | — |  |  |
| Amortization of intangibles |  | 1,927 |  |  |  | 4,110 |  |  |
| Total adjustments to GAAP operating income |  | 26,592 |  |  |  | 18,770 |  |  |
| Non-GAAP operating income | $ | 62,491 |  |  | $ | 36,166 |  |  |
| Non-GAAP operating income percentage |  | 17.7 | % |  |  | 12.1 | % |  |

[0000950170-23-057125:8k_2_02:106]
| Non-GAAP Net Income | Three Months Ended |
|  | September 30,2023 |  |  | September 30,2022 |  |  |
| GAAP net income | $ | 28,676 |  |  | $ | 12,585 |  |  |
| Adjustments: |  |  |  |  |  |  |
| Share-based compensation expense |  | 19,919 |  |  |  | 13,789 |  |  |
| Acquisition and integration costs |  | — |  |  |  | 390 |  |  |
| Restructuring charge, net of reversal |  | 2,717 |  |  |  | 481 |  |  |
| Litigation charges |  | 1,460 |  |  |  | — |  |  |
| System transition costs |  | 569 |  |  |  | — |  |  |
| Amortization of intangibles |  | 1,927 |  |  |  | 4,110 |  |  |
| Tax effect of non-GAAP adjustments |  | (8,728 | ) |  |  | (4,268 | ) |  |
| Total adjustments to GAAP net income | $ | 17,864 |  |  | $ | 14,502 |  |  |
| Non-GAAP net income | $ | 46,540 |  |  | $ | 27,087 |  |  |
| Earnings per share |  |  |  |  |  |  |
| GAAP net income per share – diluted | $ | 0.21 |  |  | $ | 0.09 |  |  |
| Non-GAAP net income per share – diluted | $ | 0.35 |  |  | $ | 0.20 |  |  |
| Shares used in net income per share – diluted: |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 128,782 |  |  |  | 130,289 |  |  |
| Potentially dilutive equity awards |  | 4,681 |  |  |  | 2,644 |  |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 133,463 |  |  |  | 132,933 |  |  |
