# EXTR note change history — 0000950170-23-015282 → 0000950170-23-058245


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000950170-23-058245:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2023, the Company had commitments to purchase $94.7 million of inventory.
  (was, 2023-04-27, similarity 0.9885):
[0000950170-23-015282:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2023, the Company had commitments to purchase $56.8 million of inventory.

- added (2023-11-02):
[0000950170-23-058245:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2023-11-02):
[0000950170-23-058245:note_history:3]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.
  (was, 2023-04-27, similarity 0.8126):
[0000950170-23-015282:note_history:3]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.

- changed (2023-11-02):
[0000950170-23-058245:note_history:4]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and the matter is proceeding through the appellate process.
  (was, 2023-04-27, similarity 0.7284):
[0000950170-23-015282:note_history:4]
a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal.

- changed (2023-11-02):
[0000950170-23-058245:note_history:5]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021 and a hearing date has been set for November 20, 2024.
  (was, 2023-04-27, similarity 0.7751):
[0000950170-23-015282:note_history:5]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. This matter is still pending.

- removed (2023-11-02):
[0000950170-23-015282:note_history:6]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The

- removed (2023-11-02):
[0000950170-23-015282:note_history:7]
Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- removed (2023-11-02):
[0000950170-23-015282:note_history:8]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

- removed (2023-11-02):
[0000950170-23-015282:note_history:9]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and the Company and other defendants filed a response brief on November 7, 2022.

- removed (2023-11-02):
[0000950170-23-015282:note_history:10]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000950170-23-058245:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2023. The results of operations for the three months ended September 30, 2023 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.
  (was, 2023-04-27, similarity 0.6824):
[0000950170-23-015282:note_history:11]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2023. The results of operations for the three and nine months ended March 31, 2023 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-11-02):
[0000950170-23-058245:note_history:12]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.

- removed (2023-11-02):
[0000950170-23-015282:note_history:13]
In December 2022, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which extends the period of time entities can utilize the reference rate reform relief guidance under ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting from December 31, 2022 to December 31, 2024. Upon issuance of ASU 2020-04, the Company elected to apply certain of the optional expedients for contract modifications to its financial instruments impacted by the London Interbank Offered Rate (“LIBOR”) discontinuance. The Company expects to continue to elect various optional expedients for contract modifications to the Company’s financial instruments affected by the reference rate reform through the effective date of December 31, 2024, as extended by ASU 2022-06. The application of this guidance did not have any impact on our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000950170-23-058245:note_history:14]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 187,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,239 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 185,261 |  |  |  | 187,591 |  |
| Total debt |  | $ | 194,586 |  |  | $ | 221,917 |  |
  (was, 2023-04-27, similarity 0.9471):
[0000950170-23-015282:note_history:14]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,128 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,872 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 199,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (812 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 198,188 |  |  |  | 270,570 |  |
| Total debt |  | $ | 234,060 |  |  | $ | 303,919 |  |

- changed (2023-11-02):
[0000950170-23-058245:note_history:15]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.
  (was, 2023-04-27, similarity 0.9429):
[0000950170-23-015282:note_history:15]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

- added (2023-11-02):
[0000950170-23-058245:note_history:16]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance its debt. On July 7, 2023 the Company made a payment of $25.0 million to pay off the outstanding revolving credit balance.

- added (2023-11-02):
[0000950170-23-058245:note_history:17]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

- changed (2023-11-02):
[0000950170-23-058245:note_history:18]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the three months ended September 30, 2023, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.
  (was, 2023-04-27, similarity 0.8645):
[0000950170-23-015282:note_history:18]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

- changed (2023-11-02):
[0000950170-23-058245:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended September 30, 2023 and 2022, respectively. The interest rate as of September 30, 2023 was 7.45% and as of September 30, 2022 was 4.50%.
  (was, 2023-04-27, similarity 0.8303):
[0000950170-23-015282:note_history:19]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million each for the three months ended March 31, 2023 and 2022 and totaled $2.2 million and $2.3 million for the nine months ended March 31, 2023 and 2022, respectively. The interest rate as of March 31, 2023 was 5.97% and as of March 31, 2022 was 2.07%.

- added (2023-11-02):
[0000950170-23-058245:note_history:20]
As of September 30, 2023, the Company did not have any outstanding balance against its 2023 Revolving Facility’s outstanding balance. The Company had $135.5 million of availability under the 2023 Revolving Facility as of September 30, 2023. During the three months ended September 30, 2023 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the three months ended September 30, 2022 the Company made an additional payment of $30.0 million, against its term loan facility under the 2019 Credit Agreement.

- changed (2023-11-02):
[0000950170-23-058245:note_history:21]
The Company had $14.5 million of outstanding letters of credit as of September 30, 2023.
  (was, 2023-04-27, similarity 0.9351):
[0000950170-23-015282:note_history:21]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2023.

- removed (2023-11-02):
[0000950170-23-015282:note_history:22]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the acquisition of Aerohive Networks, Inc. and for working capital and general corporate purposes.

- removed (2023-11-02):
[0000950170-23-015282:note_history:23]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly

- removed (2023-11-02):
[0000950170-23-015282:note_history:24]
(currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

- removed (2023-11-02):
[0000950170-23-015282:note_history:25]
On April 8, 2020, the Company entered into an amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into a second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required the Company to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

- removed (2023-11-02):
[0000950170-23-015282:note_history:26]
On November 3, 2020, the Company and its lenders entered into a Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into a fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

- removed (2023-11-02):
[0000950170-23-015282:note_history:27]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three and nine months ended March 31, 2023, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.

- removed (2023-11-02):
[0000950170-23-015282:note_history:28]
As of March 31, 2023, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance. The Company had $60.2 million of availability under the 2019 Revolving Facility as of March 31, 2023. During the nine months ended March 31, 2023 and 2022, the Company made an additional payment of $45.5 million and $12.0 million, respectively, against its term loan facility, respectively.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000950170-23-058245:note_history:29]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 187,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,239 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 185,261 |  |  |  | 187,591 |  |
| Total debt |  | $ | 194,586 |  |  | $ | 221,917 |  |
  (was, 2023-04-27, similarity 0.9471):
[0000950170-23-015282:note_history:29]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,128 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,872 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 199,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (812 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 198,188 |  |  |  | 270,570 |  |
| Total debt |  | $ | 234,060 |  |  | $ | 303,919 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000950170-23-058245:note_history:30]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 117,801 |  | $ | 64,951 |  | $ | 182,752 |  |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |
| Other |  |  | 2,531 |  |  | 10,366 |  |  | 12,897 |  |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |
| Total Americas |  |  | 120,332 |  |  | 75,317 |  |  | 195,649 |  |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |
| EMEA |  |  | 102,311 |  |  | 41,292 |  |  | 143,603 |  |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |
| APAC |  |  | 111 |  |  | 13,774 |  |  | 13,885 |  |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |
| Total net revenues |  | $ | 222,754 |  | $ | 130,383 |  | $ | 353,137 |  |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |
  (was, 2023-04-27, similarity 0.9657):
[0000950170-23-015282:note_history:30]
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |
| Other |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |
| Total Americas |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |
| EMEA |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |
| APAC |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |
| Total net revenues |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |

- removed (2023-11-02):
[0000950170-23-015282:note_history:31]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |
| Other |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |
| Total Americas |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |
| EMEA |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |
| APAC |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |
| Total net revenues |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000950170-23-058245:note_history:32]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products,  SaaS, and
  (was, 2023-04-27, similarity 0.6128):
[0000950170-23-015282:note_history:32]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606). The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

- added (2023-11-02):
[0000950170-23-058245:note_history:33]
maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

- changed (2023-11-02):
[0000950170-23-058245:note_history:34]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2023-04-27, similarity 0.9648):
[0000950170-23-015282:note_history:34]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2023-11-02):
[0000950170-23-058245:note_history:35]
On September 30, 2023, the Company had $525.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 46% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 26% in fiscal 2025 and 28% of the balance thereafter.

- changed (2023-11-02):
[0000950170-23-058245:note_history:36]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.
  (was, 2023-04-27, similarity 0.9873):
[0000950170-23-015282:note_history:36]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

- changed (2023-11-02):
[0000950170-23-058245:note_history:37]
Revenue recognized for the three months ended September 30, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $89.7 million and $80.0 million, respectively.
  (was, 2023-04-27, similarity 0.6444):
[0000950170-23-015282:note_history:37]
Revenue recognized for the three months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $81.0 million and $77.3 million, respectively. Revenue recognized for the nine months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $193.7 million and $176.1 million, respectively.

- changed (2023-11-02):
[0000950170-23-058245:note_history:38]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $21.3 million and $20.0 million at September 30, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2023 and 2022, was $2.6 million and $2.1 million, respectively.
  (was, 2023-04-27, similarity 0.9246):
[0000950170-23-015282:note_history:38]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $18.2 million and $16.3 million at March 31, 2023 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2023 and 2022, was $2.3 million and $1.9 million, respectively. Amortization recognized during the nine months ended March 31, 2023 and 2022, was $6.7 million and $5.5 million, respectively.

- changed (2023-11-02):
[0000950170-23-058245:note_history:39]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 117,801 |  | $ | 64,951 |  | $ | 182,752 |  |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |
| Other |  |  | 2,531 |  |  | 10,366 |  |  | 12,897 |  |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |
| Total Americas |  |  | 120,332 |  |  | 75,317 |  |  | 195,649 |  |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |
| EMEA |  |  | 102,311 |  |  | 41,292 |  |  | 143,603 |  |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |
| APAC |  |  | 111 |  |  | 13,774 |  |  | 13,885 |  |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |
| Total net revenues |  | $ | 222,754 |  | $ | 130,383 |  | $ | 353,137 |  |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |
  (was, 2023-04-27, similarity 0.9657):
[0000950170-23-015282:note_history:39]
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |
| Other |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |
| Total Americas |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |
| EMEA |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |
| APAC |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |
| Total net revenues |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |

- added (2023-11-02):
[0000950170-23-058245:note_history:40]
For the three months ended September 30, 2023, the Company generated 14% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of its revenue for the three months ended September 30, 2023. For the three months ended September 30, 2022, no foreign country accounted for 10% or more of its revenue.

- changed (2023-11-02):
[0000950170-23-058245:note_history:41]
|  |  | Three Months Ended |
|  |  | September 30,2023 |  | September 30,2022 |
| Jenne, Inc. |  | 27% |  | 13% |
| Westcon Group, Inc. |  | 25% |  | 15% |
| TD Synnex Corporation |  | 18% |  | 19% |
  (was, 2023-04-27, similarity 0.6969):
[0000950170-23-015282:note_history:41]
|  |  | March 31,2023 |  | June 30,2022 |
| Jenne, Inc. |  | 25% |  | 28% |
| Westcon Group, Inc. |  | 21% |  | * |
| TD Synnex Corporation |  | * |  | 11% |
| * Less than 10% of accounts receivable. |  |  |  |  |

- changed (2023-11-02):
[0000950170-23-058245:note_history:42]
The following table sets forth major customers accounting for 10% or more of the Company’s net accounts receivable balance:
  (was, 2023-04-27, similarity 0.9573):
[0000950170-23-015282:note_history:42]
The following table sets forth customers accounting for 10% or more of the Company’s accounts receivable balance:

- added (2023-11-02):
[0000950170-23-058245:note_history:43]
|  |  | September 30,2023 |  | June 30,2023 |
| Jenne, Inc. |  | 75% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| * Less than 10% of accounts receivable |  |  |  |  |

- added (2023-11-02):
[0000950170-23-058245:note_history:44]
The majority of the Company's net accounts receivable balance with Jenne, Inc. as of September 30, 2023 is current and the Company expects to collect this balance by December 31, 2023.

- removed (2023-11-02):
[0000950170-23-015282:note_history:45]
On March 31, 2023, the Company had $464.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 20% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 44% in fiscal 2024 and 36% of the balance thereafter.

- removed (2023-11-02):
[0000950170-23-015282:note_history:46]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |
| Other |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |
| Total Americas |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |
| EMEA |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |
| APAC |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |
| Total net revenues |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |

- removed (2023-11-02):
[0000950170-23-015282:note_history:47]
For three and nine months ended March 31, 2023 the Company generated 17% and 12% of its revenues from the Netherlands, respectively. For the three and nine months ended March 31, 2022 the Company generated 18% and 12% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2023 and 2022.

- removed (2023-11-02):
[0000950170-23-015282:note_history:48]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2023 |  | March 31,2022 |  | March 31,2023 |  | March 31,2022 |
| Westcon Group, Inc. |  | 25% |  | 25% |  | 20% |  | 18% |
| TD Synnex Corporation |  | 19% |  | 17% |  | 19% |  | 20% |
| Jenne, Inc. |  | 15% |  | 20% |  | 14% |  | 17% |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-02):
[0000950170-23-058245:note_history:49]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2023-04-27, similarity 0.9648):
[0000950170-23-015282:note_history:49]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2023-11-02):
[0000950170-23-058245:note_history:50]
On September 30, 2023, the Company had $525.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 46% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 26% in fiscal 2025 and 28% of the balance thereafter.

- changed (2023-11-02):
[0000950170-23-058245:note_history:51]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.
  (was, 2023-04-27, similarity 0.9873):
[0000950170-23-015282:note_history:51]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

- changed (2023-11-02):
[0000950170-23-058245:note_history:52]
Revenue recognized for the three months ended September 30, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $89.7 million and $80.0 million, respectively.
  (was, 2023-04-27, similarity 0.6444):
[0000950170-23-015282:note_history:52]
Revenue recognized for the three months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $81.0 million and $77.3 million, respectively. Revenue recognized for the nine months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $193.7 million and $176.1 million, respectively.

- changed (2023-11-02):
[0000950170-23-058245:note_history:53]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $21.3 million and $20.0 million at September 30, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2023 and 2022, was $2.6 million and $2.1 million, respectively.
  (was, 2023-04-27, similarity 0.9246):
[0000950170-23-015282:note_history:53]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $18.2 million and $16.3 million at March 31, 2023 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2023 and 2022, was $2.3 million and $1.9 million, respectively. Amortization recognized during the nine months ended March 31, 2023 and 2022, was $6.7 million and $5.5 million, respectively.

- changed (2023-11-02):
[0000950170-23-058245:note_history:54]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 117,801 |  | $ | 64,951 |  | $ | 182,752 |  |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |
| Other |  |  | 2,531 |  |  | 10,366 |  |  | 12,897 |  |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |
| Total Americas |  |  | 120,332 |  |  | 75,317 |  |  | 195,649 |  |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |
| EMEA |  |  | 102,311 |  |  | 41,292 |  |  | 143,603 |  |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |
| APAC |  |  | 111 |  |  | 13,774 |  |  | 13,885 |  |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |
| Total net revenues |  | $ | 222,754 |  | $ | 130,383 |  | $ | 353,137 |  |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |
  (was, 2023-04-27, similarity 0.9657):
[0000950170-23-015282:note_history:54]
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |
| Other |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |
| Total Americas |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |
| EMEA |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |
| APAC |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |
| Total net revenues |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |

- added (2023-11-02):
[0000950170-23-058245:note_history:55]
For the three months ended September 30, 2023, the Company generated 14% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of its revenue for the three months ended September 30, 2023. For the three months ended September 30, 2022, no foreign country accounted for 10% or more of its revenue.

- removed (2023-11-02):
[0000950170-23-015282:note_history:56]
On March 31, 2023, the Company had $464.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 20% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 44% in fiscal 2024 and 36% of the balance thereafter.

- removed (2023-11-02):
[0000950170-23-015282:note_history:57]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |
| Other |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |
| Total Americas |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |
| EMEA |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |
| APAC |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |
| Total net revenues |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |

- removed (2023-11-02):
[0000950170-23-015282:note_history:58]
For three and nine months ended March 31, 2023 the Company generated 17% and 12% of its revenues from the Netherlands, respectively. For the three and nine months ended March 31, 2022 the Company generated 18% and 12% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2023 and 2022.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-11-02):
[0000950170-23-058245:note_history:59]
16. Subsequent Events

- added (2023-11-02):
[0000950170-23-058245:note_history:60]
In October 2023, the Company initiated an additional global reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with our business and strategic priorities while reducing its operating expenses (the “2024 Plan”). The Company is currently evaluating the timing and impact of this reduction-in-force on the Company's business, financial condition and results of operations for the year ending June 30, 2024.
