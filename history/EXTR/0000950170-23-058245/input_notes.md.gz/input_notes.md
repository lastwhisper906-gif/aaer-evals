# EXTR notes — 0000950170-23-058245


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-23-058245:notes:1]
[same as prior period, unchanged from 0000950170-23-015282:notes:1]

[0000950170-23-058245:notes:2]
[same as prior period, unchanged from 0000950170-23-015282:notes:2]

[0000950170-23-058245:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2023 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2023.

[0000950170-23-058245:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2023. The results of operations for the three months ended September 30, 2023 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.

[0000950170-23-058245:notes:5]
[same as prior period, unchanged from 0000950170-23-015282:notes:5]

[0000950170-23-058245:notes:6]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2024” represent the fiscal year ending June 30, 2024. All references herein to “fiscal 2023” represent the fiscal year ended June 30, 2023.

[0000950170-23-058245:notes:7]
[same as prior period, unchanged from 0000950170-23-015282:notes:7]

[0000950170-23-058245:notes:8]
[same as prior period, unchanged from 0000950170-23-015282:notes:8]

[0000950170-23-058245:notes:9]
[same as prior period, unchanged from 0000950170-23-015282:notes:9]

[0000950170-23-058245:notes:10]
[same as prior period, unchanged from 0000950170-23-015282:notes:10]

[0000950170-23-058245:notes:11]
[same as prior period, unchanged from 0000950170-23-015282:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-23-058245:notes:12]
[same as prior period, unchanged from 0000950170-23-015282:notes:12]

[0000950170-23-058245:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2023. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0000950170-23-058245:notes:14]
Recently Adopted Accounting Pronouncements

[0000950170-23-058245:notes:15]
There were no recently adopted accounting standards which would have a material effect on our condensed consolidated financial statements and accompanying disclosures, and no recently issued accounting standards that are expected to have a material impact on our condensed consolidated financial statements and accompanying disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-058245:notes:16]
[same as prior period, unchanged from 0000950170-23-015282:notes:16]

[0000950170-23-058245:notes:17]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts with Customers (Topic 606). The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products,  SaaS, and

[0000950170-23-058245:notes:18]
maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0000950170-23-058245:notes:19]
[same as prior period, unchanged from 0000950170-23-015282:notes:18]

[0000950170-23-058245:notes:20]
[same as prior period, unchanged from 0000950170-23-015282:notes:19]

[0000950170-23-058245:notes:21]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0000950170-23-058245:notes:22]
On September 30, 2023, the Company had $525.4 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 46% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 26% in fiscal 2025 and 28% of the balance thereafter.

[0000950170-23-058245:notes:23]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenues. These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0000950170-23-058245:notes:24]
Revenue recognized for the three months ended September 30, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $89.7 million and $80.0 million, respectively.

[0000950170-23-058245:notes:25]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $21.3 million and $20.0 million at September 30, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2023 and 2022, was $2.6 million and $2.1 million, respectively.

[0000950170-23-058245:notes:26]
[same as prior period, unchanged from 0000950170-23-015282:notes:25]

[0000950170-23-058245:notes:27]
[same as prior period, unchanged from 0000950170-23-015282:notes:26]

[0000950170-23-058245:notes:28]
[same as prior period, unchanged from 0000950170-23-015282:notes:27]

[0000950170-23-058245:notes:29]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 117,801 |  | $ | 64,951 |  | $ | 182,752 |  |  | $ | 73,314 |  | $ | 64,312 |  | $ | 137,626 |  |
| Other |  |  | 2,531 |  |  | 10,366 |  |  | 12,897 |  |  |  | 16,025 |  |  | 4,098 |  |  | 20,123 |  |
| Total Americas |  |  | 120,332 |  |  | 75,317 |  |  | 195,649 |  |  |  | 89,339 |  |  | 68,410 |  |  | 157,749 |  |
| EMEA |  |  | 102,311 |  |  | 41,292 |  |  | 143,603 |  |  |  | 76,256 |  |  | 39,253 |  |  | 115,509 |  |
| APAC |  |  | 111 |  |  | 13,774 |  |  | 13,885 |  |  |  | 2,038 |  |  | 22,393 |  |  | 24,431 |  |
| Total net revenues |  | $ | 222,754 |  | $ | 130,383 |  | $ | 353,137 |  |  | $ | 167,633 |  | $ | 130,056 |  | $ | 297,689 |  |

[0000950170-23-058245:notes:30]
For the three months ended September 30, 2023, the Company generated 14% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of its revenue for the three months ended September 30, 2023. For the three months ended September 30, 2022, no foreign country accounted for 10% or more of its revenue.

[0000950170-23-058245:notes:31]
[same as prior period, unchanged from 0000950170-23-015282:notes:31]

[0000950170-23-058245:notes:32]
[same as prior period, unchanged from 0000950170-23-015282:notes:32]

[0000950170-23-058245:notes:33]
[same as prior period, unchanged from 0000950170-23-015282:notes:33]

[0000950170-23-058245:notes:34]
|  |  | Three Months Ended |
|  |  | September 30,2023 |  | September 30,2022 |
| Jenne, Inc. |  | 27% |  | 13% |
| Westcon Group, Inc. |  | 25% |  | 15% |
| TD Synnex Corporation |  | 18% |  | 19% |

[0000950170-23-058245:notes:35]
The following table sets forth major customers accounting for 10% or more of the Company’s net accounts receivable balance:

[0000950170-23-058245:notes:36]
|  |  | September 30,2023 |  | June 30,2023 |
| Jenne, Inc. |  | 75% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| * Less than 10% of accounts receivable |  |  |  |  |

[0000950170-23-058245:notes:37]
The majority of the Company's net accounts receivable balance with Jenne, Inc. as of September 30, 2023 is current and the Company expects to collect this balance by December 31, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-23-058245:notes:38]
4.
Balance Sheet Accounts

[0000950170-23-058245:notes:39]
Cash and Cash equivalents

[0000950170-23-058245:notes:40]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents.

[0000950170-23-058245:notes:41]
The following table summarizes the Company's cash and cash equivalents (in thousands):

[0000950170-23-058245:notes:42]
|  |  | September 30,2023 |  | June 30,2023 |
| Cash |  | $218,851 |  | $227,675 |
| Cash equivalents |  | 5,583 |  | 7,151 |
| Total cash and cash equivalents |  | $224,434 |  | $234,826 |

[0000950170-23-058245:notes:43]
[same as prior period, unchanged from 0000950170-23-015282:notes:49]

[0000950170-23-058245:notes:44]
Inventories are stated at the lower of cost, or net realizable value. Extreme uses a standard cost methodology to determine the cost basis for its inventories. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company adjusts the carrying value of its inventory when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0000950170-23-058245:notes:45]
The following table summarizes the Company's inventory by category (in thousands):

[0000950170-23-058245:notes:46]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Finished goods |  | $ | 93,711 |  |  | $ | 78,180 |  |
| Raw materials |  |  | 7,112 |  |  |  | 10,844 |  |
| Total inventories |  | $ | 100,823 |  |  | $ | 89,024 |  |

[0000950170-23-058245:notes:47]
[same as prior period, unchanged from 0000950170-23-015282:notes:53]

[0000950170-23-058245:notes:48]
The following table summarizes the Company's property and equipment, net by category (in thousands):

[0000950170-23-058245:notes:49]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Computers and equipment |  | $ | 82,174 |  |  | $ | 81,612 |  |
| Purchased software |  |  | 52,629 |  |  |  | 51,444 |  |
| Office equipment, furniture and fixtures |  |  | 8,830 |  |  |  | 8,899 |  |
| Leasehold improvements |  |  | 50,495 |  |  |  | 48,943 |  |
| Total property and equipment |  |  | 194,128 |  |  |  | 190,898 |  |
| Less: accumulated depreciation and amortization |  |  | (147,792 | ) |  |  | (144,450 | ) |
| Property and equipment, net |  | $ | 46,336 |  |  | $ | 46,448 |  |

[0000950170-23-058245:notes:50]
[same as prior period, unchanged from 0000950170-23-015282:notes:56]

[0000950170-23-058245:notes:51]
Deferred revenue represents invoiced amounts for deferred maintenance, SaaS, and other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0000950170-23-058245:notes:52]
[same as prior period, unchanged from 0000950170-23-015282:notes:58]

[0000950170-23-058245:notes:53]
[same as prior period, unchanged from 0000950170-23-015282:notes:59]

[0000950170-23-058245:notes:54]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0000950170-23-058245:notes:55]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Balance beginning of period |  | $ | 12,322 |  |  | $ | 10,852 |  |
| New warranties issued |  |  | 3,674 |  |  |  | 4,008 |  |
| Warranty expenditures |  |  | (3,832 | ) |  |  | (3,338 | ) |
| Balance end of period |  | $ | 12,164 |  |  | $ | 11,522 |  |

[0000950170-23-058245:notes:56]
To facilitate sales of its products in the normal course of business, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from intellectual property infringement and certain other losses. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0000950170-23-058245:notes:57]
[same as prior period, unchanged from 0000950170-23-015282:notes:63]

[0000950170-23-058245:notes:58]
[same as prior period, unchanged from 0000950170-23-015282:notes:64]


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-23-058245:notes:59]
5.
Fair Value Measurements

[0000950170-23-058245:notes:60]
[same as prior period, unchanged from 0000950170-23-015282:notes:66]

[0000950170-23-058245:notes:61]
[same as prior period, unchanged from 0000950170-23-015282:notes:67]

[0000950170-23-058245:notes:62]
[same as prior period, unchanged from 0000950170-23-015282:notes:68]

[0000950170-23-058245:notes:63]
[same as prior period, unchanged from 0000950170-23-015282:notes:69]

[0000950170-23-058245:notes:64]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at September 30, 2023 and June 30, 2023 (in thousands).

[0000950170-23-058245:notes:65]
| September 30, 2023 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 5,583 |  |  | $ | — |  |  | $ | 5,583 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 13 |  |  |  | — |  |  |  | 13 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 5,596 |  |  | $ | — |  |  | $ | 5,596 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |

[0000950170-23-058245:notes:66]
| June 30, 2023 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 7,151 |  |  | $ | — |  |  | $ | 7,151 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 31 |  |  |  | — |  |  |  | 31 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 7,182 |  |  | $ | — |  |  | $ | 7,182 |  |

[0000950170-23-058245:notes:67]
[same as prior period, unchanged from 0000950170-23-015282:notes:73]

[0000950170-23-058245:notes:68]
The Company's level 2 assets consist of certificates of deposit and derivative instruments. Certificates of deposit do not have regular market pricing and are considered Level 2. The fair value of derivative instruments under the Company’s foreign exchange forward contracts are estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.

[0000950170-23-058245:notes:69]
As of September 30, 2023 and June 30, 2023, the Company had investment in certificates of deposit of $5.6 million and $7.2 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed

[0000950170-23-058245:notes:70]
consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of September 30, 2023 and June 30, 2023, their fair value approximated their amortized cost.

[0000950170-23-058245:notes:71]
As of September 30, 2023 and June 30, 2023, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $18.7 million and $3.4 million, respectively. These contracts have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income, net in the condensed consolidated statement of operations. For the three months ended September 30, 2023 and 2022, there were net losses of less than $0.1 million and $0.5 million, respectively. As of September 30, 2023 and June 30, 2023, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 12, Derivatives and Hedging, for additional information.

[0000950170-23-058245:notes:72]
The fair value of borrowings under the 2023 Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2023 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $197.5 million and $225.0 million as of September 30, 2023 and June 30, 2023, respectively.

[0000950170-23-058245:notes:73]
[same as prior period, unchanged from 0000950170-23-015282:notes:78]

[0000950170-23-058245:notes:74]
As of September 30, 2023 and June 30, 2023 the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three months ended September 30, 2023 and 2022. There were no impairments recorded for the three months ended September 30, 2023 and 2022.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-058245:notes:75]
6.
Intangible Assets and Goodwill

[0000950170-23-058245:notes:76]
[same as prior period, unchanged from 0000950170-23-015282:notes:81]

[0000950170-23-058245:notes:77]
The following tables summarize the components of gross and net intangible assets (in thousands, except years):

[0000950170-23-058245:notes:78]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 4.9 years |  | $ | 169,089 |  |  | $ | 160,875 |  |  | $ | 8,214 |  |
| Customer relationships |  | 3.7 years |  |  | 64,652 |  |  |  | 59,240 |  |  |  | 5,412 |  |
| Trade names |  | 0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 3.2 years |  |  | 2,445 |  |  |  | 2,214 |  |  |  | 231 |  |
| Total intangible assets, net* |  |  |  | $ | 246,886 |  |  | $ | 233,029 |  |  | $ | 13,857 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-23-058245:notes:79]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 4.1 years |  | $ | 169,460 |  |  | $ | 159,592 |  |  | $ | 9,868 |  |
| Customer relationships |  | 3.4 years |  |  | 64,839 |  |  |  | 58,894 |  |  |  | 5,945 |  |
| Trade names |  | 0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 3.4 years |  |  | 2,445 |  |  |  | 2,195 |  |  |  | 250 |  |
| Total intangible assets, net* |  |  |  | $ | 247,444 |  |  | $ | 231,381 |  |  | $ | 16,063 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-23-058245:notes:80]
The following table summarizes the amortization expense of intangible assets for the periods presented (in thousands):

[0000950170-23-058245:notes:81]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 1,433 |  |  | $ | 3,605 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 511 |  |  |  | 523 |  |
| Total amortization expense |  | $ | 1,944 |  |  | $ | 4,128 |  |

[0000950170-23-058245:notes:82]
The amortization expense that is recognized in “Total cost of revenues” primarily consists of amortization related to developed technology and license agreements.

[0000950170-23-058245:notes:83]
[same as prior period, unchanged from 0000950170-23-015282:notes:88]

[0000950170-23-058245:notes:84]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2024 (the remainder of fiscal 2024) |  | $ | 3,733 |  |
| 2025 |  |  | 4,248 |  |
| 2026 |  |  | 3,046 |  |
| 2027 |  |  | 1,365 |  |
| 2028 |  |  | 1,212 |  |
| Thereafter |  |  | 253 |  |
| Total |  | $ | 13,857 |  |

[0000950170-23-058245:notes:85]
[same as prior period, unchanged from 0000950170-23-015282:notes:90]

[0000950170-23-058245:notes:86]
The Company had Goodwill in the amount of $393.0 million and $394.8 million as of September 30, 2023 and June 30, 2023, respectively. The change in goodwill during the three months ended September 30, 2023 is due to foreign currency translation adjustment that is recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-058245:notes:87]
7.
Debt

[0000950170-23-058245:notes:88]
The Company’s debt is comprised of the following (in thousands):

[0000950170-23-058245:notes:89]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 187,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,239 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 185,261 |  |  |  | 187,591 |  |
| Total debt |  | $ | 194,586 |  |  | $ | 221,917 |  |

[0000950170-23-058245:notes:90]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-23-058245:notes:91]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance its debt. On July 7, 2023 the Company made a payment of $25.0 million to pay off the outstanding revolving credit balance.

[0000950170-23-058245:notes:92]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-23-058245:notes:93]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the three months ended September 30, 2023, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.

[0000950170-23-058245:notes:94]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended September 30, 2023 and 2022, respectively. The interest rate as of September 30, 2023 was 7.45% and as of September 30, 2022 was 4.50%.

[0000950170-23-058245:notes:95]
As of September 30, 2023, the Company did not have any outstanding balance against its 2023 Revolving Facility’s outstanding balance. The Company had $135.5 million of availability under the 2023 Revolving Facility as of September 30, 2023. During the three months ended September 30, 2023 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the three months ended September 30, 2022 the Company made an additional payment of $30.0 million, against its term loan facility under the 2019 Credit Agreement.

[0000950170-23-058245:notes:96]
The Company had $14.5 million of outstanding letters of credit as of September 30, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-058245:notes:97]
8.
Commitments and Contingencies

[0000950170-23-058245:notes:98]
Purchase Commitments

[0000950170-23-058245:notes:99]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2023, the Company had commitments to purchase $94.7 million of inventory.

[0000950170-23-058245:notes:100]
Legal Proceedings

[0000950170-23-058245:notes:101]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-23-058245:notes:102]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0000950170-23-058245:notes:103]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-23-058245:notes:104]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0000950170-23-058245:notes:105]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0000950170-23-058245:notes:106]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022 the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.

[0000950170-23-058245:notes:107]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-23-058245:notes:108]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.

[0000950170-23-058245:notes:109]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-23-058245:notes:110]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and the matter is proceeding through the appellate process.

[0000950170-23-058245:notes:111]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021 and a hearing date has been set for November 20, 2024.

[0000950170-23-058245:notes:112]
Indemnification Obligations

[0000950170-23-058245:notes:113]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-23-058245:notes:114]
9.
Stockholders’ Equity

[0000950170-23-058245:notes:115]
[same as prior period, unchanged from 0000950170-23-015282:notes:131]

[0000950170-23-058245:notes:116]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 14, 2023 to increase the maximum number of available shares by 5.0 million shares, which is pending ratification by the stockholders at the Company's annual meeting of the stockholders to be held on November 8, 2023.

[0000950170-23-058245:notes:117]
[same as prior period, unchanged from 0000950170-23-015282:notes:133]

[0000950170-23-058245:notes:118]
[same as prior period, unchanged from 0000950170-23-015282:notes:134]

[0000950170-23-058245:notes:119]
[same as prior period, unchanged from 0000950170-23-015282:notes:135]

[0000950170-23-058245:notes:120]
On May 18, 2022, the Company announced the Board had authorized management to repurchase up to $200.0 million shares of the Company’s common stock over a three-year period commencing July 1, 2022 (as amended, the “2022 Repurchase Program”). Initially, under the 2022 Repurchase program, a maximum of $25.0 million of shares was authorized to be repurchased in any quarter; however, on November 17, 2022, the Board increased the authorization to repurchase shares in any quarter from up to $25.0 million of

[0000950170-23-058245:notes:121]
shares per quarter to up to $50.0 million of shares per quarter. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0000950170-23-058245:notes:122]
During the three months ended September 30, 2023, the Company repurchased a total of 880,215 shares of its common stock on the open market at a total cost of $24.9 million with an average price of $28.28 per share. There were no shares repurchased during the three months ended September 30, 2022. As of September 30, 2023, approximately $75.2 million remains available for share repurchases under the 2022 Repurchase Program.

[0000950170-23-058245:notes:123]
As a provision of the Inflation Reduction Act enacted in the U.S., the Company is subject to an excise tax on corporate stock repurchases, which is assessed as one percent of the fair market value of net corporate stock repurchases after December 31, 2022. The Company expects that the impact of the excise tax on net corporate stock repurchases will not be material for fiscal 2024.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-058245:notes:124]
10.
Employee Benefit Plans

[0000950170-23-058245:notes:125]
[same as prior period, unchanged from 0000950170-23-015282:notes:140]

[0000950170-23-058245:notes:126]
[same as prior period, unchanged from 0000950170-23-015282:notes:141]

[0000950170-23-058245:notes:127]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 7,409 |  |  |  | 9,995 |  |
| Employee stock options and awards outstanding |  |  | 9,656 |  |  |  | 10,038 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,948 |  |  |  | 8,467 |  |
| Total shares reserved for issuance |  |  | 25,013 |  |  |  | 28,500 |  |

[0000950170-23-058245:notes:128]
[same as prior period, unchanged from 0000950170-23-015282:notes:143]

[0000950170-23-058245:notes:129]
[same as prior period, unchanged from 0000950170-23-015282:notes:144]

[0000950170-23-058245:notes:130]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Cost of product revenues |  | $ | 483 |  |  | $ | 374 |  |
| Cost of subscription and support revenues |  |  | 866 |  |  |  | 672 |  |
| Research and development |  |  | 4,377 |  |  |  | 3,090 |  |
| Sales and marketing |  |  | 6,988 |  |  |  | 4,639 |  |
| General and administrative |  |  | 7,205 |  |  |  | 5,014 |  |
| Total share-based compensation expense |  | $ | 19,919 |  |  | $ | 13,789 |  |

[0000950170-23-058245:notes:131]
[same as prior period, unchanged from 0000950170-23-015282:notes:146]

[0000950170-23-058245:notes:132]
The following table summarizes stock option activity for the three months ended September 30, 2023 (in thousands, except per share amount and contractual term):

[0000950170-23-058245:notes:133]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.70 |  |  | $ | 23,136 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.45 |  |  | $ | 20,952 |  |
| Vested and expected to vest at September 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.45 |  |  | $ | 20,952 |  |
| Exercisable at September 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.45 |  |  | $ | 20,952 |  |

[0000950170-23-058245:notes:134]
[same as prior period, unchanged from 0000950170-23-015282:notes:149]

[0000950170-23-058245:notes:135]
options granted during the three months ended September 30, 2023 and 2022. There were no stock options exercised during the three months ended September 30, 2023 and 2022.

[0000950170-23-058245:notes:136]
[same as prior period, unchanged from 0000950170-23-015282:notes:151]

[0000950170-23-058245:notes:137]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance-condition or market-condition RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the stock awards over the vesting period based on the awards’ fair value as of the date of grant. The Company does not estimate forfeitures, but accounts for them as incurred.

[0000950170-23-058245:notes:138]
The following table summarizes stock award activity for the three months ended September 30, 2023 (in thousands, except grant date fair value):

[0000950170-23-058245:notes:139]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2023 |  |  | 8,851 |  |  | $ | 14.25 |  |  |  |  |
| Granted |  |  | 3,126 |  |  |  | 30.69 |  |  |  |  |
| Exercised |  |  | (3,335 | ) |  |  | 12.33 |  |  |  |  |
| Canceled |  |  | (173 | ) |  |  | 14.53 |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2023 |  |  | 8,469 |  |  | $ | 21.06 |  |  | $ | 205,023 |  |
| Stock awards expected to vest at September 30, 2023 |  |  | 8,469 |  |  | $ | 21.06 |  |  | $ | 205,023 |  |

[0000950170-23-058245:notes:140]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the three months ended September 30, 2023 included 0.5 million RSUs including the market condition awards discussed below to the named executive officers and directors.

[0000950170-23-058245:notes:141]
[same as prior period, unchanged from 0000950170-23-015282:notes:156]

[0000950170-23-058245:notes:142]
During the three months ended September 30, 2023 and 2022 the Compensation Committee of the Board granted 0.7 million and 1.0 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. The MSUs granted during the three months ended September 30, 2023 included 0.4 million MSUs subject to total shareholder return (“TSR”) and 0.3 million MSUs subject to certain stock price targets. The MSUs granted during the three months ended September 30, 2022 were subject to TSR.

[0000950170-23-058245:notes:143]
The TSR MSUs vest based on the Company’s TSR relative to the TSR of the Russell 2000 Index (“Index”). The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant, as indicated in the table below. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0000950170-23-058245:notes:144]
[same as prior period, unchanged from 0000950170-23-015282:notes:158]

[0000950170-23-058245:notes:145]
[same as prior period, unchanged from 0000950170-23-015282:notes:159]

[0000950170-23-058245:notes:146]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the three months ended September 30, 2023 was $38.23 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free interest rate of 4.59%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The weighted-average grant-date fair value of the TSR MSUs granted during the three months ended September 30, 2022 was $16.57 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 67%, risk-free interest rate of 3.12%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-23-058245:notes:147]
The stock price target MSUs vest upon the achievement of a certain stock price target over the defined performance period. The stock price target shall be deemed as achieved if the average closing stock price over any thirty consecutive trading days during the period from grant date through the third anniversary of the grant date equals or exceeds the price target of $41.38 for the initial performance period. Upon satisfaction of the initial stock price target, 50% of the target shares will vest on the 3rd anniversary of the grant date and the remaining 50% will vest on the 4th anniversary of the grant date, subject to employees continued service through the applicable vesting dates. If the units are not earned on the last day of initial performance period, the units will remain outstanding and be eligible to be earned if the average closing stock price over any thirty consecutive trading days equals or exceeds the price target of $46.96.

[0000950170-23-058245:notes:148]
The grant date fair value of these stock price target MSUs was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of these stock price target MSUs granted during the three months ended September 30, 2023 was $28.80 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 63%, risk-free interest rate of 4.45%, no expected dividend yield, expected term of three years based on possible future stock prices over the performance period based on the historical stock prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-23-058245:notes:149]
The fair value of each share purchase option under the ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the ESPP represents the term of the offering period of each option. The risk-free interest rate is based on the estimated life and on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s common stock.

[0000950170-23-058245:notes:150]
There were 0.5 million and 0.7 million shares issued under the ESPP during the three months ended September 30, 2023 and 2022, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0000950170-23-058245:notes:151]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 5.54 | % |  |  | 3.12 | % |
| Volatility |  |  | 42 | % |  |  | 60 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0000950170-23-058245:notes:152]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended September 30, 2023 and 2022 was $8.09 and $4.38 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-058245:notes:153]
11.
Information about Segments and Geographic Areas

[0000950170-23-058245:notes:154]
The Company operates in one segment, the development and marketing of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area based on the billing address of customers. The Company operates in three geographical areas: Americas, EMEA, and APAC. The Company’s chief operating decision maker, who is its Chief Executive Officer, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0000950170-23-058245:notes:155]
[same as prior period, unchanged from 0000950170-23-015282:notes:168]

[0000950170-23-058245:notes:156]
[same as prior period, unchanged from 0000950170-23-015282:notes:169]

[0000950170-23-058245:notes:157]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Americas |  | $ | 135,410 |  |  | $ | 124,375 |  |
| EMEA |  |  | 34,828 |  |  |  | 35,175 |  |
| APAC |  |  | 10,865 |  |  |  | 11,244 |  |
| Total long-lived assets |  | $ | 181,103 |  |  | $ | 170,794 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-058245:notes:158]
12.
Derivatives and Hedging

[0000950170-23-058245:notes:159]
[same as prior period, unchanged from 0000950170-23-015282:notes:172]

[0000950170-23-058245:notes:160]
The Company is exposed to interest rate risk on its debt. The Company may enter into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which may have floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0000950170-23-058245:notes:161]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in "Accumulated other comprehensive loss" and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0000950170-23-058245:notes:162]
During fiscal year ended June 30, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of September 30, 2023 the Company did not have any outstanding interest rate swaps contracts. As of September 30, 2022, the notional amount of these interest rate swaps was $75.0 million, and had maturity dates through April 2023. As of September 30, 2022 these contracts had unrealized gain of $1.3 million, and were recorded in “Accumulated other comprehensive loss” with the associated asset in “Prepaid expenses and other current assets”, in the condensed consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in "Accumulated other comprehensive loss" related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts.

[0000950170-23-058245:notes:163]
[same as prior period, unchanged from 0000950170-23-015282:notes:177]

[0000950170-23-058245:notes:164]
[same as prior period, unchanged from 0000950170-23-015282:notes:178]

[0000950170-23-058245:notes:165]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income, net” in the accompanying condensed consolidated statements of operations. As of September 30, 2023 and 2022, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amounts of $18.7 million and $4.2 million, respectively. These contracts have maturities of 40 days or less. The net gains and losses recorded in the condensed consolidated statement of operations from these contracts during the three months ended September 30, 2023 were net losses of  less than $0.1 million and $0.5 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities. 
For the three months ended September 30, 2023 and 2022, the Company recognized total foreign currency gains of $0.5 million and $0.9 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-058245:notes:166]
13.
Restructuring and Related Charges

[0000950170-23-058245:notes:167]
The Company recorded $2.7 million of restructuring and related charges during the three months ended September 30, 2023, which primarily related to the restructuring plans as noted below.

[0000950170-23-058245:notes:168]
During the first quarter of fiscal 2024, the Company executed a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with our business and strategic priorities (the “Q1 2024 Plan”). It consisted primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general & administrative functions. During the three months ended September 30, 2023, the Company incurred charges of approximately $2.7 million related to the Q1 2024 Plan.

[0000950170-23-058245:notes:169]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform our business infrastructure and reduce our facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project the Company will move engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating our labs. The Company expects that the project will take about 12 to 15 months from September 30, 2023 for completion, and expects to incur charges of approximately $11.0 million throughout this period primarily for asset disposals, contractor costs, severance, relocation and other non-recurring fees.

[0000950170-23-058245:notes:170]
The Company recorded $0.5 million of restructuring and related charges during the three months ended September 30, 2022 which primarily included additional facility related expenses related to previously impaired facilities.

[0000950170-23-058245:notes:171]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of September 30, 2023 the restructuring liability was $0.9 million related to the Q1 2024 Plan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-058245:notes:172]
14.
Income Taxes

[0000950170-23-058245:notes:173]
For the three months ended September 30, 2023 and 2022, the Company recorded an income tax provision of $4.6 million and $1.7 million, respectively.

[0000950170-23-058245:notes:174]
The income tax provisions for the three months ended September 30, 2023 and 2022, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In addition, the tax provision for the three months ended September 30, 2023, includes US Federal income tax. The interim income tax provisions for the three months ended September 30, 2023 and 2022 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0000950170-23-058245:notes:175]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, the Company considers all available positive and negative evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable including past operating results, estimates of future taxable income, changes to enacted tax laws, and the feasibility of tax planning strategies; such assessment is required on a jurisdiction-by-jurisdiction basis. The Company's inconsistent earnings in recent periods, including historical losses, tax attributes expiring unutilized in recent years and the cyclical nature of the Company's business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets. In the event the Company changes its determination as to the amount of deferred tax assets that can be realized, it will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000950170-23-058245:notes:176]
The Company had $18.3 million of unrecognized tax benefits as of September 30, 2023. If fully recognized in the future, $0.2 million would impact the effective tax rate and $18.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur

[0000950170-23-058245:notes:177]
during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0000950170-23-058245:notes:178]
[same as prior period, unchanged from 0000950170-23-015282:notes:191]

[0000950170-23-058245:notes:179]
[same as prior period, unchanged from 0000950170-23-015282:notes:192]


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-058245:notes:180]
15.
Net Income Per Share

[0000950170-23-058245:notes:181]
Basic net income per share is calculated by dividing net income by the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is calculated by dividing net income by the weighted-average number of shares of common stock used in the basic net income per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0000950170-23-058245:notes:182]
[same as prior period, unchanged from 0000950170-23-015282:notes:195]

[0000950170-23-058245:notes:183]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Net income |  | $ | 28,676 |  |  | $ | 12,585 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 128,782 |  |  |  | 130,289 |  |
| Options to purchase common stock |  |  | 898 |  |  |  | 523 |  |
| Restricted stock units |  |  | 3,783 |  |  |  | 2,121 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 133,463 |  |  |  | 132,933 |  |
| Net income per share – basic and diluted |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.22 |  |  | $ | 0.10 |  |
| Net income per share – diluted |  | $ | 0.21 |  |  | $ | 0.09 |  |

[0000950170-23-058245:notes:184]
[same as prior period, unchanged from 0000950170-23-015282:notes:197]

[0000950170-23-058245:notes:185]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Restricted stock units |  |  | 1,071 |  |  |  | 2,343 |  |
| Employee Stock Purchase Plan shares |  |  | 267 |  |  |  | 410 |  |
| Total shares excluded |  |  | 1,338 |  |  |  | 2,753 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-23-058245:notes:186]
16. Subsequent Events

[0000950170-23-058245:notes:187]
In October 2023, the Company initiated an additional global reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with our business and strategic priorities while reducing its operating expenses (the “2024 Plan”). The Company is currently evaluating the timing and impact of this reduction-in-force on the Company's business, financial condition and results of operations for the year ending June 30, 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-23-058245:notes:188]
On August 4, 2023, Edward B. Meyercord, the Company's President and CEO, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 897,303 shares of the Company's common stock until July 31, 2025.

[0000950170-23-058245:notes:189]
On August 14, 2023, Rajendra K. Khanna, a member of the Company's board of directors, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 25,000 shares of the Company's common stock until October 30, 2024.

[0000950170-23-058245:notes:190]
On August 30, 2023, Ingrid J. Burton, a member of the Company's board of directors, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 5,000 shares of the Company's common stock until August 30, 2024.
