# EXTR MD&A — 0000950170-23-058245


## mdna

[0000950170-23-058245:mdna:1]
[same as prior period, unchanged from 0000950170-23-015282:mdna:1]

[0000950170-23-058245:mdna:2]
[same as prior period, unchanged from 0000950170-23-015282:mdna:2]

[0000950170-23-058245:mdna:3]
[same as prior period, unchanged from 0000950170-23-015282:mdna:3]

[0000950170-23-058245:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of cloud networking solutions and industry leading services and support. Extreme designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment. The Company’s cloud solution is a single platform that offers unified network management of wireless access points, switches, and SD-WAN. It leverages machine learning, Artificial Intelligence Operations and analytics to help customers deliver secure connectivity at the edge of the network, speed cloud deployments, and uncover actionable insights to save time, lower costs and streamline operations. Extreme is currently managing more than two million devices in the cloud.

[0000950170-23-058245:mdna:5]
Extreme has been pushing the boundaries of networking technology since 1996, driven by a higher purpose of helping our customers connect beyond the network. Extreme’s cloud networking technologies provide flexibility and scalability in deployment, management, and licensing of networks globally. Our global footprint provides service to over 50,000 customers and over 10 million daily end users across the world including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0000950170-23-058245:mdna:6]
[same as prior period, unchanged from 0000950170-23-015282:mdna:6]

[0000950170-23-058245:mdna:7]
Enterprises across every industry are going through unprecedented changes, such as leading digital initiatives, migrating their workloads to cloud-based environments, modernizing applications, and adopting to a distributed workforce. To accomplish this, they are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. As networks become more complex and more distributed in nature, we believe IT teams in every industry will need more control and better insights than ever before to ensure secure, distributed connectivity and comprehensive centralized visibility. Managing networks from cloud-based applications where customers can run their entire end-to-end networks, from wired or wireless infrastructure to SD-WAN, while ensuring full IT management of the business becomes critical. In addition, Machine Learning (“ML”) and Artificial Intelligence (“AI”) technologies have the potential to vastly improve the network experience in today's world by collating large data sets to increase accuracy and derive resolutions to improve the operation of the network. When ML and AI are applied with cloud-driven networking and automation, administrators can quickly scale to provide productivity, availability, accessibility, manageability, security, and speed, regardless of the distribution of the network.

[0000950170-23-058245:mdna:8]
As the edge of the network continues to expand, our customers are managing more endpoints. With that comes a host of challenges. This continued expansion creates issues such as a higher risk of cyberattacks and a need for more bandwidth as a result of an increase in applications running across the network.

[0000950170-23-058245:mdna:9]
Network complexity manifests itself in the form of more endpoints to manage, more applications to monitor, and more services that rely on the network for service delivery and enablement. When performance suffers, and the tug on internal systems and IT staff becomes more intense, often technology is being overworked. Resolving network problems expeditiously and identifying their root cause, can improve organizational productivity and result in higher performance of operations.

[0000950170-23-058245:mdna:10]
We believe that the network has never been more vital than it is today. As administrators grapple with more data, coming from more places, more connected devices, and more Software-as-a-service (“SaaS”) based applications, the cloud is fundamental to establishing a new normal. Traditional network offerings are not well-suited to fulfill enterprise expectations for rapid delivery of new services, more flexible business models, real-time response, and massive scalability.

[0000950170-23-058245:mdna:11]
[same as prior period, unchanged from 0000950170-23-015282:mdna:11]

[0000950170-23-058245:mdna:12]
[same as prior period, unchanged from 0000950170-23-015282:mdna:12]

[0000950170-23-058245:mdna:13]
[same as prior period, unchanged from 0000950170-23-015282:mdna:13]

[0000950170-23-058245:mdna:14]
We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), SD-WAN solutions and management, automation, and elements of the Secure Access Services Edge (“SASE”) market to be over $40 billion, and growing at approximately 12% annually over the next five years. This comprises over $28 billion for networking, infrastructure spanning enterprise and service provider (largely 5G) applications, and a $4 billion SD-WAN market, and we also participate in $7 billion of the served addressable market for networking software.

[0000950170-23-058245:mdna:15]
[same as prior period, unchanged from 0000950170-23-015282:mdna:15]

[0000950170-23-058245:mdna:16]
We are driven to help our customers find new ways to deliver better outcomes. Connectivity is just the foundation. We make the network a strategic asset. The combination of our solutions provides the connectivity, bandwidth, performance and insights that organizations of all sizes need to move their organizations forward. IT leaders are now tasked with ensuring the global, hybrid workforce is functional and successful no matter where they are, and ensuring people can work wherever they want.

[0000950170-23-058245:mdna:17]
We help identify and solve business challenges. We simplify and improve the way our customers work and are relentlessly focused on finding new ways to drive better outcomes.

[0000950170-23-058245:mdna:18]
Cloud networking management allows customers to gain real-time visibility and insights into areas such as application usage, location and workflow patterns across their environment, helping to inform strategic business decisions and create personalized experiences. Customers benefit from visibility, control and reduced time to resolution. This is the cornerstone of our One Network, One Cloud, One Extreme vision..

[0000950170-23-058245:mdna:19]
Extreme has recognized that the way we and our customers communicate has changed and given rise to these distributed enterprise environments, or in other words, the Infinite Enterprise, which has three tenets:

[0000950170-23-058245:mdna:20]
•
Infinitely distributed connectivity is the enterprise-grade reliable connectivity that allows users to connect anywhere, from anywhere. It is always present, available and assured, while being secure and manageable.

[0000950170-23-058245:mdna:21]
[same as prior period, unchanged from 0000950170-23-015282:mdna:19]

[0000950170-23-058245:mdna:22]
[same as prior period, unchanged from 0000950170-23-015282:mdna:20]

[0000950170-23-058245:mdna:23]
[same as prior period, unchanged from 0000950170-23-015282:mdna:21]

[0000950170-23-058245:mdna:24]
[same as prior period, unchanged from 0000950170-23-015282:mdna:22]

[0000950170-23-058245:mdna:25]
[same as prior period, unchanged from 0000950170-23-015282:mdna:23]

[0000950170-23-058245:mdna:26]
•
Provide a differentiated end-to-end cloud architecture.  Cloud networking is estimated to be a $4.1 billion segment of the networking market comprised of cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at a 13% over the next three years, according to data from the 650 Group. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the Internet of Things (“IoT”) edge to the enterprise data center. Key characteristics of our cloud architecture include:

[0000950170-23-058245:mdna:27]
o
A robust cloud management platform that delivers visibility, intelligence, and assurance from the IoT edge to the network core.

[0000950170-23-058245:mdna:28]
[same as prior period, unchanged from 0000950170-23-015282:mdna:26]

[0000950170-23-058245:mdna:29]
o
Consumption Flexibility: Offer a range of financing and network purchase options. Our value-based subscription tiers (including Connect, Navigator, Pilot and CoPilot) provide customers with flexibility to grow, as well as offer pool-able and portable licenses that can be transferred between products (e.g., access points and switches) at one fixed price.

[0000950170-23-058245:mdna:30]
[same as prior period, unchanged from 0000950170-23-015282:mdna:29]

[0000950170-23-058245:mdna:31]
o
Extreme Cloud IQ cloud platform conforms to ISO/ IEC 27017, is certified by DQS to ISO/IEC 27001 and ISO/IEC 27701 by the International Standards Organization (“ISO”), and is CSA STAR certified.

[0000950170-23-058245:mdna:32]
•
Offer customers choice: public or private cloud, or on-premises. We leverage the cloud where it makes sense for our customers and provide on-premises solutions where customers need it and also have a solution for those who want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what is going on across their network and applications in real time – who, when, and what is connected to the network, which is critical for bring your own device (“BYOD”) and IoT usage.

[0000950170-23-058245:mdna:33]
[same as prior period, unchanged from 0000950170-23-015282:mdna:31]

[0000950170-23-058245:mdna:34]
o
Extreme AirDefense™ is a comprehensive wireless intrusion prevention system ("WIPS") that simplifies the protection, monitoring and security of wireless networks. With the added Bluetooth and Bluetooth low energy intrusion prevention, network administrators can address growing threats against Bluetooth and Bluetooth low energy devices.

[0000950170-23-058245:mdna:35]
[same as prior period, unchanged from 0000950170-23-015282:mdna:33]

[0000950170-23-058245:mdna:36]
[same as prior period, unchanged from 0000950170-23-015282:mdna:34]

[0000950170-23-058245:mdna:37]
[same as prior period, unchanged from 0000950170-23-015282:mdna:35]

[0000950170-23-058245:mdna:38]
[same as prior period, unchanged from 0000950170-23-015282:mdna:36]

[0000950170-23-058245:mdna:39]
o
Universal switches (7720/5720/5520/5420/5320) support fabric or traditional networking with a choice of cloud or on-premises (air-gapped or cloud connected) management.

[0000950170-23-058245:mdna:40]
o
Universal Wi-Fi 6/6E APs (300/400, 4000 and 5000 series) support campus or distributed deployments with a choice of cloud or on-premises (air-gapped or cloud connected) management.

[0000950170-23-058245:mdna:41]
o
Universal licensing with one portable management license for any device and for any type of management. For switches, OS feature licenses are portable, and bulk activated through ExtremeCloud IQ.

[0000950170-23-058245:mdna:42]
[same as prior period, unchanged from 0000950170-23-015282:mdna:40]

[0000950170-23-058245:mdna:43]
[same as prior period, unchanged from 0000950170-23-015282:mdna:41]

[0000950170-23-058245:mdna:44]
[same as prior period, unchanged from 0000950170-23-015282:mdna:42]

[0000950170-23-058245:mdna:45]
[same as prior period, unchanged from 0000950170-23-015282:mdna:43]

[0000950170-23-058245:mdna:46]
•
Expand Wi-Fi technology leadership.  Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our cloud architecture with ML and AI-driven insights.

[0000950170-23-058245:mdna:47]
[same as prior period, unchanged from 0000950170-23-015282:mdna:45]

[0000950170-23-058245:mdna:48]
•
Expand market penetration by targeting high-growth market segments.  Within the campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our data center approach leverages our product portfolio to address the needs of public and private cloud data center providers. We believe that the cloud networking compound annual growth rate will continue to outpace the compound annual growth rate for on-premises managed networking. Our focus is on expanding our technology foothold in the critical cloud networking segment to accelerate not only cloud management adoption, but also subscription-based licensing consumption.

[0000950170-23-058245:mdna:49]
[same as prior period, unchanged from 0000950170-23-015282:mdna:47]

[0000950170-23-058245:mdna:50]
[same as prior period, unchanged from 0000950170-23-015282:mdna:48]

[0000950170-23-058245:mdna:51]
[same as prior period, unchanged from 0000950170-23-015282:mdna:49]

[0000950170-23-058245:mdna:52]
Results of Operations

[0000950170-23-058245:mdna:53]
During the first quarter of fiscal 2024, we achieved the following results:

[0000950170-23-058245:mdna:54]
•
Net revenues of $353.1 million compared to $297.7 million in the first quarter of fiscal 2023.

[0000950170-23-058245:mdna:55]
•
Product revenues of $253.5 million compared to $206.3 million in the first quarter of fiscal 2023.

[0000950170-23-058245:mdna:56]
•
Subscription and support revenues of $99.7 million compared to $91.4 million in the first quarter of fiscal 2023.

[0000950170-23-058245:mdna:57]
•
Total gross margin of 60.3% of net revenues compared to 56.0% of net revenues in the first quarter of fiscal 2023.

[0000950170-23-058245:mdna:58]
•
Operating income of $35.9 million compared to $17.4 million in the first quarter of fiscal 2023.

[0000950170-23-058245:mdna:59]
•
Net income of $28.7 million compared to $12.6 million in the first quarter of fiscal 2023.

[0000950170-23-058245:mdna:60]
•
Cash flows provided by operating activities of $75.6 million compared to $49.7 million in the three months ended September 30, 2022.

[0000950170-23-058245:mdna:61]
•
Cash and cash equivalents of $224.4 million as of September 30, 2023 compared to $234.8 million as of June 30, 2023.

[0000950170-23-058245:mdna:62]
[same as prior period, unchanged from 0000950170-23-015282:mdna:61]

[0000950170-23-058245:mdna:63]
The following table presents net product and subscription and support revenues for the periods presented (in thousands, except percentages):

[0000950170-23-058245:mdna:64]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  | September 30,2022 |  | $Change |  | %Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |
| Product |  | $253,483 |  | $206,276 |  | $47,207 |  | 22.9 % |  |
| Percentage of net revenues |  | 71.8% |  | 69.3% |  |  |  |  |  |
| Subscription and support |  | 99,654 |  | 91,413 |  | 8,241 |  | 9.0 % |  |
| Percentage of net revenues |  | 28.2% |  | 30.7% |  |  |  |  |  |
| Total net revenues |  | $353,137 |  | $297,689 |  | $55,448 |  | 18.6 % |  |

[0000950170-23-058245:mdna:65]
Product revenue is generated primarily from sales of our networking equipment. Subscription and support revenue is derived primarily from sales of our subscription and support offerings which includes SaaS offerings, maintenance contracts, professional services and training for its products. Prior to fiscal 2023, subscription and support revenue was referred to as service and subscription revenue, however, the composition of subscription and support revenue has not been modified.

[0000950170-23-058245:mdna:66]
Product revenues increased $47.2 million or 22.9% for the three months ended September 30, 2023 as compared to the corresponding period in fiscal 2023. The increase in product revenue was primarily due to strong demand for our products and higher shipments resulting from an easing in supply chain constraints which had impacted our ability to fulfill the demand for our products.

[0000950170-23-058245:mdna:67]
Subscription and support revenues increased $8.2 million or 9.0% for the three months ended September 30, 2023 as compared to the corresponding period in fiscal 2023. The increase in subscription and support revenue was primarily due to the continued growth in our subscription business.

[0000950170-23-058245:mdna:68]
The following table presents the product and subscription and support gross profit and the respective gross profit percentages for the periods presented (in thousands, except percentages):

[0000950170-23-058245:mdna:69]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  | September 30,2022 |  | $Change |  | %Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |
| Product |  | $144,947 |  | $106,513 |  | $38,434 |  | 36.1 % |  |
| Percentage of product revenues |  | 57.2% |  | 51.6% |  |  |  |  |  |
| Subscription and support |  | 67,989 |  | 60,195 |  | 7,794 |  | 12.9 % |  |
| Percentage of subscription and support revenues |  | 68.2% |  | 65.8% |  |  |  |  |  |
| Total gross profit |  | $212,936 |  | $166,708 |  | $46,228 |  | 27.7 % |  |
| Percentage of net revenues |  | 60.3% |  | 56.0% |  |  |  |  |  |

[0000950170-23-058245:mdna:70]
Product gross profit increased $38.4 million or 36.1% for the three months ended September 30, 2023 as compared to the corresponding period in fiscal 2023. The increase in product gross profit was primarily due to increased product revenues along with lower amortization of intangible assets due to certain intangible assets being fully amortized, lower warranty reserve, favorable purchase price variance due to the improved market conditions and easing of supply constraints, partially offset by higher reserves for excess and obsolete inventory.

[0000950170-23-058245:mdna:71]
Subscription and support gross profit increased $7.8 million or 12.9% for the three months ended September 30, 2023 as compared to the corresponding period in fiscal 2023. The increase in subscription and support gross profit was primarily due to increased  subscription and support revenues, partially offset by higher cloud services costs.

[0000950170-23-058245:mdna:72]
[same as prior period, unchanged from 0000950170-23-015282:mdna:71]

[0000950170-23-058245:mdna:73]
The following table presents operating expenses for the periods presented (in thousands, except percentages):

[0000950170-23-058245:mdna:74]
|  |  | Three Months Ended |  |  |
|  |  | September 30,2023 |  | September 30,2022 |  | $Change |  | %Change |  |  |
| Research and development |  | $58,016 |  | $50,989 |  | $7,027 |  | 13.8 % |  |  |
| Sales and marketing |  | 91,920 |  | 78,382 |  | 13,538 |  | 17.3 % |  |  |
| General and administrative |  | 23,873 |  | 18,547 |  | 5,326 |  | 28.7 % |  |  |
| Acquisition and integration costs |  | — |  | 390 |  | (390) |  | (100.0)% |  |  |
| Restructuring and related charges |  | 2,717 |  | 481 |  | 2,236 |  | 464.9 % |  |  |
| Amortization of intangible assets |  | 511 |  | 523 |  | (12) |  | (2.3)% |  |  |
| Total operating expenses |  | $177,037 |  | $149,312 |  | $27,725 |  | 18.6 % |  |  |

[0000950170-23-058245:mdna:75]
[same as prior period, unchanged from 0000950170-23-015282:mdna:74]

[0000950170-23-058245:mdna:76]
[same as prior period, unchanged from 0000950170-23-015282:mdna:75]

[0000950170-23-058245:mdna:77]
Research and development expenses increased by $7.0 million or 13.8% for the three months ended September 30, 2023 as compared to the corresponding period in fiscal 2023. The increase in research and development expenses was primarily due to a $5.3 million increase in personnel costs due to increased headcount and higher compensation costs primarily related to share-based compensation, a $1.7 million increase in contractor and consultant fees, and a $0.5 million increase in equipment related costs, partially offset by a $0.5 million decrease in engineering project costs and other costs.

[0000950170-23-058245:mdna:78]
[same as prior period, unchanged from 0000950170-23-015282:mdna:78]

[0000950170-23-058245:mdna:79]
[same as prior period, unchanged from 0000950170-23-015282:mdna:79]

[0000950170-23-058245:mdna:80]
Sales and marketing expenses increased by $13.5 million or 17.3% for the three months ended September 30, 2023 as compared to the corresponding period in fiscal 2023. The increase in sales and marketing expenses was primarily due to a $11.2 million increase in personnel costs due to increased headcount, higher compensation and benefits costs primarily related to higher commissions and share-based compensation, a $2.6 million increase in marketing costs and a $0.7 million increase in equipment and facilities related costs, partially offset by a $1.0 million decrease in travel and other expenses.

[0000950170-23-058245:mdna:81]
[same as prior period, unchanged from 0000950170-23-015282:mdna:82]

[0000950170-23-058245:mdna:82]
[same as prior period, unchanged from 0000950170-23-015282:mdna:83]

[0000950170-23-058245:mdna:83]
General and administrative expenses increased by $5.3 million or 28.7% for the three months ended September 30, 2023 as compared to the corresponding period in fiscal 2023. The increase in general and administrative expenses was primarily due to a $3.2 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $1.5 million increase in legal expenses related to our litigation, a $0.6 million increase in professional service fees and equipment related costs and a $0.6 million increase in system transition related costs, partially offset by a $0.5 million decrease in facilities and related expenses.

[0000950170-23-058245:mdna:84]
[same as prior period, unchanged from 0000950170-23-015282:mdna:86]

[0000950170-23-058245:mdna:85]
During the three months ended September 30, 2023, we did not incur any acquisition and integration costs.

[0000950170-23-058245:mdna:86]
During the three months ended September 30, 2022, we incurred acquisition and integration costs of $0.4 million, which consisted primarily of professional fees and certain compensation charges related to the acquisition of Ipanema Tech SAS.

[0000950170-23-058245:mdna:87]
[same as prior period, unchanged from 0000950170-23-015282:mdna:89]

[0000950170-23-058245:mdna:88]
For the three months ended September 30, 2023, we recorded restructuring and related charges of $2.7 million, which primarily consisted of costs associated with the headcount reduction related to the Q1 2024 plan.

[0000950170-23-058245:mdna:89]
For the three months ended September 30, 2022, we recorded restructuring charges of $0.5 million, which primarily consisted of facility related charges related to our previously impaired facilities.

[0000950170-23-058245:mdna:90]
Amortization of Intangible Assets

[0000950170-23-058245:mdna:91]
During the three months ended September 30, 2023 and 2022, we recorded $0.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-23-058245:mdna:92]
Interest Income

[0000950170-23-058245:mdna:93]
During the three months ended September 30, 2023 and 2022, we recorded $1.2 million and $0.4 million, respectively, in interest income. The increase in interest income is primarily due to higher interest earned on our cash balance due to rising interest rates.

[0000950170-23-058245:mdna:94]
[same as prior period, unchanged from 0000950170-23-015282:mdna:94]

[0000950170-23-058245:mdna:95]
During the three months ended September 30, 2023 and 2022, we recorded $4.3 million and $3.8 million, respectively, in interest expense. The increase in interest expenses was primarily due to higher average rates under our new 2023 Credit Agreement due to rising interest rates.

[0000950170-23-058245:mdna:96]
Other Income, Net

[0000950170-23-058245:mdna:97]
During the three months ended September 30, 2023 and 2022, we recorded other income, net of $0.4 million each. The other income, net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-23-058245:mdna:98]
[same as prior period, unchanged from 0000950170-23-015282:mdna:98]

[0000950170-23-058245:mdna:99]
For the three months ended September 30, 2023 and 2022, we recorded income tax provision of $4.6 million and $1.7 million, respectively.

[0000950170-23-058245:mdna:100]
The income tax provisions for the three months ended September 30, 2023 and 2022 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications System. In addition, the income tax provision for the three months ended September 30, 2023 includes U.S. federal income tax.

[0000950170-23-058245:mdna:101]
[same as prior period, unchanged from 0000950170-23-015282:mdna:101]

[0000950170-23-058245:mdna:102]
[same as prior period, unchanged from 0000950170-23-015282:mdna:102]

[0000950170-23-058245:mdna:103]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2023, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0000950170-23-058245:mdna:104]
[same as prior period, unchanged from 0000950170-23-015282:mdna:104]

[0000950170-23-058245:mdna:105]
[same as prior period, unchanged from 0000950170-23-015282:mdna:105]

[0000950170-23-058245:mdna:106]
[same as prior period, unchanged from 0000950170-23-015282:mdna:106]

[0000950170-23-058245:mdna:107]
[same as prior period, unchanged from 0000950170-23-015282:mdna:107]

[0000950170-23-058245:mdna:108]
The following table summarizes information regarding our cash and cash equivalents (in thousands):

[0000950170-23-058245:mdna:109]
|  |  | September 30,2023 |  |  | June 30,2023 |  |
| Cash and cash equivalents |  | $ | 224,434 |  |  | $ | 234,826 |  |

[0000950170-23-058245:mdna:110]
As of September 30, 2023, our principal sources of liquidity consisted of cash and cash equivalents of $224.4 million, accounts receivable, net of $131.5 million, and available borrowings under our five-year 2023 Revolving Facility of $135.5 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest and share repurchases. We believe that our $224.4 million of cash and cash equivalents at September 30, 2023, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0000950170-23-058245:mdna:111]
On May 18, 2022, our Board of Directors (the “Board”) authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate us to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended September 30, 2023, we repurchased a total of 880,215 shares of its common stock on the open market at a total cost of $24.9 million with an average price of $28.28 per share. As of September 30, 2023, we have $75.2 million available under our share repurchase program.

[0000950170-23-058245:mdna:112]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among Extreme, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement") by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “ 2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use proceeds of the loans for working capital and general corporate purposes. On June 22, 2023, we borrowed $25.0 million against the 2023 Revolving Facility, which was subsequently paid off on July 7, 2023.

[0000950170-23-058245:mdna:113]
At our election, the initial term loan (the “Initial Term Loan”) under the 2023 Credit Agreement may be made as either a base rate loan or a Secured Overnight Financing Data Rate (“SOFR loan"). The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s Consolidated Leverage Ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. We also agreed to pay other closing fees, arrangement fees, and administration fees.

[0000950170-23-058245:mdna:114]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-23-058245:mdna:115]
During the three months ended September 30, 2023, we were in compliance with all the original terms and financial covenants under the 2023 Credit Agreement.

[0000950170-23-058245:mdna:116]
[same as prior period, unchanged from 0000950170-23-015282:mdna:118]

[0000950170-23-058245:mdna:117]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0000950170-23-058245:mdna:118]
|  |  | Three Months Ended |  |
|  |  | September 30,2023 |  |  | September 30,2022 |  |
| Net cash provided by operating activities |  | $ | 75,635 |  |  | $ | 49,734 |  |
| Net cash used in investing activities |  |  | (4,314 | ) |  |  | (3,139 | ) |
| Net cash used in financing activities |  |  | (81,461 | ) |  |  | (42,124 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (252 | ) |  |  | (649 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (10,392 | ) |  | $ | 3,822 |  |

[0000950170-23-058245:mdna:119]
[same as prior period, unchanged from 0000950170-23-015282:mdna:121]

[0000950170-23-058245:mdna:120]
Cash flows provided by operations in the three months ended September 30, 2023 were $75.6 million, including our net income of $28.7 million and non-cash expenses of $29.8 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included a decrease in accounts receivable, and an increase in deferred revenue and other accrued liabilities. This was partially offset by increases in inventories, prepaid and other assets and decreases in accounts payable, accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0000950170-23-058245:mdna:121]
Cash flows provided by operations in the three months ended September 30, 2022 were $49.7 million, including our net income of $12.6 million and non-cash expenses of $22.8 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included a decrease in accounts payable and increase in deferred revenues. This was partially offset by increases in inventories, prepaid expenses and other current assets and decreases in accounts payable, accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0000950170-23-058245:mdna:122]
[same as prior period, unchanged from 0000950170-23-015282:mdna:124]

[0000950170-23-058245:mdna:123]
Cash flows used in investing activities in the three months ended September 30, 2023 were $4.3 million for the purchases of property and equipment.

[0000950170-23-058245:mdna:124]
Cash flows used in investing activities in the three months ended September 30, 2022 were $3.1 million for the purchases of property and equipment.

[0000950170-23-058245:mdna:125]
[same as prior period, unchanged from 0000950170-23-015282:mdna:127]

[0000950170-23-058245:mdna:126]
Cash flows used in financing activities in the three months ended September 30, 2023 were $81.5 million primarily due to payment of $29.1 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan ("ESPP"), a $25.0 million payment against our revolving facility, share repurchase of $24.9 million under our share repurchase program and debt repayment of $2.5 million.

[0000950170-23-058245:mdna:127]
Cash flows used in financing activities in the three months ended September 30, 2022 were $42.1 million primarily due to debt repayments of $37.1 million, $1.0 million for deferred payments on acquisitions and $4.0 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP.

[0000950170-23-058245:mdna:128]
Foreign Currency Effect on Cash and cash equivalents

[0000950170-23-058245:mdna:129]
Foreign currency effect on cash and cash equivalents increased in the three months ended September 30, 2023, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the EURO.

[0000950170-23-058245:mdna:130]
[same as prior period, unchanged from 0000950170-23-015282:mdna:132]

[0000950170-23-058245:mdna:131]
As of September 30, 2023, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0000950170-23-058245:mdna:132]
Our debt obligations relate to amounts owed under our 2023 Credit Agreement. As of September 30, 2023, we had $197.5 million of debt outstanding which is payable on quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0000950170-23-058245:mdna:133]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of September 30, 2023, we had non-cancelable commitments to purchase $94.7 million of inventory. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0000950170-23-058245:mdna:134]
We have contractual commitments to our suppliers which represent commitments for future services. As of September 30, 2023, we had contractual commitments of $32.3 million that are due through our fiscal year 2027.

[0000950170-23-058245:mdna:135]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of September 30, 2023, the value of our obligations under operating leases was $61.0 million.

[0000950170-23-058245:mdna:136]
[same as prior period, unchanged from 0000950170-23-015282:mdna:138]

[0000950170-23-058245:mdna:137]
We did not have any material commitments for capital expenditures as of September 30, 2023.

[0000950170-23-058245:mdna:138]
[same as prior period, unchanged from 0000950170-23-015282:mdna:140]

[0000950170-23-058245:mdna:139]
We did not have any off-balance sheet arrangements as of September 30, 2023.
