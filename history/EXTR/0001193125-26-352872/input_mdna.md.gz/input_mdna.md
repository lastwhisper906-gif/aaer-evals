# EXTR MD&A — 0001193125-26-352872


## mdna

[0001193125-26-352872:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001193125-26-352872:mdna:2]
Business Overview

[0001193125-26-352872:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Part II, Item 8 of this Annual Report on Form 10-K.

[0001193125-26-352872:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Annual Report on Form 10-K, which have been prepared in accordance with U.S. generally accepted accounting principles. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting estimates, see “Critical Accounting Estimates” included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001193125-26-352872:mdna:5]
Extreme is a leader in AI-powered cloud networking, focused on delivering simple and secure solutions that help businesses address challenges and enable connections among devices, applications, and users. We push the boundaries of technology, leveraging the powers of artificial intelligence, analytics, and automation and have industry leading support services. Tens of thousands of customers globally trust Extreme to drive value, foster innovation, and overcome extreme challenges. Extreme also designs, develops, and manufactures wired, wireless, and SD-WAN infrastructure equipment. Our Extreme Platform ONE solution, made generally available in July 2025, is a technology platform that is designed to reduce the complexity for enterprises by seamlessly integrating networking, security and AI solutions into a single platform. AI-powered automation includes conversational, interactive and autonomous AI agents—to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex tasks.

[0001193125-26-352872:mdna:6]
Our global footprint provides service to some of the world’s leading names in business across verticals such as large sports and entertainment venues, hospitality, retail, transportation and logistics, education, government, healthcare, manufacturing and service providers. We derive all our revenues from the sale of our networking equipment, software subscriptions, and related maintenance contracts.

[0001193125-26-352872:mdna:7]
Fiscal Year

[0001193125-26-352872:mdna:8]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2026” or “2026”; “fiscal 2025” or “2025”; “fiscal 2024” or “2024” represent, respectively, the fiscal years ended June 30, 2026, June 30, 2025 and June 30, 2024.

[0001193125-26-352872:mdna:9]
Key Business Metrics:

[0001193125-26-352872:mdna:10]
SaaS Annual Recurring Revenue (“SaaS ARR”)

[0001193125-26-352872:mdna:11]
SaaS ARR is an operating metric used by management to measure the annualized value of customer arrangements for our software solutions, which are delivered via cloud-based subscription (such as Extreme Platform ONE, generally available July 2025, and ExtremeCloud IQ) or term-based software deployed on-premises by the customer. We include term-based license arrangements in SaaS ARR because they provide time-bound access to our software solutions and are operationally and economically similar to our cloud-based subscriptions, even though they are accounted for differently under U.S. GAAP.

[0001193125-26-352872:mdna:12]
SaaS ARR is calculated using the annualized value of quarterly subscription revenue plus the trailing twelve months of the software license portion of term-based license arrangements, which includes revenue recognized during the applicable period with respect to multi-year term-based license arrangements. The Company has not adjusted SaaS ARR to allocate revenue from these multi-year term-based license arrangements over their contractual term because they have historically been immaterial to SaaS ARR and doing so would not be expected to materially affect reported SaaS ARR or related growth rates. For those software solutions that include embedded support as part of a bundled offering, including Extreme Platform ONE and term-based license arrangements, the quarterly revenue recognized in the period with respect to the support portion of the offering is annualized and included in SaaS ARR.

[0001193125-26-352872:mdna:13]
SaaS ARR excludes perpetual licenses, professional services revenue, support revenue associated with hardware or standalone maintenance contracts, and other non-recurring or non-subscription revenue streams. Management evaluates and manages support revenues from maintenance contracts primarily through analysis of the related GAAP revenue trends, renewal activity, and customer support operations, together with broader business performance indicators, rather than through a single standalone metric, in part due to the Company’s go-to-market model in which many customers transact through distributors and resellers, limiting consistent visibility into end-customer usage and renewals.

[0001193125-26-352872:mdna:14]
Management uses SaaS ARR to evaluate the scale and trajectory of the Company’s subscription-based offerings and progress against customer adoption initiatives. We believe this metric is useful to investors for the same reasons, as it provides insight into our ability to acquire new customers and to maintain and expand our existing customer relationships. SaaS ARR should be considered

[0001193125-26-352872:mdna:15]
independently of revenue or deferred revenue under U.S. GAAP, does not have a standardized meaning, and is not a substitute for, or a forecast of, revenue.

[0001193125-26-352872:mdna:16]
As of June 30, 2026, our SaaS ARR was $244.3 million, which was 17.7% higher than our SaaS ARR of $207.6 million as of June 30, 2025. The increase in SaaS ARR was primarily due to continued growth in our subscription business as a result of increased adoption of our cloud network management solutions, including Extreme Platform ONE. Support revenues from maintenance contracts included in Subscription and support revenues but excluded from SaaS ARR were $235.3 million and $234.2 million, representing 49.6% and 53.8% of total Subscription and support revenues, respectively, for the years ended June 30, 2026 and 2025.

[0001193125-26-352872:mdna:17]
36

[0001193125-26-352872:mdna:18]
Results of Operations

[0001193125-26-352872:mdna:19]
The following is a summary of our results of operations during the fiscal year ended June 30, 2026:

[0001193125-26-352872:mdna:20]
•
Net revenues of $1,283.6 million, increased 12.6% from fiscal 2025 net revenues of $1,140.1 million.

[0001193125-26-352872:mdna:21]
•
Product revenues of $809.6 million, increased 14.9% from fiscal 2025 product revenues of $704.5 million.

[0001193125-26-352872:mdna:22]
•
Subscription and support revenues of $474.0 million, increased 8.8% from fiscal 2025 subscription and support revenues of $435.6 million.

[0001193125-26-352872:mdna:23]
•
Total gross margin of 61.5% of net revenues in fiscal 2026, compared to 62.2% in fiscal 2025.

[0001193125-26-352872:mdna:24]
•
Operating income of $62.7 million in fiscal 2026, compared to operating income of $16.9 million in fiscal 2025.

[0001193125-26-352872:mdna:25]
•
Net income of $42.1 million in fiscal 2026, compared to net loss of $7.5 million in fiscal 2025.

[0001193125-26-352872:mdna:26]
•
Cash flow provided by operating activities of $123.2 million, compared to cash flow provided by operating activities of $152.0 million in fiscal 2025, a decrease of $28.8 million. Cash and cash equivalents were $211.8 million as of June 30, 2026, a decrease of approximately $20.0 million, compared to $231.7 million at the end of fiscal 2025.

[0001193125-26-352872:mdna:27]
Net Revenues

[0001193125-26-352872:mdna:28]
The following table presents net product and subscription and support revenues for the fiscal years ended June 30, 2026, 2025 and 2024 (in thousands, except percentages):

[0001193125-26-352872:mdna:29]
|  |  | Year Ended |  | Year Ended |  |
|  |  | June 30, 2026 |  |  | June 30, 2025 |  |  | $Change |  |  | %Change |  | June 30, 2025 |  |  | June 30, 2024 |  |  | $Change |  |  | %Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 809,624 |  |  | $ | 704,462 |  |  | $ | 105,162 |  |  |  | 14.9 | % | $ | 704,462 |  |  | $ | 699,257 |  |  | $ | 5,205 |  |  |  | 0.7 | % |
| Percentage of net revenues |  |  | 63.1 | % |  |  | 61.8 | % |  |  |  |  |  |  |  | 61.8 | % |  |  | 62.6 | % |  |  |  |  |  |  |
| Subscription and support |  |  | 473,969 |  |  |  | 435,605 |  |  |  | 38,364 |  |  |  | 8.8 | % |  | 435,605 |  |  |  | 417,946 |  |  |  | 17,659 |  |  |  | 4.2 | % |
| Percentage of net revenues |  |  | 36.9 | % |  |  | 38.2 | % |  |  |  |  |  |  |  | 38.2 | % |  |  | 37.4 | % |  |  |  |  |  |  |
| Total net revenues |  | $ | 1,283,593 |  |  | $ | 1,140,067 |  |  | $ | 143,526 |  |  |  | 12.6 | % | $ | 1,140,067 |  |  | $ | 1,117,203 |  |  | $ | 22,864 |  |  |  | 2.0 | % |

[0001193125-26-352872:mdna:30]
We generate product revenues from sales of our networking equipment. We derive subscription and support revenues from sales of our subscription and support offerings which includes SaaS offerings, maintenance contracts, professional services and training for our products.

[0001193125-26-352872:mdna:31]
Product revenues increased $105.2 million or 14.9% for the year ended June 30, 2026, compared to fiscal 2025. The product revenues increase for the year ended June 30, 2026 as compared to fiscal 2025 was driven by average selling price improvements as a result of price increases implemented during fiscal 2026 and changes in product mix.

[0001193125-26-352872:mdna:32]
Product revenues increased $5.2 million or 0.7% for the year ended June 30, 2025, compared to fiscal 2024. The product revenues increase for the year ended June 30, 2025 as compared to fiscal 2024 was driven by higher bookings and shipments in the second half of fiscal 2025 than in the corresponding period in fiscal 2024 which was impacted by elongated sales cycles to end customers and lower channel sell-through caused by macroeconomic conditions.

[0001193125-26-352872:mdna:33]
Subscription and support revenues increased $38.4 million or 8.8% for the year ended June 30, 2026, compared to fiscal 2025. The increase in subscription and support revenues was driven by increased adoption of our cloud network management solutions, including Extreme Platform ONE.

[0001193125-26-352872:mdna:34]
Subscription and support revenues increased $17.7 million or 4.2% for the year ended June 30, 2025, compared to fiscal 2024. The increase in subscription and support revenues was due to increased adoption of our cloud network management solutions and continued growth in our subscription business.

[0001193125-26-352872:mdna:35]
We operate in three regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table presents the total net revenues geographically for the fiscal years ended June 30, 2026, 2025 and 2024 (in thousands, except percentages):

[0001193125-26-352872:mdna:36]
|  |  | Year Ended |  | Year Ended |  |  |
| Net Revenues |  | June 30, 2026 |  |  | June 30, 2025 |  |  | $Change |  |  | %Change |  | June 30, 2025 |  |  | June 30, 2024 |  |  | $Change |  |  | %Change |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 576,200 |  |  | $ | 547,658 |  |  | $ | 28,542 |  |  |  | 5.2 | % | $ | 547,658 |  |  | $ | 581,141 |  |  | $ | (33,483 | ) |  |  | (5.8 | )% |  |
| Other |  |  | 49,341 |  |  |  | 49,047 |  |  |  | 294 |  |  |  | 0.6 | % |  | 49,047 |  |  |  | 46,578 |  |  |  | 2,469 |  |  |  | 5.3 | % |  |
| Total Americas |  |  | 625,541 |  |  |  | 596,705 |  |  |  | 28,836 |  |  |  | 4.8 | % |  | 596,705 |  |  |  | 627,719 |  |  |  | (31,014 | ) |  |  | (4.9 | )% |  |
| Percentage of net revenues |  |  | 48.8 | % |  |  | 52.3 | % |  |  |  |  |  |  |  | 52.3 | % |  |  | 56.2 | % |  |  |  |  |  |  |  |
| EMEA |  |  | 534,304 |  |  |  | 451,649 |  |  |  | 82,655 |  |  |  | 18.3 | % |  | 451,649 |  |  |  | 421,966 |  |  |  | 29,683 |  |  |  | 7.0 | % |  |
| Percentage of net revenues |  |  | 41.6 | % |  |  | 39.6 | % |  |  |  |  |  |  |  | 39.6 | % |  |  | 37.8 | % |  |  |  |  |  |  |  |
| APAC |  |  | 123,748 |  |  |  | 91,713 |  |  |  | 32,035 |  |  |  | 34.9 | % |  | 91,713 |  |  |  | 67,518 |  |  |  | 24,195 |  |  |  | 35.8 | % |  |
| Percentage of net revenues |  |  | 9.6 | % |  |  | 8.1 | % |  |  |  |  |  |  |  | 8.1 | % |  |  | 6.0 | % |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 1,283,593 |  |  | $ | 1,140,067 |  |  | $ | 143,526 |  |  |  | 12.6 | % | $ | 1,140,067 |  |  | $ | 1,117,203 |  |  | $ | 22,864 |  |  |  | 2.0 | % |  |

[0001193125-26-352872:mdna:37]
Cost of Revenues and Gross Profit

[0001193125-26-352872:mdna:38]
The following table presents the gross profit on product and subscription and support revenues and the gross profit percentage of net revenues for the fiscal years ended June 30, 2026, 2025 and 2024 (in thousands, except percentages):

[0001193125-26-352872:mdna:39]
|  |  | Year Ended |  | Year Ended |  |
|  |  | June 30, 2026 |  |  | June 30, 2025 |  |  | $Change |  |  | %Change |  | June 30, 2025 |  |  | June 30, 2024 |  |  | $Change |  |  | %Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 457,974 |  |  | $ | 403,631 |  |  | $ | 54,343 |  |  |  | 13.5 | % | $ | 403,631 |  |  | $ | 333,498 |  |  | $ | 70,133 |  |  |  | 21.0 | % |
| Percentage of product revenues |  |  | 56.6 | % |  |  | 57.3 | % |  |  |  |  |  |  |  | 57.3 | % |  |  | 47.7 | % |  |  |  |  |  |  |
| Subscription and support |  |  | 331,167 |  |  |  | 305,496 |  |  |  | 25,671 |  |  |  | 8.4 | % |  | 305,496 |  |  |  | 297,333 |  |  |  | 8,163 |  |  |  | 2.7 | % |
| Percentage of subscription and support revenues |  |  | 69.9 | % |  |  | 70.1 | % |  |  |  |  |  |  |  | 70.1 | % |  |  | 71.1 | % |  |  |  |  |  |  |
| Total gross profit |  | $ | 789,141 |  |  | $ | 709,127 |  |  | $ | 80,014 |  |  |  | 11.3 | % | $ | 709,127 |  |  | $ | 630,831 |  |  | $ | 78,296 |  |  |  | 12.4 | % |
| Percentage of net revenues |  |  | 61.5 | % |  |  | 62.2 | % |  |  |  |  |  |  |  | 62.2 | % |  |  | 56.5 | % |  |  |  |  |  |  |

[0001193125-26-352872:mdna:40]
Cost of product revenues includes costs of materials, amounts paid to third-party original design manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing, engineering, and document control at our facilities in San Jose, California, Salem, New Hampshire, Taiwan, Vietnam, Thailand and the Philippines.

[0001193125-26-352872:mdna:41]
Product gross profit increased $54.3 million or 13.5% for the year ended June 30, 2026 as compared to the corresponding period in fiscal 2025. The increase in product gross profit was due to the increase in product revenues of $105.2 million, partially offset by a proportional increase in direct product costs and, to a lesser extent, increased distribution costs of $8.2 million and an increase in purchase price variances of $10.6 million driven by higher memory component costs.

[0001193125-26-352872:mdna:42]
Product gross profit increased $70.1 million or 21.0% for the year ended June 30, 2025 as compared to the corresponding period in fiscal 2024. The increase in product gross profit was due to higher product revenues as well as lower provisions for excess and obsolete inventory and lower warranty costs, partially offset by higher overhead and distribution costs related to increased purchases of inventory.

[0001193125-26-352872:mdna:43]
Our cost of subscription and support revenues consist of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts as well as third-party professional services costs, data center costs and cloud hosting service costs.

[0001193125-26-352872:mdna:44]
Subscription and support gross profit increased $25.7 million or 8.4% for the year ended June 30, 2026, as compared to the corresponding period in fiscal 2025. The increase in subscription and support gross profit was due to higher subscription revenues of $38.4 million related to increased adoption of our Extreme Platform ONE subscription, partially offset by $10.0 million of higher subscription hosting costs and $3.9 million in higher personnel costs.

[0001193125-26-352872:mdna:45]
Subscription and support gross profit increased $8.2 million or 2.7% for the year ended June 30, 2025, as compared to the corresponding period in fiscal 2024. The increase in subscription and support gross profit was due to higher subscription revenues, partially offset by higher personnel costs and increased cloud service costs.

[0001193125-26-352872:mdna:46]
Operating Expenses

[0001193125-26-352872:mdna:47]
The following table presents operating expenses for the fiscal years ended June 30, 2026, 2025 and 2024 (in thousands, except percentages):

[0001193125-26-352872:mdna:48]
|  |  | Year Ended |  |  | Year Ended |  |  |
|  |  | June 30, 2026 |  |  | June 30, 2025 |  |  | $Change |  |  | %Change |  |  | June 30, 2025 |  |  | June 30, 2024 |  |  | $Change |  |  | %Change |  |  |
| Research and development |  | $ | 233,878 |  |  | $ | 221,459 |  |  | $ | 12,419 |  |  |  | 5.6 | % |  | $ | 221,459 |  |  | $ | 211,931 |  |  | $ | 9,528 |  |  |  | 4.5 | % |  |
| Sales and marketing |  |  | 364,305 |  |  |  | 327,563 |  |  |  | 36,742 |  |  |  | 11.2 | % |  |  | 327,563 |  |  |  | 345,802 |  |  |  | (18,239 | ) |  |  | (5.3 | )% |  |
| General and administrative |  |  | 125,277 |  |  |  | 139,621 |  |  |  | (14,344 | ) |  |  | (10.3 | )% |  |  | 139,621 |  |  |  | 99,938 |  |  |  | 39,683 |  |  |  | 39.7 | % |  |
| Restructuring and related charges |  |  | 1,265 |  |  |  | 1,492 |  |  |  | (227 | ) |  |  | (15.2 | )% |  |  | 1,492 |  |  |  | 36,321 |  |  |  | (34,829 | ) |  |  | (95.9 | )% |  |
| Amortization of intangible assets |  |  | 1,721 |  |  |  | 2,043 |  |  |  | (322 | ) |  |  | (15.8 | )% |  |  | 2,043 |  |  |  | 2,041 |  |  |  | 2 |  |  |  | 0.1 | % |  |
| Total operating expenses |  | $ | 726,446 |  |  | $ | 692,178 |  |  | $ | 34,268 |  |  |  | 5.0 | % |  | $ | 692,178 |  |  | $ | 696,033 |  |  | $ | (3,855 | ) |  |  | (0.6 | )% |  |

[0001193125-26-352872:mdna:49]
The following table highlights our operating expenses and operating income as a percentage of net revenues for the fiscal years ended June 30, 2026, 2025 and 2024:

[0001193125-26-352872:mdna:50]
|  |  | Year Ended |  |  |
|  |  | June 30, 2026 |  |  | June 30, 2025 |  |  | June 30, 2024 |  |  |
| Research and development |  |  | 18.2 | % |  |  | 19.4 | % |  |  | 19.0 | % |  |
| Sales and marketing |  |  | 28.4 | % |  |  | 28.7 | % |  |  | 31.0 | % |  |
| General and administrative |  |  | 9.8 | % |  |  | 12.2 | % |  |  | 8.9 | % |  |
| Restructuring and related charges |  |  | 0.1 | % |  |  | 0.1 | % |  |  | 3.3 | % |  |
| Amortization of intangible assets |  |  | 0.1 | % |  |  | 0.2 | % |  |  | 0.2 | % |  |
| Total operating expenses |  |  | 56.6 | % |  |  | 60.7 | % |  |  | 62.3 | % |  |
| Operating income (loss) |  |  | 4.9 | % |  |  | 1.5 | % |  |  | (5.8 | )% |  |

[0001193125-26-352872:mdna:51]
Research and Development Expenses

[0001193125-26-352872:mdna:52]
Research and development expenses consist of personnel costs (which includes compensation, benefits and stock-based compensation), consultant fees and engineering expenses related to the design, development, and testing of our products.

[0001193125-26-352872:mdna:53]
Research and development expenses increased by $12.4 million or 5.6% for the year ended June 30, 2026 as compared to fiscal 2025, due to a $5.7 million increase in personnel costs due to increased compensation and benefits costs, a $4.0 million increase in information technology costs, and a $2.7 million increase in other costs primarily related to engineering project costs.

[0001193125-26-352872:mdna:54]
Research and development expenses increased by $9.5 million or 4.5% for the year ended June 30, 2025 as compared to fiscal 2024, due to a $10.5 million increase in personnel costs due to increased compensation and benefits costs, a $2.9 million increase in other costs primarily related to software costs, professional service fees, non-recurring engineering project costs and travel costs and a $2.6 million increase in information technology costs, offset by a $6.5 million decrease in contractor costs.

[0001193125-26-352872:mdna:55]
Sales and Marketing Expenses

[0001193125-26-352872:mdna:56]
Sales and marketing expenses consist of personnel costs (which includes compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001193125-26-352872:mdna:57]
Sales and marketing expenses increased by $36.7 million or 11.2% for the year ended June 30, 2026, as compared to fiscal 2025, due to a $17.2 million increase in personnel costs due to increased compensation and benefits costs, a $9.9 million increase in sales and marketing costs due to higher sales commissions, a $5.5 million increase in information technology costs, and a $4.1 million increase in other cost primarily related to professional service fees and travel costs.

[0001193125-26-352872:mdna:58]
Sales and marketing expenses decreased by $18.2 million or 5.3% for the year ended June 30, 2025, as compared to fiscal 2024, due to a $9.8 million decrease in personnel costs due to lower head count, a $3.1 million decrease in contractor costs and professional fees, a $2.6 million decrease in information technology and facilities costs, a $2.3 million decrease in travel costs, and $0.4 million in other expenses primarily related to lower depreciation expense.

[0001193125-26-352872:mdna:59]
General and Administrative Expenses

[0001193125-26-352872:mdna:60]
General and administrative expenses consist of personnel costs (which includes compensation, benefits and share-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001193125-26-352872:mdna:61]
General and administrative expenses decreased by $14.3 million or 10.3% for the year ended June 30, 2026, as compared to fiscal 2025, due to a $25.9 million decrease in expense for legal costs related to litigation matters, a $9.5 million decrease in other costs primarily related to allocated information technology costs and depreciation, partially offset by a $9.0 million increase in personnel costs due to higher compensation and benefits costs, a $5.2 million increase in amortization of cloud computing implementation costs, a $3.3 million increase in professional fees, a $2.6 million increase in software licensing costs, and a $1.0 million increase in other costs primarily related to system transition costs.

[0001193125-26-352872:mdna:62]
General and administrative expenses increased by $39.7 million or 39.7% for the year ended June 30, 2025, as compared to fiscal 2024, due to a $16.3 million increase in system transition costs, a $6.8 million increase in personnel costs due to higher compensation and benefits costs, a $24.2 million increase in expense for legal costs related to litigation matters and a $1.5 million increase in other costs primarily related to third-party licensing fees, information technology and travel costs, partially offset by a $5.2 million decrease in professional service fees and a $4.0 million decrease in depreciation expense.

[0001193125-26-352872:mdna:63]
Restructuring and Related Charges

[0001193125-26-352872:mdna:64]
During the fiscal years ended June 30, 2026, 2025 and 2024, we recorded restructuring and related charges of $1.3 million, $1.5 million and $36.3 million, respectively.

[0001193125-26-352872:mdna:65]
Fiscal year 2026

[0001193125-26-352872:mdna:66]
During fiscal 2026, we completed the restructuring plans initiated in prior years and incurred restructuring charges of $0.5 million related to severance and benefits costs and asset disposal costs related to those plans. Additionally, we recorded approximately $0.7 million in restructuring charges related to a one-time early termination fee for a facility lease exit. Refer to Note 14, Restructuring and Related Charges, in the Notes to Consolidated Financial Statements included elsewhere in this Report for additional information.

[0001193125-26-352872:mdna:67]
Fiscal year 2025

[0001193125-26-352872:mdna:68]
During fiscal 2025, we recorded $1.5 million of restructuring charges which were related to severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q2 2024 Plan” and “Q3 2024 Plan”, each as described in Note 14, Restructuring and Related Charges, in the Notes to Consolidated Financial Statements included elsewhere in this Report.

[0001193125-26-352872:mdna:69]
Fiscal year 2024

[0001193125-26-352872:mdna:70]
During fiscal 2024, we recorded $36.3 million of restructuring charges which were related to severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q1 2024 Plan”, “Q2 2024 Plan”, and “Q3 2024 Plan”, each as described in Note 14, Restructuring and Related Charges, in the Notes to Consolidated Financial Statements included elsewhere in this Report.

[0001193125-26-352872:mdna:71]
Amortization of Intangible Assets

[0001193125-26-352872:mdna:72]
We recorded $1.7 million, $2.0 million and $2.0 million of amortization expense in operating expenses for intangible assets related to certain intangibles from previous acquisitions for the fiscal years ended June 30, 2026, 2025 and 2024, respectively. There were no acquisitions or impairments of intangible assets during fiscal years ended June 30, 2026, 2025 and 2024.

[0001193125-26-352872:mdna:73]
Interest Income

[0001193125-26-352872:mdna:74]
Interest income was $4.2 million, $4.3 million and $4.6 million for fiscal years ended June 30, 2026, 2025 and 2024, respectively. The decrease in interest income between each fiscal year was driven by lower interest earned on cash deposits.

[0001193125-26-352872:mdna:75]
Interest Expense

[0001193125-26-352872:mdna:76]
We recorded $13.8 million, $15.9 million, and $17.0 million of interest expense for fiscal years ended June 30, 2026, 2025 and 2024, respectively. The decrease in interest expense between each fiscal year was driven by lower interest rates on lower outstanding balances under the Amended Credit Agreement.

[0001193125-26-352872:mdna:77]
Other Income (Expense), net

[0001193125-26-352872:mdna:78]
We had other expense, net of $1.6 million and $1.1 million and other income, net of less than $0.1 million in fiscal years ended June 30, 2026, 2025 and 2024, respectively. The other income (expense), net for fiscal years ended June 30, 2026, 2025 and 2024 was due to foreign exchange gains or losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001193125-26-352872:mdna:79]
Provision for Income Taxes

[0001193125-26-352872:mdna:80]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rate differs from the U.S. federal statutory rate of 21% primarily due to the impact of (i) Global Intangible Low-Tax Income (“GILTI”), (ii) the full valuation allowance against our deferred tax assets in the U.S. and certain foreign jurisdictions, (iii) foreign income taxes of our international

[0001193125-26-352872:mdna:81]
subsidiaries, and (iv) U.S. state taxes. For the fiscal years ended June 30, 2026, 2025 and 2024, we recorded income tax provisions of $9.4 million, $11.7 million, and $8.5 million, respectively.

[0001193125-26-352872:mdna:82]
For fiscal years 2026, 2025 and 2024, our tax provision is primarily related to (i) taxes on our foreign operations, including foreign withholding taxes remitted to foreign tax authorities by customers on our behalf, (ii) US federal taxes resulting from our US operations, (iii) tax expense related to the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business and (iv) state taxes in states where we have exhausted available net operating losses or are subject to certain franchise taxes qualifying as income tax under the relevant tax accounting guidance.

[0001193125-26-352872:mdna:83]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 15, Income Taxes, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K.

[0001193125-26-352872:mdna:84]
Critical Accounting Estimates

[0001193125-26-352872:mdna:85]
The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting estimates described below, among others, require more significant judgments and estimates when used in the preparation of our consolidated financial statements. Historically, our assumptions, judgments and estimates relative to these areas have not differed materially from actual results.

[0001193125-26-352872:mdna:86]
Revenue Recognition

[0001193125-26-352872:mdna:87]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for the products we offer. We sell our products and SaaS and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell primarily to end-users. Products and services may be sold separately or in bundled packages.

[0001193125-26-352872:mdna:88]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, we consider the promise to transfer products and services, each of which is distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0001193125-26-352872:mdna:89]
We generally do not grant return privileges and pricing credits to our value-added resellers, non-stocking distributors and end-user customers, except for defective products during the warranty period. We may provide sales incentives and other programs to these customers which are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the historical actuals.

[0001193125-26-352872:mdna:90]
Our stocking distributors are allowed certain price adjustments in the form of rebates and limited stock rotation rights. In determining the transaction price, we consider these rebates to be variable consideration which are estimated based on an analysis of historical claims at the distributor level. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotations are an additional form of variable consideration and are estimated based on an analysis of historical return rates.

[0001193125-26-352872:mdna:91]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price. The stand-alone selling prices are determined based on the prices at which we separately sell these products. For items that are not sold separately, we estimate the stand-alone selling prices using other observable inputs.

[0001193125-26-352872:mdna:92]
Our performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of our product revenues are recognized at a point in time and our subscription and support revenues are recognized over time. For revenues recognized over time, we use an input measure, days elapsed, to measure progress.

[0001193125-26-352872:mdna:93]
See Note 3, Revenues, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information.

[0001193125-26-352872:mdna:94]
Inventory Valuation and Purchase Commitments

[0001193125-26-352872:mdna:95]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0001193125-26-352872:mdna:96]
New Accounting Pronouncements

[0001193125-26-352872:mdna:97]
See Note 2, Summary of Significant Accounting Policies, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001193125-26-352872:mdna:98]
Liquidity and Capital Resources

[0001193125-26-352872:mdna:99]
The following summarizes information regarding our cash and cash equivalents (in thousands):

[0001193125-26-352872:mdna:100]
|  |  | June 30, 2026 |  |  | June 30, 2025 |  |
| Cash and cash equivalents |  | $ | 211,758 |  |  | $ | 231,745 |  |

[0001193125-26-352872:mdna:101]
As of June 30, 2026, our principal sources of liquidity consisted of cash and cash equivalents of $211.8 million, accounts receivable, net of $164.6 million, and available borrowings under our 2023 Revolving Facility (as defined below) of $135.6 million. As described below under “2026 Credit Agreement,” on July 29, 2026 we terminated the Amended Credit Agreement and entered into a new $500.0 million revolving credit facility, under which $300.0 million of revolving commitments remained available for borrowing as of the closing date. We anticipate our principal uses of cash and cash equivalents for fiscal 2027 will be purchases of raw materials and finished goods inventory from our contract manufacturers, payroll, share repurchases, payments under debt obligations and related interest, payments under lease obligations, purchases of property and equipment and other operating expenses related to the development and marketing of our products. We believe that our existing cash and cash equivalents, cash flows from operations, and the availability of borrowings under the 2026 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months. We are not currently aware of any material cash requirements beyond the next 12 months other than those described above for fiscal 2027 and our known contractual obligations. See the section titled “Contractual Obligations” below.

[0001193125-26-352872:mdna:102]
On February 18, 2025, we announced that our Board had authorized management to repurchase up to $200.0 million of shares of the Company's common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”). Under these repurchase programs, purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan or through accelerated share repurchase agreements. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The 2025 Repurchase Program does not obligate us to acquire any shares of our common stock, and it may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations.

[0001193125-26-352872:mdna:103]
During the year ended June 30, 2026, we repurchased a total of 5,377,808 shares of our common stock, at a total cost of $87.0 million, with an average price of $16.18 per share. As of June 30, 2026, we had $113.0 million available under the 2025 Repurchase Program.

[0001193125-26-352872:mdna:104]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provided for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with specified Consolidated Leverage Ratio tests. We may use proceeds of the loans for working capital and general corporate purposes.

[0001193125-26-352872:mdna:105]
At our election, the initial term loan (the “Initial Term Loan”) under the 2023 Credit Agreement may be made as either a base rate loan or a Secured Overnight Financing Rate (“SOFR loan”). The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s Consolidated Leverage Ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum.

[0001193125-26-352872:mdna:106]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001193125-26-352872:mdna:107]
On August 14, 2024, we entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, we modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the Amended Credit Agreement. The amended definition of consolidated EBITDA modified the amount and type of add-backs that are allowable to better align with our operations and activities.

[0001193125-26-352872:mdna:108]
During the year and as of June 30, 2026, we were in compliance with all the terms and financial covenants under the Amended Credit Agreement. The Amended Credit Agreement was terminated on July 29, 2026 in connection with our entry into the 2026 Credit Agreement described below.

[0001193125-26-352872:mdna:109]
On July 29, 2026, we entered into a Credit Agreement (the “2026 Credit Agreement”) with the lenders party thereto and JPMorgan Chase Bank, N.A., as administrative agent. The 2026 Credit Agreement provides for a five-year revolving loan facility in an aggregate principal amount of $500.0 million (the “2026 Revolving Facility”). The 2026 Revolving Facility includes an uncommitted accordion feature, pursuant to which we may request incremental revolving loan commitments and/or incremental term loans in an aggregate amount not to exceed the sum of (A) the greater of (i) $175.0 million and (ii) 100.0% of Consolidated EBITDA, plus (B) an amount equal to any voluntary prepayments (in the case of voluntary prepayments of revolving indebtedness, accompanied by a permanent reduction to the related revolving commitments) of indebtedness under the 2026 Revolving Facility and other first lien indebtedness, plus (C) an unlimited amount subject to pro forma compliance with our consolidated total net leverage ratio and consolidated interest charge coverage ratio financial covenants.

[0001193125-26-352872:mdna:110]
Borrowings under the 2026 Revolving Facility will bear interest at a fluctuating rate per annum equal to, at our option, either the Alternate Base Rate (as defined in the 2026 Credit Agreement) or the Adjusted Term SOFR Rate (as defined in the 2026 Credit Agreement) in each case, plus an applicable margin that is calculated based on our consolidated total net leverage ratio from time to time and ranges from 1.25% to 2.00% in the case of loans accruing interest based on the Adjusted Term SOFR Rate and from 0.25% to 1.00% in the case of loans accruing interest based on the Alternate Base Rate (it being understood that the Adjusted Term SOFR Rate as defined can be no lower than 0.00% and the Alternate Base Rate as defined can be no lower than 1.00%). In addition, we have agreed to pay to the lenders under the 2026 Credit Agreement certain customary fees, including a commitment fee on the average daily unused portion of the revolving commitments under the 2026 Revolving Facility, which ranges from 0.20% to 0.25% based on our consolidated total net leverage ratio from time to time.

[0001193125-26-352872:mdna:111]
Financial covenants under the 2026 Credit Agreement require us to maintain (i) a consolidated interest charge coverage ratio of at least 3.00 to 1.00 at the end of each fiscal quarter, commencing with the fiscal quarter ending September 30, 2026, and (ii) a consolidated total net leverage ratio not to exceed 3.75 to 1.00 (with a step-up to 4.25 to 1.00 for a specified period of time upon consummation of a material acquisition) at the end of each fiscal quarter, commencing with the fiscal quarter ending September 30, 2026. The 2026 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate, or sell all or substantially all of its assets.

[0001193125-26-352872:mdna:112]
On the closing date of the 2026 Credit Agreement, we repaid all outstanding indebtedness under the Amended Credit Agreement, together with all accrued and unpaid interest and fees. At closing, we borrowed $200.0 million under the 2026 Revolving Facility and used the proceeds to repay the outstanding indebtedness under the Amended Credit Agreement and to pay fees and expenses related to the 2026 Revolving Facility. As of the closing date, $200.0 million of revolving loans were outstanding under the 2026 Revolving Facility and $300.0 million of revolving commitments remained available for borrowing thereunder.

[0001193125-26-352872:mdna:113]
Key Components of Cash Flows and Liquidity

[0001193125-26-352872:mdna:114]
A summary of the sources and uses of cash and cash equivalents is as follows for the fiscal years ended June 30, 2026, 2025 and 2024 (in thousands):

[0001193125-26-352872:mdna:115]
|  |  | Year Ended |  |
|  |  | June 30, 2026 |  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| Net cash provided by operating activities |  | $ | 123,182 |  |  | $ | 152,031 |  |  | $ | 55,486 |  |
| Net cash used in investing activities |  |  | (27,941 | ) |  |  | (24,713 | ) |  |  | (18,121 | ) |
| Net cash used in financing activities |  |  | (114,500 | ) |  |  | (52,586 | ) |  |  | (114,978 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (728 | ) |  |  | 314 |  |  |  | (514 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (19,987 | ) |  | $ | 75,046 |  |  | $ | (78,127 | ) |

[0001193125-26-352872:mdna:116]
Cash and cash equivalents were $211.8 million at June 30, 2026, representing a decrease of approximately $20.0 million from $231.7 million at June 30, 2025. This decrease was due to cash used in financing activities of $114.5 million mainly as a result of payments for borrowings under the Amended Credit Agreement and share repurchases as well as cash used in investing activities of

[0001193125-26-352872:mdna:117]
$27.9 million for purchases of property and equipment and capitalized software development costs, offset by cash provided by operating activities of $123.2 million.

[0001193125-26-352872:mdna:118]
Cash and cash equivalents were $231.7 million at June 30, 2025, representing an increase of $75.0 million from $156.7 million at June 30, 2024. This increase was due to cash provided by operating activities of $152.0 million, offset by cash used in financing activities of $52.6 million mainly as a result of payments for borrowings under the Amended Credit Agreement and share repurchases as well as cash used in investing activities of $24.7 million for purchases of property and equipment.

[0001193125-26-352872:mdna:119]
Net Cash Provided by Operating Activities

[0001193125-26-352872:mdna:120]
Cash provided by operating activities during the fiscal year ended June 30, 2026 was $123.2 million. Factors contributing to cash provided by operating activities were net income of $42.1 million and non-cash expenses of $129.5 million for items such as amortization of intangible assets, amortization of cloud computing implementation costs, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in inventories and increases in accounts payable, accrued compensation and benefits and deferred revenue. This was partially offset by increases in net accounts receivable and prepaid expenses and other assets, and decreases in operating lease liabilities and other current and long-term liabilities.

[0001193125-26-352872:mdna:121]
Cash provided by operating activities during the fiscal year ended June 30, 2025 was $152.0 million. Factors contributing to cash provided by operating activities were the net loss of $7.5 million and non-cash expenses of $118.1 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in inventories and increases in accounts payable, accrued compensation and benefits, deferred revenue and other accrued liabilities. This was partially offset by increases in net accounts receivable and prepaid expenses and other assets, and a decrease in operating lease liabilities.

[0001193125-26-352872:mdna:122]
Cash provided by operating activities during the fiscal year ended June 30, 2024 was $55.5 million. Factors contributing to cash provided by operating activities were the net loss of $86.0 million and non-cash expenses of $187.6 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in accounts receivable and increases in deferred revenue and other current liabilities. These amounts were partially offset by increases in inventories and prepaid expenses and other assets and decreases in accounts payable, accrued compensation and benefits, and operating lease liabilities.

[0001193125-26-352872:mdna:123]
Net Cash Used in Investing Activities

[0001193125-26-352872:mdna:124]
Cash used in investing activities during the fiscal year ended June 30, 2026 was $27.9 million for purchases of property and equipment and capitalized software development costs.

[0001193125-26-352872:mdna:125]
Cash used in investing activities during the fiscal year ended June 30, 2025 was $24.7 million for purchases of property and equipment.

[0001193125-26-352872:mdna:126]
Cash used in investing activities during the fiscal year ended June 30, 2024 was $18.1 million for purchases of property and equipment.

[0001193125-26-352872:mdna:127]
Net Cash Used in Financing Activities

[0001193125-26-352872:mdna:128]
Cash used in financing activities during the fiscal year ended June 30, 2026 was $114.5 million due to share repurchases of $87.0 million, debt repayments of $15.0 million and $12.5 million in payments for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and through exercise of stock options.

[0001193125-26-352872:mdna:129]
Cash used in financing activities during the fiscal year ended June 30, 2025 was $52.6 million due to share repurchases of $38.0 million, debt repayments of $10.0 million and $3.9 million in payments for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and through the exercise of stock options.

[0001193125-26-352872:mdna:130]
Cash used in financing activities during the fiscal year ended June 30, 2024 was $115.0 million due primarily to share repurchases of $49.9 million, payments on the 2023 Revolving Facility of $55.0 million, debt repayments of $10.0 million and a $30.1 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP. The amounts were partially offset by cash received of $30.0 million from borrowings under the 2023 Revolving Facility.

[0001193125-26-352872:mdna:131]
Foreign Currency Effect on Cash and cash equivalents

[0001193125-26-352872:mdna:132]
Foreign currency effect on cash and cash equivalents decreased in 2026, primarily due to changes in exchange rates between the U.S. Dollar and the Indian Rupee, U.K. Pound, and the Euro.

[0001193125-26-352872:mdna:133]
Contractual Obligations

[0001193125-26-352872:mdna:134]
As of June 30, 2026, we had contractual obligations for debt obligations, purchase obligations, lease obligations and other obligations.

[0001193125-26-352872:mdna:135]
Our debt obligations relate to amounts owed under our Amended Credit Agreement. As of June 30, 2026, we have $165.0 million of debt outstanding which is payable in quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our debt obligations.

[0001193125-26-352872:mdna:136]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of June 30, 2026, we have non-cancelable commitments to purchase $112.5 million of inventory. See Note 9, Commitments and Contingencies, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our purchase obligations.

[0001193125-26-352872:mdna:137]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of June 30, 2026, the value of our obligations under operating leases was $30.8 million. See Note 8, Leases, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our lease obligations.

[0001193125-26-352872:mdna:138]
We have contractual commitments with our suppliers which represent commitments for future services. As of June 30, 2026, we have contractual commitments of $21.5 million that are due through our fiscal year 2029.

[0001193125-26-352872:mdna:139]
We have immaterial income tax liabilities related to uncertain tax positions and we are unable to reasonably estimate the timing of the settlement of those liabilities.

[0001193125-26-352872:mdna:140]
We do not have any material commitments for capital expenditures as of June 30, 2026.

[0001193125-26-352872:mdna:141]
Off-Balance Sheet Arrangements

[0001193125-26-352872:mdna:142]
We did not have any off-balance sheet arrangements as of June 30, 2026.
