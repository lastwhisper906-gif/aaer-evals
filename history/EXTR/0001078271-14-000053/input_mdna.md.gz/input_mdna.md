# EXTR MD&A — 0001078271-14-000053


## mdna

[0001078271-14-000053:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001078271-14-000053:mdna:2]
Business Overview

[0001078271-14-000053:mdna:3]
We develop and sell network infrastructure equipment and offer related services contracts for extended warranty and maintenance to our enterprise, data center and service provider customers. Substantially all of our revenue is derived from the sale of our networking equipment and related service contracts.

[0001078271-14-000053:mdna:4]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal year ended June 30, 2014.

[0001078271-14-000053:mdna:5]
We are a leading provider of network infrastructure equipment and services for enterprises, data centers, and service

[0001078271-14-000053:mdna:6]
providers. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. Our corporate

[0001078271-14-000053:mdna:7]
headquarters are located in San Jose, California. We develop and sell network infrastructure equipment to our enterprise, data

[0001078271-14-000053:mdna:8]
center and telecommunications service provider customers.

[0001078271-14-000053:mdna:9]
On October 31, 2013 (the “Acquisition Date”), we completed the acquisition of Enterasys Networks, Inc. (“Enterasys”), a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired, whereby Enterasys became our wholly-owned subsidiary. The combined entity immediately became a networking industry leader with more than 12,000 customers. As a combined Company, we believe we will set the standard for the networking industry with a strategic focus on three principles:

[0001078271-14-000053:mdna:10]
Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center

[0001078271-14-000053:mdna:11]
networking, switching and routing, Software-Defined Networking (SDN), wired and wireless LAN access, network

[0001078271-14-000053:mdna:12]
management with analytics and integrated security features. This broader solutions portfolio can be leveraged to better serve existing and new customers. We will continue to enhance and support the product roadmaps of both companies going forward to protect the investments of customers and avoid any disruption to their businesses. We intend to increase research and development to accelerate our vision for high-performance, modular, open networking.

[0001078271-14-000053:mdna:13]
Leading customer service and support: We are working to augment our current outsourced support model by

[0001078271-14-000053:mdna:14]
integrating Enterasys' in-sourced expertise, building on Enterasys' award-winning heritage and strong commitment

[0001078271-14-000053:mdna:15]
to exceptional customer experience. The Company's expanded global network of channel partners and distributors

[0001078271-14-000053:mdna:16]
will benefit from expanded services and support capabilities.

[0001078271-14-000053:mdna:17]
Strong Channels and Strategic Partners: Our focus is to leverage the capabilities of the combined

[0001078271-14-000053:mdna:18]
Company and expand existing partnerships with Ericsson and the developing partnership with Lenovo as well as

[0001078271-14-000053:mdna:19]
continue to add new strategic partnerships in the future. Additionally, we will increase our focus on partnering with

[0001078271-14-000053:mdna:20]
distributors and channel partners globally. The goal is to develop and enhance relationships that grow revenue

[0001078271-14-000053:mdna:21]
and profits for the Company and our alliance and channel partners. At the same time, we are investing in

[0001078271-14-000053:mdna:22]
infrastructure to make doing business with the Company easier and more efficient.

[0001078271-14-000053:mdna:23]
Also, on October 31, 2013, the Company entered into a $125 million senior secured credit facilities agreement consisting of a $65 million term loan facility (“Term Loan”) and a revolving credit facility of $60 million (“Revolving Facility”).  Both facilities mature on October 31, 2018.  The Company drew $35 million of the $60 million Revolving Facility on the acquisition date and used the proceeds from the Term Loan to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys.

[0001078271-14-000053:mdna:24]
Impact of the Global Economic Developments

[0001078271-14-000053:mdna:25]
We believe that the slow economic recovery in the United States, Asia and Europe, and other challenges affecting global economic conditions placed significant limitations on our financial performance. We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. Sales in APAC and some European countries were most impacted as a result of the soft global economy. We believe that conservative purchasing patterns and delays or cancellation of IT infrastructure plans in the face of continued uncertainty regarding the global economy, may continue to negatively impact overall demand for networking solutions, including Ethernet equipment.

[0001078271-14-000053:mdna:26]
We have taken, and plan to continue to take, other steps to manage our business in the current economic environment. For example, we have managed from time to time our contingent work force, consolidation of office locations, reduced travel and other discretionary spending, realigned our product portfolio and organization to grow revenue and operating income, and controlled all hiring activities.

[0001078271-14-000053:mdna:27]
Increasing Demand for Bandwidth

[0001078271-14-000053:mdna:28]
We believe that the continued increase in demand for bandwidth will over time drive future demand for high performance Ethernet solutions. Wide-spread adoption of electronic communications in all aspects of our lives, proliferation of next generation converged mobile devices and deployment of triple-play services to residences and businesses alike, continues to generate demand for greater network performance across broader geographic locations. In parallel to these transformational forces within society and the community at large, the accelerating adoption of internet and intranet “cloud” solutions within business enterprises is enabling organizations to offer greater business scalability to improve efficiency and through more effective operations, improve profitability. In order to realize the benefits of these developments, customers require additional bandwidth and high performance from their network infrastructure at affordable prices. We are seeing the initial indications that the Ethernet segment of the networking equipment market will return to growth as enterprise, data center and carrier customers continue to recognize the performance and operating cost benefits of Ethernet technology.

[0001078271-14-000053:mdna:29]
Expanding Product Portfolio

[0001078271-14-000053:mdna:30]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but is not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology. Over the past few years, we further extended our product portfolio through continued evolutions of our BlackDiamond BDX8, a highly-scalable core switch for IT and cloud data centers, the Summit family of stackable switches for the intelligent edge, the S-series flow-based switching for campus and data center, the identiFi Wi-Fi product portfolio with both indoor and outdoor 802.11a/b/g/n/ac access points, the E4G Cell Site Router family for mobile backhaul, and a revamp of our software and network management solutions that include: NetSight for centralized network management and NAC/Mobile-IAM that provides BYOD management and network access control solution for wired and wireless LAN and VPN users. During fiscal 2014, we also introduced key software functionality that will drive differentiation.  New software and hardware introductions during the current year included a Summit X770 switch supporting industry's highest density performing top of rack switching, Purview - a network-powered application analytics and optimization solution, identiFi 38xx WiFi Access Points supporting 802.11ac, SDN 2.0 - an open, standards-based (based on OpenDaylight) and comprehensive SDN solution, 100GbE support for the BDX8 and NetSight 6.0 a consolidated management across the expanded portfolio.​

[0001078271-14-000053:mdna:31]
Industry Developments

[0001078271-14-000053:mdna:32]
The market for network infrastructure equipment is highly competitive and dominated by a few large companies. The current economic climate has further driven consolidation of vendors within the Ethernet networking market and with vendors from adjacent markets, including storage, security, wireless and voice applications. We believe that the underpinning technology for all of these adjacent markets is Ethernet. As a result, independent Ethernet switch vendors are being acquired or merged with larger, adjacent market vendors to enable them to deliver complete and broad solutions. As an independent Ethernet switch vendor, we must provide products that, when combined with the products of our large strategic partners, create compelling solutions for end-user customers. Our acquisition of Enterasys gives us a larger market share and presence and an opportunity to create complementary solutions for our customers. Our approach is to focus on the intelligence and automation layer that spans our hardware products and that facilitates end-to-end solutions, as opposed to positioning Extreme Networks as a low-cost-vendor with point products. Lower overall market growth has also created an environment of declining margins due to increased competition between the remaining vendors in this space. During the last year, overall Ethernet port counts have grown, while industry revenues have decreased, signaling a decline in average selling price per port. Our product life cycle and operational cost reduction efforts are therefore even more critical for margin preservation.

[0001078271-14-000053:mdna:33]
Amendment to Rights Agreement

[0001078271-14-000053:mdna:34]
On November 27, 2012, our Board of Directors adopted an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of our Series A Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as amended on June 30, 2010; April 26, 2011, between us and Mellon Investor services LLC (the “Prior Rights Plan”).

[0001078271-14-000053:mdna:35]
The Board reviewed the necessity of the provisions of the Prior Rights Plan. The Prior Rights Plan was adopted to preserve the value of our deferred tax assets, including our net operating loss carry forwards, with respect to our ability to fully use its tax benefits to offset future income which may be limited if we experience an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of our common stock. Following its review, the Board decided it was necessary and in the best interests of us and our stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Our stockholders voted to extend the term of the Restated Rights Plan from April 30, 2013

[0001078271-14-000053:mdna:36]
to April 30, 2014 at our 2012 Annual Meeting of Stockholders, and the Restated Rights Plan was amended effective April 30, 2013 to reflect the extension of the term.  The Board of Directors unanimously approved an amendment to the Rights Plan effective April 30, 2014 to extend the Rights Plan through May 31, 2015, subject to ratification by a majority of the stockholders at the next annual meeting, expected to be held on November 12, 2014.

[0001078271-14-000053:mdna:37]
Results of Operations

[0001078271-14-000053:mdna:38]
Our operations and financial performance have been affected by the economic factors described above and our acquisition of Enterasys, and during fiscal 2014, we achieved the following results:

[0001078271-14-000053:mdna:39]
| • | Net revenue of $519.6 million, an increase of 73.6% from fiscal 2013 net revenue of $299.3 million. |

[0001078271-14-000053:mdna:40]
| • | Product revenue of $411.8 million, an increase of 71.6% from fiscal 2013 product revenue of $240.0 million. |

[0001078271-14-000053:mdna:41]
| • | Service revenue of $107.8 million, an increase of 81.5% from fiscal 2013 service revenue of $59.4 million. |

[0001078271-14-000053:mdna:42]
| • | Total gross margin of 51.5% of net revenue in fiscal 2014, compared to 54.3% in fiscal 2013. |

[0001078271-14-000053:mdna:43]
| • | Operating loss of $50.2 million (including acquisition and integration costs of $25.7 million, amortization of intangibles of $16.7 million, restructuring charges of $0.5 million, and $0.1 million of litigation settlement income), a decrease from operating income of $10.9 million in fiscal 2013. |

[0001078271-14-000053:mdna:44]
| • | Net loss was $57.3 million in fiscal 2014, a decrease from net income of $9.7 million in fiscal 2013. |

[0001078271-14-000053:mdna:45]
| • | Cash flow used in operating activities was $26.8 million, compared to cash flow provided by operating activities of $32.2 million in fiscal 2013, a decrease of $59.1 million. Cash and cash equivalents, short-term investments and marketable securities were $105.9 million as of June 30, 2014, a decrease of $99.7 million from fiscal 2013. |

[0001078271-14-000053:mdna:46]
Net Revenue

[0001078271-14-000053:mdna:47]
The following table presents net product and service revenue for the fiscal years 2014, 2013 and 2012 (dollars in thousands):

[0001078271-14-000053:mdna:48]
|  | Year Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |  | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 411,761 |  |  | $ | 239,955 |  |  | $ | 171,806 |  |  | 71.6 | % |  | $ | 239,955 |  |  | $ | 261,873 |  |  | $ | (21,918 | ) |  | (8.4 | )% |
| Percentage of net revenue | 79.3 | % |  | 80.2 | % |  |  |  |  |  | 80.2 | % |  | 81.2 | % |  |  |  |  |
| Service | 107,793 |  |  | 59,388 |  |  | 48,405 |  |  | 81.5 | % |  | 59,388 |  |  | 60,849 |  |  | (1,461 | ) |  | (2.4 | )% |
| Percentage of net revenue | 20.7 | % |  | 19.8 | % |  |  |  |  |  | 19.8 | % |  | 18.9 | % |  |  |  |  |
| Total net revenue | $ | 519,554 |  |  | $ | 299,343 |  |  | $ | 220,211 |  |  | 73.6 | % |  | $ | 299,343 |  |  | $ | 322,722 |  |  | $ | (23,379 | ) |  | (7.2 | )% |

[0001078271-14-000053:mdna:49]
Product revenue increased in fiscal 2014 as compared to fiscal 2013 primarily due to significant increase in the number of customers and products sold due to our acquisition of Enterasys in the second quarter of fiscal 2014.  This resulted in a significant increase in our product revenue in all regions.

[0001078271-14-000053:mdna:50]
Product revenue decreased in fiscal 2013 as compared to fiscal 2012 primarily due to weaker than expected demand from our public sector and enterprise customers in the United States and we continued to experience weak demand from our public sector and strategic customers and distributors in the EMEA region attributable to the persistent macroeconomic challenges in Western Europe.

[0001078271-14-000053:mdna:51]
Service revenue increased in fiscal 2014 as compared to fiscal 2013 primarily due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000053:mdna:52]
Service revenue decreased in fiscal 2013 as compared to fiscal 2012 reflecting slight decrease in the levels of service contract renewals.

[0001078271-14-000053:mdna:53]
As noted previously, we operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenue geographically for the fiscal years 2014, 2013 and 2012 (dollars in thousands):

[0001078271-14-000053:mdna:54]
|  | Year Ended |  | Year Ended |
| Net Revenue | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |  | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 211,734 |  |  | $ | 101,790 |  |  | $ | 109,944 |  |  | 108.0 | % |  | $ | 101,790 |  |  | $ | 106,110 |  |  | $ | (4,320 | ) |  | (4.1 | )% |
| Other | 45,790 |  |  | 33,584 |  |  | 12,206 |  |  | 36.3 | % |  | 33,584 |  |  | 34,970 |  |  | (1,386 | ) |  | (4.0 | )% |
| Total Americas | 257,524 |  |  | 135,374 |  |  | 122,150 |  |  | 90.2 | % |  | 135,374 |  |  | 141,080 |  |  | (5,706 | ) |  | (4.0 | )% |
| Percentage of net revenue | 49.6 | % |  | 45.2 | % |  |  |  |  |  | 45.2 | % |  | 43.7 | % |  |  |  |  |
| EMEA | 202,555 |  |  | 112,812 |  |  | 89,743 |  |  | 79.6 | % |  | 112,812 |  |  | 128,093 |  |  | (15,281 | ) |  | (11.9 | )% |
| Percentage of net revenue | 39.0 | % |  | 37.7 | % |  |  |  |  |  | 37.7 | % |  | 39.7 | % |  |  |  |  |
| APAC | 59,475 |  |  | 51,157 |  |  | 8,318 |  |  | 16.3 | % |  | 51,157 |  |  | 53,549 |  |  | (2,392 | ) |  | (4.5 | )% |
| Percentage of net revenue | 11.4 | % |  | 17.1 | % |  |  |  |  |  | 17.1 | % |  | 16.6 | % |  |  |  |  |
| Total net revenues | $ | 519,554 |  |  | $ | 299,343 |  |  | $ | 220,211 |  |  | 73.6 | % |  | $ | 299,343 |  |  | $ | 322,722 |  |  | $ | (23,379 | ) |  | (7.2 | )% |

[0001078271-14-000053:mdna:55]
Revenue increased in all regions in 2014 as compared to fiscal 2013 primarily due increased customers and service contracts from the acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000053:mdna:56]
Revenue in the EMEA decreased in 2013 as compared to fiscal 2012 primarily due to macroeconomic challenges which affected the demand from customers in those regions.  Revenue in the Americas and APAC decreased slightly as compared to fiscal 2012.

[0001078271-14-000053:mdna:57]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEM, and direct sales.  Revenue through our distributor channel was 44% of total product revenue in fiscal 2014, 43% of total product revenue in fiscal 2013, and 42% in fiscal 2012.

[0001078271-14-000053:mdna:58]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001078271-14-000053:mdna:59]
Cost of Revenue and Gross Profit

[0001078271-14-000053:mdna:60]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenue for the fiscal years 2014, 2013 and 2012 (dollars in thousands):

[0001078271-14-000053:mdna:61]
|  | Year Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |  | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 198,088 |  |  | $ | 124,093 |  |  | $ | 73,995 |  |  | 59.6 | % |  | $ | 124,093 |  |  | $ | 141,646 |  |  | $ | (17,553 | ) |  | (12.4 | )% |
| Percentage of product revenue | 48.1 | % |  | 51.7 | % |  |  |  |  |  | 51.7 | % |  | 54.1 | % |  |  |  |  |
| Service | 69,241 |  |  | 38,533 |  |  | 30,708 |  |  | 79.7 | % |  | 38,533 |  |  | 38,201 |  |  | 332 |  |  | 0.9 | % |
| Percentage of service revenue | 64.2 | % |  | 64.9 | % |  |  |  |  |  | 64.9 | % |  | 62.8 | % |  |  |  |  |
| Total gross profit | $ | 267,329 |  |  | $ | 162,626 |  |  | $ | 104,703 |  |  | 64.4 | % |  | $ | 162,626 |  |  | $ | 179,847 |  |  | $ | (17,221 | ) |  | (9.6 | )% |
| Percentage of net revenue | 51.5 | % |  | 54.3 | % |  |  |  |  |  | 54.3 | % |  | 55.7 | % |  |  |  |  |

[0001078271-14-000053:mdna:62]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, amortization of developed technology intangibles, royalties under

[0001078271-14-000053:mdna:63]
technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001078271-14-000053:mdna:64]
Product gross margin in fiscal 2014 decreased as compared to fiscal 2013 primarily due to a $11.1 million charge related to the utilization of the net increase in cost basis of the inventory acquired in connection with the purchase of Enterasys, $11.0 million for the amortization of developed technology intangibles from the acquisition of Enterasys during the second quarter of fiscal 2014 and increased stock compensation expenses offset by higher economic benefits realized in our manufacturing costs as compared to fiscal 2013.

[0001078271-14-000053:mdna:65]
Product gross margin in fiscal 2013 decreased as compared to fiscal 2012 due to lower product revenue and an increase in charges for excess and obsolete inventory offset by economic benefits realized in our manufacturing costs.

[0001078271-14-000053:mdna:66]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spares used in providing support under customer service contracts.

[0001078271-14-000053:mdna:67]
Service gross margin in fiscal 2014 increased as compared to fiscal 2013 primarily due to increased service revenue as a result of acquisition of Enterasys and cost reduction initiatives offset by higher personnel, overhead and travel cost as a result of our acquisition of Enterasys during the second quarter of fiscal 2014.

[0001078271-14-000053:mdna:68]
Service gross profit in fiscal 2013 increased as compared to fiscal 2012 primarily due to lower labor costs from our cost reduction initiatives.

[0001078271-14-000053:mdna:69]
Operating Expenses

[0001078271-14-000053:mdna:70]
The following table presents operating expenses and operating income (dollars in thousands):

[0001078271-14-000053:mdna:71]
|  | Year Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |  | June 30, 2013 |  | June 30, 2012 |  | $Change |  | %Change |
| Research and development | $ | 77,146 |  |  | $ | 40,521 |  |  | $ | 36,625 |  |  | 90.4 | % |  | $ | 40,521 |  |  | $ | 45,640 |  |  | $ | (5,119 | ) |  | (11.2 | )% |
| Sales and marketing | 156,666 |  |  | 87,202 |  |  | 69,464 |  |  | 79.7 | % |  | 87,202 |  |  | 90,167 |  |  | (2,965 | ) |  | (3.3 | )% |
| General and administrative | 40,912 |  |  | 26,725 |  |  | 14,187 |  |  | 53.1 | % |  | 26,725 |  |  | 28,658 |  |  | (1,933 | ) |  | (6.7 | )% |
| Acquisition and integration costs | 25,716 |  |  | — |  |  | 25,716 |  |  | 100.0 | % |  | — |  |  | — |  |  | — |  |  | — | % |
| Restructuring charge, net of reversals | 510 |  |  | 6,836 |  |  | (6,326 | ) |  | (92.5 | )% |  | 6,836 |  |  | 1,594 |  |  | 5,242 |  |  | 328.9 | % |
| Amortization of intangibles | 16,711 |  |  | — |  |  | 16,711 |  |  | 100.0 | % |  | — |  |  | — |  |  | — |  |  | — | % |
| Litigation settlement (income)/loss | (100 | ) |  | 2,029 |  |  | (2,129 | ) |  | (104.9 | )% |  | 2,029 |  |  | (121 | ) |  | 2,150 |  |  | (1,776.9 | )% |
| Gain on sale of campus | — |  |  | (11,539 | ) |  | 11,539 |  |  | (100.0 | )% |  | (11,539 | ) |  | — |  |  | (11,539 | ) |  | 100.0 | % |
| Total operating expenses | $ | 317,561 |  |  | $ | 151,774 |  |  | $ | 165,787 |  |  | 109.2 | % |  | $ | 151,774 |  |  | $ | 165,938 |  |  | $ | (14,164 | ) |  | (8.5 | )% |
| Operating (loss) income | $ | (50,232 | ) |  | $ | 10,852 |  |  | $ | (61,084 | ) |  | (562.9 | )% |  | $ | 10,852 |  |  | $ | 13,909 |  |  | $ | (3,057 | ) |  | (22.0 | )% |

[0001078271-14-000053:mdna:72]
The following table highlights our operating expenses and operating income as a percentage of net revenues:

[0001078271-14-000053:mdna:73]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Research and development | 14.8 | % |  | 13.5 | % |  | 14.1 | % |
| Sales and marketing | 30.2 | % |  | 29.1 | % |  | 27.9 | % |
| General and administrative | 7.9 | % |  | 8.9 | % |  | 8.9 | % |
| Acquisition and integration costs | 5.0 | % |  | — | % |  | — | % |
| Restructuring charge, net of reversals | 0.1 | % |  | 2.3 | % |  | 0.5 | % |
| Amortization of intangibles | 3.2 | % |  | — | % |  | — | % |
| Litigation settlement (income)/loss | — | % |  | 0.7 | % |  | — | % |
| Gain on sale of campus | — | % |  | (3.9 | )% |  | — | % |
| Total operating expenses | 61.1 | % |  | 50.6 | % |  | 51.4 | % |
| Operating (loss) income | (9.7 | )% |  | 3.6 | % |  | 4.3 | % |

[0001078271-14-000053:mdna:74]
Research and Development Expenses

[0001078271-14-000053:mdna:75]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products. Research and development expenses increased in fiscal 2014 as compared to fiscal 2013 primarily due to increased personnel and occupancy costs as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000053:mdna:76]
Research and development expenses decreased in fiscal 2013 as compared to fiscal 2012 primarily due to lower spending on engineering projects due to differences in timing and pattern of planned engineering project spending as compared to fiscal 2012.

[0001078271-14-000053:mdna:77]
Sales and Marketing Expenses

[0001078271-14-000053:mdna:78]
Sales and marketing expenses consist of salaries, commissions and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses. Sales and marketing expenses increased in fiscal 2014 as compared to fiscal 2013 primarily due to increased personnel costs as well as additional spending on additional sales and marketing programs, as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000053:mdna:79]
Sales and marketing expenses decreased in fiscal 2013 as compared to fiscal 2012 primarily due to lower commissions and reduced personnel costs resulting from lower revenue levels and a reduction in headcount during the year.

[0001078271-14-000053:mdna:80]
General and Administrative Expenses

[0001078271-14-000053:mdna:81]
General and administrative expenses increased in fiscal 2014 as compared to fiscal 2013 primarily due to higher personnel and travel costs and higher occupancy costs as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-14-000053:mdna:82]
General and administrative expenses decreased in fiscal 2013 as compared to fiscal 2012 primarily due to cost reduction initiatives realized as part of the restructuring plan offset by CEO transition expenses of $2.1 million.

[0001078271-14-000053:mdna:83]
Acquisition and Integration Costs

[0001078271-14-000053:mdna:84]
As a result of our acquisition of Enterasys, we incurred $25.7 million of acquisition and integration costs in fiscal 2014.  Of the total $25.7 million expense for fiscal 2014, $19.7 million expense related to integration costs and the remaining $6.0 million expense related to acquisition costs. The Company expects to incur integration costs for the next two years at a lower rate.

[0001078271-14-000053:mdna:85]
Amortization of Intangibles

[0001078271-14-000053:mdna:86]
During fiscal 2014, we recorded $16.7 million of amortization expenses primarily for certain intangibles related to the acquisition of Enterasys.

[0001078271-14-000053:mdna:87]
Restructuring Charge, Net of Reversal

[0001078271-14-000053:mdna:88]
During fiscal 2014, 2013 and 2012, we recorded restructuring charges, net of reversals, of $0.5 million, $6.8 million, and $1.6 million, respectively.

[0001078271-14-000053:mdna:89]
Fiscal 2013 Restructuring

[0001078271-14-000053:mdna:90]
During the second quarter of fiscal 2013, we reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. As part of our restructuring efforts in the second quarter of fiscal 2013, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. We have substantially expensed all costs associated with this initiative.  As of June 30, 2014, we had restructuring liabilities of $0.3 million related to the fiscal 2013 restructuring, which we anticipate paying by the end of fiscal 2015.

[0001078271-14-000053:mdna:91]
Fiscal 2012 Restructuring

[0001078271-14-000053:mdna:92]
During fiscal 2012, we incurred total charges of $2.2 million, including $1.8 million related to severance, $0.1 million of contract termination fees, and $0.2 million other charges. A portion of this restructuring activity was related to the liquidation of our Japan subsidiary with a cost of $0.5 million at June 30, 2012. We substantially liquidated the subsidiary in Japan in the fourth quarter or fiscal 2012, as part of our broad restructuring effort. We disposed of the remaining immaterial assets and liabilities and completed the liquidation process during fiscal 2013.  There were no outstanding liabilities related to the fiscal 2012 restructuring as of June 30, 2014.

[0001078271-14-000053:mdna:93]
Fiscal 2011 Restructuring

[0001078271-14-000053:mdna:94]
During fiscal 2011, we commenced a strategy to focus on growing revenue in specific market verticals and on improving operational effectiveness.  As of June 30, 2013, we had restructuring liabilities of $0.4 million remaining related to the fiscal 2011 restructuring, which we paid during fiscal 2014.

[0001078271-14-000053:mdna:95]
Litigation Settlement (Income) Expense

[0001078271-14-000053:mdna:96]
During the third quarter of fiscal 2014, the Company received $0.1 million from the settlement of a property lease litigation matter.

[0001078271-14-000053:mdna:97]
During the third quarter of fiscal 2013, we recognized a litigation charge of $2.5 million related to a settlement agreement entered into with Enterasys Networks prior to the acquisition.

[0001078271-14-000053:mdna:98]
During the fourth quarter of fiscal 2012, from a judgment related to our lawsuit with Enterasys Networks for patent infringement, we received $0.6 million from Enterasys including a first trial damage award of $0.2 million, reimbursement of legal costs from the first trial of $0.4 million, and interest.

[0001078271-14-000053:mdna:99]
Gain on Sale of Campus

[0001078271-14-000053:mdna:100]
During fiscal 2013, we completed the sale of our corporate campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of approximately $44.7 million of which approximately $2.0 million was received in fiscal 2012. We realized a gain of approximately $11.5 million in connection with this transaction, yet recorded a tax loss of approximately $24.6 million.

[0001078271-14-000053:mdna:101]
Interest Income

[0001078271-14-000053:mdna:102]
Interest income was $0.8 million in fiscal 2014, $1.1 million in fiscal 2013 and $1.2 million in fiscal 2012, representing a decrease of $0.3 million in fiscal 2014 from fiscal 2013, and a decrease of $0.1 million in fiscal 2013 from fiscal 2012.  The decrease in interest income in fiscal 2014 from fiscal 2013 was due to a decrease in the investment balance to fund a portion of the acquisition of Enterasys.  The decrease in interest income in fiscal 2013 from fiscal 2012 was due to a decrease in the average interest yield from 0.95% in fiscal 2012 to 0.54% in fiscal 2013.

[0001078271-14-000053:mdna:103]
Interest Expense

[0001078271-14-000053:mdna:104]
We had $2.1 million interest expense for fiscal 2014.  Interest expense was immaterial for both fiscal years 2013 and 2012.  Interest expense in fiscal 2014 primarily related to the Credit Facility that the Company entered into on October 31, 2013 to fund the acquisition of Enterasys.

[0001078271-14-000053:mdna:105]
Interest expense in fiscal 2013 and fiscal 2012 were primarily related to interest amortization of technology agreements.

[0001078271-14-000053:mdna:106]
Other (Expense) Income, net

[0001078271-14-000053:mdna:107]
Other (expense) income net was expense of $1.6 million in fiscal 2014, expense of $0.6 million in fiscal 2013 and income of $2.0 million in fiscal 2012.  Other expense in fiscal 2014 was primarily due to the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.

[0001078271-14-000053:mdna:108]
Other expense in fiscal 2013 was primarily due to the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. dollars.

[0001078271-14-000053:mdna:109]
Other income in fiscal 2012 was primarily comprised of $1.9 million in foreign currency translation gains that were reclassified from other comprehensive income (loss) due to the substantial liquidation of our Japan subsidiary.

[0001078271-14-000053:mdna:110]
Provision for Income Taxes

[0001078271-14-000053:mdna:111]
We are subject to income taxes in the United States and numerous foreign jurisdictions.  Our effective tax rate differs from the U.S. federal statutory rate of 35% primarily due to the impact of state taxes, foreign operations which are generally taxed at lower statutory rates and the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions.  For the fiscal years ended June 30, 2014, 2013 and 2012, we recorded income tax provisions of $4.2 million, $1.7 million and $1.2 million respectively. The effective tax rates for fiscal years ended June 30, 2014, 2013 and 2012 were 7.9%, 14.8% and 7.0% respectively.

[0001078271-14-000053:mdna:112]
For the fiscal years ended June 30, 2014, 2013 and 2012 the vast majority of our tax provision relates to taxes on our foreign operations as well as state taxes due to the full valuation allowance on our U.S. and certain foreign deferred tax assets.  In the fiscal year ended June 30, 2014, a portion of our provision resulted from the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc.

[0001078271-14-000053:mdna:113]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 35% and for further explanation of our provision for income taxes, see Note 9 to the consolidated financial statements.

[0001078271-14-000053:mdna:114]
Critical Accounting Policies and Estimates

[0001078271-14-000053:mdna:115]
Our significant accounting policies are more fully described in Note 3 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001078271-14-000053:mdna:116]
Revenue Recognition

[0001078271-14-000053:mdna:117]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance service contracts, professional services, and training for our products. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and the collection of the sales proceeds is reasonably assured. In instances where any of the criteria for revenue recognition are not met, we defer revenue until all criteria have been met.

[0001078271-14-000053:mdna:118]
Product revenue from our value-added resellers, non-stocking distributors and end-user customers is recognized at the time of shipment, provided that all of the foregoing revenue recognition requirements have been satisfied.  We generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits. Accordingly, we recognize revenue upon transfer of title and risk of loss to the customer, which is generally upon shipment. We maintain estimated accruals and allowances for sales incentives and other programs that we may make available to our partners, based on historical experience or applicable contractual terms. Shipping costs are included in cost of product revenues. Sales taxes collected from customers are excluded from revenues.

[0001078271-14-000053:mdna:119]
We also sell our products to distributors that stock inventory and sell to resellers. We defer recognition of revenue on all sales to our stocking distributors until the distributors have sold the products, as evidenced by sales data that the distributors provide to us. We grant stocking distributors certain price protection rights and the right to return a portion of unsold inventory for the purpose of stock rotation. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. We also provide stocking distributors with credits for changes in selling prices based on competitive conditions, and provide funding for our distributors and their resellers to perform marketing development activities. We maintain estimated accruals and allowances for these exposures based upon our contractual obligations. Our marketing development channel programs do not meet the criteria for recognizing the costs as marketing expenses and therefore these costs are accrued as a reduction to revenue in the same period that the products are sold.

[0001078271-14-000053:mdna:120]
Revenue from service contracts is deferred and recognized ratably over the contractual service period, which is typically from one to two years. Professional service revenue is recognized upon delivery or completion of performance.

[0001078271-14-000053:mdna:121]
Our networking products are tangible products that contain software and non-software components that function together to deliver the tangible product's essential functionality. Our sales arrangements may contain multiple deliverables comprised of our tangible products, standalone software licenses, and service offerings depending on the distribution sales channel through which the products are sold and the requirements of our customers. We recognize revenue for our multiple deliverable arrangements in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. The industry-specific software revenue recognition guidance does not apply to the sales of our tangible products.  Software revenue guidance is applied to sales of our standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-14-000053:mdna:122]
Pursuant to the guidance of the accounting standard for multiple-deliverable revenue arrangements, we allocate the total arrangement consideration to each separable element of an arrangement based on the relative selling price of each element.  We determine the standalone selling price for each element based on a selling price hierarchy. Under the selling price hierarchy, the selling price for each deliverable is based on our vendor-specific objective evidence of selling price (“VSOE”), which is determined by a substantial majority of our historical standalone sales transactions for a product or service falling within a reasonable range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, we determine the best estimate of standalone selling price (“ESP”) for a product or service by considering several factors including, but not limited to, the 12-month historical median sales price, sales channels, geography, gross margin consistency, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, we apply management judgment to determine the best estimate of selling price through consultation with and formal approval by our management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of all other deliverables is determined by using ESP. We regularly review VSOE, TPE and ESP for all of our products and services and maintain internal controls over the establishment and updates of these estimates.

[0001078271-14-000053:mdna:123]
Pursuant to the software revenue recognition accounting standard, we continue to recognize revenue for software using the residual method for our sales of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the multiple deliverable arrangement, we recognize revenue in accordance with our policies for product, software, and service revenue recognition.

[0001078271-14-000053:mdna:124]
Our total deferred product revenue from customers other than distributors was $4.1 million and $3.1 million as of June 30, 2014 and June 30, 2013, respectively. Our total deferred revenue for services, primarily from service contracts, was $97.7 million as of June 30, 2014 and $38.7 million as of June 30, 2013. Service contracts typically range from one to two years. Shipping costs are included in cost of product revenues.

[0001078271-14-000053:mdna:125]
We provide an allowance for sales returns based on our historical returns, analysis of credit memo data and our return policies. The allowance for sales returns was $2.7 million and $0.8 million as of June 30, 2014 and June 30, 2013, respectively, for estimated future returns that were recorded as a reduction of our accounts receivable. If the historical data that we use to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. We estimate and adjust this allowance at each balance sheet date.

[0001078271-14-000053:mdna:126]
Business Combinations

[0001078271-14-000053:mdna:127]
We allocate the purchase price of acquired companies to the tangible and intangible assets acquired and liabilities assumed, assumed equity awards, as well as to in-process research and development based upon their estimated fair values at the acquisition date.   The purchase price allocation process requires management’s judgment and often involves the use of significant estimates and assumptions, especially at the acquisition date with respect to intangible assets, deferred revenue obligations and equity assumed.

[0001078271-14-000053:mdna:128]
Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain.  Examples of critical estimates in valuing certain of intangible assets we have acquired or may acquire in future include but are not limited to assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, expected costs to develop the in-process research and development into commercially viable products, among other items.

[0001078271-14-000053:mdna:129]
In connection with the purchase price allocations for our acquisitions, we estimate the fair value of inventory using the comparative sales method.  The fair value of the inventory utilizing the comparative sales method is estimated using the selling price, less sales costs, marketing costs and profit on these costs.  The operating profit margins are based on the historical margins.

[0001078271-14-000053:mdna:130]
In connection with the purchase price allocations for our acquisitions, we estimate the fair value of deferred revenue using the cost build-up approach.  The cost build-up approach determines the fair value by estimating the costs related to fulfilling the obligations plus a normal profit margin.  The estimated costs to fulfill the obligations are based on historical costs and benchmarking analysis.

[0001078271-14-000053:mdna:131]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001078271-14-000053:mdna:132]
Goodwill

[0001078271-14-000053:mdna:133]
Goodwill is assessed for impairment annually during the fourth quarter of the fiscal year (April 1) or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. We have determined that we have one reporting unit. To test goodwill for impairment, we first perform a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, we then perform the two-step goodwill impairment test. Otherwise, the two-step goodwill impairment test is not required. Under the two-step goodwill impairment test, we in the first step, compare the estimated fair value of a reporting unit to its carrying value. If the fair value of the reporting unit exceeds the carrying value, no impairment loss is recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which we determine the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

[0001078271-14-000053:mdna:134]
We completed our annual goodwill impairment test in the fourth quarter of fiscal 2014 and determined there was no impairment as the fair value of the reporting unit exceeded its carrying value.

[0001078271-14-000053:mdna:135]
Share-based Payments

[0001078271-14-000053:mdna:136]
We use the Black-Scholes option-pricing model to determine the fair value of option awards other than performance-based option awards, options assumed as part of the Enterasys acquisition, and share purchase options under our Employee Stock Purchase Plan (“ESPP”) on the date of grant with the weighted average assumptions. We use the Monte-Carlo simulation model to determine the fair value and the derived service period of performance-based option awards, with market conditions, on the date of grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of purchase options under our ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP award is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on our stock and historical volatility on our stock. We do not currently pay cash dividends on our common stock and do not anticipate doing so in the foreseeable future. Accordingly, our expected dividend yield is zero. We are required to estimate forfeitures at the time of grant and revise those estimates in subsequent periods if actual forfeitures differ from those estimates. In fiscal 2014, our estimated forfeiture rates based on historical forfeiture experiences are 14% for executives and 12% for non-executive employees. We use the straight-line method for expense attribution, and we only recognize expense for those shares expected to vest.

[0001078271-14-000053:mdna:137]
Income Taxes

[0001078271-14-000053:mdna:138]
Deferred Tax Asset Valuation Allowance

[0001078271-14-000053:mdna:139]
We use the asset and liability method of accounting for income taxes provided under the authoritative guidance for income taxes. Under this method, deferred tax assets and liabilities are recognized for the estimated future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases.  Deferred tax assets are recognized for deductible temporary differences, along with net operating loss carryforwards and credit carryforwards, if it is more likely than not that the tax benefits will be realized. To the extent a deferred tax asset cannot be recognized under the preceding criteria, valuation allowances are established.  Significant management judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available positive and negative evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies.

[0001078271-14-000053:mdna:140]
In the fiscal year ended June 30, 2014, the global valuation allowance increased by $30.5 million to $172.5 million and in the fiscal year ended June 30, 2013, the global valuation allowance increased by $1.4 million to $142.0 million.  The global valuation allowance is comprised primarily of a U.S. allowance, however, valuation allowances have also been provided against deferred tax assets in Australia, Brazil, Japan and Singapore.  Our assessment of the available evidence in determining the need for valuation allowances placed greater weight on historical operating results rather than our expectations of future profitability, which is inherently uncertain. Our inconsistent history of earnings during those periods coupled with difficulties in forecasting more than one quarter in advance as well as the cyclical nature of our industry represent sufficient negative evidence to require a full valuation allowance against our U.S. federal and state net deferred tax assets. This valuation allowance will be evaluated periodically and can be reversed partially or totally if business results sufficiently improved to support realization of the deferred tax assets.

[0001078271-14-000053:mdna:141]
Accounting for Uncertainty in Income Taxes

[0001078271-14-000053:mdna:142]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes.  Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals.  We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate.  To the extent the final tax outcome of these matters is different than the amount recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate as well as the related interest and penalties.

[0001078271-14-000053:mdna:143]
We had unrecognized tax benefits of $11.6 million as of June 30, 2014.  If fully recognized in the future, $0.2 million would impact our effective tax rate, and $11.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrecognized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.  During the fiscal year ended June 30, 2013, we performed a study of our U.S. research and development credits documenting the historic credits as prescribed by Internal Revenue Service rules. As a result of this study we adjusted our available federal and state research credits as well as the amount of these credits that representing uncertain tax positions. The credits classified as uncertain tax positions decreased by approximately $15.0 million as a result of this study.

[0001078271-14-000053:mdna:144]
Impact of Recently Issued Accounting Standards

[0001078271-14-000053:mdna:145]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013. The Company intends to adopt this standard prospectively in the first quarter of its fiscal year ending June 30, 2015. The Company does not believe this updated standard will have a material impact on its consolidated financial statements.

[0001078271-14-000053:mdna:146]
In May 2014, the FASB, jointly with the International Accounting Standards Board, issued Accounting Standard Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers ("ASU 2014-09"). This ASU's core principle is that a reporting entity will recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In applying this new guidance to contracts within its scope, an entity will: (1) identify the contract(s) with a customer, (2) identify the performance obligation in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, this new guidance will require significantly expanded disclosures about revenue recognition. ASU 2014-09 is effective for annual reporting periods (including interim reporting periods within those annual periods) beginning after December 15, 2016. Early application is not permitted. Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this ASU. The Company is currently evaluating the potential effect on its consolidated financial position, results of operations and cash flows from adoption of this standard.

[0001078271-14-000053:mdna:147]
Liquidity and Capital Resources

[0001078271-14-000053:mdna:148]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001078271-14-000053:mdna:149]
|  | June 30, 2014 |  | June 30, 2013 |
| Cash and cash equivalent | $ | 73,190 |  |  | $ | 95,803 |  |
| Short-term investments | 32,692 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total cash and investments | $ | 105,882 |  |  | $ | 205,613 |  |
| Working capital | $ | 56,548 |  |  | $ | 96,279 |  |

[0001078271-14-000053:mdna:150]
As of June 30, 2014, our principal sources of liquidity consisted of cash, cash equivalents and investments of $105.9 million, net accounts receivable of $124.7 million and $0.9 million of letters of credit and borrowings from the Revolving Facility under which the Company had $0.1 million of availability at June 30, 2014. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products, purchases of property and equipment and repurchases of our common stock. We believe that our $105.9 million of cash and cash equivalents and investments at June 30, 2014 along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months including the repayment of the additional borrowings of $24 million from the Revolving Facility as of the filing date of this report.

[0001078271-14-000053:mdna:151]
Our Credit Agreement contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum a Consolidated Leverage Ratio and several other covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001078271-14-000053:mdna:152]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Agreement may be accelerated upon certain events of default. We believe we are in compliance and expect to remain in compliance with our Credit Agreement covenants and they are not expected to impact our liquidity or capital resources.

[0001078271-14-000053:mdna:153]
Key Components of Cash Flows and Liquidity

[0001078271-14-000053:mdna:154]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001078271-14-000053:mdna:155]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Net cash (used in) provided by operating activities | $ | (26,843 | ) |  | $ | 32,237 |  |  | $ | 13,813 |  |
| Net cash (used in ) provided by investing activities | $ | (126,189 | ) |  | $ | 16,480 |  |  | $ | (10,410 | ) |
| Net cash provided by (used in) financing activities | $ | 129,580 |  |  | $ | (7,391 | ) |  | $ | 2,393 |  |
| Foreign currency effect on cash | $ | 839 |  |  | $ | (119 | ) |  | $ | (1,172 | ) |
| Net (decrease) increase in cash and cash equivalents | $ | (22,613 | ) |  | $ | 41,207 |  |  | $ | 4,624 |  |

[0001078271-14-000053:mdna:156]
Cash and cash equivalents, short-term investments and marketable securities were $105.9 million at June 30, 2014, representing a decrease of $99.7 million from $205.6 million at June 30, 2013. Cash and cash equivalents primarily decreased due to cash used in operations of $26.8 million and cash used in investing activities of $126.2 million offset by cash provided by financing activities of $129.6 million and foreign currency impact of $0.8 million.

[0001078271-14-000053:mdna:157]
Cash used in operating activities was $26.8 million compared to cash provided by operating activities of $32.2 million in fiscal 2013, a decrease of $59.1 million during the year ended June 30, 2014.  The current year's net loss of 57.3 million was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.  Post-

[0001078271-14-000053:mdna:158]
acquisition increases in accounts receivables, inventory, accounts payable and  deferred revenue were the primary factors contributing to the cash used in operating activities for the year ended June 30, 2014.

[0001078271-14-000053:mdna:159]
Cash flow used in investing activities was $126.2 million primarily from $180.0 million proceeds used for acquisition of Enterasys, capital expenditures of $22.4 million and purchases of investments of $9.0 million. Such decreases were offset by proceeds from maturities of investments and marketable securities of $28.7 million and sales of investments and marketable securities of $56.6 million.

[0001078271-14-000053:mdna:160]
Cash flow provided by financing activities was $129.6 million resulting from issuance of Term Loan of $65 million and a draw on the Revolving Facility of $35 million used for the acquisition of Enterasys, an additional draw of $24 million on the Revolving Facility for working capital requirements, and $8.0 million proceeds from the exercise of stock options and purchases of shares of our common stock under the ESPP, net of taxes paid on vested and released stock awards.

[0001078271-14-000053:mdna:161]
Contractual Obligations

[0001078271-14-000053:mdna:162]
The following summarizes our contractual obligations at June 30, 2014, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-14-000053:mdna:163]
|  | Total |  | Less Than1 Year |  | 1 – 3 Years |  | 3 – 5 Years |  | More ThanFive Years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 121,563 |  |  | $ | 29,688 |  |  | $ | 29,250 |  |  | $ | 62,625 |  |  | $ | — |  |
| Interest on debt obligations | 8,813 |  |  | 2,588 |  |  | 4,377 |  |  | 1,848 |  |  | — |  |
| Non-cancelable inventory purchase commitments | 64,651 |  |  | 64,651 |  |  | — |  |  | — |  |  | — |  |
| Non-cancelable operating lease obligations | 58,109 |  |  | 9,093 |  |  | 14,456 |  |  | 13,805 |  |  | 20,755 |  |
| Other liabilities | 5,470 |  |  | 2,818 |  |  | 2,491 |  |  | 161 |  |  | — |  |
| Total contractual cash obligations | $ | 258,606 |  |  | $ | 108,838 |  |  | $ | 50,574 |  |  | $ | 78,439 |  |  | $ | 20,755 |  |

[0001078271-14-000053:mdna:164]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $64.7 million as of June 30, 2014, an increase of $14.6 million from $50.1 million as of June 30, 2013.

[0001078271-14-000053:mdna:165]
Non-cancelable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001078271-14-000053:mdna:166]
Other liabilities include the Company's commitments towards debt related fees and specific arrangements other than inventory.

[0001078271-14-000053:mdna:167]
The amounts in the table above exclude $0.2 million of income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of settlement.

[0001078271-14-000053:mdna:168]
We did not have any material commitments for capital expenditures as of June 30, 2014.

[0001078271-14-000053:mdna:169]
Off-Balance Sheet Arrangements

[0001078271-14-000053:mdna:170]
We did not have any off-balance sheet arrangements as of June 30, 2014.

[0001078271-14-000053:mdna:171]
Capital Resources and Financial Condition

[0001078271-14-000053:mdna:172]
As of June 30, 2014, in addition to $73.2 million in cash and cash equivalents, we had $32.7 million invested in short-term investments for total cash and cash equivalents and short-term investments of $105.9 million.

[0001078271-14-000053:mdna:173]
We believe that our current cash and cash equivalents and short-term investments and cash available from future operations will enable us to meet our working capital requirements for at least the next 12 months.
