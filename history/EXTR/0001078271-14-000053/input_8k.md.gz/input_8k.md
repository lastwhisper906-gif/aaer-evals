# EXTR 8-K — 0001078271-14-000047 filed 2014-08-14

## item codes, every 8-K on or before 2014-09-15

- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2014-09-15

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-14-000047:8k_2_02:1]
EX-99.1
2
extr8kq414ex991.htm
PRESS RELEASE

[0001078271-14-000047:8k_2_02:2]
EXTR 8K Q4'14 EX 99.1

[0001078271-14-000047:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-14-000047:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Public Relations |
| 510/315-1004 |  | 408/579-3483 |
| investor_relations@extremenetworks.com |  | gcross@extremenetworks.com |

[0001078271-14-000047:8k_2_02:5]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2014 Financial Results

[0001078271-14-000047:8k_2_02:6]
Q4 GAAP Revenue of $155.3 million & non-GAAP Revenue of $156.9 million

[0001078271-14-000047:8k_2_02:7]
Q4 GAAP EPS loss of $0.17 & non-GAAP EPS of $0.09

[0001078271-14-000047:8k_2_02:8]
Fiscal Year GAAP Revenue of $519.6 million & non-GAAP Revenue of $524.8 million

[0001078271-14-000047:8k_2_02:9]
Fiscal Year GAAP EPS loss of $0.60 & non-GAAP EPS of $0.30

[0001078271-14-000047:8k_2_02:10]
SAN JOSE, Calif., August 14, 2014 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for the fourth quarter of fiscal year 2014, ended June 30, 2014.  GAAP revenue was $155.3 million and non-GAAP revenue was $156.9 million.  GAAP net loss for the fourth fiscal quarter was $16.2 million, or $0.17 per share, and non-GAAP net income was $8.5 million, or $0.09 per diluted share.  This is the second quarter that Extreme Networks is reporting full quarter results that include the Enterasys acquisition.

[0001078271-14-000047:8k_2_02:11]
For the full fiscal year, Extreme Networks reported GAAP revenue of $519.6 million, compared to $299.3 million for fiscal 2013.  Fiscal year non-GAAP revenue was $524.8 million.  GAAP net loss was $57.3 million, or $0.60 per share, for fiscal 2014, compared to GAAP net income of $9.7 million, or $0.10 per diluted share, for 2013.  On a non-GAAP basis, net income for the fiscal 2014 was $29.5 million, or $0.30 per diluted share, compared to $16.2 million, or $0.17 per diluted share, for fiscal 2013.

[0001078271-14-000047:8k_2_02:12]
“Extreme ended our first fiscal year as a combined company with a strong finish.  Our sales force integration is complete, with all territories rationalized, and the team is aligned and executing, which is evident in this quarter’s results.  Our new channel program brings together legacy partner programs and provides better resources and incentives for our more than 2,700 worldwide partners.  With new branding rolled out this year, our go to market approach has never been stronger,” said Chuck Berger, president and CEO of Extreme Networks.  “Our engineering team continues to create products that deliver on our promise of simple, fast and smart networking solutions, including our new SDN platform and IdentiFi outdoor wireless access point.”

[0001078271-14-000047:8k_2_02:13]
Berger added, “On the integration front, Extreme had a number of significant accomplishments.  Most notably, we successfully combined ERP systems in early July, two months ahead of schedule.  With our relationship to our customers, partners, distributors, vendors and employees united on a single interface, the combined company is in a better position than ever to seamlessly deliver value to the customer.”

[0001078271-14-000047:8k_2_02:14]
Fiscal Q4 2014 Financial Metrics:

[0001078271-14-000047:8k_2_02:15]
|  |  | Fourth Quarter |  |  |  |  |
|  |  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |
|  |  | 2014 |  | 2013 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 121.8 |  |  | $ | 64.5 |  |  | $ | 57.3 |  |  | 89 | % |
| Service |  | $ | 33.5 |  |  | $ | 15.0 |  |  | $ | 18.5 |  |  | 123 | % |
| Total Net Revenue |  | $ | 155.3 |  |  | $ | 79.5 |  |  | $ | 75.8 |  |  | 95 | % |
| Gross Margin |  | 53.4 | % |  | 55.3 | % |  | (1.9 | )% |  | (3 | )% |
| Operating Margin/Loss |  | (8.7 | )% |  | 3.7 | % |  | (12.0 | )% |  | (324 | )% |
| Net (Loss) Income |  | $ | (16.2 | ) |  | $ | 3.2 |  |  | $ | (19.4 | ) |  | (606 | )% |
| Earnings per diluted share |  | $ | (0.17 | ) |  | $ | 0.03 |  |  | $ | (0.20 | ) |  | (667 | )% |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 121.8 |  |  | $ | 64.5 |  |  | $ | 57.3 |  |  | 89 | % |
| Service |  | $ | 35.1 |  |  | $ | 15.0 |  |  | $ | 20.1 |  |  | 134 | % |
| Total Net Revenue |  | $ | 156.9 |  |  | $ | 79.5 |  |  | $ | 77.4 |  |  | 97 | % |
| Gross Margin |  | 56.9 | % |  | 55.3 | % |  | 1.6 | % |  | 3 | % |
| Operating Margin |  | 7.2 | % |  | 8.2 | % |  | (1.0 | )% |  | (12 | )% |
| Net Income |  | $ | 8.5 |  |  | $ | 6.7 |  |  | $ | 1.8 |  |  | 27 | % |
| Earnings per diluted share |  | $ | 0.09 |  |  | $ | 0.07 |  |  | $ | 0.02 |  |  | 29 | % |

[0001078271-14-000047:8k_2_02:16]
| • | Cash and investments ended the quarter at $105.9 million, as compared to $106.1 million from the prior quarter. |

[0001078271-14-000047:8k_2_02:17]
| • | Accounts receivable balance ending Q4 was $124.7 million, with non-GAAP days sales outstanding (DSO) of 72, both impacted by heavy shipments near the end of the quarter. |

[0001078271-14-000047:8k_2_02:18]
| • | Inventory ending Q4 was $57.1 million, a decrease of $6 million from the prior quarter, due to continued right sizing of inventory. |

[0001078271-14-000047:8k_2_02:19]
Recent Business Highlights:

[0001078271-14-000047:8k_2_02:20]
| • | Selected by Tennessee Titans to set up In-Stadium Wi-Fi and Analytics. Extreme’s IdentiFi high performance Wi-Fi technology will provide fans the capability to seamlessly access mobile services and custom applications in the Nashville’s LP Field. |

[0001078271-14-000047:8k_2_02:21]
| • | Announced an open and standards-based Software Defined Networking (SDN) platform. This versatile offering will enable customers to meet challenges in implementing SDN and evolve data center orchestration, automation and provisioning. |

[0001078271-14-000047:8k_2_02:22]
| • | Advances mobile scalability with IdentiFiTM Wireless LAN. With the addition of the 802. 11ac WLAN outdoor access point, IdentiFi is one of the most complete and scalable enterprise Wi-Fi solutions addressing both indoor and outdoor wireless connectivity. |

[0001078271-14-000047:8k_2_02:23]
| • | Named proud partner of the Pro Football Hall of Fame. Centered on education and community outreach in K-12 school districts, the partnership highlights Extreme’s leadership as a provider of optimized networking and wireless solutions to support education innovation. |

[0001078271-14-000047:8k_2_02:24]
| • | Launched Extreme Partner Network. The program offers a single global framework to simplify the way business is done, empowering partners to deliver significant value to customers while simplifying engagement and maximizing partner profitability. |

[0001078271-14-000047:8k_2_02:25]
| • | Recognized as a leader and innovator |

[0001078271-14-000047:8k_2_02:26]
| • | Named a “Champion” in the 2014 Vendor Landscape report assessing Network Access Control solutions for secure network edge. |

[0001078271-14-000047:8k_2_02:27]
| • | Awarded the 2014 Network Innovation Award for the Purview application by SearchNetworking. |

[0001078271-14-000047:8k_2_02:28]
| • | Recognized with two 2014 Manufacturing Leadership Awards. |

[0001078271-14-000047:8k_2_02:29]
Business Outlook:

[0001078271-14-000047:8k_2_02:30]
For its first quarter of fiscal 2015 ending September 30, 2014, the Company is targeting GAAP revenue in a range of $149 million to $154 million with non-GAAP revenue in a range of $150 million to $155 million. GAAP gross margin is targeted at 51% and non-GAAP gross margin targeted at 55%. Operating expenses are targeted to be between $86 million and $88 million on a GAAP basis and $75 million to $77 million on a non-GAAP basis. GAAP net loss is targeted to be between $7 million to $12 million, or $0.08 to $0.12 per diluted share.  Non-GAAP net income is targeted in a range of $6 million to $8 million, or $0.06 to $0.08 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 96 million and 101 million average outstanding shares, respectively. The estimates for non-GAAP revenue include purchase accounting adjustments for deferred revenue of approximately $1M related to our acquisition of Enterasys Networks. The estimates for non-GAAP gross margin include adjustments of $4 million for amortization of intangibles, $1 million for purchase accounting adjustments and $1 million stock based compensation expense. The estimate for non-GAAP operating expenses exclude $7 to $8M for amortization of intangibles and integration expenses related to our acquisition of Enterasys Networks, stock based compensation expenses of $4 to $5 million and executive transition costs of $0.5 million.

[0001078271-14-000047:8k_2_02:31]
Financial Model Targets:

[0001078271-14-000047:8k_2_02:32]
The Company is targeting a quarterly financial model of operating at an approximate non-GAAP operating income of 10%, exiting the fiscal year ending June 30, 2015.  To achieve this goal, the Company intends to focus on completing the integration of the two companies, achieving its synergy goals and growing its revenue.

[0001078271-14-000047:8k_2_02:33]
Conference Call:

[0001078271-14-000047:8k_2_02:34]
Extreme Networks will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the highlights of the fourth fiscal quarter 2014 and business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August 13, 2015.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #: 74641489.

[0001078271-14-000047:8k_2_02:35]
About Extreme Networks:

[0001078271-14-000047:8k_2_02:36]
Extreme Networks, Inc. (NASDAQ: EXTR) is setting a new standard for superior customer experience by delivering network-powered innovation and marketing leading service and support. Extreme Networks delivers high-performance switching and routing products for data center and core-to-edge networks, wired/wireless LAN access, and unified network management and control.  Its award-winning solutions include software-defined networking (SDN), cloud and high-density Wi-Fi, BYOD and enterprise mobility, identity access management and security.  Extreme Networks is headquartered in San Jose, CA and has more than 12,000 customers in over 80 countries. For more information, visit the Company's website at http://www.extremenetworks.com.

[0001078271-14-000047:8k_2_02:37]
Non-GAAP Financial Measures:

[0001078271-14-000047:8k_2_02:38]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). To supplement its consolidated financial statements presented in accordance with GAAP, the Company is also providing with this press release non-GAAP net income/(loss) and non-GAAP operating income/(loss) financial measures. In preparing non-GAAP information, the company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, executive transition costs, share-based compensation, gain on sale of facilities and litigation settlements.  The company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the company and the company's marketplace performance. In particular, management finds it useful to exclude these items in order to more readily correlate the company's operating activities with the company's ability to generate cash from operations. Accordingly, management uses these non-GAAP measures, along with the comparable GAAP information, in evaluating the Company’s historical performance and in planning its future business activities. Please note that the company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the company presents should be considered in conjunction with, and not as a substitute for, the company’s financial information presented in accordance with GAAP.  The Company has provided a non-GAAP reconciliation of the Condensed Consolidated Statement of Operations for the periods presented in this release, which are adjusted to exclude acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring charges, share-based compensation expense and gain on sale of facilities for these periods. These measures should only be used to evaluate the company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-14-000047:8k_2_02:39]
Forward Looking Statements:

[0001078271-14-000047:8k_2_02:40]
Actual results, including with respect to the Company’s financial targets and general business prospects, could differ materially due to a number of factors, including the risks that:

[0001078271-14-000047:8k_2_02:41]
| • | The Company may not achieve targeted revenues for the Company's products and services given increasing price competition and product technology developments in key network switching equipment markets; |

[0001078271-14-000047:8k_2_02:42]
| • | The Company may be unable to effectively integrate the businesses of Extreme Networks and Enterasys Networks, both in terms of customer acceptance of combined product lines as well as the need to align the Company’s cost structure to meet the company’s financial goals, including controlling expenses, and meet financial covenants as part of the Company’s debt financing used to acquire Enterasys Networks; |

[0001078271-14-000047:8k_2_02:43]
| • | The Company may not accurately anticipate demand from end customers, which can result in increased inventory and reduced orders as it experiences wide fluctuations in supply and demand; |

[0001078271-14-000047:8k_2_02:44]
| • | The Company is dependent on third parties to manufacture its products and any potential production delays could preclude the Company from shipping sufficient quantities to meet customer orders or could result in higher production costs and lower margins; |

[0001078271-14-000047:8k_2_02:45]
| • | Ongoing uncertainty in global economic conditions, infrastructure development or customer demand could negatively affect product demand, collectability of receivables and other related matters as consumers and businesses may defer purchases or payments, or default on payments; |

[0001078271-14-000047:8k_2_02:46]
| • | The Company may be unable to complete development and commercialization of products under development, such as its pipeline of new network switches and related software |

[0001078271-14-000047:8k_2_02:47]
| • | The Company may be adversely affected by ongoing litigation. |

[0001078271-14-000047:8k_2_02:48]
More information about potential factors that could affect the Company's business and financial results is included in its filings with the Securities and Exchange Commission, including, without limitation, under the captions: “Management's Discussion and Analysis of Financial Condition and Results of Operations,” and “Risk Factors,” which are on file with the Securities and Exchange Commission.  Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-14-000047:8k_2_02:49]
EXTREME NETWORKS, INC.

[0001078271-14-000047:8k_2_02:50]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-14-000047:8k_2_02:51]
(In thousands, except share and per share amounts)

[0001078271-14-000047:8k_2_02:52]
(Unaudited)

[0001078271-14-000047:8k_2_02:53]
|  | June 30, 2014 |  | June 30, 2013 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 73,190 |  |  | $ | 95,803 |  |
| Short-term investments | 32,692 |  |  | 43,034 |  |
| Accounts receivable, net of allowances of $3,618 at June 30, 2014 and $1,252 at June 30, 2013 | 124,664 |  |  | 47,642 |  |
| Inventories | 57,109 |  |  | 16,167 |  |
| Deferred income taxes | 1,058 |  |  | 386 |  |
| Prepaid expenses and other current assets | 15,562 |  |  | 5,749 |  |
| Total current assets | 304,275 |  |  | 208,781 |  |
| Property and equipment, net | 46,554 |  |  | 23,644 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Intangible assets, net | 87,459 |  |  | 4,243 |  |
| Goodwill | 69,458 |  |  | — |  |
| Other assets, net | 18,686 |  |  | 7,980 |  |
| Total assets | $ | 526,432 |  |  | $ | 311,424 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 29,688 |  |  | $ | — |  |
| Accounts payable | 37,308 |  |  | 27,163 |  |
| Accrued compensation and benefits | 26,677 |  |  | 13,503 |  |
| Restructuring liabilities | 322 |  |  | 1,466 |  |
| Accrued warranty | 7,551 |  |  | 3,296 |  |
| Deferred revenue, net | 74,735 |  |  | 33,184 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 31,992 |  |  | 17,388 |  |
| Other accrued liabilities | 38,035 |  |  | 16,502 |  |
| Total current liabilities | 246,308 |  |  | 112,502 |  |
| Deferred revenue, less current portion | 22,942 |  |  | 8,270 |  |
| Long-term debt, less current portion | 91,875 |  |  | — |  |
| Other long-term liabilities | 8,595 |  |  | 1,507 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 156,712 |  |  | 189,145 |  |
| Total liabilities and stockholders’ equity | $ | 526,432 |  |  | $ | 311,424 |  |

[0001078271-14-000047:8k_2_02:54]
EXTREME NETWORKS, INC.

[0001078271-14-000047:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000047:8k_2_02:56]
(In thousands, except per share amounts)

[0001078271-14-000047:8k_2_02:57]
(Unaudited)

[0001078271-14-000047:8k_2_02:58]
|  | Three Months Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 121,761 |  |  | $ | 64,505 |  |  | $ | 411,761 |  |  | $ | 239,955 |  |
| Service | 33,532 |  |  | 14,957 |  |  | 107,793 |  |  | 59,388 |  |
| Total net revenues | 155,293 |  |  | 79,462 |  |  | 519,554 |  |  | 299,343 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 60,561 |  |  | 30,803 |  |  | 213,673 |  |  | 115,862 |  |
| Service | 11,810 |  |  | 4,684 |  |  | 38,552 |  |  | 20,855 |  |
| Total cost of revenues | 72,371 |  |  | 35,487 |  |  | 252,225 |  |  | 136,717 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 61,200 |  |  | 33,702 |  |  | 198,088 |  |  | 124,093 |  |
| Service | 21,722 |  |  | 10,273 |  |  | 69,241 |  |  | 38,533 |  |
| Total gross profit | 82,922 |  |  | 43,975 |  |  | 267,329 |  |  | 162,626 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 24,048 |  |  | 9,567 |  |  | 77,146 |  |  | 40,521 |  |
| Sales and marketing | 48,634 |  |  | 22,438 |  |  | 156,666 |  |  | 87,202 |  |
| General and administrative | 11,511 |  |  | 8,434 |  |  | 40,912 |  |  | 26,725 |  |
| Acquisition and integration costs | 6,890 |  |  | — |  |  | 25,716 |  |  | — |  |
| Restructuring charge, net of reversals | 11 |  |  | 593 |  |  | 510 |  |  | 6,836 |  |
| Amortization of intangibles | 5,267 |  |  | — |  |  | 16,711 |  |  | — |  |
| Litigation settlement (income) expense | — |  |  | — |  |  | (100 | ) |  | 2,029 |  |
| Gain on sale of facilities | — |  |  | — |  |  | — |  |  | (11,539 | ) |
| Total operating expenses | 96,361 |  |  | 41,032 |  |  | 317,561 |  |  | 151,774 |  |
| Operating (loss) income | (13,439 | ) |  | 2,943 |  |  | (50,232 | ) |  | 10,852 |  |
| Interest income | 148 |  |  | 284 |  |  | 751 |  |  | 1,070 |  |
| Interest expense | (796 | ) |  | — |  |  | (2,085 | ) |  | — |  |
| Other (expense) income, net | (217 | ) |  | 243 |  |  | (1,555 | ) |  | (571 | ) |
| (Loss) income before income taxes | (14,304 | ) |  | 3,470 |  |  | (53,121 | ) |  | 11,351 |  |
| Provision for income taxes | 1,927 |  |  | 286 |  |  | 4,189 |  |  | 1,678 |  |
| Net (loss) income | $ | (16,231 | ) |  | $ | 3,184 |  |  | $ | (57,310 | ) |  | $ | 9,673 |  |
| Basic and diluted net (loss) income per share: |  |  |  |  |  |  |  |
| Net (loss) income per share - basic | $ | (0.17 | ) |  | $ | 0.03 |  |  | $ | (0.60 | ) |  | $ | 0.10 |  |
| Net (loss) income per share - diluted | $ | (0.17 | ) |  | $ | 0.03 |  |  | $ | (0.60 | ) |  | $ | 0.10 |  |
| Shares used in per share calculation - basic | 96,713 |  |  | 93,611 |  |  | 95,515 |  |  | 93,954 |  |
| Shares used in per share calculation - diluted | 96,713 |  |  | 94,894 |  |  | 95,515 |  |  | 95,044 |  |

[0001078271-14-000047:8k_2_02:59]
EXTREME NETWORKS, INC.

[0001078271-14-000047:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-14-000047:8k_2_02:61]
(In thousands)

[0001078271-14-000047:8k_2_02:62]
(Unaudited)

[0001078271-14-000047:8k_2_02:63]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Net cash (used in) provided by operating activities | $ | (26,843 | ) |  | $ | 32,237 |  |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (22,373 | ) |  | (12,737 | ) |
| Acquisition, net of cash acquired | (180,000 | ) |  | — |  |
| Purchases of investments | (9,045 | ) |  | (57,712 | ) |
| Proceeds from maturities of investments and marketable securities | 28,722 |  |  | 16,367 |  |
| Proceeds from sales of investments and marketable securities | 56,594 |  |  | 28,528 |  |
| Purchases of intangible assets | (87 | ) |  | (625 | ) |
| Proceeds from sales of facilities | — |  |  | 42,659 |  |
| Net cash (used in) provided by investing activities | (126,189 | ) |  | 16,480 |  |
| Cash flows from financing activities: |  |  |  |
| Borrowings under Revolving Facility | 83,000 |  |  | — |  |
| Borrowings under Term Loan | 65,000 |  |  | — |  |
| Repayment of debt | (26,437 | ) |  | — |  |
| Proceeds from issuance of common stock | 8,017 |  |  | 7,084 |  |
| Repurchase of common stock | — |  |  | (14,475 | ) |
| Net cash provided by (used in) financing activities | 129,580 |  |  | (7,391 | ) |
| Foreign currency effect on cash | 839 |  |  | (119 | ) |
| Net (decrease) increase in cash and cash equivalents | (22,613 | ) |  | 41,207 |  |
| Cash and cash equivalents at beginning of period | 95,803 |  |  | 54,596 |  |
| Cash and cash equivalents at end of period | $ | 73,190 |  |  | $ | 95,803 |  |

[0001078271-14-000047:8k_2_02:64]
Extreme Networks, Inc.

[0001078271-14-000047:8k_2_02:65]
Non-GAAP Measures of Financial Performance

[0001078271-14-000047:8k_2_02:66]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, or GAAP, Extreme Networks uses non-GAAP measure of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-14-000047:8k_2_02:67]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring expenses and gains related to the sale of the Santa Clara campus.

[0001078271-14-000047:8k_2_02:68]
Non-GAAP measures presented in this press release are not in accordance with or an alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition these, non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-14-000047:8k_2_02:69]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-14-000047:8k_2_02:70]
For its internal planning process, and as discussed further below, Extreme Network's management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring expenses and gains related to the sale of the Santa Clara campus.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-14-000047:8k_2_02:71]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-14-000047:8k_2_02:72]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-14-000047:8k_2_02:73]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-14-000047:8k_2_02:74]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-14-000047:8k_2_02:75]
Purchase accounting adjustments relating to inventory and deferred revenue.  Purchase accounting adjustments consists of adjustments to the carrying value of deferred revenue and the step up of the carrying value for finished goods inventory.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.   The carrying value of the finished goods inventories acquired was adjusted to reflect only a selling profit margin that a market

[0001078271-14-000047:8k_2_02:76]
participant would incur to fulfill an order.  However, we have excluded the step up adjustment since we believe it is not reflective of the normal profit margin we expect on similar types of transactions with 3rd party customers.

[0001078271-14-000047:8k_2_02:77]
Restructuring expenses. Restructuring expenses primarily consist of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-14-000047:8k_2_02:78]
Gains related to the sale of facilities.  The one-time net gain related to the sale of the Santa Clara campus consists of the gross proceeds of the sale less the expenses directly related to the sale such as commissions, closing costs and legal fees.  Extreme Networks excludes this gain because it is a one-time event and does not believe that the gain is reflective of ongoing operations.

[0001078271-14-000047:8k_2_02:79]
Executive transition expenses. This expense is related to the costs associated with the severance payments, both cash and stock based, for the Company's prior executives and the cost of transitioning with the new executives. Extreme Networks excludes these costs as it does not believe it is reflective of ongoing operations.

[0001078271-14-000047:8k_2_02:80]
Currency loss related to closing of certain foreign subsidiaries. This is related to the closing of our Japanese subsidiary. This has accumulated over time and has historically been included in Other Comprehensive Income. Extreme Networks excludes these losses as it is a one-time event and does not believe it is reflective of ongoing operations.

[0001078271-14-000047:8k_2_02:81]
In addition to the non-GAAP measures discussed above, Extreme Networks also uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, strengthen the balance sheet and repurchase stock.  A limitation of the utility of free cash slows as a measure of financial performance is that it does not represent the total increases or decrease in the Company's cash balance for the period.

[0001078271-14-000047:8k_2_02:82]
EXTREME NETWORKS, INC.

[0001078271-14-000047:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-14-000047:8k_2_02:84]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-14-000047:8k_2_02:85]
(In thousands, except per share amounts)

[0001078271-14-000047:8k_2_02:86]
(Unaudited)

[0001078271-14-000047:8k_2_02:87]
| Non-GAAP Revenue | Three Months Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Revenue - GAAP Basis | $ | 155,293 |  |  | $ | 79,462 |  |  | $ | 519,554 |  |  | $ | 299,343 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Purchase accounting adjustments | $ | 1,579 |  |  | $ | — |  |  | $ | 5,256 |  |  | $ | — |  |
| Revenue - Non-GAAP Basis | $ | 156,872 |  |  | $ | 79,462 |  |  | $ | 524,810 |  |  | $ | 299,343 |  |
| Non-GAAP Gross Margin | Three Months Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Gross profit - GAAP Basis | $ | 82,922 |  |  | $ | 43,975 |  |  | $ | 267,329 |  |  | $ | 162,626 |  |
| Gross margin - GAAP Basis percentage | 53.4 | % |  | 55.3 | % |  | 51.5 | % |  | 54.3 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 540 |  |  | $ | 3 |  |  | $ | 1,730 |  |  | $ | 720 |  |
| Purchase accounting adjustments | $ | 1,579 |  |  | $ | — |  |  | $ | 16,383 |  |  | $ | — |  |
| Amortization of intangibles | $ | 4,292 |  |  | $ | — |  |  | $ | 11,028 |  |  | $ | — |  |
| Gross profit - Non-GAAP Basis | $ | 89,333 |  |  | $ | 43,978 |  |  | $ | 296,470 |  |  | $ | 163,346 |  |
| Gross margin - Non-GAAP Basis percentage | 56.9 | % |  | 55.3 | % |  | 56.5 | % |  | 54.6 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| GAAP operating (loss) income | $ | (13,439 | ) |  | $ | 2,943 |  |  | $ | (50,232 | ) |  | $ | 10,852 |  |
| GAAP operating (loss) income percentage | (8.7 | )% |  | 3.7 | % |  | (9.7 | )% |  | 3.6 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 6,047 |  |  | $ | 886 |  |  | $ | 15,922 |  |  | $ | 6,512 |  |
| Acquisition and integration costs | $ | 6,890 |  |  | $ | — |  |  | $ | 25,716 |  |  | $ | — |  |
| Restructuring charge, net of reversal | $ | 11 |  |  | $ | 593 |  |  | $ | 510 |  |  | $ | 6,836 |  |
| Amortization of intangibles | $ | 9,559 |  |  | $ | — |  |  | $ | 27,739 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 1,579 |  |  | $ | — |  |  | $ | 16,383 |  |  | $ | — |  |
| Litigation settlement (income) expense | $ | — |  |  | $ | — |  |  | $ | (100 | ) |  | $ | 2,197 |  |
| Gain on sale of facilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |
| Executive transition expenses | $ | 600 |  |  | $ | 2,086 |  |  | $ | 600 |  |  | $ | 2,086 |  |
| Total adjustments to GAAP operating income | $ | 24,686 |  |  | $ | 3,565 |  |  | $ | 86,770 |  |  | $ | 6,092 |  |
| Non-GAAP operating income | $ | 11,247 |  |  | $ | 6,508 |  |  | $ | 36,538 |  |  | $ | 16,944 |  |
| Non-GAAP operating income percentage | 7.2 | % |  | 8.2 | % |  | 7.0 | % |  | 5.7 | % |
| Non-GAAP Net Income | Three Months Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |

[0001078271-14-000047:8k_2_02:88]
| GAAP net (loss) income | $ | (16,231 | ) |  | $ | 3,184 |  |  | $ | (57,310 | ) |  | $ | 9,673 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | $ | 6,047 |  |  | $ | 886 |  |  | $ | 15,922 |  |  | $ | 6,512 |  |
| Acquisition and integration costs | $ | 6,890 |  |  | $ | — |  |  | $ | 25,716 |  |  | $ | — |  |
| Restructuring charge, net of reversal | $ | 11 |  |  | $ | 593 |  |  | $ | 510 |  |  | $ | 6,836 |  |
| Amortization of intangibles | $ | 9,559 |  |  | $ | — |  |  | $ | 27,739 |  |  | $ | — |  |
| Purchase accounting adjustments | $ | 1,579 |  |  | $ | — |  |  | $ | 16,383 |  |  | $ | — |  |
| Litigation settlement (income) expense | $ | — |  |  | $ | — |  |  | $ | (100 | ) |  | $ | 2,197 |  |
| Gain on sale of facilities | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (11,539 | ) |
| Executive transition expenses | $ | 600 |  |  | $ | 2,086 |  |  | $ | 600 |  |  | $ | 2,086 |  |
| Currency loss from closing of a foreign subsidiary | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 465 |  |
| Total adjustments to GAAP net income | $ | 24,686 |  |  | $ | 3,565 |  |  | $ | 86,770 |  |  | $ | 6,557 |  |
| Non-GAAP net income | $ | 8,455 |  |  | $ | 6,749 |  |  | $ | 29,460 |  |  | $ | 16,230 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.09 |  |  | $ | 0.07 |  |  | $ | 0.30 |  |  | $ | 0.17 |  |
| Shares used in diluted net income per share calculation | 99,125 |  |  | 94,894 |  |  | 98,171 |  |  | 95,044 |  |
| Free Cash Flow | Three Months Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2014 |  | June 30, 2013 |
| Cash flow used in operations | $ | 3,774 |  |  | $ | 25,235 |  |  | $ | (26,843 | ) |  | $ | 32,237 |  |
| Add: PP&E CapEx spending | (4,988 | ) |  | (8,315 | ) |  | (22,373 | ) |  | (12,737 | ) |
| Total free cash flow | $ | (1,214 | ) |  | $ | 16,920 |  |  | $ | (49,216 | ) |  | $ | 19,500 |  |
