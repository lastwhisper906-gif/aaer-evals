# EXTR note change history — 0001078271-14-000008 → 0001078271-14-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001078271-14-000020:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2014, the Company had non-cancelable commitments to purchase approximately $52.5 million of such inventory.
  (was, 2014-02-06, similarity 0.9896):
[0001078271-14-000008:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2013, the Company had non-cancelable commitments to purchase approximately $63.2 million of such inventory.

- changed (2014-05-07):
[0001078271-14-000020:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.
  (was, 2014-02-06, similarity 0.9991):
[0001078271-14-000008:note_history:2]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

- changed (2014-05-07):
[0001078271-14-000020:note_history:3]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775 (Extreme Case). Further on May 6, 2013 they also filed a similar suit against Enterasys in the same court, Civil Action case number 13-774.The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on both cases in July, 2013. The suit is one of approximately 40 nearly simultaneous suits filed by Relay IP against numerous networking equipment manufacturers, suppliers, operators, and users including Cisco Systems, Hewlett-Packard, Juniper Networks, Avaya, Extreme and Enterasys.  The Company denies the claims and intends to vigorously defend itself in both cases.
  (was, 2014-02-06, similarity 0.6474):
[0001078271-14-000008:note_history:3]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775 (Extreme Case). Further on May 6, 2013 they also filed a similar suit against Enterasys in the same court, Civil Action case number 13-774.The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on both cases in July, 2013. The suit is one of approximately 40 nearly simultaneous suits filed against numerous networking equipment manufacturers, suppliers, operators, and users including Cisco Systems, Hewlett-Packard, Juniper Networks, Avaya, Extreme and Enterasys.  The Company denies the claims and intends to vigorously defend itself in both cases. Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

- changed (2014-05-07):
[0001078271-14-000020:note_history:4]
On September 17, 2012, ReefEdge filed suit against Enterasys in the United States District Court for the District of Delaware alleging certain of the company's products (wireless controllers and wireless access points), infringe three ReefEdge U.S. patents (6633761, 6975864, 7197308).  ReefEdge, a non-practicing entity, sought injunctive relief as well as monetary damages, costs, expenses and attorney fees, although there was no quantified amount sought.  Extreme assumed this litigation as part of the acquisition of Enterasys.  As of the date of this filing, the parties reached a settlement which required the Company to pay an immaterial amount.
  (was, 2014-02-06, similarity 0.7286):
[0001078271-14-000008:note_history:4]
On September 17, 2012, ReefEdge filed suit against Enterasys in the United States District Court for the District of Delaware alleging certain of the company's products (wireless controllers and wireless access points), infringe three ReefEdge U.S. patents (6633761, 6975864, 7197308).  ReefEdge, a Non-Practicing Entity, seeks injunctive relief as well as monetary damages, cost, expenses and attorney fees, although there was no quantified amount sought.  Preliminary talks have taken place between the parties. Enterasys has filed its Answer to the claims and is awaiting a scheduling conference. Extreme assumed this litigation as part of the acquisition of Enterasys.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

- changed (2014-05-07):
[0001078271-14-000020:note_history:5]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of March 31, 2014, the Company had no outstanding indemnification claims.
  (was, 2014-02-06, similarity 0.9939):
[0001078271-14-000008:note_history:5]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of December 31, 2013, the Company had no outstanding indemnification claims.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001078271-14-000020:note_history:6]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at March 31, 2014. The results of operations for the three and nine months ended March 31, 2014 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.
  (was, 2014-02-06, similarity 0.9414):
[0001078271-14-000008:note_history:6]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme Networks at December 31, 2013. The results of operations for the three and six months ended December 31, 2013 are not necessarily indicative of the results that may be expected for fiscal 2014 or any future periods.

- changed (2014-05-07):
[0001078271-14-000020:note_history:7]
On October 31, 2013, the Company completed the acquisition of Enterasys Networks, Inc., a Delaware corporation ("Enterasys"), whereby Enterasys became a wholly-owned subsidiary of the Company (see Note 2: Summary of Significant Accounting Policies - Business Combinations" and Note 4: "Business Combinations" for further discussion).  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013.
  (was, 2014-02-06, similarity 0.9007):
[0001078271-14-000008:note_history:7]
On October 31, 2013, the Company completed the acquisition of Enterasys Networks, Inc., a Delaware corporation ("Enterasys"), whereby Enterasys became a wholly-owned subsidiary of the Company (see Note 4: "Business Combinations" for further discussion).  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001078271-14-000020:note_history:8]
The Company applies the acquisition method of accounting for business combinations, including its acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.
  (was, 2014-02-06, similarity 0.9991):
[0001078271-14-000008:note_history:8]
The Company applies the acquisition method of accounting for business combinations, including its acquisition of Enterasys Networks, Inc. on October 31, 2013. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.

- added (2014-05-07):
[0001078271-14-000020:note_history:9]
Intangibles assets are reviewed for impairment annually or more frequently when an event occurs or circumstances change that would more likely than not reduce the fair value of the asset below its carrying value.  License agreements are presented at cost, net of accumulated amortization and are amortized over their estimated useful life.  The in-process research and development efforts are monitored regularly for completion and once they are completed, the Company will determine whether the asset will continue to be an indefinite-lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.  The Company determines that its in-process research and development project is complete when all material research and development costs have been incurred and no significant risks remain. The Company reviews the carrying value of indefinite-lived intangible assets for impairment at least annually during the last quarter of the fiscal year, or more frequently if it believes indicators of impairment exist.

- removed (2014-05-07):
[0001078271-14-000008:note_history:10]
Intangibles assets are reviewed for impairment annually or more frequently when an event occurs or circumstances change that would more likely than not reduce the fair value of the asset below its carrying value.  License agreements are presented at cost, net of accumulated amortization and are amortized over their estimated useful life.  The in-process research and development efforts will be monitored regularly for completion and once they are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or it has become a finite lived asset and apply the appropriate accounting accordingly.  The Company determines that our in-process research and development project is complete when all material research and development costs have been incurred and no significant risks remain. The Company  reviews the carrying value of indefinite-lived intangible assets for impairment at least annually during the last quarter of our fiscal year, or more frequently if we believe indicators of impairment exist.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001078271-14-000020:note_history:11]
|  |  | March 31, 2014 |
| Current portion of long-term debt: |  |  |
| Term Loan |  | 4,875 |  |
| Revolving Facility |  | 24,000 |  |
| Current portion of long-term debt |  | 28,875 |  |
| Long-term debt, less current portion: |  |  |
| Term Loan |  | 58,500 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt, less current portion |  | 93,500 |  |
| Total debt |  | 122,375 |  |
  (was, 2014-02-06, similarity 0.8705):
[0001078271-14-000008:note_history:11]
|  |  | December 31, 2013 |
| Current portion of long-term debt |  |  |
| Term Loan |  | 4,063 |  |
| Current portion of long-term debt |  | 4,063 |  |
| Long-term debt, less current portion |  |  |
| Term Loan |  | 60,125 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt less current portion |  | 95,125 |  |
| Total debt |  | 99,188 |  |
