# EXTR notes — 0001078271-14-000053


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001078271-14-000053:notes:1]
Advertising

[0001078271-14-000053:notes:2]
Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. All other advertising costs are expensed as incurred. Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Otherwise, such cooperative advertising obligations with customers are recorded as a reduction of revenue.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001078271-14-000053:notes:3]
The Company estimates and adjusts this allowance at each balance sheet date.

[0001078271-14-000053:notes:4]
| Description | Balance atbeginningof period |  | Charges tocosts andexpenses |  | (Deductions) |  | Balance atend ofperiod |
| Year Ended July 3, 2012: |  |  |  |  |  |  |  |
| Allowance for sales returns | $ | 645 |  |  | $ | 1,013 |  |  | $ | (396 | ) |  | $ | 1,262 |  |
| Year Ended June 30, 2013: |  |  |  |  |  |  |  |
| Allowance for sales returns | $ | 1,262 |  |  | $ | 130 |  |  | $ | (615 | ) |  | $ | 777 |  |
| Year Ended June 30, 2014: |  |  |  |  |  |  |  |
| Allowance for sales returns | $ | 777 |  |  | $ | 3,063 |  |  | $ | (1,140 | ) |  | $ | 2,700 |  |

[0001078271-14-000053:notes:5]
The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001078271-14-000053:notes:6]
| Description | Balance atbeginningof period |  | Charges tocosts andexpenses |  | (Deductions) (1) |  | Balance atend ofperiod |
| Year Ended July 3, 2012: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 767 |  |  | $ | 127 |  |  | $ | (510 | ) |  | $ | 384 |  |
| Year Ended June 30, 2013: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 384 |  |  | $ | 312 |  |  | $ | (221 | ) |  | $ | 475 |  |
| Year Ended June 30, 2014: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 475 |  |  | $ | 468 |  |  | $ | (25 | ) |  | $ | 918 |  |
| (1) Uncollectible accounts written off, net of recoveries |  |  |  |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-14-000053:notes:7]
Available-for-Sale Securities

[0001078271-14-000053:notes:8]
The following is a summary of available-for-sale securities (in thousands):

[0001078271-14-000053:notes:9]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| June 30, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
| Marketable securities | — |  |  | — |  |  | — |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |
| June 30, 2013 |  |  |  |  |  |  |  |
| Money market funds | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 110,078 |  |  | 109,810 |  |  | 126 |  |  | (394 | ) |
| U.S. government agency securities | — |  |  | — |  |  | — |  |  | — |  |
| U.S. municipal bonds | — |  |  | — |  |  | — |  |  | — |  |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 54,285 |  |  | $ | 54,285 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 42,994 |  |  | 43,034 |  |  | 44 |  |  | (4 | ) |
| Marketable securities | 67,084 |  |  | 66,776 |  |  | 82 |  |  | (390 | ) |
|  | $ | 164,363 |  |  | $ | 164,095 |  |  | $ | 126 |  |  | $ | (394 | ) |

[0001078271-14-000053:notes:10]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at June 30, 2014, by contractual maturity, were as follows (in thousands):

[0001078271-14-000053:notes:11]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 23,512 |  |  | $ | 23,598 |  |
| Due in 1-2 years | 6,049 |  |  | 6,070 |  |
| Due in 2-5 years | 3,017 |  |  | 3,024 |  |
| Total investments in available for sale debt securities | $ | 32,578 |  |  | $ | 32,692 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001078271-14-000053:notes:12]
The following table summarizes the pro forma financial information (in thousands, except per share amounts):

[0001078271-14-000053:notes:13]
|  |  | Year Ended |
|  |  | June 30, 2014 |  | June 30, 2013 |
| Net revenues |  | $ | 618,893 |  |  | $ | 633,736 |  |
| Net loss |  | $ | (71,770 | ) |  | $ | (37,752 | ) |
| Net loss per share – basic and diluted |  | $ | (0.74 | ) |  | $ | (0.40 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001078271-14-000053:notes:14]
Business Combinations

[0001078271-14-000053:notes:15]
On October 31, 2013 (the “Acquisition Date”), the Company completed the acquisition of Enterasys, a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired. The Company also assumed outstanding options and restricted stock units of Enterasys at the Acquisition Date, all of which were unvested.

[0001078271-14-000053:notes:16]
The acquisition has been accounted for using the acquisition method of accounting. The preliminary purchase price allocation as of the date of the acquisition is set forth in the table below and reflects various fair value estimates. These estimates were determined through established and generally accepted valuation techniques, including preliminary work performed by third-party valuation specialists, and are subject to change during the purchase price allocation period (generally one year from the acquisition date) as valuations are finalized. The final purchase price allocation is pending the finalization of valuations for certain prepaid expenses and other current assets, accrued liabilities for certain tax liabilities in foreign jurisdictions and deferred taxes which may ultimately impact the overall level of goodwill associated with the acquisition.  Finally, the Company will consider any additional information which existed as of the acquisition date but was unknown to the Company at that time, that may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date, and may result in a change in the purchase price allocation.  While management believes that its preliminary estimates and assumptions underlying the valuations are reasonable, different estimates and assumptions could result in different valuations assigned to the individual assets acquired and liabilities assumed, and the resulting amount of goodwill.

[0001078271-14-000053:notes:17]
The following table below summarizes the preliminary allocation as of June 30, 2014 of the tangible and identifiable intangible assets acquired and liabilities assumed as compared to the allocation as of December 31, 2013, the quarter in which the transaction was completed:

[0001078271-14-000053:notes:18]
|  |  | Preliminary Allocation as of December 31, 2013 |  | Change during six months ended June 30, 2014 |  | Preliminary Allocation as of June 30, 2014 |
| Cash |  | $ | 4,969 |  |  | $ | 2,428 |  | a | $ | 7,397 |  |
| Receivables |  | 25,699 |  |  | (2,428 | ) | a | 23,271 |  |
| Inventory |  | 33,662 |  |  | — |  |  | 33,662 |  |
| Other current assets |  | 8,888 |  |  | (1,514 | ) | b | 7,374 |  |
| Property and equipment |  | 23,122 |  |  | (1,829 | ) | c | 21,293 |  |
| Identifiable intangible assets |  | 108,900 |  |  | — |  | d | 108,900 |  |
| In-process research and development |  | 3,000 |  |  | — |  |  | 3,000 |  |
| Deferred tax assets |  | 9 |  |  | — |  |  | 9 |  |
| Other assets |  | 7,343 |  |  | — |  |  | 7,343 |  |
| Goodwill |  | 57,922 |  |  | 12,955 |  |  | 70,877 |  |
| Current liabilities |  | (75,394 | ) |  | (6,141 | ) | c,e,f | (81,535 | ) |
| Other long-term liabilities |  | (13,151 | ) |  | (1,043 | ) | c | (14,194 | ) |
| Total purchase price allocation |  | $ | 184,969 |  |  | $ | 2,428 |  |  | $ | 187,397 |  |
| Less: Cash acquired from acquisition |  | (4,969 | ) |  | (2,428 | ) | a | (7,397 | ) |
| Total purchase price consideration, net of cash acquired |  | $ | 180,000 |  |  | $ | — |  |  | $ | 180,000 |  |

[0001078271-14-000053:notes:19]
a.The Company finalized the working capital adjustment during the six months ended June 30, 2014, which led to a decrease of $2.4 million in receivables and a corresponding increase in cash.  As a result of this adjustment, the total cash acquired from the acquisition also increased by the same amount.  The net effect of this adjustment is an increase in goodwill of $2.4 million.

[0001078271-14-000053:notes:20]
b.The Company obtained new information regarding the existence of prepaids as of the acquisition date which led to a decrease in the fair value of current assets of $1.5 million, and a corresponding increase in goodwill.  The change in the amortization of prepaids due to the change in fair value of current assets was immaterial.

[0001078271-14-000053:notes:21]
c.The Company updated its preliminary estimate of the fair value of property and equipment which led to a decrease of $3.0 million in property and equipment with a corresponding increase in goodwill.  The Company also updated the fair values of the asset retirement obligations and the related asset retirement assets which led to an increase in the fair value of property and equipment of $1.2 million and a corresponding increase in current liabilities and other long-term liabilities of $0.2 million and $1.0 million, respectively.  The decrease in depreciation expense due to the change in fair value of property and equipment was immaterial.

[0001078271-14-000053:notes:22]
d.During the six months ended June 30, 2014, there were no changes to the fair value of the identifiable intangible assets acquired.  However, the Company revised the estimated useful life of Order backlog from 1.5 years to 1 year.

[0001078271-14-000053:notes:23]
e.The Company obtained new information regarding accruals for litigation and statutory tax assessment as of the acquisition date which led to an increase in the fair value of current liabilities of $5.4 million and a corresponding increase in goodwill.

[0001078271-14-000053:notes:24]
f.The Company obtained new information regarding the existence of accrued liabilities as of the acquisition date which led to a net increase in the fair value of accrued liabilities by $0.5 million with a corresponding increase in goodwill.

[0001078271-14-000053:notes:25]
The Company does not believe that the measurement period adjustments to date have had a significant impact on the condensed consolidated statement of operations, balance sheet or cash flows in any period previously reported and, therefore, no retrospective adjustments were made to the Company's financial statements.

[0001078271-14-000053:notes:26]
The fair value of the acquired intangible assets were estimated using an income approach. Under this method, an intangible asset's fair value is equal to the present value of the incremental after-tax cash flows (excess earnings) attributable solely to the intangible asset over its remaining useful life. To calculate fair value, the Company used cash flows discounted at rates considered appropriate given the inherent risks associated with each type of asset. The Company believes that the level and timing of cash flows appropriately reflect market participant assumptions. Cash flows were assumed to extend through the remaining economic useful life of each class of intangible asset.

[0001078271-14-000053:notes:27]
The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay a third party to assume the obligation. The fair value of the deferred revenue obligation is affected most significantly by the estimated costs required to support the obligation, but is also affected by the assumed profit and the discount rate.

[0001078271-14-000053:notes:28]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001078271-14-000053:notes:29]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |
| Developed technology |  | 3 |  | $ | 45,000 |  |
| Customer relationships |  | 3 |  | 37,000 |  |
| Maintenance contracts |  | 5 |  | 17,000 |  |
| Trademarks |  | 3 |  | 2,500 |  |
| Order backlog |  | 1 |  | 7,400 |  |
| Total identifiable intangible assets |  | 3 |  | $ | 108,900 |  |

[0001078271-14-000053:notes:30]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Enterasys.  The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001078271-14-000053:notes:31]
The Company had an indefinite-lived asset of $3.0 million as of the acquisition-date which represents the fair value of in-process research and development activities.  The Company completed the research and development efforts in the fourth quarter of fiscal 2014 and has determined that the asset is an identifiable intangible asset with an estimated useful life of 3 years.

[0001078271-14-000053:notes:32]
The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013. For the year ended June 30, 2014, $227.7 million of revenue and $13.5 million of operating income from Enterasys are included in the consolidated statement of operations.  The Company incurred $6.0 million of acquisition-related expenses for the year ended June 30, 2014. Such acquisition-related costs are included in "Acquisition-integration costs" on the consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees payable to financial and legal advisors.

[0001078271-14-000053:notes:33]
Pro forma financial information

[0001078271-14-000053:notes:34]
The following unaudited pro forma results of operations are presented as though the acquisition of Enterasys had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, stock-based compensation for the options and restricted stock units assumed, depreciation and amortization on acquired property and equipment and intangibles, interest income and expense and related tax effects. The pro forma results of operations do not reflect the impact of non-recurring charges that have resulted from or in connection with the acquisition including acquisition and integration expenses incurred in connection with the acquisition.  The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the earliest period presented, nor are they necessarily indicative of future operating results.

[0001078271-14-000053:notes:35]
The unaudited pro forma financial information for the year ended June 30, 2014 combines the results for Extreme for the year ended June 30, 2014, which includes the results of Enterasys subsequent to the acquisition date, and the historical results for Enterasys for the three months ended September 30, 2013 and the month ended October 31, 2013. The unaudited pro forma financial information for the year ended June 30, 2013 combines the historical results for Extreme for that period, with the historical results for Enterasys for the year ended June 30, 2013. The following table summarizes the pro forma financial information (in thousands, except per share amounts):


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001078271-14-000053:notes:36]
Description of Business and Basis of Presentation

[0001078271-14-000053:notes:37]
Extreme Networks, Inc. (“Extreme Networks” or “the Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001078271-14-000053:notes:38]
Fiscal Year

[0001078271-14-000053:notes:39]
Effective June 30, 2012, the Company changed their fiscal period to coincide with calendar month-end.  Previously, the Company used a fiscal 52/53 week manufacturing calendar year.  All references herein to “fiscal 2014” or “2014” represent the fiscal year ended June 30, 2014.

[0001078271-14-000053:notes:40]
Principles of Consolidation

[0001078271-14-000053:notes:41]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001078271-14-000053:notes:42]
The Company uses the U.S. dollar predominantly as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States dollars at current rates of exchange; and revenue and expenses are translated using average rates.

[0001078271-14-000053:notes:43]
Accounting Estimates

[0001078271-14-000053:notes:44]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.


## us-gaap:CollaborativeArrangementDisclosureTextBlock

[0001078271-14-000053:notes:45]
Technology Agreements

[0001078271-14-000053:notes:46]
On July 16, 2013, the Company entered into a confidential Patent License and Settlement Agreement (“License Agreement”) with Chrimar Systems Inc. The agreement provides for a non-exclusive, irrevocable, perpetual, non-transferable, and non-assignable, fully-paid-up worldwide royalty-bearing license to certain patents and a release of claims based on any prior infringement of such patents. Total fees for the grant of the license under the License Agreement was $1.4 million. The Company had capitalized $1.2 million related to such patents in fiscal 2012 based on a probable estimated value and recorded a charge of $0.3 million based on the estimated probable loss. The $1.2 million was recorded as intangible assets, net and continues to be amortized over the remaining life of the patents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-14-000053:notes:47]
Commitments, Contingencies and Leases

[0001078271-14-000053:notes:48]
Leases

[0001078271-14-000053:notes:49]
The Company currently leases its current headquarters, research and development facilities and office spaces for its various United States and international operations. Certain leases contain rent escalation clauses and renewal options. As part of the Company’s existing leased facilities, the Company has received lease incentives which take the form of a fixed allowance towards lease improvements on the respective facility. The Company used the allowance to make leasehold improvements which are being depreciated over the useful life of the assets or the lease term, whichever is shorter. The offsetting lease incentives liability is being amortized on a straight-line basis over the term of the lease as an offset to rent expense.

[0001078271-14-000053:notes:50]
Future annual minimum lease payments under all non-cancelable operating leases having initial or remaining lease terms in excess of one year at June 30, 2014 were as follows (in thousands):

[0001078271-14-000053:notes:51]
|  | Future LeasePayments |
| Fiscal 2015 | $ | 9,093 |  |
| Fiscal 2016 | 7,482 |  |
| Fiscal 2017 | 6,974 |  |
| Fiscal 2018 | 6,887 |  |
| Fiscal 2019 | 6,918 |  |
| Thereafter | 20,755 |  |
| Total minimum payments | $ | 58,109 |  |

[0001078271-14-000053:notes:52]
Rent expense was approximately $10.2 million in fiscal 2014, $5.9 million in fiscal 2013, and $4.3 million in fiscal 2012.

[0001078271-14-000053:notes:53]
Purchase Commitments

[0001078271-14-000053:notes:54]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2014, the Company had non-cancelable commitments to purchase approximately $64.7 million of such inventory during the first quarter of fiscal 2015.

[0001078271-14-000053:notes:55]
Legal Proceedings

[0001078271-14-000053:notes:56]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-14-000053:notes:57]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-14-000053:notes:58]
Intellectual Property Litigation

[0001078271-14-000053:notes:59]
Enterasys Networks

[0001078271-14-000053:notes:60]
On June 21, 2005, Enterasys Networks ("Enterasys") filed suit against Extreme and Foundry Networks, Inc. (“Foundry”) in the United States District Court for the District of Massachusetts, Civil Action No. 05-11298 DPW. The complaint alleged willful infringement of U.S. Patent Nos. 5,251,205; 5,390,173; 6,128,665; 6,147,995; 6,539,022; and 6,560,236, and sought: a) a judgment that the Company willfully infringes each of the patents; (b) a permanent injunction from infringement, inducement of infringement and contributory infringement of each of the six patents; (c) damages and a “reasonable royalty” to be determined at trial; (d) treble damages; (e) attorneys' fees, costs and interest; and (f) equitable relief at the Court's discretion. Petitions for reexamination were filed challenging five of the patents at issue to the U.S. Patent and Trademark Office, and a stay of the case was entered. Following the reexamination proceedings, Enterasys withdrew its allegations of infringement as to two of the patents, U.S. Patent Nos. 6,539,022 and 6,560,236. The stay was lifted on May 21, 2010, and the Court held claim construction hearings in December 2010. Fact discovery was ongoing. No trial date was set.

[0001078271-14-000053:notes:61]
On April 20, 2007, the Company filed suit against Enterasys in the United States District Court for the Western District of Wisconsin, Civil Action No. 07-C-0229-C. The complaint alleged willful infringement of U.S. Patents Nos. 6,104,700, 6,678,248, and 6,859,438, and sought injunctive relief against Enterasys' continuing sale of infringing goods and monetary damages. Enterasys responded to the complaint on May 30, 2007, and also filed counterclaims alleging infringement of three U.S. patents owned by Enterasys. On April 9, 2008, the Court dismissed Enterasys' counterclaims on one of its patents with prejudice. On May 5, 2008, the Court granted the Company's motion for summary judgment, finding that it does not infringe Enterasys' two remaining patents and dismissing all of Enterasys' remaining counterclaims with prejudice. On May 30, 2008, a jury found that Enterasys infringed all three of the Company's patents and awarded the Company damages in the amount of $0.2 million. The Court also ruled in the Company's favor on Enterasys' challenge to the validity of the Company's patents. On October 29, 2008, the Court denied Enterasys' post-trial motion for judgment as a matter of law, and granted Extreme Network's motion for a permanent injunction against Enterasys. The injunction order permanently enjoins Enterasys from manufacturing, using, offering to sell, selling in the U.S. and importing into the U.S. the Enterasys products accused of infringing Extreme Network's three patents. On March 16, 2009, the Court also denied Enterasys' motion for a new trial, but granted Enterasys' motion for a stay of the injunction pending appeal. On April 17, 2009, Enterasys filed its notice of appeal and on May 1, 2009, the Company filed its cross appeal. On September 30, 2010, the U.S. Court of Appeals for the Federal Circuit upheld the jury verdict of infringement by Enterasys of the Company's patents and the Districts Court's summary judgment of non-infringement by the Company of Enterasys' '727 patent. The Federal Circuit reversed the judgment of non-infringement by the Company of Enterasys '181 patent, holding that the District Court Judge applied an incorrect claim construction and reversed the District Court's denial of the Company's request for attorneys' fees as premature.

[0001078271-14-000053:notes:62]
On November 4, 2011, a jury returned a verdict of non-infringement by the Company of the '181 patent and found the patent to be valid. Both parties filed post-trial motions, including motions for a new trial, for judgment as a matter of law and for attorneys' fees, all of which the Court denied on July 11, 2012. Enterasys did not file a notice of appeal by the August 10, 2012 deadline.  Consequently, the judgment of non-infringement in favor of the Company in the second trial is final. During the fourth quarter of fiscal 2012, Enterasys paid the Company $0.6 million related to the judgment.  During the quarter ended December 31, 2012, the Company received payments from Enterasys totaling approximately $0.4 million for the Court's award for damages, supplemental damages, pre and post judgment interests, costs from the first trial and second trial, plus the amount Enterasys agreed to release for damages held in escrow that accrued during the stay of the injunction post-trial and on appeal.

[0001078271-14-000053:notes:63]
On March 29, 2013, the parties entered into a confidential settlement agreement (“Agreement”). The Agreement required a dismissal with prejudice of the Wisconsin and Massachusetts litigation, as well as cross covenants not to sue and survival of settlement rights for any acquiring party of the parties. Joint motions to dismiss were granted on April 13, 2013, and April 15, 2013 respectively.  All matters between the parties have now been resolved.

[0001078271-14-000053:notes:64]
Chrimar Systems

[0001078271-14-000053:notes:65]
On October 31, 2011, Chrimar Systems, Inc. DBA CMS Technologies, and Chrimar Holding Company filed suit against the Company, Cisco Systems, Inc., and Cisco Consumer Products LLC. Cisco-Linksys LLC, Hewlett-Packard Company, 3Com Corporation and Avaya, Inc. in the United States District Court for the District of Delaware, Civil Action No. 11-1050 (the "Delaware action").  The complaint alleges infringement of U.S. Patent No. 7,457,250.   The Delaware action has been stayed pursuant to 28 USC Section 1659(a) pending final determination of the International Trade Commission action described below, based on the fact that the allegations in both cases relate to the same patent.

[0001078271-14-000053:notes:66]
During the fourth quarter of the fiscal 2012, the Company engaged in settlement discussions with Chrimar Systems Inc.  As part of the negotiations the Company determined that it is reasonably possible that a range of loss could be between $0.3 million and $1.4 million which was dependent on a number of factors including whether mutually acceptable settlement terms can be reached. During the quarter ended June 30, 2012 the Company capitalized $1.2 million related to such patents as intangibles based on a probable estimated value and recorded a charge of $0.3 million based on its best estimate of the probable loss.  In addition, during the quarter ending March 31, 2013, venue for the Delaware action was transferred to the United States District Court for the District of Northern California.

[0001078271-14-000053:notes:67]
On July 16, 2013, the parties entered into a confidential patent license and settlement agreement (“Agreement”). Pursuant to that Agreement, the Company paid $1.4 million on July 25, 2013 and Chrimar filed for dismissal of the Delaware Action with prejudice on July 29, 2013. All matters between the parties have now been resolved.

[0001078271-14-000053:notes:68]
Reefedge Networks

[0001078271-14-000053:notes:69]
On September 17, 2012, Reefedge Networks, LLC ("ReefEdge) filed suit against the Company in the United States District Court for the District of Delaware, Civil Action No. 12-1148. The complaint alleged wrongful use, making, selling, and/or offering to sell products that infringe U.S. Patent Nos. 6,633.761; 6,975,864; and 7,197,308 and sought unspecified monetary damages and a permanent injunction for products originating from a single supplier to which the Company had submitted an indemnification request. An answer was filed on December 10, 2012. The Company was dismissed from the suit on May 6, 2013. All matters between the parties have now been resolved.

[0001078271-14-000053:notes:70]
On September 17, 2012, ReefEdge also filed suit against Enterasys in the United States District Court for the District of Delaware alleging certain of the company's products (wireless controllers and wireless access points), infringe three ReefEdge U.S. patents (6633761, 6975864, 7197308).  ReefEdge sought injunctive relief as well as monetary damages, costs, expenses and attorney fees, although there was no quantified amount sought.  Extreme assumed this litigation as part of the acquisition of Enterasys.  The parties reached a settlement in April 2014, which required the Company to pay an immaterial amount.

[0001078271-14-000053:notes:71]
Relay IP Inc.

[0001078271-14-000053:notes:72]
On May 3, 2013, Relay IP, Inc. filed suit against the Company in the United States District Court for the District of Delaware, Civil Action case number 13-775 (Extreme Case). Further on May 6, 2013 they also filed a similar suit against Enterasys in the same court, Civil Action case number 13-774. The complaint alleges infringement based on the Company's testing of its own equipment and inducing its customers to infringe U.S. Patent No. 5,331,637 and seeks unspecified monetary damages. An answer was filed on both cases in July, 2013. The suit is one of approximately 40 nearly simultaneous suits filed by Relay IP against numerous networking equipment manufacturers, suppliers, operators, and users including Cisco Systems, Hewlett-Packard, Juniper Networks, Avaya, Extreme and Enterasys. An answer was filed on both cases in July, 2013.  This matter was dismissed against Extreme and Enterasys on all claims by an Order of the District Court on April 28, 2014. It is our understanding that the suit was dismissed due to a settlement by RPX with the Plaintiff on behalf of all RPX members named as Defendants in this action.

[0001078271-14-000053:notes:73]
Net Navigation Systems, LLC.

[0001078271-14-000053:notes:74]
On April 23, 2014, Net Navigation Systems, LLC (“Net Navigation”) filed a complaint against Extreme Networks, Inc. in the Eastern District of Texas.  In the Complaint, the plaintiff asserts infringement of U.S. Patent No. 6,625,122 (“the ’122 Patent”), entitled “Selection of Data for Network Transmission,” which issued on September 23, 2003.  Although somewhat vague, the Complaint identifies the following products as accused of infringing the ‘122 Patent:  “Networking products capable of providing priority to different data flows based on bandwidth.”  The Complaint also states that Extreme has infringed by “making, selling, and causing its customers to use networking products capable of providing priority to different data flows based on bandwidth, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.”  The Complaint also asserts infringement of U.S. Patent No. 6,434,145 (“the ’145 Patent”), entitled “Processing of Network Data by Parallel Processing Channels,” which issued on August 13, 2002.  Again, although somewhat vague, the Complaint states that Extreme has infringed by “making, using, importing, selling, and/or offering for sale in the United States, including within this judicial district, networking products that use parallel processing channels, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.” Net Navigation, a non-practicing entity, seeks injunctive relief as well as monetary damages, cost, expenses and attorney fees, although the complaint seeks no quantified amount.  The Company denies the claims and is preparing to vigorously defend our technology.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

[0001078271-14-000053:notes:75]
Selene Communication Technologies, LLC.

[0001078271-14-000053:notes:76]
On April 7, 2014, Selene Communication Technologies, LLC (“Selene”), filed a complaint in the US District Court for the District of Delaware against Extreme and Enterasys asserting a cause of action for infringement of United States Patent No. 7,143,444 (the “444 Patent”). Selene has also recently sued a number of other technology companies including Cisco for infringement of the 444 Patent.  Selene, a non-practicing entity, seeks injunctive relief as well as monetary damages, costs, expenses and attorney fees, although the complaint seeks no quantified amount.  The Company denies the claims and is preparing to vigorously defend our technology.  Given the preliminary nature of the claims, it is premature to assess the likelihood of a particular outcome.

[0001078271-14-000053:notes:77]
Commonwealth of Kentucky

[0001078271-14-000053:notes:78]
On or about February 3, 2014, a class action lawsuit was filed in the Commonwealth of Kentucky against Enterasys Networks, Inc. and two other defendants.  The complaint alleges that Enterasys and its subcontractor, TJL Information Technologies, Inc., d.b.a. Unbridled Information Technologies (“Subcontractor”), violated Kentucky’s wage and hour laws and failed to pay the prevailing wage in violation of the Kentucky State Prevailing Wage Act (the “Act”) on various public works projects for a number of Kentucky government agencies since January 2010.  Plaintiffs also allege common law actions for quantum merit and unjust enrichment and they seek monetary damages, costs, expenses and attorney fees, although there was no quantified amount identified.  One of the defendants, Integrated Facility Systems, LLC (“IFS”), has filed a cross-claim against Enterasys.  The Company denies the claims and has filed answers to both the complaint and cross-claim on April 16, 2014.  In addition, Company filed a cross-claim for indemnity against IFS and the Subcontractor.  This litigation is in the early stages of discovery.  Furthermore, the Company has made a claim for indemnification to Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.) (“Seller”), which claim arises pursuant to the stock purchase agreement between Seller and Extreme in connection with Extreme’s purchase of Enterasys (the “Purchase Agreement”).  Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular outcome.

[0001078271-14-000053:notes:79]
ICMS Tax Assessment Matters

[0001078271-14-000053:notes:80]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014 by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US$1.5 million), plus interest and penalties (that are currently estimated to be approximately US$9 million).  Given the preliminary nature of the lawsuit and the uncertainty of the legal environment in Brazil, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position, cash flows or overall trends in results of operations.  The range of the potential total tax liability related to these matters is estimated to be from $0 million to $9 million, of which the Company believes $4.3 million is the best estimate within the range and has recorded an accrual as of the acquisition date of Enterasys as such matter relates to the period before the acquisition.

[0001078271-14-000053:notes:81]
Indemnification Obligations

[0001078271-14-000053:notes:82]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers insurance coverage is uncertain. As of June 30, 2014, the Company had no outstanding indemnification claims.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-14-000053:notes:83]
The following table summarizes deferred revenue, net at June 30, 2014 and June 30, 2013, respectively (in thousands):

[0001078271-14-000053:notes:84]
|  | June 30, 2014 |  | June 30, 2013 |
| Deferred services | $ | 89,657 |  |  | $ | 38,003 |  |
| Deferred product and other revenue | 8,020 |  |  | 3,451 |  |
| Total deferred revenue | 97,677 |  |  | 41,454 |  |
| Less: current portion | 74,735 |  |  | 33,184 |  |
| Non-current deferred revenue, net | $ | 22,942 |  |  | $ | 8,270 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-14-000053:notes:85]
Foreign Exchange Forward Contracts

[0001078271-14-000053:notes:86]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as Other Assets, Net at fair value. Changes in the fair value of derivatives are recognized in earnings as Other Income (Expense). The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by the foreign currency forecasted transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. At June 30, 2014, these forward foreign currency contracts had a notional principal amount of $7.6 million and an immaterial unrealized gain. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-14-000053:notes:87]
Foreign currency transaction gains and losses from operations were a loss of $1.5 million in fiscal 2014, a loss of $0.9 million in fiscal 2013 and a gain of $2.5 million in fiscal 2012.  Included in the 2012 gain is a $1.9 million adjustment resulting from Japan subsidiary liquidation.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-14-000053:notes:88]
Employee Benefit Plans (including Share-based Compensation)

[0001078271-14-000053:notes:89]
As of June 30, 2014, the Company has the following share-based compensation plans:

[0001078271-14-000053:notes:90]
2013 Equity Incentive Plan

[0001078271-14-000053:notes:91]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaces the 2005 Equity Incentive Plan (the "2005 Plan").

[0001078271-14-000053:notes:92]
Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorizes the issuance of up to 9,000,000 shares of the Company’s common stock. In addition, up to 9,500,000 shares subject to stock options and awards outstanding under the 2005 Plan that expired and 6,900,000 shares subject to stock options outstanding and awards outstanding under the Enterasys Networks Inc. 2013 Stock Plan have been added to the number of shares available for future grant under the 2013 Plan.  As of June 30, 2014, total options and awards to acquire 2,149,398 shares were outstanding under the 2013 Plan and 6,350,048 shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0001078271-14-000053:notes:93]
Enterasys Inc. 2013 Stock Plan

[0001078271-14-000053:notes:94]
Enterasys Networks Inc. 2013 Stock Plan (the "Enterasys Plan") was assumed by the Company on October 31, 2013 pursuant to the Stock Purchase Agreement, dated September 12, 2013, by and between the Company and Enterprise Networks Holdings, Inc.  As of June 30, 2014, total options and awards to acquire 5,700,360 shares were outstanding under the Enterasys Plan. Options granted under this plan have a contractual term of seven years.

[0001078271-14-000053:notes:95]
2005 Equity Incentive Plan

[0001078271-14-000053:notes:96]
The 2005 Plan was adopted by the Company’s Board of Directors on October 20, 2005, and approved by stockholders on December 2, 2005. The 2005 Plan replaced the 1996 Stock Option Plan (the “1996 Plan”), 2000 Non-statutory Stock Option Plan (the “2000 Plan”) and 2001 Non-statutory Stock Option Plan (the “2001 Plan”).   Effective November 20, 2013, the 2005 Plan was terminated, and, as of June 30, 2014, options to acquire 9,183,034 shares were outstanding under the 2005 Plan.

[0001078271-14-000053:notes:97]
Amended 1996 Stock Option Plan

[0001078271-14-000053:notes:98]
The 1996 Plan was originally adopted in September 1996, and provided for the grant of options for common stock to eligible participants. A total of 56,382,867 shares were reserved under the 1996 Plan. Options granted under this plan have a contractual term of ten years. Effective December 2, 2005, the 1996 Plan was terminated, and, as of June 30, 2014, options to acquire 303,763 shares were outstanding under the 1996 Plan.

[0001078271-14-000053:notes:99]
2000 Plan

[0001078271-14-000053:notes:100]
In March 2000, the Board of Directors adopted the 2000 Plan which provided for the grant of options for common stock to eligible participants. A total of 4,000,000 shares were reserved under the 2000 Plan. Options granted under this plan have a contractual term of ten years. Effective December 2, 2005, the 2000 Plan was terminated, and, as of June 30, 2014, options to acquire 5,000 shares were outstanding under the 2000 Plan.

[0001078271-14-000053:notes:101]
2001 Plan

[0001078271-14-000053:notes:102]
In May 2001, the Board of Directors adopted the 2001 Plan which provided for the grant of options for common stock to eligible participants. A total of 4,000,000 shares were reserved under the 2001 Plan. Options granted under this plan have a contractual term of ten years. Effective December 2, 2005, the 2001 Plan was terminated, and, as of June 30, 2014, there were  no shares outstanding under the 2001 Plan.

[0001078271-14-000053:notes:103]
The following table summarizes stock option activity under all plans:

[0001078271-14-000053:notes:104]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value($ 000’s) |
| Options outstanding at July 3, 2011 | 9,132 |  |  | $ | 4.01 |  |  |  |  |  |
| Granted | 2,593 |  |  | $ | 3.30 |  |  |  |  |  |
| Exercised | (437 | ) |  | $ | 2.24 |  |  |  |  |  |
| Canceled | (2,282 | ) |  | $ | 4.85 |  |  |  |  |  |
| Options outstanding at June 30, 2012 | 9,006 |  |  | $ | 3.68 |  |  |  |  |  |
| Granted | 4,163 |  |  | $ | 3.35 |  |  |  |  |  |
| Exercised | (2,045 | ) |  | $ | 3.00 |  |  |  |  |  |
| Canceled | (1,979 | ) |  | $ | 3.77 |  |  |  |  |  |
| Options outstanding at June 30, 2013 | 9,145 |  |  | $ | 3.66 |  |  |  |  |  |
| Granted | 6,347 |  |  | $ | 5.15 |  |  |  |  |  |
| Exercised | (1,792 | ) |  | $ | 3.59 |  |  |  |  |  |
| Canceled | (1,968 | ) |  | $ | 5.01 |  |  |  |  |  |
| Options outstanding at June 30, 2014 | 11,732 |  |  | $ | 4.26 |  |  | 5.13 |  | 6,846 |  |
| Exercisable at June 30, 2014 | 4,846 |  |  | $ | 3.88 |  |  | 3.77 |  | 3,825 |  |
| Vested and expected to vest at June 30, 2014 | 10,563 |  |  | $ | 4.21 |  |  | 5.01 |  | 6,397 |  |

[0001078271-14-000053:notes:105]
Included in the options granted above for the year ended June 30, 2014 are 4.2 million options, assumed in connection with the acquisition of Enterasys on October 31, 2013, with an exercise price of $5.30.

[0001078271-14-000053:notes:106]
The following table summarizes significant ranges of outstanding and exercisable options at June 30, 2014:

[0001078271-14-000053:notes:107]
| Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices | NumberOutstanding (000’s) |  | Weighted-AverageRemaining Contractual Life |  | Weighted-AverageExercise Price |  | NumberExercisable (000’s) |  | Weighted-AverageExercise Price |
|  |  |  | (In years) |  |  |  |  |  |  |
| $1.69 – $3.03 | 784 |  |  | 3.62 |  | $ | 2.42 |  |  | 756 |  |  | $ | 2.40 |  |
| $3.17 – $3.17 | 1,954 |  |  | 5.80 |  | $ | 3.17 |  |  | 597 |  |  | $ | 3.17 |  |
| $3.25 – $3.53 | 1,313 |  |  | 4.25 |  | $ | 3.37 |  |  | 834 |  |  | $ | 3.38 |  |
| $3.54 – $3.87 | 1,224 |  |  | 4.91 |  | $ | 3.63 |  |  | 629 |  |  | $ | 3.69 |  |
| $4.03 – $4.25 | 1,588 |  |  | 4.59 |  | $ | 4.20 |  |  | 776 |  |  | $ | 4.22 |  |
| $4.26 – $5.26 | 242 |  |  | 1.36 |  | $ | 4.70 |  |  | 242 |  |  | $ | 4.70 |  |
| $5.30 – $5.30 | 3,466 |  |  | 5.73 |  | $ | 5.30 |  |  | 897 |  |  | $ | 5.30 |  |
| $5.36 – $6.44 | 1,061 |  |  | 6.49 |  | $ | 5.75 |  |  | 15 |  |  | $ | 6.02 |  |
| $6.48 – $6.48 | 10 |  |  | 0.35 |  | $ | 6.48 |  |  | 10 |  |  | $ | 6.48 |  |
| $6.96 – $6.96 | 90 |  |  | 0.42 |  | $ | 6.96 |  |  | 90 |  |  | $ | 6.96 |  |
| $1.69 – $6.96 | 11,732 |  |  | 5.13 |  | $ | 4.26 |  |  | 4,846 |  |  | $ | 3.88 |  |

[0001078271-14-000053:notes:108]
The total intrinsic value of options exercised in fiscal 2014, fiscal 2013 and fiscal 2012 was $4.1 million, $1.1 million, and $0.5 million, respectively. The fair value of options vested in fiscal 2014, fiscal 2013 and fiscal 2012 was $2.9 million, $1.5 million, and $2.3 million, respectively.

[0001078271-14-000053:notes:109]
Stock Awards

[0001078271-14-000053:notes:110]
Stock awards may be granted under the 2005 Plan on terms approved by the Board of Directors. Stock awards generally provide for the issuance of restricted stock which vests over a fixed period.

[0001078271-14-000053:notes:111]
The following table summarizes stock award activity:

[0001078271-14-000053:notes:112]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |
| Non-vested stock outstanding at July 3, 2011 | 1,870 |  |  | $ | 2.79 |  |
| Granted | 739 |  |  | $ | 3.11 |  |
| Vested | (1,233 | ) |  | $ | 3.28 |  |
| Cancelled | (298 | ) |  | $ | 3.17 |  |
| Non-vested stock outstanding at June 30, 2012 | 1,078 |  |  | $ | 2.35 |  |
| Granted | 3,220 |  |  | $ | 3.49 |  |
| Vested | (939 | ) |  | $ | 3.38 |  |
| Cancelled | (673 | ) |  | $ | 3.44 |  |
| Non-vested stock outstanding at June 30, 2013 | 2,686 |  |  | $ | 3.09 |  |
| Granted | 5,193 |  |  | $ | 5.50 |  |
| Vested | (1,062 | ) |  | $ | 3.77 |  |
| Cancelled | (817 | ) |  | $ | 3.65 |  |
| Non-vested stock outstanding at June 30, 2014 | 6,000 |  |  | $ | 4.98 |  |

[0001078271-14-000053:notes:113]
Included in the restricted stock units granted above for the year ended June 30, 2014 are 2.7 million restricted stock units assumed in connection with the acquisition of Enterasys on October 31, 2013, with an acquisition-date fair value of $5.30.

[0001078271-14-000053:notes:114]
The non-vested shares were placed in an escrow account and will be released to the recipients as the shares vest over periods of up to twenty-four months. If a participant terminates employment prior to the vesting dates, the non-vested shares will be canceled and returned to the 2013 Plan. The Company recognizes compensation expense on the awards over the vesting period based on an intrinsic value as of the date of grant.

[0001078271-14-000053:notes:115]
1999 Employee Stock Purchase Plan

[0001078271-14-000053:notes:116]
In January 1999, the Board of Directors approved the adoption of Extreme Network’s 1999 Employee Stock Purchase Plan (the “ESPP”). On December 2, 2005, the stockholders approved an amendment to the ESPP to increase the maximum number of shares of common stock that may be issued under the plan by 5,000,000 to a total of 12,000,000 shares. The ESPP permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation. No more than 625 shares may be purchased on any purchase date per employee. Each offering period has a maximum duration of 3 months. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. On January 26, 2010, the Board of Directors approved an amendment to the ESPP to increase the maximum number of shares that may be purchased on any purchase date per employee from 625 shares to 1,000 shares. Through June 30, 2014, 10,795,209 shares had been purchased under the ESPP.

[0001078271-14-000053:notes:117]
Share Based Compensation

[0001078271-14-000053:notes:118]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (dollars in thousands):

[0001078271-14-000053:notes:119]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Cost of product revenue | $ | 836 |  |  | $ | 428 |  |  | $ | 463 |  |
| Cost of service revenue | 895 |  |  | 292 |  |  | 257 |  |
| Research and development | 4,111 |  |  | 2,461 |  |  | 1,363 |  |
| Sales and marketing | 6,430 |  |  | 1,032 |  |  | 1,765 |  |
| General and administrative | 3,650 |  |  | 3,140 |  |  | 2,341 |  |
| Total share-based compensation expense | $ | 15,922 |  |  | $ | 7,353 |  |  | $ | 6,189 |  |

[0001078271-14-000053:notes:120]
The amount of stock based compensation expense capitalized in inventory has been immaterial for each of the periods presented. As of June 30, 2014, there was $12.6 million of total unrecognized compensation cost related to unvested stock options. This cost is expected to be recognized over a weighted-average period of approximately 2.8 years. As of June 30, 2014, there were approximately $20.4 million in unrecognized compensation costs related to non-vested stock awards. This cost is expected to be recognized over a weighted-average period of approximately 1.9 years.

[0001078271-14-000053:notes:121]
The weighted-average grant-date per share fair value of options granted in fiscal 2014, fiscal 2013, and fiscal 2012 was $2.36, $1.74, and $1.67, respectively. The weighted-average estimated per share fair value of shares purchased under the ESPP in fiscal 2014, fiscal 2013, and fiscal 2012 was $1.64, $0.88, and $0.98, respectively.  The average fair-value and the average derived service period on the grant-date for the performance-based option awards with market conditions, granted in fiscal 2013, was $1.53 and 2.5 years respectively.

[0001078271-14-000053:notes:122]
The Company uses the straight-line method for expense attribution, and the Company estimates forfeitures and only recognizes expense for those shares expected to vest. The Company’s estimated forfeiture rate in fiscal 2014 based on the Company’s historical forfeiture experience is approximately 12% for non-executives and 14% for executives.

[0001078271-14-000053:notes:123]
The fair value of each option award and share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of performance-based option awards, with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-14-000053:notes:124]
|  | Stock Option Plan |  | Employee Stock Purchase Plan |
|  | Year Ended |  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Expected life | 4.40 years |  |  | 4.58 years |  |  | 5.06 years |  |  | 0.25 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.24 | % |  | 0.74 | % |  | 1.05 | % |  | 0.08 | % |  | 0.07 | % |  | 0.07 | % |
| Volatility | 56 | % |  | 64 | % |  | 60 | % |  | 58 | % |  | 49 | % |  | 61 | % |
| Dividend yield | 0 | % |  | 0 | % |  | 0 | % |  | 0 | % |  | 0 | % |  | 0 | % |

[0001078271-14-000053:notes:125]
401(k) Plan

[0001078271-14-000053:notes:126]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $17,500 for calendar year 2014. Effective January 1, 2005, employees age 50 or over may elect to contribute an additional $5,500. The amount contributed to the Plan is on a pre-tax basis.

[0001078271-14-000053:notes:127]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year.   All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. During the year ended June 30, 2014, eligible employees from Enterasys were also added to the Plan as of the acquisition date.  The program is to match $0.50 for every dollar contributed by the employee up to the first 2.5% of pay. The Company’s matching contributions to the Plan totaled $0.8 million, $0.5 million, and $0.5 million, for fiscal 2014, fiscal 2013 and fiscal 2012, respectively. No discretionary contributions were made in fiscal 2014, fiscal 2013 and fiscal 2012.


## us-gaap:EarningsPerShareTextBlock

[0001078271-14-000053:notes:128]
Net (Loss) Income Per Share

[0001078271-14-000053:notes:129]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock. The following table presents the calculation of basic and diluted net (loss) income per share (in thousands, except per share data):

[0001078271-14-000053:notes:130]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Net (loss) income | $ | (57,310 | ) |  | $ | 9,673 |  |  | $ | 15,872 |  |
| Weighted-average shares used in per share calculation – basic | 95,515 |  |  | 93,954 |  |  | 93,451 |  |
| Incremental shares using the treasury stock method: |  |  |  |  |  |
| Stock options | — |  |  | 385 |  |  | 372 |  |
| Unvested restricted awards | — |  |  | 600 |  |  | 554 |  |
| Employee Stock Purchase Plan | — |  |  | 105 |  |  | 113 |  |
| Weighted -average share used in per share calculation – diluted | 95,515 |  |  | 95,044 |  |  | 94,490 |  |
| Net (loss) income per share – basic | $ | (0.60 | ) |  | $ | 0.10 |  |  | $ | 0.17 |  |
| Net (loss) income per share – diluted | $ | (0.60 | ) |  | $ | 0.10 |  |  | $ | 0.17 |  |

[0001078271-14-000053:notes:131]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP. Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For fiscal 2014, 2013, and 2012, the Company excluded 4.1 million, 6.7 million, and 8.3 million outstanding weighted average stock options, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-14-000053:notes:132]
Long-Lived Assets

[0001078271-14-000053:notes:133]
Long-lived assets include (a) property and equipment, (b) goodwill and intangible assets, and (c) other assets.  Property and equipment, goodwill and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. The Company reduces the carrying value of service inventory to net realizable value based on expected quantities needed to satisfy contractual service requirements of customers.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-14-000053:notes:134]
Income Taxes

[0001078271-14-000053:notes:135]
Income before income taxes is as follows (in thousands):

[0001078271-14-000053:notes:136]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Domestic | $ | (70,321 | ) |  | $ | 14,692 |  |  | $ | 20,839 |  |
| Foreign | 17,200 |  |  | (3,341 | ) |  | (3,771 | ) |
| Total | $ | (53,121 | ) |  | $ | 11,351 |  |  | $ | 17,068 |  |

[0001078271-14-000053:notes:137]
The provision for income taxes for fiscal 2014, 2013 and fiscal 2012 consisted of the following (in thousands):

[0001078271-14-000053:notes:138]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Current: |  |  |  |  |  |
| Federal | $ | 22 |  |  | $ | 225 |  |  | $ | 114 |  |
| State | 329 |  |  | 140 |  |  | 79 |  |
| Foreign | 2,987 |  |  | 1,163 |  |  | 916 |  |
| Total current | 3,338 |  |  | 1,528 |  |  | 1,109 |  |
| Deferred: |  |  |  |  |  |
| Federal | 1,632 |  |  | 15 |  |  | 30 |  |
| State | 76 |  |  | — |  |  | — |  |
| Foreign | (857 | ) |  | 135 |  |  | 57 |  |
| Total deferred | 851 |  |  | 150 |  |  | 87 |  |
| Provision for income taxes | $ | 4,189 |  |  | $ | 1,678 |  |  | $ | 1,196 |  |

[0001078271-14-000053:notes:139]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (35 percent) to income before taxes is explained below (in thousands):

[0001078271-14-000053:notes:140]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Tax at federal statutory rate | $ | (18,592 | ) |  | $ | 3,973 |  |  | $ | 5,974 |  |
| State income tax, net of federal benefit | 329 |  |  | 105 |  |  | 51 |  |
| Change in valuation allowance | 20,729 |  |  | (3,687 | ) |  | (8,035 | ) |
| Foreign earnings taxed at other than U.S. rates | (346 | ) |  | 498 |  |  | 3,607 |  |
| Deferred compensation | 348 |  |  | 845 |  |  | 170 |  |
| Goodwill amortization | 1,097 |  |  | — |  |  | — |  |
| Other | 624 |  |  | (56 | ) |  | (571 | ) |
| Provision for income taxes | $ | 4,189 |  |  | $ | 1,678 |  |  | $ | 1,196 |  |

[0001078271-14-000053:notes:141]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001078271-14-000053:notes:142]
|  | June 30, 2014 |  | June 30, 2013 |
| Deferred tax assets: |  |  |  |
| Net operating loss carry-forwards | $ | 97,630 |  |  | $ | 85,276 |  |
| Tax credit carry-forwards | 30,019 |  |  | 28,882 |  |
| Depreciation | 129 |  |  | — |  |
| Intangible amortization | 6,061 |  |  | — |  |
| Deferred revenue (net) | 10,540 |  |  | 9,710 |  |
| Warrant amortization | 2,723 |  |  | 3,991 |  |
| Inventory write-downs | 3,265 |  |  | 2,759 |  |
| Other allowances and accruals | 6,380 |  |  | 3,658 |  |
| Stock based compensation | 6,257 |  |  | 2,973 |  |
| Other | 10,772 |  |  | 5,741 |  |
| Total deferred tax assets | 173,776 |  |  | 142,990 |  |
| Valuation allowance | (172,475 | ) |  | (142,023 | ) |
| Total net deferred tax assets | 1,301 |  |  | 967 |  |
| Deferred tax liabilities: |  |  |  |
| Depreciation | — |  |  | (388 | ) |
| Goodwill amortization | (1,097 | ) |  | — |  |
| Brazilian foreign exchange gain | (2,670 | ) |  | — |  |
| Deferred tax liability on foreign withholdings | (167 | ) |  | (134 | ) |
| Total deferred tax liabilities | (3,934 | ) |  | (522 | ) |
| Net deferred tax assets (liabilities) | $ | (2,633 | ) |  | $ | 445 |  |
| Recorded as: |  |  |  |
| Net current deferred tax assets | $ | 1,058 |  |  | $ | 386 |  |
| Net non-current deferred tax assets | 230 |  |  | 294 |  |
| Net current deferred tax liabilities | (2,657 | ) |  | (235 | ) |
| Net non-current deferred tax liabilities | (1,264 | ) |  | — |  |
| Net deferred tax assets (liabilities) | $ | (2,633 | ) |  | $ | 445 |  |

[0001078271-14-000053:notes:143]
The Company's global valuation allowance increased by $30.5 million in the fiscal year ended June 30, 2014 and increased by $1.4 million in the fiscal year ended June 30, 2013. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against non-U.S. deferred tax assets in Australia, Brazil, Japan and Singapore.  The valuation allowance is determined by assessing both negative and positive available evidence to assess whether it is more likely than not that the deferred tax assets will be recoverable; The Company's inconsistent earnings in recent periods coupled with the inability to forecast greater than one quarter in advance as well as the cyclical nature of the Company's business provides sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001078271-14-000053:notes:144]
As of June 30, 2014, the Company had net operating loss carry-forwards for U.S. federal and state tax purposes of $290.2 million and $97.4 million, respectively, of which $38.6 million and $36.0 million, respectively, represent deductions from share-based compensation for which a benefit would be recorded in additional paid-in capital when realized. The Company also had foreign net operating loss carry-forwards in Ireland, Australia, Japan and Singapore of $67.5 million, $12.5 million, $0.1 million, and $1.9 million, respectively, as of June 30, 2014. The Company also had federal and state tax credit carry-forwards of $19.1 million and $16.8 million, respectively, as of June 30, 2014. These credit carryforwards consist of research and development tax credits as well as foreign tax credits with a small portion representing Alternative Minimum Tax Credits. The U.S. federal net operating loss carry-forwards of $290.2 million will begin to expire in the fiscal year ending June 30, 2021 and state net operating losses of $97.4 million will begin to expire in the fiscal year ending June 30, 2015, if not utilized. The foreign net operating losses can generally be carried forward indefinitely. Federal research and development tax credits of $19.1 million will expire beginning in the fiscal year ending June 30, 2018, if not utilized and North Carolina state research and development tax credits of $1.2 million will expire beginning in the fiscal year ending June 30, 2015, if not utilized. California state research and development tax credits of $15.6 million do not expire and can be carried forward indefinitely.

[0001078271-14-000053:notes:145]
As of June 30, 2014, the Company performed an Internal Revenue Code section 382 analysis with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2014, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes.

[0001078271-14-000053:notes:146]
As of June 30, 2014, the Company intends to indefinitely reinvest the earnings of approximately $78.2 million of certain foreign corporations. If such earnings were distributed, the Company would accrue an additional income tax expense of approximately $1.5 million.

[0001078271-14-000053:notes:147]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, Brazil, India, California, New Hampshire and North Carolina.  The Company is not currently under examination by any federal, state or foreign tax authority with respect to income taxes.  The Company recently settled an income tax examination of one of its subsidiaries with the Italian tax authorities.  The tax reserves were adjusted appropriately to reflect this settlement.

[0001078271-14-000053:notes:148]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.

[0001078271-14-000053:notes:149]
During the fiscal year ended June 30, 2014, the Company acquired the stock of Enterasys Networks, Inc. and as such they became a wholly owned subsidiary of Extreme Networks.  With respect to this acquisition, the Company made an election under Internal Revenue Code section 338(h)(10) to treat the acquisition as an asset purchase from a tax perspective.  Under this election the tax basis of all assets is effectively reset to that of fair market value and therefore the transaction did not result in the recording of an opening net deferred tax position as the Company's tax basis in the acquired assets equaled its book basis.

[0001078271-14-000053:notes:150]
As of June 30, 2014, the Company had $11.6 million of unrecognized tax benefits. If fully recognized in the future, $0.2 million would impact the effective tax rate, and $11.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. It is reasonably possible that the amount of unrealized tax benefit could decrease by approximately $0.2 million during the next twelve months due to the expiration of the statute of limitations in certain foreign jurisdictions.

[0001078271-14-000053:notes:151]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001078271-14-000053:notes:152]
| Balance at July 3, 2011 | $ | 26,010 |  |
| Increases related to prior year tax positions | (444 | ) |
| Increases related to current year tax positions | 729 |  |
| Lapse of statute of limitations | (549 | ) |
| Balance at June 30, 2012 | $ | 25,746 |  |
| Decrease related to prior year tax positions | (14,966 | ) |
| Increase related to prior year tax positions | 45 |  |
| Increase related to current year tax positions | 270 |  |
| Lapse of statute of limitations | (197 | ) |
| Balance at June 30, 2013 | $ | 10,898 |  |
| Decrease related to prior year tax positions | — |  |
| Increase related to prior year tax positions | 415 |  |
| Increase related to current year tax positions | 464 |  |
| Lapse of statute of limitations | (177 | ) |
| Balance at June 30, 2014 | $ | 11,600 |  |

[0001078271-14-000053:notes:153]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the Consolidated Statement of Operations and totaled approximately $14,000, $14,000, and $28,000 for the years ended June 30, 2014, June 30, 2013, and June 30, 2012, respectively. Accrued interest and penalties were approximately $22,000 and $40,000 as of June 30, 2014 and June 30, 2013, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001078271-14-000053:notes:154]
The Company values its inventory at lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company provides inventory allowances based on excess and obsolete inventories determined primarily by the age of inventory. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.


## us-gaap:InvestmentPolicyTextBlock

[0001078271-14-000053:notes:155]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with maturities of greater than three months, but less than one year at the balance sheet date are classified as Short Term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

[0001078271-14-000053:notes:156]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value. The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001078271-14-000053:notes:157]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. Realized gains or losses recognized on the sale of investments were not significant for fiscal 2014, 2013 or fiscal 2012. As of June 30, 2014, there were two out of 18 investment securities that had unrealized losses for less than 12 months.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-14-000053:notes:158]
Recently Issued Accounting Pronouncements

[0001078271-14-000053:notes:159]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013. The Company intends to adopt this standard prospectively in the first quarter of its fiscal year ending June 30, 2015. The Company does not believe this updated standard will have a material impact on its consolidated financial statements.

[0001078271-14-000053:notes:160]
In May 2014, the FASB, jointly with the International Accounting Standards Board, issued Accounting Standard Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers ("ASU 2014-09"). This ASU's core principle is that a reporting entity will recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In applying this new guidance to contracts within its scope, an entity will: (1) identify the contract(s) with a customer, (2) identify the performance obligation in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, this new guidance will require significantly expanded disclosures about revenue recognition. ASU 2014-09 is effective for annual reporting periods (including interim reporting periods within those annual periods) beginning after December 15, 2016. Early application is not permitted. Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this ASU. The Company is currently evaluating the potential effect on its consolidated financial position, results of operations and cash flows from adoption of this standard.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001078271-14-000053:notes:161]
Property and Equipment, Net

[0001078271-14-000053:notes:162]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and software. Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years).


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001078271-14-000053:notes:163]
Property and equipment consist of the following (in thousands):

[0001078271-14-000053:notes:164]
|  | June 30, 2014 |  | June 30, 2013 |
| Computer equipment | $ | 27,319 |  |  | $ | 29,400 |  |
| Purchased software | 10,859 |  |  | 3,699 |  |
| Office equipment, furniture and fixtures | 28,813 |  |  | 1,506 |  |
| Leasehold improvements | 29,029 |  |  | 11,344 |  |
|  | 96,020 |  |  | 45,949 |  |
| Less: accumulated depreciation and amortization | (49,466 | ) |  | (22,305 | ) |
| Property and equipment, net | $ | 46,554 |  |  | $ | 23,644 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-14-000053:notes:165]
Restructuring Charges

[0001078271-14-000053:notes:166]
As of June 30, 2014, restructuring liabilities were $0.3 million and consisted of obligations for termination benefits. During fiscal 2014, 2013 and 2012, the Company recorded a restructuring charge, net of $0.5 million, $6.8 million, and $1.6 million, respectively.  A portion of the 2012 restructuring activity is related to the liquidation of the Company's Japan subsidiary with a charge of $0.5 million during fiscal 2012. The Company substantially liquidated the subsidiary in Japan in the fourth quarter of fiscal 2012, as part of the Company's broad restructuring effort. The Company disposed the remaining immaterial assets and liabilities and completed the liquidation process during fiscal 2013.

[0001078271-14-000053:notes:167]
Fiscal 2013 Restructuring

[0001078271-14-000053:notes:168]
During the second quarter of fiscal 2013, the Company further reduced costs through targeted restructuring activities intended to reduce operating costs and realign its organization in the current competitive environment. As part of its restructuring efforts in the second quarter, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. As of June 30, 2014, the Company had restructuring liabilities of $0.3 million related to the fiscal 2013 restructuring, which it anticipates paying by the end of fiscal 2015.

[0001078271-14-000053:notes:169]
Fiscal 2012 Restructuring

[0001078271-14-000053:notes:170]
During fiscal 2012, the Company incurred total charges of $2.2 million, including $6.3 million of related severance, $0.1 million of contract termination fees, and $0.2 million other charges. The Company also made payments of $4.3 million. The associated restructuring costs were primarily termination benefits and contract termination costs. Termination benefits primarily consist of outplacement services, health insurance coverage, and legal costs. Contract termination costs primarily consist of costs to terminate operating leases and other contracts, including rent expense (less expected sublease income) on facilities under operating leases.  There are no outstanding liabilities as of June 30, 2014.

[0001078271-14-000053:notes:171]
Restructuring liabilities consist of (in thousands):

[0001078271-14-000053:notes:172]
|  | ContractTermination |  | TerminationBenefits |  | Other |  | Total |
| Balance at July 3, 2011 | $ | — |  |  | $ | 3,103 |  |  | $ | 80 |  |  | $ | 3,183 |  |
| Period charges | 124 |  |  | 1,832 |  |  | 206 |  |  | 2,162 |  |
| Period reversals | (18 | ) |  | (499 | ) |  | (51 | ) |  | (568 | ) |
| Period payments | (13 | ) |  | (4,077 | ) |  | (224 | ) |  | (4,314 | ) |
| Balance at June 30, 2012 | $ | 93 |  |  | $ | 359 |  |  | $ | 11 |  |  | $ | 463 |  |
| Period charges | 113 |  |  | 6,293 |  |  | 719 |  |  | 7,125 |  |
| Period reversals | (2 | ) |  | (287 | ) |  | — |  |  | (289 | ) |
| Period payments | (204 | ) |  | (5,148 | ) |  | (481 | ) |  | (5,833 | ) |
| Balance at June 30, 2013 | $ | — |  |  | $ | 1,217 |  |  | $ | 249 |  |  | $ | 1,466 |  |
| Period charges | 628 |  |  | 119 |  |  | 86 |  |  | 833 |  |
| Period reversals | (11 | ) |  | (309 | ) |  | (4 | ) |  | (324 | ) |
| Addition from acquisition | (20 | ) |  | — |  |  | — |  |  | (20 | ) |
| Period payments | (275 | ) |  | (1,027 | ) |  | (331 | ) |  | (1,633 | ) |
| Restructuring liabilities at June 30, 2014 | $ | 322 |  |  | $ | — |  |  | $ | — |  |  | $ | 322 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-14-000053:notes:173]
Revenue Recognition

[0001078271-14-000053:notes:174]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-14-000053:notes:175]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP. The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

[0001078271-14-000053:notes:176]
Pursuant to the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.

[0001078271-14-000053:notes:177]
The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance service contracts, professional services, and training for its products. The Company generally recognizes product revenue from its value-added resellers, non-stocking distributors and end-user customers at the time of shipment, provided that persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and collection of the sales proceeds is reasonably assured. In instances where the criteria for revenue recognition are not met, revenue is deferred until all criteria have been met.  The Company’s total deferred product revenue from customers other than distributors was $4.1 million and $3.1 million as of June 30, 2014 and June 30, 2013, respectively. The Company’s total deferred revenue for services, primarily from service contracts, was $97.7 million as of June 30, 2014 and $38.7 million as of June 30, 2013. Shipping costs are included in cost of product revenues. Sales taxes collected from customers are excluded from revenues.

[0001078271-14-000053:notes:178]
The Company sells its products and maintenance service contracts to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The Company defers recognition of revenue on all sales to its stocking distributors until the distributors sell the product, as evidenced by “sales-out” reports that the distributors provide. The Company grants these distributors the right to return a portion of unsold inventory for the purpose of stock rotation and certain price protection rights. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. The Company also provides distributors with credits for changes in selling prices based on competitive conditions, and allows distributors to participate in cooperative marketing programs. The Company maintains estimated accruals and allowances for these exposures based upon the Company's historical experience. In connection with cooperative advertising programs, the Company does not meet the criteria for recognizing the expenses as marketing expenses and accordingly, the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001078271-14-000053:notes:179]
The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users. For product sales to non-stocking distributors and value-added resellers, the Company does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Accordingly, the Company recognizes revenue upon transfer of title and risk of loss or damage, generally upon shipment. The Company reduces product revenue for cooperative marketing activities and certain price protection rights that may occur under contractual arrangements with its resellers.

[0001078271-14-000053:notes:180]
The Company provides an allowance for sales returns based on its historical returns, analysis of credit memo data and its return policies. The allowance for sales returns is as a reduction of our accounts receivable. If the historical data that the Company uses to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. The Company estimates and adjusts this allowance at each balance sheet date.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-14-000053:notes:181]
Cash Equivalents, Short-Term Investments and Marketable Securities

[0001078271-14-000053:notes:182]
Summary of Cash and Available-for-Sale Securities (in thousands)

[0001078271-14-000053:notes:183]
|  | June 30 |
|  | 2014 |  | 2013 |
| Cash | $ | 72,623 |  |  | $ | 41,518 |  |
| Cash equivalents | $ | 567 |  |  | $ | 54,285 |  |
| Short-term investments | 32,692 |  |  | 43,034 |  |
| Marketable securities | — |  |  | 66,776 |  |
| Total available-for-sale | $ | 33,259 |  |  | $ | 164,095 |  |
| Total cash and available for sale securities | $ | 105,882 |  |  | $ | 205,613 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-14-000053:notes:184]
The Company's debt is comprised of the following:

[0001078271-14-000053:notes:185]
|  |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |
| Term Loan |  | $ | 5,688 |  |
| Revolving Facility |  | 24,000 |  |
| Current portion of long-term debt |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |
| Term Loan |  | $ | 56,875 |  |
| Revolving Facility |  | 35,000 |  |
| Total long-term debt, less current portion |  | $ | 91,875 |  |
| Total debt |  | $ | 121,563 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001078271-14-000053:notes:186]
The Company did not hold any financial liabilities that required measurement at fair value on a recurring basis.  The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis:

[0001078271-14-000053:notes:187]
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | — |  |  | $ | — |  |  | $ | 567 |  |
| Corporate notes/bonds | — |  |  | 32,692 |  |  | — |  |  | 32,692 |  |
| Foreign currency forward contracts | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total | $ | 567 |  |  | $ | 32,713 |  |  | $ | — |  |  | $ | 33,280 |  |

[0001078271-14-000053:notes:188]
| June 30, 2013 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (In thousands) |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Municipal bonds | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Federal agency notes | — |  |  | — |  |  | — |  |  | — |  |
| Money market funds | 54,285 |  |  | — |  |  | — |  |  | 54,285 |  |
| Corporate notes/bonds | — |  |  | 109,810 |  |  | — |  |  | 109,810 |  |
| Foreign currency forward contracts | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total | $ | 54,285 |  |  | $ | 109,831 |  |  | $ | — |  |  | $ | 164,116 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001078271-14-000053:notes:189]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001078271-14-000053:notes:190]
|  |  | Total |
| Balance as of June 30, 2013 |  | $ | — |  |
| Addition due to acquisition of Enterasys (Note 2) |  | 70,877 |  |
| Balance as of June 30, 2014 |  | $ | 70,877 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001078271-14-000053:notes:191]
The following tables summarize the components of gross and net intangible asset balances (in thousands):

[0001078271-14-000053:notes:192]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| June 30, 2014 |  |  |  |  |  |  |  |
| Developed technology | 2.2 years |  | $ | 48,000 |  |  | $ | 11,028 |  |  | $ | 36,972 |  |
| Customer relationships | 2.3 years |  | 37,000 |  |  | 8,222 |  |  | 28,778 |  |
| Maintenance contracts | 4.3 years |  | 17,000 |  |  | 2,267 |  |  | 14,733 |  |
| Trademarks | 2.3 years |  | 2,500 |  |  | 555 |  |  | 1,945 |  |
| Order backlog | 1.3 years |  | 7,400 |  |  | 5,667 |  |  | 1,733 |  |
| License Agreements | 11.2 years |  | 10,447 |  |  | 8,141 |  |  | 2,306 |  |
| Other Intangibles | 4.8 years |  | 2,547 |  |  | 1,555 |  |  | 992 |  |
|  |  |  | $ | 124,894 |  |  | $ | 37,435 |  |  | $ | 87,459 |  |

[0001078271-14-000053:notes:193]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| June 30, 2013 |  |  |  |  |  |  |  |
| License Agreements | 10.3 years |  | $ | 10,447 |  |  | $ | 7,407 |  |  | $ | 3,040 |  |
| Other Intangibles | 5.8 years |  | 2,459 |  |  | 1,256 |  |  | 1,203 |  |
| Total assets with finite lives |  |  | $ | 12,906 |  |  | $ | 8,663 |  |  | $ | 4,243 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-14-000053:notes:194]
The following table summarizes the activity related to the Company’s product warranty liability during fiscal 2014 and fiscal 2013:

[0001078271-14-000053:notes:195]
|  | Year ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Balance beginning of period | $ | 3,296 |  |  | $ | 2,871 |  |
| Assumed from acquisition | 3,702 |  |  | — |  |
| New warranties issued | 6,225 |  |  | 4,299 |  |
| Warranty expenditures | (5,672 | ) |  | (3,874 | ) |
| Balance end of period | $ | 7,551 |  |  | $ | 3,296 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001078271-14-000053:notes:196]
The following table sets forth major customers accounting for 10% or more of our net revenue:

[0001078271-14-000053:notes:197]
|  |  | Fiscal Year Ended |
|  |  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Tech Data Corporation |  | 11 | % |  | 10 | % |  | * |  |
| Westcon Group Inc. |  | 11 | % |  | 16 | % |  | 19 | % |
| Scansource, Inc. |  | * |  |  | 12 | % |  | 13 | % |
| Ericsson AB |  | * |  |  | * |  |  | 12 | % |
| * Less than 10% of revenue |  |  |  |  |  |  |

[0001078271-14-000053:notes:198]
The following table sets forth major customers accounting for 10% or more of our accounts receivable balance.

[0001078271-14-000053:notes:199]
|  |  | June 30, 2014 |  | June 30, 2013 |
| Westcon Group Inc. |  | 19 | % |  | 25 | % |
| Tech Data Corporation |  | 13 | % |  | * |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-14-000053:notes:200]
The Company attributes revenues to geographic regions based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001078271-14-000053:notes:201]
|  | Year Ended |
| Net Revenues: | June 30, 2014 |  | June 30, 2013 |  | June 30, 2012 |
| Americas: |  |  |  |  |  |
| United States | $ | 211,734 |  |  | $ | 101,790 |  |  | $ | 106,110 |  |
| Other | 45,790 |  |  | 33,584 |  |  | 34,970 |  |
| Total Americas | 257,524 |  |  | 135,374 |  |  | 141,080 |  |
| EMEA | 202,555 |  |  | 112,812 |  |  | 128,093 |  |
| APAC | 59,475 |  |  | 51,157 |  |  | 53,549 |  |
| Total net revenues | $ | 519,554 |  |  | $ | 299,343 |  |  | $ | 322,722 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001078271-14-000053:notes:202]
| For the fiscal year ending: |  |
| 2015 | $ | 35,699 |  |
| 2016 | 32,281 |  |
| 2017 | 13,129 |  |
| 2018 | 3,682 |  |
| 2019 | 1,415 |  |
| Thereafter | 1,253 |  |
| Total | $ | 87,459 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-14-000053:notes:203]
Disclosure about Segments of an Enterprise and Geographic Areas

[0001078271-14-000053:notes:204]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision makers with respect to the allocation of resources and performance.

[0001078271-14-000053:notes:205]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia and Japan.

[0001078271-14-000053:notes:206]
Of the Company's total long-lived assets as of June 30, 2014, $104.4 million were attributable to Americas, $45.2 million were attributable to the EMEA region and the remaining to APAC. As of June 30, 2013, substantially all of the Company's long-lived assets were attributable to Americas.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-14-000053:notes:207]
Summary of Significant Accounting Policies

[0001078271-14-000053:notes:208]
Allowance for Doubtful Accounts

[0001078271-14-000053:notes:209]
The Company maintains an allowance for doubtful accounts which reflects its best estimate of potentially uncollectible trade receivables.  The allowance is based on both specific and general reserves.  The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001078271-14-000053:notes:210]
Concentrations

[0001078271-14-000053:notes:211]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting principally of marketable investments and accounts receivable. The Company has placed its investments with high-credit quality issuers. The Company does not invest an amount exceeding 10% of its combined cash, cash equivalents, short-term investments and marketable securities in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001078271-14-000053:notes:212]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001078271-14-000053:notes:213]
Inventory Valuation

[0001078271-14-000053:notes:214]
The Company's inventory balance was $57.1 million as of June 30, 2014, compared with $16.2 million as of June 30, 2013. The Company values its inventory at lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company provides inventory allowances based on excess and obsolete inventories determined primarily by the age of inventory. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed. Inventory write-downs charged to cost of product revenue were immaterial in fiscal 2014, $0.8 million in fiscal 2013 and $1.1 million in fiscal 2012.

[0001078271-14-000053:notes:215]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method. Realized gains or losses recognized on the sale of investments were not significant for fiscal 2014, 2013 or fiscal 2012. As of June 30, 2014, there were two out of 18 investment securities that had unrealized losses for less than 12 months. For investments that were in an unrealized loss position as of June 30, 2014, the Company recorded an other-than-temporary impairment loss of $158,000 during the year ended June 30, 2014.

[0001078271-14-000053:notes:216]
Fair Value of Financial Instruments

[0001078271-14-000053:notes:217]
Level 2 investment valuations are based on inputs such as quoted market prices of similar instruments, dealer quotations or valuations provided by alternative pricing sources supported by observable inputs. These generally include U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations. As of June 30, 2014 and June 30, 2013, the Company had no assets or liabilities classified within Level 3. There were no transfers of assets or liabilities between Level 1 and Level 2 during the fiscal 2014.

[0001078271-14-000053:notes:218]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.  There were no impairments recorded for the fiscal year 2014.

[0001078271-14-000053:notes:219]
The fair value of the borrowings under the credit facility is estimated based valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  The carrying amount and estimated fair value of the Company’s total long-term indebtedness, including current portion was $121.6 million and $121.3 million, respectively, as of June 30, 2014.  The Company did not have such debt as of June 30, 2013.

[0001078271-14-000053:notes:220]
(a) Property and Equipment, Net

[0001078271-14-000053:notes:221]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and software. Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years). Property and equipment consist of the following (in thousands):

[0001078271-14-000053:notes:222]
During the year ended June 30, 2014, there was an increase in property and equipment of $1.2 million for asset retirement obligations recorded from the acquisition of Enterasys.

[0001078271-14-000053:notes:223]
(b) Goodwill and Intangibles

[0001078271-14-000053:notes:224]
As part of the acquisition of Enterasys, the Company acquired $70.9 million in goodwill which has been allocated to the Company's only reportable segment, the development and marketing of network infrastructure equipment.

[0001078271-14-000053:notes:225]
Amortization expense was $28.8 million, $1.5 million, and $1.8 million in fiscal 2014, 2013, and 2012, respectively.  Of the total amount recognized, $11.9 million,  $1.5 million, and $1.8 million is included in "Cost of revenues for products" on the consolidated statements of operations in fiscal 2014, 2013, and 2012, respectively, while the remainder of the amortization expense is included in "Amortization of intangibles" on the consolidated statement of operations.  The amortization expense for developed technology, patents, license agreements and other intangibles is recognized in "Cost of revenues for products" on the consolidated statement of operations. The estimated future amortization expense to be recorded for each of the next five years is as follows (in thousands):

[0001078271-14-000053:notes:226]
(c) Other Assets

[0001078271-14-000053:notes:227]
Other assets primarily consists of service inventory and long term deposits. The Company holds service inventory to support customers who have purchased long term service contracts with a hardware replacement element. The Company held service inventory of $11.4 million and $6.3 million as of June 30, 2014 and June 30, 2013, respectively.

[0001078271-14-000053:notes:228]
Deferred Revenue, Net

[0001078271-14-000053:notes:229]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met.  The following table summarizes deferred revenue, net at June 30, 2014 and June 30, 2013, respectively (in thousands):

[0001078271-14-000053:notes:230]
The Company offers for sale to its customers, renewable support arrangements, including extended warranty contracts, to its customers that range generally from one to five years. Deferred support revenue is included within deferred revenue, net within the services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-14-000053:notes:231]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Balance beginning of period | $ | 38,003 |  |  | $ | 37,461 |  |
| Assumed from acquisition | 35,879 |  |  | — |  |
| New support arrangements | 113,412 |  |  | 57,342 |  |
| Recognition of support revenue | (97,637 | ) |  | (56,800 | ) |
| Balance end of period | 89,657 |  |  | 38,003 |  |
| Less: current portion | 66,715 |  |  | 29,733 |  |
| Non-current deferred revenue | $ | 22,942 |  |  | $ | 8,270 |  |

[0001078271-14-000053:notes:232]
Deferred Distributors Revenue, Net of Cost of Sales to Distributors

[0001078271-14-000053:notes:233]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay on a current basis for product delivered, the Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its consolidated balance sheets. Deferred distributors revenue, net of cost of sales to distributors effectively represents the gross margin on the sale to the distributor; however, the amount of gross margin the Company recognizes in future periods will frequently be less than the originally recorded deferred distributors revenue, net of cost of sales to distributors as a result of price concessions negotiated at time of sell-through to end customers. The Company sells each item in its product catalog to all of its distributors worldwide at contractually discounted prices. However, distributors resell the Company’s products to end customers at a very broad range of individually negotiated price points based on customer, product, quantity, geography, and other competitive conditions which results in the Company remitting back to the distributors a portion of their original purchase price after the resale transaction is completed. Thus, a portion of the deferred revenue balance represents a portion of distributors’ original purchase price that will be remitted back to the distributors in the future. The wide range and variability of negotiated price credits granted to distributors does not allow the Company to accurately estimate the portion of the balance in the deferred revenue that will be remitted to the distributors. Therefore, the Company does not reduce deferred revenue by anticipated future price credits; instead, price credits are recorded against revenue when incurred, which is generally at the time the distributor sells the product.

[0001078271-14-000053:notes:234]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors at the end of fiscal 2014 and 2013, respectively (in thousands):

[0001078271-14-000053:notes:235]
|  | Year Ended |
|  | June 30, 2014 |  | June 30, 2013 |
| Deferred distributors revenue | $ | 40,715 |  |  | $ | 22,411 |  |
| Deferred cost of sales to distributors | (8,723 | ) |  | (5,023 | ) |
| Total deferred distributors revenue, net of cost of sales to distributors | $ | 31,992 |  |  | $ | 17,388 |  |

[0001078271-14-000053:notes:236]
Debt

[0001078271-14-000053:notes:237]
On October 31, 2013, the Company entered into a Credit Agreement which provides for a $60 million five-year Revolving Facility and a $65 million five-year Term Loan and together with the Revolving Facility (the “Senior Secured Credit Facilities”).  The proceeds from the Term Loan were used to pay a portion of the purchase price in the acquisition of all of the issued and outstanding capital stock of Enterasys. The company also drew $35 million of the Revolving Facility to pay a portion of the purchase price and subsequently drew $48 million to fund working capital requirements.  The Company repaid $24 million of such draw during the year ended June 30, 2014 and the remaining draw of $24 million was repaid as of the filing date of this Form 10-K.

[0001078271-14-000053:notes:238]
Borrowings under the Senior Secured Credit Facilities bear interest, at the Company's election, at a rate per annum equal to an agreed to applicable margin plus (a) the higher of (x) the prime rate in effect on such day or (y) the federal funds effective rate in effect on such day plus 0.50%, or (b) an adjusted Libor rate. In addition, the Company is required to pay a commitment fee of between 0.375% and 0.50% quarterly (currently 0.50%) on the unused portion of the Revolving Facility, also based on the Company’s Consolidated Leverage Ratio.  Principal installments are payable on the Term Loan in varying percentages quarterly starting December 31, 2013 and to the extent not previously paid, all outstanding balance to be paid at maturity. If not repaid before maturity, the draws on the Revolving Facility shall be repaid on the maturity date. The Senior Secured Credit Facilities are secured by substantially all of the Company’s assets and are jointly and severally guaranteed by the Company and certain of its subsidiaries.

[0001078271-14-000053:notes:239]
The Credit Agreement contains financial covenants that require the Company to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other covenants and restrictions that limit the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets, etc.  These covenants, which are described more fully in the Credit Agreement, to which reference is made for a complete statement of the covenants, are subject to certain exceptions. The Company currently is in compliance with its covenants.

[0001078271-14-000053:notes:240]
The Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by the Company is false or misleading in any material respect, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company.  The amounts outstanding under the Senior Secured Credit Facilities may be accelerated upon certain events of default.

[0001078271-14-000053:notes:241]
Deferred financing costs are costs incurred in connection with obtaining long-term financing. The Company incurred $1.3 million deferred financing costs related to Senior Secured Credit Facilities during the year ended June 30, 2014.  Deferred financing costs are amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs, included in "Interest expense" in the Consolidated Statements of Operations, totaled $0.2 million in 2014.

[0001078271-14-000053:notes:242]
The Company had $0.9 million of outstanding letters of credit as of June 30, 2014.

[0001078271-14-000053:notes:243]
Guarantees and Product Warranties

[0001078271-14-000053:notes:244]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates.  The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001078271-14-000053:notes:245]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligation it assumes under the warranty. The following table summarizes the activity related to the Company’s product warranty liability during fiscal 2014 and fiscal 2013:

[0001078271-14-000053:notes:246]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001078271-14-000053:notes:247]
Other Accrued Liabilities

[0001078271-14-000053:notes:248]
The following are the components of other accrued liabilities (in thousands):

[0001078271-14-000053:notes:249]
|  | June 30, 2014 |  | June 30, 2013 |
| Accrued general and administrative costs | $ | 4,018 |  |  | $ | 2,959 |  |
| Other accrued liabilities | 34,017 |  |  | 13,543 |  |
| Total | $ | 38,035 |  |  | $ | 16,502 |  |

[0001078271-14-000053:notes:250]
Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. All other advertising costs are expensed as incurred. Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Otherwise, such cooperative advertising obligations with customers are recorded as a reduction of revenue. Advertising expenses were $0.5 million, $0.2 million, and $0.5 million, respectively, in fiscal 2014, fiscal 2013, and fiscal 2012.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001078271-14-000053:notes:251]
Stockholders’ Equity

[0001078271-14-000053:notes:252]
Preferred Stock

[0001078271-14-000053:notes:253]
In April 2001, in connection with the entering into of the Company's Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2014, no shares of preferred stock were outstanding.

[0001078271-14-000053:notes:254]
Stockholders’ Rights Agreement

[0001078271-14-000053:notes:255]
On November 27, 2012, the Company's Board of Directors adopted an Amended and Restated Rights Agreement (the “Restated Rights Plan”), between Extreme Networks and Computershare Inc. (Successor-in-interest to Computershare Shareholder Services LLC) as the rights agent (the “Rights Agent”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of Series A Preferred Stock of Extreme Networks. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as amended on June 30, 2010 and April 26, 2011 between Extreme Networks and Mellon Investor Services LLC (the “Prior Rights Plan”). The Board reviewed the necessity of the provision of the Prior Rights Plan adopted to preserve the value of Extreme Networks' deferred tax assets, including its net operating loss carry forwards, with respect to its ability to fully use its tax benefits to offset future income may be limited if it experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of Extreme Networks' common stock. Following its review, the Board decided it was necessary and in the best interests of Extreme Networks and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  The Company's stockholders voted to extend the term of the Restated Rights Plan from April 30, 2013 to April 30, 2014 at our 2012 Annual Meeting of Stockholders, and the Restated Rights Plan was amended effective April 30, 2013 to reflect the extension of the term.  The Board of Directors have unanimously approved an amendment to the Rights Plan effective April 30, 2014 to extend the Rights Plan through May 31, 2015, subject to ratification by a majority of the stockholders at the next annual meeting of the stockholders on November 12, 2014.

[0001078271-14-000053:notes:256]
Shares Reserved for Issuance

[0001078271-14-000053:notes:257]
The following are shares reserved for issuance (in thousands):

[0001078271-14-000053:notes:258]
|  | June 30, 2014 |
| Employee stock purchase plan | 1,205 |  |
| Employee stock options | 23,692 |  |
| Total shares reserved for issuance | 24,897 |  |


## us-gaap:TreasuryStockTextBlock

[0001078271-14-000053:notes:259]
Common Stock Repurchases and Retirement

[0001078271-14-000053:notes:260]
Retirement of Treasury Stock

[0001078271-14-000053:notes:261]
On September 5, 2012, the Company retired 39,631,836 shares of treasury stock. The retired shares had a carrying value of approximately $149.7 million, and the Company reduced additional paid-in capital by approximately $149.7 million upon the formal retirement of the shares. The retired shares are now included in the Company's authorized but unissued shares.

[0001078271-14-000053:notes:262]
Common Stock Repurchases

[0001078271-14-000053:notes:263]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which may be purchased over a three year period in the open market or in privately negotiated transactions. All repurchased shares will be retired and included in the Company's authorized but unissued shares. During the year ended June 30, 2013, the Company repurchased 4.1 million shares of common stock at a total cost of $14.5 million. No shares were repurchased during the year ended June 30, 2014.
