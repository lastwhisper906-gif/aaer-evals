# EXTR notes — 0001564590-17-008860


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-17-008860:notes:1]
[same as prior period, unchanged from 0001564590-17-000906:notes:1]

[0001564590-17-008860:notes:2]
[same as prior period, unchanged from 0001564590-17-000906:notes:2]

[0001564590-17-008860:notes:3]
[same as prior period, unchanged from 0001564590-17-000906:notes:3]

[0001564590-17-008860:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2017  The results of operations for the three and nine months ended March 31, 2017 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.

[0001564590-17-008860:notes:5]
[same as prior period, unchanged from 0001564590-17-000906:notes:5]

[0001564590-17-008860:notes:6]
[same as prior period, unchanged from 0001564590-17-000906:notes:6]

[0001564590-17-008860:notes:7]
[same as prior period, unchanged from 0001564590-17-000906:notes:7]

[0001564590-17-008860:notes:8]
[same as prior period, unchanged from 0001564590-17-000906:notes:8]

[0001564590-17-008860:notes:9]
[same as prior period, unchanged from 0001564590-17-000906:notes:9]

[0001564590-17-008860:notes:10]
[same as prior period, unchanged from 0001564590-17-000906:notes:10]

[0001564590-17-008860:notes:11]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes.  Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ from these estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-008860:notes:12]
[same as prior period, unchanged from 0001564590-17-000906:notes:12]

[0001564590-17-008860:notes:13]
[same as prior period, unchanged from 0001564590-17-000906:notes:13]

[0001564590-17-008860:notes:14]
[same as prior period, unchanged from 0001564590-17-000906:notes:14]

[0001564590-17-008860:notes:15]
The following table below summarizes the preliminary allocation as of March 31, 2017 of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-17-008860:notes:16]
|  |  | Preliminary Allocation as of December 31, 2016 |  |  | Change during three months ended March 31, 2017 |  |  |  | Preliminary Allocation as of March 31, 2017 |  |
| Receivables/net |  | $ | 17,818 |  |  | $ | (3,182 | ) | (a) |  | $ | 14,636 |  |
| Inventory |  |  | 12,408 |  |  |  | 635 |  | (b) |  |  | 13,043 |  |
| Other current assets |  |  | 808 |  |  |  | — |  |  |  |  | 808 |  |
| Property and equipment |  |  | 1,780 |  |  |  | 1,379 |  | (c) |  |  | 3,159 |  |
| Identifiable intangible assets |  |  | 20,500 |  |  |  | 100 |  | (d) |  |  | 20,600 |  |
| In-process research and development |  |  | 1,600 |  |  |  | — |  |  |  |  | 1,600 |  |
| Other assets |  |  | 7,634 |  |  |  | — |  |  |  |  | 7,634 |  |
| Goodwill |  |  | 9,836 |  |  |  | 1,967 |  |  |  |  | 11,803 |  |
| Current liabilities |  |  | (7,763 | ) |  |  | (273 | ) | (f) |  |  | (8,036 | ) |
| Deferred revenue |  |  | (13,533 | ) |  |  | (626 | ) | (g) |  |  | (14,159 | ) |
| Total purchase price allocation |  | $ | 51,088 |  |  | $ | - |  |  |  | $ | 51,088 |  |

[0001564590-17-008860:notes:17]
The estimated purchase price has been allocated based on the preliminary estimates of the fair value of assets acquired and liabilities assumed as of the acquisition date.  The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach.   The fair value of property and equipment was determined using a cost approach. Valuations of the intangible assets were valued using income approaches based on projections provided by management, which we consider to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition.

[0001564590-17-008860:notes:18]
The changes during the period in the table above is as follows: a) information on accounts receivable and related reserves of matters that existed as of the acquisition date; b) additional receipts of products; c) additional fixed assets acquired in India; d) revised net realizable value based on usefulness of asset; e) additional employee benefits assumed; f) additional maintenance contracts.

[0001564590-17-008860:notes:19]
[same as prior period, unchanged from 0001564590-17-000906:notes:18]

[0001564590-17-008860:notes:20]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |  |
| Developed technology |  | 6 |  | $ | 14,600 |  |
| Customer relationships |  | 4 |  |  | 3,400 |  |
| Trademarks |  | 5 |  |  | 2,600 |  |
| Total identifiable intangible assets |  |  |  | $ | 20,600 |  |

[0001564590-17-008860:notes:21]
[same as prior period, unchanged from 0001564590-17-000906:notes:20]

[0001564590-17-008860:notes:22]
The Company also has an indefinite lived asset of $1.6 million which represents the fair value of in-process research and development activities.  Once the related research and development efforts are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or become a finite lived asset and apply the appropriate accounting accordingly.

[0001564590-17-008860:notes:23]
The results of operations of the WLAN Business are included in the consolidated results of operations beginning October 28, 2016.  The Company incurred $7.6 million acquisition-related expenses of which $1.1 million was incurred in the three months ended March 31, 2017.  Such acquisition-related costs are included in "Acquisition and integration costs" on the condensed consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants and companies.

[0001564590-17-008860:notes:24]
[same as prior period, unchanged from 0001564590-17-000906:notes:23]

[0001564590-17-008860:notes:25]
The following unaudited pro forma results of operations are presented as though the acquisition of the WLAN Business had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-17-008860:notes:26]
[same as prior period, unchanged from 0001564590-17-000906:notes:25]

[0001564590-17-008860:notes:27]
The unaudited pro forma financial information for the three months ended March 31, 2017, are the results for Extreme for the three months ended March 31, 2017.

[0001564590-17-008860:notes:28]
The unaudited pro forma financial information for the three months ended March 31, 2016, combines the historical results for Extreme for that period, with the historical results of the WLAN Business for the same period.

[0001564590-17-008860:notes:29]
The unaudited pro forma financial information for the nine months ended March 31, 2017 combines the results for Extreme for the nine months ended March 31, 2017, which include the results of the WLAN Business subsequent to the acquisition date, and the historical results of the WLAN Business for the three months ended September 30, 2016 and the month ended October 28, 2016.

[0001564590-17-008860:notes:30]
The unaudited pro forma financial information for the nine months ended March 31, 2016, combines the historical results for Extreme for those periods, with the historical results of the WLAN Business for the nine months ended March 31, 2016.

[0001564590-17-008860:notes:31]
[same as prior period, unchanged from 0001564590-17-000906:notes:29]

[0001564590-17-008860:notes:32]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Net revenues |  | $ | 148,664 |  |  | $ | 157,798 |  |  | $ | 462,689 |  |  | $ | 488,462 |  |
| Net income (loss) |  | $ | (2,774 | ) |  | $ | (17,833 | ) |  | $ | (7,560 | ) |  | $ | (59,341 | ) |
| Net earnings (loss) per share - basic |  | $ | (0.03 | ) |  | $ | (0.17 | ) |  | $ | (0.07 | ) |  | $ | (0.58 | ) |
| Net earnings (loss) per share - diluted |  | $ | (0.03 | ) |  | $ | (0.17 | ) |  | $ | (0.07 | ) |  | $ | (0.58 | ) |
| Shares used in per share calculation - basic |  |  | 109,213 |  |  |  | 104,104 |  |  |  | 107,531 |  |  |  | 102,486 |  |
| Shares used in per share calculation - diluted |  |  | 109,213 |  |  |  | 104,104 |  |  |  | 107,531 |  |  |  | 102,486 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-17-008860:notes:33]
[same as prior period, unchanged from 0001564590-17-000906:notes:31]

[0001564590-17-008860:notes:34]
[same as prior period, unchanged from 0001564590-17-000906:notes:32]

[0001564590-17-008860:notes:35]
[same as prior period, unchanged from 0001564590-17-000906:notes:33]

[0001564590-17-008860:notes:36]
[same as prior period, unchanged from 0001564590-17-000906:notes:34]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-17-008860:notes:37]
| 4. | Recent Accounting Pronouncements |

[0001564590-17-008860:notes:38]
Recently Adopted Accounting Pronouncements

[0001564590-17-008860:notes:39]
In March 2016, the FASB issued Accounting Standards Update (“ASU”) 2016-09, Compensation – Stock Compensation (“ASU 2016-09”) which identifies areas for simplification involving several aspects of accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, an option to recognize gross stock compensation expense with actual forfeitures recognized as they occur, as well as certain classifications on the statement of cash flows.  The Company early adopted this standard beginning with its fiscal year 2017. The impact of the adoption had the following impacts:

[0001564590-17-008860:notes:40]
|  | • | In recording share-based compensation expense, the standard allows companies to make a policy election as to whether they will include an estimate of awards expected to be forfeited or whether they will account for forfeitures as they occur. The Company has elected to not include an estimated forfeiture rate in the computation of its share-based compensation expense. This election did not have a material impact on the Company’s condensed consolidated financial statements and accordingly no adjustment was made to beginning accumulated deficit to apply the modified retrospective method. |

[0001564590-17-008860:notes:41]
|  | • | The standard requires that employee taxes paid when an employer withholds shares for tax-withholding purposes be reported as financing activities in the consolidated statements of cash flows. Previously, the Company included these cash flows in financing activities and therefore the adoption of this provision had no impact. |

[0001564590-17-008860:notes:42]
|  | • | The new standard requires that the tax effects of share-based compensation be recognized in the income tax provision. Previously, these amounts were recognized in additional paid-in capital. Given the full valuation allowance against the US deferred tax assets, there will be no impact to the effective tax rate until such time as the valuation allowance may be reversed. |

[0001564590-17-008860:notes:43]
|  | • | The standard also requires previously unrecognized excess tax benefits to be recognized on a modified retrospective basis. Unrecognized tax benefits result when a deduction for stock based compensation does not actually reduce taxes payable. The Company has recorded $13.5 million and $0.9 million of previously unrecorded deferred tax assets for federal and state net operating losses, respectively, with a corresponding increase to the valuation allowance pursuant to the evidence discussed in Note 9. The cumulative net impact to accumulated deficit of early adoption of this provision was therefore zero. |

[0001564590-17-008860:notes:44]
|  | • | ASU 2016-09 also requires excess tax benefits to be presented as an operating activity on the statement of cash flows rather than as a financing activity on either a retrospective or prospective basis. The Company has elected to apply this provision of the standard on a prospective basis. |

[0001564590-17-008860:notes:45]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs (“ASU 2015-03”),  which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts.  ASU 2015-03 requires retrospective adoption and will be effective for annual and interim periods in fiscal years beginning after December 15, 2015.  This guidance became effective for the Company beginning with its fiscal year 2017.

[0001564590-17-008860:notes:46]
In connection with the Company’s adoption of ASU 2015-03 in fiscal 2017, all debt issuance costs have been presented, with the exception of those related to the revolving credit facility, as a reduction of the carrying amount of the related debt liability.  The previously reported balances in the Company’s June 30, 2016 Form 10-K for debt issuance costs listed in “Other assets” have been reclassified to “Current portion of long-term debt” in the amount of $0.2 million and “Long-term debt, less current portion” in the amount of $0.2 million to conform to the December 31, 2016 presentation.

[0001564590-17-008860:notes:47]
Recently Issued Accounting Pronouncements

[0001564590-17-008860:notes:48]
In May 2014, the FASB issued ASU 2014-09, Revenue Recognition - Revenue from Contracts with Customers (Topic 606), which will replace substantially all current revenue recognition guidance once it becomes effective. The new standard provides accounting guidance for all revenue arising from contracts with customers and affects all entities that enter into contracts to provide goods or services to their customers unless the contracts are in the scope of other standards. The new standard is less prescriptive and may require software entities to use more judgment and estimates in the revenue recognition process than are required under existing revenue guidance. Since ASU 2014-09 was issued, several additional ASUs have been issued and incorporated within ASC 606 to clarify various elements of the guidance.  In August 2015, the FASB issued ASU 2015-14 which amended the effective date of this ASU to fiscal years beginning after December 15, 2017, and early adoption is permitted only for fiscal years beginning after December 15, 2016.

[0001564590-17-008860:notes:49]
The new revenue standard may be applied using either of the following transition methods: (1) a full retrospective approach reflecting the application of the standard in each prior reporting period with the option to elect certain practical expedients, or (2) a modified retrospective approach with the cumulative effect of initially adopting the standard recognized at the date of adoption (which includes additional footnote disclosures).   The Company plans to adopt the standard in the first quarter of fiscal 2018 and preliminarily expects to use the full retrospective method.  However, the Company is continuing to evaluate the impact of the standard, and our adoption method is subject to change.  The Company expects that the adoption of this guidance will have a material impact on its financial statements, specifically related to the timing of revenue recognition for sales through our distributors.  The Company is continuing to assess all other potential impacts of the standard, including the pattern with which the Company recognizes revenue.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-17-008860:notes:50]
[same as prior period, unchanged from 0001564590-17-000906:notes:45]

[0001564590-17-008860:notes:51]
[same as prior period, unchanged from 0001564590-17-000906:notes:46]

[0001564590-17-008860:notes:52]
[same as prior period, unchanged from 0001564590-17-000906:notes:47]

[0001564590-17-008860:notes:53]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Cash |  | $ | 112,996 |  |  | $ | 89,847 |  |
| Cash equivalents |  |  | 4,284 |  |  |  | 4,275 |  |
| Total cash and cash equivalents |  | $ | 117,280 |  |  | $ | 94,122 |  |

[0001564590-17-008860:notes:54]
[same as prior period, unchanged from 0001564590-17-000906:notes:49]

[0001564590-17-008860:notes:55]
Inventory

[0001564590-17-008860:notes:56]
The Company values its inventory at lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-17-008860:notes:57]
[same as prior period, unchanged from 0001564590-17-000906:notes:52]

[0001564590-17-008860:notes:58]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Finished goods |  | $ | 46,658 |  |  | $ | 38,751 |  |
| Raw materials |  |  | 1,031 |  |  |  | 2,238 |  |
| Total Inventory |  | $ | 47,689 |  |  | $ | 40,989 |  |

[0001564590-17-008860:notes:59]
[same as prior period, unchanged from 0001564590-17-000906:notes:54]

[0001564590-17-008860:notes:60]
[same as prior period, unchanged from 0001564590-17-000906:notes:55]

[0001564590-17-008860:notes:61]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Computer equipment |  | $ | 36,372 |  |  | $ | 34,657 |  |
| Purchased software |  |  | 11,099 |  |  |  | 5,574 |  |
| Office equipment, furniture and fixtures |  |  | 11,099 |  |  |  | 10,385 |  |
| Leasehold improvements |  |  | 22,505 |  |  |  | 19,342 |  |
| Total property and equipment |  |  | 81,075 |  |  |  | 69,958 |  |
| Less: accumulated depreciation and amortization |  |  | (50,666 | ) |  |  | (40,378 | ) |
| Property and equipment, net |  | $ | 30,409 |  |  | $ | 29,580 |  |

[0001564590-17-008860:notes:62]
[same as prior period, unchanged from 0001564590-17-000906:notes:57]

[0001564590-17-008860:notes:63]
[same as prior period, unchanged from 0001564590-17-000906:notes:58]

[0001564590-17-008860:notes:64]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 5.52 years |  | $ | 55,600 |  |  | $ | 42,056 |  |  | $ | 13,544 |  |
| Customer relationships |  | 3.59 years |  |  | 40,400 |  |  |  | 37,354 |  |  |  | 3,046 |  |
| Maintenance contracts |  | 1.59 years |  |  | 17,000 |  |  |  | 11,617 |  |  |  | 5,383 |  |
| Trademarks |  | 4.59 years |  |  | 5,100 |  |  |  | 2,717 |  |  |  | 2,383 |  |
| License agreements |  | 6.60 years |  |  | 2,445 |  |  |  | 1,052 |  |  |  | 1,393 |  |
| Other intangibles |  | 2.90 years |  |  | 1,382 |  |  |  | 965 |  |  |  | 417 |  |
| Total intangibles, net with finite lives |  |  |  |  | 121,927 |  |  |  | 95,761 |  |  |  | 26,166 |  |
| In-process research and development, with indefinite life |  |  |  |  | 1,600 |  |  |  | - |  |  |  | 1,600 |  |
| Total intangibles, net |  |  |  | $ | 123,527 |  |  | $ | 95,761 |  |  | $ | 27,766 |  |

[0001564590-17-008860:notes:65]
[same as prior period, unchanged from 0001564590-17-000906:notes:60]

[0001564590-17-008860:notes:66]
[same as prior period, unchanged from 0001564590-17-000906:notes:61]

[0001564590-17-008860:notes:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Amortization in "Cost of revenues: Product" |  | $ | 995 |  |  | $ | 3,417 |  |  | $ | 6,271 |  |  | $ | 11,847 |  |
| Amortization of intangibles |  |  | 1,193 |  |  |  | 4,142 |  |  |  | 7,510 |  |  |  | 12,860 |  |
| Total amortization |  | $ | 2,188 |  |  | $ | 7,559 |  |  | $ | 13,781 |  |  | $ | 24,707 |  |

[0001564590-17-008860:notes:68]
[same as prior period, unchanged from 0001564590-17-000906:notes:63]

[0001564590-17-008860:notes:69]
[same as prior period, unchanged from 0001564590-17-000906:notes:64]

[0001564590-17-008860:notes:70]
[same as prior period, unchanged from 0001564590-17-000906:notes:65]

[0001564590-17-008860:notes:71]
|  |  | March 31, 2017 |  |
| Balance as of June 30, 2016 |  | $ | 70,877 |  |
| Additions due to acquisition |  |  | 11,803 |  |
| Balance at end of period |  | $ | 82,680 |  |

[0001564590-17-008860:notes:72]
During the nine months ended March 31, 2017, the Company completed the acquisition of certain assets and liabilities from Zebra resulting in an additional $11.8 million of goodwill.  See Note 2 for additional information related to the acquisition.

[0001564590-17-008860:notes:73]
[same as prior period, unchanged from 0001564590-17-000906:notes:68]

[0001564590-17-008860:notes:74]
[same as prior period, unchanged from 0001564590-17-000906:notes:69]

[0001564590-17-008860:notes:75]
[same as prior period, unchanged from 0001564590-17-000906:notes:70]

[0001564590-17-008860:notes:76]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Deferred maintenance |  | $ | 95,683 |  |  | $ | 83,419 |  |
| Deferred product and other revenue |  |  | 7,091 |  |  |  | 11,441 |  |
| Total deferred revenue, net |  |  | 102,774 |  |  |  | 94,860 |  |
| Less: current portion |  |  | 78,918 |  |  |  | 72,934 |  |
| Non-current deferred revenue, net |  | $ | 23,856 |  |  | $ | 21,926 |  |

[0001564590-17-008860:notes:77]
[same as prior period, unchanged from 0001564590-17-000906:notes:72]

[0001564590-17-008860:notes:78]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Balance beginning of period |  | $ | 98,128 |  |  | $ | 84,706 |  |  | $ | 83,419 |  |  | $ | 87,441 |  |
| Deferred maintenance assumed due to acquisition |  |  | 626 |  |  |  | — |  |  |  | 14,159 |  |  |  | — |  |
| New maintenance arrangements |  |  | 28,181 |  |  |  | 27,683 |  |  |  | 90,690 |  |  |  | 84,502 |  |
| Recognition of maintenance revenue |  |  | (31,252 | ) |  |  | (27,320 | ) |  |  | (92,585 | ) |  |  | (86,874 | ) |
| Balance end of period |  |  | 95,683 |  |  |  | 85,069 |  |  |  | 95,683 |  |  |  | 85,069 |  |
| Less: current portion |  |  | 71,827 |  |  |  | 62,842 |  |  |  | 71,827 |  |  |  | 62,842 |  |
| Non-current deferred revenue |  | $ | 23,856 |  |  | $ | 22,227 |  |  | $ | 23,856 |  |  | $ | 22,227 |  |

[0001564590-17-008860:notes:79]
[same as prior period, unchanged from 0001564590-17-000906:notes:74]

[0001564590-17-008860:notes:80]
[same as prior period, unchanged from 0001564590-17-000906:notes:75]

[0001564590-17-008860:notes:81]
[same as prior period, unchanged from 0001564590-17-000906:notes:76]

[0001564590-17-008860:notes:82]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Deferred distributors revenue |  | $ | 57,188 |  |  | $ | 35,138 |  |
| Deferred cost of sales to distributors |  |  | (12,930 | ) |  |  | (8,321 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | $ | 44,258 |  |  | $ | 26,817 |  |

[0001564590-17-008860:notes:83]
[same as prior period, unchanged from 0001564590-17-000906:notes:78]

[0001564590-17-008860:notes:84]
[same as prior period, unchanged from 0001564590-17-000906:notes:79]

[0001564590-17-008860:notes:85]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 11,149 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 11,149 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 73,775 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 83,775 |  |  |  | 37,446 |  |
| Total debt |  | $ | 94,924 |  |  | $ | 55,074 |  |

[0001564590-17-008860:notes:86]
During the three months ended December 31, 2016, the Company entered into an Amended and Restated Credit Agreement which agreement was subsequently amended on March 2, 2017, by Amendment One to such agreement (collectively the agreement and Amendment One, the “Credit Facility, as amended”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Facility, as amended provides for a five-year $90.5 million term loan (“Term Loan”) and a five-year $50.0 million revolving credit facility (“Revolver”), which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Facility, as amended among other things, amends and restates the Company’s existing credit facility.  The Credit Facility, as amended is collateralized by substantially all of the assets of the Company.

[0001564590-17-008860:notes:87]
Borrowings under the Term Loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on the Company’s consolidated leverage ratio).  Borrowings under the Revolver bear interest, at the Company’s option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The Revolver has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.

[0001564590-17-008860:notes:88]
The Company had $23.2 million of availability under the Revolver as of March 31, 2017.  The Company had $0.9 million of outstanding letters of credit under the Revolver as of March 31, 2017.

[0001564590-17-008860:notes:89]
[same as prior period, unchanged from 0001564590-17-000906:notes:84]

[0001564590-17-008860:notes:90]
[same as prior period, unchanged from 0001564590-17-000906:notes:85]

[0001564590-17-008860:notes:91]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2017 and 2016 (in thousands):

[0001564590-17-008860:notes:92]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Balance beginning of period |  | $ | 10,228 |  |  | $ | 10,415 |  |  | $ | 9,600 |  |  | $ | 8,676 |  |
| Warranties assumed due to acquisition |  |  | — |  |  |  | — |  |  |  | 2,034 |  |  |  | — |  |
| New warranties issued |  |  | 1,893 |  |  |  | 1,638 |  |  |  | 3,997 |  |  |  | 7,158 |  |
| Warranty expenditures |  |  | (2,091 | ) |  |  | (1,773 | ) |  |  | (5,601 | ) |  |  | (5,554 | ) |
| Balance end of period |  | $ | 10,030 |  |  | $ | 10,280 |  |  | $ | 10,030 |  |  | $ | 10,280 |  |

[0001564590-17-008860:notes:93]
[same as prior period, unchanged from 0001564590-17-000906:notes:88]

[0001564590-17-008860:notes:94]
[same as prior period, unchanged from 0001564590-17-000906:notes:89]

[0001564590-17-008860:notes:95]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue. All other advertising costs are expensed as incurred.  Advertising expenses for three and nine months ended March 31, 2017 and 2016, were immaterial.

[0001564590-17-008860:notes:96]
[same as prior period, unchanged from 0001564590-17-000906:notes:91]

[0001564590-17-008860:notes:97]
[same as prior period, unchanged from 0001564590-17-000906:notes:92]

[0001564590-17-008860:notes:98]
[same as prior period, unchanged from 0001564590-17-000906:notes:93]

[0001564590-17-008860:notes:99]
[same as prior period, unchanged from 0001564590-17-000906:notes:94]

[0001564590-17-008860:notes:100]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Tech Data Corporation |  |  | 13% |  |  |  | 16% |  |  |  | 15% |  |  |  | 16% |  |
| Jenne |  |  | 14% |  |  |  | 17% |  |  |  | 14% |  |  | 13% |  |
| Westcon Group Inc. |  |  | 10% |  |  |  | 13% |  |  |  | 12% |  |  |  | 15% |  |

[0001564590-17-008860:notes:101]
The following customer accounts for more than 10% of our accounts receivable outstanding as of March 31, 2017, Westcon Group Inc. 18%.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-17-008860:notes:102]
[same as prior period, unchanged from 0001564590-17-000906:notes:98]

[0001564590-17-008860:notes:103]
[same as prior period, unchanged from 0001564590-17-000906:notes:99]

[0001564590-17-008860:notes:104]
[same as prior period, unchanged from 0001564590-17-000906:notes:100]

[0001564590-17-008860:notes:105]
[same as prior period, unchanged from 0001564590-17-000906:notes:101]

[0001564590-17-008860:notes:106]
[same as prior period, unchanged from 0001564590-17-000906:notes:102]

[0001564590-17-008860:notes:107]
[same as prior period, unchanged from 0001564590-17-000906:notes:103]

[0001564590-17-008860:notes:108]
| March 31, 2017 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,284 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,284 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  | $ | — |  |  | $ | 80 |  |  | $ | — |  |  | $ | 80 |  |
| Total |  | $ | 4,284 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 4,364 |  |

[0001564590-17-008860:notes:109]
[same as prior period, unchanged from 0001564590-17-000906:notes:105]

[0001564590-17-008860:notes:110]
Level 2 investments:

[0001564590-17-008860:notes:111]
[same as prior period, unchanged from 0001564590-17-000906:notes:107]

[0001564590-17-008860:notes:112]
The fair value of the derivative instruments under our foreign currency contracts is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the derivative instruments, the fair value approximates the carrying amount of the Company’s contracts of $96.0 million

[0001564590-17-008860:notes:113]
The fair value of the borrowings under the Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the face amount of the Company’s indebtedness of $96.0 million and $55.5 million as of March 31, 2017 and June 30, 2016, respectively.

[0001564590-17-008860:notes:114]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. There were no impairments recorded for the three and nine months ended March 31, 2017 or 2016.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-008860:notes:115]
[same as prior period, unchanged from 0001564590-17-000906:notes:111]

[0001564590-17-008860:notes:116]
[same as prior period, unchanged from 0001564590-17-000906:notes:112]

[0001564590-17-008860:notes:117]
[same as prior period, unchanged from 0001564590-17-000906:notes:113]

[0001564590-17-008860:notes:118]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,785 |  |  |  | 10,001 |  |
| Employee stock options and awards outstanding |  |  | 9,352 |  |  |  | 10,609 |  |
| 2013 Employee Plan shares available for grant |  |  | 10,241 |  |  |  | 5,401 |  |
| Total shares reserved for issuance |  |  | 27,378 |  |  |  | 26,011 |  |

[0001564590-17-008860:notes:119]
[same as prior period, unchanged from 0001564590-17-000906:notes:115]

[0001564590-17-008860:notes:120]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Cost of product revenue |  | $ | 73 |  |  | $ | 205 |  |  | $ | 262 |  |  | $ | 777 |  |
| Cost of service revenue |  |  | 56 |  |  |  | 223 |  |  |  | 475 |  |  |  | 867 |  |
| Research and development |  |  | 625 |  |  |  | 1,137 |  |  |  | 2,593 |  |  |  | 3,857 |  |
| Sales and marketing |  |  | 809 |  |  |  | 996 |  |  |  | 3,129 |  |  |  | 3,791 |  |
| General and administrative |  |  | 911 |  |  |  | 942 |  |  |  | 2,869 |  |  |  | 2,828 |  |
| Total share-based compensation expense |  | $ | 2,474 |  |  | $ | 3,503 |  |  | $ | 9,328 |  |  | $ | 12,120 |  |

[0001564590-17-008860:notes:121]
During the three and nine months ended March 31, 2017 and 2016, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-17-008860:notes:122]
[same as prior period, unchanged from 0001564590-17-000906:notes:118]

[0001564590-17-008860:notes:123]
[same as prior period, unchanged from 0001564590-17-000906:notes:119]

[0001564590-17-008860:notes:124]
The following table summarizes stock award activity for the nine months ended March 31, 2017  (in thousands, except grant date fair value):

[0001564590-17-008860:notes:125]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2016 |  |  | 4,224 |  |  | $ | 3.36 |  |  |  |  |  |
| Granted |  |  | 3,527 |  |  |  | 4.09 |  |  |  |  |  |
| Vested |  |  | (1,476 | ) |  |  | 3.94 |  |  |  |  |  |
| Cancelled |  |  | (797 | ) |  |  | 3.43 |  |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2017 |  |  | 5,478 |  |  | $ | 3.66 |  |  | $ | 41,094 |  |

[0001564590-17-008860:notes:126]
The following table summarizes stock option activity for the nine months ended March 31, 2017 (in thousands, except per share and contractual term):

[0001564590-17-008860:notes:127]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2016 |  |  | 6,385 |  |  | $ | 4.10 |  |  |  | 3.70 |  |  | $ | 1,416 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (1,467 | ) |  |  | 3.75 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (1,044 | ) |  |  | 4.51 |  |  |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2017 |  |  | 3,874 |  |  | $ | 4.12 |  |  |  | 4.11 |  |  | $ | 13,143 |  |
| Vested and expected to vest at March 31, 2017 |  |  | 3,874 |  |  | $ | 4.12 |  |  |  | 4.11 |  |  | $ | 13,143 |  |
| Exercisable at March 31, 2017 |  |  | 2,919 |  |  | $ | 4.48 |  |  |  | 3.27 |  |  | $ | 8,841 |  |

[0001564590-17-008860:notes:128]
The fair value of each stock option grant under the Company's 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-17-008860:notes:129]
[same as prior period, unchanged from 0001564590-17-000906:notes:126]

[0001564590-17-008860:notes:130]
During the first quarter of fiscal 2017, the Company approved the grant of 680,000 stock awards to the Company’s Executive Officers and 771,020 stock awards to other Company employees.  Fifty percent (50%) of the stock awards granted were in the form of PSUs, with grant date fair values ranging from $3.02 to $3.09, and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs.   The RSUs vest from the original grant date as to one-third (1/3) on the one year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-17-008860:notes:131]
The PSUs are considered earned once the Company's stock price equals or exceeds $5.00 per share for 30 consecutive trading days after January 1, 2017 ("Performance Threshold").  Once the Performance Threshold is satisfied the PSUs shall vest with respect to the number of RSUs that have vested as of the date the Performance Threshold is satisfied and thereafter shall vest on the same schedule as the RSUs, subject to continued service to the Company.  If the Performance Threshold is not met by the third anniversary of the grant date the award is terminated for no consideration.  In addition, the Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $5.00 per share.

[0001564590-17-008860:notes:132]
During the quarter ended March 31, 2017, all of the PSU grants referenced above achieved their Performance Threshold and as such, began vesting and will be released on the schedule as noted, subject to continued service to the Company.

[0001564590-17-008860:notes:133]
During the quarter ended March 31, 2017, a grant of 100,000 RSUs was made to one of the Company’s Executive Officers.  The award was granted under the Company’s standard terms and conditions.

[0001564590-17-008860:notes:134]
The fair value of each share purchase option under the Company's ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of the ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-17-008860:notes:135]
There were 1,114,707; 2,218,306; 999,758 and 1,999,519 shares issued under the Company’s 2014 Employee Stock Purchase Plan (“ESPP”) during the three and nine months ended March 31, 2017 and 2016, respectively.

[0001564590-17-008860:notes:136]
|  |  | Employee Stock Purchase Plan |  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Expected life |  | 0.50 years |  |  | 1.45 years |  |  | 4.0 years |  |  | 0.50 years |  |  | 1.25 |  |
| Risk-free interest rate |  |  | 0.40 | % |  |  | 0.52 | % |  |  | 1.78 | % |  |  | 0.40 | % |  |  | 0.44 | % |
| Volatility |  |  | 37 | % |  |  | 57 | % |  |  | 52 | % |  |  | 38 | % |  |  | 57 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-008860:notes:137]
[same as prior period, unchanged from 0001564590-17-000906:notes:131]

[0001564590-17-008860:notes:138]
As of March 31, 2017, restructuring liabilities were $6.3 million and consisted of obligations for estimated future obligations for non-cancelable lease payments for excess facilities and for severance payments and benefits.  Pursuant with the WLAN Business acquisition from Zebra, the Company assumed a facility lease located at and transferred its headquarters to 6480 Via del Oro, San Jose, California.  The Company consolidated its existing workforce from the Company’s previous headquarters location on Rio Robles Drive in San Jose, California, with employees assumed from Zebra at the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to the Company’s cease use of the Rio Robles facility and abandonment of all leasehold improvements, it accelerated the amortization of the remaining leasehold improvements balance for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  The Company recorded accelerated amortization expense for the three and nine months ended March 31, 2017 of $0.9 million and $2.6 million respectively, and it is reflected in "Restructuring and related charges, net of reversals" in the condensed consolidated statements of operations.

[0001564590-17-008860:notes:139]
The Company entered into a sublease agreement during the third quarter of fiscal 2017.  The sublease is for the remaining duration of the Company’s lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease. The net adjustments resulted in a charge of $1.5 million during the third quarter of fiscal 2017.  Previously, in the second quarter of fiscal 2017, the Company had modified its estimated future obligations for non-cancelable lease payments and related future sub-leasing income and recorded charges of $0.1 million.  The excess facilities payments will continue through fiscal year 2023, due to the length of the lease agreements.

[0001564590-17-008860:notes:140]
In conjunction with the above noted actions, the Company announced a reduction-in-force during the quarter ended March 31, 2017 affecting 90 employees.  The Company recorded $5.3 million in severance and benefits charges during the period.  Cash payments of $2.9 million were made during the third quarter and the balance of cash payments are expected to be paid by the end of the first quarter of fiscal 2018.

[0001564590-17-008860:notes:141]
[same as prior period, unchanged from 0001564590-17-000906:notes:134]

[0001564590-17-008860:notes:142]
During the first quarter of fiscal 2016, the Company recorded restructuring charges of $5.6 million including $5.4 million for excess facility charges and adjustments to service and benefits of $0.2 million.  Excess facilities charges included $4.1 million of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and accelerated depreciation of leasehold improvements in the amount of $1.3 million.

[0001564590-17-008860:notes:143]
During the second quarter of fiscal 2016, the Company incurred restructuring charges of $3.0 million including $2.9 million in excess facilities charges related to amending its lease in North Carolina, thereby reducing it floor space by 36%, and adjustments to severance and benefits of $0.2 million. Excess facilities charges included accelerated depreciation of leasehold improvements in the amount of $1.9 million and contract termination charges and professional fees of $1.0 million.

[0001564590-17-008860:notes:144]
During the third quarter of fiscal 2016, in conjunction with the exiting of facilities noted above, the Company incurred restructuring charges of $1.4 million.  Excess facilities charges included accelerated depreciation of leasehold improvements in the amount of $1.2 million associated with the North Carolina facility, $0.2 million related to a change in the accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for our San Jose, California headquarters facility and the reversal of $0.2 million of estimated severance benefits.  These charges are reflected in “Restructuring and related charges, net of reversals” in the condensed consolidated statements of operations.

[0001564590-17-008860:notes:145]
[same as prior period, unchanged from 0001564590-17-000906:notes:137]

[0001564590-17-008860:notes:146]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2016 |  |  | 4,644 |  |  |  | — |  |  |  | — |  |  |  | 4,644 |  |
| Period charges |  |  | 1,655 |  |  |  | 5,339 |  |  |  | 2,578 |  |  |  | 9,572 |  |
| Non cash charges |  |  | — |  |  |  | — |  |  |  | (2,578 | ) |  |  | (2,578 | ) |
| Period payments |  |  | (2,286 | ) |  |  | (3,049 | ) |  |  | — |  |  |  | (5,335 | ) |
| Balance as of March 31, 2017 |  | $ | 4,013 |  |  | $ | 2,290 |  |  | $ | — |  |  | $ | 6,303 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3,529 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,774 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-008860:notes:147]
| 9. | Commitments and Contingencies |

[0001564590-17-008860:notes:148]
Purchase Commitments

[0001564590-17-008860:notes:149]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2017, the Company had non-cancelable commitments to purchase $88.9 million of such inventory.  As of March 31, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $22.8 of software and support services.

[0001564590-17-008860:notes:150]
Legal Proceedings

[0001564590-17-008860:notes:151]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-17-008860:notes:152]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-17-008860:notes:153]
Brazilian Tax Assessment Matters

[0001564590-17-008860:notes:154]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of March 31, 2017.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.1 million), plus interest and penalties BRL 18.1 million (US $5.8 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

[0001564590-17-008860:notes:155]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits covered the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company had changed its ICMS procedures effective May 2009. This audit was recently completed and in March 2017 the Company paid BRL 0.2 million (US $0.1 ) related to the audit.

[0001564590-17-008860:notes:156]
Based on the currently available information, the Company believes the ultimate outcome of the above assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL 25.3 million (US $8.1 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $3.0 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

[0001564590-17-008860:notes:157]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from the Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

[0001564590-17-008860:notes:158]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-17-008860:notes:159]
On October 23 and 29, 2015, complaints were filed alleging violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint. On November 10, 2016 defendants filed a motion to dismiss the complaint and on April 27, 2017, the case was dismissed by the court, with leave to amend the complaint.  Plaintiffs have until May 29, 2017, if they elect to file an amended complaint.

[0001564590-17-008860:notes:160]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.

[0001564590-17-008860:notes:161]
Plectrum, LLC v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-17-008860:notes:162]
On February 27, 2017, the Company was served with a patent infringement complaint, dated February 2, 2017, and filed by Plectrum LLC in the U.S. District Court for the Eastern District of Texas.  The case is Plectrum LLC v. Extreme Networks, Inc., No. 4:17-cv-0079.  The complaint asserts infringement of U.S. Patent Nos. 5,978,951, 6,205,149, and 6,751,677.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s S-Series products and Summit Series Switch products.  Plectrum seeks an injunction and damages of an unspecified amount.  The Company has not yet responded to the complaint.

[0001564590-17-008860:notes:163]
XR Communications, LLC d/b/a Vivato Technologies, LLC v. Extreme Networks, Inc.

[0001564590-17-008860:notes:164]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies, LLC) sued Extreme in the Central District of California.   The complaint asserts infringement of U.S. Patent Nos. 7,062,296; 7,729,728; and 6,611,231. XR seeks damages of an unspecified amount and on-going royalties, but not an injunction. The Company has not yet responded to the complaint.  The Company believes the claims are without merit and intends to vigorously defend the claims.

[0001564590-17-008860:notes:165]
Indemnification Obligations

[0001564590-17-008860:notes:166]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of March 31, 2017, the Company had no outstanding indemnification claims.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-008860:notes:167]
[same as prior period, unchanged from 0001564590-17-000906:notes:157]

[0001564590-17-008860:notes:168]
For the three months ended March 31, 2017 and 2016, the Company recorded an income tax provision of $1.2 million and $0.9  million, respectively.    For the nine months ended March 31, 2017 and 2016, the Company recorded an income tax provision of $3.3 million and $3.0 million, respectively.

[0001564590-17-008860:notes:169]
The income tax provisions for the three months ended March 31, 2017 and 2016, consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. and the Zebra WLAN Business. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended March 31, 2017 and 2016, and therefore may not reflect the annual effective tax rate.

[0001564590-17-008860:notes:170]
[same as prior period, unchanged from 0001564590-17-000906:notes:160]

[0001564590-17-008860:notes:171]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  Additionally, the Company purchased the Zebra WLAN Business in an asset acquisition.  The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.  During the three and nine months ended March 31, 2017, the Company deducted $1.3 million and $3.7 million of tax amortization expense respectively, for each period of tax related to capitalized goodwill resulting from the acquisition of Enterasys and the Zebra WLAN Business. As of March 31, 2017, the Company recorded a deferred tax liability of $5.8 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-17-008860:notes:172]
The Company had $19.4 million of unrecognized tax benefits as of March 31, 2017.  The future impact of the unrecognized tax benefit of $19.3 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-17-008860:notes:173]
[same as prior period, unchanged from 0001564590-17-000906:notes:163]

[0001564590-17-008860:notes:174]
[same as prior period, unchanged from 0001564590-17-000906:notes:164]


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-008860:notes:175]
[same as prior period, unchanged from 0001564590-17-000906:notes:165]

[0001564590-17-008860:notes:176]
[same as prior period, unchanged from 0001564590-17-000906:notes:166]

[0001564590-17-008860:notes:177]
[same as prior period, unchanged from 0001564590-17-000906:notes:167]

[0001564590-17-008860:notes:178]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Net loss |  | $ | (5,604 | ) |  | $ | (10,784 | ) |  | $ | (20,694 | ) |  | $ | (29,544 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 109,213 |  |  |  | 104,104 |  |  |  | 107,531 |  |  |  | 102,486 |  |
| Net loss per share - basic and diluted |  | $ | (0.05 | ) |  | $ | (0.10 | ) |  | $ | (0.19 | ) |  | $ | (0.29 | ) |

[0001564590-17-008860:notes:179]
[same as prior period, unchanged from 0001564590-17-000906:notes:169]

[0001564590-17-008860:notes:180]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Options to purchase common stock |  |  | — |  |  |  | 4,439 |  |  |  | 398 |  |  |  | 7,249 |  |
| Restricted stock units |  |  | 4 |  |  |  | 330 |  |  |  | 7 |  |  |  | 959 |  |
| Employee Stock Purchase Plan shares |  |  | 269 |  |  |  | 185 |  |  |  | 269 |  |  |  | 185 |  |
| Total shares excluded |  |  | 273 |  |  |  | 4,954 |  |  |  | 674 |  |  |  | 8,393 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-008860:notes:181]
[same as prior period, unchanged from 0001564590-17-000906:notes:171]

[0001564590-17-008860:notes:182]
[same as prior period, unchanged from 0001564590-17-000906:notes:172]

[0001564590-17-008860:notes:183]
As of March 31, 2017, forward foreign currency contracts had a notional principal amount of $4.3 million and an immaterial unrealized gain. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. As of March 31, 2016, the Company did not have any derivative instruments outstanding.

[0001564590-17-008860:notes:184]
Foreign currency transactions gains and losses from operations was gain of $0.8 million and $0.2 million for the three months ended March 31, 2017 and 2016, respectively.   Foreign currency transactions gains and losses from operations was gain of $0.0 million and $1.3 million for the nine months ended March 31, 2017 and 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-008860:notes:185]
[same as prior period, unchanged from 0001564590-17-000906:notes:175]

[0001564590-17-008860:notes:186]
[same as prior period, unchanged from 0001564590-17-000906:notes:176]

[0001564590-17-008860:notes:187]
[same as prior period, unchanged from 0001564590-17-000906:notes:177]

[0001564590-17-008860:notes:188]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Net Revenues: |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 79,088 |  |  | $ | 58,205 |  |  | $ | 202,139 |  |  | $ | 173,298 |  |
| Other |  |  | 3,448 |  |  |  | 5,398 |  |  |  | 21,618 |  |  |  | 18,983 |  |
| Total Americas |  |  | 82,536 |  |  |  | 63,603 |  |  |  | 223,757 |  |  |  | 192,281 |  |
| EMEA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Germany |  |  | 17,918 |  |  |  | 16,795 |  |  |  | 61,782 |  |  |  | 49,150 |  |
| Other |  |  | 34,058 |  |  |  | 33,563 |  |  |  | 97,526 |  |  |  | 112,336 |  |
| Total EMEA |  |  | 51,976 |  |  |  | 50,358 |  |  |  | 159,308 |  |  |  | 161,486 |  |
| APAC: |  |  | 14,152 |  |  |  | 10,925 |  |  |  | 36,352 |  |  |  | 35,005 |  |
| Total net revenues |  | $ | 148,664 |  |  | $ | 124,886 |  |  | $ | 419,417 |  |  | $ | 388,772 |  |

[0001564590-17-008860:notes:189]
| Long Lived Assets: |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Americas |  | $ | 67,484 |  |  | $ | 58,277 |  |
| EMEA |  |  | 9,909 |  |  |  | 14,234 |  |
| APAC |  |  | 4,236 |  |  |  | 2,493 |  |
| Total long lived assets |  | $ | 81,629 |  |  | $ | 75,004 |  |
