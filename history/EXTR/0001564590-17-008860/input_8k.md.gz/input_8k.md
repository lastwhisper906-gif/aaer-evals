# EXTR 8-K — 0001564590-17-008378 filed 2017-05-03

## item codes, every 8-K on or before 2017-05-04

- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2017-05-04

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-008378:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-17-008378:8k_2_02:2]
extr-ex991_6.htm

[0001564590-17-008378:8k_2_02:3]
Exhibit 99.1

[0001564590-17-008378:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-17-008378:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Laurie Little |  | Media Contact Ben Haber |
| 212/481-2050 |  | 617/624-3200 |
| extreme@tpr-ir.com |  | ExtremeUS@racepointglobal.com |

[0001564590-17-008378:8k_2_02:6]
Extreme Networks Reports Third Quarter Fiscal Year 2017 Financial Results

[0001564590-17-008378:8k_2_02:7]
SAN JOSE, Calif., May 3, 2017 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal third quarter ended March 31, 2017.

[0001564590-17-008378:8k_2_02:8]
|  | • | Third quarter revenue was $148.7 million, an increase of 19.0% year-over-year. |

[0001564590-17-008378:8k_2_02:9]
|  | • | GAAP gross margin for the third fiscal quarter was 55.3% and non-GAAP gross margin was 57.0%, an increase of 360 basis points year-over-year. |

[0001564590-17-008378:8k_2_02:10]
|  | • | GAAP operating margin for the third fiscal quarter was (2.2)% and non-GAAP operating margin was 9.4%, an increase of 510 basis points year-over-year. |

[0001564590-17-008378:8k_2_02:11]
|  | • | GAAP net loss for the third fiscal quarter was $5.6 million, or $0.05 per basic share, and non-GAAP net income was $11.6 million, or $0.10 per diluted share, an increase of $0.07 year-over-year. |

[0001564590-17-008378:8k_2_02:12]
“We are pleased to deliver our eighth consecutive quarter of strong financial results as demonstrated by  continued growth in gross margins, operating income and earnings – all exceeding expectations,” stated Ed Meyercord, President and CEO of Extreme Networks.  “The strength of our cash flow and top line growth, driven by the successful integration of the Zebra WLAN acquisition, highlights the success of our accretive acquisition strategy.  While our more disciplined discounting policies put pressure on revenue during the quarter, our focus on higher quality customer solutions contributed to enhanced non-GAAP gross margins that grew 360 basis points year-over-year.  This improvement, combined with our operating expense management, drove cash flows significantly higher as evidenced by our non-GAAP operating income that more than doubled from the same period a year ago.

[0001564590-17-008378:8k_2_02:13]
“During the quarter, we also took proactive steps to strengthen our competitive position in the enterprise networking market by signing asset purchase agreements with Avaya and Brocade,” continued Meyercord.   “Both companies have blue chip enterprise customers across our target verticals, as well as strong teams of talented networking professionals and newly refreshed product and software portfolios with differentiated technology. These strengths will further elevate Extreme’s competitiveness, especially in the data center.

[0001564590-17-008378:8k_2_02:14]
“Moving forward, we are well positioned to take share in the enterprise networking industry with a significantly expanded, high quality enterprise customer base and new innovative products. We are the only pure play IP networking company solely focused on a strategy of software-driven, end-to-end, wired and wireless networking solutions for enterprise customers with 100% insourced customer service,” concluded Meyercord.

[0001564590-17-008378:8k_2_02:15]
Recent Key Events:

[0001564590-17-008378:8k_2_02:16]
|  | • | Successfully Integrated Zebra’s Wireless LAN Business: The recently acquired Wireless LAN business has already provided significant contributions to Extreme’s earnings and cash flow growth in the quarter, showcasing the strength of the Company’s execution of our acquisition strategy, Zebra WLAN has been successfully consolidated into our business operations. |

[0001564590-17-008378:8k_2_02:17]
|  | • | Signed Agreement to Acquire Avaya’s Networking Business: Extreme entered into an asset purchase agreement with Avaya Inc. to acquire its networking business in Avaya’s bankruptcy process as the stalking horse bidder. Avaya’s technology, heritage and enterprise campus focus with a similar solutions-driven go-to-market approach complements Extreme’s strategy. Avaya’s fixed and modular switching and advanced software-licensing capabilities, combined with the successful roll out of its next generation Layer 2 fabric technology that provides hyper-segmentation, native stealth and automatic elasticity, will add to Extreme’s solutions portfolio. |

[0001564590-17-008378:8k_2_02:18]
|  | • | Signed Agreement to Purchase Brocade’s Data Center Networking Business: Extreme entered into an agreement to acquire Brocade Communications Systems, Inc.’s data center switching, routing, and analytics business from Broadcom following Broadcom’s acquisition of Brocade. Extreme will be adding Brocade’s completely refreshed SLX family of data center products and over 6,000 Brocade enterprise customers mostly on the VDX switching and MLX routing platform. The deal, once consummated, will significantly strengthen Extreme’s position in the expanding high-end data center market and reinforce the Company’s strategy of delivering software-driven networking solutions focused on the enterprise customer. |

[0001564590-17-008378:8k_2_02:19]
|  | • | Introduced Powerful Retail Guest Analytics Solution: Extreme introduced its Retail Guest Analytics solution as part of its new ExtremeWireless™ WiNG product portfolio, which is a highly integrated and customizable platform that enables retailers to better understand shoppers’ in-store habits and create personalized offers. |

[0001564590-17-008378:8k_2_02:20]
|  | • | Introduced Information Governance Engine: Extreme introduced the Information Governance Engine, an optional add-on to the ExtremeManagement™ product portfolio, enabling CISOs and CIOs to establish and maintain a clinical baseline that demonstrates compliance with HIPAA and PCI standards for their mission-critical networks. |

[0001564590-17-008378:8k_2_02:21]
|  | • | Continued Customer Momentum: Extreme announced steady growth in acquiring new community college customers worldwide, including Alabama Southern Community College, Halifax Community College, College of the Canyons, Southern Union State Community College and Johnston Community College. |

[0001564590-17-008378:8k_2_02:22]
|  | • | Powered “Most Connected” Super Bowl: As the Official Wi-Fi and Wi-Fi Analytics provider of Super Bowl LI, Extreme’s entire suite of technologies was utilized to power Super Bowl LI at NRG Stadium, connected to over 35,000 fans, and transferred a record breaking 11.8 Terabytes of data across the Wi-Fi network during the game. |

[0001564590-17-008378:8k_2_02:23]
|  | • | Class Action Shareholder Litigation Dismissed: On April 27, 2017 the court issued an opinion granting our motion to dismiss the litigation. The plaintiffs were given leave to amend the complaint by May 29, 2017. If they do, we intend to continue to defend the case zealously. |

[0001564590-17-008378:8k_2_02:24]
Fiscal Q3 2017 Financial Metrics:

[0001564590-17-008378:8k_2_02:25]
|  |  | 2017 |  |  | 2016 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 110.8 |  |  | $ | 92.7 |  |  | $ | 18.1 |  |  |  | 20 | % |
| Service |  |  | 37.9 |  |  |  | 32.2 |  |  |  | 5.7 |  |  |  | 18 | % |
| Total Net Revenue |  | $ | 148.7 |  |  | $ | 124.9 |  |  | $ | 23.8 |  |  |  | 19 | % |
| Gross Margin |  |  | 55.3 | % |  |  | 50.2 | % |  |  | 5.1 | % |  |  | 10 | % |
| Operating Margin |  |  | (2.2 | )% |  |  | (7.1 | )% |  |  | 4.9 | % |  |  | 69 | % |
| Net Loss |  | $ | (5.6 | ) |  | $ | (10.8 | ) |  | $ | 5.2 |  |  |  | 48 | % |
| Loss per basic share |  | $ | (0.05 | ) |  | $ | (0.10 | ) |  | $ | 0.05 |  |  |  | 50 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 110.8 |  |  | $ | 92.7 |  |  | $ | 18.1 |  |  |  | 20 | % |
| Service |  |  | 37.9 |  |  |  | 32.6 |  |  |  | 5.3 |  |  |  | 16 | % |
| Total Net Revenue |  | $ | 148.7 |  |  | $ | 125.3 |  |  | $ | 23.4 |  |  |  | 19 | % |
| Gross Margin |  |  | 57.0 | % |  |  | 53.4 | % |  |  | 3.6 | % |  |  | 7 | % |
| Operating Margin |  |  | 9.4 | % |  |  | 4.3 | % |  |  | 5.1 | % |  |  | 119 | % |
| Net Income |  | $ | 11.6 |  |  | $ | 3.5 |  |  | $ | 8.1 |  |  |  | 232 | % |
| Earnings per diluted share |  | $ | 0.10 |  |  | $ | 0.03 |  |  | $ | 0.07 |  |  |  | 233 | % |

[0001564590-17-008378:8k_2_02:26]
|  | • | Cash and investments ended the quarter at $117.3 million, as compared to $103.8 million from the prior quarter and increased $29.0 million from the prior year. |

[0001564590-17-008378:8k_2_02:27]
|  | • | Accounts receivable balance ending Q3 was $102.0, with days sales outstanding (“DSO”) of 62. |

[0001564590-17-008378:8k_2_02:28]
|  | • | Inventory ending Q3 was $47.7 million, an increase of $0.3 million from the prior quarter and a decrease of $5.1 million from the prior year. |

[0001564590-17-008378:8k_2_02:29]
Business Outlook:

[0001564590-17-008378:8k_2_02:30]
For its fourth quarter of fiscal 2017 ending June 30, 2017, the Company is targeting revenue in a range of $168.0 million to $178.0 million.  GAAP gross margin is targeted between 55.6% and 56.6% and non-GAAP gross margin is targeted between 56.5% and 57.5%. Operating expenses are targeted to be between $86.0 million and $90.0 million on a GAAP basis and $76.5 million to $80.5 million on a non-GAAP basis. GAAP earnings are targeted to be between a net income of $5.1 million to $8.5 million, or earnings of $0.04 to $0.07 per diluted share.  Non-GAAP earnings are targeted in a range of net income of $16.2 million to $19.6 million, or $0.14 to $0.17 per diluted share. The GAAP and non-GAAP net income targets are based on an estimated 114.3 million average outstanding shares.

[0001564590-17-008378:8k_2_02:31]
The following table shows the GAAP to non-GAAP reconciliation for Q4FY’17 guidance:

[0001564590-17-008378:8k_2_02:32]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.6% - 56.6% |  |  | 4.4% - 6.1% |  |  | $0.04 - $0.07 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles |  | 0.6% |  |  |  | 0.7% |  |  | $ | 0.01 |  |
| Stock based compensation |  | 0.3% |  |  |  | 2.2% |  |  | $ | 0.03 |  |
| Restructuring charge, net | - |  |  |  | 1.2% |  |  | $ | 0.02 |  |
| Amortization of non product intangibles | - |  |  |  | 0.6% |  |  | $ | 0.01 |  |
| Acquisition and integration costs | - |  |  |  | 1.7% |  |  | $ | 0.03 |  |
| Non-GAAP | 56.5% - 57.5% |  |  | 11.0% - 12.3% |  |  | $0.14 - $0.17 |  |

[0001564590-17-008378:8k_2_02:33]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-17-008378:8k_2_02:34]
Conference Call:

[0001564590-17-008378:8k_2_02:35]
Extreme will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the third fiscal quarter results as well as the fourth fiscal quarter 2017 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through May 2, 2018.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406   Conference ID # 6976972.

[0001564590-17-008378:8k_2_02:36]
About Extreme Networks:

[0001564590-17-008378:8k_2_02:37]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, on premise or through the cloud, we go to extreme measures for our customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-17-008378:8k_2_02:38]
Extreme Networks and the Extreme Networks logo, ExtremeManagement, ExtremeWireless, ExtremeControl and ExtremeAnalytics are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-17-008378:8k_2_02:39]
Non-GAAP Financial Measures:

[0001564590-17-008378:8k_2_02:40]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, executive transition costs, litigation expenses and overhead adjustments.  The Company believes that excluding these items provides both management and investors

[0001564590-17-008378:8k_2_02:41]
with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-17-008378:8k_2_02:42]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-17-008378:8k_2_02:43]
Forward Looking Statements:

[0001564590-17-008378:8k_2_02:44]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-17-008378:8k_2_02:45]
EXTREME NETWORKS, INC.

[0001564590-17-008378:8k_2_02:46]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-008378:8k_2_02:47]
(In thousands)

[0001564590-17-008378:8k_2_02:48]
(Unaudited)

[0001564590-17-008378:8k_2_02:49]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 117,280 |  |  | $ | 94,122 |  |
| Accounts receivable, net of allowances of $2,160 at March 31, 2017 and $3,257 at June 30, 2016 |  |  | 101,960 |  |  |  | 81,419 |  |
| Inventories |  |  | 47,689 |  |  |  | 40,989 |  |
| Prepaid expenses and other current assets |  |  | 25,343 |  |  |  | 12,438 |  |
| Total current assets |  |  | 292,272 |  |  |  | 228,968 |  |
| Property and equipment, net |  |  | 30,409 |  |  |  | 29,580 |  |
| Intangible assets, net |  |  | 27,766 |  |  |  | 19,762 |  |
| Goodwill |  |  | 82,680 |  |  |  | 70,877 |  |
| Other assets |  |  | 23,454 |  |  |  | 25,236 |  |
| Total assets |  | $ | 456,581 |  |  | $ | 374,423 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 11,149 |  |  | $ | 17,628 |  |
| Accounts payable |  |  | 35,629 |  |  |  | 30,711 |  |
| Accrued compensation and benefits |  |  | 28,170 |  |  |  | 27,145 |  |
| Accrued warranty |  |  | 10,030 |  |  |  | 9,600 |  |
| Deferred revenue, net |  |  | 78,918 |  |  |  | 72,934 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  |  | 44,258 |  |  |  | 26,817 |  |
| Other accrued liabilities |  |  | 37,062 |  |  |  | 26,691 |  |
| Total current liabilities |  |  | 245,216 |  |  |  | 211,526 |  |
| Deferred revenue, less current portion |  |  | 23,856 |  |  |  | 21,926 |  |
| Long-term debt, less current portion |  |  | 83,775 |  |  |  | 37,446 |  |
| Deferred income taxes |  |  | 6,140 |  |  |  | 4,693 |  |
| Other long-term liabilities |  |  | 9,808 |  |  |  | 8,635 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 87,786 |  |  |  | 90,197 |  |
| Total liabilities and stockholders’ equity |  | $ | 456,581 |  |  | $ | 374,423 |  |

[0001564590-17-008378:8k_2_02:50]
EXTREME NETWORKS, INC.

[0001564590-17-008378:8k_2_02:51]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-008378:8k_2_02:52]
(In thousands, except per share amounts)

[0001564590-17-008378:8k_2_02:53]
(Unaudited)

[0001564590-17-008378:8k_2_02:54]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 110,789 |  |  | $ | 92,711 |  |  | $ | 310,709 |  |  | $ | 289,447 |  |
| Service |  |  | 37,875 |  |  |  | 32,175 |  |  |  | 108,708 |  |  |  | 99,325 |  |
| Total net revenues |  |  | 148,664 |  |  |  | 124,886 |  |  |  | 419,417 |  |  |  | 388,772 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 52,401 |  |  |  | 50,240 |  |  |  | 155,987 |  |  |  | 154,277 |  |
| Service |  |  | 14,117 |  |  |  | 11,926 |  |  |  | 40,684 |  |  |  | 36,382 |  |
| Total cost of revenues |  |  | 66,518 |  |  |  | 62,166 |  |  |  | 196,671 |  |  |  | 190,659 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 58,388 |  |  |  | 42,471 |  |  |  | 154,722 |  |  |  | 135,170 |  |
| Service |  |  | 23,758 |  |  |  | 20,249 |  |  |  | 68,024 |  |  |  | 62,943 |  |
| Total gross profit |  |  | 82,146 |  |  |  | 62,720 |  |  |  | 222,746 |  |  |  | 198,113 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 24,691 |  |  |  | 18,852 |  |  |  | 67,003 |  |  |  | 59,836 |  |
| Sales and marketing |  |  | 38,759 |  |  |  | 38,322 |  |  |  | 116,824 |  |  |  | 111,442 |  |
| General and administrative |  |  | 9,612 |  |  |  | 8,957 |  |  |  | 27,296 |  |  |  | 27,896 |  |
| Acquisition and integration costs |  |  | 3,418 |  |  |  | - |  |  |  | 9,908 |  |  |  | 1,157 |  |
| Restructuring and related charges, net of reversals |  |  | 7,719 |  |  |  | 1,358 |  |  |  | 9,572 |  |  |  | 9,992 |  |
| Amortization of intangibles |  |  | 1,193 |  |  |  | 4,142 |  |  |  | 7,510 |  |  |  | 12,860 |  |
| Total operating expenses |  |  | 85,392 |  |  |  | 71,631 |  |  |  | 238,113 |  |  |  | 223,183 |  |
| Operating loss |  |  | (3,246 | ) |  |  | (8,911 | ) |  |  | (15,367 | ) |  |  | (25,070 | ) |
| Interest income |  |  | 236 |  |  |  | 28 |  |  |  | 374 |  |  |  | 84 |  |
| Interest expense |  |  | (1,177 | ) |  |  | (769 | ) |  |  | (3,000 | ) |  |  | (2,404 | ) |
| Other income (expense), net |  |  | (251 | ) |  |  | (266 | ) |  |  | 551 |  |  |  | 813 |  |
| Loss before income taxes |  |  | (4,438 | ) |  |  | (9,918 | ) |  |  | (17,442 | ) |  |  | (26,577 | ) |
| Provision for income taxes |  |  | 1,166 |  |  |  | 866 |  |  |  | 3,252 |  |  |  | 2,967 |  |
| Net loss |  | $ | (5,604 | ) |  | $ | (10,784 | ) |  | $ | (20,694 | ) |  | $ | (29,544 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.05 | ) |  | $ | (0.10 | ) |  | $ | (0.19 | ) |  | $ | (0.29 | ) |
| Net loss per share - diluted |  | $ | (0.05 | ) |  | $ | (0.10 | ) |  | $ | (0.19 | ) |  | $ | (0.29 | ) |
| Shares used in per share calculation - basic |  |  | 109,213 |  |  |  | 104,104 |  |  |  | 107,531 |  |  |  | 102,486 |  |
| Shares used in per share calculation - diluted |  |  | 109,213 |  |  |  | 104,104 |  |  |  | 107,531 |  |  |  | 102,486 |  |

[0001564590-17-008378:8k_2_02:55]
EXTREME NETWORKS, INC.

[0001564590-17-008378:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-008378:8k_2_02:57]
(In thousands)

[0001564590-17-008378:8k_2_02:58]
(Unaudited)

[0001564590-17-008378:8k_2_02:59]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Net cash provided by operating activities |  | $ | 43,961 |  |  | $ | 18,913 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (7,832 | ) |  |  | (2,797 | ) |
| Acquisition |  |  | (51,088 | ) |  |  | - |  |
| Deposit related to future acquisition |  |  | (10,239 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (69,159 | ) |  |  | (2,797 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | - |  |  |  | 15,000 |  |
| Borrowings under Term Loan |  |  | 48,250 |  |  |  |  |  |
| Loan fees on borrowings |  |  | (1,327 | ) |  |  |  |  |
| Repayment of debt |  |  | (7,775 | ) |  |  | (23,125 | ) |
| Proceeds from issuance of common stock |  |  | 9,180 |  |  |  | 4,460 |  |
| Net cash provided by (used in) financing activities |  |  | 48,328 |  |  |  | (3,665 | ) |
| Foreign currency effect on cash |  |  | 28 |  |  |  | (342 | ) |
| Net increase in cash and cash equivalents |  |  | 23,158 |  |  |  | 12,109 |  |
| Cash and cash equivalents at beginning of period |  |  | 94,122 |  |  |  | 76,225 |  |
| Cash and cash equivalents at end of period |  | $ | 117,280 |  |  | $ | 88,334 |  |

[0001564590-17-008378:8k_2_02:60]
Extreme Networks, Inc.

[0001564590-17-008378:8k_2_02:61]
Non-GAAP Measures of Financial Performance

[0001564590-17-008378:8k_2_02:62]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-17-008378:8k_2_02:63]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of intangibles, restructuring expenses, executive transition expenses, litigation expense and overhead adjustments.

[0001564590-17-008378:8k_2_02:64]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-17-008378:8k_2_02:65]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-17-008378:8k_2_02:66]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustment, amortization of  intangibles, restructuring expenses,  executive transition costs, litigation expenses and overhead adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-17-008378:8k_2_02:67]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-17-008378:8k_2_02:68]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-17-008378:8k_2_02:69]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of Zebra Technologies Corporation’s wireless LAN business.   Extreme

[0001564590-17-008378:8k_2_02:70]
Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-17-008378:8k_2_02:71]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-17-008378:8k_2_02:72]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-17-008378:8k_2_02:73]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-17-008378:8k_2_02:74]
Restructuring expenses. Restructuring expenses primarily consist of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-17-008378:8k_2_02:75]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits and legal transition cash transactions.  The expenses are incurred through execution of pre-established employment contracts with senior executives.  The Company does not believe these expenses are reflective of ongoing cash requirements related to its operating results.

[0001564590-17-008378:8k_2_02:76]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matter as a result of a securities laws class action lawsuit.

[0001564590-17-008378:8k_2_02:77]
Overhead adjustments. Overhead adjustment relate to service inventory overhead capitalization, this was a one-time event and was non-cash in nature.

[0001564590-17-008378:8k_2_02:78]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-17-008378:8k_2_02:79]
EXTREME NETWORKS, INC.

[0001564590-17-008378:8k_2_02:80]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-008378:8k_2_02:81]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-17-008378:8k_2_02:82]
(In thousands, except per share amounts)

[0001564590-17-008378:8k_2_02:83]
(Unaudited)

[0001564590-17-008378:8k_2_02:84]
| Non-GAAP Revenue | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Revenue - GAAP Basis | $ | 148,664 |  |  | $ | 124,886 |  |  | $ | 419,417 |  |  | $ | 388,772 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,131 |  |
| Revenue - Non-GAAP Basis | $ | 148,664 |  |  | $ | 125,263 |  |  | $ | 419,550 |  |  | $ | 389,903 |  |

[0001564590-17-008378:8k_2_02:85]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Gross profit - GAAP Basis | $ | 82,146 |  |  | $ | 62,720 |  |  | $ | 222,746 |  |  | $ | 198,113 |  |
| Gross margin - GAAP Basis percentage |  | 55.3 | % |  |  | 50.2 | % |  |  | 53.1 | % |  |  | 51.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 129 |  |  |  | 428 |  |  |  | 737 |  |  |  | 1,644 |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,131 |  |
| Acquired inventory adjustments |  | 1,963 |  |  |  | - |  |  |  | 4,263 |  |  |  | - |  |
| Acquisition and integration costs |  | (413 | ) |  |  | - |  |  |  | 5,104 |  |  |  | - |  |
| Amortization of intangibles |  | 891 |  |  |  | 3,417 |  |  |  | 6,027 |  |  |  | 11,416 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Gross profit - Non-GAAP Basis | $ | 84,716 |  |  | $ | 66,942 |  |  | $ | 239,010 |  |  | $ | 210,811 |  |
| Gross margin - Non-GAAP Basis percentage |  | 57.0 | % |  |  | 53.4 | % |  |  | 57.0 | % |  |  | 54.1 | % |

[0001564590-17-008378:8k_2_02:86]
| Non-GAAP Operating Income | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| GAAP operating loss | $ | (3,246 | ) |  | $ | (8,911 | ) |  | $ | (15,367 | ) |  | $ | (25,070 | ) |
| GAAP operating loss percentage |  | (2.2 | )% |  |  | (7.1 | )% |  |  | (3.7 | )% |  |  | (6.4 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 2,474 |  |  |  | 3,503 |  |  |  | 9,328 |  |  |  | 12,120 |  |
| Acquisition and integration costs |  | 3,005 |  |  |  | - |  |  |  | 15,012 |  |  |  | 1,145 |  |
| Restructuring charge, net of reversal |  | 7,719 |  |  |  | 1,358 |  |  |  | 9,572 |  |  |  | 9,992 |  |
| Acquired inventory adjustments |  | 1,963 |  |  |  | - |  |  |  | 4,263 |  |  |  | - |  |
| Amortization of intangibles |  | 2,084 |  |  |  | 7,559 |  |  |  | 13,537 |  |  |  | 24,276 |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,131 |  |
| Executive transition costs |  | - |  |  |  | 1,395 |  |  |  | 34 |  |  |  | 1,395 |  |
| Litigation |  | (44 | ) |  |  | 85 |  |  |  | 219 |  |  |  | 164 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Total adjustments to GAAP operating loss | $ | 17,201 |  |  | $ | 14,277 |  |  | $ | 52,098 |  |  | $ | 48,730 |  |
| Non-GAAP operating income | $ | 13,955 |  |  | $ | 5,366 |  |  | $ | 36,731 |  |  | $ | 23,660 |  |
| Non-GAAP operating income percentage |  | 9.4 | % |  |  | 4.3 | % |  |  | 8.8 | % |  |  | 6.1 | % |

[0001564590-17-008378:8k_2_02:87]
| Non-GAAP Net Income | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| GAAP net loss | $ | (5,604 | ) |  | $ | (10,784 | ) |  | $ | (20,694 | ) |  | $ | (29,544 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 2,474 |  |  |  | 3,503 |  |  |  | 9,328 |  |  |  | 12,120 |  |
| Acquisition and integration costs |  | 3,005 |  |  |  | - |  |  |  | 15,012 |  |  |  | 1,145 |  |
| Restructuring charge, net of reversal |  | 7,719 |  |  |  | 1,358 |  |  |  | 9,572 |  |  |  | 9,992 |  |
| Amortization of intangibles |  | 2,084 |  |  |  | 7,559 |  |  |  | 13,537 |  |  |  | 24,276 |  |
| Acquired inventory adjustments |  | 1,963 |  |  |  | - |  |  |  | 4,263 |  |  |  | - |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 1,131 |  |
| Executive transition costs |  | - |  |  |  | 1,395 |  |  |  | 34 |  |  |  | 1,395 |  |
| Litigation |  | (44 | ) |  |  | 85 |  |  |  | 219 |  |  |  | 164 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Total adjustments to GAAP net loss | $ | 17,201 |  |  | $ | 14,277 |  |  | $ | 52,098 |  |  | $ | 48,730 |  |
| Non-GAAP net income | $ | 11,597 |  |  | $ | 3,493 |  |  | $ | 31,404 |  |  | $ | 19,186 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.10 |  |  | $ | 0.03 |  |  | $ | 0.28 |  |  | $ | 0.18 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 112,576 |  |  |  | 105,956 |  |  |  | 110,455 |  |  |  | 104,650 |  |

[0001564590-17-008378:8k_2_02:88]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31, 2017 |  |  | March 31, 2016 |  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Cash flow provided by operations | $ | 24,673 |  |  | $ | 4,946 |  |  | $ | 43,961 |  |  | $ | 18,913 |  |
| Less: PP&E CapEx spending |  | (3,170 | ) |  | $ | (1,388 | ) |  |  | (7,832 | ) |  |  | (2,797 | ) |
| Total free cash flow | $ | 21,503 |  |  | $ | 3,558 |  |  | $ | 36,129 |  |  | $ | 16,116 |  |
