# EXTR MD&A — 0001564590-17-008860


## mdna

[0001564590-17-008860:mdna:1]
[same as prior period, unchanged from 0001564590-17-000906:mdna:1]

[0001564590-17-008860:mdna:2]
[same as prior period, unchanged from 0001564590-17-000906:mdna:2]

[0001564590-17-008860:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended March 31, 2017.

[0001564590-17-008860:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from the data center to the access point, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. We strive to help our customers and partners Connect Beyond the Network™ by building world-class software and network infrastructure solutions that solve the wide range of problems faced by information technology (“IT”) departments.

[0001564590-17-008860:mdna:5]
[same as prior period, unchanged from 0001564590-17-000906:mdna:5]

[0001564590-17-008860:mdna:6]
[same as prior period, unchanged from 0001564590-17-000906:mdna:6]

[0001564590-17-008860:mdna:7]
[same as prior period, unchanged from 0001564590-17-000906:mdna:7]

[0001564590-17-008860:mdna:8]
[same as prior period, unchanged from 0001564590-17-000906:mdna:8]

[0001564590-17-008860:mdna:9]
[same as prior period, unchanged from 0001564590-17-000906:mdna:9]

[0001564590-17-008860:mdna:10]
[same as prior period, unchanged from 0001564590-17-000906:mdna:10]

[0001564590-17-008860:mdna:11]
[same as prior period, unchanged from 0001564590-17-000906:mdna:11]

[0001564590-17-008860:mdna:12]
[same as prior period, unchanged from 0001564590-17-000906:mdna:12]

[0001564590-17-008860:mdna:13]
[same as prior period, unchanged from 0001564590-17-000906:mdna:13]

[0001564590-17-008860:mdna:14]
[same as prior period, unchanged from 0001564590-17-000906:mdna:14]

[0001564590-17-008860:mdna:15]
[same as prior period, unchanged from 0001564590-17-000906:mdna:15]

[0001564590-17-008860:mdna:16]
|  | • | Multi-vendor management from a “single pane of glass”. Extreme offers a single unified management system that is designed to provide insight, management and control across the entire network. This can provide better visibility to make the network easier to manage and troubleshoot, often with lower operating expenses. Our software can also manage many other vendors’ network devices, enabling our customers to potentially maximize device lifespan. |

[0001564590-17-008860:mdna:17]
|  | • | Software-driven vertical solutions. We design our software-driven solutions to support the unique needs of our target vertical markets in industries such as, healthcare, hospitality, education, manufacturing, government, transportation and logistics and retail. These solutions are well positioned to add value to our vertical-specific partner ecosystem. |

[0001564590-17-008860:mdna:18]
|  | • | Application-aware Quality of Service (“QoS”) and analytics. Extreme has innovative analytic software that enables our customers to see application usage across the network and apply policies that maximize network capabilities. This allows our customers to improve the user experience and drive better business outcomes. |

[0001564590-17-008860:mdna:19]
|  | • | Built-in identity and access control. We design our network access control and identity management with the wired and wireless hardware. The Air Defense Services Platform (“ADSP”) leads the industry in Wireless Intrusion Prevention and supports advanced forensics analysis required for PCI, HIPAA and other compliance regulations. |

[0001564590-17-008860:mdna:20]
[same as prior period, unchanged from 0001564590-17-000906:mdna:20]

[0001564590-17-008860:mdna:21]
|  | • | Managed Services Solutions. Extreme outsourced network monitoring and management services can save money on IT staff and training and allow the IT staff to focus on more strategic tasks to drive better value across the business. |

[0001564590-17-008860:mdna:22]
[same as prior period, unchanged from 0001564590-17-000906:mdna:21]

[0001564590-17-008860:mdna:23]
[same as prior period, unchanged from 0001564590-17-000906:mdna:22]

[0001564590-17-008860:mdna:24]
[same as prior period, unchanged from 0001564590-17-000906:mdna:23]

[0001564590-17-008860:mdna:25]
[same as prior period, unchanged from 0001564590-17-000906:mdna:24]

[0001564590-17-008860:mdna:26]
[same as prior period, unchanged from 0001564590-17-000906:mdna:25]

[0001564590-17-008860:mdna:27]
During the three and nine months ended March 31, 2017, we recognized acquisition costs of $1.1 million and $7.6 million, respectively, which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-17-008860:mdna:28]
Future Acquisitions

[0001564590-17-008860:mdna:29]
On March 7, 2017, we entered into an Asset Purchase Agreement (“Purchase Agreement”) with Avaya Inc., (“Avaya”), to purchase Avaya’s fabric-based secure networking solutions and network security solutions business (the “Business”).  Upon the terms and subject to the conditions of the Purchase Agreement, we will acquire customers, employees, technology and other assets of the Business, as well as assume certain contracts and other liabilities of the Business, for a purchase price of $100 million, subject to certain adjustments set forth in the Purchase Agreement related to net working capital, deferred revenue, certain assumed lease obligations and certain assumed pension obligations for transferring employees of the Business.  Pursuant to certain ancillary agreements, Avaya will also provide us with access to certain technology related to the Business, as well as transition services for a period of time following the closing of the transaction.  The Purchase Agreement is contingent upon approval of the court and we have made a deposit of $10.0 million toward the purchase price, which is included in “Prepaid expenses and other current assets” in the accompanying condensed consolidated balance sheets.

[0001564590-17-008860:mdna:30]
During the three and nine months ended March 31, 2017, we recognized acquisition costs of $1.3 million, which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations related to the Purchase Agreement.

[0001564590-17-008860:mdna:31]
On March 29, 2017, we entered into another Asset Purchase Agreement (the “Purchase Agreement II”) with LSI Corporation,

[0001564590-17-008860:mdna:32]
(“LSI”), and, solely for the purposes set forth in the Purchase Agreement II, Broadcom Corporation, (“Broadcom”) to purchase the data center technology business (the “ Business II”) of Brocade Communication Systems, Inc. (“Brocade”) and its subsidiaries.  Upon the terms and subject to the conditions of the Purchase Agreement II, we will acquire customers, employees, technology and other assets of the Business II, as well as assume certain contracts and other liabilities of the Business II, for an upfront cash closing payment equal to $35.0 million, plus a deferred payment equal to $20.0 million to be paid $1 million per quarter for 20 quarters following the closing date of the transaction (the “Closing,” and such date, the “Closing Date”), plus quarterly earnout payments equal to 50% of profits of the Business II for the five-year period commencing at the end of our first full fiscal quarter following the Closing Date.  Pursuant to certain ancillary agreements, LSI will also provide us with access to certain technology related to the Business II, as well as transition services for a period of time following the Closing.  The acquisition will include the rights to have manufactured and sold Brocade’s current SLX based solutions product portfolio, which launched in March 2017.  The Purchase Agreement II is contingent upon Broadcom acquiring Brocade, therefore we do not expect our transaction to close until the first quarter of fiscal 2018.

[0001564590-17-008860:mdna:33]
During the three and nine months ended March 31, 2017, we recognized acquisition costs of $1.0 million, which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations related to the Purchase Agreement II.

[0001564590-17-008860:mdna:34]
[same as prior period, unchanged from 0001564590-17-000906:mdna:27]

[0001564590-17-008860:mdna:35]
During the third quarter of fiscal 2017, we achieved the following results:

[0001564590-17-008860:mdna:36]
|  | • | Net revenues of $148.7 million compared to $124.9 million in the third quarter of fiscal 2016. |

[0001564590-17-008860:mdna:37]
|  | • | Product revenues of $110.8 million compared to $92.7 million in the third quarter of fiscal 2016. |

[0001564590-17-008860:mdna:38]
|  | • | Service revenues of $37.9 million compared to $32.2 million in the third quarter of fiscal 2016. |

[0001564590-17-008860:mdna:39]
|  | • | Total gross margin of 55.3% of net revenues compared to 50.2% of net revenues in the third quarter of fiscal 2016. |

[0001564590-17-008860:mdna:40]
|  | • | Operating loss of $3.2 million compared to $8.9 million in the third quarter of fiscal 2016. |

[0001564590-17-008860:mdna:41]
|  | • | Net loss of $5.6 million compared to a net loss of $10.8 million in the third quarter of fiscal 2016. |

[0001564590-17-008860:mdna:42]
|  | • | Cash flow provided by operating activities of $44.0 million in the nine months ended March 31, 2017 compared to $18.9 million in the nine months ended March 31, 2016. |

[0001564590-17-008860:mdna:43]
|  | • | Cash and cash equivalents of $117.3 million compared to $88.3 million as of March 31, 2016. |

[0001564590-17-008860:mdna:44]
[same as prior period, unchanged from 0001564590-17-000906:mdna:37]

[0001564590-17-008860:mdna:45]
[same as prior period, unchanged from 0001564590-17-000906:mdna:38]

[0001564590-17-008860:mdna:46]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | $ Change |  |  | % Change |  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 110,789 |  |  | $ | 92,711 |  |  | $ | 18,078 |  |  |  | 19.5 | % |  | $ | 310,709 |  |  | $ | 289,447 |  |  | $ | 21,262 |  |  |  | 7.3 | % |
| Percentage of net revenue |  |  | 74.5 | % |  |  | 74.2 | % |  |  |  |  |  |  |  |  |  |  | 74.1 | % |  |  | 74.5 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 37,875 |  |  |  | 32,175 |  |  |  | 5,700 |  |  |  | 17.7 | % |  |  | 108,708 |  |  |  | 99,325 |  |  |  | 9,383 |  |  |  | 9.4 | % |
| Percentage of net revenue |  |  | 25.5 | % |  |  | 25.8 | % |  |  |  |  |  |  |  |  |  |  | 25.9 | % |  |  | 25.5 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 148,664 |  |  | $ | 124,886 |  |  | $ | 23,778 |  |  |  | 19.0 | % |  | $ | 419,417 |  |  | $ | 388,772 |  |  | $ | 30,645 |  |  |  | 7.9 | % |

[0001564590-17-008860:mdna:47]
Product revenues increased $18.1 million or 19.5% for the three months ended March 31, 2017 as compared to the corresponding period of fiscal 2016.  Product revenues increased by $21.3 million or 7.3% for the nine months ended March 31, 2017 as compared to the corresponding period of fiscal 2016.  The increases in product revenues for both periods of fiscal 2017 were attributable to growth in our wireless business due to the acquisition of the WLAN Business and lower discounting from list price.  The increase was partially offset by lower e-rate educational revenue.

[0001564590-17-008860:mdna:48]
Service revenues increased $5.7 million or 17.7% in the third quarter of fiscal 2017, compared to the corresponding period of fiscal 2016. Service revenues increased $9.4 million or 9.4% for the nine months ended March 31, 2017, compared to the corresponding period of fiscal 2016.  The increase in service revenues for both periods was due to the acquisition of the WLAN Business and the increased number of service contracts acquired.

[0001564590-17-008860:mdna:49]
[same as prior period, unchanged from 0001564590-17-000906:mdna:42]

[0001564590-17-008860:mdna:50]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | $ Change |  |  | % Change |  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 58,388 |  |  | $ | 42,471 |  |  | $ | 15,917 |  |  |  | 37.5 | % |  | $ | 154,722 |  |  | $ | 135,170 |  |  | $ | 19,552 |  |  |  | 14.5 | % |
| Percentage of product revenue |  |  | 52.7 | % |  |  | 45.8 | % |  |  |  |  |  |  |  |  |  |  | 49.8 | % |  |  | 46.7 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 23,758 |  |  |  | 20,249 |  |  |  | 3,509 |  |  |  | 17.3 | % |  |  | 68,024 |  |  |  | 62,943 |  |  |  | 5,081 |  |  |  | 8.1 | % |
| Percentage of service revenue |  |  | 62.7 | % |  |  | 62.9 | % |  |  |  |  |  |  |  |  |  |  | 62.6 | % |  |  | 63.4 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 82,146 |  |  | $ | 62,720 |  |  | $ | 19,426 |  |  |  | 31.0 | % |  | $ | 222,746 |  |  | $ | 198,113 |  |  | $ | 24,633 |  |  |  | 12.4 | % |
| Percentage of net revenue |  |  | 55.3 | % |  |  | 50.2 | % |  |  |  |  |  |  |  |  |  |  | 53.1 | % |  |  | 51.0 | % |  |  |  |  |  |  |  |  |

[0001564590-17-008860:mdna:51]
Product gross profit increased $15.9 million or 37.5% in the third quarter of fiscal 2017 as compared to the corresponding period in fiscal 2016.  Gross profit increased during the third quarter of fiscal 2017 due to higher revenues of $18.1 million, lower intangible asset amortization of $2.7 million, lower material costs of $1.5 million and inventory charges of $0.9 million.

[0001564590-17-008860:mdna:52]
Product gross profit increased $19.6 million or 14.5% in the first nine months of fiscal 2017 as compared to the corresponding period in fiscal 2016.  Gross profit increased during the first nine months of fiscal 2017, due to higher revenues of $21.3 million, lower intangible asset amortization of $2.7 million, warranty charges of $3.3 million due to lower claim rates, offset by increases in excess inventory charges of $0.9 million related to the discontinuance of certain product lines due to the acquisition of the WLAN Business.

[0001564590-17-008860:mdna:53]
Service gross profit increased $3.5 million or 17.3% in the third quarter of fiscal 2017 as compared to the third quarter of fiscal 2016 and increased $5.0 million or 8.1% in the first nine months of fiscal 2017 as compared to the corresponding period of fiscal 2016.  The increase in service gross profit was due to the increase in service revenues related to the acquisition of the WLAN Business and the increased service contracts acquired for both periods of fiscal 2017.

[0001564590-17-008860:mdna:54]
28

[0001564590-17-008860:mdna:55]
[same as prior period, unchanged from 0001564590-17-000906:mdna:47]

[0001564590-17-008860:mdna:56]
[same as prior period, unchanged from 0001564590-17-000906:mdna:48]

[0001564590-17-008860:mdna:57]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | $ Change |  |  | % Change |  |  | March 31, 2017 |  |  | March 31, 2016 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 24,691 |  |  | $ | 18,852 |  |  | $ | 5,839 |  |  |  | 31.0 | % |  | $ | 67,003 |  |  | $ | 59,836 |  |  | $ | 7,167 |  |  |  | 12.0 | % |
| Sales and marketing |  |  | 38,759 |  |  |  | 38,322 |  |  |  | 437 |  |  |  | 1.1 | % |  |  | 116,824 |  |  |  | 111,442 |  |  |  | 5,382 |  |  |  | 4.8 | % |
| General and administrative |  |  | 9,612 |  |  |  | 8,957 |  |  |  | 655 |  |  |  | 7.3 | % |  |  | 27,296 |  |  |  | 27,896 |  |  |  | (600 | ) |  |  | (2.2 | )% |
| Acquisition and integration costs |  |  | 3,418 |  |  |  | — |  |  |  | 3,418 |  |  |  | — |  |  |  | 9,908 |  |  |  | 1,157 |  |  |  | 8,751 |  |  |  | 756.4 | % |
| Restructuring and related charges, net of reversals |  |  | 7,719 |  |  |  | 1,358 |  |  |  | 6,361 |  |  |  | 468.4 | % |  |  | 9,572 |  |  |  | 9,992 |  |  |  | (420 | ) |  |  | (4.2 | )% |
| Amortization of intangibles |  |  | 1,193 |  |  |  | 4,142 |  |  |  | (2,949 | ) |  |  | (71.2 | )% |  |  | 7,510 |  |  |  | 12,860 |  |  |  | (5,350 | ) |  |  | (41.6 | )% |
| Total operating expenses |  | $ | 85,392 |  |  | $ | 71,631 |  |  | $ | 13,761 |  |  |  | 19.2 | % |  | $ | 238,113 |  |  | $ | 223,183 |  |  | $ | 14,930 |  |  |  | 6.7 | % |

[0001564590-17-008860:mdna:58]
[same as prior period, unchanged from 0001564590-17-000906:mdna:50]

[0001564590-17-008860:mdna:59]
[same as prior period, unchanged from 0001564590-17-000906:mdna:51]

[0001564590-17-008860:mdna:60]
Research and development expenses increased by $5.8 million or 31.0% for the three months ended March 31, 2017 as compared to the corresponding period of fiscal 2016.  The increase in research and development expenses was due to higher personnel costs of $4.2 million due to increased headcount related to the acquisition of the WLAN Business, higher facility and information technology costs of $0.9 million associated with the WLAN Business, increased professional fees of $0.6 million and increased equipment costs of $0.1 million.

[0001564590-17-008860:mdna:61]
Research and development expenses increased by $7.2 million or 12.0% for the nine months ended March 31, 2017 as compared to the corresponding period of fiscal 2016.  The increase in research and development expenses was due to higher personnel costs of $5.1 million, increased professional fees of $1.1 million and increased facility and information technology costs of $1.0 million.  All of which were driven by the acquisition of the WLAN Business.

[0001564590-17-008860:mdna:62]
[same as prior period, unchanged from 0001564590-17-000906:mdna:54]

[0001564590-17-008860:mdna:63]
[same as prior period, unchanged from 0001564590-17-000906:mdna:55]

[0001564590-17-008860:mdna:64]
Sales and marketing expenses increased by $0.4 million or 1.1% for the three months ended March 31, 2017 as compared to the corresponding period of fiscal 2016.  The increase in sales and marketing expenses was primarily due to higher personnel costs of $0.7 million driven in large part by the acquisition of the WLAN Business partially offset with reduced marketing costs of $0.3 million.

[0001564590-17-008860:mdna:65]
Sales and marketing expenses increased by $5.4 million or 4.8% for the nine months ended March 31, 2017 as compared to the corresponding period of fiscal 2016. The increase in sales and marketing expenses was primarily due to higher personnel costs of $3.2 million, travel costs of $1.2 million and professional fees of $0.7 million, due in large part to the acquisition of the WLAN Business.  The increases were partially offset by reduced marketing costs of $0.4 million.

[0001564590-17-008860:mdna:66]
[same as prior period, unchanged from 0001564590-17-000906:mdna:58]

[0001564590-17-008860:mdna:67]
[same as prior period, unchanged from 0001564590-17-000906:mdna:59]

[0001564590-17-008860:mdna:68]
General and administrative expenses increased by $0.7 million or 7.3% for the three months ended March 31, 2017 as compared to the corresponding period of fiscal 2016. The increase in general and administrative expenses was due to higher personnel costs of $0.3 million and professional fees and sales taxes of $0.4 million.

[0001564590-17-008860:mdna:69]
General and administrative expenses decreased by $0.6 million or 2.2% for the nine months ended March 31, 2017 as compared to the corresponding period of fiscal 2016. The decrease in general and administrative expenses was due to lower personnel costs of $1.0 million partially offset by an increase in professional fees of $0.4 million.

[0001564590-17-008860:mdna:70]
[same as prior period, unchanged from 0001564590-17-000906:mdna:62]

[0001564590-17-008860:mdna:71]
During the three months ended March 31, 2017 and 2016, we recorded $3.4 million and none, respectively, of acquisition and integration costs.  Expenses for the three months ended March 31, 2017 consisted primarily of legal and accounting services associated with the acquisition of the WLAN Business.

[0001564590-17-008860:mdna:72]
During the nine months ended March 31, 2017 and 2016, we recorded $9.9 million and $1.2 million, respectively, of acquisition and integration costs.  Costs for the nine months ended March 31, 2017 relate primarily to the acquisition of the WLAN Business and costs for the nine months ended March 31, 2016 were related to integration costs primarily for IT and sales integration associated with Enterasys.

[0001564590-17-008860:mdna:73]
[same as prior period, unchanged from 0001564590-17-000906:mdna:65]

[0001564590-17-008860:mdna:74]
During the three months ended March 31, 2017, we incurred $7.7 million in restructuring and other charges.  The significant charges during the quarter were related to a reduction in force totaling $5.3 million.  Additionally, we entered into a sublease agreement for our Rio Robles site in San Jose, California during the third quarter of fiscal 2017. The sublease is for the remaining duration of the our lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease.   The adjustments to sub-lease income to be received related to the future obligations for non-cancelable lease payments in the amount of $1.5 million and accelerated depreciation of leasehold improvements and fixed assets in the amount of $0.9 million.

[0001564590-17-008860:mdna:75]
During the nine months ended March 31, 2017, we incurred $9.6 million in restructuring and other charges.  The significant charges during the period was related to a reduction in force totaling $5.3 million.  Additionally, there were adjustments to estimated sub-lease income to be received related to the future obligations for non-cancelable lease payments in the amount of $1.7 million and accelerated depreciation of leasehold improvements and fixed assets in the amount of $2.6 million.

[0001564590-17-008860:mdna:76]
During the three months ended March 31, 2016, we incurred $1.2 million in charges related to amending our facility lease in North Carolina and $0.2 million of adjustments to severance and benefits.  Excess facilities charges included the acceleration of depreciation of leasehold improvements in the amount of $1.2 million, and contract termination charges and other of $1.0 million.  These charges were partially offset by adjustments to the estimated future sublease income at our San Jose facility of $0.3 million.

[0001564590-17-008860:mdna:77]
During the nine months ended March 31, 2016, we incurred $10.0 million in excess facilities charges. Excess facilities charges included $4.4 million of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities, acceleration of depreciation of leasehold improvements of $4.5 million and contract termination charges and professional fees of $1.0 million.

[0001564590-17-008860:mdna:78]
[same as prior period, unchanged from 0001564590-17-000906:mdna:69]

[0001564590-17-008860:mdna:79]
During the three months ended March 31, 2017 and 2016, we recorded $1.2 million and $4.1 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.  The reduction was due to complete amortization of acquired intangibles from the Enterasys acquisition.

[0001564590-17-008860:mdna:80]
During the nine months ended March 31, 2017 and 2016, we recorded $7.5 million and $12.9 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations. The reduction was due to complete amortization of acquired intangibles from the Enterasys acquisition.

[0001564590-17-008860:mdna:81]
[same as prior period, unchanged from 0001564590-17-000906:mdna:72]

[0001564590-17-008860:mdna:82]
During the three and nine months ended March 31, 2017 we recorded $1.2 million and $3.0 million, respectively, in interest expense primarily in connection with our Credit Facility, as amended. We expect our interest expense will increase in future periods due to the higher balances of our Credit Facility, as Amended.

[0001564590-17-008860:mdna:83]
During the three and nine months ended March 31, 2016, we recorded $0.8 million and $2.4 million, respectively, in interest expense primarily in connection with our Credit Facility, as Amended.

[0001564590-17-008860:mdna:84]
Other Income (Expense)

[0001564590-17-008860:mdna:85]
During the three months ended March 31, 2017 and 2016, we recorded expenses of $0.3 million, for both periods, in other expense. The charge was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-17-008860:mdna:86]
During the nine months ended March 31, 2017 and 2016 we recorded income of $0.6 million and $0.8 million, respectively, in other income. The increases for both periods was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-17-008860:mdna:87]
[same as prior period, unchanged from 0001564590-17-000906:mdna:78]

[0001564590-17-008860:mdna:88]
For the three months ended March 31, 2017 and 2016, we recorded an income tax provision of $1.2 million and $0.9 million, respectively. For the nine months ended March 31, 2017 and 2016, we recorded an income tax provision of $3.3 and $3.0 million, respectively.

[0001564590-17-008860:mdna:89]
The income tax provisions for the three months ended March 31, 2017 and 2016 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys and the WLAN Business.

[0001564590-17-008860:mdna:90]
[same as prior period, unchanged from 0001564590-17-000906:mdna:81]

[0001564590-17-008860:mdna:91]
[same as prior period, unchanged from 0001564590-17-000906:mdna:82]

[0001564590-17-008860:mdna:92]
[same as prior period, unchanged from 0001564590-17-000906:mdna:83]

[0001564590-17-008860:mdna:93]
[same as prior period, unchanged from 0001564590-17-000906:mdna:84]

[0001564590-17-008860:mdna:94]
[same as prior period, unchanged from 0001564590-17-000906:mdna:85]

[0001564590-17-008860:mdna:95]
[same as prior period, unchanged from 0001564590-17-000906:mdna:86]

[0001564590-17-008860:mdna:96]
[same as prior period, unchanged from 0001564590-17-000906:mdna:87]

[0001564590-17-008860:mdna:97]
[same as prior period, unchanged from 0001564590-17-000906:mdna:88]

[0001564590-17-008860:mdna:98]
[same as prior period, unchanged from 0001564590-17-000906:mdna:89]

[0001564590-17-008860:mdna:99]
We allocate the purchase price of acquired business’ to the tangible and intangible assets acquired and liabilities assumed, assumed equity awards, as well as to in-process research and development based upon their estimated fair values at the acquisition date.   The purchase price allocation process requires management’s judgment and often involves the use of significant estimates and assumptions, especially at the acquisition date with respect to intangible assets, deferred revenue obligations and equity assumed.

[0001564590-17-008860:mdna:100]
[same as prior period, unchanged from 0001564590-17-000906:mdna:91]

[0001564590-17-008860:mdna:101]
[same as prior period, unchanged from 0001564590-17-000906:mdna:92]

[0001564590-17-008860:mdna:102]
In connection with the purchase price allocations for our acquisitions, we estimate the fair value of deferred revenue using the cost build-up approach.  The cost build-up approach determines the fair value by estimating the costs related to fulfilling the obligations plus a normal profit margin.  The estimated costs to fulfill the obligations are based on historical costs and benchmarking analysis.

[0001564590-17-008860:mdna:103]
[same as prior period, unchanged from 0001564590-17-000906:mdna:95]

[0001564590-17-008860:mdna:104]
[same as prior period, unchanged from 0001564590-17-000906:mdna:96]

[0001564590-17-008860:mdna:105]
[same as prior period, unchanged from 0001564590-17-000906:mdna:97]

[0001564590-17-008860:mdna:106]
[same as prior period, unchanged from 0001564590-17-000906:mdna:98]

[0001564590-17-008860:mdna:107]
[same as prior period, unchanged from 0001564590-17-000906:mdna:99]

[0001564590-17-008860:mdna:108]
|  |  | March 31, 2017 |  |  | June 30, 2016 |  |
| Cash and cash equivalent |  | $ | 117,280 |  |  | $ | 94,122 |  |
| Total cash and investments |  | $ | 117,280 |  |  | $ | 94,122 |  |
| Working capital |  | $ | 47,056 |  |  | $ | 17,442 |  |

[0001564590-17-008860:mdna:109]
As of March 31, 2017, our principal sources of liquidity consisted of cash and cash equivalents of $117.3 million, accounts receivable, net of $102.0 million and availability of borrowings from the Revolving Facility of $23.2 million. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment. We believe that our $117.3 million of cash and cash equivalents at March 31, 2017, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-17-008860:mdna:110]
During the three months ended December 31, 2016, we entered into an Amended and Restated Credit Agreement which agreement was subsequently amended on March 2, 2017, by Amendment One to such agreement (collectively the agreement and Amendment One, the “Credit Facility, as Amended”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Facility, as Amended provides for a five-year $90.5 million term loan (“Term”) and a five-year $50.0 million revolving credit facility (“Revolver”), which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Facility, as Amended among other things, amends and restates the Company’s existing credit facility.  The Credit Facility, as Amended is collateralized by substantially all of the assets of the Company.

[0001564590-17-008860:mdna:111]
The Credit Facility, as Amended, contains financial covenants that among other things, require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.

[0001564590-17-008860:mdna:112]
The Credit Facility, as Amended, also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Facility, as Amended, may be accelerated upon certain events of default.  At March 31, 2017, we were in compliance and expect to remain in compliance with the covenants of the Credit Facility, as Amended, and they are not expected to impact our liquidity or capital resources.

[0001564590-17-008860:mdna:113]
[same as prior period, unchanged from 0001564590-17-000906:mdna:105]

[0001564590-17-008860:mdna:114]
[same as prior period, unchanged from 0001564590-17-000906:mdna:106]

[0001564590-17-008860:mdna:115]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2017 |  |  | March 31, 2016 |  |
| Net cash provided by operating activities |  | $ | 43,961 |  |  | $ | 18,913 |  |
| Net cash used in investing activities |  |  | (69,159 | ) |  |  | (2,797 | ) |
| Net cash provided by (used in) financing activities |  |  | 48,328 |  |  |  | (3,665 | ) |
| Foreign currency effect on cash |  |  | 28 |  |  |  | (342 | ) |
| Net increase in cash and cash equivalents |  | $ | 23,158 |  |  | $ | 12,109 |  |

[0001564590-17-008860:mdna:116]
[same as prior period, unchanged from 0001564590-17-000906:mdna:108]

[0001564590-17-008860:mdna:117]
Cash flows provided by operations in the nine months ended March 31, 2017 were $44.0 million due to non-cash expenses of $35.4 million for items such as amortization of intangibles, stock-based compensation expense and depreciation as well as decreases

[0001564590-17-008860:mdna:118]
in inventory, prepaid expenses and other assets and increases in accounts payable, deferred revenues and other current and long-term liabilities.   This was partially offset by the current period's net loss of $20.7 million along with increases in accounts receivable.

[0001564590-17-008860:mdna:119]
Cash flows provided by operations in the nine months ended March 31, 2016, were $18.9 million due to non-cash expenses of $50.9 million such as amortization of intangibles, stock-based compensation expense and depreciation as well as decreases in accounts receivables and was partially offset by the current period's net loss of $29.6 million and decreases in accounts payable and deferred distributor revenues.

[0001564590-17-008860:mdna:120]
[same as prior period, unchanged from 0001564590-17-000906:mdna:111]

[0001564590-17-008860:mdna:121]
Cash flows used in investing activities in the nine months ended March 31, 2017 and 2016 were $69.2 million and $2.8 million, respectively.  For the nine months ended March 31, 2017, cash flows consisted of expenditures of $51.1 million for the WLAN Business acquisition, $10.2 million in deposits in conjunction with a future acquisition and $7.8 million of purchases of property and equipment.  For the nine months ended March 31, 2016, amounts consisted of purchases of property and equipment.

[0001564590-17-008860:mdna:122]
[same as prior period, unchanged from 0001564590-17-000906:mdna:113]

[0001564590-17-008860:mdna:123]
Cash flows provided by financing activities in the nine months ended March 31, 2017 were $48.3 million which consisted of new borrowings of $48.3 million under our Credit Facility, as amended, $9.2 million proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by repayment of debt totaling $7.8 million and $1.3 million of loan fees incurred in connection with the Credit Facility, as amended.

[0001564590-17-008860:mdna:124]
Cash flow used in financing activities in the nine months ended March 31, 2016 were $3.7 million, consisting of $23.1 million of cash used for repayment of debt partial offset by borrowings under the Revolver of $15.0 million and $4.5 million of proceeds from the issuance of shares of our common stock under the ESPP combined with the exercise of stock options and vested and released stock awards, net of taxes paid.

[0001564590-17-008860:mdna:125]
[same as prior period, unchanged from 0001564590-17-000906:mdna:116]

[0001564590-17-008860:mdna:126]
Foreign currency effect on cash increased in the nine months ended March 31, 2017, primarily due to changes in foreign currency exchange rates between the US Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-17-008860:mdna:127]
[same as prior period, unchanged from 0001564590-17-000906:mdna:118]

[0001564590-17-008860:mdna:128]
The following summarizes our contractual obligations as of March 31, 2017, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-17-008860:mdna:129]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 95,976 |  |  | $ | 11,313 |  |  | $ | 36,200 |  |  | $ | 48,463 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 12,234 |  |  |  | 3,952 |  |  |  | 6,053 |  |  |  | 2,229 |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 88,879 |  |  |  | 88,879 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable purchase commitments |  |  | 22,816 |  |  |  | 5,066 |  |  |  | 10,375 |  |  |  | 7,375 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 54,988 |  |  |  | 12,513 |  |  |  | 20,134 |  |  |  | 14,458 |  |  |  | 7,883 |  |
| Other liabilities |  |  | 950 |  |  |  | 200 |  |  |  | 400 |  |  |  | 350 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 275,843 |  |  | $ | 121,923 |  |  | $ | 73,162 |  |  | $ | 72,875 |  |  | $ | 7,883 |  |

[0001564590-17-008860:mdna:130]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $88.9 million as of   March 31, 2017. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-17-008860:mdna:131]
Non-cancelable purchase commitments represent future payments for software and support used in our products.

[0001564590-17-008860:mdna:132]
[same as prior period, unchanged from 0001564590-17-000906:mdna:123]

[0001564590-17-008860:mdna:133]
[same as prior period, unchanged from 0001564590-17-000906:mdna:124]

[0001564590-17-008860:mdna:134]
[same as prior period, unchanged from 0001564590-17-000906:mdna:125]

[0001564590-17-008860:mdna:135]
We did not have any material commitments for capital expenditures as of March 31, 2017.

[0001564590-17-008860:mdna:136]
[same as prior period, unchanged from 0001564590-17-000906:mdna:127]

[0001564590-17-008860:mdna:137]
We did not have any off-balance sheet arrangements as of March 31, 2017.
