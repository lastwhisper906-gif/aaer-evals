# EXTR 8-K — 0001564590-20-048160 filed 2020-10-28

## item codes, every 8-K on or before 2020-10-29

- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2020-10-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-048160:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-20-048160:8k_2_02:2]
extr-ex991_6.htm

[0001564590-20-048160:8k_2_02:3]
Exhibit 99.1

[0001564590-20-048160:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-20-048160:8k_2_02:5]
Extreme Networks Reports First Quarter Fiscal Year 2021 Financial Results

[0001564590-20-048160:8k_2_02:6]
Reports Year-over-Year Growth in Operating Profit and Cash Flow

[0001564590-20-048160:8k_2_02:7]
Company Has Now Paid Down $40 Million in Revolving Debt

[0001564590-20-048160:8k_2_02:8]
SAN JOSE, Calif., October 28, 2020 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its first fiscal quarter ended September 30, 2020.

[0001564590-20-048160:8k_2_02:9]
Fiscal First Quarter Results:

[0001564590-20-048160:8k_2_02:10]
|  | • | Revenue $235.8 million, down 8% year-over-year and up 9% quarter-over-quarter |

[0001564590-20-048160:8k_2_02:11]
|  | • | GAAP EPS $(0.07), up from ($0.31) in Q1 last year |

[0001564590-20-048160:8k_2_02:12]
|  | • | Non-GAAP EPS $0.09, up from $0.07 in Q1 last year |

[0001564590-20-048160:8k_2_02:13]
|  | • | GAAP gross margin 57.3% compared to 53.7% in Q1 last year |

[0001564590-20-048160:8k_2_02:14]
|  | • | Non-GAAP gross margin 60.3% compared to 59.9% in Q1 last year |

[0001564590-20-048160:8k_2_02:15]
|  | • | GAAP operating margin at breakeven compared to (12.6)% in Q1 last year |

[0001564590-20-048160:8k_2_02:16]
|  | • | Non-GAAP operating margin 8.3%, compared to 6.2% in Q1 last year |

[0001564590-20-048160:8k_2_02:17]
|  | • | Net cash provided by operating activities of $24.7 million |

[0001564590-20-048160:8k_2_02:18]
|  | • | Free Cash Flow of $21.7 million |

[0001564590-20-048160:8k_2_02:19]
“Our quarterly results exceeded our outlook across all of our financial metrics. The network is more strategic than ever, delivering valuable data that provides greater intelligence and insights customers can use to drive better outcomes. At Extreme, we make it easier than any other vendor to capture this valuable data and use it productively. We also offer more choice and flexibility for end-to-end solutions in today’s more distributed networking environment. This is elevating Extreme’s competitive position in customer and partner conversations, leading to more opportunities and enhancing our future growth outlook,” stated Ed Meyercord, President and CEO of Extreme.

[0001564590-20-048160:8k_2_02:20]
“Customer adoption of our cloud-based networking solutions drove 20% sequential growth of new subscription bookings of ExtremeCloud IQTM, the fastest growing cloud-managed platform in the industry. During the quarter we had significant customer wins across our portfolio and in our targeted key verticals, including, most notably, our win of Major League Baseball,” concluded Meyercord.

[0001564590-20-048160:8k_2_02:21]
“Stronger execution in each of our geographic regions drove solid sequential growth for the second consecutive quarter. This revenue growth, combined with improved gross margins and reduced operating expenses, resulted in a significant improvement in profitability and cash flow,” stated Remi Thomas, CFO of Extreme.

[0001564590-20-048160:8k_2_02:22]
“We have repaid another $20 million of our revolving credit facility on October 23, leaving a remaining balance at just $15 million. We are off to a good start in Q2 and remain well positioned throughout fiscal 2021 to deliver improving operating leverage and cash flow,” concluded Thomas.

[0001564590-20-048160:8k_2_02:23]
Recent Key Highlights:

[0001564590-20-048160:8k_2_02:24]
|  | • | Extreme was identified as the fastest-growing vendor in Omdia's 2020 Cloud Managed Networking Report. Omdia is a global technology research group established following the merger of the research division of Informa Tech's research brands – Ovum, Heavy Reading, Tractica – and the acquired IHS Markit technology research portfolio. In the report, Omdia found that of the top five vendors in the cloud-managed networking market, Extreme has experienced the largest increase in market share in the past year. |

[0001564590-20-048160:8k_2_02:25]
|  | • | Extreme announced it has integrated Bluetooth® and Bluetooth Low Energy Intrusion Prevention detection capabilities into its Extreme AirDefense™ Wireless Intrusion Prevention System. Extreme has the largest threat detection library in the industry. It was first to offer 24/7/365 Wireless Intrusion Prevention and first to utilize Wi-Fi access points as sensors. By adding Bluetooth and Bluetooth Low Energy to AirDefense, network administrators can use a single platform to address 325+ known threat vectors, as well as growing threats against Bluetooth and BLE devices using proven automated detection, identification, classification, notification, and mitigation capabilities. |

[0001564590-20-048160:8k_2_02:26]
|  | • | ŠKODA AUTO, a leading car manufacturer in the Volkswagen Group, upgraded its network with Extreme's campus networking technology to advance its digital transformation effort. Extreme's solutions, including Extreme Fabric Connect, provide ŠKODA AUTO with a secure, agile, and resilient network which has increased its infrastructure's stability and capacity, as well as staff productivity—helping to maximize business growth and application performance. |

[0001564590-20-048160:8k_2_02:27]
|  | • | Wisconsin Center, a premier convention facility and the host of the 2020 Democratic National Convention, deployed the ExtremeCloud IQ network management platform and high-density Wi-Fi 6 access points to deliver agile, secure, and reliable connectivity throughout its meeting rooms, ballrooms, and exposition center, as well as in its sister venue, the Miller High Life Theatre. Wisconsin Center has additionally leveraged the platform to monetize its network, offering dedicated Wi-Fi for event organizers that need guaranteed bandwidth beyond event connectivity, and pay-as-you go Wi-Fi for public guests. |

[0001564590-20-048160:8k_2_02:28]
|  | • | Kean University, the first post-secondary institution in New Jersey, has selected Extreme campus networking solutions and services to deliver seamless, secure connectivity and enable immersive video conferencing across 40 academic and administrative buildings and residence halls on its main campus. The University will extend Extreme Fabric Connect software already deployed in the network to new ExtremeSwitching technology at its network edge to automate onboarding and management of mobile and network devices, support its shift to new digital teaching and learning initiatives for 11,000 students and staff, and enable contact tracing and proximity sensing. |

[0001564590-20-048160:8k_2_02:29]
|  | • | Hurricane Electric, a global Internet service provider based in California, deployed Extreme data center solutions in its global internet backbone to provide IP transit and layer 2 transport services to over 200 major exchange points and 9,000 networks spanning over 190 countries. Extreme SLX hardware, including the new SLX9740 IPV4/IPV6 internet border router, enable Hurricane |

[0001564590-20-048160:8k_2_02:30]
|  |  | Electric to cost-effectively meet growing demand for high-density 100G transport services while meeting space and power requirements. |

[0001564590-20-048160:8k_2_02:31]
|  | • | Extreme announced the formation of a Corporate Social Responsibility Council to promote sustainable development, corporate philanthropy, and the empowerment of people – both inside and outside the company. To drive this effort, the company named Katy Motiey as the company's first Chief Sustainability Officer, in addition to her current role as Chief Administrative Officer. Extreme also appointed Kimberley Basnight to Head of Diversity and Inclusion, in addition to her role as Chief of Staff/Office of the CEO. |

[0001564590-20-048160:8k_2_02:32]
|  | • | Extreme introduced new universal platforms for its switching and wireless portfolios. The new platforms enable simplified ordering, licensing, and warranty processes, as well as reduced complexity and flexible operations, creating a more effortless experience for customers and minimizing total cost of ownership. |

[0001564590-20-048160:8k_2_02:33]
|  | • | In addition to offering unmatched cloud deployment flexibility, portable licensing across the entire portfolio, unlimited data duration, and industry-leading uptime, Extreme announced it will offer five valuable applications at no additional cost to ExtremeCloud IQ customers with a Pilot subscription, providing IT departments with advanced wireless intrusion protection, location services, IoT management, guest access, and compliance capabilities from a single tool. Subscribers can do more for their organizations without spending additional dollars, while potentially retiring overlay applications used to deliver these services. |

[0001564590-20-048160:8k_2_02:34]
Fiscal Q1 2021 Financial Metrics:

[0001564590-20-048160:8k_2_02:35]
(in millions, except percentages and per share information)

[0001564590-20-048160:8k_2_02:36]
|  |  | Q1 FY'21 |  |  | Q1 FY'20 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 161.4 |  |  | $ | 185.1 |  |  | $ | (23.7 | ) |  |  | (13 | )% |
| Service and subscription |  |  | 74.4 |  |  |  | 70.4 |  |  |  | 4.0 |  |  |  | 6 | % |
| Total net revenue |  | $ | 235.8 |  |  | $ | 255.5 |  |  | $ | (19.7 | ) |  |  | (8 | )% |
| Gross margin |  |  | 57.3 | % |  |  | 53.7 | % |  | 360 bps |  |  | - |  |
| Operating margin |  |  | (0.0 | )% |  |  | (12.6 | )% |  | 1258 bps |  |  | - |  |
| Net loss |  | $ | (8.8 | ) |  | $ | (37.7 | ) |  | $ | 28.9 |  |  |  | 77 | % |
| Net loss per diluted share |  | $ | (0.07 | ) |  | $ | (0.31 | ) |  | $ | 0.24 |  |  |  | 77 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 161.4 |  |  | $ | 185.1 |  |  | $ | (23.7 | ) |  |  | (13 | )% |
| Service and subscription |  |  | 74.4 |  |  |  | 70.4 |  |  |  | 4.0 |  |  |  | 6 | % |
| Total net revenue |  | $ | 235.8 |  |  | $ | 255.5 |  |  | $ | (19.7 | ) |  |  | (8 | )% |
| Gross margin |  |  | 60.3 | % |  |  | 59.9 | % |  | 40 bps |  |  | - |  |
| Operating margin |  |  | 8.3 | % |  |  | 6.2 | % |  | 210 bps |  |  | - |  |
| Net income |  | $ | 11.0 |  |  | $ | 8.9 |  |  | $ | 2.0 |  |  |  | 23 | % |
| Net income per diluted share |  | $ | 0.09 |  |  | $ | 0.07 |  |  | $ | 0.02 |  |  |  | 29 | % |

[0001564590-20-048160:8k_2_02:37]
|  | • | Q1 ending cash balance was $193.1 million, a decrease of $0.8 million from the end of Q4. This was primarily driven by cash usage of $22.8 million for financing activities, related to partial repayment of our revolving credit facility and principal payments on our term loan, along with |

[0001564590-20-048160:8k_2_02:38]
|  |  | $3.0 million for capital expenditures, partially offset by operating cash flow generation of $24.7 million. |

[0001564590-20-048160:8k_2_02:39]
|  | • | Q1 accounts receivable balance was $123.6 million, with days sales outstanding of 48, a decrease of 4 days from Q4 and a decrease of 7 days from Q1 last year. |

[0001564590-20-048160:8k_2_02:40]
|  | • | Q1 ending inventory was $55.8 million, a decrease of $6.8 million from Q4 and a decrease of $26.6 million from Q1 last year. The year-over-year and quarter-over-quarter decreases in inventory largely reflect demand planning considerations, while the sequential decrease is a function of SKU rationalization as we prepare for the introduction of our Universal Platform products. |

[0001564590-20-048160:8k_2_02:41]
|  | • | Q1 ending gross debt* was $396.0 million, a decrease of $24.8 million from the prior quarter. The decrease reflects the principal debt payment of approximately $4.8 million and a payment of $20.0 million on the revolving credit facility. The $16.0 million increase from Q1 last year resulted primarily from the borrowings under the revolving facility partially offset by principal debt payments. Net debt* of $202.9 million decreased by $24.0 million from $226.9 million in Q4. |

[0001564590-20-048160:8k_2_02:42]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow as useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0001564590-20-048160:8k_2_02:43]
| Free Cash Flow | Three Months Ended |  |  |
|  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| Cash flow provided by (used in) operations | $ | 24,745 |  |  | $ | (202 | ) |  |
| Less: PP&E CapEx spending |  | (3,023 | ) |  |  | (5,239 | ) |  |
| Total free cash flow | $ | 21,722 |  |  | $ | (5,441 | ) |  |

[0001564590-20-048160:8k_2_02:44]
*Gross debt is defined as long-term and current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs. Net debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0001564590-20-048160:8k_2_02:45]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 396.0 |  |  | $ | 193.1 |  |  | $ | 202.9 |  |

[0001564590-20-048160:8k_2_02:46]
Business Outlook:

[0001564590-20-048160:8k_2_02:47]
For its second quarter of fiscal 2021, ending December 31, 2020, the Company is targeting:

[0001564590-20-048160:8k_2_02:48]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ2'21 Guidance – GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 235.0 |  |  | $ | 245.0 |  |
| Gross Margin |  | 56.8 | % |  |  | 57.5 | % |
| Operating Expenses | $ | 134.5 |  |  | $ | 137.5 |  |
| Operating Margin |  | (0.4 | )% |  |  | 1.4 | % |
| Net Loss | $ | (9.2 | ) |  | $ | (4.3 | ) |
| Net Loss per basic share | $ | (0.07 | ) |  | $ | (0.03 | ) |
| Shares outstanding used in calculating GAAP EPS | 123.4 |  |  | 123.4 |  |
| FQ2’21 Guidance – Non-GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 235.0 |  |  | $ | 245.0 |  |
| Gross Margin |  | 60.0 | % |  |  | 60.6 | % |
| Operating Expenses | $ | 122.1 |  |  | $ | 125.1 |  |
| Operating Margin |  | 8.0 | % |  |  | 9.5 | % |
| Net Income | $ | 10.6 |  |  | $ | 15.5 |  |
| Net Income per diluted share | $ | 0.09 |  |  | $ | 0.12 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 124.3 |  |  |  | 124.3 |  |

[0001564590-20-048160:8k_2_02:49]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY’21 guidance:

[0001564590-20-048160:8k_2_02:50]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 56.8% - 57.5% |  |  | (0.4)% - 1.4% |  |  | $(0.07) - $(0.03) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.4% |  |  | 2.4% |  |  |  | 0.05 |  |
| Share-based compensation | 0.4% |  |  | 4.3% |  |  |  | 0.08 |  |
| Restructuring | - |  |  | 0.3% |  |  |  | 0.01 |  |
| Amortization of non-product intangibles | 0.3% |  |  | 1.2% |  |  |  | 0.02 |  |
| Non-GAAP | 60.0% - 60.6% |  |  | 8.0% - 9.5% |  |  | $0.09- $0.12 |  |

[0001564590-20-048160:8k_2_02:51]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-20-048160:8k_2_02:52]
Conference Call:

[0001564590-20-048160:8k_2_02:53]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the first fiscal quarter results as well as the business outlook for second fiscal quarter ending December 31, 2020, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for 7 days following the call. The conference call may also be heard by dialing 1 (877) 303-9826 or international 1 (224) 357-2194 with Conference ID # 1042849. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The

[0001564590-20-048160:8k_2_02:54]
encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 1042849. The encore recording will be available for 7 days following the call.

[0001564590-20-048160:8k_2_02:55]
About Extreme:

[0001564590-20-048160:8k_2_02:56]
Extreme Networks, Inc. (EXTR) creates effortless networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website or follow us on Twitter, LinkedIn, and Facebook.

[0001564590-20-048160:8k_2_02:57]
Extreme Networks, the Extreme Networks logo, ExtremeCloud IQ, and Extreme Fabric Connect, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries.   The Bluetooth® word mark is a registered trademark owned by the Bluetooth SIG, Inc. and any use of such mark by Extreme Networks is under license.  Other trademarks shown herein are the property of their respective owners.

[0001564590-20-048160:8k_2_02:58]
Non-GAAP Financial Measures:

[0001564590-20-048160:8k_2_02:59]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, inventory valuation adjustment, and restructuring charges.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-20-048160:8k_2_02:60]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-20-048160:8k_2_02:61]
Forward Looking Statements:

[0001564590-20-048160:8k_2_02:62]
looking statements as a result of certain factors, including: our failure to achieve targeted revenues and forecasted demand from end customers; a highly competitive business environment for network switching equipment and cloud management of network devices; our effectiveness in controlling expenses; the possibility that we might experience delays in the development or introduction of new technology and products; customer response to our new technology and products; risks related to pending or future litigation; macroeconomic and political and geopolitical factors, a dependency on third parties for certain components and for the manufacturing of our products; and the impacts of COVID-19, and any worsening of the global business and economic environment as a result, on the Company’s business, financial condition and operating results.

[0001564590-20-048160:8k_2_02:63]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2020, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-20-048160:8k_2_02:64]
###

[0001564590-20-048160:8k_2_02:65]
EXTREME NETWORKS, INC.

[0001564590-20-048160:8k_2_02:66]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-20-048160:8k_2_02:67]
(In thousands, except per share amounts)

[0001564590-20-048160:8k_2_02:68]
(Unaudited)

[0001564590-20-048160:8k_2_02:69]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 193,116 |  |  | $ | 193,872 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,193 and $1,212, respectively |  |  | 123,637 |  |  |  | 122,727 |  |
| Inventories |  |  | 55,830 |  |  |  | 62,589 |  |
| Prepaid expenses and other current assets |  |  | 34,097 |  |  |  | 35,019 |  |
| Total current assets |  |  | 406,680 |  |  |  | 414,207 |  |
| Property and equipment, net |  |  | 55,995 |  |  |  | 58,813 |  |
| Operating lease right-of-use assets, net |  |  | 48,460 |  |  |  | 51,274 |  |
| Intangible assets, net |  |  | 59,903 |  |  |  | 68,394 |  |
| Goodwill |  |  | 331,159 |  |  |  | 331,159 |  |
| Other assets |  |  | 57,297 |  |  |  | 55,241 |  |
| Total assets |  | $ | 959,494 |  |  | $ | 979,088 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,485 and $2,484, respectively |  | $ | 51,515 |  |  | $ | 16,516 |  |
| Accounts payable |  |  | 59,440 |  |  |  | 48,439 |  |
| Accrued compensation and benefits |  |  | 45,529 |  |  |  | 50,884 |  |
| Accrued warranty |  |  | 13,484 |  |  |  | 14,035 |  |
| Current portion, operating lease liabilities |  |  | 19,560 |  |  |  | 19,196 |  |
| Current portion, deferred revenue |  |  | 192,330 |  |  |  | 190,226 |  |
| Other accrued liabilities |  |  | 53,753 |  |  |  | 58,525 |  |
| Total current liabilities |  |  | 435,611 |  |  |  | 397,821 |  |
| Deferred revenue, less current portion |  |  | 105,463 |  |  |  | 100,961 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $6,539 and $7,165, respectively |  |  | 335,461 |  |  |  | 394,585 |  |
| Operating lease liabilities, less current portion |  |  | 46,414 |  |  |  | 50,238 |  |
| Deferred income taxes |  |  | 2,446 |  |  |  | 2,334 |  |
| Other long-term liabilities |  |  | 24,188 |  |  |  | 27,751 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 129,532 and 127,114 shares issued, respectively; 122,935 and 120,517 shares outstanding, respectively |  |  | 130 |  |  |  | 127 |  |
| Additional paid-in-capital |  |  | 1,046,921 |  |  |  | 1,035,041 |  |
| Accumulated other comprehensive loss |  |  | (4,936 | ) |  |  | (6,378 | ) |
| Accumulated deficit |  |  | (989,091 | ) |  |  | (980,279 | ) |
| Treasury stock at cost: 6,597 and 6,597 shares, respectively |  |  | (43,113 | ) |  |  | (43,113 | ) |
| Total stockholders’ equity |  |  | 9,911 |  |  |  | 5,398 |  |
| Total liabilities and stockholders’ equity |  | $ | 959,494 |  |  | $ | 979,088 |  |

[0001564590-20-048160:8k_2_02:70]
EXTREME NETWORKS, INC.

[0001564590-20-048160:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-048160:8k_2_02:72]
(In thousands, except per share amounts)

[0001564590-20-048160:8k_2_02:73]
(Unaudited)

[0001564590-20-048160:8k_2_02:74]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 161,396 |  |  | $ | 185,134 |  |
| Service and subscription |  |  | 74,406 |  |  |  | 70,372 |  |
| Total net revenues |  |  | 235,802 |  |  |  | 255,506 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 73,395 |  |  |  | 91,391 |  |
| Service and subscription |  |  | 27,389 |  |  |  | 26,872 |  |
| Total cost of revenues |  |  | 100,784 |  |  |  | 118,263 |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  |  | 88,001 |  |  |  | 93,743 |  |
| Service and subscription |  |  | 47,017 |  |  |  | 43,500 |  |
| Total gross profit |  |  | 135,018 |  |  |  | 137,243 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 49,524 |  |  |  | 59,116 |  |
| Sales and marketing |  |  | 64,325 |  |  |  | 71,357 |  |
| General and administrative |  |  | 16,461 |  |  |  | 14,982 |  |
| Acquisition and integration costs |  |  | 1,975 |  |  |  | 15,925 |  |
| Restructuring and related charges, net of reversals |  |  | 1,001 |  |  |  | 6,137 |  |
| Amortization of intangibles |  |  | 1,792 |  |  |  | 1,930 |  |
| Total operating expenses |  |  | 135,078 |  |  |  | 169,447 |  |
| Operating loss |  |  | (60 | ) |  |  | (32,204 | ) |
| Interest income |  |  | 118 |  |  |  | 667 |  |
| Interest expense |  |  | (6,663 | ) |  |  | (5,164 | ) |
| Other (expense) income, net |  |  | (887 | ) |  |  | 558 |  |
| Loss before income taxes |  |  | (7,492 | ) |  |  | (36,143 | ) |
| Provision for income taxes |  |  | 1,320 |  |  |  | 1,595 |  |
| Net loss |  | $ | (8,812 | ) |  | $ | (37,738 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |
| Net loss per share - basic and diluted |  | $ | (0.07 | ) |  | $ | (0.31 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 121,705 |  |  |  | 120,226 |  |

[0001564590-20-048160:8k_2_02:75]
EXTREME NETWORKS, INC.

[0001564590-20-048160:8k_2_02:76]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-20-048160:8k_2_02:77]
(In thousands)

[0001564590-20-048160:8k_2_02:78]
(Unaudited)

[0001564590-20-048160:8k_2_02:79]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (8,812 | ) |  | $ | (37,738 | ) |
| Adjustments to reconcile net loss to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 6,727 |  |  |  | 7,101 |  |
| Amortization of intangible assets |  |  | 8,491 |  |  |  | 8,425 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 4,038 |  |  |  | 4,317 |  |
| Provision for doubtful accounts |  |  | - |  |  |  | 401 |  |
| Share-based compensation |  |  | 8,302 |  |  |  | 8,834 |  |
| Deferred income taxes |  |  | 312 |  |  |  | 357 |  |
| Non-cash restructuring and impairment charges |  |  | - |  |  |  | 3,839 |  |
| Non-cash interest expense |  |  | 1,103 |  |  |  | 904 |  |
| Other |  |  | 1,380 |  |  |  | (78 | ) |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (910 | ) |  |  | 33,490 |  |
| Inventories |  |  | 6,628 |  |  |  | (2,108 | ) |
| Prepaid expenses and other assets |  |  | (1,521 | ) |  |  | (486 | ) |
| Accounts payable |  |  | 10,628 |  |  |  | (11,198 | ) |
| Accrued compensation and benefits |  |  | (5,482 | ) |  |  | (10,277 | ) |
| Operating lease liabilities |  |  | (4,812 | ) |  |  | (4,631 | ) |
| Deferred revenue |  |  | 6,607 |  |  |  | 2,001 |  |
| Other current and long-term liabilities |  |  | (7,934 | ) |  |  | (3,355 | ) |
| Net cash provided by (used in) operating activities |  |  | 24,745 |  |  |  | (202 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (3,023 | ) |  |  | (5,239 | ) |
| Business acquisitions, net of cash acquired |  |  | — |  |  |  | (219,458 | ) |
| Maturities and sales of investments |  |  | — |  |  |  | 15,503 |  |
| Net cash used in investing activities |  |  | (3,023 | ) |  |  | (209,194 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 199,500 |  |
| Loan fees on borrowings |  |  | — |  |  |  | (10,515 | ) |
| Payments on debt obligations |  |  | (24,750 | ) |  |  | (20,099 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 3,581 |  |  |  | 4,136 |  |
| Payment of contingent consideration obligations |  |  | (603 | ) |  |  | (635 | ) |
| Deferred payments on an acquisition |  |  | (1,000 | ) |  |  | (1,000 | ) |
| Net cash (used in) provided by financing activities |  |  | (22,772 | ) |  |  | 171,387 |  |
| Foreign currency effect on cash |  |  | 294 |  |  |  | (229 | ) |
| Net decrease in cash |  |  | (756 | ) |  |  | (38,238 | ) |
| Cash at beginning of period |  |  | 193,872 |  |  |  | 169,607 |  |
| Cash and cash equivalents at end of period |  | $ | 193,116 |  |  | $ | 131,369 |  |

[0001564590-20-048160:8k_2_02:80]
Extreme Networks, Inc.

[0001564590-20-048160:8k_2_02:81]
Non-GAAP Measures of Financial Performance

[0001564590-20-048160:8k_2_02:82]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles, (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per diluted share and non-GAAP free cash flow.

[0001564590-20-048160:8k_2_02:83]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme also presents its target for non-GAAP operating expenses, which is operating expenses less share-based compensation expense, restructuring charges and amortization of acquired intangibles.

[0001564590-20-048160:8k_2_02:84]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0001564590-20-048160:8k_2_02:85]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-20-048160:8k_2_02:86]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquired inventory adjustments, acquisition and integration costs, amortization of acquired intangibles, inventory valuation adjustments, and restructuring charges.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-20-048160:8k_2_02:87]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-20-048160:8k_2_02:88]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0001564590-20-048160:8k_2_02:89]
Acquired inventory adjustments. Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-20-048160:8k_2_02:90]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, legal and professional fees related to the acquisition of Aerohive.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-20-048160:8k_2_02:91]
Amortization of acquired intangibles. Amortization of acquired intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-20-048160:8k_2_02:92]
Inventory valuation adjustments. Adjustments relating to the mark down of inventory due to duplication of products lines with acquisition of Aerohive net of recoveries on the sale of inventory marked down in previous quarters.

[0001564590-20-048160:8k_2_02:93]
Restructuring charges. Restructuring charges primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets, long-lived assets and other charges related to excess facilities. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0001564590-20-048160:8k_2_02:94]
Income Taxes. Beginning with our first quarter of fiscal 2021, we are changing how we calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.   Previously, the non-GAAP tax provision consisted of current and deferred income tax expense on a GAAP basis as if our carryforward net operating losses were sufficient to offset our non-GAAP adjustments.   Beginning with our first quarter of fiscal 2021, we have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which consequently, enables our use of research and development tax credits which were previously not utilizable.  The non-GAAP tax provision will now consist of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.2%.  We have adjusted the fiscal 2020 non-GAAP tax provision to reflect the 2020 non-GAAP operating results to be comparable with fiscal 2021 results.  As a result of this change, non-GAAP net income for the first quarter of fiscal 2020 changed from $0.08 per diluted share as previously reported to $0.07 per diluted share.

[0001564590-20-048160:8k_2_02:95]
This change will not affect our non-GAAP income before income taxes, actual cash tax payments or cash flows, but will result in a higher or lower non-GAAP provision for income taxes depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of June 30, 2020, we had U.S. federal net operating loss carryforwards of $287 million and state net operating loss carryforwards of $156 million.  We do not expect to pay substantial taxes on a GAAP basis in the U.S. and certain other foreign jurisdictions for the foreseeable future due to our net operating loss carryforward balances.  Over the near term, most of our cash taxes will continue to be mainly driven by the tax expense of our foreign subsidiaries which amounts have not historically been significant.  We also believe our long-term effective GAAP tax rate will be lower than the U.S. statutory rate based upon our established tax structure.

[0001564590-20-048160:8k_2_02:96]
EXTREME NETWORKS, INC.

[0001564590-20-048160:8k_2_02:97]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-20-048160:8k_2_02:98]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-20-048160:8k_2_02:99]
(In thousands, except percentages and per share amounts)

[0001564590-20-048160:8k_2_02:100]
(Unaudited)

[0001564590-20-048160:8k_2_02:101]
| Revenues | Three Months Ended |  |  |
|  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| Revenues - GAAP | $ | 235,802 |  |  | $ | 255,506 |  |  |

[0001564590-20-048160:8k_2_02:102]
| Non-GAAP Gross Margin | Three Months Ended |  |  |
|  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| Gross profit - GAAP | $ | 135,018 |  |  | $ | 137,243 |  |  |
| Gross margin - GAAP percentage |  | 57.3 | % |  |  | 53.7 | % |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 630 |  |  |  | 597 |  |  |
| Acquired inventory adjustments |  | — |  |  |  | 3,869 |  |  |
| Acquisition and integration costs |  | 10 |  |  |  | 150 |  |  |
| Amortization of intangibles |  | 6,633 |  |  |  | 6,392 |  |  |
| Inventory valuation adjustments |  | — |  |  |  | 4,846 |  |  |
| Total adjustments to GAAP gross profit | $ | 7,273 |  |  | $ | 15,854 |  |  |
| Gross profit - non-GAAP | $ | 142,291 |  |  | $ | 153,097 |  |  |
| Gross margin - non-GAAP percentage |  | 60.3 | % |  |  | 59.9 | % |  |

[0001564590-20-048160:8k_2_02:103]
| Non-GAAP Operating Income | Three Months Ended |  |  |
|  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| GAAP operating loss | $ | (60 | ) |  | $ | (32,204 | ) |  |
| GAAP operating loss percentage |  | (0.0 | )% |  |  | (12.6 | )% |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 630 |  |  |  | 597 |  |  |
| Share-based compensation expense, R&D |  | 2,272 |  |  |  | 2,435 |  |  |
| Share-based compensation expense, S&M |  | 2,647 |  |  |  | 3,719 |  |  |
| Share-based compensation expense, G&A |  | 2,753 |  |  |  | 2,083 |  |  |
| Inventory valuation adjustments |  | — |  |  |  | 4,846 |  |  |
| Acquisition and integration costs |  | 1,985 |  |  |  | 16,075 |  |  |
| Restructuring charges, net of reversals |  | 1,001 |  |  |  | 6,137 |  |  |
| Acquired inventory adjustments |  | — |  |  |  | 3,869 |  |  |
| Amortization of intangibles |  | 8,425 |  |  |  | 8,322 |  |  |
| Total adjustments to GAAP operating loss | $ | 19,713 |  |  | $ | 48,083 |  |  |
| Non-GAAP operating income | $ | 19,653 |  |  | $ | 15,879 |  |  |
| Non-GAAP operating income percentage |  | 8.3 | % |  |  | 6.2 | % |  |

[0001564590-20-048160:8k_2_02:104]
| Non-GAAP Net Income | Three Months Ended |  |  |
|  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| GAAP net loss | $ | (8,812 | ) |  | $ | (37,738 | ) |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 8,302 |  |  |  | 8,834 |  |  |
| Inventory valuation adjustments |  | — |  |  |  | 4,846 |  |  |
| Acquisition and integration costs |  | 1,985 |  |  |  | 16,075 |  |  |
| Restructuring charge, net of reversal |  | 1,001 |  |  |  | 6,137 |  |  |
| Acquired inventory adjustments |  | — |  |  |  | 3,869 |  |  |
| Amortization of intangibles |  | 8,425 |  |  |  | 8,322 |  |  |
| Tax effect of non-GAAP adjustments |  | 58 |  |  |  | (1,435 | ) |  |
| Total adjustments to GAAP net loss | $ | 19,771 |  |  | $ | 46,648 |  |  |
| Non-GAAP net income | $ | 10,959 |  |  | $ | 8,910 |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.09 |  |  | $ | 0.07 |  |  |
| Shares used in net income per share-diluted: |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation - basic and diluted |  | 121,705 |  |  |  | 120,226 |  |  |
| Potentially dilutive equity awards |  | 901 |  |  |  | 3,479 |  |  |
| Non-GAAP diluted shares used in per share calculation |  | 122,606 |  |  |  | 123,705 |  |  |
