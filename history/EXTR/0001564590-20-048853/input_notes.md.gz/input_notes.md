# EXTR notes — 0001564590-20-048853


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-20-048853:notes:1]
[same as prior period, unchanged from 0001564590-20-024274:notes:1]

[0001564590-20-048853:notes:2]
[same as prior period, unchanged from 0001564590-20-024274:notes:2]

[0001564590-20-048853:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2020 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2020.

[0001564590-20-048853:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2020. The results of operations for the three months ended September 30, 2020 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.

[0001564590-20-048853:notes:5]
[same as prior period, unchanged from 0001564590-20-024274:notes:5]

[0001564590-20-048853:notes:6]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2021” or “2021” represent the fiscal year ending June 30, 2021.  All references herein to “fiscal 2020” or “2020” represent the fiscal year ended June 30, 2020.

[0001564590-20-048853:notes:7]
[same as prior period, unchanged from 0001564590-20-024274:notes:7]

[0001564590-20-048853:notes:8]
The unaudited condensed consolidated financial statements include the accounts of Extreme and its wholly owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-20-048853:notes:9]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenues and expenses are translated using the monthly average rate.

[0001564590-20-048853:notes:10]
[same as prior period, unchanged from 0001564590-20-024274:notes:10]

[0001564590-20-048853:notes:11]
[same as prior period, unchanged from 0001564590-20-024274:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-20-048853:notes:12]
[same as prior period, unchanged from 0001564590-20-024274:notes:12]

[0001564590-20-048853:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2020. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-20-048853:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-20-048853:notes:15]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 was effective for fiscal years beginning after December 15, 2019.  The Company adopted the standard on July 1, 2020 and the impact of the adoption was not material to the Company's condensed consolidated financial statements as credit losses are not expected to be significant based on historical collection trends, the financial condition of payment partners, and external market factors.

[0001564590-20-048853:notes:16]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-20-048853:notes:17]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-20-048853:notes:18]
Recently Issued Accounting Pronouncements

[0001564590-20-048853:notes:19]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-048853:notes:20]
| 3. | Revenues |  |

[0001564590-20-048853:notes:21]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-20-048853:notes:22]
[same as prior period, unchanged from 0001564590-20-024274:notes:30]

[0001564590-20-048853:notes:23]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-20-048853:notes:24]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-20-048853:notes:25]
On September 30, 2020, the Company had $297.8 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 54 percent of its deferred revenue as revenue in fiscal 2021, an additional 25 percent in fiscal 2022 and 21 percent of the balance thereafter.

[0001564590-20-048853:notes:26]
[same as prior period, unchanged from 0001564590-20-024274:notes:34]

[0001564590-20-048853:notes:27]
Revenue recognized for the three months ended September 30, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $66.9 million and $53.8 million, respectively.

[0001564590-20-048853:notes:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.7 million and $8.1 million at September 30, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2020 and 2019, was $1.2 million and $1.4 million, respectively.

[0001564590-20-048853:notes:29]
[same as prior period, unchanged from 0001564590-20-024274:notes:37]

[0001564590-20-048853:notes:30]
Revenues by Category

[0001564590-20-048853:notes:31]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

[0001564590-20-048853:notes:32]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |
| Other |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |
| Total Americas |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |
| EMEA |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |
| APAC |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |
| Total net revenues |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |

[0001564590-20-048853:notes:33]
[same as prior period, unchanged from 0001564590-20-024274:notes:43]

[0001564590-20-048853:notes:34]
[same as prior period, unchanged from 0001564590-20-024274:notes:44]

[0001564590-20-048853:notes:35]
The following table sets forth customers accounting for 10% or more of the Company’s net revenues for the periods indicated below:

[0001564590-20-048853:notes:36]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Tech Data Corporation |  | 27% |  |  | 16% |  |
| Jenne Corporation |  | 15% |  |  | 14% |  |
| Westcon Group Inc. |  | 13% |  |  | 10% |  |

[0001564590-20-048853:notes:37]
The following table sets forth customers accounting for 10% or more of the Company’s accounts receivable balance:

[0001564590-20-048853:notes:38]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  |  | 33 | % |  |  | 23 | % |
| Jenne Corporation |  |  | 22 | % |  |  | 25 | % |
| Westcon Group Inc. |  |  | 12 | % |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-20-048853:notes:39]
[same as prior period, unchanged from 0001564590-20-024274:notes:51]

[0001564590-20-048853:notes:40]
Fiscal 2020 Acquisition

[0001564590-20-048853:notes:41]
[same as prior period, unchanged from 0001564590-20-024274:notes:52]

[0001564590-20-048853:notes:42]
On August 9, 2019 (the “Acquisition Date”), the Company consummated its acquisition (the “Acquisition”) of all of the outstanding common stock of Aerohive Networks, Inc. (“Aerohive”) pursuant to that certain Agreement and Plan of Merger entered into as of June 26, 2019.  Under the terms of the Acquisition, the net consideration paid by Extreme to Aerohive stockholders was $267.1 million.

[0001564590-20-048853:notes:43]
The Acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets.  Of the total purchase consideration, $192.6 million was allocated to goodwill, $52.5 million to identifiable intangible assets and the remainder to net tangible assets assumed.  All valuations were finalized as of June 30, 2020.

[0001564590-20-048853:notes:44]
[same as prior period, unchanged from 0001564590-20-024274:notes:69]

[0001564590-20-048853:notes:45]
[same as prior period, unchanged from 0001564590-20-024274:notes:70]

[0001564590-20-048853:notes:46]
The unaudited pro forma financial information for the three months ended September 30, 2019 combines the historical results for Extreme for such periods, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-20-048853:notes:47]
[same as prior period, unchanged from 0001564590-20-024274:notes:73]

[0001564590-20-048853:notes:48]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |
| Net revenues |  | $ | 267,678 |  |
| Net loss |  | $ | (24,084 | ) |
| Net loss per share - basic and diluted |  | $ | (0.20 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 120,226 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-20-048853:notes:49]
[same as prior period, unchanged from 0001564590-20-024274:notes:75]

[0001564590-20-048853:notes:50]
[same as prior period, unchanged from 0001564590-20-024274:notes:76]

[0001564590-20-048853:notes:51]
The Company values its inventory at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company adjusts the carrying value of its inventory when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-20-048853:notes:52]
[same as prior period, unchanged from 0001564590-20-024274:notes:78]

[0001564590-20-048853:notes:53]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Finished goods |  | $ | 48,468 |  |  | $ | 52,879 |  |
| Raw materials |  |  | 7,362 |  |  |  | 9,710 |  |
| Total Inventories |  | $ | 55,830 |  |  | $ | 62,589 |  |

[0001564590-20-048853:notes:54]
[same as prior period, unchanged from 0001564590-20-024274:notes:80]

[0001564590-20-048853:notes:55]
Property and equipment, net consist of the following (in thousands):

[0001564590-20-048853:notes:56]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Computers and equipment |  | $ | 74,275 |  |  | $ | 73,244 |  |
| Purchased software |  |  | 35,942 |  |  |  | 34,015 |  |
| Office equipment, furniture and fixtures |  |  | 10,679 |  |  |  | 10,639 |  |
| Leasehold improvements |  |  | 52,678 |  |  |  | 52,317 |  |
| Total property and equipment |  |  | 173,574 |  |  |  | 170,215 |  |
| Less: accumulated depreciation and amortization |  |  | (117,579 | ) |  |  | (111,402 | ) |
| Property and equipment, net |  | $ | 55,995 |  |  | $ | 58,813 |  |

[0001564590-20-048853:notes:57]
[same as prior period, unchanged from 0001564590-20-024274:notes:83]

[0001564590-20-048853:notes:58]
Deferred revenue represents amounts for deferred maintenance, support, SaaS, and other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001564590-20-048853:notes:59]
[same as prior period, unchanged from 0001564590-20-024274:notes:85]

[0001564590-20-048853:notes:60]
The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-20-048853:notes:61]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2020 and 2019 (in thousands):

[0001564590-20-048853:notes:62]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| Balance beginning of period |  | $ | 14,035 |  |  | $ | 14,779 |  |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | 570 |  |  |
| New warranties issued |  |  | 3,079 |  |  |  | 5,922 |  |  |
| Warranty expenditures |  |  | (3,630 | ) |  |  | (5,283 | ) |  |
| Balance end of period |  | $ | 13,484 |  |  | $ | 15,988 |  |  |

[0001564590-20-048853:notes:63]
To facilitate sales of its products in the normal course of business, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising for intellectual property infringement and certain other losses. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.  It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-20-048853:notes:64]
[same as prior period, unchanged from 0001564590-20-024274:notes:90]

[0001564590-20-048853:notes:65]
Other long-term liabilities consist of the following (in thousands):

[0001564590-20-048853:notes:66]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Acquisition-related deferred payments, less current portion |  | $ | 4,891 |  |  | $ | 5,847 |  |
| Other contractual obligations, less current portion |  |  | 14,715 |  |  |  | 16,722 |  |
| Other |  |  | 4,582 |  |  |  | 5,182 |  |
| Total other long-term liabilities |  | $ | 24,188 |  |  | $ | 27,751 |  |

[0001564590-20-048853:notes:67]
[same as prior period, unchanged from 0001564590-20-024274:notes:93]

[0001564590-20-048853:notes:68]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments. The Company does not invest an amount exceeding 10% of its combined cash and cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-20-048853:notes:69]
[same as prior period, unchanged from 0001564590-20-024274:notes:95]

[0001564590-20-048853:notes:70]
[same as prior period, unchanged from 0001564590-20-024274:notes:96]

[0001564590-20-048853:notes:71]
[same as prior period, unchanged from 0001564590-20-024274:notes:97]

[0001564590-20-048853:notes:72]
[same as prior period, unchanged from 0001564590-20-024274:notes:98]

[0001564590-20-048853:notes:73]
[same as prior period, unchanged from 0001564590-20-024274:notes:99]

[0001564590-20-048853:notes:74]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at September 30, 2020 and June 30, 2020 (in thousands).

[0001564590-20-048853:notes:75]
| September 30, 2020 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | — |  |  | $ | 1,782 |  |  | $ | — |  |  | $ | 1,782 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 1,576 |  |  |  | 1,576 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,782 |  |  | $ | 1,576 |  |  | $ | 3,358 |  |

[0001564590-20-048853:notes:76]
| June 30, 2020 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |
| Interest rate swaps |  |  | — |  |  |  | 1,769 |  |  |  | — |  |  |  | 1,769 |  |
| Acquisition-related contingent consideration obligations |  |  | — |  |  |  | — |  |  |  | 2,167 |  |  |  | 2,167 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 1,777 |  |  | $ | 2,167 |  |  | $ | 3,944 |  |

[0001564590-20-048853:notes:77]
The Company’s financial instruments consist of cash, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0001564590-20-048853:notes:78]
The fair value of derivative instruments under the Company’s foreign exchange forward contracts and interest rate swaps are estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.

[0001564590-20-048853:notes:79]
As of September 30, 2020 and June 30, 2020, the Company had foreign exchange forward contracts with notional principal amount of $7.5 million and $4.0 million, respectively. For the three months ended September 30, 2020, there were gains of less than $0.1 million. There were no foreign exchange forward contracts or related gains or losses for the three months ended September 30, 2019. These contracts have maturities of less than 30 days. Changes in the fair value of these foreign exchange forward contracts are included in other income or expense. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-20-048853:notes:80]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of September 30, 2020 and as of June 30, 2020, the Company had entered into multiple interest rate swap contracts with the total notional amount of $200.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive loss. As of September 30, 2020 and as of June 30, 2020, these contracts had an unrealized loss of $1.8 million. See Note 13, Derivatives and Hedging, for additional information.

[0001564590-20-048853:notes:81]
The fair value of the borrowings under the 2019 Credit Agreement (as defined below) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Since the interest rate is variable in the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $396.0 million and $420.8 million as of September 30, 2020, and June 30, 2020, respectively.

[0001564590-20-048853:notes:82]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.

[0001564590-20-048853:notes:83]
At September 30, 2020 and June 30, 2020, the Company reflected one liability measured at fair value of $1.6 million and $2.2 million, respectively, for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-20-048853:notes:84]
[same as prior period, unchanged from 0001564590-20-024274:notes:108]

[0001564590-20-048853:notes:85]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Beginning balance |  |  | 2,167 |  |  |  | 6,298 |  |
| Payments |  |  | (603 | ) |  |  | (635 | ) |
| Accretion on discount |  |  | 12 |  |  |  | 30 |  |
| Ending balance |  | $ | 1,576 |  |  | $ | 5,693 |  |

[0001564590-20-048853:notes:86]
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three months ended September 30, 2020 and 2019. There were no impairments recorded for the three months ended September 30, 2020 and 2019.

[0001564590-20-048853:notes:87]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income (loss) into earnings using the specific identification method.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-048853:notes:88]
| 7. | Intangible Assets |

[0001564590-20-048853:notes:89]
The following tables summarize the components of gross and net intangible asset balances (dollars in thousands):

[0001564590-20-048853:notes:90]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.2 years |  | $ | 156,100 |  |  | $ | 110,420 |  |  | $ | 45,680 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 50,914 |  |  |  | 12,125 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.2 years |  |  | 10,700 |  |  |  | 9,047 |  |  |  | 1,653 |  |
| License agreements |  | 6.2 years |  |  | 2,445 |  |  |  | 2,000 |  |  |  | 445 |  |
| Other intangibles |  | — years |  |  | 1,382 |  |  |  | 1,382 |  |  |  | — |  |
| Total intangibles, net |  |  |  | $ | 234,066 |  |  | $ | 174,163 |  |  | $ | 59,903 |  |

[0001564590-20-048853:notes:91]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 156,100 |  |  | $ | 103,806 |  |  | $ | 52,294 |  |
| Customer relationships |  | 4.8 years |  |  | 63,039 |  |  |  | 49,598 |  |  |  | 13,441 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.4 years |  |  | 10,700 |  |  |  | 8,554 |  |  |  | 2,146 |  |
| License agreements |  | 5.8 years |  |  | 2,445 |  |  |  | 1,932 |  |  |  | 513 |  |
| Other intangibles |  | — years |  |  | 1,382 |  |  |  | 1,382 |  |  |  | — |  |
| Total intangibles, net |  |  |  | $ | 234,066 |  |  | $ | 165,672 |  |  | $ | 68,394 |  |

[0001564590-20-048853:notes:92]
The amortization expense of intangibles for the periods presented is summarized below (in thousands):

[0001564590-20-048853:notes:93]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| Amortization in “Cost of revenues: Product and Service and subscription” |  | $ | 6,699 |  |  | $ | 6,495 |  |  |
| Amortization of intangibles in "Operations" |  |  | 1,792 |  |  |  | 1,930 |  |  |
| Total amortization expense |  | $ | 8,491 |  |  | $ | 8,425 |  |  |

[0001564590-20-048853:notes:94]
The amortization expense that is recognized in “Cost of revenues: Product and Service and subscription” is comprised of amortization for developed technology, license agreements and other intangibles.


## us-gaap:DebtDisclosureTextBlock

[0001564590-20-048853:notes:95]
| 8. | Debt |

[0001564590-20-048853:notes:96]
The Company’s debt is comprised of the following (in thousands):

[0001564590-20-048853:notes:97]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 19,000 |  |
| Revolving Facility |  | $ | 35,000 |  |  | $ | — |  |
| Less: unamortized debt issuance costs |  |  | (2,485 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 51,515 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 342,000 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (6,539 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 335,461 |  |  |  | 394,585 |  |
| Total debt |  | $ | 386,976 |  |  | $ | 411,101 |  |

[0001564590-20-048853:notes:98]
In connection with the Acquisition discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-20-048853:notes:99]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380 million and a five-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.

[0001564590-20-048853:notes:100]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.40%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-20-048853:notes:101]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0001564590-20-048853:notes:102]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirements and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5%, and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.

[0001564590-20-048853:notes:103]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of September 30, 2020 was 4.85%.

[0001564590-20-048853:notes:104]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.5 million for the three months ended September 30, 2020 and 2019.

[0001564590-20-048853:notes:105]
During the three months ended September 30, 2020, the Company repaid $20.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million.  Although not required under the terms of the 2019 Credit Agreement and amendments, the Company intends to repay the balance of $35.0 million in full under the 2019 Revolving Facility within the next 12 months should market conditions improve, and has classified the remaining balance as a current liability as of September 30, 2020 in the accompanying condensed consolidated balance sheets. The Company has $20.0 million of availability under the 2019 Revolving Facility as of September 30, 2020. In October 2020, the Company repaid another $20.0 million against its 2019 Revolving Credit Facility and has a remaining outstanding balance of $15.0 million.

[0001564590-20-048853:notes:106]
The Company had $7.7 million of outstanding letters of credit as of September 30, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-048853:notes:107]
| 9. | Commitments and Contingencies |

[0001564590-20-048853:notes:108]
Purchase Commitments

[0001564590-20-048853:notes:109]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer

[0001564590-20-048853:notes:110]
procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2020, the Company had commitments to purchase $33.9 million of inventory and other services.

[0001564590-20-048853:notes:111]
Legal Proceedings

[0001564590-20-048853:notes:112]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-20-048853:notes:113]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-20-048853:notes:114]
All currency conversions in this Legal Proceedings section are as of September 30, 2020.

[0001564590-20-048853:notes:115]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-20-048853:notes:116]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is now set for November 23, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-20-048853:notes:117]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-20-048853:notes:118]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents.  After a hearing on January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company.  The matter is proceeding through the appeal process, pursuant to the appeal filed by Orckit on March 13, 2020.

[0001564590-20-048853:notes:119]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that we no longer sell in Germany.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  The Company filed a nullity action with the German Federal Patent Court, seeking to invalidate the asserted patent.  Orckit has filed its substantive reasons for opposing the Company’s nullity action on June 11, 2020.  A hearing was held on September 29, 2020, and the Court issued an infringement decision and injunction against the Company.  The Company is evaluating its options for further proceedings.

[0001564590-20-048853:notes:120]
The Company believes that all claims in both cases filed by Orckit are without merit and intends to defend them vigorously.

[0001564590-20-048853:notes:121]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

[0001564590-20-048853:notes:122]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). A first hearing in the trial was held on July 30, 2020, and the Court held a second hearing for September 4, 2020.  The Court then ordered the parties to retain a third-party appraisal center to analyze and report to the Court on various technical aspects of the case.  The Company believes that the claims are without merit and intends to defend them vigorously.

[0001564590-20-048853:notes:123]
Proven Networks, LLC v. Extreme Networks, Inc.

[0001564590-20-048853:notes:124]
On March 24, 2020, Proven Networks, LLC (“Proven”) filed a patent infringement lawsuit against the Company in the Northern District of California. The lawsuit alleged direct and indirect infringement of three U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of Extreme Analytics Extreme XOS, and certain network devices equipped with the Extreme XOS operating system.  Proven sought injunctive relief, unspecified damages, pre- and post-judgment interest, and attorneys’ fees.  The parties have reached a settlement in this case that was not material and the case was subsequently dismissed.

[0001564590-20-048853:notes:125]
DataCloud Technologies, LLC. v. Extreme Networks, Inc.

[0001564590-20-048853:notes:126]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware.  The lawsuit alleges direct infringement of four U.S. patents based on Company’s shipping, distributing, making, using, importing, offering for sale, and/or selling of Extreme SLX Insight Architecture, Extreme Management Center, ExtremeSwitching switches, and ExtremeCloud Subscription Service.  DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-048853:notes:127]
American Patents LLC v. Extreme Networks, Inc.

[0001564590-20-048853:notes:128]
On August 14, 2020, American Patents LLC filed a patent infringement lawsuit against the Company in the Western District of Texas.  The complaint alleges direct and indirect infringement of certain U.S. patents and seeks injunctive relief, unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  The parties have reached settlement terms for a non-material amount and are finalizing a settlement agreement.

[0001564590-20-048853:notes:129]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0001564590-20-048853:notes:130]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-20-048853:notes:131]
Indemnification Obligations

[0001564590-20-048853:notes:132]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-20-048853:notes:133]
| 10. | Stockholders’ Equity |

[0001564590-20-048853:notes:134]
[same as prior period, unchanged from 0001564590-20-024274:notes:174]

[0001564590-20-048853:notes:135]
[same as prior period, unchanged from 0001564590-20-024274:notes:175]

[0001564590-20-048853:notes:136]
The Company’s Board of Directors (the “Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of shares of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 8, 2020, to extend the Restated Rights Plan through May 31, 2021, subject to ratification by a majority of the stockholders of the Company at the next annual meeting of stockholders.

[0001564590-20-048853:notes:137]
[same as prior period, unchanged from 0001564590-20-024274:notes:177]

[0001564590-20-048853:notes:138]
The Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) to increase the maximum number of available shares by 7.0 million shares.  The amendment was approved by the stockholders at the Company’s annual meeting of stockholders held on November 7, 2019.

[0001564590-20-048853:notes:139]
[same as prior period, unchanged from 0001564590-20-024274:notes:179]

[0001564590-20-048853:notes:140]
The Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan (the “ESPP”) to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares.  The amendment was approved by the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018.

[0001564590-20-048853:notes:141]
[same as prior period, unchanged from 0001564590-20-024274:notes:181]

[0001564590-20-048853:notes:142]
On November 2, 2018, the Company announced the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock over a two-year period from the date of authorization. Purchases may be made from time to time through any means including, but not limited to, open market purchases and privately negotiated transactions.  A maximum of $30.0 million of the Company’s common stock may be repurchased in any calendar year. In February 2020, the Board increased the authorization to repurchase by $40.0 million to $100.0 million and extended the period for repurchase for three years from February 5, 2020.

[0001564590-20-048853:notes:143]
There were no shares repurchased during the three months ended September 30, 2020 and 2019.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-048853:notes:144]
| 11. | Employee Benefit Plans |

[0001564590-20-048853:notes:145]
[same as prior period, unchanged from 0001564590-20-024274:notes:187]

[0001564590-20-048853:notes:146]
The Company had the following reserved shares of common stock for future issuance as of the dates noted (in thousands):

[0001564590-20-048853:notes:147]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 6,431 |  |  |  | 13,118 |  |
| Employee stock options and awards outstanding |  |  | 13,549 |  |  |  | 10,396 |  |
| 2014 Employee Stock Purchase Plan |  |  | 5,913 |  |  |  | 7,364 |  |
| Total shares reserved for issuance |  |  | 25,893 |  |  |  | 30,878 |  |

[0001564590-20-048853:notes:148]
[same as prior period, unchanged from 0001564590-20-024274:notes:192]

[0001564590-20-048853:notes:149]
[same as prior period, unchanged from 0001564590-20-024274:notes:193]

[0001564590-20-048853:notes:150]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Cost of product revenues |  | $ | 258 |  |  | $ | 250 |  |
| Cost of service and subscription revenues |  |  | 372 |  |  |  | 347 |  |
| Research and development |  |  | 2,272 |  |  |  | 2,435 |  |
| Sales and marketing |  |  | 2,647 |  |  |  | 3,719 |  |
| General and administrative |  |  | 2,753 |  |  |  | 2,083 |  |
| Total share-based compensation expense |  | $ | 8,302 |  |  | $ | 8,834 |  |

[0001564590-20-048853:notes:151]
Stock Options

[0001564590-20-048853:notes:152]
The following table summarizes stock option activity for the three months ended September 30, 2020 (in thousands, except per share and contractual term):

[0001564590-20-048853:notes:153]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2020 |  |  | 2,922 |  |  | $ | 4.95 |  |  |  | 3.09 |  |  | $ | 1,688 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (15 | ) |  |  | 4.18 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (81 | ) |  |  | 5.29 |  |  |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2020 |  |  | 2,826 |  |  | $ | 4.95 |  |  |  | 2.94 |  |  | $ | 1,384 |  |
| Vested and expected to vest at September 30, 2020 |  |  | 2,826 |  |  | $ | 4.95 |  |  |  | 2.94 |  |  | $ | 1,384 |  |
| Exercisable at September 30, 2020 |  |  | 1,745 |  |  | $ | 3.97 |  |  |  | 1.44 |  |  | $ | 1,384 |  |

[0001564590-20-048853:notes:154]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the three months ended September 30, 2020. The average fair value of the stock options granted during the three months ended September 30, 2019 was $3.52.

[0001564590-20-048853:notes:155]
[same as prior period, unchanged from 0001564590-20-024274:notes:196]

[0001564590-20-048853:notes:156]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance or market-condition RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the awards’ grant date fair value as of the date of grant.  The Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-20-048853:notes:157]
The following table summarizes stock award activity for the three months ended September 30, 2020 (in thousands, except grant date fair value):

[0001564590-20-048853:notes:158]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2020 |  |  | 7,474 |  |  | $ | 6.83 |  |  |  |  |  |
| Granted |  |  | 5,306 |  |  |  | 4.71 |  |  |  |  |  |
| Released |  |  | (1,453 | ) |  |  | 7.35 |  |  |  |  |  |
| Cancelled |  |  | (604 | ) |  |  | 9.61 |  |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2020 |  |  | 10,723 |  |  | $ | 5.55 |  |  | $ | 43,108 |  |
| Vested and expected to vest at September 30, 2020 |  |  | 10,409 |  |  | $ | 5.52 |  |  | $ | 41,843 |  |

[0001564590-20-048853:notes:159]
The RSU's granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company. The stock awards granted during the three months ended September 30, 2020 included 1,350,000 RSUs including the market condition awards discussed below to named executive officers.

[0001564590-20-048853:notes:160]
Fiscal 2021 Awards

[0001564590-20-048853:notes:161]
On July 27, 2020, the Compensation Committee of the Board granted 475,000 RSUs with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. These MSUs will vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”).  The MSU award represents the right to receive a target number of shares of common stock up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods from August 15, 2020 through August 15, 2023, subject to the grantees’ continued service through the certification of performance.

[0001564590-20-048853:notes:162]
| Level | Relative TSR | Shares Vested |  |
| Below Threshold | TSR is less than the Index by more than 37.5 percentage points | 0% |  |
| Threshold | TSR is less than the Index by 37.5 percentage points | 25% |  |
| Target | TSR equals the Index | 100% |  |
| Maximum | TSR is greater than the Index by 25 percentage points or more | 150% |  |

[0001564590-20-048853:notes:163]
Total shareholder return is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years 1 and 2 and the ability for up to the maximum of the full award to vest based on the full 3-year TSR less any shares vested based on 1 and 2 year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0001564590-20-048853:notes:164]
The grant date fair value of each MSU was determined using the Monte-Carlo simulation model. The weighted-average grant-date fair value of these MSU was $5.32. The assumptions used in the Monte-Carlo simulation included the expected volatility of 69%, risk-free rate of 0.18%, no expected dividend yield, expected term of 3 years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0001564590-20-048853:notes:165]
Fiscal 2018 and 2019 Awards

[0001564590-20-048853:notes:166]
During fiscal 2019 and 2018, the Company approved the grant of 0.6 million shares underlying stock awards each year in the form of restricted stock units with certain performance conditions (“PSUs”) to named executive officers and other vice president level employees. These PSUs would vest once the Company’s U.S. GAAP earnings aggregates at least $0.09 per share over two consecutive quarters (the “Performance Thresholds”). Upon satisfying the Performance Thresholds, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the Performance Thresholds are not met by the third anniversary of the grant date for each award, that award is canceled. The PSUs issued in fiscal 2018 expired and were cancelled during the three months ended September 30, 2020 without the achievement of the Performance Thresholds.  During the three months ended September 30, 2020 and 2019 the Performance Thresholds for outstanding performance PSUs issued in fiscal 2019 were not achieved, and as such, no compensation expense was recorded in either reporting period.

[0001564590-20-048853:notes:167]
The fair value of each share purchase option under the ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of the ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-20-048853:notes:168]
There were 1.5 million and 1.2 million shares issued under the ESPP during the three months ended September 30, 2020 and 2019, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0001564590-20-048853:notes:169]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 0.12 | % |  |  | 1.85 | % |
| Volatility |  |  | 119 | % |  |  | 43 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-20-048853:notes:170]
The weighted-average grant-date fair value of shares issued under the ESPP during the three months ended September 30, 2020 and 2019 was $2.23  and $2.02, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-048853:notes:171]
| 12. | Information about Segments and Geographic Areas |

[0001564590-20-048853:notes:172]
The Company operates in one segment, the development and marketing of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area based on the ship-to location of its customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan. The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-20-048853:notes:173]
See Note 3, Revenues, for the Company’s revenues by geographic regions and channel based on the customer’s ship-to location.

[0001564590-20-048853:notes:174]
[same as prior period, unchanged from 0001564590-20-024274:notes:214]

[0001564590-20-048853:notes:175]
| Long-lived Assets |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Americas |  | $ | 168,844 |  |  | $ | 177,443 |  |
| EMEA |  |  | 36,270 |  |  |  | 39,477 |  |
| APAC |  |  | 16,541 |  |  |  | 16,802 |  |
| Total long-lived assets |  | $ | 221,655 |  |  | $ | 233,722 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-20-048853:notes:176]
| 13. | Derivatives and Hedging |

[0001564590-20-048853:notes:177]
[same as prior period, unchanged from 0001564590-20-024274:notes:217]

[0001564590-20-048853:notes:178]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. Gains and losses recorded in the condensed consolidated statement of operations from these transactions during the three months ended September 30, 2020 were less than $0.1 million. There were no related gains and losses for the three months ended September 30, 2019 as the Company did not have any foreign exchange forward contracts at September 30, 2019.

[0001564590-20-048853:notes:179]
As of September 30, 2020, foreign exchange forward contracts had a notional principal amount of $7.5 million. These contracts have maturities of less than 30 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0001564590-20-048853:notes:180]
The Company recognized total foreign currency losses of $1.2 million and gains $0.6 million for the three months ended September 30, 2020 and 2019, respectively related to the change in fair value of foreign currency denominated assets and liabilities.

[0001564590-20-048853:notes:181]
[same as prior period, unchanged from 0001564590-20-024274:notes:221]

[0001564590-20-048853:notes:182]
[same as prior period, unchanged from 0001564590-20-024274:notes:222]

[0001564590-20-048853:notes:183]
[same as prior period, unchanged from 0001564590-20-024274:notes:223]

[0001564590-20-048853:notes:184]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt.  As of September 30, 2020, the total notional amount of these interest rate swaps was $200.0 million and had maturity dates through April 2023. As of September 30, 2020, these contracts had an unrealized loss of $1.8 million which is recorded in “Accumulated other comprehensive loss” with the associated liability in “Other accrued liabilities” in the condensed consolidated balance sheets and other financial statements. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. The Company did not have any interest rate swaps as of or for the three months ended September 30, 2019. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive loss related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $0.9 million will be reclassified to interest expense over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-048853:notes:185]
| 14. | Restructuring Charges, Net of Reversals, Impairment, and Related Charges. |

[0001564590-20-048853:notes:186]
The Company recorded $1.0 million of restructuring charges, net of reversals and impairments during the three months ended September 30, 2020 which included severance and benefits charges of $0.7 million and facility related charges of $0.3 million. Severance and benefit restructuring charges consisted primarily of additional employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. The Company incurred $8.8 million of charges under the 2020 Plan through September 30, 2020. With the reduction and realignment of the headcount under the 2020 Plan, the Company is relocating certain of its lab test equipment to third-party consulting companies. The Company expects to incur equipment related relocation expenses of approximately $1.0 million related to these activities and expects to substantially complete these activities by the end of fiscal 2021. The facility restructuring charges included additional facilities expenses related to previously impaired facilities.

[0001564590-20-048853:notes:187]
The Company recorded $6.1 million of restructuring charges, net of reversals and impairment during the three months ended September 30, 2019, including charges of $3.9 million for right-of-use assets related to facilities which the Company has exited during the period and employee severance and benefit expenses of $2.2 million incurred under the Company’s restructuring plans initiated in prior years which were complete as of the end of fiscal 2020.

[0001564590-20-048853:notes:188]
Restructuring liabilities related to severance and benefits obligations are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. The following table summarizes the activity related to the severance and benefits related equipment restructuring liabilities during the three months ended September 30, 2020 and 2019 (in thousands):

[0001564590-20-048853:notes:189]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Severance Benefits |  |  | Severance Benefits |  |
| Balance as of June 30, 2020 |  | $ | 2,219 |  |  | $ | 3,559 |  |
| Period charges |  |  | 772 |  |  |  | 2,595 |  |
| Period reversals |  |  | (50 | ) |  |  | (409 | ) |
| Period payments |  |  | (2,639 | ) |  |  | (3,608 | ) |
| Balance as of September 30, 2020 |  | $ | 302 |  |  | $ | 2,137 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-048853:notes:190]
| 15. | Income Taxes |

[0001564590-20-048853:notes:191]
For the three months ended September 30, 2020 and 2019, the Company recorded an income tax provision of $1.3 million and $1.6 million, respectively.

[0001564590-20-048853:notes:192]
The income tax provisions for the three months ended September 30, 2020 and 2019, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes, (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network (“WLAN”) business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade, and (4) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”). The interim income tax provisions for the three months ended September 30, 2020 and 2019 were calculated using the discrete effective tax rate method as allowed by Accounting Standards Codification (“ASC”) 740-270-30-18, “Income Taxes – Interim Reporting.”  The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate.  The discrete method treats the year to date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0001564590-20-048853:notes:193]
On March 27, 2020, the Coronavirus Aid, Relief and Economic Security Act (the “CARES Act”) was signed into law in the United States.  The CARES Act, among other things, includes modifications to net operating loss carryforward provisions and the net interest expense deduction, and deferment of employer social security tax payments.  The Company has evaluated the provisions of the CARES Act and how certain elections may impact its financial position and results of operations, and has determined the enactment of the CARES Act did not have a material impact to the Company’s income tax provision for the three months ended September 30, 2020, or to the Company’s net deferred tax assets as of September 30, 2020.

[0001564590-20-048853:notes:194]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-20-048853:notes:195]
On August 9, 2019, the Company completed its acquisition of Aerohive.  This acquisition was treated as a non-taxable stock acquisition and, therefore, Extreme Networks will have carryover tax basis in the assets and liabilities acquired. During the fourth quarter of fiscal 2020 following the acquisition of Aerohive, the Company realigned the Aerohive related non U.S. intellectual property (“IP”) rights to correspond with the Company’s global operating model.  This transaction resulted in recognition of a $75 million U.S. tax gain

[0001564590-20-048853:notes:196]
which was fully consumed by existing NOLs and the intangibles transferred are being amortized over 10 years for Irish statutory purposes.

[0001564590-20-048853:notes:197]
The Company had $23.8 million of unrecognized tax benefits as of September 30, 2020.  If fully recognized in the future, $0.5 million would impact the effective tax rate and $23.3 million, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-20-048853:notes:198]
[same as prior period, unchanged from 0001564590-20-024274:notes:242]

[0001564590-20-048853:notes:199]
[same as prior period, unchanged from 0001564590-20-024274:notes:243]


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-048853:notes:200]
| 16. | Net Loss Per Share |

[0001564590-20-048853:notes:201]
Basic net loss per share is calculated by dividing net loss by the weighted average number of shares of common stock outstanding during the period. Dilutive loss per share is calculated by dividing net loss by the weighted average number of shares of common stock used in the basic loss per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested RSUs.

[0001564590-20-048853:notes:202]
[same as prior period, unchanged from 0001564590-20-024274:notes:246]

[0001564590-20-048853:notes:203]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |  |
| Net loss |  | $ | (8,812 | ) |  | $ | (37,738 | ) |  |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 121,705 |  |  |  | 120,226 |  |  |
| Net loss per share - basic and diluted |  | $ | (0.07 | ) |  | $ | (0.31 | ) |  |

[0001564590-20-048853:notes:204]
[same as prior period, unchanged from 0001564590-20-024274:notes:248]

[0001564590-20-048853:notes:205]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Options to purchase common stock |  |  | 2,864 |  |  |  | 2,898 |  |
| Restricted stock units |  |  | 8,877 |  |  |  | 9,305 |  |
| Employee Stock Purchase Plan shares |  |  | 750 |  |  |  | 750 |  |
| Total shares excluded |  |  | 12,491 |  |  |  | 12,953 |  |
