# EXTR MD&A — 0001564590-20-048853


## mdna

[0001564590-20-048853:mdna:1]
[same as prior period, unchanged from 0001564590-20-024274:mdna:1]

[0001564590-20-048853:mdna:2]
[same as prior period, unchanged from 0001564590-20-024274:mdna:2]

[0001564590-20-048853:mdna:3]
[same as prior period, unchanged from 0001564590-20-024274:mdna:3]

[0001564590-20-048853:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”), is a leader in providing cloud-driven networking solutions for enterprise, data center, and service provider customers. Providing a combined end-to-end solution from the Internet of Things (“IoT”) edge to the cloud, Extreme designs, develops, and manufactures wired and wireless network infrastructure equipment as well as designs and develops a leading cloud networking platform and application portfolio using cloud management, machine learning, and artificial intelligence to deliver network policy, analytics, security, and access controls. Extreme cloud-driven technologies provide flexibility and scalability in deployment, management, and licensing of networks globally, and the global cloud footprint provides service to over 50,000 customers and over 10 million daily users. Our corporate headquarters are located in San Jose, California. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. We derive substantially all of our revenues from the sale of our networking equipment, software, and related maintenance contracts.

[0001564590-20-048853:mdna:5]
Extreme delivers cloud-driven solutions from the IoT edge to the cloud that are agile, adaptive, and secure to enable autonomous enterprises of the future. We recognize that every customer environment is unique with its own requirements, which may be industry-specific or site driven. Extreme gives customers and partners the power to mix and match a broad array of software, hardware, and services (including third-party applications) to create a custom network that can be managed and automated from end-to-end and enabled with intelligence and assurance from the cloud. With this strategic asset in place, organizations have the foundation needed to drive both digital transformation and the outcomes impacting each one of us.

[0001564590-20-048853:mdna:6]
We believe our 100% in-sourced services and support are number one in the industry, and even as we increase the breadth of our portfolio and scale our organization, we remain nimble and responsive to ensure customer and partner success. We are relentless in our commitment to our over 50,000 customers around the world, including some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing, and provide the building blocks that drive competitive advantage, accelerate innovation, and improve the human experience.

[0001564590-20-048853:mdna:7]
Enterprise network administrators need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business, and the ever-present need for network security. In January 2020, an outbreak of a new strain of coronavirus, COVID-19, was identified in Wuhan, China. Through the first calendar quarter of 2020, the disease became widespread around the world, and on March 11, 2020, the World Health Organization declared the outbreak a pandemic. Particularly in 2020, COVID-19 has accelerated digital transformation efforts for organizations everywhere, driving rapid adoption of new cloud technologies to support remote working and online learning. For organizations bringing employees back to work and students back into schools, technology drivers such as IoT, robotics automation, occupancy management, and contact tracing applications have a profound effect across the entire enterprise network by placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, security, and analytics of the enterprise networks they manage.

[0001564590-20-048853:mdna:8]
Improving the network experience for enterprises that increasingly require greater simplification at the edge or the access layer of the network remains a key focus for Extreme. In fiscal 2020, we augmented our cloud and infrastructure offerings by closing the acquisition of Aerohive Networks, which allowed us to focus our product and go-to-market strategy on delivering ease and simplicity in deployment, management, licensing, and operation of networking, with a particular emphasis on Wi-Fi, security, and analytics. Cloud-Driven Networking positions us to deliver effortless experiences to organizations of various sizes by combining our software-driven applications with machine learning and artificial intelligence to assist in collecting data to build, secure, and maintain agile and distributed environments. In addition, we are the only major vendor who can provide these enterprise-class capabilities in public cloud, private cloud, and on-premises deployment options with a single, unified license and end-to-end portfolio.

[0001564590-20-048853:mdna:9]
We have chosen to focus on enterprise cloud networking based on compelling benefits we believe we can offer our customers. Legacy approaches to network management have relied on complex enterprise applications that customers must install, integrate, maintain, and administer. New releases were infrequent, and updates installed by customers even less frequent. In contrast, our cloud-based ExtremeCloud IQ application provides a single, integrated management view across the entire network that a customer can access from virtually anywhere. We maintain and administer the network management application in global regional data centers from Amazon Web Services (“AWS”), Google Cloud Platform (“GCP”), and Microsoft Azure, delivering the industry’s only completely cloud-agnostic network management application which users then access as a subscription service that can be regularly updated in response to new features or urgent changes.

[0001564590-20-048853:mdna:10]
[same as prior period, unchanged from 0001564590-20-024274:mdna:10]

[0001564590-20-048853:mdna:11]
We are focused on delivering cloud-driven end-to-end networking and software solutions for today’s enterprise environments. From wireless and wired access technologies, through the campus, core, and into the datacenter, Extreme is developing solutions to deliver outstanding business outcomes for our customers. Leveraging a unified management approach, both on premises and in the cloud, we continue to accelerate adoption and delivery of new technologies in support of emerging trends in enterprise networking. We continue to execute on our growth objectives by seeking to maximize customer, partner, and stockholder value. As we advance our strategy to transition our business to subscription-oriented Cloud solutions, we also plan to change the mix of our revenues to a more recurring basis.

[0001564590-20-048853:mdna:12]
In fiscal 2017, we completed the acquisition of the Wireless Local Area Network (“WLAN”) Business from Zebra Technologies. In fiscal 2018, we completed the acquisitions of the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In August 2019, we acquired the entire Cloud Networking portfolio from Aerohive. These acquisitions support our growth strategy to lead the enterprise network equipment market with end-to-end software-driven cloud and on-premises solutions for enterprise customers from the data center to the wireless edge.  After the closing of the acquisitions of the Campus Fabric Business and Data Center Business, Extreme immediately became a networking industry leader with more than 30,000 customers. In addition, the acquisition of Aerohive brought us more than 20,000 additional customers and solidified our position as the second-ranked cloud networking provider globally. As a network switching leader in enterprise, datacenter, and cloud, we combine and extend our world-class products and technologies to provide customers with some of the most advanced, high performance and open solutions in the market as well as a superb overall customer experience. Extreme brings together distinct strengths addressing the key areas of the network, from unified wired and wireless edge, to the enterprise core, to the data center to offer a complete, unified portfolio of cloud-driven network access solutions.

[0001564590-20-048853:mdna:13]
[same as prior period, unchanged from 0001564590-20-024274:mdna:13]

[0001564590-20-048853:mdna:14]
[same as prior period, unchanged from 0001564590-20-024274:mdna:14]

[0001564590-20-048853:mdna:15]
[same as prior period, unchanged from 0001564590-20-024274:mdna:15]

[0001564590-20-048853:mdna:16]
[same as prior period, unchanged from 0001564590-20-024274:mdna:16]

[0001564590-20-048853:mdna:17]
[same as prior period, unchanged from 0001564590-20-024274:mdna:17]

[0001564590-20-048853:mdna:18]
[same as prior period, unchanged from 0001564590-20-024274:mdna:18]

[0001564590-20-048853:mdna:19]
27

[0001564590-20-048853:mdna:20]
|  | • | Provide the industry’s most differentiated end-to-end cloud architecture. Cloud technologies have evolved significantly over the past decade, from monolithic software images hosted remotely to microservices providing machine learning insights continuous integration and delivery of new features. We believe we deliver unrivaled innovation, reliability, and security with the leading end-to-end cloud management platform powered by machine learning (“ML”) and artificial intelligence (“AI”) that spans from the IoT edge to the enterprise data center. Key characteristics of our cloud architecture include being deployment agnostic, device agnostic and focus on the power of network data (availability/durability/unlimited) for our customers. |

[0001564590-20-048853:mdna:21]
[same as prior period, unchanged from 0001564590-20-024274:mdna:20]

[0001564590-20-048853:mdna:22]
[same as prior period, unchanged from 0001564590-20-024274:mdna:22]

[0001564590-20-048853:mdna:23]
|  | • | Offer customers choice – cloud or on-premises. We leverage the cloud where it makes sense for our customers and provide on premises solutions where customers need it and have a solution for those that want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what’s going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for bring your own device (“BYOD”) and IoT usage. |

[0001564590-20-048853:mdna:24]
[same as prior period, unchanged from 0001564590-20-024274:mdna:24]

[0001564590-20-048853:mdna:25]
[same as prior period, unchanged from 0001564590-20-024274:mdna:25]

[0001564590-20-048853:mdna:26]
[same as prior period, unchanged from 0001564590-20-024274:mdna:26]

[0001564590-20-048853:mdna:27]
[same as prior period, unchanged from 0001564590-20-024274:mdna:27]

[0001564590-20-048853:mdna:28]
[same as prior period, unchanged from 0001564590-20-024274:mdna:28]

[0001564590-20-048853:mdna:29]
|  | o | A wide range of service providers, such as regional service provider, cloud service provider, internet service providers and mobile service providers are using our products to transport mission critical data over their network infrastructure. |

[0001564590-20-048853:mdna:30]
[same as prior period, unchanged from 0001564590-20-024274:mdna:29]

[0001564590-20-048853:mdna:31]
|  | • | Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience and our operating systems - the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud. Furthermore, our network operating systems, our primary merchant silicon vendor Broadcom, and select manufacturing partners permit us to leverage our engineering investment. We have invested in engineering resources to create leading-edge technologies to increase the performance and functionality of our products, and as a direct result, the value of our solution to our current and future customers. We look for maximum synergies from our engineering investment in our targeted verticals. |

[0001564590-20-048853:mdna:32]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The increase in demand being seen today, fueled by more users with multiple devices, increases the expectation that everything will just work. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending |

[0001564590-20-048853:mdna:33]
|  |  | migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our cloud architecture with machine learning and AI-driven insights. |

[0001564590-20-048853:mdna:34]
[same as prior period, unchanged from 0001564590-20-024274:mdna:32]

[0001564590-20-048853:mdna:35]
|  | • | Offer a superior quality of experience. Our network-powered application analytics provide actionable business insight by capturing and analyzing context-based data about the network and applications to deliver meaningful intelligence about applications, users, locations and devices. With an easy to comprehend dashboard, our applications help businesses turn their network into a strategic business asset that helps executives make faster and more effective decisions. |

[0001564590-20-048853:mdna:36]
[same as prior period, unchanged from 0001564590-20-024274:mdna:34]

[0001564590-20-048853:mdna:37]
[same as prior period, unchanged from 0001564590-20-024274:mdna:35]

[0001564590-20-048853:mdna:38]
[same as prior period, unchanged from 0001564590-20-024274:mdna:36]

[0001564590-20-048853:mdna:39]
|  | • | Expand market penetration by targeting high-growth market segments. Within the Campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our Data Center approach leverages our product portfolio to address the needs of public and private Cloud Data Center providers. Within the Campus, we also target the high-growth physical security market, converging technologies such as Internet Protocol (“IP”) video across a common Ethernet infrastructure in conjunction with technology partners. Cloud networking compound annual growth rate will continue to outpace on premises managed networking and our focus is on expanding our technology foothold in this key segment with the acquisition of Aerohive to accelerate not only cloud management adoption, but also subscription-based licensing (SaaS) consumption. |

[0001564590-20-048853:mdna:40]
[same as prior period, unchanged from 0001564590-20-024274:mdna:38]

[0001564590-20-048853:mdna:41]
|  | • | Maintain and extend our strategic relationships. We have established strategic relationships with a number of industry-leading vendors to both provide increased and enhanced routes to market, but also to collaboratively develop unique solutions. We announced in October 2019, that we were selected by Broadcom, the industry’s largest merchant silicon provider, as a preferred choice for enterprise campus deployments. As a Broadcom preferred choice for enterprise campus networking solutions, Extreme attempts to give enterprise customers and partners powerful security, segmentation, resiliency, policy, telemetry, and performance advantages as they pursue cloud-driven digital transformation with the industry's most simple, secure, and intelligent campus architecture. |

[0001564590-20-048853:mdna:42]
29

[0001564590-20-048853:mdna:43]
[same as prior period, unchanged from 0001564590-20-024274:mdna:40]

[0001564590-20-048853:mdna:44]
[same as prior period, unchanged from 0001564590-20-024274:mdna:41]

[0001564590-20-048853:mdna:45]
|  | • | ExtremeCloud IQTM. ExtremeCloud IQ is a robust cloud management platform that delivers visibility, intelligence, and assurance from the IoT edge to the core. The application helps organizations automate end-to-end network operations, unlock new analytics, scale faster, and secure and optimize the end-user and application experience. |

[0001564590-20-048853:mdna:46]
|  | • | Cloud-Driven end-to-end networking solutions. The acquisition of Aerohive enhances our cloud offering - with ML/AI insights. We believe this breadth of coverage from the edge to the enterprise data center will be unique in the industry, and cloud networking is projected to be the fastest growing segment of the networking industry. |

[0001564590-20-048853:mdna:47]
|  | • | First Cloud Networking solution available on all major cloud providers. Extreme gives customers cloud choice. Unlike our competitors whose solution relies on one cloud platform, our cloud agnostic approach supports AWS, Azure, and GCP. Customers are seeking multi-cloud and distributed cloud options – support for the top three providers is increasingly an expected minimum. |

[0001564590-20-048853:mdna:48]
|  | • | First Cloud Networking company to offer Unlimited Data. Data-driven analytics and insights power operational efficiency, helping customers adapt to unpredictable times. Data fuels ML and AI solutions and shorter periods of Data Duration reduces ML/AI effectiveness. Further, network data is especially useful in occupancy management and proximity tracking type capabilities. Most vendors only provide 30 or 90-day data durations. Extreme offers unlimited data duration for the length of the cloud subscription to improve an organization’s ability to make smarter, more effective business decisions. |

[0001564590-20-048853:mdna:49]
|  | • | Award Winning, Market Defining Fabric Technology. Extreme’s fabric technology delivers the simplicity, security and automation capabilities that businesses demand. Featuring stealth attributes, Automation of services (L2-3, Multicast), Service Mapping to VSNs, End-to-end encapsulation via MacSec, Extension of the LAN without need for complex protocol stacks, Extreme has pioneered the benefits of fabric technology for more than a decade. |

[0001564590-20-048853:mdna:50]
|  | • | Differentiated Security and Privacy (we are ISO 27001 Security Certified). Security and privacy remain a top priority for all businesses. Extreme’s zero-trust approach extends from the network edge, to the data cloud to the public cloud. Our holistic network security solution includes ExtremeCloud IQ security, Fabric Connect, Defender, NAC, Air Defense and more. Unlike networking vendors who rely solely on the ISO certification of the cloud platform, Extreme goes one step further with an independent ISO 27001 certification for ExtremeCloud IQ. ISO 27001 is internationally recognized as providing a best-practice specification for an information security management system (ISMS). Extreme’s unique approach to go beyond just AWS, GCP, and Azure certification levels represents our commitment to robust security, ongoing risk management and protecting sensitive information for our customers and those they serve. |

[0001564590-20-048853:mdna:51]
|  | • | Leading “No 9’s” Reliability and Resiliency. Business continuity has become increasingly important and Extreme provides exceptional results as fully audited continuous operation is a minimum requirement of today’s enterprise network. In April 2020, ExtremeCloud IQ met an operational state of 100% uptime for the last calendar year – evidence of Extreme’s trustworthy operational effectiveness. To our knowledge, no other vendor has made such a claim. |

[0001564590-20-048853:mdna:52]
|  | • | Consumption Flexibility. With declining budgets and uncertainty over the future, Enterprises want greater flexibility in how they purchase networking solutions and more flexible licensing. Extreme offers a range of financing and network purchase options. Our value-based subscription tiers (Connect, Pilot, etc.) provides customers flexibility to grow and they go. Extreme is the only vendor to offer pool-able and portable licenses that can be transferred between products (AP’s, switches etc.) at one fixed price. |

[0001564590-20-048853:mdna:53]
[same as prior period, unchanged from 0001564590-20-024274:mdna:45]

[0001564590-20-048853:mdna:54]
|  | • | Multi-vendor management from a “single pane-of-glass”. Extreme’s Management Center is a single unified management system that is designed to provide visibility, security, and control across the entire network. This can make the network easier to manage and troubleshoot, often with lower operating expenses. Extreme’s software can manage third-party vendors’ network devices, allowing our customers to potentially maximize device lifespan and protect investments. |

[0001564590-20-048853:mdna:55]
[same as prior period, unchanged from 0001564590-20-024274:mdna:48]

[0001564590-20-048853:mdna:56]
[same as prior period, unchanged from 0001564590-20-024274:mdna:49]

[0001564590-20-048853:mdna:57]
30

[0001564590-20-048853:mdna:58]
|  | • | Application-aware Quality of Service and analytics. Extreme has innovative analytic software that enables our customers to see application usage across the network and apply policies to maximize network capabilities. This allows our customers to improve the user experience. |

[0001564590-20-048853:mdna:59]
[same as prior period, unchanged from 0001564590-20-024274:mdna:51]

[0001564590-20-048853:mdna:60]
|  | • | 100% in-sourced tech support. We believe ExtremeWorks delivers best-in-class customer support in the industry with 92% first call resolution through a 100% in-sourced support model. |

[0001564590-20-048853:mdna:61]
|  | • | Strengthens the channel. Extreme sells products primarily through an ecosystem of channel partners, which combine our portfolio elements together to create customized IT solutions for end user customers. |

[0001564590-20-048853:mdna:62]
[same as prior period, unchanged from 0001564590-20-024274:mdna:55]

[0001564590-20-048853:mdna:63]
During the first quarter of fiscal 2021, we achieved the following results:

[0001564590-20-048853:mdna:64]
|  | • | Net revenues of $235.8 million compared to $255.5 million in the first quarter of fiscal 2020. |

[0001564590-20-048853:mdna:65]
|  | • | Product revenues of $161.4 million compared to $185.1 million in the first quarter of fiscal 2020. |

[0001564590-20-048853:mdna:66]
|  | • | Service and subscription revenues of $74.4 million compared to $70.4 million in the first quarter of fiscal 2020. |

[0001564590-20-048853:mdna:67]
|  | • | Total gross margin of 57.3% of net revenues compared to 53.7% of net revenues in the first quarter of fiscal 2020. |

[0001564590-20-048853:mdna:68]
|  | • | Operating loss of $0.1 million compared to operating loss of $32.1 million in the first quarter of fiscal 2020. |

[0001564590-20-048853:mdna:69]
|  | • | Net loss of $8.8 million compared to $37.7 million in the first quarter of fiscal 2020. |

[0001564590-20-048853:mdna:70]
During the first three months of fiscal 2021, we reflected the following results:

[0001564590-20-048853:mdna:71]
|  | • | Cash flow provided by operating activities of $24.7 million compared to cash flow used in operating activities of $0.2 million in the three months ended September 30, 2019. Cash of $193.1 million compared to $193.9 million as of June 30, 2020. |

[0001564590-20-048853:mdna:72]
Events relating to COVID-19

[0001564590-20-048853:mdna:73]
A novel strain of coronavirus emerged in December 2019. This coronavirus, now known as COVID-19, spread around the world and resulted in authorities implementing numerous measures to try to contain the virus, such as travel bans and restrictions, quarantines, shelter-in-place orders and shutdowns and was declared a pandemic in March 2020. COVID-19 has had and we expect will continue to have an adverse effect on our results of operations due to supply chain disruptions and reduced demand for our products. Because if this, we realigned our operations and recorded severance and benefits charges of $5.8 million during the third quarter of our fiscal 2020. Although we expect to reduce research and development and sales and marketing costs for the year ended June 30, 2021 compared to the year ended June 30, 2020, given the uncertainty around the extent and timing of the potential future spread or mitigation of COVID-19 and around the imposition or relaxation of protective measures, we cannot further reasonably estimate the impact of the COVID-19 pandemic on our future results of operations or financial position. See also Part II, Item 1A – Risk Factors.

[0001564590-20-048853:mdna:74]
[same as prior period, unchanged from 0001564590-20-024274:mdna:67]

[0001564590-20-048853:mdna:75]
The following table presents net product and service and subscription revenues for the periods presented (dollars in thousands):

[0001564590-20-048853:mdna:76]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |  | $ Change |  |  | % Change |  |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 161,396 |  |  | $ | 185,134 |  |  | $ | (23,738 | ) |  |  | (12.8 | )% |  |
| Percentage of net revenues |  |  | 68.4 | % |  |  | 72.5 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 74,406 |  |  |  | 70,372 |  |  |  | 4,034 |  |  |  | 5.7 | % |  |
| Percentage of net revenues |  |  | 31.6 | % |  |  | 27.5 | % |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 235,802 |  |  | $ | 255,506 |  |  | $ | (19,704 | ) |  |  | (7.7 | )% |  |

[0001564590-20-048853:mdna:77]
Product revenues decreased $23.7 million or 12.8% for the three months ended September 30, 2020, as compared to the corresponding period of fiscal 2020. The product revenues decline was primarily due to the continued impact of the global outbreak of COVID-19 across all geographies.

[0001564590-20-048853:mdna:78]
Service and subscription revenues increased $4.0 million, or 5.7% for the three months ended September 30, 2020 as compared to the corresponding period in fiscal 2020. The increase in service and subscription revenues was primarily due to growth in subscription revenues.

[0001564590-20-048853:mdna:79]
The following table presents the product and service and subscription, gross profit and the respective gross profit percentages for the periods presented (dollars in thousands):

[0001564590-20-048853:mdna:80]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 88,001 |  |  | $ | 93,743 |  |  | $ | (5,742 | ) |  |  | (6.1 | )% |  |
| Percentage of product revenues |  |  | 54.5 | % |  |  | 50.6 | % |  |  |  |  |  |  |  |  |  |
| Service and subscription |  |  | 47,017 |  |  |  | 43,500 |  |  |  | 3,517 |  |  |  | 8.1 | % |  |
| Percentage of service and subscription revenues |  |  | 63.2 | % |  |  | 61.8 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 135,018 |  |  | $ | 137,243 |  |  | $ | (2,225 | ) |  |  | (1.6 | )% |  |
| Percentage of net revenues |  |  | 57.3 | % |  |  | 53.7 | % |  |  |  |  |  |  |  |  |  |

[0001564590-20-048853:mdna:81]
Product gross profit decreased $5.7 million or 6.1% for the three months ended September 30, 2020, as compared to the corresponding period in fiscal 2020. The decrease in product gross profit was primarily due to lower revenues and higher distribution charges of $2.0 million, which were mainly due to increased freight and tariffs. This was partially offset by lower excess and obsolete inventory charges of $3.8 million, lower expensing of the fair value step-up of inventories acquired from Aerohive of $3.9 million, lower warranty costs of $2.9 million and more favorable manufacturing costs due to cost reduction efforts including a reduction in headcount during the current quarter.

[0001564590-20-048853:mdna:82]
Service and subscription gross profit increased $3.5 million or 8.1% for the three months ended September 30, 2020, as compared to the corresponding period in fiscal 2020. The increases were primarily due to higher level of service and subscription revenues including increased cloud service costs and higher personnel costs due to increased headcount, partially offset by reduced return costs for the three months ended September 30, 2020.

[0001564590-20-048853:mdna:83]
[same as prior period, unchanged from 0001564590-20-024274:mdna:77]

[0001564590-20-048853:mdna:84]
[same as prior period, unchanged from 0001564590-20-024274:mdna:78]

[0001564590-20-048853:mdna:85]
|  |  | Three Months Ended |  |  |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |  | $ Change |  |  | % Change |  |  |  |
| Research and development |  | $ | 49,524 |  |  | $ | 59,116 |  |  | $ | (9,592 | ) |  |  | (16.2 | )% |  |  |
| Sales and marketing |  |  | 64,325 |  |  |  | 71,357 |  |  |  | (7,032 | ) |  |  | (9.9 | )% |  |  |
| General and administrative |  |  | 16,461 |  |  |  | 14,982 |  |  |  | 1,479 |  |  |  | 9.9 | % |  |  |
| Acquisition and integration costs |  |  | 1,975 |  |  |  | 15,925 |  |  |  | (13,950 | ) |  |  | (87.6 | )% |  |  |
| Restructuring and related charges, net of reversals |  |  | 1,001 |  |  |  | 6,137 |  |  |  | (5,136 | ) |  |  | (83.7 | )% |  |  |
| Amortization of intangibles |  |  | 1,792 |  |  |  | 1,930 |  |  |  | (138 | ) |  |  | (7.2 | )% |  |  |
| Total operating expenses |  | $ | 135,078 |  |  | $ | 169,447 |  |  | $ | (34,369 | ) |  |  | (20.3 | )% |  |  |

[0001564590-20-048853:mdna:86]
[same as prior period, unchanged from 0001564590-20-024274:mdna:81]

[0001564590-20-048853:mdna:87]
Research and development expenses consist primarily of personnel costs (which consist of compensation, benefits and share-based compensation), consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-20-048853:mdna:88]
Research and development expenses decreased by $9.6 million or 16.2% for the three months ended September 30, 2020, as compared to the corresponding period in fiscal 2020. The decrease in research and development expenses was due to a $9.5 million decrease in personnel costs primarily due to lower headcount as a result of the cost reduction actions taken in fiscal 2020, a $1.2 million decrease in facility and information technology costs, a $0.9 million decrease in engineering project costs and a $0.5 million decrease in travel and other expenses, partially offset by a $2.5 million increase in professional and contractor fees.

[0001564590-20-048853:mdna:89]
[same as prior period, unchanged from 0001564590-20-024274:mdna:85]

[0001564590-20-048853:mdna:90]
Sales and marketing expenses consist primarily of personnel costs (which consist of compensation, benefits and share-based compensation), as well as trade shows and promotional expenses.

[0001564590-20-048853:mdna:91]
Sales and marketing expenses decreased by $7.0 million or 9.9% for the three months ended September 30, 2020, as compared to the corresponding period in fiscal 2020. The decrease in sales and marketing expenses was primarily due to a $2.3 million decrease in personnel costs, a $3.1 million decrease in travel costs, a $1.4 million decrease in professional and recruiting fees and a $0.6 million decrease in equipment related costs and other expenses, partially offset by a $0.4 million increase in marketing related expenses.

[0001564590-20-048853:mdna:92]
[same as prior period, unchanged from 0001564590-20-024274:mdna:89]

[0001564590-20-048853:mdna:93]
General and administrative expenses consist primarily of personnel costs (which consist of compensation, benefits and share-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001564590-20-048853:mdna:94]
General and administrative expenses increased by $1.5 million or 9.9% for the three months ended September 30, 2020, as compared to the corresponding period in fiscal 2020. The increase in general and administrative expenses was primarily due to a $1.0 million increase in personnel costs, a $0.2 million increase in professional fees, and a $0.7 million increase in facility and information technology costs, partially offset by a $0.4 million decrease in travel and other expenses.

[0001564590-20-048853:mdna:95]
[same as prior period, unchanged from 0001564590-20-024274:mdna:93]

[0001564590-20-048853:mdna:96]
During the three months ended September 30, 2020, we incurred $2.0 million of acquisition and integration costs. Acquisition and integration costs consisted primarily of additional professional fees for system integration and financial services related to the Aerohive acquisition.

[0001564590-20-048853:mdna:97]
During the three months ended September 30, 2019, we incurred $15.9 million of integration costs including a $6.8 million compensation charge for certain Aerohive Executives’ stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts.  Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees.

[0001564590-20-048853:mdna:98]
[same as prior period, unchanged from 0001564590-20-024274:mdna:96]

[0001564590-20-048853:mdna:99]
For the three months ended September 30, 2020, we recorded restructuring charges of $1.0 million.  We continued our reduction-in-force initiative began in the third quarter of fiscal 2020 and recorded related severance and benefits charges of $0.7 million related to the 2020 Plan.  In addition, we had facility-related charges of $0.3 million related to our previously impaired facilities.

[0001564590-20-048853:mdna:100]
For the three months ended September 30, 2019, we recorded restructuring charges of $6.1 million. The charges consisted of excess facility charges of $3.9 million for impairment of right-of-use assets related to our San Jose California and Salem, New Hampshire facilities.  Additionally, we continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and we recorded severance and benefits charges of $2.2 million.

[0001564590-20-048853:mdna:101]
[same as prior period, unchanged from 0001564590-20-024274:mdna:100]

[0001564590-20-048853:mdna:102]
During the three months ended September 30, 2020 and 2019, we recorded $1.8 million and $1.9 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The decrease was primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized, partially offset by an increase from full period amortization of acquired intangibles from the Aerohive acquisition.

[0001564590-20-048853:mdna:103]
[same as prior period, unchanged from 0001564590-20-024274:mdna:103]

[0001564590-20-048853:mdna:104]
During the three months ended September 30, 2020 and 2019, we recorded $6.7 million and $5.2 million, respectively, in interest expense.  The increase in interest expense was primarily driven by higher average loan balances for the period ended September 30, 2020 under our Credit Agreement.

[0001564590-20-048853:mdna:105]
Other (Expense) Income, Net

[0001564590-20-048853:mdna:106]
During the three months ended September 30, 2020 and 2019, we recorded other expense of $0.9 million and other income of $0.6 million, respectively, in other (expense) income, net.  The change for the three months ended September 30, 2020 was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-20-048853:mdna:107]
[same as prior period, unchanged from 0001564590-20-024274:mdna:109]

[0001564590-20-048853:mdna:108]
For the three months ended September 30, 2020 and 2019, we recorded an income tax provision of $1.3 million and $1.6 million, respectively.

[0001564590-20-048853:mdna:109]
The income tax provisions for the three months ended September 30, 2020 and 2019 consisted of (1) taxes on the income of our foreign subsidiaries, (2) foreign withholding taxes, (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business, and (4) state taxes in jurisdictions where we have no remaining state net operating losses.

[0001564590-20-048853:mdna:110]
[same as prior period, unchanged from 0001564590-20-024274:mdna:112]

[0001564590-20-048853:mdna:111]
Our unaudited condensed consolidated financial statements and the related notes included elsewhere in this Report are prepared in accordance with accounting principles generally accepted in the United States. Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under SEC rules and regulations. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, costs and expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. In many instances, we could have reasonably used different accounting estimates, and in other instances changes in the accounting estimates are reasonably likely to occur from period to period. Accordingly, actual results could differ significantly from the estimates made by our management. On an ongoing basis, we evaluate our estimates and assumptions. To the extent that there are material differences between these estimates and actual results, our future financial statement presentation, financial condition, results of operations and cash flows will be affected.

[0001564590-20-048853:mdna:112]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2020, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-20-048853:mdna:113]
[same as prior period, unchanged from 0001564590-20-024274:mdna:115]

[0001564590-20-048853:mdna:114]
[same as prior period, unchanged from 0001564590-20-024274:mdna:117]

[0001564590-20-048853:mdna:115]
[same as prior period, unchanged from 0001564590-20-024274:mdna:118]

[0001564590-20-048853:mdna:116]
[same as prior period, unchanged from 0001564590-20-024274:mdna:119]

[0001564590-20-048853:mdna:117]
[same as prior period, unchanged from 0001564590-20-024274:mdna:120]

[0001564590-20-048853:mdna:118]
[same as prior period, unchanged from 0001564590-20-024274:mdna:121]

[0001564590-20-048853:mdna:119]
The following table summarizes information regarding our cash (in thousands):

[0001564590-20-048853:mdna:120]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Cash |  | $ | 193,116 |  |  | $ | 193,872 |  |

[0001564590-20-048853:mdna:121]
As of September 30, 2020, our principal sources of liquidity consisted of cash of $193.1 million and accounts receivable, net of $123.6 million, and available borrowings under our five-year 2019 Revolving Facility of $20.0 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $193.1 million of cash at September 30, 2020, our cash flow from operations, and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0001564590-20-048853:mdna:122]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its shares of common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in fiscal 2019 and $30.0 million was used for repurchases in fiscal 2020. Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. There were no repurchases in the three months ended September 30, 2020.

[0001564590-20-048853:mdna:123]
In connection with the acquisition of Aerohive as discussed in Note 4 of the accompanying condensed consolidated financial statements, as of August 9, 2019, we amended the 2018 Credit Agreement, which is no longer outstanding, and entered into the 2019 Credit Agreement, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380 million and a five-year revolving loan facility in an aggregate principal amount of $75 million (“2019 Revolving Facility”).  In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests.  On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-20-048853:mdna:124]
[same as prior period, unchanged from 0001564590-20-024274:mdna:127]

[0001564590-20-048853:mdna:125]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-048853:mdna:126]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-20-048853:mdna:127]
On April 8, 2020, we entered into the first amendment to our 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants effective through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires us to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021.  Under the terms of the Second Amendment, we are not permitted to exceed $55.0 million in our outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and we are restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we are in compliance with the original covenants of the 2019 Credit Agreement. We expect to be in compliance with the original terms of the 2019 Credit Agreement prior to June 30, 2021.

[0001564590-20-048853:mdna:128]
[same as prior period, unchanged from 0001564590-20-024274:mdna:131]

[0001564590-20-048853:mdna:129]
[same as prior period, unchanged from 0001564590-20-024274:mdna:132]

[0001564590-20-048853:mdna:130]
[same as prior period, unchanged from 0001564590-20-024274:mdna:133]

[0001564590-20-048853:mdna:131]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Net cash provided by (used in) operating activities |  | $ | 24,745 |  |  | $ | (202 | ) |
| Net cash used in investing activities |  |  | (3,023 | ) |  |  | (209,194 | ) |
| Net cash (used in) provided by financing activities |  |  | (22,772 | ) |  |  | 171,387 |  |
| Foreign currency effect on cash |  |  | 294 |  |  |  | (229 | ) |
| Net decrease in cash and cash equivalents |  | $ | (756 | ) |  | $ | (38,238 | ) |

[0001564590-20-048853:mdna:132]
Net Cash Provided by (Used in) Operating Activities

[0001564590-20-048853:mdna:133]
Cash flows provided by operations in the three months ended September 30, 2020, were $24.7 million, including our net loss of $8.8 million and non-cash expenses of $30.4 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and imputed interest.  Other sources of cash for the period included a decrease in inventory and increases in accounts payable and deferred revenues. This was partially offset by decreases in accrued compensation, other current and long-term liabilities, and operating lease liabilities, and increases in accounts receivables and prepaid expenses and other current assets.

[0001564590-20-048853:mdna:134]
Cash flows used in operations in the three months ended September 30, 2019, were $0.2 million, including our net loss of $37.7 million and non-cash expenses of $34.1 million for items such as amortization of intangibles, amortization of right-of-use assets, share-based compensation, depreciation, restructuring, deferred income taxes and imputed interest.  Other sources of cash for the current quarter included a decrease in accounts receivables and increases in deferred revenues. This was fully offset by decreases in accounts payable, accrued compensation, other current liabilities and operating lease liabilities, and increases in inventories.

[0001564590-20-048853:mdna:135]
[same as prior period, unchanged from 0001564590-20-024274:mdna:138]

[0001564590-20-048853:mdna:136]
Cash flows used in investing activities in the three months ended September 30, 2020 were $3.0 million for the purchases of property and equipment.

[0001564590-20-048853:mdna:137]
Cash flows used in investing activities in the three months ended September 30, 2019 were $209.2 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $5.2 million, which was partially offset by proceeds of $15.5 million related to the maturity of short-term investments.

[0001564590-20-048853:mdna:138]
[same as prior period, unchanged from 0001564590-20-024274:mdna:141]

[0001564590-20-048853:mdna:139]
Cash flows used in financing activities in the three months ended September 30, 2020 were $22.8 million due primarily to debt repayments of $24.8 million, payment of contingent consideration of $0.6 million, and $1.0 million for deferred payments on acquisitions. This was partially offset by $3.6 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options, net of taxes paid on vested and released stock awards.

[0001564590-20-048853:mdna:140]
Cash flows provided by financing activities in the three months ended September 30, 2019 were $171.4 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $4.1 million of proceeds from the issuance of shares of our common stock under our ESPP, the exercise of stock options and net of taxes paid on vested and released stock awards. This was partially offset by debt repayments of $20.1 million, assumed from the Aerohive acquisition, payment of loan fees of $10.5 million, contingent consideration of $0.6 million, and $1.0 million for deferred payments on acquisitions.

[0001564590-20-048853:mdna:141]
[same as prior period, unchanged from 0001564590-20-024274:mdna:145]

[0001564590-20-048853:mdna:142]
Foreign currency effect on cash increased in the three months ended September 30, 2020 and 2019, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound, and the EURO.

[0001564590-20-048853:mdna:143]
[same as prior period, unchanged from 0001564590-20-024274:mdna:147]

[0001564590-20-048853:mdna:144]
The following summarizes our contractual obligations as of September 30, 2020, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-20-048853:mdna:145]
|  |  | Payments due by Period |  |
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 396,000 |  |  | $ | 54,000 |  |  | $ | 66,500 |  |  | $ | 275,500 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 60,742 |  |  |  | 19,278 |  |  |  | 30,460 |  |  |  | 11,004 |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 33,895 |  |  |  | 33,895 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 90,475 |  |  |  | 20,367 |  |  |  | 37,796 |  |  |  | 17,233 |  |  |  | 15,079 |  |
| Lease payments on operating leases |  |  | 72,201 |  |  |  | 16,748 |  |  |  | 36,354 |  |  |  | 10,919 |  |  |  | 8,180 |  |
| Deferred payments for an acquisition |  |  | 10,000 |  |  |  | 4,000 |  |  |  | 6,000 |  |  |  | — |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 1,576 |  |  |  | 1,120 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Other liabilities |  |  | 899 |  |  |  | 129 |  |  |  | 538 |  |  |  | 232 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 665,788 |  |  | $ | 149,537 |  |  | $ | 178,104 |  |  | $ | 314,888 |  |  | $ | 23,259 |  |

[0001564590-20-048853:mdna:146]
[same as prior period, unchanged from 0001564590-20-024274:mdna:150]

[0001564590-20-048853:mdna:147]
[same as prior period, unchanged from 0001564590-20-024274:mdna:151]

[0001564590-20-048853:mdna:148]
Unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecasts. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-20-048853:mdna:149]
[same as prior period, unchanged from 0001564590-20-024274:mdna:153]

[0001564590-20-048853:mdna:150]
[same as prior period, unchanged from 0001564590-20-024274:mdna:154]

[0001564590-20-048853:mdna:151]
[same as prior period, unchanged from 0001564590-20-024274:mdna:155]

[0001564590-20-048853:mdna:152]
Contingent consideration for an acquisition of a capital financing business in December 2017 from Broadcom, at the estimated fair value.  Actual payments could be different.

[0001564590-20-048853:mdna:153]
[same as prior period, unchanged from 0001564590-20-024274:mdna:157]

[0001564590-20-048853:mdna:154]
[same as prior period, unchanged from 0001564590-20-024274:mdna:158]

[0001564590-20-048853:mdna:155]
We did not have any material commitments for capital expenditures as of September 30, 2020.

[0001564590-20-048853:mdna:156]
[same as prior period, unchanged from 0001564590-20-024274:mdna:160]

[0001564590-20-048853:mdna:157]
We did not have any off-balance sheet arrangements as of September 30, 2020.
