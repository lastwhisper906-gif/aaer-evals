# EXTR note change history — 0001564590-20-024274 → 0001564590-20-048853


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer
  (was, 2020-05-11, similarity 0.7614):
[0001564590-20-024274:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2020, the Company had commitments to purchase $37.1 million of inventory and other services.

- added (2020-10-29):
[0001564590-20-048853:note_history:2]
procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2020, the Company had commitments to purchase $33.9 million of inventory and other services.

- changed (2020-10-29):
[0001564590-20-048853:note_history:3]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2020-05-11, similarity 0.9997):
[0001564590-20-024274:note_history:3]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2020-10-29):
[0001564590-20-048853:note_history:4]
All currency conversions in this Legal Proceedings section are as of September 30, 2020.
  (was, 2020-05-11, similarity 0.9375):
[0001564590-20-024274:note_history:4]
All currency conversions in this Legal Proceedings section are as of March 31, 2020.

- changed (2020-10-29):
[0001564590-20-048853:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (“IPR”) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB previously invalidated all asserted claims of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is now set for November 23, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.
  (was, 2020-05-11, similarity 0.7944):
[0001564590-20-024274:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California.  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  In 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims

- changed (2020-10-29):
[0001564590-20-048853:note_history:6]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents.  After a hearing on January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company.  The matter is proceeding through the appeal process, pursuant to the appeal filed by Orckit on March 13, 2020.
  (was, 2020-05-11, similarity 0.6905):
[0001564590-20-024274:note_history:6]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  After a hearing on January 28, 2020, the Court rendered a decision in favor of the Company fully dismissing Orckit’s complaint.  Orckit  filed a notice of appeal on March 13, 2020.

- added (2020-10-29):
[0001564590-20-048853:note_history:7]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that we no longer sell in Germany.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  The Company filed a nullity action with the German Federal Patent Court, seeking to invalidate the asserted patent.  Orckit has filed its substantive reasons for opposing the Company’s nullity action on June 11, 2020.  A hearing was held on September 29, 2020, and the Court issued an infringement decision and injunction against the Company.  The Company is evaluating its options for further proceedings.

- changed (2020-10-29):
[0001564590-20-048853:note_history:8]
The Company believes that all claims in both cases filed by Orckit are without merit and intends to defend them vigorously.
  (was, 2020-05-11, similarity 0.9304):
[0001564590-20-024274:note_history:8]
The Company believes that all claims in both cases are without merit and intends to defend them vigorously.

- added (2020-10-29):
[0001564590-20-048853:note_history:9]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), a Chinese subsidiary of the Company, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.5 million). A first hearing in the trial was held on July 30, 2020, and the Court held a second hearing for September 4, 2020.  The Court then ordered the parties to retain a third-party appraisal center to analyze and report to the Court on various technical aspects of the case.  The Company believes that the claims are without merit and intends to defend them vigorously.

- changed (2020-10-29):
[0001564590-20-048853:note_history:10]
On March 24, 2020, Proven Networks, LLC (“Proven”) filed a patent infringement lawsuit against the Company in the Northern District of California. The lawsuit alleged direct and indirect infringement of three U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of Extreme Analytics Extreme XOS, and certain network devices equipped with the Extreme XOS operating system.  Proven sought injunctive relief, unspecified damages, pre- and post-judgment interest, and attorneys’ fees.  The parties have reached a settlement in this case that was not material and the case was subsequently dismissed.
  (was, 2020-05-11, similarity 0.7817):
[0001564590-20-024274:note_history:10]
On March 24, 2020, Proven Networks, LLC (“Proven”) filed a patent infringement lawsuit against the Company in the Northern District of California. The lawsuit alleges direct and indirect infringement of three U.S. patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of Extreme Analytics Extreme XOS, and certain network devices equipped with the Extreme XOS operating system.  Proven seeks injunctive relief, unspecified damages, pre- and post-judgment interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, the Company cannot estimate at this time the possible loss or range of loss that may result from this action.

- added (2020-10-29):
[0001564590-20-048853:note_history:11]
DataCloud Technologies, LLC. v. Extreme Networks, Inc.

- added (2020-10-29):
[0001564590-20-048853:note_history:12]
On June 5, 2020, DataCloud Technologies, LLC (“DataCloud”) filed a patent infringement lawsuit against the Company in the District of Delaware.  The lawsuit alleges direct infringement of four U.S. patents based on Company’s shipping, distributing, making, using, importing, offering for sale, and/or selling of Extreme SLX Insight Architecture, Extreme Management Center, ExtremeSwitching switches, and ExtremeCloud Subscription Service.  DataCloud seeks injunctive relief, monetary damages, interest, and attorneys’ fees.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- added (2020-10-29):
[0001564590-20-048853:note_history:13]
American Patents LLC v. Extreme Networks, Inc.

- added (2020-10-29):
[0001564590-20-048853:note_history:14]
On August 14, 2020, American Patents LLC filed a patent infringement lawsuit against the Company in the Western District of Texas.  The complaint alleges direct and indirect infringement of certain U.S. patents and seeks injunctive relief, unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees.  The parties have reached settlement terms for a non-material amount and are finalizing a settlement agreement.

- added (2020-10-29):
[0001564590-20-048853:note_history:15]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

- added (2020-10-29):
[0001564590-20-048853:note_history:16]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use their software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- removed (2020-10-29):
[0001564590-20-024274:note_history:17]
of the ’296 patent and ’728 patent and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. The matter has been stayed and a status conference is set for June 8, 2020.  The Company believes the claims are without merit and intends to defend them vigorously.

- removed (2020-10-29):
[0001564590-20-024274:note_history:18]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  The Company filed a nullity action with the German Federal Patent Court, seeking to invalidate the asserted patent.  Orckit has filed its formal opposition to the Company’s nullity action on March 11, 2020.  No hearing has been scheduled yet in this case, which was split from the original.

- removed (2020-10-29):
[0001564590-20-024274:note_history:19]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co.

- removed (2020-10-29):
[0001564590-20-024274:note_history:20]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China.  In each lawsuit, GIA has accused a number of Summit switching products of infringing one of six patents (the “Asserted Patents”). One trial has been postponed, and the trials for the rest of the cases have not yet been scheduled. Additionally, the Company has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of five of the Asserted Patents.  The Company has appealed three of these rulings.  All the claims in one case have been fully invalidated.

- removed (2020-10-29):
[0001564590-20-024274:note_history:21]
The Company disputes GIA’s claims and intends to defend the matter vigorously. Given the uncertainty of litigation and the preliminary stage of the case, the Company cannot estimate at this time the possible loss or range of loss that may result from this action.

- removed (2020-10-29):
[0001564590-20-024274:note_history:22]
On June 20, 2019, Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) filed a patent infringement lawsuit against Aerohive Networks, Inc. (“Aerohive”), its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of a Chinese patent and seeks damages of RMB 10.0 million (USD $1.4 million). The trial originally scheduled for November 15, 2019 has been postponed by the Court, pending the jurisdictional objections filed by Aerohive, and has not yet been rescheduled.  The Court rejected the jurisdictional challenge, which Aerohive is appealing. The Company cannot estimate at this time the possible loss or range of loss that may result from this action.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:23]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2020. The results of operations for the three months ended September 30, 2020 are not necessarily indicative of the results that may be expected for fiscal 2021 or any future periods.
  (was, 2020-05-11, similarity 0.6824):
[0001564590-20-024274:note_history:23]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2020. The results of operations for the three and nine months ended March 31, 2020 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.

- changed (2020-10-29):
[0001564590-20-048853:note_history:24]
The unaudited condensed consolidated financial statements include the accounts of Extreme and its wholly owned subsidiaries. All inter-company accounts and transactions have been eliminated.
  (was, 2020-05-11, similarity 0.9389):
[0001564590-20-024274:note_history:24]
The consolidated financial statements include the accounts of Extreme and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

- changed (2020-10-29):
[0001564590-20-048853:note_history:25]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenues and expenses are translated using the monthly average rate.
  (was, 2020-05-11, similarity 0.9988):
[0001564590-20-024274:note_history:25]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange and revenue and expenses are translated using the monthly average rate.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:26]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2020. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.
  (was, 2020-05-11, similarity 0.8257):
[0001564590-20-024274:note_history:26]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K, except for the adoption of the new lease guidance, new derivatives and hedging guidance and related policies as discussed within these financial statements.

- changed (2020-10-29):
[0001564590-20-048853:note_history:27]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 was effective for fiscal years beginning after December 15, 2019.  The Company adopted the standard on July 1, 2020 and the impact of the adoption was not material to the Company's condensed consolidated financial statements as credit losses are not expected to be significant based on historical collection trends, the financial condition of payment partners, and external market factors.
  (was, 2020-05-11, similarity 0.6174):
[0001564590-20-024274:note_history:27]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2020.  The Company is currently evaluating the impact of this new standard on its condensed consolidated financial statements and related disclosures. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

- changed (2020-10-29):
[0001564590-20-048853:note_history:28]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.
  (was, 2020-05-11, similarity 0.6782):
[0001564590-20-024274:note_history:28]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added.  This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.

- changed (2020-10-29):
[0001564590-20-048853:note_history:29]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard was effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The standard was adopted on July 1, 2020 and did not have a material impact on the Company’s financial statements upon adoption.
  (was, 2020-05-11, similarity 0.7379):
[0001564590-20-024274:note_history:29]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for fiscal years beginning after December 15, 2019, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures. This guidance is effective for the Company’s fiscal year 2021, beginning on July 1, 2020.

- changed (2020-10-29):
[0001564590-20-048853:note_history:30]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year, which is the Company’s fiscal year 2022, beginning on July 1, 2021. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements and related disclosures.
  (was, 2020-05-11, similarity 0.7737):
[0001564590-20-024274:note_history:30]
In December 2019, the FASB issued ASU 2019-12, Income taxes – Simplifying the Accounting for Income Taxes (Topic 740), which reduces the complexity of accounting for income taxes including the removal of certain exceptions to the general principles of ASC 740, Income Taxes, and simplification in several other areas such as accounting for franchise tax (or similar tax) that is partially based on income. This standard is effective for fiscal years beginning after December 15, 2020, including interim periods within the fiscal year. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements and related disclosures.  This guidance is effective for the Company’s fiscal year 2022, beginning on July 1, 2021.

- removed (2020-10-29):
[0001564590-20-024274:note_history:31]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also requires lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

- removed (2020-10-29):
[0001564590-20-024274:note_history:32]
The Company adopted the new standards beginning with its fiscal year 2020. Topic 842 is applied on the modified retrospective method, applying the new standard to all leases existing as of July 1, 2019. The Company adopted the new standard using the effective date of July 1, 2019 as the date of initial application. Consequently, financial information has not been updated, and disclosures required under the new standard will not be provided for dates and periods prior to July 1, 2019.

- removed (2020-10-29):
[0001564590-20-024274:note_history:33]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and provides maintenance and support over a service period which is recognized under ASC Topic 606. See Note 9, Leases, for additional information regarding the Company’s leases.

- removed (2020-10-29):
[0001564590-20-024274:note_history:34]
On July 1, 2019, the Company recognized ROU assets of $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases.

- removed (2020-10-29):
[0001564590-20-024274:note_history:35]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption. During the third quarter of fiscal 2020, the Company entered into interest rate swap agreements to manage its exposure to fluctuations of interest rates associated with its debt.  See Note 14, Derivatives and Hedging, for additional information.

- removed (2020-10-29):
[0001564590-20-024274:note_history:36]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), which allows the reclassification from Additional Other Comprehensive Income (“AOCI”) to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act").  The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI.  This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.

- removed (2020-10-29):
[0001564590-20-024274:note_history:37]
In March 2020, the FASB issued ASU 2020-04, “Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which provides optional expedients and exceptions for applying U.S. GAAP to contracts, hedging relationships and other transactions affected by the discontinuation of the London Interbank Offered Rate (LIBOR) and other interbank offered rates. This guidance is

- removed (2020-10-29):
[0001564590-20-024274:note_history:38]
effective upon issuance and can be applied to applicable contract modifications through December 31, 2022. The Company elected to apply the amendments in this update to eligible hedging relationships existing as of January 1, 2020 or entered into during the three months ended March 31, 2020 in accordance with the transition options available. This guidance did not have any impact upon adoption. The Company will apply this guidance to transactions or modifications of these arrangements as appropriate through transition period.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:39]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 19,000 |  |
| Revolving Facility |  | $ | 35,000 |  |  | $ | — |  |
| Less: unamortized debt issuance costs |  |  | (2,485 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 51,515 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 342,000 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (6,539 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 335,461 |  |  |  | 394,585 |  |
| Total debt |  | $ | 386,976 |  |  | $ | 411,101 |  |
  (was, 2020-05-11, similarity 0.932):
[0001564590-20-024274:note_history:39]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,819 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 351,500 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (6,796 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 399,704 |  |  |  | 169,739 |  |
| Total debt |  | $ | 416,523 |  |  | $ | 178,750 |  |

- changed (2020-10-29):
[0001564590-20-048853:note_history:40]
In connection with the Acquisition discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.
  (was, 2020-05-11, similarity 0.9967):
[0001564590-20-024274:note_history:40]
In connection with the Acquisition as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

- changed (2020-10-29):
[0001564590-20-048853:note_history:41]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380 million and a five-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the Acquisition and for working capital and general corporate purposes.
  (was, 2020-05-11, similarity 0.9567):
[0001564590-20-024274:note_history:41]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the Acquisition and for working capital and general corporate purposes.

- changed (2020-10-29):
[0001564590-20-048853:note_history:42]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.
  (was, 2020-05-11, similarity 0.9854):
[0001564590-20-024274:note_history:42]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

- changed (2020-10-29):
[0001564590-20-048853:note_history:43]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirements and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5%, and the Company is restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company is in compliance with the original covenants of the 2019 Credit Agreement.
  (was, 2020-05-11, similarity 0.8272):
[0001564590-20-024274:note_history:43]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which supersedes the First Amendment and provides certain revised terms and financial covenants through March 31, 2021.  Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement will resume in effect. The Second Amendment requires the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company is not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate will be 4.5% and the Company is restricted  from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company 
is in compliance with the original covenants of the 2019 Credit Agreement.

- changed (2020-10-29):
[0001564590-20-048853:note_history:44]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2020, the Company incurred $10.5 million of deferred financing costs in conjunction with the 2019 Credit Agreement and $1.5 million of deferred financing costs from the amendments, and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility. The interest rate as of September 30, 2020 was 4.85%.
  (was, 2020-05-11, similarity 0.7064):
[0001564590-20-024274:note_history:44]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $10.5 million of deferred financing costs in conjunction with this modification of the debt and continues to amortize $1.6 million of debt issuance costs as of August 9, 2019 that were associated with the previous facility.  The interest rate as of March 31, 2020 was 5.1%.

- changed (2020-10-29):
[0001564590-20-048853:note_history:45]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.8 million and $0.5 million for the three months ended September 30, 2020 and 2019.
  (was, 2020-05-11, similarity 0.7623):
[0001564590-20-024274:note_history:45]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.6 million and $0.2 million for the three months ended March 31, 2020 and 2019, and totaled $1.8 million and $0.5 million for the nine months ended March 31, 2020 and 2019, respectively.

- added (2020-10-29):
[0001564590-20-048853:note_history:46]
During the three months ended September 30, 2020, the Company repaid $20.0 million against its 2019 Revolving Facility’s outstanding balance of $55.0 million.  Although not required under the terms of the 2019 Credit Agreement and amendments, the Company intends to repay the balance of $35.0 million in full under the 2019 Revolving Facility within the next 12 months should market conditions improve, and has classified the remaining balance as a current liability as of September 30, 2020 in the accompanying condensed consolidated balance sheets. The Company has $20.0 million of availability under the 2019 Revolving Facility as of September 30, 2020. In October 2020, the Company repaid another $20.0 million against its 2019 Revolving Credit Facility and has a remaining outstanding balance of $15.0 million.

- changed (2020-10-29):
[0001564590-20-048853:note_history:47]
The Company had $7.7 million of outstanding letters of credit as of September 30, 2020.
  (was, 2020-05-11, similarity 0.9351):
[0001564590-20-024274:note_history:47]
The Company had $7.7 million of outstanding letters of credit as of March 31, 2020.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:48]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 19,000 |  |
| Revolving Facility |  | $ | 35,000 |  |  | $ | — |  |
| Less: unamortized debt issuance costs |  |  | (2,485 | ) |  |  | (2,484 | ) |
| Current portion of long-term debt |  | $ | 51,515 |  |  | $ | 16,516 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 342,000 |  |  | $ | 346,750 |  |
| Revolving Facility |  |  | — |  |  |  | 55,000 |  |
| Less: unamortized debt issuance costs |  |  | (6,539 | ) |  |  | (7,165 | ) |
| Total long-term debt, less current portion |  |  | 335,461 |  |  |  | 394,585 |  |
| Total debt |  | $ | 386,976 |  |  | $ | 411,101 |  |
  (was, 2020-05-11, similarity 0.932):
[0001564590-20-024274:note_history:48]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,819 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 351,500 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | 55,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (6,796 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 399,704 |  |  |  | 169,739 |  |
| Total debt |  | $ | 416,523 |  |  | $ | 178,750 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:49]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):
  (was, 2020-05-11, similarity 0.9969):
[0001564590-20-024274:note_history:49]
The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- changed (2020-10-29):
[0001564590-20-048853:note_history:50]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |
| Other |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |
| Total Americas |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |
| EMEA |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |
| APAC |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |
| Total net revenues |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |
  (was, 2020-05-11, similarity 0.9634):
[0001564590-20-024274:note_history:50]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |
| Other |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |
| Total Americas |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |
| EMEA |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |
| APAC |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |
| Total net revenues |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |

- removed (2020-10-29):
[0001564590-20-024274:note_history:51]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |
| Other |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |
| Total Americas |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |
| EMEA |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |
| APAC |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |
| Total net revenues |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:52]
| 3. | Revenues |  |
  (was, 2020-05-11, similarity 0.6667):
[0001564590-20-024274:note_history:52]
3.Revenues

- changed (2020-10-29):
[0001564590-20-048853:note_history:53]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017.  The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.
  (was, 2020-05-11, similarity 0.8757):
[0001564590-20-024274:note_history:53]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from software delivered as a service (“SaaS”) and service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- changed (2020-10-29):
[0001564590-20-048853:note_history:54]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2020-05-11, similarity 0.6598):
[0001564590-20-024274:note_history:54]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time. For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2020-10-29):
[0001564590-20-048853:note_history:55]
On September 30, 2020, the Company had $297.8 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 54 percent of its deferred revenue as revenue in fiscal 2021, an additional 25 percent in fiscal 2022 and 21 percent of the balance thereafter.

- changed (2020-10-29):
[0001564590-20-048853:note_history:56]
Revenue recognized for the three months ended September 30, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $66.9 million and $53.8 million, respectively.
  (was, 2020-05-11, similarity 0.6444):
[0001564590-20-024274:note_history:56]
Revenue recognized for the three months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $64.3 million and $54.8 million, respectively. Revenue recognized for the nine months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $116.7 million and $110.8 million, respectively.

- changed (2020-10-29):
[0001564590-20-048853:note_history:57]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.7 million and $8.1 million at September 30, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2020 and 2019, was $1.2 million and $1.4 million, respectively.
  (was, 2020-05-11, similarity 0.9276):
[0001564590-20-024274:note_history:57]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.4 million and $6.5 million at March 31, 2020 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2020 and 2019, was $1.1 million and $0.8 million, respectively. Amortization recognized during the nine months ended March 31, 2020 and 2019 was $4.1 million and $2.2 million, respectively.

- changed (2020-10-29):
[0001564590-20-048853:note_history:58]
Revenues by Category
  (was, 2020-05-11, similarity 0.9744):
[0001564590-20-024274:note_history:58]
Revenue by Category

- changed (2020-10-29):
[0001564590-20-048853:note_history:59]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):
  (was, 2020-05-11, similarity 0.9969):
[0001564590-20-024274:note_history:59]
The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- changed (2020-10-29):
[0001564590-20-048853:note_history:60]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |
| Other |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |
| Total Americas |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |
| EMEA |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |
| APAC |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |
| Total net revenues |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |
  (was, 2020-05-11, similarity 0.9634):
[0001564590-20-024274:note_history:60]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |
| Other |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |
| Total Americas |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |
| EMEA |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |
| APAC |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |
| Total net revenues |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |

- changed (2020-10-29):
[0001564590-20-048853:note_history:61]
The following table sets forth customers accounting for 10% or more of the Company’s net revenues for the periods indicated below:
  (was, 2020-05-11, similarity 0.8362):
[0001564590-20-024274:note_history:61]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenues:

- changed (2020-10-29):
[0001564590-20-048853:note_history:62]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Tech Data Corporation |  | 27% |  |  | 16% |  |
| Jenne Corporation |  | 15% |  |  | 14% |  |
| Westcon Group Inc. |  | 13% |  |  | 10% |  |
  (was, 2020-05-11, similarity 0.7892):
[0001564590-20-024274:note_history:62]
|  |  | March 31, 2020 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 11 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 10 | % |  |  | 35 | % |
| Westcon Group Inc. |  |  | 14 | % |  | * |  |

- changed (2020-10-29):
[0001564590-20-048853:note_history:63]
The following table sets forth customers accounting for 10% or more of the Company’s accounts receivable balance:
  (was, 2020-05-11, similarity 0.9739):
[0001564590-20-024274:note_history:63]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable balance:

- added (2020-10-29):
[0001564590-20-048853:note_history:64]
|  |  | September 30, 2020 |  |  | June 30, 2020 |  |
| Tech Data Corporation |  |  | 33 | % |  |  | 23 | % |
| Jenne Corporation |  |  | 22 | % |  |  | 25 | % |
| Westcon Group Inc. |  |  | 12 | % |  | * |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |

- removed (2020-10-29):
[0001564590-20-024274:note_history:65]
On March 31, 2020, the Company had $271.7 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 24 percent of its deferred revenue as revenue in fiscal 2020, an additional 46 percent in fiscal 2021 and 30 percent of the balance thereafter.

- removed (2020-10-29):
[0001564590-20-024274:note_history:66]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |
| Other |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |
| Total Americas |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |
| EMEA |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |
| APAC |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |
| Total net revenues |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |

- removed (2020-10-29):
[0001564590-20-024274:note_history:67]
Included in the above amounts are $2.2 million and $6.9 million of leasing revenue for the three and nine months ended March 31, 2020, respectively.  Included in the above amounts are $2.7 million and $8.6 million of leasing revenue for the three and nine months ended March 31, 2019, respectively.

- removed (2020-10-29):
[0001564590-20-024274:note_history:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| Tech Data Corporation |  | 19% |  |  | 14% |  |  | 16% |  |  | 17% |  |
| Jenne Corporation |  | * |  |  | 21% |  |  | 13% |  |  | 15% |  |
| Westcon Group Inc. |  | 19% |  |  | 12% |  |  | 14% |  |  | 13% |  |

- removed (2020-10-29):
[0001564590-20-024274:note_history:69]
* Less than 10% of net revenue.

- removed (2020-10-29):
[0001564590-20-024274:note_history:70]
* Less than 10% of accounts receivable.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001564590-20-048853:note_history:71]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenues recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2020-05-11, similarity 0.6598):
[0001564590-20-024274:note_history:71]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time. For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2020-10-29):
[0001564590-20-048853:note_history:72]
On September 30, 2020, the Company had $297.8 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues.  The Company expects to recognize approximately 54 percent of its deferred revenue as revenue in fiscal 2021, an additional 25 percent in fiscal 2022 and 21 percent of the balance thereafter.

- changed (2020-10-29):
[0001564590-20-048853:note_history:73]
Revenue recognized for the three months ended September 30, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $66.9 million and $53.8 million, respectively.
  (was, 2020-05-11, similarity 0.6444):
[0001564590-20-024274:note_history:73]
Revenue recognized for the three months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $64.3 million and $54.8 million, respectively. Revenue recognized for the nine months ended March 31, 2020 and 2019 that was included in the deferred revenue balance at the beginning of each period was $116.7 million and $110.8 million, respectively.

- changed (2020-10-29):
[0001564590-20-048853:note_history:74]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $8.7 million and $8.1 million at September 30, 2020 and June 30, 2020, respectively. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended September 30, 2020 and 2019, was $1.2 million and $1.4 million, respectively.
  (was, 2020-05-11, similarity 0.9276):
[0001564590-20-024274:note_history:74]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.4 million and $6.5 million at March 31, 2020 and June 30, 2019, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2020 and 2019, was $1.1 million and $0.8 million, respectively. Amortization recognized during the nine months ended March 31, 2020 and 2019 was $4.1 million and $2.2 million, respectively.

- changed (2020-10-29):
[0001564590-20-048853:note_history:75]
Revenues by Category
  (was, 2020-05-11, similarity 0.9744):
[0001564590-20-024274:note_history:75]
Revenue by Category

- changed (2020-10-29):
[0001564590-20-048853:note_history:76]
The following table sets forth the Company’s revenues disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):
  (was, 2020-05-11, similarity 0.9969):
[0001564590-20-024274:note_history:76]
The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- changed (2020-10-29):
[0001564590-20-048853:note_history:77]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 60,670 |  | $ | 57,347 |  | $ | 118,017 |  |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |
| Other |  |  | 8,241 |  |  | 4,090 |  |  | 12,331 |  |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |
| Total Americas |  |  | 68,911 |  |  | 61,437 |  |  | 130,348 |  |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |
| EMEA |  |  | 47,529 |  |  | 33,576 |  |  | 81,105 |  |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |
| APAC |  |  | 5,051 |  |  | 19,298 |  |  | 24,349 |  |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |
| Total net revenues |  | $ | 121,491 |  | $ | 114,311 |  | $ | 235,802 |  |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |
  (was, 2020-05-11, similarity 0.9634):
[0001564590-20-024274:note_history:77]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 38,666 |  | $ | 56,391 |  | $ | 95,057 |  |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |
| Other |  |  | 3,277 |  |  | 5,781 |  |  | 9,058 |  |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |
| Total Americas |  |  | 41,943 |  |  | 62,172 |  |  | 104,115 |  |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |
| EMEA |  |  | 49,979 |  |  | 33,630 |  |  | 83,609 |  |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |
| APAC |  |  | 3,242 |  |  | 18,553 |  |  | 21,795 |  |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |
| Total net revenues |  | $ | 95,164 |  | $ | 114,355 |  | $ | 209,519 |  |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |

- removed (2020-10-29):
[0001564590-20-024274:note_history:78]
On March 31, 2020, the Company had $271.7 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 24 percent of its deferred revenue as revenue in fiscal 2020, an additional 46 percent in fiscal 2021 and 30 percent of the balance thereafter.

- removed (2020-10-29):
[0001564590-20-024274:note_history:79]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 168,755 |  | $ | 180,358 |  | $ | 349,113 |  |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |
| Other |  |  | 15,496 |  |  | 16,343 |  |  | 31,839 |  |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |
| Total Americas |  |  | 184,251 |  |  | 196,701 |  |  | 380,952 |  |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |
| EMEA |  |  | 173,825 |  |  | 107,521 |  |  | 281,346 |  |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |
| APAC |  |  | 18,362 |  |  | 51,837 |  |  | 70,199 |  |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |
| Total net revenues |  | $ | 376,438 |  | $ | 356,059 |  | $ | 732,497 |  |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |
