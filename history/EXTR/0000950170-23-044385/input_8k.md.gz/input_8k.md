# EXTR 8-K — 0000950170-23-036775 filed 2023-08-02

## item codes, every 8-K on or before 2023-08-24

- 2023-08-02 0000950170-23-036775 — 2.02, 9.01
- 2023-06-23 0000950170-23-029645 — 1.01, 2.03, 9.01
- 2023-06-09 0000950170-23-027267 — 5.03, 9.01
- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2023-08-24

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-036775:8k_2_02:1]
EX-99.1
2
extr-ex99_1.htm
EX-99.1

[0000950170-23-036775:8k_2_02:2]
EX-99.1

[0000950170-23-036775:8k_2_02:3]
Exhibit 99.1

[0000950170-23-036775:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0000950170-23-036775:8k_2_02:5]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2023 Financial Results

[0000950170-23-036775:8k_2_02:6]
Marks Second Consecutive Year of Double-Digit Revenue Growth

[0000950170-23-036775:8k_2_02:7]
Significant Operating Leverage and GAAP EPS Growth of 76%

[0000950170-23-036775:8k_2_02:8]
Expect Continued Strong Growth in FY24

[0000950170-23-036775:8k_2_02:9]
Morrisville, NC, August 2, 2023 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal year and fourth quarter ended June 30, 2023.

[0000950170-23-036775:8k_2_02:10]
"Extreme delivered a year of exceptional performance, with revenue growth accelerating to 31% in the fourth quarter and 18% overall for the year," said Ed Meyercord, President and Chief Executive Officer.  "This marks our second consecutive year of double-digit growth. We're outgrowing our competitors, gaining share, and winning new logos, which helped drive more than 30% growth in the value of deals over $1 million. We're breaking the status quo of networking through product innovation with differentiated solutions like universal hardware, end-to-end cloud management, enhanced AI, and our unique fabric technology, which greatly simplifies network management and bolsters security. Our focus on simplicity, flexibility, and performance continues to fuel our funnel of large opportunities. I remain confident in our growth prospects and am excited about the new innovations and opportunities we have in store for FY24 and beyond," concluded Meyercord.

[0000950170-23-036775:8k_2_02:11]
Kevin Rhodes, Executive Vice President and Chief Financial Officer stated, "the strong topline growth we achieved in Q4 and FY23 resulted in significant operating leverage that drove over 76% growth in GAAP EPS. We doubled our cash generation to $235 million in free cash flow this year, and even after repurchasing another $100 million worth of shares, and paying down $80 million in debt, we improved our year-end balance sheet to achieve a net cash position. Extreme has never been in a more robust financial position, and I am encouraged about our future prospects."

[0000950170-23-036775:8k_2_02:12]
Fiscal Fourth Quarter Results:

[0000950170-23-036775:8k_2_02:13]
•
Revenue $363.9 million, up 31% year-over-year, and up 9% quarter-over-quarter

[0000950170-23-036775:8k_2_02:14]
•
SaaS ARR $129.0 million, up 25% year-over-year, and up 10% quarter-over-quarter

[0000950170-23-036775:8k_2_02:15]
•
GAAP diluted EPS $0.19, compared to $0.04 in the prior year quarter

[0000950170-23-036775:8k_2_02:16]
•
Non-GAAP diluted EPS $0.33, compared to $0.15 in the prior year quarter

[0000950170-23-036775:8k_2_02:17]
•
GAAP gross margin 58.9% compared to 55.4% in the prior year quarter

[0000950170-23-036775:8k_2_02:18]
•
Non-GAAP gross margin 60.2% compared to 57.0% in the prior year quarter

[0000950170-23-036775:8k_2_02:19]
•
GAAP operating margin 10.4 % compared to 3.8 % in the prior year quarter

[0000950170-23-036775:8k_2_02:20]
•
Non-GAAP operating margin 17.4 % compared to 9.6% in the prior year quarter

[0000950170-23-036775:8k_2_02:21]
Fiscal Year 2023 Results:

[0000950170-23-036775:8k_2_02:22]
•
Revenue $1.3 billion, up 18% compared to $1.1 billion in fiscal 2022

[0000950170-23-036775:8k_2_02:23]
•
GAAP EPS $0.58, up from $0.33 in fiscal 2022

[0000950170-23-036775:8k_2_02:24]
•
Non-GAAP EPS $1.09, up from $0.77 in fiscal 2022

[0000950170-23-036775:8k_2_02:25]
•
GAAP operating margin 8.3% compared to 5.8% in fiscal 2022

[0000950170-23-036775:8k_2_02:26]
•
Non-GAAP operating margin 15.2% compared to 12.2% in fiscal 2022

[0000950170-23-036775:8k_2_02:27]
Liquidity:

[0000950170-23-036775:8k_2_02:28]
•
During Q4, we generated net cash flow from operations of $80.7 million and free cash flow of $75.5 million. For the full year, we generated net cash flow from operations of $249.2 million and free cash flow of $235.4 million.

[0000950170-23-036775:8k_2_02:29]
•
During Q4, we repurchased 1.4 million shares of our common stock on the open market at a total cost of $25.1 million with a weighted average price of $17.32 per share.  For the full year, we repurchased 5.4 million shares for $100 million with a weighted average price of $18.58 per share.

[0000950170-23-036775:8k_2_02:30]
•
Year ending cash balance was $234.8 million, an increase of $31.8 million from the end of Q3 2023 and $40.3 million at the end of last year.

[0000950170-23-036775:8k_2_02:31]
•
Year ending net cash was $9.8 million, an increase of $43.8 million from net debt of $34.0 million at Q3 2023 and an increase of $123.9 million from net debt of $114.1 million at the end of last year.

[0000950170-23-036775:8k_2_02:32]
Recent Key Highlights:

[0000950170-23-036775:8k_2_02:33]
•
Customers including Norwegian Cruise Line, European energy company E.ON and French university hospital Charité were named as recipients of the 2023 Extreme X-Factor Customer Awards. They were recognized for their innovative and impactful use of Extreme solutions to help drive their organizations forward.

[0000950170-23-036775:8k_2_02:34]
•
 During Extreme Connect 2023 in May, the company unveiled a series of groundbreaking networking solutions, including:

[0000950170-23-036775:8k_2_02:35]
o
ExtremeCloud Edge, the industry’s first networking cloud continuum, which offers organizations increased choice and flexibility in running networking applications, including management, analytics, and AI, from any location.

[0000950170-23-036775:8k_2_02:36]
o
The AP3000, the industry's smallest and most energy-efficient Wi-Fi 6E access point (AP)

[0000950170-23-036775:8k_2_02:37]
o
The 7520 and 7720 switches for enterprise core and aggregation use cases and the 8820 switches for large data center networks.

[0000950170-23-036775:8k_2_02:38]
•
Customers like Nevada Department of Transportation and Baylor University are adopting Extreme CoPilot AIOps to offset IT staffing shortages, reduce mean time to resolution of network issues and help IT and network administrators access and leverage network insights to prioritize tickets. As a result, teams can improve service quality, expedite problem resolution, help mitigate cyberthreats and improve time to innovation.

[0000950170-23-036775:8k_2_02:39]
•
Living Tomorrow Innovation Campus in Brussels selected Extreme as its network connectivity partner and will leverage hundreds of AP4000 Wi-Fi 6E access points (APs) to test and

[0000950170-23-036775:8k_2_02:40]
demonstrate advanced technologies. The campus will also rely on ExtremeAnalytics and ExtremeCloud IQ to optimize connectivity, enhance guest experiences, improve security and IT productivity, and automate daily network maintenance tasks while detecting anomalies in network activity.

[0000950170-23-036775:8k_2_02:41]
•
The University of Mount Union refreshed its network with end-to-end wired and wireless solutions from Extreme, including Fabric and ExtremeCloud IQ CoPilot for AIOps. The new network provides seamless, AI and Fabric powered automation and optimization across campus, which improves IT productivity and greatly reduces mean time to resolving network anomalies. Extreme improves the performance of in-classroom technology like AR/VR and 4K video streaming.

[0000950170-23-036775:8k_2_02:42]
•
Professional sports teams including the Arizona Diamondbacks, Philadelphia Phillies and Philadelphia Flyers are deploying Wi-Fi 6 and 6E to help create better fan experiences, improve amenities like digital concession signage and mobile tickets, ensure support for future fan experiences like AR/VR and AI applications and streamline venue operations.

[0000950170-23-036775:8k_2_02:43]
Fiscal Q4 2023 and Full Year 2023 Financial Metrics:

[0000950170-23-036775:8k_2_02:44]
(in millions, except percentages and per share information)

[0000950170-23-036775:8k_2_02:45]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | Change |  |  | June 30,2023 |  |  | June 30,2022 |  |  | Change |  |
| Product |  | $ | 261.7 |  |  | $ | 187.1 |  |  | $ | 74.6 |  |  | $ | 932.5 |  |  | $ | 761.7 |  |  | $ | 170.8 |  |
| Service and subscription |  |  | 102.2 |  |  |  | 91.1 |  |  |  | 11.1 |  |  |  | 380.0 |  |  |  | 350.6 |  |  |  | 29.4 |  |
| Total net revenue |  | $ | 363.9 |  |  | $ | 278.2 |  |  | $ | 85.7 |  |  | $ | 1,312.5 |  |  | $ | 1,112.3 |  |  | $ | 200.2 |  |
| Gross margin |  |  | 58.9 | % |  |  | 55.4 | % |  |  | 3.5 | % |  |  | 57.5 | % |  |  | 56.6 | % |  |  | 0.9 | % |
| Operating margin |  |  | 10.4 | % |  |  | 3.8 | % |  |  | 6.6 | % |  |  | 8.3 | % |  |  | 5.8 | % |  |  | 2.5 | % |
| Net income |  | $ | 25.4 |  |  | $ | 5.4 |  |  | $ | 20.0 |  |  | $ | 78.1 |  |  | $ | 44.3 |  |  | $ | 33.8 |  |
| Net income per diluted share |  | $ | 0.19 |  |  | $ | 0.04 |  |  | $ | 0.15 |  |  | $ | 0.58 |  |  | $ | 0.33 |  |  | $ | 0.25 |  |

[0000950170-23-036775:8k_2_02:46]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | Change |  |  | June 30,2023 |  |  | June 30,2022 |  |  | Change |  |
| Product |  | $ | 261.7 |  |  | $ | 187.1 |  |  | $ | 74.6 |  |  | $ | 932.5 |  |  | $ | 761.7 |  |  | $ | 170.8 |  |
| Service and subscription |  |  | 102.2 |  |  |  | 91.1 |  |  |  | 11.1 |  |  |  | 380.0 |  |  |  | 350.6 |  |  |  | 29.4 |  |
| Total net revenue |  | $ | 363.9 |  |  | $ | 278.2 |  |  | $ | 85.7 |  |  | $ | 1,312.5 |  |  | $ | 1,112.3 |  |  | $ | 200.2 |  |
| Gross margin |  |  | 60.2 | % |  |  | 57.0 | % |  |  | 3.2 | % |  |  | 58.9 | % |  |  | 58.4 | % |  |  | 0.5 | % |
| Operating margin |  |  | 17.4 | % |  |  | 9.6 | % |  |  | 7.8 | % |  |  | 15.2 | % |  |  | 12.2 | % |  |  | 3.0 | % |
| Net income |  | $ | 43.9 |  |  | $ | 19.7 |  |  | $ | 24.2 |  |  | $ | 146.3 |  |  | $ | 103.5 |  |  | $ | 42.9 |  |
| Net income per diluted share |  | $ | 0.33 |  |  | $ | 0.15 |  |  | $ | 0.18 |  |  | $ | 1.09 |  |  | $ | 0.77 |  |  | $ | 0.32 |  |

[0000950170-23-036775:8k_2_02:47]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in millions):

[0000950170-23-036775:8k_2_02:48]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| Cash flow provided by operations | $ | 80.7 |  |  | $ | 64.1 |  |  | $ | 249.2 |  |  | $ | 128.2 |  |
| Less: Property and equipment capital expenditures |  | (5.2 | ) |  |  | (4.3 | ) |  |  | (13.8 | ) |  |  | (15.5 | ) |
| Total free cash flow | $ | 75.5 |  |  | $ | 59.8 |  |  | $ | 235.4 |  |  | $ | 112.7 |  |

[0000950170-23-036775:8k_2_02:49]
SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud™ IQ (XIQ) and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue or deferred revenue accounted under U.S. GAAP. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0000950170-23-036775:8k_2_02:50]
Gross Debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0000950170-23-036775:8k_2_02:51]
Net Cash (Debt) is defined as cash minus gross debt, as shown in the table below (in millions):

[0000950170-23-036775:8k_2_02:52]
| Cash |  |  | Gross debt |  |  | Net cash (debt) |  |
| $ | 234.8 |  |  | $ | 225.0 |  |  | $ | 9.8 |  |

[0000950170-23-036775:8k_2_02:53]
Business Outlook:

[0000950170-23-036775:8k_2_02:54]
For its first quarter of fiscal 2024, ending September 30, 2023, the Company is targeting:

[0000950170-23-036775:8k_2_02:55]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ1'24 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 342.0 |  |  | $ | 352.0 |  |
| Gross margin |  | 58.6 | % |  |  | 60.6 | % |
| Operating margin |  | 7.5 | % |  |  | 9.8 | % |
| Net income per diluted share | $ | 0.12 |  |  | $ | 0.18 |  |
| Shares outstanding used in calculating GAAP EPS |  | 133.0 |  |  |  | 133.0 |  |
| FQ1’24 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 342.0 |  |  | $ | 352.0 |  |
| Gross margin |  | 59.5 | % |  |  | 61.5 | % |
| Operating margin |  | 15.3 | % |  |  | 17.6 | % |
| Net income per diluted share | $ | 0.28 |  |  | $ | 0.33 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 133.0 |  |  |  | 133.0 |  |

[0000950170-23-036775:8k_2_02:56]
The following table shows the GAAP to non-GAAP reconciliation for Q1 FY’24 guidance:

[0000950170-23-036775:8k_2_02:57]
|  | Gross MarginRate |  | OperatingMargin Rate |  | Earnings perShare |
| GAAP | 58.6% - 60.6% |  | 7.5% - 9.8% |  | $0.12 - $0.18 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.5% |  | 5.7% |  | 0.15 |
| Amortization of product intangibles | 0.3% |  | 0.3% |  | 0.01 |
| Amortization of non-product intangibles | 0.1% |  | 0.2% |  | 0.01 |
| Restructuring | — |  | 1.0% |  | 0.03 |
| Litigation charges | — |  | 0.3% |  | 0.01 |
| System transition cost | — |  | 0.3% |  | 0.01 |
| Tax adjustment | — |  | — |  | (0.06) |
| Non-GAAP | 59.5% - 61.5% |  | 15.3% - 17.6% |  | $0.28 - $0.33 |

[0000950170-23-036775:8k_2_02:58]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0000950170-23-036775:8k_2_02:59]
Conference Call:

[0000950170-23-036775:8k_2_02:60]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the fourth quarter results of fiscal 2023 as well as the business outlook for the first quarter of fiscal 2024 ending September 30, 2023, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call by phone, please go to this link (Extreme Networks Q4'23 Earnings Registration Link) and you will be provided with dial in details. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0000950170-23-036775:8k_2_02:61]
About Extreme:

[0000950170-23-036775:8k_2_02:62]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0000950170-23-036775:8k_2_02:63]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0000950170-23-036775:8k_2_02:64]
Non-GAAP Financial Measures:

[0000950170-23-036775:8k_2_02:65]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net cash (debt) and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges, debt restructuring charges and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP

[0000950170-23-036775:8k_2_02:66]
financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0000950170-23-036775:8k_2_02:67]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0000950170-23-036775:8k_2_02:68]
Forward-Looking Statements:

[0000950170-23-036775:8k_2_02:69]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2022, Quarterly Reports on Form 10-Q for the quarters ended September 30, 2022, December 31, 2022, and, March 31, 2023, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0000950170-23-036775:8k_2_02:70]
###

[0000950170-23-036775:8k_2_02:71]
EXTREME NETWORKS, INC.

[0000950170-23-036775:8k_2_02:72]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-23-036775:8k_2_02:73]
(In thousands, except per share amounts)

[0000950170-23-036775:8k_2_02:74]
(Unaudited)

[0000950170-23-036775:8k_2_02:75]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash |  | $ | 234,826 |  |  | $ | 194,522 |  |
| Accounts receivable, net |  |  | 182,045 |  |  |  | 184,097 |  |
| Inventories |  |  | 89,024 |  |  |  | 49,231 |  |
| Prepaid expenses and other current assets |  |  | 70,263 |  |  |  | 61,239 |  |
| Total current assets |  |  | 576,158 |  |  |  | 489,089 |  |
| Property and equipment, net |  |  | 46,448 |  |  |  | 49,578 |  |
| Operating lease right-of-use assets, net |  |  | 34,739 |  |  |  | 36,454 |  |
| Intangible assets, net |  |  | 16,063 |  |  |  | 32,515 |  |
| Goodwill |  |  | 394,755 |  |  |  | 400,144 |  |
| Other assets |  |  | 73,544 |  |  |  | 60,730 |  |
| Total assets |  | $ | 1,141,707 |  |  | $ | 1,068,510 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $674 and $2,276, respectively |  | $ | 34,326 |  |  | $ | 33,349 |  |
| Accounts payable |  |  | 99,724 |  |  |  | 84,338 |  |
| Accrued compensation and benefits |  |  | 71,367 |  |  |  | 53,710 |  |
| Accrued warranty |  |  | 12,322 |  |  |  | 10,852 |  |
| Current portion, operating lease liabilities |  |  | 10,847 |  |  |  | 13,956 |  |
| Current portion, deferred revenue |  |  | 282,475 |  |  |  | 238,262 |  |
| Other accrued liabilities |  |  | 64,440 |  |  |  | 65,714 |  |
| Total current liabilities |  |  | 575,501 |  |  |  | 500,181 |  |
| Deferred revenue, less current portion |  |  | 219,024 |  |  |  | 163,357 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $2,409 and $2,430, respectively |  |  | 187,591 |  |  |  | 270,570 |  |
| Operating lease liabilities, less current portion |  |  | 31,845 |  |  |  | 33,256 |  |
| Deferred income taxes |  |  | 7,747 |  |  |  | 7,717 |  |
| Other long-term liabilities |  |  | 3,247 |  |  |  | 3,086 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 143,629 and 139,742 shares issued, respectively; 127,775 and 129,263 shares outstanding, respectively |  |  | 144 |  |  |  | 140 |  |
| Additional paid-in-capital |  |  | 1,173,744 |  |  |  | 1,115,416 |  |
| Accumulated other comprehensive loss |  |  | (13,192 | ) |  |  | (3,055 | ) |
| Accumulated deficit |  |  | (855,998 | ) |  |  | (934,072 | ) |
| Treasury stock at cost, 15,854 and 10,479 shares, respectively |  |  | (187,946 | ) |  |  | (88,086 | ) |
| Total stockholders’ equity |  |  | 116,752 |  |  |  | 90,343 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,141,707 |  |  | $ | 1,068,510 |  |

[0000950170-23-036775:8k_2_02:76]
EXTREME NETWORKS, INC.

[0000950170-23-036775:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-036775:8k_2_02:78]
(In thousands, except per share amounts)

[0000950170-23-036775:8k_2_02:79]
(Unaudited)

[0000950170-23-036775:8k_2_02:80]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 261,675 |  |  | $ | 187,085 |  |  | $ | 932,454 |  |  | $ | 761,721 |  |
| Service and subscription |  |  | 102,235 |  |  |  | 91,111 |  |  |  | 380,000 |  |  |  | 350,600 |  |
| Total net revenues |  |  | 363,910 |  |  |  | 278,196 |  |  |  | 1,312,454 |  |  |  | 1,112,321 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 114,030 |  |  |  | 96,103 |  |  |  | 426,295 |  |  |  | 360,562 |  |
| Service and subscription |  |  | 35,461 |  |  |  | 27,902 |  |  |  | 131,439 |  |  |  | 121,821 |  |
| Total cost of revenues |  |  | 149,491 |  |  |  | 124,005 |  |  |  | 557,734 |  |  |  | 482,383 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 147,645 |  |  |  | 90,982 |  |  |  | 506,159 |  |  |  | 401,159 |  |
| Service and subscription |  |  | 66,774 |  |  |  | 63,209 |  |  |  | 248,561 |  |  |  | 228,779 |  |
| Total gross profit |  |  | 214,419 |  |  |  | 154,191 |  |  |  | 754,720 |  |  |  | 629,938 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 55,826 |  |  |  | 45,130 |  |  |  | 214,270 |  |  |  | 190,591 |  |
| Sales and marketing |  |  | 94,024 |  |  |  | 80,538 |  |  |  | 336,906 |  |  |  | 294,470 |  |
| General and administrative |  |  | 25,619 |  |  |  | 16,103 |  |  |  | 89,934 |  |  |  | 68,697 |  |
| Acquisition and integration costs |  |  | — |  |  |  | 553 |  |  |  | 390 |  |  |  | 7,009 |  |
| Restructuring and related charges |  |  | 540 |  |  |  | 770 |  |  |  | 2,860 |  |  |  | 1,748 |  |
| Amortization of intangibles |  |  | 510 |  |  |  | 639 |  |  |  | 2,047 |  |  |  | 3,235 |  |
| Total operating expenses |  |  | 176,519 |  |  |  | 143,733 |  |  |  | 646,407 |  |  |  | 565,750 |  |
| Operating income |  |  | 37,900 |  |  |  | 10,458 |  |  |  | 108,313 |  |  |  | 64,188 |  |
| Interest income |  |  | 1,100 |  |  |  | 110 |  |  |  | 3,155 |  |  |  | 412 |  |
| Interest expense |  |  | (5,729 | ) |  |  | (3,039 | ) |  |  | (17,385 | ) |  |  | (12,789 | ) |
| Other income (expense), net |  |  | (119 | ) |  |  | 86 |  |  |  | 23 |  |  |  | 383 |  |
| Income before income taxes |  |  | 33,152 |  |  |  | 7,615 |  |  |  | 94,106 |  |  |  | 52,194 |  |
| Provision for income taxes |  |  | 7,725 |  |  |  | 2,205 |  |  |  | 16,032 |  |  |  | 7,923 |  |
| Net income |  | $ | 25,427 |  |  | $ | 5,410 |  |  | $ | 78,074 |  |  | $ | 44,271 |  |
| Basic and diluted income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.20 |  |  | $ | 0.04 |  |  | $ | 0.60 |  |  | $ | 0.34 |  |
| Net income per share – diluted |  | $ | 0.19 |  |  | $ | 0.04 |  |  | $ | 0.58 |  |  | $ | 0.33 |  |
| Shares used in per share calculation – basic |  |  | 128,294 |  |  |  | 129,788 |  |  |  | 129,473 |  |  |  | 129,437 |  |
| Shares used in per share calculation – diluted |  |  | 132,873 |  |  |  | 132,304 |  |  |  | 133,649 |  |  |  | 133,494 |  |

[0000950170-23-036775:8k_2_02:81]
EXTREME NETWORKS, INC.

[0000950170-23-036775:8k_2_02:82]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-23-036775:8k_2_02:83]
(In thousands)

[0000950170-23-036775:8k_2_02:84]
(Unaudited)

[0000950170-23-036775:8k_2_02:85]
|  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 78,074 |  |  | $ | 44,271 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 19,888 |  |  |  | 20,215 |  |
| Amortization of intangible assets |  |  | 14,988 |  |  |  | 19,946 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 12,248 |  |  |  | 14,929 |  |
| Provision for doubtful accounts |  |  | 459 |  |  |  | 29 |  |
| Share-based compensation |  |  | 63,472 |  |  |  | 43,362 |  |
| Deferred income taxes |  |  | 407 |  |  |  | 682 |  |
| Non-cash interest expense |  |  | 1,145 |  |  |  | 4,443 |  |
| Other |  |  | (8,056 | ) |  |  | 423 |  |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,593 |  |  |  | (26,231 | ) |
| Inventories |  |  | (41,827 | ) |  |  | (16,722 | ) |
| Prepaid expenses and other assets |  |  | (1,368 | ) |  |  | (4,469 | ) |
| Accounts payable |  |  | 14,733 |  |  |  | 23,810 |  |
| Accrued compensation and benefits |  |  | 17,137 |  |  |  | (20,709 | ) |
| Operating lease liabilities |  |  | (15,219 | ) |  |  | (18,949 | ) |
| Deferred revenue |  |  | 90,102 |  |  |  | 44,635 |  |
| Other current and long-term liabilities |  |  | 1,436 |  |  |  | (1,488 | ) |
| Net cash provided by operating activities |  |  | 249,212 |  |  |  | 128,177 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures |  |  | (13,800 | ) |  |  | (15,433 | ) |
| Business acquisition, net of cash acquired |  |  | — |  |  |  | (69,517 | ) |
| Net cash used in investing activities |  |  | (13,800 | ) |  |  | (84,950 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | 25,000 |  |  |  | — |  |
| Payments on debt obligations |  |  | (108,625 | ) |  |  | (38,125 | ) |
| Loan fees on borrowings |  |  | (3,158 | ) |  |  | — |  |
| Repurchase of common stock |  |  | (99,860 | ) |  |  | (44,973 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (5,140 | ) |  |  | (6,541 | ) |
| Payment of contingent consideration obligations |  |  | — |  |  |  | (1,024 | ) |
| Deferred payments on an acquisition |  |  | (3,000 | ) |  |  | (4,000 | ) |
| Net cash used in financing activities |  |  | (194,783 | ) |  |  | (94,663 | ) |
| Foreign currency effect on cash |  |  | (325 | ) |  |  | (936 | ) |
| Net increase (decrease) in cash |  |  | 40,304 |  |  |  | (52,372 | ) |
| Cash at beginning of period |  |  | 194,522 |  |  |  | 246,894 |  |
| Cash at end of period |  | $ | 234,826 |  |  | $ | 194,522 |  |

[0000950170-23-036775:8k_2_02:86]
Extreme Networks, Inc.

[0000950170-23-036775:8k_2_02:87]
Non-GAAP Measures of Financial Performance

[0000950170-23-036775:8k_2_02:88]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net cash (debt) and non-GAAP free cash flow.

[0000950170-23-036775:8k_2_02:89]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0000950170-23-036775:8k_2_02:90]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0000950170-23-036775:8k_2_02:91]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0000950170-23-036775:8k_2_02:92]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges, debt restructuring charges and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0000950170-23-036775:8k_2_02:93]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0000950170-23-036775:8k_2_02:94]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0000950170-23-036775:8k_2_02:95]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, and legal and professional fees related to the acquisition of Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0000950170-23-036775:8k_2_02:96]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0000950170-23-036775:8k_2_02:97]
Restructuring charges. Restructuring charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0000950170-23-036775:8k_2_02:98]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution and our configure, price, quote solution. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency making it difficult to contribute to a meaningful evaluation of our operating performance.

[0000950170-23-036775:8k_2_02:99]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for a non-recurring pending litigation.

[0000950170-23-036775:8k_2_02:100]
Debt refinancing charges. Debt refinancing charges consist of the write-off of certain unamortized debt issuance costs included on interest expense, as well as other debt refinancing charges that were not capitalizable and are included in other income (expense), that occurred in conjunction with the amendment of our credit facility in June 2023.

[0000950170-23-036775:8k_2_02:101]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation. We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits. The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0000950170-23-036775:8k_2_02:102]
The non-GAAP provision for income taxes has typically been and is currently higher than the GAAP provision given the Company has a valuation allowance against its US and a portion of its Irish deferred tax assets due to historical losses. Once these valuation allowances are released, the non-GAAP and the GAAP provision for income taxes will be more closely aligned.

[0000950170-23-036775:8k_2_02:103]
Over the next year, our cash taxes will be driven by US federal and state taxes and the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which performs research and development activities, as well as the Company’s Irish trading subsidiaries.

[0000950170-23-036775:8k_2_02:104]
EXTREME NETWORKS, INC.

[0000950170-23-036775:8k_2_02:105]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-036775:8k_2_02:106]
GAAP TO NON-GAAP RECONCILIATION

[0000950170-23-036775:8k_2_02:107]
(In thousands, except percentages and per share amounts)

[0000950170-23-036775:8k_2_02:108]
(Unaudited)

[0000950170-23-036775:8k_2_02:109]
| Revenues | Three Months Ended | Year Ended |
|  | June 30,2023 |  | June 30,2022 |  | June 30,2023 |  | June 30,2022 |
| Revenues – GAAP | $363,910 |  | $278,196 |  | $1,312,454 |  | $1,112,321 |

[0000950170-23-036775:8k_2_02:110]
| Non-GAAP Gross Margin | Three Months Ended | Year Ended |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| Gross profit – GAAP | $ | 214,419 |  |  | $ | 154,191 |  |  | $ | 754,720 |  |  | $ | 629,938 |  |
| Gross margin – GAAP percentage |  | 58.9 | % |  |  | 55.4 | % |  |  | 57.5 | % |  |  | 56.6 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 491 |  |  |  | 281 |  |  |  | 1,856 |  |  |  | 1,186 |  |
| Share-based compensation expense, Services and subscription |  | 945 |  |  |  | 365 |  |  |  | 3,513 |  |  |  | 1,421 |  |
| Amortization of intangibles, Product |  | 2,230 |  |  |  | 2,804 |  |  |  | 9,611 |  |  |  | 13,381 |  |
| Amortization of intangibles, Service and subscription |  | 815 |  |  |  | 815 |  |  |  | 3,258 |  |  |  | 3,259 |  |
| Total adjustments to GAAP gross profit | $ | 4,481 |  |  | $ | 4,265 |  |  | $ | 18,238 |  |  | $ | 19,247 |  |
| Gross profit – non-GAAP | $ | 218,900 |  |  | $ | 158,456 |  |  | $ | 772,958 |  |  | $ | 649,185 |  |
| Gross margin – non-GAAP percentage |  | 60.2 | % |  |  | 57.0 | % |  |  | 58.9 | % |  |  | 58.4 | % |

[0000950170-23-036775:8k_2_02:111]
| Non-GAAP Operating Income | Three Months Ended | Year Ended |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| GAAP operating income | $ | 37,900 |  |  | $ | 10,458 |  |  | $ | 108,313 |  |  | $ | 64,188 |  |
| GAAP operating income percentage |  | 10.4 | % |  |  | 3.8 | % |  |  | 8.3 | % |  |  | 5.8 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,436 |  |  |  | 646 |  |  |  | 5,369 |  |  |  | 2,607 |  |
| Share-based compensation expense, R&D |  | 3,889 |  |  |  | 2,427 |  |  |  | 14,824 |  |  |  | 9,995 |  |
| Share-based compensation expense, S&M |  | 5,924 |  |  |  | 3,733 |  |  |  | 22,250 |  |  |  | 15,000 |  |
| Share-based compensation expense, G&A |  | 5,662 |  |  |  | 3,925 |  |  |  | 21,029 |  |  |  | 15,760 |  |
| Acquisition and integration costs |  | — |  |  |  | 553 |  |  |  | 390 |  |  |  | 7,009 |  |
| Restructuring charges |  | 540 |  |  |  | 770 |  |  |  | 2,860 |  |  |  | 1,748 |  |
| Litigation charges |  | 4,022 |  |  |  | — |  |  |  | 8,026 |  |  |  | — |  |
| System transition costs |  | 467 |  |  |  | — |  |  |  | 957 |  |  |  | — |  |
| Amortization of intangibles |  | 3,555 |  |  |  | 4,258 |  |  |  | 14,916 |  |  |  | 19,875 |  |
| Total adjustments to GAAP operating income |  | 25,495 |  |  |  | 16,312 |  |  |  | 90,621 |  |  |  | 71,994 |  |
| Non-GAAP operating income | $ | 63,395 |  |  | $ | 26,770 |  |  | $ | 198,934 |  |  | $ | 136,182 |  |
| Non-GAAP operating income percentage |  | 17.4 | % |  |  | 9.6 | % |  |  | 15.2 | % |  |  | 12.2 | % |

[0000950170-23-036775:8k_2_02:112]
| Non-GAAP Net Income | Three Months Ended | Year Ended |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| GAAP net income | $ | 25,427 |  |  | $ | 5,410 |  |  | $ | 78,074 |  |  | $ | 44,271 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 16,911 |  |  |  | 10,731 |  |  |  | 63,472 |  |  |  | 43,362 |  |
| Acquisition and integration costs |  | — |  |  |  | 553 |  |  |  | 390 |  |  |  | 7,009 |  |
| Restructuring charge, net of reversal |  | 540 |  |  |  | 770 |  |  |  | 2,860 |  |  |  | 1,748 |  |
| Litigation charges |  | 4,022 |  |  |  | — |  |  |  | 8,026 |  |  |  | — |  |
| System transition costs |  | 467 |  |  |  | — |  |  |  | 957 |  |  |  | — |  |
| Amortization of intangibles |  | 3,555 |  |  |  | 4,258 |  |  |  | 14,916 |  |  |  | 19,875 |  |
| Debt refinancing charges, Interest expense |  | 1,346 |  |  |  | — |  |  |  | 1,346 |  |  |  | — |  |
| Debt refinancing charges, Other income (expense) |  | 197 |  |  |  | — |  |  |  | 197 |  |  |  | — |  |
| Tax effect of non-GAAP adjustments |  | (8,574 | ) |  |  | (2,074 | ) |  |  | (23,933 | ) |  |  | (12,814 | ) |
| Total adjustments to GAAP net income | $ | 18,464 |  |  | $ | 14,238 |  |  | $ | 68,231 |  |  | $ | 59,180 |  |
| Non-GAAP net income | $ | 43,891 |  |  | $ | 19,648 |  |  | $ | 146,305 |  |  | $ | 103,451 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share – diluted | $ | 0.19 |  |  | $ | 0.04 |  |  | $ | 0.58 |  |  | $ | 0.33 |  |
| Non-GAAP net income per share – diluted | $ | 0.33 |  |  | $ | 0.15 |  |  | $ | 1.09 |  |  | $ | 0.77 |  |
| Shares used in net income per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 128,294 |  |  |  | 129,788 |  |  |  | 129,473 |  |  |  | 129,437 |  |
| Potentially dilutive equity awards |  | 4,579 |  |  |  | 2,516 |  |  |  | 4,176 |  |  |  | 4,057 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 132,873 |  |  |  | 132,304 |  |  |  | 133,649 |  |  |  | 133,494 |  |
