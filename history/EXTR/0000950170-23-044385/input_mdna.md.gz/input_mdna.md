# EXTR MD&A — 0000950170-23-044385


## mdna

[0000950170-23-044385:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-23-044385:mdna:2]
Business Overview

[0000950170-23-044385:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Part II, Item 8 of this Annual Report on Form 10-K.

[0000950170-23-044385:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Annual Report on Form 10-K, which have been prepared in accordance with U.S. generally accepted accounting principles, or U.S. GAAP. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0000950170-23-044385:mdna:5]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we,” “us” and “our”) is a leading provider of cloud networking solutions and industry leading services and support. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. Our corporate headquarters are located in Morrisville, North Carolina. We derive a majority of our revenues from the sale of our networking equipment, software subscriptions and services, and related maintenance contracts.

[0000950170-23-044385:mdna:6]
Extreme is a leading provider of cloud networking solutions and industry leading services and support. Extreme designs, develops and manufactures wired, wireless, and SD-WAN infrastructure equipment. The Company's cloud solution is a single platform that offers unified network management of wireless access points, switches and SD-WAN. It leverages ML, AI Operations, and analytics to help customers deliver secure connectivity at the edge of the network, speed cloud deployments, and uncover actionable insights saves time, lower costs and streamlines operations.

[0000950170-23-044385:mdna:7]
Enterprise network administrators need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security. Accelerators such as IoT, AI, BYOD, ML, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0000950170-23-044385:mdna:8]
A direction affecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud, and third-party, public cloud services with orchestration between multiple platforms. We introduced our Cloud offering in 2016 and in August 2019 acquired Aerohive Networks, Inc to enhance our Cloud strategy with a 3rd generation Cloud platform and to accelerate adoption of hybrid cloud networking solutions in the Enterprise. Extreme’s enhanced Cloud solution is the only offering in the market that seamlessly integrates the cloud with on-premises infrastructures and enables visibility from the edge to everywhere. See Part 1, Item 1. Business, for additional discussion of our business.

[0000950170-23-044385:mdna:9]
Fiscal Year

[0000950170-23-044385:mdna:10]
The Company uses a fiscal calendar year ending on June 30. All references herein to  “fiscal 2023” or “2023"; “fiscal 2022” or “2022”; “fiscal 2021” or “2021” represent the fiscal years ending, respectively.

[0000950170-23-044385:mdna:11]
Acquisitions

[0000950170-23-044385:mdna:12]
Ipanematech SAS

[0000950170-23-044385:mdna:13]
On September 14, 2021 (the “Acquisition Date”), we completed our acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network business unit of InfoVista pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million. The primary reason for the Acquisition was to acquire the talent and the technology to allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers. The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanema were recorded at their respective fair values including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets. Results of operations of Ipanema are included in our operations beginning with the Acquisition Date. During the fiscal years ended June 30, 2023 and 2022, we recognized transaction costs related to this acquisition of $0.4 million and $7.0 million, respectively, which are included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0000950170-23-044385:mdna:14]
Results of Operations

[0000950170-23-044385:mdna:15]
The following is a summary of our results of operations during the fiscal year ended June 30, 2023:

[0000950170-23-044385:mdna:16]
•
Net revenues of $1,312.5 million, increased 18.0% from fiscal 2022 net revenues of $1,112.3 million.

[0000950170-23-044385:mdna:17]
•
Product revenues of $932.5 million, increased 22.4% from fiscal 2022 product revenues of $761.7 million.

[0000950170-23-044385:mdna:18]
•
Service and subscription revenues of $380.0 million, increased 8.4% from fiscal 2022 service and subscription revenues of $350.6 million.

[0000950170-23-044385:mdna:19]
•
Total gross margin of 57.5% of net revenues in fiscal 2023, compared to 56.6% in fiscal 2022.

[0000950170-23-044385:mdna:20]
•
Operating income of $108.3 million, compared to operating income of $64.2 million in fiscal 2022.

[0000950170-23-044385:mdna:21]
•
Net income was $78.1 million in fiscal 2023, compared to net income of $44.3 million in fiscal 2022.

[0000950170-23-044385:mdna:22]
•
Cash flow provided by operating activities of $249.2 million, compared to cash flow provided by operating activities of $128.2 million in fiscal 2022, an increase of $121.0 million. Cash and cash equivalents was $234.8 million as of June 30, 2023, an increase of $40.3 million, compared to $194.5 million at the end of fiscal 2022.

[0000950170-23-044385:mdna:23]
Net Revenues

[0000950170-23-044385:mdna:24]
The following table presents net product and service and subscription revenues for the fiscal years ended June 30, 2023, 2022 and 2021 (in thousands, except percentages):

[0000950170-23-044385:mdna:25]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | $Change |  |  | %Change |  |  | June 30,2022 |  |  | June 30, 2021 |  |  | $Change |  |  | %Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 932,454 |  |  | $ | 761,721 |  |  | $ | 170,733 |  |  |  | 22.4 | % |  | $ | 761,721 |  |  | $ | 699,396 |  |  | $ | 62,325 |  |  |  | 8.9 | % |
| Percentage of net revenues |  |  | 71.0 | % |  |  | 68.5 | % |  |  |  |  |  |  |  |  | 68.5 | % |  |  | 69.3 | % |  |  |  |  |  |  |
| Service and subscription |  |  | 380,000 |  |  |  | 350,600 |  |  |  | 29,400 |  |  |  | 8.4 | % |  |  | 350,600 |  |  |  | 310,022 |  |  |  | 40,578 |  |  |  | 13.1 | % |
| Percentage of net revenues |  |  | 29.0 | % |  |  | 31.5 | % |  |  |  |  |  |  |  |  | 31.5 | % |  |  | 30.7 | % |  |  |  |  |  |  |
| Total net revenues |  | $ | 1,312,454 |  |  | $ | 1,112,321 |  |  | $ | 200,133 |  |  |  | 18.0 | % |  | $ | 1,112,321 |  |  | $ | 1,009,418 |  |  | $ | 102,903 |  |  |  | 10.2 | % |

[0000950170-23-044385:mdna:26]
Product revenues increased $170.7 million or 22.4% for the year ended June 30, 2023, compared to fiscal 2022. The product revenues increase for the year ended June 30, 2023 as compared to fiscal 2022 was primarily due to strong demand for our products and higher shipments resulting from an easing in supply chain constraints which had impacted our ability to fulfill the demand for our products during fiscal 2022.

[0000950170-23-044385:mdna:27]
Product revenues increased $62.3 million or 8.9% for the year ended June 30, 2022, compared to fiscal 2021. The product revenues increase for the year ended June 30, 2022 as compared to fiscal 2021 was primarily due to strong demand for our products partially offset by supply chain constraints which impacted our ability to fulfill the demand for our products during fiscal 2022. Additionally, the first half of fiscal 2021 product revenue was impacted by the material slow-down in global demand due to the global outbreak of COVID-19.

[0000950170-23-044385:mdna:28]
Service and subscription revenues increased $29.4 million or 8.4% for the year ended June 30, 2023, compared to fiscal 2022. The increase in service and subscription revenues was primarily due to the growth in our subscription business.

[0000950170-23-044385:mdna:29]
Service and subscription revenues increased $40.6 million or 13.1% for the year ended June 30, 2022, compared to fiscal 2021. The increase in service and subscription revenues was primarily due to the growth in subscription revenues and partially due to the acquisition of Ipanema.

[0000950170-23-044385:mdna:30]
We operate in three regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table presents the total net revenues geographically for the fiscal years ended June 30, 2023, 2022 and 2021 (in thousands, except percentages):

[0000950170-23-044385:mdna:31]
|  |  | Year Ended |  |  | Year Ended |  |
| Net Revenues |  | June 30,2023 |  |  | June 30,2022 |  |  | $Change |  |  | %Change |  |  | June 30,2022 |  |  | June 30, 2021 |  |  | $Change |  |  | %Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 572,927 |  |  | $ | 503,635 |  |  | $ | 69,292 |  |  |  | 13.8 | % |  | $ | 503,635 |  |  | $ | 485,471 |  |  | $ | 18,164 |  |  |  | 3.7 | % |
| Other |  |  | 84,108 |  |  |  | 44,608 |  |  |  | 39,500 |  |  |  | 88.5 | % |  |  | 44,608 |  |  |  | 48,049 |  |  |  | (3,441 | ) |  |  | (7.2 | )% |
| Total Americas |  |  | 657,035 |  |  |  | 548,243 |  |  |  | 108,792 |  |  |  | 19.8 | % |  |  | 548,243 |  |  |  | 533,520 |  |  |  | 14,723 |  |  |  | 2.8 | % |
| Percentage of net revenues |  |  | 50.1 | % |  |  | 49.3 | % |  |  |  |  |  |  |  |  | 49.3 | % |  |  | 52.9 | % |  |  |  |  |  |  |
| EMEA |  |  | 559,669 |  |  |  | 477,081 |  |  |  | 82,588 |  |  |  | 17.3 | % |  |  | 477,081 |  |  |  | 387,545 |  |  |  | 89,536 |  |  |  | 23.1 | % |
| Percentage of net revenues |  |  | 42.6 | % |  |  | 42.9 | % |  |  |  |  |  |  |  |  | 42.9 | % |  |  | 38.4 | % |  |  |  |  |  |  |
| APAC |  |  | 95,750 |  |  |  | 86,997 |  |  |  | 8,753 |  |  |  | 10.1 | % |  |  | 86,997 |  |  |  | 88,353 |  |  |  | (1,356 | ) |  |  | (1.5 | )% |
| Percentage of net revenues |  |  | 7.3 | % |  |  | 7.8 | % |  |  |  |  |  |  |  |  | 7.8 | % |  |  | 8.8 | % |  |  |  |  |  |  |
| Total net revenues |  | $ | 1,312,454 |  |  | $ | 1,112,321 |  |  | $ | 200,133 |  |  |  | 18.0 | % |  | $ | 1,112,321 |  |  | $ | 1,009,418 |  |  | $ | 102,903 |  |  |  | 10.2 | % |

[0000950170-23-044385:mdna:32]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEMs and direct sales. Revenues through our distributor channel were 83% of total product revenues in fiscal 2023, 80% of total product revenues in fiscal 2022 and 77% of total product revenue in fiscal 2021.

[0000950170-23-044385:mdna:33]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0000950170-23-044385:mdna:34]
Cost of Revenues and Gross Profit

[0000950170-23-044385:mdna:35]
The following table presents the gross profit on product and service and subscription revenues and the gross profit percentage of net revenues for the fiscal years ended June 30, 2023, 2022 and 2021 (in thousands, except percentages):

[0000950170-23-044385:mdna:36]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | $Change |  |  | %Change |  |  | June 30,2022 |  |  | June 30, 2021 |  |  | $Change |  |  | %Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 506,159 |  |  | $ | 401,159 |  |  | $ | 105,000 |  |  |  | 26.2 | % |  | $ | 401,159 |  |  | $ | 389,438 |  |  | $ | 11,721 |  |  |  | 3.0 | % |
| Percentage of product revenues |  |  | 54.3 | % |  |  | 52.7 | % |  |  |  |  |  |  |  |  | 52.7 | % |  |  | 55.7 | % |  |  |  |  |  |  |
| Service and subscription |  |  | 248,561 |  |  |  | 228,779 |  |  |  | 19,782 |  |  |  | 8.6 | % |  |  | 228,779 |  |  |  | 195,685 |  |  |  | 33,094 |  |  |  | 16.9 | % |
| Percentage of service and subscription revenues |  |  | 65.4 | % |  |  | 65.3 | % |  |  |  |  |  |  |  |  | 65.3 | % |  |  | 63.1 | % |  |  |  |  |  |  |
| Total gross profit |  | $ | 754,720 |  |  | $ | 629,938 |  |  | $ | 124,782 |  |  |  | 19.8 | % |  | $ | 629,938 |  |  | $ | 585,123 |  |  | $ | 44,815 |  |  |  | 7.7 | % |
| Percentage of net revenues |  |  | 57.5 | % |  |  | 56.6 | % |  |  |  |  |  |  |  |  | 56.6 | % |  |  | 58.0 | % |  |  |  |  |  |  |

[0000950170-23-044385:mdna:37]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing, engineering, and document control at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0000950170-23-044385:mdna:38]
Product gross profit increased to $506.2 million for the year ended June 30, 2023, from $401.2 million in fiscal 2022, primarily due to increased product revenues along with lower amortization of intangibles of $3.8 million due to certain intangibles being fully amortized, and lower distribution costs of $1.1 million due to easing of supply chain constraints, partially offset by higher direct product costs, higher excess and obsolete inventory charges of $6.3 million and higher warranty reserves cost of $2.1 million..

[0000950170-23-044385:mdna:39]
Product gross profit increased to $401.2 million for the year ended June 30, 2022, from $389.4 million in fiscal 2021, primarily due to increased revenues along with lower amortization of intangibles of $9.5 million due to certain intangibles being fully amortized, and lower excess and obsolete inventory charges of $3.0 million, partially offset by higher direct product costs and higher distribution cost of $18.5 million.

[0000950170-23-044385:mdna:40]
Our cost of service and subscription revenues consist primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts as well as third-party professional services costs, data center costs and cloud hosting service costs.

[0000950170-23-044385:mdna:41]
Service and subscription gross profit increased to $248.6 million for the year ended June 30, 2023, from $228.8 million in fiscal 2022, primarily due to higher service and subscription revenues partially offset by higher professional services fees and increased cloud service costs.

[0000950170-23-044385:mdna:42]
Service and subscription gross profit increased to $228.8 million for the year ended June 30, 2022, from $195.7 million in fiscal 2021, primarily due to higher service and subscription revenues partially offset by higher professional fees and increased cloud service costs.

[0000950170-23-044385:mdna:43]
Operating Expenses

[0000950170-23-044385:mdna:44]
The following table presents operating expenses for the fiscal years ended June 30, 2023, 2022 and 2021 (in thousands, except percentages):

[0000950170-23-044385:mdna:45]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | $Change |  |  | %Change |  |  | June 30,2022 |  |  | June 30, 2021 |  |  | $Change |  |  | %Change |  |
| Research and development |  | $ | 214,270 |  |  | $ | 190,591 |  |  | $ | 23,679 |  |  |  | 12.4 | % |  | $ | 190,591 |  |  | $ | 196,995 |  |  | $ | (6,404 | ) |  |  | (3.3 | )% |
| Sales and marketing |  |  | 336,906 |  |  |  | 294,470 |  |  |  | 42,436 |  |  |  | 14.4 | % |  |  | 294,470 |  |  |  | 276,841 |  |  |  | 17,629 |  |  |  | 6.4 | % |
| General and administrative |  |  | 89,934 |  |  |  | 68,697 |  |  |  | 21,237 |  |  |  | 30.9 | % |  |  | 68,697 |  |  |  | 66,201 |  |  |  | 2,496 |  |  |  | 3.8 | % |
| Acquisition and integration costs |  |  | 390 |  |  |  | 7,009 |  |  |  | (6,619 | ) |  |  | (94.4 | )% |  |  | 7,009 |  |  |  | 1,975 |  |  |  | 5,034 |  |  |  | 254.9 | % |
| Restructuring and related charges |  |  | 2,860 |  |  |  | 1,748 |  |  |  | 1,112 |  |  |  | 63.6 | % |  |  | 1,748 |  |  |  | 2,625 |  |  |  | (877 | ) |  |  | (33.4 | )% |
| Amortization of intangible assets |  |  | 2,047 |  |  |  | 3,235 |  |  |  | (1,188 | ) |  |  | (36.7 | )% |  |  | 3,235 |  |  |  | 6,110 |  |  |  | (2,875 | ) |  |  | (47.1 | )% |
| Total operating expenses |  | $ | 646,407 |  |  | $ | 565,750 |  |  | $ | 80,657 |  |  |  | 14.3 | % |  | $ | 565,750 |  |  | $ | 550,747 |  |  | $ | 15,003 |  |  |  | 2.7 | % |

[0000950170-23-044385:mdna:46]
The following table highlights our operating expenses and operating income as a percentage of net revenues for the fiscal years ended June 30, 2023, 2022 and 2021:

[0000950170-23-044385:mdna:47]
|  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |
| Research and development |  |  | 16.3 | % |  |  | 17.1 | % |  |  | 19.5 | % |
| Sales and marketing |  |  | 25.7 | % |  |  | 26.5 | % |  |  | 27.4 | % |
| General and administrative |  |  | 6.9 | % |  |  | 6.2 | % |  |  | 6.6 | % |
| Acquisition and integration costs |  |  | 0.0 | % |  |  | 0.6 | % |  |  | 0.2 | % |
| Restructuring and related charges |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 0.3 | % |
| Amortization of intangible assets |  |  | 0.2 | % |  |  | 0.3 | % |  |  | 0.6 | % |
| Total operating expenses |  |  | 49.3 | % |  |  | 50.9 | % |  |  | 54.6 | % |
| Operating income |  |  | 8.3 | % |  |  | 5.8 | % |  |  | 3.4 | % |

[0000950170-23-044385:mdna:48]
Research and Development Expenses

[0000950170-23-044385:mdna:49]
Research and development expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), consultant fees and prototype expenses related to the design, development, and testing of our products.

[0000950170-23-044385:mdna:50]
Research and development expenses increased by $23.7 million or 12.42% for the year ended June 30, 2023 as compared to fiscal 2022, primarily due to a $15.4 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation and higher headcount, a $3.8 million increase in third-party software licenses and engineering project costs, a $2.2 million increase in contractor and consultant fees, a $1.3 million increase in facility and information technology costs and a $2.3 million increase in other costs primarily related to travel.

[0000950170-23-044385:mdna:51]
Research and development expenses decreased by $6.4 million or 3.25% for the year ended June 30, 2022 as compared to fiscal 2021, primarily due to a $0.7 million decrease in personnel costs, a $3.8 million decrease in facility and information technology costs, a $1.2 million decrease in third-party software licenses and engineering project costs and a $1.0 million decrease in other expenses, partially offset by a $0.3 million increase in travel expenses.

[0000950170-23-044385:mdna:52]
Sales and Marketing Expenses

[0000950170-23-044385:mdna:53]
Sales and marketing expenses consist of personnel costs (which consists of compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0000950170-23-044385:mdna:54]
Sales and marketing expenses increased by $42.4 million or 14.4% for the year ended June 30, 2023, as compared to fiscal 2022, primarily due to a $35.1 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $5.9 million increase in travel expenses due to loosening of COVID-19 restrictions, and a $1.4 million increase in other expenses primarily professional fees and sales and marketing activities.

[0000950170-23-044385:mdna:55]
Sales and marketing expenses increased by $17.6 million or 6.4% for the year ended June 30, 2022, as compared to fiscal 2021, primarily due to a $6.6 million increase in personnel costs primarily due to higher headcount, a $7.0 million increase in marketing sales and promotional costs, a $5.5 million increase in travel expenses due to loosening of COVID-19 restrictions, partially offset by a $1.5 million decrease in professional fees and equipment related costs.

[0000950170-23-044385:mdna:56]
General and Administrative Expenses

[0000950170-23-044385:mdna:57]
General and administrative expenses consist of primarily of personnel costs (which consists of compensation, benefits and share-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0000950170-23-044385:mdna:58]
General and administrative expenses increased by $21.2 million or 30.9% for the year ended June 30, 2023, as compared to fiscal 2022, primarily due to a $10.1 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation and higher headcount, a $6.2 million increase in professional fees primarily for legal, a $5.1 million increase for litigation settlement charges, a $0.9 million increase in system transition costs, partially offset by a $1.2 million decrease in other expenses primarily for travel and facilities related costs.

[0000950170-23-044385:mdna:59]
General and administrative expenses increased by $2.5 million or 3.8% for the year ended June 30, 2022, as compared to fiscal 2021, primarily due to a $1.4 million increase in third party software and equipment related costs, a $1.9 million increase in facilities and related costs, partially offset by a $0.2 million decrease in personnel costs and a $0.6 million decrease in travel and professional fees.

[0000950170-23-044385:mdna:60]
Acquisition and Integration Costs

[0000950170-23-044385:mdna:61]
As a result of our acquisitions of Ipanema in fiscal 2022, and Aerohive Networks, Inc. (“Aerohive”) in fiscal 2020, we incurred $0.4 million, $7.0 million and $2.0 million of acquisition and integration costs in fiscal years ended June 30, 2023, 2022 and 2021, respectively.

[0000950170-23-044385:mdna:62]
For fiscal 2023, we incurred $0.4 million of acquisition and integration costs which consisted primarily of professional fees and certain compensation charges related to the Acquisition.

[0000950170-23-044385:mdna:63]
For fiscal 2022, we incurred $7.0 million of acquisition and integration costs which consisted primarily of professional fees for product integration, system integration, financial, legal and advisory services related to the Acquisition.

[0000950170-23-044385:mdna:64]
For fiscal 2021, we incurred $2.0 million of integration costs which consisted primarily of additional professional fees for system integration and financial services related to the Aerohive acquisition.

[0000950170-23-044385:mdna:65]
Restructuring and Related Charges

[0000950170-23-044385:mdna:66]
During the fiscal years ended June 30, 2023, 2022 and 2021, we recorded restructuring and related charges of $2.9 million, $1.7 million and $2.6 million, respectively.

[0000950170-23-044385:mdna:67]
Fiscal year 2023

[0000950170-23-044385:mdna:68]
During fiscal 2023, the Company recorded $2.9 million of restructuring charges which primarily comprised of $2.0 million of facility related charges related to our previously impaired facilities and $0.9 million in charges associated with our restructuring plan initiated in the third quarter of fiscal 2023 to transform our business and facilities infrastructure.

[0000950170-23-044385:mdna:69]
Fiscal year 2022

[0000950170-23-044385:mdna:70]
During fiscal 2022, the Company recorded $1.7 million of restructuring charges which primarily comprised of facility related charges. The facility restructuring charges included some impairment charges and additional facilities expenses related to previously impaired facilities. During fiscal 2022, the Company completed the reduction-in-force action initiated in the third quarter of fiscal 2020.

[0000950170-23-044385:mdna:71]
Fiscal year 2021

[0000950170-23-044385:mdna:72]
During fiscal 2021, we continued our cost reduction initiative that began in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of $1.5 million, related to the 2020 Plan. In addition, we had facility-related charges of $1.1 million, related to our previously impaired facilities.

[0000950170-23-044385:mdna:73]
Amortization of Intangible Assets

[0000950170-23-044385:mdna:74]
During the fiscal years ended June 30, 2023, 2022 and 2021, we recorded $2.0 million, $3.2 million and $6.1 million, respectively, of amortization expense in operating expenses primarily for certain intangibles related to the acquisitions of the Ipanema, and Aerohive businesses. The decrease in amortization expense in fiscal 2023 from fiscal 2022 was primarily due to certain acquired intangibles from previous acquisitions becoming fully amortized. The decrease in amortization expense in fiscal 2022 from fiscal 2021 was primarily due to certain acquired intangibles from previous acquisitions becoming fully amortized, partially offset by an increase from the amortization of acquired intangibles from the Ipanema acquisition.

[0000950170-23-044385:mdna:75]
Interest Income

[0000950170-23-044385:mdna:76]
Interest income was $3.2 million, $0.4 million and $0.4 million in fiscal years ended June 30, 2023, 2022 and 2021, respectively. Interest income increased in fiscal 2023 as compared to fiscal 2022 primarily due to higher interest earned cash deposits. Interest income remained flat in fiscal 2022 from fiscal 2021.

[0000950170-23-044385:mdna:77]
Interest Expense

[0000950170-23-044385:mdna:78]
We incurred $17.4 million, $12.8 million, and $22.9 million of interest expense for fiscal years ended June 30, 2023, 2022 and 2021, respectively. The increase in interest expense in fiscal year ended June 30, 2023 was primarily driven by higher average rates under our Credit Agreements and write-off the unamortized deferred financing costs related to our 2019 Credit Agreement, as we amended the 2019 Credit Agreement and entered into the 2023 Credit Agreement during June 2023. The decrease in interest expense in fiscal year ended June 30, 2022 as compared to fiscal 2021 was primarily driven by lower average loan balances and lower average rates under our 2019 Credit Agreement. For a discussion of our credit agreements, see the section titled "Liquidity and Capital Resources" below.

[0000950170-23-044385:mdna:79]
Other Income (Expense), net

[0000950170-23-044385:mdna:80]
We had other income of less than $0.1 million and $0.4 million in fiscal years ended June 30, 2023 and 2022, respectively, and other expense of $1.7 million in fiscal 2021. The other income for fiscal years ended June 30, 2023 and 2022 was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars. The other expense for fiscal 2021 was primarily due to foreign exchange losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-23-044385:mdna:81]
Provision for Income Taxes

[0000950170-23-044385:mdna:82]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rate differs from the U.S. federal statutory rate of 21% primarily due to the impact of (i) GILTI, (ii) the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions, (iii) foreign income taxes of our international subsidiaries, and (iv) U.S. state taxes. For the fiscal years ended June 30, 2023, 2022 and 2021, we recorded income tax provisions of $16.0 million, $7.9 million, and $8.2 million respectively.

[0000950170-23-044385:mdna:83]
For fiscal 2023, 2022 and 2021, our tax provision primarily related to taxes on our foreign operations, including foreign withholding taxes remitted to foreign tax authorities by customers on our behalf, tax expense related to the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business and state taxes in states where we have exhausted available Net Operating Losses or are subject to certain franchise taxes qualifying as income tax under the relevant tax accounting guidance. In addition, our tax provision for the fiscal year ended June 30, 2023 included $3.2 million of U.S. federal tax.

[0000950170-23-044385:mdna:84]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 16, Income Taxes, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K.

[0000950170-23-044385:mdna:85]
Critical Accounting Policies and Estimates

[0000950170-23-044385:mdna:86]
Our significant accounting policies are more fully described in Note 2, Summary of Significant Accounting Policies, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0000950170-23-044385:mdna:87]
Revenue Recognition

[0000950170-23-044385:mdna:88]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from SaaS and service fees relating to maintenance contracts, professional services, and training for our products. We sell our products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0000950170-23-044385:mdna:89]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, we consider the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0000950170-23-044385:mdna:90]
We generally do not grant return privileges and pricing credits to our value-added resellers, non-stocking distributors and end-user customers, except for defective products during the warranty period. We may provide sales incentives and other programs to these customers which are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the historical actuals.

[0000950170-23-044385:mdna:91]
Our stocking distributors are allowed certain price adjustments in the form of rebates and limited stock rotation rights. In determining the transaction price, we consider these rebates to be variable consideration which are estimated based on an analysis of historical claims at the distributor level. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotations are an additional form of variable consideration and are estimated based on an analysis of historical return rates.

[0000950170-23-044385:mdna:92]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price. The stand-alone selling prices are determined based on the prices at which we separately sell these products. For items that are not sold separately, we estimate the stand-alone selling prices using other observable inputs.

[0000950170-23-044385:mdna:93]
Our performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of our product sales revenues are recognized at a point in time and our service and subscription revenues are recognized over time. For revenues recognized over time, we use an input measure, days elapsed, to measure progress.

[0000950170-23-044385:mdna:94]
See Note 3, Revenues, in Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information.

[0000950170-23-044385:mdna:95]
Business Combinations

[0000950170-23-044385:mdna:96]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all tangible and intangible assets acquired and liabilities assumed are recorded at their respective fair values at the acquisition date. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to expected future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0000950170-23-044385:mdna:97]
Inventory Valuation and Purchase Commitments

[0000950170-23-044385:mdna:98]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0000950170-23-044385:mdna:99]
New Accounting Pronouncements

[0000950170-23-044385:mdna:100]
See Note 2, Summary of Significant Accounting Policies, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0000950170-23-044385:mdna:101]
Liquidity and Capital Resources

[0000950170-23-044385:mdna:102]
The following summarizes information regarding our cash and cash equivalent (in thousands):

[0000950170-23-044385:mdna:103]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Cash and cash equivalents |  | $ | 234,826 |  |  | $ | 194,522 |  |

[0000950170-23-044385:mdna:104]
As of June 30, 2023, our principal sources of liquidity consisted of cash and cash equivalents of $234.8 million, accounts receivable, net of $182.0 million and available borrowings under our five-year 2023 Revolving Facility (as defined below) of $125.0

[0000950170-23-044385:mdna:105]
million. We anticipate our principal uses of cash and cash equivalents for fiscal 2024 will be purchases of finished goods inventory from our contract manufacturers, payroll, share repurchases, payments under debt obligations and related interest, payments under lease obligations, purchases of property and equipment and other operating expenses related to the development and marketing of our products. We believe that our existing cash and cash equivalents, cash flows from operations, and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months. We are not currently aware of any material cash requirements beyond the next 12 months other than those described above for fiscal 2023 and our known contractual obligations. See the section titled “Contractual Obligations” below.

[0000950170-23-044385:mdna:106]
On May 18, 2022, our Board of Directors authorized a share repurchase program with authorization to repurchase up to $200.0 million of our common stock over a three-year period beginning in our fiscal year commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. The current repurchase authorization supersedes and replaces any previously authorized repurchase programs. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the year ended June 30, 2023 we repurchased a total of 5,375,391 shares of common stock on the open market at a total cost of $99.9 million with an average price of $18.58 per share. As of June 30, 2023, we have $100.1 million available under our share repurchase program.

[0000950170-23-044385:mdna:107]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”). The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (“2019 Revolving Facility”). In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0000950170-23-044385:mdna:108]
At our election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement was either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranged from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranged from 1.25% to 3.50%, in each case based on Extreme’s Consolidated Leverage Ratio. All Eurodollar loans are subject to a Base Rate floor of 0.00%. The 2019 Credit Agreement was secured by substantially all of our assets.

[0000950170-23-044385:mdna:109]
The 2019 Credit Agreement required us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also included covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also included customary events of default which may result in acceleration of the outstanding balance.

[0000950170-23-044385:mdna:110]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into a Second Amendment which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required us to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we came into compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into a Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into a Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0000950170-23-044385:mdna:111]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement resulted in our Eurodollar loan spread decreasing from 4.5% during the Suspension Period to 2.75%, the unused facility commitment fee decreasing from 0.4% to 0.35%, and the limitation on revolver borrowings being removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0000950170-23-044385:mdna:112]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that

[0000950170-23-044385:mdna:113]
is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use proceeds of the loans for working capital and general corporate purposes. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit, which was subsequently paid off on July 7, 2023.

[0000950170-23-044385:mdna:114]
At the Company’s election, the initial term loan (the “Initial Term Loan”) under the 2023 Credit Agreement may be made as either a base rate loan or a Secured Overnight Financing Data Rate (“SOFR loan"). The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s Consolidated Leverage Ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company also agrees to pay other closing fees, arrangement fees, and administration fees.

[0000950170-23-044385:mdna:115]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-23-044385:mdna:116]
Key Components of Cash Flows and Liquidity

[0000950170-23-044385:mdna:117]
A summary of the sources and uses of cash and cash equivalents is as follows for the fiscal years ended June 30, 2023, 2022, and 2021 (in thousands):

[0000950170-23-044385:mdna:118]
|  | Year Ended |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |
| Net cash provided by operating activities | $ | 249,212 |  |  | $ | 128,177 |  |  | $ | 144,535 |  |
| Net cash used in investing activities |  | (13,800 | ) |  |  | (84,950 | ) |  |  | (17,176 | ) |
| Net cash used in financing activities |  | (194,783 | ) |  |  | (94,663 | ) |  |  | (74,782 | ) |
| Foreign currency effect on cash and cash equivalents |  | (325 | ) |  |  | (936 | ) |  |  | 445 |  |
| Net increase (decrease) in cash and cash equivalents | $ | 40,304 |  |  | $ | (52,372 | ) |  | $ | 53,022 |  |

[0000950170-23-044385:mdna:119]
Cash and cash equivalent was $234.8 million at June 30, 2023, representing an increase of $40.3 million from $194.5 million at June 30, 2022. This increase was primarily due to cash provided by operating activities of $249.2 million, which is offset by cash used in financing activities of $194.8 million mainly as a result of payments on the  2019 Initial Term Loan and share repurchases and cash used in investing activities of $13.8 million primarily for the purchase of property and equipment.

[0000950170-23-044385:mdna:120]
Cash was $194.5 million at June 30, 2022, representing a decrease of $52.4 million from $246.9 million at June 30, 2021. This decrease was primarily due to cash used in financing activities of $94.7 million mainly as a result of payments on the Term Loan and share repurchases and cash used in investing activities of $85.0 million, mainly for acquisition of Ipanema partially offset by cash provided by operations of $128.2 million.

[0000950170-23-044385:mdna:121]
Net Cash Provided by Operating Activities

[0000950170-23-044385:mdna:122]
Cash provided by operating activities during the fiscal year ended June 30, 2023 was $249.2 million. Factors contributing to cash provided by operating activities were net income of $78.1 million, non-cash expenses of $104.6 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included decrease in account receivable and increases in accounts payable, accrued compensation and deferred revenue. These amounts were partially offset by increases in inventories and prepaid expenses and other assets and decreases in operating lease liabilities.

[0000950170-23-044385:mdna:123]
Cash provided by operating activities during the fiscal year ended June 30, 2022 was $128.2 million. Factors contributing to cash provided by operating activities were net income of $44.3 million, non-cash expenses of $104.0 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included increases in accounts payable and deferred revenue. These amounts were partially offset by increases in accounts receivable, inventories and prepaid expenses and other assets and decreases in accrued compensation, current and long-term liabilities and operating lease liabilities.

[0000950170-23-044385:mdna:124]
Cash provided by operating activities during the fiscal year ended June 30, 2021 was $144.5 million. Factors contributing to cash provided by operating activities were net income of $1.9 million, non-cash expenses of $121.7 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and imputed interest. Other sources of cash for the period included a decrease in inventory and increases in accounts payable, accrued compensation and deferred revenue. These amounts were partially offset by increases in accounts receivable and prepaid expenses and other current assets and decreases in the current and long-term liabilities and operating lease liabilities.

[0000950170-23-044385:mdna:125]
Net Cash Used in Investing Activities

[0000950170-23-044385:mdna:126]
Cash used in investing activities during the fiscal year ended June 30, 2023 was $13.8 million, primarily due to the payment of $13.8 million for the purchases of property and equipment.

[0000950170-23-044385:mdna:127]
Cash used in investing activities during the fiscal year ended June 30, 2022 was $85.0 million, primarily due to the payment of $69.5 million (net of cash acquired) for the Acquisition and $15.4 million for purchases of property and equipment.

[0000950170-23-044385:mdna:128]
Cash used in investing activities during the fiscal year ended June 30, 2021 was $17.2 million for the purchases of property and equipment.

[0000950170-23-044385:mdna:129]
Net Cash Used in by Financing Activities

[0000950170-23-044385:mdna:130]
Cash used in financing activities during the fiscal year ended June 30, 2023 was $194.8 million due primarily to share repurchases of $99.9 million, debt repayments of $108.6 million, payments of debt financing cost of $3.2 million, $3.0 million of deferred payments on acquisitions and a $5.1 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”). The amounts were partially offset by cash received of $25.0 million from the 2023 Revolving Facility.

[0000950170-23-044385:mdna:131]
Cash used in financing activities during the fiscal year ended June 30, 2022 was $94.7 million due primarily to share repurchases of $45.0 million, debt repayments of $38.1 million, payments of contingent consideration of $1.0 million and $4.0 million of deferred payments on acquisitions and a $6.5 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options.

[0000950170-23-044385:mdna:132]
Cash used in financing activities during the fiscal year ended June 30, 2021 was $74.8 million due primarily to debt repayments of $74.0 million, payments of contingent consideration of $1.3 million and $4.0 million of deferred payments on acquisitions. This was partially offset by $4.5 million of proceeds from issuance of shares of our common stock under our ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards.

[0000950170-23-044385:mdna:133]
Foreign Currency Effect on Cash and cash equivalents

[0000950170-23-044385:mdna:134]
Foreign currency effect on cash and cash equivalents increased in 2023, primarily due to changes in exchange rates between the U.S. Dollar and particularly the Indian Rupee, U.K. Pound, and the Euro.

[0000950170-23-044385:mdna:135]
Contractual Obligations

[0000950170-23-044385:mdna:136]
As of June 30, 2023, we have contractual obligations for debt obligations, purchase obligations, lease obligations and other obligations.

[0000950170-23-044385:mdna:137]
Our debt obligations relate to amounts owed under our 2023 Credit Agreement. As of June 30, 2023, we have $225.0 million of debt outstanding which is payable in quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 8, Debt, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our debt obligations.

[0000950170-23-044385:mdna:138]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of June 30, 2023, we have non-cancelable commitments to purchase $69.6 million of inventory. See Note 10, Commitments and Contingencies, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our purchase obligations.

[0000950170-23-044385:mdna:139]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2032. As of June 30, 2023, the value of our obligations under operating leases was $48.2 million. See Note 9, Leases, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our lease obligations.

[0000950170-23-044385:mdna:140]
We have contractual commitments with our suppliers which represent commitments for future services. As of June 30, 2023, we have contractual commitments of $34.5 million that are due through our fiscal year 2027.

[0000950170-23-044385:mdna:141]
We have immaterial income tax liabilities related to uncertain tax positions and we are unable to reasonably estimate the timing of the settlement of those liabilities.

[0000950170-23-044385:mdna:142]
We do not have any material commitments for capital expenditures as of June 30, 2023.

[0000950170-23-044385:mdna:143]
Off-Balance Sheet Arrangements

[0000950170-23-044385:mdna:144]
We did not have any off-balance sheet arrangements as of June 30, 2023.
