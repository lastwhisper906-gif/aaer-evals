# EXTR notes — 0000950170-23-044385


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-23-044385:notes:1]
Portions of the registrant's definitive proxy statement for the year ended June 30, 2023 Annual Meeting of Stockholders to be filed with the Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated herein by reference in Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-23-044385:notes:2]
1. Description of Business and Basis of Presentation

[0000950170-23-044385:notes:3]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0000950170-23-044385:notes:4]
Fiscal Year

[0000950170-23-044385:notes:5]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2023” or “ 2023”; “fiscal 2022” or “2022”; “fiscal 2021” or “2021” represent the fiscal years ending, respectively.

[0000950170-23-044385:notes:6]
Principles of Consolidation

[0000950170-23-044385:notes:7]
The consolidated financial statements include the accounts of Extreme Networks, Inc. and its wholly-owned subsidiaries. All inter-company balances and transactions have been eliminated on consolidation.

[0000950170-23-044385:notes:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month-end exchange rates; and revenues and expenses are translated using the monthly average rate.

[0000950170-23-044385:notes:9]
Accounting Estimates

[0000950170-23-044385:notes:10]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the financial statements and the accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-23-044385:notes:11]
2. Summary of Significant Accounting Policies

[0000950170-23-044385:notes:12]
Revenue Recognition

[0000950170-23-044385:notes:13]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers. The Company derives revenues primarily from sales of its networking equipment, with the remaining revenues generated from software delivered as a service and service fees relating to maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0000950170-23-044385:notes:14]
See Note 3, Revenues, for further discussion.

[0000950170-23-044385:notes:15]
Cash and Cash Equivalents

[0000950170-23-044385:notes:16]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents.

[0000950170-23-044385:notes:17]
Allowance for Product Returns

[0000950170-23-044385:notes:18]
The Company maintains estimates for product returns based on its historical returns, analysis of credit memos and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is shown as a reduction of accounts receivable as there is a contractual right of offset and returns are applied to accounts receivable balances outstanding as of the balance sheet date. There have not been material revisions to the estimated product returns for any periods presented.

[0000950170-23-044385:notes:19]
Allowance for Credit Losses

[0000950170-23-044385:notes:20]
The Company maintains an allowance for credit losses which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring certain of its customers in the Asia-Pacific region to pay cash in advance or secure letters of credit when placing an order with the Company.

[0000950170-23-044385:notes:21]
Inventories

[0000950170-23-044385:notes:22]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory is obsolete or may be in excess of anticipated demand based upon assumptions about future demand. At the point of the loss recognition, a new lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0000950170-23-044385:notes:23]
Long-Lived Assets

[0000950170-23-044385:notes:24]
Long-lived assets include (a) property and equipment, (b) operating lease right-of-use (“ROU”) assets, (c) goodwill and intangible assets, and (d) other assets. Property and equipment, ROU assets, and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0000950170-23-044385:notes:25]
(a) Property and Equipment, Net

[0000950170-23-044385:notes:26]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and purchased software. Estimated useful lives of three to seven years are used for office equipment and furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms.

[0000950170-23-044385:notes:27]
(b) Leases

[0000950170-23-044385:notes:28]
The Company leases facilities, equipment and vehicles under operating leases that expire on various dates through fiscal 2033. The Company determines if an arrangement is a lease at inception. We evaluate the classification of leases at commencement date and as necessary, at modification. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as ROU assets with associated operating lease liabilities on the consolidated balance sheets.

[0000950170-23-044385:notes:29]
ROU assets under the Company’s operating leases represent the Company’s right to use an underlying asset over the lease term. Operating lease liabilities represent the Company’s obligation to make payments arising from the lease. The ROU asset is reduced over a straight-line or other systematic basis representative of the pattern in which the Company expects to consume the ROU assets’ future economic benefits. The ROU asset is also adjusted for leasehold improvements paid by the lessor, lease incentives, and asset impairments, among other things.

[0000950170-23-044385:notes:30]
See Note 9, Leases, for further discussion.

[0000950170-23-044385:notes:31]
(c) Goodwill and Intangible Assets

[0000950170-23-044385:notes:32]
Goodwill and intangible assets are generated as a result of business combinations and are comprised of, among other things, developed technology, customer relationships, trade names, and licensing agreements.

[0000950170-23-044385:notes:33]
The remaining lives of intangible assets are considered regularly along with assessments of impairment and lives are adjusted or impairment charges taken when required.

[0000950170-23-044385:notes:34]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company has one reporting unit and performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceeds directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Based on the results of the goodwill impairment analysis, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0000950170-23-044385:notes:35]
Business Combinations

[0000950170-23-044385:notes:36]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, useful lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0000950170-23-044385:notes:37]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0000950170-23-044385:notes:38]
Deferred Revenue

[0000950170-23-044385:notes:39]
Deferred revenue represents amounts for (i) deferred maintenance, support, and software as a service (“SaaS”) revenues, and (ii) other deferred revenue including professional services when the revenue recognition criteria have not been met.

[0000950170-23-044385:notes:40]
Product Warranties and Guarantees

[0000950170-23-044385:notes:41]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0000950170-23-044385:notes:42]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0000950170-23-044385:notes:43]
Stock-based Compensation

[0000950170-23-044385:notes:44]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock options and stock purchase options under the 2014 ESPP using the Black-Scholes-Merton option valuation model. The fair value of RSUs is based on the closing stock price of the Company’s common stock on the grant date.

[0000950170-23-044385:notes:45]
The Company grants certain employees with stock options and RSUs that are tied to either company-wide financial performance metrics or certain market metrics. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0000950170-23-044385:notes:46]
Advertising

[0000950170-23-044385:notes:47]
Advertising costs are expensed as incurred. Advertising expenses were immaterial in fiscal years 2023, 2022 and 2021.

[0000950170-23-044385:notes:48]
Income Taxes

[0000950170-23-044385:notes:49]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0000950170-23-044385:notes:50]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions. The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes. For additional discussion, see Note 16, Income Taxes.

[0000950170-23-044385:notes:51]
Recently Issued and Adopted Accounting Pronouncements

[0000950170-23-044385:notes:52]
In December 2022, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which extends the period of time entities can utilize the reference rate reform relief guidance under ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting from December 31, 2022 to December 31, 2024. Upon issuance of ASU 2020-04, the Company elected to apply certain of the optional expedients for contract modifications to its financial instruments impacted by the London Interbank Offered Rate (“LIBOR”) discontinuance. The application of this guidance did not have any impact on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-044385:notes:53]
3. Revenues

[0000950170-23-044385:notes:54]
The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts, and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier consists of a non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0000950170-23-044385:notes:55]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0000950170-23-044385:notes:56]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenues

[0000950170-23-044385:notes:57]
from maintenance contracts and SaaS are recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which generally ranges from one to five years. For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Sales taxes collected from customers are excluded from revenues. Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the historical actuals. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-23-044385:notes:58]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotations are variable consideration and are estimated based on historical return rates and estimates provided by the distributors. Additionally, distributors often need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price. At the time the distributor invoices its end customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these customer rebates to be variable consideration. Such price adjustments are estimated based on an analysis of historical claims at the distributor level. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-23-044385:notes:59]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

[0000950170-23-044385:notes:60]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service, subscription, and SaaS revenues are recognized over time. For revenue recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.

[0000950170-23-044385:notes:61]
At June 30, 2023, the Company had $501.5 million of remaining performance obligations, which are primarily comprised of deferred services, subscription and SaaS revenues. The Company expects to recognize approximately 56% of this amount in fiscal 2024, an additional 21% percent in fiscal 2025 and 23% of the balance thereafter.

[0000950170-23-044385:notes:62]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenue. These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0000950170-23-044385:notes:63]
The Company's total deferred revenue balances at June 30, 2023, 2022 and 2021 were $501.5 million, $401.6 million and $345.6 million, respectively. Revenue recognized for the years ended June 30, 2023, 2022, and 2021, that was included in the deferred revenue balance at the beginning of each period was $232.9 million, $208.4 million and $188.4 million, respectively.

[0000950170-23-044385:notes:64]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals, are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $20.0 million and $16.3 million at June 30, 2023 and 2022, respectively which are included within “Other assets”. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations. Amortization recognized during the years ended 2023, 2022 and 2021 was $9.1 million, $7.5 million and $5.6 million, respectively.

[0000950170-23-044385:notes:65]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-23-044385:notes:66]
Disaggregation of Revenues: The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following tables set forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0000950170-23-044385:notes:67]
|  |  | Year Ended June 30, 2023 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 306,240 |  |  | $ | 266,687 |  |  | $ | 572,927 |  |
| Other |  |  | 60,957 |  |  |  | 23,151 |  |  |  | 84,108 |  |
| Total Americas |  |  | 367,197 |  |  |  | 289,838 |  |  |  | 657,035 |  |
| EMEA |  |  | 390,495 |  |  |  | 169,174 |  |  |  | 559,669 |  |
| APAC |  |  | 19,384 |  |  |  | 76,366 |  |  |  | 95,750 |  |
| Total net revenues |  | $ | 777,076 |  |  | $ | 535,378 |  |  | $ | 1,312,454 |  |

[0000950170-23-044385:notes:68]
|  |  | Year Ended June 30, 2022 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 237,163 |  |  | $ | 266,472 |  |  | $ | 503,635 |  |
| Other |  |  | 27,018 |  |  |  | 17,590 |  |  |  | 44,608 |  |
| Total Americas |  |  | 264,181 |  |  |  | 284,062 |  |  |  | 548,243 |  |
| EMEA |  |  | 325,290 |  |  |  | 151,791 |  |  |  | 477,081 |  |
| APAC |  |  | 17,517 |  |  |  | 69,480 |  |  |  | 86,997 |  |
| Total net revenues |  | $ | 606,988 |  |  | $ | 505,333 |  |  | $ | 1,112,321 |  |

[0000950170-23-044385:notes:69]
|  |  | Year Ended June 30, 2021 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 244,851 |  |  | $ | 240,620 |  |  | $ | 485,471 |  |
| Other |  |  | 31,583 |  |  |  | 16,466 |  |  |  | 48,049 |  |
| Total Americas |  |  | 276,434 |  |  |  | 257,086 |  |  |  | 533,520 |  |
| EMEA |  |  | 250,897 |  |  |  | 136,648 |  |  |  | 387,545 |  |
| APAC |  |  | 14,280 |  |  |  | 74,073 |  |  |  | 88,353 |  |
| Total net revenues |  | $ | 541,611 |  |  | $ | 467,807 |  |  | $ | 1,009,418 |  |

[0000950170-23-044385:notes:70]
For the year ended June 30, 2023, 2022, and 2021, the Company generated 13%, 12% and 11%, respectively, of its revenue from the Netherlands. No other foreign country accounted for 10% or more of the Company’s net revenue for the years ended June 30, 2023, 2022 and 2021.

[0000950170-23-044385:notes:71]
Concentrations

[0000950170-23-044385:notes:72]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0000950170-23-044385:notes:73]
The following table sets forth customers accounting for 10% or more of the Company’s net revenues:

[0000950170-23-044385:notes:74]
|  |  |  |  | Year Ended |  |  |
|  |  | June 30,2023 |  | June 30,2022 |  | June 30, 2021 |
| Westcon Group, Inc. |  | 20% |  | 18% |  | 16% |
| TD Synnex Corporation |  | 18% |  | 20% |  | 19% |
| Jenne, Inc. |  | 15% |  | 16% |  | 18% |

[0000950170-23-044385:notes:75]
The following table sets forth major customers accounting for 10% or more of the Company’s net accounts receivable, as of June 30, 2023 and June 30, 2022:

[0000950170-23-044385:notes:76]
|  |  | June 30,2023 |  | June 30,2022 |
| Jenne, Inc. |  | 39% |  | 28% |
| TD Synnex Corporation |  | 10% |  | 11% |
| ScanSource, Inc. |  | 10% |  | * |
| * Less than 10% of accounts receivable. |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-044385:notes:77]
4. Business Combinations

[0000950170-23-044385:notes:78]
The Company completed one acquisition during the fiscal year ended June 30, 2022. The acquisition was accounted for using the acquisition method of accounting. The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The purchase price of the acquisition has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition. Inventories were valued at fair value using the net realizable value approach. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount the Company would be required to pay to a third party to assume the obligation. Intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. Results of operations of the acquired entity are included in the Company’s operations beginning with the closing date of acquisition.

[0000950170-23-044385:notes:79]
Fiscal 2022 Acquisition

[0000950170-23-044385:notes:80]
Ipanema Acquisition

[0000950170-23-044385:notes:81]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of InfoVista SAS  ("InfoVista") pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to InfoVista was $70.9 million, which was funded entirely by cash. The primary reason for the acquisition was to acquire the talent and the technology to allow the Company to expand its portfolio with new cloud-managed SD-WAN and security offerings to support its enterprise customers.

[0000950170-23-044385:notes:82]
The following table below summarizes the purchase price allocation of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0000950170-23-044385:notes:83]
|  | Final Allocation as ofJune 30, 2022 |  |
| Cash and cash equivalents | $ | 1,364 |  |
| Accounts receivable, net |  | 1,434 |  |
| Inventories |  | 274 |  |
| Prepaid expenses and other current assets |  | 610 |  |
| Property and equipment |  | 46 |  |
| Other assets |  | 21 |  |
| Accounts payable |  | (976 | ) |
| Accrued compensation and benefits |  | (1,837 | ) |
| Accrued warranty |  | (41 | ) |
| Other accrued liabilities |  | (122 | ) |
| Deferred revenue |  | (10,134 | ) |
| Deferred taxes |  | (4,320 | ) |
| Other liabilities |  | (723 | ) |
| Net tangible liabilities |  | (14,404 | ) |
| Identifiable intangible assets |  | 16,300 |  |
| Goodwill |  | 68,985 |  |
| Total intangible assets acquired |  | 85,285 |  |
| Total net assets acquired | $ | 70,881 |  |

[0000950170-23-044385:notes:84]
The following table presents details of the identifiable intangible assets acquired as part of the Ipanema acquisition (in thousands, except years)

[0000950170-23-044385:notes:85]
| Intangible Assets |  | Weighted Average Estimated Useful Life(in years) |  |  | Amount |  |
| Developed technologies |  |  | 6 |  |  | $ | 14,500 |  |
| Customer relationships |  |  | 4 |  |  |  | 1,800 |  |
| Total identifiable intangible assets |  |  |  |  | $ | 16,300 |  |

[0000950170-23-044385:notes:86]
The amortization for the developed technologies is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles assets” in the accompanying consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Ipanema. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as this acquisition is a nontaxable stock acquisition.

[0000950170-23-044385:notes:87]
The results of operations of Ipanema are included in the accompanying consolidated results of operations beginning September 15, 2021. The overall results of operations of Ipanema were not material to the consolidated financial statements of Extreme.

[0000950170-23-044385:notes:88]
Pro forma financial information

[0000950170-23-044385:notes:89]
The following unaudited pro forma results of operations are presented as though the Acquisition had occurred as of July 1, 2020, the beginning of fiscal 2021, after giving effect to purchase accounting adjustments relating to deferred revenue, depreciation and amortization of intangibles and acquisition and integration costs.

[0000950170-23-044385:notes:90]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2021, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions, which could alter the unaudited pro forma results.

[0000950170-23-044385:notes:91]
The unaudited pro forma financial information for the year ended June 30, 2022 combines the results for Extreme for such periods assuming the transaction closed on July 1, 2020, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s

[0000950170-23-044385:notes:92]
historical results up to the Acquisition Date. The unaudited pro forma financial information for the year ended June 30, 2021 combines the historical results of operations for Extreme assuming the transaction closed on July 1, 2020 and historical results for Ipanema.

[0000950170-23-044385:notes:93]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0000950170-23-044385:notes:94]
|  | Year Ended |  |
|  | June 30,2022 |  | June 30,2021 |  |
| Net revenue | $ | 1,115,942 |  | $ | 1,031,825 |  |
| Net income | $ | 53,659 |  | $ | (6,755 | ) |
| Net income per share – basic | $ | 0.41 |  | $ | (0.05 | ) |
| Net income per share – diluted | $ | 0.40 |  | $ | (0.05 | ) |
| Shares used in per share calculation – basic |  | 129,437 |  |  | 124,019 |  |
| Shares used in per share calculation – diluted |  | 133,494 |  |  | 124,019 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-23-044385:notes:95]
5. Balance Sheet Components

[0000950170-23-044385:notes:96]
Accounts Receivable, Net

[0000950170-23-044385:notes:97]
The following table summarizes the Company's accounts receivable (in thousands):

[0000950170-23-044385:notes:98]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Accounts receivable |  | $ | 440,298 |  |  | $ | 368,778 |  |
| Customer rebates |  |  | (222,246 | ) |  |  | (163,953 | ) |
| Allowance for credit losses |  |  | (882 | ) |  |  | (695 | ) |
| Allowance for product returns |  |  | (35,125 | ) |  |  | (20,033 | ) |
| Accounts receivable, net |  | $ | 182,045 |  |  | $ | 184,097 |  |

[0000950170-23-044385:notes:99]
The following table summarizes the Company's allowance for credit losses (in thousands):

[0000950170-23-044385:notes:100]
| Description |  | Balance atbeginning ofperiod |  |  | Provision for expected credit losses |  |  | Deductions (1) |  |  | Balance atend of period |  |
| Year Ended June 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 695 |  |  | $ | 464 |  |  | $ | (277 | ) |  | $ | 882 |  |
| Year Ended June 30, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 986 |  |  | $ | 39 |  |  | $ | (330 | ) |  | $ | 695 |  |
| Year Ended June 30, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 1,212 |  |  | $ | 409 |  |  | $ | (635 | ) |  | $ | 986 |  |

[0000950170-23-044385:notes:101]
(1)
Uncollectible accounts written off, net of recoveries.

[0000950170-23-044385:notes:102]
The following table summarizes the Company’s allowance for product returns (in thousands):

[0000950170-23-044385:notes:103]
| Description |  | Balance atbeginning ofperiod |  |  | Additions |  |  | Deductions |  |  | Balance atend of period |  |
| Year Ended June 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 20,033 |  |  | $ | 104,028 |  |  | $ | (88,936 | ) |  | $ | 35,125 |  |
| Year Ended June 30, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 17,371 |  |  | $ | 67,407 |  |  | $ | (64,745 | ) |  | $ | 20,033 |  |
| Year Ended June 30, 2021: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 27,963 |  |  | $ | 67,113 |  |  | $ | (77,705 | ) |  | $ | 17,371 |  |

[0000950170-23-044385:notes:104]
Inventories, Net

[0000950170-23-044385:notes:105]
The following table summarizes the Company’s inventory by category (in thousands):

[0000950170-23-044385:notes:106]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Finished goods |  | $ | 78,180 |  |  | $ | 40,733 |  |
| Raw materials |  |  | 10,844 |  |  |  | 8,498 |  |
| Total inventories |  | $ | 89,024 |  |  | $ | 49,231 |  |

[0000950170-23-044385:notes:107]
Property and Equipment, Net

[0000950170-23-044385:notes:108]
The following table summarizes the Company’s property and equipment by category (in thousands):

[0000950170-23-044385:notes:109]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Computers and equipment |  | $ | 81,612 |  |  | $ | 75,387 |  |
| Purchased software |  |  | 51,444 |  |  |  | 47,161 |  |
| Office equipment, furniture and fixtures |  |  | 8,899 |  |  |  | 9,463 |  |
| Leasehold improvements |  |  | 48,943 |  |  |  | 52,564 |  |
| Total property and equipment |  |  | 190,898 |  |  |  | 184,575 |  |
| Less: accumulated depreciation and amortization |  |  | (144,450 | ) |  |  | (134,997 | ) |
| Property and equipment, net |  | $ | 46,448 |  |  | $ | 49,578 |  |

[0000950170-23-044385:notes:110]
The Company recognized depreciation expense of $19.5 million, $19.8 million, and $23.0 million related to property and equipment during the years ended June 30, 2023, 2022 and 2021, respectively.

[0000950170-23-044385:notes:111]
The following table summarizes the Company's contract liabilities which are shown as deferred revenue (in thousands):

[0000950170-23-044385:notes:112]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Deferred maintenance, support, and SaaS |  | $ | 486,075 |  |  | $ | 393,289 |  |
| Other deferred revenue |  |  | 15,424 |  |  |  | 8,330 |  |
| Total deferred revenue |  |  | 501,499 |  |  |  | 401,619 |  |
| Less: current portion |  |  | 282,475 |  |  |  | 238,262 |  |
| Non-current deferred revenue |  | $ | 219,024 |  |  | $ | 163,357 |  |

[0000950170-23-044385:notes:113]
Accrued Warranty

[0000950170-23-044385:notes:114]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0000950170-23-044385:notes:115]
|  | Year Ended |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |
| Balance beginning of period | $ | 10,852 |  |  | $ | 11,623 |  |  | $ | 14,035 |  |
| Warranties assumed due to acquisition |  | — |  |  |  | 41 |  |  |  | — |  |
| New warranties issued |  | 15,463 |  |  |  | 13,314 |  |  |  | 11,760 |  |
| Warranty expenditures |  | (13,993 | ) |  |  | (14,126 | ) |  |  | (14,172 | ) |
| Balance end of period | $ | 12,322 |  |  | $ | 10,852 |  |  | $ | 11,623 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-23-044385:notes:116]
6. Fair Value Measurements

[0000950170-23-044385:notes:117]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0000950170-23-044385:notes:118]
•
Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities;

[0000950170-23-044385:notes:119]
•
Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000950170-23-044385:notes:120]
•
Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value.

[0000950170-23-044385:notes:121]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0000950170-23-044385:notes:122]
| June 30, 2023 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 7,151 |  |  | $ | — |  |  | $ | 7,151 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 31 |  |  |  | — |  |  |  | 31 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 7,182 |  |  | $ | — |  |  | $ | 7,182 |  |

[0000950170-23-044385:notes:123]
| June 30, 2022 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0000950170-23-044385:notes:124]
The Company’s financial instruments consist of cash, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0000950170-23-044385:notes:125]
The Company's level 2 assets consist of certificates of deposit and derivative instruments. Certificates of deposit do not have regular market pricing and are considered Level 2. The fair value of derivative instruments under the Company’s foreign exchange forward contracts and interest rate swaps are estimated based on valuations provided by alternative pricing sources supported by observable inputs which are considered Level 2.

[0000950170-23-044385:notes:126]
As of June 30, 2023, the Company had investment in certificates of deposit of $7.2 million with maturity of three months at the date of purchase and are recorded as cash equivalents in the consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and as of June 30, 2023, their fair value approximated their amortized cost.

[0000950170-23-044385:notes:127]
As of June 30, 2023 and 2022, foreign exchange forward currency contracts not designated as hedging instruments had a notional amount of $3.4 million and $9.6 million, respectively. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income or expense in the consolidated statements of operations. For the years ended June 30, 2023, and 2022 the net loss recorded in the consolidated statements of operations from these contracts were $0.4 million and $1.4 million, respectively. For the year ended June 30, 2021, the net gains recorded in the consolidated statements of operations related to these contracts were $0.5 million. There were no outstanding foreign exchange forward contracts that were designated as hedging instruments at June 30, 2023 and at June 30, 2022. See Note 14, Derivatives and Hedging, for additional information.

[0000950170-23-044385:notes:128]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of June 30, 2023, the Company did not have any interest rate swap contracts. As of June 30, 2022, the Company had interest rate swap contracts, designated as cash flow hedges, with a total notional amount of $75.0 million. Changes in fair value of these contracts are recorded as a component of accumulated other comprehensive loss in the consolidated balance sheets. As of June 30, 2022, these contracts had unrealized gains of $1.3 million. See Note 14, Derivatives and Hedging, for additional information.

[0000950170-23-044385:notes:129]
The fair value of the borrowings under the 2023 Credit Agreement and the 2019 Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2023 Credit Agreement and 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $225.0 million and $308.6 million as of June 30, 2023 and 2022, respectively.

[0000950170-23-044385:notes:130]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. There were no Level 3 assets as of June 30, 2023 and 2022.

[0000950170-23-044385:notes:131]
There were no transfers of assets or liabilities between Level 1, Level 2 or Level 3 during the years ended June 30, 2023 and 2022. There were no impairments recorded during the years ended June 30, 2023 and 2022.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-23-044385:notes:132]
7. Goodwill and Intangible Assets

[0000950170-23-044385:notes:133]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0000950170-23-044385:notes:134]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Balance at beginning of period |  | $ | 400,144 |  |  | $ | 331,159 |  |
| Additions due to acquisitions (see Note 4) |  |  | — |  |  |  | 68,985 |  |
| Foreign currency translation |  |  | (5,389 | ) |  |  | — |  |
| Balance at end of period |  | $ | 394,755 |  |  | $ | 400,144 |  |

[0000950170-23-044385:notes:135]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0000950170-23-044385:notes:136]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 4.1 years |  | $ | 169,460 |  |  | $ | 159,592 |  |  | $ | 9,868 |  |
| Customer relationships |  | 3.4 years |  |  | 64,839 |  |  |  | 58,894 |  |  |  | 5,945 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 3.4 years |  |  | 2,445 |  |  |  | 2,195 |  |  |  | 250 |  |
| Total intangible assets, net* |  |  |  | $ | 247,444 |  |  | $ | 231,381 |  |  | $ | 16,063 |  |
| * The carrying amounts of foreign intangible assets are affected by foreign currency translation. |  |  |  |  |

[0000950170-23-044385:notes:137]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 170,600 |  |  | $ | 146,560 |  |  | $ | 24,040 |  |
| Customer relationships |  | 3.9 years |  |  | 64,839 |  |  |  | 56,704 |  |  |  | 8,135 |  |
| Trade names |  | 0.1 years |  |  | 10,700 |  |  |  | 10,680 |  |  |  | 20 |  |
| License agreements |  | 4.4 years |  |  | 2,445 |  |  |  | 2,125 |  |  |  | 320 |  |
| Total intangible assets, net* |  |  |  | $ | 248,584 |  |  | $ | 216,069 |  |  | $ | 32,515 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation. |  |  |  |  |

[0000950170-23-044385:notes:138]
The following table summarizes the amortization expense of intangible assets for the periods presented (in thousands):

[0000950170-23-044385:notes:139]
|  |  | Year Ended |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 12,941 |  |  | $ | 16,711 |  |  | $ | 26,246 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 2,047 |  |  |  | 3,235 |  |  |  | 6,110 |  |
| Total amortization expense |  | $ | 14,988 |  |  | $ | 19,946 |  |  | $ | 32,356 |  |

[0000950170-23-044385:notes:140]
The amortization expense that is recognized in “Total cost of revenues” primarily consists of amortization related to developed technology, license agreements and other intangibles.

[0000950170-23-044385:notes:141]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0000950170-23-044385:notes:142]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2024 |  | $ | 5,293 |  |
| 2025 |  |  | 4,519 |  |
| 2026 |  |  | 3,241 |  |
| 2027 |  |  | 1,452 |  |
| 2028 |  |  | 1,289 |  |
| Thereafter |  |  | 269 |  |
| Total |  | $ | 16,063 |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-044385:notes:143]
8. Debt

[0000950170-23-044385:notes:144]
The Company’s debt is comprised of the following (in thousands):

[0000950170-23-044385:notes:145]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 35,625 |  |
| Revolving Facility |  |  | 25,000 |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (674 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 34,326 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 190,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,409 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 187,591 |  |  |  | 270,570 |  |
| Total debt |  | $ | 221,917 |  |  | $ | 303,919 |  |

[0000950170-23-044385:notes:146]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0000950170-23-044385:notes:147]
The 2019 Credit Agreement provided for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million (the “2019 Term Loan”) and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”). In addition, the Company had access to incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests.

[0000950170-23-044385:notes:148]
On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the acquisition of Aerohive Networks, Inc. and for working capital and general corporate purposes.

[0000950170-23-044385:notes:149]
At the Company’s election, the initial term loan under the 2019 Credit Agreement was either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranged from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranged from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans were subject to a Base Rate of 0.00%. In addition, the Company was required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Starting December 31, 2019, principal installments were payable on the term loan in varying percentages quarterly and to the extent not previously paid, all outstanding balances were to be paid at maturity. The 2019 Credit Agreement was secured by substantially all of the Company’s assets.

[0000950170-23-044385:notes:150]
The 2019 Credit Agreement required the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also included covenants and restrictions that limited, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also included customary events of default which may result in acceleration of the payment of the outstanding balance.

[0000950170-23-044385:notes:151]
On April 8, 2020, the Company entered into the first amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into the second amendment to the 2019 Credit Agreement (the “Second Amendment”) which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. Subsequent to March 31, 2021, the original terms and financial covenants under the 2019 Credit Agreement resumed in effect. The Second Amendment required the Company to maintain certain minimum cash requirement and certain financial metrics at the end of each fiscal quarter through March 31, 2021. Under the terms of the Second Amendment, the Company was not permitted to exceed $55.0 million in its outstanding balance under the 2019 Revolving Facility, the applicable margin for Eurodollar rate was 4.5% and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

[0000950170-23-044385:notes:152]
On November 3, 2020, The Company and its lenders entered into the Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into the fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0000950170-23-044385:notes:153]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021 the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing its Form 10-Q for the quarterly period ended March 31, 2021. Returning to compliance with the covenants per the original terms of the 2019 Credit Agreement resulted in the Company’s Eurodollar loan spread decreasing from 4.5% during the Suspension Period to 2.75%, and the unused facility commitment fee decreased from 0.4% to 0.35%, and the limitation on revolver borrowings were removed effective May 1, 2021 after filing of the certificate with the administrative agent.

[0000950170-23-044385:notes:154]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance our debt. On July 7, 2023 the Company made a prepayment of $25.0 million to pay off the outstanding revolving credit balance.

[0000950170-23-044385:notes:155]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-23-044385:notes:156]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. At June 30, 2023, we were in compliance with the covenants of the 2023 Credit Agreement.

[0000950170-23-044385:notes:157]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2023, in conjunction with the debt refinancing, as noted above, the Company wrote-off a certain portion of the unamortized debt issuance cost of $1.3 million associated with the 2019 Credit Agreement which is included in “Interest expense” in the accompanying consolidated statements of operations. During the year ended June 30, 2023, the Company incurred and capitalized $3.2 million of debt issuance costs in conjunction with the 2023 Credit Agreement. The remaining unamortized debt issuance cost related to the 2019 Credit Agreement and the new capitalized debt issuance cost associated with the 2023 Credit Agreement will be amortized over the new term of five years. The interest rate as of June 30, 2023 was 7.18% and as of June 30, 2022 was 2.9%.

[0000950170-23-044385:notes:158]
Amortization of debt issuance costs are included in “Interest expense” in the accompanying consolidated statements of operations and were $2.6 million, $3.0 million and $3.0 million for the fiscal years ended June 30, 2023, 2022 and 2021, respectively.

[0000950170-23-044385:notes:159]
During the fiscal year ended June 30, 2021, the Company repaid $55.0 million against its 2019 Revolving Facility that was outstanding as of June 30, 2020 and had no outstanding balances as of June 30, 2021 and 2022. At  June 30, 2023, the Company had an outstanding balance of $25.0 million against its 2023 Revolving Facility. The Company has $110.2 million availability under the 2023 Revolving Facility as of June 30, 2023.

[0000950170-23-044385:notes:160]
During the fiscal year ended June 30, 2023, the Company made additional payments of $57.5 million against its 2019 Term Loan.

[0000950170-23-044385:notes:161]
The Company had $14.8 million of outstanding letters of credit as of June 30, 2023.

[0000950170-23-044385:notes:162]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0000950170-23-044385:notes:163]
|  |  | Amount |  |
| For the fiscal year ending June 30, |  |  |  |
| 2024 |  | $ | 35,000 |  |
| 2025 |  |  | 10,000 |  |
| 2026 |  |  | 15,000 |  |
| 2027 |  |  | 20,000 |  |
| 2028 |  |  | 145,000 |  |
| Total |  | $ | 225,000 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-23-044385:notes:164]
9. Leases

[0000950170-23-044385:notes:165]
Lessee Considerations

[0000950170-23-044385:notes:166]
The Company leases certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2033. Its leases generally have terms that range from one year to ten years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0000950170-23-044385:notes:167]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or ROU asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate at the commencement date because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is the rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. The biggest drivers having the greatest effect determining the incremental borrowing rate for each one of the Company’s leases are term of the lease and the currency in which the lease obligation is satisfied. Operating lease assets also included a reclassification for previous asset impairments and associated restructuring liabilities, deferred rent, lease incentives and initial direct costs which reduced the operating lease ROU assets.

[0000950170-23-044385:notes:168]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for variable lease and non-lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s consolidated statements of operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0000950170-23-044385:notes:169]
The following table presents additional information relating to the Company's operating leases (in thousands, except for lease term and discount rate):

[0000950170-23-044385:notes:170]
|  |  | Year Ended |  |
|  |  | June 30,2023 |  | June 30,2022 |  | June 30, 2021 |  |
| Operating lease costs | $ | 14,416 |  | $ | 16,852 |  | $ | 18,840 |  |
| Variable lease costs |  |  | 6,920 |  |  | 6,921 |  |  | 6,487 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 17,396 |  |  | 20,890 |  |  | 22,676 |  |
| ROU assets obtained for new lease obligations |  | 10,972 |  |  | 18,641 |  |  | 2,162 |  |

[0000950170-23-044385:notes:171]
|  |  | June 30,2023 |  | June 30,2022 |  |
| Weighted average remaining lease term | 4.6 years |  | 4.8 years |  |
| Weighted average discount rate |  | 5.2 | % |  | 4.7 | % |

[0000950170-23-044385:notes:172]
Short-term lease expense, which represents expense for leases with terms of one year or less, was not material for the years ended June 30, 2023 and 2022.

[0000950170-23-044385:notes:173]
The following table presents maturities of the Company’s operating lease liabilities as of June 30, 2023 (in thousands):

[0000950170-23-044385:notes:174]
|  |  | Amount |  |
| For the fiscal year ending June 30, |  |  |  |
| 2024 |  | $ | 12,210 |  |
| 2025 |  |  | 10,199 |  |
| 2026 |  |  | 9,706 |  |
| 2027 |  |  | 8,671 |  |
| 2028 |  |  | 2,805 |  |
| Thereafter |  |  | 4,567 |  |
| Total future minimum lease payments |  |  | 48,158 |  |
| Less amount representing interest |  |  | (5,466 | ) |
| Total operating lease liabilities |  | $ | 42,692 |  |
| Operating lease liabilities, current |  | $ | 10,847 |  |
| Operating lease liabilities, non-current |  | $ | 31,845 |  |

[0000950170-23-044385:notes:175]
Sublease Considerations
The Company currently is a sublessor on several operating facility subleases that expire on various dates through fiscal 2024. The subleases have original terms ranging from one to six years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. These operating subleases include only lease components. The Company included $0.5 million, $2.7 million and $2.9 million of sublease income in lease expense for the years ended June 30, 2023, 2022, and 2021, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-044385:notes:176]
10. Commitments and Contingencies

[0000950170-23-044385:notes:177]
Purchase Commitments

[0000950170-23-044385:notes:178]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2023, the Company had non-cancelable commitments to purchase $69.6 million of inventory, which will be received and consumed during fiscal 2024. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0000950170-23-044385:notes:179]
Legal Proceedings

[0000950170-23-044385:notes:180]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-23-044385:notes:181]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0000950170-23-044385:notes:182]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

[0000950170-23-044385:notes:183]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and the Company and other defendants filed a response brief on November 7, 2022. On May 18, 2023, the Court of Appeals for the Federal Circuit affirmed the lower court ruling dismissing the case. XR has not appealed, and the date for appeal has now passed.

[0000950170-23-044385:notes:184]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-23-044385:notes:185]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0000950170-23-044385:notes:186]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of

[0000950170-23-044385:notes:187]
liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0000950170-23-044385:notes:188]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.

[0000950170-23-044385:notes:189]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-23-044385:notes:190]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.

[0000950170-23-044385:notes:191]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-23-044385:notes:192]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal.

[0000950170-23-044385:notes:193]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021and a hearing date has been set for November 20, 2024.

[0000950170-23-044385:notes:194]
Intellectual Ventures I LLC v. Extreme Networks, Inc.

[0000950170-23-044385:notes:195]
On May 4, 2023, Intellectual Ventures I LLC ("IV”) filed a patent infringement lawsuit against the Company in the District of Delaware.  The complaint alleges infringement of a U.S. patent related to certain wireless communication products that support IEEE 802.11ac beamforming. IV sought unspecified damages, pre- and post-judgment interest, and costs. The Company had not been served and after negotiations, the Company and IV have reached a settlement and IV has dismissed the case with prejudice.

[0000950170-23-044385:notes:196]
Indemnification Obligations

[0000950170-23-044385:notes:197]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-23-044385:notes:198]
11. Stockholders’ Equity

[0000950170-23-044385:notes:199]
Preferred Stock

[0000950170-23-044385:notes:200]
In April 2001, in connection with entering into the Company’s Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors (the “Board”) is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2023, no shares of preferred stock were outstanding.

[0000950170-23-044385:notes:201]
Stockholders’ Rights Agreement

[0000950170-23-044385:notes:202]
On April 26, 2012, the Company entered into the “Restated Rights Plan,” which governed the terms of each right (“Right”) that had been issued with respect to each share of common stock of Extreme Networks. Each Right initially represented the right to purchase one one-thousandth of a share of the Company’s Preferred Stock. From 2013 through 2020, the Board and stockholders approved amendments providing for one-year extensions of the term of the Restated Rights Plan.

[0000950170-23-044385:notes:203]
On May 17, 2021, the Company entered into the Amended and Restated Tax Benefit Preservation Plan (the “2021 Tax Benefit Preservation Plan”), which amended and restated the Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC, as the rights agent. The 2021 Tax Benefit Preservation Plan was approved by stockholders of the Company at the annual meeting of stockholders held on November 4, 2021. The 2021 Tax Benefit Preservation Plan governs the terms of each right (“Right”) that has been issued with respect to each share of common stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0000950170-23-044385:notes:204]
The Board adopted the 2021 Tax Benefit Preservation Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of shares of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the 2021 Tax Benefit Preservation Plan.

[0000950170-23-044385:notes:205]
On August 23, 2023, the Board approved an amendment to the 2021 Tax Benefit Preservation Plan, effective as of August 24, 2023 (the “First Amendment”). The First Amendment amended the Restated Tax Plan by accelerating the expiration of the Company’s preferred share purchase rights by amending the definition of “Final Expiration Date” to mean the close of business on August 24, 2023. Accordingly, the Rights which were previously dividended to holders of record of the common stock of the Company shall expire on the close of business on August 24, 2023 and no person shall have any rights pursuant to the 2021 Tax Benefit Preservation Plan or the Rights.

[0000950170-23-044385:notes:206]
Equity Incentive Plan

[0000950170-23-044385:notes:207]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on August 11, 2021 to update tax withholding obligations. The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 12, 2022 to increase the maximum number of available shares by 6.5 million shares. The amendment was approved by the stockholders of the Company at the annual meeting of stockholders held on November 17, 2022.

[0000950170-23-044385:notes:208]
Employee Stock Purchase Plan

[0000950170-23-044385:notes:209]
The Compensation Committee of the Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan (the “ESPP”) on September 9, 2021 to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares. The amendment was approved by a majority of the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021.

[0000950170-23-044385:notes:210]
Common Stock Repurchases

[0000950170-23-044385:notes:211]
In May 2022, the Board of Directors authorized a share repurchase program with authorization to repurchase up to $200.0 million of the Company's common stock over a three-year period beginning in our fiscal year commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. In November 2022, the Board increased the authorization to repurchase shares in any quarter from up to $25.0 million of shares per quarter to up to $50.0 million of shares per quarter. This authorization supersedes and replaces any previously authorized repurchase programs. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0000950170-23-044385:notes:212]
During fiscal year 2023, the Company repurchased a total of 5.4 million shares of its common stock on the open market at a total cost of $99.9 million with an average price of $18.58 per share. In fiscal year 2022, the Company repurchased a total of 3.9 million shares of its common stock on the open market at a total cost of $45.0 million with an average price of $11.59 per share. As of June 30, 2023, approximately $100.1 million remains available for share repurchases under the share repurchase program.

[0000950170-23-044385:notes:213]
As provision of the Inflation Reduction Act enacted in the U.S., the Company is subject to an excise tax on corporate stock repurchases, which is assessed as one percent of the fair market value of net corporate stock repurchases after December 31, 2022. The  excise tax's effect on net corporate stock repurchases was not material for fiscal year ended June 30, 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-044385:notes:214]
12. Employee Benefit Plans

[0000950170-23-044385:notes:215]
As of June 30, 2023, the Company has the following share-based compensation plans:

[0000950170-23-044385:notes:216]
2013 Equity Incentive Plan

[0000950170-23-044385:notes:217]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, 6.6 million shares under the 2005 Plan were transferred to the 2013 Stock Plan and were added to the number of shares available for future grant under the 2013 Plan. Prior to fiscal 2023, stockholders approved the issuance of an additional 32.2 million shares of the Company's common stock. During the year ended June 30, 2023, an additional 6.5 million shares were authorized and made available for grant under the 2013 Plan. The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting. As of June 30, 2023, total options and awards to acquire 10.0 million shares were outstanding under the 2013 Plan and 10.0 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0000950170-23-044385:notes:218]
Aerohive 2014 Equity Incentive Plan

[0000950170-23-044385:notes:219]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the “Aerohive Plan”). Stock awards outstanding under the Aerohive Plan were converted into awards for Extreme shares as of the Acquisition Date at a predetermined rate pursuant to the Merger Agreement. As of June 30, 2023, total awards to acquire 2,288 shares of Extreme common stock were outstanding under the Aerohive Plan. If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0000950170-23-044385:notes:220]
Shares Reserved for Issuance

[0000950170-23-044385:notes:221]
The Company had the following reserved shares of common stock for future issuance as of the dates noted (in thousands):

[0000950170-23-044385:notes:222]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 9,995 |  |  |  | 11,430 |  |
| Employee stock options and awards outstanding |  |  | 10,038 |  |  |  | 7,616 |  |
| 2014 Employee Stock Purchase Plan |  |  | 8,467 |  |  |  | 9,961 |  |
| Total shares reserved for issuance |  |  | 28,500 |  |  |  | 29,007 |  |

[0000950170-23-044385:notes:223]
Stock Options

[0000950170-23-044385:notes:224]
The following table summarizes stock option activity under all plans for the year ended June 30, 2023 (in thousands except per share amount and contractual term):

[0000950170-23-044385:notes:225]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.70 |  |  | $ | 2,801 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.70 |  |  | $ | 23,136 |  |
| Vested and expected to vest at June 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.70 |  |  | $ | 23,136 |  |
| Exercisable at June 30, 2023 |  |  | 1,147 |  |  | $ | 6.56 |  |  |  | 2.68 |  |  | $ | 22,366 |  |

[0000950170-23-044385:notes:226]
The total intrinsic value of options exercised in fiscal years 2022 and 2021 was $4.9 million and $3.9 million, respectively. There were no options exercised during the fiscal year 2023.

[0000950170-23-044385:notes:227]
There were no stock options granted during the fiscal years 2023 and 2022. As of June 30, 2023, there was $0.1 million of total unrecognized compensation cost related to unvested stock options that will be recognized over a weighted-average period of 0.17 years.

[0000950170-23-044385:notes:228]
Stock Awards

[0000950170-23-044385:notes:229]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of RSUs, including performance-based or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the award’s fair value as of the date of grant. The Company does not estimate forfeitures, but accounts for them as incurred.

[0000950170-23-044385:notes:230]
The following table summarizes stock award activity for the year ended June 30, 2023 (in thousands, except grant date fair value):

[0000950170-23-044385:notes:231]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2022 |  |  | 6,429 |  |  | $ | 9.57 |  |  |  |  |
| Granted |  |  | 7,012 |  |  |  | 15.24 |  |  |  |  |
| Released |  |  | (3,805 | ) |  |  | 8.49 |  |  |  |  |
| Canceled |  |  | (785 | ) |  |  | 12.73 |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2023 |  |  | 8,851 |  |  | $ | 14.25 |  |  | $ | 230,564 |  |
| Stock awards expected to vest at June 30, 2023 |  |  | 8,851 |  |  | $ | 14.25 |  |  | $ | 230,564 |  |

[0000950170-23-044385:notes:232]
The RSUs granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company. The stock awards granted during the fiscal year ended June 30, 2023 included $1.8 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0000950170-23-044385:notes:233]
The aggregate fair value, as of the respective grant dates of awards granted during the fiscal years ended June 30, 2023, 2022 and 2021 was $106.8 million, $50.7 million and $32.9 million, respectively.

[0000950170-23-044385:notes:234]
For fiscal years ended June 30, 2023, 2022 and 2021, the Company withheld an aggregate of 1.4 million shares, 2.2 million shares, and 1.3 million shares, respectively, upon the vesting of awards, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0000950170-23-044385:notes:235]
For fiscal years ended June 30, 2023, 2022 and 2021, the Company remitted cash of $21.9 million, $24.5 million and $9.2 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Payments for tax withholdings, net of proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0000950170-23-044385:notes:236]
As of June 30, 2023, there was $82.9 million in unrecognized compensation costs related to non-vested stock awards which includes the performance and market condition awards as discussed below. This cost is expected to be recognized over a weighted-average period of 1.6 years.

[0000950170-23-044385:notes:237]
Stock Awards – Officers and Directors

[0000950170-23-044385:notes:238]
RSUs granted during fiscal 2023, 2022 and 2021 to named executive officers and directors totaled 1.8 million awards, 1.0 million awards and 1.6 million awards, respectively which included awards with market conditions as discussed below.

[0000950170-23-044385:notes:239]
Stock Awards - Performance Awards

[0000950170-23-044385:notes:240]
During fiscal 2023 and 2022, the Compensation Committee of the Board granted 1.2 million and 0.7 million RSUs, respectively with vesting based on market conditions (“MSUs”) to certain of the Company’s named executive officers. These MSUs will vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”). The MSU award represents the right to receive a target number of shares of common stock up to 150% of the original grant. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over 3 years performance period subject to the grantees’ continued service through the certification of performance.

[0000950170-23-044385:notes:241]
| Level | Relative TSR | Shares Vested |
| Below Threshold | TSR is less than the Index by more than 37.5 percentage points | 0% |
| Threshold | TSR is less than the Index by 37.5 percentage points | 25% |
| Target | TSR equals the Index | 100% |
| Maximum | TSR is greater than the Index by 25 percentage points or more | 150% |

[0000950170-23-044385:notes:242]
Total shareholder return is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years 1 and 2 and the ability for up to the maximum of the full award to vest based on the full 3-year TSR less any shares vested based on 1- and 2- year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0000950170-23-044385:notes:243]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the MSUs granted during the year ended June 30, 2023 was $17.62 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 65%, risk-free rate of 3.27%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-23-044385:notes:244]
The weighted-average grant-date fair value of the MSUs granted during the year ended June 30, 2022 was $12.69 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of 3 years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-23-044385:notes:245]
The following table summarizes stock awards with market or performance-based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0000950170-23-044385:notes:246]
|  |  | Fiscal Year 2023 |  |  | Fiscal Year 2022 |  |  | Fiscal Year 2021 |  |
| Performance awards granted |  |  | 1,221 |  |  |  | 727 |  |  |  | 475 |  |
| Performance awards earned |  |  | 400 |  |  |  | 158 |  |  |  | — |  |

[0000950170-23-044385:notes:247]
2014 Employee Stock Purchase Plan

[0000950170-23-044385:notes:248]
On August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. During the fiscal year ended June 30, 2022, the Board of Directors unanimously approved an amendment to the 2014 ESPP to increase the maximum number of shares that will be available for sale by 7.5 million shares, which was ratified by the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period has a maximum duration of six months and the maximum shares issuable for each purchase period is 1.5 million shares. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.

[0000950170-23-044385:notes:249]
During the fiscal years ended June 30, 2023 and 2022, there were 1.5 million and 2.0 million shares issued under the 2014 ESPP. As of June 30, 2023, there have been an aggregate 18.5 million shares issued under the 2014 ESPP.

[0000950170-23-044385:notes:250]
Share-Based Compensation Expense

[0000950170-23-044385:notes:251]
Share-based compensation expense recognized in the financial statements by line-item caption is as follows (in thousands):

[0000950170-23-044385:notes:252]
|  |  |  | Year Ended |  |
|  |  |  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |
| Cost of product revenues |  |  | $ | 1,856 |  |  | $ | 1,186 |  |  | $ | 1,209 |  |
| Cost of service and subscription revenues |  |  |  | 3,513 |  |  |  | 1,421 |  |  |  | 1,662 |  |
| Research and development |  |  |  | 14,824 |  |  |  | 9,995 |  |  |  | 9,969 |  |
| Sales and marketing |  |  |  | 22,250 |  |  |  | 15,000 |  |  |  | 12,505 |  |
| General and administrative |  |  |  | 21,029 |  |  |  | 15,760 |  |  |  | 13,706 |  |
| Total share-based compensation expense |  |  | $ | 63,472 |  |  | $ | 43,362 |  |  | $ | 39,051 |  |

[0000950170-23-044385:notes:253]
The Company uses the straight-line method for expense attribution, other than for the PSUs and MSUs, which may use the accelerated attribution method. The Company does not estimate forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur.

[0000950170-23-044385:notes:254]
The fair value of each RSU grant with market-based vesting criteria under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0000950170-23-044385:notes:255]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP shares is the offering period for each purchase. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility of the Company’s stock.

[0000950170-23-044385:notes:256]
The weighted-average estimated per share fair value of shares under the 2014 ESPP in fiscal years 2023, 2022 and 2021, was $4.87, $3.32 and $2.47, respectively.

[0000950170-23-044385:notes:257]
|  | Employee Stock Purchase Plan |  |  |
|  | Year Ended |  |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |  |
| Expected term | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  |
| Risk-free interest rate |  | 3.84 | % |  |  | 0.33 | % |  |  | 0.09 | % |  |
| Volatility |  | 55 | % |  |  | 49 | % |  |  | 95 | % |  |
| Dividend yield |  | — | % |  |  | — | % |  |  | — | % |  |

[0000950170-23-044385:notes:258]
401(k) Plan

[0000950170-23-044385:notes:259]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $22,500 for calendar year 2023. Employees aged 50 or over may elect to contribute an additional $7,500. The amount contributed to the Plan is on a pre-tax basis.

[0000950170-23-044385:notes:260]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. The program effective during fiscal 2023 was established to match $0.50 for every dollar contributed by the employee up to the first 6.0% of pay with annual cap of $5,000. The Company’s matching contributions to the Plan totaled $5.2 million, $4.6 million and $4.2 million, for fiscal years ended June 30, 2023, 2022 and 2021, respectively. No discretionary contributions were made in fiscal years ended June 30, 2023, 2022 and 2021.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-044385:notes:261]
13. Information about Segments and Geographic Areas

[0000950170-23-044385:notes:262]
The Company operates in one segment, which develops and markets network infrastructure equipment and related software. Revenues are attributed to a geographical area based on the location of the customers. The Company operates in three geographic regions: Americas, EMEA, and APAC. The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0000950170-23-044385:notes:263]
See Note 3, Revenues, for the Company’s revenues by geographic regions and channel based on the customers’ billing address.

[0000950170-23-044385:notes:264]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0000950170-23-044385:notes:265]
|  |  | June 30,2023 |  |  | June 30,2022 |  |
| Americas |  | $ | 124,375 |  |  | $ | 130,715 |  |
| EMEA |  |  | 35,175 |  |  |  | 36,792 |  |
| APAC |  |  | 11,244 |  |  |  | 11,770 |  |
| Total long-lived assets |  | $ | 170,794 |  |  | $ | 179,277 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-044385:notes:266]
14. Derivatives and Hedging

[0000950170-23-044385:notes:267]
Interest Rate Swaps

[0000950170-23-044385:notes:268]
The Company is exposed to interest rate risk on its debt. The Company may enter into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which has a floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0000950170-23-044385:notes:269]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a

[0000950170-23-044385:notes:270]
counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815, Derivatives and Hedging, the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in "Accumulated other comprehensive loss" and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0000950170-23-044385:notes:271]
During the fiscal year ended June 30, 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. These contracts had maturity dates through April 2023. As of June 30, 2023 the Company did not have any outstanding interest rate swaps contracts. As of June 30, 2022, the total notional amount of these interest rate swaps was $75.0 million, and these contracts had unrealized gains of $1.3 million, which were recorded in “Accumulated other comprehensive loss” with the associated asset in “Prepaid expenses and other current assets” in the consolidated balance sheet. Cash flows associated with periodic settlements of interest rate swaps were classified as operating activities in the consolidated statements of cash flows. Realized gains and losses were recognized as they accrued in interest expense. Amounts reported in "Accumulated other comprehensive loss" related to these cash flow hedges were reclassified to interest expense over the life of the swap contracts. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0000950170-23-044385:notes:272]
Foreign Exchange Forward Contracts

[0000950170-23-044385:notes:273]
The Company uses derivative financial instruments to manage exposures to foreign currency that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts primarily to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies.

[0000950170-23-044385:notes:274]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income, net” in the accompanying consolidated statements of operations. As of June 30, 2023 and 2022, foreign exchange forward currency contracts not designated as hedging instruments had the total notional amount of $3.4 million and $9.6 million, respectively. These contracts had maturities of less than 60 days. For the years ended June 30, 2023 and 2022, the net loss recorded in the consolidated statements of operations from these contracts was $0.4 million and $1.4 million, respectively. For the year ended June 30, 2021, the net gains recorded in the consolidated statement of operations from these contracts were $0.5 million. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0000950170-23-044385:notes:275]
For foreign exchange forward contracts designated as hedging instruments, unrealized gains and losses arising from these contracts are recorded as a component of "Accumulated other comprehensive loss" on the consolidated balance sheets. The hedging gains and losses in "Accumulated other comprehensive loss" are subsequently reclassified to expenses, as applicable, in the consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. As of June 30, 2021, foreign exchange forward currency contracts designated as hedging instruments had a notional amount of $21.8 million. These contracts have maturities of less than twelve months. As of June 30, 2021, these contracts had unrealized losses of $0.2 million, which are recorded in "Accumulated other comprehensive loss" with the associated assets in the accompanying consolidated balance sheets. There were no foreign exchange forward currency contracts that were designated as hedging instruments as of June 30, 2023 and 2022.

[0000950170-23-044385:notes:276]
Foreign currency transaction gains and losses from operations were gains of $0.8 million and $1.7 million for fiscal years ended June 30, 2023 and 2022, respectively, and a loss of $2.2 million for fiscal year ended June 30, 2021.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-044385:notes:277]
15. Restructuring, Impairments, and Related Charges

[0000950170-23-044385:notes:278]
The Company did not have any restructuring liability as of June 30, 2023 and 2022. As of June 30, 2021, the restructuring liability was $0.3 million, which was recorded in “Other accrued liabilities” in the accompanying consolidated balance sheet.

[0000950170-23-044385:notes:279]
During fiscal years ended June 30, 2023, 2022 and 2021, the Company recorded restructuring, impairment and related charges of $2.9 million, $1.7 million and $2.6 million, respectively. The charges are reflected in “Restructuring and related charges” in the consolidated statements of operations.

[0000950170-23-044385:notes:280]
2023 Restructuring

[0000950170-23-044385:notes:281]
During fiscal 2023, the Company initiated a restructuring plan to transform our business infrastructure and reduce our facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project the Company will move engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating our labs. The Company expects that the project will take about 18 to 24 months for completion and expects to incur charges of approximately $10.0 million throughout this period primarily for asset disposals, contractor costs, severance, relocation and other non-recurring fees.

[0000950170-23-044385:notes:282]
2022 Restructuring

[0000950170-23-044385:notes:283]
During fiscal 2022, the Company recorded $1.7 million of restructuring charges which was primarily consisted of facility related charges. The facility restructuring charges included some impairment charges and additional facilities expenses related to previously impaired facilities. In addition, during fiscal 2022, the Company completed the reduction-in-force action initiated in the third quarter of fiscal 2020 to reduce its operating costs and enhance financial flexibility (the “2020 Plan”). The Company had incurred $9.6 million of charges under the 2020 Plan through June 30, 2022.

[0000950170-23-044385:notes:284]
2021 Restructuring

[0000950170-23-044385:notes:285]
During fiscal 2021, the Company continued its cost reduction initiative begun in the third quarter of fiscal 2020 and recorded related severance, benefits, and equipment relocation charges of $1.5 million, related to the 2020 Plan. In addition, the Company incurred facility-related charges of $1.1 million, which represented additional expenses related to previously impaired facilities. Severance and benefits charges consisted primarily of additional employee severance and benefit expenses incurred under the 2020 Plan. With the reduction and realignment of the headcount under the 2020 Plan, the Company relocated certain of its lab equipment to third-party consulting companies. The Company had incurred $9.6 million of charges under the 2020 Plan through June 30, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-044385:notes:286]
16. Income Taxes

[0000950170-23-044385:notes:287]
Income (loss) before income taxes is as follows (in thousands):

[0000950170-23-044385:notes:288]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | (2,179 | ) |  | $ | (1,204 | ) |  | $ | (4,194 | ) |
| Foreign |  |  | 96,285 |  |  |  | 53,398 |  |  |  | 14,379 |  |
| Income before income taxes |  | $ | 94,106 |  |  | $ | 52,194 |  |  | $ | 10,185 |  |

[0000950170-23-044385:notes:289]
The provision for income taxes for the years ended June 30, 2023, 2022 and 2021 consisted of the following (in thousands):

[0000950170-23-044385:notes:290]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Current: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 3,221 |  |  | $ | — |  |  | $ | — |  |
| State |  |  | 3,640 |  |  |  | 1,069 |  |  |  | 1,160 |  |
| Foreign |  |  | 9,086 |  |  |  | 6,460 |  |  |  | 5,334 |  |
| Total current |  |  | 15,947 |  |  |  | 7,529 |  |  |  | 6,494 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 368 |  |  |  | 396 |  |  |  | 324 |  |
| State |  |  | 433 |  |  |  | 227 |  |  |  | 1,169 |  |
| Foreign |  |  | (716 | ) |  |  | (229 | ) |  |  | 262 |  |
| Total deferred |  |  | 85 |  |  |  | 394 |  |  |  | 1,755 |  |
| Provision for income taxes |  | $ | 16,032 |  |  | $ | 7,923 |  |  | $ | 8,249 |  |

[0000950170-23-044385:notes:291]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (21 percent) to income before income taxes is explained below (in thousands):

[0000950170-23-044385:notes:292]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Tax at federal statutory rate |  | $ | 19,762 |  |  | $ | 10,960 |  |  | $ | 2,139 |  |
| State income tax, net of federal benefit |  |  | 3,003 |  |  |  | 844 |  |  |  | 917 |  |
| Global intangible low-taxed income |  |  | 22,721 |  |  |  | 15,470 |  |  |  | — |  |
| US valuation allowance change – deferred tax movement |  |  | (24,682 | ) |  |  | (15,264 | ) |  |  | (9,387 | ) |
| Research and development credits |  |  | (1,503 | ) |  |  | (3,122 | ) |  |  | (2,423 | ) |
| Tax impact of foreign earnings |  |  | (5,627 | ) |  |  | (3,762 | ) |  |  | 11,979 |  |
| Foreign withholding taxes |  |  | 1,082 |  |  |  | 1,032 |  |  |  | 828 |  |
| Stock based compensation |  |  | (1,980 | ) |  |  | (5,011 | ) |  |  | 1,162 |  |
| Goodwill amortization |  |  | 730 |  |  |  | 525 |  |  |  | 1,467 |  |
| Nondeductible officer compensation |  |  | 4,582 |  |  |  | 5,691 |  |  |  | 1,496 |  |
| Nondeductible meals and entertainment |  |  | 324 |  |  |  | 193 |  |  |  | 71 |  |
| Foreign tax credits |  |  | (2,380 | ) |  |  | 367 |  |  |  | — |  |
| Provision for income taxes |  | $ | 16,032 |  |  | $ | 7,923 |  |  | $ | 8,249 |  |

[0000950170-23-044385:notes:293]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0000950170-23-044385:notes:294]
|  |  | June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 21,553 |  |  | $ | 51,494 |  |
| Tax credit carry-forwards |  |  | 57,841 |  |  |  | 70,683 |  |
| Depreciation |  |  | 1,899 |  |  |  | 2,093 |  |
| Intangible amortization |  |  | 20,652 |  |  |  | 25,725 |  |
| Deferred revenue |  |  | 19,698 |  |  |  | 15,928 |  |
| Inventory write-downs |  |  | 13,616 |  |  |  | 13,121 |  |
| Other allowances and accruals |  |  | 38,391 |  |  |  | 23,961 |  |
| Stock based compensation |  |  | 6,332 |  |  |  | 2,746 |  |
| Deferred intercompany gain |  |  | 3,693 |  |  |  | 3,693 |  |
| Ireland goodwill amortization |  |  | 4,862 |  |  |  | 5,583 |  |
| Capitalization of research and development |  |  | 19,062 |  |  |  | 3,813 |  |
| Operating lease liability |  |  | 6,303 |  |  |  | 7,203 |  |
| Other |  |  | 634 |  |  |  | 244 |  |
| Total deferred tax assets |  |  | 214,536 |  |  |  | 226,287 |  |
| Valuation allowance |  |  | (195,297 | ) |  |  | (209,727 | ) |
| Total net deferred tax assets |  |  | 19,239 |  |  |  | 16,560 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Goodwill amortization |  |  | (12,471 | ) |  |  | (10,415 | ) |
| Operating lease right of use asset |  |  | (4,543 | ) |  |  | (4,656 | ) |
| Prepaid commissions |  |  | (4,899 | ) |  |  | (3,931 | ) |
| Deferred tax liability on foreign withholdings |  |  | (747 | ) |  |  | (676 | ) |
| Total deferred tax liabilities |  |  | (22,660 | ) |  |  | (19,678 | ) |
| Net deferred tax liabilities |  | $ | (3,421 | ) |  | $ | (3,118 | ) |
| Recorded as: |  |  |  |  |  |  |
| Net non-current deferred tax assets |  |  | 4,326 |  |  |  | 4,599 |  |
| Net non-current deferred tax liabilities |  |  | (7,747 | ) |  |  | (7,717 | ) |
| Net deferred tax liabilities |  | $ | (3,421 | ) |  | $ | (3,118 | ) |

[0000950170-23-044385:notes:295]
The Company’s global valuation allowance decreased by $14.4 million in the fiscal year ended June 30, 2023 and decreased by $20.9 million in the fiscal year ended June 30, 2022. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against certain non-U.S. deferred tax assets in Ireland and Brazil. The valuation allowance is determined by assessing both negative and positive available evidence to determine whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including historical losses, tax attributes expiring unutilized in recent years and the cyclical nature of the Company's business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets. During the fiscal year ended June 30, 2023, the Company has experienced a shift toward additional positive evidence, specifically the Company has achieved cumulative profits for the last three years for the first time in over 20 years.

[0000950170-23-044385:notes:296]
As of June 30, 2023, the Company had net operating loss carry-forwards (“NOLs”) for U.S. federal and state tax purposes of $33.2 million and $127.3 million, respectively. As of June 30, 2023, the Company also had foreign NOLs in Australia and Brazil of $5.9 million, and $14.8 million, respectively. As of June 30, 2023, the Company also had federal and state tax credit carry-forwards of $30.5 million and $34.6 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits. Of the $33.2 million U.S. federal NOLs carry-forwards, $19.9 million will begin to expire in the fiscal year ending June 30, 2036 and $13.4 million have an indefinite carryforward life. The state net operating losses of $127.3 million will begin to partially expire in the fiscal year ending June 30, 2024. The foreign net operating losses can generally be carried forward indefinitely. Federal research and development tax credits of $26.2 million will expire beginning in fiscal 2027, if not utilized and foreign tax credits of $4.3 million will expire beginning in fiscal 2024. North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2024, if not utilized. California state research and development tax credits of $33.7 million do not expire and can be carried forward indefinitely.

[0000950170-23-044385:notes:297]
In June 2023, the Company performed an analysis under Section 382 of the Internal Revenue Code (“IRC”) with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of these U.S. tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2022, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes. The Company also performed in June 2020 a separate IRC section 382 analysis with respect to the NOLs and tax credits acquired from Aerohive and have determined that while the Company will be subject to an annual limitation, the Company should not be limited on the full utilization of the losses and credits during the statutory allowable carryforward period for the NOLs and credits.

[0000950170-23-044385:notes:298]
As of June 30, 2023, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $37.1 million. It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the U.S. The Company has reviewed its prior position on the reinvestment of earnings of certain foreign subsidiaries and has recorded a deferred tax liability of $0.7 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential tax associated with repatriation of these earnings as well as the deemed repatriation related to U.S. tax reform enacted in 2017 is $7.0 million.

[0000950170-23-044385:notes:299]
Most recently, the United States enacted the Inflation Reduction Act in 2022, which made a number of changes to the Internal Revenue Code, including adding a 1% excise tax on stock buybacks by publicly traded corporations and a corporate minimum tax on adjusted financial statement income of certain large companies. We do not anticipate this legislation will have a material impact for the Company.

[0000950170-23-044385:notes:300]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world. Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire, Texas and North Carolina. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years ended June 2003 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years ended June 2004 forward due to net operating losses. Statutes related to material foreign jurisdictions are generally open for fiscal years ended June 2019 forward for Ireland and for tax year ended March 2019 forward for India.

[0000950170-23-044385:notes:301]
The U.S. tax rules require U.S. tax on foreign earnings, known as Global Intangible Low Taxed Income (“GILTI”). Under U.S. GAAP, taxpayers are allowed to make an accounting policy election of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes. The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred under the period cost method.

[0000950170-23-044385:notes:302]
As of June 30, 2023, the Company had $18.3 million of unrecognized tax benefits. If fully recognized in the future, $0.2 million would impact the effective tax rate, and $18.1 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not reasonably expect the amount of unrealized tax benefits to materially decrease during the next twelve months. The decrease in the current year related to prior year tax positions relates to the reclassification of an unrecognized tax benefit to a valuation allowance with no net impact to the financial statements.

[0000950170-23-044385:notes:303]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0000950170-23-044385:notes:304]
| Balance at June 30, 2020 |  | $ | 23,897 |  |
| Decrease related to prior year tax positions |  |  | (4,296 | ) |
| Increase related to prior year tax positions |  |  | 28 |  |
| Increase related to current year tax positions |  |  | 72 |  |
| Lapse of statute of limitations |  |  | (637 | ) |
| Balance at June 30, 2021 |  | $ | 19,064 |  |
| Decrease related to prior year tax positions |  |  | (34 | ) |
| Increase related to current year tax positions |  |  | 11 |  |
| Lapse of statute of limitations |  |  | (674 | ) |
| Balance at June 30, 2022 |  | $ | 18,367 |  |
| Decrease related to prior year tax positions |  |  | (21 | ) |
| Increase related to prior year tax positions |  |  | 1 |  |
| Increase related to current year tax positions |  |  | 15 |  |
| Lapse of statute of limitations |  |  | (65 | ) |
| Balance at June 30, 2023 |  | $ | 18,297 |  |

[0000950170-23-044385:notes:305]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of income tax expense in the consolidated statements of operations and totaled less than $0.1 million for each of the years ended 2023, 2022 and 2021.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-044385:notes:306]
17. Net Income Per Share

[0000950170-23-044385:notes:307]
Basic net income per share is calculated by dividing net income by the weighted average number of shares of common stock outstanding during the period. Diluted income per share is calculated by dividing net income by the weighted average number of shares of common stock used in the basic net income per share calculation plus the dilutive effect of shares subject to repurchase, options and unvested restricted stock units.

[0000950170-23-044385:notes:308]
The following table presents the calculation of basic and diluted net income per share (in thousands, except per share data):

[0000950170-23-044385:notes:309]
|  | Year Ended |  |
|  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |
| Net income | $ | 78,074 |  |  | $ | 44,271 |  |  | $ | 1,936 |  |
| Weighted-average shares used in per share calculation – basic |  | 129,473 |  |  |  | 129,437 |  |  |  | 124,019 |  |
| Options to purchase common stock |  | 708 |  |  |  | 567 |  |  |  | 542 |  |
| Restricted stock units |  | 3,468 |  |  |  | 3,490 |  |  |  | 3,047 |  |
| Employee Stock Purchase Plan shares |  | — |  |  |  | — |  |  |  | 61 |  |
| Weighted-average shares used in per share calculation – diluted |  | 133,649 |  |  |  | 133,494 |  |  |  | 127,669 |  |
| Net income per share – basic and diluted |  |  |  |  |  |  |  |  |
| Net income per share – basic | $ | 0.60 |  |  | $ | 0.34 |  |  | $ | 0.02 |  |
| Net income per share – diluted | $ | 0.58 |  |  | $ | 0.33 |  |  | $ | 0.02 |  |

[0000950170-23-044385:notes:310]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.

[0000950170-23-044385:notes:311]
The following securities were excluded from the computation of net income per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0000950170-23-044385:notes:312]
|  |  |  |  |  | Year Ended |  |  |  |  |
|  |  | June 30,2023 |  |  | June 30,2022 |  |  | June 30, 2021 |  |
| Options to purchase common stock |  |  | — |  |  |  | — |  |  |  | 637 |  |
| Restricted stock units |  |  | 153 |  |  |  | 99 |  |  |  | 80 |  |
| Employee Stock Purchase Plan shares |  |  | 181 |  |  |  | 400 |  |  |  | 334 |  |
| Total shares excluded |  |  | 334 |  |  |  | 499 |  |  |  | 1,051 |  |


## extr:MtrlTermsOfTrdArr2TextBlock

[0000950170-23-044385:notes:313]
On May 26, 2023, Joe Vitalone, Chief Revenue Officer adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 70,402 shares of the Company's common stock until July 31, 2024.

[0000950170-23-044385:notes:314]
Because this Annual Report on Form 10-K is being filed within four business days from the date of the reportable events described below, we have elected to make the following disclosures in this Annual Report on Form 10-K instead of in a Current Report on Form 8-K under Item 1.01, Item 1.02, and Item 3.03.

[0000950170-23-044385:notes:315]
The information set forth below is included herein for the purpose of providing the disclosure required under “Item 1.01 – Entry into a Material Definitive Agreement” of Form 8-K.
