# EXTR note change history — 0001564590-18-012675 → 0001564590-18-026529


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001564590-18-026529:note_history:1]
9.Commitments and Contingencies
  (was, 2018-05-10, similarity 0.8955):
[0001564590-18-012675:note_history:1]
| 9. | Commitments and Contingencies |

- changed (2018-11-02):
[0001564590-18-026529:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2018, the Company had non-cancelable commitments to purchase $158.7 million of such inventory.  As of September 30, 2018 the Company had non-cancelable commitments to purchase $117.5 million of software and new product support services.
  (was, 2018-05-10, similarity 0.9092):
[0001564590-18-012675:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2018, the Company had non-cancelable commitments to purchase $151.5 million of such inventory.  As of March 31, 2018 the Company had non-cancelable software and maintenance support commitments to purchase $17.5 million of software and support services.

- changed (2018-11-02):
[0001564590-18-026529:note_history:3]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of September 30, 2018.
  (was, 2018-05-10, similarity 0.9675):
[0001564590-18-012675:note_history:3]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (approximately U.S. $1.0 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of March 31, 2018.

- changed (2018-11-02):
[0001564590-18-026529:note_history:4]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 19.6 million (USD $4.8 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.
  (was, 2018-05-10, similarity 0.9886):
[0001564590-18-012675:note_history:4]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.8 million (approximately U.S. $5.1 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of March 31, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

- changed (2018-11-02):
[0001564590-18-026529:note_history:5]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (USD $2.3 million) as of the date the Company acquired Enterasys Networks.
  (was, 2018-05-10, similarity 0.9813):
[0001564590-18-012675:note_history:5]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (approximately U.S. $2.8 million) as of the date the Company acquired Enterasys Networks.

- changed (2018-11-02):
[0001564590-18-026529:note_history:6]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties have signed a term sheet to settle the litigation and are preparing further documentation for the settlement to submit for court approval.
  (was, 2018-05-10, similarity 0.9209):
[0001564590-18-012675:note_history:6]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The Company believes plaintiffs’ claims are without merit, and intends to defend them vigorously.

- changed (2018-11-02):
[0001564590-18-026529:note_history:7]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended.  The parties have reached an agreement in principle to settle the case, and are preparing further documentation for the settlement to submit for court approval.
  (was, 2018-05-10, similarity 0.8364):
[0001564590-18-012675:note_history:7]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation now has ended.

- changed (2018-11-02):
[0001564590-18-026529:note_history:8]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit
  (was, 2018-05-10, similarity 0.8315):
[0001564590-18-012675:note_history:8]
XR Communications, LLC d/b/a Vivato Technologies, LLC v. Extreme Networks, Inc.

- added (2018-11-02):
[0001564590-18-026529:note_history:9]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (PTAB) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date). During a status conference on October 22, 2018, the Court continued the stay and set a status conference for February 11, 2019. The Company believes the claims are without merit, and intends to defend them vigorously.

- changed (2018-11-02):
[0001564590-18-026529:note_history:10]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit, and intends to defend them vigorously.
  (was, 2018-05-10, similarity 0.6101):
[0001564590-18-012675:note_history:10]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and our Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit, and intends to defend them vigorously.

- changed (2018-11-02):
[0001564590-18-026529:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of September 30, 2018, the Company has the outstanding indemnification claims described above.
  (was, 2018-05-10, similarity 0.9671):
[0001564590-18-012675:note_history:11]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.

- removed (2018-11-02):
[0001564590-18-012675:note_history:12]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In an order dated April 10, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board of inter partes review petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date), and scheduled a status conference on October 22, 2018.  The Company believes the claims are without merit, and intends to defend them vigorously.

- removed (2018-11-02):
[0001564590-18-012675:note_history:13]
DIFF Scale Operation Research, LLC v. Extreme Networks, Inc.

- removed (2018-11-02):
[0001564590-18-012675:note_history:14]
On March 15, 2018, DIFF Scale Operation Research, LLC (“DIFF”) filed a patent infringement lawsuit against the Company in the United States District Court for the Southern District of New York (DIFF Scale Operation Research, LLC v. Extreme Networks, Inc., No. 18-cv-2324-KBF).  The complaint alleges infringement of seven patents (four expired) generally directed to virtual connection networking, and accuses a variety of products, including: (1) SLX router and switch products, and NetIron and MLX products; (2) Extreme Management Center versions 7.0.9, 7.1.3, 8.0, and 8.1; (3) ExtremeSwitching and Summit Series switches; and (4) ERS 3000 Series, 4000 Series, and 5000 Series switches.  DIFF seeks unspecified and enhanced damages, pre- and post-judgment interest, attorneys’ fees and costs (but no injunction).  The Company believes the claims are without merit, and intends to defend them vigorously.

- removed (2018-11-02):
[0001564590-18-012675:note_history:15]
Be Labs, Inc. v. Extreme Networks, Inc.

- removed (2018-11-02):
[0001564590-18-012675:note_history:16]
On April 25, 2018, Be Labs, Inc. (“Be Labs”) filed a patent infringement lawsuit against the Company in the United States District Court for the District of Delaware (Be Labs, Inc. v. Extreme Networks, Inc., No. 1:18-cv-00626).  The complaint alleges direct and indirect infringement of two patents generally directed to a multimedia wireless distribution system for home or office use, and appears to accuse the Company’s 802.11ac- and 802.11n-compliant ExtremeWireless products.  Be Labs seeks damages, pre- and post-judgment interest, attorneys’ fees, costs, and a permanent injunction.  The Company believes the claims are without merit, and intends to defend them vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001564590-18-026529:note_history:17]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2018. The results of operations for the three months ended September 30, 2018 are not necessarily indicative of the results that may be expected for fiscal 2019 or any future periods.
  (was, 2018-05-10, similarity 0.6824):
[0001564590-18-012675:note_history:17]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2018. The results of operations for the three and nine months ended March 31, 2018 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.

- added (2018-11-02):
[0001564590-18-026529:note_history:18]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Actual results could differ from these estimates.

- removed (2018-11-02):
[0001564590-18-012675:note_history:19]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606). All amounts and disclosures set forth in this Form 10-Q have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.

- removed (2018-11-02):
[0001564590-18-012675:note_history:20]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes.  Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs, measurements of contingent consideration and income taxes. Actual results could differ from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001564590-18-026529:note_history:21]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2018. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.
  (was, 2018-05-10, similarity 0.9551):
[0001564590-18-012675:note_history:21]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017. Except for the following policies, there have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

- added (2018-11-02):
[0001564590-18-026529:note_history:22]
Recently Adopted Accounting Pronouncements

- added (2018-11-02):
[0001564590-18-026529:note_history:23]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities. The guidance was adopted effective July 1, 2018 and the Company reclassified a $0.5 million unrealized gain, net of tax, related to its available-for-sale investments from accumulated other comprehensive loss to accumulated deficit as a cumulative-effect adjustment in the accompanying condensed consolidated balance sheets.  Future changes in fair value will be included in earnings in each period.

- added (2018-11-02):
[0001564590-18-026529:note_history:24]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice.  The Company adopted the new guidance effective July 1, 2018. The amendments in this update have been applied on a retrospective transition method to each period presented. The adoption of this guidance did not have a material effect on the Company’s presentation of cash flows.

- added (2018-11-02):
[0001564590-18-026529:note_history:25]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740) - Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset other than inventory when the transfer occurs. Historical GAAP prohibits the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset has been sold outside the consolidated group.  The new guidance is effective for interim and annual reporting periods beginning after December 15, 2017. The Company adopted ASU 2016-16 effective July 1, 2018 on a modified retrospective basis. The adoption of this guidance did not have a material effect on the Company’s financial statements.

- added (2018-11-02):
[0001564590-18-026529:note_history:26]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting, which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718.  Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The Company adopted this guidance effective July 1, 2018, on a prospective basis.  The adoption of this guidance did not have a material effect on the Company’s financial statements.

- added (2018-11-02):
[0001564590-18-026529:note_history:27]
Recently Issued Accounting Pronouncements

- added (2018-11-02):
[0001564590-18-026529:note_history:28]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements.

- added (2018-11-02):
[0001564590-18-026529:note_history:29]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy Levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements.

- added (2018-11-02):
[0001564590-18-026529:note_history:30]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period, for reporting periods for which financial statements have not yet been issued. The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. Management is currently evaluating implementation options and impact on the Company's financial statements and related disclosures.

- added (2018-11-02):
[0001564590-18-026529:note_history:31]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The guidance is effective for fiscal years beginning after December 15, 2018. The Company is evaluating the accounting, transition and disclosure requirements of the standard and cannot currently estimate the financial statement impact of adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

- added (2018-11-02):
[0001564590-18-026529:note_history:32]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, Topic 842 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures.  The Company believes that Topic 842 will have a material impact on its financial position, as a result of recognizing right-of-use assets and lease liabilities on its consolidated balance sheets. The Company continues to evaluate the impact the new standard will have on its condensed consolidated statement of operations and statement of cash flows. This guidance will become effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

- removed (2018-11-02):
[0001564590-18-012675:note_history:33]
Revenue Recognition

- removed (2018-11-02):
[0001564590-18-012675:note_history:34]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- removed (2018-11-02):
[0001564590-18-012675:note_history:35]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

- removed (2018-11-02):
[0001564590-18-012675:note_history:36]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

- removed (2018-11-02):
[0001564590-18-012675:note_history:37]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- removed (2018-11-02):
[0001564590-18-012675:note_history:38]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- removed (2018-11-02):
[0001564590-18-012675:note_history:39]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and nine months ended March 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- removed (2018-11-02):
[0001564590-18-012675:note_history:40]
On March 31, 2018, the Company had $156.6 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 33 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 48 percent in fiscal 2019 and 19 percent of the balance thereafter.

- removed (2018-11-02):
[0001564590-18-012675:note_history:41]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- removed (2018-11-02):
[0001564590-18-012675:note_history:42]
Revenue recognized for the nine months ended March 31, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $66.7 million and $61.4 million, respectively. Revenue recognized for the three months ended March 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $31.3 million, respectively.

- removed (2018-11-02):
[0001564590-18-012675:note_history:43]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.1 million and $2.5 million at March 31, 2018 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2018 and 2017, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the nine months ended March 31, 2018 and 2017 was $1.4 million and $1.1 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- removed (2018-11-02):
[0001564590-18-012675:note_history:44]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands, unaudited):

- removed (2018-11-02):
[0001564590-18-012675:note_history:45]
|  |  | Three Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |  | $ | 31,972 |  | $ | 47,367 |  | $ | 79,339 |  |
| Other |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |  |  | 1,559 |  |  | 1,901 |  |  | 3,460 |  |
| Total Americas |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |  |  | 33,531 |  |  | 49,268 |  |  | 82,799 |  |
| EMEA: |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |  |  | 32,090 |  |  | 20,136 |  |  | 52,226 |  |
| APAC: |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |  |  | 2,399 |  |  | 11,772 |  |  | 14,171 |  |
| Total net revenues |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |  | $ | 68,020 |  | $ | 81,176 |  | $ | 149,196 |  |

- removed (2018-11-02):
[0001564590-18-012675:note_history:46]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |  | $ | 98,026 |  | $ | 112,592 |  | $ | 210,618 |  |
| Other |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |  |  | 5,779 |  |  | 14,772 |  |  | 20,551 |  |
| Total Americas |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |  |  | 103,805 |  |  | 127,364 |  |  | 231,169 |  |
| EMEA: |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |  |  | 99,459 |  |  | 61,026 |  |  | 160,485 |  |
| APAC: |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |  |  | 5,464 |  |  | 31,059 |  |  | 36,523 |  |
| Total net revenues |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |  | $ | 208,728 |  | $ | 219,449 |  | $ | 428,177 |  |

- removed (2018-11-02):
[0001564590-18-012675:note_history:47]
Business Combinations

- removed (2018-11-02):
[0001564590-18-012675:note_history:48]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

- removed (2018-11-02):
[0001564590-18-012675:note_history:49]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized in the statements of operations. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001564590-18-026529:note_history:50]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (492 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,008 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 178,125 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,627 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 176,498 |  |  |  | 188,749 |  |
| Total debt |  | $ | 185,506 |  |  | $ | 197,756 |  |
  (was, 2018-05-10, similarity 0.9612):
[0001564590-18-012675:note_history:50]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 25,260 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (540 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 24,720 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 145,173 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,215 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 153,958 |  |  |  | 80,422 |  |
| Total debt |  | $ | 178,678 |  |  | $ | 92,702 |  |

- changed (2018-11-02):
[0001564590-18-026529:note_history:51]
On May 1, 2018, the Company entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) $40 million five-year revolving credit facility (the “New Revolving Facility”) ii) a $190 million five-year term loan (the “New Term Loan”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement to pay off existing debt and for general corporate purposes.
  (was, 2018-05-10, similarity 0.7585):
[0001564590-18-012675:note_history:51]
On May 1, 2018, the Company entered into a Credit Agreement (the “New Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The New Credit Agreement provides for a $40 million five-year revolving credit facility (the “New Revolver”) and a $190 million five-year term loan (the “New Term Loan” and together with the New Revolver, the “New Senior Secured Credit Facilities”). On May 1, 2018, the Company borrowed $200 million under the New Senior Secured Credit Facilities in order to pay off existing debt and for general corporate purposes.

- added (2018-11-02):
[0001564590-18-026529:note_history:52]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting June 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The Credit Agreement is secured by substantially all of the Company’s assets.

- added (2018-11-02):
[0001564590-18-026529:note_history:53]
The Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

- added (2018-11-02):
[0001564590-18-026529:note_history:54]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the Credit Agreement.  Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.2 million for each of the three month periods ended September 30, 2018 and 2017.

- added (2018-11-02):
[0001564590-18-026529:note_history:55]
The Company had $38.7 million of availability under the New Revolving Facility as of September 30, 2018.  The Company had $1.3 million of outstanding letters of credit as of September 30, 2018.

- removed (2018-11-02):
[0001564590-18-012675:note_history:56]
In connection with the closing of Campus Fabric Business discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility.  On July 14, 2017, the Company borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.

- removed (2018-11-02):
[0001564590-18-012675:note_history:57]
In connection with the closing of the acquisition of the Data Center Business discussed in Note 2, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”) on October 26, 2017. Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Data Center Business Purchase Agreement (as defined above). On the Data Center Business Closing Date, the Company borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.

- removed (2018-11-02):
[0001564590-18-012675:note_history:58]
Borrowings under the Term Loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on the Company’s consolidated leverage ratio).  Borrowings under the Revolver bear interest, at the Company’s option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The Revolver has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.

- removed (2018-11-02):
[0001564590-18-012675:note_history:59]
The Company had $1.2 million of outstanding letters of credit and $48.8 million of availability under the Revolver as of March 31, 2018.

- removed (2018-11-02):
[0001564590-18-012675:note_history:60]
On May 1, 2018, the Company terminated the Credit Facility.

- removed (2018-11-02):
[0001564590-18-012675:note_history:61]
See Note 14 (Subsequent Events) to the condensed consolidated financial statements for more information on the New Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001564590-18-026529:note_history:62]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (492 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,008 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 178,125 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,627 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 176,498 |  |  |  | 188,749 |  |
| Total debt |  | $ | 185,506 |  |  | $ | 197,756 |  |
  (was, 2018-05-10, similarity 0.9612):
[0001564590-18-012675:note_history:62]
|  |  | March 31, 2018 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 25,260 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (540 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 24,720 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 145,173 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,215 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 153,958 |  |  |  | 80,422 |  |
| Total debt |  | $ | 178,678 |  |  | $ | 92,702 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-02):
[0001564590-18-026529:note_history:63]
The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- added (2018-11-02):
[0001564590-18-026529:note_history:64]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |
| Other |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |
| Total Americas |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |
| EMEA |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |
| APAC |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |
| Total net revenues |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-02):
[0001564590-18-026529:note_history:65]
| 4. | Revenues |

- added (2018-11-02):
[0001564590-18-026529:note_history:66]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- added (2018-11-02):
[0001564590-18-026529:note_history:67]
Revenue Recognition

- added (2018-11-02):
[0001564590-18-026529:note_history:68]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- added (2018-11-02):
[0001564590-18-026529:note_history:69]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three months ended September 30, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2018-11-02):
[0001564590-18-026529:note_history:70]
On September 30, 2018, the Company had $183.9 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 65 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 22 percent in fiscal 2020 and 13 percent of the balance thereafter.

- added (2018-11-02):
[0001564590-18-026529:note_history:71]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- added (2018-11-02):
[0001564590-18-026529:note_history:72]
Revenue recognized for the three months ended September 30, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $42.0 million, respectively.

- added (2018-11-02):
[0001564590-18-026529:note_history:73]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $4.9 million and $2.5 million at September 30, 2018 and 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2018 and 2017, was $0.7 million and $0.4 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- added (2018-11-02):
[0001564590-18-026529:note_history:74]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2018-11-02):
[0001564590-18-026529:note_history:75]
Revenue by Category

- added (2018-11-02):
[0001564590-18-026529:note_history:76]
The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

- added (2018-11-02):
[0001564590-18-026529:note_history:77]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |
| Other |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |
| Total Americas |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |
| EMEA |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |
| APAC |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |
| Total net revenues |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |

- added (2018-11-02):
[0001564590-18-026529:note_history:78]
Customer Concentrations

- added (2018-11-02):
[0001564590-18-026529:note_history:79]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

- added (2018-11-02):
[0001564590-18-026529:note_history:80]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenues:

- added (2018-11-02):
[0001564590-18-026529:note_history:81]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Tech Data Corporation |  | 17% |  |  | 11% |  |
| Westcon Group Inc. |  | 13% |  |  | 15% |  |
| Jenne Corporation |  | 12% |  |  | 14% |  |

- added (2018-11-02):
[0001564590-18-026529:note_history:82]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable balance:

- added (2018-11-02):
[0001564590-18-026529:note_history:83]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Tech Data Corporation |  | 21% |  |  | 17% |  |
| Westcon Group Inc. |  | 12% |  |  | * |  |
| Jenne Corporation |  | * |  |  | 13% |  |
| * Less than 10% of accounts receivable |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-02):
[0001564590-18-026529:note_history:84]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.
  (was, 2018-05-10, similarity 0.9995):
[0001564590-18-012675:note_history:84]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

- added (2018-11-02):
[0001564590-18-026529:note_history:85]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three months ended September 30, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2018-11-02):
[0001564590-18-026529:note_history:86]
On September 30, 2018, the Company had $183.9 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 65 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 22 percent in fiscal 2020 and 13 percent of the balance thereafter.

- added (2018-11-02):
[0001564590-18-026529:note_history:87]
Revenue recognized for the three months ended September 30, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $42.0 million, respectively.

- changed (2018-11-02):
[0001564590-18-026529:note_history:88]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $4.9 million and $2.5 million at September 30, 2018 and 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2018 and 2017, was $0.7 million and $0.4 million, respectively.  There was no impairment loss in relation to the costs capitalized.
  (was, 2018-05-10, similarity 0.9132):
[0001564590-18-012675:note_history:88]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.1 million and $2.5 million at March 31, 2018 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2018 and 2017, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the nine months ended March 31, 2018 and 2017 was $1.4 million and $1.1 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- added (2018-11-02):
[0001564590-18-026529:note_history:89]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- added (2018-11-02):
[0001564590-18-026529:note_history:90]
Revenue by Category

- changed (2018-11-02):
[0001564590-18-026529:note_history:91]
The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):
  (was, 2018-05-10, similarity 0.9106):
[0001564590-18-012675:note_history:91]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands, unaudited):

- changed (2018-11-02):
[0001564590-18-026529:note_history:92]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |
| Other |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |
| Total Americas |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |
| EMEA |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |
| APAC |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |
| Total net revenues |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |
  (was, 2018-05-10, similarity 0.9232):
[0001564590-18-012675:note_history:92]
|  |  | Three Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |  | $ | 31,972 |  | $ | 47,367 |  | $ | 79,339 |  |
| Other |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |  |  | 1,559 |  |  | 1,901 |  |  | 3,460 |  |
| Total Americas |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |  |  | 33,531 |  |  | 49,268 |  |  | 82,799 |  |
| EMEA: |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |  |  | 32,090 |  |  | 20,136 |  |  | 52,226 |  |
| APAC: |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |  |  | 2,399 |  |  | 11,772 |  |  | 14,171 |  |
| Total net revenues |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |  | $ | 68,020 |  | $ | 81,176 |  | $ | 149,196 |  |

- removed (2018-11-02):
[0001564590-18-012675:note_history:93]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- removed (2018-11-02):
[0001564590-18-012675:note_history:94]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

- removed (2018-11-02):
[0001564590-18-012675:note_history:95]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

- removed (2018-11-02):
[0001564590-18-012675:note_history:96]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- removed (2018-11-02):
[0001564590-18-012675:note_history:97]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and nine months ended March 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- removed (2018-11-02):
[0001564590-18-012675:note_history:98]
On March 31, 2018, the Company had $156.6 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 33 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 48 percent in fiscal 2019 and 19 percent of the balance thereafter.

- removed (2018-11-02):
[0001564590-18-012675:note_history:99]
Revenue recognized for the nine months ended March 31, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $66.7 million and $61.4 million, respectively. Revenue recognized for the three months ended March 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $31.3 million, respectively.

- removed (2018-11-02):
[0001564590-18-012675:note_history:100]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2018 |  |  | March 31, 2017 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |  | $ | 98,026 |  | $ | 112,592 |  | $ | 210,618 |  |
| Other |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |  |  | 5,779 |  |  | 14,772 |  |  | 20,551 |  |
| Total Americas |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |  |  | 103,805 |  |  | 127,364 |  |  | 231,169 |  |
| EMEA: |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |  |  | 99,459 |  |  | 61,026 |  |  | 160,485 |  |
| APAC: |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |  |  | 5,464 |  |  | 31,059 |  |  | 36,523 |  |
| Total net revenues |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |  | $ | 208,728 |  | $ | 219,449 |  | $ | 428,177 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-11-02):
[0001564590-18-026529:note_history:101]
On November 2, 2018, the Company announced that its Board of Directors has authorized the Company to repurchase up to $60.0 million of its common stock over the next two years. Purchases may be made from time to time in the open market, in privately negotiated transactions or otherwise. The manner, timing and amount of any purchases will be determined by the Company's management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations.  No repurchases were made during the quarter ended September 30, 2018.

- removed (2018-11-02):
[0001564590-18-012675:note_history:102]
On May 1, 2018, the Company terminated the Amended and Restated Credit Agreement dated October 28, 2016, by and among the Company, as borrower, Silicon Valley Bank, as administrative agent, and the financial institutions that were a party thereto as lenders.

- removed (2018-11-02):
[0001564590-18-012675:note_history:103]
On May 1, 2018, the Company entered into a Credit Agreement (the “New Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The New Credit Agreement provides for a $40 million five-year revolving credit facility (the “New Revolver”) and a $190 million five-year term loan (the “New Term Loan” and together with the New Revolver, the “New Senior Secured Credit Facilities”). On May 1, 2018, the Company borrowed $200 million under the New Senior Secured Credit Facilities in order to pay off the existing debt, as noted above and for general corporate purposes.

- removed (2018-11-02):
[0001564590-18-012675:note_history:104]
Borrowings under the New Senior Secured Credit Facilities will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolver, also based on the Company’s Consolidated Leverage Ratio. Principal installments are payable on the New Term Loan in varying percentages quarterly starting June 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The New Senior Secured Credit Facilities are secured by substantially all of the Company’s assets.

- removed (2018-11-02):
[0001564590-18-012675:note_history:105]
Financial covenants under the New Credit Agreement require the Company to maintain a minimum consolidated fixed charge coverage ratio of at least 1.25:1.00 at the end of each fiscal quarter. In addition, the Company’s Consolidated Leverage Ratio shall not be greater than (i) 3.00:1.00 at the end of the fiscal quarters ending March 31, 2018 through September 30, 2019, (ii) 2.75:1.00 at the end of the fiscal quarters ending December 31, 2019 through March 31, 2021, and (iii) 2.50:1.00 at the end of the fiscal quarters ending June 30, 2021 and thereafter. The New Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets.

- removed (2018-11-02):
[0001564590-18-012675:note_history:106]
The New Credit Agreement also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, the material breach of any of representations and warranties, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company. The amounts outstanding under the New Senior Secured Credit Facilities may be accelerated upon certain events of default.
