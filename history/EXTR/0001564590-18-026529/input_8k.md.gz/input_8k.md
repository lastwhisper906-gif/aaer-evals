# EXTR 8-K — 0001564590-18-026372 filed 2018-11-02

## item codes, every 8-K on or before 2018-11-02

- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2018-11-02

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-026372:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-18-026372:8k_2_02:2]
extr-ex991_6.htm

[0001564590-18-026372:8k_2_02:3]
Exhibit 99.1

[0001564590-18-026372:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-18-026372:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Stan Kovler |  | Media Contact Christi Nicolacopoulos |
| 919/595-4196 |  | 603/952-5005 |
| Investor relations@extremenetworks.com |  | pr@extremenetworks.com |

[0001564590-18-026372:8k_2_02:6]
Extreme Networks Reports First Quarter Fiscal Year 2019 Financial Results

[0001564590-18-026372:8k_2_02:7]
SAN JOSE, Calif., November 2, 2018 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal first quarter ended September 30, 2018.

[0001564590-18-026372:8k_2_02:8]
First Quarter Results:

[0001564590-18-026372:8k_2_02:9]
|  | • | First quarter revenue was $239.9 million, an increase of 13% year-over-year. |

[0001564590-18-026372:8k_2_02:10]
|  | • | GAAP gross margin for the first fiscal quarter was 55.1%, an increase of 200 basis points year-over-year. Non-GAAP gross margin was 58.0% year-over-year, an increase of 130 basis points year-over-year. |

[0001564590-18-026372:8k_2_02:11]
|  | • | GAAP operating margin for the first fiscal quarter was (2.1)%. Non-GAAP operating margin was 5.8%, compared to 2.1% and 10.6% , respectively, year-over-year. |

[0001564590-18-026372:8k_2_02:12]
|  | • | GAAP net loss for the first fiscal quarter was $9.1 million, or $0.08 per basic share, a decrease of $13.5 million or $0.12 per basic share, respectively, year-over-year. Non-GAAP net income was $9.4 million, or $0.08 per diluted share, a decrease of $9.2 million or $0.08 per diluted share, respectively, year-over-year. |

[0001564590-18-026372:8k_2_02:13]
“We reported results towards the high-end of our guidance. We made considerable progress to consolidate our distributors, and we stabilized our data center business.  With new products on the horizon and new hires focused on key verticals such as Service Provider and Federal, we are improving our execution and go to market activities.” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-18-026372:8k_2_02:14]
Meyercord also stated that: “Our Board of Directors has authorized a $60 million share repurchase and remains focused on driving shareholder value and fiscal responsibility to offset dilution from our equity incentive compensation programs.”

[0001564590-18-026372:8k_2_02:15]
"Beginning on November 1, we instituted a 5% global price increase on our products after four years of not raising prices, and a 7% price increase on products sold in the US. These increases reflect rising component costs, with an incremental amount related to US tariffs on goods produced in China. We are transitioning a significant portion of our manufacturing outside of China over the next several quarters and expect additional pricing actions in the US in January to mitigate our exposure to tariffs.  We are committed to continuous supply chain optimization to provide the highest value products and services to our customers."

[0001564590-18-026372:8k_2_02:16]
Meyercord added, “Finally, in late fiscal Q1 we observed a slight uptick in customer orders ahead of tariffs being implemented in the US, in anticipation of rising prices.  Looking ahead, we believe our strong product roadmap and improved execution, combined with our digital transformation initiatives to make it easier for customers to do business with Extreme, will drive continued growth into the second half of fiscal ‘19.”

[0001564590-18-026372:8k_2_02:17]
Recent Key Highlights:

[0001564590-18-026372:8k_2_02:18]
|  | • | Toi Ohomai Institute of Technology, one of the largest tertiary education providers in New Zealand, selected Extreme Networks to upgrade both wired and wireless networks across eight campus locations and more than 70 delivery sites. With technology from Extreme's Smart OmniEdge™ and Automated Campus™ solutions, Toi Ohomai will deliver improved network performance and access for students, teachers and staff, consistent across every site, and secure, reliable Wi-Fi coverage throughout each campus. The system-wide update will facilitate innovation, knowledge creation and collaborative learning. |

[0001564590-18-026372:8k_2_02:19]
|  | • | North Carolina A&T State University, part of the UNC system with approximately 12,000 students, has signed a five-year Extreme Campus Services Agreement, giving its students a state-of-the-art network at a fixed price per student. The complete switching, edge and distribution layer refresh will include deployment of Extreme Networks Smart OmniEdge™ and Automated Campus™ solutions, with single pane of glass management across the multi-vendor network via Extreme Management Center™. The total package includes professional services and helps the University lower total cost of ownership. |

[0001564590-18-026372:8k_2_02:20]
|  | • | The Tampa Bay Buccaneers, teamed with Extreme Networks to improve Wi-Fi capacity at their home field, Raymond James Stadium. With solutions from Extreme's Automated Campus™ and Smart OmniEdge™ product families, the Wi-Fi density at the NFL's top-rated venue for in-stadium technology increased by 400 percent, giving 65,000+ Buccaneers fans the opportunity to share their experiences and engage with friends and family without missing a moment of action on game day. |

[0001564590-18-026372:8k_2_02:21]
|  | • | Zwarte Cross Festival in the Netherlands, one of the largest outdoor music and sports festivals in Europe and the biggest motocross event in the world, leveraged Extreme Smart OmniEdge™ solutions at its July event. Zwarte Cross deployed 198 ExtremeMobility™ access points to provide Wi-Fi connectivity for fans and to power central festival functions, including ticketing, point of sale, and internal communications. Over 10,000 unique attendees logged into the network during the event, with up to 3,200 clients concurrently connected. 6TBs of data was transferred on Day 2 from the festival main stage. ExtremeAnalytics™ provided visibility and understanding of network performance and usage, ensuring a quality, consistent experience for guests and festival staff. |

[0001564590-18-026372:8k_2_02:22]
|  | • | Extreme introduced The Extreme Dojo™ program, a new online training program for global partners consisting of competency-based curricula delivered in bite-sized video modules. Each of the four levels of learning in Extreme Dojo offer foundational and commercial knowledge on Extreme’s business model, its solutions portfolio, vertical positioning and solutions selling strategies in a modern and engaging format. Originally designed to train Extreme employees, |

[0001564590-18-026372:8k_2_02:23]
|  |  | Extreme Dojo extends instruction to the company’s global partner community, helping to align its go-to market strategy across regions. The latest version includes modifications from a pilot test of the program completed by more than 100 partners. |

[0001564590-18-026372:8k_2_02:24]
|  | • | Extreme introduced Premier Services, a new, high-touch support service available to customers worldwide. Staffed by its award-winning team of Customer-Driven Networking™ experts, Premier Services comes in two packages – Premier and PremierPLUS – offering comprehensive, proactive engagement, support and management to guide Extreme technology implementations from inception to installation and beyond. |

[0001564590-18-026372:8k_2_02:25]
|  | • | Extreme announced Share Repurchase. Extreme Networks, Inc. announced that its Board of Directors authorized the Company to repurchase up to $60 million of its common stock. |

[0001564590-18-026372:8k_2_02:26]
Fiscal Q1 2019 Financial Metrics:

[0001564590-18-026372:8k_2_02:27]
(in millions, except percentages ad per share information)

[0001564590-18-026372:8k_2_02:28]
|  |  | Q1 FY'19 |  |  | Q1 FY'18 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 177.7 |  |  | $ | 164.8 |  |  | $ | 12.9 |  |  |  | 8 | % |
| Service |  |  | 62.2 |  |  |  | 46.9 |  |  |  | 15.3 |  |  |  | 33 | % |
| Total Net Revenue |  | $ | 239.9 |  |  | $ | 211.7 |  |  | $ | 28.2 |  |  |  | 13 | % |
| Gross Margin |  |  | 55.1 | % |  |  | 53.1 | % |  | 200 bps |  |  |  | 4 | % |
| Operating Margin |  |  | (2.1 | )% |  |  | 2.1 | % |  | -420 bps |  |  |  | 200 | % |
| Net Loss |  | $ | (9.1 | ) |  | $ | 4.4 |  |  | $ | (13.5 | ) |  |  | 307 | % |
| Loss per basic and diluted share |  | $ | (0.08 | ) |  | $ | 0.04 |  |  | $ | (0.12 | ) |  |  | 300 | % |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 177.7 |  |  | $ | 164.8 |  |  | $ | 12.9 |  |  |  | 8 | % |
| Service |  |  | 62.2 |  |  |  | 46.9 |  |  |  | 15.3 |  |  |  | 33 | % |
| Total Net Revenue |  | $ | 239.9 |  |  | $ | 211.7 |  |  | $ | 28.2 |  |  |  | 13 | % |
| Gross Margin |  |  | 58.0 | % |  |  | 56.7 | % |  | 130 bps |  |  |  | 2 | % |
| Operating Margin |  |  | 5.8 | % |  |  | 10.6 | % |  | -480 bps |  |  |  | (45 | )% |
| Net Income |  | $ | 9.4 |  |  | $ | 18.6 |  |  | $ | (9.2 | ) |  |  | (49 | )% |
| Earnings per diluted share |  | $ | 0.08 |  |  | $ | 0.16 |  |  | $ | (0.08 | ) |  |  | (50 | )% |

[0001564590-18-026372:8k_2_02:29]
|  | • | Cash and investments ended the quarter at $141.1 million, an increase of $18.5 million from Q4 and a decrease of $13.0 million from Q1 last year, driven primarily by the funding of the acquisition of the Campus Fabric and Data Center businesses. |

[0001564590-18-026372:8k_2_02:30]
|  | • | Accounts receivable balance ending Q1 was $164.7 million, with days sales outstanding of 63. |

[0001564590-18-026372:8k_2_02:31]
|  | • | Q1 ending inventory was $55.6 million, a decrease of $8.3 million from Q4 and a decrease of $2.5 million from Q1 last year. |

[0001564590-18-026372:8k_2_02:32]
|  | • | Q1 ending debt was $187.6 million, a decrease of $10.2 million from Q4 and an increase of $20.0 million from Q1 last year, driven primarily by borrowings to fund Extreme's acquisitions of the Campus Fabric and Data Center businesses. |

[0001564590-18-026372:8k_2_02:33]
Business Outlook:

[0001564590-18-026372:8k_2_02:34]
For its second quarter of fiscal 2019, ending December 31, 2018, the Company is targeting revenue in a range of $239.0 million to $249.0 million.  GAAP gross margin is targeted between 55.1% and 57.1% and non-GAAP gross margin is targeted between 57.5% and 59.5%. Operating expenses are targeted to be between $134.7 million and $137.7 million on a GAAP basis and $125.0 million to $128.0 million on a non-GAAP basis. GAAP earnings are targeted to be between net loss of ($7.7) million to ($0.1) million or a net loss of ($0.06) to ($0.00) per basis share.  Non-GAAP net income earnings are targeted in a range of of $7.8 million to $15.4 million, or $0.06 to $0.13 per diluted share. The GAAP and non-GAAP per share targets are based on 119.1 million and 121.6 million weighted shares outstanding, respectively.

[0001564590-18-026372:8k_2_02:35]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY’19 guidance:

[0001564590-18-026372:8k_2_02:36]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.1% - 57.1% |  |  | (1.3)% - 1.8% |  |  | $(0.06)-$0.00 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.0% |  |  | 2.0% |  |  | $ | 0.04 |  |
| Stock based compensation | 0.2% |  |  | 3.0% |  |  | $ | 0.06 |  |
| Amortization of non product intangibles | 0.0% |  |  | 0.9% |  |  | $ | 0.02 |  |
| Acquisition and integration costs | 0.2% |  |  | 0.6% |  |  | $ | 0.01 |  |
| Non-GAAP | 57.5% - 59.5% |  |  | 5.2% - 8.1% |  |  | $0.06 - $0.13 |  |

[0001564590-18-026372:8k_2_02:37]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-18-026372:8k_2_02:38]
Conference Call:

[0001564590-18-026372:8k_2_02:39]
Extreme will host a conference call at 8:30 a.m. Eastern (5:30 a.m. Pacific) today to review the first fiscal quarter results as well as the business outlook for second fiscal quarter ending December 31, 2018 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through November 8, 2019.  The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406   Conference ID # 8878938. The encore recording will be available for 7 days following the call.

[0001564590-18-026372:8k_2_02:40]
About Extreme Networks:

[0001564590-18-026372:8k_2_02:41]
Extreme Networks, Inc. (EXTR) delivers software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable digital transformation. Our 100% in-sourced services and

[0001564590-18-026372:8k_2_02:42]
support are number one in the industry. Even with 30,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking™. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's  website or call 1-888-257-3000.

[0001564590-18-026372:8k_2_02:43]
Extreme Networks and the Extreme Networks logo, Automated Campus, Smart OmniEdge, Extreme Management Center, ExtremeMobility, ExtremeAnalytics, Extreme Dojo and Customer-Driven Networking are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-18-026372:8k_2_02:44]
Non-GAAP Financial Measures:

[0001564590-18-026372:8k_2_02:45]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, gain on sale of equity investment and income tax.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-18-026372:8k_2_02:46]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-18-026372:8k_2_02:47]
Forward Looking Statements:

[0001564590-18-026372:8k_2_02:48]
technology and products; customer response to our new technology and products; risks related to pending or future litigation; and a dependency on third parties for certain components and for the manufacturing of our products.

[0001564590-18-026372:8k_2_02:49]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-18-026372:8k_2_02:50]
EXTREME NETWORKS, INC.

[0001564590-18-026372:8k_2_02:51]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-026372:8k_2_02:52]
(In thousands)

[0001564590-18-026372:8k_2_02:53]
(Unaudited)

[0001564590-18-026372:8k_2_02:54]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 140,167 |  |  | $ | 121,139 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,661 at September 30, 2018 and $1,478 at June 30, 2018 |  |  | 164,683 |  |  |  | 212,423 |  |
| Inventories |  |  | 55,580 |  |  |  | 63,867 |  |
| Prepaid expenses and other current assets |  |  | 35,371 |  |  |  | 30,484 |  |
| Total current assets |  |  | 395,801 |  |  |  | 427,913 |  |
| Property and equipment, net |  |  | 76,224 |  |  |  | 78,519 |  |
| Intangible assets, net |  |  | 70,023 |  |  |  | 77,092 |  |
| Goodwill |  |  | 139,082 |  |  |  | 139,082 |  |
| Other assets |  |  | 50,754 |  |  |  | 47,642 |  |
| Total assets |  |  | 731,884 |  |  | $ | 770,248 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 9,008 |  |  | $ | 9,007 |  |
| Accounts payable |  |  | 43,873 |  |  |  | 75,689 |  |
| Accrued compensation and benefits |  |  | 36,387 |  |  |  | 50,351 |  |
| Accrued warranty |  |  | 12,601 |  |  |  | 12,807 |  |
| Deferred revenue, net |  |  | 137,991 |  |  |  | 130,865 |  |
| Other accrued liabilities |  |  | 82,180 |  |  |  | 81,153 |  |
| Total current liabilities |  |  | 322,040 |  |  |  | 359,872 |  |
| Deferred revenue, less current portion |  |  | 45,874 |  |  |  | 43,660 |  |
| Long-term debt, less current portion |  |  | 176,498 |  |  |  | 188,749 |  |
| Deferred income taxes |  |  | 6,234 |  |  |  | 6,135 |  |
| Other long-term liabilities |  |  | 64,107 |  |  |  | 59,100 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000,000 shares authorized; 103,229,140 shares issued and outstanding at December 31, 2015 and 100,284,106 shares issued and outstanding at June 30, 2015 |  |  | 118 |  |  |  | 116 |  |
| Additional paid-in-capital |  |  | 956,356 |  |  |  | 942,397 |  |
| Accumulated other comprehensive loss |  |  | (2,697 | ) |  |  | (1,703 | ) |
| Accumulated deficit |  |  | (836,646 | ) |  |  | (828,078 | ) |
| Stockholders’ equity |  |  | 117,131 |  |  |  | 112,732 |  |
| Total liabilities and stockholders’ equity |  |  | 731,884 |  |  | $ | 770,248 |  |

[0001564590-18-026372:8k_2_02:55]
EXTREME NETWORKS, INC.

[0001564590-18-026372:8k_2_02:56]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-026372:8k_2_02:57]
(In thousands, except per share amounts)

[0001564590-18-026372:8k_2_02:58]
(Unaudited)

[0001564590-18-026372:8k_2_02:59]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 177,720 |  |  | $ | 164,774 |  |
| Service |  |  | 62,166 |  |  |  | 46,941 |  |
| Total net revenues |  |  | 239,886 |  |  |  | 211,715 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 83,543 |  |  |  | 80,045 |  |
| Service |  |  | 24,272 |  |  |  | 19,289 |  |
| Total cost of revenues |  |  | 107,815 |  |  |  | 99,334 |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  |  | 94,177 |  |  |  | 84,729 |  |
| Service |  |  | 37,894 |  |  |  | 27,652 |  |
| Total gross profit |  |  | 132,071 |  |  |  | 112,381 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 51,241 |  |  |  | 34,285 |  |
| Sales and marketing |  |  | 67,582 |  |  |  | 55,561 |  |
| General and administrative |  |  | 12,771 |  |  |  | 12,185 |  |
| Acquisition and integration costs |  |  | 2,546 |  |  |  | 4,244 |  |
| Restructuring charges, net of reversals |  |  | 808 |  |  |  | — |  |
| Amortization of intangibles |  |  | 2,141 |  |  |  | 1,614 |  |
| Total operating expenses |  |  | 137,089 |  |  |  | 107,889 |  |
| Operating loss |  |  | (5,018 | ) |  |  | 4,492 |  |
| Interest income |  |  | 394 |  |  |  | 647 |  |
| Interest expense |  |  | (3,526 | ) |  |  | (2,215 | ) |
| Other income (expense), net |  |  | 487 |  |  |  | 3,127 |  |
| Loss before income taxes |  |  | (7,663 | ) |  |  | 6,051 |  |
| Provision for income taxes |  |  | 1,402 |  |  |  | 1,675 |  |
| Net loss |  | $ | (9,065 | ) |  | $ | 4,376 |  |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.08 | ) |  | $ | 0.04 |  |
| Net loss per share - diluted |  | $ | (0.08 | ) |  | $ | 0.04 |  |
| Shares used in per share calculation - basic |  |  | 117,368 |  |  |  | 112,241 |  |
| Shares used in per share calculation - diluted |  |  | 117,368 |  |  |  | 118,431 |  |

[0001564590-18-026372:8k_2_02:60]
EXTREME NETWORKS, INC.

[0001564590-18-026372:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-026372:8k_2_02:62]
(In thousands)

[0001564590-18-026372:8k_2_02:63]
(Unaudited)

[0001564590-18-026372:8k_2_02:64]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (9,065 | ) |  | $ | 4,376 |  |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 6,783 |  |  |  | 3,125 |  |
| Amortization of intangible assets |  |  | 7,073 |  |  |  | 4,309 |  |
| Provision for doubtful accounts |  |  | 515 |  |  |  | 489 |  |
| Stock-based compensation |  |  | 6,825 |  |  |  | 4,803 |  |
| Deferred income taxes |  |  | (25 | ) |  |  | 488 |  |
| Unrealized/realized (gain) loss on equity investment |  |  | (154 | ) |  |  | (3,757 | ) |
| Non-cash interest |  |  | 995 |  |  |  | 227 |  |
| Other non-cash items |  |  | (172 | ) |  |  | 701 |  |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 46,661 |  |  |  | (5,762 | ) |
| Inventories |  |  | 8,287 |  |  |  | 5,915 |  |
| Prepaid expenses and other assets |  |  | (7,814 | ) |  |  | (1,856 | ) |
| Accounts payable |  |  | (31,251 | ) |  |  | 9,042 |  |
| Accrued compensation and benefits |  |  | (13,964 | ) |  |  | (5,360 | ) |
| Deferred revenue |  |  | 9,374 |  |  |  | 4,650 |  |
| Other current and long-term liabilities |  |  | 10,262 |  |  |  | (2,792 | ) |
| Net cash provided by operating activities |  |  | 34,330 |  |  |  | 18,598 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (7,417 | ) |  |  | (7,421 | ) |
| Business acquisitions |  |  | — |  |  |  | (68,047 | ) |
| Proceeds from sale of investment |  |  | 727 |  |  |  | 4,922 |  |
| Net cash used in investing activities |  |  | (6,690 | ) |  |  | (70,546 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 80,000 |  |
| Loan fees on borrowings |  |  | (273 | ) |  |  | (1,494 | ) |
| Repayments of debt |  |  | (12,375 | ) |  |  | (4,093 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 7,137 |  |  |  | 42 |  |
| Capital lease financing |  |  | (91 | ) |  |  | — |  |
| Contingent consideration obligations |  |  | (1,577 | ) |  |  | — |  |
| Deferred payments on an acquisition |  |  | (1,000 | ) |  |  | — |  |
| Net cash (used in) provided by financing activities |  |  | (8,179 | ) |  |  | 74,455 |  |
| Foreign currency effect on cash |  |  | (433 | ) |  |  | 57 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | 19,028 |  |  |  | 22,564 |  |
| Cash and cash equivalents at beginning of period |  |  | 121,139 |  |  |  | 130,450 |  |
| Cash and cash equivalents at end of period |  | $ | 140,167 |  |  | $ | 153,014 |  |

[0001564590-18-026372:8k_2_02:65]
Extreme Networks, Inc.

[0001564590-18-026372:8k_2_02:66]
Non-GAAP Measures of Financial Performance

[0001564590-18-026372:8k_2_02:67]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-18-026372:8k_2_02:68]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, gain on sale of equity investment and income tax.

[0001564590-18-026372:8k_2_02:69]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-18-026372:8k_2_02:70]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures to enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-18-026372:8k_2_02:71]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, restructuring charges, gain on sale of equity investment and income tax.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-18-026372:8k_2_02:72]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-18-026372:8k_2_02:73]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-18-026372:8k_2_02:74]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Wireless LAN business, b) Campus Fabric business, c) Data Center

[0001564590-18-026372:8k_2_02:75]
business and d) the bargain purchase gain for the capital financing business; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-18-026372:8k_2_02:76]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-18-026372:8k_2_02:77]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-18-026372:8k_2_02:78]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-18-026372:8k_2_02:79]
Gain on sale of equity investment.  The gain on the sale of an equity investment refers to a third party acquisition that acquired a business entity in which the Company had an equity investment.

[0001564590-18-026372:8k_2_02:80]
Income tax.   Income tax adjustments relate to the tax impact of reducing the US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation as well as the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada.

[0001564590-18-026372:8k_2_02:81]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-18-026372:8k_2_02:82]
EXTREME NETWORKS, INC.

[0001564590-18-026372:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-026372:8k_2_02:84]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-18-026372:8k_2_02:85]
(In thousands, except percentages and per share amounts)

[0001564590-18-026372:8k_2_02:86]
(Unaudited)

[0001564590-18-026372:8k_2_02:87]
| Non-GAAP Revenue | Three Months Ended |  |
|  | September 30, 2018 |  |  | September 30, 2017 |  |
| Revenue - GAAP Basis | $ | 239,886 |  |  | $ | 211,715 |  |
| Revenue - Non-GAAP Basis | $ | 239,886 |  |  | $ | 211,715 |  |

[0001564590-18-026372:8k_2_02:88]
| Non-GAAP Gross Margin | Three Months Ended |  |
|  | September 30, 2018 |  |  | September 30, 2017 |  |
| Gross profit - GAAP Basis | $ | 132,071 |  |  | $ | 112,381 |  |
| Gross margin - GAAP Basis percentage |  | 55.1 | % |  |  | 53.1 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 523 |  |  |  | 225 |  |
| Acquired inventory adjustments |  | — |  |  |  | 2,938 |  |
| Acquisition and integration costs |  | 1,752 |  |  |  | 1,846 |  |
| Amortization of intangibles |  | 4,825 |  |  |  | 2,564 |  |
| Total adjustments to GAAP gross profit | $ | 7,100 |  |  | $ | 7,573 |  |
| Gross profit - Non-GAAP | $ | 139,171 |  |  | $ | 119,954 |  |
| Gross margin - Non-GAAP percentage |  | 58.0 | % |  |  | 56.7 | % |

[0001564590-18-026372:8k_2_02:89]
| Non-GAAP Operating Income | Three Months Ended |  |
|  | September 30, 2018 |  |  | September 30, 2017 |  |
| GAAP operating (loss) income | $ | (5,018 | ) |  | $ | 4,492 |  |
| GAAP operating loss percentage |  | (2.1 | )% |  |  | 2.1 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 6,825 |  |  |  | 4,803 |  |
| Acquisition and integration costs |  | 4,298 |  |  |  | 6,090 |  |
| Restructuring charge, net of reversal |  | 808 |  |  |  | — |  |
| Acquired inventory adjustments |  | — |  |  |  | 2,938 |  |
| Amortization of intangibles |  | 6,966 |  |  |  | 4,178 |  |
| Total adjustments to GAAP operating (loss) income | $ | 18,897 |  |  | $ | 18,009 |  |
| Non-GAAP operating income | $ | 13,879 |  |  | $ | 22,501 |  |
| Non-GAAP operating income percentage |  | 5.8 | % |  |  | 10.6 | % |

[0001564590-18-026372:8k_2_02:90]
| Non-GAAP Net Income | Three Months Ended |  |
|  | September 30, 2018 |  |  | September 30, 2017 |  |
| GAAP net (loss) income | $ | (9,065 | ) |  | $ | 4,376 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 6,825 |  |  |  | 4,803 |  |
| Acquisition and integration costs |  | 4,298 |  |  |  | 6,090 |  |
| Restructuring charge, net of reversal |  | 808 |  |  |  | — |  |
| Acquired inventory adjustments |  | — |  |  |  | 2,938 |  |
| Amortization of intangibles |  | 6,966 |  |  |  | 4,178 |  |
| Gain on sale of equity investment |  | — |  |  |  | (3,757 | ) |
| Income tax |  | (480 | ) |  |  | — |  |
| Total adjustments to GAAP net (loss) income | $ | 18,417 |  |  | $ | 14,252 |  |
| Non-GAAP net income | $ | 9,352 |  |  | $ | 18,628 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.08 |  |  | $ | 0.16 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 120,242 |  |  |  | 118,431 |  |

[0001564590-18-026372:8k_2_02:91]
| Free Cash Flow | Three Months Ended |  |
|  | September 30, 2018 |  |  | September 30, 2017 |  |
| Cash flow provided by operations | $ | 34,330 |  |  | $ | 18,598 |  |
| Less: PP&E CapEx spending |  | (7,417 | ) |  |  | (7,421 | ) |
| Total free cash flow | $ | 26,913 |  |  | $ | 11,177 |  |
