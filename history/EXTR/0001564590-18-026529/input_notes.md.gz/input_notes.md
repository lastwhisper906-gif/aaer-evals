# EXTR notes — 0001564590-18-026529


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-026529:notes:1]
[same as prior period, unchanged from 0001564590-18-012675:notes:1]

[0001564590-18-026529:notes:2]
[same as prior period, unchanged from 0001564590-18-012675:notes:2]

[0001564590-18-026529:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2018 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2018.

[0001564590-18-026529:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2018. The results of operations for the three months ended September 30, 2018 are not necessarily indicative of the results that may be expected for fiscal 2019 or any future periods.

[0001564590-18-026529:notes:5]
[same as prior period, unchanged from 0001564590-18-012675:notes:6]

[0001564590-18-026529:notes:6]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2019” or “2019” represent the fiscal year ending June 30, 2019.  All references herein to “fiscal 2018” or “2018” represent the fiscal year ended June 30, 2018.

[0001564590-18-026529:notes:7]
[same as prior period, unchanged from 0001564590-18-012675:notes:8]

[0001564590-18-026529:notes:8]
[same as prior period, unchanged from 0001564590-18-012675:notes:9]

[0001564590-18-026529:notes:9]
[same as prior period, unchanged from 0001564590-18-012675:notes:10]

[0001564590-18-026529:notes:10]
[same as prior period, unchanged from 0001564590-18-012675:notes:11]

[0001564590-18-026529:notes:11]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Actual results could differ from these estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-026529:notes:12]
[same as prior period, unchanged from 0001564590-18-012675:notes:13]

[0001564590-18-026529:notes:13]
[same as prior period, unchanged from 0001564590-18-012675:notes:16]

[0001564590-18-026529:notes:14]
[same as prior period, unchanged from 0001564590-18-012675:notes:17]

[0001564590-18-026529:notes:15]
The Company completed its acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc.’s (“Brocade”) on October 27, 2017 (the “Data Center Closing Date”), pursuant to an Asset Purchase Agreement (the “Data Center Business APA”) dated as of October 3, 2017, by and between the Company and Brocade for an aggregate purchase consideration of $84.3 million. Under the terms and conditions of the Data Center Business APA, the Company acquired customers, employees, technology and other assets of the Data Center Business as well as assumed certain contracts and other liabilities of the Data Center Business.

[0001564590-18-026529:notes:16]
The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-18-026529:notes:17]
|  | Final Allocation |  |
| Accounts receivables | $ | 33,488 |  |
| Inventories |  | 19,934 |  |
| Prepaid expenses and other current assets |  | 988 |  |
| Property and equipment |  | 18,938 |  |
| Other assets |  | 4,734 |  |
| Accounts payable and accrued expenses |  | (16,494 | ) |
| Deferred revenue |  | (33,025 | ) |
| Net tangible assets acquired |  | 28,563 |  |
| Identifiable intangible assets |  | 32,800 |  |
| Goodwill |  | 22,974 |  |
| Total intangible assets acquired |  | 55,774 |  |
| Total net assets acquired | $ | 84,337 |  |

[0001564590-18-026529:notes:18]
[same as prior period, unchanged from 0001564590-18-012675:notes:34]

[0001564590-18-026529:notes:19]
The Company completed its acquisition of Avaya Inc.’s (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) on July 14, 2017, (the “Campus Fabric Business Closing Date”) pursuant to an Asset Purchase Agreement (the “Campus Fabric Business APA”) dated March 7, 2017.  Under the terms and conditions of the Campus Fabric Business APA, the Company acquired the customers, employees, technology and other assets of the Campus Fabric Business, as well as assumed certain contracts and other liabilities of the Campus Fabric Business, for total consideration of $79.4 million.

[0001564590-18-026529:notes:20]
|  | Final Allocation |  |
| Accounts receivables | $ | 19,527 |  |
| Inventories |  | 14,165 |  |
| Prepaid expenses and other current assets |  | 240 |  |
| Property and equipment |  | 5,406 |  |
| Other assets |  | 7,009 |  |
| Accounts payable and accrued expenses |  | (31,670 | ) |
| Deferred revenue |  | (8,994 | ) |
| Other long-term liabilities |  | (5,849 | ) |
| Net tangible assets acquired |  | (166 | ) |
| Identifiable intangible assets |  | 41,300 |  |
| In-process research and development |  | 2,400 |  |
| Goodwill |  | 35,892 |  |
| Total intangible assets acquired |  | 79,592 |  |
| Total net assets acquired | $ | 79,426 |  |

[0001564590-18-026529:notes:21]
[same as prior period, unchanged from 0001564590-18-012675:notes:42]

[0001564590-18-026529:notes:22]
[same as prior period, unchanged from 0001564590-18-012675:notes:43]

[0001564590-18-026529:notes:23]
Net assets acquired included financing receivables of $13.7 million, lease equipment of $3.5 million and identifiable intangible assets of $0.8 million, and the fair value of the contingent consideration was $13.0 million. As the preliminary fair value of the net assets acquired exceeded the fair value of the purchase consideration, the Company recorded a bargain purchase gain of $5.0 million.

[0001564590-18-026529:notes:24]
[same as prior period, unchanged from 0001564590-18-012675:notes:48]

[0001564590-18-026529:notes:25]
The following unaudited pro forma results of operations are presented as though the acquisitions of the Data Center Business, CF Business and Campus Fabric Business had occurred as of the beginning of fiscal 2017 presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-18-026529:notes:26]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2017, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-18-026529:notes:27]
The unaudited pro forma financial information for the three months ended September 30, 2017, combines the historical results for Extreme for that period, which includes the results of the Campus Fabric Business subsequent to the acquisition date, with the historical results of the Data Center Business, CF Business and Campus Fabric Business, prior to the acquisition date, for the three months ended September 30, 2017.

[0001564590-18-026529:notes:28]
Pro forma results of operations from the Data Center Business, CF Business and Campus Fabric Business acquisitions included in the pro forma results of operations for the three months ended September 30, 2017, have not been adjusted for the adoption of Topic 606 because the Company determined that it is impractical to estimate the impact of the adoption.

[0001564590-18-026529:notes:29]
[same as prior period, unchanged from 0001564590-18-012675:notes:54]

[0001564590-18-026529:notes:30]
|  | Three Months Ended |  |  |
|  |  | September 30, 2017 |  |  |
| Net revenues |  | $ | 284,508 |  |  |
| Net loss |  | $ | (8,774 | ) |  |
| Net loss per share - basic |  | $ | (0.08 | ) |  |
| Net loss per share - diluted |  | $ | (0.08 | ) |  |
| Shares used in per share calculation - basic |  |  | 112,241 |  |  |
| Shares used in per share calculation - diluted |  |  | 112,241 |  |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-026529:notes:31]
[same as prior period, unchanged from 0001564590-18-012675:notes:56]

[0001564590-18-026529:notes:32]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2018. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-18-026529:notes:33]
Recently Adopted Accounting Pronouncements

[0001564590-18-026529:notes:34]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities. The guidance was adopted effective July 1, 2018 and the Company reclassified a $0.5 million unrealized gain, net of tax, related to its available-for-sale investments from accumulated other comprehensive loss to accumulated deficit as a cumulative-effect adjustment in the accompanying condensed consolidated balance sheets.  Future changes in fair value will be included in earnings in each period.

[0001564590-18-026529:notes:35]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice.  The Company adopted the new guidance effective July 1, 2018. The amendments in this update have been applied on a retrospective transition method to each period presented. The adoption of this guidance did not have a material effect on the Company’s presentation of cash flows.

[0001564590-18-026529:notes:36]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740) - Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset other than inventory when the transfer occurs. Historical GAAP prohibits the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset has been sold outside the consolidated group.  The new guidance is effective for interim and annual reporting periods beginning after December 15, 2017. The Company adopted ASU 2016-16 effective July 1, 2018 on a modified retrospective basis. The adoption of this guidance did not have a material effect on the Company’s financial statements.

[0001564590-18-026529:notes:37]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting, which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718.  Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The Company adopted this guidance effective July 1, 2018, on a prospective basis.  The adoption of this guidance did not have a material effect on the Company’s financial statements.

[0001564590-18-026529:notes:38]
Recently Issued Accounting Pronouncements

[0001564590-18-026529:notes:39]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements.

[0001564590-18-026529:notes:40]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy Levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements.

[0001564590-18-026529:notes:41]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period, for reporting periods for which financial statements have not yet been issued. The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. Management is currently evaluating implementation options and impact on the Company's financial statements and related disclosures.

[0001564590-18-026529:notes:42]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The guidance is effective for fiscal years beginning after December 15, 2018. The Company is evaluating the accounting, transition and disclosure requirements of the standard and cannot currently estimate the financial statement impact of adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

[0001564590-18-026529:notes:43]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, Topic 842 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures.  The Company believes that Topic 842 will have a material impact on its financial position, as a result of recognizing right-of-use assets and lease liabilities on its consolidated balance sheets. The Company continues to evaluate the impact the new standard will have on its condensed consolidated statement of operations and statement of cash flows. This guidance will become effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-18-026529:notes:44]
| 4. | Revenues |

[0001564590-18-026529:notes:45]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-18-026529:notes:46]
Revenue Recognition

[0001564590-18-026529:notes:47]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-18-026529:notes:48]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three months ended September 30, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-18-026529:notes:49]
On September 30, 2018, the Company had $183.9 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 65 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 22 percent in fiscal 2020 and 13 percent of the balance thereafter.

[0001564590-18-026529:notes:50]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

[0001564590-18-026529:notes:51]
Revenue recognized for the three months ended September 30, 2018 and 2017, that was included in the deferred revenue balance at the beginning of each period was $50.6 million and $42.0 million, respectively.

[0001564590-18-026529:notes:52]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $4.9 million and $2.5 million at September 30, 2018 and 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2018 and 2017, was $0.7 million and $0.4 million, respectively.  There was no impairment loss in relation to the costs capitalized.

[0001564590-18-026529:notes:53]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-18-026529:notes:54]
Revenue by Category

[0001564590-18-026529:notes:55]
The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the customer’s ship-to locations (in thousands):

[0001564590-18-026529:notes:56]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |
| Other |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |
| Total Americas |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |
| EMEA |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |
| APAC |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |
| Total net revenues |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |

[0001564590-18-026529:notes:57]
Customer Concentrations

[0001564590-18-026529:notes:58]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-18-026529:notes:59]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenues:

[0001564590-18-026529:notes:60]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Tech Data Corporation |  | 17% |  |  | 11% |  |
| Westcon Group Inc. |  | 13% |  |  | 15% |  |
| Jenne Corporation |  | 12% |  |  | 14% |  |

[0001564590-18-026529:notes:61]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable balance:

[0001564590-18-026529:notes:62]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Tech Data Corporation |  | 21% |  |  | 17% |  |
| Westcon Group Inc. |  | 12% |  |  | * |  |
| Jenne Corporation |  | * |  |  | 13% |  |
| * Less than 10% of accounts receivable |  |  |  |  |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-026529:notes:63]
[same as prior period, unchanged from 0001564590-18-012675:notes:96]

[0001564590-18-026529:notes:64]
[same as prior period, unchanged from 0001564590-18-012675:notes:97]

[0001564590-18-026529:notes:65]
[same as prior period, unchanged from 0001564590-18-012675:notes:98]

[0001564590-18-026529:notes:66]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Cash |  | $ | 140,167 |  |  | $ | 121,139 |  |
| Cash equivalents |  |  | — |  |  |  | — |  |
| Total cash and cash equivalents |  |  | 140,167 |  |  |  | 121,139 |  |
| Marketable securities (consisting of available-for-sale securities) |  |  | 887 |  |  |  | 1,459 |  |
| Total cash, cash equivalents and marketable securities |  | $ | 141,054 |  |  | $ | 122,598 |  |

[0001564590-18-026529:notes:67]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Marketable equity securities are recorded in “Prepaid expense and other current assets” in the accompanying condensed consolidated balance sheets as these securities are publicly-traded with readily determinable values. Marketable equity securities are classified as available-for-sale and reported at fair value with unrealized gains and losses included in “Other (expense) income, net” in the accompanying condensed consolidated statements of operations.

[0001564590-18-026529:notes:68]
[same as prior period, unchanged from 0001564590-18-012675:notes:101]

[0001564590-18-026529:notes:69]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-18-026529:notes:70]
[same as prior period, unchanged from 0001564590-18-012675:notes:103]

[0001564590-18-026529:notes:71]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Finished goods |  | $ | 42,150 |  |  | $ | 49,393 |  |
| Raw materials |  |  | 13,430 |  |  |  | 14,474 |  |
| Total Inventories |  | $ | 55,580 |  |  | $ | 63,867 |  |

[0001564590-18-026529:notes:72]
[same as prior period, unchanged from 0001564590-18-012675:notes:105]

[0001564590-18-026529:notes:73]
[same as prior period, unchanged from 0001564590-18-012675:notes:106]

[0001564590-18-026529:notes:74]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Computers and equipment |  | $ | 63,456 |  |  | $ | 60,677 |  |
| Purchased software |  |  | 21,558 |  |  |  | 21,389 |  |
| Office equipment, furniture and fixtures |  |  | 15,034 |  |  |  | 14,980 |  |
| Leasehold improvements |  |  | 50,959 |  |  |  | 50,070 |  |
| Total property and equipment |  |  | 151,007 |  |  |  | 147,116 |  |
| Less: accumulated depreciation and amortization |  |  | (74,783 | ) |  |  | (68,597 | ) |
| Property and equipment, net |  | $ | 76,224 |  |  | $ | 78,519 |  |

[0001564590-18-026529:notes:75]
[same as prior period, unchanged from 0001564590-18-012675:notes:108]

[0001564590-18-026529:notes:76]
[same as prior period, unchanged from 0001564590-18-012675:notes:109]

[0001564590-18-026529:notes:77]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.1 years |  | $ | 117,000 |  |  | $ | 63,106 |  |  | $ | 53,894 |  |
| Customer relationships |  | 2.8 years |  |  | 51,639 |  |  |  | 41,578 |  |  |  | 10,061 |  |
| Maintenance contracts |  | 0.1 years |  |  | 17,000 |  |  |  | 16,717 |  |  |  | 283 |  |
| Trade names |  | 3.2 years |  |  | 9,100 |  |  |  | 4,506 |  |  |  | 4,594 |  |
| License agreements |  | 7.3 years |  |  | 2,232 |  |  |  | 1,244 |  |  |  | 988 |  |
| Other intangibles |  | 1.3 years |  |  | 1,382 |  |  |  | 1,179 |  |  |  | 203 |  |
| Total intangibles, net |  |  |  | $ | 198,353 |  |  | $ | 128,330 |  |  | $ | 70,023 |  |

[0001564590-18-026529:notes:78]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 117,000 |  |  | $ | 58,299 |  |  | $ | 58,701 |  |
| Customer relationships |  | 3.0 years |  |  | 51,639 |  |  |  | 40,634 |  |  |  | 11,005 |  |
| Maintenance contracts |  | 0.3 years |  |  | 17,000 |  |  |  | 15,866 |  |  |  | 1,134 |  |
| Trade names |  | 3.4 years |  |  | 9,100 |  |  |  | 4,141 |  |  |  | 4,959 |  |
| Backlogs |  | — years |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |
| License agreements |  | 5.8 years |  |  | 2,445 |  |  |  | 1,390 |  |  |  | 1,055 |  |
| Other intangibles |  | 1.6 years |  |  | 1,382 |  |  |  | 1,144 |  |  |  | 238 |  |
| Total intangibles, net |  |  |  | $ | 200,366 |  |  | $ | 123,274 |  |  | $ | 77,092 |  |

[0001564590-18-026529:notes:79]
[same as prior period, unchanged from 0001564590-18-012675:notes:113]

[0001564590-18-026529:notes:80]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 4,932 |  |  | $ | 2,695 |  |
| Amortization of intangibles |  |  | 2,141 |  |  |  | 1,614 |  |
| Total amortization |  | $ | 7,073 |  |  | $ | 4,309 |  |

[0001564590-18-026529:notes:81]
[same as prior period, unchanged from 0001564590-18-012675:notes:115]

[0001564590-18-026529:notes:82]
[same as prior period, unchanged from 0001564590-18-012675:notes:120]

[0001564590-18-026529:notes:83]
[same as prior period, unchanged from 0001564590-18-012675:notes:121]

[0001564590-18-026529:notes:84]
[same as prior period, unchanged from 0001564590-18-012675:notes:122]

[0001564590-18-026529:notes:85]
[same as prior period, unchanged from 0001564590-18-012675:notes:123]

[0001564590-18-026529:notes:86]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (492 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,008 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 178,125 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,627 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 176,498 |  |  |  | 188,749 |  |
| Total debt |  | $ | 185,506 |  |  | $ | 197,756 |  |

[0001564590-18-026529:notes:87]
On May 1, 2018, the Company entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) $40 million five-year revolving credit facility (the “New Revolving Facility”) ii) a $190 million five-year term loan (the “New Term Loan”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement to pay off existing debt and for general corporate purposes.

[0001564590-18-026529:notes:88]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting June 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-18-026529:notes:89]
The Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-18-026529:notes:90]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the Credit Agreement.  Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.2 million for each of the three month periods ended September 30, 2018 and 2017.

[0001564590-18-026529:notes:91]
The Company had $38.7 million of availability under the New Revolving Facility as of September 30, 2018.  The Company had $1.3 million of outstanding letters of credit as of September 30, 2018.

[0001564590-18-026529:notes:92]
[same as prior period, unchanged from 0001564590-18-012675:notes:132]

[0001564590-18-026529:notes:93]
[same as prior period, unchanged from 0001564590-18-012675:notes:133]

[0001564590-18-026529:notes:94]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2018 and 2017 (in thousands):

[0001564590-18-026529:notes:95]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Balance beginning of period |  | $ | 12,807 |  |  | $ | 10,584 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | 3,156 |  |
| New warranties issued |  |  | 3,722 |  |  |  | 2,272 |  |
| Warranty expenditures |  |  | (3,928 | ) |  |  | (2,513 | ) |
| Balance end of period |  | $ | 12,601 |  |  | $ | 13,499 |  |

[0001564590-18-026529:notes:96]
[same as prior period, unchanged from 0001564590-18-012675:notes:136]

[0001564590-18-026529:notes:97]
[same as prior period, unchanged from 0001564590-18-012675:notes:137]

[0001564590-18-026529:notes:98]
[same as prior period, unchanged from 0001564590-18-012675:notes:138]

[0001564590-18-026529:notes:99]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Acquisition related deferred payments, less current portion |  | $ | 12,350 |  |  | $ | 13,251 |  |
| Contingent consideration obligations, less current portion |  |  | 4,711 |  |  |  | 4,898 |  |
| Other contractual obligations, less current portion |  |  | 31,402 |  |  |  | 31,200 |  |
| Other |  |  | 15,644 |  |  |  | 9,751 |  |
| Total other long-term liabilities |  | $ | 64,107 |  |  | $ | 59,100 |  |

[0001564590-18-026529:notes:100]
[same as prior period, unchanged from 0001564590-18-012675:notes:140]

[0001564590-18-026529:notes:101]
All advertising costs are expensed as incurred. Advertising expenses for three months ended September 30, 2018 and 2017, were immaterial.

[0001564590-18-026529:notes:102]
[same as prior period, unchanged from 0001564590-18-012675:notes:142]

[0001564590-18-026529:notes:103]
[same as prior period, unchanged from 0001564590-18-012675:notes:143]


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-18-026529:notes:104]
[same as prior period, unchanged from 0001564590-18-012675:notes:148]

[0001564590-18-026529:notes:105]
[same as prior period, unchanged from 0001564590-18-012675:notes:149]

[0001564590-18-026529:notes:106]
[same as prior period, unchanged from 0001564590-18-012675:notes:150]

[0001564590-18-026529:notes:107]
[same as prior period, unchanged from 0001564590-18-012675:notes:151]

[0001564590-18-026529:notes:108]
[same as prior period, unchanged from 0001564590-18-012675:notes:152]

[0001564590-18-026529:notes:109]
[same as prior period, unchanged from 0001564590-18-012675:notes:153]

[0001564590-18-026529:notes:110]
| September 30, 2018 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable securities |  | $ | 887 |  |  | $ | — |  |  | $ | — |  |  | $ | 887 |  |
| Total assets measured at fair value |  | $ | 887 |  |  | $ | — |  |  | $ | — |  |  | $ | 887 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 11,233 |  |  | $ | 11,233 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 11,233 |  |  | $ | 11,233 |  |

[0001564590-18-026529:notes:111]
| June 30, 2018 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable securities |  | $ | 1,459 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,459 |  |
| Total assets measured at fair value |  | $ | 1,459 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,459 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 12,749 |  |  | $ | 12,749 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 12,749 |  |  | $ | 12,749 |  |

[0001564590-18-026529:notes:112]
[same as prior period, unchanged from 0001564590-18-012675:notes:156]

[0001564590-18-026529:notes:113]
The Company holds an investment in marketable equity securities which is classified as available-for-sale marketable securities at Level 1 as the investments have readily determinable fair value (see below, Level 3 investments). An unrealized holding gain on the investments was $0.5 million as of June 30, 2018.

[0001564590-18-026529:notes:114]
[same as prior period, unchanged from 0001564590-18-012675:notes:158]

[0001564590-18-026529:notes:115]
[same as prior period, unchanged from 0001564590-18-012675:notes:159]

[0001564590-18-026529:notes:116]
The fair value of the borrowings under the Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the short duration until maturity of the Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $187.6 million and $200.0 million as of September 30, 2018 and June 30, 2018, respectively. Such differences are immaterial for all periods presented.

[0001564590-18-026529:notes:117]
[same as prior period, unchanged from 0001564590-18-012675:notes:161]

[0001564590-18-026529:notes:118]
[same as prior period, unchanged from 0001564590-18-012675:notes:162]

[0001564590-18-026529:notes:119]
At June 30, 2018, the Company reflected a liability for contingent consideration related to a certain acquisition completed in Fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. The fair value of contingent consideration obligations is based on a discounted cash flow model.  These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations would be recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-18-026529:notes:120]
[same as prior period, unchanged from 0001564590-18-012675:notes:165]

[0001564590-18-026529:notes:121]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Beginning balance |  | $ | 12,749 |  |  | $ | — |  |
| Payments |  |  | (1,577 | ) |  |  | — |  |
| Accretion on discount |  |  | 61 |  |  |  | — |  |
| Ending balance |  | $ | 11,233 |  |  | $ | — |  |

[0001564590-18-026529:notes:122]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the three months ended September 30, 2018 or 2017. There were no impairments recorded for the three months ended September 30, 2018 or 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-026529:notes:123]
[same as prior period, unchanged from 0001564590-18-012675:notes:168]

[0001564590-18-026529:notes:124]
[same as prior period, unchanged from 0001564590-18-012675:notes:169]

[0001564590-18-026529:notes:125]
[same as prior period, unchanged from 0001564590-18-012675:notes:170]

[0001564590-18-026529:notes:126]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 7,804 |  |  |  | 9,957 |  |
| Employee stock options and awards outstanding |  |  | 12,236 |  |  |  | 12,060 |  |
| 2014 Employee Stock Purchase Plan |  |  | 4,084 |  |  |  | 5,365 |  |
| Total shares reserved for issuance |  |  | 24,124 |  |  |  | 27,382 |  |

[0001564590-18-026529:notes:127]
[same as prior period, unchanged from 0001564590-18-012675:notes:172]

[0001564590-18-026529:notes:128]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Cost of product revenue |  | $ | 178 |  |  | $ | 92 |  |
| Cost of service revenue |  |  | 345 |  |  |  | 133 |  |
| Research and development |  |  | 2,342 |  |  |  | 1,051 |  |
| Sales and marketing |  |  | 2,359 |  |  |  | 1,643 |  |
| General and administrative |  |  | 1,601 |  |  |  | 1,884 |  |
| Total share-based compensation expense |  | $ | 6,825 |  |  | $ | 4,803 |  |

[0001564590-18-026529:notes:129]
During the three months ended September 30, 2018 or 2017, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-18-026529:notes:130]
[same as prior period, unchanged from 0001564590-18-012675:notes:175]

[0001564590-18-026529:notes:131]
[same as prior period, unchanged from 0001564590-18-012675:notes:176]

[0001564590-18-026529:notes:132]
The following table summarizes stock award activity for the three months ended September 30, 2018 (in thousands, except grant date fair value):

[0001564590-18-026529:notes:133]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2018 |  |  | 7,764 |  |  | $ | 8.60 |  |  | $ | 61,804 |  |
| Granted |  |  | 3,337 |  |  |  | 6.44 |  |  |  |  |  |
| Vested |  |  | (1,142 | ) |  |  | 6.28 |  |  |  |  |  |
| Cancelled |  |  | (565 | ) |  |  | 8.69 |  |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2018 |  |  | 9,394 |  |  | $ | 8.11 |  |  | $ | 51,479 |  |

[0001564590-18-026529:notes:134]
The following table summarizes stock option activity for the three months ended September 30, 2018 (in thousands, except per share and contractual term):

[0001564590-18-026529:notes:135]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2018 |  |  | 2,193 |  |  | $ | 3.88 |  |  |  | 2.90 |  |  | $ | 8,996 |  |
| Granted |  |  | 852 |  |  |  | 6.40 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (123 | ) |  |  | 3.81 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (80 | ) |  |  | 6.18 |  |  |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2018 |  |  | 2,842 |  |  | $ | 4.57 |  |  |  | 3.88 |  |  | $ | 3,343 |  |
| Vested and expected to vest at September 30, 2018 |  |  | 2,842 |  |  | $ | 4.57 |  |  |  | 3.88 |  |  | $ | 3,343 |  |
| Exercisable at September 30, 2018 |  |  | 1,939 |  |  | $ | 3.98 |  |  |  | 2.68 |  |  | $ | 2,946 |  |

[0001564590-18-026529:notes:136]
[same as prior period, unchanged from 0001564590-18-012675:notes:181]

[0001564590-18-026529:notes:137]
[same as prior period, unchanged from 0001564590-18-012675:notes:182]

[0001564590-18-026529:notes:138]
During the first quarter of fiscal 2019, the Company approved the grant of 1,269,800 stock awards to its vice president level employees or above (“VPs”), including 278,000 stock awards to its Executive Officers, and 2,067,074 stock awards to its other employees.  Fifty percent (50%) of the stock awards granted to the VPs and the chief executive officer, were in the form of PSUs, with grant date fair values of $6.40, and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs.  The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-18-026529:notes:139]
For the PSUs referenced in the preceding paragraph, they will be considered earned once the Company’s combined earnings per share equals or exceeds $0.20 over two consecutive quarters (the “FY19 Performance Threshold”).  Upon satisfying the FY19 Performance Threshold, the PSUs shall vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, shall vest on the same schedule as the RSUs, subject to continued service to the Company.  If the FY19 Performance Threshold is not met by the third anniversary of the grant date the award is canceled.  In addition, the FY19 Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $10.00 per share.

[0001564590-18-026529:notes:140]
During the first quarter of fiscal 2019, the Company granted 851,700 Performance Stock Options (“PSOs”) to certain officers and executive vice presidents that will vest if the Company’s stock price achieves a price hurdle of $10.00 during the three-year performance period from August 29, 2018 through August 31, 2021. The price hurdle will be deemed to have been achieved if, at any time over the performance period, the Company’s stock maintains a price of $10.00 for 30 consecutive days.  If the price hurdle is achieved, the PSOs will vest as follows:

[0001564590-18-026529:notes:141]
If the price hurdle is met before or on August 31, 2019, one-third of the PSOs will vest on August 31, 2019 and the remainder will vest quarterly over two years.

[0001564590-18-026529:notes:142]
If the price hurdle is met after August 31, 2019, a number of the PSOs will vest (ratably calculated based upon the time elapsed between August 31, 2018 and the date the hurdle is met) and the remainder will vest quarterly through August 31, 2021.  The grant date fair value was $2.62.

[0001564590-18-026529:notes:143]
2014 Employee Stock Purchase Plan

[0001564590-18-026529:notes:144]
[same as prior period, unchanged from 0001564590-18-012675:notes:190]

[0001564590-18-026529:notes:145]
There were 1,280,708 and 1,267,930 shares issued under the ESPP during the three months ended September 30, 2018 and 2017, respectively.  The following assumptions were used to calculate the fair value of shares granted under the ESPP during the following periods:

[0001564590-18-026529:notes:146]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 2.20 | % |  |  | 1.15 | % |
| Volatility |  |  | 63 | % |  |  | 42 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-18-026529:notes:147]
The weighted-average fair value of shares granted under the ESPP during the three months ended September 30, 2018 and 2017 was $2.73 and $2.41, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-026529:notes:148]
8.Restructuring Charges, net of reversals

[0001564590-18-026529:notes:149]
[same as prior period, unchanged from 0001564590-18-012675:notes:201]

[0001564590-18-026529:notes:150]
The Company recorded $0.8 million of additional restructuring charges, net of reversals during the three months ended September 30, 2018, associated with a reduction-in-force in the fourth quarter of fiscal 2018.

[0001564590-18-026529:notes:151]
Cash payments of $3.4 million were paid during the first three months of fiscal 2019.  The balance of the severance and benefits obligations are expected to be paid by the end of fiscal 2019.  The excess facilities obligations will continue through fiscal year 2023.

[0001564590-18-026529:notes:152]
[same as prior period, unchanged from 0001564590-18-012675:notes:202]

[0001564590-18-026529:notes:153]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Total |  |
| Balance as of June 30, 2018 |  | $ | 1,797 |  |  | $ | 4,658 |  |  | $ | 6,455 |  |
| Period charges |  |  | — |  |  |  | 999 |  |  |  | 999 |  |
| Period reversals |  |  | — |  |  |  | (191 | ) |  |  | (191 | ) |
| Period payments |  |  | — |  |  |  | (3,402 | ) |  |  | (3,402 | ) |
| Balance as of September 30, 2018 |  | $ | 1,797 |  |  | $ | 2,064 |  |  | $ | 3,861 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  | 2,601 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  | $ | 1,260 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-026529:notes:154]
9.Commitments and Contingencies

[0001564590-18-026529:notes:155]
Purchase Commitments

[0001564590-18-026529:notes:156]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2018, the Company had non-cancelable commitments to purchase $158.7 million of such inventory.  As of September 30, 2018 the Company had non-cancelable commitments to purchase $117.5 million of software and new product support services.

[0001564590-18-026529:notes:157]
Legal Proceedings

[0001564590-18-026529:notes:158]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-18-026529:notes:159]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-18-026529:notes:160]
Brazilian Tax Assessment Matter

[0001564590-18-026529:notes:161]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of September 30, 2018.

[0001564590-18-026529:notes:162]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 19.6 million (USD $4.8 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

[0001564590-18-026529:notes:163]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (USD $2.3 million) as of the date the Company acquired Enterasys Networks.

[0001564590-18-026529:notes:164]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-18-026529:notes:165]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-18-026529:notes:166]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties have signed a term sheet to settle the litigation and are preparing further documentation for the settlement to submit for court approval.

[0001564590-18-026529:notes:167]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended.  The parties have reached an agreement in principle to settle the case, and are preparing further documentation for the settlement to submit for court approval.

[0001564590-18-026529:notes:168]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-18-026529:notes:169]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (PTAB) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date). During a status conference on October 22, 2018, the Court continued the stay and set a status conference for February 11, 2019. The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-026529:notes:170]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-18-026529:notes:171]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit, and intends to defend them vigorously.

[0001564590-18-026529:notes:172]
Indemnification Obligations

[0001564590-18-026529:notes:173]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of September 30, 2018, the Company has the outstanding indemnification claims described above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-026529:notes:174]
10.Income Taxes

[0001564590-18-026529:notes:175]
For the three months ended September 30, 2018 and 2017, the Company recorded income tax provision of $1.4 million and $1.7 million, respectively.

[0001564590-18-026529:notes:176]
The income tax provisions for the three months ended September 30, 2018 and 2017, consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and for the three months ended September 30, 2018, the Data Center Business. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended September 30, 2018 and 2017, respectively and therefore may not reflect the annual effective tax rate.

[0001564590-18-026529:notes:177]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, is effective for the Company’s fiscal year ended 2019. As a fiscal year taxpayer, the Company was not subject to the majority of the tax law provisions until the first quarter of fiscal year 2019; however, there were certain significant items of impact that were recognized in fiscal year 2018, the year the TCJA was enacted.

[0001564590-18-026529:notes:178]
The TCJA’s primary change is a reduction in the U.S. Federal statutory corporate tax rate from 35% to 21%.  As a result, the Company recognized a tax benefit in the amount of $2.5 million in the second quarter of fiscal 2018 due to the revaluation of the Company's deferred tax liability related to amortizable goodwill to reflect the lower statutory rate.  Because the U.S. deferred tax assets are offset by a full valuation allowance, the reduction in deferred tax assets for the lower rate was fully offset by a corresponding reduction in valuation allowance resulting in no additional tax provision.

[0001564590-18-026529:notes:179]
The TCJA moves the U.S. from a global taxation regime to a modified territorial regime.  Under the territorial regime, the company’s foreign earnings will generally not be subject to tax in the US.  As part of transitioning to this new regime, U.S. companies were required to pay tax on historical earnings generated offshore that have not been repatriated to the U.S. (“Transition Tax”).  The Company has estimated there will be no incremental tax provision relating to the Transition Tax given the Company’s ability to utilize existing tax attributes to offset the impact of the deemed repatriation.

[0001564590-18-026529:notes:180]
The TCJA makes broad and complex changes to the U.S. tax code, and in certain instances, lacks clarity and is subject to interpretation until additional U.S. Treasury guidance is issued.  On December 22, 2017, the SEC issued guidance under Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (“SAB 118”), which allows registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations.  However, the measurement period is deemed to have ended earlier when the registrant has obtained, prepared and analyzed the information necessary to finalize its accounting.  During the measurement period, impacts of the law are expected to be recorded at the time a reasonable estimate for all or a portion of the effects can be made, and provisional amounts can be recognized and adjusted as information becomes available, prepared or analyzed. SAB 118 summarizes a three-step process to be applied at each reporting period to account for and qualitatively disclose: (1) the effects of the change in tax law for which accounting is complete; (2) provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but that a reasonable estimate has been determined; and (3) a reasonable estimate cannot yet be made and therefore taxes are reflected in accordance with law prior to the enactment of the TCJA.

[0001564590-18-026529:notes:181]
Amounts recorded where accounting is complete principally relate to the reduction in the U.S. federal tax rate to 21 percent, which resulted in the Company reporting an income tax benefit of $2.5 million in the fiscal year ended June 30, 2018 to remeasure deferred tax liabilities associated with indefinitely lived intangible assets that will reverse at the new 21% rate. Absent this deferred tax liability, the Company is in a net deferred tax asset position that is offset by a full valuation allowance.  Though the impact of the rate change related to net deferred tax assets has a net tax effect of zero, the accounting to determine the gross change in the deferred tax position and the offsetting valuation is not yet complete.  In accordance with SAB 118, the estimated income tax impact associated with the Transition Tax of zero represents our best estimate based on interpretation of the U.S. legislation as we are still accumulating data to finalize the underlying calculation. In accordance with SAB 118, estimated income tax impact associated with the Transition Tax is considered provisional and will be finalized prior to the end of the measurement period. The ultimate impact may differ from these provisional amounts, due to, among other things, additional analysis, changes in interpretations and assumptions the Company has made, additional regulatory guidance that may be issued, and actions the Company may take as a result of the TCJA.

[0001564590-18-026529:notes:182]
With respect to provisions of the TCJA effective for the Company’s fiscal year ended 2019, the Company anticipates several new provisions may potentially impact tax provisions in future periods including limitations on the deductibility of interest expense and certain executive compensation, a minimum tax on certain foreign earnings (i.e., global intangible low-taxed income or “GILTI”).  The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. Based on initial assessment and interpretation of the new provision, the Company expects that it will be subject to incremental U.S. tax on GILTI income beginning in fiscal 2019. The Company may elect to account for GILTI tax as a component of tax expense in the period in which it is incurred or account for the GILTI tax in the measurement of deferred taxes. The Company is continuing to evaluate this particular provision and therefore has not yet elected a method but will do so once our analysis is complete. The Base Erosion and Anti-Abuse Tax (“BEAT”) provisions in the Tax Reform Act eliminate the deduction of certain base-erosion payments made to related foreign corporations and impose a minimum tax if greater than regular tax.  There is a reasonable amount of uncertainty surrounding the interpretation of this new provision, however, based on initial assessment and a reasonable interpretation of the new provision, the Company expects that it will not be subject to the incremental U.S. tax on BEAT income beginning in fiscal 2019, due to a realignment of the Company’s international structure.

[0001564590-18-026529:notes:183]
In the three months ended September 30, 2019, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs.  Historically, GAAP has prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset had been sold outside the consolidated group.  Effective as of July 1, 2018, the Company adopted ASU 2016-16 on a modified retrospective basis which requires an adjustment of the cumulative-effect of the adoption to retained earnings.  However, the adjustment was immaterial to the financial statements and no such adjustment was necessary.  As a result of adoption, the income tax consequences of future intra-entity transfer of assets will be recognized in earnings in each period rather than be deferred until the assets leave the consolidated group.  In the three months ended September 30, 2018, the Company recognized a deferred tax asset relating to a transfer of certain assets from the US parent company to its wholly-owned Irish subsidiary of $5.4 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to Company’s statement of operations.

[0001564590-18-026529:notes:184]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as the deferred tax assets in Australia and a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the above mentioned foreign jurisdictions.  This valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-18-026529:notes:185]
The acquisition of Enterasys in October 2013 included a U.S. parent company as well as its wholly-owned foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  In addition, the Company completed asset purchases of the WLAN Business, the Campus Fabric Business and the Data Center Business in October 2016, July 2017 and October 2017, respectively.  The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.  During the three months ended September 30, 2018 and 2017, the Company deducted $0.5 million and $1.6 million of tax amortization expense respectively, for each period related to capitalized goodwill resulting from these acquisitions. As of September 30, 2018, the Company recorded a deferred tax liability of $5.9 million related to this goodwill amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-18-026529:notes:186]
The Company had $17.2 million of unrecognized tax benefits as of September 30, 2018.  The future impact of the unrecognized tax benefit of $17.2 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-18-026529:notes:187]
[same as prior period, unchanged from 0001564590-18-012675:notes:241]

[0001564590-18-026529:notes:188]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses. The Company is in the process of settling examination by the state of North Carolina for fiscal years ended 2014, 2015 and 2016. The settlement will result in an immaterial payment to the state to close all three years.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-026529:notes:189]
11.Net Loss Per Share

[0001564590-18-026529:notes:190]
[same as prior period, unchanged from 0001564590-18-012675:notes:244]

[0001564590-18-026529:notes:191]
[same as prior period, unchanged from 0001564590-18-012675:notes:245]

[0001564590-18-026529:notes:192]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Net (loss) income |  | $ | (9,065 | ) |  | $ | 4,376 |  |
| Weighted-average shares used in per share calculation - basic |  |  | 117,368 |  |  |  | 112,241 |  |
| Effect of potentially dilutive shares: |  |  |  |  |  |  |  |  |
| Options to purchase common stock |  |  | — |  |  |  | 1,760 |  |
| Restricted stock units |  |  | — |  |  |  | 4,007 |  |
| Employee Stock Purchase Plan shares |  |  | — |  |  |  | 423 |  |
| Weighted-average shares used in per share calculation - diluted |  |  | 117,368 |  |  |  | 118,431 |  |
| Net (loss) income per share: |  |  |  |  |  |  |  |  |
| Net (loss) income per share - basic |  | $ | (0.08 | ) |  | $ | 0.04 |  |
| Net (loss) income per share - diluted |  | $ | (0.08 | ) |  | $ | 0.04 |  |

[0001564590-18-026529:notes:193]
[same as prior period, unchanged from 0001564590-18-012675:notes:247]

[0001564590-18-026529:notes:194]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Options to purchase common stock |  |  | 989 |  |  |  | — |  |
| Restricted stock units |  |  | 1,913 |  |  |  | 496 |  |
| Employee Stock Purchase Plan shares |  |  | — |  |  |  | 204 |  |
| Total shares excluded |  |  | 2,902 |  |  |  | 700 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-026529:notes:195]
[same as prior period, unchanged from 0001564590-18-012675:notes:249]

[0001564590-18-026529:notes:196]
[same as prior period, unchanged from 0001564590-18-012675:notes:250]

[0001564590-18-026529:notes:197]
As of September 30, 2018, the Company did not have any forward foreign currency contracts. As of September 30, 2017 forward foreign currency contracts had a notional principal amount of $9.6 million and an immaterial unrealized loss. These contracts typically have maturities of less than 90 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001564590-18-026529:notes:198]
Foreign currency transactions gains and losses from operations was a gain of $0.2 million and loss from operations of $0.6 million for the three months ended September 30, 2018 and 2017, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-026529:notes:199]
[same as prior period, unchanged from 0001564590-18-012675:notes:253]

[0001564590-18-026529:notes:200]
The Company operates in one segment, the development and marketing of network infrastructure equipment. The Company conducts business globally and is managed geographically. Revenue is attributed to a geographical area based on the location of its customers. The Company operates in three geographical areas: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia, India, Australia and Japan. The Company’s chief operating decision maker, who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-18-026529:notes:201]
See Note 4 Net Revenues for the Company’s revenues by geographic regions and channel based on the customer’s ship-to location.

[0001564590-18-026529:notes:202]
[same as prior period, unchanged from 0001564590-18-012675:notes:256]

[0001564590-18-026529:notes:203]
| Long-lived Assets |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Americas |  | $ | 147,276 |  |  | $ | 178,251 |  |
| EMEA |  |  | 46,119 |  |  |  | 15,106 |  |
| APAC |  |  | 9,187 |  |  |  | 9,896 |  |
| Total long-lived assets |  | $ | 202,582 |  |  | $ | 203,253 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-026529:notes:204]
14.Subsequent Event

[0001564590-18-026529:notes:205]
On November 2, 2018, the Company announced that its Board of Directors has authorized the Company to repurchase up to $60.0 million of its common stock over the next two years. Purchases may be made from time to time in the open market, in privately negotiated transactions or otherwise. The manner, timing and amount of any purchases will be determined by the Company's management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations.  No repurchases were made during the quarter ended September 30, 2018.
