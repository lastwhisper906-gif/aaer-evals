# EXTR MD&A — 0001564590-18-026529


## mdna

[0001564590-18-026529:mdna:1]
[same as prior period, unchanged from 0001564590-18-012675:mdna:1]

[0001564590-18-026529:mdna:2]
[same as prior period, unchanged from 0001564590-18-012675:mdna:2]

[0001564590-18-026529:mdna:3]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”).  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-18-026529:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leading provider of network infrastructure equipment and offers related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. Substantially all of our revenue is derived from the sale of our networking equipment and related maintenance contracts.

[0001564590-18-026529:mdna:5]
Extreme is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from the data center to the access point, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. We strive to help our customers and partners Connect Beyond the Network by building world-class software and network infrastructure solutions that solve the wide range of problems faced by IT departments.

[0001564590-18-026529:mdna:6]
Enterprise network administrators from the data center to the access layer need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security.  Accelerators such as Internet of Things (“IoT”), artificial intelligence (“AI”), bring your own device (“BYOD”), machine learning, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-18-026529:mdna:7]
A trend effecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud and third-party, public cloud services with orchestration between the two platforms. ExtremeCloud is the only offering in the market that seamlessly integrates the cloud with on-premise infrastructures.

[0001564590-18-026529:mdna:8]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended September 30, 2018.

[0001564590-18-026529:mdna:9]
To facilitate the readers understanding, the following is a list of common terms in our industry used in the discussion of our business:

[0001564590-18-026529:mdna:10]
|  | • | Access: Network access is the closest point of entry to a network whether it is a wireless access point, Ethernet connection, or Wi-Fi device. |

[0001564590-18-026529:mdna:11]
|  | • | Access Point: A wireless access point, or more generally just access point (“AP”), is a networking hardware device that allows a Wi-Fi device to connect to a wired network. (Industry term) |

[0001564590-18-026529:mdna:12]
|  | • | Aggregation: In computer networking, the term aggregation applies to various methods of combining (aggregating) multiple network connections in parallel in order to increase throughput beyond what a single connection could sustain, and to provide redundancy in case one of the links should fail. |

[0001564590-18-026529:mdna:13]
|  | • | Artificial Intelligence: Artificial Intelligence (“AI”) is a set of technologies that enable computers to simulate the cognitive knowledge-processing capabilities of humans. Because it is artificial, the objective of most work in AI is to augment the capabilities of humans, not to replace them. Just as computers in general are applied to the tedious and repetitive tasks that humans find tedious, AI-based solutions can deal with often large (“Big Data”) volumes of digitally-encoded information dispassionately, unemotionally, rapidly, and, depending upon the parameters of a specific application and implementation, accurately. In network administration, AI can be applied to dealing with the “more-variables-than-equations nature” of radio frequency settings in even very- large-scale Wi-Fi installations. The goal is to achieve optimal network-wide performance more accurately and at lower cost than would be possible with humans alone. |

[0001564590-18-026529:mdna:14]
|  | • | Campus (Network): A campus network, or campus area network, or corporate area network (“CAN”) is a computer network made up of an interconnection of local area networks (“LANs”) within a limited geographical area, such as a college campus, company campus, hospital, hotel, convention center or sports venue. |

[0001564590-18-026529:mdna:15]
|  | • | CloudStack: CloudStack is an open source cloud computing software for creating, managing, and deploying infrastructure cloud services. It uses existing hypervisors such as KVM, VMware ESXi and XenServer/XCP for virtualization. |

[0001564590-18-026529:mdna:16]
|  | • | Core: A core network, or network core, is the central part of a telecommunications network that provides various services to customers who are connected by the access network. |

[0001564590-18-026529:mdna:17]
|  | • | Data Center: A data center is a facility used to house computer systems and associated components, such as telecommunications and storage systems. It generally includes redundant or backup power supplies, redundant data communications connections, environmental controls (e.g. air conditioning, fire suppression) and various security devices. |

[0001564590-18-026529:mdna:18]
|  | • | Data Center Fabric technologies: Also known as networking switch fabric, is the basic topology of how a network is laid out and connected to switch traffic on a data or circuit-switched network. |

[0001564590-18-026529:mdna:19]
|  | • | Edge: An edge device is a device which provides an entry point into enterprise or service provider core networks. Examples include routers, routing switches, integrated access devices (“IADs”), multiplexers, and a variety of metropolitan area network (“MAN”) and wide area network (“WAN”) access devices. |

[0001564590-18-026529:mdna:20]
|  | • | Fabric Attach: Avaya’s Fabric Attach (“FA”) fundamentally introduces autonomic/automatic attachment to network services for end users IoT devices to a network infrastructure. Fabric Attach and Fabric Connect are key building blocks of the Avaya SDN Fx™ architecture. |

[0001564590-18-026529:mdna:21]
|  | • | Fabric Connect: Fabric Connect is an extended implementation of the IEEE/IEFT standards for Shortest Path Bridging (“SPB”). It offers a full-service network virtualization technology that combines the best of Ethernet and the best of IP. |

[0001564590-18-026529:mdna:22]
|  | • | Flipped Classroom: Flipped classroom is an instructional strategy and a type of blended learning that reverses the traditional learning environment by delivering instructional content, often online, outside of the classroom. |

[0001564590-18-026529:mdna:23]
|  | • | Internet Protocol: Internet Protocol (“IP”) is the principal set (or communications protocol) of digital message formats and rules for exchanging messages between computers across a single network or a series of interconnected networks, using the Internet Protocol Suite (often referred to as TCP/IP) |

[0001564590-18-026529:mdna:24]
|  | • | Layer 3 Data Center Interconnect; A Data Center Interconnect (“DCI”) refers to the networking of two or more different data centers to achieve business or IT objectives. This interconnectivity between separate data centers enables them to work together, share resources and/or pass workloads between one another. A Layer 3 DCI refers to interconnection made through layer 3 of the commonly-referenced multilayered communication model, Open Systems Interconnection (“OSI”). |

[0001564590-18-026529:mdna:25]
|  | • | Machine Learning: Machine Learning (“ML”) is a set of technologies, and itself a branch of AI, that enables computers to simulate human learning, with learning defined here as the ability to change behavior and/or essential capabilities (again, simulated as a digital process on a computer) in response to new information suitably encoded for consumption by the algorithms implementing ML. In other words, ML enables AI-based processes to “learn” from past behaviors and consequently to improve future results, in much the same way as experiential education benefits humans. |

[0001564590-18-026529:mdna:26]
|  | • | Network Automation: Network Automation (“NA”) is a methodology in which software automatically configures, provisions, manages and tests network devices. It is used by enterprises and service providers to improve efficiency and reduce human error and operating expenses. |

[0001564590-18-026529:mdna:27]
27

[0001564590-18-026529:mdna:28]
|  | • | OpenFlow: OpenFlow (“OF”) is considered one of the first software-defined networking (“SDN”) standards. It originally defined the communication protocol in SDN environments that enables the SDN Controller to directly interact with the forwarding plane of network devices such as switches and routers, both physical and virtual (hypervisor-based), so it can better adapt to changing business requirements. (Source: SDx Central) |

[0001564590-18-026529:mdna:29]
|  | • | OpenStack: OpenStack software controls large pools of compute, storage, and networking resources throughout a datacenter, managed through a dashboard or via the OpenStack API. OpenStack works with popular enterprise and open source technologies making it ideal for heterogeneous infrastructure. (Source: OpenStack.org) |

[0001564590-18-026529:mdna:30]
|  | • | Single Pane of Glass: Single pane of glass is a term used to describe a management display console that integrates all parts of a computer infrastructure. |

[0001564590-18-026529:mdna:31]
|  | • | Stackstorm: A platform for integration and automation across services and tools. It ties existing infrastructure and application environment to automate that environment. It has a particular focus on taking actions in response to events. |

[0001564590-18-026529:mdna:32]
|  | • | Wi-Fi: Wireless Access points using Radio Frequency and protocols to allow computers, smartphones, or other devices to connect to the Internet or communicate with one another wirelessly within an area. |

[0001564590-18-026529:mdna:33]
Industry Background

[0001564590-18-026529:mdna:34]
Enterprises are adopting new IT delivery models and applications that require fundamental network alterations and enhancements spanning from device access point to the network core. AI and ML technologies have the potential to vastly improve the network experience. When AI and ML are used in conjunction with an NA technology, administrators can make significant advances in productivity, availability, accessibility, manageability, security and speed of their network infrastructure. These emerging technologies are driving administrators to a mindset of change toward agile processes that allow a versatile workforce to improve the rate of innovation of the enterprise safely, securely and with confidence.

[0001564590-18-026529:mdna:35]
AI, ML and NA have increased the relevance and importance of the network in the enterprise. Traditional network offerings are not well-suited to fulfill enterprise expectations for rapid delivery of new services, more flexible business models, real-time response and massive scalability.

[0001564590-18-026529:mdna:36]
The networking industry appears to be invigorated by this wave of technological change:

[0001564590-18-026529:mdna:37]
[same as prior period, unchanged from 0001564590-18-012675:mdna:8]

[0001564590-18-026529:mdna:38]
|  | • | The mobile workforce continues to proliferate. Employees expect high-quality and secure access to corporate resources in a BYOD world across a diversity of endpoints such as laptops, tablets, smart phones and wearables, whether they are within the corporate firewall or on-the-go. With ExtremeManagement, IT departments focus their investment decisions on this mobile workforce, taking a unified view of wireless access, from the campus core and the data center. Extreme offers end-to-end solutions that permit IT managers to meet employee expectations and to maximize IT return on investment. |

[0001564590-18-026529:mdna:39]
|  | • | Verticals such as retail, finance, healthcare, education, manufacturing, government and hospitality (which includes sports and entertainment venues) are connecting with their customers and guests beyond the network. These enterprises are investing in guest and location technologies that connect with their customers via their mobile devices over their WLAN. This allows them to obtain rich analytics for contextual marketing, which in turn, enables them to deliver a personalized brand experience. ExtremeGuest and ExtremeLocation have been built on cloud-based technology for simple implementation and fast release to market to better provide necessary insights into guest demographics and location-based analytics. |

[0001564590-18-026529:mdna:40]
28

[0001564590-18-026529:mdna:41]
|  | • | The Internet of Things. The Internet of Things is having dramatic effects on network infrastructure in healthcare, education, manufacturing, government and retail as more “smart” devices are entering the networks. These devices pose opportunities as well as threats to the network. |

[0001564590-18-026529:mdna:42]
|  | • | Growing usage of the cloud. Enterprises have migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. Ethernet speeds, scaling from 10 Gigabits per second ("G") to 100G, provide the infrastructure for both private and public clouds. In addition, there is growing interest in SDN approaches that may include technologies such as OpenFlow, OpenStack, and CloudStack for increased network agility. |

[0001564590-18-026529:mdna:43]
|  | • | Vendor consolidation is expected to continue. Consolidation of vendors within the enterprise network equipment market and between adjacent markets (storage, security, wireless & voice software and applications) continues to gain momentum. Further, we believe customers are demanding more end-to-end, integrated networking solutions. To address this demand, we acquired the WLAN Business of Zebra in October 2016, the Campus Fabric Business from Avaya in July 2017, and the Data Center Business from Brocade in October 2017. |

[0001564590-18-026529:mdna:44]
Our strategy, product portfolio and research and development are closely aligned with what we have identified as the following trends in our industry:

[0001564590-18-026529:mdna:45]
|  | ○ | The software segment of the worldwide enterprise network equipment market has continued to evolve and demands for improvements in Network Management will continue. |

[0001564590-18-026529:mdna:46]
|  | ➣ | We announced our Extreme Management Console in Fiscal 2017. This innovative software helps IT network administrators to navigate the unprecedented demands caused by the surge of IoT devices and technology. |

[0001564590-18-026529:mdna:47]
|  | ○ | Enterprise adoption of the cloud and open-source options are disrupting traditional license and maintenance business models. |

[0001564590-18-026529:mdna:48]
|  | ➣ | We announced cloud offerings in April 2016 and enhanced those offerings in 2017. Extreme began participation in the OpenSwitch program in May 2016 and now participates in the StackStorm community with the acquisition from Brocade in November 2017. |

[0001564590-18-026529:mdna:49]
|  | o | Enterprise adoption of new financing solutions allows for increased flexibility, limited investment and zero long-term commitments. These offerings are changing the traditional CAPEX model to (OPEX) models using financing purchases over time are disrupting traditional sell-in business models. |

[0001564590-18-026529:mdna:50]
|  | ➣ | We announced Extreme Capital Solutions in April 2018. The offering includes subscription, capital leasing and usage business models that provide flexibility for partners and customers. |

[0001564590-18-026529:mdna:51]
|  | ○ | Growth of wireless devices continues to outpace hardwire switch growth. |

[0001564590-18-026529:mdna:52]
|  | ➣ | We announced our 802.11ac Wave 2 wireless offering in late 2015 and plans to continue to advance our wireless portfolio of indoor and outdoor access points. |

[0001564590-18-026529:mdna:53]
The Extreme Strategy

[0001564590-18-026529:mdna:54]
We are focused on delivering end-to-end IP networking solutions for today’s enterprise environments. From wireless and wired access technologies, through the campus, core and into the datacenter, Extreme is developing solutions to deliver outstanding business outcomes for our customers.  Leveraging a unified management approach, both on premise and in the cloud, we continue to accelerate adoption and delivery of new technologies in support of emerging trends in enterprise networking. We continue to execute on our growth objectives by maximizing customer, partner, and shareholder value.

[0001564590-18-026529:mdna:55]
In fiscal 2017, we completed the acquisition of the WLAN Business from Zebra. In fiscal 2018, we completed the acquisitions of the Campus Fabric Business from Avaya and the Data Center Business from Brocade. These acquisitions support our growth strategy to lead the enterprise network equipment market with end-to-end software-driven solutions for enterprise customers from the data center to the wireless edge.  After the closing of the acquisitions of the Campus Fabric Business and Data Center Business, Extreme immediately became a networking industry leader with more than 30,000 customers. As a network switching leader in enterprise, datacenter and cloud, after closing of the Campus Fabric Business, we combine and extend our world-class products and technologies to provide customers with some of the most advanced, high performance and open solutions in the market as well as a superb overall customer experience.  The combination of Extreme, the Campus Fabric Business and the Data Center Business is significant in that it brings together distinct strengths addressing the key areas of the network, from unified wired and wireless edge, to the enterprise core, to the data center and cloud to offer a complete, unified portfolio of software-driven network access solutions.

[0001564590-18-026529:mdna:56]
Provider of high quality, software-driven, secure networking solutions and the industry’s #1 customer support organization

[0001564590-18-026529:mdna:57]
|  | • | Only multi-vendor network management with “single pane of glass”. |

[0001564590-18-026529:mdna:58]
|  | • | Delivering new releases of next generation portfolio organically and through acquisition. |

[0001564590-18-026529:mdna:59]
Key elements of our strategy include:

[0001564590-18-026529:mdna:60]
|  | • | Focus on being nimble and responsive to customers and partners, we call this “Customer-Driven Networking™.” We work with our customers to deliver software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable digital transformation for our customers. We help our customers move beyond just “keeping the lights on”, so they can think strategically and innovate. By allowing customers to access critical decision-making intelligence, we are able reduce their daily tactical work so they can spend their time on learning and understanding how to innovate their business with IT. |

[0001564590-18-026529:mdna:61]
|  | • | Enable a common fabric to simplify and automate the network. With the acquisition of the Campus Fabric Business, Extreme now has access to field driven Campus and Data Center Fabric technologies. Fabric technologies virtualize the network infrastructure (decoupling network services from physical connectivity) which enables network services to be turned up faster, with lower likelihood of error. They make the underlying network much easier to design, implement, manage and troubleshoot. |

[0001564590-18-026529:mdna:62]
|  | • | Software-driven networking services-led solutions. Our software-driven solutions provide visibility, control and strategic intelligence from the Edge to the Data Center, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points and controllers. We offer a suite of products that are tightly integrated with access control, network and application analytics as well as network management. All can be managed, assessed and controlled from one single pane of glass. |

[0001564590-18-026529:mdna:63]
|  | • | Offer customers choice – cloud or on premise. We leverage cloud where it makes sense for our customers and provide on premise solutions where customers need it. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with one single pane of glass. Our customers can understand what’s going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for BYOD and IoT. |

[0001564590-18-026529:mdna:64]
|  | • | Enable IoT without additional IT resources. In a recent IoT IT infrastructure survey conducted in December 2016, enterprise IT decision makers across industry verticals indicated their preference to opt for their existing wireless connectivity infrastructure to support IoT devices. These preferences will place unprecedented demand on network administrators to enhance management capabilities, scalability and programmability of the enterprise networks they manage without additional IT resources. |

[0001564590-18-026529:mdna:65]
|  | • | Provide a strong value proposition for our customers. Our cloud-managed wired and wireless networking solutions that provide additional choice and flexibility with on or off premise network, device and application management coupled with our award-winning services and support provide a strong value proposition to the following customers and applications: |

[0001564590-18-026529:mdna:66]
|  | ○ | Enterprises and private cloud data centers use our products to deploy automated next-generation virtualized and high-density infrastructure solutions. |

[0001564590-18-026529:mdna:67]
|  | ○ | Enterprises and organizations in education, healthcare, manufacturing, hospitality, transportation and logistics and government agencies use our solutions for their mobile campus and backbone networks. |

[0001564590-18-026529:mdna:68]
|  | ○ | Enterprises, universities, healthcare and hospitality organizations use our solutions to enable better visibility and control of their data processing and analytics requirements. |

[0001564590-18-026529:mdna:69]
|  | • | Provide high-quality customer service and support. We seek to enhance customer satisfaction and build customer loyalty through high-quality service and support. This includes a wide range of standard support programs that provide the level of service our customers require, from standard business hours to global 24-hour-a-day, 365-days-a-year real-time response support. |

[0001564590-18-026529:mdna:70]
30

[0001564590-18-026529:mdna:71]
|  | • | Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience and our operating systems - the software that runs on all of our Ethernet Switches. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud, etc. Furthermore, our network operating systems, our primary merchant silicon vendor, and select manufacturing partners permit us to leverage our engineering investment. We have invested in engineering resources to create leading-edge technologies to increase the performance and functionality of our products, and as a direct result, the value of our solution to our current and future customers. We look for maximum synergies from our engineering investment in our targeted verticals. |

[0001564590-18-026529:mdna:72]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The increase in demand being seen today, fueled by more users with multiple devices, increases the expectation that everything will just work. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent and always-on wired to wireless edge services. This new “unified access layer” requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. Our unified access layer portfolio provides intelligence for the wired/wireless edge |

[0001564590-18-026529:mdna:73]
|  | • | Continue to deliver unified management and a common fabric across the wired/wireless environment from the Data Center to the mobile Edge. Our rich set of integrated management capabilities provides centralized visibility and highly efficient anytime, anywhere control of enterprise wired and wireless network resources. |

[0001564590-18-026529:mdna:74]
|  | • | Offer a superior quality of experience. Our network-powered application analytics provide actionable business insight by capturing and analyzing context-based data about the network and applications to deliver meaningful intelligence about applications, users, locations and devices. With an easy to comprehend dashboard, our applications help businesses to turn their network into a strategic business asset that helps executives make faster and more effective decisions. |

[0001564590-18-026529:mdna:75]
Data can be mined to show how applications are being used enabling a better understanding of user behavior on the network, identifying the level of user engagement and assuring business application delivery to optimize the user experience. Application adoption can be tracked to determine the return on investment associated with new application deployment.

[0001564590-18-026529:mdna:76]
Visibility into network and application performance enables our customers to pinpoint and resolve performance bottlenecks in the infrastructure whether they are caused by the network, application or server. This saves both time and money for the business and ensures critical applications are running at the best possible performance.

[0001564590-18-026529:mdna:77]
|  | • | Software-driven networking solutions for the enterprise. We are a software-driven networking solution company focused on the enterprise. We focus our R&D team and our sales teams to execute against a refined set of requirements for optimized return on investment, faster innovation, and clearer focus on mega trends and changes in the industry. As a software-driven networking company, we offer solutions for the entire enterprise network, the data center, the campus, the core and the WLAN. |

[0001564590-18-026529:mdna:78]
|  | • | Expand market penetration by targeting high-growth market segments. Within the Campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our Data Center approach leverages our product portfolio to address the needs of public and private Cloud Data Center providers. Within the Campus we also target the high-growth physical security market, converging technologies such as Internet Protocol (“IP”) video across a common Ethernet infrastructure in conjunction with technology partners. |

[0001564590-18-026529:mdna:79]
|  | • | Leverage and expand multiple distribution channels. We distribute our products through select distributors, a large number of resellers and system-integrators worldwide, and several large strategic partners. We maintain a field sales force to support our channel partners and to sell directly to certain strategic accounts. As an independent Ethernet switch vendor, we seek to provide products that, when combined with the offerings of our channel partners, create compelling solutions for end-user customers. |

[0001564590-18-026529:mdna:80]
|  | • | Maintain and extend our strategic relationships. We have established strategic relationships with a number of industry-leading vendors to both provide increased and enhanced routes to market, but also to collaboratively develop unique solutions. |

[0001564590-18-026529:mdna:81]
[same as prior period, unchanged from 0001564590-18-012675:mdna:33]

[0001564590-18-026529:mdna:82]
During the first quarter of fiscal 2019, we reflected the following results:

[0001564590-18-026529:mdna:83]
|  | • | Net revenues of $239.9 million compared to $211.7 million in the first quarter of fiscal 2018. |

[0001564590-18-026529:mdna:84]
|  | • | Product revenue of $177.7 million compared to $164.8 million in the first quarter of fiscal 2018. |

[0001564590-18-026529:mdna:85]
|  | • | Service revenue of $62.2 million compared to $46.9 million in the first quarter of fiscal 2018. |

[0001564590-18-026529:mdna:86]
|  | • | Total gross margin of 55.1% of net revenues compared to 53.1% of net revenues in the first quarter of fiscal 2018. |

[0001564590-18-026529:mdna:87]
|  | • | Operating loss of $5.0 million compared to operating profit $4.5 million in the first quarter of fiscal 2018. |

[0001564590-18-026529:mdna:88]
|  | • | Net loss of $9.1 million compared to a net income of $4.4 million in the first quarter of fiscal 2018. |

[0001564590-18-026529:mdna:89]
|  | • | Cash flow provided by operating activities of $34.3 million compared to $18.6 million in the three months ended September 30, 2017. Cash, cash equivalents and marketable securities of $141.1 million compared to $130.5 million as of June 30, 2018. |

[0001564590-18-026529:mdna:90]
[same as prior period, unchanged from 0001564590-18-012675:mdna:42]

[0001564590-18-026529:mdna:91]
[same as prior period, unchanged from 0001564590-18-012675:mdna:43]

[0001564590-18-026529:mdna:92]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 177,720 |  |  | $ | 164,774 |  |  | $ | 12,946 |  |  |  | 7.9 | % |
| Percentage of net revenue |  |  | 74.1 | % |  |  | 77.8 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 62,166 |  |  |  | 46,941 |  |  |  | 15,225 |  |  |  | 32.4 | % |
| Percentage of net revenue |  |  | 25.9 | % |  |  | 22.2 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 239,886 |  |  | $ | 211,715 |  |  | $ | 28,171 |  |  |  | 13.3 | % |

[0001564590-18-026529:mdna:93]
Product revenue increased $12.9 million or 7.9% for the three months ended September 30, 2018 as compared to the corresponding period of fiscal 2018. The growth in product revenues was attributable to the acquisition of the Data Center Business, partial offset by longer customer buying cycles and growth in our backlog.

[0001564590-18-026529:mdna:94]
Service revenue increased $15.2 million, or 32.4% for the three months ended September 30, 2018 as compared to the corresponding period of fiscal 2018.  The growth in service revenue was primarily due to the increased number of service contracts acquired with the acquisition of the Data Center Business.

[0001564590-18-026529:mdna:95]
[same as prior period, unchanged from 0001564590-18-012675:mdna:49]

[0001564590-18-026529:mdna:96]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 94,177 |  |  | $ | 84,729 |  |  | $ | 9,448 |  |  |  | 11.2 | % |
| Percentage of product revenue |  |  | 53.0 | % |  |  | 51.4 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 37,894 |  |  |  | 27,652 |  |  |  | 10,242 |  |  |  | 37.0 | % |
| Percentage of service revenue |  |  | 61.0 | % |  |  | 58.9 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 132,071 |  |  | $ | 112,381 |  |  | $ | 19,690 |  |  |  | 17.5 | % |
| Percentage of net revenues |  |  | 55.1 | % |  |  | 53.1 | % |  |  |  |  |  |  |  |  |

[0001564590-18-026529:mdna:97]
Product gross profit increased $9.4 million or 11.2% for the three months ended September 30, 2018 as compared to the corresponding period in fiscal 2018.   The increase was due to higher revenues and more favorable manufacturing costs due to our cost reduction efforts in addition to lower acquired inventory purchase accounting adjustments of $2.9 million incurred in the first fiscal quarter of 2018. Increases in product gross margin were partially offset by increased distribution costs of $3.3 million, amortization of developed technology intangibles of $2.3 million due to the acquisition of the Data Center Business, and warranty charges of $1.4 million.

[0001564590-18-026529:mdna:98]
Service gross profit increased $10.2 million or 37.0% for the three months ended September 30, 2018 as compared to the corresponding period in fiscal 2018, primarily due to a higher number of maintenance contracts related to the acquisition of the Data Center Business.

[0001564590-18-026529:mdna:99]
[same as prior period, unchanged from 0001564590-18-012675:mdna:54]

[0001564590-18-026529:mdna:100]
[same as prior period, unchanged from 0001564590-18-012675:mdna:55]

[0001564590-18-026529:mdna:101]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 51,241 |  |  | $ | 34,285 |  |  | $ | 16,956 |  |  |  | 49.5 | % |
| Sales and marketing |  |  | 67,582 |  |  |  | 55,561 |  |  |  | 12,021 |  |  |  | 21.6 | % |
| General and administrative |  |  | 12,771 |  |  |  | 12,185 |  |  |  | 586 |  |  |  | 4.8 | % |
| Acquisition and integration costs |  |  | 2,546 |  |  |  | 4,244 |  |  |  | (1,698 | ) |  |  | (40.0 | )% |
| Restructuring charges, net of reversals |  |  | 808 |  |  |  | — |  |  |  | 808 |  |  |  | — |  |
| Amortization of intangibles |  |  | 2,141 |  |  |  | 1,614 |  |  |  | 527 |  |  |  | 32.7 | % |
| Total operating expenses |  | $ | 137,089 |  |  | $ | 107,889 |  |  | $ | 29,200 |  |  |  | 27.1 | % |

[0001564590-18-026529:mdna:102]
[same as prior period, unchanged from 0001564590-18-012675:mdna:57]

[0001564590-18-026529:mdna:103]
[same as prior period, unchanged from 0001564590-18-012675:mdna:58]

[0001564590-18-026529:mdna:104]
Research and development expenses increased by $17.0 million or 49.5% for the three months ended September 30, 2018 as compared to the corresponding period of fiscal 2018.  The increase in research and development expenses was due to higher personnel costs of $7.3 million due to increased headcount related to the acquisition of the Data Center Business, $2.4 million in increased facility and information technology costs, $3.9 million in increased supplies and equipment costs and $3.0 million in increased contractor and professional fees.

[0001564590-18-026529:mdna:105]
[same as prior period, unchanged from 0001564590-18-012675:mdna:61]

[0001564590-18-026529:mdna:106]
[same as prior period, unchanged from 0001564590-18-012675:mdna:62]

[0001564590-18-026529:mdna:107]
Sales and marketing expenses increased by $12.0 million or 21.6% for the three months ended September 30, 2018 as compared to the corresponding period of fiscal 2018 primarily as a result of the acquisition of the Data Center Business.  The increase consisted of higher personnel costs of $10.1 million, $0.5 million in increased travel, marketing, meeting and conference costs, $0.4 million in increased facility and information technology costs and $1.0 million in increased software, supplies and equipment costs.

[0001564590-18-026529:mdna:108]
[same as prior period, unchanged from 0001564590-18-012675:mdna:65]

[0001564590-18-026529:mdna:109]
[same as prior period, unchanged from 0001564590-18-012675:mdna:66]

[0001564590-18-026529:mdna:110]
General and administrative expenses increased by $0.6 million or 4.8% for the three months ended September 30, 2018 as compared to the corresponding period of fiscal 2018 primarily due to $0.6 million in higher personnel costs and $0.4 million in higher facility and information technology costs, offset by $0.5 million in reduced professional fees.

[0001564590-18-026529:mdna:111]
Acquisition and Integration Costs

[0001564590-18-026529:mdna:112]
For the three months ended September 30, 2018, we incurred $2.5 million of integration costs related to the acquisitions of the Campus Fabric and Data Center Businesses.

[0001564590-18-026529:mdna:113]
For the three months ended September 30, 2017, we incurred $1.2 million of acquisition and $1.7 million of integration costs related to the acquisition of the Campus Fabric Business and $1.3 million of acquisition costs related to the future acquisition of the Data Center Business.

[0001564590-18-026529:mdna:114]
Restructuring Charges, Net of Reversals

[0001564590-18-026529:mdna:115]
For the three months ended September 30, 2018, we recorded restructuring charges of $0.8 million associated with a reduction-in-force in the fourth quarter of fiscal 2018.

[0001564590-18-026529:mdna:116]
[same as prior period, unchanged from 0001564590-18-012675:mdna:80]

[0001564590-18-026529:mdna:117]
During the three months ended September 30, 2018 and 2017, we recorded $2.1 million and $1.6 million, respectively, of amortization expense as operating expenses in the accompanying condensed consolidated statements of operations.  The increase was mainly due to additional amortization related to the acquired intangibles from the Data Center Business.

[0001564590-18-026529:mdna:118]
[same as prior period, unchanged from 0001564590-18-012675:mdna:83]

[0001564590-18-026529:mdna:119]
During the three months ended September 30, 2018 and 2017, we recorded $3.5 million and $2.2 million, respectively, in interest expense.  The increase in interest expense was due to the increased balance of our Credit Agreement and higher interest rates as compared to the corresponding period of fiscal 2018 as well as additional imputed interest charges associated with various long-term contracts.

[0001564590-18-026529:mdna:120]
[same as prior period, unchanged from 0001564590-18-012675:mdna:86]

[0001564590-18-026529:mdna:121]
During the three months ended September 30, 2018 and 2017, we recorded income of $0.5 million and $3.1 million, respectively, in other income (expense), net. The change was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-18-026529:mdna:122]
[same as prior period, unchanged from 0001564590-18-012675:mdna:89]

[0001564590-18-026529:mdna:123]
For the three months ended September 30, 2018 and 2017, we recorded an income tax provision of $1.4 million and $1.7 million, respectively, which consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys, the WLAN Business and the Campus Fabric Business.  The income tax provisions for the three months ended September 30, 2018 and 2017 were calculated based on actual results of operations three months ended September 30, 2018 and 2017and therefore may not reflect the annual effective tax rate.

[0001564590-18-026529:mdna:124]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, is effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, we were not subject to the majority of the tax law provisions until fiscal year 2019; however, there are certain significant items of impact that were recognized in fiscal year 2018. Because a change in tax law is accounted for in the period of enactment, the effects of the TCJA, a tax benefit of $2.5 million, have been reflected in the second quarter of fiscal 2018. See Note 10 to the condensed consolidated financial statements which includes a detailed discussion of the various provisions of the new U.S. tax legislation.

[0001564590-18-026529:mdna:125]
[same as prior period, unchanged from 0001564590-18-012675:mdna:93]

[0001564590-18-026529:mdna:126]
[same as prior period, unchanged from 0001564590-18-012675:mdna:94]

[0001564590-18-026529:mdna:127]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2018, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-18-026529:mdna:128]
[same as prior period, unchanged from 0001564590-18-012675:mdna:96]

[0001564590-18-026529:mdna:129]
[same as prior period, unchanged from 0001564590-18-012675:mdna:99]

[0001564590-18-026529:mdna:130]
|  | • | Inventory Valuation and Purchase Commitments |

[0001564590-18-026529:mdna:131]
The have been no changes to our critical accounting policies since the filing of our last Annual Report on Form 10-K.

[0001564590-18-026529:mdna:132]
[same as prior period, unchanged from 0001564590-18-012675:mdna:111]

[0001564590-18-026529:mdna:133]
See Note 3 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-18-026529:mdna:134]
[same as prior period, unchanged from 0001564590-18-012675:mdna:113]

[0001564590-18-026529:mdna:135]
[same as prior period, unchanged from 0001564590-18-012675:mdna:114]

[0001564590-18-026529:mdna:136]
|  |  | September 30, 2018 |  |  | June 30, 2018 |  |
| Cash and cash equivalents |  | $ | 140,167 |  |  | $ | 121,139 |  |
| Marketable securities |  |  | 887 |  |  |  | 1,459 |  |
| Total cash, cash equivalent and marketable securities |  | $ | 141,054 |  |  | $ | 122,598 |  |
| Working capital |  | $ | 73,761 |  |  | $ | 68,041 |  |

[0001564590-18-026529:mdna:137]
As of September 30, 2018, our principal sources of liquidity consisted of cash, cash equivalents and marketable securities of $141.1 million, accounts receivable, net of $164.7 million and availability of borrowings from our five-year New Revolving Facility of $39.1 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development, marketing of our products, purchases of property and equipment and include repayments of debt and related interest. We believe that our $141.1 million of cash, cash equivalents and marketable securities at September 30, 2018 and the availability of borrowings from the New Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-18-026529:mdna:138]
On November 2, 2018, the Company announced that its Board of Directors has authorized the Company to repurchase up to $60.0 million of its common stock over the next two years. Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any purchases will be determined by the Company's management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations.

[0001564590-18-026529:mdna:139]
On May 1, 2018, the Company entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”), ii) a $190 million five-year term loan (the “New Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement.

[0001564590-18-026529:mdna:140]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s consolidated leverage ratio. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting September 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The obligations under the Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-18-026529:mdna:141]
Financial covenants under the Credit Agreement require the Company to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets.  The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.  At September 30, 2018, we were in compliance with the covenants of the Credit Agreement.

[0001564590-18-026529:mdna:142]
[same as prior period, unchanged from 0001564590-18-012675:mdna:124]

[0001564590-18-026529:mdna:143]
[same as prior period, unchanged from 0001564590-18-012675:mdna:125]

[0001564590-18-026529:mdna:144]
|  |  | Three Months Ended |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Net cash provided by operating activities |  | $ | 34,330 |  |  | $ | 18,598 |  |
| Net cash used in investing activities |  |  | (6,690 | ) |  |  | (70,546 | ) |
| Net cash (used in) provided by financing activities |  |  | (8,179 | ) |  |  | 74,455 |  |
| Foreign currency effect on cash |  |  | (433 | ) |  |  | 57 |  |
| Net increase in cash and cash equivalents |  | $ | 19,028 |  |  | $ | 22,564 |  |

[0001564590-18-026529:mdna:145]
Net Cash Provided by Operating Activities

[0001564590-18-026529:mdna:146]
Cash flows provided by operations in the three months ended September 30, 2018 were $34.3 million, including our net loss of $9.1 million and non-cash expenses of $21.8 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes and imputed interest.  Other sources of cash for the current quarter included a decrease in accounts receivables and inventories and increases in deferred revenues and other current and long-term liabilities. This was partially offset by decreases in accounts payable and accrued compensation.

[0001564590-18-026529:mdna:147]
Cash flows provided by operations in the three months ended September 30, 2017 were $18.6 million, including net income of $4.4 million and non-cash expenses of $10.4 million for items such as amortization of intangibles, stock-based compensation expense, depreciation and gain on sale of non-marketable equity investment as well as a decrease in inventory and increases in accounts and deferred revenue.  This was partially offset by an increase in accounts receivable and decreases in accrued compensation and current and noncurrent liabilities.

[0001564590-18-026529:mdna:148]
[same as prior period, unchanged from 0001564590-18-012675:mdna:130]

[0001564590-18-026529:mdna:149]
Cash flows used in investing activities in the three months ended September 30, 2018 were $6.7 million which consisted of purchases of property and equipment of $7.4 million and proceeds of $0.7 million related to the sale of marketable equity securities.

[0001564590-18-026529:mdna:150]
Cash flows used in investing activities in the three months ended September 30, 2017, were $70.5 million.  For the three months ended September 30, 2017, cash flows consisted of expenditures for acquisitions of $68.0 million consisting of $69.6 million for the Campus Fabric Business acquisition less receipt of $1.6 million as final settlement of a working capital adjustment related to the WLAN Business acquisition, $7.4 million of purchases of property and equipment and proceeds of $4.9 million related to the sale of non-marketable equity investment.

[0001564590-18-026529:mdna:151]
Net Cash (Used in) Provided by Financing Activities

[0001564590-18-026529:mdna:152]
Cash flows used in financing activities in the three months ended September 30, 2018 were $8.2 million, due to repayments of debt totaling $12.4 million and $1.6 million of contingent consideration and $1.0 million for deferred payments on acquisitions.  This was partially offset by $7.1 million proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”), the exercise of stock options and net of taxes paid on vested and released stock awards,

[0001564590-18-026529:mdna:153]
Cash flows provided by financing activities in the three months ended September 30, 2017 were $74.5 million, including new borrowings of $80.0 million to fund our acquisition of the Campus Fabric Business, $4.9 million proceeds from issuance of shares of our common stock under our ESPP and the exercise of stock options less $4.8 million of taxes paid on vested and released stock awards, partially offset by repayment of debt totaling $4.1 million and $1.5 million of loan fees incurred in connection with the Second Amendment of our Credit Facility.

[0001564590-18-026529:mdna:154]
[same as prior period, unchanged from 0001564590-18-012675:mdna:136]

[0001564590-18-026529:mdna:155]
Foreign currency effect on cash increased in the three months ended September 30, 2018, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-18-026529:mdna:156]
[same as prior period, unchanged from 0001564590-18-012675:mdna:138]

[0001564590-18-026529:mdna:157]
The following summarizes our contractual obligations as of September 30, 2018, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-18-026529:mdna:158]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 187,625 |  |  | $ | 9,500 |  |  | $ | 24,938 |  |  | $ | 153,187 |  |
| Interest on debt obligations |  |  | 31,638 |  |  |  | 8,537 |  |  |  | 15,614 |  |  |  | 7,487 |  |
| Non-cancellable inventory purchase commitments |  |  | 158,697 |  |  |  | 158,697 |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 117,500 |  |  |  | 29,375 |  |  |  | 47,000 |  |  |  | 41,125 |  |
| Non-cancellable operating lease obligations |  |  | 99,856 |  |  |  | 19,611 |  |  |  | 34,759 |  |  |  | 45,486 |  |
| Deferred payments for an acquisition |  |  | 18,000 |  |  |  | 5,000 |  |  |  | 8,000 |  |  |  | 5,000 |  |
| Contingent consideration for an acquisition |  |  | 11,233 |  |  |  | 6,592 |  |  |  | 4,218 |  |  |  | 423 |  |
| Other liabilities |  |  | 518 |  |  |  | 136 |  |  |  | 273 |  |  |  | 109 |  |
| Total contractual cash obligations |  | $ | 625,067 |  |  | $ | 237,448 |  |  | $ | 134,802 |  |  | $ | 252,817 |  |

[0001564590-18-026529:mdna:159]
The contractual obligations referenced above are more fully defined as follows:

[0001564590-18-026529:mdna:160]
Debt obligations relate to amounts owed under our Credit Agreement.

[0001564590-18-026529:mdna:161]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-18-026529:mdna:162]
Non-cancellable contractual commitments to suppliers for future services.

[0001564590-18-026529:mdna:163]
[same as prior period, unchanged from 0001564590-18-012675:mdna:143]

[0001564590-18-026529:mdna:164]
Deferred payments for the acquisition of the Data Center Business represent a $1.0 million per quarter.

[0001564590-18-026529:mdna:165]
Contingent consideration for the Capital Financing Business acquisition, at fair value.  Actual payments could be different.

[0001564590-18-026529:mdna:166]
[same as prior period, unchanged from 0001564590-18-012675:mdna:146]

[0001564590-18-026529:mdna:167]
[same as prior period, unchanged from 0001564590-18-012675:mdna:147]

[0001564590-18-026529:mdna:168]
We did not have any material commitments for capital expenditures as of September 30, 2018.

[0001564590-18-026529:mdna:169]
[same as prior period, unchanged from 0001564590-18-012675:mdna:149]

[0001564590-18-026529:mdna:170]
We did not have any off-balance sheet arrangements as of September 30, 2018.
