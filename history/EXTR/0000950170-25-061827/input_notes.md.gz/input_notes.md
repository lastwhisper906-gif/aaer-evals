# EXTR notes — 0000950170-25-061827


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-25-061827:notes:1]
[same as prior period, unchanged from 0000950170-25-011087:notes:1]

[0000950170-25-061827:notes:2]
[same as prior period, unchanged from 0000950170-25-011087:notes:2]

[0000950170-25-061827:notes:3]
[same as prior period, unchanged from 0000950170-25-011087:notes:3]

[0000950170-25-061827:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2025. The results of operations for the three and nine months ended March 31, 2025 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.

[0000950170-25-061827:notes:5]
[same as prior period, unchanged from 0000950170-25-011087:notes:5]

[0000950170-25-061827:notes:6]
[same as prior period, unchanged from 0000950170-25-011087:notes:6]

[0000950170-25-061827:notes:7]
[same as prior period, unchanged from 0000950170-25-011087:notes:7]

[0000950170-25-061827:notes:8]
[same as prior period, unchanged from 0000950170-25-011087:notes:8]

[0000950170-25-061827:notes:9]
[same as prior period, unchanged from 0000950170-25-011087:notes:9]

[0000950170-25-061827:notes:10]
[same as prior period, unchanged from 0000950170-25-011087:notes:10]

[0000950170-25-061827:notes:11]
[same as prior period, unchanged from 0000950170-25-011087:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-25-061827:notes:12]
[same as prior period, unchanged from 0000950170-25-011087:notes:12]

[0000950170-25-061827:notes:13]
[same as prior period, unchanged from 0000950170-25-011087:notes:13]

[0000950170-25-061827:notes:14]
Recently Adopted Accounting Pronouncements

[0000950170-25-061827:notes:15]
There were no recently adopted accounting standards which would have a material effect on the Company's condensed consolidated financial statements and accompanying disclosures.

[0000950170-25-061827:notes:16]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000950170-25-061827:notes:17]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses to improve disclosures about public business entities’ expenses and to provide more detailed information around the types of expenses included in commonly presented expense captions. Additionally, in January 2025 the FASB issued ASU 2025-01 to clarify the effective date of ASU 2024-03. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, and interim periods for fiscal years beginning after December 15, 2027, and can be applied on a prospective basis or on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2024-03 and ASU 2025-01 on its consolidated financial statements and related disclosures.

[0000950170-25-061827:notes:18]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.

[0000950170-25-061827:notes:19]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-25-061827:notes:20]
[same as prior period, unchanged from 0000950170-25-011087:notes:20]

[0000950170-25-061827:notes:21]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts to customers and partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell primarily to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0000950170-25-061827:notes:22]
[same as prior period, unchanged from 0000950170-25-011087:notes:22]

[0000950170-25-061827:notes:23]
[same as prior period, unchanged from 0000950170-25-011087:notes:23]

[0000950170-25-061827:notes:24]
[same as prior period, unchanged from 0000950170-25-011087:notes:24]

[0000950170-25-061827:notes:25]
As of March 31, 2025, the Company had $588.7 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 17% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 42% in fiscal 2026, and the remaining 41% of the balance thereafter.

[0000950170-25-061827:notes:26]
[same as prior period, unchanged from 0000950170-25-011087:notes:26]

[0000950170-25-061827:notes:27]
Revenue recognized for the three months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $96.9 million and $95.9 million, respectively. Revenue recognized for the nine months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $245.5 million and $230.8 million, respectively.

[0000950170-25-061827:notes:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $25.6 million and $24.7 as of March 31, 2025 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2025 and 2024 was $3.2 million and $2.8 million, respectively. Amortization recognized during the nine months ended March 31, 2025 and 2024 was $9.3 million and $8.0 million, respectively.

[0000950170-25-061827:notes:29]
[same as prior period, unchanged from 0000950170-25-011087:notes:29]

[0000950170-25-061827:notes:30]
[same as prior period, unchanged from 0000950170-25-011087:notes:30]

[0000950170-25-061827:notes:31]
[same as prior period, unchanged from 0000950170-25-011087:notes:31]

[0000950170-25-061827:notes:32]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 145,426 |  |  | $ | 124,082 |  |  |  | 418,356 |  |  | $ | 456,383 |  |
| Other |  |  | 14,126 |  |  |  | 10,291 |  |  |  | 38,018 |  |  |  | 36,274 |  |
| Total Americas |  |  | 159,552 |  |  |  | 134,373 |  |  |  | 456,374 |  |  |  | 492,657 |  |
| EMEA |  |  | 107,132 |  |  |  | 59,035 |  |  |  | 320,307 |  |  |  | 313,243 |  |
| APAC |  |  | 17,821 |  |  |  | 17,628 |  |  |  | 56,383 |  |  |  | 54,650 |  |
| Total net revenues |  | $ | 284,505 |  |  | $ | 211,036 |  |  | $ | 833,064 |  |  | $ | 860,550 |  |

[0000950170-25-061827:notes:33]
[same as prior period, unchanged from 0000950170-25-011087:notes:33]

[0000950170-25-061827:notes:34]
For the three and nine months ended March 31, 2025, the Company generated 10% and 11% of its net revenues respectively from the Netherlands. For the nine months ended March 31, 2024, the Company generated 10% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and nine months ended March 31, 2025 and 2024.

[0000950170-25-061827:notes:35]
[same as prior period, unchanged from 0000950170-25-011087:notes:35]

[0000950170-25-061827:notes:36]
[same as prior period, unchanged from 0000950170-25-011087:notes:36]

[0000950170-25-061827:notes:37]
[same as prior period, unchanged from 0000950170-25-011087:notes:37]

[0000950170-25-061827:notes:38]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2025 |  | March 31,2024 |  | March 31,2025 |  | March 31,2024 |
| Jenne, Inc. |  | 21% |  | 12% |  | 19% |  | 22% |
| TD Synnex Corporation |  | 18% |  | 22% |  | 19% |  | 21% |
| Westcon Group, Inc. |  | 16% |  | 13% |  | 17% |  | 17% |
| ScanSource, Inc. |  | * |  | 11% |  | * |  | * |
| * Less than 10% of net revenue |  |  |  |  |  |  |  |  |

[0000950170-25-061827:notes:39]
[same as prior period, unchanged from 0000950170-25-011087:notes:39]

[0000950170-25-061827:notes:40]
|  |  | March 31,2025 |  | June 30,2024 |
| Jenne, Inc. |  | 33% |  | 64% |
| TD Synnex Corporation |  | 13% |  | * |
| ScanSource, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-25-061827:notes:41]
[same as prior period, unchanged from 0000950170-25-011087:notes:41]

[0000950170-25-061827:notes:42]
[same as prior period, unchanged from 0000950170-25-011087:notes:42]

[0000950170-25-061827:notes:43]
[same as prior period, unchanged from 0000950170-25-011087:notes:43]

[0000950170-25-061827:notes:44]
[same as prior period, unchanged from 0000950170-25-011087:notes:44]

[0000950170-25-061827:notes:45]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Cash |  | $ | 179,483 |  |  | $ | 153,483 |  |
| Cash equivalents |  |  | 5,997 |  |  |  | 3,216 |  |
| Total cash and cash equivalents |  | $ | 185,480 |  |  | $ | 156,699 |  |

[0000950170-25-061827:notes:46]
[same as prior period, unchanged from 0000950170-25-011087:notes:46]

[0000950170-25-061827:notes:47]
[same as prior period, unchanged from 0000950170-25-011087:notes:47]

[0000950170-25-061827:notes:48]
[same as prior period, unchanged from 0000950170-25-011087:notes:48]

[0000950170-25-061827:notes:49]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Finished goods |  | $ | 69,342 |  |  | $ | 115,813 |  |
| Raw materials |  |  | 46,396 |  |  |  | 25,219 |  |
| Total inventories |  | $ | 115,738 |  |  | $ | 141,032 |  |

[0000950170-25-061827:notes:50]
[same as prior period, unchanged from 0000950170-25-011087:notes:50]

[0000950170-25-061827:notes:51]
[same as prior period, unchanged from 0000950170-25-011087:notes:51]

[0000950170-25-061827:notes:52]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Computers and equipment |  | $ | 75,842 |  |  | $ | 77,224 |  |
| Software |  |  | 58,973 |  |  |  | 60,717 |  |
| Office equipment, furniture and fixtures |  |  | 8,111 |  |  |  | 8,134 |  |
| Leasehold improvements |  |  | 48,697 |  |  |  | 47,880 |  |
| Total property and equipment |  |  | 191,623 |  |  |  | 193,955 |  |
| Less: accumulated depreciation and amortization |  |  | (152,102 | ) |  |  | (150,211 | ) |
| Property and equipment, net |  | $ | 39,521 |  |  | $ | 43,744 |  |

[0000950170-25-061827:notes:53]
[same as prior period, unchanged from 0000950170-25-011087:notes:53]

[0000950170-25-061827:notes:54]
[same as prior period, unchanged from 0000950170-25-011087:notes:54]

[0000950170-25-061827:notes:55]
[same as prior period, unchanged from 0000950170-25-011087:notes:55]

[0000950170-25-061827:notes:56]
[same as prior period, unchanged from 0000950170-25-011087:notes:56]

[0000950170-25-061827:notes:57]
[same as prior period, unchanged from 0000950170-25-011087:notes:57]

[0000950170-25-061827:notes:58]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Balance at beginning of period |  | $ | 10,036 |  |  | $ | 11,397 |  |  | $ | 10,942 |  |  | $ | 12,322 |  |
| New warranties issued |  |  | 2,855 |  |  |  | 3,312 |  |  |  | 8,387 |  |  |  | 9,763 |  |
| Warranty expenditures |  |  | (3,418 | ) |  |  | (3,642 | ) |  |  | (9,856 | ) |  |  | (11,018 | ) |
| Balance at end of period |  | $ | 9,473 |  |  | $ | 11,067 |  |  | $ | 9,473 |  |  | $ | 11,067 |  |

[0000950170-25-061827:notes:59]
[same as prior period, unchanged from 0000950170-25-011087:notes:59]

[0000950170-25-061827:notes:60]
[same as prior period, unchanged from 0000950170-25-011087:notes:60]

[0000950170-25-061827:notes:61]
[same as prior period, unchanged from 0000950170-25-011087:notes:61]


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-25-061827:notes:62]
[same as prior period, unchanged from 0000950170-25-011087:notes:62]

[0000950170-25-061827:notes:63]
[same as prior period, unchanged from 0000950170-25-011087:notes:63]

[0000950170-25-061827:notes:64]
[same as prior period, unchanged from 0000950170-25-011087:notes:64]

[0000950170-25-061827:notes:65]
[same as prior period, unchanged from 0000950170-25-011087:notes:65]

[0000950170-25-061827:notes:66]
[same as prior period, unchanged from 0000950170-25-011087:notes:66]

[0000950170-25-061827:notes:67]
[same as prior period, unchanged from 0000950170-25-011087:notes:67]

[0000950170-25-061827:notes:68]
| March 31, 2025 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 5,997 |  |  | $ | — |  |  | $ | 5,997 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 101 |  |  |  | — |  |  |  | 101 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 6,098 |  |  | $ | — |  |  | $ | 6,098 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 70 |  |  | $ | — |  |  | $ | 70 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 70 |  |  | $ | — |  |  | $ | 70 |  |

[0000950170-25-061827:notes:69]
[same as prior period, unchanged from 0000950170-25-011087:notes:69]

[0000950170-25-061827:notes:70]
[same as prior period, unchanged from 0000950170-25-011087:notes:70]

[0000950170-25-061827:notes:71]
[same as prior period, unchanged from 0000950170-25-011087:notes:71]

[0000950170-25-061827:notes:72]
As of March 31, 2025 and June 30, 2024, the Company had investment in certificates of deposit of $6.0 million and $3.2 million, respectively, with maturity of three months at the date of purchase, which are recorded as cash equivalents in the condensed consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of March 31, 2025 and June 30, 2024, their fair value approximated their amortized cost.

[0000950170-25-061827:notes:73]
As of March 31, 2025 and June 30, 2024, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $52.2 million and $31.3 million, respectively. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in “Other income (expense), net” in the condensed consolidated statements of operations. For the three months ended March 31, 2025 and 2024, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net gains of $0.6 million and net losses of $0.3 million, respectively. For the nine months ended March 31, 2025 and 2024, the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $0.7 million and net losses of less than $0.1 million, respectively. As of March 31, 2025 and June 30, 2024, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 12, Derivatives and Hedging, for additional information.

[0000950170-25-061827:notes:74]
The fair value of borrowings under the Amended Credit Agreement (as defined in Note 7) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the Amended Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $182.5 million and $190.0 million as of March 31, 2025 and June 30, 2024, respectively.

[0000950170-25-061827:notes:75]
[same as prior period, unchanged from 0000950170-25-011087:notes:75]

[0000950170-25-061827:notes:76]
As of March 31, 2025 and June 30, 2024, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2, or Level 3 during the three and nine months ended March 31, 2025 and 2024. There were no impairments recorded for the three and nine months ended March 31, 2025 and 2024.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-25-061827:notes:77]
[same as prior period, unchanged from 0000950170-25-011087:notes:77]

[0000950170-25-061827:notes:78]
[same as prior period, unchanged from 0000950170-25-011087:notes:78]

[0000950170-25-061827:notes:79]
[same as prior period, unchanged from 0000950170-25-011087:notes:79]

[0000950170-25-061827:notes:80]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2025 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.8 years |  | $ | 169,389 |  |  | $ | 164,571 |  |  | $ | 4,818 |  |
| Customer relationships |  | 1.3 years |  |  | 64,688 |  |  |  | 62,318 |  |  |  | 2,370 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 1.7 years |  |  | 1,282 |  |  |  | 1,158 |  |  |  | 124 |  |
| Total intangible assets, net* |  |  |  | $ | 246,059 |  |  | $ | 238,747 |  |  | $ | 7,312 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-25-061827:notes:81]
[same as prior period, unchanged from 0000950170-25-011087:notes:81]

[0000950170-25-061827:notes:82]
[same as prior period, unchanged from 0000950170-25-011087:notes:82]

[0000950170-25-061827:notes:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 598 |  |  | $ | 616 |  |  | $ | 1,828 |  |  | $ | 2,661 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 507 |  |  |  | 511 |  |  |  | 1,528 |  |  |  | 1,531 |  |
| Total amortization expense |  | $ | 1,105 |  |  | $ | 1,127 |  |  | $ | 3,356 |  |  | $ | 4,192 |  |

[0000950170-25-061827:notes:84]
[same as prior period, unchanged from 0000950170-25-011087:notes:84]

[0000950170-25-061827:notes:85]
[same as prior period, unchanged from 0000950170-25-011087:notes:85]

[0000950170-25-061827:notes:86]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2025 (the remainder of fiscal 2025) |  | $ | 1,120 |  |
| 2026 |  |  | 3,211 |  |
| 2027 |  |  | 1,438 |  |
| 2028 |  |  | 1,277 |  |
| 2029 |  |  | 266 |  |
| Total |  | $ | 7,312 |  |

[0000950170-25-061827:notes:87]
[same as prior period, unchanged from 0000950170-25-011087:notes:87]

[0000950170-25-061827:notes:88]
The Company had goodwill in the amount of $394.4 million and $393.7 million as of March 31, 2025 and June 30, 2024, respectively. The change in goodwill during the nine months ended March 31, 2025 is due to foreign currency translation adjustments that are recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0000950170-25-061827:notes:89]
7.
Debt

[0000950170-25-061827:notes:90]
The Company’s debt is comprised of the following (in thousands):

[0000950170-25-061827:notes:91]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 13,750 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (741 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 13,009 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 168,750 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,456 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 167,294 |  |  |  | 178,265 |  |
| Total debt |  | $ | 180,303 |  |  | $ | 187,591 |  |

[0000950170-25-061827:notes:92]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-25-061827:notes:93]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association, and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million.

[0000950170-25-061827:notes:94]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-25-061827:notes:95]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-25-061827:notes:96]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024.

[0000950170-25-061827:notes:97]
As of March 31, 2025, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

[0000950170-25-061827:notes:98]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each period during the three months ended March 31, 2025 and 2024, and was $0.9 million and $0.8 million for the nine months ended March 31, 2025 and 2024, respectively. The interest rate was 6.41% and 7.44% as of March 31, 2025 and 2024, respectively.

[0000950170-25-061827:notes:99]
As of March 31, 2025, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of March 31, 2025. During the three and nine months ended March 31, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

[0000950170-25-061827:notes:100]
The Company had $14.2 million of outstanding letters of credit as of March 31, 2025.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-25-061827:notes:101]
8.
Commitments and Contingencies

[0000950170-25-061827:notes:102]
Purchase Commitments

[0000950170-25-061827:notes:103]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2025, the Company had commitments to purchase $36.0 million of inventory.

[0000950170-25-061827:notes:104]
Legal Proceedings

[0000950170-25-061827:notes:105]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships, or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-25-061827:notes:106]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year. As of March 31, 2025, the total estimated litigation expense accrual included in the “Other accrued liabilities” in the condensed consolidated balance sheets was $28.5 million for various ongoing litigation matters with probable losses that can be reasonably estimated.

[0000950170-25-061827:notes:107]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-25-061827:notes:108]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On January 3, 2025, both parties filed motions for summary judgment seeking to resolve various claims in the case. Those motions are currently pending before the Court. The trial is set for August 5, 2025.

[0000950170-25-061827:notes:109]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-25-061827:notes:110]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal. On December 9, 2024, the Higher Regional Court stayed the matter until the nullity action has been finally decided.

[0000950170-25-061827:notes:111]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. Mala appealed the decision on March 3, 2025, and the Company will defend the appeal.

[0000950170-25-061827:notes:112]
Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al.

[0000950170-25-061827:notes:113]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Firefighters Pension and Retirement System, Oklahoma Police Pension and Retirement System, Oakland County Voluntary Employees’ Beneficiary Association, Oakland County Employees’ Retirement System as the lead plaintiffs. The Company filed a Motion to Dismiss the amended complaint on April 15, 2025. Trial has been scheduled for March 29, 2027.

[0000950170-25-061827:notes:114]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these cases (collectively, the “Derivative Cases”) names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. The plaintiffs in the Derivative Cases have agreed in principle to stay the matters pending resolution of the Class Action.

[0000950170-25-061827:notes:115]
Indemnification Obligations

[0000950170-25-061827:notes:116]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers, and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-25-061827:notes:117]
[same as prior period, unchanged from 0000950170-25-011087:notes:122]

[0000950170-25-061827:notes:118]
[same as prior period, unchanged from 0000950170-25-011087:notes:123]

[0000950170-25-061827:notes:119]
[same as prior period, unchanged from 0000950170-25-011087:notes:124]

[0000950170-25-061827:notes:120]
[same as prior period, unchanged from 0000950170-25-011087:notes:125]

[0000950170-25-061827:notes:121]
On May 18, 2022, the Company announced that the Board had authorized management to repurchase up to $200.0 million shares of the Company’s common stock over a three-year period commencing July 1, 2022 (as amended, the “2022 Repurchase Program”). Under the 2022 Repurchase Program, a maximum of $25.0 million of shares was authorized to be repurchased in any quarter. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The 2022 Repurchase Program expires on June 30, 2025. On February 18, 2025, the Company announced that the Board had authorized management to repurchase up to $200.0 million shares of the Company's common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”).

[0000950170-25-061827:notes:122]
During the three and nine months ended March 31, 2025 the Company repurchased a total of 853,247 shares of its common stock on the open market at a total cost of $13.0 million with an average price of $15.24 per share. During the three months ended March 31, 2024, the Company did not repurchase any shares of its common stock. During the nine months ended March 31, 2024, the Company repurchased a total of 2,365,220 shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. As of March 31, 2025, approximately $37.3 million remains available for share repurchases under the 2022 Repurchase Program.

[0000950170-25-061827:notes:123]
[same as prior period, unchanged from 0000950170-25-011087:notes:128]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-25-061827:notes:124]
[same as prior period, unchanged from 0000950170-25-011087:notes:129]

[0000950170-25-061827:notes:125]
[same as prior period, unchanged from 0000950170-25-011087:notes:130]

[0000950170-25-061827:notes:126]
[same as prior period, unchanged from 0000950170-25-011087:notes:131]

[0000950170-25-061827:notes:127]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 10,820 |  |  |  | 13,414 |  |
| Employee stock options and awards outstanding |  |  | 8,164 |  |  |  | 7,562 |  |
| 2014 Employee Stock Purchase Plan |  |  | 5,952 |  |  |  | 7,130 |  |
| Total shares reserved for issuance |  |  | 24,936 |  |  |  | 28,106 |  |

[0000950170-25-061827:notes:128]
[same as prior period, unchanged from 0000950170-25-011087:notes:133]

[0000950170-25-061827:notes:129]
[same as prior period, unchanged from 0000950170-25-011087:notes:134]

[0000950170-25-061827:notes:130]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Cost of product revenues |  | $ | 663 |  |  | $ | 405 |  |  | $ | 1,961 |  |  | $ | 1,352 |  |
| Cost of subscription and support revenues |  |  | 706 |  |  |  | 679 |  |  |  | 2,193 |  |  |  | 2,294 |  |
| Research and development |  |  | 4,178 |  |  |  | 4,226 |  |  |  | 12,858 |  |  |  | 13,038 |  |
| Sales and marketing |  |  | 6,963 |  |  |  | 5,683 |  |  |  | 21,441 |  |  |  | 20,206 |  |
| General and administrative |  |  | 7,844 |  |  |  | 6,840 |  |  |  | 23,120 |  |  |  | 21,819 |  |
| Total share-based compensation expense |  | $ | 20,354 |  |  | $ | 17,833 |  |  | $ | 61,573 |  |  | $ | 58,709 |  |

[0000950170-25-061827:notes:131]
[same as prior period, unchanged from 0000950170-25-011087:notes:136]

[0000950170-25-061827:notes:132]
The following table summarizes stock option activity for the nine months ended March 31, 2025 (in thousands, except per share amount and contractual term):

[0000950170-25-061827:notes:133]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 1.75 |  |  | $ | 7,376 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (398 | ) |  |  | 6.43 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2025 |  |  | 675 |  |  | $ | 6.67 |  |  |  | 1.30 |  |  | $ | 4,429 |  |
| Vested and expected to vest at March 31, 2025 |  |  | 675 |  |  | $ | 6.67 |  |  |  | 1.30 |  |  | $ | 4,429 |  |
| Exercisable at March 31, 2025 |  |  | 675 |  |  | $ | 6.67 |  |  |  | 1.30 |  |  | $ | 4,429 |  |

[0000950170-25-061827:notes:134]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock options granted during the three and nine months ended March 31, 2025 and 2024.

[0000950170-25-061827:notes:135]
[same as prior period, unchanged from 0000950170-25-011087:notes:141]

[0000950170-25-061827:notes:136]
[same as prior period, unchanged from 0000950170-25-011087:notes:142]

[0000950170-25-061827:notes:137]
The following table summarizes stock award activity for the nine months ended March 31, 2025 (in thousands, except grant date fair value):

[0000950170-25-061827:notes:138]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2024 |  |  | 6,489 |  |  | $ | 22.65 |  |  |  |  |
| Granted |  |  | 4,641 |  |  |  | 15.83 |  |  |  |  |
| Released |  |  | (3,264 | ) |  |  | 20.15 |  |  |  |  |
| Canceled |  |  | (377 | ) |  |  | 21.01 |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2025 |  |  | 7,489 |  |  | $ | 19.62 |  |  | $ | 99,082 |  |
| Stock awards expected to vest at March 31, 2025 |  |  | 7,489 |  |  | $ | 19.62 |  |  | $ | 99,082 |  |

[0000950170-25-061827:notes:139]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the nine months ended March 31, 2025 included 1.3 million RSUs including the market condition awards discussed below to the named executive officers and outside directors.

[0000950170-25-061827:notes:140]
[same as prior period, unchanged from 0000950170-25-011087:notes:146]

[0000950170-25-061827:notes:141]
During the nine months ended March 31, 2025 and 2024, the Compensation Committee of the Board granted 1.0 million and 0.8 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s employees. The MSUs granted during the nine months ended March 31, 2025 were subject to total stockholder return (“TSR”). The MSUs granted during the nine months ended March 31, 2024 included 0.5 million MSUs subject to TSR and 0.3 million MSUs subject to certain stock price targets.

[0000950170-25-061827:notes:142]
[same as prior period, unchanged from 0000950170-25-011087:notes:148]

[0000950170-25-061827:notes:143]
[same as prior period, unchanged from 0000950170-25-011087:notes:149]

[0000950170-25-061827:notes:144]
[same as prior period, unchanged from 0000950170-25-011087:notes:150]

[0000950170-25-061827:notes:145]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during the nine months ended March 31, 2025 was $17.10 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 48%, risk-free interest rate of 3.87%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The weighted-average grant-date fair value of the TSR MSUs granted during the nine months ended March 31, 2024 was $32.66 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free interest rate of 4.43%, no expected dividend yield, expected term of three years, and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-25-061827:notes:146]
[same as prior period, unchanged from 0000950170-25-011087:notes:152]

[0000950170-25-061827:notes:147]
The grant date fair value of these stock price target MSUs was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of these stock price target MSUs granted during the nine months ended March 31, 2024 was $28.80 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 63%, risk-free interest rate of 4.45%, no expected dividend yield and expected term of three years based on possible future stock prices over the performance period based on the historical stock prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-25-061827:notes:148]
[same as prior period, unchanged from 0000950170-25-011087:notes:154]

[0000950170-25-061827:notes:149]
[same as prior period, unchanged from 0000950170-25-011087:notes:155]

[0000950170-25-061827:notes:150]
[same as prior period, unchanged from 0000950170-25-011087:notes:156]

[0000950170-25-061827:notes:151]
There were 0.7 and 0.8 million shares issued under the ESPP during the three months ended March 31, 2025 and 2024, respectively. There were 1.2 million and 1.3 million shares issued under the ESPP during the nine months ended March 31, 2025 and 2024, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0000950170-25-061827:notes:152]
|  |  | Employee Stock Purchase Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 4.32 | % |  |  | 5.31 | % |  |  | 4.73 | % |  |  | 5.42 | % |
| Volatility |  |  | 39 | % |  |  | 52 | % |  |  | 37 | % |  |  | 47 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0000950170-25-061827:notes:153]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended March 31, 2025 and 2024 was $4.32 and $3.68 per share, respectively. The weighted-average grant-date fair value of shares under the ESPP during the nine months ended March 31, 2025 and 2024 was $3.99 and $5.73 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-25-061827:notes:154]
[same as prior period, unchanged from 0000950170-25-011087:notes:160]

[0000950170-25-061827:notes:155]
[same as prior period, unchanged from 0000950170-25-011087:notes:161]

[0000950170-25-061827:notes:156]
[same as prior period, unchanged from 0000950170-25-011087:notes:162]

[0000950170-25-061827:notes:157]
[same as prior period, unchanged from 0000950170-25-011087:notes:163]

[0000950170-25-061827:notes:158]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Americas |  | $ | 151,545 |  |  | $ | 136,745 |  |
| EMEA |  |  | 40,408 |  |  |  | 33,715 |  |
| APAC |  |  | 10,144 |  |  |  | 11,499 |  |
| Total long-lived assets |  | $ | 202,097 |  |  | $ | 181,959 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-25-061827:notes:159]
[same as prior period, unchanged from 0000950170-25-011087:notes:165]

[0000950170-25-061827:notes:160]
[same as prior period, unchanged from 0000950170-25-011087:notes:166]

[0000950170-25-061827:notes:161]
The Company uses derivative financial instruments to manage exposures to foreign currency risk that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize

[0000950170-25-061827:notes:162]
the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts to attempt to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies.

[0000950170-25-061827:notes:163]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations. As of March 31, 2025 and June 30, 2024, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amount of $52.2 million and $31.3 million, respectively. During the three months ended March 31, 2025 and 2024, the net gains and losses recorded in the condensed consolidated statement of operations from these contracts were net gains of $0.6 million and net losses of $0.3 million, respectively. During the nine months ended March 31, 2025 and 2024 the net gains and losses recorded in the condensed consolidated statement of operations were net losses of $0.7 million and net losses of less than $0.1 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0000950170-25-061827:notes:164]
There were no foreign exchange forward contracts that were designated as hedging instruments as of March 31, 2025 or June 30, 2024.
For the three months ended March 31, 2025 and 2024, the Company recognized foreign currency transaction net losses of $0.9 million and foreign currency transaction net gains of $0.7 million, respectively, and for the nine months ended March 31, 2025 and 2024, the Company recognized foreign currency transaction net gains of $0.5 million and $0.4 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-25-061827:notes:165]
[same as prior period, unchanged from 0000950170-25-011087:notes:170]

[0000950170-25-061827:notes:166]
The Company recorded restructuring benefit of $0.4 million and restructuring and related charges of $14.4 million during the three months ended March 31, 2025 and 2024, respectively. The Company recorded $1.9 million and $26.3 million of restructuring and related charges during the nine months ended March 31, 2025 and 2024, respectively. These charges primarily included severance and benefits costs and professional fees related to the restructuring plans executed in prior years.

[0000950170-25-061827:notes:167]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company's research and development and sales and marketing functions to align the Company's workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”). During the three and nine months ended March 31, 2025, the Company recorded restructuring benefit of $0.2 million and restructuring charges of $1.3 million, respectively, related to the Q3 2024 Plan, which primarily consisted of additions to severance and benefits expenses, legal and consulting fees and reversals of previously established accruals related to unused severance benefits. During the three and nine months ended March 31, 2024, the Company recorded restructuring charges of $9.7 million related to the Q3 2024 Plan, which primarily consisted of severance and benefits expenses.

[0000950170-25-061827:notes:168]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the three and nine months ended March 31, 2025, the Company recorded restructuring benefit of $0.2 million and restructuring charges $0.4 million, respectively, related to the Q2 2024 Plan, which primarily consisted of additions to severance and benefits expenses, legal fees and consulting fees and reversals of previously established accruals related to unused severance benefits. During the three and nine months ended March 31, 2024, the Company recorded restructuring charges of $4.6 million and $13.3 million, respectively, related to the Q2 2024 Plan, which primarily consisted of severance and benefits expenses, legal and consulting fees.

[0000950170-25-061827:notes:169]
Through March 31, 2025, the Company has incurred $28.7 million in restructuring charges under the Q2 2024 Plan and Q3 2024 Plan which primarily related to severance and benefits costs. The Company expects to complete these ongoing restructuring plans by the end of fiscal year 2025 and does not expect to incur any significant additional charges for the Q2 2024 Plan and the Q3 2024 Plan.

[0000950170-25-061827:notes:170]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company moved engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company's labs. During the nine months ended March 31, 2025, the Company recorded restructuring charges of $0.1 million related to the 2023 Plan. The Company expects to complete the 2023 Plan by the end of fiscal year 2026 and expects to incur charges of approximately $1.0 million throughout this period, primarily for asset disposals and other fees. Through March 31, 2025, the Company has incurred $6.6 million of restructuring charges under the 2023 Plan, which primarily consisted of $5.9 million in accelerated depreciation on lab leasehold improvements and $0.7 million in other charges related to moving expenses and asset disposal costs.

[0000950170-25-061827:notes:171]
During the first quarter of fiscal 2024, the Company initiated a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with the Company's business and strategic priorities (the “Q1 2024 Plan”). It consisted

[0000950170-25-061827:notes:172]
primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general and administrative functions. During the nine months ended March 31, 2024, the Company incurred charges of $2.9 million related to the Q1 2024 Plan. As of June 30, 2024, the Q1 2024 Plan was completed.

[0000950170-25-061827:notes:173]
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of March 31, 2025 and 2024, the restructuring liability was $2.1 million and $17.0 million, respectively related to these restructuring plans.

[0000950170-25-061827:notes:174]
[same as prior period, unchanged from 0000950170-25-011087:notes:179]

[0000950170-25-061827:notes:175]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  | March 31,2025 |  |  | March 31,2024 |  |
| Balance at beginning of period |  | $ | 3,398 |  |  | $ | 6,192 |  | $ | 11,469 |  |  | $ | — |  |
| Period charges |  |  | 557 |  |  |  | 14,937 |  |  | 3,264 |  |  |  | 27,113 |  |
| Period reversals |  |  | (996 | ) |  |  | (516 | ) |  | (1,389 | ) |  |  | (802 | ) |
| Period payments |  |  | (903 | ) |  |  | (3,641 | ) |  | (11,288 | ) |  |  | (9,339 | ) |
| Balance at end of period |  | $ | 2,056 |  |  | $ | 16,972 |  | $ | 2,056 |  |  | $ | 16,972 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-25-061827:notes:176]
[same as prior period, unchanged from 0000950170-25-011087:notes:181]

[0000950170-25-061827:notes:177]
For the three months ended March 31, 2025 and 2024, the Company recorded an income tax provision of $3.7 million and an income tax benefit of $0.6 million, respectively. For the nine months ended March 31, 2025 and 2024, the Company recorded an income tax provision of $7.8 million and $7.0 million, respectively.

[0000950170-25-061827:notes:178]
The income tax provisions for the three and nine months ended March 31, 2025 and 2024, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In addition, the income tax provision for each of the three and nine months ended March 31, 2025, includes US Federal income tax expense of $1.5 million. The interim income tax provisions for the three and nine months ended March 31, 2025 and 2024 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis. The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0000950170-25-061827:notes:179]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, the Company considers all available positive and negative evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable including past operating results, estimates of future taxable income, changes to enacted tax laws, and the feasibility of tax planning strategies; such assessment is required on a jurisdiction-by-jurisdiction basis. The Company's inconsistent earnings in recent periods, including historical losses, tax attributes expiring unutilized in recent years and the cyclical nature of the Company's business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland. These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets. In the event the Company changes its determination as to the amount of deferred tax assets that can be realized, it will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000950170-25-061827:notes:180]
The Company had $18.2 million of unrecognized tax benefits as of March 31, 2025. If fully recognized in the future, $18.0 million would impact the effective tax rate and $0.2 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0000950170-25-061827:notes:181]
[same as prior period, unchanged from 0000950170-25-011087:notes:187]

[0000950170-25-061827:notes:182]
[same as prior period, unchanged from 0000950170-25-011087:notes:188]


## us-gaap:EarningsPerShareTextBlock

[0000950170-25-061827:notes:183]
[same as prior period, unchanged from 0000950170-25-011087:notes:189]

[0000950170-25-061827:notes:184]
[same as prior period, unchanged from 0000950170-25-011087:notes:190]

[0000950170-25-061827:notes:185]
[same as prior period, unchanged from 0000950170-25-011087:notes:191]

[0000950170-25-061827:notes:186]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Net income (loss) |  | $ | 3,458 |  |  | $ | (64,425 | ) |  | $ | 336 |  |  | $ | (31,761 | ) |
| Weighted-average shares used in per share calculation – basic |  |  | 132,979 |  |  |  | 129,299 |  |  |  | 132,173 |  |  |  | 129,021 |  |
| Options to purchase common stock |  |  | 452 |  |  |  | — |  |  |  | 528 |  |  |  | — |  |
| Restricted stock units |  |  | 1,155 |  |  |  | — |  |  |  | 1,069 |  |  |  | — |  |
| Employee Stock Purchase Plan shares |  |  | 4 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 134,590 |  |  |  | 129,299 |  |  |  | 133,770 |  |  |  | 129,021 |  |
| Net income (loss) per share – basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | 0.03 |  |  | $ | (0.50 | ) |  | $ | 0.00 |  |  | $ | (0.25 | ) |
| Net income (loss) per share – diluted |  | $ | 0.03 |  |  | $ | (0.50 | ) |  | $ | 0.00 |  |  | $ | (0.25 | ) |

[0000950170-25-061827:notes:187]
[same as prior period, unchanged from 0000950170-25-011087:notes:193]

[0000950170-25-061827:notes:188]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Options to purchase common stock |  |  | — |  |  |  | 1,083 |  |  |  | — |  |  |  | 1,144 |  |
| Restricted stock units |  |  | 1,349 |  |  |  | 5,577 |  |  |  | 1,258 |  |  |  | 6,269 |  |
| Employee Stock Purchase Plan shares |  |  | 345 |  |  |  | 266 |  |  |  | 114 |  |  |  | 88 |  |
| Total shares excluded |  |  | 1,694 |  |  |  | 6,926 |  |  |  | 1,372 |  |  |  | 7,501 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000950170-25-061827:notes:189]
On February 11, 2025, Katayoun ("Katy") Motiey, the Company's Chief Legal, Administrative & Sustainability Officer, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 79,461 shares of the Company's common stock until December 31, 2025.

[0000950170-25-061827:notes:190]
On March 3, 2025, Rajendra K. Khanna, a member of the Company's board of directors, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) for the sale of up to 25,000 shares of the Company's common stock until February 15, 2026.
