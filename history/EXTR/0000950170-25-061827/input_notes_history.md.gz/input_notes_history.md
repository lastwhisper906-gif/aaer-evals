# EXTR note change history — 0000950170-25-011087 → 0000950170-25-061827


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000950170-25-061827:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2025, the Company had commitments to purchase $36.0 million of inventory.
  (was, 2025-01-30, similarity 0.9893):
[0000950170-25-011087:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2024, the Company had commitments to purchase $29.5 million of inventory.

- changed (2025-05-01):
[0000950170-25-061827:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year. As of March 31, 2025, the total estimated litigation expense accrual included in the “Other accrued liabilities” in the condensed consolidated balance sheets was $28.5 million for various ongoing litigation matters with probable losses that can be reasonably estimated.
  (was, 2025-01-30, similarity 0.9968):
[0000950170-25-011087:note_history:2]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year. As of December 31, 2024, the total estimated litigation expense accrual included in the “Other accrued liabilities” in the condensed consolidated balance sheets was $23.5 million for various ongoing litigation matters with probable losses that can be reasonably estimated.

- changed (2025-05-01):
[0000950170-25-061827:note_history:3]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On January 3, 2025, both parties filed motions for summary judgment seeking to resolve various claims in the case. Those motions are currently pending before the Court. The trial is set for August 5, 2025.
  (was, 2025-01-30, similarity 0.6014):
[0000950170-25-011087:note_history:3]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software. SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without

- changed (2025-05-01):
[0000950170-25-061827:note_history:4]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. Mala appealed the decision on March 3, 2025, and the Company will defend the appeal.
  (was, 2025-01-30, similarity 0.7229):
[0000950170-25-011087:note_history:4]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. The German Federal Patent Court issued a decision finding that the patent was invalid on November 20, 2024. It is not yet known if Mala will appeal the ruling of the German Federal Patent Court.

- changed (2025-05-01):
[0000950170-25-061827:note_history:5]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Firefighters Pension and Retirement System, Oklahoma Police Pension and Retirement System, Oakland County Voluntary Employees’ Beneficiary Association, Oakland County Employees’ Retirement System as the lead plaintiffs. The Company filed a Motion to Dismiss the amended complaint on April 15, 2025. Trial has been scheduled for March 29, 2027.
  (was, 2025-01-30, similarity 0.8052):
[0000950170-25-011087:note_history:5]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of its current and former executive officers as defendants. The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”). The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about the Company's business and prospects during the Class Period. The lawsuit seeks unspecified damages. On December 30, 2024, the Court selected Oklahoma Fire/Police and Oakland County Employees as the lead plaintiffs. Trial has been scheduled for March 20, 2027.

- added (2025-05-01):
[0000950170-25-061827:note_history:6]
On February 27, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Turner v. Brown et al., Case No. 3:25-cv-02101. On March 6, 2025, a shareholder derivative case was filed in the United States District Court for the Northern District of California captioned Hemani v. Meyercord et al., Case No. 3:25-cv-02318-AGT. On March 25, 2025, a shareholder derivative case was filed in the United States District Court for the Eastern District of North Carolina captioned Miller v. Meyercord et al., Case No. 5:25-cv-00161. Each of these cases (collectively, the “Derivative Cases”) names current and former officers, directors, and employees of the Company as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the Class Action. The plaintiffs in the Derivative Cases have agreed in principle to stay the matters pending resolution of the Class Action.

- removed (2025-05-01):
[0000950170-25-011087:note_history:7]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

- removed (2025-05-01):
[0000950170-25-011087:note_history:8]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleged direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. On October 21, 2024, the District Court in Dusseldorf, Germany confirmed the withdrawal by Orckit of its complaint, thus concluding this action.

- removed (2025-05-01):
[0000950170-25-011087:note_history:9]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleged infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. On December 23, 2024, Orckit withdrew this infringement complaint.

- removed (2025-05-01):
[0000950170-25-011087:note_history:10]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On December 10, 2024, the Federal Court of Justice ruled that the ‘077 patent is invalid.

- removed (2025-05-01):
[0000950170-25-011087:note_history:11]
As a result of the withdrawals and the invalidity ruling, these cases are now concluded in the Company’s favor.

- removed (2025-05-01):
[0000950170-25-011087:note_history:12]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. The trial is set for August 5, 2025.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000950170-25-061827:note_history:13]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2025. The results of operations for the three and nine months ended March 31, 2025 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.
  (was, 2025-01-30, similarity 0.9404):
[0000950170-25-011087:note_history:13]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2024. The results of operations for the three and six months ended December 31, 2024 are not necessarily indicative of the results that may be expected for fiscal 2025 or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000950170-25-061827:note_history:14]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 13,750 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (741 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 13,009 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 168,750 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,456 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 167,294 |  |  |  | 178,265 |  |
| Total debt |  | $ | 180,303 |  |  | $ | 187,591 |  |
  (was, 2025-01-30, similarity 0.9874):
[0000950170-25-011087:note_history:14]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 12,500 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (752 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 11,748 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 172,500 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,634 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 170,866 |  |  |  | 178,265 |  |
| Total debt |  | $ | 182,614 |  |  | $ | 187,591 |  |

- changed (2025-05-01):
[0000950170-25-061827:note_history:15]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the 2023 Credit Agreement as amended by that certain Amendment Number One, the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024.
  (was, 2025-01-30, similarity 0.9508):
[0000950170-25-011087:note_history:15]
On August 14, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement (the “Amended Credit Agreement”). Under the Amended Credit Agreement, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the Amended Credit Agreement provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024.

- changed (2025-05-01):
[0000950170-25-061827:note_history:16]
As of March 31, 2025, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.
  (was, 2025-01-30, similarity 0.9633):
[0000950170-25-011087:note_history:16]
As of December 31, 2024, the Company was in compliance with all the terms and financial covenants of the Amended Credit Agreement.

- changed (2025-05-01):
[0000950170-25-061827:note_history:17]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations was $0.3 million for each period during the three months ended March 31, 2025 and 2024, and was $0.9 million and $0.8 million for the nine months ended March 31, 2025 and 2024, respectively. The interest rate was 6.41% and 7.44% as of March 31, 2025 and 2024, respectively.
  (was, 2025-01-30, similarity 0.9287):
[0000950170-25-011087:note_history:17]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs is included in “Interest expense” in the accompanying condensed consolidated statements of operations and was $0.3 million for each period during the three months ended December 31, 2024 and 2023 and was $0.6 million and $0.5 million for the six months ended December 31, 2024 and 2023, respectively. The interest rate was 6.84% and 7.46% as of December 31, 2024 and 2023, respectively.

- changed (2025-05-01):
[0000950170-25-061827:note_history:18]
As of March 31, 2025, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of March 31, 2025. During the three and nine months ended March 31, 2025 and 2024, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.
  (was, 2025-01-30, similarity 0.9093):
[0000950170-25-011087:note_history:18]
As of December 31, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of December 31, 2024. During the three and six months ended December 31, 2024 and 2023, the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the Amended Credit Agreement.

- changed (2025-05-01):
[0000950170-25-061827:note_history:19]
The Company had $14.2 million of outstanding letters of credit as of March 31, 2025.
  (was, 2025-01-30, similarity 0.9412):
[0000950170-25-011087:note_history:19]
The Company had $14.2 million of outstanding letters of credit as of December 31, 2024.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000950170-25-061827:note_history:20]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 13,750 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (741 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 13,009 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 168,750 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,456 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 167,294 |  |  |  | 178,265 |  |
| Total debt |  | $ | 180,303 |  |  | $ | 187,591 |  |
  (was, 2025-01-30, similarity 0.9874):
[0000950170-25-011087:note_history:20]
|  |  | December 31,2024 |  |  | June 30,2024 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 12,500 |  |  | $ | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (752 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 11,748 |  |  | $ | 9,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 172,500 |  |  | $ | 180,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,634 | ) |  |  | (1,735 | ) |
| Total long-term debt, less current portion |  |  | 170,866 |  |  |  | 178,265 |  |
| Total debt |  | $ | 182,614 |  |  | $ | 187,591 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-01):
[0000950170-25-061827:note_history:21]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 145,426 |  |  | $ | 124,082 |  |  |  | 418,356 |  |  | $ | 456,383 |  |
| Other |  |  | 14,126 |  |  |  | 10,291 |  |  |  | 38,018 |  |  |  | 36,274 |  |
| Total Americas |  |  | 159,552 |  |  |  | 134,373 |  |  |  | 456,374 |  |  |  | 492,657 |  |
| EMEA |  |  | 107,132 |  |  |  | 59,035 |  |  |  | 320,307 |  |  |  | 313,243 |  |
| APAC |  |  | 17,821 |  |  |  | 17,628 |  |  |  | 56,383 |  |  |  | 54,650 |  |
| Total net revenues |  | $ | 284,505 |  |  | $ | 211,036 |  |  | $ | 833,064 |  |  | $ | 860,550 |  |

- removed (2025-05-01):
[0000950170-25-011087:note_history:22]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 119,678 |  |  | $ | 149,549 |  |  |  | 272,931 |  |  | $ | 332,301 |  |
| Other |  |  | 11,710 |  |  |  | 13,086 |  |  |  | 23,892 |  |  |  | 25,983 |  |
| Total Americas |  |  | 131,388 |  |  |  | 162,635 |  |  |  | 296,823 |  |  |  | 358,284 |  |
| EMEA |  |  | 128,257 |  |  |  | 110,605 |  |  |  | 213,175 |  |  |  | 254,208 |  |
| APAC |  |  | 19,710 |  |  |  | 23,137 |  |  |  | 38,561 |  |  |  | 37,022 |  |
| Total net revenues |  | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |

- removed (2025-05-01):
[0000950170-25-011087:note_history:23]
Geographic Concentrations

- removed (2025-05-01):
[0000950170-25-011087:note_history:24]
For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000950170-25-061827:note_history:25]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts to customers and partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell primarily to end-users. Products and subscription and support may be sold separately or in bundled packages.
  (was, 2025-01-30, similarity 0.99):
[0000950170-25-011087:note_history:25]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts direct to customers and partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

- changed (2025-05-01):
[0000950170-25-061827:note_history:26]
As of March 31, 2025, the Company had $588.7 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 17% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 42% in fiscal 2026, and the remaining 41% of the balance thereafter.
  (was, 2025-01-30, similarity 0.9819):
[0000950170-25-011087:note_history:26]
As of December 31, 2024, the Company had $589.5 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 31% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 34% in fiscal 2026, and the remaining 35% of the balance thereafter.

- changed (2025-05-01):
[0000950170-25-061827:note_history:27]
Revenue recognized for the three months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $96.9 million and $95.9 million, respectively. Revenue recognized for the nine months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $245.5 million and $230.8 million, respectively.
  (was, 2025-01-30, similarity 0.9194):
[0000950170-25-011087:note_history:27]
Revenue recognized for the three months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $101.3 million and $105.7 million, respectively. Revenue recognized for the six months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $183.3 million and $172.0 million, respectively.

- added (2025-05-01):
[0000950170-25-061827:note_history:28]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $25.6 million and $24.7 as of March 31, 2025 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2025 and 2024 was $3.2 million and $2.8 million, respectively. Amortization recognized during the nine months ended March 31, 2025 and 2024 was $9.3 million and $8.0 million, respectively.

- added (2025-05-01):
[0000950170-25-061827:note_history:29]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 145,426 |  |  | $ | 124,082 |  |  |  | 418,356 |  |  | $ | 456,383 |  |
| Other |  |  | 14,126 |  |  |  | 10,291 |  |  |  | 38,018 |  |  |  | 36,274 |  |
| Total Americas |  |  | 159,552 |  |  |  | 134,373 |  |  |  | 456,374 |  |  |  | 492,657 |  |
| EMEA |  |  | 107,132 |  |  |  | 59,035 |  |  |  | 320,307 |  |  |  | 313,243 |  |
| APAC |  |  | 17,821 |  |  |  | 17,628 |  |  |  | 56,383 |  |  |  | 54,650 |  |
| Total net revenues |  | $ | 284,505 |  |  | $ | 211,036 |  |  | $ | 833,064 |  |  | $ | 860,550 |  |

- added (2025-05-01):
[0000950170-25-061827:note_history:30]
For the three and nine months ended March 31, 2025, the Company generated 10% and 11% of its net revenues respectively from the Netherlands. For the nine months ended March 31, 2024, the Company generated 10% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and nine months ended March 31, 2025 and 2024.

- added (2025-05-01):
[0000950170-25-061827:note_history:31]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2025 |  | March 31,2024 |  | March 31,2025 |  | March 31,2024 |
| Jenne, Inc. |  | 21% |  | 12% |  | 19% |  | 22% |
| TD Synnex Corporation |  | 18% |  | 22% |  | 19% |  | 21% |
| Westcon Group, Inc. |  | 16% |  | 13% |  | 17% |  | 17% |
| ScanSource, Inc. |  | * |  | 11% |  | * |  | * |
| * Less than 10% of net revenue |  |  |  |  |  |  |  |  |

- changed (2025-05-01):
[0000950170-25-061827:note_history:32]
|  |  | March 31,2025 |  | June 30,2024 |
| Jenne, Inc. |  | 33% |  | 64% |
| TD Synnex Corporation |  | 13% |  | * |
| ScanSource, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |
  (was, 2025-01-30, similarity 0.8509):
[0000950170-25-011087:note_history:32]
|  |  | December 31,2024 |  | June 30,2024 |
| Jenne, Inc. |  | 26% |  | 64% |
| ScanSource, Inc. |  | * |  | 11% |
| * Less than 10% of accounts receivable |  |  |  |  |

- removed (2025-05-01):
[0000950170-25-011087:note_history:33]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.7 million as of December 31, 2024 and June 30, 2024. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2024 and 2023 was $3.1 million and $2.7 million, respectively. Amortization recognized during the six months ended December 31, 2024 and 2023 was $6.1 million and $5.2 million, respectively.

- removed (2025-05-01):
[0000950170-25-011087:note_history:34]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 119,678 |  |  | $ | 149,549 |  |  |  | 272,931 |  |  | $ | 332,301 |  |
| Other |  |  | 11,710 |  |  |  | 13,086 |  |  |  | 23,892 |  |  |  | 25,983 |  |
| Total Americas |  |  | 131,388 |  |  |  | 162,635 |  |  |  | 296,823 |  |  |  | 358,284 |  |
| EMEA |  |  | 128,257 |  |  |  | 110,605 |  |  |  | 213,175 |  |  |  | 254,208 |  |
| APAC |  |  | 19,710 |  |  |  | 23,137 |  |  |  | 38,561 |  |  |  | 37,022 |  |
| Total net revenues |  | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |

- removed (2025-05-01):
[0000950170-25-011087:note_history:35]
For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively. For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany and for the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and six months ended December 31, 2024 and 2023.

- removed (2025-05-01):
[0000950170-25-011087:note_history:36]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2024 |  | December 31,2023 |  | December 31,2024 |  | December 31,2023 |
| Westcon Group, Inc. |  | 22% |  | 10% |  | 18% |  | 18% |
| TD Synnex Corporation |  | 17% |  | 24% |  | 19% |  | 21% |
| Jenne, Inc. |  | 15% |  | 23% |  | 18% |  | 25% |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0000950170-25-061827:note_history:37]
As of March 31, 2025, the Company had $588.7 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 17% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 42% in fiscal 2026, and the remaining 41% of the balance thereafter.
  (was, 2025-01-30, similarity 0.9819):
[0000950170-25-011087:note_history:37]
As of December 31, 2024, the Company had $589.5 million of remaining performance obligations, which primarily comprised of deferred SaaS subscription and deferred support revenues. The Company expects to recognize approximately 31% of its deferred revenue as revenue in the remainder of fiscal 2025, an additional 34% in fiscal 2026, and the remaining 35% of the balance thereafter.

- changed (2025-05-01):
[0000950170-25-061827:note_history:38]
Revenue recognized for the three months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $96.9 million and $95.9 million, respectively. Revenue recognized for the nine months ended March 31, 2025 and 2024 that was included in the deferred revenue balance at the beginning of each period was $245.5 million and $230.8 million, respectively.
  (was, 2025-01-30, similarity 0.9194):
[0000950170-25-011087:note_history:38]
Revenue recognized for the three months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $101.3 million and $105.7 million, respectively. Revenue recognized for the six months ended December 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $183.3 million and $172.0 million, respectively.

- added (2025-05-01):
[0000950170-25-061827:note_history:39]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $25.6 million and $24.7 as of March 31, 2025 and June 30, 2024, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2025 and 2024 was $3.2 million and $2.8 million, respectively. Amortization recognized during the nine months ended March 31, 2025 and 2024 was $9.3 million and $8.0 million, respectively.

- added (2025-05-01):
[0000950170-25-061827:note_history:40]
|  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |  | March 31,2025 |  |  | March 31,2024 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 145,426 |  |  | $ | 124,082 |  |  |  | 418,356 |  |  | $ | 456,383 |  |
| Other |  |  | 14,126 |  |  |  | 10,291 |  |  |  | 38,018 |  |  |  | 36,274 |  |
| Total Americas |  |  | 159,552 |  |  |  | 134,373 |  |  |  | 456,374 |  |  |  | 492,657 |  |
| EMEA |  |  | 107,132 |  |  |  | 59,035 |  |  |  | 320,307 |  |  |  | 313,243 |  |
| APAC |  |  | 17,821 |  |  |  | 17,628 |  |  |  | 56,383 |  |  |  | 54,650 |  |
| Total net revenues |  | $ | 284,505 |  |  | $ | 211,036 |  |  | $ | 833,064 |  |  | $ | 860,550 |  |

- added (2025-05-01):
[0000950170-25-061827:note_history:41]
For the three and nine months ended March 31, 2025, the Company generated 10% and 11% of its net revenues respectively from the Netherlands. For the nine months ended March 31, 2024, the Company generated 10% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and nine months ended March 31, 2025 and 2024.

- removed (2025-05-01):
[0000950170-25-011087:note_history:42]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $24.7 million as of December 31, 2024 and June 30, 2024. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2024 and 2023 was $3.1 million and $2.7 million, respectively. Amortization recognized during the six months ended December 31, 2024 and 2023 was $6.1 million and $5.2 million, respectively.

- removed (2025-05-01):
[0000950170-25-011087:note_history:43]
|  | Three Months Ended |  | Six Months Ended |  |
|  |  | December 31,2024 |  |  | December 31,2023 |  |  | December 31,2024 |  |  | December 31,2023 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  | 119,678 |  |  | $ | 149,549 |  |  |  | 272,931 |  |  | $ | 332,301 |  |
| Other |  |  | 11,710 |  |  |  | 13,086 |  |  |  | 23,892 |  |  |  | 25,983 |  |
| Total Americas |  |  | 131,388 |  |  |  | 162,635 |  |  |  | 296,823 |  |  |  | 358,284 |  |
| EMEA |  |  | 128,257 |  |  |  | 110,605 |  |  |  | 213,175 |  |  |  | 254,208 |  |
| APAC |  |  | 19,710 |  |  |  | 23,137 |  |  |  | 38,561 |  |  |  | 37,022 |  |
| Total net revenues |  | $ | 279,355 |  |  | $ | 296,377 |  |  | $ | 548,559 |  |  | $ | 649,514 |  |

- removed (2025-05-01):
[0000950170-25-011087:note_history:44]
For the three and six months ended December 31, 2024, the Company generated 15% and 11% of its net revenues from the Netherlands, respectively. For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany and for the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. No other foreign country accounted for 10% or more of the Company's net revenues for the three and six months ended December 31, 2024 and 2023.
