# EXTR MD&A — 0000950170-25-061827


## mdna

[0000950170-25-061827:mdna:1]
[same as prior period, unchanged from 0000950170-25-011087:mdna:1]

[0000950170-25-061827:mdna:2]
[same as prior period, unchanged from 0000950170-25-011087:mdna:2]

[0000950170-25-061827:mdna:3]
[same as prior period, unchanged from 0000950170-25-011087:mdna:3]

[0000950170-25-061827:mdna:4]
Extreme Networks, Inc. (“Extreme” or “Company”) is a leading provider of cloud networking with integrated security and Artificial Intelligence (“AI”) solutions along with industry leading services and support. Extreme designs, develops, and manufactures wired, wireless, and software-defined wide area-network (“SD-WAN”) infrastructure equipment, software and cloud-based network management solutions and security and AI software solutions. The Company’s Platform ONETM solution, announced in December 2024, is a technology platform that reduces the complexity for enterprises by seamlessly integrating networking, security and AI solutions into a single platform. AI-powered automation includes conversational, interactive and autonomous AI agents—to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex tasks.

[0000950170-25-061827:mdna:5]
[same as prior period, unchanged from 0000950170-25-011087:mdna:5]

[0000950170-25-061827:mdna:6]
[same as prior period, unchanged from 0000950170-25-011087:mdna:6]

[0000950170-25-061827:mdna:7]
Enterprises across every industry are going through unprecedented changes, such as digital transformation initiatives, migrating their workloads to cloud-based environments, modernizing applications, finding new ways to leverage generative AI (“GenAI”) technology, and adapting to a distributed workforce. To accomplish this, they are adopting new Information Technology (“IT”) delivery models and applications that require fundamental network alterations and enhancements spanning from the access edge to the data center. As networks become more complex and more distributed in nature, we believe IT teams in every industry will need more control and better insights than ever before to deliver secure, distributed connectivity and comprehensive centralized visibility. Networking is mission critical and touches all elements of how services are delivered to customers, employees, students, and patients. Managing networks from a single platform that integrates AI networking and security is critical to help reduce complexity and minimize the time it takes to complete tasks.

[0000950170-25-061827:mdna:8]
[same as prior period, unchanged from 0000950170-25-011087:mdna:8]

[0000950170-25-061827:mdna:9]
[same as prior period, unchanged from 0000950170-25-011087:mdna:9]

[0000950170-25-061827:mdna:10]
We believe that the network has never been more vital than it is today. As administrators grapple with more data, coming from more places, more connected devices, and more Software-as-a-Service (“SaaS”) based applications, the cloud is fundamental to managing and maintaining a modern network. Traditional network offerings are not well-suited to fulfill enterprise expectations for rapid delivery of new services, more flexible business models, real-time response, and massive scalability. We expect Platform ONE’s new capabilities to deliver significant productivity gains for IT teams by streamlining network design, deployment, management, and commercial operations.

[0000950170-25-061827:mdna:11]
[same as prior period, unchanged from 0000950170-25-011087:mdna:11]

[0000950170-25-061827:mdna:12]
[same as prior period, unchanged from 0000950170-25-011087:mdna:12]

[0000950170-25-061827:mdna:13]
[same as prior period, unchanged from 0000950170-25-011087:mdna:13]

[0000950170-25-061827:mdna:14]
[same as prior period, unchanged from 0000950170-25-011087:mdna:14]

[0000950170-25-061827:mdna:15]
[same as prior period, unchanged from 0000950170-25-011087:mdna:15]

[0000950170-25-061827:mdna:16]
[same as prior period, unchanged from 0000950170-25-011087:mdna:16]

[0000950170-25-061827:mdna:17]
Extreme Platform ONE will reduce complexity for enterprises by seamlessly integrating networking, security and AI solutions. The platform’s AI-powered automation includes conversational, interactive and autonomous AI agents, to assist, advise and accelerate the productivity of networking, security and business teams—reducing the time to complete complex tasks. Extreme Platform ONE is also designed to offer the industry's simplest licensing.

[0000950170-25-061827:mdna:18]
[same as prior period, unchanged from 0000950170-25-011087:mdna:18]

[0000950170-25-061827:mdna:19]
[same as prior period, unchanged from 0000950170-25-011087:mdna:19]

[0000950170-25-061827:mdna:20]
[same as prior period, unchanged from 0000950170-25-011087:mdna:20]

[0000950170-25-061827:mdna:21]
[same as prior period, unchanged from 0000950170-25-011087:mdna:21]

[0000950170-25-061827:mdna:22]
[same as prior period, unchanged from 0000950170-25-011087:mdna:22]

[0000950170-25-061827:mdna:23]
[same as prior period, unchanged from 0000950170-25-011087:mdna:23]

[0000950170-25-061827:mdna:24]
[same as prior period, unchanged from 0000950170-25-011087:mdna:24]

[0000950170-25-061827:mdna:25]
[same as prior period, unchanged from 0000950170-25-011087:mdna:25]

[0000950170-25-061827:mdna:26]
[same as prior period, unchanged from 0000950170-25-011087:mdna:26]

[0000950170-25-061827:mdna:27]
[same as prior period, unchanged from 0000950170-25-011087:mdna:27]

[0000950170-25-061827:mdna:28]
[same as prior period, unchanged from 0000950170-25-011087:mdna:28]

[0000950170-25-061827:mdna:29]
[same as prior period, unchanged from 0000950170-25-011087:mdna:29]

[0000950170-25-061827:mdna:30]
•
Additional AI Capabilities in ExtremeCloud IQ. The ExtremeCloud IQ CoPilot license tier is an add-on to the Pilot license tier. It includes all the capabilities of the ExtremeCloud Pilot and Navigator license tiers. CoPilot serves as more than a centralized point of management with AIOps and other enhancements to network management and automation. It is a trusted digital advisor for your Extreme cloud-managed Wi-Fi networks that proactively reduces risk and provides the fastest time to the best experience. This includes advanced anomaly detection and capabilities to ensure the user experience of wireless and wired devices.

[0000950170-25-061827:mdna:31]
[same as prior period, unchanged from 0000950170-25-011087:mdna:31]

[0000950170-25-061827:mdna:32]
[same as prior period, unchanged from 0000950170-25-011087:mdna:32]

[0000950170-25-061827:mdna:33]
[same as prior period, unchanged from 0000950170-25-011087:mdna:33]

[0000950170-25-061827:mdna:34]
[same as prior period, unchanged from 0000950170-25-011087:mdna:34]

[0000950170-25-061827:mdna:35]
•
AI is a dynamic tool and is leveraged to drive productivity across our company and to offer security and GenAI solutions to our customers. Extreme’s journey in AI began in 2020 with the advent of machine learning and purpose-built AI. We then introduced Co-Pilot AIOps in 2022 to further enhance network performance and troubleshooting. Today we have the next exciting chapter – Extreme AI Expert – a GenAI solution that will help optimize networks, provide better design, improve mean time to resolution for technical issues, and create cost savings in the overall design and implementation of networks. We are utilizing AI to improve mean time to resolution for customers, both through our AIOps offerings as well as internal use of Extreme AI Expert. We announced a technology preview of our Extreme AI Expert showcasing its ability to speed up documentation searches and resolution of network performance issues. This allows our customers to optimize their network performance and make it easier to focus on value-added activities.

[0000950170-25-061827:mdna:36]
•
Provide a new enterprise connectivity platform - Extreme Platform ONE. In February 2025, Extreme launched what we believe is the industry's leading multi-tenant architecture and consumption-based billing model for managed service providers,

[0000950170-25-061827:mdna:37]
with poolable licensing, which creates significant benefits and cost savings for partners and customers alike. In the second half of the calendar year 2025, Extreme will integrate networking and security with AI into one simplified experience so organizations can manage and secure the network faster and more efficiently than ever into Platform ONE for end customers that will provide:

[0000950170-25-061827:mdna:38]
[same as prior period, unchanged from 0000950170-25-011087:mdna:41]

[0000950170-25-061827:mdna:39]
[same as prior period, unchanged from 0000950170-25-011087:mdna:42]

[0000950170-25-061827:mdna:40]
[same as prior period, unchanged from 0000950170-25-011087:mdna:43]

[0000950170-25-061827:mdna:41]
•
AI capabilities in Extreme Platform ONE. There are several ways customers will be able to leverage our AI in the future as part of Extreme Platform ONE:

[0000950170-25-061827:mdna:42]
[same as prior period, unchanged from 0000950170-25-011087:mdna:37]

[0000950170-25-061827:mdna:43]
[same as prior period, unchanged from 0000950170-25-011087:mdna:38]

[0000950170-25-061827:mdna:44]
[same as prior period, unchanged from 0000950170-25-011087:mdna:39]

[0000950170-25-061827:mdna:45]
•
Enable a common fabric to simplify and automate the network. Fabric technologies virtualize the network infrastructure (decoupling network services from physical connectivity) which enables network services to be turned up faster, with lower likelihood of error. They make the underlying network much easier to design, implement, manage, and troubleshoot.

[0000950170-25-061827:mdna:46]
[same as prior period, unchanged from 0000950170-25-011087:mdna:45]

[0000950170-25-061827:mdna:47]
o
ExtremeCloud Universal ZTNA. Universal ZTNA is the first network security offering to integrate network, application, and device security within a single solution. By combining Cloud Network Access Control (“NAC”) and Zero Trust Network Authentication (“ZTNA”) into a single, easy-to-use SaaS offering, we help customers ensure unified observability, frictionless user experiences and a consistent security policy for applications and devices, as well as support secure hybrid work use cases for customers. As the virtual private network market transitions to ZTNA, the proliferation of individual applications, each with their own policy and dashboard, is adding complexity and expense for enterprise customers. We expect the broadening of our security offering to drive significant traction for our business with growth opportunities.

[0000950170-25-061827:mdna:48]
[same as prior period, unchanged from 0000950170-25-011087:mdna:47]

[0000950170-25-061827:mdna:49]
[same as prior period, unchanged from 0000950170-25-011087:mdna:48]

[0000950170-25-061827:mdna:50]
[same as prior period, unchanged from 0000950170-25-011087:mdna:49]

[0000950170-25-061827:mdna:51]
[same as prior period, unchanged from 0000950170-25-011087:mdna:50]

[0000950170-25-061827:mdna:52]
•
Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience, and our operating systems- the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud.

[0000950170-25-061827:mdna:53]
[same as prior period, unchanged from 0000950170-25-011087:mdna:53]

[0000950170-25-061827:mdna:54]
[same as prior period, unchanged from 0000950170-25-011087:mdna:54]

[0000950170-25-061827:mdna:55]
[same as prior period, unchanged from 0000950170-25-011087:mdna:55]

[0000950170-25-061827:mdna:56]
[same as prior period, unchanged from 0000950170-25-011087:mdna:56]

[0000950170-25-061827:mdna:57]
[same as prior period, unchanged from 0000950170-25-011087:mdna:57]

[0000950170-25-061827:mdna:58]
[same as prior period, unchanged from 0000950170-25-011087:mdna:58]

[0000950170-25-061827:mdna:59]
During the third quarter of fiscal 2025, we achieved the following results:

[0000950170-25-061827:mdna:60]
•
Net revenues of $284.5 million compared to $211.0 million in the third quarter of fiscal 2024.

[0000950170-25-061827:mdna:61]
•
Product revenues of $178.1 million compared to $106.4 million in the third quarter of fiscal 2024.

[0000950170-25-061827:mdna:62]
•
Subscription and support revenues of $106.4 million compared to $104.6 million in the third quarter of fiscal 2024.

[0000950170-25-061827:mdna:63]
•
Total gross margin of 61.7% of net revenues compared to 56.8% of net revenues in the third quarter of fiscal 2024.

[0000950170-25-061827:mdna:64]
•
Operating income of $10.4 million compared to operating loss of $62.5 million in the third quarter of fiscal 2024.

[0000950170-25-061827:mdna:65]
•
Net income of $3.5 million compared to net loss of $64.4 million in the third quarter of fiscal 2024.

[0000950170-25-061827:mdna:66]
During the first nine months of fiscal 2025, we reflected the following results:

[0000950170-25-061827:mdna:67]
•
Cash flows provided by operating activities of $70.1 million compared to $40.0 million in the nine months ended March 31, 2024.

[0000950170-25-061827:mdna:68]
•
Cash and cash equivalents of $185.5 million as of March 31, 2025 compared to $156.7 million as of June 30, 2024.

[0000950170-25-061827:mdna:69]
[same as prior period, unchanged from 0000950170-25-011087:mdna:69]

[0000950170-25-061827:mdna:70]
[same as prior period, unchanged from 0000950170-25-011087:mdna:70]

[0000950170-25-061827:mdna:71]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  | March 31,2024 |  | $Change |  | %Change |  | March 31,2025 |  | March 31,2024 |  | $Change |  | %Change |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $178,060 |  | $106,442 |  | $71,618 |  | 67.3 % |  | $512,605 |  | $546,536 |  | $(33,931) |  | (6.2)% |  |
| Percentage of net revenues |  | 62.6% |  | 50.4% |  |  |  |  |  | 61.5% |  | 63.5% |  |  |  |  |  |
| Subscription and support |  | 106,445 |  | 104,594 |  | 1,851 |  | 1.8 % |  | 320,459 |  | 314,014 |  | 6,445 |  | 2.1 % |  |
| Percentage of net revenues |  | 37.4% |  | 49.6% |  |  |  |  |  | 38.5% |  | 36.5% |  |  |  |  |  |
| Total net revenues |  | $284,505 |  | $211,036 |  | $73,469 |  | 34.8 % |  | $833,064 |  | $860,550 |  | $(27,486) |  | (3.2)% |  |

[0000950170-25-061827:mdna:72]
[same as prior period, unchanged from 0000950170-25-011087:mdna:72]

[0000950170-25-061827:mdna:73]
Product revenues increased $71.6 million or 67.3% for the three months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The increase in product revenues was primarily driven by higher shipments than in the corresponding period in fiscal 2024 which was impacted by elongated sales cycles to end customers and lower channel sell-through caused by macroeconomic conditions. Product revenues decreased $33.9 million or 6.2% for the nine months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The decrease in product revenues was primarily driven by higher shipments in the corresponding period in fiscal 2024 due to the release of product backlog resulting from the easing of supply chain constraints.

[0000950170-25-061827:mdna:74]
Subscription and support revenues increased $1.9 million or 1.8% for the three months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. Subscription and support revenues increased $6.4 million or 2.1% for the nine months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The increases in subscription and support revenues were primarily due to higher subscription revenue.

[0000950170-25-061827:mdna:75]
[same as prior period, unchanged from 0000950170-25-011087:mdna:75]

[0000950170-25-061827:mdna:76]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | March 31,2025 |  | March 31,2024 |  | $Change |  | %Change |  | March 31,2025 |  | March 31,2024 |  | $Change |  | %Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $102,001 |  | $45,605 |  | $56,396 |  | 123.7 % |  | $294,540 |  | $295,670 |  | $(1,130) |  | (0.4)% |  |
| Percentage of product revenues |  | 57.3% |  | 42.8% |  |  |  |  |  | 57.5% |  | 54.1% |  |  |  |  |  |
| Subscription and support |  | 73,408 |  | 74,296 |  | (888) |  | (1.2)% |  | 225,499 |  | 220,537 |  | 4,962 |  | 2.2 % |  |
| Percentage of subscription and support revenues |  | 69.0% |  | 71.0% |  |  |  |  |  | 70.4% |  | 70.2% |  |  |  |  |  |
| Total gross profit |  | $175,409 |  | $119,901 |  | $55,508 |  | 46.3 % |  | $520,039 |  | $516,207 |  | $3,832 |  | 0.7 % |  |
| Percentage of net revenues |  | 61.7% |  | 56.8% |  |  |  |  |  | 62.4% |  | 60.0% |  |  |  |  |  |

[0000950170-25-061827:mdna:77]
Product gross profit increased $56.4 million or 123.7% for the three months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The increase in product gross profit was primarily due to higher product revenues and lower reserves for excess and obsolete inventories, partially offset by higher overhead and distribution costs.

[0000950170-25-061827:mdna:78]
Product gross profit decreased $1.1 million or 0.4% for the nine months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The decrease in product gross profit was primarily due to lower product revenues and increased overhead costs, partially offset by lower reserves for excess and obsolete inventory.

[0000950170-25-061827:mdna:79]
Subscription and support gross profit decreased $0.9 million or 1.2% for the three months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The decrease in subscription and support gross profit was primarily due to higher subscription hosting costs.

[0000950170-25-061827:mdna:80]
Subscription and support gross profit increased $5.0 million or 2.2% for the nine months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The increase in subscription and support gross profit was primarily due to increased subscription revenues, partially offset by higher subscription hosting costs.

[0000950170-25-061827:mdna:81]
[same as prior period, unchanged from 0000950170-25-011087:mdna:81]

[0000950170-25-061827:mdna:82]
[same as prior period, unchanged from 0000950170-25-011087:mdna:82]

[0000950170-25-061827:mdna:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2025 |  | March 31,2024 |  | $Change |  | %Change |  | March 31,2025 |  | March 31,2024 |  | $Change |  | %Change |
| Research and development | $55,656 |  | $54,517 |  | $1,139 |  | 2.1 % |  | $164,990 |  | $165,366 |  | $(376) |  | (0.2)% |
| Sales and marketing | 79,773 |  | 87,708 |  | (7,935) |  | (9.0)% |  | 241,123 |  | 264,782 |  | (23,659) |  | (8.9)% |
| General and administrative | 29,537 |  | 25,213 |  | 4,324 |  | 17.1 % |  | 92,202 |  | 74,470 |  | 17,732 |  | 23.8 % |
| Restructuring and related (benefit) charges | (441) |  | 14,421 |  | (14,862) |  | (103.1)% |  | 1,871 |  | 26,312 |  | (24,441) |  | (92.9)% |
| Amortization of intangible assets | 507 |  | 511 |  | (4) |  | (0.8)% |  | 1,528 |  | 1,531 |  | (3) |  | (0.2)% |
| Total operating expenses | $165,032 |  | $182,370 |  | $(17,338) |  | (9.5)% |  | $501,714 |  | $532,461 |  | $(30,747) |  | (5.8)% |

[0000950170-25-061827:mdna:84]
[same as prior period, unchanged from 0000950170-25-011087:mdna:84]

[0000950170-25-061827:mdna:85]
[same as prior period, unchanged from 0000950170-25-011087:mdna:85]

[0000950170-25-061827:mdna:86]
Research and development expenses increased by $1.1 million or 2.1% for the three months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The increase in research and development expenses was primarily due to a $1.1 million increase in personnel costs due to higher headcount and higher compensation and benefits costs, a $0.7 million increase in engineering project costs, and a $0.5 million increase in other expenses primarily consisting of software costs, partially offset by a $1.2 million decrease in contractor costs.

[0000950170-25-061827:mdna:87]
Research and development expenses decreased by $0.4 million or 0.2% for the nine months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The decrease in research and development expenses was primarily due to a $7.0 million decrease in contractor costs, partially offset by a $3.0 million increase in personnel costs due to higher headcount and higher compensation and benefits costs, a $1.6 million increase in information and technology and facilities related costs, and a $2.0 million increase in other expenses primarily consisting of recruiting and professional fees.

[0000950170-25-061827:mdna:88]
[same as prior period, unchanged from 0000950170-25-011087:mdna:88]

[0000950170-25-061827:mdna:89]
[same as prior period, unchanged from 0000950170-25-011087:mdna:89]

[0000950170-25-061827:mdna:90]
Sales and marketing expenses decreased by $7.9 million or 9.0% for the three months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The decrease in sales and marketing expenses was primarily due to a $4.3 million decrease in personnel costs primarily due to lower headcount, a $2.4 million decrease in other expenses primarily related to marketing expenses for trade shows and information technology and facilities expenses, and a $1.2 million decrease in professional fees.

[0000950170-25-061827:mdna:91]
Sales and marketing expenses decreased by $23.7 million or 8.9% for the nine months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The decrease in sales and marketing expenses was primarily due to a $16.7 million decrease in personnel costs due to lower headcount, a $2.7 million decrease in information technology and facilities costs, a $2.8 million decrease in contractor costs and professional services costs, and a $1.5 million decrease in travel expenses.

[0000950170-25-061827:mdna:92]
[same as prior period, unchanged from 0000950170-25-011087:mdna:92]

[0000950170-25-061827:mdna:93]
[same as prior period, unchanged from 0000950170-25-011087:mdna:93]

[0000950170-25-061827:mdna:94]
General and administrative expenses increased by $4.3 million or 17.1% for the three months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The increase in general and administrative expenses was primarily due to a $6.7 million increase in system transition costs, partially offset by a $1.5 million decrease in legal costs related to litigation matters, net of insurance recoveries, and a $0.9 million decrease in professional fees.

[0000950170-25-061827:mdna:95]
General and administrative expenses increased by $17.7 million or 23.8% for the nine months ended March 31, 2025 as compared to the corresponding period in fiscal 2024. The increase in general and administrative expenses was primarily due to a $14.5 million increase in system transition costs and a $7.3 million increase in legal costs related to litigation matters, net of insurance recoveries, partially offset by a $3.7 million decrease in professional fees, and a $0.4 million decrease in other costs related to recruiting fees and advertising.

[0000950170-25-061827:mdna:96]
[same as prior period, unchanged from 0000950170-25-011087:mdna:96]

[0000950170-25-061827:mdna:97]
For the three and nine months ended March 31, 2025, we recorded restructuring benefit  of $0.4 million and restructuring charges of $1.9 million, respectively, which primarily consisted of additions to severance and benefits costs and professional services fees as well as reversals of previously established accruals related to unused severance benefits associated with the reduction-in-force actions related to the “Q2 2024 Plan”, and “Q3 2024 Plan”, each as described in Note 13, Restructuring and Related Charges, in Notes to the Condensed Consolidated Financial Statements included elsewhere in this Report.

[0000950170-25-061827:mdna:98]
For the three and nine months ended March 31, 2024, we recorded restructuring and related charges of $14.4 million and $26.3 million, which primarily consisted of severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q1 2024 Plan”, “Q2 2024 Plan”, and “Q3 2024 Plan”.

[0000950170-25-061827:mdna:99]
[same as prior period, unchanged from 0000950170-25-011087:mdna:99]

[0000950170-25-061827:mdna:100]
During the three months ended March 31, 2025 and 2024, we recorded $0.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-25-061827:mdna:101]
During the nine months ended March 31, 2025 and 2024, we recorded $1.5 million of operating expenses for each period related to the amortization of intangible assets.

[0000950170-25-061827:mdna:102]
[same as prior period, unchanged from 0000950170-25-011087:mdna:102]

[0000950170-25-061827:mdna:103]
During the three months ended March 31, 2025 and 2024, we recorded $1.0 million and $1.2 million, respectively, in interest income. The decrease in interest income was primarily related to the lower interest earned on our cash accounts due to lower cash and cash equivalents balances held during the third quarter in fiscal 2025.

[0000950170-25-061827:mdna:104]
During the nine months ended March 31, 2025 and 2024, we recorded $2.7 million and $3.9 million, respectively, in interest income. The decrease in interest income is primarily related to the lower interest earned on our cash accounts due to lower cash and cash equivalents balances held during the first three quarters of fiscal 2025.

[0000950170-25-061827:mdna:105]
[same as prior period, unchanged from 0000950170-25-011087:mdna:105]

[0000950170-25-061827:mdna:106]
During the three months ended March 31, 2025 and 2024, we recorded $3.8 million and $4.2 million, respectively, in interest expense related to the debt obligations held under our Amended Credit Agreement. The decrease in interest expense was primarily due to lower average rates under the Amended Credit Agreement.

[0000950170-25-061827:mdna:107]
During the nine months ended March 31, 2025 and 2024, we recorded $12.4 million and $12.8 million, respectively, in interest expense related to the debt obligations held under the Amended Credit Agreement. The decrease in interest expense was primarily due to lower average rates under the Amended Credit Agreement.

[0000950170-25-061827:mdna:108]
[same as prior period, unchanged from 0000950170-25-011087:mdna:108]

[0000950170-25-061827:mdna:109]
During the three months ended March 31, 2025 and 2024, we recorded other expense, net of $0.4 million and other income, net of $0.4 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-25-061827:mdna:110]
During the nine months ended March 31, 2025 and 2024, we recorded other expense, net of $0.4 million and other income, net of $0.4 million, respectively. The other income (expense), net for each period primarily related to the foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-25-061827:mdna:111]
[same as prior period, unchanged from 0000950170-25-011087:mdna:111]

[0000950170-25-061827:mdna:112]
For the three months ended March 31, 2025 and 2024, we recorded income tax provision of $3.7 million and an income tax benefit of $0.6 million, respectively.

[0000950170-25-061827:mdna:113]
For the nine months ended March 31, 2025 and 2024, we recorded income tax provision of $7.8 million and $7.0 million, respectively.

[0000950170-25-061827:mdna:114]
The income tax provisions for the three and nine months ended March 31, 2025 and 2024 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya LLC and the Data Center Business from Brocade Communications System. In addition, the income tax provision for each of the three and nine months ended March 31, 2025 includes U.S. federal income tax expense of $1.5 million.

[0000950170-25-061827:mdna:115]
[same as prior period, unchanged from 0000950170-25-011087:mdna:115]

[0000950170-25-061827:mdna:116]
[same as prior period, unchanged from 0000950170-25-011087:mdna:116]

[0000950170-25-061827:mdna:117]
[same as prior period, unchanged from 0000950170-25-011087:mdna:117]

[0000950170-25-061827:mdna:118]
[same as prior period, unchanged from 0000950170-25-011087:mdna:118]

[0000950170-25-061827:mdna:119]
[same as prior period, unchanged from 0000950170-25-011087:mdna:119]

[0000950170-25-061827:mdna:120]
[same as prior period, unchanged from 0000950170-25-011087:mdna:120]

[0000950170-25-061827:mdna:121]
[same as prior period, unchanged from 0000950170-25-011087:mdna:121]

[0000950170-25-061827:mdna:122]
[same as prior period, unchanged from 0000950170-25-011087:mdna:122]

[0000950170-25-061827:mdna:123]
|  |  | March 31,2025 |  |  | June 30,2024 |  |
| Cash and cash equivalents |  | $ | 185,480 |  |  | $ | 156,699 |  |

[0000950170-25-061827:mdna:124]
As of March 31, 2025, our principal sources of liquidity consisted of cash and cash equivalents of $185.5 million, accounts receivable, net of $99.5 million, and available borrowings under our 2023 Revolving Facility of $135.8 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest and share repurchases. We believe that our $185.5 million of cash and cash equivalents at March 31, 2025, our cash flow from operations and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months and into the foreseeable future.

[0000950170-25-061827:mdna:125]
On February 18, 2025, we announced that our Board had authorized management to repurchase up to $200 million shares of the Company's common stock over a three-year period, commencing July 1, 2025 (the “2025 Repurchase Program”). As of March 31, 2025, we had approximately $37.3 million remaining from the $200.0 million share repurchase authorization approved in May 2022 (the “2022 Repurchase Program”), which expires on June 30, 2025. Under these repurchase programs, purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. Neither of the 2022 Repurchase Program or the 2025 Repurchase Program obligate us to acquire any shares of our common stock, and they may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three and nine months ended March 31, 2025, we repurchased a total of 853,247 shares of our common stock on the open market at a total cost of $13.0 million with an average price of $15.24 per share.

[0000950170-25-061827:mdna:126]
[same as prior period, unchanged from 0000950170-25-011087:mdna:126]

[0000950170-25-061827:mdna:127]
On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, Bank of America, N.A., JPMorgan Chase Bank, N.A., PNC Bank, National Association and Wells Fargo Bank, National Association, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as an administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount

[0000950170-25-061827:mdna:128]
[same as prior period, unchanged from 0000950170-25-011087:mdna:128]

[0000950170-25-061827:mdna:129]
[same as prior period, unchanged from 0000950170-25-011087:mdna:129]

[0000950170-25-061827:mdna:130]
The 2023 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-25-061827:mdna:131]
On August 14, 2024, we entered into an Amendment Number One to the 2023 Credit Agreement the (the 2023 Credit Agreement as amended by that certain Amendment Number One, “Amended Credit Agreement”). Under the Amended Credit Agreement, we modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the Amended Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with our operations and activities.

[0000950170-25-061827:mdna:132]
During the three and nine months ended March 31, 2025, the Company was in compliance with the modified terms and financial covenants under the Amended Credit Agreement.

[0000950170-25-061827:mdna:133]
[same as prior period, unchanged from 0000950170-25-011087:mdna:133]

[0000950170-25-061827:mdna:134]
[same as prior period, unchanged from 0000950170-25-011087:mdna:134]

[0000950170-25-061827:mdna:135]
|  |  | Nine Months Ended |  |
|  |  | March 31,2025 |  |  | March 31,2024 |  |
| Net cash provided by operating activities |  | $ | 70,092 |  |  | $ | 39,997 |  |
| Net cash used in investing activities |  |  | (18,067 | ) |  |  | (13,632 | ) |
| Net cash used in financing activities |  |  | (23,102 | ) |  |  | (109,919 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (142 | ) |  |  | (265 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 28,781 |  |  | $ | (83,819 | ) |

[0000950170-25-061827:mdna:136]
[same as prior period, unchanged from 0000950170-25-011087:mdna:136]

[0000950170-25-061827:mdna:137]
Cash flows provided by operations in the nine months ended March 31, 2025 were $70.1 million, including our net income of $0.3 million and non-cash expenses of $86.0 million for items such as amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in inventories and increases in deferred revenue and accrued compensation and benefits. This was partially offset by increases in accounts receivable and prepaid expenses and other assets as well as decreases in accounts payable, operating lease liabilities and other liabilities.

[0000950170-25-061827:mdna:138]
Cash flows provided by operations in the nine months ended March 31, 2024 were $40.0 million, including our net loss of $31.8 million and non-cash expenses of $109.3 million for items amortization of intangible assets, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest. Other sources of cash for the period included a decrease in accounts receivable, and increases in deferred revenue and other current and long-term liabilities. This was partially offset by increases in inventories and prepaid expenses and other assets as well as decreases in accounts payable, operating lease liabilities and accrued compensation and benefits.

[0000950170-25-061827:mdna:139]
[same as prior period, unchanged from 0000950170-25-011087:mdna:139]

[0000950170-25-061827:mdna:140]
Cash flows used in investing activities in the nine months ended March 31, 2025 were $18.1 million for the purchases of property and equipment and the capitalized software development costs.

[0000950170-25-061827:mdna:141]
Cash flows used in investing activities in the nine months ended March 31, 2024 were $13.6 million for the purchases of property and equipment.

[0000950170-25-061827:mdna:142]
[same as prior period, unchanged from 0000950170-25-011087:mdna:142]

[0000950170-25-061827:mdna:143]
Cash flows used in financing activities in the nine months ended March 31, 2025 were $23.1 million primarily due to share repurchases of $13.0 million under the 2022 Repurchase Program, payments of $1.9 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and exercise of stock options, a payment of $0.7 million for debt financing costs related to the Amended Credit Agreement, and debt repayments of $7.5 million.

[0000950170-25-061827:mdna:144]
Cash flows used in financing activities in the nine months ended March 31, 2024 were $109.9 million primarily due to payments of $27.6 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options, share repurchases of $49.9 million under the 2022 Repurchase Program, a $25.0 million payment against our revolving facility, and debt repayments of $7.5 million.

[0000950170-25-061827:mdna:145]
[same as prior period, unchanged from 0000950170-25-011087:mdna:145]

[0000950170-25-061827:mdna:146]
Foreign currency effect on cash and cash equivalents increased in the nine months ended March 31, 2025, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the Euro.

[0000950170-25-061827:mdna:147]
[same as prior period, unchanged from 0000950170-25-011087:mdna:147]

[0000950170-25-061827:mdna:148]
As of March 31, 2025, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0000950170-25-061827:mdna:149]
Our debt obligations relate to amounts owed under our Amended Credit Agreement. As of March 31, 2025, we had $182.5 million of debt outstanding, which is payable on quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 7, Debt, in the Notes to Condensed Consolidated Financial Statements in this Report for additional information regarding our debt obligations.

[0000950170-25-061827:mdna:150]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of March 31, 2025, we had non-cancelable commitments to purchase $36.0 million of inventory. See Note 8, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0000950170-25-061827:mdna:151]
We have contractual commitments to our suppliers which represent commitments for future services. As of March 31, 2025, we had contractual commitments of $19.4 million that are due through our fiscal year 2027.

[0000950170-25-061827:mdna:152]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of March 31, 2025, the value of our obligations under operating leases was $55.3 million.

[0000950170-25-061827:mdna:153]
[same as prior period, unchanged from 0000950170-25-011087:mdna:153]

[0000950170-25-061827:mdna:154]
We did not have any material commitments for capital expenditures as of March 31, 2025.

[0000950170-25-061827:mdna:155]
[same as prior period, unchanged from 0000950170-25-011087:mdna:155]

[0000950170-25-061827:mdna:156]
We did not have any off-balance sheet arrangements as of March 31, 2025.
