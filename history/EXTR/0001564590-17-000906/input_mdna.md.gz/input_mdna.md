# EXTR MD&A — 0001564590-17-000906


## mdna

[0001564590-17-000906:mdna:1]
[same as prior period, unchanged from 0001564590-16-027054:mdna:1]

[0001564590-17-000906:mdna:2]
[same as prior period, unchanged from 0001564590-16-027054:mdna:2]

[0001564590-17-000906:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended December 31, 2016.

[0001564590-17-000906:mdna:4]
[same as prior period, unchanged from 0001564590-16-027054:mdna:4]

[0001564590-17-000906:mdna:5]
[same as prior period, unchanged from 0001564590-16-027054:mdna:5]

[0001564590-17-000906:mdna:6]
[same as prior period, unchanged from 0001564590-16-027054:mdna:6]

[0001564590-17-000906:mdna:7]
[same as prior period, unchanged from 0001564590-16-027054:mdna:7]

[0001564590-17-000906:mdna:8]
[same as prior period, unchanged from 0001564590-16-027054:mdna:8]

[0001564590-17-000906:mdna:9]
[same as prior period, unchanged from 0001564590-16-027054:mdna:9]

[0001564590-17-000906:mdna:10]
[same as prior period, unchanged from 0001564590-16-027054:mdna:10]

[0001564590-17-000906:mdna:11]
|  | • | Vendor Consolidation. We believe consolidation of vendors within the Ethernet networking market and between adjacent markets (storage, security, wireless & voice software and applications) continues to gain momentum. In 2015, the Hewlett-Packard Company (“HP”) acquired Aruba, the Dell, Inc. acquisition of EMC closed in September 2016 and Brocade Communication Systems acquired Ruckus in May 2016. We believe these acquisitions reflect a realization that customers want end-to-end, integrated networking solutions. Extreme identified this trend in 2013 and sought to address the issue with |

[0001564590-17-000906:mdna:12]
|  |  | its acquisition of Enterasys in 2013. During October 2016, Extreme has continued this activity with the acquisition of the WLAN Business from Zebra. With these acquisitions Extreme has rationalized the roadmap and provided an upgrade path for customers. |

[0001564590-17-000906:mdna:13]
[same as prior period, unchanged from 0001564590-16-027054:mdna:13]

[0001564590-17-000906:mdna:14]
[same as prior period, unchanged from 0001564590-16-027054:mdna:14]

[0001564590-17-000906:mdna:15]
[same as prior period, unchanged from 0001564590-16-027054:mdna:15]

[0001564590-17-000906:mdna:16]
[same as prior period, unchanged from 0001564590-16-027054:mdna:16]

[0001564590-17-000906:mdna:17]
[same as prior period, unchanged from 0001564590-16-027054:mdna:17]

[0001564590-17-000906:mdna:18]
[same as prior period, unchanged from 0001564590-16-027054:mdna:18]

[0001564590-17-000906:mdna:19]
[same as prior period, unchanged from 0001564590-16-027054:mdna:19]

[0001564590-17-000906:mdna:20]
[same as prior period, unchanged from 0001564590-16-027054:mdna:20]

[0001564590-17-000906:mdna:21]
[same as prior period, unchanged from 0001564590-16-027054:mdna:21]

[0001564590-17-000906:mdna:22]
[same as prior period, unchanged from 0001564590-16-027054:mdna:22]

[0001564590-17-000906:mdna:23]
[same as prior period, unchanged from 0001564590-16-027054:mdna:23]

[0001564590-17-000906:mdna:24]
On October 28, 2016, we closed the purchase of the wireless LAN business (the “WLAN Business”) of Zebra Technologies Corporation, (“Zebra”), pursuant to an Asset Purchase Agreement (the “Purchase Agreement”).  Under the terms of the Purchase Agreement, we acquired customers, employees, technology and other assets, as well as assumed certain contracts and other liabilities of the WLAN Business, for a cash purchase price of $51.1 million, subject to certain adjustments related to net working capital and deferred revenue on October 28, 2016 (the “Closing”).

[0001564590-17-000906:mdna:25]
We are accounting for the acquisition of the WLAN Business using the acquisition method whereby the acquired assets and liabilities of the WLAN Business will be recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the WLAN Business are included in our operations beginning with the Closing.

[0001564590-17-000906:mdna:26]
During the three and six months ended December 31, 2016, we recognized acquisition costs of $1.7 million and $1.8 million, respectively, which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-17-000906:mdna:27]
[same as prior period, unchanged from 0001564590-16-027054:mdna:30]

[0001564590-17-000906:mdna:28]
During the second quarter of fiscal 2017, we achieved the following results:

[0001564590-17-000906:mdna:29]
|  | • | Net revenues of $148.1 million compared to $139.3 million in the second quarter of fiscal 2016. |

[0001564590-17-000906:mdna:30]
|  | • | Product revenues of $109.8 million compared to $105.4 million in the second quarter of fiscal 2016. |

[0001564590-17-000906:mdna:31]
|  | • | Service revenues of $38.3 million compared to $34.0 million in the second quarter of fiscal 2016. |

[0001564590-17-000906:mdna:32]
|  | • | Total gross margin of 50.9% of net revenues compared to 50.4% of net revenues in the second quarter of fiscal 2016. |

[0001564590-17-000906:mdna:33]
|  | • | Operating loss of $7.4 million compared to $5.4 million in the second quarter of fiscal 2016. |

[0001564590-17-000906:mdna:34]
|  | • | Net loss of $8.6 million compared to a net loss of $7.2 million in the second quarter of fiscal 2016. |

[0001564590-17-000906:mdna:35]
|  | • | Cash flow provided by operating activities of $19.3 million in the six months ended December 31, 2016 compared to $14.0 million in the six months ended December 31, 2015. |

[0001564590-17-000906:mdna:36]
|  | • | Cash and cash equivalents of $103.8 million as of December 31, 2016 compared to $85.9 million as of December 31, 2015. |

[0001564590-17-000906:mdna:37]
[same as prior period, unchanged from 0001564590-16-027054:mdna:40]

[0001564590-17-000906:mdna:38]
The following table presents net product and service revenue for the periods presented (dollars in thousands):

[0001564590-17-000906:mdna:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | $ Change |  |  | % Change |  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 109,789 |  |  | $ | 105,355 |  |  | $ | 4,434 |  |  |  | 4.2 | % |  | $ | 199,920 |  |  | $ | 196,736 |  |  | $ | 3,184 |  |  |  | 1.6 | % |
| Percentage of net revenue |  |  | 74.1 | % |  |  | 75.6 | % |  |  |  |  |  |  |  |  |  |  | 73.8 | % |  |  | 74.6 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 38,322 |  |  |  | 33,950 |  |  |  | 4,372 |  |  |  | 12.9 | % |  |  | 70,833 |  |  |  | 67,150 |  |  |  | 3,683 |  |  |  | 5.5 | % |
| Percentage of net revenue |  |  | 25.9 | % |  |  | 24.4 | % |  |  |  |  |  |  |  |  |  |  | 26.2 | % |  |  | 25.4 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 148,111 |  |  | $ | 139,305 |  |  | $ | 8,806 |  |  |  | 6.3 | % |  | $ | 270,753 |  |  | $ | 263,886 |  |  | $ | 6,867 |  |  |  | 2.6 | % |

[0001564590-17-000906:mdna:40]
Product revenues increased $4.4 million or 4.2% for the three months ended December 31, 2016 as compared to the corresponding period of fiscal 2016.  Product revenues increased by $3.2 million or 1.6% for the six months ended December 31, 2016 as compared to the corresponding period of fiscal 2016.  The increases in product revenues for both periods of fiscal 2017 were attributable to growth in our wireless business due to the acquisition of the WLAN Business and lower discounting from list price.  The increase was partially offset by lower e-rate educational revenue.

[0001564590-17-000906:mdna:41]
Service revenues increased $4.4 million or 12.9% in the second quarter of fiscal 2017, compared to the corresponding period of fiscal 2016. Service revenues increased $3.7 million or 5.5% for the six months ended December 31, 2016, compared to the corresponding period of fiscal 2016.  The increase in service revenues for both periods was due to the acquisition of the WLAN Business and the increased number of service contracts acquired.

[0001564590-17-000906:mdna:42]
The following table presents the product and service, gross profit and the respective gross profit percentages for the periods presented (dollars in thousands):

[0001564590-17-000906:mdna:43]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | $ Change |  |  | % Change |  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 51,130 |  |  | $ | 48,252 |  |  | $ | 2,878 |  |  |  | 6.0 | % |  | $ | 96,334 |  |  | $ | 92,699 |  |  | $ | 3,635 |  |  |  | 3.9 | % |
| Percentage of product revenue |  |  | 46.6 | % |  |  | 45.8 | % |  |  |  |  |  |  |  |  |  |  | 48.2 | % |  |  | 47.1 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 24,224 |  |  |  | 22,023 |  |  |  | 2,201 |  |  |  | 10.0 | % |  |  | 44,266 |  |  |  | 42,694 |  |  |  | 1,572 |  |  |  | 3.7 | % |
| Percentage of service revenue |  |  | 63.2 | % |  |  | 64.9 | % |  |  |  |  |  |  |  |  |  |  | 62.5 | % |  |  | 63.6 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 75,354 |  |  | $ | 70,275 |  |  | $ | 5,079 |  |  |  | 7.2 | % |  | $ | 140,600 |  |  | $ | 135,393 |  |  | $ | 5,207 |  |  |  | 3.8 | % |
| Percentage of net revenue |  |  | 50.9 | % |  |  | 50.4 | % |  |  |  |  |  |  |  |  |  |  | 51.9 | % |  |  | 51.3 | % |  |  |  |  |  |  |  |  |

[0001564590-17-000906:mdna:44]
Product gross profit increased $2.9 million or 6.0% in the second quarter of fiscal 2017 as compared to the corresponding period in fiscal 2016.  Gross profit increased during the second quarter of fiscal 2017 due to higher revenues of $4.4 million, lower intangible asset amortization of $2.0 million and warranty charges of $1.8 million offset by increases in excess inventory charges of $5.1 million related to the discontinuance of certain product lines due to the acquisition of the WLAN Business.

[0001564590-17-000906:mdna:45]
Product gross profit increased $3.6 million or 3.9% in the first six months of fiscal 2017 as compared to the corresponding period in fiscal 2016.  Gross profit increased during the second quarter of fiscal 2017 due to higher revenues of $3.2 million, lower intangible asset amortization of $2.9 million and warranty charges of $3.1 million offset by increases in excess inventory charges of $4.9 million related to the discontinuance of certain product lines due to the acquisition of the WLAN Business.

[0001564590-17-000906:mdna:46]
Service gross profit increased $2.2 million or 10.0% in the second quarter of fiscal 2017 as compared to the second quarter of fiscal 2016 and increased $1.6 million or 3.7% in the first six months of fiscal 2017 as compared to the corresponding period of fiscal 2016.  The increase in service revenues was primarily due to the acquisition of the WLAN Business and the increased service contracts acquired for both periods of fiscal 2017.

[0001564590-17-000906:mdna:47]
[same as prior period, unchanged from 0001564590-16-027054:mdna:49]

[0001564590-17-000906:mdna:48]
The following table presents operating expenses for the periods presented (dollars in thousands):

[0001564590-17-000906:mdna:49]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | $ Change |  |  | % Change |  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 24,013 |  |  | $ | 20,716 |  |  | $ | 3,297 |  |  |  | 15.9 | % |  | $ | 42,312 |  |  | $ | 40,984 |  |  | $ | 1,328 |  |  |  | 3.2 | % |
| Sales and marketing |  |  | 41,109 |  |  |  | 37,058 |  |  |  | 4,051 |  |  |  | 10.9 | % |  |  | 78,065 |  |  |  | 73,120 |  |  |  | 4,945 |  |  |  | 6.8 | % |
| General and administrative |  |  | 9,397 |  |  |  | 9,775 |  |  |  | (378 | ) |  |  | (3.9 | )% |  |  | 17,684 |  |  |  | 18,951 |  |  |  | (1,267 | ) |  |  | (6.7 | )% |
| Acquisition and integration costs |  |  | 4,169 |  |  |  | 807 |  |  |  | 3,362 |  |  |  | 416.6 | % |  |  | 6,490 |  |  |  | 1,145 |  |  |  | 5,345 |  |  |  | 466.8 | % |
| Restructuring and related charges, net of reversals |  |  | 1,853 |  |  |  | 3,031 |  |  |  | (1,178 | ) |  |  | (38.9 | )% |  |  | 1,853 |  |  |  | 8,634 |  |  |  | (6,781 | ) |  |  | (78.5 | )% |
| Amortization of intangibles |  |  | 2,175 |  |  |  | 4,251 |  |  |  | (2,076 | ) |  |  | (48.8 | )% |  |  | 6,317 |  |  |  | 8,718 |  |  |  | (2,401 | ) |  |  | (27.5 | )% |
| Total operating expenses |  | $ | 82,716 |  |  | $ | 75,638 |  |  | $ | 7,078 |  |  |  | 9.4 | % |  | $ | 152,721 |  |  | $ | 151,552 |  |  | $ | 1,169 |  |  |  | 0.8 | % |

[0001564590-17-000906:mdna:50]
[same as prior period, unchanged from 0001564590-16-027054:mdna:52]

[0001564590-17-000906:mdna:51]
[same as prior period, unchanged from 0001564590-16-027054:mdna:53]

[0001564590-17-000906:mdna:52]
Research and development expenses increased by $3.3 million, or 15.9% for the three months ended December 31, 2016 as compared to the corresponding period of fiscal 2016.  The increase in research and development expenses was due to higher personnel costs of $1.8 million due to increased headcount related to the acquisition of the WLAN Business, higher facility and information technology costs of $0.6 million associated with the WLAN Business, increased professional fees of $0.4 million and increased equipment costs of $0.3 million.

[0001564590-17-000906:mdna:53]
Research and development expenses increased by $1.3 million, or 3.2% for the six months ended December 31, 2016 as compared to the corresponding period of fiscal 2016.  The increase in research and development expenses was due to higher personnel costs of $0.8 million, increased professional fees of $0.5 million and increased facility and information technology costs of $0.4 million.

[0001564590-17-000906:mdna:54]
[same as prior period, unchanged from 0001564590-16-027054:mdna:55]

[0001564590-17-000906:mdna:55]
[same as prior period, unchanged from 0001564590-16-027054:mdna:56]

[0001564590-17-000906:mdna:56]
Sales and marketing expenses increased by $4.1 million or 10.9% for the three months ended December 31, 2016 as compared to the corresponding period of fiscal 2016.  The increase in sales and marketing expenses was primarily due to higher personnel costs of $2.0 million, travel costs of $1.1 million and professional fees of $0.7 million, driven in large part by the acquisition of the WLAN Business.

[0001564590-17-000906:mdna:57]
Sales and marketing expenses increased by $4.9 million or 6.8% for the six months ended December 31, 2016 as compared to the corresponding period of fiscal 2016. The increase in sales and marketing expenses was primarily due to higher personnel costs of $2.4 million, travel costs of $1.1 million, software and supplies costs of $0.6 million and professional fees of $0.7 million.

[0001564590-17-000906:mdna:58]
[same as prior period, unchanged from 0001564590-16-027054:mdna:58]

[0001564590-17-000906:mdna:59]
[same as prior period, unchanged from 0001564590-16-027054:mdna:59]

[0001564590-17-000906:mdna:60]
General and administrative expenses decreased by $0.4 million or 3.9% for the three months ended December 31, 2016 as compared to the corresponding period of fiscal 2016. The decrease in general and administrative expenses was due to lower personnel costs of $0.9 million, partial offset with an increase in professional fees of $0.4 million.

[0001564590-17-000906:mdna:61]
General and administrative expenses decreased by $1.3 million or 6.7% for the six months ended December 31, 2016 as compared to the corresponding period of fiscal 2016. The decrease in general and administrative expenses was due to lower personnel costs of $1.3 million partially offset by an increase in professional fees of $0.2 million.

[0001564590-17-000906:mdna:62]
[same as prior period, unchanged from 0001564590-16-027054:mdna:61]

[0001564590-17-000906:mdna:63]
During the three months ended December 31, 2016 and 2015, we recorded $4.2 million and $0.8 million, respectively, of acquisition and integration costs.  Expenses for the three months ended December 31, 2016 consisted primarily of legal and accounting services associated with the acquisition of the WLAN Business. Expenses for the three months ended December 31, 2015 related to the integration costs of Enterasys.

[0001564590-17-000906:mdna:64]
During the six months ended December 31, 2016 and 2015, we recorded $6.5 million and $1.1 million of acquisition and integration costs.  Costs for the six months ended December 31, 2016 related to the acquisition of the WLAN Business and Costs for the six months ended December 31, 2015 were related to integration costs primarily for IT and sales integration associated with Enterasys.

[0001564590-17-000906:mdna:65]
Restructuring and Related Charges

[0001564590-17-000906:mdna:66]
During the three and six months ended December 31, 2016, we incurred $1.9 million in restructuring and other charges including accelerated depreciation of leasehold improvements and fixed assets in the amount of $1.7 million and adjustments to estimated sub-lease income to be received related to the estimated future obligations for non-cancelable lease payments for excess facilities of $0.1 million.

[0001564590-17-000906:mdna:67]
During the three months ended December 31, 2015, we incurred $2.8 million in charges related to amending our facility lease in North Carolina and $0.2 million of adjustments to severance benefits.  Excess facilities charges included the acceleration of depreciation of leasehold improvements in the amount of $1.8 million, and contract termination charges and professional fees of $1.0 million.

[0001564590-17-000906:mdna:68]
During the six months ended December 31, 2015, we incurred $8.3 million in excess facilities charges and $0.4 million of adjustments to severance benefits. Excess facilities charges included $4.1 million of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities, acceleration of depreciation of leasehold improvements of $3.2 million and contract termination charges and professional fees of $1.0 million.

[0001564590-17-000906:mdna:69]
[same as prior period, unchanged from 0001564590-16-027054:mdna:67]

[0001564590-17-000906:mdna:70]
During the three months ended December 31, 2016 and 2015, we recorded $2.2 million and $4.3 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.

[0001564590-17-000906:mdna:71]
During the six months ended December 31, 2016 and 2015, we recorded $6.3 million and $8.7 million, respectively of amortization expense recorded in operating expenses in the condensed consolidated statements of operations.

[0001564590-17-000906:mdna:72]
[same as prior period, unchanged from 0001564590-16-027054:mdna:69]

[0001564590-17-000906:mdna:73]
During the three and six months ended December 31, 2016 we recorded $1.2 million and $1.8 million, respectively, in interest expense primarily in connection with our Credit Facility, as amended. We expect our interest expense will increase in future periods due to the higher balances of our Credit Facility, as Amended.

[0001564590-17-000906:mdna:74]
During the three and six months ended December 31, 2015 we recorded $0.8 million and $1.6 million, respectively, in interest expense primarily in connection with our Credit Facility, as amended.

[0001564590-17-000906:mdna:75]
Other Income

[0001564590-17-000906:mdna:76]
During the three months ended December 31, 2016 and 2015 we recorded income of $1.0 million for both periods, in other income. The change was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-17-000906:mdna:77]
During the six months ended December 31, 2016 and 2015 we recorded income of $0.8 million and $1.1 million, respectively, in other income. The increases for both periods was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-17-000906:mdna:78]
[same as prior period, unchanged from 0001564590-16-027054:mdna:73]

[0001564590-17-000906:mdna:79]
For the three months ended December 31, 2016 and 2015, we recorded an income tax provision of $1.2 million for both years. For the six months ended December 31, 2016 and 2015, we recorded an income tax provision of $2.1 million for both years.

[0001564590-17-000906:mdna:80]
The income tax provisions for the three months ended December 31, 2016 and 2015 consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys and the WLAN Business.

[0001564590-17-000906:mdna:81]
[same as prior period, unchanged from 0001564590-16-027054:mdna:76]

[0001564590-17-000906:mdna:82]
[same as prior period, unchanged from 0001564590-16-027054:mdna:77]

[0001564590-17-000906:mdna:83]
[same as prior period, unchanged from 0001564590-16-027054:mdna:78]

[0001564590-17-000906:mdna:84]
[same as prior period, unchanged from 0001564590-16-027054:mdna:79]

[0001564590-17-000906:mdna:85]
[same as prior period, unchanged from 0001564590-16-027054:mdna:80]

[0001564590-17-000906:mdna:86]
[same as prior period, unchanged from 0001564590-16-027054:mdna:81]

[0001564590-17-000906:mdna:87]
[same as prior period, unchanged from 0001564590-16-027054:mdna:82]

[0001564590-17-000906:mdna:88]
The following critical accounting policy is the only change since the filing of our last Annual Report on Form 10-K.

[0001564590-17-000906:mdna:89]
Business Combinations

[0001564590-17-000906:mdna:90]
We allocate the purchase price of acquired companies to the tangible and intangible assets acquired and liabilities assumed, assumed equity awards, as well as to in-process research and development based upon their estimated fair values at the acquisition date.   The purchase price allocation process requires management’s judgment and often involves the use of significant estimates and assumptions, especially at the acquisition date with respect to intangible assets, deferred revenue obligations and equity assumed.

[0001564590-17-000906:mdna:91]
Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain.  Examples of critical estimates in valuing certain of intangible assets we have acquired or may acquire in future include but are not limited to assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, expected costs to develop the in-process research and development into commercially viable products, among other items.

[0001564590-17-000906:mdna:92]
In connection with the purchase price allocations for our acquisitions, we estimate the fair value of inventory using the comparative sales method.  The fair value of the inventory utilizing the comparative sales method is estimated using the selling price, less sales costs, marketing costs and profit on these costs.  The operating profit margins are based on the historical margins.

[0001564590-17-000906:mdna:93]
In connection with the purchase price allocations for our acquisitions, we estimate the fair value of deferred revenue using the cost build-up approach.  The cost build-up approach determines the fair value by estimating the costs related to fulfilling the

[0001564590-17-000906:mdna:94]
obligations plus a normal profit margin.  The estimated costs to fulfill the obligations are based on historical costs and benchmarking analysis.

[0001564590-17-000906:mdna:95]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-17-000906:mdna:96]
[same as prior period, unchanged from 0001564590-16-027054:mdna:84]

[0001564590-17-000906:mdna:97]
See Note 4 of the accompanying condensed consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-17-000906:mdna:98]
[same as prior period, unchanged from 0001564590-16-027054:mdna:86]

[0001564590-17-000906:mdna:99]
[same as prior period, unchanged from 0001564590-16-027054:mdna:87]

[0001564590-17-000906:mdna:100]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Cash and cash equivalent |  | $ | 103,786 |  |  | $ | 94,122 |  |
| Total cash and investments |  | $ | 103,786 |  |  | $ | 94,122 |  |
| Working capital |  | $ | 45,906 |  |  | $ | 17,442 |  |

[0001564590-17-000906:mdna:101]
As of December 31, 2016, our principal sources of liquidity consisted of cash and cash equivalents of $103.8 million, accounts receivable, net of $117.8 million and availability of borrowings from the Revolving Facility of $23.7 million. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment. We believe that our $103.8 million of cash and cash equivalents at December 31, 2016, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-17-000906:mdna:102]
During the three months ended December 31, 2016, the Company entered into an Amended and Restated Credit Agreement (the “Credit Facility, as amended”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Facility, as amended provides for a five-year $90.5 million term loan (“Term”) and a five-year $50.0 million revolving credit facility (“Revolver”), which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Facility, as amended among other things, amends and restates the Company’s existing credit facility.  The Credit Facility, as amended is collateralized by substantially all of the assets of the Company.

[0001564590-17-000906:mdna:103]
The Credit Facility, as amended, contain financial covenants that among other things, require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.

[0001564590-17-000906:mdna:104]
The Credit Facility, as amended, also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Credit Facility, as amended, may be accelerated upon certain events of default.  At December 31, 2016, we were in compliance and expect to remain in compliance with the covenants of the Credit Facility, as amended, and they are not expected to impact our liquidity or capital resources.

[0001564590-17-000906:mdna:105]
[same as prior period, unchanged from 0001564590-16-027054:mdna:92]

[0001564590-17-000906:mdna:106]
[same as prior period, unchanged from 0001564590-16-027054:mdna:93]

[0001564590-17-000906:mdna:107]
|  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Net cash provided by operating activities |  | $ | 19,288 |  |  | $ | 13,967 |  |
| Net cash used in investing activities |  |  | (55,750 | ) |  |  | (1,409 | ) |
| Net cash provided by (used in) financing activities |  |  | 46,241 |  |  |  | (2,545 | ) |
| Foreign currency effect on cash |  |  | (115 | ) |  |  | (373 | ) |
| Net increase in cash and cash equivalents |  | $ | 9,664 |  |  | $ | 9,640 |  |

[0001564590-17-000906:mdna:108]
[same as prior period, unchanged from 0001564590-16-027054:mdna:95]

[0001564590-17-000906:mdna:109]
Cash flows provided by operations in the six months ended December 31, 2016 were $19.3 million due to non-cash expenses of $25.8 million such as amortization of intangibles, stock-based compensation expense and depreciation and higher deferred distributor revenue due to initial shipments to distributors of WLAN Business products.  This was partially offset by the current period's net loss of $15.1 million along with increased use of cash for accounts receivable in the amount of $18.7 million, accounts payable and accrued compensation.

[0001564590-17-000906:mdna:110]
Cash flows provided by operations in the six months ended December 31, 2015, were $14.0 million reflecting the impact of non-cash expenses such as amortization of intangibles, stock-based compensation expense and depreciation as well as increases in accounts receivables and was partially offset by the current period's net loss of $18.8 million and decreases in accounts payable and deferred revenues.

[0001564590-17-000906:mdna:111]
[same as prior period, unchanged from 0001564590-16-027054:mdna:98]

[0001564590-17-000906:mdna:112]
Cash flows used in investing activities in the six months ended December 31, 2016 and 2015, were $55.8 million and $1.4 million, respectively.  For the six months ended December 31, 2016, cash flows consisted of expenditures of $51.1 million for the WLAN Business acquisition and $4.7 million of purchases of property and equipment.  For the six months ended December 31, 2015, amounts consisted of purchases of property and equipment.

[0001564590-17-000906:mdna:113]
[same as prior period, unchanged from 0001564590-16-027054:mdna:100]

[0001564590-17-000906:mdna:114]
Cash flows provided by financing activities in the six months ended December 31, 2016 were $46.2 million which consisted of new borrowings of $48.3 million under our Credit Facility, as amended, $4.8 million proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by repayment of debt totaling $5.5 million and $1.3 million of loan fees incurred in connection with the Credit Facility, as amended.

[0001564590-17-000906:mdna:115]
Cash flow used in financing activities in the six months ended December 31, 2015 were $2.5 million, consisting of $19.9 million of cash used for repayment of debt partial offset by borrowings under the Revolver of $15.0 million and $2.3 million of proceeds from the issuance of shares of our common stock under the ESPP combined with the exercise of stock options and vested and released stock awards, net of taxes paid.

[0001564590-17-000906:mdna:116]
[same as prior period, unchanged from 0001564590-16-027054:mdna:103]

[0001564590-17-000906:mdna:117]
Foreign currency effect on cash increased in the six months ended December 31, 2016, primarily due to changes in foreign currency exchange rates between the US Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-17-000906:mdna:118]
[same as prior period, unchanged from 0001564590-16-027054:mdna:105]

[0001564590-17-000906:mdna:119]
The following summarizes our contractual obligations as of December 31, 2016, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-17-000906:mdna:120]
|  |  | Total |  |  | Less than 1 Year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 98,238 |  |  | $ | 10,181 |  |  | $ | 33,938 |  |  | $ | 54,119 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 13,168 |  |  |  | 4,024 |  |  |  | 6,357 |  |  |  | 2,787 |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 93,643 |  |  |  | 93,643 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable purchase commitments |  |  | 24,157 |  |  |  | 2,657 |  |  |  | 10,000 |  |  |  | 11,500 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 57,846 |  |  |  | 13,010 |  |  |  | 20,545 |  |  |  | 14,686 |  |  |  | 9,605 |  |
| Other liabilities |  |  | 1,000 |  |  |  | 200 |  |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 288,052 |  |  | $ | 123,715 |  |  | $ | 71,240 |  |  | $ | 83,492 |  |  | $ | 9,605 |  |

[0001564590-17-000906:mdna:121]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $93.6 million as of   December 31, 2016. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-17-000906:mdna:122]
Non-cancelable software and maintenance support commitments represent future payments for software and support used in our products.

[0001564590-17-000906:mdna:123]
[same as prior period, unchanged from 0001564590-16-027054:mdna:110]

[0001564590-17-000906:mdna:124]
[same as prior period, unchanged from 0001564590-16-027054:mdna:111]

[0001564590-17-000906:mdna:125]
[same as prior period, unchanged from 0001564590-16-027054:mdna:112]

[0001564590-17-000906:mdna:126]
We did not have any material commitments for capital expenditures as of December 31, 2016.

[0001564590-17-000906:mdna:127]
[same as prior period, unchanged from 0001564590-16-027054:mdna:114]

[0001564590-17-000906:mdna:128]
We did not have any off-balance sheet arrangements as of December 31, 2016.
