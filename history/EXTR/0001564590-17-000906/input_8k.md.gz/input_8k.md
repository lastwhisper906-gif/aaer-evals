# EXTR 8-K — 0001564590-17-000835 filed 2017-02-01

## item codes, every 8-K on or before 2017-02-02

- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2017-02-02

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-17-000835:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-17-000835:8k_2_02:2]
extr-ex991_6.htm

[0001564590-17-000835:8k_2_02:3]
Exhibit 99.1

[0001564590-17-000835:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-17-000835:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Matt Steinberg |  | Media Contact Ben Haber |
| 212/481-2050 |  | 617/624-3200 |
| extreme@tpr-ir.com |  | ExtremeUS@racepointglobal.com |

[0001564590-17-000835:8k_2_02:6]
Extreme Networks Reports Second Quarter Fiscal Year 2017 Financial Results

[0001564590-17-000835:8k_2_02:7]
SAN JOSE, Calif., February 1, 2017 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal second quarter ended December 31, 2016.  Second quarter revenue was $148.1 million.  GAAP gross margin for the second fiscal quarter was 50.9% and non-GAAP gross margin 57.5%.  GAAP operating margin for the second fiscal quarter was (5.0)% and non-GAAP operating margin was 9.4%.  GAAP net loss for the second fiscal quarter was $8.6 million, or $0.08 per basic share, and non-GAAP net income was $12.7 million, or $0.12 per diluted share.

[0001564590-17-000835:8k_2_02:8]
“We are pleased to announce solid second quarter results reflecting strong execution of our operating plan to drive higher cash flows,” stated Ed Meyercord, President and CEO of Extreme Networks.  “During the quarter, we expanded gross margins and increased profitability through our focused selling strategy to enterprise campus customers across our targeted verticals, while also implementing significant cost savings initiatives.  We grew our non-GAAP gross margin by 390 basis points and operating margin by 160 basis points year-over-year, each reaching their highest levels in three years, underscoring the progress we have made both strategically and operationally.”

[0001564590-17-000835:8k_2_02:9]
“Looking ahead, we are well-positioned to take advantage of new growth opportunities by delivering industry-leading solutions and services to our enterprise customers.  These customers include large, multi-national accounts from our recently acquired WLAN business from Zebra Technologies.  Additionally, we remain focused on managing our cost structure as we continue to realize the synergies from the acquired business and implement our realignment of the Company’s resources to accelerate the achievement of our growth and margin objectives,” Meyercord added.

[0001564590-17-000835:8k_2_02:10]
Recent Key Events:

[0001564590-17-000835:8k_2_02:11]
|  | • | Completed Acquisition of Zebra’s Wireless LAN Business. We officially completed our acquisition of Zebra’s Wireless LAN business, solidifying Extreme's position as the third largest provider in our target enterprise campus market. |

[0001564590-17-000835:8k_2_02:12]
|  | • | Official Wi-Fi and Wi-Fi Analytics Provider of Super Bowl LI; MetLife Stadium Win with New York Jets and New York Giants; and Expanded Partnership with the New England Patriots. Extreme announced that it will power Super Bowl LI following its wired and wireless deployment at NRG Stadium in Houston. We also won the MetLife Stadium (formally Cisco customers) core networking business. |

[0001564590-17-000835:8k_2_02:13]
|  | • | New Wave2 Wireless APs. We strengthened our ExtremeWireless™ portfolio with the industry’s first Wave2 integrated camera access points, which offer customers significant cost savings and unified management as compared to traditional surveillance camera solutions. |

[0001564590-17-000835:8k_2_02:14]
|  | • | Recognized for Outstanding Partnership Support. Tech Data awarded Extreme with its ‘Growth Vendor Partner of the Year’ award based on our year-over-year sales performance, executive engagement and overall support for Tech Data. |

[0001564590-17-000835:8k_2_02:15]
Fiscal Q2 2017 Financial Metrics:

[0001564590-17-000835:8k_2_02:16]
|  |  | 2017 |  |  | 2016 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 109.8 |  |  | $ | 105.3 |  |  | $ | 4.5 |  |  |  | 4 | % |
| Service |  |  | 38.3 |  |  |  | 34.0 |  |  |  | 4.3 |  |  |  | 13 | % |
| Total Net Revenue |  | $ | 148.1 |  |  | $ | 139.3 |  |  | $ | 8.8 |  |  |  | 6 | % |
| Gross Margin |  |  | 50.9 | % |  |  | 50.4 | % |  |  | 0.5 | % |  |  | 1 | % |
| Operating Margin |  |  | (5.0 | )% |  |  | (3.8 | )% |  |  | (1.2 | )% |  |  | (32 | )% |
| Net Loss |  | $ | (8.6 | ) |  | $ | (7.2 | ) |  | $ | (1.4 | ) |  |  | (20 | )% |
| Loss per basic share |  | $ | (0.08 | ) |  | $ | (0.07 | ) |  | $ | (0.01 | ) |  |  | (14 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 109.8 |  |  | $ | 105.4 |  |  | $ | 4.4 |  |  |  | 4 | % |
| Service |  |  | 38.3 |  |  |  | 34.3 |  |  |  | 4.0 |  |  |  | 12 | % |
| Total Net Revenue |  | $ | 148.1 |  |  | $ | 139.7 |  |  | $ | 8.4 |  |  |  | 6 | % |
| Gross Margin |  |  | 57.5 | % |  |  | 53.6 | % |  |  | 3.9 | % |  |  | 7 | % |
| Operating Margin |  |  | 9.4 | % |  |  | 7.8 | % |  |  | 1.6 | % |  |  | 21 | % |
| Net Income |  | $ | 12.7 |  |  | $ | 9.0 |  |  | $ | 3.7 |  |  |  | 41 | % |
| Earnings per diluted share |  | $ | 0.12 |  |  | $ | 0.09 |  |  | $ | 0.03 |  |  |  | 33 | % |

[0001564590-17-000835:8k_2_02:17]
|  | • | Cash and investments ended the quarter at $103.8 million, as compared to $102.3 million from the prior quarter and an increase of $17.9 million from the prior year. |

[0001564590-17-000835:8k_2_02:18]
|  | • | Accounts receivable balance ending Q2 was $117.8 million, with days sales outstanding (“DSO”) of 73. |

[0001564590-17-000835:8k_2_02:19]
|  | • | Inventory ending Q2 was $47.4 million, an increase of $4.0 million from the prior quarter and down $9.2 million from the prior year. |

[0001564590-17-000835:8k_2_02:20]
Business Outlook:

[0001564590-17-000835:8k_2_02:21]
For its third quarter of fiscal 2017 ending March 31, 2017, the Company is targeting revenue in a range of $151.0 million to $161.0 million.  GAAP gross margin is targeted between 53.4% and 54.5% and non-GAAP gross margin is targeted between 55.5% and 56.5%. Operating expenses are targeted to be between $90.3 million and $92.8 million on a GAAP basis and $74.9 million to $77.5 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $7.4 million to $12.0 million, or a loss of $0.07 to $0.11 per share.  Non-GAAP earnings are targeted in a range of net income of $6.6 million to $11.2 million, or $0.06 to $0.10 per diluted share. The GAAP and non-GAAP net income (loss) targets are based on an estimated 109.1 million and 110.6 million average outstanding shares, respectively.

[0001564590-17-000835:8k_2_02:22]
The following table shows the GAAP to non-GAAP reconciliation for Q3FY’17 guidance:

[0001564590-17-000835:8k_2_02:23]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 53.4% - 54.5% |  |  | (6.4)% - (3.2)% |  |  | $(0.11) - $(0.07) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles |  | 1.9% |  |  |  | 1.9% |  |  | $ | 0.03 |  |
| Stock based compensation |  | 0.3% |  |  |  | 2.4% |  |  | $ | 0.03 |  |
| Restructuring charge, net | - |  |  |  | 5.0% |  |  | $ | 0.07 |  |
| Amortization of non product intangibles | - |  |  |  | 0.8% |  |  | $ | 0.01 |  |
| Acquisition and integration costs | - |  |  |  | 2.3% |  |  | $ | 0.03 |  |
| Non-GAAP | 55.5% - 56.5% |  |  | 5.9% - 8.4% |  |  | $0.06 - $0.10 |  |

[0001564590-17-000835:8k_2_02:24]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-17-000835:8k_2_02:25]
Conference Call:

[0001564590-17-000835:8k_2_02:26]
Extreme will host a conference call at 4:30 p.m. Eastern (1:30 p.m. Pacific) today to review the second fiscal quarter results as well as the third fiscal quarter 2017 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through February 1, 2018.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406   Conference ID # 40315271.

[0001564590-17-000835:8k_2_02:27]
About Extreme Networks:

[0001564590-17-000835:8k_2_02:28]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, on premise or through the cloud, we go to extreme measures for our customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-17-000835:8k_2_02:29]
Extreme Networks and the Extreme Networks logo, ExtremeManagement, ExtremeWireless, ExtremeControl and ExtremeAnalytics are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-17-000835:8k_2_02:30]
Non-GAAP Financial Measures:

[0001564590-17-000835:8k_2_02:31]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, executive transition costs, litigation expenses and overhead adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's

[0001564590-17-000835:8k_2_02:32]
marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-17-000835:8k_2_02:33]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-17-000835:8k_2_02:34]
Forward Looking Statements:

[0001564590-17-000835:8k_2_02:35]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-17-000835:8k_2_02:36]
EXTREME NETWORKS, INC.

[0001564590-17-000835:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-17-000835:8k_2_02:38]
(In thousands)

[0001564590-17-000835:8k_2_02:39]
(Unaudited)

[0001564590-17-000835:8k_2_02:40]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 103,786 |  |  | $ | 94,122 |  |
| Accounts receivable, net of allowances of $2,451 at December 31, 2016 and $3,257 at June 30, 2016 |  |  | 117,819 |  |  |  | 81,419 |  |
| Inventories |  |  | 47,394 |  |  |  | 40,989 |  |
| Prepaid expenses and other current assets |  |  | 14,806 |  |  |  | 12,438 |  |
| Total current assets |  |  | 283,805 |  |  |  | 228,968 |  |
| Property and equipment, net |  |  | 30,599 |  |  |  | 29,580 |  |
| Intangible assets, net |  |  | 29,854 |  |  |  | 19,762 |  |
| Goodwill |  |  | 80,713 |  |  |  | 70,877 |  |
| Other assets |  |  | 25,026 |  |  |  | 25,236 |  |
| Total assets |  | $ | 449,997 |  |  | $ | 374,423 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 10,020 |  |  | $ | 17,628 |  |
| Accounts payable |  |  | 26,841 |  |  |  | 30,711 |  |
| Accrued compensation and benefits |  |  | 28,188 |  |  |  | 27,145 |  |
| Accrued warranty |  |  | 10,228 |  |  |  | 9,600 |  |
| Deferred revenue, net |  |  | 81,404 |  |  |  | 72,934 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  |  | 41,333 |  |  |  | 26,817 |  |
| Other accrued liabilities |  |  | 39,885 |  |  |  | 26,691 |  |
| Total current liabilities |  |  | 237,899 |  |  |  | 211,526 |  |
| Deferred revenue, less current portion |  |  | 24,519 |  |  |  | 21,926 |  |
| Long-term debt, less current portion |  |  | 87,127 |  |  |  | 37,446 |  |
| Deferred income taxes |  |  | 5,615 |  |  |  | 4,693 |  |
| Other long-term liabilities |  |  | 9,017 |  |  |  | 8,635 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Stockholders’ equity |  |  | 85,820 |  |  |  | 90,197 |  |
| Total liabilities and stockholders’ equity |  | $ | 449,997 |  |  | $ | 374,423 |  |

[0001564590-17-000835:8k_2_02:41]
EXTREME NETWORKS, INC.

[0001564590-17-000835:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-000835:8k_2_02:43]
(In thousands, except per share amounts)

[0001564590-17-000835:8k_2_02:44]
(Unaudited)

[0001564590-17-000835:8k_2_02:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 109,789 |  |  | $ | 105,355 |  |  | $ | 199,920 |  |  | $ | 196,736 |  |
| Service |  |  | 38,322 |  |  |  | 33,950 |  |  |  | 70,833 |  |  |  | 67,150 |  |
| Total net revenues |  |  | 148,111 |  |  |  | 139,305 |  |  |  | 270,753 |  |  |  | 263,886 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 58,659 |  |  |  | 57,103 |  |  |  | 103,586 |  |  |  | 104,037 |  |
| Service |  |  | 14,098 |  |  |  | 11,927 |  |  |  | 26,567 |  |  |  | 24,456 |  |
| Total cost of revenues |  |  | 72,757 |  |  |  | 69,030 |  |  |  | 130,153 |  |  |  | 128,493 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 51,130 |  |  |  | 48,252 |  |  |  | 96,334 |  |  |  | 92,699 |  |
| Service |  |  | 24,224 |  |  |  | 22,023 |  |  |  | 44,266 |  |  |  | 42,694 |  |
| Total gross profit |  |  | 75,354 |  |  |  | 70,275 |  |  |  | 140,600 |  |  |  | 135,393 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 24,013 |  |  |  | 20,716 |  |  |  | 42,312 |  |  |  | 40,984 |  |
| Sales and marketing |  |  | 41,109 |  |  |  | 37,058 |  |  |  | 78,065 |  |  |  | 73,120 |  |
| General and administrative |  |  | 9,397 |  |  |  | 9,775 |  |  |  | 17,684 |  |  |  | 18,951 |  |
| Acquisition and integration costs |  |  | 4,169 |  |  |  | 807 |  |  |  | 6,490 |  |  |  | 1,145 |  |
| Restructuring and related charges, net of reversals |  |  | 1,853 |  |  |  | 3,031 |  |  |  | 1,853 |  |  |  | 8,634 |  |
| Amortization of intangibles |  |  | 2,175 |  |  |  | 4,251 |  |  |  | 6,317 |  |  |  | 8,718 |  |
| Total operating expenses |  |  | 82,716 |  |  |  | 75,638 |  |  |  | 152,721 |  |  |  | 151,552 |  |
| Operating loss |  |  | (7,362 | ) |  |  | (5,363 | ) |  |  | (12,121 | ) |  |  | (16,159 | ) |
| Interest income |  |  | 81 |  |  |  | 29 |  |  |  | 138 |  |  |  | 56 |  |
| Interest expense |  |  | (1,176 | ) |  |  | (809 | ) |  |  | (1,823 | ) |  |  | (1,635 | ) |
| Other income (expense), net |  |  | 1,025 |  |  |  | 112 |  |  |  | 802 |  |  |  | 1,079 |  |
| Loss before income taxes |  |  | (7,432 | ) |  |  | (6,031 | ) |  |  | (13,004 | ) |  |  | (16,659 | ) |
| Provision for income taxes |  |  | 1,179 |  |  |  | 1,203 |  |  |  | 2,086 |  |  |  | 2,101 |  |
| Net loss |  | $ | (8,611 | ) |  | $ | (7,234 | ) |  | $ | (15,090 | ) |  | $ | (18,760 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.08 | ) |  | $ | (0.07 | ) |  | $ | (0.14 | ) |  | $ | (0.18 | ) |
| Net loss per share - diluted |  | $ | (0.08 | ) |  | $ | (0.07 | ) |  | $ | (0.14 | ) |  | $ | (0.18 | ) |
| Shares used in per share calculation - basic |  |  | 107,425 |  |  |  | 102,369 |  |  |  | 106,690 |  |  |  | 101,677 |  |
| Shares used in per share calculation - diluted |  |  | 107,425 |  |  |  | 102,369 |  |  |  | 106,690 |  |  |  | 101,677 |  |

[0001564590-17-000835:8k_2_02:46]
EXTREME NETWORKS, INC.

[0001564590-17-000835:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-17-000835:8k_2_02:48]
(In thousands)

[0001564590-17-000835:8k_2_02:49]
(Unaudited)

[0001564590-17-000835:8k_2_02:50]
|  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Net cash provided by operating activities |  | $ | 19,288 |  |  | $ | 13,967 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (4,662 | ) |  |  | (1,409 | ) |
| Acquisition |  |  | (51,088 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (55,750 | ) |  |  | (1,409 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | - |  |  |  | 15,000 |  |
| Borrowings under Term Loan |  |  | 48,250 |  |  |  |  |  |
| Loan fees on borrowings |  |  | (1,327 | ) |  |  |  |  |
| Repayment of debt |  |  | (5,513 | ) |  |  | (19,875 | ) |
| Proceeds from issuance of common stock |  |  | 4,831 |  |  |  | 2,330 |  |
| Net cash provided by (used in) financing activities |  |  | 46,241 |  |  |  | (2,545 | ) |
| Foreign currency effect on cash |  |  | (115 | ) |  |  | (373 | ) |
| Net increase in cash and cash equivalents |  |  | 9,664 |  |  |  | 9,640 |  |
| Cash and cash equivalents at beginning of period |  |  | 94,122 |  |  |  | 76,225 |  |
| Cash and cash equivalents at end of period |  | $ | 103,786 |  |  | $ | 85,865 |  |

[0001564590-17-000835:8k_2_02:51]
Extreme Networks, Inc.

[0001564590-17-000835:8k_2_02:52]
Non-GAAP Measures of Financial Performance

[0001564590-17-000835:8k_2_02:53]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-17-000835:8k_2_02:54]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of intangibles, restructuring expenses, executive transition expenses, litigation expense and overhead adjustments.

[0001564590-17-000835:8k_2_02:55]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-17-000835:8k_2_02:56]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-17-000835:8k_2_02:57]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustment, amortization of  intangibles, restructuring expenses,  executive transition costs, litigation expenses and overhead adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-17-000835:8k_2_02:58]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-17-000835:8k_2_02:59]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-17-000835:8k_2_02:60]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of Zebra Technologies Corporation’s wireless LAN business.   Extreme

[0001564590-17-000835:8k_2_02:61]
Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-17-000835:8k_2_02:62]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-17-000835:8k_2_02:63]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-17-000835:8k_2_02:64]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-17-000835:8k_2_02:65]
Restructuring expenses. Restructuring expenses primarily consist of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-17-000835:8k_2_02:66]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits and legal transition cash transactions.  The expenses are incurred through execution of pre-established employment contracts with senior executives.  The Company does not believe these expenses are reflective of ongoing cash requirements related to its operating results.

[0001564590-17-000835:8k_2_02:67]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matter as a result of a securities laws class action lawsuit.

[0001564590-17-000835:8k_2_02:68]
Overhead adjustments. Overhead adjustment relate to service inventory overhead capitalization, this was a one-time event and was non-cash in nature.

[0001564590-17-000835:8k_2_02:69]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-17-000835:8k_2_02:70]
EXTREME NETWORKS, INC.

[0001564590-17-000835:8k_2_02:71]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-17-000835:8k_2_02:72]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-17-000835:8k_2_02:73]
(In thousands, except per share amounts)

[0001564590-17-000835:8k_2_02:74]
(Unaudited)

[0001564590-17-000835:8k_2_02:75]
| Non-GAAP Revenue | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Revenue - GAAP Basis | $ | 148,111 |  |  | $ | 139,305 |  |  | $ | 270,753 |  |  | $ | 263,886 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 754 |  |
| Revenue - Non-GAAP Basis | $ | 148,111 |  |  | $ | 139,682 |  |  | $ | 270,886 |  |  | $ | 264,640 |  |

[0001564590-17-000835:8k_2_02:76]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Gross profit - GAAP Basis | $ | 75,354 |  |  | $ | 70,275 |  |  | $ | 140,600 |  |  | $ | 135,393 |  |
| Gross margin - GAAP Basis percentage |  | 50.9 | % |  |  | 50.4 | % |  |  | 51.9 | % |  |  | 51.3 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 308 |  |  |  | 554 |  |  |  | 608 |  |  |  | 1,216 |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 754 |  |
| Acquired inventory adjustments |  | 2,300 |  |  |  | - |  |  |  | 2,300 |  |  |  | - |  |
| Acquisition and integration costs |  | 5,517 |  |  |  | - |  |  |  | 5,517 |  |  |  | - |  |
| Amortization of intangibles |  | 1,719 |  |  |  | 3,708 |  |  |  | 5,136 |  |  |  | 8,000 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Gross profit - Non-GAAP Basis | $ | 85,198 |  |  | $ | 74,914 |  |  | $ | 154,294 |  |  | $ | 143,870 |  |
| Gross margin - Non-GAAP Basis percentage |  | 57.5 | % |  |  | 53.6 | % |  |  | 57.0 | % |  |  | 54.4 | % |

[0001564590-17-000835:8k_2_02:77]
| Non-GAAP Operating Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| GAAP operating loss | $ | (7,362 | ) |  | $ | (5,363 | ) |  | $ | (12,121 | ) |  | $ | (16,159 | ) |
| GAAP operating loss percentage |  | (5.0 | )% |  |  | (3.8 | )% |  |  | (4.5 | )% |  |  | (6.1 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,381 |  |  |  | 3,945 |  |  |  | 6,856 |  |  |  | 8,616 |  |
| Acquisition and integration costs |  | 9,686 |  |  |  | 807 |  |  |  | 12,007 |  |  |  | 1,145 |  |
| Restructuring charge, net of reversal |  | 1,853 |  |  |  | 3,031 |  |  |  | 1,853 |  |  |  | 8,634 |  |
| Acquired inventory adjustments |  | 2,300 |  |  |  | - |  |  |  | 2,300 |  |  |  | - |  |
| Amortization of intangibles |  | 3,894 |  |  |  | 7,959 |  |  |  | 11,453 |  |  |  | 16,718 |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 754 |  |
| Executive transition costs |  | - |  |  |  | - |  |  |  | 34 |  |  |  | - |  |
| Litigation |  | 236 |  |  |  | 79 |  |  |  | 263 |  |  |  | 79 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Total adjustments to GAAP operating loss | $ | 21,350 |  |  | $ | 16,198 |  |  | $ | 34,899 |  |  | $ | 34,453 |  |
| Non-GAAP operating income | $ | 13,988 |  |  | $ | 10,835 |  |  | $ | 22,778 |  |  | $ | 18,294 |  |
| Non-GAAP operating income percentage |  | 9.4 | % |  |  | 7.8 | % |  |  | 8.4 | % |  |  | 6.9 | % |

[0001564590-17-000835:8k_2_02:78]
| Non-GAAP Net Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| GAAP net loss | $ | (8,611 | ) |  | $ | (7,234 | ) |  | $ | (15,090 | ) |  | $ | (18,760 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 3,381 |  |  |  | 3,945 |  |  |  | 6,856 |  |  |  | 8,616 |  |
| Acquisition and integration costs |  | 9,686 |  |  |  | 807 |  |  |  | 12,007 |  |  |  | 1,145 |  |
| Restructuring charge, net of reversal |  | 1,853 |  |  |  | 3,031 |  |  |  | 1,853 |  |  |  | 8,634 |  |
| Amortization of intangibles |  | 3,894 |  |  |  | 7,959 |  |  |  | 11,453 |  |  |  | 16,718 |  |
| Acquired inventory adjustments |  | 2,300 |  |  |  | - |  |  |  | 2,300 |  |  |  | - |  |
| Purchase accounting adjustments |  | - |  |  |  | 377 |  |  |  | 133 |  |  |  | 754 |  |
| Executive transition costs |  | - |  |  |  | - |  |  |  | 34 |  |  |  | - |  |
| Litigation |  | 236 |  |  |  | 79 |  |  |  | 263 |  |  |  | 79 |  |
| Service inventory overhead capitalization |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,493 | ) |
| Total adjustments to GAAP net loss | $ | 21,350 |  |  | $ | 16,198 |  |  | $ | 34,899 |  |  | $ | 34,453 |  |
| Non-GAAP net income | $ | 12,739 |  |  | $ | 8,964 |  |  | $ | 19,809 |  |  | $ | 15,693 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP diluted net income per share | $ | 0.12 |  |  | $ | 0.09 |  |  | $ | 0.18 |  |  | $ | 0.15 |  |
| Shares used in diluted net income per share calculation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 110,152 |  |  |  | 105,087 |  |  |  | 109,394 |  |  |  | 103,997 |  |

[0001564590-17-000835:8k_2_02:79]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Cash flow provided by operations | $ | 9,713 |  |  | $ | 7,441 |  |  | $ | 19,288 |  |  | $ | 13,967 |  |
| Less: PP&E CapEx spending |  | (3,027 | ) |  | $ | (776 | ) |  |  | (4,662 | ) |  |  | (1,409 | ) |
| Total free cash flow | $ | 6,686 |  |  | $ | 6,665 |  |  | $ | 14,626 |  |  | $ | 12,558 |  |
