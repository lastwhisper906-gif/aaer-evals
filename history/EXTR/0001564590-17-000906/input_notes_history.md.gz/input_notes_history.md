# EXTR note change history — 0001564590-16-027054 → 0001564590-17-000906


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-02):
[0001564590-17-000906:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2016, the Company had non-cancelable commitments to purchase $93.6 million of such inventory.  As of December 31, 2016 the Company had non-cancelable software and maintenance support commitments to purchase $24.2 of software and support services.
  (was, 2016-11-02, similarity 0.8936):
[0001564590-16-027054:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2016, the Company had non-cancelable commitments to purchase $70.6 million of such inventory.

- added (2017-02-02):
[0001564590-17-000906:note_history:2]
Brazilian Tax Assessment Matters

- changed (2017-02-02):
[0001564590-17-000906:note_history:3]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of December 31, 2016.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.0 million), plus interest and penalties BRL 17.7 million (US $5.4 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.
  (was, 2016-11-02, similarity 0.9882):
[0001564590-16-027054:note_history:3]
Brazilian Tax Assessment Matters                                                                                                                                                   Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of September 30, 2016.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.1 million), plus interest and penalties BRL 17.5 million (US $5.4 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

- changed (2017-02-02):
[0001564590-17-000906:note_history:4]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint. On November 10, 2016 defendants filed a motion to dismiss.  The motion is scheduled to be heard, after completion of the briefing, on February 9, 2017.   The Company believes the claims are without merit and intends to vigorously defend the claims.
  (was, 2016-11-02, similarity 0.8194):
[0001564590-16-027054:note_history:4]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint, which the defendants will move to dismiss.  The Company believes the claims are without merit and intends to vigorously defend the claims.

- changed (2017-02-02):
[0001564590-17-000906:note_history:5]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation to that effect.
  (was, 2016-11-02, similarity 0.9123):
[0001564590-16-027054:note_history:5]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and have submitted a stipulation to that effect to the court.

- changed (2017-02-02):
[0001564590-17-000906:note_history:6]
Dunti Network Technologies, LLC v Extreme Networks, Inc. Patent Infringement Suit
  (was, 2016-11-02, similarity 0.9877):
[0001564590-16-027054:note_history:6]
Dunti Network Technoligies, LLC v Extreme Networks, Inc. Patent Infringement Suit

- changed (2017-02-02):
[0001564590-17-000906:note_history:7]
On September 22, 2016, the Company was served with a patent infringement complaint by Dunti Network Technologies, LLC in the U.S. District Court for the Eastern District of Texas.  The case is Dunti Network Technologies, LLC v. Extreme Networks, Inc., No. 2:16-cv-01034.  The complaint asserts infringement of U.S. Patent Nos. 6,587,462, 6,788,701, 6,804,235, 6,643,286, and 7,778,259.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s BlackDiamond-X, Summit X670, and Summit X770 series switches.  Dunti sought damages of an unspecified amount.  Dunti moved to dismiss the case and the case against the Company was dismissed by the court as of December 27, 2016.
  (was, 2016-11-02, similarity 0.7611):
[0001564590-16-027054:note_history:7]
On September 22, 2016, the Company was served with a patent infringement complaint by Dunti Network Technologies, LLC in the U.S. District Court for the Eastern District of Texas.  The case is Dunti Network Technologies, LLC v. Extreme Networks, Inc., No. 2:16-cv-01034.  The complaint asserts infringement of U.S. Patent Nos. 6,587,462, 6,788,701, 6,804,235, 6,643,286, and 7,778,259.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s BlackDiamond-X, Summit X670, and Summit X770 series switches.  Dunti seeks damages of an unspecified amount.  The Company’s answer to the complaint is presently due November 14, 2016.  The Company believes the claims are without merit and intends to defend itself vigorously against the claims.

- changed (2017-02-02):
[0001564590-17-000906:note_history:8]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of December 31, 2016, the Company had no outstanding indemnification claims.
  (was, 2016-11-02, similarity 0.9967):
[0001564590-16-027054:note_history:8]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of September 30, 2016, the Company had no outstanding indemnification claims.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-02):
[0001564590-17-000906:note_history:9]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2016  The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.
  (was, 2016-11-02, similarity 0.775):
[0001564590-16-027054:note_history:9]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2016  The results of operations for the three months ended September 30, 2016 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.

- changed (2017-02-02):
[0001564590-17-000906:note_history:10]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ from these estimates.
  (was, 2016-11-02, similarity 0.9931):
[0001564590-16-027054:note_history:10]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-02):
[0001564590-17-000906:note_history:11]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual Report on Form 10-K for the fiscal year ended June 30, 2016. Except for the following policy, there have been no material changes to the Company's significant accounting policies since the filing of the Annual Report on Form 10-K.
  (was, 2016-11-02, similarity 0.9575):
[0001564590-16-027054:note_history:11]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual Report on Form 10-K for the fiscal year ended June 30, 2016. There have been no material changes to the Company's significant accounting policies since the filing of the Annual Report on Form 10-K.

- added (2017-02-02):
[0001564590-17-000906:note_history:12]
Business Combinations

- added (2017-02-02):
[0001564590-17-000906:note_history:13]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-02):
[0001564590-17-000906:note_history:14]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 10,020 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 10,020 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 77,127 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 87,127 |  |  |  | 37,446 |  |
| Total debt |  | $ | 97,147 |  |  | $ | 55,074 |  |
  (was, 2016-11-02, similarity 0.992):
[0001564590-16-027054:note_history:14]
|  |  | September 30, 2016 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,269 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 19,269 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,621 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 32,621 |  |  |  | 37,446 |  |
| Total debt |  | $ | 51,890 |  |  | $ | 55,074 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-02-02):
[0001564590-17-000906:note_history:15]
On January 5, 2017, Extreme Networks, Inc. (the "Company") approved and on January 6, 2017 began executing a reduction-in-force plan (the ”Plan”) to re-align the Company’s resources as a result of the Company’s purchase of the wireless LAN business of Zebra Technologies Corporation. The Company expects to incur charges of approximately $6.5 million and affected employees worldwide and all functional areas. Upon completion of the Plan, the potential savings is expected to yield annualized savings of approximately $8.0 million. The costs associated with this Plan are primarily employee severance and benefits expenses.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.

- removed (2017-02-02):
[0001564590-16-027054:note_history:16]
On September 13, 2016, the Company entered into an Asset Purchase Agreement (the “Purchase”) with Zebra Technologies Corporation, a Delaware corporation (“Zebra”), to purchase Zebra’s wireless LAN business (the “Business”).  Under the terms of the Purchase, the Company acquired customers, employees, technology and other assets of the Business, as well as assumed certain contracts and other liabilities of the Business, for a cash purchase price of approximately $55.0 million, subject to certain adjustments related to net working capital and deferred revenue of the Business on October 28, 2016 (the “Closing”).  Pursuant to certain ancillary agreements, Zebra will also provide the Company with access to certain technology related to the Business, as well as transition services for a period of time following the Closing.

- removed (2017-02-02):
[0001564590-16-027054:note_history:17]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Business will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Business will be included in the operations of the Company beginning with the Closing.

- removed (2017-02-02):
[0001564590-16-027054:note_history:18]
The Company expects to include a preliminary determination of the acquisition consideration and detail of the assets acquired and liabilities assumed in the Company’s consolidated financial statements for the quarter ending December 31, 2016.

- removed (2017-02-02):
[0001564590-16-027054:note_history:19]
During the three months ended September 30, 2016, the Company recognized transaction costs of $2.3 million which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

- removed (2017-02-02):
[0001564590-16-027054:note_history:20]
Borrowing Facility

- removed (2017-02-02):
[0001564590-16-027054:note_history:21]
Commensurate with the Closing, the Company entered into an Amended and Restated Credit Agreement (the “Credit Agreement”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Agreement provides for a five-year $90.5 million term loan and a five-year $50.0 million revolving credit facility, which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Agreement among other things, amends and restates the Company’s existing credit facility.  At the Closing, the Company incurred $100.5 million of indebtedness to pay off existing debt and to finance the acquisition of the Business.  Borrowings under the term loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on our consolidated leverage ratio).  Borrowings under the revolving credit facility bear interest, at the Company’s option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the prime lending rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The revolving credit facility has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.  The Credit Agreement is collateralized by substantially all assets of the Company.
