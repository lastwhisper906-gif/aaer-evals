# EXTR notes — 0001564590-17-000906


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-17-000906:notes:1]
[same as prior period, unchanged from 0001564590-16-027054:notes:1]

[0001564590-17-000906:notes:2]
[same as prior period, unchanged from 0001564590-16-027054:notes:2]

[0001564590-17-000906:notes:3]
[same as prior period, unchanged from 0001564590-16-027054:notes:3]

[0001564590-17-000906:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2016  The results of operations for the three and six months ended December 31, 2015 are not necessarily indicative of the results that may be expected for fiscal 2017 or any future periods.

[0001564590-17-000906:notes:5]
[same as prior period, unchanged from 0001564590-16-027054:notes:5]

[0001564590-17-000906:notes:6]
[same as prior period, unchanged from 0001564590-16-027054:notes:6]

[0001564590-17-000906:notes:7]
[same as prior period, unchanged from 0001564590-16-027054:notes:7]

[0001564590-17-000906:notes:8]
[same as prior period, unchanged from 0001564590-16-027054:notes:8]

[0001564590-17-000906:notes:9]
[same as prior period, unchanged from 0001564590-16-027054:notes:9]

[0001564590-17-000906:notes:10]
[same as prior period, unchanged from 0001564590-16-027054:notes:10]

[0001564590-17-000906:notes:11]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ from these estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-17-000906:notes:12]
2. Business Combinations

[0001564590-17-000906:notes:13]
On October 28, 2016 (the “Acquisition Date”), the Company completed the acquisition of Zebra Technologies Corporation’s (“Zebra”) wireless LAN assets (the “WLAN Business”).  Under the terms of the purchase agreement, the Company acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for cash consideration of $51.1 million.  The purchase price consideration is provisional as it is still pending finalization of post close adjustments as defined in the purchase agreement.  All accounts noted above are “preliminary” to the table below as all accounts are open.

[0001564590-17-000906:notes:14]
The acquisition has been accounted for using the acquisition method of accounting.  The provisional purchase price has been allocated on a preliminary basis to tangible and intangible assets acquired and liabilities assumed.  The final purchase price allocation is pending the finalization of valuations, which may result in an adjustment to the preliminary purchase price allocation. Also, additional information which existed as of the acquisition date, but was unknown to the Company at that time, may become known to the Company during the remainder of the measurement period (up to one year from the acquisition date), and may result in a change in the purchase price allocation.  While management believes that its preliminary estimates and assumptions underlying the valuations are reasonable, different estimates and assumptions could result in different valuations assigned to the individual assets acquired and liabilities assumed, and the resulting amount of goodwill.

[0001564590-17-000906:notes:15]
The following table below summarizes the allocation as of December 31, 2016 of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-17-000906:notes:16]
|  |  | December 31, 2016 |  |
| Receivables |  | $ | 17,818 |  |
| Inventory |  |  | 12,408 |  |
| Other current assets |  |  | 808 |  |
| Property and equipment |  |  | 1,780 |  |
| Identifiable intangible assets |  |  | 20,500 |  |
| In-process research and development |  |  | 1,600 |  |
| Other assets |  |  | 7,634 |  |
| Goodwill |  |  | 9,836 |  |
| Current liabilities |  |  | (7,763 | ) |
| Deferred revenue |  |  | (13,533 | ) |
| Total purchase price allocation |  | $ | 51,088 |  |

[0001564590-17-000906:notes:17]
The estimated purchase price has been allocated based on the preliminary estimates of the fair value of assets acquired and liabilities assumed as of the acquisition date. The fair value of working capital related items, such as accounts receivable, other current assets and accrued liabilities, approximated their book values at the date of acquisition. Inventories were valued at fair value using the net realizable value approach.   The fair value of property and equipment was determined using a cost approach. Valuations of the intangible assets were valued using income approaches based on projections provided by management, which we consider to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of these Assets which may ultimately impact the overall level of goodwill associated with the acquisition.

[0001564590-17-000906:notes:18]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001564590-17-000906:notes:19]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |  |
| Developed technology |  | 6 |  | $ | 14,500 |  |
| Customer relationships |  | 4 |  |  | 3,400 |  |
| Trademarks |  | 5 |  |  | 2,600 |  |
| Total identifiable intangible assets |  |  |  | $ | 20,500 |  |

[0001564590-17-000906:notes:20]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the condensed consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the WLAN Business.  The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001564590-17-000906:notes:21]
The Company also has an indefinite lived asset of $1.6 million which represents the fair value of in-process research and development activities.  Once the related research and development efforts are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or is become a finite lived asset and apply the appropriate accounting accordingly.

[0001564590-17-000906:notes:22]
The results of operations of the WLAN Business are included in the consolidated results of operations beginning October 28, 2016.  The Company incurred $6.5 million acquisition-related expenses of which $4.2 million was incurred in the three months ended December 31, 2016.  Such acquisition-related costs are included in "Acquisition and integration costs" on the condensed consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants and companies.

[0001564590-17-000906:notes:23]
Pro forma financial information

[0001564590-17-000906:notes:24]
The following unaudited pro forma results of operations are presented as though the acquisition of the WLAN Business had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, interest income and expense and related tax effects. The pro forma results of operations do not reflect the impact of non-recurring charges that have resulted from or in connection with the acquisition including acquisition and integration expenses incurred in connection with the acquisition.

[0001564590-17-000906:notes:25]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the earliest period presented, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-17-000906:notes:26]
The unaudited pro forma financial information for the three months ended December 31, 2016 combines the results of Extreme for the three months ended December 31, 2016, which include the results of the WLAN Business subsequent to the acquisition date, and the historical results of the WLAN Business for the month ended October 28, 2016.

[0001564590-17-000906:notes:27]
The unaudited pro forma financial information for the six months ended December 31, 2016 combines the results for Extreme for the six months ended December 31, 2016, which include the results of the WLAN Business subsequent to the acquisition date, and the historical results of the WLAN Business for the three months ended September 30, 2016 and the month ended October 28, 2016.

[0001564590-17-000906:notes:28]
The unaudited pro forma financial information for the three and six months ended December 31, 2015 combines the historical results for Extreme for those periods, with the historical results of the WLAN Business for the three and six months ended December 31, 2015.

[0001564590-17-000906:notes:29]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0001564590-17-000906:notes:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Net revenues |  | $ | 158,929 |  |  | $ | 174,679 |  |  | $ | 314,025 |  |  | $ | 330,665 |  |
| Net income (loss) |  | $ | 3,920 |  |  | $ | (12,006 | ) |  | $ | (4,786 | ) |  | $ | (41,509 | ) |
| Net earnings (loss) per share - basic |  | $ | 0.04 |  |  | $ | (0.12 | ) |  | $ | (0.04 | ) |  | $ | (0.41 | ) |
| Net earnings (loss) per share - diluted |  | $ | 0.04 |  |  | $ | (0.12 | ) |  | $ | (0.04 | ) |  | $ | (0.41 | ) |
| Shares used in per share calculation - basic |  |  | 107,425 |  |  |  | 102,369 |  |  |  | 106,690 |  |  |  | 101,677 |  |
| Shares used in per share calculation - diluted |  |  | 110,152 |  |  |  | 102,369 |  |  |  | 106,690 |  |  |  | 101,677 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-17-000906:notes:31]
| 3. | Summary of Significant Accounting Policies |

[0001564590-17-000906:notes:32]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company's Annual Report on Form 10-K for the fiscal year ended June 30, 2016. Except for the following policy, there have been no material changes to the Company's significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-17-000906:notes:33]
Business Combinations

[0001564590-17-000906:notes:34]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items.  Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill.  Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.  As a result, during the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to the Company's consolidated statements of operations.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-17-000906:notes:35]
| 4. | Recent Accounting Pronouncements |

[0001564590-17-000906:notes:36]
Recently Adopted Accounting Pronouncements

[0001564590-17-000906:notes:37]
In March 2016, the FASB issued Accounting Standards Update (“ASU”) 2016-09, Compensation – Stock Compensation (“ASU 2016-09”) which identifies areas for simplification involving several aspects of accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, an option to recognize gross stock compensation expense with actual forfeitures recognized as they occur, as well as certain classifications on the statement of cash flows.  The Company early adopted this standard beginning with its fiscal year 2017. The impact of the adoption had the following impacts:

[0001564590-17-000906:notes:38]
|  | • | In recording share-based compensation expense, the standard allows companies to make a policy election as to whether they will include an estimate of awards expected to be forfeited or whether they will account for forfeitures as they occur. The Company has elected to not include an estimated forfeiture rate in the computation of its share-based compensation expense. This election did not have a material impact on the Company’s condensed consolidated financial statements and accordingly no adjustment was made to beginning accumulated deficit to apply the modified retrospective method. |

[0001564590-17-000906:notes:39]
|  | • | The standard requires that employee taxes paid when an employer withholds shares for tax-withholding purposes be reported as financing activities in the consolidated statements of cash flows. Previously, the Company included these cash flows in financing activities and therefore the adoption of this provision had no impact. |

[0001564590-17-000906:notes:40]
|  | • | The new standard requires that the tax effects of share-based compensation be recognized in the income tax provision. Previously, these amounts were recognized in additional paid-in capital. Given the full valuation allowance against the US deferred tax assets, there will be no impact to the effective tax rate until such time as the valuation allowance may be reversed. |

[0001564590-17-000906:notes:41]
|  | • | The standard also requires previously unrecognized excess tax benefits to be recognized on a modified retrospective basis. Unrecognized tax benefits result when a deduction for stock based compensation does not actually reduce taxes payable. The Company has recorded $13.5 million and $0.9 million of previously unrecorded deferred tax assets for federal and state net operating losses, respectively, with a corresponding increase to the valuation allowance pursuant to the evidence discussed in Note 9. The cumulative net impact to accumulated deficit of early adoption of this provision was therefore zero. |

[0001564590-17-000906:notes:42]
|  | • | ASU 2016-09 also requires excess tax benefits to be presented as an operating activity on the statement of cash flows rather than as a financing activity on either a retrospective or prospective basis. The Company has elected to apply this provision of the standard on a prospective basis. |

[0001564590-17-000906:notes:43]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs (“ASU 2015-03”),  which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts.  ASU 2015-03 requires retrospective adoption and will be effective for annual and interim periods in fiscal years beginning after December 15, 2015.  This guidance became effective for the Company beginning with its fiscal year 2017.

[0001564590-17-000906:notes:44]
In connection with the Company’s adoption of ASU 2015-03 in fiscal 2017, all debt issuance costs have been presented, with the exception of those related to the revolving credit facility, as a reduction of the carrying amount of the related debt liability.  The previously reported balances in the Company’s June 30, 2016 Form 10-K for debt issuance costs listed in “Other assets” have been reclassified to “Current portion of long-term debt” in the amount of $0.2 million and “Long-term debt, less current portion” in the amount of $0.2 million to conform to the December 31, 2016 presentation.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-17-000906:notes:45]
| 5. | Balance Sheet Accounts |

[0001564590-17-000906:notes:46]
[same as prior period, unchanged from 0001564590-16-027054:notes:25]

[0001564590-17-000906:notes:47]
[same as prior period, unchanged from 0001564590-16-027054:notes:26]

[0001564590-17-000906:notes:48]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Cash |  | $ | 99,506 |  |  | $ | 89,847 |  |
| Cash equivalents |  |  | 4,280 |  |  |  | 4,275 |  |
| Total cash and cash equivalents |  | $ | 103,786 |  |  | $ | 94,122 |  |

[0001564590-17-000906:notes:49]
[same as prior period, unchanged from 0001564590-16-027054:notes:28]

[0001564590-17-000906:notes:50]
[same as prior period, unchanged from 0001564590-16-027054:notes:29]

[0001564590-17-000906:notes:51]
The Company’s inventory balances as of December 31, 2016 and June 30, 2016 were $47.4 million and $41.0 million, respectively. The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001564590-17-000906:notes:52]
Inventory consists of the following (in thousands):

[0001564590-17-000906:notes:53]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Finished goods |  | $ | 45,679 |  |  | $ | 38,751 |  |
| Raw materials |  |  | 1,715 |  |  |  | 2,238 |  |
| Total Inventory |  | $ | 47,394 |  |  | $ | 40,989 |  |

[0001564590-17-000906:notes:54]
[same as prior period, unchanged from 0001564590-16-027054:notes:33]

[0001564590-17-000906:notes:55]
[same as prior period, unchanged from 0001564590-16-027054:notes:34]

[0001564590-17-000906:notes:56]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Computer equipment |  | $ | 35,547 |  |  | $ | 34,657 |  |
| Purchased software |  |  | 10,013 |  |  |  | 5,574 |  |
| Office equipment, furniture and fixtures |  |  | 10,302 |  |  |  | 10,385 |  |
| Leasehold improvements |  |  | 21,601 |  |  |  | 19,342 |  |
| Total property and equipment |  |  | 77,463 |  |  |  | 69,958 |  |
| Less: accumulated depreciation and amortization |  |  | (46,864 | ) |  |  | (40,378 | ) |
| Property and equipment, net |  | $ | 30,599 |  |  | $ | 29,580 |  |

[0001564590-17-000906:notes:57]
[same as prior period, unchanged from 0001564590-16-027054:notes:36]

[0001564590-17-000906:notes:58]
[same as prior period, unchanged from 0001564590-16-027054:notes:37]

[0001564590-17-000906:notes:59]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 5.69 years |  | $ | 55,500 |  |  | $ | 41,165 |  |  | $ | 14,335 |  |
| Customer relationships |  | 3.84 years |  |  | 40,400 |  |  |  | 37,142 |  |  |  | 3,258 |  |
| Maintenance contracts |  | 1.84 years |  |  | 17,000 |  |  |  | 10,767 |  |  |  | 6,233 |  |
| Trademarks |  | 4.84 years |  |  | 5,100 |  |  |  | 2,586 |  |  |  | 2,514 |  |
| License agreements |  | 6.80 years |  |  | 2,445 |  |  |  | 984 |  |  |  | 1,461 |  |
| Other intangibles |  | 3.20 years |  |  | 1,382 |  |  |  | 929 |  |  |  | 453 |  |
| Total intangibles, net with finite lives |  |  |  |  | 121,827 |  |  |  | 93,573 |  |  |  | 28,254 |  |
| In-process research and development, with indefinite life |  |  |  |  | 1,600 |  |  |  | - |  |  |  | 1,600 |  |
| Total intangibles, net |  |  |  | $ | 123,427 |  |  | $ | 93,573 |  |  | $ | 29,854 |  |

[0001564590-17-000906:notes:60]
[same as prior period, unchanged from 0001564590-16-027054:notes:39]

[0001564590-17-000906:notes:61]
The amortization expense of intangibles for the periods presented is summarized below (in thousands):

[0001564590-17-000906:notes:62]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Amortization in "Cost of revenues: Product" |  | $ | 1,720 |  |  | $ | 3,852 |  |  | $ | 5,276 |  |  | $ | 8,276 |  |
| Amortization of intangibles |  |  | 2,175 |  |  |  | 4,251 |  |  |  | 6,317 |  |  |  | 8,718 |  |
| Total amortization |  | $ | 3,895 |  |  | $ | 8,103 |  |  | $ | 11,593 |  |  | $ | 16,994 |  |

[0001564590-17-000906:notes:63]
[same as prior period, unchanged from 0001564590-16-027054:notes:42]

[0001564590-17-000906:notes:64]
[same as prior period, unchanged from 0001564590-16-027054:notes:43]

[0001564590-17-000906:notes:65]
[same as prior period, unchanged from 0001564590-16-027054:notes:44]

[0001564590-17-000906:notes:66]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Balance at beginning of period |  | $ | 70,877 |  |  | $ | 70,877 |  |
| Additions during period |  |  | 9,836 |  |  |  | — |  |
| Balance at end of period |  | $ | 80,713 |  |  | $ | 70,877 |  |

[0001564590-17-000906:notes:67]
During the three months ended December 31, 2016, the Company completed the acquisition of certain assets and liabilities from Zebra resulting in an additional $9.8 million of goodwill.  See Note 2 for additional information related to the acquisition.

[0001564590-17-000906:notes:68]
[same as prior period, unchanged from 0001564590-16-027054:notes:49]

[0001564590-17-000906:notes:69]
[same as prior period, unchanged from 0001564590-16-027054:notes:50]

[0001564590-17-000906:notes:70]
[same as prior period, unchanged from 0001564590-16-027054:notes:51]

[0001564590-17-000906:notes:71]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Deferred maintenance |  | $ | 84,595 |  |  | $ | 83,419 |  |
| Deferred maintenance assumed due to acquisition |  |  | 13,533 |  |  |  | - |  |
| Deferred product and other revenue |  |  | 7,795 |  |  |  | 11,441 |  |
| Total deferred revenue, net |  |  | 105,923 |  |  |  | 94,860 |  |
| Less: current portion |  |  | 81,404 |  |  |  | 72,934 |  |
| Non-current deferred revenue, net |  | $ | 24,519 |  |  | $ | 21,926 |  |

[0001564590-17-000906:notes:72]
[same as prior period, unchanged from 0001564590-16-027054:notes:53]

[0001564590-17-000906:notes:73]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Balance beginning of period |  | $ | 84,334 |  |  | $ | 85,255 |  |  | $ | 83,419 |  |  | $ | 87,441 |  |
| Deferred maintenance assumed due to acquisition |  |  | 13,533 |  |  |  | - |  |  |  | 13,533 |  |  |  | - |  |
| New maintenance arrangements |  |  | 33,765 |  |  |  | 29,773 |  |  |  | 62,510 |  |  |  | 56,819 |  |
| Recognition of maintenance revenue |  |  | (33,504 | ) |  |  | (30,322 | ) |  |  | (61,334 | ) |  |  | (59,554 | ) |
| Balance end of period |  |  | 98,128 |  |  |  | 84,706 |  |  |  | 98,128 |  |  |  | 84,706 |  |
| Less: current portion |  |  | 73,609 |  |  |  | 63,201 |  |  |  | 73,609 |  |  |  | 63,201 |  |
| Non-current deferred revenue |  | $ | 24,519 |  |  | $ | 21,505 |  |  | $ | 24,519 |  |  | $ | 21,505 |  |

[0001564590-17-000906:notes:74]
[same as prior period, unchanged from 0001564590-16-027054:notes:55]

[0001564590-17-000906:notes:75]
The Company records revenue from its stocking distributors on a sell-through basis, recording deferred revenue and deferred cost of sales associated with all sales transactions to these distributors in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its condensed consolidated balance sheets. The amount shown as “Deferred distributors’ revenue, net of cost of sales to distributors” represents the deferred gross profit on sales to distributors based on contractual pricing.

[0001564590-17-000906:notes:76]
[same as prior period, unchanged from 0001564590-16-027054:notes:57]

[0001564590-17-000906:notes:77]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Deferred distributors revenue |  | $ | 54,471 |  |  | $ | 35,138 |  |
| Deferred cost of sales to distributors |  |  | (13,138 | ) |  |  | (8,321 | ) |
| Deferred distributors revenue, net of cost of sales to distributors |  | $ | 41,333 |  |  | $ | 26,817 |  |

[0001564590-17-000906:notes:78]
[same as prior period, unchanged from 0001564590-16-027054:notes:59]

[0001564590-17-000906:notes:79]
[same as prior period, unchanged from 0001564590-16-027054:notes:60]

[0001564590-17-000906:notes:80]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 10,020 |  |  | $ | 17,628 |  |
| Current portion of long-term debt |  | $ | 10,020 |  |  | $ | 17,628 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 77,127 |  |  | $ | 27,446 |  |
| Revolving Facility |  |  | 10,000 |  |  |  | 10,000 |  |
| Total long-term debt, less current portion |  |  | 87,127 |  |  |  | 37,446 |  |
| Total debt |  | $ | 97,147 |  |  | $ | 55,074 |  |

[0001564590-17-000906:notes:81]
During the three months ended December 31, 2016, the Company entered into an Amended and Restated Credit Agreement (the “Credit Facility, as amended”) with Silicon Valley Bank, JPMorgan Chase Bank, N.A., Bank of America, N.A., Cadence Bank, N.A., and Comerica Bank (collectively, the “Lenders”).  The Credit Facility, as amended provides for a five-year $90.5 million term loan (“Term Loan”) and a five-year $50.0 million revolving credit facility (“Revolver”), which includes a $5.0 million swing line loan sub facility and a $10.0 million letter of credit sub facility.  The Credit Facility, as amended among other things, amends and restates the Company’s existing credit facility.  The Credit Facility, as amended is collateralized by substantially all of the assets of the Company.

[0001564590-17-000906:notes:82]
Borrowings under the Term Loan bear interest, at our option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on our consolidated leverage ratio).  Borrowings under the Revolver bear interest, at the Company’s option, at a rate equal to either the LIBOR rate (subject to a 0.0% LIBOR floor), plus an applicable margin (currently 3.25% per annum based on a stated consolidated leverage ratio) or the adjusted base rate, plus an applicable margin (currently 1.25% per annum based on a stated consolidated leverage ratio).  The Revolver has a commitment fee payable on the undrawn amount ranging from 0.375% to 0.50% per annum based upon a stated consolidated leverage ratio.

[0001564590-17-000906:notes:83]
The Company had $23.7 million of availability under the Revolver as of December 31, 2016.  The Company had $0.9 million of outstanding letters of credit under the Revolver as of December 31, 2016.

[0001564590-17-000906:notes:84]
[same as prior period, unchanged from 0001564590-16-027054:notes:66]

[0001564590-17-000906:notes:85]
[same as prior period, unchanged from 0001564590-16-027054:notes:67]

[0001564590-17-000906:notes:86]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three months ended December 31, 2016 and 2015 (in thousands):

[0001564590-17-000906:notes:87]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Balance beginning of period |  | $ | 8,620 |  |  | $ | 9,244 |  |  | $ | 9,600 |  |  | $ | 8,676 |  |
| Warranties assumed due to acquisition |  |  | 2,034 |  |  |  | - |  |  |  | 2,034 |  |  |  | - |  |
| New warranties issued |  |  | 1,176 |  |  |  | 2,956 |  |  |  | 2,104 |  |  |  | 5,520 |  |
| Warranty expenditures |  |  | (1,602 | ) |  |  | (1,785 | ) |  |  | (3,510 | ) |  |  | (3,781 | ) |
| Balance end of period |  | $ | 10,228 |  |  | $ | 10,415 |  |  | $ | 10,228 |  |  | $ | 10,415 |  |

[0001564590-17-000906:notes:88]
[same as prior period, unchanged from 0001564590-16-027054:notes:70]

[0001564590-17-000906:notes:89]
[same as prior period, unchanged from 0001564590-16-027054:notes:71]

[0001564590-17-000906:notes:90]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue. All other advertising costs are expensed as incurred.  Advertising expenses for three and six months ended December 31, 2016 and 2015, were immaterial.

[0001564590-17-000906:notes:91]
[same as prior period, unchanged from 0001564590-16-027054:notes:73]

[0001564590-17-000906:notes:92]
[same as prior period, unchanged from 0001564590-16-027054:notes:74]

[0001564590-17-000906:notes:93]
[same as prior period, unchanged from 0001564590-16-027054:notes:75]

[0001564590-17-000906:notes:94]
[same as prior period, unchanged from 0001564590-16-027054:notes:76]

[0001564590-17-000906:notes:95]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Tech Data Corporation |  |  | 16% |  |  |  | 19% |  |  |  | 16% |  |  |  | 16% |  |
| Jenne |  |  | 14% |  |  |  | 12% |  |  |  | 15% |  |  |  | 11% |  |
| Westcon Group Inc. |  |  | 13% |  |  |  | 14% |  |  |  | 12% |  |  |  | 15% |  |
| Avnet |  | * |  |  | * |  |  |  | 11% |  |  | * |  |

[0001564590-17-000906:notes:96]
[same as prior period, unchanged from 0001564590-16-027054:notes:78]

[0001564590-17-000906:notes:97]
The following customers account for more than 10% of our accounts receivable outstanding as of December 31, 2016, Westcon Group Inc. 17% and Tech Data Corporation 11%.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-17-000906:notes:98]
| 6. | Fair Value Measurements |

[0001564590-17-000906:notes:99]
[same as prior period, unchanged from 0001564590-16-027054:notes:81]

[0001564590-17-000906:notes:100]
[same as prior period, unchanged from 0001564590-16-027054:notes:82]

[0001564590-17-000906:notes:101]
[same as prior period, unchanged from 0001564590-16-027054:notes:83]

[0001564590-17-000906:notes:102]
[same as prior period, unchanged from 0001564590-16-027054:notes:84]

[0001564590-17-000906:notes:103]
[same as prior period, unchanged from 0001564590-16-027054:notes:85]

[0001564590-17-000906:notes:104]
| December 31, 2016 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,280 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,280 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency contracts |  |  |  |  |  |  | (43 | ) |  |  |  |  |  | $ | (43 | ) |
| Total |  | $ | 4,280 |  |  | $ | (43 | ) |  | $ | - |  |  | $ | 4,237 |  |

[0001564590-17-000906:notes:105]
[same as prior period, unchanged from 0001564590-16-027054:notes:87]

[0001564590-17-000906:notes:106]
[same as prior period, unchanged from 0001564590-16-027054:notes:88]

[0001564590-17-000906:notes:107]
[same as prior period, unchanged from 0001564590-16-027054:notes:89]

[0001564590-17-000906:notes:108]
The fair value of the borrowings under the Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the carrying amount of the Company’s indebtedness of $98.2 million and $55.5 million as of December 31, 2016 and June 30, 2016, respectively.

[0001564590-17-000906:notes:109]
[same as prior period, unchanged from 0001564590-16-027054:notes:91]

[0001564590-17-000906:notes:110]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. There were no impairments recorded for the three and six months ended December 31, 2016 or 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-17-000906:notes:111]
7.Share-based Compensation

[0001564590-17-000906:notes:112]
[same as prior period, unchanged from 0001564590-16-027054:notes:94]

[0001564590-17-000906:notes:113]
The Company had reserved for issuance for the periods noted (in thousands):

[0001564590-17-000906:notes:114]
|  |  | December 31, 2016 |  |  | June 30, 2016 |  |
| 2014 Employee Stock Purchase Plan |  |  | 8,897 |  |  |  | 10,001 |  |
| Employee stock options and awards outstanding |  |  | 10,450 |  |  |  | 10,609 |  |
| 2013 Employee Plan shares available for grant |  |  | 1,553 |  |  |  | 5,401 |  |
| Total shares reserved for issuance |  |  | 20,900 |  |  |  | 26,011 |  |

[0001564590-17-000906:notes:115]
[same as prior period, unchanged from 0001564590-16-027054:notes:97]

[0001564590-17-000906:notes:116]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Cost of product revenue |  | $ | 122 |  |  | $ | 277 |  |  | $ | 190 |  |  | $ | 572 |  |
| Cost of service revenue |  |  | 186 |  |  |  | 277 |  |  |  | 418 |  |  |  | 644 |  |
| Research and development |  |  | 906 |  |  |  | 1,165 |  |  |  | 1,968 |  |  |  | 2,795 |  |
| Sales and marketing |  |  | 1,180 |  |  |  | 1,291 |  |  |  | 2,321 |  |  |  | 2,719 |  |
| General and administrative |  |  | 987 |  |  |  | 935 |  |  |  | 1,959 |  |  |  | 1,886 |  |
| Total share-based compensation expense |  | $ | 3,381 |  |  | $ | 3,945 |  |  | $ | 6,856 |  |  | $ | 8,616 |  |

[0001564590-17-000906:notes:117]
During the three months ended December 31, 2016 and 2015, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-17-000906:notes:118]
[same as prior period, unchanged from 0001564590-16-027054:notes:100]

[0001564590-17-000906:notes:119]
Stock awards may be granted under the 2013 Equity Incentive Plan (the “2013 Plan”) on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (including performance or market-based restricted stock units) which vest over a fixed period of time or based upon the satisfaction of certain performance criteria.  The Company uses the straight-line method for expense attribution, and beginning with fiscal 2017, the Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-17-000906:notes:120]
The following table summarizes stock award activity for the six months ended December 31, 2016  (in thousands, except grant date fair value):

[0001564590-17-000906:notes:121]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2016 |  |  | 4,224 |  |  | $ | 3.36 |  |  |  |  |  |
| Granted |  |  | 3,148 |  |  |  | 3.90 |  |  |  |  |  |
| Vested |  |  | (1,164 | ) |  |  | 4.25 |  |  |  |  |  |
| Cancelled |  |  | (326 | ) |  |  | 2.88 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2016 |  |  | 5,882 |  |  | $ | 3.49 |  |  | $ | 29,587 |  |

[0001564590-17-000906:notes:122]
The following table summarizes stock option activity for the six months ended December 31, 2016 (in thousands, except per share and contractual term):

[0001564590-17-000906:notes:123]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2016 |  |  | 6,385 |  |  | $ | 4.10 |  |  |  | 3.70 |  |  | $ | 1,416 |  |
| Granted |  |  | - |  |  |  | - |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (944 | ) |  |  | 3.43 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (873 | ) |  |  | 4.56 |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2016 |  |  | 4,568 |  |  | $ | 4.15 |  |  |  | 3.79 |  |  | $ | 4,742 |  |
| Exercisable at December 31, 2016 |  |  | 3,419 |  |  | $ | 4.49 |  |  |  | 3.36 |  |  | $ | 2,490 |  |
| Vested and expected to vest at December 31, 2016 |  |  | 4,568 |  |  | $ | 4.15 |  |  |  | 3.79 |  |  | $ | 4,742 |  |

[0001564590-17-000906:notes:124]
There were 4,800 stock options granted during the three and six months ended December 31, 2015.

[0001564590-17-000906:notes:125]
[same as prior period, unchanged from 0001564590-16-027054:notes:108]

[0001564590-17-000906:notes:126]
[same as prior period, unchanged from 0001564590-16-027054:notes:109]

[0001564590-17-000906:notes:127]
On August 1, 2016, the Compensation Committee of the Company approved the grant of 680,000 awards of restricted stock units to the Company’s Executive Officers, with a grant date of August 15, 2016. Fifty percent (50%) of the restricted stock units granted were in the form of PSUs and fifty percent (50%) of the restricted stock units granted were in the form of service-based restricted stock units (“RSUs”).  The RSUs vest from the original grant date as to one-third (1/3) on the one year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company  The PSUs vest once the Company's stock price equals or exceeds $5.00 per share for 30 consecutive trading days after January 1, 2017 ("Performance Threshold"). Once the Performance Threshold is satisfied the PSUs shall vest with respect to the number of RSUs that have vested as of the date the Performance Threshold is satisfied and thereafter shall vest on the same schedule as the RSUs, subject to continued service to the Company. If the Performance Threshold is not met by the third anniversary of the grant date the award is terminated for no consideration.  In addition, the Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $5.00 per share.

[0001564590-17-000906:notes:128]
[same as prior period, unchanged from 0001564590-16-027054:notes:111]

[0001564590-17-000906:notes:129]
There were no shares granted under the Company’s 2014 Employee Stock Purchase Plan (“ESPP”) during the three months ended December 31, 2016 and 2015.

[0001564590-17-000906:notes:130]
|  |  | Stock Option Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2015 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Expected life |  | 4.0 years |  |  | 4.0 years |  |  | 1.21 years |  |  | 1.25 years |  |
| Risk-free interest rate |  |  | 1.78 | % |  |  | 1.78 | % |  |  | 0.33 | % |  |  | 0.29 | % |
| Volatility |  |  | 52 | % |  |  | 52 | % |  |  | 58 | % |  |  | 58 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-17-000906:notes:131]
| 8. | Restructuring Charges |

[0001564590-17-000906:notes:132]
As of December 31, 2016, restructuring liabilities were $3.8 million and consisted of obligations for estimated future obligations for non-cancelable lease payments for excess facilities.   With the acquisition of certain assets and liabilities from Zebra, the Company assumed a facility lease located at 6480 Via del Oro, San Jose CA.  The Company will consolidate its existing workforce with employees assumed from Zebra in the Via del Oro site.  The Company expects to cease use of the remaining 34,905 sf of the Rio Robles site by January 31, 2017.   Because the Company expects to cease use of the Rio Robles facility by January 31, 2017, and will abandon all leasehold improvements, it will accelerate the amortization of the remaining leasehold improvements balance for this site over the shortened service period such that the net book value of the lease hold improvements on the cease-use date will be zero.  The Company recorded accelerated amortization expense in the three month period ended December 31, 2016 of $1.7 million and it is reflected in "Restructuring and related charges, net of reversals" in the condensed consolidated statements of operations.

[0001564590-17-000906:notes:133]
Previous restructuring charges included obligations for estimated future obligations for non-cancelable lease payments, offset for future sub-leasing income.  The Company has estimated future sub-lease income based on its existing leases agreement, as well the real estate market conditions at the respective locations.  The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.  The Company evaluates estimated sub-lease income on a regular basis and adjust the accrual as necessary if and when facts should change.  In the three months ended December 31, 2016 the Company recorded a charge of $0.1 million to adjust its estimated future sub-lease income for its exited facilities. This charge is reflected in "Restructuring and related charges, net of reversals" in the condensed consolidated statements of operations.

[0001564590-17-000906:notes:134]
Fiscal 2016 Restructuring

[0001564590-17-000906:notes:135]
During the first quarter fiscal of 2016, the Company recorded restructuring charges of $5.6 million including $5.4 million for excess facility charges and adjustments to service benefits of $0.2 million.  Excess facilities charges included $4.1 million of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments for excess facilities and accelerated depreciation of leasehold improvements in the amount of $1.3 million. This charge is reflected in "Restructuring and related charges, net of reversals" in the condensed consolidated statements of operations.

[0001564590-17-000906:notes:136]
During the second quarter fiscal of 2016, the Company incurred restructuring charges of $3.0 million including $2.9 million in excess facilities charges related to amending its lease in North Carolina, thereby reducing it floor space by 36%, and adjustments to severance benefits of $0.2 million. Excess facilities charges included accelerated depreciation of leasehold improvements in the amount of $1.9 million and contract termination charges and professional fees of $1.0 million. This charge is reflected in "Restructuring and related charges, net of reversals" in the condensed consolidated statements of operations

[0001564590-17-000906:notes:137]
Restructuring and related liabilities consist of (in thousands):

[0001564590-17-000906:notes:138]
|  |  | Excess Facilities |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2016 |  |  | 4,644 |  |  |  | — |  |  |  | 4,644 |  |
| Period charges |  |  | 135 |  |  |  | 1,718 |  |  |  | 1,853 |  |
| Non cash charges |  |  | — |  |  |  | (1,718 | ) |  |  | (1,718 | ) |
| Period payments |  |  | (956 | ) |  |  | — |  |  |  | (956 | ) |
| Balance as of December 31, 2016 |  | $ | 3,823 |  |  | $ | — |  |  | $ | 3,823 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  | 1,481 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  | $ | 2,342 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-17-000906:notes:139]
| 9. | Commitments and Contingencies |

[0001564590-17-000906:notes:140]
Purchase Commitments

[0001564590-17-000906:notes:141]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2016, the Company had non-cancelable commitments to purchase $93.6 million of such inventory.  As of December 31, 2016 the Company had non-cancelable software and maintenance support commitments to purchase $24.2 of software and support services.

[0001564590-17-000906:notes:142]
Legal Proceedings

[0001564590-17-000906:notes:143]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-17-000906:notes:144]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-17-000906:notes:145]
Brazilian Tax Assessment Matters

[0001564590-17-000906:notes:146]
Certain Brazilian tax authorities have made tax assessments against our Brazilian subsidiary, Enterasys Networks do Brazil Ltda., based on an alleged underpayment of taxes.  The tax authorities are also seeking interest and penalties with respect to such claims (collectively, the “ICMS Tax Assessments”).  The State of Sao Paolo, Brazil denied Enterasys Networks do Brazil Ltda. the use of certain tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the tax years of 2002 through 2009. The Company’s application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  All currency conversions in this Legal Proceedings section are as of December 31, 2016.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is BRL 3.4 million (US $1.0 million), plus interest and penalties BRL 17.7 million (US $5.4 million).  Possible court fees are estimated to be BRL 4.2 million (US $1.3 million).  On January 10, 2014, the Company filed a lawsuit to overturn or reduce the ICMS Assessments, which lawsuit remains on-going. As part of this lawsuit, the Company made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellate court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by the Company.

[0001564590-17-000906:notes:147]
On or about June 18, 2014, the State of San Paolo notified Enterasys Networks do Brazil Ltda. that it intends to audit the records of such entity for tax years 2012 and 2013.  In addition, the Company received a similar notice in December 2015 with respect to an audit by the State of San Paolo of tax years 2011-2014. The audits are expected to cover the same or very similar issues as the ICMS Tax Assessments for tax years 2002-2009, however, the Company changed its ICMS procedures effective May 2009 and a similar tax assessment is not anticipated.  The Company has provided the requested information for these tax years to the Brazilian tax authorities, but has received no further response from the Brazilian tax authorities.

[0001564590-17-000906:notes:148]
Based on the currently available information, the Company believes the ultimate outcome of the above audits and assessments will not have a material adverse effect on the Company's financial position or overall results of operations. The Company believes that the ICMS Tax Assessments against our Brazilian subsidiary are without merit and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, it is unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and estimate the potential tax liability related to the ICMS Tax Assessments, if any, may be up to BRL 25.3 million (US $7.8 million).  The Company does not expect a final judicial determination for several years.  The Company believes BRL 9.4 million (US $2.9 million) is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys Networks as such matter relates to the period before the acquisition.

[0001564590-17-000906:notes:149]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks (“Seller”) of the ICMS Tax Assessments. Seller agreed to assume the defense of the ICMS Tax Assessments on May 20, 2014. In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend the Company with respect to the ICMS Tax Assessments and to indemnify the Company for losses related thereto subject to certain conditions. In addition, the Seller has agreed to indemnify the Company in connection with tax assessments up to a specified cap related to the 2012 and 2013 tax years subject to certain conditions.  These conditions include the offsetting of foreign income tax benefits realized by the Company in the connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, the Company does not anticipate that any amounts under the indemnification will be due from the Seller in connection with either the ICMS Tax Assessments or any potential tax assessments for tax years 2012 and 2013.

[0001564590-17-000906:notes:150]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-17-000906:notes:151]
On October 23 and 29, 2015, complaints were filed for violations of securities laws in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated.  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding Extreme Networks' current financial condition and growth prospects. Plaintiffs seek damages of an unspecified amount on behalf of a class of investors who purchased the Company's common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the court appointed a lead plaintiff.  On September 26, 2016, lead plaintiff filed a consolidated complaint. On November 10, 2016 defendants filed a motion to dismiss.  The motion is scheduled to be heard, after completion of the briefing, on February 9, 2017.   The Company believes the claims are without merit and intends to vigorously defend the claims.

[0001564590-17-000906:notes:152]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County, Shaffer v. Kispert et al., No. 16 CV 291726.  The complaint names current and former officers and members of the Board of Directors as defendants and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation to that effect.

[0001564590-17-000906:notes:153]
Dunti Network Technologies, LLC v Extreme Networks, Inc. Patent Infringement Suit

[0001564590-17-000906:notes:154]
On September 22, 2016, the Company was served with a patent infringement complaint by Dunti Network Technologies, LLC in the U.S. District Court for the Eastern District of Texas.  The case is Dunti Network Technologies, LLC v. Extreme Networks, Inc., No. 2:16-cv-01034.  The complaint asserts infringement of U.S. Patent Nos. 6,587,462, 6,788,701, 6,804,235, 6,643,286, and 7,778,259.  The complaint asserts that the Company infringes based on its manufacture, use, sale, and/or offer for sale of the Company’s BlackDiamond-X, Summit X670, and Summit X770 series switches.  Dunti sought damages of an unspecified amount.  Dunti moved to dismiss the case and the case against the Company was dismissed by the court as of December 27, 2016.

[0001564590-17-000906:notes:155]
Indemnification Obligations

[0001564590-17-000906:notes:156]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its director and officers’ insurance coverage is uncertain. As of December 31, 2016, the Company had no outstanding indemnification claims.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-17-000906:notes:157]
| 10. | Income Taxes |

[0001564590-17-000906:notes:158]
For the three months ended December 31, 2016 and 2015, the Company recorded an income tax provision of $1.2 million and $1.2  million, respectively.    For the six months ended December 31, 2016 and 2015, the Company recorded an income tax provision of $2.1 million and $2.1 million, respectively.

[0001564590-17-000906:notes:159]
The income tax provisions for the three months ended December 31, 2016 and 2015, consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc. and the WLAN Business of Zebra. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended December 31, 2016 and 2015, and therefore may not reflect the annual effective tax rate.

[0001564590-17-000906:notes:160]
[same as prior period, unchanged from 0001564590-16-027054:notes:138]

[0001564590-17-000906:notes:161]
The acquisition of Enterasys included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  The Company has estimated the value of the intangible assets from this transaction and is amortizing the amount over 15 years for tax purposes.  During the three months ended December 31, 2016 and 2015, the Company deducted $1.1 million of tax amortization expense for each period related to capitalized goodwill. As of December 31, 2016, the Company recorded a deferred tax liability of $5.3 million related to this amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-17-000906:notes:162]
The Company had $19.0 million of unrecognized tax benefits as of December 31, 2016.  The future impact of the unrecognized tax benefit of $18.9 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-17-000906:notes:163]
[same as prior period, unchanged from 0001564590-16-027054:notes:142]

[0001564590-17-000906:notes:164]
[same as prior period, unchanged from 0001564590-16-027054:notes:143]


## us-gaap:EarningsPerShareTextBlock

[0001564590-17-000906:notes:165]
| 11. | Net Loss Per Share |

[0001564590-17-000906:notes:166]
[same as prior period, unchanged from 0001564590-16-027054:notes:145]

[0001564590-17-000906:notes:167]
[same as prior period, unchanged from 0001564590-16-027054:notes:146]

[0001564590-17-000906:notes:168]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Net loss |  | $ | (8,611 | ) |  | $ | (7,234 | ) |  | $ | (15,090 | ) |  | $ | (18,760 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 107,425 |  |  |  | 102,369 |  |  |  | 106,690 |  |  |  | 101,677 |  |
| Net loss per share - basic and diluted |  | $ | (0.08 | ) |  | $ | (0.07 | ) |  | $ | (0.14 | ) |  | $ | (0.18 | ) |

[0001564590-17-000906:notes:169]
[same as prior period, unchanged from 0001564590-16-027054:notes:148]

[0001564590-17-000906:notes:170]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Options to purchase common stock |  |  | 2,301 |  |  |  | 5,280 |  |  |  | 2,762 |  |  |  | 5,608 |  |
| Restricted stock units |  |  | 28 |  |  |  | 138 |  |  |  | 79 |  |  |  | 77 |  |
| Employee Stock Purchase Plan shares |  |  | 330 |  |  |  | 449 |  |  |  | 330 |  |  |  | 449 |  |
| Total shares excluded |  |  | 2,659 |  |  |  | 5,867 |  |  |  | 3,171 |  |  |  | 6,134 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-17-000906:notes:171]
12.Foreign Exchange Forward Contracts

[0001564590-17-000906:notes:172]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as "Other accrued liabilities" at fair value. Changes in the fair value of derivatives are recognized in earnings as "Other Income". The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges.

[0001564590-17-000906:notes:173]
At December 31, 2016, forward foreign currency contracts had a notional principal amount of $4.8 million and an immaterial unrealized loss. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. At December 31, 2015, the Company did not have any derivative instruments outstanding.

[0001564590-17-000906:notes:174]
Foreign currency transactions gains and losses from operations was gain of $1.1 million and $0.2 million for the three months ended December 31, 2016 and 2015, respectively.   Foreign currency transactions gains and losses from operations was gain of $0.8 million and $1.3 million for the six months ended December 31, 2016 and 2015, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-17-000906:notes:175]
| 13. | Disclosure about Segments of an Enterprise and Geographic Areas |

[0001564590-17-000906:notes:176]
[same as prior period, unchanged from 0001564590-16-027054:notes:154]

[0001564590-17-000906:notes:177]
[same as prior period, unchanged from 0001564590-16-027054:notes:155]

[0001564590-17-000906:notes:178]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Net Revenues: |  | December 31, 2016 |  |  | December 31, 2015 |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,193 |  |  | $ | 58,749 |  |  | $ | 123,051 |  |  | $ | 115,093 |  |
| Other |  |  | 9,985 |  |  |  | 7,743 |  |  |  | 18,170 |  |  |  | 13,585 |  |
| Total Americas |  |  | 79,178 |  |  |  | 66,492 |  |  |  | 141,221 |  |  |  | 128,678 |  |
| EMEA: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Germany |  |  | 19,277 |  |  |  | 17,818 |  |  |  | 43,864 |  |  |  | 32,356 |  |
| Other |  |  | 37,406 |  |  |  | 42,284 |  |  |  | 63,468 |  |  |  | 78,772 |  |
| Total EMEA |  |  | 56,683 |  |  |  | 60,102 |  |  |  | 107,332 |  |  |  | 111,128 |  |
| APAC: |  |  | 12,250 |  |  |  | 12,711 |  |  |  | 22,200 |  |  |  | 24,080 |  |
| Total net revenues |  | $ | 148,111 |  |  | $ | 139,305 |  |  | $ | 270,753 |  |  | $ | 263,886 |  |

[0001564590-17-000906:notes:179]
| Long Lived Assets: |  | December 31, 2016 |  |  | June 30, 2016 |  |
| Americas |  | $ | 75,156 |  |  | $ | 58,277 |  |
| EMEA |  |  | 7,833 |  |  |  | 14,234 |  |
| APAC |  |  | 2,490 |  |  |  | 2,493 |  |
| Total long lived assets |  | $ | 85,479 |  |  | $ | 75,004 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-17-000906:notes:180]
14.Subsequent Events

[0001564590-17-000906:notes:181]
On January 5, 2017, Extreme Networks, Inc. (the "Company") approved and on January 6, 2017 began executing a reduction-in-force plan (the ”Plan”) to re-align the Company’s resources as a result of the Company’s purchase of the wireless LAN business of Zebra Technologies Corporation. The Company expects to incur charges of approximately $6.5 million and affected employees worldwide and all functional areas. Upon completion of the Plan, the potential savings is expected to yield annualized savings of approximately $8.0 million. The costs associated with this Plan are primarily employee severance and benefits expenses.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.
