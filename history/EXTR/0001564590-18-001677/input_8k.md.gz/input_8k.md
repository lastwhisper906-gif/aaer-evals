# EXTR 8-K — 0001564590-18-001403 filed 2018-02-06

## item codes, every 8-K on or before 2018-02-08

- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2018-02-08

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-001403:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-18-001403:8k_2_02:2]
extr-ex991_6.htm

[0001564590-18-001403:8k_2_02:3]
Exhibit 99.1

[0001564590-18-001403:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-18-001403:8k_2_02:5]
| For more information, contact: |  |  |
| Investor Relations Jean Marie Young |  | Media Contact Jen Grabowski |
| 212/481-2050 |  | 617/624-3200 |
| extreme@tpg-ir.com |  | ExtremeUS@racepointglobal.com |

[0001564590-18-001403:8k_2_02:6]
Extreme Networks Reports Second Quarter Fiscal Year 2018 Financial Results

[0001564590-18-001403:8k_2_02:7]
SAN JOSE, Calif., February 6, 2018 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal second quarter ended December 31, 2017.

[0001564590-18-001403:8k_2_02:8]
Second Quarter Results:

[0001564590-18-001403:8k_2_02:9]
|  | • | Second quarter revenue was $231.1 million, an increase of 48% year-over-year. |

[0001564590-18-001403:8k_2_02:10]
|  | • | GAAP gross margin for the second fiscal quarter was 55.8%, an increase of 490 basis points year-over-year, and non-GAAP gross margin was 59.4% year-over-year, an increase of 220 basis points year-over-year. |

[0001564590-18-001403:8k_2_02:11]
|  | • | GAAP operating margin for the second fiscal quarter was (13.5)% and non-GAAP operating margin was 8.8%, compared to (1.9)% and 11.7 %, respectively, year-over-year. |

[0001564590-18-001403:8k_2_02:12]
|  | • | GAAP net loss for the second fiscal quarter was $31.9 million, or $0.28 per basic share. Non-GAAP net income was $16.4 million, or $0.14 per diluted share, a decrease of $0.7 million and $0.02, respectively, year-over-year. |

[0001564590-18-001403:8k_2_02:13]
“We delivered solid performance in the second fiscal quarter highlighted by revenue growth, gross margin expansion and solid execution of our integration initiatives associated with our newly acquired assets,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-18-001403:8k_2_02:14]
“I am especially pleased with our non-GAAP gross margin performance in the quarter, which is close to exceeding our near-term goal of 60%,” continued Meyercord.  “We turned away a significant volume of low margin business this quarter in favor of higher quality, solutions-driven sales that drove our non-GAAP gross margin improvement for the twelfth consecutive quarter. We expect to see continued improvement in gross margins in the second half of our fiscal year in addition to significant sequential quarterly growth.”

[0001564590-18-001403:8k_2_02:15]
“Our recent acquisitions have meaningfully strengthened our brand, our competitive position and our technology differentiation in the market. We are seeing significant growth in our pipeline which includes many cross-selling opportunities. Our March quarter will be the first quarter of fully consolidated operations and we expect to deliver year-over-year organic growth in our core Extreme business and meeting or exceeding our annual target of $430 million of newly acquired revenue which is evident in our guidance.” Meyercord added.

[0001564590-18-001403:8k_2_02:16]
Finally, Meyercord added, "We successfully completed the migration of the data and IT systems of the acquired assets from Brocade into Extreme as planned on January 15th and we are on track to migrate the data and systems of the Avaya assets in early April. Our teams have done an outstanding job driving our business while managing these large and complex integration initiatives."

[0001564590-18-001403:8k_2_02:17]
Recent Key Events:

[0001564590-18-001403:8k_2_02:18]
|  | • | St John's Hotel is a luxury hotel with 1,091 guest rooms located in Pyeongchang, South Korea, the host city for the 2018 Winter Olympics. The newly-opened hotel will accommodate International Olympic Committee members during the upcoming Games. Extreme solved their need for secure and reliable, easy-to-manage wired and wireless unified access for guest rooms and indoor/outdoor venues highlighted by our feature-rich Extreme Management Center software that provides complete visibility, control and analytics of the entire networking infrastructure environment. |

[0001564590-18-001403:8k_2_02:19]
|  | • | SK Telecom is the largest mobile service provider in South Korea with 50+ million subscribers. They originally preferred our largest competitor, but ultimately decided on Extreme's switches for their core and top-of-rack at their Boramae Data Center. Their confidence that Extreme delivers the best products, support, and long-term ROI led to their decision. |

[0001564590-18-001403:8k_2_02:20]
|  | • | Ultravision is a service provider in Mexico that offers TV, TV on Demand, Internet, and Voice over LTE. Ultravision chose Extreme for the automation, traffic flow visibility, and competitive pricing. The IP/MPLS transport and core network consists of integrated technologies with the Summit Series from Extreme and newly acquired datacenter assets including the SLX, MLX and VDX switching and routing families along with Flow Optimizer for threat mitigation, Workflow Composer for high automation capabilities, and Extreme Management Center for their next phase network management. |

[0001564590-18-001403:8k_2_02:21]
|  | • | Extreme Networks was named the Official Wi-Fi Analytics Provider of Super Bowl LII by the NFL for the 5th consecutive year. To maximize network visibility and the fan experience, Extreme deployed its cloud-based ExtremeAnalytics™ solution during this year's Super Bowl at Minneapolis' U.S. Bank Stadium. Our analytics solution delivers actionable, real-time insight into how fans use apps, video, social media and images throughout the game. Extreme has, this past season, delivered high-density Wi-Fi solutions to 10 NFL teams and insightful Wi-Fi analytics to an additional 12 NFL teams. |

[0001564590-18-001403:8k_2_02:22]
Fiscal Q2 2018 Financial Metrics:

[0001564590-18-001403:8k_2_02:23]
(in millions, except percentages ad per share information)

[0001564590-18-001403:8k_2_02:24]
|  |  | Q2 FY'18 |  |  | Q2 FY'17 |  |  | Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 174.8 |  |  | $ | 118.1 |  |  | $ | 56.7 |  |  |  | 48 | % |
| Service |  |  | 56.3 |  |  |  | 38.3 |  |  |  | 18.0 |  |  |  | 47 | % |
| Total Net Revenue |  | $ | 231.1 |  |  | $ | 156.4 |  |  | $ | 74.7 |  |  |  | 48 | % |
| Gross Margin |  |  | 55.8 | % |  |  | 50.9 | % |  | 490bps |  |  |  | 10 | % |
| Operating Margin |  |  | (13.5 | )% |  |  | (1.9 | )% |  | -1156bps |  |  |  | (608 | )% |
| Net Loss |  | $ | (31.9 | ) |  | $ | (4.2 | ) |  | $ | (27.7 | ) |  |  | (660 | )% |
| Loss per basic and diluted share |  | $ | (0.28 | ) |  | $ | (0.04 | ) |  | $ | (0.24 | ) |  |  | (600 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 174.8 |  |  | $ | 118.1 |  |  | $ | 56.7 |  |  |  | 48 | % |
| Service |  |  | 56.3 |  |  |  | 38.3 |  |  |  | 18.0 |  |  |  | 47 | % |
| Total Net Revenue |  | $ | 231.1 |  |  | $ | 156.4 |  |  | $ | 74.7 |  |  |  | 48 | % |
| Gross Margin |  |  | 59.4 | % |  |  | 57.2 | % |  | 220bps |  |  |  | 4 | % |
| Operating Margin |  |  | 8.8 | % |  |  | 11.7 | % |  | 290bps |  |  |  | (25 | )% |
| Net Income |  | $ | 16.4 |  |  | $ | 17.1 |  |  | $ | (0.7 | ) |  |  | (4 | )% |
| Earnings per diluted share |  | $ | 0.14 |  |  | $ | 0.16 |  |  | $ | (0.02 | ) |  |  | (13 | )% |

[0001564590-18-001403:8k_2_02:25]
|  | • | With the adoption of new revenue recognition accounting guidance (“ASC 606”) in FY’18, we have adjusted prior periods. The impact of these adjustments to the balance sheet and income statement, are noted with “as adjusted”. |

[0001564590-18-001403:8k_2_02:26]
|  | • | Cash and investments ended the quarter at $128.2 million, a decrease of $25.9 million from Q1 and an increase of $24.4 million from Q2 last year. |

[0001564590-18-001403:8k_2_02:27]
|  | • | Accounts receivable balance ending Q2 was $154.9 million, with days sales outstanding (“DSO”) of 62. |

[0001564590-18-001403:8k_2_02:28]
|  | • | Q2 ending inventory was $83.4 million, an increase of $25.3 million from the prior quarter and an increase of $34.0 million from Q2 last year. |

[0001564590-18-001403:8k_2_02:29]
|  | • | Q2 ending debt was $183.1 million, an increase of $15.5 million from Q1, driven primarily by borrowings to fund Extreme's acquisition of Brocade's Data Center business and an increase of $86.0 million from Q2 last year, driven primarily by borrowings to fund Extreme's acquisitions of Avaya’s Campus Fabric business and Brocade's Data Center business. |

[0001564590-18-001403:8k_2_02:30]
Business Outlook:

[0001564590-18-001403:8k_2_02:31]
For its third quarter of fiscal 2018, ending March 31, 2018, the Company is targeting revenue in a range of $262.0 million to $272.0 million.  GAAP gross margin is targeted between 56.1% and 58.4% and non-GAAP gross margin is targeted between 58.9% and 61.1%. Operating expenses are targeted to be between $153.5 million and $156.5 million on a GAAP basis and $130.0 million to $133.0 million on a non-GAAP basis. GAAP earnings are targeted to be between a net loss of $1.6 million to $10.4 million or a loss of $(0.01) to $(0.09) per basic share.  Non-GAAP earnings are targeted in a range of net income of $20.4

[0001564590-18-001403:8k_2_02:32]
million to $29.2 million, or $0.17 to $0.24 per diluted share. The GAAP net loss targets are based on 114.8 million average outstanding shares and non-GAAP net income targets are based on an estimated 120.3 million average outstanding shares.

[0001564590-18-001403:8k_2_02:33]
The following table shows the GAAP to non-GAAP reconciliation for Q3 FY’18 guidance:

[0001564590-18-001403:8k_2_02:34]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 56.1% - 58.4% |  |  | (2.5)% - 0.8% |  |  | $(0.09)-$(0.01) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 1.7% |  |  | 0.6% |  |  | $ | 0.01 |  |
| Stock based compensation | 0.2% |  |  | 3.2% |  |  | $ | 0.07 |  |
| Inventory adjustments | 0.4% |  |  | 0.4% |  |  | $ | 0.01 |  |
| Amortization of non product intangibles | - |  |  | 1.7% |  |  | $ | 0.04 |  |
| Restructuring charges, net | - |  |  | 1.6% |  |  | $ | 0.04 |  |
| Acquisition and integration costs | 0.5% |  |  | 4.1% |  |  | $ | 0.09 |  |
| Non-GAAP | 58.9% - 61.1% |  |  | 9.2% - 12.2% |  |  | $0.17 - $0.24 |  |

[0001564590-18-001403:8k_2_02:35]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-18-001403:8k_2_02:36]
Conference Call:

[0001564590-18-001403:8k_2_02:37]
Extreme will host a conference call at 5:00 p.m. Eastern (2:00 p.m. Pacific) today to review the Second fiscal quarter results as well as the third fiscal quarter ended March 31, 2018 business outlook, including

[0001564590-18-001403:8k_2_02:38]
significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through February 6, 2019.  The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406   Conference ID # 3459947.

[0001564590-18-001403:8k_2_02:39]
About Extreme Networks:

[0001564590-18-001403:8k_2_02:40]
Extreme Networks, Inc. (EXTR) delivers software-driven networking solutions that help IT departments everywhere deliver the ultimate business outcome: stronger connections with customers, partners and employees. Wired to wireless, desktop to datacenter, on premise or through the cloud, we go to extreme measures for our customers in more than 80 countries, delivering 100% insourced call-in technical support to organizations large and small, including some of the world’s leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-18-001403:8k_2_02:41]
Extreme Networks and the Extreme Networks logo, Extreme Management Center, ExtremeWireless, ExtremeWireless WiNG, Extreme Secure Automated Campus, ExtremeControl, ExtremeAnalytics, and ExtremeCloud are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-18-001403:8k_2_02:42]
Non-GAAP Financial Measures:

[0001564590-18-001403:8k_2_02:43]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, amortization of acquired intangibles, restructuring charges, executive transition costs, litigation expenses, other income and income tax.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-18-001403:8k_2_02:44]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-18-001403:8k_2_02:45]
Forward Looking Statements:

[0001564590-18-001403:8k_2_02:46]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-18-001403:8k_2_02:47]
EXTREME NETWORKS, INC.

[0001564590-18-001403:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-18-001403:8k_2_02:49]
(In thousands)

[0001564590-18-001403:8k_2_02:50]
(Unaudited)

[0001564590-18-001403:8k_2_02:51]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 127,108 |  |  | $ | 130,450 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,382 at December 31, 2017 and $1,190 at June 30, 2017 |  |  | 154,906 |  |  |  | 93,115 |  |
| Inventories |  |  | 83,377 |  |  |  | 47,410 |  |
| Prepaid expenses and other current assets |  |  | 24,772 |  |  |  | 27,867 |  |
| Total current assets |  |  | 390,163 |  |  |  | 298,842 |  |
| Property and equipment, net |  |  | 68,565 |  |  |  | 30,240 |  |
| Intangible assets, net |  |  | 92,925 |  |  |  | 25,337 |  |
| Goodwill |  |  | 130,988 |  |  |  | 80,216 |  |
| Other assets |  |  | 44,267 |  |  |  | 25,065 |  |
| Total assets |  | $ | 726,908 |  |  | $ | 459,700 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 22,426 |  |  | $ | 12,280 |  |
| Accounts payable |  |  | 73,553 |  |  |  | 31,587 |  |
| Accrued compensation and benefits |  |  | 49,104 |  |  |  | 42,662 |  |
| Accrued warranty |  |  | 13,010 |  |  |  | 10,584 |  |
| Deferred revenue, net |  |  | 113,664 |  |  |  | 79,048 |  |
| Other accrued liabilities |  |  | 74,517 |  |  |  | 37,044 |  |
| Total current liabilities |  |  | 346,274 |  |  |  | 213,205 |  |
| Deferred revenue, less current portion |  |  | 38,693 |  |  |  | 25,293 |  |
| Long-term debt, less current portion |  |  | 160,712 |  |  |  | 80,422 |  |
| Deferred income taxes |  |  | 5,163 |  |  |  | 6,576 |  |
| Other long-term liabilities |  |  | 64,347 |  |  |  | 8,526 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity |  |  | 111,719 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity |  | $ | 726,908 |  |  | $ | 459,700 |  |

[0001564590-18-001403:8k_2_02:52]
EXTREME NETWORKS, INC.

[0001564590-18-001403:8k_2_02:53]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-001403:8k_2_02:54]
(In thousands, except per share amounts)

[0001564590-18-001403:8k_2_02:55]
(Unaudited)

[0001564590-18-001403:8k_2_02:56]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 174,850 |  |  | $ | 118,055 |  |  | $ | 339,624 |  |  | $ | 208,148 |  |
| Service |  |  | 56,273 |  |  |  | 38,322 |  |  |  | 103,214 |  |  |  | 70,833 |  |
| Total net revenues |  |  | 231,123 |  |  |  | 156,377 |  |  |  | 442,838 |  |  |  | 278,981 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 78,472 |  |  |  | 62,627 |  |  |  | 158,517 |  |  |  | 106,876 |  |
| Service |  |  | 23,665 |  |  |  | 14,098 |  |  |  | 42,954 |  |  |  | 26,567 |  |
| Total cost of revenues |  |  | 102,137 |  |  |  | 76,725 |  |  |  | 201,471 |  |  |  | 133,443 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 96,378 |  |  |  | 55,428 |  |  |  | 181,107 |  |  |  | 101,272 |  |
| Service |  |  | 32,608 |  |  |  | 24,224 |  |  |  | 60,260 |  |  |  | 44,266 |  |
| Total gross profit |  |  | 128,986 |  |  |  | 79,652 |  |  |  | 241,367 |  |  |  | 145,538 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 45,907 |  |  |  | 24,013 |  |  |  | 80,192 |  |  |  | 42,312 |  |
| Sales and marketing |  |  | 65,659 |  |  |  | 41,025 |  |  |  | 121,220 |  |  |  | 77,884 |  |
| General and administrative |  |  | 11,669 |  |  |  | 9,397 |  |  |  | 23,854 |  |  |  | 17,684 |  |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 34,115 |  |  |  | 4,169 |  |  |  | 38,359 |  |  |  | 6,490 |  |
| Restructuring and related charges, net of reversals |  |  | — |  |  |  | 1,853 |  |  |  | — |  |  |  | 1,853 |  |
| Amortization of intangibles |  |  | 2,746 |  |  |  | 2,175 |  |  |  | 4,360 |  |  |  | 6,317 |  |
| Total operating expenses |  |  | 160,096 |  |  |  | 82,632 |  |  |  | 267,985 |  |  |  | 152,540 |  |
| Operating loss |  |  | (31,110 | ) |  |  | (2,980 | ) |  |  | (26,618 | ) |  |  | (7,002 | ) |
| Interest income |  |  | 717 |  |  |  | 81 |  |  |  | 1,364 |  |  |  | 138 |  |
| Interest expense |  |  | (2,504 | ) |  |  | (1,176 | ) |  |  | (4,719 | ) |  |  | (1,823 | ) |
| Other income (expense), net |  |  | (643 | ) |  |  | 1,025 |  |  |  | 2,484 |  |  |  | 802 |  |
| Loss before income taxes |  |  | (33,540 | ) |  |  | (3,050 | ) |  |  | (27,489 | ) |  |  | (7,885 | ) |
| Provision (benefit) for income taxes |  |  | (1,617 | ) |  |  | 1,179 |  |  |  | 58 |  |  |  | 2,086 |  |
| Net loss |  | $ | (31,923 | ) |  | $ | (4,229 | ) |  | $ | (27,547 | ) |  | $ | (9,971 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.28 | ) |  | $ | (0.04 | ) |  | $ | (0.24 | ) |  | $ | (0.09 | ) |
| Net loss per share - diluted |  | $ | (0.28 | ) |  | $ | (0.04 | ) |  | $ | (0.24 | ) |  | $ | (0.09 | ) |
| Shares used in per share calculation - basic |  |  | 113,621 |  |  |  | 107,425 |  |  |  | 112,931 |  |  |  | 106,690 |  |
| Shares used in per share calculation - diluted |  |  | 113,621 |  |  |  | 107,425 |  |  |  | 112,931 |  |  |  | 106,690 |  |

[0001564590-18-001403:8k_2_02:57]
EXTREME NETWORKS, INC.

[0001564590-18-001403:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-18-001403:8k_2_02:59]
(In thousands)

[0001564590-18-001403:8k_2_02:60]
(Unaudited)

[0001564590-18-001403:8k_2_02:61]
|  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Net cash provided by operating activities |  | $ | 14,248 |  |  | $ | 19,288 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (13,309 | ) |  |  | (4,662 | ) |
| Acquisitions |  |  | (97,581 | ) |  |  | (51,088 | ) |
| Proceeds from sale of non-marketable equity investment |  |  | 4,922 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (105,968 | ) |  |  | (55,750 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | 100,000 |  |  |  | 48,250 |  |
| Loan fees on borrowings |  |  | (1,494 | ) |  |  | (1,327 | ) |
| Repayments of debt |  |  | (8,686 | ) |  |  | (5,513 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | (1,536 | ) |  |  | 4,831 |  |
| Net cash provided by financing activities |  |  | 88,284 |  |  |  | 46,241 |  |
| Foreign currency effect on cash |  |  | 94 |  |  |  | (115 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (3,342 | ) |  |  | 9,664 |  |
| Cash and cash equivalents at beginning of period |  |  | 130,450 |  |  |  | 94,122 |  |
| Cash and cash equivalents at end of period |  | $ | 127,108 |  |  | $ | 103,786 |  |

[0001564590-18-001403:8k_2_02:62]
Extreme Networks, Inc.

[0001564590-18-001403:8k_2_02:63]
Non-GAAP Measures of Financial Performance

[0001564590-18-001403:8k_2_02:64]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001564590-18-001403:8k_2_02:65]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustments, restructuring charges, executive transition costs, litigation, amortization of acquired intangibles, restructuring expenses, executive transition expenses, litigation expenses, other income and income tax.

[0001564590-18-001403:8k_2_02:66]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-18-001403:8k_2_02:67]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures to enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-18-001403:8k_2_02:68]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, purchase accounting adjustments, acquired inventory adjustment, amortization of intangibles, restructuring charges, executive transition costs, litigation, other income and income tax.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-18-001403:8k_2_02:69]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-18-001403:8k_2_02:70]
Share-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-18-001403:8k_2_02:71]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Zebra Technologies Corporation’s wireless LAN business b) Avaya,

[0001564590-18-001403:8k_2_02:72]
Inc.’s, Campus Fabric business and c) Brocade’s Data Center assets; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-18-001403:8k_2_02:73]
Purchase accounting adjustments.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001564590-18-001403:8k_2_02:74]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-18-001403:8k_2_02:75]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-18-001403:8k_2_02:76]
Restructuring expenses. Restructuring expenses primarily consist of accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments and accelerated depreciation of leasehold improvements related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-18-001403:8k_2_02:77]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits and legal transition cash transactions.  The expenses are incurred through execution of pre-established employment contracts with senior executives.

[0001564590-18-001403:8k_2_02:78]
Litigation expenses. Litigation expenses consist of legal and professional fees and expenses related to our on-going ligation matters.

[0001564590-18-001403:8k_2_02:79]
Other income. Other income consists of the gain on the sale of our equity investment in a private company.

[0001564590-18-001403:8k_2_02:80]
Income tax.   Income tax adjustments relate to the tax impact of reducing the US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation as well as the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada.

[0001564590-18-001403:8k_2_02:81]
In addition to the non-GAAP measures discussed above, Extreme uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001564590-18-001403:8k_2_02:82]
EXTREME NETWORKS, INC.

[0001564590-18-001403:8k_2_02:83]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-18-001403:8k_2_02:84]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-18-001403:8k_2_02:85]
(In thousands, except percentages and per share amounts)

[0001564590-18-001403:8k_2_02:86]
(Unaudited)

[0001564590-18-001403:8k_2_02:87]
| Non-GAAP Revenue | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Revenue - GAAP Basis | $ | 231,123 |  |  | $ | 156,377 |  |  | $ | 442,838 |  |  | $ | 278,981 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchase accounting adjustment |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Revenue - Non-GAAP Basis | $ | 231,123 |  |  | $ | 156,377 |  |  | $ | 442,838 |  |  | $ | 279,114 |  |

[0001564590-18-001403:8k_2_02:88]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Gross profit - GAAP Basis | $ | 128,986 |  |  | $ | 79,652 |  |  | $ | 241,367 |  |  | $ | 145,538 |  |
| Gross margin - GAAP Basis percentage |  | 55.8 | % |  |  | 50.9 | % |  |  | 54.5 | % |  |  | 52.2 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 430 |  |  |  | 308 |  |  |  | 655 |  |  |  | 608 |  |
| Purchase accounting adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Acquired inventory adjustments |  | 1,249 |  |  |  | 2,300 |  |  |  | 4,187 |  |  |  | 2,300 |  |
| Acquisition and integration costs |  | 2,672 |  |  |  | 5,517 |  |  |  | 4,518 |  |  |  | 5,517 |  |
| Amortization of intangibles |  | 3,964 |  |  |  | 1,719 |  |  |  | 6,528 |  |  |  | 5,136 |  |
| Total adjustments to GAAP gross profit | $ | 8,315 |  |  | $ | 9,844 |  |  | $ | 15,888 |  |  | $ | 13,694 |  |
| Gross profit - Non-GAAP | $ | 137,301 |  |  | $ | 89,496 |  |  | $ | 257,255 |  |  | $ | 159,232 |  |
| Gross margin - Non-GAAP percentage |  | 59.4 | % |  |  | 57.2 | % |  |  | 58.1 | % |  |  | 57.0 | % |

[0001564590-18-001403:8k_2_02:89]
| Non-GAAP Operating Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| GAAP operating income (loss) | $ | (31,110 | ) |  | $ | (2,980 | ) |  | $ | (26,618 | ) |  | $ | (7,002 | ) |
| GAAP operating income (loss) percentage |  | (13.5 | )% |  |  | (1.9 | )% |  |  | (6.0 | )% |  |  | (2.5 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 7,025 |  |  |  | 3,381 |  |  |  | 11,828 |  |  |  | 6,856 |  |
| Acquisition and integration costs, net of bargain purchase gain |  | 36,787 |  |  |  | 9,686 |  |  |  | 42,877 |  |  |  | 12,007 |  |
| Restructuring charge, net of reversal |  | — |  |  |  | 1,853 |  |  |  | — |  |  |  | 1,853 |  |
| Acquired inventory adjustments |  | 1,249 |  |  |  | 2,300 |  |  |  | 4,187 |  |  |  | 2,300 |  |
| Amortization of intangibles |  | 6,710 |  |  |  | 3,894 |  |  |  | 10,888 |  |  |  | 11,453 |  |
| Purchase accounting adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Executive transition costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |
| Litigation |  | (365 | ) |  |  | 236 |  |  |  | (365 | ) |  |  | 263 |  |
| Total adjustments to GAAP operating income | $ | 51,406 |  |  | $ | 21,350 |  |  | $ | 69,415 |  |  | $ | 34,899 |  |
| Non-GAAP operating income | $ | 20,296 |  |  | $ | 18,370 |  |  | $ | 42,797 |  |  | $ | 27,897 |  |
| Non-GAAP operating income percentage |  | 8.8 | % |  |  | 11.7 | % |  |  | 9.7 | % |  |  | 10.0 | % |

[0001564590-18-001403:8k_2_02:90]
| Non-GAAP Net Income | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| GAAP net loss | $ | (31,923 | ) |  | $ | (4,229 | ) |  | $ | (27,547 | ) |  | $ | (9,971 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 7,025 |  |  |  | 3,381 |  |  |  | 11,828 |  |  |  | 6,856 |  |
| Acquisition and integration costs, net of bargain purchase gain |  | 36,787 |  |  |  | 9,686 |  |  |  | 42,877 |  |  |  | 12,007 |  |
| Restructuring charge, net of reversal |  | — |  |  |  | 1,853 |  |  |  | — |  |  |  | 1,853 |  |
| Acquired inventory adjustments |  | 1,249 |  |  |  | 2,300 |  |  |  | 4,187 |  |  |  | 2,300 |  |
| Amortization of intangibles |  | 6,710 |  |  |  | 3,894 |  |  |  | 10,888 |  |  |  | 11,453 |  |
| Purchase accounting adjustments |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |
| Executive transition costs |  | — |  |  |  | — |  |  |  | — |  |  |  | 34 |  |
| Litigation |  | (365 | ) |  |  | 236 |  |  |  | (365 | ) |  |  | 263 |  |
| Gain on sale of non-marketable equity investment |  | — |  |  |  | — |  |  |  | (3,757 | ) |  |  | — |  |
| Income tax |  | (3,102 | ) |  |  | — |  |  |  | (3,102 | ) |  |  | — |  |
| Total adjustments to GAAP net loss | $ | 48,304 |  |  | $ | 21,350 |  |  | $ | 62,556 |  |  | $ | 34,899 |  |
| Non-GAAP net income | $ | 16,381 |  |  | $ | 17,121 |  |  | $ | 35,009 |  |  | $ | 24,928 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.14 |  |  | $ | 0.16 |  |  | $ | 0.29 |  |  | $ | 0.23 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 119,646 |  |  |  | 110,152 |  |  |  | 119,038 |  |  |  | 109,394 |  |

[0001564590-18-001403:8k_2_02:91]
| Free Cash Flow | Three Months Ended |  |  | Six Months Ended |  |
|  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Cash flow (used in) provided by operations | $ | (4,350 | ) |  | $ | 9,714 |  |  | $ | 14,248 |  |  | $ | 19,288 |  |
| Less: PP&E CapEx spending |  | (5,888 | ) |  |  | (3,027 | ) |  |  | (13,309 | ) |  |  | (4,662 | ) |
| Total free cash flow | $ | (10,238 | ) |  | $ | 6,687 |  |  | $ | 939 |  |  | $ | 14,626 |  |
