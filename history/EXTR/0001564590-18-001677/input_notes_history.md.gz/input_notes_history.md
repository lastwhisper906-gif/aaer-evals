# EXTR note change history — 0001564590-17-023316 → 0001564590-18-001677


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-08):
[0001564590-18-001677:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2017, the Company had non-cancelable commitments to purchase $145.3 million of such inventory.  As of December 31, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $19.0 million of software and support services.
  (was, 2017-11-09, similarity 0.9911):
[0001564590-17-023316:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of September 30, 2017, the Company had non-cancelable commitments to purchase $115.1 million of such inventory.  As of September 30, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $20.3 million of software and support services.

- changed (2018-02-08):
[0001564590-18-001677:note_history:2]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (approximately U.S. $1.0 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of December 31, 2017.
  (was, 2017-11-09, similarity 0.8813):
[0001564590-17-023316:note_history:2]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (US $1.1 million), excluding interest and penalties. As of September 30, 2017, the total amount claimed by the Tax Authority—including accrued interest, penalties, and attorneys’ fees—is BRL 26.6 million (US $8.4 million).  All currency conversions in this Legal Proceedings section are as of September 30, 2017.

- changed (2018-02-08):
[0001564590-18-001677:note_history:3]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.7 million (approximately U.S. $5.1 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 31, 2017.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, has appealed the lower court’s decision and has requested a stay of execution.
  (was, 2017-11-09, similarity 0.7603):
[0001564590-17-023316:note_history:3]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court determined that Enterasys Brasil’s claim is “well grounded,” but nonetheless validated the assessment and penalty imposed by the Tax Authority.   The court did rule, however, that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.6 million (US $5.2 million), including penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2017.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, and expects to continue prosecuting vigorously its challenge to the assessment.  Enterasys Brasil has filed a motion for clarification and reconsideration, and, if the motion is denied, expects to appeal.

- changed (2018-02-08):
[0001564590-18-001677:note_history:4]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (approximately U.S. $2.9 million) as of the date the Company acquired Enterasys Networks.
  (was, 2017-11-09, similarity 0.9821):
[0001564590-17-023316:note_history:4]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (US $3.0 million) as of the date the Company acquired Enterasys Networks.

- changed (2018-02-08):
[0001564590-18-001677:note_history:5]
On October 23 and 29, 2015, putative class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  The Court held a hearing on Defendants’ motion to dismiss on December 14, 2017, and a ruling is expected in the next few months. The Company believes plaintiffs’ claims are without merit and intends to defend them vigorously.
  (was, 2017-11-09, similarity 0.9487):
[0001564590-17-023316:note_history:5]
On October 23 and 29, 2015, putative class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  Defendants’ motion to dismiss currently is scheduled to be heard on December 14, 2017. The Company believes plaintiffs’ claims are without merit and intends to defend them vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-08):
[0001564590-18-001677:note_history:6]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.
  (was, 2017-11-09, similarity 0.9907):
[0001564590-17-023316:note_history:6]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

- changed (2018-02-08):
[0001564590-18-001677:note_history:7]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2017. The results of operations for the three and six months ended December 31, 2017 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.
  (was, 2017-11-09, similarity 0.775):
[0001564590-17-023316:note_history:7]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2017. The results of operations for the three months ended September 30, 2017 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.

- added (2018-02-08):
[0001564590-18-001677:note_history:8]
Reclassification

- added (2018-02-08):
[0001564590-18-001677:note_history:9]
Certain amounts from prior years have been reclassified to conform to the current year’s presentation in the accompanying condensed consolidated statements of cash flow. The reclassification had no impact on previously reported net loss or accumulated deficit.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-08):
[0001564590-18-001677:note_history:10]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017. Except for the following policies, there have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.
  (was, 2017-11-09, similarity 0.9951):
[0001564590-17-023316:note_history:10]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017. Except for the following policy, there have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

- changed (2018-02-08):
[0001564590-18-001677:note_history:11]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.
  (was, 2017-11-09, similarity 0.9991):
[0001564590-17-023316:note_history:11]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e. when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which range from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

- changed (2018-02-08):
[0001564590-18-001677:note_history:12]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve-month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.
  (was, 2017-11-09, similarity 0.9994):
[0001564590-17-023316:note_history:12]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- changed (2018-02-08):
[0001564590-18-001677:note_history:13]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month and six-month periods ended December 31, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2017-11-09, similarity 0.9505):
[0001564590-17-023316:note_history:13]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month periods ended September 30, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2018-02-08):
[0001564590-18-001677:note_history:14]
On December 31, 2017, the Company had $152.4 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 54 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 31 percent by fiscal 2019 and 15 percent of the balance thereafter.
  (was, 2017-11-09, similarity 0.9718):
[0001564590-17-023316:note_history:14]
On September 30, 2017, the Company had $119.2 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 70 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 18 percent by fiscal 2019 and the balance thereafter.

- changed (2018-02-08):
[0001564590-18-001677:note_history:15]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.
  (was, 2017-11-09, similarity 0.9984):
[0001564590-17-023316:note_history:15]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue on the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- changed (2018-02-08):
[0001564590-18-001677:note_history:16]
Revenue recognized for the six-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $53.1 million and $49.7 million respectively. Revenue recognized for the three-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $36.9 million and $33.5 million, respectively.
  (was, 2017-11-09, similarity 0.6271):
[0001564590-17-023316:note_history:16]
Revenue recognized for the three month periods ended September 30, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each year was $42.1 million and $37.2 million respectively.

- changed (2018-02-08):
[0001564590-18-001677:note_history:17]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.0 million and $2.5 million at December 31, 2017 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three-month period ended December 31, 2017 and 2016, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the six-month period ended December 31, 2017 and 2016, was $0.9 million and $0.7 million, respectively.  There was no impairment loss in relation to the costs capitalized.
  (was, 2017-11-09, similarity 0.7868):
[0001564590-17-023316:note_history:17]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  These costs are included in selling and marketing expenses.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $2.5 million and $2.3 million at September 30, 2017 and 2016, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in sales and marketing expenses.  Amortization recognized during the three-month period ended September 30, 2017 and September 30, 2016, was $0.4 million and $0.3 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- changed (2018-02-08):
[0001564590-18-001677:note_history:18]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands, unaudited):
  (was, 2017-11-09, similarity 0.9851):
[0001564590-17-023316:note_history:18]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of our customers (in thousands, unaudited):

- changed (2018-02-08):
[0001564590-18-001677:note_history:19]
|  |  | Three Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |  | $ | 39,063 |  | $ | 38,396 |  | $ | 77,459 |  |
| Other |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |  |  | 2,827 |  |  | 3,243 |  |  | 6,070 |  |
| Total Americas |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |  |  | 41,890 |  |  | 41,639 |  |  | 83,529 |  |
| EMEA: |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |  |  | 36,070 |  |  | 24,361 |  |  | 60,431 |  |
| APAC: |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |  |  | 1,613 |  |  | 10,804 |  |  | 12,417 |  |
| Total net revenues |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |  | $ | 79,573 |  | $ | 76,804 |  | $ | 156,377 |  |
  (was, 2017-11-09, similarity 0.9897):
[0001564590-17-023316:note_history:19]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |  | $ | 26,991 |  | $ | 26,829 |  | $ | 53,820 |  |
| Other |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |  |  | 1,393 |  |  | 9,628 |  |  | 11,021 |  |
| Total Americas |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |  |  | 28,384 |  |  | 36,457 |  |  | 64,841 |  |
| EMEA: |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |  |  | 31,299 |  |  | 16,529 |  |  | 47,828 |  |
| APAC: |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |  |  | 1,452 |  |  | 8,483 |  |  | 9,935 |  |
| Total net revenues |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |  | $ | 61,135 |  | $ | 61,469 |  | $ | 122,604 |  |

- added (2018-02-08):
[0001564590-18-001677:note_history:20]
|  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |  | $ | 66,054 |  | $ | 65,225 |  | $ | 131,279 |  |
| Other |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |  |  | 4,220 |  |  | 12,871 |  |  | 17,091 |  |
| Total Americas |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |  |  | 70,274 |  |  | 78,096 |  |  | 148,370 |  |
| EMEA: |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |  |  | 67,369 |  |  | 40,890 |  |  | 108,259 |  |
| APAC: |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |  |  | 3,065 |  |  | 19,287 |  |  | 22,352 |  |
| Total net revenues |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |  | $ | 140,708 |  | $ | 138,273 |  | $ | 278,981 |  |


## us-gaap:DebtPolicyTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-08):
[0001564590-18-001677:note_history:21]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,964 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (538 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 22,426 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 152,062 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,350 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 160,712 |  |  |  | 80,422 |  |
| Total debt |  | $ | 183,138 |  |  | $ | 92,702 |  |
  (was, 2017-11-09, similarity 0.9938):
[0001564590-17-023316:note_history:21]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 18,418 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (555 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 17,863 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 141,202 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,473 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 149,729 |  |  |  | 80,422 |  |
| Total debt |  | $ | 167,592 |  |  | $ | 92,702 |  |

- changed (2018-02-08):
[0001564590-18-001677:note_history:22]
In connection with the closing of Campus Fabric Business discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.
  (was, 2017-11-09, similarity 0.9659):
[0001564590-17-023316:note_history:22]
In connection with the closing of Avaya Networking discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed an additional $80.0 million under the Term Loan which was used to fund the purchase of Avaya Networking.

- added (2018-02-08):
[0001564590-18-001677:note_history:23]
In connection with the closing of the acquisition of the Data Center Business discussed in Note 2, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”) on October 26, 2017. Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement (as defined above). On the Brocade Closing Date, the Company borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.

- changed (2018-02-08):
[0001564590-18-001677:note_history:24]
The Company had $1.2 million of outstanding letters of credit and $48.8 million of availability under the Revolver as of December 31, 2017.
  (was, 2017-11-09, similarity 0.9805):
[0001564590-17-023316:note_history:24]
The Company had $0.9 million of outstanding letters of credit and $49.1 million of availability under the Revolver as of September 30, 2017.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-08):
[0001564590-18-001677:note_history:25]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,964 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (538 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 22,426 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 152,062 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,350 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 160,712 |  |  |  | 80,422 |  |
| Total debt |  | $ | 183,138 |  |  | $ | 92,702 |  |
  (was, 2017-11-09, similarity 0.9938):
[0001564590-17-023316:note_history:25]
|  |  | September 30, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 18,418 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (555 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 17,863 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 141,202 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,473 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 149,729 |  |  |  | 80,422 |  |
| Total debt |  | $ | 167,592 |  |  | $ | 92,702 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-02-08):
[0001564590-18-001677:note_history:26]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.
  (was, 2017-11-09, similarity 0.9991):
[0001564590-17-023316:note_history:26]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e. when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which range from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

- changed (2018-02-08):
[0001564590-18-001677:note_history:27]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve-month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.
  (was, 2017-11-09, similarity 0.9994):
[0001564590-17-023316:note_history:27]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

- changed (2018-02-08):
[0001564590-18-001677:note_history:28]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month and six-month periods ended December 31, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2017-11-09, similarity 0.9505):
[0001564590-17-023316:note_history:28]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month periods ended September 30, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2018-02-08):
[0001564590-18-001677:note_history:29]
On December 31, 2017, the Company had $152.4 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 54 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 31 percent by fiscal 2019 and 15 percent of the balance thereafter.
  (was, 2017-11-09, similarity 0.9718):
[0001564590-17-023316:note_history:29]
On September 30, 2017, the Company had $119.2 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 70 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 18 percent by fiscal 2019 and the balance thereafter.

- changed (2018-02-08):
[0001564590-18-001677:note_history:30]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.
  (was, 2017-11-09, similarity 0.9984):
[0001564590-17-023316:note_history:30]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue on the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- changed (2018-02-08):
[0001564590-18-001677:note_history:31]
Revenue recognized for the six-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $53.1 million and $49.7 million respectively. Revenue recognized for the three-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $36.9 million and $33.5 million, respectively.
  (was, 2017-11-09, similarity 0.6271):
[0001564590-17-023316:note_history:31]
Revenue recognized for the three month periods ended September 30, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each year was $42.1 million and $37.2 million respectively.

- changed (2018-02-08):
[0001564590-18-001677:note_history:32]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.0 million and $2.5 million at December 31, 2017 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three-month period ended December 31, 2017 and 2016, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the six-month period ended December 31, 2017 and 2016, was $0.9 million and $0.7 million, respectively.  There was no impairment loss in relation to the costs capitalized.
  (was, 2017-11-09, similarity 0.7868):
[0001564590-17-023316:note_history:32]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  These costs are included in selling and marketing expenses.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $2.5 million and $2.3 million at September 30, 2017 and 2016, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in sales and marketing expenses.  Amortization recognized during the three-month period ended September 30, 2017 and September 30, 2016, was $0.4 million and $0.3 million, respectively.  There was no impairment loss in relation to the costs capitalized.

- changed (2018-02-08):
[0001564590-18-001677:note_history:33]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands, unaudited):
  (was, 2017-11-09, similarity 0.9851):
[0001564590-17-023316:note_history:33]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of our customers (in thousands, unaudited):

- changed (2018-02-08):
[0001564590-18-001677:note_history:34]
|  |  | Three Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |  | $ | 39,063 |  | $ | 38,396 |  | $ | 77,459 |  |
| Other |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |  |  | 2,827 |  |  | 3,243 |  |  | 6,070 |  |
| Total Americas |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |  |  | 41,890 |  |  | 41,639 |  |  | 83,529 |  |
| EMEA: |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |  |  | 36,070 |  |  | 24,361 |  |  | 60,431 |  |
| APAC: |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |  |  | 1,613 |  |  | 10,804 |  |  | 12,417 |  |
| Total net revenues |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |  | $ | 79,573 |  | $ | 76,804 |  | $ | 156,377 |  |
  (was, 2017-11-09, similarity 0.9897):
[0001564590-17-023316:note_history:34]
|  |  | Three Months Ended |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 42,392 |  | $ | 50,990 |  | $ | 93,382 |  |  | $ | 26,991 |  | $ | 26,829 |  | $ | 53,820 |  |
| Other |  |  | 14,336 |  |  | 6,395 |  |  | 20,731 |  |  |  | 1,393 |  |  | 9,628 |  |  | 11,021 |  |
| Total Americas |  |  | 56,728 |  |  | 57,385 |  |  | 114,113 |  |  |  | 28,384 |  |  | 36,457 |  |  | 64,841 |  |
| EMEA: |  |  | 51,232 |  |  | 27,903 |  |  | 79,135 |  |  |  | 31,299 |  |  | 16,529 |  |  | 47,828 |  |
| APAC: |  |  | 3,264 |  |  | 15,203 |  |  | 18,467 |  |  |  | 1,452 |  |  | 8,483 |  |  | 9,935 |  |
| Total net revenues |  | $ | 111,224 |  | $ | 100,491 |  | $ | 211,715 |  |  | $ | 61,135 |  | $ | 61,469 |  | $ | 122,604 |  |

- added (2018-02-08):
[0001564590-18-001677:note_history:35]
|  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |  | $ | 66,054 |  | $ | 65,225 |  | $ | 131,279 |  |
| Other |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |  |  | 4,220 |  |  | 12,871 |  |  | 17,091 |  |
| Total Americas |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |  |  | 70,274 |  |  | 78,096 |  |  | 148,370 |  |
| EMEA: |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |  |  | 67,369 |  |  | 40,890 |  |  | 108,259 |  |
| APAC: |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |  |  | 3,065 |  |  | 19,287 |  |  | 22,352 |  |
| Total net revenues |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |  | $ | 140,708 |  | $ | 138,273 |  | $ | 278,981 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-02-08):
[0001564590-18-001677:note_history:36]
On January 31, 2018, the Company approved and on February 2, 2018 began executing a reduction-in-force (the “Plan”) to re-align the Company’s resources as a result of the Company’s recent acquisitions of the Campus Fabric Business and the Data Center Business. The Plan is expected to reduce the overall costs of the Company and to accelerate the achievement of the Company’s operating margin target objectives. The Company expects to incur charges of approximately $4.0 million in connection with the Plan. Upon completion of the Plan, the potential savings expected to be achieved as a result of reduced employee related expenses and lower operating costs will yield annualized savings of $7.0 - $9.0 million. The costs associated with this Plan primarily include employee severance and benefits expenses.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.

- removed (2018-02-08):
[0001564590-17-023316:note_history:37]
On October 27, 2017 (the “Brocade Closing Date”), the Company completed its acquisition of Brocade Communication Systems, Inc.’s (“Brocade”) switching, routing and analytics business (“Brocade SRA”), that had been announced on October 3, 2017. Under the terms and subject to the conditions of the Brocade Asset Purchase Agreement (“Brocade Purchase Agreement”), the Company acquired customers, employees, technology and other assets of Brocade SRA, as well as assumed certain contracts and other liabilities of Brocade SRA, for an upfront cash closing payment equal to $23.0 million, plus a deferred payment equal to $20.0 million to be paid $1 million per quarter for 20 quarters following the Brocade Closing Date, plus quarterly earn out payments equal to 50% of profits of Brocade SRA, with certain deductions per the terms of the Brocade Purchase Agreement for the five-year period commencing at the end of our first full fiscal quarter following the Brocade Closing Date. The Company is still evaluating the estimated consideration from the earn out provision.  In conjunction with the acquisition, Extreme paid a fee of $25.0 million to Broadcom, Inc. in October 2017, for the right to acquire the Brocade SRA business.

- removed (2018-02-08):
[0001564590-17-023316:note_history:38]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Brocade SRA will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets. Results of operations of Brocade SRA will be included in the Company’s operations beginning with the Brocade Closing Date, As of the date of filing this Form 10-Q, the initial purchase price allocation has not been prepared as there has not been sufficient time to complete the related activities.

- removed (2018-02-08):
[0001564590-17-023316:note_history:39]
On October 26, 2017, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”). Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement (as defined above). On the Brocade Closing Date to partially fund the acquisition of the Brocade SRA acquisition, the Company drew $20.0 million on the Term Loan.
