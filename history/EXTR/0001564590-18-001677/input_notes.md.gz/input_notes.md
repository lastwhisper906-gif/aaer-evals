# EXTR notes — 0001564590-18-001677


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-001677:notes:1]
[same as prior period, unchanged from 0001564590-17-023316:notes:1]

[0001564590-18-001677:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-18-001677:notes:3]
[same as prior period, unchanged from 0001564590-17-023316:notes:3]

[0001564590-18-001677:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2017. The results of operations for the three and six months ended December 31, 2017 are not necessarily indicative of the results that may be expected for fiscal 2018 or any future periods.

[0001564590-18-001677:notes:5]
Effective July 1, 2017, the Company adopted the requirements of Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers. All amounts and disclosures set forth in this Form 10-Q have been updated to comply with the new standards, as indicated by the “as adjusted” footnote.

[0001564590-18-001677:notes:6]
[same as prior period, unchanged from 0001564590-17-023316:notes:6]

[0001564590-18-001677:notes:7]
[same as prior period, unchanged from 0001564590-17-023316:notes:7]

[0001564590-18-001677:notes:8]
[same as prior period, unchanged from 0001564590-17-023316:notes:8]

[0001564590-18-001677:notes:9]
[same as prior period, unchanged from 0001564590-17-023316:notes:9]

[0001564590-18-001677:notes:10]
[same as prior period, unchanged from 0001564590-17-023316:notes:10]

[0001564590-18-001677:notes:11]
[same as prior period, unchanged from 0001564590-17-023316:notes:11]

[0001564590-18-001677:notes:12]
[same as prior period, unchanged from 0001564590-17-023316:notes:12]

[0001564590-18-001677:notes:13]
Reclassification

[0001564590-18-001677:notes:14]
Certain amounts from prior years have been reclassified to conform to the current year’s presentation in the accompanying condensed consolidated statements of cash flow. The reclassification had no impact on previously reported net loss or accumulated deficit.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-001677:notes:15]
[same as prior period, unchanged from 0001564590-17-023316:notes:13]

[0001564590-18-001677:notes:16]
The Company completed three acquisitions during the six months ended December 31, 2017. The acquisitions have been accounted for using the acquisition method of accounting.  The purchase price has been allocated on a preliminary basis to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach.  The fair value of property and equipment was determined using a cost approach.  The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay to a third party to assume the obligation.  Valuations of the intangible assets were valued using income approaches based on management projections, which we consider to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition.

[0001564590-18-001677:notes:17]
The final purchase price allocation is pending the finalization of valuations, which may result in an adjustment to the preliminary purchase price allocation. Also, additional information which existed as of the acquisition dates, but was unknown to the Company at that time, may become known to the Company during the remainder of the measurement period (up to one year from the acquisition dates), and may result in a change in the purchase price allocation.  While management believes that its preliminary estimates and assumptions underlying the valuations are reasonable, different estimates and assumptions could result in different valuations assigned to the individual assets acquired and liabilities assumed, and the resulting amount of goodwill. Results of operations of the acquired entities are included in the Company’s operations beginning with the closing date of each acquisition.

[0001564590-18-001677:notes:18]
Fiscal 2018 Acquisitions

[0001564590-18-001677:notes:19]
Data Center Business

[0001564590-18-001677:notes:20]
On October 27, 2017 (the “Brocade Closing”), the Company completed its acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc.’s (“Brocade”), pursuant to an Asset Purchase Agreement (the “Brocade APA”) dated as of October 3, 2017, by and between the Company and Brocade. Under the terms and conditions of the Brocade APA, the Company acquired customers, employees, technology and other assets of the Data Center Business as well as assumed certain contracts and other liabilities of the Data Center Business.

[0001564590-18-001677:notes:21]
The fair value of consideration transferred on the Brocade Closing date includes:

[0001564590-18-001677:notes:22]
|  | • | upfront cash closing payment equal to $23.0 million, |

[0001564590-18-001677:notes:23]
|  | • | deferred payments of $1.0 million per quarter for the next twenty full fiscal quarters of the Company following the acquisition date discounted to their present value, |

[0001564590-18-001677:notes:24]
|  | • | contingent consideration in the form of quarterly earnout payments equal to 50% of the profits of the Data Center Business for the five-year period commencing at the end of the first full fiscal quarter of the Company following the acquisition of the Data Center Business discounted to their present value, |

[0001564590-18-001677:notes:25]
|  | • | an amount payable due to the excess working capital acquired over the target working capital agreed upon in the Brocade APA, and, |

[0001564590-18-001677:notes:26]
|  | • | portion of the fair value of replacement stock awards granted to employees assumed from Brocade for which their services were provided prior to the Brocade Closing date. |

[0001564590-18-001677:notes:27]
The components of aggregate estimated purchase consideration are as follows (in thousands):

[0001564590-18-001677:notes:28]
| Estimated purchase consideration | October 27, 2017 |  |
| Cash paid to sellers at closing | $ | 23,000 |  |
| Deferred payments |  | 18,430 |  |
| Contingent consideration |  | 34,100 |  |
| Working capital adjustment |  | 6,534 |  |
| Replacement of stock-based awards |  | 2,273 |  |
| Aggregate estimated purchase consideration | $ | 84,337 |  |

[0001564590-18-001677:notes:29]
The following table below summarizes the preliminary allocation as of October 27, 2017 of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-18-001677:notes:30]
|  | Preliminary Allocation as of October 27, 2017 |  |
| Accounts receivables | $ | 33,488 |  |
| Inventories |  | 19,973 |  |
| Prepaid expenses and other current assets |  | 988 |  |
| Property and equipment |  | 29,160 |  |
| Other assets |  | 4,734 |  |
| Accounts payable and accrued expenses |  | (15,850 | ) |
| Deferred revenue |  | (33,519 | ) |
| Net tangible assets acquired |  | 38,974 |  |
| Identifiable intangible assets |  | 28,600 |  |
| Goodwill |  | 16,763 |  |
| Total intangible assets acquired |  | 45,363 |  |
| Total net assets acquired | $ | 84,337 |  |

[0001564590-18-001677:notes:31]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands, except years):

[0001564590-18-001677:notes:32]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  | 2 - 5 |  |  | $ | 21,800 |  |
| Customer relationships |  |  | 5 |  |  |  | 5,400 |  |
| Trade names |  |  | 4 |  |  |  | 1,400 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 28,600 |  |

[0001564590-18-001677:notes:33]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying condensed consolidated statements of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the Data Center Business.  The Company anticipates both the goodwill and intangible assets to be fully deductible for income tax purposes.

[0001564590-18-001677:notes:34]
The results of operations of the Data Center Business are included with those of the Company beginning October 28, 2017.  The associated expenses of the Data Center Business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available.  In the three and six months ended December 31, 2017 the Company incurred $32.5 million and $33.8 million, respectively, of acquisition and integration related expenses associated with the acquisition of the Data Center Business, including a $25.0 consent fee paid to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom Corporation, in anticipation of Broadcom’s proposed acquisition of Brocade. The fee was paid to allow the Company to buy the Data Center Business directly from Brocade.  Such acquisition-related costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations. The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants and companies.

[0001564590-18-001677:notes:35]
Campus Fabric Business

[0001564590-18-001677:notes:36]
On July 14, 2017, (the “Avaya Closing Date”) the Company completed its acquisition of Avaya Inc.’s. (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) that had been announced on March 7, 2017.  Upon the terms and subject to the conditions of the Asset Purchase Agreement (the “Avaya APA”), the Company acquired the customers, employees, technology and other assets of the Campus Fabric Business, as well as assumed certain contracts and other liabilities of the Campus Fabric Business, for total provisional consideration of $79.8 million, calculated as $100.0 million, less adjustments set forth in the Avaya APA related to net working capital, deferred revenue, certain assumed lease obligations and certain assumed pension obligations for transferring employees of the Campus Fabric Business.  Pursuant to certain ancillary agreements, Avaya will also provide the Company with transition services for a period of time following the Avaya Closing Date. As a condition of the Avaya APA, the Company had made deposits of $10.2 million in the third quarter of fiscal 2017, which were applied to the purchase price upon the Avaya Closing Date.

[0001564590-18-001677:notes:37]
The following table below summarizes the preliminary allocation as of December 31, 2017 of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-18-001677:notes:38]
|  | Preliminary Allocation as of September 30, 2017 |  |  | Change during three months ended December 31, 2017 |  |  | Preliminary Allocation as of December 31, 2017 |  |
| Accounts receivables | $ | 18,112 |  |  | $ | 183 |  | (a) | $ | 18,295 |  |
| Inventories |  | 16,605 |  |  |  | (1,060 | ) | (b)(c) |  | 15,545 |  |
| Prepaid expenses and other current assets |  | 673 |  |  |  | — |  |  |  | 673 |  |
| Property and equipment |  | 3,768 |  |  |  | — |  |  |  | 3,768 |  |
| Other assets |  | 2,568 |  |  |  | 2,743 |  | (c) |  | 5,311 |  |
| Accounts payable and accrued expenses |  | (29,716 | ) |  |  | (2,203 | ) | (d)(f) |  | (31,919 | ) |
| Deferred revenue |  | (10,214 | ) |  |  | 163 |  | (d)(e) |  | (10,051 | ) |
| Other long-term liabilities |  | (6,608 | ) |  |  | 1,403 |  | (f) |  | (5,205 | ) |
| Net tangible assets acquired |  | (4,812 | ) |  |  | 1,229 |  |  |  | (3,583 | ) |
| Identifiable intangible assets |  | 44,000 |  |  |  | 2,900 |  | (g) |  | 46,900 |  |
| In-process research and development |  | 2,300 |  |  |  | 200 |  | (g) |  | 2,500 |  |
| Goodwill |  | 38,338 |  |  |  | (4,329 | ) |  |  | 34,009 |  |
| Total intangible assets acquired |  | 84,638 |  |  |  | (1,229 | ) |  |  | 83,409 |  |
| Total net assets acquired | $ | 79,826 |  |  | $ | — |  |  | $ | 79,826 |  |

[0001564590-18-001677:notes:39]
The changes during the period in the table above include: a) additional information on accounts receivable as of the acquisition date, b) additional receipts of product, c) a reclassification from inventories to other assets related to service parts, d) a reclassification from deferred revenue to accounts payable, e) an adjustment of the fair value of deferred maintenance revenue, f) a reclassification from long-term liabilities to short-term related to liabilities assumed, g) revised net realizable value based on usefulness of identifiable intangible assets and in-process research and development acquired.

[0001564590-18-001677:notes:40]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 6 |  |  | $ | 37,400 |  |
| Customer relationships |  |  | 4 |  |  |  | 5,100 |  |
| Trademarks |  |  | 5 |  |  |  | 2,600 |  |
| Backlog |  |  | 1 |  |  |  | 1,800 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 46,900 |  |

[0001564590-18-001677:notes:41]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying condensed consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the Campus Fabric Business.  The Company anticipates both the goodwill and intangible assets to be fully deductible for income tax purposes.

[0001564590-18-001677:notes:42]
The Company also acquired an indefinite lived asset of $2.5 million which represents the fair value of in-process research and development activities.  Once the related research and development efforts are completed, the Company will determine whether the asset will continue to be an indefinite lived asset or become a finite lived asset and apply the appropriate accounting accordingly.

[0001564590-18-001677:notes:43]
The results of operations of the Campus Fabric Business are included in the accompanying condensed consolidated results of operations beginning July 14, 2017.  The associated expenses of the Campus Fabric Business have been incorporated with the results of operations of the Company as a product line and, therefore, stand-alone operating results are not available. In the three and six months ended December 31, 2017, the Company incurred $6.6 million and $9.5 million, respectively, of acquisition and integration related expenses associated with the acquisition of the Campus Fabric Business.  Such acquisition-related costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees to financial and legal advisors and IT consultants and companies.

[0001564590-18-001677:notes:44]
Capital Financing Business

[0001564590-18-001677:notes:45]
On December 1, 2017, Company completed its acquisition of a capital financing business (the “CF Business”), pursuant to a Bill of Sale and Assignment and Assumption Agreement (the “Assumption Agreement”) between the Company and Broadcom.  Under the terms and conditions of the Assumption Agreement, the Company acquired customers, employees, contracts and lease equipment of the CF Business equal to the earn out payments to Broadcom of 90% of acquired financing receivables to be collected commencing at the closing date.

[0001564590-18-001677:notes:46]
Net assets acquired included financing receivables of $13.8 million, lease equipment of $3.5 million and identifiable intangible assets of $0.6 million, and the fair value of the contingent consideration was $12.9 million. As the preliminary fair value of the net assets acquired exceeded the fair value of the purchase consideration, the Company recorded a gain from the bargain purchase of $4.9 million in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations for the second quarter of fiscal 2018.  Acquisition and integration related expenses associated with the acquisition of the CF Business were immaterial.

[0001564590-18-001677:notes:47]
Fiscal 2017 Acquisition

[0001564590-18-001677:notes:48]
On October 28, 2016, the Company completed the acquisition of the wireless local area network business (“WLAN Business”) from Zebra Technologies Corporation.  Under the terms of the WLAN Asset Purchase Agreement, the Company acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for a net cash consideration to $49.5 million.  The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001564590-18-001677:notes:49]
|  | Final Allocation as of October 28, 2016 |  |
| Accounts receivables, net | $ | 14,636 |  |
| Inventories |  | 13,593 |  |
| Other current assets |  | 808 |  |
| Property and equipment |  | 3,159 |  |
| Other assets |  | 7,634 |  |
| Deferred revenue |  | (14,159 | ) |
| Other liabilities |  | (7,201 | ) |
| Total tangible assets acquired and liabilities assumed |  | 18,470 |  |
| Identifiable intangible assets |  | 20,300 |  |
| In-process research and development |  | 1,400 |  |
| Goodwill |  | 9,339 |  |
| Total intangible assets acquired |  | 31,039 |  |
| Total net assets acquired | $ | 49,509 |  |

[0001564590-18-001677:notes:50]
[same as prior period, unchanged from 0001564590-17-023316:notes:31]

[0001564590-18-001677:notes:51]
The following unaudited pro forma results of operations are presented as though the acquisitions of the Data Center Business, CF Business, Campus Fabric Business and WLAN Businesses had occurred as of the beginning of the earliest period presented after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-18-001677:notes:52]
[same as prior period, unchanged from 0001564590-17-023316:notes:33]

[0001564590-18-001677:notes:53]
The unaudited pro forma financial information for the three and six months ended December 31, 2017, combines the results for Extreme for the three and six months ended December 31, 2017, which include the results of the Data Center Business, CF Business and Campus Fabric Business subsequent to the acquisition date and their historical results up to the acquisition date.

[0001564590-18-001677:notes:54]
The unaudited pro forma financial information for the three and six months ended December 31, 2016, combines the historical results for Extreme for those periods, as adjusted for the adoption of ASC 606, with the historical results of the Data Center Business, CF Business and Campus Fabric Business for the three and six months ended December 31, 2016, as well as the historical results of the WLAN Business up to the acquisition date.

[0001564590-18-001677:notes:55]
Pro forma results of operations from the Data Center Business, CF Business, Campus Fabric Business and WLAN Business acquisitions included in the pro forma results of operations for the three and six months ended December 31, 2016 or 2017 have not been adjusted for the adoption of ASC 606 because the Company determined that it is impractical to estimate the impact of the adoption.

[0001564590-18-001677:notes:56]
[same as prior period, unchanged from 0001564590-17-023316:notes:36]

[0001564590-18-001677:notes:57]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Net revenues |  | $ | 252,532 |  |  | $ | 311,503 |  |  | $ | 537,040 |  |  | $ | 644,435 |  |
| Net income (loss) |  | $ | 1,152 |  |  | $ | (62,134 | ) |  | $ | (7,622 | ) |  | $ | (95,972 | ) |
| Net income (loss) per share - basic |  | $ | 0.01 |  |  | $ | (0.58 | ) |  | $ | (0.07 | ) |  | $ | (0.90 | ) |
| Net income (loss) per share - diluted |  | $ | 0.01 |  |  | $ | (0.58 | ) |  | $ | (0.07 | ) |  | $ | (0.90 | ) |
| Shares used in per share calculation - basic |  |  | 113,621 |  |  |  | 107,425 |  |  |  | 112,931 |  |  |  | 106,690 |  |
| Shares used in per share calculation - diluted |  |  | 119,656 |  |  |  | 107,425 |  |  |  | 112,931 |  |  |  | 106,690 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-001677:notes:58]
[same as prior period, unchanged from 0001564590-17-023316:notes:38]

[0001564590-18-001677:notes:59]
For a description of significant accounting policies, see Note 3, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2017. Except for the following policies, there have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-18-001677:notes:60]
[same as prior period, unchanged from 0001564590-17-023316:notes:40]

[0001564590-18-001677:notes:61]
[same as prior period, unchanged from 0001564590-17-023316:notes:41]

[0001564590-18-001677:notes:62]
[same as prior period, unchanged from 0001564590-17-023316:notes:42]

[0001564590-18-001677:notes:63]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-18-001677:notes:64]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve-month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-18-001677:notes:65]
[same as prior period, unchanged from 0001564590-17-023316:notes:45]

[0001564590-18-001677:notes:66]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the consolidated statements of operations for the three-month and six-month periods ended December 31, 2017, and 2016 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-18-001677:notes:67]
On December 31, 2017, the Company had $152.4 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 54 percent of its remaining performance obligations as revenue in fiscal 2018, an additional 31 percent by fiscal 2019 and 15 percent of the balance thereafter.

[0001564590-18-001677:notes:68]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

[0001564590-18-001677:notes:69]
Revenue recognized for the six-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $53.1 million and $49.7 million respectively. Revenue recognized for the three-month periods ended December 31, 2017 and 2016, that was included in the deferred revenue balance at the beginning of each period was $36.9 million and $33.5 million, respectively.

[0001564590-18-001677:notes:70]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company capitalized them as contract costs in the amount of $3.0 million and $2.5 million at December 31, 2017 and June 30, 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three-month period ended December 31, 2017 and 2016, was $0.5 million and $0.4 million, respectively.  Amortization recognized during the six-month period ended December 31, 2017 and 2016, was $0.9 million and $0.7 million, respectively.  There was no impairment loss in relation to the costs capitalized.

[0001564590-18-001677:notes:71]
Revenue by Category: The following table sets forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands, unaudited):

[0001564590-18-001677:notes:72]
|  |  | Three Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |  | $ | 39,063 |  | $ | 38,396 |  | $ | 77,459 |  |
| Other |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |  |  | 2,827 |  |  | 3,243 |  |  | 6,070 |  |
| Total Americas |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |  |  | 41,890 |  |  | 41,639 |  |  | 83,529 |  |
| EMEA: |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |  |  | 36,070 |  |  | 24,361 |  |  | 60,431 |  |
| APAC: |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |  |  | 1,613 |  |  | 10,804 |  |  | 12,417 |  |
| Total net revenues |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |  | $ | 79,573 |  | $ | 76,804 |  | $ | 156,377 |  |

[0001564590-18-001677:notes:73]
|  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |  | $ | 66,054 |  | $ | 65,225 |  | $ | 131,279 |  |
| Other |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |  |  | 4,220 |  |  | 12,871 |  |  | 17,091 |  |
| Total Americas |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |  |  | 70,274 |  |  | 78,096 |  |  | 148,370 |  |
| EMEA: |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |  |  | 67,369 |  |  | 40,890 |  |  | 108,259 |  |
| APAC: |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |  |  | 3,065 |  |  | 19,287 |  |  | 22,352 |  |
| Total net revenues |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |  | $ | 140,708 |  | $ | 138,273 |  | $ | 278,981 |  |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001564590-18-001677:notes:74]
4.Recent Accounting Pronouncements

[0001564590-18-001677:notes:75]
Recently Issued Accounting Pronouncements

[0001564590-18-001677:notes:76]
In August 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (ASU) 2017-12, Derivatives and Hedging (Topic 815) – Targeted Improvements to Accounting for Hedging Activities (“ASU 2017-12”), which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. The guidance is effective for fiscal years beginning after December 15, 2018. The Company is evaluating the accounting, transition and disclosure requirements of the standard and cannot currently estimate the financial statement impact of adoption. This guidance is effective for the Company beginning with its fiscal year 2020.

[0001564590-18-001677:notes:77]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718) - Scope of Modification Accounting (“ASU 2017-09”) which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under ASC 718. Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The guidance is effective prospectively for fiscal years beginning after December 15, 2017, and interim periods within that reporting period. Early adoption is permitted, including adoption in any interim period. The Company does not expect the adoption of this guidance to have a material effect on our financial statements. This guidance will be effective for the Company beginning with its fiscal year 2019.

[0001564590-18-001677:notes:78]
In January 2016, the FASB issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities.  The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2019.

[0001564590-18-001677:notes:79]
In February 2016, the FASB issued ASU No. 2016-02 (Topic 842), Leases (“ASU 2016-02”) which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under ASU 2016-02, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of ASU 2016-02 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, ASU 2016-02 requires the use of the modified retrospective method, which will require adjustment to all comparative periods presented in the consolidated financial statements. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures. This guidance will become effective for the Company beginning with its fiscal year 2020.

[0001564590-18-001677:notes:80]
Recently Adopted Accounting Pronouncements

[0001564590-18-001677:notes:81]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), to clarify the principles of recognizing revenue and create common revenue recognition guidance between U.S. GAAP and International Financial Reporting Standards. Under ASU 2014-09, revenue is recognized when a customer obtains control of promised goods or services and is recognized at an amount that reflects the consideration expected to be received in exchange for such goods or services.  In addition, ASU 2014-09 requires disclosure of the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers.

[0001564590-18-001677:notes:82]
The Company adopted Topic 606 on July 1, 2017, using the full retrospective method. This adoption primarily affected the Company’s accounting for distributor and resellers revenues from a primarily “sell-through” model, where revenue is recognized upon the sale from the distribution channel to the end customer, to the “sell-in” method where revenue is recognized upon transfer of control to its customers, including distributors. Under the sell-in method, the Company is required to make estimates at the time of shipment to its distributors of variable consideration as well as estimated returns under stock rotation rights granted to the distributors.  Additionally, the Company capitalizes contract acquisition costs such as commissions paid for maintenance services contracts in excess of one year.  Following the adoption of ASU 2014-09, the revenue recognition for the Company’s other sales arrangements remained materially consistent with our historical practice.

[0001564590-18-001677:notes:83]
Upon adoption of Topic 606, we applied the standard’s practical expedients that allows a) an entity to use the transaction price at the date the contract was completed rather than estimating variable consideration amounts in the comparative reporting periods, b) that permits the omission of prior-period information about our performance obligations, and c) that allows the Company to reflect the aggregate effect of all modifications that occur before the beginning of the earliest period presented when identifying the satisfied and unsatisfied performance obligations, determining the transaction price and allocating the transaction price to the satisfied and unsatisfied performance obligations.

[0001564590-18-001677:notes:84]
See the tables at the end of this note for the effects of the adoption of ASU 2014-09 on our condensed consolidated financial statements as of June 30, 2017, and for the three and six months ended December 31, 2016.  See Note 3. “Summary of Significant Accounting Policies” to our condensed consolidated financial statements for further discussion of the effects of the adoption of ASU 2014-09 on our significant accounting policies.

[0001564590-18-001677:notes:85]
Adjustments to Previously Reported Financial Statements from the Adoption of Accounting Pronouncements

[0001564590-18-001677:notes:86]
The following table presents the effect of the adoption of ASU 2014-09 on our condensed consolidated balance sheet (unaudited) as of June 30, 2017, (in thousands):

[0001564590-18-001677:notes:87]
|  | As of June 30, 2017 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Accounts receivable, net | $ | 120,770 |  |  | $ | (27,655 | ) |  | $ | 93,115 |  |
| Inventories |  | 45,880 |  |  |  | 1,530 |  |  |  | 47,410 |  |
| Total current assets |  | 324,967 |  |  |  | (26,125 | ) |  |  | 298,842 |  |
| Other assets |  | 22,586 |  |  |  | 2,479 |  |  |  | 25,065 |  |
| Total assets |  | 483,346 |  |  |  | (23,646 | ) |  |  | 459,700 |  |
| Accrued warranty |  | 10,007 |  |  |  | 577 |  |  |  | 10,584 |  |
| Other accrued liabilities |  | 36,713 |  |  |  | 331 |  |  |  | 37,044 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 43,525 |  |  |  | (43,525 | ) |  |  | — |  |
| Total current liabilities |  | 255,822 |  |  |  | (42,617 | ) |  |  | 213,205 |  |
| Accumulated deficit |  | (800,257 | ) |  |  | 18,971 |  |  |  | (781,286 | ) |
| Total stockholders’ equity |  | 106,707 |  |  |  | 18,971 |  |  |  | 125,678 |  |
| Total liabilities and stockholders’ equity | $ | 483,346 |  |  | $ | (23,646 | ) |  | $ | 459,700 |  |

[0001564590-18-001677:notes:88]
The following tables present the effect of the adoption of ASU 2014-09 on our condensed consolidated statements of operations (unaudited) for the three and six months ended December 31, 2016 (in thousands, except per share amounts):

[0001564590-18-001677:notes:89]
|  | Three Months Ended December 31, 2016 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 109,789 |  |  | $ | 8,266 |  |  | $ | 118,055 |  |
| Service |  | 38,322 |  |  |  | — |  |  |  | 38,322 |  |
| Total net revenues |  | 148,111 |  |  |  | 8,266 |  |  |  | 156,377 |  |
| Cost of revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 58,659 |  |  |  | 3,968 |  |  |  | 62,627 |  |
| Service |  | 14,098 |  |  |  | — |  |  |  | 14,098 |  |
| Total cost of revenues |  | 72,757 |  |  |  | 3,968 |  |  |  | 76,725 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 51,130 |  |  |  | 4,298 |  |  |  | 55,428 |  |
| Service |  | 24,224 |  |  |  | — |  |  |  | 24,224 |  |
| Total Gross profit |  | 75,354 |  |  |  | 4,298 |  |  |  | 79,652 |  |
| Sales and marketing expenses |  | 41,109 |  |  |  | (84 | ) |  |  | 41,025 |  |
| Operating loss |  | (7,362 | ) |  |  | 4,382 |  |  |  | (2,980 | ) |
| Net loss before tax |  | (7,432 | ) |  |  | 4,382 |  |  |  | (3,050 | ) |
| Net loss | $ | (8,611 | ) |  | $ | 4,382 |  |  | $ | (4,229 | ) |
| Basic and diluted net loss per share |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.08 | ) |  |  |  |  |  | $ | (0.04 | ) |
| Net loss per share - diluted | $ | (0.08 | ) |  |  |  |  |  | $ | (0.04 | ) |
| Shares used in per share calculation - basic |  | 107,425 |  |  |  |  |  |  |  | 107,425 |  |
| Shares used in per share calculation - diluted |  | 107,425 |  |  |  |  |  |  |  | 107,425 |  |

[0001564590-18-001677:notes:90]
|  | Six Months Ended December 31, 2016 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 199,920 |  |  | $ | 8,228 |  |  | $ | 208,148 |  |
| Service |  | 70,833 |  |  |  | — |  |  |  | 70,833 |  |
| Total net revenues |  | 270,753 |  |  |  | 8,228 |  |  |  | 278,981 |  |
| Cost of revenues |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 103,586 |  |  |  | 3,290 |  |  |  | 106,876 |  |
| Service |  | 26,567 |  |  |  | — |  |  |  | 26,567 |  |
| Total cost of revenues |  | 130,153 |  |  |  | 3,290 |  |  |  | 133,443 |  |
| Gross profit |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 96,334 |  |  |  | 4,938 |  |  |  | 101,272 |  |
| Service |  | 44,266 |  |  |  | — |  |  |  | 44,266 |  |
| Total Gross profit |  | 140,600 |  |  |  | 4,938 |  |  |  | 145,538 |  |
| Sales and marketing expenses |  | 78,065 |  |  |  | (181 | ) |  |  | 77,884 |  |
| Operating loss |  | (12,121 | ) |  |  | 5,119 |  |  |  | (7,002 | ) |
| Net loss before tax |  | (13,004 | ) |  |  | 5,119 |  |  |  | (7,885 | ) |
| Net loss | $ | (15,090 | ) |  | $ | 5,119 |  |  | $ | (9,971 | ) |
| Basic and diluted net loss per share |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.14 | ) |  |  |  |  |  | $ | (0.09 | ) |
| Net loss per share - diluted | $ | (0.14 | ) |  |  |  |  |  | $ | (0.09 | ) |
| Shares used in per share calculation - basic |  | 106,690 |  |  |  |  |  |  |  | 106,690 |  |
| Shares used in per share calculation - diluted |  | 106,690 |  |  |  |  |  |  |  | 106,690 |  |

[0001564590-18-001677:notes:91]
The following tables present the effect of the adoption of ASU 2014-09 on our condensed consolidated statement of cash flows (unaudited) for the six months ended December 31, 2016 (in thousands):

[0001564590-18-001677:notes:92]
|  | Six Months Ended December 31, 2016 |  |
|  | As Reported |  |  | Adjustment |  |  | As Adjusted |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (15,090 | ) |  | $ | 5,119 |  |  | $ | (9,971 | ) |
| Changes in operating assets and liabilities, net |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable |  | (18,737 | ) |  |  | 10,981 |  |  |  | (7,756 | ) |
| Inventories |  | 6,004 |  |  |  | (1,691 | ) |  |  | 4,313 |  |
| Prepaid and other assets |  | 7,004 |  |  |  | (181 | ) |  |  | 6,823 |  |
| Deferred distributors revenue, net of cost of sales to distributors |  | 14,516 |  |  |  | (14,516 | ) |  |  | — |  |
| Other current and long term liabilities |  | 7,587 |  |  |  | 288 |  |  |  | 7,875 |  |
| Net cash provided by operating activities |  | 19,288 |  |  |  | — |  |  |  | 19,288 |  |
| Cash flows from investing activities |  | (55,750 | ) |  |  | — |  |  |  | (55,750 | ) |
| Cash flows from financing activities |  | 46,241 |  |  |  | — |  |  |  | 46,241 |  |
| Foreign currency effect on cash |  | (115 | ) |  |  | — |  |  |  | (115 | ) |
| Net increase in cash and cash equivalents | $ | 9,664 |  |  | $ | — |  |  | $ | 9,664 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-18-001677:notes:93]
[same as prior period, unchanged from 0001564590-17-023316:notes:71]

[0001564590-18-001677:notes:94]
Cash, Cash Equivalents and Marketable Securities

[0001564590-18-001677:notes:95]
The following is a summary of cash, cash equivalents and marketable securities (in thousands):

[0001564590-18-001677:notes:96]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Cash |  | $ | 122,608 |  |  | $ | 126,159 |  |
| Cash equivalents |  |  | 4,500 |  |  |  | 4,291 |  |
| Total cash and cash equivalents |  |  | 127,108 |  |  |  | 130,450 |  |
| Marketable securities (consisting of available-for-sale securities) |  |  | 1,104 |  |  |  | — |  |
| Total cash, cash equivalents and marketable securities |  | $ | 128,212 |  |  | $ | 130,450 |  |

[0001564590-18-001677:notes:97]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Marketable securities are recorded in “Prepaid expense and other current assets” in the accompanying condensed consolidated balance sheet as these original maturities are greater than three months, but less than one year at the balance sheet date. Marketable securities are classified as available-for-sale and reported at fair value with unrealized gains and losses included in “Accumulated other comprehensive loss” in the accompanying condensed consolidated balance sheets.

[0001564590-18-001677:notes:98]
[same as prior period, unchanged from 0001564590-17-023316:notes:76]

[0001564590-18-001677:notes:99]
[same as prior period, unchanged from 0001564590-17-023316:notes:77]

[0001564590-18-001677:notes:100]
[same as prior period, unchanged from 0001564590-17-023316:notes:78]

[0001564590-18-001677:notes:101]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As Adjusted) |  |
| Finished goods |  | $ | 67,244 |  |  | $ | 46,620 |  |
| Raw materials |  |  | 16,133 |  |  |  | 790 |  |
| Total Inventories |  | $ | 83,377 |  |  | $ | 47,410 |  |

[0001564590-18-001677:notes:102]
[same as prior period, unchanged from 0001564590-17-023316:notes:80]

[0001564590-18-001677:notes:103]
[same as prior period, unchanged from 0001564590-17-023316:notes:81]

[0001564590-18-001677:notes:104]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Computers and equipment |  | $ | 63,539 |  |  | $ | 34,716 |  |
| Purchased software |  |  | 16,329 |  |  |  | 11,785 |  |
| Office equipment, furniture and fixtures |  |  | 17,272 |  |  |  | 10,852 |  |
| Leasehold improvements |  |  | 29,319 |  |  |  | 23,046 |  |
| Total property and equipment |  |  | 126,459 |  |  |  | 80,399 |  |
| Less: accumulated depreciation and amortization |  |  | (57,894 | ) |  |  | (50,159 | ) |
| Property and equipment, net |  | $ | 68,565 |  |  | $ | 30,240 |  |

[0001564590-18-001677:notes:105]
[same as prior period, unchanged from 0001564590-17-023316:notes:83]

[0001564590-18-001677:notes:106]
The following tables summarize the components of gross and net intangible asset balances (dollars in thousands)

[0001564590-18-001677:notes:107]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 4.5 years |  | $ | 116,000 |  |  | $ | 48,334 |  |  | $ | 67,666 |  |
| Customer relationships |  | 3.9 years |  |  | 51,410 |  |  |  | 38,674 |  |  |  | 12,736 |  |
| Maintenance contracts |  | 0.8 years |  |  | 17,000 |  |  |  | 14,166 |  |  |  | 2,834 |  |
| Trademarks |  | 3.9 years |  |  | 9,100 |  |  |  | 3,411 |  |  |  | 5,689 |  |
| Backlogs |  | — years |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |
| License agreements |  | 6.1 years |  |  | 2,445 |  |  |  | 1,255 |  |  |  | 1,190 |  |
| Other intangibles |  | 2.2 years |  |  | 1,382 |  |  |  | 1,072 |  |  |  | 310 |  |
| Total intangibles, net with finite lives |  |  |  |  | 199,137 |  |  |  | 108,712 |  |  |  | 90,425 |  |
| In-process research and development, with indefinite life |  |  |  |  | 2,500 |  |  |  | — |  |  |  | 2,500 |  |
| Total intangibles, net |  |  |  | $ | 201,637 |  |  | $ | 108,712 |  |  | $ | 92,925 |  |

[0001564590-18-001677:notes:108]
[same as prior period, unchanged from 0001564590-17-023316:notes:86]

[0001564590-18-001677:notes:109]
During the six months ended December 31, 2017, in-process research and development of $1.4 million was reclassified to developed technology upon completion of the project and is being amortized over its estimated useful life.

[0001564590-18-001677:notes:110]
[same as prior period, unchanged from 0001564590-17-023316:notes:88]

[0001564590-18-001677:notes:111]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 3,866 |  |  | $ | 1,720 |  |  | $ | 6,663 |  |  | $ | 5,276 |  |
| Amortization of intangibles |  |  | 2,746 |  |  |  | 2,175 |  |  |  | 4,360 |  |  |  | 6,317 |  |
| Total amortization |  | $ | 6,612 |  |  | $ | 3,895 |  |  | $ | 11,023 |  |  | $ | 11,593 |  |

[0001564590-18-001677:notes:112]
[same as prior period, unchanged from 0001564590-17-023316:notes:90]

[0001564590-18-001677:notes:113]
[same as prior period, unchanged from 0001564590-17-023316:notes:91]

[0001564590-18-001677:notes:114]
[same as prior period, unchanged from 0001564590-17-023316:notes:92]

[0001564590-18-001677:notes:115]
|  |  | December 31, 2017 |  |
| Balance as of June 30, 2017 |  | $ | 80,216 |  |
| Additions due to acquisitions |  |  | 50,772 |  |
| Balance at end of period |  | $ | 130,988 |  |

[0001564590-18-001677:notes:116]
During the six months ended December 31, 2017, the Company completed acquisitions of the Campus Fabric Business and the Data Center Business, resulting in an additional goodwill of $34.0 million and $16.8 million, respectively.  See Note 2 for additional information related to the acquisitions.

[0001564590-18-001677:notes:117]
[same as prior period, unchanged from 0001564590-17-023316:notes:95]

[0001564590-18-001677:notes:118]
[same as prior period, unchanged from 0001564590-17-023316:notes:96]

[0001564590-18-001677:notes:119]
[same as prior period, unchanged from 0001564590-17-023316:notes:97]

[0001564590-18-001677:notes:120]
[same as prior period, unchanged from 0001564590-17-023316:notes:98]

[0001564590-18-001677:notes:121]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 22,964 |  |  | $ | 12,444 |  |
| Less: unamortized debt issuance costs |  |  | (538 | ) |  |  | (164 | ) |
| Current portion of long-term debt |  | $ | 22,426 |  |  | $ | 12,280 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 152,062 |  |  | $ | 71,268 |  |
| Revolver |  |  | 10,000 |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,350 | ) |  |  | (846 | ) |
| Total long-term debt, less current portion |  |  | 160,712 |  |  |  | 80,422 |  |
| Total debt |  | $ | 183,138 |  |  | $ | 92,702 |  |

[0001564590-18-001677:notes:122]
In connection with the closing of Campus Fabric Business discussed in Note 2, the Company entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amended the Amended and Restated Credit Agreement, dated as of October 28, 2016 (the “Credit Facility, as amended”), by and among the Company, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, composed of (a) the five-year term loan (“Term Loan”) in a principal amount of up to $183.7 million and (b) the five-year revolving credit facility (“Revolver”) in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver, (iii) provides for an uncommitted additional incremental loan facility in the principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as lenders pursuant to the terms of the Credit Facility, as amended.  On July 14, 2017, the Company borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.

[0001564590-18-001677:notes:123]
In connection with the closing of the acquisition of the Data Center Business discussed in Note 2, the Company entered into the Third Amendment to the Credit Facility (the “Third Amendment”) on October 26, 2017. Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for the fiscal year of the Company ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement (as defined above). On the Brocade Closing Date, the Company borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.

[0001564590-18-001677:notes:124]
[same as prior period, unchanged from 0001564590-17-023316:notes:101]

[0001564590-18-001677:notes:125]
The Company had $1.2 million of outstanding letters of credit and $48.8 million of availability under the Revolver as of December 31, 2017.

[0001564590-18-001677:notes:126]
[same as prior period, unchanged from 0001564590-17-023316:notes:103]

[0001564590-18-001677:notes:127]
[same as prior period, unchanged from 0001564590-17-023316:notes:104]

[0001564590-18-001677:notes:128]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty. The following table summarizes the activity related to the Company’s product warranty liability during the three and six months ended December 31, 2017 and 2016 (in thousands):

[0001564590-18-001677:notes:129]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Balance beginning of period |  | $ | 13,499 |  |  | $ | 9,017 |  |  | $ | 10,584 |  |  | $ | 9,998 |  |
| Warranties assumed due to acquisition |  |  | 526 |  |  |  | 2,034 |  |  |  | 3,682 |  |  |  | 2,034 |  |
| New warranties issued |  |  | 1,657 |  |  |  | 1,176 |  |  |  | 3,929 |  |  |  | 2,104 |  |
| Warranty expenditures |  |  | (2,672 | ) |  |  | (1,437 | ) |  |  | (5,185 | ) |  |  | (3,346 | ) |
| Balance end of period |  | $ | 13,010 |  |  | $ | 10,790 |  |  | $ | 13,010 |  |  | $ | 10,790 |  |

[0001564590-18-001677:notes:130]
[same as prior period, unchanged from 0001564590-17-023316:notes:107]

[0001564590-18-001677:notes:131]
Other long-term liabilities

[0001564590-18-001677:notes:132]
The following is a summary of long-term liabilities (in thousands):

[0001564590-18-001677:notes:133]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Acquisition related deferred payments, less current portion |  | $ | 15,037 |  |  | $ | — |  |
| Acquisition-related contingent consideration obligations, less current portion |  |  | 36,130 |  |  |  | — |  |
| Other |  |  | 13,180 |  |  |  | 8,526 |  |
| Total other accrued liabilities |  | $ | 64,347 |  |  | $ | 8,526 |  |

[0001564590-18-001677:notes:134]
[same as prior period, unchanged from 0001564590-17-023316:notes:108]

[0001564590-18-001677:notes:135]
All advertising costs are expensed as incurred.  Advertising expenses for three and six months ended December 31, 2017 and 2016, were immaterial.

[0001564590-18-001677:notes:136]
[same as prior period, unchanged from 0001564590-17-023316:notes:110]

[0001564590-18-001677:notes:137]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and marketable securities. The Company does not invest an amount exceeding 10% of its combined cash or cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001564590-18-001677:notes:138]
[same as prior period, unchanged from 0001564590-17-023316:notes:112]

[0001564590-18-001677:notes:139]
[same as prior period, unchanged from 0001564590-17-023316:notes:113]

[0001564590-18-001677:notes:140]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Westcon Group Inc. |  | 14% |  |  | 12% |  |  | 15% |  |  | 12% |  |
| Tech Data Corporation |  | 12% |  |  | 15% |  |  | 12% |  |  | 16% |  |
| Jenne Corporation |  | * |  |  | 13% |  |  | 10% |  |  | 14% |  |
| Avnet |  | * |  |  | * |  |  | * |  |  | 10% |  |

[0001564590-18-001677:notes:141]
*Less than 10% of net revenue

[0001564590-18-001677:notes:142]
The following customers account for more than 10% of the Company’s accounts receivable outstanding as of December 31, 2017, Westcon Group 24%, Tech Data 21% and Avnet 11%.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-18-001677:notes:143]
[same as prior period, unchanged from 0001564590-17-023316:notes:116]

[0001564590-18-001677:notes:144]
[same as prior period, unchanged from 0001564590-17-023316:notes:117]

[0001564590-18-001677:notes:145]
[same as prior period, unchanged from 0001564590-17-023316:notes:118]

[0001564590-18-001677:notes:146]
[same as prior period, unchanged from 0001564590-17-023316:notes:119]

[0001564590-18-001677:notes:147]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value. |

[0001564590-18-001677:notes:148]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-18-001677:notes:149]
| December 31, 2017 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,500 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,500 |  |
| Marketable securities |  |  | 1,104 |  |  |  | — |  |  |  | — |  |  |  | 1,104 |  |
| Total assets measured at fair value |  | $ | 5,604 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,604 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 47,030 |  |  | $ | — |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 47,030 |  |  | $ | — |  |

[0001564590-18-001677:notes:150]
[same as prior period, unchanged from 0001564590-17-023316:notes:123]

[0001564590-18-001677:notes:151]
[same as prior period, unchanged from 0001564590-17-023316:notes:124]

[0001564590-18-001677:notes:152]
During the first quarter of fiscal 2018, pursuant to the sale of an investment in non-marketable equity securities, the Company received 41,685 shares of a company publicly traded on the London Stock Exchange.  As of December 31, 2017, the shares received have a fair value of $1.1 million. (See below, Level 3 investments)

[0001564590-18-001677:notes:153]
[same as prior period, unchanged from 0001564590-17-023316:notes:126]

[0001564590-18-001677:notes:154]
[same as prior period, unchanged from 0001564590-17-023316:notes:127]

[0001564590-18-001677:notes:155]
The fair value of the borrowings under the Credit Facility, as amended is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Due to the short duration until maturity of the credit facility, the fair value approximates the face amount of the Company’s indebtedness of $185.0 million and $93.7 million as of December 31, 2017 and June 30, 2017, respectively. Such amounts are immaterial for all periods presented.

[0001564590-18-001677:notes:156]
[same as prior period, unchanged from 0001564590-17-023316:notes:129]

[0001564590-18-001677:notes:157]
[same as prior period, unchanged from 0001564590-17-023316:notes:130]

[0001564590-18-001677:notes:158]
As of June 30, 2017, the Company reflected its non-marketable equity investment as Level 3 in the fair value hierarchy as it is based on unobservable inputs that market participants would use in pricing this asset due to the absence of recent comparable market transactions and inherent lack of liquidity.  During fiscal 2015, the Company purchased a $3.0 million equity interest in a company that operated in the enterprise software platform industry.  The Company did not enter into any other transactions with the investee during fiscal 2017 or the first quarter of fiscal 2018.   During the three months ended September 30, 2017, the investee was acquired by a third party.  The Company received $6.8 million as consideration for its equity interest in the investee, including $5.4 million in cash and 65,937 shares the third party’s common stock with a market value of $1.4 million. During the first quarter of fiscal 2018, the Company received $5.8 million of the consideration, consisting of $4.9 million in cash and 41,685 shares with a market value of $0.9 million. The remainder of the consideration consisting of $0.5 million and $0.5 million of cash and shares, respectively, will remain in escrow for a period of 18 months from the date of sales for general representations and warranties. A gain of $3.8 million related to this sale was recorded in “Other income (expense), net” in the accompanying condensed consolidated statements of operations for the six months ended December 31, 2017. The 41,685 shares received and held as of December 31, 2017 were considered Level 1 investments as these have quoted prices in active markets.

[0001564590-18-001677:notes:159]
During the quarter ended December 31, 2017, the Company recorded a liability for contingent consideration related to its acquisitions of the Data Center Business and the CF Business (see Note 2 for additional information related to the acquisitions). The fair value measurement of the contingent consideration obligations is determined using Level 3 inputs. The fair value of contingent consideration obligations is based on a discounted cash flow model. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period. Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period. Changes in the value of the contingent consideration obligations would be recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-18-001677:notes:160]
The change in the acquisition-related contingent consideration obligations is as follows (in thousands):

[0001564590-18-001677:notes:161]
|  |  | Three Months Ended |  |
|  |  | December 31, 2017 |  |
| Beginning balance |  | $ | — |  |
| Initial fair value measurements |  |  | 47,030 |  |
| Change in fair value |  |  | — |  |
| Ending balance |  | $ | 47,030 |  |

[0001564590-18-001677:notes:162]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the first six months of fiscal year 2018 or 2017. There were no impairments recorded for the first six months of fiscal 2018 or 2017.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-001677:notes:163]
[same as prior period, unchanged from 0001564590-17-023316:notes:133]

[0001564590-18-001677:notes:164]
[same as prior period, unchanged from 0001564590-17-023316:notes:134]

[0001564590-18-001677:notes:165]
[same as prior period, unchanged from 0001564590-17-023316:notes:135]

[0001564590-18-001677:notes:166]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| 2014 Employee Stock Purchase Plan |  |  | 6,517 |  |  |  | 7,785 |  |
| Employee stock options and awards outstanding |  |  | 10,900 |  |  |  | 9,726 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 12,242 |  |  |  | 7,629 |  |
| Total shares reserved for issuance |  |  | 29,659 |  |  |  | 25,140 |  |

[0001564590-18-001677:notes:167]
[same as prior period, unchanged from 0001564590-17-023316:notes:137]

[0001564590-18-001677:notes:168]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Cost of product revenue |  | $ | 134 |  |  | $ | 122 |  |  | $ | 226 |  |  | $ | 190 |  |
| Cost of service revenue |  |  | 296 |  |  |  | 186 |  |  |  | 429 |  |  |  | 418 |  |
| Research and development |  |  | 1,829 |  |  |  | 906 |  |  |  | 2,880 |  |  |  | 1,968 |  |
| Sales and marketing |  |  | 2,699 |  |  |  | 1,180 |  |  |  | 4,342 |  |  |  | 2,321 |  |
| General and administrative |  |  | 2,067 |  |  |  | 987 |  |  |  | 3,951 |  |  |  | 1,959 |  |
| Total share-based compensation expense |  | $ | 7,025 |  |  | $ | 3,381 |  |  | $ | 11,828 |  |  | $ | 6,856 |  |

[0001564590-18-001677:notes:169]
During the six months ended December 31, 2017 or 2016, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-18-001677:notes:170]
[same as prior period, unchanged from 0001564590-17-023316:notes:140]

[0001564590-18-001677:notes:171]
Stock awards may be granted under the 2013 Equity Incentive Plan (the “2013 Plan”) on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria.  The Company uses the straight-line method for expense attribution, and beginning with fiscal 2017, the Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-18-001677:notes:172]
The following table summarizes stock award activity for the six months ended December 31, 2017 (in thousands, except grant date fair value):

[0001564590-18-001677:notes:173]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2017 |  |  | 6,664 |  |  | $ | 4.66 |  |  | $ | 61,440 |  |
| Granted |  |  | 3,726 |  |  |  | 11.13 |  |  |  |  |  |
| Vested |  |  | (1,871 | ) |  |  | 3.78 |  |  |  |  |  |
| Cancelled |  |  | (160 | ) |  |  | 5.17 |  |  |  |  |  |
| Non-vested stock awards outstanding at December 31, 2017 |  |  | 8,359 |  |  | $ | 7.73 |  |  | $ | 104,653 |  |

[0001564590-18-001677:notes:174]
The following table summarizes stock option activity for the six months ended December 31, 2017(in thousands, except per share and contractual term):

[0001564590-18-001677:notes:175]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2017 |  |  | 3,062 |  |  | $ | 4.06 |  |  |  | 4.19 |  |  | $ | 15,868 |  |
| Exercised |  |  | (517 | ) |  |  | 4.42 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (4 | ) |  |  | 4.31 |  |  |  |  |  |  |  |  |  |
| Options outstanding at December 31, 2017 |  |  | 2,541 |  |  | $ | 3.99 |  |  |  | 3.28 |  |  | $ | 21,687 |  |
| Vested and expected to vest at December 31, 2017 |  |  | 2,541 |  |  | $ | 3.99 |  |  |  | 3.28 |  |  | $ | 21,687 |  |
| Exercisable at December 31, 2017 |  |  | 2,126 |  |  | $ | 4.24 |  |  |  | 3.08 |  |  | $ | 17,599 |  |

[0001564590-18-001677:notes:176]
[same as prior period, unchanged from 0001564590-17-023316:notes:146]

[0001564590-18-001677:notes:177]
The fair value of each RSUs grant with performance-based vesting criteria (“PSUs”) under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-18-001677:notes:178]
During the first quarter of fiscal 2018, the Company approved the grant of 1,154,014 stock awards to its vice president level employees or above (“VPs”), including 560,344 stock awards to its Executive Officers, and 939,925 stock awards to its other employees.  Fifty percent (50%) of the stock awards granted to the VPs, except the chief executive officer, were in the form of PSUs, with grant date fair values of $10.90, and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs. The Company’s chief executive officer received sixty percent (60%) of his stock award grant in the form of PSUs, while forty percent (40%) of this award were in the form of RSUs, with a grant date fair value of $10.90.  The RSUs vest from the original grant date as to one-third (1/3) on the one year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.   No PSUs were granted during the second quarter of fiscal 2018.

[0001564590-18-001677:notes:179]
For the PSUs referenced in the preceding paragraph, they will be considered earned once the Company’s combined earnings per share equals or exceeds $0.32 for two consecutive quarters. (the “FY18 Performance Threshold”).  Once the FY18 Performance Threshold is satisfied the PSUs shall vest with respect to the number of RSUs granted on the same date that have vested as of the date the FY18 Performance Threshold is satisfied and thereafter shall vest on the same schedule as the RSUs, subject to continued service to the Company.  If the FY18 Performance Threshold is not met by the third anniversary of the grant date the award is canceled.  In addition, the FY18 Performance Threshold shall be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $16.00 per share.

[0001564590-18-001677:notes:180]
During the three months and six months ended December 31, 2017, none of the PSU grants referenced above achieved their FY18 Performance Threshold.

[0001564590-18-001677:notes:181]
During the first quarter of fiscal 2017, the Company approved the grant of 1,505,120 stock awards to its VPs, including 680,000 stock awards to its Executive Officers, and 1,053,300 stock awards to other Company employees.  Fifty percent (50%) of the stock awards granted to the VPs were in the form of PSUs, with grant date fair values ranging from $3.02 to $3.09, and fifty percent (50%) of the stock awards granted were in the form of RSUs.   The RSUs vest from the original grant date as to one-third (1/3) on the one year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.  No PSUs were granted during the second quarter of fiscal 2017.

[0001564590-18-001677:notes:182]
The PSUs were considered earned once the Company’s stock price equaled or exceeded $5.00 per share for 30 consecutive trading days after January 1, 2017 (the “FY17 Performance Threshold”).  Once the FY17 Performance Threshold goal was attainted the PSUs began to vest on the same schedule as the RSUs that were granted at the same time, subject to continued service to the Company.

[0001564590-18-001677:notes:183]
[same as prior period, unchanged from 0001564590-17-023316:notes:153]

[0001564590-18-001677:notes:184]
[same as prior period, unchanged from 0001564590-17-023316:notes:154]

[0001564590-18-001677:notes:185]
There were no shares granted under the ESPP during the three months ended December 31, 2017 or 2016. The weighted-average fair value of shares granted under the Company’s 2014 ESPP during the six months ended December 31, 2017 and 2016, was $2.41 and $1.00, respectively.  There were 1,267,930 and 1,103,599 shares issued under the Company’s 2014 ESPP during the six months ended December 31, 2017 and 2016, respectively.

[0001564590-18-001677:notes:186]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Six Month Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Expected life |  | 0.50 years |  |  | 0.50 years |  |
| Risk-free interest rate |  |  | 1.15 | % |  |  | 0.40 | % |
| Volatility |  |  | 42 | % |  |  | 40 | % |
| Dividend yield |  |  | — | % |  |  | — | % |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-18-001677:notes:187]
[same as prior period, unchanged from 0001564590-17-023316:notes:157]

[0001564590-18-001677:notes:188]
No restructuring charges were recorded during the three or six months ended December 31, 2017.

[0001564590-18-001677:notes:189]
For the three and six months ended December 31, 2016, the Company recorded $1.9 million in restructuring and other charges including accelerated depreciation of leasehold improvements and fixed assets in the amount of $1.7 million and adjustments to estimated sub-lease income to be received related to the estimated future obligations for non-cancelable lease payments for excess facilities of $0.1 million.

[0001564590-18-001677:notes:190]
[same as prior period, unchanged from 0001564590-17-023316:notes:159]

[0001564590-18-001677:notes:191]
In fiscal 2017, the Company announced a reduction-in-force (“RIF”).  The Company recorded $5.6 million in severance and benefits charges, net during the year ended June 30, 2017.  Cash payments of $2.2 million were paid during the first six months of fiscal 2018. The balance of cash payments for the RIF was immaterial as of December 31, 2017.  The excess facilities payments will continue through fiscal year 2023.

[0001564590-18-001677:notes:192]
[same as prior period, unchanged from 0001564590-17-023316:notes:162]

[0001564590-18-001677:notes:193]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2017 |  | $ | 2,184 |  |  | $ | 1,853 |  |  | $ | 85 |  |  | $ | 4,122 |  |
| Period payments |  |  | (397 | ) |  |  | (1,770 | ) |  |  | (73 | ) |  |  | (2,240 | ) |
| Balance as of December 31, 2017 |  | $ | 1,787 |  |  | $ | 83 |  |  | $ | 12 |  |  | $ | 1,882 |  |
| Less: current portion included in other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 473 |  |
| Restructuring accrual included in other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,409 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-001677:notes:194]
| 9. | Commitments and Contingencies |

[0001564590-18-001677:notes:195]
Purchase Commitments

[0001564590-18-001677:notes:196]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2017, the Company had non-cancelable commitments to purchase $145.3 million of such inventory.  As of December 31, 2017 the Company had non-cancelable software and maintenance support commitments to purchase $19.0 million of software and support services.

[0001564590-18-001677:notes:197]
Legal Proceedings

[0001564590-18-001677:notes:198]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-18-001677:notes:199]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-18-001677:notes:200]
Brazilian Tax Assessment Matter

[0001564590-18-001677:notes:201]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed our Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (approximately U.S. $1.0 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of December 31, 2017.

[0001564590-18-001677:notes:202]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority, but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts, and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 16.7 million (approximately U.S. $5.1 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 31, 2017.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit, has appealed the lower court’s decision and has requested a stay of execution.

[0001564590-18-001677:notes:203]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (approximately U.S. $2.9 million) as of the date the Company acquired Enterasys Networks.

[0001564590-18-001677:notes:204]
The Company made a demand on April 11, 2014 for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-18-001677:notes:205]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-18-001677:notes:206]
On October 23 and 29, 2015, putative class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  The Court held a hearing on Defendants’ motion to dismiss on December 14, 2017, and a ruling is expected in the next few months. The Company believes plaintiffs’ claims are without merit and intends to defend them vigorously.

[0001564590-18-001677:notes:207]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  The parties have agreed to stay the case pending further activities in the securities class action litigation, and the court signed a stipulation and order to that effect.

[0001564590-18-001677:notes:208]
XR Communications, LLC d/b/a Vivato Technologies, LLC v. Extreme Networks, Inc.

[0001564590-18-001677:notes:209]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) sued the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  On July 24, 2017, the Company filed its answer.  In an order entered on October 23, 2017, the court scheduled a claim construction hearing for April 10, 2018, and ordered any trial of this matter to commence no earlier than March 19, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-18-001677:notes:210]
Indemnification Obligations

[0001564590-18-001677:notes:211]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-001677:notes:212]
[same as prior period, unchanged from 0001564590-17-023316:notes:182]

[0001564590-18-001677:notes:213]
For the three months ended December 31, 2017 and 2016, the Company recorded income tax benefit of $1.6 million and income tax provision of $1.2 million, respectively.  For the six months ended December 31, 2017 and 2016, the Company recorded income tax provision of $0.1 million and $2.1 million, respectively.

[0001564590-18-001677:notes:214]
The income tax provisions for the three months ended December 31, 2017 and 2016, consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the Zebra WLAN Business and the Campus Fabric Business. The tax provision for the three months ended December 31, 2017 is offset by a tax benefit of $2.5 million resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to our deferred tax liability related to amortizable goodwill as required by the recently enacted U.S. tax legislation discussed below. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended December 31, 2017 and 2016, and therefore may not reflect the annual effective tax rate.

[0001564590-18-001677:notes:215]
The income tax provisions for the six months ended December 31, 2017 and 2016 consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisitions referenced above.  The income tax provision for the six months ended December 31, 2017 is offset by the tax benefit of $2.5 million resulting from the U.S. Federal tax legislation referenced above.

[0001564590-18-001677:notes:216]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, is effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, the Company will not be subject to the majority of the tax law provisions until fiscal year 2019; however, there are certain significant items of impact that will be recognized in fiscal year 2018. Because a change in tax law is accounted for in the period of enactment, the effects of the TCJA, a tax benefit of $2.5 million, have been reflected in the second quarter of fiscal 2018.

[0001564590-18-001677:notes:217]
The TCJA’s primary change is a reduction in the U.S. Federal statutory corporate tax rate from 35% to 21%, including a pro rata reduction from 35% to 28% for the Company in fiscal 2018.  As a result, the Company has recognized a tax benefit in the amount of $2.5 million in the second quarter of fiscal 2018 due to the revaluation of the Company's deferred tax liability related to amortizable goodwill to reflect the lower statutory rate.  Because the U.S. deferred tax assets are offset by a full valuation allowance, the reduction in deferred tax assets for the lower rate was fully offset by a corresponding reduction in valuation allowance resulting in no additional tax provision.

[0001564590-18-001677:notes:218]
The TCJA moves the U.S. from a global taxation regime to a modified territorial regime.  Under the territorial regime, the company’s foreign earnings will generally not be subject to tax in the US.  As part of transitioning to this new regime, U.S. companies are required to pay tax on historical earnings generated offshore that have not been repatriated to the U.S. (“Transition Tax”).  The Company has estimated as of the second quarter of fiscal 2018, there will be no incremental tax provision relating to the Transition Tax given the Company’s ability to utilize existing tax attributes to offset the impact of the deemed repatriation.

[0001564590-18-001677:notes:219]
The TCJA makes broad and complex changes to the U.S. tax code, and in certain instances, lacks clarity and is subject to interpretation until additional U.S. Treasury guidance is issued.  On December 22, 2017, the SEC issued guidance under Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (“SAB 118”), which allows registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations.  However, the measurement period is deemed to have ended earlier when the registrant has obtained, prepared and analyzed the information necessary to finalize its accounting.  During the measurement period, impacts of the law are expected to be recorded at the time a reasonable estimate for all or a portion of the effects can be made, and provisional amounts can be recognized and adjusted as information becomes available, prepared or analyzed. The SAB summarizes a three-step process to be applied at each reporting period to account for and qualitatively disclose: (1) the effects of the change in tax law for which accounting is complete; (2) provisional amounts (or adjustments to provisional amounts) for the effects of the tax law where accounting is not complete, but that a reasonable estimate has been determined; and (3) a reasonable estimate cannot yet be made and therefore taxes are reflected in accordance with law prior to the enactment of the TCJA.

[0001564590-18-001677:notes:220]
Amounts recorded where accounting is complete in the three and six months ended December 31, 2017 principally relate to the reduction in the U.S. federal tax rate to 21 percent, which resulted in the Company reporting an income tax benefit of $2.5 million to remeasure deferred taxes liabilities associated with indefinitely lived intangible assets that will reverse at the new 21% rate. Absent this deferred tax liability, the Company is in a net deferred tax asset position that is offset by a full valuation allowance.  Though the impact of the rate change related to net deferred tax assets has a net tax effect of zero, the accounting to determine the gross change in the deferred tax position and the offsetting valuation is not yet complete.  In accordance with Staff Accounting Bulletin (“SAB”) 118, the estimated income tax impact associated with the Transition Tax of zero represents our best estimate based on interpretation of the U.S. legislation as we are still accumulating data to finalize the underlying calculation. In accordance with SAB 118, estimated income tax impact associated with the Transition Tax is considered provisional and will be finalized prior to the end of the measurement period. The ultimate impact may differ from these provisional amounts, due to, among other things, additional analysis, changes in interpretations and assumptions the Company has made, additional regulatory guidance that may be issued, and actions the Company may take as a result of the TCJA.

[0001564590-18-001677:notes:221]
With respect to provisions of the TCJA effective for tax years beginning on or after January 1, 2018, the company anticipates several new provisions may potentially impact tax provisions in future periods including limitations on the deductibility of interest expense and certain executive compensation, a minimum tax on certain foreign earnings (i.e., global intangible low-taxed income or “GILTI”), as well as a base-erosion and anti-abuse tax (“BEAT”).  The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. Based on initial assessment and interpretation of the new provision, the Company expects that it will be subject to incremental U.S. tax on GILTI income beginning in fiscal 2019. The Company may elect to account for GILTI tax as a component of tax expense in the period in which it is incurred or account for the GILTI tax in the measurement of deferred taxes. The Company is continuing to evaluate this particular provision and therefore has not yet elected a method but will do so once our analysis is complete.. The BEAT provisions in the Tax Reform Act eliminate the deduction of certain base-erosion payments made to related foreign corporations, and impose a minimum tax if greater than regular tax.  There is a reasonable amount of uncertainty surrounding the interpretation of this new provision, however, based on initial assessment and a conservative interpretation of the new provision, the Company expects that it will be subject to the incremental U.S. tax on BEAT income beginning in fiscal 2019.

[0001564590-18-001677:notes:222]
[same as prior period, unchanged from 0001564590-17-023316:notes:185]

[0001564590-18-001677:notes:223]
The acquisition of Enterasys in October 2013 included a U.S. parent company as well as its wholly-owned domestic and foreign subsidiaries. The Company elected to treat this stock acquisition as an asset purchase by filing the required election forms under IRC Sec 338(h)(10).  Additionally, the Company completed asset purchases of the Zebra WLAN Business, the Campus Fabric Business and the Brocade Data Center Business in October 2016, July 2017 and October 2017, respectively.  The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.  During the three and six months ended December 31, 2017, the Company deducted $2.1 million and $3.7 million of tax amortization expense respectively, for each period related to capitalized goodwill resulting from these acquisitions. As of December 31, 2017, the Company recorded a deferred tax liability of $4.9 million related to this goodwill amortization which is not considered a future source of taxable income in evaluating the need for a valuation allowance against its deferred tax assets.

[0001564590-18-001677:notes:224]
The Company had $19.0 million of unrecognized tax benefits as of December 31, 2017.  The future impact of the unrecognized tax benefit of $18.9 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-18-001677:notes:225]
The Company’s policy is to accrue interest and penalties related to the underpayment of income taxes as a component of tax expense in the accompanying condensed consolidated statements of operations.

[0001564590-18-001677:notes:226]
[same as prior period, unchanged from 0001564590-17-023316:notes:189]


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-001677:notes:227]
| 11. | Net Loss Per Share |

[0001564590-18-001677:notes:228]
[same as prior period, unchanged from 0001564590-17-023316:notes:191]

[0001564590-18-001677:notes:229]
The following table presents the calculation of net loss per share of basic and diluted (in thousands, except per share data):

[0001564590-18-001677:notes:230]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  | (As adjusted) |  |
| Net loss |  | $ | (31,923 | ) |  | $ | (4,229 | ) |  | $ | (27,547 | ) |  | $ | (9,971 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 113,621 |  |  |  | 107,425 |  |  |  | 112,931 |  |  |  | 106,690 |  |
| Net loss per share - basic and diluted |  | $ | (0.28 | ) |  | $ | (0.04 | ) |  | $ | (0.24 | ) |  | $ | (0.09 | ) |

[0001564590-18-001677:notes:231]
The following securities were excluded from the computation of net loss per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0001564590-18-001677:notes:232]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | December 31, 2017 |  |  | December 31, 2016 |  |
| Options to purchase common stock |  |  | 2,622 |  |  |  | 2,301 |  |  |  | 2,781 |  |  |  | 2,762 |  |
| Restricted stock units |  |  | 7,950 |  |  |  | 28 |  |  |  | 7,162 |  |  |  | 79 |  |
| Employee Stock Purchase Plan shares |  |  | 834 |  |  |  | 330 |  |  |  | 906 |  |  |  | 330 |  |
| Total shares excluded |  |  | 11,406 |  |  |  | 2,659 |  |  |  | 10,849 |  |  |  | 3,171 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-001677:notes:233]
[same as prior period, unchanged from 0001564590-17-023316:notes:196]

[0001564590-18-001677:notes:234]
[same as prior period, unchanged from 0001564590-17-023316:notes:197]

[0001564590-18-001677:notes:235]
As of December 31, 2017, forward foreign currency contracts had a notional principal amount of $1.5 million and an immaterial unrealized gain. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities. As of December 31, 2016, the Company did not have any derivative instruments outstanding.

[0001564590-18-001677:notes:236]
Foreign currency transactions gains and losses from operations was loss of $0.6 million and gain of $1.1 million for the three months ended December 31, 2017 and 2016, respectively. Foreign currency transactions gains and losses from operations was loss of $1.1 million and gain of $0.8 million for the six months ended December 31, 2017 and 2016, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-001677:notes:237]
[same as prior period, unchanged from 0001564590-17-023316:notes:200]

[0001564590-18-001677:notes:238]
[same as prior period, unchanged from 0001564590-17-023316:notes:201]

[0001564590-18-001677:notes:239]
[same as prior period, unchanged from 0001564590-17-023316:notes:202]

[0001564590-18-001677:notes:240]
[same as prior period, unchanged from 0001564590-17-023316:notes:203]

[0001564590-18-001677:notes:241]
| Long Lived Assets |  | December 31, 2017 |  |  | June 30, 2017 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Americas |  | $ | 187,617 |  |  | $ | 67,369 |  |
| EMEA |  |  | 10,066 |  |  |  | 8,998 |  |
| APAC |  |  | 8,075 |  |  |  | 4,275 |  |
| Total long lived assets |  | $ | 205,758 |  |  | $ | 80,642 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-001677:notes:242]
14.Subsequent Event

[0001564590-18-001677:notes:243]
On January 31, 2018, the Company approved and on February 2, 2018 began executing a reduction-in-force (the “Plan”) to re-align the Company’s resources as a result of the Company’s recent acquisitions of the Campus Fabric Business and the Data Center Business. The Plan is expected to reduce the overall costs of the Company and to accelerate the achievement of the Company’s operating margin target objectives. The Company expects to incur charges of approximately $4.0 million in connection with the Plan. Upon completion of the Plan, the potential savings expected to be achieved as a result of reduced employee related expenses and lower operating costs will yield annualized savings of $7.0 - $9.0 million. The costs associated with this Plan primarily include employee severance and benefits expenses.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.
