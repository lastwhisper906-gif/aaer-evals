# EXTR MD&A — 0001564590-18-001677


## mdna

[0001564590-18-001677:mdna:1]
[same as prior period, unchanged from 0001564590-17-023316:mdna:1]

[0001564590-18-001677:mdna:2]
[same as prior period, unchanged from 0001564590-17-023316:mdna:2]

[0001564590-18-001677:mdna:3]
[same as prior period, unchanged from 0001564590-17-023316:mdna:4]

[0001564590-18-001677:mdna:4]
[same as prior period, unchanged from 0001564590-17-023316:mdna:5]

[0001564590-18-001677:mdna:5]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended December 31, 2017.

[0001564590-18-001677:mdna:6]
[same as prior period, unchanged from 0001564590-17-023316:mdna:6]

[0001564590-18-001677:mdna:7]
[same as prior period, unchanged from 0001564590-17-023316:mdna:7]

[0001564590-18-001677:mdna:8]
[same as prior period, unchanged from 0001564590-17-023316:mdna:8]

[0001564590-18-001677:mdna:9]
[same as prior period, unchanged from 0001564590-17-023316:mdna:9]

[0001564590-18-001677:mdna:10]
|  | • | Verticals such as healthcare, education, manufacturing, government, and hospitality, which includes sports and entertainment venues and retail are connecting with their customers and guests beyond the network. These enterprises are investing in guest and location technologies that connect with their customers via their mobile devices over their WLAN. This allows them to obtain rich analytics for contextual marketing, which in turn, enables them to deliver a personalized brand experience. ExtremeGuest™ and ExtremeLocation™ have been built on cloud-based technology for simple implementation and fast release to market to better provide necessary insights into guest demographics and location-based analytics. |

[0001564590-18-001677:mdna:11]
|  | • | Growing usage of the cloud. Enterprises have migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. Ethernet speeds, scaling from 10 Gigabits per second (“G”) to 40G and even 100G, provide the infrastructure for both private and public clouds. In addition, there is growing interest in software-defined networking (“SDN”) approaches that may include technologies such as OpenFlow, OpenStack, and CloudStack for increased network agility. |

[0001564590-18-001677:mdna:12]
|  | • | Vendor consolidation is expected to continue. Consolidation of vendors within the enterprise network equipment market and between adjacent markets (storage, security, wireless & voice software and applications) continues to gain momentum. We identified this trend in 2013 with our acquisition of Enterasys. Further, we believe customers are demanding more end-to-end, integrated networking solutions. To address this demand, we acquired the wireless local area network business (the “WLAN Business”) from Zebra Technologies Corporation in October 2016, Avaya’s fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) in July 2017, and Brocade’s data center business (the “Data Center Business”) in October 2017. |

[0001564590-18-001677:mdna:13]
[same as prior period, unchanged from 0001564590-17-023316:mdna:13]

[0001564590-18-001677:mdna:14]
[same as prior period, unchanged from 0001564590-17-023316:mdna:14]

[0001564590-18-001677:mdna:15]
|  | • | Data Center to access edge wired and wireless solutions. The addition of the WLAN Business, the Campus Fabric Business and the Data Center Business will allow Extreme to offer a complete, unified portfolio of software-driven network access solutions. We offer the latest in wireless access points for both outdoor and indoor use plus a complete line of switches for the Campus, Core and Data Center. |

[0001564590-18-001677:mdna:16]
|  | • | Multi-vendor management from a “single pane-of-glass”. Extreme’s Management Center (“EMC”) is a single unified management system that is designed to provide visibility, security, and control across the entire network. This can make the network easier to manage and troubleshoot, often with lower operating expenses. Extreme’s software can manage third-party vendors’ network devices, including Campus Fabric products, enabling our customers to potentially maximize device lifespan and protect investments. |

[0001564590-18-001677:mdna:17]
[same as prior period, unchanged from 0001564590-17-023316:mdna:17]

[0001564590-18-001677:mdna:18]
[same as prior period, unchanged from 0001564590-17-023316:mdna:18]

[0001564590-18-001677:mdna:19]
[same as prior period, unchanged from 0001564590-17-023316:mdna:19]

[0001564590-18-001677:mdna:20]
[same as prior period, unchanged from 0001564590-17-023316:mdna:20]

[0001564590-18-001677:mdna:21]
[same as prior period, unchanged from 0001564590-17-023316:mdna:21]

[0001564590-18-001677:mdna:22]
[same as prior period, unchanged from 0001564590-17-023316:mdna:22]

[0001564590-18-001677:mdna:23]
[same as prior period, unchanged from 0001564590-17-023316:mdna:23]

[0001564590-18-001677:mdna:24]
Campus Fabric

[0001564590-18-001677:mdna:25]
On July 14, 2017 (“Avaya Closing Date”), we completed the acquisition of Avaya Inc’s. fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”), that had been announced on March 7, 2017, and funds were remitted to Avaya pursuant to the Avaya Purchase Agreement. We acquired customers, employees, technology and other assets, as well as assumed contracts and other liabilities of the Campus Fabric Business, for a purchase price of $79.8 million,

[0001564590-18-001677:mdna:26]
34

[0001564590-18-001677:mdna:27]
including all adjustments.  Pursuant to certain ancillary agreements, Avaya also provides us transition services for a period of time following the Avaya Closing Date.  See Note 2. Business Combination for additional information.

[0001564590-18-001677:mdna:28]
The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Campus Fabric Business is recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Campus Fabric Business are included in our operations beginning with the Avaya Closing Date.

[0001564590-18-001677:mdna:29]
During the three months and six months ended December 31, 2017, we recognized acquisition and integration costs of $6.6 million and $9.5 million, respectively, related to the Campus Fabric Business which is included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations.

[0001564590-18-001677:mdna:30]
Data Center Business

[0001564590-18-001677:mdna:31]
On October 27, 2017 (“Brocade Closing Date”), we completed our acquisition of Brocade Communication Systems, Inc.’s (“Brocade”) Data Center Business that had been announced on October 3, 2017.  Upon the terms and subject to the conditions of the Brocade Asset Purchase Agreement, we acquired customers, employees, technology and other assets of the Data Center Business, as well as assumed certain contracts and other liabilities of the Data Center Business, for an upfront cash closing payment equal to $23.0 million, plus deferred payments of $20.0 million to be paid $1.0 million per quarter for 20 quarters following the Brocade Closing Date, plus quarterly earn out payments equal to 50% of profits of the Data Center Business for the five-year period commencing at the end of our first full fiscal quarter following the Brocade Closing Date. Pursuant to certain ancillary agreements, Brocade also provides us with transition services for a period of time following the Brocade Closing Date.  See Note 2. Business Combination for additional information.

[0001564590-18-001677:mdna:32]
The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of the Data Center Business is recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of the Data Center Business are included in our operations beginning with the Closing Date.

[0001564590-18-001677:mdna:33]
During the three and six months ended December 31, 2017, we recognized acquisition costs of $32.5 million and $33.8 million, respectively, including a $25.0 million consent fee paid to Broadcom Corporation (“Broadcom”), to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade. Acquisitions costs are included in “Acquisition and integration costs, net of bargain purchase gain” in the accompanying condensed consolidated statements of operations.

[0001564590-18-001677:mdna:34]
Key Financial Metrics

[0001564590-18-001677:mdna:35]
During the second quarter of fiscal 2018, we reflected the following results:

[0001564590-18-001677:mdna:36]
|  | • | Net revenues of $231.1 million compared to $156.4 million in the second quarter of fiscal 2017. |

[0001564590-18-001677:mdna:37]
|  | • | Product revenues of $174.9 million compared to $118.1 million in the second quarter of fiscal 2017. |

[0001564590-18-001677:mdna:38]
|  | • | Service revenues of $56.3 million compared to $38.3 million in the second quarter of fiscal 2017. |

[0001564590-18-001677:mdna:39]
|  | • | Total gross margin of 55.8% of net revenues compared to 50.9% of net revenues in the second quarter of fiscal 2017. |

[0001564590-18-001677:mdna:40]
|  | • | Operating loss of $31.1 million compared to operating loss $3.0 million in the second quarter of fiscal 2017. |

[0001564590-18-001677:mdna:41]
|  | • | Net loss of $31.9 million compared to a net loss of $4.2 million in the second quarter of fiscal 2017. |

[0001564590-18-001677:mdna:42]
|  | • | Cash flow provided by operating activities of $14.2 million compared to $19.3 million in the six months ended December 31, 2016. |

[0001564590-18-001677:mdna:43]
|  | • | Cash, cash equivalents and marketable securities of $128.2 million compared to $130.5 million as of June 30, 2017. |

[0001564590-18-001677:mdna:44]
[same as prior period, unchanged from 0001564590-17-023316:mdna:43]

[0001564590-18-001677:mdna:45]
[same as prior period, unchanged from 0001564590-17-023316:mdna:44]

[0001564590-18-001677:mdna:46]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | $ Change |  |  | % Change |  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 174,850 |  |  | $ | 118,055 |  |  | $ | 56,795 |  |  |  | 48.1 | % |  | $ | 339,624 |  |  | $ | 208,148 |  |  | $ | 131,476 |  |  |  | 63.2 | % |
| Percentage of net revenue |  |  | 75.7 | % |  |  | 75.5 | % |  |  |  |  |  |  |  |  |  |  | 76.7 | % |  |  | 74.6 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 56,273 |  |  |  | 38,322 |  |  |  | 17,951 |  |  |  | 46.8 | % |  |  | 103,214 |  |  |  | 70,833 |  |  |  | 32,381 |  |  |  | 45.7 | % |
| Percentage of net revenue |  |  | 24.3 | % |  |  | 24.5 | % |  |  |  |  |  |  |  |  |  |  | 23.3 | % |  |  | 25.4 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 231,123 |  |  | $ | 156,377 |  |  | $ | 74,746 |  |  |  | 47.8 | % |  | $ | 442,838 |  |  | $ | 278,981 |  |  | $ | 163,857 |  |  |  | 58.7 | % |

[0001564590-18-001677:mdna:47]
Product revenues increased $56.8 million or 48.1% for the three months ended December 31, 2017 as compared to the corresponding period of fiscal 2017. Product revenues increased $131.5 million or 63.2% for the six months ended December 31, 2017as compared to the corresponding period of fiscal 2017. The increase in product revenues for both periods of fiscal 2018 were attributable to low single digit organic growth and growth related to the acquisitions of the WLAN Business, Campus Fabric Business and the Data Center Business.

[0001564590-18-001677:mdna:48]
Service revenues increased $18.0 million, or 46.8% for the three months ended December 31, 2017 as compared to the corresponding period of fiscal 2017. Service revenues increased $32.4 million or 45.7% for the six months ended December 31, 2017 as compared to the corresponding period of fiscal 2017. The increase in service revenue for both periods of fiscal 2018 were due to the increased number of service contracts acquired as a result of the acquisitions of the WLAN Business, Campus Fabric Business and the Data Center Business.

[0001564590-18-001677:mdna:49]
[same as prior period, unchanged from 0001564590-17-023316:mdna:48]

[0001564590-18-001677:mdna:50]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | $ Change |  |  | % Change |  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 96,378 |  |  | $ | 55,428 |  |  | $ | 40,950 |  |  |  | 73.9 | % |  | $ | 181,107 |  |  | $ | 101,272 |  |  | $ | 79,835 |  |  |  | 78.8 | % |
| Percentage of product revenue |  |  | 55.1 | % |  |  | 47.0 | % |  |  |  |  |  |  |  |  |  |  | 53.3 | % |  |  | 48.7 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 32,608 |  |  |  | 24,224 |  |  |  | 8,384 |  |  |  | 34.6 | % |  |  | 60,260 |  |  |  | 44,266 |  |  |  | 15,994 |  |  |  | 36.1 | % |
| Percentage of service revenue |  |  | 57.9 | % |  |  | 63.2 | % |  |  |  |  |  |  |  |  |  |  | 58.4 | % |  |  | 62.5 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 128,986 |  |  | $ | 79,652 |  |  | $ | 49,334 |  |  |  | 61.9 | % |  | $ | 241,367 |  |  | $ | 145,538 |  |  | $ | 95,829 |  |  |  | 65.8 | % |
| Percentage of net revenue |  |  | 55.8 | % |  |  | 50.9 | % |  |  |  |  |  |  |  |  |  |  | 54.5 | % |  |  | 52.2 | % |  |  |  |  |  |  |  |  |

[0001564590-18-001677:mdna:51]
Product gross profit increased $41.0 million or 73.9% for the three months ended December 31, 2017 as compared to the corresponding period in fiscal 2017, primarily due to the acquisitions of the WLAN Business, the Campus Fabric Business and the Data Center Business and the corresponding revenues attributed to those acquisitions, more favorable manufacturing costs due to cost reduction efforts and a decrease in integration costs of $3.9 million including excess inventory charges related to the discontinuance of certain product lines due to the acquisition of the Data Center Business as opposed to the same charges incurred related to the acquisition of the WLAN Business in the corresponding period in fiscal 2017.  The increases in product gross profit were partially offset by increases in amortization of developed technology intangibles of $2.2 million and warranty charges of $1.0 million.

[0001564590-18-001677:mdna:52]
Product gross profit increased $79.8 million or 78.8% for the six months ended December 31, 2017 as compared to the corresponding period of fiscal 2017, primarily due to the acquisitions of the WLAN Business, Campus Fabric Business and the Data Center Business and the corresponding revenues attributed to those acquisitions and more favorable manufacturing costs due to cost reduction efforts. The increases in product gross profit were partially offset by increases in warranty charges of $2.7 million, royalty charges of $1.4 million, amortization of developed technology intangibles of $1.1 million, and integration costs of $0.9 million including excess inventory charges related to the discontinuance of certain product lines due to the acquisitions of the Campus Fabric Business and the Data Center Business as opposed to the same charges incurred related to the acquisition of the WLAN Business in the corresponding period in fiscal 2017.

[0001564590-18-001677:mdna:53]
Service gross profit increased $8.4 million or 34.6% for the three months ended December 31, 2017 as compared to the corresponding period in fiscal 2017, primarily due to the acquisitions of the WLAN Business, Campus Fabric Business and the Data Center Business as a result of higher number of maintenance contracts.

[0001564590-18-001677:mdna:54]
Service gross profit increased $16.0 million or 36.1% for the six months ended December 31, 2017 as compared to the corresponding period in fiscal 2017, primarily due the acquisitions of the WLAN Business, Campus Fabric Business and the Data Center Business as a result of higher number of maintenance contracts.

[0001564590-18-001677:mdna:55]
[same as prior period, unchanged from 0001564590-17-023316:mdna:52]

[0001564590-18-001677:mdna:56]
[same as prior period, unchanged from 0001564590-17-023316:mdna:53]

[0001564590-18-001677:mdna:57]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | $ Change |  |  | % Change |  |  | December 31, 2017 |  |  | December 31, 2016 |  |  | $ Change |  |  | % Change |  |
|  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (As adjusted) |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 45,907 |  |  | $ | 24,013 |  |  | $ | 21,894 |  |  |  | 91.2 | % |  | $ | 80,192 |  |  | $ | 42,312 |  |  | $ | 37,880 |  |  |  | 89.5 | % |
| Sales and marketing |  |  | 65,659 |  |  |  | 41,025 |  |  |  | 24,634 |  |  |  | 60.0 | % |  |  | 121,220 |  |  |  | 77,884 |  |  |  | 43,336 |  |  |  | 55.6 | % |
| General and administrative |  |  | 11,669 |  |  |  | 9,397 |  |  |  | 2,272 |  |  |  | 24.2 | % |  |  | 23,854 |  |  |  | 17,684 |  |  |  | 6,170 |  |  |  | 34.9 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 34,115 |  |  |  | 4,169 |  |  |  | 29,946 |  |  |  | 718.3 | % |  |  | 38,359 |  |  |  | 6,490 |  |  |  | 31,869 |  |  |  | 491.0 | % |
| Restructuring and related charges, net of reversals |  |  | — |  |  |  | 1,853 |  |  |  | (1,853 | ) |  |  | (100.0 | )% |  |  | — |  |  |  | 1,853 |  |  |  | (1,853 | ) |  |  | (100.0 | )% |
| Amortization of intangibles |  |  | 2,746 |  |  |  | 2,175 |  |  |  | 571 |  |  |  | 26.3 | % |  |  | 4,360 |  |  |  | 6,317 |  |  |  | (1,957 | ) |  |  | (31.0 | )% |
| Total operating expenses |  | $ | 160,096 |  |  | $ | 82,632 |  |  | $ | 77,464 |  |  |  | 93.7 | % |  | $ | 267,985 |  |  | $ | 152,540 |  |  | $ | 115,445 |  |  |  | 75.7 | % |

[0001564590-18-001677:mdna:58]
[same as prior period, unchanged from 0001564590-17-023316:mdna:55]

[0001564590-18-001677:mdna:59]
[same as prior period, unchanged from 0001564590-17-023316:mdna:56]

[0001564590-18-001677:mdna:60]
Research and development expenses increased by $21.9 million or 91.2% for the three months ended December 31, 2017 as compared to the corresponding period of fiscal 2017.  The increase in research and development expenses was due to higher personnel costs (which consists of compensation, benefits and non-cash stock based compensation) of $18.5 million due to increased headcount related to the acquisitions of the WLAN Business, the Campus Fabric Business and the Data Center Business, $2.8 million in increased facility and information technology costs, $0.4 million in increased supplies and equipment costs and $0.2 million in increased travel and other costs.

[0001564590-18-001677:mdna:61]
Research and development expenses increased by $37.9 million or 89.5% for the six months ended December 31, 2017as compared to the corresponding period of fiscal 2017.  The increase in research and development expenses was due to higher personnel costs (which consists of compensation, benefits and non-cash stock based compensation) of $29.7 million due to increased headcount related to the acquisitions of the WLAN Business, the Campus Fabric Business and the Data Center Business, $5.3 million in increased facility and information technology costs, $1.8 million in increased supplies and equipment costs and $1.1 million in increased travel and other costs.

[0001564590-18-001677:mdna:62]
[same as prior period, unchanged from 0001564590-17-023316:mdna:58]

[0001564590-18-001677:mdna:63]
[same as prior period, unchanged from 0001564590-17-023316:mdna:59]

[0001564590-18-001677:mdna:64]
Sales and marketing expenses increased by $24.6 million or 60.0% for the three months ended December 31, 2017 as compared to the corresponding period of fiscal 2017 three and six months ended December 31, 2017 primarily as a result of the acquisitions of the WLAN Business, the Campus Fabric Business and the Data Center Business.  The increase consisted of higher personnel costs including benefits and non-cash stock compensation of $18.5 million, $3.0 million in increased travel, meeting and conference costs, and $1.8 million in increased facility and information technology costs and $0.9 million in additional professional fees.

[0001564590-18-001677:mdna:65]
Sales and marketing expenses increased by $43.3 million or 55.6% for the six months ended December 31, 2017 as compared to the corresponding period of fiscal 2017 three and six months ended December 31, 2017 primarily as a result of the acquisitions of the WLAN Business, the Campus Fabric Business and the Data Center Business.  The increase consisted of higher personnel costs including benefits and non-cash stock compensation of $30.9 million, $6.7 million in increased travel, meeting and conference costs, $3.4 million in increased facility and information technology costs and $2.1 million in additional professional fees.

[0001564590-18-001677:mdna:66]
[same as prior period, unchanged from 0001564590-17-023316:mdna:61]

[0001564590-18-001677:mdna:67]
[same as prior period, unchanged from 0001564590-17-023316:mdna:62]

[0001564590-18-001677:mdna:68]
General and administrative expenses increased by $2.3 million or 24.2% for the three months ended December 31, 2017 as compared to the corresponding period of fiscal 2017 primarily due to $1.6 million in higher compensation, benefits and non-cash stock based compensation, $0.7 million in higher bad debts provision, $0.3 million in higher professional fees and $0.3 million in reduced facility and information technology costs.

[0001564590-18-001677:mdna:69]
General and administrative expenses increased by $6.2 million or 34.9% for the six months ended December 31, 2017 as compared to the corresponding period of fiscal 2017 primarily due to $3.8 million in higher compensation, benefits and non-cash stock based compensation, $1.3 million in higher professional fees and $1.1 million in higher bad debts provision.

[0001564590-18-001677:mdna:70]
Acquisition and Integration Costs, Net of Bargain Purchase Gain

[0001564590-18-001677:mdna:71]
During the three months ended December 31, 2017 and 2016, we recorded $34.1 million and $4.2 million, respectively, of acquisition and integration costs.

[0001564590-18-001677:mdna:72]
For the three months ended December 31, 2017, we incurred $4.6 million of acquisition and $1.9 million of integration costs related to the acquisition of the Campus Fabric Business and $30.3 million of acquisition and $2.2 million of integration costs related to the acquisition of the Data Center Business.  The Data Center Business acquisition costs includes a $25.0 million consent fee paid to Broadcom, to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade.  Included in Acquisition and Integration Costs is a gain on bargain purchase of $4.9 million related to the acquisition of the capital financing business (“CF Business”).

[0001564590-18-001677:mdna:73]
Expenses for the three months ended December 31, 2016 consisted primarily of legal and accounting services associated with the acquisition of the WLAN Business.

[0001564590-18-001677:mdna:74]
During the six months ended December 31, 2017 and 2016, we recorded $38.4 million and $6.5 million, respectively, of acquisition and integration costs.

[0001564590-18-001677:mdna:75]
For the six months ended December 31, 2017, we incurred $5.9 million of acquisition and $3.4 million of integration costs related to the acquisition of the Campus Fabric Business and $31.6 million of acquisition and $2.2 million of integration costs related to the acquisition of the Data Center Business. We also recorded a gain on bargain purchase of $4.9 million related to the acquisition of the CF Business.

[0001564590-18-001677:mdna:76]
Expenses for the six months ended December 31, 2016 consisted primarily of legal and accounting services associated with the acquisition of the WLAN Business.

[0001564590-18-001677:mdna:77]
Restructuring and Related Charges, Net of Reversals

[0001564590-18-001677:mdna:78]
No restructuring charges were recorded for the three or six months ended December 31, 2017.

[0001564590-18-001677:mdna:79]
For the three and six months ended December 31, 2016, we incurred $1.9 million in restructuring and other charges including accelerated depreciation of leasehold improvements and fixed assets in the amount of $1.7 million and adjustments to estimated sub-lease income to be received related to the estimated future obligations for non-cancelable lease payments for excess facilities of $0.1 million.

[0001564590-18-001677:mdna:80]
[same as prior period, unchanged from 0001564590-17-023316:mdna:68]

[0001564590-18-001677:mdna:81]
During the three months ended December 31, 2017 and 2016, we recorded $2.7 million and $2.2 million, respectively, of amortization of our intangibles.  The increase was mainly due to additional amortization related to the acquired intangibles from the Campus Fabric and the Data Center Business, partially offset by the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-18-001677:mdna:82]
During the six months ended December 31, 2017 and 2016, we recorded $4.4 million and $6.3 million, respectively of amortization expense as operating expenses in the accompanying condensed consolidated statements of operations.  The reduction was due to the acquired intangibles from the Enterasys acquisition becoming fully amortized, partially offset by additional amortization related to the acquired intangibles from the Campus Fabric and the Data Center Business.

[0001564590-18-001677:mdna:83]
[same as prior period, unchanged from 0001564590-17-023316:mdna:70]

[0001564590-18-001677:mdna:84]
During the three months ended December 31, 2017 and 2016, we recorded $2.5 million and $1.2 million, respectively, in interest expense.  The increase in interest expense was primarily in connection with the increased balance of our Credit Facility due to the acquisitions of the Campus Fabric Business and the Data Center Business.

[0001564590-18-001677:mdna:85]
During the six months ended December 31, 2017 and 2016, we recorded $4.7 million and $1.8 million, respectively, in interest expense.  The increase in interest expense was primarily in connection with the increased balance of our Credit Facility due to the acquisitions of the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0001564590-18-001677:mdna:86]
[same as prior period, unchanged from 0001564590-17-023316:mdna:72]

[0001564590-18-001677:mdna:87]
During the three months ended December 31, 2017 and 2016, we recorded expense of $0.6 million and income of $1.0 million, respectively, in other income (expense), net. The change was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-18-001677:mdna:88]
During the six months ended December 31, 2017 and 2016, we recorded income of 2.5 million and $0.8 million, respectively, in other income (expense), net. The income for fiscal 2018 period was primarily driven by a gain of $3.8 million due to the sale of non-marketable equity investment, partially offset by foreign exchange losses.  The income for fiscal 2017 period was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-18-001677:mdna:89]
Provision (Benefit) for Income Taxes

[0001564590-18-001677:mdna:90]
For the three months ended December 31, 2017 and 2016, we recorded an income tax benefit of $1.6 million and an income tax provision of $1.2 million, respectively, which consisted primarily of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys, the WLAN Business and the Campus Fabric Business.  The tax provision for the three months ended December 31, 2017 is offset by a tax benefit resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to our deferred tax liability related to amortizable goodwill as required by the recently enacted U.S. tax legislation discussed in Note 10 of the accompanying condensed consolidated financial statements. The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended December 31, 2017 and 2016, and therefore may not reflect the annual effective tax rate.

[0001564590-18-001677:mdna:91]
For the six months ended December 31, 2017 and 2016, we recorded an income tax provision of $0.1 million and $2.1 million, respectively, which consisted primarily of taxes on the income of the Company’s foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisitions referenced above.  The income tax provision for the six months ended December 31, 2017 is offset by the tax benefit referenced above.

[0001564590-18-001677:mdna:92]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, is effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, we will not be subject to the majority of the tax law provisions until fiscal year 2019; however, there are certain significant items of impact that will be recognized in fiscal year 2018. Because a change in tax law is accounted for in the period of enactment, the effects of the TCJA, a tax benefit of $2.5 million, have been reflected in the second quarter of fiscal 2018. See Note 10 to the consolidated financial statements includes a detailed discussion of the various provisions of the new U.S. tax legislation.

[0001564590-18-001677:mdna:93]
[same as prior period, unchanged from 0001564590-17-023316:mdna:76]

[0001564590-18-001677:mdna:94]
[same as prior period, unchanged from 0001564590-17-023316:mdna:77]

[0001564590-18-001677:mdna:95]
[same as prior period, unchanged from 0001564590-17-023316:mdna:78]

[0001564590-18-001677:mdna:96]
[same as prior period, unchanged from 0001564590-17-023316:mdna:79]

[0001564590-18-001677:mdna:97]
[same as prior period, unchanged from 0001564590-17-023316:mdna:80]

[0001564590-18-001677:mdna:98]
[same as prior period, unchanged from 0001564590-17-023316:mdna:81]

[0001564590-18-001677:mdna:99]
[same as prior period, unchanged from 0001564590-17-023316:mdna:82]

[0001564590-18-001677:mdna:100]
[same as prior period, unchanged from 0001564590-17-023316:mdna:83]

[0001564590-18-001677:mdna:101]
The following critical accounting policies are the only change since the filing of our last Annual Report on Form 10-K.

[0001564590-18-001677:mdna:102]
[same as prior period, unchanged from 0001564590-17-023316:mdna:85]

[0001564590-18-001677:mdna:103]
[same as prior period, unchanged from 0001564590-17-023316:mdna:86]

[0001564590-18-001677:mdna:104]
[same as prior period, unchanged from 0001564590-17-023316:mdna:87]

[0001564590-18-001677:mdna:105]
[same as prior period, unchanged from 0001564590-17-023316:mdna:88]

[0001564590-18-001677:mdna:106]
[same as prior period, unchanged from 0001564590-17-023316:mdna:89]

[0001564590-18-001677:mdna:107]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Revenue from sales to distributors is recognized upon the transfer of control to the distributor. Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business, and submits rebate requests for Company pre-approval prior to selling the product through at the discounted price. At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a trailing twelve-month period of time considered adequate to account for current pricing and business trends. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are also estimated using the expected value method based on historical return rates The Company did not experience significant differences in its estimates during the six months ended December 31, 2017.  For additional information, see Note 3, Summary of Significant Accounting Policies.

[0001564590-18-001677:mdna:108]
Business Combinations

[0001564590-18-001677:mdna:109]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the completion of the transaction. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of purchase price, a gain on bargain purchase is recognized in the statements of operations. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part

[0001564590-18-001677:mdna:110]
on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001564590-18-001677:mdna:111]
[same as prior period, unchanged from 0001564590-17-023316:mdna:91]

[0001564590-18-001677:mdna:112]
[same as prior period, unchanged from 0001564590-17-023316:mdna:92]

[0001564590-18-001677:mdna:113]
[same as prior period, unchanged from 0001564590-17-023316:mdna:93]

[0001564590-18-001677:mdna:114]
The following summarizes information regarding our cash, cash equivalents, marketable securities, and working capital (in thousands):

[0001564590-18-001677:mdna:115]
|  |  | December 31, 2017 |  |  | June 30, 2017 |  |
| Cash and cash equivalents |  | $ | 127,108 |  |  | $ | 130,450 |  |
| Marketable securities |  |  | 1,104 |  |  |  | — |  |
| Total cash, cash equivalent and marketable securities |  | $ | 128,212 |  |  | $ | 130,450 |  |
| Working capital |  | $ | 43,889 |  |  | $ | 85,637 |  |

[0001564590-18-001677:mdna:116]
As of December 31, 2017, our principal sources of liquidity consisted of cash, cash equivalents and marketable securities of $128.2 million, accounts receivable, net of $154.9 million and availability of borrowings from the five-year revolving credit facility (“Revolver”) of $48.8 million. Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment. We believe that our $128.2 million of cash, cash equivalents and marketable securities at December 31, 2017, cash flows from operations along with the availability of borrowings from the Revolver will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-18-001677:mdna:117]
On July 14, 2017, in connection with the closing of the acquisition of the Campus Fabric Business, we entered into the Second Amendment to the Amended and Restated Credit Agreement (“Second Amendment”), which amends the Amended and Restated Credit Agreement, dated as of October 28, 2016 (as amended, the “Credit Facility”), by and among us, as borrower, Silicon Valley Bank, as administrative agent and collateral agent, and Lenders. Among other things, the Second Amendment (i) increased the amount of the available borrowing under the Credit Facility from $140.5 million to $243.7 million, consisted of (a) the five-year term loan (“Term Loan”) facilities in a principal amount of up to $183.7 million and (b) the Revolver  in a principal amount of up to $60.0 million, (ii) extends the maturity date under the existing Term Loan and the termination date under the existing Revolver until July 2022, (iii) provides for an uncommitted additional incremental loan facility in a principal amount of up to $50.0 million (“Incremental Facility”), and (iv) joins certain additional banks, financial institutions and institutional lenders as Lenders pursuant to the terms of the Credit Facility.  On July 14, 2017, we borrowed $80.0 million under the Term Loan which was used to fund the purchase of Campus Fabric Business.

[0001564590-18-001677:mdna:118]
On October 26, 2017, we entered into the Third Amendment to the Credit Facility (the “Third Amendment”).  Among other things, the Third Amendment (i) amends the negative covenant governing dispositions to increase the general dispositions basket for our fiscal year ending June 30, 2018, and (ii) amends certain definitions and provisions to update certain references to the Brocade Purchase Agreement.  On October 27, 2017, we borrowed $20.0 million on the Term Loan to partially fund the acquisition of the Data Center Business.

[0001564590-18-001677:mdna:119]
[same as prior period, unchanged from 0001564590-17-023316:mdna:99]

[0001564590-18-001677:mdna:120]
If not repaid earlier, the borrowings on the Revolver shall be repaid on the termination date. The Credit Facility is secured by substantially all of our assets and is jointly and severally guaranteed by us and certain of our subsidiaries.

[0001564590-18-001677:mdna:121]
The Credit Facility contains financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.  These covenants, are subject to certain exceptions.

[0001564590-18-001677:mdna:122]
The Credit Facility also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting us and our subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of us.  The amounts outstanding under the Credit Facility may be accelerated upon certain events of default. At December 31, 2017, we were in compliance with the covenants of the Credit Facility and they are not expected to impact our liquidity or capital resources.

[0001564590-18-001677:mdna:123]
[same as prior period, unchanged from 0001564590-17-023316:mdna:103]

[0001564590-18-001677:mdna:124]
[same as prior period, unchanged from 0001564590-17-023316:mdna:104]

[0001564590-18-001677:mdna:125]
|  |  | Six Months Ended |  |
|  |  | December 31, 2017 |  |  | December 31, 2016 |  |
|  |  |  |  |  |  | (As adjusted) |  |
| Net cash provided by operating activities |  | $ | 14,248 |  |  | $ | 19,288 |  |
| Net cash used in investing activities |  |  | (105,968 | ) |  |  | (55,750 | ) |
| Net cash provided by financing activities |  |  | 88,284 |  |  |  | 46,241 |  |
| Foreign currency effect on cash |  |  | 94 |  |  |  | (115 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (3,342 | ) |  | $ | 9,664 |  |

[0001564590-18-001677:mdna:126]
Net Cash Provided by Operating Activities

[0001564590-18-001677:mdna:127]
Cash flows provided by operations in the six months ended December 31, 2017 were $14.2 million, including net loss of $27.5 million and non-cash expenses of $23.1 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes, gain on bargain purchase and gain on sale of non-marketable equity investment as well as increases in accounts payable, accrued compensation, deferred revenue and other current and long-term liabilities and a decrease in prepaid expenses and other assets.  This was partially offset by increases in accounts receivable and inventories.

[0001564590-18-001677:mdna:128]
Cash flows provided by operations in the six months ended December 31, 2016 were $19.3 million, including net loss of $10.0 million and non-cash expenses of $25.8 million such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes and non-cash restructuring and related charges as well as decreases in inventories, prepaid expenses and other current assets and an increase in current and long-term liabilities. This was partially offset by an increase of accounts receivable and decreases of accounts payable, accrued compensation and deferred revenue.

[0001564590-18-001677:mdna:129]
Net Cash Used in Investing Activities

[0001564590-18-001677:mdna:130]
Cash flows used in investing activities in the six months ended December 31, 2017 were $106.0 million which consisted of expenditures for acquisitions of $97.6 million consisting of $69.6 million for the acquisition of the Campus Fabric Business and $29.5 million for the acquisition of the Data Center Business, less receipt of $1.6 million as final settlement of a working capital adjustment related to the WLAN Business acquisition, purchases of property and equipment of $13.3 million and proceeds of $4.9 million related to the sale of non-marketable equity investment.

[0001564590-18-001677:mdna:131]
Cash flows used in investing activities in the six months ended December 31, 2016 were $55.8 million which consisted of expenditures of $51.1 million for the WLAN Business acquisition and $4.7 million of purchases of property and equipment.

[0001564590-18-001677:mdna:132]
[same as prior period, unchanged from 0001564590-17-023316:mdna:112]

[0001564590-18-001677:mdna:133]
Cash flows provided by financing activities in the six months ended December 31, 2017 were $88.3 million, including new borrowings of $100.0 million to fund our acquisitions of the Campus Fabric Business and the Data Center Business, $5.6 million proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options less $7.1 million of taxes paid on vested and released stock awards, partially offset by repayments of debt totaling $8.7 million and $1.5 million of loan fees incurred in connection with the Second Amendment of our Credit Facility.

[0001564590-18-001677:mdna:134]
Cash flows provided by financing activities in the six months ended December 31, 2016 were $46.2 million which consisted of new borrowings of $48.3 million under our Credit Facility, as amended, $4.8 million proceeds from the issuance of shares of our

[0001564590-18-001677:mdna:135]
common stock under our ESPP and the exercise of stock options, net of taxes paid on vested and released stock awards, offset by repayments of debt totaling $5.5 million and $1.3 million of loan fees incurred in connection with the Credit Facility, as amended.

[0001564590-18-001677:mdna:136]
Foreign Currency Effect on Cash

[0001564590-18-001677:mdna:137]
Foreign currency effect on cash increased in the three and six months ended December 31, 2017, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-18-001677:mdna:138]
Contractual Obligations

[0001564590-18-001677:mdna:139]
The following summarizes our contractual obligations as of December 31, 2017, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-18-001677:mdna:140]
|  |  | Total |  |  | Less than 1 Year |  |  |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 185,027 |  |  | $ | 22,964 |  |  |  |  | $ | 70,985 |  |  | $ | 91,078 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 25,383 |  |  |  | 8,259 |  |  |  |  |  | 12,437 |  |  |  | 4,687 |  |  |  | — |  |
| Non-cancellable inventory purchase commitments |  |  | 145,261 |  |  |  | 145,261 |  |  |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-cancellable purchase commitments |  |  | 19,000 |  |  |  | 5,000 |  |  |  |  |  | 11,000 |  |  |  | 3,000 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 103,958 |  |  |  | 21,164 |  |  |  |  |  | 35,169 |  |  |  | 26,533 |  |  |  | 21,092 |  |
| Deferred payments for an acquisition |  |  | 20,000 |  |  |  | 4,000 |  |  |  |  |  | 12,000 |  |  |  | 4,000 |  |  |  | — |  |
| Contingent consideration for acquisitions |  |  | 47,030 |  |  |  | 11,270 |  |  |  |  |  | 28,850 |  |  |  | 6,910 |  |  |  | — |  |
| Other liabilities |  |  | 1,107 |  |  |  | 244 |  |  |  |  |  | 488 |  |  |  | 375 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 546,766 |  |  | $ | 218,162 |  |  |  |  | $ | 170,929 |  |  | $ | 136,583 |  |  | $ | 21,092 |  |

[0001564590-18-001677:mdna:141]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. Inventory purchase commitments were $145.3 million as of   December 31, 2017. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-18-001677:mdna:142]
[same as prior period, unchanged from 0001564590-17-023316:mdna:121]

[0001564590-18-001677:mdna:143]
[same as prior period, unchanged from 0001564590-17-023316:mdna:122]

[0001564590-18-001677:mdna:144]
Deferred payments for an acquisition of the Data Center Business represent a $1.0 million per quarter for our next twenty full fiscal quarters following the acquisition date of October 27, 2017.

[0001564590-18-001677:mdna:145]
Contingent consideration for acquisitions of the Data Center Business and the Capital Financing Business is recorded at fair value and actual results could be different.

[0001564590-18-001677:mdna:146]
[same as prior period, unchanged from 0001564590-17-023316:mdna:123]

[0001564590-18-001677:mdna:147]
[same as prior period, unchanged from 0001564590-17-023316:mdna:124]

[0001564590-18-001677:mdna:148]
We did not have any material commitments for capital expenditures as of December 31, 2017.

[0001564590-18-001677:mdna:149]
[same as prior period, unchanged from 0001564590-17-023316:mdna:126]

[0001564590-18-001677:mdna:150]
We did not have any off-balance sheet arrangements as of December 31, 2017.
