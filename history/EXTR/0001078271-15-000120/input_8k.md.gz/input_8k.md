# EXTR 8-K — 0001078271-15-000093 filed 2015-08-06

## item codes, every 8-K on or before 2015-09-14

- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2015-09-14

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001078271-15-000093:8k_2_02:1]
EX-99.1
2
extr8-kq415ex991.htm
EXHIBIT 99.1

[0001078271-15-000093:8k_2_02:2]
EXTR 8-K Q4'15 EX 99.1

[0001078271-15-000093:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001078271-15-000093:8k_2_02:4]
| For more information, contact: |  |  |
| Investor Relations |  | Media Contact |
| 408/579-3456 |  | 617/624-3231 |
| fyoshino@extremenetworks.com |  | ExtremeUS@racepointglobal.com |

[0001078271-15-000093:8k_2_02:5]
Extreme Networks Reports Fourth Quarter and Fiscal Year 2015 Financial Results

[0001078271-15-000093:8k_2_02:6]
Q4 GAAP Revenue of $149.9 million & Non-GAAP Revenue of $150.6 million

[0001078271-15-000093:8k_2_02:7]
Q4 GAAP EPS Loss of $0.16 & Non-GAAP EPS Income of $0.10

[0001078271-15-000093:8k_2_02:8]
Fiscal Year GAAP Revenue of $552.9 million & Non-GAAP Revenue of $556.0 million

[0001078271-15-000093:8k_2_02:9]
Fiscal Year GAAP EPS Loss of $0.72 & Non-GAAP EPS Income of $0.06

[0001078271-15-000093:8k_2_02:10]
SAN JOSE, Calif., August 6, 2015 -- Extreme Networks, Inc. (Nasdaq: EXTR) today released financial results for the fourth quarter and fiscal year ended June 30, 2015.  Fourth quarter GAAP revenue was $149.9 million and non-GAAP revenue was $150.6 million.  GAAP net loss for the fourth fiscal quarter was $15.7 million, or $0.16 per share, and non-GAAP net income was $10.1 million, or $0.10 per share.

[0001078271-15-000093:8k_2_02:11]
For the full fiscal year 2015, Extreme Networks reported GAAP revenue of $552.9 million, compared to $519.6 million for fiscal 2014.  Fiscal year 2015 non-GAAP revenue was $556.0 million compared to $524.8 million in fiscal 2014.  GAAP net loss was $71.6 million, or $0.72 per share, for fiscal 2015, compared to GAAP net loss of $57.3 million, or $0.60 per share, for fiscal 2014.  On a non-GAAP basis, net income for fiscal 2015 was $5.9 million, or $0.06 per diluted share, compared to $29.5 million, or $0.30 per diluted share for fiscal 2014.

[0001078271-15-000093:8k_2_02:12]
“We had a strong finish to fiscal 2015 while reducing headcount and realigning our functional groups to become more customer focused,” stated Ed Meyercord, president and CEO of Extreme Networks.  “We saw a nice recovery across all geographies except Latin America where we are transitioning from direct sales to channel distribution.  Our US sales team performed particularly well with several notable deals with entertainment venues and K-12 education customers as the later began to benefit from E-Rate funding.  After successfully streamlining our organization, reducing costs and sharpening our focus on a solutions-based strategy, we enter fiscal 2016 on solid footing,” said Meyercord.  “We anticipate E-Rate will have a positive impact to our US based business in fiscal 2016, however the pace at which the government funds the requests will dictate the timing and impact to our business.  Although EMEA and APAC rebounded nicely this quarter, we continue to see currency, pricing and competition as headwinds in these geographies.”

[0001078271-15-000093:8k_2_02:13]
Recent Key Events:

[0001078271-15-000093:8k_2_02:14]
| • | Extreme Networks unveiled its new solutions-based go-to-market strategy to enable businesses, manufacturing companies, health care providers, educational institutions and government agencies to adapt quickly to meet and exceed business objectives. |

[0001078271-15-000093:8k_2_02:15]
| • | Extreme Networks announced its advanced solutions portfolio with new policy management capabilities. Expanding the Company’s software-driven networking solutions portfolio, secure, role-based policy management technology is now available for the newly launched Summit® X450-G2 family of fixed switches and several previously released Summit families. This marks the integration of proven policy and security management technology into the ExtremeXOS® operating system. |

[0001078271-15-000093:8k_2_02:16]
| • | Extreme Networks announced expanded classroom solutions and momentum in customer adoption. Customers include Hardin County School District, Stonington Public School District and Aldine School District. |

[0001078271-15-000093:8k_2_02:17]
| • | Extreme Networks, in partnership with US Ignite, announced the winners of the first annual Extreme Networks SDN Innovation Challenge. The Company awarded prizes to the top three teams for applications that leveraged the Extreme Networks SDN platform to best drive innovation. |

[0001078271-15-000093:8k_2_02:18]
| • | Extreme Networks continued to showcase customer momentum across the global education, healthcare, manufacturing, sports and entertainment, government and financial services markets. Notable customer wins include the European Investment Bank, State of Connecticut General Assembly, Manipal Hospitals, Gyeonggi-do Fire Service, Aldine Independent School District, Baylor University, Viadrina and the NFL’s Buffalo Bills. |

[0001078271-15-000093:8k_2_02:19]
| • | Extreme Networks’ Sandra Cheek was honored as one of CRN’s 2015 Women of the Channel. The honor recognizes top female executives whose expertise and vision in the channel have made them leaders in the channel market. |

[0001078271-15-000093:8k_2_02:20]
Fiscal Q4 2015 Financial Metrics:

[0001078271-15-000093:8k_2_02:21]
|  | Fourth Quarter |  |  |  |  |
|  | (in millions, except per share amounts and percentages) |  |  |  |  |
|  | (unaudited) |  |  |  |  |
|  | 2015 |  | 2014 |  | Change |
| GAAP Net Revenue |  |  |  |  |  |  |  |
| Product | $ | 116.3 |  |  | $ | 121.8 |  |  | $ | (5.5 | ) |  | (5 | )% |
| Service | $ | 33.6 |  |  | $ | 33.5 |  |  | $ | 0.1 |  |  | — | % |
| Total Net Revenue | $ | 149.9 |  |  | $ | 155.3 |  |  | $ | (5.4 | ) |  | (3 | )% |
| Gross Margin | 50.9 | % |  | 53.4 | % |  | (2.5 | )% |  | (5 | )% |
| Operating (Loss) Margin | (9.0 | )% |  | (8.7 | )% |  | (0.3 | )% |  | 3 | % |
| Net Loss | $ | (15.7 | ) |  | $ | (16.2 | ) |  | $ | 0.5 |  |  | (3 | )% |
| Loss per diluted share | $ | (0.16 | ) |  | $ | (0.17 | ) |  | $ | 0.01 |  |  | (6 | )% |
| Non-GAAP Net Revenue |  |  |  |  |  |  |  |
| Product | $ | 116.3 |  |  | $ | 121.8 |  |  | $ | (5.5 | ) |  | (5 | )% |
| Service | $ | 34.3 |  |  | $ | 35.1 |  |  | $ | (0.8 | ) |  | (2 | )% |
| Total Net Revenue | $ | 150.6 |  |  | $ | 156.9 |  |  | $ | (6.3 | ) |  | (4 | )% |
| Gross Margin | 54.4 | % |  | 56.9 | % |  | (2.5 | )% |  | (4 | )% |
| Operating Margin | 8.2 | % |  | 7.2 | % |  | 1.0 | % |  | 14 | % |
| Net Income | $ | 10.1 |  |  | $ | 8.5 |  |  | $ | 1.6 |  |  | 19 | % |
| Earnings per diluted share | $ | 0.10 |  |  | $ | 0.09 |  |  | $ | 0.01 |  |  | 11 | % |

[0001078271-15-000093:8k_2_02:22]
| • | Cash and investments ended the quarter at $76.2 million, as compared to $75.6 million from the prior quarter. |

[0001078271-15-000093:8k_2_02:23]
| • | Accounts receivable balance ending Q4 was $92.7 million, with days sales outstanding (DSO) of 56. |

[0001078271-15-000093:8k_2_02:24]
| • | Inventory ending Q4 was $58.0 million, a decrease of $8.8 million from the prior quarter. |

[0001078271-15-000093:8k_2_02:25]
Business Outlook:

[0001078271-15-000093:8k_2_02:26]
For its first quarter of fiscal 2016 ending September 30, 2015, the Company is targeting GAAP revenue in a range of $119.6 million to $129.6 million with non-GAAP revenue in a range of $120 million to $130 million. GAAP gross margin is targeted between 49.5% and 51.0% and non-GAAP gross margin targeted between 54.0% and 55.0%. Operating expenses are targeted to be between $73.0 million and $75.5 million on a GAAP basis and $62.5 million to $65.0 million on a non-GAAP basis. GAAP net loss is targeted to be between $10.5 million to $15.0 million, or $0.11 to $0.15 per share.  Non-GAAP earnings are targeted in a range of a net income of $0.75 million to $5.0 million, or $0.01 to $0.05 per share. The GAAP and non-GAAP net income (loss) targets are based on an estimated 102 million and 104 million average outstanding shares, respectively. Targeted non-GAAP earnings exclude expenses related to stock-based compensation expense, the amortization of acquired intangibles, acquisition and integration related expenses, restructuring expenses and the purchase accounting adjustment related to deferred service revenue.

[0001078271-15-000093:8k_2_02:27]
Conference Call:

[0001078271-15-000093:8k_2_02:28]
Extreme Networks will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the fourth fiscal quarter and fiscal year end results and first fiscal quarter 2016 business outlook, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the Internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August 5, 2016.  The conference call may also be heard by dialing 1-877-303-9826 (international callers dial 1-224-357-2194). Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing (855) 859-2056 /or international 1 (404) 537-3406; Conference ID #:74553850.

[0001078271-15-000093:8k_2_02:29]
About Extreme Networks:

[0001078271-15-000093:8k_2_02:30]
Extreme Networks, Inc. (EXTR) is a software and services-led networking solutions company committed to solving IT's toughest networking challenges. Extreme Networks is headquartered in San Jose, CA with more than 14,000 customers in over 80 countries. For more information, visit Extreme's website.

[0001078271-15-000093:8k_2_02:31]
Extreme Networks and the Extreme Networks logo, ExtremeXOS, and Summit are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries. All other names are the property of their respective owners.

[0001078271-15-000093:8k_2_02:32]
Non-GAAP Financial Measures:

[0001078271-15-000093:8k_2_02:33]
Extreme Networks provides all financial information required in accordance with generally accepted accounting principles (GAAP). The Company is providing with this press release non-GAAP revenue, non-GAAP gross margins, non-GAAP operating expenses, and non-GAAP income/(loss) per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of acquisition and integration costs, purchase accounting adjustments, amortization of acquired intangibles, restructuring

[0001078271-15-000093:8k_2_02:34]
charges, executive transition expenses,  share-based compensation and litigation settlements.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note that the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.  The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001078271-15-000093:8k_2_02:35]
Forward Looking Statements:

[0001078271-15-000093:8k_2_02:36]
More information about potential factors that could affect the Company's business and financial results is included in the Company’s filings with the Securities and Exchange Commission, including, without limitation, under the captions: "Management's Discussion and Analysis of Financial Condition and Results of Operations," and "Risk Factors".  Except as required under the U.S. federal securities laws and the rules and regulations of the SEC, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001078271-15-000093:8k_2_02:37]
EXTREME NETWORKS, INC.

[0001078271-15-000093:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001078271-15-000093:8k_2_02:39]
(In thousands, except share and per share amounts)

[0001078271-15-000093:8k_2_02:40]
(Unaudited)

[0001078271-15-000093:8k_2_02:41]
|  | June 30, 2015 |  | June 30, 2014 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 76,225 |  |  | $ | 73,190 |  |
| Short-term investments | — |  |  | 32,692 |  |
| Accounts receivable, net of allowances of $2,396 at June 30, 2015 and $3,618 at June 30, 2014 | 92,737 |  |  | 124,664 |  |
| Inventories | 58,014 |  |  | 57,109 |  |
| Deferred income taxes | 760 |  |  | 1,058 |  |
| Prepaid expenses and other current assets | 10,258 |  |  | 14,143 |  |
| Total current assets | 237,994 |  |  | 302,856 |  |
| Property and equipment, net | 39,862 |  |  | 46,554 |  |
| Intangible assets, net | 52,132 |  |  | 87,459 |  |
| Goodwill | 70,877 |  |  | 70,877 |  |
| Other assets | 27,795 |  |  | 18,686 |  |
| Total assets | $ | 428,660 |  |  | $ | 526,432 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Current portion of long-term debt | $ | 11,375 |  |  | $ | 29,688 |  |
| Accounts payable | 40,135 |  |  | 37,308 |  |
| Accrued compensation and benefits | 25,195 |  |  | 26,677 |  |
| Accrued warranty | 8,676 |  |  | 7,551 |  |
| Deferred revenue, net | 76,551 |  |  | 74,735 |  |
| Deferred distributors revenue, net of cost of sales to distributors | 40,875 |  |  | 31,992 |  |
| Other accrued liabilities | 32,623 |  |  | 38,357 |  |
| Total current liabilities | 235,430 |  |  | 246,308 |  |
| Deferred revenue, less current portion | 23,231 |  |  | 22,942 |  |
| Long-term debt, less current portion | 55,500 |  |  | 91,875 |  |
| Deferred income taxes | 2,979 |  |  | — |  |
| Other long-term liabilities | 7,285 |  |  | 8,595 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity | 104,235 |  |  | 156,712 |  |
| Total liabilities and stockholders’ equity | $ | 428,660 |  |  | $ | 526,432 |  |

[0001078271-15-000093:8k_2_02:42]
EXTREME NETWORKS, INC.

[0001078271-15-000093:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000093:8k_2_02:44]
(In thousands, except per share amounts)

[0001078271-15-000093:8k_2_02:45]
(Unaudited)

[0001078271-15-000093:8k_2_02:46]
|  | Three Months Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Net revenues: |  |  |  |  |  |  |  |
| Product | $ | 116,347 |  |  | $ | 121,761 |  |  | $ | 418,046 |  |  | $ | 411,761 |  |
| Service | 33,523 |  |  | 33,532 |  |  | 134,894 |  |  | 107,793 |  |
| Total net revenues | 149,870 |  |  | 155,293 |  |  | 552,940 |  |  | 519,554 |  |
| Cost of revenues: |  |  |  |  |  |  |  |
| Product | 60,736 |  |  | 60,561 |  |  | 225,018 |  |  | 213,673 |  |
| Service | 12,807 |  |  | 11,810 |  |  | 48,185 |  |  | 38,552 |  |
| Total cost of revenues | 73,543 |  |  | 72,371 |  |  | 273,203 |  |  | 252,225 |  |
| Gross profit: |  |  |  |  |  |  |  |
| Product | 55,611 |  |  | 61,200 |  |  | 193,028 |  |  | 198,088 |  |
| Service | 20,716 |  |  | 21,722 |  |  | 86,709 |  |  | 69,241 |  |
| Total gross profit | 76,327 |  |  | 82,922 |  |  | 279,737 |  |  | 267,329 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 22,242 |  |  | 24,048 |  |  | 93,447 |  |  | 77,146 |  |
| Sales and marketing | 41,322 |  |  | 48,634 |  |  | 169,299 |  |  | 156,666 |  |
| General and administrative | 11,001 |  |  | 11,511 |  |  | 42,092 |  |  | 40,912 |  |
| Acquisition and integration costs | 923 |  |  | 6,890 |  |  | 10,205 |  |  | 25,716 |  |
| Restructuring charge, net of reversals | 9,819 |  |  | 11 |  |  | 9,819 |  |  | 510 |  |
| Amortization of intangibles | 4,467 |  |  | 5,267 |  |  | 17,869 |  |  | 16,711 |  |
| Litigation settlement | — |  |  | — |  |  | — |  |  | (100 | ) |
| Total operating expenses | 89,774 |  |  | 96,361 |  |  | 342,731 |  |  | 317,561 |  |
| Operating loss | (13,447 | ) |  | (13,439 | ) |  | (62,994 | ) |  | (50,232 | ) |
| Interest income | 70 |  |  | 148 |  |  | 541 |  |  | 751 |  |
| Interest expense | (757 | ) |  | (796 | ) |  | (3,177 | ) |  | (2,085 | ) |
| Other expense, net | (174 | ) |  | (217 | ) |  | (1,206 | ) |  | (1,555 | ) |
| Loss before income taxes | (14,308 | ) |  | (14,304 | ) |  | (66,836 | ) |  | (53,121 | ) |
| Provision for income taxes | 1,349 |  |  | 1,927 |  |  | 4,807 |  |  | 4,189 |  |
| Net loss | $ | (15,657 | ) |  | $ | (16,231 | ) |  | $ | (71,643 | ) |  | $ | (57,310 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |
| Net loss per share - basic | $ | (0.16 | ) |  | $ | (0.17 | ) |  | $ | (0.72 | ) |  | $ | (0.60 | ) |
| Net loss per share - diluted | $ | (0.16 | ) |  | $ | (0.17 | ) |  | $ | (0.72 | ) |  | $ | (0.60 | ) |
| Shares used in per share calculation - basic | 100,226 |  |  | 96,713 |  |  | 99,000 |  |  | 95,515 |  |
| Shares used in per share calculation - diluted | 100,226 |  |  | 96,713 |  |  | 99,000 |  |  | 95,515 |  |

[0001078271-15-000093:8k_2_02:47]
EXTREME NETWORKS, INC.

[0001078271-15-000093:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001078271-15-000093:8k_2_02:49]
(In thousands)

[0001078271-15-000093:8k_2_02:50]
(Unaudited)

[0001078271-15-000093:8k_2_02:51]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Net cash provided by (used in) operating activities | $ | 37,423 |  |  | $ | (26,843 | ) |
| Cash flows from investing activities: |  |  |  |
| Capital expenditures | (7,205 | ) |  | (22,373 | ) |
| Acquisition, net of cash acquired | — |  |  | (180,000 | ) |
| Purchases of investments | — |  |  | (9,045 | ) |
| Purchases of non-marketable equity investments | (3,000 | ) |  | — |  |
| Proceeds from maturities of investments and marketable securities | 23,321 |  |  | 28,722 |  |
| Proceeds from sales of investments and marketable securities | 9,051 |  |  | 56,594 |  |
| Purchases of intangible assets | (569 | ) |  | (87 | ) |
| Net cash provided by (used in) investing activities | 21,598 |  |  | (126,189 | ) |
| Cash flows from financing activities: |  |  |  |
| Borrowings under Revolving Facility | 24,000 |  |  | 83,000 |  |
| Issuance of Term Loan | — |  |  | 65,000 |  |
| Repayment of debt | (78,688 | ) |  | (26,437 | ) |
| Proceeds from issuance of common stock | 2,218 |  |  | 8,017 |  |
| Net cash (used in) provided by financing activities | (52,470 | ) |  | 129,580 |  |
| Foreign currency effect on cash | (3,516 | ) |  | 839 |  |
| Net increase (decrease) in cash and cash equivalents | 3,035 |  |  | (22,613 | ) |
| Cash and cash equivalents at beginning of period | 73,190 |  |  | 95,803 |  |
| Cash and cash equivalents at end of period | $ | 76,225 |  |  | $ | 73,190 |  |

[0001078271-15-000093:8k_2_02:52]
Extreme Networks, Inc.

[0001078271-15-000093:8k_2_02:53]
Non-GAAP Measures of Financial Performance

[0001078271-15-000093:8k_2_02:54]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP earnings per diluted share, non-GAAP gross margin, non-GAAP operating expenses and free cash flow.

[0001078271-15-000093:8k_2_02:55]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less stock based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of intangibles, restructuring expenses, litigation settlement and executive transition expenses.

[0001078271-15-000093:8k_2_02:56]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001078271-15-000093:8k_2_02:57]
Extreme Networks believes that these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance shareholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes that the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001078271-15-000093:8k_2_02:58]
For its internal planning process, and as discussed further below, Extreme Networks' management uses financial statements that do not include stock-based compensation expense, acquisition and integration costs, purchase accounting adjustments, amortization of  intangibles, restructuring expenses, litigation settlement and executive transition expenses.  Extreme Networks' management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001078271-15-000093:8k_2_02:59]
As described above, Extreme Networks excludes the following items from one or more of its non-GAAP measures when applicable.

[0001078271-15-000093:8k_2_02:60]
Stock based compensation expense. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its ESPP.  Extreme Networks excludes stock based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur stock-based compensation expenses in future periods.

[0001078271-15-000093:8k_2_02:61]
Acquisition and integration costs. Acquisition and integration costs primarily consist of legal and professional fees, severance costs, and other expenses related to the acquisition and integration of Enterasys Inc.  Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001078271-15-000093:8k_2_02:62]
Amortization of intangibles.  Amortization of intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business.

[0001078271-15-000093:8k_2_02:63]
Purchase accounting adjustments relating to deferred revenue.  Purchase accounting adjustments relating to deferred revenue consists of adjustments to the carrying value of deferred revenue.  We have recorded adjustments to the assumed deferred revenue to reflect only a fulfillment margin and thereby excluding the profit margin and revenue which would have been incurred had Extreme Networks entered into the service contract post-acquisition.

[0001078271-15-000093:8k_2_02:64]
Purchase accounting adjustments relating to inventory.  Purchase accounting adjustments relating to inventory consists of the amortization of the step up value from the valuation of the inventory at fair value in cost of revenues as part of business combination accounting.  Extreme Networks excludes these expenses since they result from an event that is out the ordinary course of continuing operations.

[0001078271-15-000093:8k_2_02:65]
Restructuring expenses. Restructuring expenses primarily consists of cash severance and termination benefits. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations. Extreme Networks expects to incur restructuring expenses in future periods.

[0001078271-15-000093:8k_2_02:66]
Executive transition expenses.  Executive transition expenses consists of severance and termination benefits and acceleration of  share-based compensation expense. The expenses are incurred through execution of pre-established employment contracts with senior executives.  The severance and termination benefits are cash transactions, while the share-based compensation are non-cash expenses the Company does not believe these expenses are reflective of ongoing cash requirements related to its operating results.

[0001078271-15-000093:8k_2_02:67]
Litigation settlement expense.  Litigation settlement income is related to settled legal issues for which the Company received adjustments.  The Company does not believe these are reflective of ongoing cash benefits related to its operating results.

[0001078271-15-000093:8k_2_02:68]
In addition to the non-GAAP measures discussed above, Extreme Networks uses free cash flow as a measure of operating performance.  Free cash flow represents operating cash flows less net purchase of property and equipment on a GAAP basis.  Extreme Networks considers free cash flows to be a liquidity measure that provides useful information to management and investors about the amount of cash generated by the business after the purchases of property and equipment, which can then be used to, among other things, invest in Extreme Networks business, make strategic acquisitions, and strengthen the balance sheet.  A limitation of the utility of free cash flows as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period.

[0001078271-15-000093:8k_2_02:69]
EXTREME NETWORKS, INC.

[0001078271-15-000093:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001078271-15-000093:8k_2_02:71]
GAAP TO NON-GAAP RECONCILIATION

[0001078271-15-000093:8k_2_02:72]
(In thousands, except per share amounts and percentages)

[0001078271-15-000093:8k_2_02:73]
(Unaudited)

[0001078271-15-000093:8k_2_02:74]
| Non-GAAP Revenue | Three Months Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Revenue - GAAP Basis | $ | 149,870 |  |  | $ | 155,293 |  |  | $ | 552,940 |  |  | $ | 519,554 |  |
| Adjustments: |  |  |  |  |  |  |  |
| Purchase accounting adjustments | $ | 766 |  |  | $ | 1,579 |  |  | $ | 3,065 |  |  | $ | 5,256 |  |
| Revenue - Non-GAAP Basis | $ | 150,636 |  |  | $ | 156,872 |  |  | $ | 556,005 |  |  | $ | 524,810 |  |
| Non-GAAP Gross Margin | Three Months Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Gross profit - GAAP Basis | $ | 76,327 |  |  | $ | 82,922 |  |  | $ | 279,737 |  |  | $ | 267,329 |  |
| Gross margin - GAAP Basis percentage | 50.9 | % |  | 53.4 | % |  | 50.6 | % |  | 51.5 | % |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | 496 |  |  | 540 |  |  | 2,135 |  |  | 1,730 |  |
| Purchase accounting adjustments | 766 |  |  | 1,579 |  |  | 3,065 |  |  | 16,383 |  |
| Amortization of intangibles | 4,291 |  |  | 4,292 |  |  | 17,166 |  |  | 11,028 |  |
| Gross profit - Non-GAAP Basis | $ | 81,880 |  |  | $ | 89,333 |  |  | $ | 302,103 |  |  | $ | 296,470 |  |
| Gross margin - Non-GAAP Basis percentage | 54.4 | % |  | 56.9 | % |  | 54.3 | % |  | 56.5 | % |
| Non-GAAP Operating Income | Three Months Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Operating loss - GAAP Basis | $ | (13,447 | ) |  | $ | (13,439 | ) |  | $ | (62,994 | ) |  | $ | (50,232 | ) |
| Operating loss - GAAP Basis percentage | (9.0 | )% |  | (8.7 | )% |  | (11.4 | )% |  | (9.7 | )% |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | 3,470 |  |  | 6,047 |  |  | 17,405 |  |  | 15,922 |  |
| Acquisition and integration costs | 923 |  |  | 6,890 |  |  | 10,205 |  |  | 25,716 |  |
| Restructuring charge, net of reversal | 9,819 |  |  | 11 |  |  | 9,819 |  |  | 510 |  |
| Amortization of intangibles | 8,758 |  |  | 9,559 |  |  | 35,035 |  |  | 27,739 |  |
| Purchase accounting adjustments | 766 |  |  | 1,579 |  |  | 3,065 |  |  | 16,383 |  |
| Litigation settlement income | — |  |  | — |  |  | — |  |  | (100 | ) |
| Executive transition expenses | 1,989 |  |  | 600 |  |  | 1,989 |  |  | 600 |  |
| Total adjustments to GAAP operating income | $ | 25,725 |  |  | $ | 24,686 |  |  | $ | 77,518 |  |  | $ | 86,770 |  |
| Operating income - Non-GAAP Basis | $ | 12,278 |  |  | $ | 11,247 |  |  | $ | 14,524 |  |  | $ | 36,538 |  |
| Operating income - Non-GAAP Basis percentage | 8.2 | % |  | 7.2 | % |  | 2.6 | % |  | 7.0 | % |

[0001078271-15-000093:8k_2_02:75]
| Non-GAAP Net Income | Three Months Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Net loss - GAAP Basis | $ | (15,657 | ) |  | $ | (16,231 | ) |  | $ | (71,643 | ) |  | $ | (57,310 | ) |
| Adjustments: |  |  |  |  |  |  |  |
| Stock based compensation expense | 3,470 |  |  | 6,047 |  |  | 17,405 |  |  | 15,922 |  |
| Acquisition and integration costs | 923 |  |  | 6,890 |  |  | 10,205 |  |  | 25,716 |  |
| Restructuring charge, net of reversal | 9,819 |  |  | 11 |  |  | 9,819 |  |  | 510 |  |
| Amortization of intangibles | 8,758 |  |  | 9,559 |  |  | 35,035 |  |  | 27,739 |  |
| Purchase accounting adjustments | 766 |  |  | 1,579 |  |  | 3,065 |  |  | 16,383 |  |
| Litigation settlement income | — |  |  | — |  |  | — |  |  | (100 | ) |
| Executive transition expenses | 1,989 |  |  | 600 |  |  | 1,989 |  |  | 600 |  |
| Total adjustments to GAAP net income | $ | 25,725 |  |  | $ | 24,686 |  |  | $ | 77,518 |  |  | $ | 86,770 |  |
| Net income - Non-GAAP Basis | $ | 10,068 |  |  | $ | 8,455 |  |  | $ | 5,875 |  |  | $ | 29,460 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Diluted net income per share - Non-GAAP Basis | $ | 0.10 |  |  | $ | 0.09 |  |  | $ | 0.06 |  |  | $ | 0.30 |  |
| Shares used in diluted net income per share calculation | 101,205 |  |  | 99,125 |  |  | 100,802 |  |  | 98,171 |  |
| Free Cash Flow | Three Months Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2015 |  | June 30, 2014 |
| Cash flow provided by (used in) operations | $ | 3,856 |  |  | $ | 3,774 |  |  | $ | 37,423 |  |  | $ | (26,843 | ) |
| Less: PP&E CapEx spending | $ | 1,594 |  |  | $ | 4,988 |  |  | 7,205 |  |  | 22,373 |  |
| Total free cash flow | $ | 2,262 |  |  | $ | (1,214 | ) |  | $ | 30,218 |  |  | $ | (49,216 | ) |
