# EXTR notes — 0001078271-15-000120


## extr:DeferredRevenueRollForwardTableTextBlock

[0001078271-15-000120:notes:1]
The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-15-000120:notes:2]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Balance beginning of period | $ | 89,657 |  |  | $ | 38,003 |  |
| Assumed from acquisition | — |  |  | 35,879 |  |
| New support arrangements | 119,906 |  |  | 113,412 |  |
| Recognition of support revenue | (122,122 | ) |  | (97,637 | ) |
| Balance end of period | 87,441 |  |  | 89,657 |  |
| Less: current portion | 64,210 |  |  | 66,715 |  |
| Non-current deferred revenue | $ | 23,231 |  |  | $ | 22,942 |  |


## extr:ScheduleOfDeferredDistributorsRevenueTableTextBlock

[0001078271-15-000120:notes:3]
The following table summarizes deferred distributors revenue, net of cost of sales to distributors as of June 30, 2015 and 2014, respectively (in thousands):

[0001078271-15-000120:notes:4]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Deferred distributors revenue | $ | 53,366 |  |  | $ | 40,715 |  |
| Deferred cost of sales to distributors | (12,491 | ) |  | (8,723 | ) |
| Total deferred distributors revenue, net of cost of sales to distributors | $ | 40,875 |  |  | $ | 31,992 |  |


## extr:ScheduleOfOtherAccruedLiabilitiesTableTextBlock

[0001078271-15-000120:notes:5]
The following are the components of other accrued liabilities (in thousands):

[0001078271-15-000120:notes:6]
|  | June 30, 2015 |  | June 30, 2014 |
| Accrued general and administrative costs | $ | 1,204 |  |  | $ | 4,018 |  |
| Restructuring | 5,854 |  |  | 322 |  |
| Other accrued liabilities | 25,565 |  |  | 34,017 |  |
| Total | $ | 32,623 |  |  | $ | 38,357 |  |


## extr:SharesReservedForInsuranceTableTextBlock

[0001078271-15-000120:notes:7]
The following are shares reserved for issuance (in thousands):

[0001078271-15-000120:notes:8]
|  | June 30, 2015 |
| 2014 Employee stock purchase plan | 12,000 |  |
| Employee stock options and stock awards outstanding | 15,273 |  |
| Employee stock options and stock awards available for grant | 5,450 |  |
| Total shares reserved for issuance | 32,723 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001078271-15-000120:notes:9]
Advertising

[0001078271-15-000120:notes:10]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001078271-15-000120:notes:11]
The following table is a summary of the allowance for doubtful accounts (in thousands).

[0001078271-15-000120:notes:12]
| Description | Balance atbeginningof period |  | Charges tobad debtexpenses |  | (Deductions) (1) |  | Balance atend ofperiod |
| Year Ended June 30, 2015: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 918 |  |  | 940 |  |  | (542 | ) |  | $ | 1,316 |  |
| Year Ended June 30, 2014: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | 475 |  |  | 468 |  |  | (25 | ) |  | $ | 918 |  |
| Year Ended June 30, 2013: |  |  |  |  |  |  |  |
| Allowance for doubtful accounts | $ | 384 |  |  | $ | 312 |  |  | $ | (221 | ) |  | $ | 475 |  |
| (1) Uncollectible accounts written off, net of recoveries |  |  |  |  |

[0001078271-15-000120:notes:13]
The following table is a summary of our allowance for sales returns (in thousands).

[0001078271-15-000120:notes:14]
| Description | Balance atbeginningof period |  | Additions |  | (Deductions) |  | Balance atend ofperiod |
| Year Ended June 30, 2015: |  |  |  |  |  |  |  |
| Allowance for sales returns | $ | 2,700 |  |  | 3,306 |  |  | (4,926 | ) |  | $ | 1,080 |  |
| Year Ended June 30, 2014: |  |  |  |  |  |  |  |
| Allowance for sales returns | 777 |  |  | 3,063 |  |  | (1,140 | ) |  | $ | 2,700 |  |
| Year Ended June 30, 2013: |  |  |  |  |  |  |  |
| Allowance for sales returns | $ | 1,262 |  |  | $ | 130 |  |  | $ | (615 | ) |  | $ | 777 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001078271-15-000120:notes:15]
The following is a summary of available-for-sale securities (in thousands):

[0001078271-15-000120:notes:16]
|  | AmortizedCost |  | Fair Value |  | UnrealizedHoldingGains |  | UnrealizedHoldingLosses |
| June 30, 2015 |  |  |  |  |  |  |  |
| Money market funds | $ | 4,770 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 4,770 |  |  | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |
| June 30, 2014 |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |
| Classified as: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 567 |  |  | $ | 567 |  |  | $ | — |  |  | $ | — |  |
| Short-term investments | 32,578 |  |  | 32,692 |  |  | 114 |  |  | — |  |
|  | $ | 33,145 |  |  | $ | 33,259 |  |  | $ | 114 |  |  | $ | — |  |

[0001078271-15-000120:notes:17]
The Company did not have any available-for sale investments in debt securities at June 30, 2015.

[0001078271-15-000120:notes:18]
The amortized cost and estimated fair value of available-for-sale investments in debt securities at June 30, 2014, by contractual maturity, were as follows (in thousands):

[0001078271-15-000120:notes:19]
|  | AmortizedCost |  | FairValue |
| Due in 1 year or less | $ | 23,512 |  |  | $ | 23,598 |  |
| Due in 1-2 years | 6,049 |  |  | 6,070 |  |
| Due in 2-5 years | 3,017 |  |  | 3,024 |  |
| Total investments in available for sale debt securities | $ | 32,578 |  |  | $ | 32,692 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001078271-15-000120:notes:20]
Business Combinations

[0001078271-15-000120:notes:21]
On October 31, 2013 (the “Acquisition Date”), the Company completed the acquisition of Enterasys Networks, Inc. ("Enterasys"), a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired. The Company also assumed outstanding options and restricted stock units of Enterasys at the Acquisition Date, all of which were unvested.

[0001078271-15-000120:notes:22]
The acquisition has been accounted for using the acquisition method of accounting. The purchase price allocation as of the Acquisition Date is set forth in the table below and reflects various fair value estimates. These estimates were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists.  All valuations were considered finalized as of September 30, 2014.

[0001078271-15-000120:notes:23]
The following table below summarizes the allocation as of September 30, 2014 of the tangible and identifiable intangible assets acquired and liabilities assumed:

[0001078271-15-000120:notes:24]
|  | September 30, 2014 |
| Cash | $ | 7,397 |  |
| Receivables | 23,271 |  |
| Inventory | 33,662 |  |
| Other current assets | 7,374 |  |
| Property and equipment | 21,293 |  |
| Identifiable intangible assets | 108,900 |  |
| In-process research and development | 3,000 |  |
| Deferred tax assets | 9 |  |
| Other assets | 7,343 |  |
| Goodwill | 70,877 |  |
| Current liabilities | (81,535 | ) |
| Other long-term liabilities | (14,194 | ) |
| Total purchase price allocation | $ | 187,397 |  |
| Less: Cash acquired from acquisition | (7,397 | ) |
| Total purchase price consideration, net of cash acquired | $ | 180,000 |  |

[0001078271-15-000120:notes:25]
There were no adjustments to the allocation of assets acquired or liabilities assumed from June 30, 2014 through the time the Company finalized the allocation as of September 30, 2014.

[0001078271-15-000120:notes:26]
The fair value of the acquired intangible assets were estimated using an income approach.  Under this method, an intangible asset's fair value is equal to the present value of the incremental after-tax cash flows (excess earnings) attributable solely to the intangible asset over its remaining useful life.  To calculate fair value, the Company used cash flows discounted at rates considered appropriate given the inherent risks associated with each type of asset. The Company believes that the level and timing of cash flows appropriately reflect market participant assumptions. Cash flows were assumed to extend through the remaining economic useful life of each class of intangible asset.

[0001078271-15-000120:notes:27]
The fair value of the acquired deferred revenue was estimated using the cost build-up approach.  The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit.  The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay a third party to assume the obligation. The fair value of the deferred revenue obligation is affected most significantly by the estimated costs required to support the obligation, but is also affected by the assumed profit and the discount rate.

[0001078271-15-000120:notes:28]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (in thousands):

[0001078271-15-000120:notes:29]
| Intangible Assets |  | Estimated Useful Life (in years) |  | Amount |
| Developed technology |  | 3 |  | $ | 45,000 |  |
| Customer relationships |  | 3 |  | 37,000 |  |
| Maintenance contracts |  | 5 |  | 17,000 |  |
| Trademarks |  | 3 |  | 2,500 |  |
| Order backlog |  | 1 |  | 7,400 |  |
| Total identifiable intangible assets |  | 3 |  | $ | 108,900 |  |

[0001078271-15-000120:notes:30]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the consolidated statement of operations.  The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Enterasys.  The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001078271-15-000120:notes:31]
The Company had an indefinite-lived asset of $3.0 million as of the Acquisition Date which represents the fair value of in-process research and development activities.  The Company completed the research and development efforts in the fourth quarter of fiscal 2014 and has determined that the asset is an identifiable intangible asset with an estimated useful life of three years.  The results of operations of Enterasys are included in the consolidated results of operations beginning October 31, 2013. For the year ended June 30, 2014, $227.7 million of revenue and $13.5 million of operating income from Enterasys are included in the consolidated statement of operations.  The Company incurred $6.0 million of acquisition-related expenses for the year ended June 30, 2014. Such acquisition-related costs are included in "Acquisition and integration costs" on the consolidated statement of operations.  The costs, which the Company expensed as incurred, consist primarily of professional fees payable to financial and legal advisors.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001078271-15-000120:notes:32]
Description of Business and Basis of Presentation

[0001078271-15-000120:notes:33]
Extreme Networks, Inc. (“Extreme Networks” or “the Company”) is a leading provider of network infrastructure equipment and markets its products primarily to business, governmental, health care, service provider, and educational customers with a focus on large corporate enterprises and metropolitan service providers on a global basis. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme Networks was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001078271-15-000120:notes:34]
Fiscal Year

[0001078271-15-000120:notes:35]
The Company uses a fiscal calendar year ending on June 30.  All references herein to  "fiscal 2015" or "2015"; “fiscal 2014” or “2014”; "fiscal 2013" or "2013" represent the fiscal years ending June 30, 2015,  2014 and 2013, respectively .

[0001078271-15-000120:notes:36]
Principles of Consolidation

[0001078271-15-000120:notes:37]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001078271-15-000120:notes:38]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001078271-15-000120:notes:39]
Certain balances included in the consolidated balance sheets and consolidated statements of cash flows related to deferred income taxes and restructuring liabilities for prior periods have been reclassified to conform to the current period presentation.  Specifically, in the consolidated balance sheet, restructuring liabilities which was presented separately has been included in other accrued liabilities while deferred income taxes, which was part of Other long-term liabilities, is now presented separately.  In the consolidated statement of cash flows, the changes in operating assets and liabilities for Other long-term liabilities includes the changes in restructuring liabilities and other accrued liabilities which were previously disclosed separately.

[0001078271-15-000120:notes:40]
Accounting Estimates

[0001078271-15-000120:notes:41]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Estimates are used for, but are not limited to, the accounting for the allowances for doubtful accounts and sales returns, determining the fair value of acquired assets and assumed liabilities, estimated selling prices, inventory valuation and purchase commitments, depreciation and amortization, impairment of long-lived assets including goodwill, warranty accruals, restructuring liabilities, measurement of share-based compensation costs and income taxes. Actual results could differ materially from these estimates.


## us-gaap:CollaborativeArrangementDisclosureTextBlock

[0001078271-15-000120:notes:42]
Technology Agreements

[0001078271-15-000120:notes:43]
On July 16, 2013, the Company entered into a confidential Patent License and Settlement Agreement (“License Agreement”) with Chrimar Systems Inc. The agreement provides for a non-exclusive, irrevocable, perpetual, non-transferable, and non-assignable, fully-paid-up worldwide royalty-bearing license to certain patents and a release of claims based on any prior infringement of such patents. Total fees for the grant of the license under the License Agreement was $1.4 million. The Company had capitalized $1.2 million related to such patents in fiscal 2012 based on a probable estimated value and recorded a charge of $0.3 million based on the estimated probable loss. The $1.2 million was recorded as intangible assets, net and continues to be amortized over the remaining life of the patents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001078271-15-000120:notes:44]
Commitments, Contingencies and Leases

[0001078271-15-000120:notes:45]
Leases

[0001078271-15-000120:notes:46]
The Company currently leases its current headquarters, research and development facilities and office spaces for its various United States and international operations. Certain leases contain rent escalation clauses and renewal options. As part of the Company’s existing leased facilities, the Company has received lease incentives which take the form of a fixed allowance towards lease improvements on the respective facility. The Company used the allowance to make leasehold improvements which are being depreciated over the useful life of the assets or the lease term, whichever is shorter. The offsetting lease incentives liability is being amortized on a straight-line basis over the term of the lease as an offset to rent expense.

[0001078271-15-000120:notes:47]
Future annual minimum lease payments under all non-cancelable operating leases having initial or remaining lease terms in excess of one year at June 30, 2015 were as follows (in thousands):

[0001078271-15-000120:notes:48]
|  | Future LeasePayments |
| Fiscal 2016 | $10,948 |
| Fiscal 2017 | 9,626 |  |
| Fiscal 2018 | 8,953 |  |
| Fiscal 2019 | 8,652 |  |
| Fiscal 2020 | 8,518 |  |
| Thereafter | 17,720 |  |
| Total minimum payments | $ | 64,417 |  |

[0001078271-15-000120:notes:49]
Rent expense was $11.1 million, $10.2 million and $5.9 million in fiscal years 2015, 2014 and 2013, respectively.

[0001078271-15-000120:notes:50]
Purchase Commitments

[0001078271-15-000120:notes:51]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2015, the Company had non-cancelable commitments to purchase $69.9 million of such inventory, which will be received and consumed during the first half of fiscal 2016.

[0001078271-15-000120:notes:52]
Legal Proceedings

[0001078271-15-000120:notes:53]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001078271-15-000120:notes:54]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001078271-15-000120:notes:55]
Intellectual Property Litigation

[0001078271-15-000120:notes:56]
Net Navigation Systems, LLC

[0001078271-15-000120:notes:57]
On April 23, 2014, Net Navigation Systems, LLC (“Net Navigation”) filed a complaint against Extreme Networks, Inc. in the Eastern District of Texas. In the Complaint, the plaintiff asserts infringement of U.S. Patent No. 6,625,122 (“the ’122 Patent”), entitled “Selection of Data for Network Transmission,” which issued on September 23, 2003. Although somewhat vague, the Complaint identifies the following products as accused of infringing the ‘122 Patent: “Networking products capable of providing priority to different data flows based on bandwidth.” The Complaint also states that Extreme has infringed by “making, selling, and causing its customers to use networking products capable of providing priority to different data flows based on bandwidth, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.” The Complaint also asserts infringement of U.S. Patent No. 6,434,145 (“the ’145 Patent”), entitled “Processing of Network Data by Parallel Processing Channels,” which issued on August 13, 2002.  Again, although somewhat vague, the Complaint states that Extreme has infringed by “making, using, importing, selling, and/or offering for sale in the United States, including within this judicial district, networking products that use parallel processing channels, such as, without limitation, the Black Diamond X8 and the Black Diamond 8000 Series of switches and routers.”  Net Navigation, a non-practicing entity, sought injunctive relief as well as monetary damages, cost, expenses and attorney fees, although the complaint sought no quantified amount.  On April 9, 2015, a confidential settlement agreement was reached between Extreme and Net Navigation (the “Settlement Agreement”). The Settlement Agreement required Extreme pay an immaterial amount in return for IP rights to the Net Navigation portfolio.  The Net Navigation suit against the Company was formally dismissed on April 5, 2015, as required by the Settlement Agreement.

[0001078271-15-000120:notes:58]
Selene Communication Technologies, LLC

[0001078271-15-000120:notes:59]
On April 7, 2014, Selene Communication Technologies, LLC (“Selene”), filed a complaint in the US District Court for the District of Delaware against Extreme and Enterasys asserting a cause of action for infringement of United States Patent No. 7,143,444 (the “444 Patent”). Selene also sued a number of other technology companies including Cisco for infringement of the 444 Patent.  Selene, a non-practicing entity, sought injunctive relief as well as monetary damages, costs, expenses and attorney fees, although the complaint sought no quantified amount. The Company denied the claims.  The Company is a member of RPX Corporation’s (“RPX”) network of clients, who procure patent risk management services from RPX.  On September 30, 2014, RPX signed an agreement on behalf of its members (including Extreme) with Selene to resolve the litigation cases against its members by Selene and to obtain a license for all RPX members to the 444 Patent and its foreign counterparts.  As a result, a release agreement was finalized on November 19, 2014 and the litigation was dismissed in US District court for the District of Delaware on November 20, 2014.

[0001078271-15-000120:notes:60]
Wetro LAN LLC

[0001078271-15-000120:notes:61]
On Mar 23, 2015, Wetro LAN LLC (Wetro), a non-practicing entity, filed a complaint against Extreme in the Eastern District of Texas asserting infringement of United States Patent No. 6,795,918 (the “918 Patent”). Wetro alleges that Extreme “makes, uses, provides, offers for sale, and sells their product entitled Extreme Networks- Altitude 4700 Series Access Points and similarly situated wireless routers” and thereby has infringed the '918 Patent. Wetro filed suit against a number of other technology companies in January and February 2015 for infringement of the "918 patent.

[0001078271-15-000120:notes:62]
On June 29, 2015, RPX signed an agreement on behalf of its members (including Extreme) with Wetro to resolve the litigation cases against its members by Wetro and to obtain a license for all RPX members to the '918 Patent and its foreign counterparts.  As a result, a release agreement between Wetro and Extreme has been executed and the matter was dismissed on August 5, 2015.

[0001078271-15-000120:notes:63]
Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.)

[0001078271-15-000120:notes:64]
On or about April 8, 2015, the Company filed a lawsuit against Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.) (“Seller”) for breach of, and indemnification by Seller under, the purchase agreement, between Seller and Company, for Company’s purchase of Enterasys Networks, Inc. and its subsidiaries (the “Purchase Agreement”).  The complaint alleged numerous claims for indemnification resulting from Seller’s violations of certain clauses in the Purchase Agreement and Seller’s failure to make accurate and proper disclosures as required by the Purchase Agreement.  The Company was compelled to file this action to perfect and preserve the Company’s right to indemnification by Seller under the Purchase Agreement.  Although the Company’s complaint did not quantify the amount being sought, the complaint sought, among other things, monetary damages, costs, expenses and attorney fees in connection with each of the claims (the “Unify Indemnification Suit”).  The Unify Indemnification Suit was settled by the parties on June 18, 2015, providing for Seller to defend Extreme for certain matters under certain conditions.

[0001078271-15-000120:notes:65]
Commonwealth of Kentucky

[0001078271-15-000120:notes:66]
On or about February 3, 2014, a class action lawsuit was filed in the Commonwealth of Kentucky against Enterasys Networks, Inc. and two other defendants. The complaint alleges that Enterasys and its subcontractor, TJL Information Technologies, Inc., d.b.a. Unbridled Information Technologies (“Subcontractor”), violated Kentucky’s wage and hour laws and failed to pay the prevailing wage in violation of the Kentucky State Prevailing Wage Act (the “Act”) on various public works projects for a number of Kentucky government agencies since January 2010. Plaintiffs also allege common law actions for quantum merit and unjust enrichment and they seek monetary damages, costs, expenses and attorney fees, although there was no quantified amount identified. One of the defendants, Integrated Facility Systems, LLC (“IFS”), has filed a cross-claim against Enterasys. The Company denies the claims and has filed answers to both the complaint and cross-claim on April 16, 2014. In addition, Company filed a cross-claim for indemnity against IFS and the Subcontractor. This litigation is in the early stages of discovery.  Furthermore, as set forth above, the Company made a claim for indemnification to Unify U.S. Holdings, Inc. (formerly known as Enterprise Networks Holdings, Inc.) (“Seller”), which claim arises pursuant to the stock purchase agreement between Seller and Extreme in connection with Extreme’s purchase of Enterasys (the “Unify Indemnification Suit”).  The Unify Indemnification Suit was subsequently settled by Extreme and Seller on June 18, 2015. Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular outcome.

[0001078271-15-000120:notes:67]
2002 - 2009 ICMS Tax Assessment Matters

[0001078271-15-000120:notes:68]
The State of Sao Paolo (Brazil) denied Enterasys Networks do Brazil Ltda. the use of certain credits derived from the State of Espirito Santo under the terms of the FUNDAP scheme for the tax years of 2002 through 2009.  Enterasys’ application to resolve the ICMS Tax Assessments at the administrative level of the Sao Paolo Tax Department under the amnesty relief program (Reference No 3.056.963-1) was denied in March, 2014, by the Sao Paolo Tax Administration.  The value of the ICMS tax credits that were disallowed by the Sao Paolo Tax Administration is approximately BR 3,443,914 (or approximately US $1.5 million), plus interest and penalties (that are currently estimated to be approximately US $9.0 million).  On January 10, 2014, Enterasys filed a lawsuit to overturn or reduce the assessment, which lawsuit remains on-going.  As part of this lawsuit, Enterasys made a request for a stay of execution, so that no tax foreclosure can be filed until a final ruling is made and no guarantee needs to be presented.  On or about October 6, 2014, the preliminary injunction was granted with regard to the stay of execution, and in response to an appeal on the guarantee requirement, the appellant court further ruled on or about January 28, 2015 that no cash deposit (or guarantee) need be made by Enterasys.

[0001078271-15-000120:notes:69]
Given the preliminary nature of the lawsuit, it is premature to assess the likelihood of a particular final outcome.  Based on the currently available information, the Company believes the ultimate outcome of this audit will not have material adverse effect on the Company's financial position or overall results of operations.  The range of the potential total tax liability related to these matters is estimated to be from US $0 million to US $9.0 million, of which the Company believes US $4.3 million is the best estimate within the range and has recorded an accrual as of the Acquisition Date of Enterasys as such matter relates to the period before the acquisition.

[0001078271-15-000120:notes:70]
Extreme made a demand on April 11, 2014 for a defense from, and indemnification by, Seller of these 2002-2009 ICMS Tax Assessment matters.  Seller agreed to assume the defense of these 2002-2009 ICMS Tax Assessment Matters on May 20, 2014.  In addition, through the settlement of the Unify Indemnification Suit on June 18, 2015, Seller has agreed to continue to defend Extreme in this matter and to indemnify Extreme for losses related thereto subject to certain conditions.

[0001078271-15-000120:notes:71]
Indemnification Obligations

[0001078271-15-000120:notes:72]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and Delaware and California law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with these matters. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of these claims. The cost to defend the Company and the named individuals could have a material adverse effect on its consolidated financial position, results of operations and cash flows in the future. Recovery of such costs under its directors and officers’ insurance coverage is uncertain. As of June 30, 2015, the Company had no outstanding indemnification claims.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001078271-15-000120:notes:73]
The following table summarizes deferred revenue, net as of June 30, 2015 and 2014, respectively, (in thousands):

[0001078271-15-000120:notes:74]
|  | June 30, 2015 |  | June 30, 2014 |
| Deferred services | $ | 87,441 |  |  | $ | 89,657 |  |
| Deferred product and other revenue | 12,341 |  |  | 8,020 |  |
| Total deferred revenue | 99,782 |  |  | 97,677 |  |
| Less: current portion | 76,551 |  |  | 74,735 |  |
| Non-current deferred revenue, net | $ | 23,231 |  |  | $ | 22,942 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001078271-15-000120:notes:75]
Foreign Exchange Forward Contracts

[0001078271-15-000120:notes:76]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company records all derivatives on the balance sheet as "Other Assets, Net" at fair value. Changes in the fair value of derivatives are recognized in earnings as "Other Income (Expense)". The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges.

[0001078271-15-000120:notes:77]
At June 30, 2015, the Company did not have any derivative instruments outstanding.  At June 30, 2014, forward foreign currency contracts had a notional principal amount of $7.6 million and an immaterial unrealized gain. These contracts have maturities of less than 60 days. Changes in the fair value of these foreign exchange forward contracts are offset largely by re-measurement of the underlying assets and liabilities.

[0001078271-15-000120:notes:78]
Foreign currency transaction gains and losses from operations were a loss of $1.0 million.  $1.5 million and $0.9 million in fiscal years 2015, 2014 and 2013, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001078271-15-000120:notes:79]
Employee Benefit Plans (including Share-based Compensation)

[0001078271-15-000120:notes:80]
As of June 30, 2015, the Company has the following share-based compensation plans:

[0001078271-15-000120:notes:81]
2013 Equity Incentive Plan

[0001078271-15-000120:notes:82]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaces the 2005 Equity Incentive Plan (the "2005 Plan").

[0001078271-15-000120:notes:83]
Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants.  The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees.  The 2013 Plan authorizes the issuance of 9,000,000 shares of the Company’s common stock.  In addition, up to 12,709,153 shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan.  The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted.  Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting.  As of June 30, 2015, total options and awards to acquire 5,308,134 shares were outstanding under the 2013 Plan and 5,449,673 shares are available for grant under the 2013 Plan.  Options granted under this plan have a contractual term of seven years.

[0001078271-15-000120:notes:84]
Enterasys 2013 Stock Plan

[0001078271-15-000120:notes:85]
Pursuant to the acquisition of Enterasys on October 31, 2013, the Company assumed the Enterasys 2013 Stock Plan (the "Enterasys Plan").   As of June 30, 2015, total options and awards to acquire 3,405,182 shares were outstanding under the Enterasys Plan.  Options granted under this plan have a contractual term of seven years.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired in the Enterasys Plan. No future grants may be made from the Enterasys Plan.

[0001078271-15-000120:notes:86]
2005 Equity Incentive Plan

[0001078271-15-000120:notes:87]
The 2005 Plan was adopted by the Company’s Board of Directors on October 20, 2005, and approved by stockholders on December 2, 2005.  The 2005 Plan replaced the Amended 1996 Stock Option Plan (the “1996 Plan”), the 2000 Non-statutory Stock Option Plan and the 2001 Non-statutory Stock Option Plan.  The 2005 Plan includes provisions upon the granting of certain awards defined by the 2005 Plan as Full Value Awards in which the shares available for grant under the 2005 Plan are decremented 1.5 shares for each such award granted.  Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2005 Plan for future issuance as was applied upon granting. Effective November 20, 2013, the 2005 Plan was replaced with the 2013 Plan, and, as of June 30, 2015, total options and awards to acquire 6,425,165 shares were outstanding under the 2005 Plan.  No future grants may be made from the 2005 Plan, however, outstanding options and awards forfeited or canceled may be transferred to the 2013 Plan until December 2, 2015, at which time, no further shares may be transferred.  To date there have been 3,948,781 shares transferred to the 2013 Plan.

[0001078271-15-000120:notes:88]
Amended 1996 Stock Option Plan

[0001078271-15-000120:notes:89]
The 1996 Plan was originally adopted in September 1996, and provided for the grant of options for common stock to eligible participants.  Effective December 2, 2005, the 1996 Plan was terminated, and, as of June 30, 2015, options to acquire 134,313 shares remain outstanding under the 1996 Plan. No future grants may be made from the 1996 Plan.

[0001078271-15-000120:notes:90]
As of June 30, 2015, the Company has the following shares available for issuance from the share-based compensation plans (in thousands):

[0001078271-15-000120:notes:91]
|  | 2005 Plan |  | 2013 Plan |  | Total |
| Shares available at June 30, 2014 | — |  |  | 8,762 |  |  | 8,762 |  |
| Granted | — |  |  | (7,060 | ) |  | (7,060 | ) |
| Canceled | 1,537 |  |  | 2,211 |  |  | 3,748 |  |
| Transferred | (1,537 | ) |  | 1,537 |  |  | — |  |
| Shares available at June 30, 2015 | — |  |  | 5,450 |  |  | 5,450 |  |

[0001078271-15-000120:notes:92]
The following table summarizes stock option activity under all plans:

[0001078271-15-000120:notes:93]
|  | Number ofShares(000’s) |  | Weighted-AverageExercise PricePer Share |  | Weighted-AverageRemainingContractualTerm (years) |  | AggregateIntrinsic Value($ 000’s) |
| Options outstanding at June 30, 2013 | 9,145 |  |  | $ | 3.66 |  |  |  |  |  |
| Granted | 6,347 |  |  | $ | 5.15 |  |  |  |  |  |
| Exercised | (1,792 | ) |  | $ | 3.59 |  |  |  |  |  |
| Canceled | (1,968 | ) |  | $ | 5.01 |  |  |  |  |  |
| Options outstanding at June 30, 2014 | 11,732 |  |  | $ | 4.26 |  |  |  |  |  |
| Granted | 2,176 |  |  | $ | 3.36 |  |  |  |  |  |
| Exercised | (447 | ) |  | $ | 3.12 |  |  |  |  |  |
| Canceled | (2,857 | ) |  | $ | 4.60 |  |  |  |  |  |
| Options outstanding at June 30, 2015 | 10,604 |  |  | $ | 4.03 |  |  | 3.79 |  | $ | 410 |  |
| Exercisable at June 30, 2015 | 6,905 |  |  | $ | 3.95 |  |  | 2.29 |  | $ | 227 |  |
| Vested and expected to vest at June 30, 2015 | 10,159 |  |  | $ | 4.02 |  |  | 3.67 |  | $ | 389 |  |

[0001078271-15-000120:notes:94]
Included in the options granted above for the year ended June 30, 2014 are 4.2 million options, assumed in connection with the acquisition of Enterasys on October 31, 2013, with an exercise price of $5.30.

[0001078271-15-000120:notes:95]
The following table summarizes significant ranges of outstanding and exercisable options at June 30, 2015:

[0001078271-15-000120:notes:96]
| Options Outstanding |  | Options Exercisable |
| Range of Exercise Prices | NumberOutstanding (000’s) |  | Weighted-AverageRemaining Contractual Life |  | Weighted-AverageExercise Price |  | NumberExercisable (000’s) |  | Weighted-AverageExercise Price |
|  |  |  | (In years) |  |  |  |  |  |  |
| $1.69 – $3.03 | 1,368 |  |  | 7.79 |  | $ | 2.39 |  |  | 351 |  |  | $ | 2.04 |  |
| $3.17 – $3.17 | 376 |  |  | 2.98 |  | $ | 2.96 |  |  | 294 |  |  | $ | 2.97 |  |
| $3.25 – $3.53 | 1,649 |  |  | 0.26 |  | $ | 3.17 |  |  | 1,623 |  |  | $ | 3.14 |  |
| $3.54 – $3.87 | 1,128 |  |  | 3.20 |  | $ | 3.41 |  |  | 812 |  |  | $ | 0.38 |  |
| $4.03 – $4.25 | 1,105 |  |  | 3.57 |  | $ | 3.63 |  |  | 809 |  |  | $ | 3.66 |  |
| $4.26 – $5.26 | 1,200 |  |  | 2.24 |  | $ | 4.21 |  |  | 1,065 |  |  | $ | 4.21 |  |
| $5.30 – $5.30 | 559 |  |  | 4.17 |  | $ | 5.04 |  |  | 272 |  |  | $ | 4.86 |  |
| $5.36 – $6.44 | 2,489 |  |  | 4.62 |  | $ | 5.30 |  |  | 1,397 |  |  | $ | 5.30 |  |
| $6.48 – $6.48 | 655 |  |  | 4.32 |  | $ | 5.67 |  |  | 247 |  |  | $ | 5.67 |  |
| $6.96 – $6.96 | 75 |  |  | 5.17 |  | $ | 6.15 |  |  | 34 |  |  | $ | 6.15 |  |
| $1.69 – $6.96 | 10,604 |  |  | 3.79 |  | $ | 4.03 |  |  | 6,905 |  |  | $ | 3.95 |  |

[0001078271-15-000120:notes:97]
The total intrinsic value of options exercised in fiscal years 2015, 2014 and 2013 was $0.4 million, $4.1 million and $1.1 million, respectively. The fair value of options vested in fiscal years 2015, 2014 and 2013 was $1.4 million, $2.9 million and $1.5 million, respectively.

[0001078271-15-000120:notes:98]
Stock Awards

[0001078271-15-000120:notes:99]
Stock awards may be granted under the 2013 Plan on terms approved by the Board of Directors.  Stock awards generally provide for the issuance of restricted stock which vests over a fixed period.  During fiscal 2015, the Company began expensing restricted stock units with market and or performance based conditions to senior executive officers that had been granted during fiscal 2015.  The Company recognizes compensation expense on the awards over the vesting period based on an intrinsic value as of the date of grant.

[0001078271-15-000120:notes:100]
The following table summarizes stock award activity:

[0001078271-15-000120:notes:101]
|  | Number ofShares(000’s) |  | Weighted-Average Grant-Date Fair Value |
| Non-vested stock outstanding at June 30, 2012 | 1,078 |  |  | $ | 2.35 |  |
| Granted | 3,220 |  |  | $ | 3.49 |  |
| Vested | (939 | ) |  | $ | 3.38 |  |
| Canceled | (673 | ) |  | $ | 3.44 |  |
| Non-vested stock outstanding at June 30, 2013 | 2,686 |  |  | $ | 3.09 |  |
| Granted | 5,193 |  |  | $ | 5.50 |  |
| Vested | (1,062 | ) |  | $ | 3.77 |  |
| Canceled | (817 | ) |  | $ | 3.65 |  |
| Non-vested stock outstanding at June 30, 2014 | 6,000 |  |  | $ | 4.98 |  |
| Granted | 3,256 |  |  | $ | 2.89 |  |
| Vested | (2,542 | ) |  | $ | 5.05 |  |
| Canceled | (2,117 | ) |  | $ | 3.96 |  |
| Non-vested stock outstanding at June 30, 2015 | 4,597 |  |  | $ | 3.82 |  |

[0001078271-15-000120:notes:102]
Included in the restricted stock units granted above for the year ended June 30, 2014 are 2.7 million restricted stock units assumed in connection with the acquisition of Enterasys on October 31, 2013, with an acquisition-date fair value of $5.30.

[0001078271-15-000120:notes:103]
2014 Employee Stock Purchase Plan

[0001078271-15-000120:notes:104]
In August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”).  On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12,000,000 shares. The 2014 ESPP replaces the 1999 ESPP.  The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation.  No more than 1,000,000 shares may be issued on any purchase date.  Each purchase period has a maximum duration of 6 months. The 2014 Plan will have offerings periods of 24 months, commonly referred to as "look back periods".  The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.  Through June 30, 2015, there have been no shares issued under the 2014 ESPP.

[0001078271-15-000120:notes:105]
1999 Employee Stock Purchase Plan

[0001078271-15-000120:notes:106]
In January 1999, the Board of Directors approved the adoption of Extreme Network’s 1999 Employee Stock Purchase Plan (the “1999 ESPP”).  On December 2, 2005, the stockholders approved an amendment to the 1999 ESPP to increase the maximum number of shares of common stock that may be issued under the plan by 5,000,000 to a total of 12,000,000 shares.  The 1999 ESPP was replaced by the 2014 ESPP.  The 1999 ESPP allowed eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation. The price at which the common stock could be purchased was 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. Through June 30, 2015, 11,933,618 shares were purchased under the 1999 ESPP.  All remaining shares available under the 1999 Plan have been retired.

[0001078271-15-000120:notes:107]
Share Based Compensation

[0001078271-15-000120:notes:108]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (dollars in thousands):

[0001078271-15-000120:notes:109]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Cost of product revenue | $ | 1,067 |  |  | $ | 836 |  |  | $ | 428 |  |
| Cost of service revenue | 1,068 |  |  | 895 |  |  | 292 |  |
| Research and development | 5,365 |  |  | 4,111 |  |  | 2,461 |  |
| Sales and marketing | 5,170 |  |  | 6,430 |  |  | 1,032 |  |
| General and administrative | 5,131 |  |  | 3,650 |  |  | 3,140 |  |
| Total share-based compensation expense | $ | 17,801 |  |  | $ | 15,922 |  |  | $ | 7,353 |  |

[0001078271-15-000120:notes:110]
During the year ended June 30, 2015, in conjunction with executive transition activity, the Company recognized $0.4 million of expense related to accelerated vesting of stock grants.

[0001078271-15-000120:notes:111]
The amount of stock based compensation expense capitalized in inventory has been immaterial for each of the periods presented. As of June 30, 2015, there was $5.6 million of total unrecognized compensation cost related to unvested stock options. This cost is expected to be recognized over a weighted-average period of approximately 2.2 years.  As of June 30, 2015, there were $11.4 million in unrecognized compensation costs related to non-vested stock awards.  This cost is expected to be recognized over a weighted-average period of approximately 1.8 years

[0001078271-15-000120:notes:112]
The weighted-average grant-date per share fair value of options granted in fiscal years 2015, 2014 and 2013, was $1.75, $2.36 and $1.74, respectively. The weighted-average estimated per share fair value of shares purchased under the 1999 ESPP in fiscal years 2015, 2014 and 2013, was $0.90, $1.64 and $0.88, respectively.

[0001078271-15-000120:notes:113]
The average fair-value and the average derived service period on the grant-date for the performance-based option awards with market conditions, granted in fiscal 2015, was $1.21 and 1.9 years respectively.  The average fair-value and the average derived service period on the grant-date for the performance-based option awards with market conditions, granted in fiscal 2013, was $1.53 and 2.5 years respectively.

[0001078271-15-000120:notes:114]
The Company uses the straight-line method for expense attribution, and the Company estimates forfeitures and only recognizes expense for those shares expected to vest.  The Company’s estimated forfeiture rate in fiscal 2015 based on the Company’s historical forfeiture experience is 12% for non-executives and 14% for executives.

[0001078271-15-000120:notes:115]
The fair value of each stock option grant under the Company's 2013 Plan and 2005 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of grants, with performance and or market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001078271-15-000120:notes:116]
The fair value of each share purchase option under the Company's 2014 ESPP and 1999 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP and the 1999 ESPP represents the term of the offering period of each option.  The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant.  Expected volatility is based on a blended rate of the implied volatilities from traded options and historical volatility on the Company’s stock.

[0001078271-15-000120:notes:117]
|  | Stock Option Plans |  | Employee Stock Purchase Plans |
|  | Year Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Expected life | 4.23 years |  |  | 4.40 years |  |  | 4.58 years |  |  | 0.66 years |  |  | 0.25 years |  |  | 0.25 years |  |
| Risk-free interest rate | 1.17 | % |  | 1.24 | % |  | 0.74 | % |  | 0.10 | % |  | 0.08 | % |  | 0.07 | % |
| Volatility | 50 | % |  | 56 | % |  | 64 | % |  | 59 | % |  | 58 | % |  | 49 | % |
| Dividend yield | 0 | % |  | 0 | % |  | 0 | % |  | 0 | % |  | 0 | % |  | 0 | % |

[0001078271-15-000120:notes:118]
401(k) Plan

[0001078271-15-000120:notes:119]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $18,000 for calendar year 2015. Employees age 50 or over may elect to contribute an additional $6,000. The amount contributed to the Plan is on a pre-tax basis.

[0001078271-15-000120:notes:120]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year.   All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. During the year ended June 30, 2014, eligible employees from Enterasys were also added to the Plan as of the acquisition date.  The program is to match $0.50 for every Dollar contributed by the employee up to the first 2.5% of pay.  The Company’s matching contributions to the Plan totaled $1.1 million, $0.8 million and $0.5 million, for fiscal years 2015, 2014 and 2013, respectively.  No discretionary contributions were made in fiscal years 2015, 2014 or 2013.


## us-gaap:EarningsPerShareTextBlock

[0001078271-15-000120:notes:121]
Net (Loss) Income Per Share

[0001078271-15-000120:notes:122]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to repurchase, options, warrants and unvested restricted stock.  The following table presents the calculation of basic and diluted net (loss) income per share (in thousands, except per share data):

[0001078271-15-000120:notes:123]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Net (loss) income | $ | (71,643 | ) |  | $ | (57,310 | ) |  | $ | 9,673 |  |
| Weighted-average shares used in per share calculation – basic | 99,000 |  |  | 95,515 |  |  | 93,954 |  |
| Incremental shares using the treasury stock method: |  |  |  |  |  |
| Stock options | — |  |  | — |  |  | 385 |  |
| Unvested restricted awards | — |  |  | — |  |  | 600 |  |
| Employee Stock Purchase Plan | — |  |  | — |  |  | 105 |  |
| Weighted -average share used in per share calculation – diluted | 99,000 |  |  | 95,515 |  |  | 95,044 |  |
| Net (loss) income per share – basic | $ | (0.72 | ) |  | $ | (0.60 | ) |  | $ | 0.10 |  |
| Net (loss) income per share – diluted | $ | (0.72 | ) |  | $ | (0.60 | ) |  | $ | 0.10 |  |

[0001078271-15-000120:notes:124]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.  Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net income per share since the effect of including them would have been anti-dilutive due to the net income position of the Company during the periods presented. For fiscal years 2015, 2014, 2013, the Company excluded  7.6 million,  4.1 million and 6.7 million outstanding weighted average stock options and awards, respectively, from the calculation of diluted earnings per common share because they would have been anti-dilutive.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001078271-15-000120:notes:125]
Long-Lived Assets

[0001078271-15-000120:notes:126]
Long-lived assets include (a) property and equipment, (b) goodwill and intangible assets, and (c) other assets.  Property and equipment, goodwill and intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable.  If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets. The Company reduces the carrying value of service inventory to net realizable value based on expected quantities needed to satisfy contractual service requirements of customers.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001078271-15-000120:notes:127]
Income Taxes

[0001078271-15-000120:notes:128]
Income before income taxes is as follows (in thousands):

[0001078271-15-000120:notes:129]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Domestic | $ | (72,176 | ) |  | $ | (70,321 | ) |  | $ | 14,692 |  |
| Foreign | 5,340 |  |  | 17,200 |  |  | (3,341 | ) |
| Total | $ | (66,836 | ) |  | $ | (53,121 | ) |  | $ | 11,351 |  |

[0001078271-15-000120:notes:130]
The provision for income taxes for fiscal years 2015, 2014 and 2013 consisted of the following (in thousands):

[0001078271-15-000120:notes:131]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Current: |  |  |  |  |  |
| Federal | $ | 476 |  |  | $ | 22 |  |  | $ | 225 |  |
| State | 13 |  |  | 329 |  |  | 140 |  |
| Foreign | 2,447 |  |  | 2,987 |  |  | 1,163 |  |
| Total current | 2,936 |  |  | 3,338 |  |  | 1,528 |  |
| Deferred: |  |  |  |  |  |
| Federal | 1,507 |  |  | 1,632 |  |  | 15 |  |
| State | 103 |  |  | 76 |  |  | — |  |
| Foreign | 261 |  |  | (857 | ) |  | 135 |  |
| Total deferred | 1,871 |  |  | 851 |  |  | 150 |  |
| Provision for income taxes | $ | 4,807 |  |  | $ | 4,189 |  |  | $ | 1,678 |  |

[0001078271-15-000120:notes:132]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (35 percent) to income before taxes is explained below (in thousands):

[0001078271-15-000120:notes:133]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Tax at federal statutory rate | $ | (23,392 | ) |  | $ | (18,592 | ) |  | $ | 3,973 |  |
| State income tax, net of federal benefit | 13 |  |  | 329 |  |  | 105 |  |
| Change in valuation allowance | 24,105 |  |  | 20,729 |  |  | (3,687 | ) |
| Foreign earnings taxed at other than U.S. rates | (1,113 | ) |  | (346 | ) |  | 498 |  |
| Deferred compensation | 2,298 |  |  | 348 |  |  | 845 |  |
| Goodwill amortization | 1,690 |  |  | 1,097 |  |  | — |  |
| Other | 1,206 |  |  | 624 |  |  | (56 | ) |
| Provision for income taxes | $ | 4,807 |  |  | $ | 4,189 |  |  | $ | 1,678 |  |

[0001078271-15-000120:notes:134]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001078271-15-000120:notes:135]
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Deferred tax assets: |  |  |  |  |  |
| Net operating loss carry-forwards | $ | 114,151 |  |  | $ | 97,630 |  |  | $ | 85,276 |  |
| Tax credit carry-forwards | 30,824 |  |  | 30,019 |  |  | 28,882 |  |
| Depreciation | — |  |  | 129 |  |  | — |  |
| Intangible amortization | 17,978 |  |  | 6,061 |  |  | — |  |
| Deferred revenue (net) | 7,811 |  |  | 10,540 |  |  | 9,710 |  |
| Warrant amortization | 1,355 |  |  | 2,723 |  |  | 3,991 |  |
| Inventory write-downs | 6,048 |  |  | 3,265 |  |  | 2,759 |  |
| Other allowances and accruals | 8,645 |  |  | 6,380 |  |  | 3,658 |  |
| Stock based compensation | 6,783 |  |  | 6,257 |  |  | 2,973 |  |
| Other | 5,902 |  |  | 10,772 |  |  | 5,741 |  |
| Total deferred tax assets | 199,497 |  |  | 173,776 |  |  | 142,990 |  |
| Valuation allowance | (197,576 | ) |  | (172,475 | ) |  | (142,023 | ) |
| Total net deferred tax assets | 1,921 |  |  | 1,301 |  |  | 967 |  |
| Deferred tax liabilities: |  |  |  |  |  |
| Depreciation | (707 | ) |  | — |  |  | (388 | ) |
| Goodwill amortization | (2,787 | ) |  | (1,097 | ) |  | — |  |
| Brazilian foreign exchange gain | — |  |  | (2,670 | ) |  | — |  |
| Deferred tax liability on foreign withholdings | (194 | ) |  | (167 | ) |  | (134 | ) |
| Total deferred tax liabilities | (3,688 | ) |  | (3,934 | ) |  | (522 | ) |
| Net deferred tax assets (liabilities) | $ | (1,767 | ) |  | $ | (2,633 | ) |  | $ | 445 |  |
| Recorded as: |  |  |  |  |  |
| Net current deferred tax assets | $ | 760 |  |  | $ | 1,058 |  |  | $ | 386 |  |
| Net non-current deferred tax assets | 452 |  |  | 230 |  |  | 294 |  |
| Net current deferred tax liabilities | — |  |  | (2,657 | ) |  | (235 | ) |
| Net non-current deferred tax liabilities | (2,979 | ) |  | (1,264 | ) |  | — |  |
| Net deferred tax assets (liabilities) | $ | (1,767 | ) |  | $ | (2,633 | ) |  | $ | 445 |  |

[0001078271-15-000120:notes:136]
The Company's global valuation allowance increased by $25.1 million in the fiscal year ended June 30, 2015 and $30.5 million in the fiscal year ended June 30, 2014. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against non-U.S. deferred tax assets in Australia, Brazil, Japan and Singapore.  The valuation allowance is determined by assessing both negative and positive available evidence to assess whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of the Company's business provides sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001078271-15-000120:notes:137]
As of June 30, 2015, the Company had net operating loss carry-forwards for U.S. federal and state tax purposes of $330.6 million and $169.6 million, respectively, of which $38.6 million and $36.0 million, respectively, represent deductions from share-based compensation for which a benefit would be recorded in additional paid-in capital when realized. As of June 30, 2015, the Company also had foreign net operating loss carry-forwards in Ireland, Australia, Japan and Singapore of $53.1 million, $9.8 million, $0.3 million, and $1.4 million, respectively.  As of June 30, 2015, the Company also had federal and state tax credit carry-forwards of $20.3 million and $16.2 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits with a small portion representing Alternative Minimum Tax Credits.  The U.S. federal net operating loss carry-forwards of $330.6 million will begin to expire in the fiscal year ending June 30, 2021 and state net operating losses of $169.6 million will begin to expire in the fiscal year ending June 30, 2016, if not utilized. The foreign net operating losses can generally be carried forward indefinitely.  Federal research and development tax credits of $20.3 million will expire beginning in fiscal 2019, if not utilized and foreign tax credits of $7.0 million will expire beginning in fiscal 2021.  North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2024, if not utilized. California state research and development tax credits of $15.3 million do not expire and can be carried forward indefinitely.

[0001078271-15-000120:notes:138]
As of March 31, 2015, the Company performed an Internal Revenue Code section 382 analysis with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2015, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes.

[0001078271-15-000120:notes:139]
As of June 30, 2015, the Company intends to indefinitely reinvest the earnings of approximately $9.3 million of certain foreign corporations. The unrecognized deferred tax liability associated with these earnings is approximately $0.3 million.

[0001078271-15-000120:notes:140]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, Brazil, India, California, New Hampshire and North Carolina.  The Company is not currently under examination by any federal, state or foreign tax authority with respect to income taxes.  The Company recently settled an income tax examination of one of its subsidiaries with the Italian tax authorities.  The tax reserves were adjusted appropriately to reflect this settlement.

[0001078271-15-000120:notes:141]
In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.

[0001078271-15-000120:notes:142]
During the fiscal year ended June 30, 2014, the Company acquired the stock of Enterasys Networks, Inc. and as such they became a wholly owned subsidiary of Extreme Networks.  With respect to this acquisition, the Company made an election under Internal Revenue Code section 338(h)(10) to treat the acquisition as an asset purchase from a tax perspective.  Under this election the tax basis of all assets is effectively reset to that of fair market value and therefore the transaction did not result in the recording of an opening net deferred tax position as the Company's tax basis in the acquired assets equaled its book basis.

[0001078271-15-000120:notes:143]
As of June 30, 2015, the Company had $11.4 million of unrecognized tax benefits.  If fully recognized in the future, there would be no impact to the effective tax rate, and $11.4 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance.  The Company does not reasonably expect the amount of unrealized tax benefits to decrease during the next twelve months.

[0001078271-15-000120:notes:144]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001078271-15-000120:notes:145]
| Balance at June 30, 2012 | $ | 25,746 |  |
| Decrease related to prior year tax positions | (14,966 | ) |
| Increase related to prior year tax positions | 45 |  |
| Increase related to current year tax positions | 270 |  |
| Lapse of statute of limitations | (197 | ) |
| Balance at June 30, 2013 | $ | 10,898 |  |
| Decrease related to prior year tax positions | — |  |
| Increase related to prior year tax positions | 415 |  |
| Increase related to current year tax positions | 464 |  |
| Lapse of statute of limitations | (177 | ) |
| Balance at June 30, 2014 | $ | 11,600 |  |
| Decrease related to prior year tax positions | (225 | ) |
| Increase related to prior year tax positions | 288 |  |
| Increase related to current year tax positions | 254 |  |
| Lapse of statute of limitations | (158 | ) |
| Settlements with tax authorities | (400 | ) |
| Balance at June 30, 2015 | $ | 11,359 |  |

[0001078271-15-000120:notes:146]
Estimated interest and penalties related to the underpayment of income taxes are classified as a component of tax expense in the consolidated statement of operations and totaled less than $0.1 million for each of the fiscal years 2015, 2014 and 2013.  Accrued interest and penalties were less than $0.1 million for each of the fiscal years 2015, 2014 and 2013.


## us-gaap:InventoryPolicyTextBlock

[0001078271-15-000120:notes:147]
The Company values its inventory at lower of cost or market.  Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis.  The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand.  At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.  Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.


## us-gaap:InvestmentPolicyTextBlock

[0001078271-15-000120:notes:148]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Investments with maturities of greater than three months, but less than one year at the balance sheet date are classified as Short-term Investments. Investments with maturities of greater than one year at balance sheet date are classified as Marketable Securities. Except for direct obligations of the United States government, securities issued by agencies of the United States government, and money market funds, the Company diversifies its investments by limiting its holdings with any individual issuer.

[0001078271-15-000120:notes:149]
Investments include available-for-sale investment-grade debt securities that the Company carries at fair value.  The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001078271-15-000120:notes:150]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method.  Realized gains or losses recognized on the sale of investments were not significant for fiscal 2015, 2014 or 2013.  As of June 30, 2015, the Company did not hold any investment securities.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001078271-15-000120:notes:151]
Recently Issued Accounting Pronouncements

[0001078271-15-000120:notes:152]
In May 2014, the FASB, jointly with the International Accounting Standards Board, issued Accounting Standard Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers ("ASU 2014-09"). This ASU's core principle is that a reporting entity will recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In applying this new guidance to contracts within its scope, an entity will: (1) identify the contract(s) with a customer, (2) identify the performance obligation in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, this new guidance will require significantly expanded disclosures about revenue recognition. ASU 2014-09 is effective for annual reporting periods (including interim reporting periods within those annual periods) beginning after December 15, 2016. In July 2015, the FASB approved a one-year deferral of the effective date of the new standard. The new standard will be effective for the Company’s fiscal 2019, with early adoption permitted.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this ASU. The Company is currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.

[0001078271-15-000120:notes:153]
In November 2014, the FASB has issued ASU 2014-15, Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern, which provides guidance on determining when and how to disclose going-concern uncertainties in the financial statements. The new standard requires management to perform interim and annual assessments of an entity’s ability to continue as a going concern within one year of the date of issuance of the entity’s financial statements and provide certain disclosures when there is substantial doubt about the entity’s ability to continue as a going concern. This guidance applies to all entities and is effective for annual periods beginning after December 15, 2015, and interim periods thereafter, with early adoption permitted. The Company does not believe adoption of this standard will have a material impact on its consolidated financial statements.

[0001078271-15-000120:notes:154]
In February 2015, the FASB issued ASU 2015-02 which provides consolidation guidance and changes the way reporting enterprises evaluate consolidation for limited partnerships, investment companies and similar entities, as well as variable interest entities. The ASU is effective for annual and interim periods in fiscal years beginning after December 15, 2015.  The Company does not believe adoption of this standard will have a material impact on its consolidated financial statements.

[0001078271-15-000120:notes:155]
In July 2015, the FASB issued ASU 2015-11, which requires entities to measure most inventory “at the lower of cost and net realizable value,” thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market (market in this context is defined as one of three different measures). The ASU will not apply to inventories that are measured by using either the last-in, first-out ("LIFO") method or the retail inventory method ("RIM").  The ASU is effective prospectively for annual periods beginning after December 15, 2016, and interim periods therein. Early application of the ASU is permitted. Upon transition, entities must disclose the nature of and reason for the accounting change. The Company does not believe adoption of this standard will have a material impact on its consolidated financial statements.

[0001078271-15-000120:notes:156]
In April 2015, the FASB issued ASU 2015-03 - Simplifying the Presentation of Debt Issuance Costs, which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts. ASU 2015-03 requires retrospective adoption and will be effective for annual and interim periods in fiscal years beginning after December 15, 2015.  Early adoption is permitted.  The Company does not believe adoption of this standard will have a material impact on its consolidated financial statements.

[0001078271-15-000120:notes:157]
Recently adopted accounting pronouncements

[0001078271-15-000120:notes:158]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013. The Company adopted this standard prospectively in the first quarter of its fiscal year ending June 30, 2015, its adoption did not have a material impact on the consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001078271-15-000120:notes:159]
Property and Equipment, Net

[0001078271-15-000120:notes:160]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets.  Estimated useful lives of one to four years are used for computer equipment and software.  Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years).


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001078271-15-000120:notes:161]
Property and equipment consist of the following (in thousands):

[0001078271-15-000120:notes:162]
|  | June 30, 2015 |  | June 30, 2014 |
| Computer equipment | $ | 32,753 |  |  | $ | 27,319 |  |
| Purchased software | 5,425 |  |  | 10,859 |  |
| Office equipment, furniture and fixtures | 10,908 |  |  | 28,813 |  |
| Leasehold improvements | 24,293 |  |  | 29,029 |  |
|  | 73,379 |  |  | 96,020 |  |
| Less: accumulated depreciation and amortization | (33,517 | ) |  | (49,466 | ) |
| Property and equipment, net | $ | 39,862 |  |  | $ | 46,554 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001078271-15-000120:notes:163]
Restructuring Charges

[0001078271-15-000120:notes:164]
As of June 30, 2015, restructuring liabilities were $5.9 million and consisted of obligations for termination benefits only. The restructuring liability is recorded in "Other accrued liabilities" in the consolidated balance sheets.  During fiscal years 2015, 2014 and 2013, the Company recorded a restructuring charges, net of $9.8 million, $0.5 million and $6.8 million, respectively.

[0001078271-15-000120:notes:165]
Fiscal 2015 Restructuring

[0001078271-15-000120:notes:166]
During the fourth quarter of fiscal 2015, we reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment.  We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing, as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions.  We have expensed all costs associated with this initiative.  We are expecting to achieve approximately $40.0 million in operational savings on an annualized basis, beginning in the first quarter of fiscal 2016.  As of June 30, 2015, the Company had restructuring liabilities of $5.9 million related to the fiscal 2015 restructuring, which it anticipates paying by the end of the second quarter of fiscal 2016.

[0001078271-15-000120:notes:167]
Fiscal 2013 Restructuring

[0001078271-15-000120:notes:168]
During the second quarter of fiscal 2013, the Company further reduced costs through targeted restructuring activities intended to reduce operating costs and realign its organization in the current competitive environment.  As part of its restructuring efforts in the second quarter, the Company initiated a plan to reduce its worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. There are no outstanding liabilities as of June 30, 2015.

[0001078271-15-000120:notes:169]
Restructuring liabilities consist of (in thousands):

[0001078271-15-000120:notes:170]
|  | ContractTermination |  | TerminationBenefits |  | Other |  | Total |
| Balance at June 30, 2012 | $ | 93 |  |  | $ | 359 |  |  | $ | 11 |  |  | $ | 463 |  |
| Period charges | 113 |  |  | 6,293 |  |  | 719 |  |  | 7,125 |  |
| Period reversals | (2 | ) |  | (287 | ) |  | — |  |  | (289 | ) |
| Period payments | (204 | ) |  | (5,148 | ) |  | (481 | ) |  | (5,833 | ) |
| Balance at June 30, 2013 | $ | — |  |  | $ | 1,217 |  |  | $ | 249 |  |  | $ | 1,466 |  |
| Period charges | 628 |  |  | 119 |  |  | 86 |  |  | 833 |  |
| Period reversals | (11 | ) |  | (309 | ) |  | (4 | ) |  | (324 | ) |
| Addition from acquisition | (20 | ) |  | — |  |  | — |  |  | (20 | ) |
| Period payments | (275 | ) |  | (1,027 | ) |  | (331 | ) |  | (1,633 | ) |
| Balance at June 30, 2014 | $ | 322 |  |  | $ | — |  |  | $ | — |  |  | $ | 322 |  |
| Period charges |  |  | 9,694 |  |  | 125 |  |  | 9,819 |  |
| Period payments | (322 | ) |  | (3,957 | ) |  | (8 | ) |  | (4,287 | ) |
| Balance at June 30, 2015 | $ | — |  |  | $ | 5,737 |  |  | $ | 117 |  |  | $ | 5,854 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001078271-15-000120:notes:171]
Revenue Recognition

[0001078271-15-000120:notes:172]
The Company's revenue is primarily derived from sales of networking products, which are tangible products containing software and non-software components that function together to deliver the tangible product's essential functionality. In addition to tangible products, the Company's sales arrangements may include other deliverables such as standalone software licenses, or service offerings.  For multiple deliverable arrangements, the Company recognizes revenue in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. Software revenue recognition guidance is applied to the sales of the Company's standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-15-000120:notes:173]
Pursuant to the guidance of the accounting standard for multiple deliverable revenue arrangements, when the Company's sales arrangements contain multiple elements, such as products, software licenses, maintenance agreements, or professional services, the Company determines the standalone selling price for each element based on a selling price hierarchy. The application of the multiple deliverable revenue accounting standard does not change the units of accounting for the Company's multiple element arrangements. Under the selling price hierarchy, the selling price for each deliverable is based on the Company's vendor-specific objective evidence (“VSOE”), which is determined by a substantial majority of the Company's historical standalone sales transactions for a product or service falling within a narrow range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used, if available. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, the Company determines its best estimate of standalone selling price (“ESP”) for a product or service and does so by considering several factors including, but not limited to, the 12-month historical median sales price, sales channel, geography, gross margin objective, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, the Company applies management judgment to determine the Company's best estimate of selling price through consultation with and formal approval by the Company's management for all products and services for which neither VSOE nor TPE is available. Generally the standalone selling price of services is determined using VSOE and the standalone selling price of other deliverables is determined by using ESP.  The Company regularly reviews VSOE, TPE and ESP for all of its products and services and maintains internal controls over the establishment and updates of these estimates.

[0001078271-15-000120:notes:174]
Pursuant to the software revenue recognition accounting standard, the Company continues to recognize revenue for software using the residual method for its sale of standalone software products, including optional software upgrades and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the arrangement, the Company recognizes revenue in accordance with the Company's policies for product, software, and service revenue recognition.

[0001078271-15-000120:notes:175]
The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance service contracts, professional services, and training for its products. The Company generally recognizes product revenue from its value-added resellers, non-stocking distributors and end-user customers at the time of shipment, provided that persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and collection of the sales proceeds is reasonably assured. In instances where the criteria for revenue recognition are not met, revenue is deferred until all criteria have been met.  As of June 30, 2015 and 2014, the Company’s total deferred product revenue from customers other than distributors was $6.1 million and $4.1 million, respectively.  As of June 30, 2015 and 2014, the Company’s total deferred revenue for services, primarily from service contracts, was $87.4 million and $89.7 million, respectively. Sales taxes collected from customers are excluded from revenues.

[0001078271-15-000120:notes:176]
The Company sells its products and maintenance service contracts to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The Company defers recognition of revenue on all sales to its stocking distributors until the distributors sell the product, as evidenced by “sales-out” reports that the distributors provide. The Company grants these distributors the right to return a portion of unsold inventory for the purpose of stock rotation and certain price protection rights. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. The Company also provides distributors with credits for changes in selling prices based on competitive conditions, and allows distributors to participate in cooperative marketing programs. The Company maintains estimated accruals and allowances for these exposures based upon the Company's historical experience. In connection with cooperative advertising programs, if the Company does not meet the criteria for recognizing the expense as marketing expense the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001078271-15-000120:notes:177]
The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users. For product sales to non-stocking distributors and value-added resellers, the Company does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Accordingly, the Company recognizes revenue upon transfer of title and risk of loss or damage, generally upon shipment. In connection with cooperative advertising programs and certain price protection rights that may occur under contractual arrangements with its resellers, if the Company does not meet the criteria for recognizing the expense as marketing expense, the costs are recorded as a reduction to revenue in the same period that the related revenue is recorded.

[0001078271-15-000120:notes:178]
Allowance for Sales Returns

[0001078271-15-000120:notes:179]
The Company provides an allowance for sales returns based on its historical returns, analysis of credit memo data and its return policies.  The allowance for sales returns is as a reduction of our accounts receivable. If the historical data that the Company uses to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. The Company estimates and adjusts this allowance at each balance sheet date.


## us-gaap:ScheduleOfCashCashEquivalentsAndShortTermInvestmentsTableTextBlock

[0001078271-15-000120:notes:180]
The following is a summary of Cash and Available-for-Sale Securities (in thousands)

[0001078271-15-000120:notes:181]
|  | June 30 |
|  | 2015 |  | 2014 |
| Cash | $ | 71,455 |  |  | $ | 72,623 |  |
| Cash equivalents | 4,770 |  |  | 567 |  |
| Short-term investments | — |  |  | 32,692 |  |
| Total available-for-sale | $ | 4,770 |  |  | $ | 33,259 |  |
| Total cash and available for sale securities | $ | 76,225 |  |  | $ | 105,882 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001078271-15-000120:notes:182]
The Company's debt is comprised of the following:

[0001078271-15-000120:notes:183]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Current portion of long-term debt: |  |  |  |
| Term Loan | $ | 11,375 |  |  | $ | 5,688 |  |
| Revolving Facility | — |  |  | 24,000 |  |
| Current portion of long-term debt | $ | 11,375 |  |  | $ | 29,688 |  |
| Long-term debt, less current portion: |  |  |  |
| Term Loan | $ | 45,500 |  |  | $ | 56,875 |  |
| Revolving Facility | 10,000 |  |  | 35,000 |  |
| Total long-term debt, less current portion | $ | 55,500 |  |  | $ | 91,875 |  |
| Total debt | $ | 66,875 |  |  | $ | 121,563 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001078271-15-000120:notes:184]
The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis (in thousands):

[0001078271-15-000120:notes:185]
| June 30, 2015 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 4,770 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,770 |  |
| Investment in non-marketable equities | — |  |  | — |  |  | 3,000 |  |  | 3,000 |  |
| Total | $ | 4,770 |  |  | $ | — |  |  | $ | 3,000 |  |  | $ | 7,770 |  |

[0001078271-15-000120:notes:186]
| June 30, 2014 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Money market funds | $ | 567 |  |  | $ | — |  |  | $ | — |  |  | $ | 567 |  |
| Corporate notes/bonds | — |  |  | 32,692 |  |  | — |  |  | 32,692 |  |
| Foreign currency forward contracts | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total | $ | 567 |  |  | $ | 32,713 |  |  | $ | — |  |  | $ | 32,280 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001078271-15-000120:notes:187]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001078271-15-000120:notes:188]
|  | June 30, 2015 |  | June 30, 2014 |
| Balance at beginning of period | $ | 70,877 |  |  | $ | — |  |
| Acquisition of Enterasys (Note 2) | — |  |  | 70,877 |  |
| Balance at end of period | $ | 70,877 |  |  | $ | 70,877 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001078271-15-000120:notes:189]
The following tables summarize the components of gross and net intangible asset balances (in thousands):

[0001078271-15-000120:notes:190]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| June 30, 2015 |  |  |  |  |  |  |  |
| Developed technology | 1.2 years |  | $ | 48,000 |  |  | $ | 28,194 |  |  | $ | 19,806 |  |
| Customer relationships | 1.3 years |  | 37,000 |  |  | 20,556 |  |  | 16,444 |  |
| Maintenance contracts | 3.3 years |  | 17,000 |  |  | 5,667 |  |  | 11,333 |  |
| Trademarks | 1.3 years |  | 2,500 |  |  | 1,389 |  |  | 1,111 |  |
| Order backlog | 0.3 years |  | 7,400 |  |  | 6,967 |  |  | 433 |  |
| License Agreements | 10.2 years |  | 10,924 |  |  | 8,620 |  |  | 2,304 |  |
| Other Intangibles | 3.8 years |  | 2,684 |  |  | 1,983 |  |  | 701 |  |
|  |  |  | $ | 125,508 |  |  | $ | 73,376 |  |  | $ | 52,132 |  |

[0001078271-15-000120:notes:191]
|  | Weighted Average Remaining Amortization Period |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |
| June 30, 2014 |  |  |  |  |  |  |  |
| Developed technology | 2.2 years |  | $ | 48,000 |  |  | $ | 11,028 |  |  | $ | 36,972 |  |
| Customer relationships | 2.3 years |  | 37,000 |  |  | 8,222 |  |  | 28,778 |  |
| Maintenance contracts | 4.3 years |  | 17,000 |  |  | 2,267 |  |  | 14,733 |  |
| Trademarks | 2.3 years |  | 2,500 |  |  | 555 |  |  | 1,945 |  |
| Order backlog | 1.3 years |  | 7,400 |  |  | 5,667 |  |  | 1,733 |  |
| License Agreements | 11.2 years |  | 10,447 |  |  | 8,141 |  |  | 2,306 |  |
| Other Intangibles | 4.8 years |  | 2,547 |  |  | 1,555 |  |  | 992 |  |
|  |  |  | $ | 124,894 |  |  | $ | 37,435 |  |  | $ | 87,459 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001078271-15-000120:notes:192]
The following is a summary of our inventory by category (in thousands).

[0001078271-15-000120:notes:193]
|  | June 30 |
|  | 2015 |  | 2014 |
| Finished goods | $ | 55,301 |  |  | $ | 56,298 |  |
| Raw materials | 2,713 |  |  | 811 |  |
| Total Inventory | $ | 58,014 |  |  | $ | 57,109 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001078271-15-000120:notes:194]
The Company's debt repayment schedule by period is as follows (in thousands):

[0001078271-15-000120:notes:195]
| For the fiscal year ending: |  |
| 2016 | $ | 11,375 |  |
| 2017 | 17,875 |  |
| 2018 | 21,938 |  |
| 2019 | 15,687 |  |
| Total | $ | 66,875 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001078271-15-000120:notes:196]
The following table summarizes the activity related to the Company’s product warranty liability during fiscal years 2015 and 2014:

[0001078271-15-000120:notes:197]
|  | Year ended |
|  | June 30, 2015 |  | June 30, 2014 |
| Balance beginning of period | $ | 7,551 |  |  | $ | 3,296 |  |
| Assumed from acquisition | — |  |  | 3,702 |  |
| New warranties issued | 8,822 |  |  | 6,225 |  |
| Warranty expenditures | (7,697 | ) |  | (5,672 | ) |
| Balance end of period | $ | 8,676 |  |  | $ | 7,551 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001078271-15-000120:notes:198]
The following table sets forth major customers accounting for 10% or more of our net revenue:

[0001078271-15-000120:notes:199]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Tech Data Corporation | 15 | % |  | 11 | % |  | 10 | % |
| Westcon Group Inc. | 15 | % |  | 11 | % |  | 16 | % |
| Scansource, Inc. | * |  | * |  |  | 12 | % |
| * Less than 10% of net revenue |  |  |  |  |  |

[0001078271-15-000120:notes:200]
The following table sets forth major customers accounting for 10% or more of our accounts receivable balance.

[0001078271-15-000120:notes:201]
|  | As of |
|  | June 30, 2015 |  | June 30, 2014 |
| Westcon Group Inc. | 27 | % |  | 19 | % |
| Tech Data Corporation | * |  | 13 | % |
| * Less than 10% of accounts receivable |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001078271-15-000120:notes:202]
The Company attributes revenues to geographic regions based on the customer's ship-to location. Information regarding geographic areas is as follows (in thousands):

[0001078271-15-000120:notes:203]
|  | Year Ended |
| Net Revenues: | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Americas: |  |  |  |  |  |
| United States | $ | 238,748 |  |  | $ | 211,734 |  |  | $ | 101,790 |  |
| Other | 31,931 |  |  | 45,790 |  |  | 33,584 |  |
| Total Americas | 270,679 |  |  | 257,524 |  |  | 135,374 |  |
| EMEA | 223,368 |  |  | 202,555 |  |  | 112,812 |  |
| APAC | 58,893 |  |  | 59,475 |  |  | 51,157 |  |
| Total net revenues | $ | 552,940 |  |  | $ | 519,554 |  |  | $ | 299,343 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001078271-15-000120:notes:204]
The Company's long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001078271-15-000120:notes:205]
|  | Year Ended |
| Long-lived Assets: | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Americas | $ | 87,071 |  |  | $ | 104,447 |  |  | $ | 36,263 |  |
| EMEA | 29,610 |  |  | 45,237 |  |  | — |  |
| APAC | 3,108 |  |  | 4,073 |  |  | — |  |
| Total long-lived assets | $ | 119,789 |  |  | $ | 153,757 |  |  | $ | 36,263 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001078271-15-000120:notes:206]
The estimated future amortization expense to be recorded for each of the next five years is as follows (in thousands):

[0001078271-15-000120:notes:207]
| For the fiscal year ending: |  |
| 2016 | $ | 32,412 |  |
| 2017 | 13,254 |  |
| 2018 | 3,724 |  |
| 2019 | 1,457 |  |
| 2020 | 324 |  |
| Thereafter, | 961 |  |
| Total | $ | 52,132 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001078271-15-000120:notes:208]
Disclosure about Segments of an Enterprise and Geographic Areas

[0001078271-15-000120:notes:209]
We conduct business globally and are primarily managed on a geographic theater basis.  Our chief operating decision maker ("CODM"), who is our CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations, operating results, and plans for levels, components, or types of products or services below the consolidated unit level.

[0001078271-15-000120:notes:210]
Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the CODM with respect to the allocation of resources and performance.

[0001078271-15-000120:notes:211]
The Company operates in one segment, the development and marketing of network infrastructure equipment.  Revenue is attributed to a geographical area based on the location of the customers. The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, South Asia and Japan.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001078271-15-000120:notes:212]
Summary of Significant Accounting Policies

[0001078271-15-000120:notes:213]
Allowance for Doubtful Accounts

[0001078271-15-000120:notes:214]
The Company maintains an allowance for doubtful accounts which reflects its best estimate of potentially uncollectible trade receivables.  The allowance is based on both specific and general reserves.  The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position.  Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience.  The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001078271-15-000120:notes:215]
Concentrations

[0001078271-15-000120:notes:216]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments.  The Company does not invest an amount exceeding 10% of its combined cash or cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.

[0001078271-15-000120:notes:217]
The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001078271-15-000120:notes:218]
Inventory Valuation

[0001078271-15-000120:notes:219]
The Company's inventory balance as of June 30, 2015 and 2014 was $58.0 million and $57.1 million, respectively. The Company values its inventory at lower of cost or market.  Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis.  The Company has established inventory allowances primarily determined by the age of inventory or when conditions exist that suggest that inventory may be in excess of anticipated demand or is obsolete based upon assumptions about future demand.  At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.  Any written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods disclosed.

[0001078271-15-000120:notes:220]
Cash Equivalents, Short-Term Investments and Marketable Securities

[0001078271-15-000120:notes:221]
Available-for-Sale Securities

[0001078271-15-000120:notes:222]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method.  Realized gains or losses recognized on the sale of investments were not significant for fiscal 2015, 2014 or 2013.  As of June 30, 2015, the Company did not hold any investment securities.  As of June 30, 2014, there were two out of 18 investment securities that had unrealized losses for less than 12 months. For investments that were in an unrealized loss position as of June 30, 2014, the Company recorded an other-than-temporary impairment loss of $158,000 during the year ended June 30, 2014.

[0001078271-15-000120:notes:223]
Fair Value of Financial Instruments

[0001078271-15-000120:notes:224]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3).  The three levels are defined as follows:

[0001078271-15-000120:notes:225]
| • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001078271-15-000120:notes:226]
| • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001078271-15-000120:notes:227]
| • | Level 3 Inputs - unobservable inputs reflecting the Company's own assumptions in measuring the asset or liability at fair value. |

[0001078271-15-000120:notes:228]
The Company did not hold any financial liabilities that required measurement at fair value on a recurring basis.  The following table presents the Company’s fair value hierarchy for its financial assets measured at fair value on a recurring basis (in thousands):

[0001078271-15-000120:notes:229]
Level 2 investments: the Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2.  There were no transfers of assets or liabilities between Level 1 and Level 2 during the fiscal years 2015 or 2014.

[0001078271-15-000120:notes:230]
The fair value of the borrowings under the credit facility is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  The carrying amount and estimated fair value of the Company’s total long-term indebtedness, including current portion was $66.9 million and $121.6 million as of June 30, 2015 and 2014, respectively.

[0001078271-15-000120:notes:231]
Level 3 investments: the Company reflects a non-marketable equity investment as Level 3 in the fair value hierarchy as it is based on unobservable inputs that market participants would use in pricing this asset due to the absence of recent comparable market transactions and inherent lack of liquidity. During the third quarter of fiscal 2015, the Company obtained a $3.0 million equity interest in a company that operates in the enterprise software platform industry.  The Company has not entered into any other transactions with the entity that are considered significant to the Company’s consolidated financial statements.

[0001078271-15-000120:notes:232]
Significant inputs and assumptions were used in management’s estimate of the enterprise value used to calculate the present value of the asset. Significant changes in any Level 3 input or assumption would result in increases or decreases to fair value measurements for this asset.

[0001078271-15-000120:notes:233]
There were no transfers of assets or liabilities between Level 3 and either Level 1 or Level 2 during the fiscal years 2015 or 2014.

[0001078271-15-000120:notes:234]
Certain of the Company's assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.  There were no impairments recorded for the fiscal years 2015 or 2014.

[0001078271-15-000120:notes:235]
(a) Property and Equipment, Net

[0001078271-15-000120:notes:236]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets.  Estimated useful lives of one to four years are used for computer equipment and software.  Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years). Property and equipment consist of the following (in thousands):

[0001078271-15-000120:notes:237]
During the year ended June 30, 2014, there was an increase in property and equipment of $1.2 million for asset retirement obligations recorded from the acquisition of Enterasys.

[0001078271-15-000120:notes:238]
(b) Goodwill and Intangibles

[0001078271-15-000120:notes:239]
As part of the acquisition of Enterasys, the Company acquired $70.9 million in goodwill which has been allocated to the Company's only reportable segment, the development and marketing of network infrastructure equipment.

[0001078271-15-000120:notes:240]
Amortization expense was $35.9 million, $28.8 million and $1.5 million in fiscal years 2015, 2014 and 2013, respectively.  Of the total amount recognized, $17.2 million, $11.9 million and $1.5 million is included in "Cost of revenues for products" on the consolidated statements of operations in fiscal years 2015,  2014 and 2013, respectively, while the remainder of the amortization expense is included in "Amortization of intangibles" on the consolidated statement of operations.  The amortization expense for developed technology, patents, license agreements and other intangibles is recognized in "Cost of revenues for products" on the consolidated statement of operations. The estimated future amortization expense to be recorded for each of the next five years is as follows (in thousands):

[0001078271-15-000120:notes:241]
(c) Other Assets

[0001078271-15-000120:notes:242]
Other assets primarily consists of service inventory and long term deposits. The Company holds service inventory to support customers who have purchased service contracts with a hardware replacement element, as well as to support our warranty program. See Inventory Valuation above in this footnote for additional information. The Company held service inventory of $18.1 million and $11.4 million as of June 30, 2015 and 2014, respectively.

[0001078271-15-000120:notes:243]
Deferred Revenue, Net

[0001078271-15-000120:notes:244]
Deferred revenue, net represents amounts for (i) deferred services revenue (support arrangements, professional services and training), and (ii) deferred product revenue net of the related cost of revenue when the revenue recognition criteria have not been met.  The following table summarizes deferred revenue, net as of June 30, 2015 and 2014, respectively, (in thousands):

[0001078271-15-000120:notes:245]
The Company offers for sale to its customers, renewable support arrangements, including extended warranty contracts that range generally from one to five years. Deferred support revenue is included within deferred revenue, net within the services category above. The change in the Company’s deferred support revenue balance in relation to these arrangements was as follows (in thousands):

[0001078271-15-000120:notes:246]
Deferred Distributors Revenue, Net of Cost of Sales to Distributors

[0001078271-15-000120:notes:247]
At the time of shipment to distributors, the Company records a trade receivable at the contractual discount to list selling price since there is a legally enforceable obligation from the distributor to pay on a current basis for product delivered.  The Company relieves inventory for the carrying value of goods shipped since legal title has passed to the distributor, and the Company records deferred revenue and deferred cost of sales in “Deferred distributors revenue, net of cost of sales to distributors” in the liability section of its consolidated balance sheets.  Deferred distributors revenue, net of cost of sales to distributors effectively represents the gross margin on the sale to the distributor; however, the amount of gross margin the Company recognizes in future periods will frequently be less than the originally recorded deferred distributors revenue, net of cost of sales to distributors as a result of price concessions negotiated at time of sell-through to end customers.  The Company sells each item in its product catalog to all of its distributors worldwide at contractually discounted prices.  However, distributors resell the Company’s products to end customers at a very broad range of individually negotiated price points based on customer, product, quantity, geography, and other competitive conditions which results in the Company remitting back to the distributors a portion of their original purchase price after the resale transaction is completed.  Thus, a portion of the deferred revenue balance represents a portion of distributors’ original purchase price that will be remitted back to the distributors in the future.  The wide range and variability of negotiated price credits granted to distributors does not allow the Company to accurately estimate the portion of the balance in the deferred revenue that will be remitted to the distributors.  Therefore, the Company does not reduce deferred revenue by anticipated future price credits; instead, price credits are recorded against revenue when incurred, which is generally at the time the distributor sells the product.

[0001078271-15-000120:notes:248]
Debt

[0001078271-15-000120:notes:249]
On October 31, 2013, the Company entered into a credit agreement which provides for a $60 million five-year Revolving Facility and a $65 million five-year Term Loan (together the “Senior Secured Credit Facilities”).  The Company used the proceeds from the Term Loan and also drew $35 million of the Revolving Facility for the purchase of all of the issued and outstanding capital stock of Enterasys.

[0001078271-15-000120:notes:250]
In the fourth quarter of fiscal 2015, the Company amended the Senior Secured Credit Facilities.  The amendment, among other items, reduced the lenders commitment by $10.0 million to a total of $115.0 million.  The amended commitment provides for a $50 million five-year Revolving Facility.  Borrowings under the Senior Secured Credit Facilities, as amended, bear interest, at the Company's election, at a rate per annum equal to an agreed to applicable margin plus (a) the higher of the prime rate in effect on such day or the federal funds effective rate in effect on such day plus 0.75% or (b) an adjusted Libor rate.  In addition, the Company is required to pay a commitment fee of between 0.375% and 0.50% quarterly (currently 0.50%) on the unused portion of the Revolving Facility, also based on the Company’s Consolidated Leverage Ratio.  Principal installments are payable on the Term Loan in varying percentages quarterly starting December 31, 2013 and to the extent not previously paid, all outstanding balances are to be paid at maturity. If not repaid before maturity, the draws on the Revolving Facility shall be repaid on the original maturity date. The Senior Secured Credit Facilities, as amended, are secured by substantially all of the Company’s assets and are jointly and severally guaranteed by the Company and certain of its subsidiaries.

[0001078271-15-000120:notes:251]
The Senior Secured Credit Facilities, as amended contain financial covenants that require the Company to maintain a minimum Consolidated Fixed Charge Coverage Ratio and a Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio as well as several other financial and non-financial covenants and restrictions that limit the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets, etc.  These covenants, which are described more fully in the Senior Secured Credit Facilities, as amended, (incorporated herein by reference on Form 8-K) to which reference is made for a complete statement of the covenants, are subject to certain exceptions. The Company is in compliance with its covenants.

[0001078271-15-000120:notes:252]
The Senior Secured Credit Facilities, as amended, also includes customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by the Company is false or misleading in any material respect, certain insolvency or receivership events affecting the Company and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of the Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended, may be accelerated upon certain events of default.

[0001078271-15-000120:notes:253]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  The Company incurred $1.3 million of financing costs related to the initial Senior Secured Credit Facilities during the year ended June 30, 2014.  During the year ended June 30, 2015, in conjunction with the amending of the Senior Secured Credit Facilities noted above, the Company incurred an additional $0.5 million of costs.  Amortization of deferred financing costs is included in "Interest expense" in the consolidated statements of operations, totaled $0.4 million and $0.2 million in fiscal years 2015 and 2014, respectively.

[0001078271-15-000120:notes:254]
The Company had $0.9 million of outstanding letters of credit as of June 30, 2015 and 2014.

[0001078271-15-000120:notes:255]
Guarantees and Product Warranties

[0001078271-15-000120:notes:256]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. In the past, we had experienced such errors in connection with products and product updates.  The Company’s standard hardware warranty period is typically 12 months from the date of shipment to end-users and 90 days for software. For certain access products, the Company offers a limited lifetime hardware warranty commencing on the date of shipment from the Company and ending five (5) years following the Company’s announcement of the end of sale of such product. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrue a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001078271-15-000120:notes:257]
Upon issuance of a standard product warranty, the Company discloses and recognizes a liability for the obligations it assumes under the product warranty.  The following table summarizes the activity related to the Company’s product warranty liability during fiscal years 2015 and 2014:

[0001078271-15-000120:notes:258]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001078271-15-000120:notes:259]
Other Accrued Liabilities

[0001078271-15-000120:notes:260]
Cooperative advertising expenses are recorded as marketing expenses to the extent that an advertising benefit separate from the revenue transaction can be identified and the cash paid does not exceed the fair value of that advertising benefit received. Cooperative advertising obligations with customers are accrued and the costs expensed at the time the related revenue is recognized. If the Company does not meet the criteria for recognizing such cooperative advertising obligations as marketing expense, the costs are recorded as a reduction of revenue.  All other advertising costs are expensed as incurred.  Advertising expenses were $0.5 million, $0.5 million and $0.2 million in fiscal years 2015, 2014 and 2013, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001078271-15-000120:notes:261]
Stockholders’ Equity

[0001078271-15-000120:notes:262]
Preferred Stock

[0001078271-15-000120:notes:263]
In April 2001, in connection with the entering into of the Company's Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2015, no shares of preferred stock were outstanding.

[0001078271-15-000120:notes:264]
Stockholders’ Rights Agreement

[0001078271-15-000120:notes:265]
On November 27, 2012, the Company's Board of Directors adopted an Amended and Restated Rights Agreement (the “Restated Rights Plan”), between Extreme Networks and Computershare Inc. (Successor-in-interest to Computershare Shareholder Services LLC) as the rights agent (the “Rights Agent”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of Series A Preferred Stock of Extreme Networks. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as amended on June 30, 2010 and April 26, 2011 between Extreme Networks and Mellon Investor Services LLC (the “Prior Rights Plan”). The Board reviewed the necessity of the provision of the Prior Rights Plan adopted to preserve the value of Extreme Networks' deferred tax assets, including its net operating loss carry forwards, with respect to its ability to fully use its tax benefits to offset future income may be limited if it experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of Extreme Networks' common stock.  Following its review, the Board decided it was necessary and in the best interests of Extreme Networks and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  The Company's stockholders voted to extend the term of the Restated Rights Plan from April 30, 2013 to April 30, 2014 at our 2012 Annual Meeting of Stockholders, and the Restated Rights Plan was amended effective April 30, 2013 to reflect the extension of the term.  The Board of Directors have unanimously approved an amendment to the Rights Plan effective April 30, 2014 to extend the Rights Plan through May 31, 2015, subject to ratification by a majority of the stockholders at the next annual meeting of the stockholders on November 12, 2014.  The Board of Directors have unanimously approved an amendment to the Rights Plan effective May 14, 2015 to extend the Rights Plan through May 31, 2016, subject to ratification by a majority of the stockholders at the next annual meeting of the stockholders expected to be held on November 12, 2015.

[0001078271-15-000120:notes:266]
Shares Reserved for Issuance


## us-gaap:TreasuryStockTextBlock

[0001078271-15-000120:notes:267]
Common Stock Repurchases and Retirement

[0001078271-15-000120:notes:268]
Retirement of Treasury Stock

[0001078271-15-000120:notes:269]
On September 5, 2012, the Company retired 39,631,836 shares of treasury stock. The retired shares had a carrying value of $149.7 million, and the Company reduced additional paid-in capital by $149.7 million upon the formal retirement of the shares. The retired shares are now included in the Company's authorized but unissued shares.

[0001078271-15-000120:notes:270]
Common Stock Repurchases

[0001078271-15-000120:notes:271]
On September 28, 2012, the Company's Board of Directors approved a share repurchase program for a maximum of $75 million which may be purchased over a three year period in the open market or in privately negotiated transactions.  All repurchased shares will be retired and included in the Company's authorized but unissued shares. During the year ended June 30, 2013, the Company repurchased 4.1 million shares of common stock at a total cost of $14.5 million.  No shares were repurchased during the years ended June 30, 2015 or 2014.
