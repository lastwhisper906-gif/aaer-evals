# EXTR MD&A — 0001078271-15-000120


## mdna

[0001078271-15-000120:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001078271-15-000120:mdna:2]
Business Overview

[0001078271-15-000120:mdna:3]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal year ended June 30, 2015.

[0001078271-15-000120:mdna:4]
We are a leading provider of network infrastructure equipment and offer related services contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996, and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. Substantially all of our revenue is derived from the sale of our networking equipment and related service contracts.

[0001078271-15-000120:mdna:5]
On June 26, 2015, the Senior Secured Credit Facilities were amended and reduced to $115 million from $125 million, with the Revolving Facility being reduced to $50 million from $60 million. The Senior Secured Credit Facilities, as amended, mature on October 31, 2018.

[0001078271-15-000120:mdna:6]
During the fourth quarter of fiscal 2015, we implemented a plan to reduce costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions.  We expect to reduce our operating expenses by approximately $40 million on an annualized basis due to these actions.

[0001078271-15-000120:mdna:7]
On October 31, 2013, we completed the acquisition of Enterasys, a privately held provider of wired and wireless network infrastructure and security solutions, for $180.0 million, net of cash acquired, whereby Enterasys became our wholly-owned subsidiary. The combined entity immediately became a networking industry leader with more than 14,000 customers.  As a combined Company, we believe we will set the standard for the networking industry with a strategic focus on three principles:

[0001078271-15-000120:mdna:8]
| • | Highly scaled and differentiated products and solutions: Our combined product portfolio spans data center networking, switching and routing, Software-Defined Networking ("SDN"), wired and wireless LAN access, network management with analytics and integrated security features. This broader solutions portfolio can be leveraged to better serve existing and new customers. We will continue to enhance and support the product roadmaps of both companies going forward to protect the investments of customers and avoid any disruption to their businesses. We intend to increase research and development to accelerate our vision for high-performance, modular, open networking. |

[0001078271-15-000120:mdna:9]
| • | Leading customer service and support: We are working to augment our current outsourced support model by integrating Enterasys' in-sourced expertise, building on Enterasys' award-winning heritage and strong commitment to exceptional customer experience. The Company's expanded global network of channel partners and distributors will benefit from expanded services and support capabilities. |

[0001078271-15-000120:mdna:10]
| • | Strong Channels and Strategic Partners: Our focus is to leverage the capabilities of the combined Company and expand existing partnerships with Ericsson, as well as continue to add new strategic partnerships in the future. Additionally, we will increase our focus on partnering with distributors and channel partners globally. The goal is to develop and enhance relationships that grow revenue and profits for the Company and our alliance and channel partners. At the same time, we are investing in infrastructure to make doing business with the Company easier and more efficient. |

[0001078271-15-000120:mdna:11]
Impact of the Global Economic Developments

[0001078271-15-000120:mdna:12]
We believe that the slow economic recovery in the United States, Asia and Europe, and other challenges affecting global economic conditions placed significant limitations on our financial performance. We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. Sales in APAC and some European countries were most impacted as a result of the soft global economy. We believe that conservative purchasing patterns and delays or cancellation of IT infrastructure plans in the face of continued uncertainty regarding the global economy, may continue to negatively impact overall demand for networking solutions, including Ethernet equipment.

[0001078271-15-000120:mdna:13]
We have taken, and plan to continue to take, other steps to manage our business in the current economic environment. For example, we have managed from time to time our contingent work force, consolidation of office locations, reduced travel and other discretionary spending, realigned our product portfolio and organization to grow revenue and operating income, and controlled all hiring activities.

[0001078271-15-000120:mdna:14]
Increasing Demand for Bandwidth

[0001078271-15-000120:mdna:15]
We believe that the continued increase in demand for bandwidth will, over time, drive future demand for high performance Ethernet solutions. Wide-spread adoption of electronic communications in all aspects of our lives, proliferation of next generation converged mobile devices and deployment of triple-play services to residences and businesses alike, continues to generate demand

[0001078271-15-000120:mdna:16]
for greater network performance across broader geographic locations. In parallel to these transformational forces within society and the community at large, the accelerating adoption of internet and intranet “cloud” solutions within business enterprises is enabling organizations to offer greater business scalability to improve efficiency and through more effective operations, improve profitability. In order to realize the benefits of these developments, customers require additional bandwidth and high performance from their network infrastructure at affordable prices. We are seeing the initial indications that the Ethernet segment of the networking equipment market will return to growth as enterprise, data center and carrier customers continue to recognize the performance and operating cost benefits of Ethernet technology.

[0001078271-15-000120:mdna:17]
Expanding Product Portfolio

[0001078271-15-000120:mdna:18]
We believe that continued success in our marketplace is dependent upon a variety of factors that includes, but is not limited to, our ability to design, develop and distribute new and enhanced products employing leading-edge technology. New software and hardware introductions during the current year included a Summit X770 switch supporting industry's highest density performing top of rack switching, Purview - a network-powered application analytics and optimization solution, identiFi 38xx WiFi Access Points supporting 802.11ac, SDN 2.0 - an open, standards-based (based on OpenDaylight) and comprehensive SDN solution, 100GbE support for the BDX8 and NetSight 6.0 a consolidated management across the expanded portfolio.  During fiscal 2014, we also introduced key software functionality that will drive differentiation.  Over the past few years, we further extended our product portfolio through the Summit family of stackable switches for the intelligent edge, continued evolutions of our BlackDiamond BDX8, a highly-scalable core switch for IT and cloud data centers,  the S-series flow-based switching for campus and data center, the identiFi Wi-Fi product portfolio with both indoor and outdoor 802.11a/b/g/n/ac access points, the E4G Cell Site Router family for mobile backhaul, and a revamp of our software and network management solutions that include: NetSight for centralized network management and NAC/Mobile-IAM that provides BYOD management and network access control solution for wired and wireless LAN and VPN users.​

[0001078271-15-000120:mdna:19]
Industry Developments

[0001078271-15-000120:mdna:20]
The market for network infrastructure equipment is highly competitive and dominated by a few large companies. The current economic climate has further driven consolidation of vendors within the Ethernet networking market and with vendors from adjacent markets, including storage, security, wireless and voice applications. We believe that the underpinning technology for all of these adjacent markets is Ethernet. As a result, independent Ethernet switch vendors are being acquired or merged with larger, adjacent market vendors to enable them to deliver complete and broad solutions.  As an independent Ethernet switch vendor, we must provide products that, when combined with the products of our large strategic partners, create compelling solutions for end-user customers. Our acquisition of Enterasys gives us a larger market share and presence and an opportunity to create complementary solutions for our customers. Our approach is to focus on the intelligence and automation layer that spans our hardware products and that facilitates end-to-end solutions, as opposed to positioning Extreme Networks as a low-cost-vendor with point products. Lower overall market growth has also created an environment of declining margins due to increased competition between the remaining vendors in this space. During the last year, overall Ethernet port counts have grown, while industry revenues have decreased, signaling a decline in average selling price per port. Our product life cycle and operational cost reduction efforts are therefore even more critical for margin preservation.

[0001078271-15-000120:mdna:21]
Amendment to Rights Agreement

[0001078271-15-000120:mdna:22]
On November 27, 2012, our Board of Directors adopted an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of our Series A Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as amended on June 30, 2010; April 26, 2011, between us and Mellon Investor Services LLC (the “Prior Rights Plan”).

[0001078271-15-000120:mdna:23]
The Board reviewed the necessity of the provisions of the Prior Rights Plan. The Prior Rights Plan was adopted to preserve the value of our deferred tax assets, including our net operating loss carry forwards, with respect to our ability to fully use its tax benefits to offset future income which may be limited if we experience an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of our common stock. Following its review, the Board decided it was necessary and in the best interests of us and our stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Our stockholders voted to extend the term of the Restated Rights Plan from April 30, 2013 to April 30, 2014 at our 2012 Annual Meeting of Stockholders, and the Restated Rights Plan was amended effective April 30, 2013 to reflect the extension of the term.  The Board of Directors unanimously approved an amendment to the Rights Plan effective May 14, 2015 to extend the Rights Plan through May 31, 2016, subject to ratification by a majority of the stockholders at the next annual meeting, expected to be held on November 12, 2015.

[0001078271-15-000120:mdna:24]
Results of Operations

[0001078271-15-000120:mdna:25]
Our operations and financial performance have been affected by the economic factors described above and our acquisition of Enterasys, and during fiscal 2015, we achieved the following results:

[0001078271-15-000120:mdna:26]
| • | Net revenue of $552.9 million, an increase of 6.4% from fiscal 2014 net revenue of $519.6 million. |

[0001078271-15-000120:mdna:27]
| • | Product revenue of $418.0 million, an increase of 1.5% from fiscal 2014 product revenue of $411.8 million. |

[0001078271-15-000120:mdna:28]
| • | Service revenue of $134.9 million, an increase of 25.1% from fiscal 2014 service revenue of $107.8 million. |

[0001078271-15-000120:mdna:29]
| • | Total gross margin of 50.6% of net revenue in fiscal 2015, compared to 51.5% in fiscal 2014. |

[0001078271-15-000120:mdna:30]
| • | Restructuring charge of $9.8 million, for termination and related benefits. |

[0001078271-15-000120:mdna:31]
| • | Operating loss of $63.0 million, an increase in the operating loss of $12.8 million from fiscal 2014. |

[0001078271-15-000120:mdna:32]
| • | Net loss was $71.6 million in fiscal 2015, an increase of $14.3 million from a net loss of $57.3 million in fiscal 2014. |

[0001078271-15-000120:mdna:33]
| • | Cash flow provided by operating activities was $37.4 million, compared to cash flow used in operating activities of $26.8 million in fiscal 2014, an increase of $64.3 million. Cash and cash equivalents were $76.2 million as of June 30, 2015, an increase of $3.0 million from fiscal 2014. |

[0001078271-15-000120:mdna:34]
Net Revenue

[0001078271-15-000120:mdna:35]
The following table presents net product and service revenue for the fiscal years 2015, 2014 and 2013 (dollars in thousands):

[0001078271-15-000120:mdna:36]
|  |  |  | Year Ended |  |  |  | Year Ended |  |  |  |
|  | June 30, 2015 |  | June 30, 2014 |  | $Change |  | %Change |  | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 418,046 |  |  | $ | 411,761 |  |  | $ | 6,285 |  |  | 1.5 | % |  | $ | 411,761 |  |  | $ | 239,955 |  |  | $ | 171,806 |  |  | 71.6 | % |
| Percentage of net revenue | 75.6 | % |  | 79.3 | % |  |  |  |  |  | 79.3 | % |  | 80.2 | % |  |  |  |  |
| Service | 134,894 |  |  | 107,793 |  |  | 27,101 |  |  | 25.1 | % |  | 107,793 |  |  | 59,388 |  |  | 48,405 |  |  | 81.5 | % |
| Percentage of net revenue | 24.4 | % |  | 20.7 | % |  |  |  |  |  | 20.7 | % |  | 19.8 | % |  |  |  |  |
| Total net revenue | $ | 552,940 |  |  | $ | 519,554 |  |  | $ | 33,386 |  |  | 6.4 | % |  | $ | 519,554 |  |  | $ | 299,343 |  |  | $ | 220,211 |  |  | 73.6 | % |

[0001078271-15-000120:mdna:37]
Product revenue increased $6.3 million or 1.5% for the year-ended June 30, 2015, compared to the corresponding period of fiscal 2014.  The fiscal 2015 period reflects increased product shipments and customers as a result of our acquisition of Enterasys, whereas the fiscal 2014 period only reflects eight months of sales subsequent to the October 31, 2013 acquisition date.  However, the increase in sales was partially offset by declines of customer spending across each geographical region and an increase in customer discounts.  The decline in customer spending was partially due to the significant strengthening of the United States Dollar in all geographical areas and the entrance of competitors in regions where we have a strong presence, specifically in Asia Pacific and EMEA regions.

[0001078271-15-000120:mdna:38]
Product revenue increased in fiscal 2014 as compared to fiscal 2013 primarily due to significant increase in the number of customers and products sold due to our acquisition of Enterasys in the second quarter of fiscal 2014.  This resulted in a significant increase in our product revenue in all regions.

[0001078271-15-000120:mdna:39]
Service revenue increased $27.1 million or 25.1% for the year-ended June 30, 2015 compared to the corresponding period of fiscal 2014 due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys.  Purchase accounting charges related to deferred service revenues decreased $2.2 million for the year-ended June 30, 2015, to $3.1 million from $5.3 million in the corresponding period of fiscal 2014.

[0001078271-15-000120:mdna:40]
Service revenue increased in fiscal 2014 as compared to fiscal 2013 primarily due to an increase in service maintenance contracts and professional service and training revenues due to our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-15-000120:mdna:41]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenue geographically for the fiscal years 2015, 2014 and 2013 (dollars in thousands):

[0001078271-15-000120:mdna:42]
|  | Year Ended |  | Year Ended |
| Net Revenue | June 30, 2015 |  | June 30, 2014 |  | $Change |  | %Change |  | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 238,748 |  |  | $ | 211,734 |  |  | $ | 27,014 |  |  | 12.8 | % |  | $ | 211,734 |  |  | $ | 101,790 |  |  | $ | 109,944 |  |  | 108.0 | % |
| Other | 31,931 |  |  | 45,790 |  |  | (13,859 | ) |  | (30.3 | )% |  | 45,790 |  |  | 33,584 |  |  | 12,206 |  |  | 36.3 | % |
| Total Americas | 270,679 |  |  | 257,524 |  |  | 13,155 |  |  | 5.1 | % |  | 257,524 |  |  | 135,374 |  |  | 122,150 |  |  | 90.2 | % |
| Percentage of net revenue | 49.0 | % |  | 49.6 | % |  |  |  |  |  | 49.6 | % |  | 45.2 | % |  |  |  |  |
| EMEA | 223,368 |  |  | 202,555 |  |  | 20,813 |  |  | 10.3 | % |  | 202,555 |  |  | 112,812 |  |  | 89,743 |  |  | 79.6 | % |
| Percentage of net revenue | 40.4 | % |  | 39.0 | % |  |  |  |  |  | 39.0 | % |  | 37.7 | % |  |  |  |  |
| APAC | 58,893 |  |  | 59,475 |  |  | (582 | ) |  | (1.0 | )% |  | 59,475 |  |  | 51,157 |  |  | 8,318 |  |  | 16.3 | % |
| Percentage of net revenue | 10.7 | % |  | 11.4 | % |  |  |  |  |  | 11.4 | % |  | 17.1 | % |  |  |  |  |
| Total net revenues | $ | 552,940 |  |  | $ | 519,554 |  |  | $ | 33,386 |  |  | 6.4 | % |  | $ | 519,554 |  |  | $ | 299,343 |  |  | $ | 220,211 |  |  | 73.6 | % |

[0001078271-15-000120:mdna:43]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEM, and direct sales.  Revenue through our distributor channel was 47% of total product revenue in fiscal 2015, 44% of total product revenue in fiscal 2014 and 43% of total product revenue in fiscal 2013.

[0001078271-15-000120:mdna:44]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001078271-15-000120:mdna:45]
Cost of Revenue and Gross Profit

[0001078271-15-000120:mdna:46]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenue for the fiscal years 2015, 2014 and 2013 (dollars in thousands):

[0001078271-15-000120:mdna:47]
|  | Year Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | $Change |  | %Change |  | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 193,028 |  |  | $ | 198,088 |  |  | $ | (5,060 | ) |  | (2.6 | )% |  | $ | 198,088 |  |  | $ | 124,093 |  |  | $ | 73,995 |  |  | 59.6 | % |
| Percentage of product revenue | 46.2 | % |  | 48.1 | % |  |  |  |  |  | 48.1 | % |  | 51.7 | % |  |  |  |  |
| Service | 86,709 |  |  | 69,241 |  |  | 17,468 |  |  | 25.2 | % |  | 69,241 |  |  | 38,533 |  |  | 30,708 |  |  | 79.7 | % |
| Percentage of service revenue | 64.3 | % |  | 64.2 | % |  |  |  |  |  | 64.2 | % |  | 64.9 | % |  |  |  |  |
| Total gross profit | $ | 279,737 |  |  | $ | 267,329 |  |  | $ | 12,408 |  |  | 4.6 | % |  | $ | 267,329 |  |  | $ | 162,626 |  |  | $ | 104,703 |  |  | 64.4 | % |
| Percentage of net revenue | 50.6 | % |  | 51.5 | % |  |  |  |  |  | 51.5 | % |  | 54.3 | % |  |  |  |  |

[0001078271-15-000120:mdna:48]
Cost of product revenue includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing and supply chain management operations, and we conduct quality assurance, manufacturing engineering, document control and distribution at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001078271-15-000120:mdna:49]
Product gross profit decreased to $193.0 million for the year-ended June 30, 2015, from $198.1 million in the corresponding period of fiscal 2014.  Product gross profit for the year-ended June 30, 2015, was favorably impacted by an increase in product revenue of $6.3 million, offset by higher material costs and increases of $5.8 million in excess and obsolete inventory charges, $6.1 million for amortization of the developed technology intangibles from the acquisition of Enterasys, $3.4 million for distribution costs due to higher utilization of air freight and $3.3 million of warranty charges. Gross profit for fiscal 2014, was negatively

[0001078271-15-000120:mdna:50]
impacted by $11.1 million related to the sale of inventory which had been adjusted to fair value upon the Enterasys acquisition due to purchase accounting.

[0001078271-15-000120:mdna:51]
Product gross profit increased for fiscal 2014 to $198.1 million as compared to $124.1 million primarily due to significant increase in product revenues due to our acquisition of Enterasys in the second quarter of fiscal 2014.  However, product gross margin in fiscal 2014 decreased as compared to fiscal 2013 primarily due to a $11.1 million charge related to the utilization of the net increase in cost basis of the inventory acquired in connection with the purchase of Enterasys, $11.0 million for the amortization of developed technology intangibles from the acquisition of Enterasys during the second quarter of fiscal 2014 and increased stock compensation expenses offset by higher economic benefits realized in our manufacturing costs as compared to fiscal 2013.

[0001078271-15-000120:mdna:52]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of spare parts used in providing support under customer service contracts.

[0001078271-15-000120:mdna:53]
Service gross profit increased to $86.7 million for the year-ended June 30, 2015, from $69.2 million in the corresponding period of fiscal 2014, primarily due to increase in service revenue of $27.1 million partially offset by increased personnel, overhead and travel costs as a result of the acquisition of Enterasys.  Additionally, purchase accounting charges related to deferred service revenues decreased $2.2 million in fiscal 2015 to $3.1 million from $5.3 million as compared to fiscal 2014.

[0001078271-15-000120:mdna:54]
Service gross profit in fiscal 2014 increased as compared to fiscal 2013 primarily due to increased service revenue as a result of acquisition of Enterasys and cost reduction initiatives offset by higher personnel, overhead and travel cost as a result of our acquisition of Enterasys during the second quarter of fiscal 2014.

[0001078271-15-000120:mdna:55]
35

[0001078271-15-000120:mdna:56]
Operating Expenses

[0001078271-15-000120:mdna:57]
The following table presents operating expenses and operating income (dollars in thousands):

[0001078271-15-000120:mdna:58]
|  | Year Ended |  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | $Change |  | %Change |  | June 30, 2014 |  | June 30, 2013 |  | $Change |  | %Change |
| Research and development | $ | 93,447 |  |  | $ | 77,146 |  |  | $ | 16,301 |  |  | 21.1 | % |  | $ | 77,146 |  |  | $ | 40,521 |  |  | $ | 36,625 |  |  | 90.4 | % |
| Sales and marketing | 169,299 |  |  | 156,666 |  |  | 12,633 |  |  | 8.1 | % |  | 156,666 |  |  | 87,202 |  |  | 69,464 |  |  | 79.7 | % |
| General and administrative | 42,092 |  |  | 40,912 |  |  | 1,180 |  |  | 2.9 | % |  | 40,912 |  |  | 26,725 |  |  | 14,187 |  |  | 53.1 | % |
| Acquisition and integration costs | 10,205 |  |  | 25,716 |  |  | (15,511 | ) |  | (60.3 | )% |  | 25,716 |  |  | — |  |  | 25,716 |  |  | N/M |
| Restructuring charge, net of reversals | 9,819 |  |  | 510 |  |  | 9,309 |  |  | 1,825.3 | % |  | 510 |  |  | 6,836 |  |  | (6,326 | ) |  | (92.5 | )% |
| Amortization of intangibles | 17,869 |  |  | 16,711 |  |  | 1,158 |  |  | 6.9 | % |  | 16,711 |  |  | — |  |  | 16,711 |  |  | N/M |
| Litigation settlement (income)/loss | — |  |  | (100 | ) |  | 100 |  |  | N/M |  | (100 | ) |  | 2,029 |  |  | (2,129 | ) |  | (104.9 | )% |
| Gain on sale of campus | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (11,539 | ) |  | 11,539 |  |  | N/M |
| Total operating expenses | $ | 342,731 |  |  | $ | 317,561 |  |  | $ | 25,170 |  |  | 7.9 | % |  | $ | 317,561 |  |  | $ | 151,774 |  |  | $ | 165,787 |  |  | 109.2 | % |
| Operating (loss) income | $ | (62,994 | ) |  | $ | (50,232 | ) |  | $ | (12,762 | ) |  | (25.4 | )% |  | $ | (50,232 | ) |  | $ | 10,852 |  |  | $ | (61,084 | ) |  | (562.9 | )% |

[0001078271-15-000120:mdna:59]
The following table highlights our operating expenses and operating income (loss) as a percentage of net revenues:

[0001078271-15-000120:mdna:60]
|  | Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Research and development | 16.9 | % |  | 14.8 | % |  | 13.5 | % |
| Sales and marketing | 30.6 | % |  | 30.2 | % |  | 29.1 | % |
| General and administrative | 7.6 | % |  | 7.9 | % |  | 8.9 | % |
| Acquisition and integration costs | 1.8 | % |  | 4.9 | % |  | — | % |
| Restructuring charge, net of reversals | 3.2 | % |  | 0.1 | % |  | 2.3 | % |
| Amortization of intangibles | 1.8 | % |  | 3.2 | % |  | — | % |
| Litigation settlement (income)/loss | — | % |  | — | % |  | 0.7 | % |
| Gain on sale of campus | — | % |  | — | % |  | (3.9 | )% |
| Total operating expenses | 62.0 | % |  | 61.1 | % |  | 50.6 | % |
| Operating (loss) income | (11.4 | )% |  | (9.7 | )% |  | 3.6 | % |

[0001078271-15-000120:mdna:61]
Research and Development Expenses

[0001078271-15-000120:mdna:62]
Research and development expenses consist primarily of salaries and related personnel expenses, consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001078271-15-000120:mdna:63]
Research and development increased by $16.3 million or 21.1% for fiscal 2015 as compared to fiscal 2014. The increase in research and development expenses were primarily due to increased spending as a result of our acquisition of Enterasys.  The increase in spending related to $13.4 million of personnel costs, which includes compensation, benefits and non-cash stock based compensation, including $0.4 million of expense related to our executive transition activity, $1.3 million in depreciation and $0.8 million for supplies and equipment.

[0001078271-15-000120:mdna:64]
Research and development expenses increased in fiscal 2014 as compared to fiscal 2013 primarily due to increased personnel and occupancy costs as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-15-000120:mdna:65]
Sales and Marketing Expenses

[0001078271-15-000120:mdna:66]
Sales and marketing expenses consist of salaries, commissions and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001078271-15-000120:mdna:67]
Sales and marketing increased by $12.6 million or 8.1% for the year-ended June 30, 2015 as compared to the corresponding period of fiscal 2014.  The increase in sales and marketing expenses during fiscal 2015 was primarily due to $6.7 million of higher compensation, benefits and non-cash stock compensation, including $0.5 million of expense related to our executive transition

[0001078271-15-000120:mdna:68]
activity, $2.7 million in marketing expense, $1.8 million in facilities and $0.8 million in depreciation.  All of these factors were primarily driven by the acquisition of Enterasys.

[0001078271-15-000120:mdna:69]
Sales and marketing expenses increased in fiscal 2014 as compared to fiscal 2013 primarily due to increased personnel costs as well as additional spending on additional sales and marketing programs, as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-15-000120:mdna:70]
General and Administrative Expenses

[0001078271-15-000120:mdna:71]
General and administrative expense consists primarily of personnel costs, legal and professional service costs, share-based compensation, travel and facilities and information technology costs.

[0001078271-15-000120:mdna:72]
General and administrative expenses increased by $1.2 million or 2.9% for the year-ended June 30, 2015 as compared to the corresponding period of fiscal 2014.  The increase in general and administrative expenses was primarily due to $1.1 million in higher personnel costs related to our executive transition activity,  higher occupancy costs due to additional facilities in Salem, New Hampshire and Shannon, Ireland as a result of our acquisition of Enterasys, a $0.8 million increase in bad debt expense and $0.2 million in professional service fees.  This increase was partial offset by $1.0 million in lower travel costs.

[0001078271-15-000120:mdna:73]
General and administrative expenses increased in fiscal 2014 as compared to fiscal 2013 primarily due to higher personnel and travel costs and higher occupancy costs as a result of our acquisition of Enterasys in the second quarter of fiscal 2014.

[0001078271-15-000120:mdna:74]
Acquisition and Integration Costs

[0001078271-15-000120:mdna:75]
As a result of our acquisition of Enterasys, we incurred $10.2 million and $25.7 million of acquisition and integration costs in fiscal 2015 and 2014, respectively.  For fiscal 2015, the entire $10.2 million of expense was related to integration costs.  The fiscal 2014 expense was related to $19.7 million of integration costs and the remaining $6.0 million expense was related to acquisition costs.  The lower fiscal 2015 integration expenses was due to lower severance and termination costs and third party consulting fees.  The Company expects to incur integration costs at a considerable lower rate for fiscal 2016.

[0001078271-15-000120:mdna:76]
Amortization of Intangibles

[0001078271-15-000120:mdna:77]
During fiscal 2015 and 2014, we recorded $17.9 million and $16.7 million, respectively, of amortization expenses primarily for certain intangibles related to the acquisition of Enterasys.

[0001078271-15-000120:mdna:78]
Restructuring Charge, Net of Reversal

[0001078271-15-000120:mdna:79]
During fiscal 2015, 2014 and 2013, we recorded restructuring charges, net of reversals, of $9.8 million, $0.5 million and $6.8 million, respectively.

[0001078271-15-000120:mdna:80]
Fiscal 2015 Restructuring

[0001078271-15-000120:mdna:81]
During the fourth quarter of fiscal 2015, we implemented a plan to reduce costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. We initiated a plan to reduce our worldwide headcount by more than 225 employees, primarily in sales and marketing as well as research and development, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. We have expensed all costs associated with this initiative. We expect to achieve approximately $40.0 million in operational savings on an annualized basis, beginning in the first quarter of fiscal 2016.  As of June 30, 2015, we anticipate paying the remaining restructuring liabilities of $5.9 million related to the fiscal 2015 restructuring by the end of the second quarter of fiscal 2016. The restructuring liability is recorded in "Other accrued liabilities" on the consolidated balance sheet.

[0001078271-15-000120:mdna:82]
Fiscal 2013 Restructuring

[0001078271-15-000120:mdna:83]
During the second quarter of fiscal 2013, we reduced costs through targeted restructuring activities intended to reduce operating costs and realign our organization in the current competitive environment. As part of our restructuring efforts in the second quarter of fiscal 2013, we initiated a plan to reduce our worldwide headcount by 13%, consolidate specific global administrative functions, and shift certain operating costs to lower cost regions, among other actions. We have substantially expensed all costs associated with this initiative.  As of June 30, 2015, there were no outstanding liabilities related to the fiscal 2013 restructuring.

[0001078271-15-000120:mdna:84]
Litigation Settlement (Income) Expense

[0001078271-15-000120:mdna:85]
During fiscal 2014, the Company received $0.1 million from the settlement of a property lease litigation matter.

[0001078271-15-000120:mdna:86]
During fiscal 2013, we recognized a litigation charge of $2.5 million related to a settlement agreement entered into with Enterasys prior to the acquisition.

[0001078271-15-000120:mdna:87]
Gain on Sale of Campus

[0001078271-15-000120:mdna:88]
During fiscal 2013, we completed the sale of our corporate campus and accompanying 16 acres of land in Santa Clara, California for net cash proceeds of $44.7 million of which, $2.0 million was received in fiscal 2012.  We realized a gain of $11.5 million in connection with this transaction, yet recorded a tax loss of $24.6 million.

[0001078271-15-000120:mdna:89]
Interest Income

[0001078271-15-000120:mdna:90]
Interest income was $0.5 million, $0.8 million and $1.1 million in fiscal years 2015, 2014 and 2013, respectively, representing a decrease of $0.2 million in fiscal 2015 from fiscal 2014 and a decrease of $0.3 million in fiscal 2014 from fiscal 2013.  The decrease in interest income in fiscal 2015 was due to a decrease in the investment balance to fund debt reduction. The decrease in interest income in fiscal 2014 was due to a decrease in our investment portfolio to fund a portion of the acquisition.

[0001078271-15-000120:mdna:91]
Interest Expense

[0001078271-15-000120:mdna:92]
We had $3.2 million and $2.1 million of interest expense for fiscal 2015 and 2014, respectively.  Interest expense was immaterial for fiscal 2013.  Interest expense in fiscal years 2015 and 2014 was primarily related to the Credit Facility that the Company entered into on October 31, 2013 to fund the acquisition of Enterasys.

[0001078271-15-000120:mdna:93]
Other (Expense) Income, net

[0001078271-15-000120:mdna:94]
Other (expense) income net was expense of $1.2 million, $1.6 million and $0.6 million in fiscal years 2015, 2014 and 2013, respectively.  Other expense in all periods was primarily due to the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001078271-15-000120:mdna:95]
Provision for Income Taxes

[0001078271-15-000120:mdna:96]
We are subject to income taxes in the United States and numerous foreign jurisdictions.  Our effective tax rate differs from the U.S. federal statutory rate of 35% primarily due to the impact of state taxes, foreign operations which are generally taxed at lower statutory rates and the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions.  For the fiscal years ended June 30, 2015, 2014 and 2013, we recorded income tax provisions of $4.8 million, $4.2 million and $1.7 million, respectively.  The effective tax rates for fiscal years ended June 30, 2015, 2014 and 2013 were 7.2%, 7.9% and 14.8%, respectively.

[0001078271-15-000120:mdna:97]
For the fiscal years ended June 30, 2015, 2014 and 2013 the majority of our tax provision relates to taxes on our foreign operations as well as state taxes due to the full valuation allowance on our U.S. and certain foreign deferred tax assets.  In the fiscal year ended June 30, 2014, a portion of our provision resulted from the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys.

[0001078271-15-000120:mdna:98]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 35% and for further explanation of our provision for income taxes, see Note 9 to the consolidated financial statements.

[0001078271-15-000120:mdna:99]
Critical Accounting Policies and Estimates

[0001078271-15-000120:mdna:100]
Our significant accounting policies are more fully described in Note 3 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001078271-15-000120:mdna:101]
Revenue Recognition

[0001078271-15-000120:mdna:102]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance service contracts, professional services, and training for our products. We recognize revenue when persuasive evidence of an arrangement exists, delivery has occurred, the price of the product is fixed or determinable, and the collection of the sales proceeds is reasonably assured. In instances where any of the criteria for revenue recognition are not met, we defer revenue until all criteria have been met.

[0001078271-15-000120:mdna:103]
Product revenue from our value-added resellers, non-stocking distributors and end-user customers is recognized at the time of shipment, provided that all of the foregoing revenue recognition requirements have been satisfied.  We generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits. Accordingly, we

[0001078271-15-000120:mdna:104]
recognize revenue upon transfer of title and risk of loss to the customer, which is generally upon shipment. We maintain estimated accruals and allowances for sales incentives and other programs that we may make available to our partners, based on historical experience or applicable contractual terms. Sales taxes collected from customers are excluded from revenues.

[0001078271-15-000120:mdna:105]
We also sell our products to distributors that stock inventory and sell to resellers. We defer recognition of revenue on all sales to our stocking distributors until the distributors have sold the products, as evidenced by sales data that the distributors provide to us. We grant stocking distributors certain price protection rights and the right to return a portion of unsold inventory for the purpose of stock rotation. The distributor-related deferred revenue and receivables are adjusted at the time of the stock rotation return or price reduction. We also provide stocking distributors with credits for changes in selling prices based on competitive conditions, and provide funding for our distributors and their resellers to perform marketing development activities. We maintain estimated accruals and allowances for these exposures based upon our contractual obligations. Our marketing development channel programs do not meet the criteria for recognizing the costs as marketing expenses and therefore these costs are accrued as a reduction to revenue in the same period that the products are sold.

[0001078271-15-000120:mdna:106]
Revenue from service contracts is deferred and recognized ratably over the contractual service period, which is typically from one to two years. Professional service revenue is recognized upon delivery or completion of performance.

[0001078271-15-000120:mdna:107]
Our networking products are tangible products that contain software and non-software components that function together to deliver the tangible product's essential functionality. Our sales arrangements may contain multiple deliverables comprised of our tangible products, standalone software licenses, and service offerings depending on the distribution sales channel through which the products are sold and the requirements of our customers. We recognize revenue for our multiple deliverable arrangements in accordance with the accounting standard for multiple deliverable revenue arrangements, which provides guidance on whether multiple deliverables exist, how deliverables in an arrangement should be separated, and how consideration should be allocated. The industry-specific software revenue recognition guidance does not apply to the sales of our tangible products.  Software revenue guidance is applied to sales of our standalone software products, including software upgrades and software that is not essential to the functionality of the hardware with which it is sold.

[0001078271-15-000120:mdna:108]
Pursuant to the guidance of the accounting standard for multiple-deliverable revenue arrangements, we allocate the total arrangement consideration to each separable element of an arrangement based on the relative selling price of each element.  We determine the standalone selling price for each element based on a selling price hierarchy. Under the selling price hierarchy, the selling price for each deliverable is based on our vendor-specific objective evidence ("VSOE") of selling price, which is determined by a substantial majority of our historical standalone sales transactions for a product or service falling within a reasonable range. If VSOE is not available due to a lack of standalone sales transactions or lack of pricing within a narrow range, then third party evidence (“TPE”), as determined by the standalone pricing of competitive vendor products in similar markets, is used. TPE typically is difficult to establish due to the proprietary differences of competitive products and difficulty in obtaining reliable competitive standalone pricing information. When neither VSOE nor TPE is available, we determine the best estimate of standalone selling price (“ESP”) for a product or service by considering several factors including, but not limited to, the 12-month historical median sales price, sales channels, geography, gross margin consistency, competitive product pricing, and product life cycle. In consideration of all relevant pricing factors, we apply management judgment to determine the best estimate of selling price through consultation with and formal approval by our management for all products and services for which neither VSOE nor TPE is available. Generally, the standalone selling price of services is determined using VSOE and the standalone selling price of all other deliverables is determined by using ESP. We regularly review VSOE, TPE and ESP for all of our products and services and maintain internal controls over the establishment and updates of these estimates.

[0001078271-15-000120:mdna:109]
Pursuant to the software revenue recognition accounting standard, we continue to recognize revenue for software using the residual method for our sales of standalone software products and other software that is not essential to the functionality of the hardware with which it is sold. After allocation of the relative selling price to each element of the multiple deliverable arrangement, we recognize revenue in accordance with our policies for product, software, and service revenue recognition.

[0001078271-15-000120:mdna:110]
Our total deferred product revenue from customers other than distributors was $6.1 million and $4.1 million as of June 30, 2015 and 2014, respectively. Our total deferred revenue for services, primarily from service contracts, was $87.4 million and $89.7 million as of June 30, 2015 and 2014, respectively. Service contracts typically range from one to two years. Shipping costs are included in cost of product revenues.

[0001078271-15-000120:mdna:111]
We provide an allowance for sales returns based on our historical returns, analysis of credit memo data and our return policies. The allowance for sales returns was $1.1 million and $2.7 million as of June 30, 2015 and 2014, respectively, for estimated future returns that were recorded as a reduction of our accounts receivable. If the historical data that we use to calculate the estimated sales returns and allowances does not properly reflect future levels of product returns, these estimates will be revised, thus resulting in an impact on future net revenue. We estimate and adjust this allowance at each balance sheet date.

[0001078271-15-000120:mdna:112]
Goodwill

[0001078271-15-000120:mdna:113]
Goodwill is assessed for impairment annually during the fourth quarter of the fiscal year (April 1) or more frequently when an event occurs or circumstances change between annual tests that would more likely than not reduce the fair value of the reporting unit below its carrying value. We have determined that we have one reporting unit. To test goodwill for impairment, we first perform a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value. If it is concluded that this is the case, we then perform the two-step goodwill impairment test. Otherwise, the two-step goodwill impairment test is not required. Under the two-step goodwill impairment test, we in the first step, compare the estimated fair value of a reporting unit to its carrying value. If the fair value of the reporting unit exceeds the carrying value, no impairment loss is recognized. However, if the carrying value of the reporting unit exceeds its fair value, the goodwill of the unit may be impaired. The amount, if any, of the impairment is then measured in the second step in which we determine the implied value of goodwill based on the allocation of the estimated fair value determined in the initial step to all assets and liabilities of the reporting unit.

[0001078271-15-000120:mdna:114]
We completed our annual goodwill impairment test in the fourth quarter of fiscal 2015 and determined there was no impairment as the fair value of the reporting unit exceeded its carrying value.

[0001078271-15-000120:mdna:115]
Share-based Payments

[0001078271-15-000120:mdna:116]
We use the Black-Scholes option-pricing model to determine the fair value of option grants other than option grants, with market, performance or service conditions or a combination of those conditions, options assumed as part of the Enterasys acquisition, and share purchase options under our Employee Stock Purchase Plan (“ESPP”) on the date of grant with the weighted average assumptions. We use the Monte-Carlo simulation model to determine the fair value and the derived service period of option grants, with market, performance or service conditions or combinations of those conditions, on the date of grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The expected term of purchase options under our ESPP represents the contractual life of the ESPP purchase period. The risk-free rate based upon the estimated life of the option and ESPP award is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on both the implied volatilities from traded options on our stock and historical volatility on our stock. We do not currently pay cash dividends on our common stock and do not anticipate doing so in the foreseeable future. Accordingly, our expected dividend yield is zero. We are required to estimate forfeitures at the time of grant and revise those estimates in subsequent periods if actual forfeitures differ from those estimates.  In fiscal 2015, our estimated forfeiture rates based on historical forfeiture experiences are 14% for executives and 12% for non-executive employees.  We use the straight-line method for expense attribution, and we only recognize expense for those shares expected to vest.

[0001078271-15-000120:mdna:117]
Restructuring Charges

[0001078271-15-000120:mdna:118]
The Company recognizes liability for exit and disposal activities when the liability is incurred.  A liability for post-employment benefits, including severance, is recorded upon attainment of certain criteria including when payment is probable, the amount is reasonably estimable, and the obligation relates to rights that have vested or accumulated.  Facilities consolidation charges are calculated using estimates and are based upon the remaining future lease commitments for vacated facilities from the date of facility consolidation, net of estimated future sublease income. The estimated costs of vacating these leased facilities are based on market information and trend analysis.

[0001078271-15-000120:mdna:119]
The Company continually evaluates the adequacy of the remaining liabilities under its restructuring initiatives.  Although the Company believes that these estimates accurately reflect the costs of its restructuring plans, actual results may differ, thereby requiring the Company to record additional provision or reverse a portion of such provision.

[0001078271-15-000120:mdna:120]
Business Combinations

[0001078271-15-000120:mdna:121]
We allocate the purchase price of acquired companies to the tangible and intangible assets acquired and liabilities assumed, assumed equity awards, as well as to in-process research and development based upon their estimated fair values at the acquisition date.   The purchase price allocation process requires management’s judgment and often involves the use of significant estimates and assumptions, especially at the acquisition date with respect to intangible assets, deferred revenue obligations and equity assumed.

[0001078271-15-000120:mdna:122]
Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain.  Examples of critical estimates in valuing certain of intangible assets we have acquired or may acquire in future include but are not limited to assumptions with respect to future cash inflows and outflows, discount rates, intangibles and other asset lives, expected costs to develop the in-process research and development into commercially viable products, among other items.

[0001078271-15-000120:mdna:123]
In connection with the purchase price allocations for our acquisitions, we estimate the fair value of inventory using the comparative sales method.  The fair value of the inventory utilizing the comparative sales method is estimated using the selling price, less sales costs, marketing costs and profit on these costs.  The operating profit margins are based on the historical margins.

[0001078271-15-000120:mdna:124]
In connection with the purchase price allocations for our acquisitions, we estimate the fair value of deferred revenue using the cost build-up approach.  The cost build-up approach determines the fair value by estimating the costs related to fulfilling the obligations plus a normal profit margin.  The estimated costs to fulfill the obligations are based on historical costs and benchmarking analysis.

[0001078271-15-000120:mdna:125]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results. As a result, during the measurement period, which may be up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded to our consolidated statements of operations.

[0001078271-15-000120:mdna:126]
Impact of Recently Issued Accounting Standards

[0001078271-15-000120:mdna:127]
In May 2014, the FASB, jointly with the International Accounting Standards Board, issued Accounting Standard Update No. 2014-09 (Topic 606) - Revenue from Contracts with Customers ("ASU 2014-09"). This ASU's core principle is that a reporting entity will recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In applying this new guidance to contracts within its scope, an entity will: (1) identify the contract(s) with a customer, (2) identify the performance obligation in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when (or as) the entity satisfies a performance obligation. Additionally, this new guidance will require significantly expanded disclosures about revenue recognition. ASU 2014-09 is effective for annual reporting periods (including interim reporting periods within those annual periods) beginning after December 15, 2016. In July 2015, the FASB approved a one-year deferral of the effective date of the new standard. The new standard will be effective for our fiscal 2019, with early adoption permitted.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this ASU. We are currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.

[0001078271-15-000120:mdna:128]
In November 2014, the FASB has issued ASU 2014-15, Disclosure of Uncertainties About an Entity’s Ability to Continue as a Going Concern, which provides guidance on determining when and how to disclose going-concern uncertainties in the financial statements. The new standard requires management to perform interim and annual assessments of an entity’s ability to continue as a going concern within one year of the date of issuance of the entity’s financial statements and provide certain disclosures when there is substantial doubt about the entity’s ability to continue as a going concern. This guidance applies to all entities and is effective for annual periods beginning after December 15, 2015, and interim periods thereafter, with early adoption permitted. We are currently evaluating the potential effect on its consolidated financial statements from adoption of this standard.

[0001078271-15-000120:mdna:129]
In February 2015, the FASB issued ASU 2015-02 which provides consolidation guidance and changes the way reporting enterprises evaluate consolidation for limited partnerships, investment companies and similar entities, as well as variable interest entities.  The ASU is effective for annual and interim periods in fiscal years beginning after December 15, 2015.  We do not believe adoption of this standard will have a material impact on our consolidated financial statements.

[0001078271-15-000120:mdna:130]
In April 2015, the FASB issued ASU 2015-03 - Simplifying the Presentation of Debt Issuance Costs, which requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of that debt liability, consistent with debt discounts.  ASU 2015-03 requires retrospective adoption and will be effective for annual and interim periods in fiscal years beginning after December 15, 2015. Early adoption is permitted. We do not believe adoption of this standard will have a material impact on our consolidated financial statements.

[0001078271-15-000120:mdna:131]
In July 2015, the FASB issued ASU 2015-11, which requires entities to measure most inventory “at the lower of cost and net realizable value,” thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market (market in this context is defined as one of three different measures). The ASU will not apply to inventories that are measured by using either the last-in, first-out ("LIFO") method or the retail inventory method ("RIM").  The ASU is effective prospectively for annual periods beginning after December 15, 2016, and interim periods therein. Early application of the ASU is permitted. Upon transition, entities must disclose the nature of and reason for the accounting change. We do not believe adoption of this standard will have a material impact on our consolidated financial statements.

[0001078271-15-000120:mdna:132]
Recently Adopted Accounting Pronouncements

[0001078271-15-000120:mdna:133]
In July 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update No. 2013-11, Income Taxes (Topic 740)-Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists (“ASU 2013-11”).  This ASU provides guidance regarding the presentation in the statement of financial position of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. The ASU generally provides that an entity's unrecognized tax benefit, or a portion of its unrecognized tax benefit, should be presented in its financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward.  ASU 2013-11 is effective for fiscal years, and interim periods within those years, beginning after December 31, 2013.  We adopted this standard prospectively in the first quarter of the fiscal year ending June 30, 2015, its adoption did not have a material impact on our consolidated financial statements.

[0001078271-15-000120:mdna:134]
Liquidity and Capital Resources

[0001078271-15-000120:mdna:135]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001078271-15-000120:mdna:136]
|  | June 30, 2015 |  | June 30, 2014 |
| Cash and cash equivalent | $ | 76,225 |  |  | $ | 73,190 |  |
| Short-term investments | — |  |  | 32,692 |  |
| Total cash and investments | $ | 76,225 |  |  | $ | 105,882 |  |
| Working capital | $ | 2,564 |  |  | $ | 56,548 |  |

[0001078271-15-000120:mdna:137]
As of June 30, 2015, our principal sources of liquidity consisted of cash and cash equivalents of $76.2 million, accounts receivable, net of $92.7 million and availability of borrowings from the Revolving Facility of $20.6 million as of June 30, 2015.  Our principal uses of cash will include repayments of debt and related interest, purchase of finished goods inventory from our contract manufacturers, payroll, restructuring expenses and other operating expenses related to the development, marketing of our products and purchases of property and equipment.  We believe that our $76.2 million of cash and cash equivalents at June 30, 2015, cash flows from operations along with the availability of borrowings from the Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001078271-15-000120:mdna:138]
The Senior Secured Credit Facilities, as amended, contain financial covenants that require us to maintain a minimum Consolidated Fixed Charge Coverage Ratio and Consolidated Quick Ratio and a maximum Consolidated Leverage Ratio and several other financial and non-financial covenants and restrictions that limit our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets, etc.

[0001078271-15-000120:mdna:139]
The Senior Secured Credit Facilities, as amended, also include customary events of default, including failure to pay principal, interest or fees when due, failure to comply with covenants, if any representation or warranty made by us is false or misleading in any material respect, certain insolvency or receivership events affecting Extreme and its subsidiaries, the occurrence of certain material judgments, the occurrence of certain ERISA events, the invalidity of the loan documents or a change in control of our Company.  The amounts outstanding under the Senior Secured Credit Facilities, as amended,  may be accelerated upon certain events of default. We believe we are in compliance and expect to remain in compliance with the covenants of the Senior Secured Credit Facilities, as amended, and they are not expected to impact our liquidity or capital resources.

[0001078271-15-000120:mdna:140]
Key Components of Cash Flows and Liquidity

[0001078271-15-000120:mdna:141]
A summary of the sources and uses of cash and cash equivalents is as follows (in thousands):

[0001078271-15-000120:mdna:142]
|  | Fiscal Year Ended |
|  | June 30, 2015 |  | June 30, 2014 |  | June 30, 2013 |
| Net cash provided by (used in) operating activities | $ | 37,423 |  |  | $ | (26,843 | ) |  | $ | 32,237 |  |
| Net cash provided by (used in ) investing activities | $ | 21,598 |  |  | $ | (126,189 | ) |  | $ | 16,480 |  |
| Net cash (used in) provided by financing activities | $ | (52,470 | ) |  | $ | 129,580 |  |  | $ | (7,391 | ) |
| Foreign currency effect on cash | $ | (3,516 | ) |  | $ | 839 |  |  | $ | (119 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 3,035 |  |  | $ | (22,613 | ) |  | $ | 41,207 |  |

[0001078271-15-000120:mdna:143]
Cash, cash equivalents and short-term investments were $76.2 million at June 30, 2015, representing a decrease of $29.7 million from $105.9 million at June 30, 2014.  Cash and cash equivalents increased primarily due to cash provided by operations of $37.4 million and cash provided by investing activities of $21.6 million offset by cash used in financing activities of $52.5 million and foreign currency impact of $3.5 million.

[0001078271-15-000120:mdna:144]
Cash provided by operating activities was $37.4 million compared to cash used in operating activities of $26.8 million in fiscal 2014, an increase of $64.3 million during the year ended June 30, 2015.  The current year's net loss of $71.6 million was primarily offset by non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.  Decreases in accounts receivables and increases in deferred revenue were also factors contributing to the cash provided by operating activities for the year ended June 30, 2015.

[0001078271-15-000120:mdna:145]
Cash flow provided by investing activities of $21.6 million, was mainly due to proceeds from sales and maturities of investments of $32.4 million offset by capital expenditures of $7.2 million and purchase of non-marketable equity investments of $3.0 million.

[0001078271-15-000120:mdna:146]
Cash flow used in financing activities was $52.5 million due to the repayment of debt of $78.7 million and borrowings of $24.0 million on the Revolving Facility for working capital requirements.

[0001078271-15-000120:mdna:147]
Contractual Obligations

[0001078271-15-000120:mdna:148]
The following summarizes our contractual obligations at June 30, 2015, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001078271-15-000120:mdna:149]
|  | Total |  | Less Than1 Year |  | 1 – 3 Years |  | 3 – 5 Years |  | More ThanFive Years |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |
| Debt obligations | $ | 66,875 |  |  | 11,375 |  |  | $ | 39,813 |  |  | $ | 15,687 |  |  | $ | — |  |
| Interest on debt obligations | 5,651 |  |  | 2,406 |  |  | 3,037 |  |  | 208 |  |  | — |  |
| Non-cancelable inventory purchase commitments | 69,863 |  |  | 69,863 |  |  | — |  |  | — |  |  | — |  |
| Non-cancelable operating lease obligations | 64,417 |  |  | 10,948 |  |  | 18,579 |  |  | 17,170 |  |  | 17,720 |  |
| Other liabilities | 650 |  |  | 195 |  |  | 390 |  |  | 65 |  |  | — |  |
| Total contractual cash obligations | $ | 207,456 |  |  | $ | 94,787 |  |  | $ | 61,819 |  |  | $ | 33,130 |  |  | $ | 17,720 |  |

[0001078271-15-000120:mdna:150]
Non-cancelable inventory purchase commitments represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast.  Inventory purchase commitments were $69.9 million as of June 30, 2015, an increase of $5.2 million from $64.7 million as of June 30, 2014.

[0001078271-15-000120:mdna:151]
Non-cancelable operating lease obligations represent base rents and operating expense obligations to landlords for facilities we occupy at various locations.

[0001078271-15-000120:mdna:152]
Other liabilities include the Company's commitments towards debt related fees and specific arrangements other than inventory.

[0001078271-15-000120:mdna:153]
The amounts in the table above exclude income tax liabilities related to uncertain tax positions as existing tax attributes of the Company are available to offset any potential income tax obligations.

[0001078271-15-000120:mdna:154]
We did not have any material commitments for capital expenditures as of June 30, 2015.

[0001078271-15-000120:mdna:155]
Off-Balance Sheet Arrangements

[0001078271-15-000120:mdna:156]
We did not have any off-balance sheet arrangements as of June 30, 2015.

[0001078271-15-000120:mdna:157]
Capital Resources and Financial Condition

[0001078271-15-000120:mdna:158]
As of June 30, 2015, we had $76.2 million in cash and cash equivalents.  We believe that our current cash, cash equivalents, cash available from future operations along with the availability of borrowings from the Revolving Facility will enable us to meet our working capital requirements for at least the next 12 months.
