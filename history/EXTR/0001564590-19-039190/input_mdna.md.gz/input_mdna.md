# EXTR MD&A — 0001564590-19-039190


## mdna

[0001564590-19-039190:mdna:1]
[same as prior period, unchanged from 0001564590-19-018574:mdna:1]

[0001564590-19-039190:mdna:2]
[same as prior period, unchanged from 0001564590-19-018574:mdna:2]

[0001564590-19-039190:mdna:3]
[same as prior period, unchanged from 0001564590-19-018574:mdna:3]

[0001564590-19-039190:mdna:4]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leader in providing cloud-driven networking solutions for enterprise, data center, and service provider customers. Providing a combined end-to-end solution from the enterprise edge to the cloud, Extreme designs, develops, and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security, and access controls.   We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California. We derive substantially all of our revenue from the sale of our networking equipment, software, and related maintenance contracts.

[0001564590-19-039190:mdna:5]
Extreme delivers software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable autonomous enterprises of the future. We recognize that every customer environment is unique with its own requirements, which may be industry-specific or site driven. We address these distinctions with our Extreme Elements architecture. Elements gives customers and partners the power to mix and match a broad array of software, hardware, and services (including third-party applications) to create a custom network that can be managed and automated from end-to-end, from the enterprise edge to the cloud. With this strategic asset in place, organizations have the foundation needed to drive both digital transformation and the outcomes impacting each one of us.

[0001564590-19-039190:mdna:6]
Our 100% in-sourced services and support are number one in the industry, and even as we increase the breadth of our portfolio and scale our organization, we remain nimble and responsive to ensure customer and partner success. We are relentless in our commitment to our 50,000 customers around the world, including over half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing, and provide the building blocks that drive competitive advantage, accelerate innovation, and improve the human experience. This is Customer-Driven Networking™.

[0001564590-19-039190:mdna:7]
[same as prior period, unchanged from 0001564590-19-018574:mdna:6]

[0001564590-19-039190:mdna:8]
Improving the network experience for enterprises that increasingly require greater simplification at the edge or the access layer of the network to ensure business success and provide a secure, unified, wired / wireless infrastructure augmented and managed through a single plane of glass remains a key focus for Extreme. We enhanced our Smart OmniEdge product portfolio in fiscal year 2019 with the launches of our suite of Wi-Fi 6 access points, ExtremeAI software solutions, and Defender for IoT to simplify IoT security. Enterprises have also migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties and are adopting new IT delivery models and applications that require fundamental network alterations and enhancements spanning from device access point to the network core.  In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments.

[0001564590-19-039190:mdna:9]
A trend affecting the enterprise network equipment market is the adoption of the cloud-managed enterprise WLAN in the enterprise market. We continued execution towards our strategic objectives by expanding our cloud portfolio with the acquisition of Aerohive Networks, Inc. (“Aerohive”) in August 2019. This acquisition enhances our cloud offering by adding a 3rd generation cloud with Machine Learning/Artificial Intelligence insights and analytics that we intend to expand to all the Extreme ElementsTM. This cloud-driven solution will be the only offering in the market that seamlessly integrates the Cloud with on premises infrastructures and spans from the edge to the enterprise data center.

[0001564590-19-039190:mdna:10]
We believe that understanding the following key developments is helpful to an understanding of our operating results for the fiscal quarter ended September 30, 2019.

[0001564590-19-039190:mdna:11]
[same as prior period, unchanged from 0001564590-19-018574:mdna:9]

[0001564590-19-039190:mdna:12]
[same as prior period, unchanged from 0001564590-19-018574:mdna:10]

[0001564590-19-039190:mdna:13]
[same as prior period, unchanged from 0001564590-19-018574:mdna:11]

[0001564590-19-039190:mdna:14]
[same as prior period, unchanged from 0001564590-19-018574:mdna:12]

[0001564590-19-039190:mdna:15]
[same as prior period, unchanged from 0001564590-19-018574:mdna:13]

[0001564590-19-039190:mdna:16]
|  | • | Bluetooth Low Energy: A variant of Bluetooth that creates a local area network technology that enables easy, low power connectivity to smartphones and other devices. |

[0001564590-19-039190:mdna:17]
[same as prior period, unchanged from 0001564590-19-018574:mdna:14]

[0001564590-19-039190:mdna:18]
[same as prior period, unchanged from 0001564590-19-018574:mdna:15]

[0001564590-19-039190:mdna:19]
|  | • | Cloud Management: A Cloud management platform is a suite of integrated software and visibility tools that an enterprise can use to monitor and control on-premises networking equipment, such as Access Points, Switches, and Routers. |

[0001564590-19-039190:mdna:20]
|  | • | CloudStack: CloudStack is an open source cloud computing software for creating, managing, and deploying infrastructure cloud services. It uses existing hypervisors such as KVM, VMware ESXi and XenServer/XCP for virtualization. |

[0001564590-19-039190:mdna:21]
[same as prior period, unchanged from 0001564590-19-018574:mdna:16]

[0001564590-19-039190:mdna:22]
[same as prior period, unchanged from 0001564590-19-018574:mdna:17]

[0001564590-19-039190:mdna:23]
30

[0001564590-19-039190:mdna:24]
[same as prior period, unchanged from 0001564590-19-018574:mdna:18]

[0001564590-19-039190:mdna:25]
[same as prior period, unchanged from 0001564590-19-018574:mdna:19]

[0001564590-19-039190:mdna:26]
[same as prior period, unchanged from 0001564590-19-018574:mdna:20]

[0001564590-19-039190:mdna:27]
[same as prior period, unchanged from 0001564590-19-018574:mdna:21]

[0001564590-19-039190:mdna:28]
[same as prior period, unchanged from 0001564590-19-018574:mdna:22]

[0001564590-19-039190:mdna:29]
[same as prior period, unchanged from 0001564590-19-018574:mdna:23]

[0001564590-19-039190:mdna:30]
|  | • | Internet of Things (IoT): the extension of IP networking into physical devices and everyday objects, such as temperature sensors and appliances. IoT devices are technically a superset of all connected devices, but the term is generally used to refer to devices not directly associated to a user (i.e., not often used for Laptops or Smart Phones). |

[0001564590-19-039190:mdna:31]
|  | • | Internet Protocol: Internet Protocol (“IP”) is the principal set (or communications protocol) of digital message formats and rules for exchanging messages between computers across a single network or a series of interconnected networks, using the Internet Protocol Suite (often referred to as TCP/IP). |

[0001564590-19-039190:mdna:32]
[same as prior period, unchanged from 0001564590-19-018574:mdna:25]

[0001564590-19-039190:mdna:33]
[same as prior period, unchanged from 0001564590-19-018574:mdna:26]

[0001564590-19-039190:mdna:34]
[same as prior period, unchanged from 0001564590-19-018574:mdna:28]

[0001564590-19-039190:mdna:35]
|  | • | OpenFlow: OpenFlow (“OF”) is considered one of the first software-defined networking (“SDN”) standards. It originally defined the communication protocol in SDN environments that enables the SDN Controller to directly interact with the forwarding plane of network devices such as switches and routers, both physical and virtual (hypervisor-based), so it can better adapt to changing business requirements. (Source: SDx Central) |

[0001564590-19-039190:mdna:36]
[same as prior period, unchanged from 0001564590-19-018574:mdna:29]

[0001564590-19-039190:mdna:37]
|  | • | Private Pre-Shared Key: Private Pre-Shared Keys are unique pre-shared keys created for individuals or groups of users on the same SSID, which mimics the security and control of Enterprise 802.1X authentication without requiring authentication servers or certificates. |

[0001564590-19-039190:mdna:38]
|  | • | RESTful APIs: A RESTful API is an application program interface (API) that uses HTTP requests to GET, PUT, POST and DELETE data. |

[0001564590-19-039190:mdna:39]
[same as prior period, unchanged from 0001564590-19-018574:mdna:30]

[0001564590-19-039190:mdna:40]
[same as prior period, unchanged from 0001564590-19-018574:mdna:31]

[0001564590-19-039190:mdna:41]
[same as prior period, unchanged from 0001564590-19-018574:mdna:27]

[0001564590-19-039190:mdna:42]
[same as prior period, unchanged from 0001564590-19-018574:mdna:32]

[0001564590-19-039190:mdna:43]
[same as prior period, unchanged from 0001564590-19-018574:mdna:33]

[0001564590-19-039190:mdna:44]
[same as prior period, unchanged from 0001564590-19-018574:mdna:34]

[0001564590-19-039190:mdna:45]
[same as prior period, unchanged from 0001564590-19-018574:mdna:35]

[0001564590-19-039190:mdna:46]
[same as prior period, unchanged from 0001564590-19-018574:mdna:36]

[0001564590-19-039190:mdna:47]
We estimate the total addressable market Extreme’s products, solutions, and services and geographic focus consisting of Wireless Local Area Networks (WLAN), Data Center networking, Ethernet switching, and campus LAN products allow us to address $21 billion of market opportunity, which is growing at approximately five percent per year over the next three years.

[0001564590-19-039190:mdna:48]
[same as prior period, unchanged from 0001564590-19-018574:mdna:37]

[0001564590-19-039190:mdna:49]
|  | • | Ethernet (wired and wireless) has solidified its role in both public and private networks through its scalability, adaptability, and cost-effectiveness. At the same time, the enterprises and service providers expect the technology to follow a price-performance curve that mandates continued innovation by Ethernet vendors, and the introduction of 5G cellular networking provides another medium for wireless connectivity that requires significant upgrades to existing Ethernet infrastructure. |

[0001564590-19-039190:mdna:50]
|  | • | The mobile workforce continues to proliferate. Employees expect high-quality and secure access to corporate resources in a BYOD world across a diversity of endpoints such as laptops, tablets, smart phones and wearables, whether they are within the corporate firewall or on-the-go. With Extreme software, IT departments focus their investment decisions on this mobile workforce, taking a unified view of wireless access, from the edge to the cloud. Extreme offers end-to-end solutions that permit IT managers to meet employee expectations and to maximize IT return on investment. |

[0001564590-19-039190:mdna:51]
[same as prior period, unchanged from 0001564590-19-018574:mdna:40]

[0001564590-19-039190:mdna:52]
|  | • | The Internet of Things. The Internet of Things is having dramatic effects on network infrastructure in healthcare, education, manufacturing, government and retail as more “smart” devices are entering the networks. These devices pose opportunities as well as threats to the network. Extreme’s Defender for IoT delivers security for end points which have limited or even no embedded security capabilities. It is especially targeted to aging wired devices, that need to roam around a room, a building, or even a campus, and complements a customer’s existing security infrastructure by adding in-line defense directly at the IoT device itself. |

[0001564590-19-039190:mdna:53]
|  | • | Growing usage of the cloud. Enterprises have migrated increasing numbers of applications and services to either private clouds or public clouds offered by third parties. In either case, the network infrastructure must adapt to this new dynamic environment. Intelligence and automation are key if enterprises are to derive maximum benefit from their cloud deployments. Ethernet speeds, scaling from 10 Gigabits per second ("G") to 400G, provide the infrastructure for both private and public clouds. In addition, there is growing interest in SDN approaches that may include technologies such as OpenFlow, OpenStack, and CloudStack for increased network agility. |

[0001564590-19-039190:mdna:54]
|  | • | Vendor consolidation is expected to continue. Consolidation of vendors within the enterprise network equipment market and between adjacent markets (storage, security, wireless & voice software and applications) continues to gain momentum. We identified this trend in 2013 with our acquisition of Enterasys. Further, we believe customers are demanding more end-to-end, integrated networking solutions. To address this demand, we acquired the WLAN Business of Zebra in October 2016, the Campus Fabric Business from Avaya in July 2017, and the Data Center Business from Brocade in October 2017, and acquired the entire Cloud Networking portfolio from Aerohive Networks in August 2019. |

[0001564590-19-039190:mdna:55]
[same as prior period, unchanged from 0001564590-19-018574:mdna:45]

[0001564590-19-039190:mdna:56]
[same as prior period, unchanged from 0001564590-19-018574:mdna:46]

[0001564590-19-039190:mdna:57]
|  | ➣ | We have been shipping ExtremeManagement Center since fiscal year 2017. This innovative software helps IT network administrators to navigate the unprecedented demands caused by the surge of IoT devices and technology. The addition of Aerohive brings us a cloud equivalent option to service all of our customer verticals and requirements. |

[0001564590-19-039190:mdna:58]
[same as prior period, unchanged from 0001564590-19-018574:mdna:48]

[0001564590-19-039190:mdna:59]
|  | ➣ | We announced cloud offerings in April 2016 and continue to enhance our portfolio for providing cloud infrastructure management and visibility with Extreme Workflow Composer and our Network Packet Brokers, as well as with our acquisition of Aerohive in August 2019. Extreme began participation in the OpenSwitch program in May 2016, and recently moved Stackstorm, an open source project acquired with Brocade in 2017, to the Linux Foundation. |

[0001564590-19-039190:mdna:60]
[same as prior period, unchanged from 0001564590-19-018574:mdna:50]

[0001564590-19-039190:mdna:61]
[same as prior period, unchanged from 0001564590-19-018574:mdna:51]

[0001564590-19-039190:mdna:62]
[same as prior period, unchanged from 0001564590-19-018574:mdna:52]

[0001564590-19-039190:mdna:63]
|  | ➣ | We began shipping our 802.11ax/Wi-Fi 6 access points in the fiscal year 2019, which are designed to deliver secure, intelligent, and scalable Wi-Fi connectivity in the most dense, crowded environments, such as stadiums, and in any weather condition – giving every customer access to high-efficiency Wi-Fi just like in NFL stadiums. With our acquisition of Aerohive, we now have the broadest portfolio of Wi-Fi 6 access points in the industry. |

[0001564590-19-039190:mdna:64]
[same as prior period, unchanged from 0001564590-19-018574:mdna:54]

[0001564590-19-039190:mdna:65]
We are focused on delivering end-to-end networking and software solutions for today’s enterprise environments. From wireless and wired access technologies, through the campus, core and into the datacenter, Extreme is developing solutions to deliver outstanding business outcomes for our customers. Leveraging a unified management approach, both on premises and in the cloud, we continue to accelerate adoption and delivery of new technologies in support of emerging trends in enterprise networking. We continue to execute on our growth objectives by maximizing customer, partner, and shareholder value.

[0001564590-19-039190:mdna:66]
In fiscal 2017, we completed the acquisition of the WLAN Business from Zebra. In fiscal 2018, we completed the acquisitions of the Campus Fabric Business from Avaya and the Data Center Business from Brocade. In August 2019, we acquired the entire Cloud Networking portfolio from Aerohive. These acquisitions support our growth strategy to lead the enterprise network equipment market with end-to-end software-driven cloud and on-premises solutions for enterprise customers from the data center to the wireless edge.  After the closing of the acquisitions of the Campus Fabric Business and Data Center Business, Extreme immediately became a networking industry leader with more than 30,000 customers. In addition, we believe the addition of Aerohive will bring us another 20,000+ customers and solidify our position as the third ranked networking vendor in the United States and the second ranked cloud networking provider globally.  As a network switching leader in enterprise, datacenter and cloud, we combine and extend our world-class products and technologies to provide customers with some of the most advanced, high performance and open solutions in the market as well as a superb overall customer experience.  The combination of all the Extreme ElementsTM is significant in that it brings together distinct strengths addressing the key areas of the network, from unified wired and wireless edge, to the enterprise core, to the data center and to the cloud to offer a complete, unified portfolio of software-driven network access solutions.

[0001564590-19-039190:mdna:67]
[same as prior period, unchanged from 0001564590-19-018574:mdna:57]

[0001564590-19-039190:mdna:68]
[same as prior period, unchanged from 0001564590-19-018574:mdna:58]

[0001564590-19-039190:mdna:69]
[same as prior period, unchanged from 0001564590-19-018574:mdna:59]

[0001564590-19-039190:mdna:70]
33

[0001564590-19-039190:mdna:71]
[same as prior period, unchanged from 0001564590-19-018574:mdna:60]

[0001564590-19-039190:mdna:72]
[same as prior period, unchanged from 0001564590-19-018574:mdna:61]

[0001564590-19-039190:mdna:73]
|  | • | Enable a common fabric to simplify and automate the network. Fabric technologies virtualize the network infrastructure (decoupling network services from physical connectivity) which enables network services to be turned up faster, with lower likelihood of error. They make the underlying network much easier to design, implement, manage and troubleshoot. |

[0001564590-19-039190:mdna:74]
|  | • | Software-driven networking services-led solutions. Our software-driven solutions provide visibility, control and strategic intelligence from the Edge to the Cloud, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points, WLAN controllers, routers, and an extensive portfolio of software applications that deliver AI-enhanced access control, network and application analytics, as well as network management. All can be managed, assessed and controlled from one single pane of glass on premises or from the cloud. |

[0001564590-19-039190:mdna:75]
|  | • | Offer customers choice – cloud or on premises. We leverage cloud where it makes sense for our customers and provide on premises solutions where customers need it. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what’s going on across the network and applications in real time – who, when, and what is connected to the network, which is critical for BYOD and IoT. |

[0001564590-19-039190:mdna:76]
|  | • | Enable IoT without additional IT resources. In a recent IoT IT infrastructure survey, enterprise IT decision makers across industry verticals indicated their preference to opt for their existing wireless connectivity infrastructure to support IoT devices. These preferences will place unprecedented demand on network administrators to enhance management capabilities, scalability and programmability of the enterprise networks they manage without additional IT resources. |

[0001564590-19-039190:mdna:77]
|  | • | Provide a strong value proposition for our customers. Our cloud-managed wired and wireless networking solutions provide additional choice and flexibility with cloud or on-premises options for device and application management coupled with our award-winning services and support. This delivers a strong value proposition to the following customers and applications: |

[0001564590-19-039190:mdna:78]
[same as prior period, unchanged from 0001564590-19-018574:mdna:67]

[0001564590-19-039190:mdna:79]
|  | ○ | Enterprises and organizations in education, healthcare, retail, manufacturing, hospitality, transportation and logistics, and government agencies use our solutions for their mobile campus and backbone networks. |

[0001564590-19-039190:mdna:80]
|  | ○ | Enterprises, universities, stadiums, healthcare, and hospitality organizations use our solutions to enable better visibility and control of their data processing and analytics requirements. |

[0001564590-19-039190:mdna:81]
[same as prior period, unchanged from 0001564590-19-018574:mdna:70]

[0001564590-19-039190:mdna:82]
|  | • | Extend switching and routing technology leadership. Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience and our operating systems - the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud, etc. Furthermore, our network operating systems, our primary merchant silicon vendor, and select manufacturing partners permit us to leverage our engineering investment. We have invested in engineering resources to create leading-edge technologies to increase the performance and functionality of our products, and as a direct result, the value of our solution to our current and future customers. We look for maximum synergies from our engineering investment in our targeted verticals. |

[0001564590-19-039190:mdna:83]
|  | • | Expand Wi-Fi technology leadership. Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The increase in demand being seen today, fueled by more users with multiple devices, increases the expectation that everything will just work. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. This new “unified access layer” requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. Our unified access layer portfolio provides intelligence for the wired/wireless edge and is enhanced by our 3rd generation cloud architecture with machine learning and AI-driven insights. |

[0001564590-19-039190:mdna:84]
[same as prior period, unchanged from 0001564590-19-018574:mdna:74]

[0001564590-19-039190:mdna:85]
[same as prior period, unchanged from 0001564590-19-018574:mdna:75]

[0001564590-19-039190:mdna:86]
[same as prior period, unchanged from 0001564590-19-018574:mdna:76]

[0001564590-19-039190:mdna:87]
[same as prior period, unchanged from 0001564590-19-018574:mdna:77]

[0001564590-19-039190:mdna:88]
[same as prior period, unchanged from 0001564590-19-018574:mdna:78]

[0001564590-19-039190:mdna:89]
|  | • | Expand market penetration by targeting high-growth market segments. Within the Campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our Data Center approach leverages our product portfolio to address the needs of public and private Cloud Data Center providers. Within the Campus we also target the high-growth physical security market, converging technologies such as Internet Protocol (“IP”) video across a common Ethernet infrastructure in conjunction with technology partners. Cloud Networking is the fastest growing segment of WLAN growth, with a 15% projected compound annual growth rate year over year (compared to low single digits for the WLAN industry as a whole), and our focus is on expanding our technology foothold in this key segment with the acquisition of Aerohive to accelerate not only cloud management adoption, but also subscription-based licensing (SaaS) consumption. |

[0001564590-19-039190:mdna:90]
|  | • | Leverage and expand multiple distribution channels. We distribute our products through select distributors, a large number of resellers and system-integrators worldwide, and several large strategic partners. We maintain a field sales force to support our channel partners and to sell directly to certain strategic accounts. As an independent networking vendor, we seek to provide products that, when combined with the offerings of our channel partners, create compelling solutions for end-user customers. |

[0001564590-19-039190:mdna:91]
[same as prior period, unchanged from 0001564590-19-018574:mdna:81]

[0001564590-19-039190:mdna:92]
We seek to differentiate ourselves in the market by delivering a value proposition based on a software-driven approach to network management, control and analytics.

[0001564590-19-039190:mdna:93]
Our key points of differentiation include:

[0001564590-19-039190:mdna:94]
|  | • | Extreme ElementsTM.. Extreme Elements are the building blocks that enable the creation of an Autonomous Network to deliver the positive outcomes important to customer organizations, including those in education, healthcare, retail, manufacturing, transportation and logistics, and government. Combining architecture, automation, and artificial intelligence, Extreme Elements enable customers to get what they need, when and where they need it. |

[0001564590-19-039190:mdna:95]
35

[0001564590-19-039190:mdna:96]
|  | • | Cloud-Driven end-to-end networking solutions. The acquisition of Aerohive enhances our cloud offering with a 3rd generation cloud with Machine Learning/Artificial Intelligence insights and analytics that we intend to expand to all the Extreme ElementsTM. This breadth of coverage from the edge to the enterprise data center will be unique in the industry, and cloud networking is the fastest growing segment of the networking industry. |

[0001564590-19-039190:mdna:97]
|  | • | Data center to access edge wired and wireless solutions. Extreme offers a complete, unified portfolio of software-driven network access solutions from the edge to the cloud. We have the latest in wireless access points for both outdoor and indoor use plus a complete line of networking options for the Campus, Core, and Data Center, all of which are enhanced with our extensive portfolio of intelligent applications. |

[0001564590-19-039190:mdna:98]
|  | • | Multi-vendor management from a “single pane-of-glass”. Extreme’s Management Center (“XMC”) is a single unified management system that is designed to provide visibility, security, and control across the entire network. This can make the network easier to manage and troubleshoot, often with lower operating expenses. Extreme’s software can manage third-party vendors’ network devices, allowing our customers to potentially maximize device lifespan and protect investments. |

[0001564590-19-039190:mdna:99]
|  | • | Software-driven vertical solutions. Extreme’s software-driven solutions are designed to be easily adaptable to vertical solutions in industries such as healthcare, education, manufacturing, retail, transportation and logistics, government and hospitality. Extreme solutions are also designed to be well-suited for vertical-specific partners in these industries. |

[0001564590-19-039190:mdna:100]
|  | • | Extreme Validated Design. Helping customers consider, select, and deploy data center network solutions for current and planned needs is our mission. Extreme Validated Designs offer a fast track to success by accelerating that process. Validated designs are repeatable reference network architectures that have been engineered and tested to address specific use cases and deployment scenarios. |

[0001564590-19-039190:mdna:101]
|  | • | Application-aware Quality of Service (“QoS”) and analytics. Extreme has innovative analytic software that enables our customers to see application usage across the network and apply policies that maximize network capabilities. This allows our customers to improve the user experience. |

[0001564590-19-039190:mdna:102]
|  | • | Built-in identity and access control. Our network access control and identity management solutions are delivered with our network infrastructure to reduce the need to add expensive software or hardware that may require complex compatibility testing. |

[0001564590-19-039190:mdna:103]
|  | • | Easier policy assignment and SDN. Our software applications allow our customers to assign policy across the entire network, and Extreme Workflow Composer improves IT agility by automating the entire network lifecycle—including initial provisioning, configuration, validation, and troubleshooting/auto-remediation—with event-driven automation. The SDN component adds versatility for implementing policies that increase network utilization. |

[0001564590-19-039190:mdna:104]
|  | • | 100% in-sourced tech support. ExtremeWorks delivers best in class customer support in the industry with 92% first call resolution through a 100% in-sourced support model. |

[0001564590-19-039190:mdna:105]
|  | • | Strengthens the Channel. Extreme sells products primarily through an ecosystem of channel partners which combine our portfolio elements together to create customized IT solutions for end user customers. |

[0001564590-19-039190:mdna:106]
[same as prior period, unchanged from 0001564590-19-018574:mdna:82]

[0001564590-19-039190:mdna:107]
During the first quarter of fiscal 2020, we achieved the following results:

[0001564590-19-039190:mdna:108]
|  | • | Net revenues of $255.5 million compared to $239.9 million in the first quarter of fiscal 2019. |

[0001564590-19-039190:mdna:109]
|  | • | Product revenue of $185.1 million compared to $177.7 million in the first quarter of fiscal 2019. |

[0001564590-19-039190:mdna:110]
|  | • | Service revenue of $70.4 million compared to $62.2 million in the first quarter of fiscal 2019. |

[0001564590-19-039190:mdna:111]
|  | • | Total gross margin of 53.7% of net revenues compared to 55.1% of net revenues in the first quarter of fiscal 2019. |

[0001564590-19-039190:mdna:112]
|  | • | Operating loss of $32.2 million compared to an operating loss of $5.0 million in the first quarter of fiscal 2019. |

[0001564590-19-039190:mdna:113]
|  | • | Net loss of $37.7 million compared to a net loss of $9.1 million in the first quarter of fiscal 2019. |

[0001564590-19-039190:mdna:114]
During the first three months of fiscal 2020, we reflected the following results:

[0001564590-19-039190:mdna:115]
|  | • | Cash flow used by operating activities of $0.2 million compared to cash flow provided by operating activities of $34.3 million in the three months ended September 30, 2018. Cash and cash equivalents of $131.4 million compared to $169.6 million as of June 30, 2019. |

[0001564590-19-039190:mdna:116]
[same as prior period, unchanged from 0001564590-19-018574:mdna:92]

[0001564590-19-039190:mdna:117]
[same as prior period, unchanged from 0001564590-19-018574:mdna:93]

[0001564590-19-039190:mdna:118]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |  | $ Change |  |  | % Change |  |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 185,134 |  |  | $ | 177,720 |  |  | $ | 7,414 |  |  |  | 4.2 | % |  |
| Percentage of net revenue |  |  | 72.5 | % |  |  | 74.1 | % |  |  |  |  |  |  |  |  |  |
| Service |  |  | 70,372 |  |  |  | 62,166 |  |  |  | 8,206 |  |  |  | 13.2 | % |  |
| Percentage of net revenue |  |  | 27.5 | % |  |  | 25.9 | % |  |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 255,506 |  |  | $ | 239,886 |  |  | $ | 15,620 |  |  |  | 6.5 | % |  |

[0001564590-19-039190:mdna:119]
Product revenue increased $7.4 million or 4.2% for the three months ended September 30, 2019, as compared to the corresponding period of fiscal 2019. The increase in product revenues was attributable to growth related to the acquisition of Aerohive offset by lower legacy revenue in the Americas and EMEA.

[0001564590-19-039190:mdna:120]
Service revenue increased $8.2 million, or 13.2% for the three months ended September 30, 2019.  The increase in service revenues was attributable to growth related to the acquisition of Aerohive, as well as higher legacy maintenance revenue.

[0001564590-19-039190:mdna:121]
[same as prior period, unchanged from 0001564590-19-018574:mdna:98]

[0001564590-19-039190:mdna:122]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |  | $ Change |  |  | % Change |  |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 93,743 |  |  | $ | 94,177 |  |  | $ | (434 | ) |  |  | (0.5 | )% |  |
| Percentage of product revenue |  |  | 50.6 | % |  |  | 53.0 | % |  |  |  |  |  |  |  |  |  |
| Service |  |  | 43,500 |  |  |  | 37,894 |  |  |  | 5,606 |  |  |  | 14.8 | % |  |
| Percentage of service revenue |  |  | 61.8 | % |  |  | 61.0 | % |  |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 137,243 |  |  | $ | 132,071 |  |  | $ | 5,172 |  |  |  | 3.9 | % |  |
| Percentage of net revenues |  |  | 53.7 | % |  |  | 55.1 | % |  |  |  |  |  |  |  |  |  |

[0001564590-19-039190:mdna:123]
Product gross profit decreased $0.4 million or 0.5% for the three months ended September 30, 2019, as compared to the corresponding period in fiscal 2019. The decrease in product gross profit were primarily due to higher excess and obsolete inventory charges of $4.6 million, the expensing of the fair value step-up of inventories acquired from Aerohive of $3.9 million, amortization of developed technology intangible assets of $0.9 million and higher warranty costs of $1.0 million.  This was offset by gross profit from higher revenues, more favorable manufacturing costs due to cost reduction efforts and lower integration expenses of $1.7 million.

[0001564590-19-039190:mdna:124]
Service gross profit increased $5.6 million or 14.8% for the three months ended September 30, 2019, as compared to the corresponding period in fiscal 2018.  The increases were primarily due to a higher level of service revenues related to the acquisition of the Aerohive, partially offset by higher service material costs and personnel costs due to increased headcount to support acquired contracts as well as amortization of developed technology intangible asset of $0.6 million.

[0001564590-19-039190:mdna:125]
[same as prior period, unchanged from 0001564590-19-018574:mdna:103]

[0001564590-19-039190:mdna:126]
[same as prior period, unchanged from 0001564590-19-018574:mdna:104]

[0001564590-19-039190:mdna:127]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |  | $ Change |  |  | % Change |  |  |
| Research and development |  | $ | 59,116 |  |  | $ | 51,241 |  |  | $ | 7,875 |  |  |  | 15.4 | % |  |
| Sales and marketing |  |  | 71,357 |  |  |  | 67,582 |  |  |  | 3,775 |  |  |  | 5.6 | % |  |
| General and administrative |  |  | 14,982 |  |  |  | 12,771 |  |  |  | 2,211 |  |  |  | 17.3 | % |  |
| Acquisition and integration costs |  |  | 15,925 |  |  |  | 2,546 |  |  |  | 13,379 |  |  |  | 525.5 | % |  |
| Restructuring charges, net of reversals |  |  | 6,137 |  |  |  | 808 |  |  |  | 5,329 |  |  |  | 659.5 | % |  |
| Amortization of intangibles |  |  | 1,930 |  |  |  | 2,141 |  |  |  | (211 | ) |  |  | (9.9 | )% |  |
| Total operating expenses |  | $ | 169,447 |  |  | $ | 137,089 |  |  | $ | 32,358 |  |  |  | 23.6 | % |  |

[0001564590-19-039190:mdna:128]
[same as prior period, unchanged from 0001564590-19-018574:mdna:106]

[0001564590-19-039190:mdna:129]
[same as prior period, unchanged from 0001564590-19-018574:mdna:107]

[0001564590-19-039190:mdna:130]
Research and development expenses increased by $7.9 million or 15.4% for the three months ended September 30, 2019, as compared to the corresponding period of fiscal 2019.  The increased in research and development expenses was due to $5.4 million of salary and compensation costs, $1.6 million increase related to third-party design and engineering collaboration charges, $0.2 million increased professional and contractor fees, a $0.2 million increase in travel costs and $0.5 million in increased facility and information technology costs.

[0001564590-19-039190:mdna:131]
[same as prior period, unchanged from 0001564590-19-018574:mdna:110]

[0001564590-19-039190:mdna:132]
[same as prior period, unchanged from 0001564590-19-018574:mdna:111]

[0001564590-19-039190:mdna:133]
Sales and marketing expenses increased by $3.8 million or 5.6% for the three months ended September 30, 2019, as compared to the corresponding period of fiscal 2019.  The increase was primarily due to $4.1 million of personnel costs, $1.3 million of professional fees and $0.7 million of increased facility and information technology costs partially offset by a $3.3 million reduction in travel and sales promotion costs.

[0001564590-19-039190:mdna:134]
[same as prior period, unchanged from 0001564590-19-018574:mdna:114]

[0001564590-19-039190:mdna:135]
[same as prior period, unchanged from 0001564590-19-018574:mdna:115]

[0001564590-19-039190:mdna:136]
General and administrative expenses increased by $2.2 million or 17.3% for the three months ended September 30, 2019, as compared to the corresponding period of fiscal 2019, primarily due to the acquisition of Aerohive Inc. The increase in general and administrative expenses was primarily due to $1.4 million of increased personnel costs, $0.3 million in higher facility and information technology costs and $0.5 million in professional fees.

[0001564590-19-039190:mdna:137]
Acquisition and Integration Costs

[0001564590-19-039190:mdna:138]
During the three months ended September 30, 2019, we incurred $15.9 million of integration costs including a $6.8 million compensation charge for certain Aerohive Executives’ stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts.  Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for Aerohive employees.

[0001564590-19-039190:mdna:139]
For the three months ended September 30, 2018, we incurred $2.5 million of integration costs related to the acquisitions of the Campus Fabric and Data Center Businesses.

[0001564590-19-039190:mdna:140]
[same as prior period, unchanged from 0001564590-19-018574:mdna:123]

[0001564590-19-039190:mdna:141]
For the three months ended September 30, 2019 we recorded restructuring charges of $6.1 million. The charges consisted of excess facility charges of $3.9 million for impairment of right-of-use assets related to our South San Jose California and Salem New Hampshire facilities.  Additionally, we continued our reduction-in-force initiative begun in the fourth quarter of fiscal 2019 and we recorded severance and benefits charges of approximately $2.2 million.

[0001564590-19-039190:mdna:142]
For the three months ended September 30, 2018, we recorded restructuring charges of $0.8 million related to a reduction-in-force associated with in the fourth quarter of fiscal 2018.

[0001564590-19-039190:mdna:143]
[same as prior period, unchanged from 0001564590-19-018574:mdna:125]

[0001564590-19-039190:mdna:144]
During the three months ended September 30, 2019 and 2018, we recorded $1.9 million and $2.1 million, respectively, of operating expenses for amortization of intangibles in the accompanying condensed consolidated statements of operations.  The decrease was mainly due to lower amortization related to the acquired intangibles from previous acquisitions becoming fully amortized offset by amortization of acquired intangibles from the Aerohive acquisition.

[0001564590-19-039190:mdna:145]
[same as prior period, unchanged from 0001564590-19-018574:mdna:128]

[0001564590-19-039190:mdna:146]
During the three months ended September 30, 2019 and 2018, we recorded $5.2 million and $3.5 million, respectively, in interest expense.  The increase in interest expense was primarily driven by higher outstanding loan balances and other charges due to refinancing our Credit Agreement.

[0001564590-19-039190:mdna:147]
[same as prior period, unchanged from 0001564590-19-018574:mdna:131]

[0001564590-19-039190:mdna:148]
During the three months ended September 30, 2019 and 2018, we recorded income of $0.6 million and $0.5 million, respectively, in other income (expense), net. The change for the three months ended September 30, 2019 was primarily due to foreign exchange gains and losses from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0001564590-19-039190:mdna:149]
[same as prior period, unchanged from 0001564590-19-018574:mdna:134]

[0001564590-19-039190:mdna:150]
For the three months ended September 30, 2019 and 2018, we recorded an income tax provision of $1.6 million and $1.4 million, respectively.

[0001564590-19-039190:mdna:151]
The income tax provisions for the three months ended September 30, 2019 and 2018, consisted primarily of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business the Data Center Business, and (4) state taxes in jurisdictions where the Company has no remaining state Net Operating Losses (“NOLs”).

[0001564590-19-039190:mdna:152]
[same as prior period, unchanged from 0001564590-19-018574:mdna:140]

[0001564590-19-039190:mdna:153]
[same as prior period, unchanged from 0001564590-19-018574:mdna:141]

[0001564590-19-039190:mdna:154]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2019, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0001564590-19-039190:mdna:155]
[same as prior period, unchanged from 0001564590-19-018574:mdna:143]

[0001564590-19-039190:mdna:156]
[same as prior period, unchanged from 0001564590-19-018574:mdna:144]

[0001564590-19-039190:mdna:157]
[same as prior period, unchanged from 0001564590-19-018574:mdna:145]

[0001564590-19-039190:mdna:158]
[same as prior period, unchanged from 0001564590-19-018574:mdna:146]

[0001564590-19-039190:mdna:159]
[same as prior period, unchanged from 0001564590-19-018574:mdna:147]

[0001564590-19-039190:mdna:160]
[same as prior period, unchanged from 0001564590-19-018574:mdna:148]

[0001564590-19-039190:mdna:161]
[same as prior period, unchanged from 0001564590-19-018574:mdna:149]

[0001564590-19-039190:mdna:162]
The following summarizes information regarding our cash, cash equivalents, and short-term investments and working capital (in thousands):

[0001564590-19-039190:mdna:163]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Cash and cash equivalents |  | $ | 131,369 |  |  | $ | 169,607 |  |
| Short-term investments |  |  | 29,705 |  |  |  | — |  |
| Total cash, cash equivalents, and short-term investments |  | $ | 161,074 |  |  | $ | 169,607 |  |
| Working capital |  | $ | 23,257 |  |  | $ | 85,960 |  |

[0001564590-19-039190:mdna:164]
As of September 30, 2019, our principal sources of liquidity consisted of cash, cash equivalents, and short-term investments of $161.1 million, accounts receivable, net of $152.3 million and available borrowings from our five-year 2019 Revolving Facility of $70.6 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $161.1 million of cash, cash equivalents, and short-term investments at September 30, 2019 and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our principal uses of cash for at least the next 12 months.

[0001564590-19-039190:mdna:165]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its common stock for two years from the date of authorization, of which $15.0 million was used for repurchases in the second quarter of fiscal 2019.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended September 30, 2019, we did not repurchase any shares.

[0001564590-19-039190:mdna:166]
In connection with the acquisition of Aerohive as discussed in Note 4 of the accompanying condensed consolidated financial statements included elsewhere in this Report, as of August 9, 2019, we amended the 2018 Credit Agreement and entered into the 2019 Credit Agreement, by and among us, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (“2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (2019 Revolving Facility”).  In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-19-039190:mdna:167]
At our election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s Consolidated Leverage Ratio. All Eurodollar loans are subject to a Base Rate floor of 0.00%. The 2019 Credit Agreement is secured by substantially all of our assets.

[0001564590-19-039190:mdna:168]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-19-039190:mdna:169]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.  At September 30, 2019, we were in compliance with the covenants of the 2019 Credit Agreement.

[0001564590-19-039190:mdna:170]
[same as prior period, unchanged from 0001564590-19-018574:mdna:157]

[0001564590-19-039190:mdna:171]
[same as prior period, unchanged from 0001564590-19-018574:mdna:158]

[0001564590-19-039190:mdna:172]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Net cash (used in) provided by operating activities |  | $ | (202 | ) |  | $ | 34,330 |  |
| Net cash used in investing activities |  |  | (209,194 | ) |  |  | (6,690 | ) |
| Net cash provided by (used in) financing activities |  |  | 171,387 |  |  |  | (8,179 | ) |
| Foreign currency effect on cash |  |  | (229 | ) |  |  | (433 | ) |
| Net (decrease) increase in cash |  | $ | (38,238 | ) |  | $ | 19,028 |  |

[0001564590-19-039190:mdna:173]
Net Cash (Used in) Provided by Operating Activities

[0001564590-19-039190:mdna:174]
Cash flows used in operations in the three months ended September 30, 2019, were $0.2 million, including our net loss of $37.7 million and non-cash expenses of $34.1 million for items such as amortization of intangibles, amortization of right-of-use assets, stock-based compensation, depreciation, restructuring, deferred income taxes and imputed interest.  Other sources of cash for the current quarter included a decrease in accounts receivables and increases in deferred revenues. This was fully offset by decreases in accounts payable, accrued compensation, other current liabilities and operating lease liabilities, and increases in inventories.

[0001564590-19-039190:mdna:175]
Cash flows provided by operations in the three months ended September 30, 2018 were $34.3 million, including our net loss of $9.1 million and non-cash expenses of $21.8 million for items such as amortization of intangibles, stock-based compensation, depreciation, deferred income taxes and imputed interest.  Other sources of cash for the quarter included a decrease in accounts receivables and inventories and increases in deferred revenues and other current and long-term liabilities. This was partially offset by decreases in accounts payable and accrued compensation.

[0001564590-19-039190:mdna:176]
[same as prior period, unchanged from 0001564590-19-018574:mdna:163]

[0001564590-19-039190:mdna:177]
Cash flows used in investing activities in the three months ended September 30, 2019 were $209.2 million, including $219.5 million for the acquisition of Aerohive (net of cash acquired), purchases of property and equipment of $5.2 million, which was partially offset by proceeds of $15.5 million related to the maturity of short-term investments.

[0001564590-19-039190:mdna:178]
Cash flows used in investing activities in the three months ended September 30, 2018 were $6.7 million which consisted of purchases of property and equipment of $7.4 million and proceeds of $0.7 million related to the sale of marketable equity securities.

[0001564590-19-039190:mdna:179]
[same as prior period, unchanged from 0001564590-19-018574:mdna:166]

[0001564590-19-039190:mdna:180]
Cash flows provided by financing activities in the three months ended September 30, 2019 were  $171.4 million due primarily to additional borrowings of $199.5 million under our 2019 Credit Agreement to partially fund our acquisition of Aerohive, $4.1 million of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”), the exercise of stock options and net of taxes paid on vested and released stock awards. This was partially offset by debt repayments of $20.1 million, assumed from the Aerohive acquisition, payment of loan fees of $10.5 million, contingent consideration of $0.6 million, and $1.0 million for deferred payments on acquisitions.

[0001564590-19-039190:mdna:181]
Cash flows used in financing activities in the three months ended September 30, 2018 were $8.2 million, due to repayments of debt totaling $12.4 million and $1.6 million of contingent consideration and $1.0 million for deferred payments on acquisitions.  This was partially offset by $7.1 million proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”), the exercise of stock options and net of taxes paid on vested and released stock awards,

[0001564590-19-039190:mdna:182]
[same as prior period, unchanged from 0001564590-19-018574:mdna:170]

[0001564590-19-039190:mdna:183]
Foreign currency effect on cash decreased in the three months ended three months ended September 30, 2019, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, Indian Rupee and the EURO. Foreign currency effect on cash increased in the three months ended September 30, 2018, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Brazilian Real, British Pound, Indian Rupee and the EURO.

[0001564590-19-039190:mdna:184]
[same as prior period, unchanged from 0001564590-19-018574:mdna:172]

[0001564590-19-039190:mdna:185]
The following summarizes our contractual obligations as of September 30, 2019, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-19-039190:mdna:186]
|  |  | Total |  |  | Less than 1 Year |  |  |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 380,000 |  |  | $ | 19,000 |  |  |  |  | $ | 47,500 |  |  | $ | 313,500 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 88,632 |  |  |  | 20,802 |  |  |  |  |  | 38,289 |  |  |  | 29,541 |  |  |  | — |  |
| Unconditional purchase obligations |  |  | 50,642 |  |  |  | 50,642 |  |  |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 88,125 |  |  |  | 23,500 |  |  |  |  |  | 47,000 |  |  |  | 17,625 |  |  |  | — |  |
| Lease payments on operating leases. |  |  | 88,658 |  |  |  | 16,172 |  |  |  |  |  | 38,953 |  |  |  | 21,351 |  |  |  | 12,182 |  |
| Deferred payments for an acquisition |  |  | 14,000 |  |  |  | 4,000 |  |  |  |  |  | 8,000 |  |  |  | 2,000 |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 5,693 |  |  |  | 3,265 |  |  |  |  |  | 2,311 |  |  |  | 117 |  |  |  | — |  |
| Other liabilities |  |  | 1,200 |  |  |  | 247 |  |  |  |  |  | 494 |  |  |  | 459 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 716,950 |  |  | $ | 137,628 |  |  |  |  | $ | 182,547 |  |  | $ | 384,593 |  |  | $ | 12,182 |  |

[0001564590-19-039190:mdna:187]
[same as prior period, unchanged from 0001564590-19-018574:mdna:175]

[0001564590-19-039190:mdna:188]
Debt obligations related to amounts owed under our 2019 Credit Agreement.

[0001564590-19-039190:mdna:189]
Unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-19-039190:mdna:190]
[same as prior period, unchanged from 0001564590-19-018574:mdna:178]

[0001564590-19-039190:mdna:191]
[same as prior period, unchanged from 0001564590-19-018574:mdna:179]

[0001564590-19-039190:mdna:192]
[same as prior period, unchanged from 0001564590-19-018574:mdna:180]

[0001564590-19-039190:mdna:193]
[same as prior period, unchanged from 0001564590-19-018574:mdna:181]

[0001564590-19-039190:mdna:194]
[same as prior period, unchanged from 0001564590-19-018574:mdna:182]

[0001564590-19-039190:mdna:195]
[same as prior period, unchanged from 0001564590-19-018574:mdna:183]

[0001564590-19-039190:mdna:196]
We did not have any material commitments for capital expenditures as of September 30, 2019.

[0001564590-19-039190:mdna:197]
[same as prior period, unchanged from 0001564590-19-018574:mdna:185]

[0001564590-19-039190:mdna:198]
We did not have any off-balance sheet arrangements as of September 30, 2019.
