# EXTR note change history — 0001564590-19-018574 → 0001564590-19-039190


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001564590-19-039190:note_history:1]
| 10. | Commitments and Contingencies |
  (was, 2019-05-10, similarity 0.8955):
[0001564590-19-018574:note_history:1]
9.Commitments and Contingencies

- changed (2019-10-31):
[0001564590-19-039190:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that inventory and other services. As of September 30, 2019, the Company had commitments to purchase $50.6 million of inventory and other services.
  (was, 2019-05-10, similarity 0.7343):
[0001564590-19-018574:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2019, the Company had commitments to purchase $194.9 million of such inventory.  As of March 31, 2019, the Company had commitments to purchase $99.9 million of software and new product support services.

- changed (2019-10-31):
[0001564590-19-039190:note_history:3]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of September 30, 2019.
  (was, 2019-05-10, similarity 0.991):
[0001564590-19-018574:note_history:3]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.9 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of March 31, 2019.

- changed (2019-10-31):
[0001564590-19-039190:note_history:4]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017, decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 20.0 million (USD $4.8 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2019.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.
  (was, 2019-05-10, similarity 0.9952):
[0001564590-19-018574:note_history:4]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017, decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 19.9 million (USD $5.2 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of March 31, 2019.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

- changed (2019-10-31):
[0001564590-19-039190:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims of the ’296 patent and ’728 patent, and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date).  During a status conference on February 11, 2019, the Court continued the stay and set a status conference for December 2, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.
  (was, 2019-05-10, similarity 0.8984):
[0001564590-19-018574:note_history:5]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date). During a status conference on February 11, 2019, the Court continued the stay and set a status conference for December 2, 2019. The Company believes the claims are without merit and intends to defend them vigorously.

- added (2019-10-31):
[0001564590-19-039190:note_history:6]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the infringement complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action. Orckit filed its reply on September 26, 2019 and Extreme’s rejoinder is due on December 17, 2019.  The District Court Düsseldorf scheduled a hearing in this case for January 28, 2020.

- added (2019-10-31):
[0001564590-19-039190:note_history:7]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  Extreme’s answer to the EP ‘077 infringement complaint is due on November 5, 2019.  Extreme also plans to file a nullity action with the German Federal Patent Court on or before that date, seeking to invalidate the asserted patent.  No hearing has been scheduled yet in this case, which was split from the original action involving the first patent in suit.

- added (2019-10-31):
[0001564590-19-039190:note_history:8]
The Company believes that all claims are without merit and defends them vigorously.

- changed (2019-10-31):
[0001564590-19-039190:note_history:9]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co.
  (was, 2019-05-10, similarity 0.9865):
[0001564590-19-018574:note_history:9]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co., Ltd

- added (2019-10-31):
[0001564590-19-039190:note_history:10]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1 (“ZL ‘028.1”), ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2 (“ZL ‘486.2”), and ZL200610060686.9 (collectively, the “Asserted Patents”).  Each patent was asserted in a separate law suit.  The filing date for the first case is January 18, 2019, and the filing date for the rest of the cases is January 23, 2019.  The trial for the first case is currently scheduled for January 15, 2020, and trials for the rest of the cases have not yet been scheduled.  GIA has accused the Summit X440-G2-24t-10GE4 (product number: 16532), Summit X440-G2-24p-10GE4 (product number: 16533) and Summit X460-G2-24x-10GE4-Base (product number: 16705) (collectively the “Accused Products”) of infringing the Asserted Patents. GIA has also alleged that the following Extreme switch products support the same functions as the Accused Products:  Summit X440-G2 series, X450-G2 series, X460-G2 series, X620 series, X670-G2 series, X770 series, X870 series, X690 series, and X590 series.  GIA is a U.S. entity established under the laws of Delaware with its principal office in Pasadena, California.  Extreme disputes GIA’s claims and intends to defend the matter vigorously.  Additionally, Extreme has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of the ZL ‘028.1 and ZL ‘486.2 patents, but has not yet issued decisions for the remaining four patents. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

- added (2019-10-31):
[0001564590-19-039190:note_history:11]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

- added (2019-10-31):
[0001564590-19-039190:note_history:12]
In late September 2019, Extreme Networks learned of a patent infringement lawsuit filed by Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) against Aerohive Networks, Inc., its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of Chinese patent ZL02123502.3.  The complaint was received by Aerohive Networks, Inc. on October 9 and by its Chinese subsidiary on October 10.  Extreme cannot estimate at this time the possible loss or range of loss that may result from this action, but Shenzhen Dunjun claims damages in the amount of RMB 10,000,000.

- changed (2019-10-31):
[0001564590-19-039190:note_history:13]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of September 30, 2019, the Company has the outstanding indemnification claims described above.
  (was, 2019-05-10, similarity 0.9951):
[0001564590-19-018574:note_history:13]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of March 31, 2019, the Company has the outstanding indemnification claims described above.

- removed (2019-10-31):
[0001564590-19-018574:note_history:14]
In re Extreme Networks, Inc. Securities Litigation

- removed (2019-10-31):
[0001564590-19-018574:note_history:15]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013, through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018, Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties have agreed to settle the litigation.   On November 30, 2018, plaintiffs filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition. The preliminary hearing took place on March 7, 2019, and the final hearing is scheduled for June 20, 2019.

- removed (2019-10-31):
[0001564590-19-018574:note_history:16]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended. The parties agreed to settle the litigation.  On May 3, 2019, the Court gave final approval to the settlement and entered judgment terminating the case.

- removed (2019-10-31):
[0001564590-19-018574:note_history:17]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, an accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The Company believes the claims are without merit and intends to defend them vigorously.

- removed (2019-10-31):
[0001564590-19-018574:note_history:18]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six lawsuits alleging patent infringement against Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1, ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2, and ZL200610060686.9. The products at issue include the Summit X440-G2 series, X450-G2 series, X460-G2 series, X620 series, X670-G2 series, X770 series, X870 series, X690 series, and X590 series. GIA is a U.S. entity established under the laws of Delaware with its principal office in Pasadena, California. Extreme disputes GIA’s claims and intends to defend them vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001564590-19-039190:note_history:19]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2019. The results of operations for the three months ended September 30, 2019 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.
  (was, 2019-05-10, similarity 0.6824):
[0001564590-19-018574:note_history:19]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2019. The results of operations for the three and nine months ended March 31, 2019 are not necessarily indicative of the results that may be expected for fiscal 2019 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-10-31):
[0001564590-19-039190:note_history:20]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements is recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also required lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

- added (2019-10-31):
[0001564590-19-039190:note_history:21]
The Company adopted the new standards beginning with its fiscal year 2020. Topic 842 is applied on the modified retrospective method, applying the new standard to all leases existing as of July 1, 2019. The Company adopted the new standard using the effective date of July 1, 2019 as the date of initial application. Consequently, financial information has not been updated, and disclosures required under the new standard will not be provided for dates and periods prior to July 1, 2019.

- added (2019-10-31):
[0001564590-19-039190:note_history:22]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and is deemed to be a lessor.  See Note 9, Leases, for additional information regarding the Company’s leases.

- added (2019-10-31):
[0001564590-19-039190:note_history:23]
The Company recognized ROU assets of approximately $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases. See Note 9 – Leases.

- changed (2019-10-31):
[0001564590-19-039190:note_history:24]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. This guidance was effective for the Company beginning with its fiscal year 2020. It did not have a material impact on the Company’s financial statements upon adoption.
  (was, 2019-05-10, similarity 0.7568):
[0001564590-19-018574:note_history:24]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (“OIS”) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The Company is continuing to evaluate the accounting, transition and disclosure requirements of these standards, but does not believe it will have a material impact on the Company’s financial statements upon adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

- changed (2019-10-31):
[0001564590-19-039190:note_history:25]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.
  (was, 2019-05-10, similarity 0.7558):
[0001564590-19-018574:note_history:25]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period, for reporting periods for which financial statements have not yet been issued. The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. Management is currently evaluating implementation options and impact on the Company's financial statements and related disclosures.  This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

- added (2019-10-31):
[0001564590-19-039190:note_history:26]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2020. The Company is currently evaluating the impact of this new standard on its condensed consolidated financial statements and related disclosures. The Company currently plans to adopt this standard beginning with its fiscal year 2022, beginning on July 1, 2021.

- added (2019-10-31):
[0001564590-19-039190:note_history:27]
In January 2017, the FASB issued ASU 2017-04, Simplifying the Test for Goodwill Impairment (Topic 350), which removes Step 2 of the goodwill impairment test, which requires a hypothetical purchase price allocation. An impairment charge will now be the amount by which a reporting unit’s carrying value exceeds the fair value, not to exceed the carrying amount of goodwill.  This standard is effective for fiscal years beginning after December 15, 2019, with early adoption permitted The Company does not expect the adoption to have a material impact on the condensed consolidated financial statements. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

- removed (2019-10-31):
[0001564590-19-018574:note_history:28]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities. The guidance was adopted effective July 1, 2018 and the Company reclassified a $0.5 million unrealized gain, net of tax, related to its available-for-sale investments from accumulated other comprehensive loss to accumulated deficit as a cumulative-effect adjustment in the accompanying condensed consolidated balance sheets.  Future changes in fair value will be included in earnings in each period.

- removed (2019-10-31):
[0001564590-19-018574:note_history:29]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice.  The Company adopted the new guidance effective July 1, 2018. The amendments in this update have been applied on a retrospective transition method to each period presented. The adoption of this guidance did not have a material effect on the Company’s presentation of cash flows.

- removed (2019-10-31):
[0001564590-19-018574:note_history:30]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740) - Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset other than inventory when the transfer occurs. Historically GAAP had prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset has been sold outside the consolidated group.  The new guidance is effective for interim and annual reporting periods beginning after December 15, 2017. The Company adopted ASU 2016-16 effective July 1, 2018 on a modified retrospective basis. The adoption of this guidance did not have a material effect on the Company’s financial statements.

- removed (2019-10-31):
[0001564590-19-018574:note_history:31]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting, which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718.  Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The Company adopted this guidance effective July 1, 2018, on a prospective basis.  The adoption of this guidance did not have a material effect on the Company’s financial statements.

- removed (2019-10-31):
[0001564590-19-018574:note_history:32]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 is applied on the modified retrospective method through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. In addition, in December 2018 and March 2019, the FASB issued ASU No. 2018-20, Leases (Topic 842) and ASU No. 2019-01, Leases (Topic 842), respectively, which includes narrow-scope improvements for lessors to increase transparency and comparability about leasing transactions and addresses lessor implementation issues and clarifies that lessees and lessors are exempt from certain interim disclosure requirements. This guidance will become effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019. The Company‘s evaluation of the new standards are underway, and significant changes from the current guidance have been identified. The Company expects to elect certain available transitional guidance. The Company also currently expects to elect the short-term lease recognition exemption for all leases that qualify. This means, for those leases that qualify, the Company will not recognize right-of-use (“ROU”) assets or lease liabilities, and this includes not recognizing ROU assets or lease liabilities for existing short-term leases of those assets in transition. In addition, the Company currently expects to elect the practical expedient to not separate lease and non-lease components for leases of vehicles and equipment. The Company has selected, and is in the process of implementing and testing a new lease accounting system and validating its results. While the Company continues to evaluate the effect of adopting Topic 842, it expects that these new standards will have a material impact to the Company’s financial position. The Company will recognize ROU assets and lease liabilities on the consolidated balance sheets with corresponding ROU assets at the same amount as the lease liability based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases. The Company does not expect that the adoption of Topic 842 will have a material effect on operating income (loss) and net cash flows, however it will impact the classification between cash flows from operations and cash flows from financing activities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-10-31):
[0001564590-19-039190:note_history:33]
| 8. | Debt |

- changed (2019-10-31):
[0001564590-19-039190:note_history:34]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,477 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,523 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 361,000 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | — |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (7,594 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 353,406 |  |  |  | 169,739 |  |
| Total debt |  | $ | 369,929 |  |  | $ | 178,750 |  |
  (was, 2019-05-10, similarity 0.986):
[0001564590-19-018574:note_history:34]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 173,375 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,382 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 171,993 |  |  |  | 188,749 |  |
| Total debt |  | $ | 181,002 |  |  | $ | 197,756 |  |

- added (2019-10-31):
[0001564590-19-039190:note_history:35]
In connection with the acquisition of Aerohive as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

- added (2019-10-31):
[0001564590-19-039190:note_history:36]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

- changed (2019-10-31):
[0001564590-19-039190:note_history:37]
At the Company’s election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.
  (was, 2019-05-10, similarity 0.6779):
[0001564590-19-018574:note_history:37]
Borrowings under the Credit Agreement will bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s consolidated leverage ratio.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the New Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the New Term Loan in varying percentages quarterly starting September 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The Credit Agreement is secured by substantially all of the Company’s assets.

- changed (2019-10-31):
[0001564590-19-039190:note_history:38]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.
  (was, 2019-05-10, similarity 0.994):
[0001564590-19-018574:note_history:38]
The Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

- added (2019-10-31):
[0001564590-19-039190:note_history:39]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.   The Company incurred $10.5 million of deferred financing costs in conjunction which this modification of the debt and continues to amortize $1.6 million of unamortized debt issuance costs associated with the previous facility.  The interest rate as of September 30, 2019 is 5.47%

- added (2019-10-31):
[0001564590-19-039190:note_history:40]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.5 million and $0.2 million for the three months ended September 30, 2019 and 2018, respectively.

- changed (2019-10-31):
[0001564590-19-039190:note_history:41]
The Company had $70.6 million of availability under the 2019 Revolving Facility as of September 30, 2019.  The Company had $4.4 million of outstanding letters of credit as of September 30, 2019.
  (was, 2019-05-10, similarity 0.9294):
[0001564590-19-018574:note_history:41]
The Company had $35.5 million of availability under the New Revolving Facility as of March 31, 2019.  The Company had $4.5 million of outstanding letters of credit as of March 31, 2019.

- removed (2019-10-31):
[0001564590-19-018574:note_history:42]
8.Debt

- removed (2019-10-31):
[0001564590-19-018574:note_history:43]
On May 1, 2018, the Company entered into a Credit Agreement (the “Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “New Revolving Facility”) ii) a $190 million five-year term loan (the “New Term Loan”) and iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“New Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the Credit Agreement to pay off existing debt and for general corporate purposes.

- removed (2019-10-31):
[0001564590-19-018574:note_history:44]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the Credit Agreement.  Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.2 million for each of the three months ended March 31, 2019 and 2018 and totaled $0.5 million for each of the nine months ended March 31, 2019 and 2018, respectively.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001564590-19-039190:note_history:45]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,477 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,523 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 361,000 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | — |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (7,594 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 353,406 |  |  |  | 169,739 |  |
| Total debt |  | $ | 369,929 |  |  | $ | 178,750 |  |
  (was, 2019-05-10, similarity 0.986):
[0001564590-19-018574:note_history:45]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 173,375 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,382 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 171,993 |  |  |  | 188,749 |  |
| Total debt |  | $ | 181,002 |  |  | $ | 197,756 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001564590-19-039190:note_history:46]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |
| Other |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |
| Total Americas |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |
| EMEA |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |
| APAC |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |
| Total net revenues |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |
  (was, 2019-05-10, similarity 0.9634):
[0001564590-19-018574:note_history:46]
|  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |
| Other |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |
| Total Americas |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |
| EMEA |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |
| APAC |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |
| Total net revenues |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |

- removed (2019-10-31):
[0001564590-19-018574:note_history:47]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |
| Other |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |
| Total Americas |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |
| EMEA |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |
| APAC: |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |
| Total net revenues |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-10-31):
[0001564590-19-039190:note_history:48]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from software delivered as a service (“SaaS”) and service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- changed (2019-10-31):
[0001564590-19-039190:note_history:49]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2019-05-10, similarity 0.9776):
[0001564590-19-018574:note_history:49]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenue is recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2019-10-31):
[0001564590-19-039190:note_history:50]
On September 30, 2019, the Company had $273.7 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 58 percent of its remaining performance obligations as revenue in fiscal 2020, an additional 24 percent in fiscal 2021 and 18 percent of the balance thereafter.

- changed (2019-10-31):
[0001564590-19-039190:note_history:51]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.
  (was, 2019-05-10, similarity 0.8715):
[0001564590-19-018574:note_history:51]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- changed (2019-10-31):
[0001564590-19-039190:note_history:52]
Revenue recognized for the three months ended September 30, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $53.8 million and $50.6 million, respectively.
  (was, 2019-05-10, similarity 0.6444):
[0001564590-19-018574:note_history:52]
Revenue recognized for the three months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $54.8 million and $50.6 million, respectively. Revenue recognized for the nine months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $110.8 million and $66.7 million, respectively.

- changed (2019-10-31):
[0001564590-19-039190:note_history:53]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.6 million and $4.9 million at September 30, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2019 and 2018, was $2.7 million and $0.7 million, respectively. There was no impairment loss in relation to the costs capitalized.
  (was, 2019-05-10, similarity 0.9223):
[0001564590-19-018574:note_history:53]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $5.6 million and $4.3 million at March 31, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2019 and 2018, was $0.8 million and $0.5 million, respectively.  Amortization recognized during the nine months ended March 31, 2019 and 2018 was $2.2 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2019-10-31):
[0001564590-19-039190:note_history:54]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |
| Other |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |
| Total Americas |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |
| EMEA |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |
| APAC |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |
| Total net revenues |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |
  (was, 2019-05-10, similarity 0.9634):
[0001564590-19-018574:note_history:54]
|  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |
| Other |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |
| Total Americas |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |
| EMEA |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |
| APAC |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |
| Total net revenues |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |

- added (2019-10-31):
[0001564590-19-039190:note_history:55]
Included in the above amounts is approximately $3.7 million and $4.0 million of leasing revenue for the quarters ended September 30, 2019 and 2018, respectively.

- added (2019-10-31):
[0001564590-19-039190:note_history:56]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Tech Data Corporation |  | 16% |  |  | 17% |  |
| Jenne Corporation |  | 14% |  |  | 12% |  |
| Westcon Group Inc. |  | 10% |  |  | 13% |  |

- added (2019-10-31):
[0001564590-19-039190:note_history:57]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 21 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 19 | % |  |  | 35 | % |
| Westcon Group Inc. |  |  | 12 | % |  | * |  |

- removed (2019-10-31):
[0001564590-19-018574:note_history:58]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- removed (2019-10-31):
[0001564590-19-018574:note_history:59]
On March 31, 2019, the Company had $187.7 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 29 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 49 percent in fiscal 2020 and 22 percent of the balance thereafter.

- removed (2019-10-31):
[0001564590-19-018574:note_history:60]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |
| Other |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |
| Total Americas |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |
| EMEA |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |
| APAC: |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |
| Total net revenues |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |

- removed (2019-10-31):
[0001564590-19-018574:note_history:61]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Tech Data Corporation |  | 14% |  |  | 14% |  |  | 17% |  |  | 13% |  |
| Westcon Group Inc. |  | 12% |  |  | 14% |  |  | 13% |  |  | 14% |  |
| Jenne Corporation |  | 21% |  |  | 13% |  |  | 15% |  |  | 11% |  |

- removed (2019-10-31):
[0001564590-19-018574:note_history:62]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Westcon Group Inc. |  | 10% |  |  | * |  |
| Tech Data Corporation |  | * |  |  | 17% |  |
| Jenne Corporation |  | 31% |  |  | 13% |  |
| * Less than 10% of accounts receivable |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-10-31):
[0001564590-19-039190:note_history:63]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2019-05-10, similarity 0.9776):
[0001564590-19-018574:note_history:63]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenue is recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- added (2019-10-31):
[0001564590-19-039190:note_history:64]
On September 30, 2019, the Company had $273.7 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 58 percent of its remaining performance obligations as revenue in fiscal 2020, an additional 24 percent in fiscal 2021 and 18 percent of the balance thereafter.

- changed (2019-10-31):
[0001564590-19-039190:note_history:65]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.
  (was, 2019-05-10, similarity 0.8715):
[0001564590-19-018574:note_history:65]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheet. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheet on a contract-by-contract basis at the end of each reporting period.

- changed (2019-10-31):
[0001564590-19-039190:note_history:66]
Revenue recognized for the three months ended September 30, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $53.8 million and $50.6 million, respectively.
  (was, 2019-05-10, similarity 0.6444):
[0001564590-19-018574:note_history:66]
Revenue recognized for the three months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $54.8 million and $50.6 million, respectively. Revenue recognized for the nine months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $110.8 million and $66.7 million, respectively.

- changed (2019-10-31):
[0001564590-19-039190:note_history:67]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.6 million and $4.9 million at September 30, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2019 and 2018, was $2.7 million and $0.7 million, respectively. There was no impairment loss in relation to the costs capitalized.
  (was, 2019-05-10, similarity 0.9223):
[0001564590-19-018574:note_history:67]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $5.6 million and $4.3 million at March 31, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2019 and 2018, was $0.8 million and $0.5 million, respectively.  Amortization recognized during the nine months ended March 31, 2019 and 2018 was $2.2 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2019-10-31):
[0001564590-19-039190:note_history:68]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |
| Other |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |
| Total Americas |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |
| EMEA |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |
| APAC |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |
| Total net revenues |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |
  (was, 2019-05-10, similarity 0.9634):
[0001564590-19-018574:note_history:68]
|  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |
| Other |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |
| Total Americas |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |
| EMEA |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |
| APAC |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |
| Total net revenues |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |

- removed (2019-10-31):
[0001564590-19-018574:note_history:69]
On March 31, 2019, the Company had $187.7 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 29 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 49 percent in fiscal 2020 and 22 percent of the balance thereafter.

- removed (2019-10-31):
[0001564590-19-018574:note_history:70]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |
| Other |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |
| Total Americas |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |
| EMEA |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |
| APAC: |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |
| Total net revenues |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |
