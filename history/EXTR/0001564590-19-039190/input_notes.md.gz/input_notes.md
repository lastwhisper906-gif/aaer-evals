# EXTR notes — 0001564590-19-039190


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-19-039190:notes:1]
[same as prior period, unchanged from 0001564590-19-018574:notes:1]

[0001564590-19-039190:notes:2]
[same as prior period, unchanged from 0001564590-19-018574:notes:2]

[0001564590-19-039190:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted under such rules and regulations.  The condensed consolidated balance sheet at June 30, 2019 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019.

[0001564590-19-039190:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at September 30, 2019. The results of operations for the three months ended September 30, 2019 are not necessarily indicative of the results that may be expected for fiscal 2020 or any future periods.

[0001564590-19-039190:notes:5]
[same as prior period, unchanged from 0001564590-19-018574:notes:5]

[0001564590-19-039190:notes:6]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal 2020” or “2020” represent the fiscal year ending June 30, 2020.  All references herein to “fiscal 2019” or “2019” represent the fiscal year ended June 30, 2019.

[0001564590-19-039190:notes:7]
[same as prior period, unchanged from 0001564590-19-018574:notes:7]

[0001564590-19-039190:notes:8]
[same as prior period, unchanged from 0001564590-19-018574:notes:8]

[0001564590-19-039190:notes:9]
[same as prior period, unchanged from 0001564590-19-018574:notes:9]

[0001564590-19-039190:notes:10]
[same as prior period, unchanged from 0001564590-19-018574:notes:10]

[0001564590-19-039190:notes:11]
[same as prior period, unchanged from 0001564590-19-018574:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-039190:notes:12]
[same as prior period, unchanged from 0001564590-19-018574:notes:12]

[0001564590-19-039190:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2019. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0001564590-19-039190:notes:14]
Recently Adopted Accounting Pronouncements

[0001564590-19-039190:notes:15]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements is recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation are recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 is calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also required lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. Substantially all of the Company’s leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

[0001564590-19-039190:notes:16]
The Company adopted the new standards beginning with its fiscal year 2020. Topic 842 is applied on the modified retrospective method, applying the new standard to all leases existing as of July 1, 2019. The Company adopted the new standard using the effective date of July 1, 2019 as the date of initial application. Consequently, financial information has not been updated, and disclosures required under the new standard will not be provided for dates and periods prior to July 1, 2019.

[0001564590-19-039190:notes:17]
The new standard provides a number of optional practical expedients in transition. The Company elected the “package of practical expedients” which permitted the Company not to reassess under the new standard its prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provided practical expedients for ongoing accounting. The Company also elected the short-term lease recognition exemption for all leases that qualified. For those leases that qualified, existing short-term leases at the transition date and those entered into subsequent to the transition date, the Company did not recognize right-of-use assets or lease liabilities. In addition, the Company elected the practical expedient not to separate lease and non-lease components for leases except for the logistic services asset class and certain revenue subscription contracts where the Company leases its hardware products and is deemed to be a lessor.  See Note 9, Leases, for additional information regarding the Company’s leases.

[0001564590-19-039190:notes:18]
The Company recognized ROU assets of approximately $64.6 million and corresponding lease liabilities of $79.5 million on the condensed consolidated balance sheets, which was based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases. See Note 9 – Leases.

[0001564590-19-039190:notes:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. This guidance was effective for the Company beginning with its fiscal year 2020. It did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-19-039190:notes:20]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The standard was adopted on July 1, 2019 and did not have a material impact on the Company’s financial statements upon adoption.

[0001564590-19-039190:notes:21]
Recently Issued Accounting Pronouncements

[0001564590-19-039190:notes:22]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments—Credit Losses (Topic 326). The standard changes the methodology for measuring credit losses on financial instruments and the timing of when such losses are recorded. It replaces the existing incurred loss impairment model with an expected loss model. It also requires credit losses related to available-for-sale debt securities to be recognized as an allowance for credit losses rather than as a reduction to the carrying value of the securities. ASU 2016-13 is effective for fiscal years beginning after December 15, 2020. The Company is currently evaluating the impact of this new standard on its condensed consolidated financial statements and related disclosures. The Company currently plans to adopt this standard beginning with its fiscal year 2022, beginning on July 1, 2021.

[0001564590-19-039190:notes:23]
In January 2017, the FASB issued ASU 2017-04, Simplifying the Test for Goodwill Impairment (Topic 350), which removes Step 2 of the goodwill impairment test, which requires a hypothetical purchase price allocation. An impairment charge will now be the amount by which a reporting unit’s carrying value exceeds the fair value, not to exceed the carrying amount of goodwill.  This standard is effective for fiscal years beginning after December 15, 2019, with early adoption permitted The Company does not expect the adoption to have a material impact on the condensed consolidated financial statements. The Company currently plans to adopt this standard beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-19-039190:notes:24]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-19-039190:notes:25]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its condensed consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-039190:notes:26]
[same as prior period, unchanged from 0001564590-19-018574:notes:25]

[0001564590-19-039190:notes:27]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from software delivered as a service (“SaaS”) and service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-19-039190:notes:28]
[same as prior period, unchanged from 0001564590-19-018574:notes:27]

[0001564590-19-039190:notes:29]
[same as prior period, unchanged from 0001564590-19-018574:notes:28]

[0001564590-19-039190:notes:30]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s service and SaaS revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-19-039190:notes:31]
On September 30, 2019, the Company had $273.7 million of remaining performance obligations, which primarily comprised of deferred maintenance and SaaS revenue.  The Company expects to recognize approximately 58 percent of its remaining performance obligations as revenue in fiscal 2020, an additional 24 percent in fiscal 2021 and 18 percent of the balance thereafter.

[0001564590-19-039190:notes:32]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the condensed consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g., quarterly or annually).  The Company sometimes receives payments from its customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the condensed consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-19-039190:notes:33]
Revenue recognized for the three months ended September 30, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $53.8 million and $50.6 million, respectively.

[0001564590-19-039190:notes:34]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $7.6 million and $4.9 million at September 30, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended September 30, 2019 and 2018, was $2.7 million and $0.7 million, respectively. There was no impairment loss in relation to the costs capitalized.

[0001564590-19-039190:notes:35]
[same as prior period, unchanged from 0001564590-19-018574:notes:34]

[0001564590-19-039190:notes:36]
[same as prior period, unchanged from 0001564590-19-018574:notes:35]

[0001564590-19-039190:notes:37]
[same as prior period, unchanged from 0001564590-19-018574:notes:36]

[0001564590-19-039190:notes:38]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 69,978 |  | $ | 62,345 |  | $ | 132,323 |  |  | $ | 56,742 |  | $ | 59,936 |  | $ | 116,678 |  |
| Other |  |  | 4,015 |  |  | 4,999 |  |  | 9,014 |  |  |  | 4,493 |  |  | 5,524 |  |  | 10,017 |  |
| Total Americas |  |  | 73,993 |  |  | 67,344 |  |  | 141,337 |  |  |  | 61,235 |  |  | 65,460 |  |  | 126,695 |  |
| EMEA |  |  | 59,129 |  |  | 29,634 |  |  | 88,763 |  |  |  | 61,331 |  |  | 30,838 |  |  | 92,169 |  |
| APAC |  |  | 9,113 |  |  | 16,293 |  |  | 25,406 |  |  |  | 2,349 |  |  | 18,673 |  |  | 21,022 |  |
| Total net revenues |  | $ | 142,235 |  | $ | 113,271 |  | $ | 255,506 |  |  | $ | 124,915 |  | $ | 114,971 |  | $ | 239,886 |  |

[0001564590-19-039190:notes:39]
Included in the above amounts is approximately $3.7 million and $4.0 million of leasing revenue for the quarters ended September 30, 2019 and 2018, respectively.

[0001564590-19-039190:notes:40]
[same as prior period, unchanged from 0001564590-19-018574:notes:39]

[0001564590-19-039190:notes:41]
[same as prior period, unchanged from 0001564590-19-018574:notes:40]

[0001564590-19-039190:notes:42]
[same as prior period, unchanged from 0001564590-19-018574:notes:41]

[0001564590-19-039190:notes:43]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Tech Data Corporation |  | 16% |  |  | 17% |  |
| Jenne Corporation |  | 14% |  |  | 12% |  |
| Westcon Group Inc. |  | 10% |  |  | 13% |  |

[0001564590-19-039190:notes:44]
[same as prior period, unchanged from 0001564590-19-018574:notes:43]

[0001564590-19-039190:notes:45]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Tech Data Corporation |  |  | 21 | % |  |  | 12 | % |
| Jenne Corporation |  |  | 19 | % |  |  | 35 | % |
| Westcon Group Inc. |  |  | 12 | % |  | * |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-039190:notes:46]
| 4. | Business Combination |

[0001564590-19-039190:notes:47]
Aerohive Acquisition

[0001564590-19-039190:notes:48]
On August 9, 2019 (the “Acquisition Date”) the Company consummated its acquisition (the “Acquisition”) of all of the outstanding common stock of Aerohive Networks, Inc. (“Aerohive”) pursuant to that certain Agreement and Plan of Merger (the “Merger Agreement”) entered into as of June 26, 2019.  Under the terms of the Acquisition, the preliminary net consideration paid by Extreme to Aerohive stockholders was $267.1 million.

[0001564590-19-039190:notes:49]
The acquisition has been accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets. The purchase price has been preliminarily allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The final purchase price allocation is pending the finalization of valuations, which may result in an adjustment to the preliminary purchase price allocation.

[0001564590-19-039190:notes:50]
The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition. Inventories were valued at fair value using the net realizable value approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount that the Company would be required to pay to a third party to assume the obligation. Valuations of the intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition. Results of operations of Aerohive have been included in the operations of the Company beginning with the Acquisition Date.

[0001564590-19-039190:notes:51]
The components of aggregate estimated purchase consideration are as follows (in thousands):

[0001564590-19-039190:notes:52]
| Estimated purchase consideration | August 9, 2019 |  |
| Cash paid to acquire outstanding shares | $ | 263,616 |  |
| Replacement of stock-based awards |  | 3,530 |  |
| Aggregate estimated purchase consideration | $ | 267,146 |  |

[0001564590-19-039190:notes:53]
The preliminary purchase price allocation is set forth in the table below and reflects estimated fair values (in thousands).

[0001564590-19-039190:notes:54]
|  | Preliminary Allocation as of August 9, 2019 |  |
| Cash and cash equivalents | $ | 44,158 |  |
| Short-term investments |  | 45,148 |  |
| Accounts receivable, net |  | 11,753 |  |
| Inventories |  | 16,698 |  |
| Prepaid expenses and other current assets |  | 3,980 |  |
| Property and equipment |  | 2,185 |  |
| Operating lease right-of-use assets |  | 6,336 |  |
| Other assets |  | 2,195 |  |
| Debt |  | (20,000 | ) |
| Accounts payable |  | (9,737 | ) |
| Accrued compensation and benefits |  | (7,129 | ) |
| Accrued warranty |  | (570 | ) |
| Other accrued liabilities |  | (1,960 | ) |
| Operating lease liabilities |  | (4,752 | ) |
| Deferred revenue |  | (68,415 | ) |
| Other liabilities |  | (408 | ) |
| Net tangible assets |  | 19,482 |  |
| Identifiable intangible assets |  | 53,400 |  |
| Goodwill |  | 194,264 |  |
| Total intangible assets acquired |  | 247,664 |  |
| Total net assets acquired | $ | 267,146 |  |

[0001564590-19-039190:notes:55]
The following table presents details of the identifiable intangible assets acquired as part of the acquisition (dollars in thousands):

[0001564590-19-039190:notes:56]
| Intangible Assets |  | Estimated Useful Life (in years) |  |  | Amount |  |
| Developed technology |  |  | 4 |  |  | $ | 40,000 |  |
| Backlog |  |  | 1 |  |  |  | 400 |  |
| Customer relationships |  |  | 7 |  |  |  | 11,400 |  |
| Trade names |  |  | 1.5 |  |  |  | 1,600 |  |
| Total identifiable intangible assets |  |  |  |  |  | $ | 53,400 |  |

[0001564590-19-039190:notes:57]
The amortization for the developed technology and backlog is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying condensed consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of Aerohive. The Company will not be entitled to amortization of the goodwill and intangible assets for tax purposes as this acquisition is a nontaxable stock acquisition.

[0001564590-19-039190:notes:58]
The results of operations of Aerohive are included in the accompanying condensed consolidated results of operations beginning August 9, 2019. The Aerohive revenue for the quarter ended September 30, 2019 was $25.4 million and has been incorporated into the revenue of the Company. The associated expenses of Aerohive have been incorporated with the results of operations of the Company and, therefore, stand-alone operating results are not available.

[0001564590-19-039190:notes:59]
In the quarter ended September 30, 2019, the Company incurred acquisition and integration related expenses of $15.9 million associated with the acquisition of Aerohive including a $6.8 million compensation charge for certain Aerohive Executive stock awards which were accelerated due to change-in-control and termination provisions included in the Executives’ employment contracts. Other acquisition and integration costs consist primarily of professional fees for financial and legal advisory services and severance charges for terminated Aerohive employees.   Such acquisition-related costs were expensed as incurred and are included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-19-039190:notes:60]
[same as prior period, unchanged from 0001564590-19-018574:notes:58]

[0001564590-19-039190:notes:61]
The following unaudited pro forma results of operations are presented as though the acquisition of Aerohive had occurred as of July 1, 2018, the beginning of fiscal 2019, after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization of intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-19-039190:notes:62]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2019, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-19-039190:notes:63]
The unaudited pro forma financial information for the three months ended September 30, 2019 combines the historical results for Extreme for the period, which include the results of Aerohive subsequent to the Acquisition Date, and Aerohive’s historical results up to the Acquisition Date.

[0001564590-19-039190:notes:64]
Pro forma results of operations for the three months ended September 30, 2018 combines the historical results of operations for Extreme and for Aerohive.

[0001564590-19-039190:notes:65]
[same as prior period, unchanged from 0001564590-19-018574:notes:63]

[0001564590-19-039190:notes:66]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Net revenues |  | $ | 267,678 |  |  | $ | 279,234 |  |
| Net loss |  | $ | (24,084 | ) |  | $ | (39,085 | ) |
| Net loss per share - basic and diluted |  | $ | (0.20 | ) |  | $ | (0.33 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 120,226 |  |  |  | 117,368 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-039190:notes:67]
[same as prior period, unchanged from 0001564590-19-018574:notes:65]

[0001564590-19-039190:notes:68]
Cash, Cash Equivalents, and Short-term Investments

[0001564590-19-039190:notes:69]
The following is a summary of cash, cash equivalents, and short-term investments (in thousands):

[0001564590-19-039190:notes:70]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Cash |  | $ | 122,722 |  |  | $ | 169,607 |  |
| Cash equivalents |  |  | 8,647 |  |  |  | — |  |
| Short-term investments (consisting of available-for-sale securities) |  |  | 29,705 |  |  |  | — |  |
| Total cash, cash equivalents, and short-term investments |  | $ | 161,074 |  |  | $ | 169,607 |  |

[0001564590-19-039190:notes:71]
[same as prior period, unchanged from 0001564590-19-018574:notes:70]

[0001564590-19-039190:notes:72]
[same as prior period, unchanged from 0001564590-19-018574:notes:71]

[0001564590-19-039190:notes:73]
[same as prior period, unchanged from 0001564590-19-018574:notes:72]

[0001564590-19-039190:notes:74]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Finished goods |  | $ | 67,268 |  |  | $ | 49,492 |  |
| Raw materials |  |  | 15,126 |  |  |  | 14,097 |  |
| Total Inventories |  | $ | 82,394 |  |  | $ | 63,589 |  |

[0001564590-19-039190:notes:75]
[same as prior period, unchanged from 0001564590-19-018574:notes:74]

[0001564590-19-039190:notes:76]
[same as prior period, unchanged from 0001564590-19-018574:notes:75]

[0001564590-19-039190:notes:77]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Computers and equipment |  | $ | 73,817 |  |  | $ | 72,309 |  |
| Purchased software |  |  | 30,709 |  |  |  | 29,126 |  |
| Office equipment, furniture and fixtures |  |  | 11,833 |  |  |  | 10,815 |  |
| Leasehold improvements |  |  | 51,613 |  |  |  | 51,245 |  |
| Total property and equipment |  |  | 167,972 |  |  |  | 163,495 |  |
| Less: accumulated depreciation and amortization |  |  | (97,359 | ) |  |  | (89,941 | ) |
| Property and equipment, net |  | $ | 70,613 |  |  | $ | 73,554 |  |

[0001564590-19-039190:notes:78]
[same as prior period, unchanged from 0001564590-19-018574:notes:77]

[0001564590-19-039190:notes:79]
Deferred revenue represents amounts for (i) deferred maintenance and support revenue (ii) deferred SaaS revenue, and (iii) other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001564590-19-039190:notes:80]
[same as prior period, unchanged from 0001564590-19-018574:notes:79]

[0001564590-19-039190:notes:81]
The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty for media only. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment.  The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-19-039190:notes:82]
The following table summarizes the activity related to the Company’s product warranty liability during the three months ended September 30, 2019 and 2018 (in thousands):

[0001564590-19-039190:notes:83]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Balance beginning of period |  | $ | 14,779 |  |  | $ | 12,807 |  |
| Warranties assumed due to acquisitions |  |  | 570 |  |  |  | — |  |
| New warranties issued |  |  | 5,922 |  |  |  | 3,722 |  |
| Warranty expenditures |  |  | (5,283 | ) |  |  | (3,928 | ) |
| Balance end of period |  | $ | 15,988 |  |  | $ | 12,601 |  |

[0001564590-19-039190:notes:84]
[same as prior period, unchanged from 0001564590-19-018574:notes:83]

[0001564590-19-039190:notes:85]
[same as prior period, unchanged from 0001564590-19-018574:notes:84]

[0001564590-19-039190:notes:86]
[same as prior period, unchanged from 0001564590-19-018574:notes:85]

[0001564590-19-039190:notes:87]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Acquisition related deferred payments, less current portion |  | $ | 8,675 |  |  | $ | 9,604 |  |
| Contingent consideration obligations, less current portion |  |  | 1,667 |  |  |  | 2,688 |  |
| Other contractual obligations, less current portion |  |  | 24,406 |  |  |  | 26,261 |  |
| Other |  |  | 3,171 |  |  |  | 15,597 |  |
| Total other long-term liabilities |  | $ | 37,919 |  |  | $ | 54,150 |  |

[0001564590-19-039190:notes:88]
[same as prior period, unchanged from 0001564590-19-018574:notes:87]

[0001564590-19-039190:notes:89]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments. The Company does not invest an amount exceeding 10% of its combined cash or cash equivalents in the securities of any one obligor or maker, except for obligations of the United States government, obligations of United States government agencies and money market accounts.


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-039190:notes:90]
[same as prior period, unchanged from 0001564590-19-018574:notes:89]

[0001564590-19-039190:notes:91]
[same as prior period, unchanged from 0001564590-19-018574:notes:90]

[0001564590-19-039190:notes:92]
[same as prior period, unchanged from 0001564590-19-018574:notes:91]

[0001564590-19-039190:notes:93]
[same as prior period, unchanged from 0001564590-19-018574:notes:92]

[0001564590-19-039190:notes:94]
[same as prior period, unchanged from 0001564590-19-018574:notes:93]

[0001564590-19-039190:notes:95]
[same as prior period, unchanged from 0001564590-19-018574:notes:94]

[0001564590-19-039190:notes:96]
| September 30, 2019 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 8,647 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,647 |  |
| U.S. Treasuries |  |  | — |  |  |  | 9,329 |  |  |  | — |  |  |  | 9,329 |  |
| Corporate debt securities |  |  | — |  |  |  | 12,408 |  |  |  | — |  |  |  | 12,408 |  |
| Commercial Paper |  |  | — |  |  |  | 7,968 |  |  |  | — |  |  |  | 7,968 |  |
| Total assets measured at fair value |  | $ | 8,647 |  |  | $ | 29,705 |  |  | $ | — |  |  | $ | 38,352 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 5,693 |  |  | $ | 5,693 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 5,693 |  |  | $ | 5,693 |  |

[0001564590-19-039190:notes:97]
The Company had one fair value item at June 30, 2019, a level 3 acquisition-related contingent consideration obligation or $6.3 million.

[0001564590-19-039190:notes:98]
[same as prior period, unchanged from 0001564590-19-018574:notes:97]

[0001564590-19-039190:notes:99]
The Company holds investment in highly liquid money market funds which are classified as cash equivalents. The Company classifies these investments within Level 1 of the fair value hierarchy because the Company values them based on quoted market prices in active markets.

[0001564590-19-039190:notes:100]
[same as prior period, unchanged from 0001564590-19-018574:notes:99]

[0001564590-19-039190:notes:101]
The Company holds investment in U.S. treasuries, investment-grade corporate bonds, corporate securities and commercial paper which are classified within Level 2 of the fair value hierarchy because the Company values them based on pricing obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. The Company classifies these instruments as short-term investments unless their maturities are three months or less when purchases, in which case the Company classifies them as cash equivalents. There were no transfers of assets or liabilities between Level 1 and Level 2 for the periods presented.

[0001564590-19-039190:notes:102]
All of the Level 1 and Level 2 assets are classified as available for sale securities. The amortized cost of the short-term investments approximates their fair value. As of September 30, 2019, unrealized gains and losses from the Company’s short-term investments were not material. All short-term investments that the Company held as of September 30, 2019 contractually mature within one year.

[0001564590-19-039190:notes:103]
The fair value of the borrowings under the 2019 Credit Agreements is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the recent establishment of the Credit agreement, the fair value approximates the face amount of the Company’s indebtedness of $380.0 million and $180.5 million as of September 30, 2019, and June 30, 2019, respectively.

[0001564590-19-039190:notes:104]
[same as prior period, unchanged from 0001564590-19-018574:notes:102]

[0001564590-19-039190:notes:105]
At June 30, 2018, the Company reflected a liability for contingent consideration related to a certain acquisition completed in fiscal 2018. The fair value measurement of the contingent consideration obligation is determined using Level 3 inputs. These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations is recorded in general and administrative expenses in the accompanying condensed consolidated statements of operations.

[0001564590-19-039190:notes:106]
[same as prior period, unchanged from 0001564590-19-018574:notes:104]

[0001564590-19-039190:notes:107]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |
| Beginning balance |  |  | 6,298 |  |
| Payments |  |  | (635 | ) |
| Accretion on discount |  |  | 30 |  |
| Ending balance |  | $ | 5,693 |  |

[0001564590-19-039190:notes:108]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the three months ended September 30, 2019, or 2018. There were no impairments recorded for the three months ended September 30, 2019, or 2018.

[0001564590-19-039190:notes:109]
Short-term investments include available-for-sale investment-grade debt securities that the Company carries at fair value.  The Company accumulates unrealized gains and losses on the Company's available-for-sale debt securities, net of tax, in accumulated other comprehensive income in the stockholders' equity section of its balance sheets. Such an unrealized gain or loss does not reduce net income for the applicable accounting period. If the fair value of an available-for-sale debt instrument is less than its amortized cost basis, an other-than-temporary impairment is triggered in circumstances where (1) the Company intends to sell the instrument, (2) it is more likely than not that the Company will be required to sell the instrument before recovery of its amortized cost basis, or (3) the Company does not expect to recover the entire amortized cost basis of the instrument (that is, a credit loss exists). If the Company intends to sell or it is more likely than not that the Company will be required to sell the available-for-sale debt instrument before recovery of its amortized cost basis, the Company recognizes an other-than-temporary impairment in earnings equal to the entire difference between the debt instruments' amortized cost basis and its fair value. For available-for-sale debt instruments that are considered other-than-temporarily impaired due to the existence of a credit loss, if the Company does not intend to sell and it is not more likely than not that the Company will be required to sell the instrument before recovery of its remaining amortized cost basis (amortized cost basis less any current-period credit loss), the Company separates the amount of the impairment into the amount that is credit related and the amount due to all other factors. The credit loss component is recognized in earnings and is the difference between the debt instrument's amortized cost basis and the present value of its expected future cash flows. The remaining difference between the debt instrument's fair value and the present value of future expected cash flows is due to factors that are not credit related and is recognized in other comprehensive income.

[0001564590-19-039190:notes:110]
The Company determines the basis of the cost of a security sold or the amount reclassified out of accumulated other comprehensive income into earnings using the specific identification method.  Realized gains or losses recognized on the sale of investment securities were not significant for the quarters ending September 30, 2019 or September 30, 2018


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-039190:notes:111]
| 7. | Goodwill and Intangible Assets |

[0001564590-19-039190:notes:112]
[same as prior period, unchanged from 0001564590-19-018574:notes:108]

[0001564590-19-039190:notes:113]
|  |  | September 30, 2019 |  |
| Balance as of June 30, 2019 |  | $ | 138,577 |  |
| Additions due to acquisition |  |  | 194,264 |  |
| Balance at end of period |  | $ | 332,841 |  |

[0001564590-19-039190:notes:114]
[same as prior period, unchanged from 0001564590-19-018574:notes:110]

[0001564590-19-039190:notes:115]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| September 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 157,000 |  |  | $ | 83,823 |  |  | $ | 73,177 |  |
| Customer relationships |  | 3.7 years |  |  | 63,039 |  |  |  | 45,544 |  |  |  | 17,495 |  |
| Backlog |  | — years |  |  | 400 |  |  |  | 400 |  |  |  | — |  |
| Trade names |  | 1.6 years |  |  | 10,700 |  |  |  | 6,061 |  |  |  | 4,639 |  |
| License agreements |  | 5.4 years |  |  | 2,445 |  |  |  | 1,729 |  |  |  | 716 |  |
| Other intangibles |  | 0.3 years |  |  | 1,382 |  |  |  | 1,322 |  |  |  | 60 |  |
| Total intangibles, net |  |  |  | $ | 234,966 |  |  | $ | 138,879 |  |  | $ | 96,087 |  |

[0001564590-19-039190:notes:116]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 117,000 |  |  | $ | 77,449 |  |  | $ | 39,551 |  |
| Customer relationships |  | 2.0 years |  |  | 51,639 |  |  |  | 44,410 |  |  |  | 7,229 |  |
| Trade names |  | 2.4 years |  |  | 9,100 |  |  |  | 5,647 |  |  |  | 3,453 |  |
| License agreements |  | 5.4 years |  |  | 2,445 |  |  |  | 1,661 |  |  |  | 784 |  |
| Other intangibles |  | 0.6 years |  |  | 1,382 |  |  |  | 1,287 |  |  |  | 95 |  |
| Total intangibles, net |  |  |  | $ | 181,566 |  |  | $ | 130,454 |  |  | $ | 51,112 |  |

[0001564590-19-039190:notes:117]
[same as prior period, unchanged from 0001564590-19-018574:notes:113]

[0001564590-19-039190:notes:118]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| Amortization in “Cost of revenues: Product” |  | $ | 6,495 |  |  | $ | 4,932 |  |  |
| Amortization of intangibles in "Operations" |  |  | 1,930 |  |  |  | 2,141 |  |  |
| Total amortization |  | $ | 8,425 |  |  | $ | 7,073 |  |  |

[0001564590-19-039190:notes:119]
[same as prior period, unchanged from 0001564590-19-018574:notes:115]


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-039190:notes:120]
| 8. | Debt |

[0001564590-19-039190:notes:121]
The Company’s debt is comprised of the following (in thousands):

[0001564590-19-039190:notes:122]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 19,000 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (2,477 | ) |  |  | (489 | ) |
| Current portion of long-term debt |  | $ | 16,523 |  |  | $ | 9,011 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 361,000 |  |  | $ | 171,000 |  |
| Revolving Facility |  |  | — |  |  |  | — |  |
| Less: unamortized debt issuance costs |  |  | (7,594 | ) |  |  | (1,261 | ) |
| Total long-term debt, less current portion |  |  | 353,406 |  |  |  | 169,739 |  |
| Total debt |  | $ | 369,929 |  |  | $ | 178,750 |  |

[0001564590-19-039190:notes:123]
In connection with the acquisition of Aerohive as discussed in Note 4, on August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-19-039190:notes:124]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0001564590-19-039190:notes:125]
At the Company’s election, the initial term loan (the “Initial Term Loan”) under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity.  The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-19-039190:notes:126]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0001564590-19-039190:notes:127]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.   The Company incurred $10.5 million of deferred financing costs in conjunction which this modification of the debt and continues to amortize $1.6 million of unamortized debt issuance costs associated with the previous facility.  The interest rate as of September 30, 2019 is 5.47%

[0001564590-19-039190:notes:128]
Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.5 million and $0.2 million for the three months ended September 30, 2019 and 2018, respectively.

[0001564590-19-039190:notes:129]
The Company had $70.6 million of availability under the 2019 Revolving Facility as of September 30, 2019.  The Company had $4.4 million of outstanding letters of credit as of September 30, 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001564590-19-039190:notes:130]
| 9. | Leases |

[0001564590-19-039190:notes:131]
Lessee Considerations

[0001564590-19-039190:notes:132]
The Company lease certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2028. Its leases generally have terms that range from 1 year to 9 years for its facilities, 1 year to 6 years for equipment, and 1 year to 5 years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0001564590-19-039190:notes:133]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or right-of-use (ROU) asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is a hypothetical rate for collateralized borrowings based on the current economic environment, credit history, credit rating and lease term. Operating lease assets also included a reclassification for asset impairments and associated restructuring liabilities, deferred rent, lease incentives and initial direct costs which reduced the operating lease ROU assets as of July 1, 2019.

[0001564590-19-039190:notes:134]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for variable lease and non-lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s Condensed Consolidated Statements of Operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0001564590-19-039190:notes:135]
Activity and other information relating to operating leases is as follows (in thousands except for lease term and discount rate):

[0001564590-19-039190:notes:136]
|  |  | Three Months Ended September 30, 2019 |  |
| Operating lease costs | $ | 5,143 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 5,507 |  |
| ROU assets obtained for new lease obligations |  | 64 |  |
| ROU assets obtained from Aerohive business combination |  | 6,336 |  |
| Weighted average remaining lease term (in years) |  | 4.8 |  |
| Weighted Average Discount Rate |  | 4.5 | % |

[0001564590-19-039190:notes:137]
Short-term lease expense for the three months ended September 30, 2019 was not material.

[0001564590-19-039190:notes:138]
The maturities of the Company’s operating lease liabilities as of September 30, 2019 by fiscal year are as follows:

[0001564590-19-039190:notes:139]
|  |  | Operating Leases (in thousands) |  |
| 2020 (remaining nine months) |  | $ | 15,749 |  |
| 2021 |  |  | 19,941 |  |
| 2022 |  |  | 19,142 |  |
| 2023 |  |  | 15,516 |  |
| 2024 |  |  | 6,128 |  |
| Thereafter |  |  | 12,182 |  |
| Total future minimum lease payments |  |  | 88,658 |  |
| Less amount representing interest |  |  | 9,352 |  |
| Total operating lease liabilities |  | $ | 79,306 |  |
| Operating lease liabilities, current |  | $ | 17,767 |  |
| Operating lease liabilities, non-current |  | $ | 61,539 |  |

[0001564590-19-039190:notes:140]
As of June 30, 2019, the minimum future rentals on non-cancellable operating leases by fiscal year, based on the previous accounting standard, were as follows:

[0001564590-19-039190:notes:141]
|  |  | Operating Leases (in thousands) |  |
| 2020 |  | $ | 22,733 |  |
| 2021 |  |  | 21,174 |  |
| 2022 |  |  | 20,680 |  |
| 2023 |  |  | 17,828 |  |
| 2024 |  |  | 5,976 |  |
| Thereafter |  |  | 16,287 |  |
| Total lease payments |  | $ | 104,678 |  |

[0001564590-19-039190:notes:142]
Sublease Considerations

[0001564590-19-039190:notes:143]
The Company currently is a sublessor on several operating facility subleases that expire on various dates through fiscal 2023. The subleases have terms from 5 to 6 years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. These operating subleases include only lease components. Cash payments for variable lease components such as operating expenses are not included as lease components for accounting purposes. The Company had $0.6 million of sublease income for the three months ended September 30, 2019.

[0001564590-19-039190:notes:144]
Lessor Considerations

[0001564590-19-039190:notes:145]
Although most of the Company’s revenue from its hardware business comes from sales of hardware, in some limited cases the recurring subscription revenue contracts represent operating leases for these customers. These leases range in duration generally up to three years with payments generally collected in equal quarterly installments. These leases include 60-day termination rights. For the three months ended September 30, 2019 and 2018, $3.7 million and $4.0 million, are included in product revenue in the financial statements, respectively. There were no changes to the accounting treatment of these transactions from the adoption of ASC 842.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-039190:notes:146]
| 10. | Commitments and Contingencies |

[0001564590-19-039190:notes:147]
Purchase Commitments

[0001564590-19-039190:notes:148]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that inventory and other services. As of September 30, 2019, the Company had commitments to purchase $50.6 million of inventory and other services.

[0001564590-19-039190:notes:149]
Legal Proceedings

[0001564590-19-039190:notes:150]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-19-039190:notes:151]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-19-039190:notes:152]
Brazilian Tax Assessment Matter

[0001564590-19-039190:notes:153]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of September 30, 2019.

[0001564590-19-039190:notes:154]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017, decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 20.0 million (USD $4.8 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of September 30, 2019.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

[0001564590-19-039190:notes:155]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (USD $2.2 million) as of the date the Company acquired Enterasys Networks.

[0001564590-19-039190:notes:156]
The Company made a demand on April 11, 2014, for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-19-039190:notes:157]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc. Patent Infringement Suit

[0001564590-19-039190:notes:158]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents. The PTAB has now invalidated all asserted claims of the ’296 patent and ’728 patent, and has found the challenged claims of the ’231 patent not invalid in view of the prior art asserted in the IPR instituted against that patent. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date).  During a status conference on February 11, 2019, the Court continued the stay and set a status conference for December 2, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-19-039190:notes:159]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-19-039190:notes:160]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 (“EP ’364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the infringement complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action. Orckit filed its reply on September 26, 2019 and Extreme’s rejoinder is due on December 17, 2019.  The District Court Düsseldorf scheduled a hearing in this case for January 28, 2020.

[0001564590-19-039190:notes:161]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  Extreme’s answer to the EP ‘077 infringement complaint is due on November 5, 2019.  Extreme also plans to file a nullity action with the German Federal Patent Court on or before that date, seeking to invalidate the asserted patent.  No hearing has been scheduled yet in this case, which was split from the original action involving the first patent in suit.

[0001564590-19-039190:notes:162]
The Company believes that all claims are without merit and defends them vigorously.

[0001564590-19-039190:notes:163]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co.

[0001564590-19-039190:notes:164]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1 (“ZL ‘028.1”), ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2 (“ZL ‘486.2”), and ZL200610060686.9 (collectively, the “Asserted Patents”).  Each patent was asserted in a separate law suit.  The filing date for the first case is January 18, 2019, and the filing date for the rest of the cases is January 23, 2019.  The trial for the first case is currently scheduled for January 15, 2020, and trials for the rest of the cases have not yet been scheduled.  GIA has accused the Summit X440-G2-24t-10GE4 (product number: 16532), Summit X440-G2-24p-10GE4 (product number: 16533) and Summit X460-G2-24x-10GE4-Base (product number: 16705) (collectively the “Accused Products”) of infringing the Asserted Patents. GIA has also alleged that the following Extreme switch products support the same functions as the Accused Products:  Summit X440-G2 series, X450-G2 series, X460-G2 series, X620 series, X670-G2 series, X770 series, X870 series, X690 series, and X590 series.  GIA is a U.S. entity established under the laws of Delaware with its principal office in Pasadena, California.  Extreme disputes GIA’s claims and intends to defend the matter vigorously.  Additionally, Extreme has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019. The Chinese patent office has issued decisions maintaining the validity of the ZL ‘028.1 and ZL ‘486.2 patents, but has not yet issued decisions for the remaining four patents. Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-19-039190:notes:165]
Shenzhen Dunjun Technology Ltd. v. Aerohive Networks (Hangzhou) Ltd.; Aerohive Networks, Inc.; and Yunqing Information Technology (Shenzhen) Ltd.

[0001564590-19-039190:notes:166]
In late September 2019, Extreme Networks learned of a patent infringement lawsuit filed by Shenzhen Dunjun Technology Ltd. (“Shenzhen Dunjun”) against Aerohive Networks, Inc., its Chinese subsidiary, and Yunqing Information Technology (Shenzhen) Ltd. in the Shenzhen Intermediate People’s Court in China.  The lawsuit alleges infringement of Chinese patent ZL02123502.3.  The complaint was received by Aerohive Networks, Inc. on October 9 and by its Chinese subsidiary on October 10.  Extreme cannot estimate at this time the possible loss or range of loss that may result from this action, but Shenzhen Dunjun claims damages in the amount of RMB 10,000,000.

[0001564590-19-039190:notes:167]
Indemnification Obligations

[0001564590-19-039190:notes:168]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of September 30, 2019, the Company has the outstanding indemnification claims described above.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-19-039190:notes:169]
| 11. | Stockholders’ Equity |

[0001564590-19-039190:notes:170]
[same as prior period, unchanged from 0001564590-19-018574:notes:147]

[0001564590-19-039190:notes:171]
[same as prior period, unchanged from 0001564590-19-018574:notes:148]

[0001564590-19-039190:notes:172]
The Company’s Board of Directors (the “Board”) adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 the Board and stockholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  The Board unanimously approved an amendment to the Restated Rights Plan on May 9, 2019, to extend the Restated Rights Plan through May 31, 2020, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting.

[0001564590-19-039190:notes:173]
[same as prior period, unchanged from 0001564590-19-018574:notes:150]

[0001564590-19-039190:notes:174]
The Board of Directors unanimously approved an amendment to the 2014 Employee Stock Purchase Plan to increase the maximum number of shares that will be available for sale thereunder by 7,500,000 shares which is pending ratification by the stockholders of the Company at the annual meeting of stockholders held on November 7, 2019.

[0001564590-19-039190:notes:175]
[same as prior period, unchanged from 0001564590-19-018574:notes:152]

[0001564590-19-039190:notes:176]
On November 2, 2018, the Company announced that the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock for two years from the date of authorization. Purchases may be made from time to time in the open market or in privately negotiated transactions.  A maximum of $35.0 million of the Company’s common stock may be repurchased in any calendar year. There were no shares repurchased for the three months ended September 30, 2019 or 2018.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-039190:notes:177]
| 12. | Employee Benefit Plans |

[0001564590-19-039190:notes:178]
[same as prior period, unchanged from 0001564590-19-018574:notes:157]

[0001564590-19-039190:notes:179]
[same as prior period, unchanged from 0001564590-19-018574:notes:158]

[0001564590-19-039190:notes:180]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 3,336 |  |  |  | 8,462 |  |
| Employee stock options and awards outstanding |  |  | 14,566 |  |  |  | 10,455 |  |
| 2014 Employee Stock Purchase Plan |  |  | 8,862 |  |  |  | 10,085 |  |
| Total shares reserved for issuance |  |  | 26,764 |  |  |  | 29,002 |  |

[0001564590-19-039190:notes:181]
Aerohive 2014 Equity Incentive Plan

[0001564590-19-039190:notes:182]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the "Aerohive Plan").  Stock awards outstanding under the Aerohive Plan were converted into awards for Extreme shares as of the Acquisition Date at a predetermined rate pursuant to the Merger Agreement.  As of September 30, 2019, total awards to acquire 1,457,321 shares of Extreme common stock were outstanding under the Aerohive Plan.  If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0001564590-19-039190:notes:183]
Share-based compensation expense

[0001564590-19-039190:notes:184]
[same as prior period, unchanged from 0001564590-19-018574:notes:160]

[0001564590-19-039190:notes:185]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| Cost of product revenue |  | $ | 250 |  |  | $ | 178 |  |  |
| Cost of service revenue |  |  | 347 |  |  |  | 345 |  |  |
| Research and development |  |  | 2,435 |  |  |  | 2,342 |  |  |
| Sales and marketing |  |  | 3,719 |  |  |  | 2,359 |  |  |
| General and administrative |  |  | 2,083 |  |  |  | 1,601 |  |  |
| Total share-based compensation expense |  | $ | 8,834 |  |  | $ | 6,825 |  |  |

[0001564590-19-039190:notes:186]
During the three months ended September 30, 2019, or 2018, the Company did not capitalize any share-based compensation expense in inventory, as the amounts were immaterial.

[0001564590-19-039190:notes:187]
[same as prior period, unchanged from 0001564590-19-018574:notes:163]

[0001564590-19-039190:notes:188]
Stock awards may be granted under the 2013 Equity Incentive Plan (the “2013 Plan”) on terms approved by the Compensation Committee of the Board. Stock awards generally provide for the issuance of restricted stock units (“RSUs”) including performance or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria.  The Company uses the straight-line method for expense attribution.  The Company does not estimate forfeitures, but accounts for them as incurred.

[0001564590-19-039190:notes:189]
The following table summarizes stock award activity for the three months ended September 30, 2019 (in thousands, except grant date fair value):

[0001564590-19-039190:notes:190]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2019 |  |  | 7,736 |  |  | $ | 7.67 |  |  |  |  |  |
| Granted |  |  | 5,485 |  |  |  | 6.83 |  |  |  |  |  |
| Released |  |  | (1,486 | ) |  |  | 6.82 |  |  |  |  |  |
| Cancelled |  |  | (387 | ) |  |  | 6.99 |  |  |  |  |  |
| Non-vested stock awards outstanding at September 30, 2019 |  |  | 11,348 |  |  | $ | 7.43 |  |  | $ | 82,614 |  |
| Vested and expected to vest at September 30, 2019 |  |  | 10,785 |  |  | $ | 7.33 |  |  | $ | 78,512 |  |

[0001564590-19-039190:notes:191]
The following table summarizes stock option activity for the three months ended September 30, 2019 (in thousands, except per share and contractual term):

[0001564590-19-039190:notes:192]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2019 |  |  | 2,719 |  |  | $ | 4.61 |  |  |  | 3.26 |  |  | $ | 5,070 |  |
| Granted |  |  | 637 |  |  |  | 6.70 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (119 | ) |  |  | 4.23 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (19 | ) |  |  | 5.02 |  |  |  |  |  |  |  |  |  |
| Options outstanding at September 30, 2019 |  |  | 3,218 |  |  | $ | 5.03 |  |  |  | 3.86 |  |  | $ | 7,235 |  |
| Vested and expected to vest at September 30, 2019 |  |  | 3,218 |  |  | $ | 5.03 |  |  |  | 3.85 |  |  | $ | 7,235 |  |
| Exercisable at September 30, 2019 |  |  | 1,801 |  |  | $ | 3.85 |  |  |  | 1.88 |  |  | $ | 6,179 |  |

[0001564590-19-039190:notes:193]
The fair value of each stock option grant under the 2013 Plan and 2005 Equity Incentive Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model.  The Company uses the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior.  The risk-free rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.  The average fair value of the options granted was $6.70.

[0001564590-19-039190:notes:194]
[same as prior period, unchanged from 0001564590-19-018574:notes:170]

[0001564590-19-039190:notes:195]
During the three months ended September 30, 2019, the Company approved the grant of 5,484,772 RSUs to employees and directors. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company. These RSUs included 566,038 RSUs to named executive officers and directors.

[0001564590-19-039190:notes:196]
During the three months ended September 30, 2019, the 2019 and 2018 Performance Thresholds for outstanding performance awards were not achieved.

[0001564590-19-039190:notes:197]
[same as prior period, unchanged from 0001564590-19-018574:notes:179]

[0001564590-19-039190:notes:198]
[same as prior period, unchanged from 0001564590-19-018574:notes:180]

[0001564590-19-039190:notes:199]
There were 1,233,544 and 1,280,708 shares issued under the ESPP during the three months ended September 30, 2019 and 2018, respectively.  The following assumptions were used to calculate the fair value of shares granted under the ESPP during the following periods:

[0001564590-19-039190:notes:200]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 1.85 | % |  |  | 2.20 | % |
| Volatility |  |  | 43 | % |  |  | 63 | % |
| Dividend yield |  |  | — | % |  |  | — | % |

[0001564590-19-039190:notes:201]
The weighted-average fair value of shares granted under the ESPP during the three months ended September 30, 2019 and 2018 was $2.02 and $2.73, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-039190:notes:202]
| 13. | Information about Segments and Geographic Areas |

[0001564590-19-039190:notes:203]
[same as prior period, unchanged from 0001564590-19-018574:notes:185]

[0001564590-19-039190:notes:204]
[same as prior period, unchanged from 0001564590-19-018574:notes:186]

[0001564590-19-039190:notes:205]
[same as prior period, unchanged from 0001564590-19-018574:notes:187]

[0001564590-19-039190:notes:206]
| Long-lived Assets |  | September 30, 2019 |  |  | June 30, 2019 |  |
| Americas |  | $ | 231,094 |  |  | $ | 136,035 |  |
| EMEA |  |  | 31,286 |  |  |  | 28,744 |  |
| APAC |  |  | 21,863 |  |  |  | 11,529 |  |
| Total long-lived assets |  | $ | 284,243 |  |  | $ | 176,308 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-039190:notes:207]
| 14. | Restructuring Charges, net of reversals and impairment |

[0001564590-19-039190:notes:208]
Restructuring liabilities at September 30, 2019 of $2.1 million relate to severance and benefits obligations and are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets.

[0001564590-19-039190:notes:209]
The Company recorded $6.1 million of restructuring charges, net of reversals and impairment during the three months ended September 30, 2019, including charges of $3.9 million of impairment of right-of-use-assets related to facilities which the Company has exited and $2.2 million related to employee severance and benefit expenses.

[0001564590-19-039190:notes:210]
During the first quarter of fiscal 2020, the Company continued its initiative to realign its operations by exiting a floor of its San Ignacio building in South San Jose California and consolidating its workforce. Also, the Company exited additional space in its Salem New Hampshire facility which includes general office and lab space. The Company has the intent and ability to sub-lease these facilities which it has ceased using and as such has considered estimated future sub-lease income based on its existing leases agreement, as well as the local real estate market conditions in measuring the amount of asset impairment. The Company also factored into its estimate the time for a sub-lease tenant to enter into an agreement and complete any improvements.

[0001564590-19-039190:notes:211]
The Company continued its reduction-in-force actions begun in the fourth quarter of fiscal 2019 and recorded additional severance and benefits charges of $2.2 million during the period.

[0001564590-19-039190:notes:212]
Cash payments of $3.6 million were paid during the three months ended September 30, 2019. Certain amounts have been reclassified from restructuring liabilities and have been recorded as a reduction to operating lease ROU assets as of July 1, 2019.

[0001564590-19-039190:notes:213]
[same as prior period, unchanged from 0001564590-19-018574:notes:197]

[0001564590-19-039190:notes:214]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Total |  |
| Balance as of June 30, 2019 |  | $ | 1,764 |  |  | $ | 3,559 |  |  | $ | 5,323 |  |
| Period charges |  |  | 3,951 |  |  |  | 2,595 |  |  |  | 6,546 |  |
| Period reversals |  |  | — |  |  |  | (409 | ) |  |  | (409 | ) |
| Reclassification to reduce operating lease assets |  |  | (5,715 | ) |  |  | — |  |  |  | (5,715 | ) |
| Period payments |  |  | — |  |  |  | (3,608 | ) |  |  | (3,608 | ) |
| Balance as of September 30, 2019 |  | $ | — |  |  | $ | 2,137 |  |  | $ | 2,137 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-039190:notes:215]
| 15. | Income Taxes |

[0001564590-19-039190:notes:216]
For the three months ended September 30, 2019 and 2018, the Company recorded an income tax provision of $1.6 million and $1.4 million, respectively.

[0001564590-19-039190:notes:217]
The income tax provisions for the three months ended September 30, 2019 and 2018, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) foreign withholding taxes (3) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business the Data Center Business, and (4) state taxes in jurisdictions where the Company has no remaining state Net Operating Losses (“NOLs”). The income tax provisions for both fiscal years were calculated based on the actual results of operations for the three months ended September 30, 2019 and 2018, respectively and therefore may not reflect the annual effective tax rate.

[0001564590-19-039190:notes:218]
In the three months ended September 30, 2018, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs.  Historically, GAAP has prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset had been sold outside the consolidated group.  Effective as of July 1, 2018, the Company adopted ASU 2016-16 on a modified retrospective basis which requires an adjustment of the cumulative-effect of the adoption to retained earnings.  However, the adjustment was immaterial to the financial statements and no such adjustment was necessary.  As a result of adoption, the income tax consequences of future intra-entity transfer of assets will be recognized in earnings in each period rather than be deferred until the assets leave the consolidated group.  In the three months ended September 30, 2018, the Company recognized a deferred tax asset relating to a transfer of certain assets from the U.S. parent company to its wholly-owned Irish subsidiary of $3.7 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to Company’s statement of operations.

[0001564590-19-039190:notes:219]
The Company has provided a full valuation allowance against all its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. A valuation allowance is determined by assessing both negative and positive evidence to determine whether it is “more likely than not” that the deferred tax assets are recoverable; such assessment is required on a jurisdiction by jurisdiction basis.  The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of its business represent sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets as well as the deferred tax assets of a newly established wholly owned Irish subsidiary as well as a portion of the deferred tax assets in Ireland.  These valuation allowance will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets.

[0001564590-19-039190:notes:220]
On August 9, 2019, the Company completed its acquisition of Aerohive.  This acquisition will be treated as a non-taxable stock acquisition and therefore Extreme Networks will have carryover tax basis in the assets and liabilities acquired.

[0001564590-19-039190:notes:221]
The Company had $25.5 million of unrecognized tax benefits as of September 30, 2019.  The future impact of the unrecognized tax benefit of $25.1 million, if recognized, would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The remaining $0.4 million would affect the effective tax rate.  The Company does not anticipate any events to occur during the next twelve months that would reduce the unrealized tax benefit as currently stated in the Company’s balance sheet.

[0001564590-19-039190:notes:222]
[same as prior period, unchanged from 0001564590-19-018574:notes:213]

[0001564590-19-039190:notes:223]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses. The Company recently settled an examination by the state of North Carolina for fiscal years ended 2014, 2015 and 2016. The settlement resulted in an immaterial payment to the state to close all three years.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-039190:notes:224]
| 16. | Net Loss Per Share |

[0001564590-19-039190:notes:225]
[same as prior period, unchanged from 0001564590-19-018574:notes:216]

[0001564590-19-039190:notes:226]
[same as prior period, unchanged from 0001564590-19-018574:notes:217]

[0001564590-19-039190:notes:227]
|  |  | Three Months Ended |  |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| Net loss |  | $ | (37,738 | ) |  | $ | (9,065 | ) |  |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 120,226 |  |  |  | 117,368 |  |  |
| Net loss per share - basic and diluted |  | $ | (0.31 | ) |  | $ | (0.08 | ) |  |

[0001564590-19-039190:notes:228]
[same as prior period, unchanged from 0001564590-19-018574:notes:219]

[0001564590-19-039190:notes:229]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Options to purchase common stock |  |  | 2,898 |  |  |  | 989 |  |
| Restricted stock units |  |  | 9,305 |  |  |  | 1,913 |  |
| Employee Stock Purchase Plan shares |  |  | 750 |  |  |  | — |  |
| Total shares excluded |  |  | 12,953 |  |  |  | 2,902 |  |
