# EXTR 8-K — 0001564590-19-038508 filed 2019-10-30

## item codes, every 8-K on or before 2019-10-31

- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2019-10-31

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-038508:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-19-038508:8k_2_02:2]
extr-ex991_6.htm

[0001564590-19-038508:8k_2_02:3]
Exhibit 99.1

[0001564590-19-038508:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-19-038508:8k_2_02:5]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-19-038508:8k_2_02:6]
Extreme Networks Reports First Quarter Fiscal Year 2020 Financial Results

[0001564590-19-038508:8k_2_02:7]
Conference Call at 8:00 a.m. EDT

[0001564590-19-038508:8k_2_02:8]
SAN JOSE, Calif., October 30, 2019 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal first quarter ended September 30, 2019.

[0001564590-19-038508:8k_2_02:9]
Fiscal First Quarter Results:

[0001564590-19-038508:8k_2_02:10]
|  | • | Revenue $255.5 million, up 7% year-over-year and up 1% quarter-over-quarter |

[0001564590-19-038508:8k_2_02:11]
|  | • | GAAP EPS ($0.31), down ($0.23) year-over-year and down ($0.17) quarter-over-quarter |

[0001564590-19-038508:8k_2_02:12]
|  | • | Non-GAAP EPS $0.08, flat year-over-year and up $0.02 quarter-over-quarter |

[0001564590-19-038508:8k_2_02:13]
|  | • | GAAP gross margin 53.7% compared to 55.1%, in Q1 last year |

[0001564590-19-038508:8k_2_02:14]
|  | • | Non-GAAP gross margin 59.9% compared to 58.0%, in Q1 last year |

[0001564590-19-038508:8k_2_02:15]
|  | • | GAAP operating margin (12.6)% compared to (2.1)%, in Q1 last year |

[0001564590-19-038508:8k_2_02:16]
|  | • | Non-GAAP operating margin 6.2%, compared to 5.8%, in Q1 last year |

[0001564590-19-038508:8k_2_02:17]
|  | • | Net cash used in operating activities was ($0.2) million |

[0001564590-19-038508:8k_2_02:18]
|  | • | Free Cash Flow of ($5.4) million |

[0001564590-19-038508:8k_2_02:19]
“We reported revenue above the midpoint of our guidance, reflecting strength in the cloud-managed wireless LAN business we acquired from Aerohive Networks (“Aerohive”), along with a strong quarter of double-digit revenue growth in our edge switching portfolio. Our Non-GAAP gross margin rose once again on a year-over-year and sequential basis, towards the high-end of our guidance range, and on the verge of our 60 percent FY20 target,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-19-038508:8k_2_02:20]
Meyercord added, “Our mission following the recent acquisition of Aerohive Networks is to be the leader in cloud-driven networking. We are excited to deliver our best-of-breed cloud platform to give customers end-to-end enterprise networking solutions, unparalleled choice of deployment, and continuously improving ML / AI capabilities that create a gateway to the autonomous enterprise. As we bring industry leading access, edge, campus, and data center networking solutions to enterprise customers, highlighted by last week’s launch of the new ExtremeCloud IQ management application, we are also backed by a growing ecosystem of strategic technology and go-to-market partners, such as Broadcom,” stated Ed Meyercord, President and CEO of Extreme Networks.”

[0001564590-19-038508:8k_2_02:21]
Remi Thomas, EVP and CFO of Extreme Networks added, “Our integration of Aerohive is progressing well ahead of our guidance from a revenue, operating expense, and product roadmap standpoint.  The combination of our previously announced restructuring and merger synergies drove lower-than-expected operating expenses for Q1 and positions us for improved operating leverage in Q2 and throughout FY20.”

[0001564590-19-038508:8k_2_02:22]
Meyercord concluded, “We have more confidence than ever in our ability to achieve our goal of a 15 percent operating margin toward fiscal year-end 2020 given the strength of our gross margins and tight expense controls. This comes despite top line softness due to macro concerns in Germany and delays in wireless orders as customers evaluate our new ExtremeCloud IQ platform. As we drive higher profitability, we also expect to improve our cash flow generation throughout the year.”

[0001564590-19-038508:8k_2_02:23]
Recent Key Highlights:

[0001564590-19-038508:8k_2_02:24]
|  | • | Extreme completed its acquisition of Aerohive. The acquisition brought together the world's #2 leader in cloud managed wireless LAN services with the #3 provider of enterprise networking equipment. With Aerohive, Extreme is now able to offer customers and partners more choices for cloud-driven, end-to-end enterprise networking technology – from the wireless and IoT edge to the data center – including the industry's broadest array of wireless LAN solutions at a critical technology transition to Wi-Fi 6 – all from a single vendor and backed by its award-winning, insourced services and support team. |

[0001564590-19-038508:8k_2_02:25]
|  | • | West Texas A&M University (WTAMU) deployed Extreme’s high-density, professional-grade Wi-Fi 6 access points, switching solutions and analytics at Buffalo Stadium. The initiative, spearheaded by students, will allow the University to use its Wi-Fi network to streamline game day operations at the new stadium, and offer digital fan experiences, such as social sign-in, mobile ticketing, access to real-time stats, and the ability to stream video. It will also power new HD digital scoreboards. |

[0001564590-19-038508:8k_2_02:26]
|  | • | Brussels Intercommunal Transport Company is nearly a 24x7x365 operation, running over one million metro, tram, and bus journeys every day for commuters, visitors, and residents, and continues to grow. With operability reaching its peak, they deployed autonomous network solutions from Extreme, including our Fabric Connect technology, network management, and analytics software, to enable real-time monitoring of rail conditions, extend passenger services and reduce network downtime. |

[0001564590-19-038508:8k_2_02:27]
|  | • | Extreme renewed its technology partnership with the National Football League (NFL). As the Official Wi-Fi Solutions Provider to the NFL, Extreme will provide Wi-Fi and Wi-Fi analytics solutions for the next three football seasons and two Super Bowls: Super Bowl LIV on February 2, 2020 in Miami, and Super Bowl LV on February 7, 2021 in Tampa, Florida. Extreme currently provides Wi-Fi or Wi-Fi analytics solutions to 24 stadiums, servicing 25 teams, in the NFL. This year marks the seventh season of the Extreme-NFL partnership. |

[0001564590-19-038508:8k_2_02:28]
|  | • | Extreme announced capabilities for and strong momentum in the fast-growing eSports market taking hold in primary and secondary schools and universities around the world, and kicked off an Extreme NOW Esports roadshow in Syracuse, New York on October 3. |

[0001564590-19-038508:8k_2_02:29]
|  | • | Extreme announced a partnership with Broadcom to bring industry leading access, edge, and campus networking solutions to enterprise customers. As a Broadcom preferred provider for enterprise campus networking solutions, Extreme will embed its solutions with Broadcom silicon and software, giving enterprise customers and partners powerful security, segmentation, resiliency, policy, telemetry, and performance advantages as they pursue cloud-driven digital transformation with a simple, secure, and intelligent campus architecture. |

[0001564590-19-038508:8k_2_02:30]
|  | • | Extreme introduced ExtremeCloud IQ, the industry's first end-to-end cloud management application that leverages machine learning and artificial intelligence to provide enterprises with insights, as well as complete visibility, control, and automation of their entire network. The application is built on an architecture supported by microservices, third-generation cloud technology, and tools acquired from Aerohive Networks. ExtremeCloud IQ is available today on Extreme’s wireless portfolio and will be available on Extreme’s wired switching solutions in January. |

[0001564590-19-038508:8k_2_02:31]
|  | • | Extreme Networks, Inc announced it is once again positioned as a Leader by Gartner, Inc. in the *Gartner Magic Quadrant for Wired and Wireless LAN Access Infrastructure. This is the second consecutive year Extreme has been positioned as a Leader in this annual research report. |

[0001564590-19-038508:8k_2_02:32]
*Gartner, Magic Quadrant for the Wired and Wireless LAN Access Infrastructure, 24 September 2019.

[0001564590-19-038508:8k_2_02:33]
Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, express or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001564590-19-038508:8k_2_02:34]
Fiscal Q1 2020 Financial Metrics:

[0001564590-19-038508:8k_2_02:35]
(in millions, except percentages and per share information)

[0001564590-19-038508:8k_2_02:36]
|  |  | Q1 FY'20 |  |  | Q1 FY'19 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 185.1 |  |  | $ | 177.7 |  |  | $ | 7.4 |  |  |  | 4 | % |
| Service |  |  | 70.4 |  |  |  | 62.2 |  |  |  | 8.2 |  |  |  | 13 | % |
| Total Net Revenue |  | $ | 255.5 |  |  | $ | 239.9 |  |  | $ | 15.6 |  |  |  | 7 | % |
| Gross Margin |  |  | 53.7 | % |  |  | 55.1 | % |  | -140 bps |  |  | - |  |
| Operating Margin |  |  | (12.6 | )% |  |  | (2.1 | )% |  | -1050 bps |  |  | - |  |
| Net Loss |  | $ | (37.7 | ) |  | $ | (9.1 | ) |  | $ | (28.6 | ) |  |  | (314 | )% |
| Loss per basic share |  | $ | (0.31 | ) |  | $ | (0.08 | ) |  | $ | (0.23 | ) |  |  | (288 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 185.1 |  |  | $ | 177.7 |  |  | $ | 7.4 |  |  |  | 4 | % |
| Service |  |  | 70.4 |  |  |  | 62.2 |  |  |  | 8.2 |  |  |  | 13 | % |
| Total Net Revenue |  | $ | 255.5 |  |  | $ | 239.9 |  |  | $ | 15.6 |  |  |  | 7 | % |
| Gross Margin |  |  | 59.9 | % |  |  | 58.0 | % |  | 190 bps |  |  | - |  |
| Operating Margin |  |  | 6.2 | % |  |  | 5.8 | % |  | 40 bps |  |  | - |  |
| Net Income |  | $ | 10.3 |  |  | $ | 9.4 |  |  | $ | 0.9 |  |  |  | 10 | % |
| Income per diluted share |  | $ | 0.08 |  |  | $ | 0.08 |  |  | $ | - |  |  |  | — |  |

[0001564590-19-038508:8k_2_02:37]
|  | • | The August 9th acquisition of Aerohive contributed approximately $25 million in revenue and 64% Non-GAAP gross margin during the quarter. |

[0001564590-19-038508:8k_2_02:38]
|  | • | Q1 ending cash and short-term investments balance was $161.1 million, a decrease of $8.5 million from Q4 and an increase of $20.9 million from Q1 last year primarily driven by the acquisition of Aerohive in Q1, net of debt proceeds. |

[0001564590-19-038508:8k_2_02:39]
|  | • | Q1 Accounts Receivable balance was $152.3 million, with days sales outstanding of 55, a decrease of 8 days from Q4 and a decrease of 8 days from Q1 last year. |

[0001564590-19-038508:8k_2_02:40]
|  | • | Q1 ending inventory was $82.4 million, an increase of $18.8 million from Q4 and an increase of $26.8 million from Q1 last year, largely attributed to the addition of Aerohive inventory. |

[0001564590-19-038508:8k_2_02:41]
|  | • | Q1 ending gross debt was $380.0 million, an increase of $199.5 million from Q4 and an increase of $192.4 million from Q1 last year. Net Debt* of $218.9 million increased by $208.0 million from $10.9 million in Q4 due to the acquisition of Aerohive in Q1. |

[0001564590-19-038508:8k_2_02:42]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP operating cash flows less purchases of property, plant and equipment. Extreme considers free cash flow as useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant, and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of the non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. As shown in the table below (in thousands):

[0001564590-19-038508:8k_2_02:43]
| Free Cash Flow | Three Months Ended |  |  |
|  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| Cash flow provided by (used in) operations | $ | (202 | ) |  | $ | 34,330 |  |  |
| Less: PP&E CapEx spending |  | (5,239 | ) |  |  | (7,417 | ) |  |
| Total free cash flow | $ | (5,441 | ) |  | $ | 26,913 |  |  |

[0001564590-19-038508:8k_2_02:44]
*Net Debt is defined as gross debt minus loan fees minus cash: as shown in the table below (in millions):

[0001564590-19-038508:8k_2_02:45]
| Gross debt |  |  | Cash and short-term investments |  |  | Net debt |  |
| $ | 380.0 |  |  | $ | 161.1 |  |  | $ | 218.9 |  |

[0001564590-19-038508:8k_2_02:46]
Business Outlook:

[0001564590-19-038508:8k_2_02:47]
For its second quarter of fiscal 2020, ending December 31, 2019, the Company is targeting:

[0001564590-19-038508:8k_2_02:48]
| (in millions) | Low-end |  |  | High-End |  |
| FQ2'20 Guidance – GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 268.0 |  |  | $ | 278.0 |  |
| Gross Margin |  | 55.2 | % |  |  | 57.4 | % |
| Operating Expenses | $ | 164.2 |  |  | $ | 169.2 |  |
| Operating Margin |  | (6.0 | %) |  |  | (3.4 | %) |
| Net Loss | $ | (23.2 | ) |  | $ | (16.6 | ) |
| Loss per basic share | $ | (0.18 | ) |  | $ | (0.14 | ) |
| Shares outstanding used in calculating GAAP EPS | 121.8 |  |  | 121.8 |  |
| FQ2’20 Guidance – Non - GAAP |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 268.0 |  |  | $ | 278.0 |  |
| Gross Margin |  | 59.1 | % |  |  | 61.1 | % |
| Operating Expenses | $ | 137.3 |  |  | $ | 142.3 |  |
| Operating Margin |  | 7.8 | % |  |  | 9.9 | % |
| Net Income | $ | 13.9 |  |  | $ | 20.5 |  |
| Income per diluted share | $ | 0.12 |  |  | $ | 0.16 |  |
| Shares outstanding used in calculating Non-GAAP EPS |  | 125.0 |  |  |  | 125.0 |  |

[0001564590-19-038508:8k_2_02:49]
The following table shows the GAAP to non-GAAP reconciliation for Q2 FY’20 guidance:

[0001564590-19-038508:8k_2_02:50]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.2% - 57.4% |  |  | (6.0%) - (3.4%) |  |  | ($0.18) - ($0.14) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.3% |  |  | 2.3% |  |  | $ | 0.05 |  |
| Stock based compensation | 0.2% |  |  | 3.2% |  |  | $ | 0.07 |  |
| Restructuring | - |  |  | 0.7% |  |  | $ | 0.02 |  |
| Acquisition and integration costs | - |  |  | 5.5% |  |  | $ | 0.12 |  |
| Adjustment to acquired inventories | 0.9% |  |  | 0.9% |  |  | $ | 0.02 |  |
| Amortization of non-product intangibles | 0.3% |  |  | 0.9% |  |  | $ | 0.02 |  |
| Non-GAAP | 59.1% - 61.1% |  |  | 7.8% - 9.9% |  |  | $0.12 - $0.16 |  |

[0001564590-19-038508:8k_2_02:51]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-19-038508:8k_2_02:52]
Conference Call:

[0001564590-19-038508:8k_2_02:53]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the first fiscal quarter results as well as the business outlook for second fiscal quarter ending December 31, 2019, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through November 7, 2019. The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 8878045. The encore recording will be available for 7 days following the call.

[0001564590-19-038508:8k_2_02:54]
About Extreme Networks:

[0001564590-19-038508:8k_2_02:55]
Extreme Networks, Inc. (EXTR) is the industry’s first cloud-driven, end-to-end enterprise networking company. Our best-of-breed technology solutions, from the wireless and IoT edge to the data center, are flexible, agile, and secure to accelerate the digital transformation of our customers and provide them with the fastest path to the autonomous enterprise. Our 100% in-sourced services and support are number one in the industry. Even with 50,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare, and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking™. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-19-038508:8k_2_02:56]
Extreme Networks and the Extreme Networks logo are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-19-038508:8k_2_02:57]
Non-GAAP Financial Measures:

[0001564590-19-038508:8k_2_02:58]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, inventory valuation adjustment, restructuring charges, gain on sale of equity investment, income tax and free cash flow.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-19-038508:8k_2_02:59]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a

[0001564590-19-038508:8k_2_02:60]
business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-19-038508:8k_2_02:61]
Forward Looking Statements:

[0001564590-19-038508:8k_2_02:62]
More information about potential factors that could affect the Company's business and financial results are described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" and "Risk Factors" included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2019 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-19-038508:8k_2_02:63]
###

[0001564590-19-038508:8k_2_02:64]
EXTREME NETWORKS, INC.

[0001564590-19-038508:8k_2_02:65]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-038508:8k_2_02:66]
(in thousands, except per share amounts)

[0001564590-19-038508:8k_2_02:67]
(Unaudited)

[0001564590-19-038508:8k_2_02:68]
|  |  | September 30, 2019 |  |  | June 30, 2019 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 131,369 |  |  | $ | 169,607 |  |
| Short term investments |  |  | 29,705 |  |  |  | — |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,431 and $1,054 respectively |  |  | 152,277 |  |  |  | 174,414 |  |
| Inventories |  |  | 82,394 |  |  |  | 63,589 |  |
| Prepaid expenses and other current assets |  |  | 38,963 |  |  |  | 34,379 |  |
| Total current assets |  |  | 434,708 |  |  |  | 441,989 |  |
| Property and equipment, net |  |  | 70,613 |  |  |  | 73,554 |  |
| Operating lease right-of-use assets, net |  |  | 62,576 |  |  |  | — |  |
| Intangible assets, net |  |  | 96,087 |  |  |  | 51,112 |  |
| Goodwill |  |  | 332,841 |  |  |  | 138,577 |  |
| Other assets |  |  | 54,967 |  |  |  | 51,642 |  |
| Total assets |  | $ | 1,051,792 |  |  | $ | 756,874 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,477 and $489, respectively |  | $ | 16,523 |  |  | $ | 9,011 |  |
| Accounts payable |  |  | 63,519 |  |  |  | 65,704 |  |
| Accrued compensation and benefits |  |  | 48,477 |  |  |  | 51,625 |  |
| Accrued warranty |  |  | 15,988 |  |  |  | 14,779 |  |
| Current portion, operating lease liability |  |  | 17,767 |  |  |  | — |  |
| Current portion, deferred revenue, net |  |  | 182,149 |  |  |  | 144,230 |  |
| Other accrued liabilities |  |  | 67,028 |  |  |  | 70,680 |  |
| Total current liabilities |  |  | 411,451 |  |  |  | 356,029 |  |
| Deferred revenue, less current portion |  |  | 91,508 |  |  |  | 59,012 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $7,594 and $1,261, respectively |  |  | 353,406 |  |  |  | 169,739 |  |
| Operating lease liability, less current portion |  |  | 61,539 |  |  |  | — |  |
| Deferred income taxes |  |  | 2,120 |  |  |  | 1,957 |  |
| Other long-term liabilities |  |  | 37,919 |  |  |  | 54,150 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000 shares authorized; 123,864 and 121,538 shares issued, respectively; 121,499 and 119,172 shares outstanding, respectively |  |  | 124 |  |  |  | 122 |  |
| Additional paid-in-capital |  |  | 1,003,268 |  |  |  | 986,772 |  |
| Accumulated other comprehensive loss |  |  | (3,371 | ) |  |  | (2,473 | ) |
| Accumulated deficit |  |  | (891,172 | ) |  |  | (853,434 | ) |
| Treasury stock at cost: 2,366 and 2,366 shares, respectively |  |  | (15,000 | ) |  |  | (15,000 | ) |
| Stockholders’ equity |  |  | 93,849 |  |  |  | 115,987 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,051,792 |  |  | $ | 756,874 |  |

[0001564590-19-038508:8k_2_02:69]
EXTREME NETWORKS, INC.

[0001564590-19-038508:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-038508:8k_2_02:71]
(In thousands, except per share amounts)

[0001564590-19-038508:8k_2_02:72]
(Unaudited)

[0001564590-19-038508:8k_2_02:73]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Net revenues: |  |  |  |  |  |  |  |  |
| Product |  | $ | 185,134 |  |  | $ | 177,720 |  |
| Service |  |  | 70,372 |  |  |  | 62,166 |  |
| Total net revenues |  |  | 255,506 |  |  |  | 239,886 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |
| Product |  |  | 91,391 |  |  |  | 83,543 |  |
| Service |  |  | 26,872 |  |  |  | 24,272 |  |
| Total cost of revenues |  |  | 118,263 |  |  |  | 107,815 |  |
| Gross profit: |  |  |  |  |  |  |  |  |
| Product |  |  | 93,743 |  |  |  | 94,177 |  |
| Service |  |  | 43,500 |  |  |  | 37,894 |  |
| Total gross profit |  |  | 137,243 |  |  |  | 132,071 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  |  | 59,116 |  |  |  | 51,241 |  |
| Sales and marketing |  |  | 71,357 |  |  |  | 67,582 |  |
| General and administrative |  |  | 14,982 |  |  |  | 12,771 |  |
| Acquisition and integration costs |  |  | 15,925 |  |  |  | 2,546 |  |
| Restructuring charges, net of reversals |  |  | 6,137 |  |  |  | 808 |  |
| Amortization of intangibles |  |  | 1,930 |  |  |  | 2,141 |  |
| Total operating expenses |  |  | 169,447 |  |  |  | 137,089 |  |
| Operating loss |  |  | (32,204 | ) |  |  | (5,018 | ) |
| Interest income |  |  | 667 |  |  |  | 394 |  |
| Interest expense |  |  | (5,164 | ) |  |  | (3,526 | ) |
| Other (expense) income, net |  |  | 558 |  |  |  | 487 |  |
| Loss before income taxes |  |  | (36,143 | ) |  |  | (7,663 | ) |
| Provision for income taxes |  |  | 1,595 |  |  |  | 1,402 |  |
| Net loss |  | $ | (37,738 | ) |  | $ | (9,065 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.31 | ) |  | $ | (0.08 | ) |
| Net loss per share - diluted |  | $ | (0.31 | ) |  | $ | (0.08 | ) |
| Shares used in per share calculation - basic |  |  | 120,226 |  |  |  | 117,368 |  |
| Shares used in per share calculation - diluted |  |  | 120,226 |  |  |  | 117,368 |  |

[0001564590-19-038508:8k_2_02:74]
EXTREME NETWORKS, INC.

[0001564590-19-038508:8k_2_02:75]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-038508:8k_2_02:76]
(In thousands)

[0001564590-19-038508:8k_2_02:77]
(Unaudited)

[0001564590-19-038508:8k_2_02:78]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (37,738 | ) |  | $ | (9,065 | ) |
| Adjustments to reconcile net loss to net cash (used in) provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 7,101 |  |  |  | 6,783 |  |
| Amortization of intangible assets |  |  | 8,425 |  |  |  | 7,073 |  |
| Amortization of operating lease right-of-use assets |  |  | 4,317 |  |  |  | - |  |
| Provision for doubtful accounts |  |  | 401 |  |  |  | 515 |  |
| Stock-based compensation |  |  | 8,834 |  |  |  | 6,825 |  |
| Deferred income taxes |  |  | 357 |  |  |  | (25 | ) |
| Non-cash restructuring and related charges |  |  | 3,839 |  |  |  | - |  |
| Unrealized/realized gain on equity investment |  |  | - |  |  |  | (154 | ) |
| Non-cash interest expense |  |  | 904 |  |  |  | 995 |  |
| Other |  |  | (78 | ) |  |  | (172 | ) |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 33,490 |  |  |  | 46,661 |  |
| Inventories |  |  | (2,108 | ) |  |  | 8,287 |  |
| Prepaid expenses and other assets |  |  | (486 | ) |  |  | (7,814 | ) |
| Accounts payable |  |  | (11,198 | ) |  |  | (31,251 | ) |
| Accrued compensation and benefits |  |  | (10,277 | ) |  |  | (13,964 | ) |
| Operating lease liabilities |  |  | (4,631 | ) |  |  | - |  |
| Deferred revenue |  |  | 2,001 |  |  |  | 9,374 |  |
| Other current and long-term liabilities |  |  | (3,355 | ) |  |  | 10,262 |  |
| Net cash (used in) provided by operating activities |  |  | (202 | ) |  |  | 34,330 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (5,239 | ) |  |  | (7,417 | ) |
| Business acquisitions, net of cash acquired |  |  | (219,458 | ) |  |  | — |  |
| Maturities and sales of investments |  |  | 15,503 |  |  |  | 727 |  |
| Net cash used in investing activities |  |  | (209,194 | ) |  |  | (6,690 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Term Loan |  |  | 199,500 |  |  |  | — |  |
| Loan fees on borrowings |  |  | (10,515 | ) |  |  | (273 | ) |
| Repayments of debt |  |  | (20,099 | ) |  |  | (12,466 | ) |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 4,136 |  |  |  | 7,137 |  |
| Contingent consideration obligations |  |  | (635 | ) |  |  | (1,577 | ) |
| Deferred payments on an acquisition |  |  | (1,000 | ) |  |  | (1,000 | ) |
| Net cash provided by (used in) financing activities |  |  | 171,387 |  |  |  | (8,179 | ) |
| Foreign currency effect on cash |  |  | (229 | ) |  |  | (433 | ) |
| Net (decrease) increase in cash |  |  | (38,238 | ) |  |  | 19,028 |  |
| Cash and cash equivalents at beginning of period |  |  | 169,607 |  |  |  | 121,139 |  |
| Cash and cash equivalents at end of period |  | $ | 131,369 |  |  | $ | 140,167 |  |

[0001564590-19-038508:8k_2_02:79]
Extreme Networks, Inc.

[0001564590-19-038508:8k_2_02:80]
Non-GAAP Measures of Financial Performance

[0001564590-19-038508:8k_2_02:81]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP earnings per diluted share and Free Cash Flow.

[0001564590-19-038508:8k_2_02:82]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, inventory valuation adjustments, gain on sale of equity investment, income tax and free cash flow.

[0001564590-19-038508:8k_2_02:83]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-19-038508:8k_2_02:84]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-19-038508:8k_2_02:85]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, inventory valuation adjustments, restructuring charges, gain on sale of equity investment, loss on lease contracts, income tax and free cash flow.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-19-038508:8k_2_02:86]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-19-038508:8k_2_02:87]
Stock-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its Employee Stock Purchase Plan.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-19-038508:8k_2_02:88]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-19-038508:8k_2_02:89]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, legal and professional fees related to the acquisition of Aerohive; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-19-038508:8k_2_02:90]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-19-038508:8k_2_02:91]
Inventory valuation adjustments.   Adjustments relating to the mark down of inventory due to end of life net of realized gross profit on the sale of inventory marked down in previous quarters.

[0001564590-19-038508:8k_2_02:92]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and impairment of right-of-use assets related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-19-038508:8k_2_02:93]
Income tax.   Income tax adjustment relates to the tax impact of a reduced US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation as well as the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada.

[0001564590-19-038508:8k_2_02:94]
We do not reflect a tax effect associated with the Non-GAAP operating adjustments as the adjustments are primarily related to the US entity which has a full valuation of various loss carryforward tax attributes.

[0001564590-19-038508:8k_2_02:95]
EXTREME NETWORKS, INC.

[0001564590-19-038508:8k_2_02:96]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-038508:8k_2_02:97]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-19-038508:8k_2_02:98]
(In thousands, except percentages and per share amounts)

[0001564590-19-038508:8k_2_02:99]
(Unaudited)

[0001564590-19-038508:8k_2_02:100]
| Non-GAAP Revenue | Three Months Ended |  |  |
|  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| Revenue - GAAP Basis | $ | 255,506 |  |  | $ | 239,886 |  |  |
| Revenue - Non-GAAP Basis | $ | 255,506 |  |  | $ | 239,886 |  |  |

[0001564590-19-038508:8k_2_02:101]
| Non-GAAP Gross Margin | Three Months Ended |  |  |
|  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| Gross profit - GAAP Basis | $ | 137,243 |  |  | $ | 132,071 |  |  |
| Gross margin - GAAP Basis percentage |  | 53.7 | % |  |  | 55.1 | % |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 597 |  |  |  | 523 |  |  |
| Acquired inventory adjustments |  | 3,869 |  |  |  | — |  |  |
| Acquisition and integration costs |  | 150 |  |  |  | 1,752 |  |  |
| Amortization of intangibles |  | 6,392 |  |  |  | 4,825 |  |  |
| Inventory valuation adjustments |  | 4,846 |  |  |  | — |  |  |
| Total adjustments to GAAP gross profit | $ | 15,854 |  |  | $ | 7,100 |  |  |
| Gross profit - Non-GAAP | $ | 153,097 |  |  | $ | 139,171 |  |  |
| Gross margin - Non-GAAP percentage |  | 59.9 | % |  |  | 58.0 | % |  |

[0001564590-19-038508:8k_2_02:102]
| Non-GAAP Operating Income | Three Months Ended |  |  |
|  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| GAAP operating loss | $ | (32,204 | ) |  | $ | (5,018 | ) |  |
| GAAP operating loss percentage |  | (12.6 | )% |  |  | (2.1 | )% |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Stock based compensation expense, cost of revenues |  | 597 |  |  |  | 523 |  |  |
| Stock based compensation expense, R&D |  | 2,435 |  |  |  | 2,342 |  |  |
| Stock based compensation expense, S&M |  | 3,719 |  |  |  | 2,359 |  |  |
| Stock based compensation expense, G&A |  | 2,083 |  |  |  | 1,601 |  |  |
| Inventory valuation adjustments |  | 4,846 |  |  |  | — |  |  |
| Acquisition and integration costs |  | 16,075 |  |  |  | 4,298 |  |  |
| Restructuring charge, net of reversal |  | 6,137 |  |  |  | 808 |  |  |
| Acquired inventory adjustments |  | 3,869 |  |  |  | — |  |  |
| Amortization of intangibles |  | 8,322 |  |  |  | 6,966 |  |  |
| Total adjustments to GAAP operating loss | $ | 48,083 |  |  | $ | 18,897 |  |  |
| Non-GAAP operating income | $ | 15,879 |  |  | $ | 13,879 |  |  |
| Non-GAAP operating income percentage |  | 6.2 | % |  |  | 5.8 | % |  |

[0001564590-19-038508:8k_2_02:103]
| Non-GAAP Net Income | Three Months Ended |  |  |
|  | September 30, 2019 |  |  | September 30, 2018 |  |  |
| GAAP net loss | $ | (37,738 | ) |  | $ | (9,065 | ) |  |
| Adjustments: |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 8,834 |  |  |  | 6,825 |  |  |
| Inventory valuation adjustments |  | 4,846 |  |  |  | — |  |  |
| Acquisition and integration costs |  | 16,075 |  |  |  | 4,298 |  |  |
| Restructuring charge, net of reversal |  | 6,137 |  |  |  | 808 |  |  |
| Acquired inventory adjustments |  | 3,869 |  |  |  | — |  |  |
| Amortization of intangibles |  | 8,322 |  |  |  | 6,966 |  |  |
| Income tax |  | — |  |  |  | (480 | ) |  |
| Total adjustments to GAAP net loss | $ | 48,083 |  |  | $ | 18,417 |  |  |
| Non-GAAP net income | $ | 10,345 |  |  | $ | 9,352 |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.08 |  |  | $ | 0.08 |  |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 123,705 |  |  |  | 120,242 |  |  |
