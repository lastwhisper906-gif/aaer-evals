# EXTR MD&A — 0000950170-24-098129


## mdna

[0000950170-24-098129:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000950170-24-098129:mdna:2]
Business Overview

[0000950170-24-098129:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Part II, Item 8 of this Annual Report on Form 10-K.

[0000950170-24-098129:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Annual Report on Form 10-K, which have been prepared in accordance with U.S. generally accepted accounting principles. In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period. In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0000950170-24-098129:mdna:5]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we,” “us” and “our”) is a leading provider of cloud networking solutions and industry leading services and support. We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999. Our corporate headquarters are located in Morrisville, North Carolina. We derive a majority of our revenues from the sale of our networking equipment, software subscriptions and services, and related maintenance contracts.

[0000950170-24-098129:mdna:6]
Extreme is a leading provider of cloud networking solutions and industry leading services and support. Extreme designs, develops and manufactures wired, wireless, and SD-WAN infrastructure equipment. The Company's cloud solution is a single platform that offers unified network management of wireless access points, switches and SD-WAN. It leverages ML, AI Operations, and analytics to help customers deliver secure connectivity at the edge of the network, speed cloud deployments, and uncover actionable insights to save time, lower costs and streamlines operations.

[0000950170-24-098129:mdna:7]
Enterprise network administrators need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security. Accelerators such as IoT, AI, BYOD, ML, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0000950170-24-098129:mdna:8]
A direction affecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud, and third-party, public cloud services with orchestration between multiple platforms. We introduced our Cloud offering in 2016 and in August 2019 acquired Aerohive Networks, Inc to enhance our Cloud strategy with a 3rd generation Cloud platform and to accelerate adoption of hybrid cloud networking solutions in the Enterprise. We believe Extreme’s enhanced Cloud solution is the only offering in the market that seamlessly integrates the cloud with on-premises infrastructures and enables visibility from the edge to everywhere. See Part 1, Item 1. Business, for additional discussion of our business.

[0000950170-24-098129:mdna:9]
Fiscal Year

[0000950170-24-098129:mdna:10]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2024” or “2024"; “fiscal 2023” or “2023”; “fiscal 2022” or “2022” represent the fiscal years ended, respectively.

[0000950170-24-098129:mdna:11]
Acquisitions

[0000950170-24-098129:mdna:12]
Ipanematech SAS

[0000950170-24-098129:mdna:13]
On September 14, 2021 (the “Acquisition Date”), we completed our acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network business unit of InfoVista pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million. The primary reason for the Acquisition was to acquire the talent and the technology to allow us to expand our portfolio with new cloud-managed SD-WAN and security offerings to support our enterprise customers. The acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanema were recorded at their respective fair values including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets. Results of operations of Ipanema are included in our operations beginning with the Acquisition Date. During the fiscal years ended June 30, 2023 and 2022, we recognized transaction costs related to this acquisition of $0.4 million and $7.0 million, respectively, which are included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0000950170-24-098129:mdna:14]
Results of Operations

[0000950170-24-098129:mdna:15]
The following is a summary of our results of operations during the fiscal year ended June 30, 2024:

[0000950170-24-098129:mdna:16]
•
Net revenues of $1,117.2 million, decreased 14.9% from fiscal 2023 net revenues of $1,312.5 million.

[0000950170-24-098129:mdna:17]
•
Product revenues of $699.3 million, decreased 25.0% from fiscal 2023 product revenues of $932.5 million.

[0000950170-24-098129:mdna:18]
•
Subscription and support revenues of $417.9 million, increased 10.0% from fiscal 2023 subscription and support revenues of $380.0 million.

[0000950170-24-098129:mdna:19]
•
Total gross margin of 56.5% of net revenues in fiscal 2024, compared to 57.5% in fiscal 2023.

[0000950170-24-098129:mdna:20]
•
Operating loss of $65.2 million in fiscal 2024, compared to operating income of $108.3 million in fiscal 2023.

[0000950170-24-098129:mdna:21]
•
Net loss was $86.0 million in fiscal 2024, compared to net income of $78.1 million in fiscal 2023.

[0000950170-24-098129:mdna:22]
•
Cash flow provided by operating activities of $55.5 million, compared to cash flow provided by operating activities of $249.2 million in fiscal 2023, a decrease of $193.7 million. Cash and cash equivalents were $156.7 million as of June 30, 2024, a decrease of $78.1 million, compared to $234.8 million at the end of fiscal 2023.

[0000950170-24-098129:mdna:23]
The Company’s reported loss per share for the year ended June 30, 2024, of $0.66 on the Company’s Consolidated Statement of Operations included within this report differs by a $0.01 as compared to the loss per share of $0.65 as reported on the Company’s Form 8-K filed with the SEC on August 7, 2024, due to a correction in shares used in the loss per share calculation for that period.

[0000950170-24-098129:mdna:24]
Net Revenues

[0000950170-24-098129:mdna:25]
The following table presents net product and subscription and support revenues for the fiscal years ended June 30, 2024, 2023 and 2022 (in thousands, except percentages):

[0000950170-24-098129:mdna:26]
|  |  | Year Ended |  | Year Ended |
|  |  | June 30,2024 |  | June 30,2023 |  | $Change |  | %Change |  | June 30,2023 |  | June 30, 2022 |  | $Change |  | %Change |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $699,257 |  | $932,454 |  | $(233,197) |  | (25.0)% |  | $932,454 |  | $761,721 |  | $170,733 |  | 22.4 % |
| Percentage of net revenues |  | 62.6% |  | 71.0% |  |  |  |  |  | 71.0% |  | 68.5% |  |  |  |  |
| Subscription and support |  | 417,946 |  | 380,000 |  | 37,946 |  | 10.0 % |  | 380,000 |  | 350,600 |  | 29,400 |  | 8.4 % |
| Percentage of net revenues |  | 37.4% |  | 29.0% |  |  |  |  |  | 29.0% |  | 31.5% |  |  |  |  |
| Total net revenues |  | $1,117,203 |  | $1,312,454 |  | $(195,251) |  | (14.9)% |  | $1,312,454 |  | $1,112,321 |  | $200,133 |  | 18.0 % |

[0000950170-24-098129:mdna:27]
We generate product revenues primarily from sales of our networking equipment. We derive subscription and support revenues primarily from sales of our subscription and support offerings which includes SaaS offerings, maintenance contracts, professional services and training for our products. Prior to fiscal 2024, we referred to subscription and support revenue as “service and subscription revenue;” however, the composition of subscription and support revenue has not been modified.

[0000950170-24-098129:mdna:28]
Product revenues decreased $233.2 million or 25.0% for the year ended June 30, 2024, compared to fiscal 2023. The product revenues decrease for the year ended June 30, 2024 as compared to fiscal 2023 was primarily driven by lower bookings and shipments as well as elongated sales cycles to end customers and lower channel sell-through caused by easing of supply chain constraints and current macroeconomic conditions.

[0000950170-24-098129:mdna:29]
Product revenues increased $170.7 million or 22.4% for the year ended June 30, 2023, compared to fiscal 2022. The product revenues increase for the year ended June 30, 2023 as compared to fiscal 2022 was primarily due to strong demand for our products and higher shipments resulting from an easing in supply chain constraints which had impacted our ability to fulfill the demand for our products during fiscal 2022.

[0000950170-24-098129:mdna:30]
Subscription and support revenues increased $37.9 million or 10.0% for the year ended June 30, 2024, compared to fiscal 2023. The increase in subscription and support revenues was primarily due to increased adoption of our cloud network management solutions, higher attachment rates of cloud support services on product sales, and continued growth in our subscription business.

[0000950170-24-098129:mdna:31]
Subscription and support revenues increased $29.4 million or 8.4% for the year ended June 30, 2023, compared to fiscal 2022. The increase in subscription and support revenues was primarily due to the growth in our subscription business.

[0000950170-24-098129:mdna:32]
We operate in three regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following table presents the total net revenues geographically for the fiscal years ended June 30, 2024, 2023 and 2022 (in thousands, except percentages):

[0000950170-24-098129:mdna:33]
|  |  | Year Ended |  | Year Ended |
| Net Revenues |  | June 30,2024 |  | June 30,2023 |  | $Change |  | %Change |  | June 30,2023 |  | June 30, 2022 |  | $Change |  | %Change |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $581,141 |  | $572,927 |  | $8,214 |  | 1.4 % |  | $572,927 |  | $503,635 |  | $69,292 |  | 13.8 % |
| Other |  | 46,578 |  | 84,108 |  | (37,530) |  | (44.6)% |  | 84,108 |  | 44,608 |  | 39,500 |  | 88.5 % |
| Total Americas |  | 627,719 |  | 657,035 |  | (29,316) |  | (4.5)% |  | 657,035 |  | 548,243 |  | 108,792 |  | 19.8 % |
| Percentage of net revenues |  | 56.2% |  | 50.1% |  |  |  |  |  | 50.1% |  | 49.3% |  |  |  |  |
| EMEA |  | 421,966 |  | 559,669 |  | (137,703) |  | (24.6)% |  | 559,669 |  | 477,081 |  | 82,588 |  | 17.3 % |
| Percentage of net revenues |  | 37.8% |  | 42.6% |  |  |  |  |  | 42.6% |  | 42.9% |  |  |  |  |
| APAC |  | 67,518 |  | 95,750 |  | (28,232) |  | (29.5)% |  | 95,750 |  | 86,997 |  | 8,753 |  | 10.1 % |
| Percentage of net revenues |  | 6.0% |  | 7.3% |  |  |  |  |  | 7.3% |  | 7.8% |  |  |  |  |
| Total net revenues |  | $1,117,203 |  | $1,312,454 |  | $(195,251) |  | (14.9)% |  | $1,312,454 |  | $1,112,321 |  | $200,133 |  | 18.0 % |

[0000950170-24-098129:mdna:34]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEMs and direct sales. Revenues through our distributor channel were 85% of total product revenues in fiscal 2024, 83% of total product revenues in fiscal 2023 and 80% of total product revenue in fiscal 2022.

[0000950170-24-098129:mdna:35]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0000950170-24-098129:mdna:36]
Cost of Revenues and Gross Profit

[0000950170-24-098129:mdna:37]
The following table presents the gross profit on product and subscription and support revenues and the gross profit percentage of net revenues for the fiscal years ended June 30, 2024, 2023 and 2022 (in thousands, except percentages):

[0000950170-24-098129:mdna:38]
|  |  | Year Ended |  | Year Ended |
|  |  | June 30,2024 |  | June 30,2023 |  | $Change |  | %Change |  | June 30,2023 |  | June 30, 2022 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $333,498 |  | $506,159 |  | $(172,661) |  | (34.1)% |  | $506,159 |  | $401,159 |  | $105,000 |  | 26.2 % |
| Percentage of product revenues |  | 47.7% |  | 54.3% |  |  |  |  |  | 54.3% |  | 52.7% |  |  |  |  |
| Subscription and support |  | 297,333 |  | 248,561 |  | 48,772 |  | 19.6 % |  | 248,561 |  | 228,779 |  | 19,782 |  | 8.6 % |
| Percentage of subscription and support revenues |  | 71.1% |  | 65.4% |  |  |  |  |  | 65.4% |  | 65.3% |  |  |  |  |
| Total gross profit |  | $630,831 |  | $754,720 |  | $(123,889) |  | (16.4)% |  | $754,720 |  | $629,938 |  | $124,782 |  | 19.8 % |
| Percentage of net revenues |  | 56.5% |  | 57.5% |  |  |  |  |  | 57.5% |  | 56.6% |  |  |  |  |

[0000950170-24-098129:mdna:39]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing, engineering, and document control at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0000950170-24-098129:mdna:40]
Product gross profit decreased to $333.5 million for the year ended June 30, 2024, from $506.2 million in fiscal 2023, primarily due to lower product revenues as well as an additional provision for excess and obsolete inventory and loss on supplier commitments of $64.5 million partially offset by lower amortization of intangibles due to certain intangibles being fully amortized, lower distribution costs due to easing of supply chain constraints, lower warranty reserves cost, and lower overhead costs. The increase in the provisions for excess and obsolete inventory and loss on supplier commitments during fiscal 2024 was primarily for certain of our older products which are scheduled to go end of sale during the Company’s fiscal year 2025 and for which excess of such inventories is beyond the demand forecast.

[0000950170-24-098129:mdna:41]
Product gross profit increased to $506.2 million for the year ended June 30, 2023, from $401.2 million in fiscal 2022, primarily due to increased product revenues along with lower amortization of intangibles of $3.8 million due to certain intangibles being fully amortized, and lower distribution costs of $1.1 million due to easing of supply chain constraints, partially offset by higher direct product costs, higher excess and obsolete inventory charges of $6.3 million and higher warranty reserves cost of $2.1 million.

[0000950170-24-098129:mdna:42]
Our cost of subscription and support revenues consist primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts as well as third-party professional services costs, data center costs and cloud hosting service costs.

[0000950170-24-098129:mdna:43]
Subscription and support gross profit increased to $297.3 million for the year ended June 30, 2024, from $248.6 million in fiscal 2023, primarily due to higher subscription and support revenues and lower headcount partially offset by higher professional services fees and increased cloud service costs.

[0000950170-24-098129:mdna:44]
Subscription and support gross profit increased to $248.6 million for the year ended June 30, 2023, from $228.8 million in fiscal 2022, primarily due to higher subscription and support revenues partially offset by higher professional services fees and increased cloud service costs.

[0000950170-24-098129:mdna:45]
Operating Expenses

[0000950170-24-098129:mdna:46]
The following table presents operating expenses for the fiscal years ended June 30, 2024, 2023 and 2022 (in thousands, except percentages):

[0000950170-24-098129:mdna:47]
|  |  | Year Ended |  | Year Ended |
|  |  | June 30,2024 |  | June 30,2023 |  | $Change |  | %Change |  | June 30,2023 |  | June 30, 2022 |  | $Change |  | %Change |
| Research and development |  | $211,931 |  | $214,270 |  | $(2,339) |  | (1.1)% |  | $214,270 |  | $190,591 |  | $23,679 |  | 12.4 % |
| Sales and marketing |  | 345,802 |  | 336,906 |  | 8,896 |  | 2.6 % |  | 336,906 |  | 294,470 |  | 42,436 |  | 14.4 % |
| General and administrative |  | 99,938 |  | 89,934 |  | 10,004 |  | 11.1 % |  | 89,934 |  | 68,697 |  | 21,237 |  | 30.9 % |
| Acquisition and integration costs |  | — |  | 390 |  | (390) |  | (100.0)% |  | 390 |  | 7,009 |  | (6,619) |  | (94.4)% |
| Restructuring and related charges |  | 36,321 |  | 2,860 |  | 33,461 |  | 1,170.0 % |  | 2,860 |  | 1,748 |  | 1,112 |  | 63.6 % |
| Amortization of intangible assets |  | 2,041 |  | 2,047 |  | (6) |  | (0.3)% |  | 2,047 |  | 3,235 |  | (1,188) |  | (36.7)% |
| Total operating expenses |  | $696,033 |  | $646,407 |  | $49,626 |  | 7.7 % |  | $646,407 |  | $565,750 |  | $80,657 |  | 14.3 % |

[0000950170-24-098129:mdna:48]
The following table highlights our operating expenses and operating income as a percentage of net revenues for the fiscal years ended June 30, 2024, 2023 and 2022:

[0000950170-24-098129:mdna:49]
|  |  | Year Ended |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |
| Research and development |  |  | 19.0 | % |  |  | 16.3 | % |  |  | 17.1 | % |
| Sales and marketing |  |  | 31.0 | % |  |  | 25.7 | % |  |  | 26.5 | % |
| General and administrative |  |  | 8.9 | % |  |  | 6.9 | % |  |  | 6.2 | % |
| Acquisition and integration costs |  |  | — |  |  |  | — |  |  |  | 0.6 | % |
| Restructuring and related charges |  |  | 3.3 | % |  |  | 0.2 | % |  |  | 0.2 | % |
| Amortization of intangible assets |  |  | 0.2 | % |  |  | 0.2 | % |  |  | 0.3 | % |
| Total operating expenses |  |  | 62.3 | % |  |  | 49.2 | % |  |  | 50.9 | % |
| Operating income (loss) |  |  | (5.8 | )% |  |  | 8.3 | % |  |  | 5.8 | % |

[0000950170-24-098129:mdna:50]
Research and Development Expenses

[0000950170-24-098129:mdna:51]
Research and development expenses consist primarily of personnel costs (which includes compensation, benefits and stock-based compensation), consultant fees and engineering expenses related to the design, development, and testing of our products.

[0000950170-24-098129:mdna:52]
Research and development expenses decreased by $2.3 million or 1.1% for the year ended June 30, 2024 as compared to fiscal 2023, primarily due to a $2.8 million decrease in personnel costs due to lower compensation and benefits costs, a $2.9 million decrease in non-recurring engineering project costs, offset by a $3.4 million increase in contractor costs.

[0000950170-24-098129:mdna:53]
Research and development expenses increased by $23.7 million or 12.42% for the year ended June 30, 2023 as compared to fiscal 2022, primarily due to a $15.4 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation and higher headcount, a $3.8 million increase in third-party software licenses and engineering project costs, a $2.2 million increase in contractor and consultant fees, a $1.3 million increase in facility and information technology costs and a $2.3 million increase in other costs primarily related to travel.

[0000950170-24-098129:mdna:54]
Sales and Marketing Expenses

[0000950170-24-098129:mdna:55]
Sales and marketing expenses consist of personnel costs (which includes compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0000950170-24-098129:mdna:56]
Sales and marketing expenses increased by $8.9 million or 2.6% for the year ended June 30, 2024, as compared to fiscal 2023, primarily due to a $1.5 million increase in personnel costs due to higher salaries and benefits costs, a $7.2 million increase in sales promotions and marketing related expenses, and a $1.2 million increase in professional fees offset by a $1.0 million decrease in other costs primarily related to contractor costs and travel costs.

[0000950170-24-098129:mdna:57]
Sales and marketing expenses increased by $42.4 million or 14.4% for the year ended June 30, 2023, as compared to fiscal 2022, primarily due to a $35.1 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $5.9 million increase in travel expenses due to loosening of COVID-19 restrictions, and a $1.4 million increase in other expenses primarily professional fees and sales and marketing activities.

[0000950170-24-098129:mdna:58]
General and Administrative Expenses

[0000950170-24-098129:mdna:59]
General and administrative expenses consist primarily of personnel costs (which includes compensation, benefits and share-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0000950170-24-098129:mdna:60]
General and administrative expenses increased by $10.0 million or 11.1% for the year ended June 30, 2024, as compared to fiscal 2023, primarily due to a $2.5 million increase in personnel costs due to higher salaries and benefits costs, a $3.4 million increase in professional fees primarily related to legal and litigation matters, a  $4.3 million increase in system transition costs, and a $2.4 million increase in third-party licensing fees, partially offset by a $2.6 million decrease in other expenses primarily for depreciation expense.

[0000950170-24-098129:mdna:61]
General and administrative expenses increased by $21.2 million or 30.9% for the year ended June 30, 2023, as compared to fiscal 2022, primarily due to a $10.1 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation and higher headcount, a $6.2 million increase in professional fees primarily for legal fees, a $5.1 million increase for litigation settlement charges, a $0.9 million increase in system transition costs, partially offset by a $1.2 million decrease in other expenses primarily for travel and facilities related costs.

[0000950170-24-098129:mdna:62]
Acquisition and Integration Costs

[0000950170-24-098129:mdna:63]
The Company did not incur any acquisition or integration costs during the fiscal year ended June 30, 2024.

[0000950170-24-098129:mdna:64]
For fiscal 2023, the Company incurred $0.4 million of acquisition and integration costs which consisted primarily of professional fees and certain compensation charges related to the acquisition of Ipanema in fiscal year 2022.

[0000950170-24-098129:mdna:65]
For fiscal 2022, the Company incurred $7.0 million of acquisition and integration costs which consisted primarily of professional fees for product integration, system integration, financial, legal and advisory services related to the acquisition of Ipanema.

[0000950170-24-098129:mdna:66]
Restructuring and Related Charges

[0000950170-24-098129:mdna:67]
During the fiscal years ended June 30, 2024, 2023 and 2022, we recorded restructuring and related charges of $36.3 million, $2.9 million and $1.7 million, respectively.

[0000950170-24-098129:mdna:68]
Fiscal year 2024

[0000950170-24-098129:mdna:69]
During fiscal 2024, the Company recorded $36.3 million of restructuring charges which were primarily related to severance and benefits costs and professional services fees associated with the reduction-in-force actions related to the “Q1 2024 Plan”, “Q2 2024 Plan”, and "Q3 2024 Plan", each as described in Note 15, Restructuring and Related Charges, in Notes to the Consolidated Financial Statements included elsewhere in this Report.

[0000950170-24-098129:mdna:70]
Fiscal year 2023

[0000950170-24-098129:mdna:71]
During fiscal 2023, the Company recorded $2.9 million of restructuring charges which was primarily comprised of $2.0 million of facility related charges related to our previously impaired facilities and $0.9 million in charges associated with our restructuring plan initiated in the third quarter of fiscal 2023 to transform our business and facilities infrastructure.

[0000950170-24-098129:mdna:72]
Fiscal year 2022

[0000950170-24-098129:mdna:73]
During fiscal 2022, the Company recorded $1.7 million of restructuring charges which was primarily comprised of facility related charges. The facility restructuring charges included some impairment charges and additional facilities expenses related to previously impaired facilities. During fiscal 2022, the Company completed the reduction-in-force action initiated in the third quarter of fiscal 2020.

[0000950170-24-098129:mdna:74]
Amortization of Intangible Assets

[0000950170-24-098129:mdna:75]
During the fiscal years ended June 30, 2024, 2023 and 2022, we recorded $2.0 million, $2.0 million and $3.2 million, respectively, of amortization expense in operating expenses primarily for certain intangibles related to the acquisitions of the Ipanema, and Aerohive businesses. There were no acquisitions or impairments of intangible assets during fiscal year 2024. The decrease in amortization expense in fiscal 2023 from fiscal 2022 was primarily due to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0000950170-24-098129:mdna:76]
Interest Income

[0000950170-24-098129:mdna:77]
Interest income was $4.6 million, $3.2 million and $0.4 million in fiscal years ended June 30, 2024, 2023 and 2022, respectively. Interest income increased across each of the periods primarily due to higher interest earned on cash deposits.

[0000950170-24-098129:mdna:78]
Interest Expense

[0000950170-24-098129:mdna:79]
We incurred $17.0 million, $17.4 million, and $12.8 million of interest expense for fiscal years ended June 30, 2024, 2023 and 2022, respectively. The decrease in interest expense in fiscal year ended June 30, 2024 as compared to fiscal 2023 was primarily driven by lower carrying balances under the 2023 Credit Agreement. The increase in interest expense in fiscal year ended June 30, 2023 as compared to fiscal 2022 was primarily driven by higher average rates under our Credit Agreements and write-off of the unamortized deferred financing costs related to our 2019 Credit Agreement, as we amended the 2019 Credit Agreement and entered into the 2023 Credit Agreement during June 2023. For a discussion of our credit agreements, see the section titled "Liquidity and Capital Resources" below.

[0000950170-24-098129:mdna:80]
Other Income, net

[0000950170-24-098129:mdna:81]
We had other income, net of less than $0.1 million, $0.1 million, and $0.4 million in fiscal years ended June 30, 2024, 2023 and 2022, respectively. The other income, net for fiscal years ended June 30, 2024, 2023 and 2022 was primarily due to foreign exchange gains from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-24-098129:mdna:82]
Provision for Income Taxes

[0000950170-24-098129:mdna:83]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rate differs from the U.S. federal statutory rate of 21% primarily due to the impact of (i) GILTI, (ii) the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions, (iii) foreign income taxes of our international subsidiaries, and (iv) U.S. state taxes. For the fiscal years ended June 30, 2024, 2023 and 2022, we recorded income tax provisions of $8.5 million, $16.0 million, and $7.9 million respectively.

[0000950170-24-098129:mdna:84]
For fiscal 2024, 2023 and 2022, our tax provision is primarily related to (i) taxes on our foreign operations, including foreign withholding taxes remitted to foreign tax authorities by customers on our behalf, (ii) tax expense related to the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business and (iii) state taxes in states where we have exhausted available Net Operating Losses or are subject to certain franchise taxes qualifying as income tax under the relevant tax accounting guidance. In addition, our tax provision for the fiscal year ended June 30, 2024 included $1.3 million of U.S. federal tax.

[0000950170-24-098129:mdna:85]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 16, Income Taxes, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K.

[0000950170-24-098129:mdna:86]
Critical Accounting Policies and Estimates

[0000950170-24-098129:mdna:87]
Our significant accounting policies are more fully described in Note 2, Summary of Significant Accounting Policies, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0000950170-24-098129:mdna:88]
Revenue Recognition

[0000950170-24-098129:mdna:89]
We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from software delivered as a service (“SaaS”) and support fees relating to maintenance contracts, professional services, and training for our products. We sell our products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0000950170-24-098129:mdna:90]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, we consider the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0000950170-24-098129:mdna:91]
We generally do not grant return privileges and pricing credits to our value-added resellers, non-stocking distributors and end-user customers, except for defective products during the warranty period. We may provide sales incentives and other programs to these customers which are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the historical actuals.

[0000950170-24-098129:mdna:92]
Our stocking distributors are allowed certain price adjustments in the form of rebates and limited stock rotation rights. In determining the transaction price, we consider these rebates to be variable consideration which are estimated based on an analysis of historical claims at the distributor level. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotations are an additional form of variable consideration and are estimated based on an analysis of historical return rates.

[0000950170-24-098129:mdna:93]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price. The stand-alone selling prices are determined based on the prices at which we separately sell these products. For items that are not sold separately, we estimate the stand-alone selling prices using other observable inputs.

[0000950170-24-098129:mdna:94]
Our performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of our product sales revenues are recognized at a point in time and our subscription and support revenues are recognized over time. For revenues recognized over time, we use an input measure, days elapsed, to measure progress.

[0000950170-24-098129:mdna:95]
See Note 3, Revenues, in Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information.

[0000950170-24-098129:mdna:96]
Business Combinations

[0000950170-24-098129:mdna:97]
We apply the acquisition method of accounting for business combinations. Under this method of accounting, all tangible and intangible assets acquired and liabilities assumed are recorded at their respective fair values at the acquisition date. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to expected future cash inflows and outflows, discount rates, intangibles and other asset lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date (an exit price). Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, we may have been required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results. Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0000950170-24-098129:mdna:98]
Inventory Valuation and Purchase Commitments

[0000950170-24-098129:mdna:99]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0000950170-24-098129:mdna:100]
New Accounting Pronouncements

[0000950170-24-098129:mdna:101]
See Note 2, Summary of Significant Accounting Policies, in Notes to the Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0000950170-24-098129:mdna:102]
Liquidity and Capital Resources

[0000950170-24-098129:mdna:103]
The following summarizes information regarding our cash and cash equivalents (in thousands):

[0000950170-24-098129:mdna:104]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Cash and cash equivalents |  | $ | 156,699 |  |  | $ | 234,826 |  |

[0000950170-24-098129:mdna:105]
As of June 30, 2024, our principal sources of liquidity consisted of cash and cash equivalents of $156.7 million, accounts receivable, net of $89.5 million and available borrowings under our five-year 2023 Revolving Facility (as defined below) of $135.8 million. We anticipate our principal uses of cash and cash equivalents for fiscal 2025 will be purchases of finished goods inventory from our contract manufacturers, payroll, share repurchases, payments under debt obligations and related interest, payments under lease obligations, purchases of property and equipment and other operating expenses related to the development and marketing of our products. We believe that our existing cash and cash equivalents, cash flows from operations, and the availability of borrowings from the 2023 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months. We are not currently aware

[0000950170-24-098129:mdna:106]
of any material cash requirements beyond the next 12 months other than those described above for fiscal 2024 and our known contractual obligations. See the section titled “Contractual Obligations” below.

[0000950170-24-098129:mdna:107]
On May 18, 2022, our Board of Directors authorized a share repurchase program with authorization to repurchase up to $200.0 million of our common stock over a three-year period beginning in our fiscal year commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. The current repurchase authorization supersedes and replaces any previously authorized repurchase programs. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the year ended June 30, 2024, we repurchased a total of 2,365,220 shares of common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. As of June 30, 2024, we have $50.3 million available under our share repurchase program.

[0000950170-24-098129:mdna:108]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among Extreme, as borrower, several banks and other financial institutions as Lenders, BMO Capital Markets Corp., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders. On June 22, 2023, we entered into the Second Amended and Restated Credit Agreement (the “2023 Credit Agreement) by and among Extreme, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, BOFA Securities, Inc.., JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and Wells Fargo Securities, LLC, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “Term Facility”), ii) a $150.0 million five-year revolving credit facility (the “Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million plus an unlimited amount that is subject to pro forma compliance with a specified Consolidated Leverage Ratio tests. We may use proceeds of the loans for working capital and general corporate purposes. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit, which was subsequently paid off on July 7, 2023. During the quarter ended June 30, 2024, the Company borrowed and subsequently repaid $30.0 million against its $150.0 million revolving credit facility.

[0000950170-24-098129:mdna:109]
At the Company’s election, the initial term loan (the “Initial Term Loan”) under the 2023 Credit Agreement may be made as either a base rate loan or a Secured Overnight Financing Data Rate (“SOFR loan"). The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s Consolidated Leverage Ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company also agrees to pay other closing fees, arrangement fees, and administration fees.

[0000950170-24-098129:mdna:110]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-24-098129:mdna:111]
Key Components of Cash Flows and Liquidity

[0000950170-24-098129:mdna:112]
A summary of the sources and uses of cash and cash equivalents is as follows for the fiscal years ended June 30, 2024, 2023 and 2022 (in thousands):

[0000950170-24-098129:mdna:113]
|  |  | Year Ended |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |
| Net cash provided by operating activities |  | $ | 55,486 |  |  | $ | 249,212 |  |  | $ | 128,177 |  |
| Net cash used in investing activities |  |  | (18,121 | ) |  |  | (13,800 | ) |  |  | (84,950 | ) |
| Net cash used in financing activities |  |  | (114,978 | ) |  |  | (194,783 | ) |  |  | (94,663 | ) |
| Foreign currency effect on cash and cash equivalents |  |  | (514 | ) |  |  | (325 | ) |  |  | (936 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (78,127 | ) |  | $ | 40,304 |  |  | $ | (52,372 | ) |

[0000950170-24-098129:mdna:114]
Cash and cash equivalents were $156.7 million at June 30, 2024, representing a decrease of $78.1 million from $234.8 million at June 30, 2023. This decrease was primarily due to cash used in financing activities of $115.0 million mainly as a result of payments for borrowings under the 2023 Credit Agreement and share repurchases as well as cash used in investing activities of $18.1 million primarily for the purchase of property and equipment, which is offset by cash provided by operating activities of $55.5 million.

[0000950170-24-098129:mdna:115]
Cash and cash equivalents were $234.8 million at June 30, 2023, representing an increase of $40.3 million from $194.5 million at June 30, 2022. This increase was primarily due to cash provided by operating activities of $249.2 million, which is offset by cash used in financing activities of $194.8 million mainly as a result of payments on the 2019 Initial Term Loan and share repurchases and cash used in investing activities of $13.8 million primarily for the purchase of property and equipment.

[0000950170-24-098129:mdna:116]
Net Cash Provided by Operating Activities

[0000950170-24-098129:mdna:117]
Cash provided by operating activities during the fiscal year ended June 30, 2024 was $55.5 million. Factors contributing to cash provided by operating activities were the net loss of $86.0 million, non-cash expenses of $187.6 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included a decrease in account receivable and increases in deferred revenue and other current liabilities. These amounts were partially offset by increases in inventories and prepaid expenses and other assets and decreases in accounts payable, accrued compensation and benefits, and operating lease liabilities.

[0000950170-24-098129:mdna:118]
Cash provided by operating activities during the fiscal year ended June 30, 2023 was $249.2 million. Factors contributing to cash provided by operating activities were net income of $78.1 million, non-cash expenses of $104.6 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included decrease in account receivable and increases in accounts payable, accrued compensation and deferred revenue. These amounts were partially offset by increases in inventories and prepaid expenses and other assets and decreases in operating lease liabilities.

[0000950170-24-098129:mdna:119]
Cash provided by operating activities during the fiscal year ended June 30, 2022 was $128.2 million. Factors contributing to cash provided by operating activities were net income of $44.3 million, non-cash expenses of $104.0 million for items such as amortization of intangible assets, stock-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, provision for excess and obsolete inventory and interest. Other sources of cash for the period included increases in accounts payable and deferred revenue. These amounts were partially offset by increases in accounts receivable, inventories and prepaid expenses and other assets and decreases in accrued compensation, current and long-term liabilities and operating lease liabilities.

[0000950170-24-098129:mdna:120]
Net Cash Used in Investing Activities

[0000950170-24-098129:mdna:121]
Cash used in investing activities during the fiscal year ended June 30, 2024 was $18.1 million for the purchases of property and equipment.

[0000950170-24-098129:mdna:122]
Cash used in investing activities during the fiscal year ended June 30, 2023 was $13.8 million for the purchases of property and equipment.

[0000950170-24-098129:mdna:123]
Cash used in investing activities during the fiscal year ended June 30, 2022 was $85.0 million, primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $15.4 million for purchases of property and equipment.

[0000950170-24-098129:mdna:124]
Net Cash Used in by Financing Activities

[0000950170-24-098129:mdna:125]
Cash used in financing activities during the fiscal year ended June 30, 2024 was $115.0 million due primarily to share repurchases of $49.9 million, payments on the 2023 Revolving Facility of $55.0 million, debt repayments of $10.0 million and a $30.1 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”). The amounts were partially offset by cash received of $30.0 million from borrowings under the 2023 Revolving Facility.

[0000950170-24-098129:mdna:126]
Cash used in financing activities during the fiscal year ended June 30, 2023 was $194.8 million due primarily to share repurchases of $99.9 million, debt repayments of $108.6 million, payments of debt financing cost of $3.2 million, $3.0 million of deferred payments on acquisitions and a $5.1 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP. The amounts were partially offset by cash received of $25.0 million from the 2023 Revolving Facility.

[0000950170-24-098129:mdna:127]
Cash used in financing activities during the fiscal year ended June 30, 2022 was $94.7 million due primarily to share repurchases of $45.0 million, debt repayments of $38.1 million, payments of contingent consideration of $1.0 million and $4.0 million of deferred payments on acquisitions and a $6.5 million payment for taxes on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options.

[0000950170-24-098129:mdna:128]
Foreign Currency Effect on Cash and cash equivalents

[0000950170-24-098129:mdna:129]
Foreign currency effect on cash and cash equivalents increased in 2024, primarily due to changes in exchange rates between the U.S. Dollar and particularly the Indian Rupee, U.K. Pound, and the Euro.

[0000950170-24-098129:mdna:130]
Contractual Obligations

[0000950170-24-098129:mdna:131]
As of June 30, 2024, we have contractual obligations for debt obligations, purchase obligations, lease obligations and other obligations.

[0000950170-24-098129:mdna:132]
Our debt obligations relate to amounts owed under our 2023 Credit Agreement. As of June 30, 2024, we have $190.0 million of debt outstanding which is payable in quarterly installments through our fiscal year 2028. We are subject to interest on our debt obligations and unused commitment fee. See Note 8, Debt, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our debt obligations.

[0000950170-24-098129:mdna:133]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of June 30, 2024, we have non-cancelable commitments to purchase $38.2 million of inventory. See Note 10, Commitments and Contingencies, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our purchase obligations.

[0000950170-24-098129:mdna:134]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2033. As of June 30, 2024, the value of our obligations under operating leases was $61.9 million. See Note 9, Leases, in the Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K for additional information regarding our lease obligations.

[0000950170-24-098129:mdna:135]
We have contractual commitments with our suppliers which represent commitments for future services. As of June 30, 2024, we have contractual commitments of $25.9 million that are due through our fiscal year 2027.

[0000950170-24-098129:mdna:136]
We have immaterial income tax liabilities related to uncertain tax positions and we are unable to reasonably estimate the timing of the settlement of those liabilities.

[0000950170-24-098129:mdna:137]
We do not have any material commitments for capital expenditures as of June 30, 2024.

[0000950170-24-098129:mdna:138]
Off-Balance Sheet Arrangements

[0000950170-24-098129:mdna:139]
We did not have any off-balance sheet arrangements as of June 30, 2024.
