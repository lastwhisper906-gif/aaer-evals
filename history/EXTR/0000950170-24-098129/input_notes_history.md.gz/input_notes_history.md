# EXTR note change history — 0000950170-24-009819 → 0000950170-24-052140


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000950170-24-052140:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2024, the Company had commitments to purchase $51.5 million of inventory.
  (was, 2024-02-01, similarity 0.9893):
[0000950170-24-009819:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2023, the Company had commitments to purchase $92.1 million of inventory.

- changed (2024-05-02):
[0000950170-24-052140:note_history:2]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint, which was denied on January 30, 2024. On March 20, 2023, the Company filed a motion to refer questions to the U.S. Copyright Office on the invalidity of SNMP’s copyrights, which was denied on March 18, 2024. The trial date has been set for October 2024.
  (was, 2024-02-01, similarity 0.8137):
[0000950170-24-009819:note_history:2]
prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000950170-24-052140:note_history:3]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2024. The results of operations for the three and nine months ended March 31, 2024 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.
  (was, 2024-02-01, similarity 0.9404):
[0000950170-24-009819:note_history:3]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2023. The results of operations for the three and six months ended December 31, 2023 are not necessarily indicative of the results that may be expected for fiscal 2024 or any future periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000950170-24-052140:note_history:4]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (674 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,326 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 182,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,903 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 180,597 |  |  |  | 187,591 |  |
| Total debt |  | $ | 189,923 |  |  | $ | 221,917 |  |
  (was, 2024-02-01, similarity 0.9884):
[0000950170-24-009819:note_history:4]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 185,000 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,069 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 182,931 |  |  |  | 187,591 |  |
| Total debt |  | $ | 192,256 |  |  | $ | 221,917 |  |

- changed (2024-05-02):
[0000950170-24-052140:note_history:5]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the nine months ended March 31, 2024, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.
  (was, 2024-02-01, similarity 0.9629):
[0000950170-24-009819:note_history:5]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. During the six months ended December 31, 2023, the Company was in compliance with all the terms and financial covenants of the 2023 Credit Agreement.

- changed (2024-05-02):
[0000950170-24-052140:note_history:6]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended March 31, 2024 and 2023, respectively, and were $0.8 million and $2.2 million for the nine months ended March 31, 2024 and 2023, respectively. The interest rate as of March 31, 2024 was 7.44% and as of March 31, 2023 was 5.97%.
  (was, 2024-02-01, similarity 0.9218):
[0000950170-24-009819:note_history:6]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.3 million and $0.7 million for the three months ended December 31, 2023 and 2022, respectively, and were $0.5 million and $1.5 million for the six months ended December 31, 2023 and 2022, respectively. The interest rate as of December 31, 2023 was 7.46% and as of December 31, 2022 was 5.50%.

- changed (2024-05-02):
[0000950170-24-052140:note_history:7]
As of March 31, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.5 million of availability under the 2023 Revolving Facility as of March 31, 2024. During the three and nine months ended March 31, 2024 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the nine months ended March 31, 2023, the Company made an additional payment of $45.5 million, against its term loan facility under the 2019 Credit Agreement.
  (was, 2024-02-01, similarity 0.8256):
[0000950170-24-009819:note_history:7]
As of December 31, 2023, the Company did not have any outstanding balance against its 2023 Revolving Facility’s outstanding balance. The Company had $135.5 million of availability under the 2023 Revolving Facility as of December 31, 2023. During the three and six months ended December 31, 2023 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement. During the six months ended December 31, 2022, the Company made an additional payment of $30.0 million, against its term loan facility under the 2023 Credit Agreement.

- changed (2024-05-02):
[0000950170-24-052140:note_history:8]
The Company had $14.5 million of outstanding letters of credit as of March 31, 2024.
  (was, 2024-02-01, similarity 0.9412):
[0000950170-24-009819:note_history:8]
The Company had $14.5 million of outstanding letters of credit as of December 31, 2023.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000950170-24-052140:note_history:9]
|  |  | March 31,2024 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (674 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,326 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 182,500 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,903 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 180,597 |  |  |  | 187,591 |  |
| Total debt |  | $ | 189,923 |  |  | $ | 221,917 |  |
  (was, 2024-02-01, similarity 0.9884):
[0000950170-24-009819:note_history:9]
|  |  | December 31,2023 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (675 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,325 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 185,000 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (2,069 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 182,931 |  |  |  | 187,591 |  |
| Total debt |  | $ | 192,256 |  |  | $ | 221,917 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000950170-24-052140:note_history:10]
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 52,543 |  | $ | 71,539 |  | $ | 124,082 |  |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |
| Other |  |  | 5,934 |  |  | 4,357 |  |  | 10,291 |  |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |
| Total Americas |  |  | 58,477 |  |  | 75,896 |  |  | 134,373 |  |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |
| EMEA |  |  | 18,313 |  |  | 40,722 |  |  | 59,035 |  |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |
| APAC* |  |  | (1,464 | ) |  | 19,092 |  |  | 17,628 |  |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |
| Total net revenues |  | $ | 75,326 |  | $ | 135,710 |  | $ | 211,036 |  |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |
  (was, 2024-02-01, similarity 0.9494):
[0000950170-24-009819:note_history:10]
|  |  | Three Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 81,350 |  | $ | 68,199 |  | $ | 149,549 |  |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |
| Other |  |  | 8,244 |  |  | 4,842 |  |  | 13,086 |  |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |
| Total Americas |  |  | 89,594 |  |  | 73,041 |  |  | 162,635 |  |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |
| EMEA |  |  | 64,082 |  |  | 46,523 |  |  | 110,605 |  |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |
| APAC |  |  | 8,864 |  |  | 14,273 |  |  | 23,137 |  |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |
| Total net revenues |  | $ | 162,540 |  | $ | 133,837 |  | $ | 296,377 |  |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |

- changed (2024-05-02):
[0000950170-24-052140:note_history:11]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 251,694 |  | $ | 204,689 |  | $ | 456,383 |  |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |
| Other |  |  | 16,709 |  |  | 19,565 |  |  | 36,274 |  |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |
| Total Americas |  |  | 268,403 |  |  | 224,254 |  |  | 492,657 |  |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |
| EMEA |  |  | 184,706 |  |  | 128,537 |  |  | 313,243 |  |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |
| APAC |  |  | 7,510 |  |  | 47,140 |  |  | 54,650 |  |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |
| Total net revenues |  | $ | 460,619 |  | $ | 399,931 |  | $ | 860,550 |  |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |
  (was, 2024-02-01, similarity 0.9253):
[0000950170-24-009819:note_history:11]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 199,151 |  | $ | 133,150 |  | $ | 332,301 |  |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |
| Other |  |  | 10,775 |  |  | 15,208 |  |  | 25,983 |  |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |
| Total Americas |  |  | 209,926 |  |  | 148,358 |  |  | 358,284 |  |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |
| EMEA |  |  | 166,393 |  |  | 87,815 |  |  | 254,208 |  |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |
| APAC |  |  | 8,975 |  |  | 28,047 |  |  | 37,022 |  |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |
| Total net revenues |  | $ | 385,294 |  | $ | 264,220 |  | $ | 649,514 |  |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |

- added (2024-05-02):
[0000950170-24-052140:note_history:12]
*The distributor revenue in the APAC region for the three months ended March 31, 2024 reflects a higher level of customer rebates for the distributors, resulting from higher sell-through to end users than the Company's product sales into these distributors.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000950170-24-052140:note_history:13]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, SaaS and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.
  (was, 2024-02-01, similarity 0.9995):
[0000950170-24-009819:note_history:13]
The Company accounts for revenues in accordance with Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers. The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products,  SaaS, and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock the Company's products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

- changed (2024-05-02):
[0000950170-24-052140:note_history:14]
On March 31, 2024, the Company had $558.3 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 18% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 42% in fiscal 2025, and 40% of the balance thereafter.
  (was, 2024-02-01, similarity 0.9803):
[0000950170-24-009819:note_history:14]
On December 31, 2023, the Company had $548.2 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 32% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 34% in fiscal 2025, and 34% of the balance thereafter.

- changed (2024-05-02):
[0000950170-24-052140:note_history:15]
Revenue recognized for the three months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $95.9 million and $81.0 million, respectively. Revenue recognized for the nine months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $230.8 million and $193.7 million, respectively.
  (was, 2024-02-01, similarity 0.9194):
[0000950170-24-009819:note_history:15]
Revenue recognized for the three months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $105.7 million and $83.9 million, respectively. Revenue recognized for the six months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $172.0 million and $145.7 million, respectively.

- changed (2024-05-02):
[0000950170-24-052140:note_history:16]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.7 million and $20.0 million at March 31, 2024 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three and a half years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2024 and 2023 was $2.8 million and $2.3 million, respectively. Amortization recognized during the nine months ended March 31, 2024 and 2023 was $8.0 million and $6.7 million, respectively.
  (was, 2024-02-01, similarity 0.8182):
[0000950170-24-009819:note_history:16]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.2 million and $20.0 million at December 31, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2023 and 2022 was $2.7 million and $2.2 million, respectively. Amortization recognized during the six months ended December 31, 2023 and 2022 was $5.2 million and $4.3 million, respectively.

- changed (2024-05-02):
[0000950170-24-052140:note_history:17]
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 52,543 |  | $ | 71,539 |  | $ | 124,082 |  |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |
| Other |  |  | 5,934 |  |  | 4,357 |  |  | 10,291 |  |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |
| Total Americas |  |  | 58,477 |  |  | 75,896 |  |  | 134,373 |  |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |
| EMEA |  |  | 18,313 |  |  | 40,722 |  |  | 59,035 |  |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |
| APAC* |  |  | (1,464 | ) |  | 19,092 |  |  | 17,628 |  |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |
| Total net revenues |  | $ | 75,326 |  | $ | 135,710 |  | $ | 211,036 |  |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |
  (was, 2024-02-01, similarity 0.9494):
[0000950170-24-009819:note_history:17]
|  |  | Three Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 81,350 |  | $ | 68,199 |  | $ | 149,549 |  |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |
| Other |  |  | 8,244 |  |  | 4,842 |  |  | 13,086 |  |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |
| Total Americas |  |  | 89,594 |  |  | 73,041 |  |  | 162,635 |  |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |
| EMEA |  |  | 64,082 |  |  | 46,523 |  |  | 110,605 |  |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |
| APAC |  |  | 8,864 |  |  | 14,273 |  |  | 23,137 |  |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |
| Total net revenues |  | $ | 162,540 |  | $ | 133,837 |  | $ | 296,377 |  |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |

- changed (2024-05-02):
[0000950170-24-052140:note_history:18]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 251,694 |  | $ | 204,689 |  | $ | 456,383 |  |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |
| Other |  |  | 16,709 |  |  | 19,565 |  |  | 36,274 |  |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |
| Total Americas |  |  | 268,403 |  |  | 224,254 |  |  | 492,657 |  |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |
| EMEA |  |  | 184,706 |  |  | 128,537 |  |  | 313,243 |  |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |
| APAC |  |  | 7,510 |  |  | 47,140 |  |  | 54,650 |  |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |
| Total net revenues |  | $ | 460,619 |  | $ | 399,931 |  | $ | 860,550 |  |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |
  (was, 2024-02-01, similarity 0.9253):
[0000950170-24-009819:note_history:18]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 199,151 |  | $ | 133,150 |  | $ | 332,301 |  |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |
| Other |  |  | 10,775 |  |  | 15,208 |  |  | 25,983 |  |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |
| Total Americas |  |  | 209,926 |  |  | 148,358 |  |  | 358,284 |  |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |
| EMEA |  |  | 166,393 |  |  | 87,815 |  |  | 254,208 |  |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |
| APAC |  |  | 8,975 |  |  | 28,047 |  |  | 37,022 |  |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |
| Total net revenues |  | $ | 385,294 |  | $ | 264,220 |  | $ | 649,514 |  |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |

- added (2024-05-02):
[0000950170-24-052140:note_history:19]
*The distributor revenue in the APAC region for the three months ended March 31, 2024 reflects a higher level of customer rebates for the distributors, resulting from higher sell-through to end users than the Company's product sales into these distributors.

- added (2024-05-02):
[0000950170-24-052140:note_history:20]
For the nine months ended March 31, 2024, the Company generated approximately 10% of its net revenues from the Netherlands. For the three and nine months ended March 31, 2023, the Company generated 17% and 12% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of its net revenues for the three and nine months ended March 31, 2024 and 2023.

- changed (2024-05-02):
[0000950170-24-052140:note_history:21]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2024 |  | March 31,2023 |  | March 31,2024 |  | March 31,2023 |
| TD Synnex Corporation |  | 22% |  | 19% |  | 21% |  | 19% |
| Westcon Group, Inc. |  | 13% |  | 25% |  | 17% |  | 20% |
| Jenne, Inc. |  | 12% |  | 15% |  | 22% |  | 14% |
| ScanSource, Inc. |  | 11% |  | * |  | * |  | * |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |
  (was, 2024-02-01, similarity 0.6014):
[0000950170-24-009819:note_history:21]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | December 31,2023 |  | December 31,2022 |  | December 31,2023 |  | December 31,2022 |
| Jenne, Inc. |  | 23% |  | 13% |  | 25% |  | 13% |
| Westcon Group, Inc. |  | 10% |  | 19% |  | 18% |  | 17% |
| TD Synnex Corporation |  | 24% |  | 17% |  | 21% |  | 18% |
| ScanSource, Inc. |  | * |  | 11% |  | * |  | * |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |

- changed (2024-05-02):
[0000950170-24-052140:note_history:22]
|  |  | March 31,2024 |  | June 30,2023 |
| Jenne, Inc. |  | 38% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| * Less than 10% of accounts receivable |  |  |  |  |
  (was, 2024-02-01, similarity 0.8951):
[0000950170-24-009819:note_history:22]
|  |  | December 31,2023 |  | June 30,2023 |
| Jenne, Inc. |  | 52% |  | 39% |
| TD Synnex Corporation |  | * |  | 10% |
| ScanSource, Inc. |  | * |  | 10% |
| Ingram Micro |  | 10% |  | * |
| * Less than 10% of accounts receivable |  |  |  |  |

- removed (2024-05-02):
[0000950170-24-009819:note_history:23]
For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany. For the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. For the three months ended December 31, 2022, the Company generated 11% and 10% of its net revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022, the Company generated 10% of its net revenues from each of the Netherlands and Germany. No other foreign country accounted for 10% or more of its net revenues for the three and six months ended December 31, 2023 and 2022.

- removed (2024-05-02):
[0000950170-24-009819:note_history:24]
The Company's net accounts receivable balance with Jenne, Inc. as of December 31, 2023 is current and the Company expects to collect the majority of this balance by March 31, 2024.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-02):
[0000950170-24-052140:note_history:25]
On March 31, 2024, the Company had $558.3 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 18% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 42% in fiscal 2025, and 40% of the balance thereafter.
  (was, 2024-02-01, similarity 0.9803):
[0000950170-24-009819:note_history:25]
On December 31, 2023, the Company had $548.2 million of remaining performance obligations, which primarily comprised deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 32% of its deferred revenue as revenue in the remainder of fiscal 2024, an additional 34% in fiscal 2025, and 34% of the balance thereafter.

- changed (2024-05-02):
[0000950170-24-052140:note_history:26]
Revenue recognized for the three months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $95.9 million and $81.0 million, respectively. Revenue recognized for the nine months ended March 31, 2024 and 2023 that was included in the deferred revenue balance at the beginning of each period was $230.8 million and $193.7 million, respectively.
  (was, 2024-02-01, similarity 0.9194):
[0000950170-24-009819:note_history:26]
Revenue recognized for the three months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $105.7 million and $83.9 million, respectively. Revenue recognized for the six months ended December 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $172.0 million and $145.7 million, respectively.

- changed (2024-05-02):
[0000950170-24-052140:note_history:27]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.7 million and $20.0 million at March 31, 2024 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three and a half years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2024 and 2023 was $2.8 million and $2.3 million, respectively. Amortization recognized during the nine months ended March 31, 2024 and 2023 was $8.0 million and $6.7 million, respectively.
  (was, 2024-02-01, similarity 0.8182):
[0000950170-24-009819:note_history:27]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining subscription and support contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $22.2 million and $20.0 million at December 31, 2023 and June 30, 2023, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2023 and 2022 was $2.7 million and $2.2 million, respectively. Amortization recognized during the six months ended December 31, 2023 and 2022 was $5.2 million and $4.3 million, respectively.

- changed (2024-05-02):
[0000950170-24-052140:note_history:28]
|  |  | Three Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 52,543 |  | $ | 71,539 |  | $ | 124,082 |  |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |
| Other |  |  | 5,934 |  |  | 4,357 |  |  | 10,291 |  |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |
| Total Americas |  |  | 58,477 |  |  | 75,896 |  |  | 134,373 |  |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |
| EMEA |  |  | 18,313 |  |  | 40,722 |  |  | 59,035 |  |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |
| APAC* |  |  | (1,464 | ) |  | 19,092 |  |  | 17,628 |  |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |
| Total net revenues |  | $ | 75,326 |  | $ | 135,710 |  | $ | 211,036 |  |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |
  (was, 2024-02-01, similarity 0.9494):
[0000950170-24-009819:note_history:28]
|  |  | Three Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 81,350 |  | $ | 68,199 |  | $ | 149,549 |  |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |
| Other |  |  | 8,244 |  |  | 4,842 |  |  | 13,086 |  |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |
| Total Americas |  |  | 89,594 |  |  | 73,041 |  |  | 162,635 |  |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |
| EMEA |  |  | 64,082 |  |  | 46,523 |  |  | 110,605 |  |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |
| APAC |  |  | 8,864 |  |  | 14,273 |  |  | 23,137 |  |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |
| Total net revenues |  | $ | 162,540 |  | $ | 133,837 |  | $ | 296,377 |  |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |

- changed (2024-05-02):
[0000950170-24-052140:note_history:29]
|  |  | Nine Months Ended |  |
|  |  | March 31,2024 |  |  | March 31,2023 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 251,694 |  | $ | 204,689 |  | $ | 456,383 |  |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |
| Other |  |  | 16,709 |  |  | 19,565 |  |  | 36,274 |  |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |
| Total Americas |  |  | 268,403 |  |  | 224,254 |  |  | 492,657 |  |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |
| EMEA |  |  | 184,706 |  |  | 128,537 |  |  | 313,243 |  |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |
| APAC |  |  | 7,510 |  |  | 47,140 |  |  | 54,650 |  |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |
| Total net revenues |  | $ | 460,619 |  | $ | 399,931 |  | $ | 860,550 |  |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |
  (was, 2024-02-01, similarity 0.9253):
[0000950170-24-009819:note_history:29]
|  |  | Six Months Ended |  |
|  |  | December 31,2023 |  |  | December 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 199,151 |  | $ | 133,150 |  | $ | 332,301 |  |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |
| Other |  |  | 10,775 |  |  | 15,208 |  |  | 25,983 |  |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |
| Total Americas |  |  | 209,926 |  |  | 148,358 |  |  | 358,284 |  |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |
| EMEA |  |  | 166,393 |  |  | 87,815 |  |  | 254,208 |  |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |
| APAC |  |  | 8,975 |  |  | 28,047 |  |  | 37,022 |  |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |
| Total net revenues |  | $ | 385,294 |  | $ | 264,220 |  | $ | 649,514 |  |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |

- added (2024-05-02):
[0000950170-24-052140:note_history:30]
*The distributor revenue in the APAC region for the three months ended March 31, 2024 reflects a higher level of customer rebates for the distributors, resulting from higher sell-through to end users than the Company's product sales into these distributors.

- added (2024-05-02):
[0000950170-24-052140:note_history:31]
For the nine months ended March 31, 2024, the Company generated approximately 10% of its net revenues from the Netherlands. For the three and nine months ended March 31, 2023, the Company generated 17% and 12% of its net revenues from the Netherlands, respectively. No other foreign country accounted for 10% or more of its net revenues for the three and nine months ended March 31, 2024 and 2023.

- removed (2024-05-02):
[0000950170-24-009819:note_history:32]
For the three months ended December 31, 2023, the Company generated 10% of its net revenues from Germany. For the six months ended December 31, 2023, the Company generated approximately 11% of its net revenues from the Netherlands. For the three months ended December 31, 2022, the Company generated 11% and 10% of its net revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022, the Company generated 10% of its net revenues from each of the Netherlands and Germany. No other foreign country accounted for 10% or more of its net revenues for the three and six months ended December 31, 2023 and 2022.
