# EXTR notes — 0000950170-24-098129


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000950170-24-098129:notes:1]
Portions of the registrant's definitive proxy statement for the year ended June 30, 2024 Annual Meeting of Stockholders to be filed with the Commission pursuant to Regulation 14A not later than 120 days after the end of the fiscal year covered by this Annual Report on Form 10-K are incorporated herein by reference in Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-24-098129:notes:2]
1. Description of Business and Basis of Presentation

[0000950170-24-098129:notes:3]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0000950170-24-098129:notes:4]
Fiscal Year

[0000950170-24-098129:notes:5]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2024” or “ 2024”; “fiscal 2023” or “2023”; “fiscal 2022” or “2022” represent the fiscal years ending, respectively.

[0000950170-24-098129:notes:6]
Principles of Consolidation

[0000950170-24-098129:notes:7]
The consolidated financial statements include the accounts of Extreme Networks, Inc. and its wholly-owned subsidiaries. All inter-company balances and transactions have been eliminated on consolidation.

[0000950170-24-098129:notes:8]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month-end exchange rates; and revenues and expenses are translated using the monthly average rate.

[0000950170-24-098129:notes:9]
Accounting Estimates

[0000950170-24-098129:notes:10]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the financial statements and the accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-24-098129:notes:11]
2. Summary of Significant Accounting Policies

[0000950170-24-098129:notes:12]
Revenue Recognition

[0000950170-24-098129:notes:13]
The Company accounts for revenue in accordance with Topic 606, Revenue from Contracts with Customers. The Company derives revenues primarily from sales of its networking equipment, with the remaining revenues generated from software delivered as a service (“SaaS”)  and support fees relating to maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0000950170-24-098129:notes:14]
See Note 3, Revenues, for further discussion.

[0000950170-24-098129:notes:15]
Cash and Cash Equivalents

[0000950170-24-098129:notes:16]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with several financial institutions. These are financial institutions with reputable credit and therefore bear minimal credit risk.  Deposits held with banks may exceed the amount of insurance provided on such deposits.

[0000950170-24-098129:notes:17]
Allowance for Product Returns

[0000950170-24-098129:notes:18]
The Company maintains estimates for product returns based on its historical returns, analysis of credit memos and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is shown as a reduction of accounts receivable as there is a contractual right of offset and returns are applied to accounts receivable balances outstanding as of the balance sheet date. There have not been material revisions to the estimated product returns for any periods presented.

[0000950170-24-098129:notes:19]
Allowance for Credit Losses

[0000950170-24-098129:notes:20]
The Company maintains an allowance for credit losses which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring certain of its customers in the Asia-Pacific region to pay cash in advance or secure letters of credit when placing an order with the Company.

[0000950170-24-098129:notes:21]
Inventories

[0000950170-24-098129:notes:22]
The Company values its inventory at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Adjustments to reduce the cost of inventory to its net realizable value are made, if required, when conditions exist that suggest that inventory is obsolete or may be in excess of anticipated demand based upon assumptions about future demand. At the point of the loss recognition, a new lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0000950170-24-098129:notes:23]
Long-Lived Assets

[0000950170-24-098129:notes:24]
Long-lived assets include (a) property and equipment, (b) operating lease right-of-use (“ROU”) assets, (c) capitalized software development costs (d) goodwill and intangible assets, and (e) other assets. Property and equipment, ROU assets, and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0000950170-24-098129:notes:25]
(a) Property and Equipment, Net

[0000950170-24-098129:notes:26]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and purchased software. Estimated useful lives of three to seven years are used for office equipment and furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms.

[0000950170-24-098129:notes:27]
(b) Leases

[0000950170-24-098129:notes:28]
The Company leases facilities, equipment and vehicles under operating leases that expire on various dates through fiscal 2033. The Company determines if an arrangement is a lease at inception. We evaluate the classification of leases at commencement date and as necessary, at modification. In general, for lease arrangements exceeding a twelve-month term, these arrangements are recognized as ROU assets with associated operating lease liabilities on the consolidated balance sheets.

[0000950170-24-098129:notes:29]
ROU assets under the Company’s operating leases represent the Company’s right to use an underlying asset over the lease term. Operating lease liabilities represent the Company’s obligation to make payments arising from the lease. The ROU asset is reduced over a straight-line or other systematic basis representative of the pattern in which the Company expects to consume the ROU assets’ future economic benefits. The ROU asset is also adjusted for leasehold improvements paid by the lessor, lease incentives, and asset impairments, among other things.

[0000950170-24-098129:notes:30]
See Note 9, Leases, for further discussion.

[0000950170-24-098129:notes:31]
(c) Capitalized Software Development Costs

[0000950170-24-098129:notes:32]
Capitalization of software development costs for software to be sold, leased, or otherwise marketed begins when a product's technological feasibility has been established and ends when a product is available for general release to customers. Generally, the Company's products are released soon after technological feasibility has been established. As a result, costs incurred between achieving technological feasibility and product general availability have not been significant.

[0000950170-24-098129:notes:33]
The Company capitalizes costs associated with internal-use software applications and systems during the application development stage. Such capitalized costs include external direct costs incurred in developing or obtaining the software applications and payroll and payroll-related costs for employees, who are directly associated with the development of the application. The

[0000950170-24-098129:notes:34]
Company includes such internal-use software costs in the software category in property and equipment and amortizes these costs on a straight-line basis over an estimated useful life. The software development costs that the Company capitalized for the fiscal years ended June 30, 2024 and 2023 were not material.

[0000950170-24-098129:notes:35]
(d) Goodwill and Intangible Assets

[0000950170-24-098129:notes:36]
Goodwill and intangible assets are generated as a result of business combinations and are comprised of, among other things, developed technology, customer relationships, trade names, and licensing agreements.

[0000950170-24-098129:notes:37]
The remaining lives of intangible assets are considered regularly along with assessments of impairment and lives are adjusted or impairment charges taken when required.

[0000950170-24-098129:notes:38]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company has one reporting unit and performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceeds directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Based on the results of the goodwill impairment analysis, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0000950170-24-098129:notes:39]
Business Combinations

[0000950170-24-098129:notes:40]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, useful lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0000950170-24-098129:notes:41]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0000950170-24-098129:notes:42]
Deferred Revenue

[0000950170-24-098129:notes:43]
Deferred revenue represents amounts for (i) deferred maintenance, support, and software as a service (“SaaS”) revenues, and (ii) other deferred revenue including professional services when the revenue recognition criteria have not been met.

[0000950170-24-098129:notes:44]
Product Warranties and Guarantees

[0000950170-24-098129:notes:45]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenues for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0000950170-24-098129:notes:46]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0000950170-24-098129:notes:47]
Stock-based Compensation

[0000950170-24-098129:notes:48]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock options and stock purchase options under the 2014 ESPP using the Black-Scholes-Merton option valuation model. The fair value of RSUs is based on the closing stock price of the Company’s common stock on the grant date.

[0000950170-24-098129:notes:49]
The Company grants certain employees with stock options and RSUs that are tied to either company-wide financial performance metrics or certain market metrics. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0000950170-24-098129:notes:50]
Advertising

[0000950170-24-098129:notes:51]
Advertising costs are expensed as incurred. Advertising expenses were immaterial in fiscal years 2024, 2023 and 2022.

[0000950170-24-098129:notes:52]
Income Taxes

[0000950170-24-098129:notes:53]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0000950170-24-098129:notes:54]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions. The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes. For additional discussion, see Note 16, Income Taxes.

[0000950170-24-098129:notes:55]
Recently Adopted Accounting Pronouncements

[0000950170-24-098129:notes:56]
There were no recently adopted accounting standards which would have a material effect on our consolidated financial statements and accompanying disclosures.

[0000950170-24-098129:notes:57]
Recently Issued Accounting Pronouncements Not Yet Adopted

[0000950170-24-098129:notes:58]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. All disclosure requirements of ASU 2023-07 are required for entities with a single reportable segment. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods for fiscal years beginning after December 15, 2024, and should be applied on a retrospective basis to all periods presented. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-07 on its consolidated financial statements and related disclosures.

[0000950170-24-098129:notes:59]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740), Improvements to Income Tax Disclosures to enhance income tax disclosures primarily through changes in the rate reconciliation and income taxes paid information. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024 on a prospective basis. Early adoption is permitted. The Company is currently evaluating the impact of adopting ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-24-098129:notes:60]
3. Revenues

[0000950170-24-098129:notes:61]
The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of subscription and support, which primarily includes software subscriptions delivered as software as a service (“SaaS”) and additional revenues from maintenance contracts, professional services and training for its products. The Company sells its products, maintenance contracts, and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and subscription and support may be sold separately or in bundled packages.

[0000950170-24-098129:notes:62]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer. For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0000950170-24-098129:notes:63]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenues from maintenance contracts and SaaS are recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which generally ranges from one to five years. For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits. Sales taxes collected from customers are excluded from revenues. Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the historical actuals. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-24-098129:notes:64]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotations are variable consideration and are estimated based on historical return rates and estimates provided by the distributors. Additionally, distributors often need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price. At the time the distributor invoices its end customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these customer rebates to be variable consideration. Such price adjustments are estimated based on an analysis of historical claims at the distributor level. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-24-098129:notes:65]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct. For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products. For items that are not sold separately, the Company estimates the stand-alone selling prices using other observable inputs.

[0000950170-24-098129:notes:66]
The Company’s performance obligations are satisfied at a point in time or over time as the customer receives and consumes the benefits provided. Substantially all of the Company’s product sales revenues are recognized at a point in time. Substantially all of the Company’s subscription and support revenues are recognized over time. For revenue recognized over time, the Company primarily uses an input measure, days elapsed, to measure progress.

[0000950170-24-098129:notes:67]
At June 30, 2024, the Company had $575.0 million of remaining performance obligations, which are primarily comprised of deferred support and SaaS subscription revenues. The Company expects to recognize approximately 53% of this amount in fiscal 2025, an additional 23% percent in fiscal 2026 and the remaining 24% of the balance thereafter.

[0000950170-24-098129:notes:68]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are either billed fully at the inception of contract or at periodic intervals (e.g.,

[0000950170-24-098129:notes:69]
quarterly or annually). The Company generally receives payments from its customers in advance of services being provided, resulting in deferred revenue. These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0000950170-24-098129:notes:70]
The Company's total deferred revenue balances at June 30, 2024, 2023 and 2022 were $575.0 million, $501.5 million, and $401.6 million, respectively. Revenue recognized for the years ended June 30, 2024, 2023 and 2022, that was included in the deferred revenue balance at the beginning of each period was $275.7 million, $232.9 million, and $208.4 million, respectively.

[0000950170-24-098129:notes:71]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals, are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $24.7 million and $20.0 million at June 30, 2024 and 2023, respectively which are included within “Other assets.” Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations. Amortization recognized during the years ended June 30, 2024, 2023 and 2022 was $10.9 million, $9.1 million and $7.5 million, respectively.

[0000950170-24-098129:notes:72]
Estimated Variable Consideration. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0000950170-24-098129:notes:73]
Disaggregation of Revenues: The Company operates in three geographic regions: Americas, EMEA (Europe, Middle East and Africa) and APAC (Asia Pacific). The following tables set forth the Company’s revenues disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0000950170-24-098129:notes:74]
|  |  | Year Ended June 30, 2024 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 315,281 |  |  | $ | 265,860 |  |  | $ | 581,141 |  |
| Other |  |  | 20,961 |  |  |  | 25,617 |  |  |  | 46,578 |  |
| Total Americas |  |  | 336,242 |  |  |  | 291,477 |  |  |  | 627,719 |  |
| EMEA |  |  | 250,213 |  |  |  | 171,753 |  |  |  | 421,966 |  |
| APAC |  |  | 9,234 |  |  |  | 58,284 |  |  |  | 67,518 |  |
| Total net revenues |  | $ | 595,689 |  |  | $ | 521,514 |  |  | $ | 1,117,203 |  |

[0000950170-24-098129:notes:75]
|  |  | Year Ended June 30, 2023 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 306,240 |  |  | $ | 266,687 |  |  | $ | 572,927 |  |
| Other |  |  | 60,957 |  |  |  | 23,151 |  |  |  | 84,108 |  |
| Total Americas |  |  | 367,197 |  |  |  | 289,838 |  |  |  | 657,035 |  |
| EMEA |  |  | 390,495 |  |  |  | 169,174 |  |  |  | 559,669 |  |
| APAC |  |  | 19,384 |  |  |  | 76,366 |  |  |  | 95,750 |  |
| Total net revenues |  | $ | 777,076 |  |  | $ | 535,378 |  |  | $ | 1,312,454 |  |

[0000950170-24-098129:notes:76]
|  |  | Year Ended June 30, 2022 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 237,163 |  |  | $ | 266,472 |  |  | $ | 503,635 |  |
| Other |  |  | 27,018 |  |  |  | 17,590 |  |  |  | 44,608 |  |
| Total Americas |  |  | 264,181 |  |  |  | 284,062 |  |  |  | 548,243 |  |
| EMEA |  |  | 325,290 |  |  |  | 151,791 |  |  |  | 477,081 |  |
| APAC |  |  | 17,517 |  |  |  | 69,480 |  |  |  | 86,997 |  |
| Total net revenues |  | $ | 606,988 |  |  | $ | 505,333 |  |  | $ | 1,112,321 |  |

[0000950170-24-098129:notes:77]
For the years ended June 30, 2024, 2023 and 2022, the Company generated 11%, 13% and 12%, respectively, of its revenue from the Netherlands. No other foreign country accounted for 10% or more of the Company’s net revenue for the years ended June 30, 2024, 2023 and 2022.

[0000950170-24-098129:notes:78]
Concentrations

[0000950170-24-098129:notes:79]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0000950170-24-098129:notes:80]
The following table sets forth customers accounting for 10% or more of the Company’s net revenues:

[0000950170-24-098129:notes:81]
|  |  |  |  | Year Ended |  |  |
|  |  | June 30,2024 |  | June 30,2023 |  | June 30, 2022 |
| Jenne, Inc. |  | 22% |  | 15% |  | 16% |
| TD Synnex Corporation |  | 21% |  | 18% |  | 20% |
| Westcon Group, Inc. |  | 16% |  | 20% |  | 18% |

[0000950170-24-098129:notes:82]
The following table sets forth major customers accounting for 10% or more of the Company’s net accounts receivable, as of June 30, 2024 and June 30, 2023:

[0000950170-24-098129:notes:83]
|  |  | June 30,2024 |  | June 30,2023 |
| Jenne, Inc. |  | 64% |  | 39% |
| ScanSource, Inc. |  | 11% |  | 10% |
| TD Synnex Corporation |  | * |  | 10% |
| * Less than 10% of accounts receivable |  |  |  |  |

[0000950170-24-098129:notes:84]
The Company's net accounts receivable balance with Jenne, Inc. as of June 30, 2024 is current and the Company expects to collect the majority of this balance by October 31, 2024.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-24-098129:notes:85]
4. Business Combinations

[0000950170-24-098129:notes:86]
The Company completed one acquisition during the fiscal year ended June 30, 2022. The acquisition was accounted for using the acquisition method of accounting. The estimated fair values were determined through established and generally accepted valuation techniques, including work performed by third-party valuation specialists. The purchase price of the acquisition has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition. Inventories were valued at fair value using the net realizable value approach. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount the Company would be required to pay to a third party to assume the obligation. Intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. Results of operations of the acquired entity are included in the Company’s operations beginning with the closing date of acquisition.

[0000950170-24-098129:notes:87]
Ipanema Acquisition

[0000950170-24-098129:notes:88]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of InfoVista SAS  ("InfoVista") pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to InfoVista was $70.9 million, which was funded entirely by cash. The primary reason for the acquisition was to acquire the talent and the technology to allow the Company to expand its portfolio with new cloud-managed SD-WAN and security offerings to support its enterprise customers.

[0000950170-24-098129:notes:89]
The results of operations of Ipanema are included in the accompanying consolidated results of operations for the year ended June 30, 2022. The overall results of operations of Ipanema were not material to the consolidated financial statements of Extreme.

[0000950170-24-098129:notes:90]
Pro forma financial information

[0000950170-24-098129:notes:91]
The following unaudited pro forma results of operations are presented as though the Acquisition had occurred as of July 1, 2020, the beginning of fiscal 2021, after giving effect to purchase accounting adjustments relating to deferred revenue, depreciation and amortization of intangibles and acquisition and integration costs.

[0000950170-24-098129:notes:92]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2021, nor are they necessarily indicative of future operating results. The

[0000950170-24-098129:notes:93]
unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions, which could alter the unaudited pro forma results.

[0000950170-24-098129:notes:94]
The unaudited pro forma financial information for the year ended June 30, 2022 combines the results for Extreme for such periods assuming the transaction closed on July 1, 2020, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s historical results up to the Acquisition Date.

[0000950170-24-098129:notes:95]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0000950170-24-098129:notes:96]
|  | Year Ended |  |
|  | June 30,2022 |  |
| Net revenue | $ | 1,115,942 |  |
| Net income | $ | 53,659 |  |
| Net income per share – basic | $ | 0.41 |  |
| Net income per share – diluted | $ | 0.40 |  |
| Shares used in per share calculation – basic |  | 129,437 |  |
| Shares used in per share calculation – diluted |  | 133,494 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-24-098129:notes:97]
5. Balance Sheet Components

[0000950170-24-098129:notes:98]
Accounts Receivable, Net

[0000950170-24-098129:notes:99]
The following table summarizes the Company's accounts receivable (in thousands):

[0000950170-24-098129:notes:100]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Accounts receivable |  | $ | 327,859 |  |  | $ | 440,298 |  |
| Customer rebates |  |  | (185,090 | ) |  |  | (222,246 | ) |
| Allowance for credit losses |  |  | (915 | ) |  |  | (882 | ) |
| Allowance for product returns |  |  | (52,336 | ) |  |  | (35,125 | ) |
| Accounts receivable, net |  | $ | 89,518 |  |  | $ | 182,045 |  |

[0000950170-24-098129:notes:101]
The following table summarizes the Company's allowance for credit losses (in thousands):

[0000950170-24-098129:notes:102]
| Description |  | Balance atbeginning ofperiod |  |  | Provision for expected credit losses |  |  | Deductions (1) |  |  | Balance atend of period |  |
| Year Ended June 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 882 |  |  | $ | 210 |  |  | $ | (177 | ) |  | $ | 915 |  |
| Year Ended June 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 695 |  |  | $ | 464 |  |  | $ | (277 | ) |  | $ | 882 |  |
| Year Ended June 30, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 986 |  |  | $ | 39 |  |  | $ | (330 | ) |  | $ | 695 |  |

[0000950170-24-098129:notes:103]
(1)
Uncollectible accounts written off, net of recoveries.

[0000950170-24-098129:notes:104]
The following table summarizes the Company’s allowance for product returns (in thousands):

[0000950170-24-098129:notes:105]
| Description |  | Balance atbeginning ofperiod |  |  | Additions |  |  | Deductions |  |  | Balance atend of period |  |
| Year Ended June 30, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 35,125 |  |  | $ | 149,161 |  |  | $ | (131,950 | ) |  | $ | 52,336 |  |
| Year Ended June 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 20,033 |  |  | $ | 104,028 |  |  | $ | (88,936 | ) |  | $ | 35,125 |  |
| Year Ended June 30, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $ | 17,371 |  |  | $ | 67,407 |  |  | $ | (64,745 | ) |  | $ | 20,033 |  |

[0000950170-24-098129:notes:106]
The following table summarizes the Company’s inventory by category (in thousands):

[0000950170-24-098129:notes:107]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Finished goods |  | $ | 115,813 |  |  | $ | 78,180 |  |
| Raw materials |  |  | 25,219 |  |  |  | 10,844 |  |
| Total inventories |  | $ | 141,032 |  |  | $ | 89,024 |  |

[0000950170-24-098129:notes:108]
Property and Equipment, Net

[0000950170-24-098129:notes:109]
The following table summarizes the Company’s property and equipment by category (in thousands):

[0000950170-24-098129:notes:110]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Computers and equipment |  | $ | 77,224 |  |  | $ | 81,612 |  |
| Purchased software |  |  | 60,717 |  |  |  | 51,444 |  |
| Office equipment, furniture and fixtures |  |  | 8,134 |  |  |  | 8,899 |  |
| Leasehold improvements |  |  | 47,880 |  |  |  | 48,943 |  |
| Total property and equipment |  |  | 193,955 |  |  |  | 190,898 |  |
| Less: accumulated depreciation and amortization |  |  | (150,211 | ) |  |  | (144,450 | ) |
| Property and equipment, net |  | $ | 43,744 |  |  | $ | 46,448 |  |

[0000950170-24-098129:notes:111]
The Company recognized depreciation expense of $23.9 million during the fiscal year ended June 30, 2024, of which $5.9 million was recorded as restructuring and related charges in the consolidated statement of operations. Refer to Note 15, Restructuring and Related Charges, for further discussion. The Company recognized depreciation expense of $19.5 million, and $19.8 million related to property and equipment during the years ended June 30, 2023 and 2022, respectively.

[0000950170-24-098129:notes:112]
The following table summarizes the Company's contract liabilities which are shown as deferred revenue (in thousands):

[0000950170-24-098129:notes:113]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Deferred maintenance, support, and SaaS |  | $ | 554,661 |  |  | $ | 486,075 |  |
| Other deferred revenue |  |  | 20,362 |  |  |  | 15,424 |  |
| Total deferred revenue |  |  | 575,023 |  |  |  | 501,499 |  |
| Less: current portion |  |  | 306,114 |  |  |  | 282,475 |  |
| Non-current deferred revenue |  | $ | 268,909 |  |  | $ | 219,024 |  |

[0000950170-24-098129:notes:114]
Accrued Warranty

[0000950170-24-098129:notes:115]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0000950170-24-098129:notes:116]
|  |  | Year Ended |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |
| Balance at beginning of period |  | $ | 12,322 |  |  | $ | 10,852 |  |  | $ | 11,623 |  |
| Warranties assumed due to acquisition |  |  | — |  |  |  | — |  |  |  | 41 |  |
| New warranties issued |  |  | 13,010 |  |  |  | 15,463 |  |  |  | 13,314 |  |
| Warranty expenditures |  |  | (14,390 | ) |  |  | (13,993 | ) |  |  | (14,126 | ) |
| Balance at end of period |  | $ | 10,942 |  |  | $ | 12,322 |  |  | $ | 10,852 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-24-098129:notes:117]
6. Fair Value Measurements

[0000950170-24-098129:notes:118]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0000950170-24-098129:notes:119]
•
Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities;

[0000950170-24-098129:notes:120]
•
Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000950170-24-098129:notes:121]
•
Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value.

[0000950170-24-098129:notes:122]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0000950170-24-098129:notes:123]
| June 30, 2024 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 3,216 |  |  | $ | — |  |  | $ | 3,216 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 18 |  |  |  | — |  |  |  | 18 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 3,234 |  |  | $ | — |  |  | $ | 3,234 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |

[0000950170-24-098129:notes:124]
| June 30, 2023 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit |  | $ | — |  |  | $ | 7,151 |  |  | $ | — |  |  | $ | 7,151 |  |
| Foreign currency derivatives |  |  | — |  |  |  | 31 |  |  |  | — |  |  |  | 31 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 7,182 |  |  | $ | — |  |  | $ | 7,182 |  |

[0000950170-24-098129:notes:125]
The Company’s financial instruments consist of cash, accounts receivable, accounts payable, and accrued liabilities. The Company states accounts receivable, accounts payable and accrued liabilities at their carrying value, which approximates fair value due to the short time to the expected receipt or payment.

[0000950170-24-098129:notes:126]
The Company's level 2 assets consist of certificates of deposit and derivative instruments. Certificates of deposit do not have regular market pricing and are considered Level 2. The fair value of derivative instruments under the Company’s foreign exchange forward contracts and interest rate swaps are estimated based on valuations provided by alternative pricing sources supported by observable inputs which are considered Level 2.

[0000950170-24-098129:notes:127]
As of June 30, 2024 and June 30, 2023 the Company had investment in certificates of deposit of $3.2 million and $7.2 million, respectively,  with maturity of three months at the date of purchase, which are recorded as cash equivalents in the consolidated balance sheets. The Company considers these cash equivalents to be available-for-sale and, as of June 30, 2024 and June 30, 2023, their fair value approximated their amortized cost.

[0000950170-24-098129:notes:128]
As of June 30, 2024 and June 30, 2023, foreign exchange forward currency contracts not designated as hedging instruments had notional principal amounts of $31.3 million and $3.4 million, respectively. These contracts have maturities of 40 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income, net in the consolidated statements of operations. For the years ended June 30, 2024, 2023 and 2022 the net losses recorded in the consolidated statements of operations from these contracts were approximately $0.3 million, $0.4 million, and $1.4 million, respectively. There were no outstanding foreign exchange forward contracts that were designated as hedging instruments at June 30, 2024 and 2023. See Note 14, Derivatives and Hedging, for additional information.

[0000950170-24-098129:notes:129]
The fair value of the borrowings under the 2023 Credit Agreement (as defined in Note 8) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable in the 2023 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $190.0 million and $225.0 million as of June 30, 2024 and 2023, respectively.

[0000950170-24-098129:notes:130]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated. As of June 30, 2024 and June 30, 2023 the Company did not have any assets or liabilities that were considered Level 3.

[0000950170-24-098129:notes:131]
There were no transfers of assets or liabilities between Level 1, Level 2 or Level 3 during the years ended June 30, 2024 and 2023. There were no impairments recorded during the years ended June 30, 2024, 2023, or  2022.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000950170-24-098129:notes:132]
7. Goodwill and Intangible Assets

[0000950170-24-098129:notes:133]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0000950170-24-098129:notes:134]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Balance at beginning of period |  | $ | 394,755 |  |  | $ | 400,144 |  |
| Foreign currency translation |  |  | (1,046 | ) |  |  | (5,389 | ) |
| Balance at end of period |  | $ | 393,709 |  |  | $ | 394,755 |  |

[0000950170-24-098129:notes:135]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0000950170-24-098129:notes:136]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2024 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.0 years |  | $ | 169,247 |  |  | $ | 162,708 |  |  | $ | 6,539 |  |
| Customer relationships |  | 2.0 years |  |  | 64,671 |  |  |  | 60,776 |  |  |  | 3,896 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 2.4 years |  |  | 1,282 |  |  |  | 1,104 |  |  |  | 178 |  |
| Total intangible assets, net* |  |  |  | $ | 245,901 |  |  | $ | 235,288 |  |  | $ | 10,613 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-24-098129:notes:137]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 4.1 years |  | $ | 169,460 |  |  | $ | 159,592 |  |  | $ | 9,868 |  |
| Customer relationships |  | 3.4 years |  |  | 64,839 |  |  |  | 58,894 |  |  |  | 5,945 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 3.4 years |  |  | 2,445 |  |  |  | 2,195 |  |  |  | 250 |  |
| Total intangible assets, net* |  |  |  | $ | 247,444 |  |  | $ | 231,381 |  |  | $ | 16,063 |  |
| * The carrying amount of foreign intangible assets are affected by foreign currency translation |  |  |  |  |

[0000950170-24-098129:notes:138]
The following table summarizes the amortization expense of intangible assets for the periods presented (in thousands):

[0000950170-24-098129:notes:139]
|  |  | Year Ended |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |
| Amortization of intangible assets in “Total cost of revenues” |  | $ | 3,272 |  |  | $ | 12,941 |  |  | $ | 16,711 |  |
| Amortization of intangible assets in “Total operating expenses” |  |  | 2,041 |  |  |  | 2,047 |  |  |  | 3,235 |  |
| Total amortization expense |  | $ | 5,313 |  |  | $ | 14,988 |  |  | $ | 19,946 |  |

[0000950170-24-098129:notes:140]
The amortization expense that is recognized in “Total cost of revenues” primarily consists of amortization related to developed technology, license agreements and other intangibles.

[0000950170-24-098129:notes:141]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0000950170-24-098129:notes:142]
|  |  | Amount |  |
| For the fiscal year ending June 30: |  |  |  |
| 2025 |  | $ | 4,453 |  |
| 2026 |  |  | 3,193 |  |
| 2027 |  |  | 1,431 |  |
| 2028 |  |  | 1,271 |  |
| 2029 |  |  | 265 |  |
| Total |  | $ | 10,613 |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-24-098129:notes:143]
8. Debt

[0000950170-24-098129:notes:144]
The Company’s debt is comprised of the following (in thousands):

[0000950170-24-098129:notes:145]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 10,000 |  |  | $ | 10,000 |  |
| Revolving Facility |  |  | — |  |  |  | 25,000 |  |
| Less: unamortized debt issuance costs |  |  | (674 | ) |  |  | (674 | ) |
| Current portion of long-term debt |  | $ | 9,326 |  |  | $ | 34,326 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 180,000 |  |  | $ | 190,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,735 | ) |  |  | (2,409 | ) |
| Total long-term debt, less current portion |  |  | 178,265 |  |  |  | 187,591 |  |
| Total debt |  | $ | 187,591 |  |  | $ | 221,917 |  |

[0000950170-24-098129:notes:146]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Capital Markets Corp., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders which was subsequently amended during fiscal 2023.

[0000950170-24-098129:notes:147]
On June 22, 2023, the Company entered into a Second Amended and Restated Credit Agreement (the “2023 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank, N.A., as an issuing lender and swingline lender, BOFA Securities, Inc.., JPMorgan Chase Bank, N.A., PNC Capital Markets LLC and Wells Fargo Securities, LLC, as issuing lenders, the financial institutions or entities party thereto as lenders, and Bank of Montreal, as administrative agent and collateral agent, which amended and restated the 2019 Credit Agreement. The 2023 Credit Agreement provides for i) a $200.0 million first lien term loan facility in an aggregate principal amount (the “2023 Term Loan”), ii) a $150.0 million five-year revolving credit facility (the “2023 Revolving Facility”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100.0 million. On June 22, 2023, the Company borrowed $25.0 million against its $150.0 million revolving credit facility to refinance our debt. On July 7, 2023 the Company made a prepayment of $25.0 million to pay off the outstanding revolving credit balance.

[0000950170-24-098129:notes:148]
Borrowings under the 2023 Credit Agreement bear interest, and at the Company’s election, the initial term loan may be made as either a base rate loan or a Secured Overnight Funding Rate (“SOFR”) loan. The applicable margin for base rate loans ranges from 1.00% to 1.75% per annum, and the applicable margin for SOFR loans ranges from 2.00% to 2.75%, in each case based on the Company’s consolidated leverage ratio. All SOFR loans are subject to a floor of 0.00% per annum and spread adjustment of 0.10% per annum. The Company paid other closing fees, arrangement fees, and administration fees associated with the 2023 Credit Agreement.

[0000950170-24-098129:notes:149]
The 2023 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2023 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2023 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance. The Company was in compliance with the covenants under the 2023 Credit Agreement as of June 30, 2024. On August 14, 2024, the Company executed an amendment to the 2023 Credit Agreement to modify the definition of Consolidated EBITDA (as defined in the 2023 Credit Agreement) under the original terms of the agreement. See Note 18, Subsequent Events, for additional information.

[0000950170-24-098129:notes:150]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. During the year ended June 30, 2023, in conjunction with the debt refinancing, as noted above, the Company wrote-off a certain portion of the unamortized debt issuance cost of $1.3 million associated with the 2019 Credit Agreement which is included in “Interest expense” in the accompanying consolidated statements of operations. During the year ended June 30, 2023, the Company incurred and capitalized $3.2 million of debt issuance costs in conjunction with the 2023 Credit Agreement. The remaining unamortized debt issuance cost related to the 2019 Credit Agreement and the capitalized debt issuance cost associated with the 2023 Credit Agreement are amortized over a term of five years. The Company's interest rate was 7.44% and 7.18% as of June 30, June 30, 2024 and 2023, respectively.

[0000950170-24-098129:notes:151]
Amortization of debt issuance costs are included in “Interest expense” in the accompanying consolidated statements of operations and were $1.1 million, $2.6 million and $3.0 million for the fiscal years ended June 30, 2024, 2023 and 2022, respectively.

[0000950170-24-098129:notes:152]
As of June 30, 2024, the Company did not have any outstanding balance against its 2023 Revolving Facility. The Company had $135.8 million of availability under the 2023 Revolving Facility as of June 30, 2024. During the year ended June 30, 2024 the Company did not make any additional payments against its term loan facility other than the scheduled payments per the terms of the 2023 Credit Agreement and repayments per the terms of the 2023 Revolving Facility. During the fiscal year ended June 30, 2023, the Company made additional payments of $57.5 million against its term loan facility under the 2019 Credit Agreement.

[0000950170-24-098129:notes:153]
The Company had $14.2 million of outstanding letters of credit as of June 30, 2024.

[0000950170-24-098129:notes:154]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0000950170-24-098129:notes:155]
|  |  | Amount |  |
| For the fiscal year ending June 30, |  |  |  |
| 2025 |  | $ | 10,000 |  |
| 2026 |  |  | 15,000 |  |
| 2027 |  |  | 20,000 |  |
| 2028 |  |  | 145,000 |  |
| Total |  | $ | 190,000 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000950170-24-098129:notes:156]
9. Leases

[0000950170-24-098129:notes:157]
Lessee Considerations

[0000950170-24-098129:notes:158]
The Company leases certain facilities, equipment, and vehicles under operating leases that expire on various dates through fiscal 2033. Its leases generally have terms that range from one year to ten years for its facilities, one year to five years for equipment, and one year to five years for vehicles. Some of its leases contain renewal options, escalation clauses, rent concessions, and leasehold improvement incentives.

[0000950170-24-098129:notes:159]
The Company determines if an arrangement is a lease at inception. The Company has elected not to recognize a lease liability or ROU asset for short-term leases (leases with a term of twelve months or less). Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The interest rate used to determine the present value of future payments is the Company’s incremental borrowing rate at the commencement date because the rate implicit in the leases are not readily determinable. The Company’s incremental borrowing rate is the rate for collateralized borrowings based on the current economic environment, credit history, credit rating, value of leases, currency in which the lease obligation is satisfied, rate sensitivity, lease term and materiality. The biggest drivers having the greatest effect in determining the incremental borrowing rate for each one of the Company’s leases are the term of the lease and the currency in which the lease obligation is satisfied.

[0000950170-24-098129:notes:160]
Some operating leases contain lease and non-lease components. Certain lease contracts include fixed payments for services, such as operations, maintenance, or other services. The Company has elected to account for fixed lease and non-lease components as a single lease component except for the logistic service asset class. Cash payments made for variable lease and non-lease costs are not included in the measurement of operating lease assets and liabilities and are recognized in the Company’s consolidated statements of operations as incurred. Some lease terms include one or more options to renew. The Company does not assume renewals in its determination of the lease term unless it is reasonably certain that it will exercise that option. The Company’s lease agreements do not contain any residual value guarantees.

[0000950170-24-098129:notes:161]
The following table presents additional information relating to the Company's operating leases (in thousands, except for lease term and discount rate):

[0000950170-24-098129:notes:162]
|  |  | Year Ended |  |
|  |  | June 30,2024 |  | June 30,2023 |  | June 30, 2022 |  |
| Operating lease costs | $ | 14,398 |  | $ | 14,416 |  | $ | 16,852 |  |
| Variable lease costs |  |  | 4,325 |  |  | 6,920 |  |  | 6,921 |  |
| Cash paid for amounts included in the measurement of operating liabilities |  | 14,487 |  |  | 17,396 |  |  | 20,890 |  |
| ROU assets obtained for new lease obligations |  | 21,082 |  |  | 10,972 |  |  | 18,641 |  |

[0000950170-24-098129:notes:163]
|  |  | June 30,2024 |  | June 30,2023 |  |
| Weighted average remaining lease term | 5.8 years |  | 4.6 years |  |
| Weighted average discount rate |  | 5.8 | % |  | 5.2 | % |

[0000950170-24-098129:notes:164]
Short-term lease expense, which represents expense for leases with terms of one year or less, was not material for each of the years ended June 30, 2024, 2023, or 2022.

[0000950170-24-098129:notes:165]
The following table presents maturities of the Company’s operating lease liabilities as of June 30, 2024 (in thousands):

[0000950170-24-098129:notes:166]
|  |  | Amount |  |
| For the fiscal year ending June 30, |  |  |  |
| 2025 |  | $ | 12,818 |  |
| 2026 |  |  | 12,544 |  |
| 2027 |  |  | 11,151 |  |
| 2028 |  |  | 5,317 |  |
| 2029 |  |  | 4,989 |  |
| Thereafter |  |  | 15,042 |  |
| Total future minimum lease payments |  |  | 61,861 |  |
| Less amount representing interest |  |  | (9,847 | ) |
| Total operating lease liabilities |  | $ | 52,014 |  |
| Operating lease liabilities, current |  | $ | 10,547 |  |
| Operating lease liabilities, non-current |  | $ | 41,466 |  |

[0000950170-24-098129:notes:167]
Sublease Considerations
The Company currently is a sublessor on one operating facility sublease that expires on July 31, 2024. The Company's subleases have original terms ranging from one to six years and extend through the term of the underlying leases. The subleases do not include renewal options, purchase options, or termination rights. The Company included $0.1 million, $0.5 million and $2.7 million of sublease income in lease expense for the years ended June 30, 2024, 2023, and 2022, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-24-098129:notes:168]
10. Commitments and Contingencies

[0000950170-24-098129:notes:169]
Purchase Commitments

[0000950170-24-098129:notes:170]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2024, the Company had non-cancelable commitments to purchase $38.2 million of inventory, which will be received and consumed during fiscal 2025. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0000950170-24-098129:notes:171]
Legal Proceedings

[0000950170-24-098129:notes:172]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-24-098129:notes:173]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment of whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty. However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0000950170-24-098129:notes:174]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-24-098129:notes:175]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process and an oral hearing has been set for October 24, 2024.

[0000950170-24-098129:notes:176]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0000950170-24-098129:notes:177]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company filed an appeal, which was dismissed on October 12, 2023. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals. An oral hearing has been set for December 10, 2024.

[0000950170-24-098129:notes:178]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-24-098129:notes:179]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint, which was denied on January 30, 2024. On March 20, 2023, the Company filed a motion to refer questions to the U.S. Copyright Office on the invalidity of SNMP’s copyrights, which was denied on March 18, 2024. The trial date and all other dates have been vacated and the parties have been ordered to attend a mediation, scheduled for September 19, 2024.

[0000950170-24-098129:notes:180]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-24-098129:notes:181]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system. Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal and an oral hearing has been set for March 27, 2025.

[0000950170-24-098129:notes:182]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021 and a hearing date has been set for November 20, 2024.

[0000950170-24-098129:notes:183]
Indemnification Obligations

[0000950170-24-098129:notes:184]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain. While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-24-098129:notes:185]
11. Stockholders’ Equity

[0000950170-24-098129:notes:186]
Preferred Stock

[0000950170-24-098129:notes:187]
In April 2001, in connection with entering into a rights agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors (the “Board”) is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As noted below, the 2021 Tax Benefit Preservation Plan (defined below), as amended, accelerated the expiration of preferred share purchase rights  under the 2021 Tax Benefit Preservation Plan to the close of business on August 24, 2023, and no person has any rights pursuant to the 2021 Tax Benefit Preservation Plan. As of June 30, 2024, no shares of preferred stock were outstanding.

[0000950170-24-098129:notes:188]
Stockholders’ Rights Agreement

[0000950170-24-098129:notes:189]
On April 26, 2012, the Company entered into the “Restated Rights Plan,” which governed the terms of each right (“Right”) that had been issued with respect to each share of the Company's common stock. Each Right initially represented the right to purchase one one-thousandth of a share of the Company’s Preferred Stock. From 2013 through 2020, the Board and stockholders approved amendments providing for one-year extensions of the term of the Restated Rights Plan.

[0000950170-24-098129:notes:190]
On May 17, 2021, the Company entered into the Amended and Restated Tax Benefit Preservation Plan (the “2021 Tax Benefit Preservation Plan”), which amended and restated the Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC, as the rights agent. The 2021 Tax Benefit Preservation Plan was approved by stockholders of the Company at the annual meeting of stockholders held on November 4, 2021. The 2021 Tax Benefit Preservation Plan governs the terms of each Right that had been issued with respect to each share of the Company's common stock. Each Right initially represented the right to purchase one one-thousandth of a share of the Company’s Preferred Stock.

[0000950170-24-098129:notes:191]
The Board adopted the 2021 Tax Benefit Preservation Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the IRC as a result of ordinary buying and selling of shares of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the 2021 Tax Benefit Preservation Plan.

[0000950170-24-098129:notes:192]
On August 23, 2023, the Board approved an amendment to the 2021 Tax Benefit Preservation Plan, effective as of August 24, 2023 (the “First Amendment”). The First Amendment amended the Restated Tax Plan by accelerating the expiration of the Company’s preferred share purchase rights by amending the definition of “Final Expiration Date” to mean the close of business on August 24, 2023. Accordingly, the Rights which were previously dividended to holders of record of the common stock of the Company expired on the close of business on August 24, 2023 and no person has any rights pursuant to the 2021 Tax Benefit Preservation Plan or the Rights.

[0000950170-24-098129:notes:193]
Equity Incentive Plan

[0000950170-24-098129:notes:194]
The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on August 11, 2021 to update tax withholding obligations. The Compensation Committee of the Board unanimously approved an amendment to the Extreme Networks, Inc. Amended and Restated 2013 Equity Incentive Plan (the “2013 Plan”) on September 14, 2023 to increase the maximum number of available shares by 5.0 million shares. The amendment was approved by the stockholders of the Company at the annual meeting of the stockholders held on November 8, 2023.

[0000950170-24-098129:notes:195]
Employee Stock Purchase Plan

[0000950170-24-098129:notes:196]
The Compensation Committee of the Board unanimously approved an amendment to the 2014 Employee Stock Purchase Plan (the “ESPP”) on September 9, 2021 to increase the maximum number of shares that will be available for sale thereunder by 7.5 million shares. The amendment was approved by a majority of the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021.

[0000950170-24-098129:notes:197]
Common Stock Repurchases

[0000950170-24-098129:notes:198]
In May 2022, the Board authorized a share repurchase program with authorization to repurchase up to $200.0 million of shares of the Company's common stock over a three-year period beginning in our fiscal year commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. In November 2022, the Board increased the authorization to repurchase shares in any quarter from up to $25.0 million of shares per quarter to up to $50.0 million of shares per quarter. This authorization supersedes and replaces any previously authorized repurchase programs. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0000950170-24-098129:notes:199]
During fiscal year 2024, the Company repurchased a total of 2.4 million shares of its common stock on the open market at a total cost of $49.9 million with an average price of $21.08 per share. During fiscal year 2023, the Company repurchased a total of 5.4 million shares of its common stock on the open market at a total cost of $99.9 million with an average price of $18.58 per share. In fiscal year 2022, the Company repurchased a total of 3.9 million shares of its common stock on the open market at a total cost of $45.0 million with an average price of $11.59 per share. As of June 30, 2024, approximately $50.3 million remains available for share repurchases under the share repurchase program.

[0000950170-24-098129:notes:200]
As provision of the Inflation Reduction Act enacted in the U.S., the Company is subject to an excise tax on corporate stock repurchases, which is assessed as one percent of the fair market value of net corporate stock repurchases after December 31, 2022. The  excise tax's effect on net corporate stock repurchases was not material for fiscal year ended June 30, 2024 and 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-24-098129:notes:201]
12. Employee Benefit Plans

[0000950170-24-098129:notes:202]
As of June 30, 2024, the Company has the following share-based compensation plans and the 401(k) Plan discussed below:

[0000950170-24-098129:notes:203]
2013 Equity Incentive Plan

[0000950170-24-098129:notes:204]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units ("RSUs") (including performance-based or market-based RSUs), performance shares, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and RSUs to non-employee members of the Board and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, 6.6 million shares of the Company's common stock under the 2005 Plan were transferred to the 2013 Stock Plan and were added to the number of shares available for future grant under the 2013 Plan. Prior to fiscal 2024, stockholders approved the issuance of an additional 38.7 million shares of the Company's common stock. During the year ended June 30, 2024, an additional 5.0 million shares were authorized and made available for grant under the 2013 Plan. The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting. As of June 30, 2024, total options and awards to acquire 7.6 million shares were outstanding under the 2013 Plan and 13.4 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0000950170-24-098129:notes:205]
Aerohive 2014 Equity Incentive Plan

[0000950170-24-098129:notes:206]
Pursuant to the acquisition of Aerohive on August 9, 2019, the Company assumed the Aerohive 2014 Equity Incentive Plan (the “Aerohive Plan”). Stock awards outstanding under the Aerohive Plan were converted into awards for shares of the Company's common stock as of the date of the acquisition of Aerohive at a predetermined rate pursuant to the Merger Agreement entered into in connection with the acquisition of Aerohive. As of June 30, 2024, total awards to acquire 2,288 shares of the Company's common stock were outstanding under the Aerohive Plan. If a participant terminates employment prior to the vesting dates, the non-vested shares will be forfeited and retired. No future grants may be made from the Aerohive Plan.

[0000950170-24-098129:notes:207]
Shares Reserved for Issuance

[0000950170-24-098129:notes:208]
The Company had the following reserved shares of the Company's common stock for future issuance as of the dates noted (in thousands):

[0000950170-24-098129:notes:209]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 13,414 |  |  |  | 9,995 |  |
| Employee stock options and awards outstanding |  |  | 7,562 |  |  |  | 10,038 |  |
| 2014 Employee Stock Purchase Plan |  |  | 7,130 |  |  |  | 8,467 |  |
| Total shares reserved for issuance |  |  | 28,106 |  |  |  | 28,500 |  |

[0000950170-24-098129:notes:210]
Stock Options

[0000950170-24-098129:notes:211]
The following table summarizes stock option activity under all plans for the year ended June 30, 2024 (in thousands except per share amount and contractual term):

[0000950170-24-098129:notes:212]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.70 |  |  | $ | 23,136 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | (114 | ) |  |  | 6.40 |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 1.75 |  |  | $ | 7,376 |  |
| Vested and expected to vest at June 30, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 1.75 |  |  | $ | 7,376 |  |
| Exercisable at June 30, 2024 |  |  | 1,073 |  |  | $ | 6.58 |  |  |  | 1.75 |  |  | $ | 7,376 |  |

[0000950170-24-098129:notes:213]
The total intrinsic value of options exercised in fiscal years 2024 and 2022 was $1.1 million and $4.9 million, respectively. There were no options exercised during the fiscal year 2023.

[0000950170-24-098129:notes:214]
There were no stock options granted during the fiscal years 2024 and 2023. As of June 30, 2024,  all outstanding options are fully vested and compensation cost related to stock options has been fully recognized.

[0000950170-24-098129:notes:215]
Stock Awards

[0000950170-24-098129:notes:216]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of RSUs, including performance-based or market-based RSUs which vest over a fixed period of time or based upon the satisfaction of certain performance criteria or market conditions. The Company recognizes compensation expense on the awards over the vesting period based on the award’s fair value as of the date of grant. The Company does not estimate forfeitures, but accounts for them as incurred.

[0000950170-24-098129:notes:217]
The following table summarizes stock award activity for the year ended June 30, 2024 (in thousands, except grant date fair value):

[0000950170-24-098129:notes:218]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2023 |  |  | 8,851 |  |  | $ | 14.25 |  |  |  |  |
| Granted |  |  | 4,038 |  |  |  | 27.37 |  |  |  |  |
| Released |  |  | (5,365 | ) |  |  | 12.84 |  |  |  |  |
| Canceled |  |  | (1,035 | ) |  |  | 20.04 |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2024 |  |  | 6,489 |  |  | $ | 22.65 |  |  | $ | 87,276 |  |
| Stock awards expected to vest at June 30, 2024 |  |  | 6,489 |  |  | $ | 22.65 |  |  | $ | 87,276 |  |

[0000950170-24-098129:notes:219]
The RSUs granted under the 2013 plan vest over a period of time, generally one-to-three years, and are subject to participant's continued service to the Company.

[0000950170-24-098129:notes:220]
The aggregate fair value, as of the respective grant dates of awards granted during the fiscal years ended June 30, 2024, 2023 and 2022 was $110.5 million, $106.8 million and $50.7 million, respectively.

[0000950170-24-098129:notes:221]
For fiscal years ended June 30, 2024, 2023, and 2022, the Company withheld an aggregate of 1.9 million shares, 1.4 million shares, and 2.2 million shares, respectively, upon the vesting of awards, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0000950170-24-098129:notes:222]
For fiscal years ended June 30, 2024, 2023 and 2022, the Company remitted cash of $47.9 million, $21.9 million, $24.5 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Payments for tax withholdings, net of proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0000950170-24-098129:notes:223]
As of June 30, 2024, there was $80.0 million in unrecognized compensation costs related to non-vested stock awards which includes the performance and market condition awards as discussed below. This cost is expected to be recognized over a weighted-average period of 1.6 years.

[0000950170-24-098129:notes:224]
Stock Awards – Officers and Directors

[0000950170-24-098129:notes:225]
RSUs granted during fiscal 2024, 2023 and 2022 to named executive officers and directors totaled 0.7 million awards, 1.8 million awards and 1.0 million awards, respectively which included awards with market-based conditions as discussed below.

[0000950170-24-098129:notes:226]
Stock Awards - Performance Awards

[0000950170-24-098129:notes:227]
During fiscal 2024 and 2023, the Compensation Committee of the Board granted 0.8 million and 1.2 million RSUs, respectively with vesting based on market conditions (“MSUs”) to certain of the Company’s executive officers. The MSUs granted during fiscal 2024 included 0.5 million MSUs subject to total shareholder return (“TSR”) and 0.3 million  MSUs subject to certain stock price targets. The MSUs granted during fiscal 2023 were subject to TSR.

[0000950170-24-098129:notes:228]
| Level | Relative TSR | Shares Vested |
| Below Threshold | TSR is less than the Index by more than 37.5 percentage points | 0% |
| Threshold | TSR is less than the Index by 37.5 percentage points | 25% |
| Target | TSR equals the Index | 100% |
| Maximum | TSR is greater than the Index by 25 percentage points or more | 150% |

[0000950170-24-098129:notes:229]
TSR is calculated based on the average closing price for the 30-trading days prior to the beginning and end of the performance periods. Performance is measured based on three periods, with the ability for up to one-third of target shares to vest after years 1 and 2 and the ability for up to the maximum of the full award to vest based on the full 3-year TSR less any shares vested based on 1- and 2- year periods. Linear interpolation is used to determine the number of shares vested for achievement between target levels.

[0000950170-24-098129:notes:230]
The stock price target MSUs vest upon the achievement of a certain stock price target over the defined performance period. The stock price target shall be deemed as achieved if the average closing stock price over any thirty consecutive trading days during the period from grant date through the third anniversary of the grant date equals or exceeds the price target of $41.38 for the initial performance period. Upon satisfaction of the initial stock price target, 50% of the target shares will vest on the 3rd anniversary of the grant date and the remaining 50% will vest on the 4th anniversary of the grant date, subject to employees continued service through the applicable vesting dates. If the units are not earned on the last day of initial performance period, the units will remain outstanding and be eligible to be earned if the average closing stock price over any thirty consecutive trading days equals or exceeds the price target of $46.96.

[0000950170-24-098129:notes:231]
On February 14, 2024, the Company modified certain terms and conditions of the stock price target MSUs for certain executive officers. Under the modified agreement, the stock price target over the initial and fourth year performance periods were revised to $23.00 and $26.00, respectively. All other contractual terms remained unchanged. The incremental compensation cost recognized during fiscal 2024 and ratably over the remaining requisite service period is not material.

[0000950170-24-098129:notes:232]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the TSR MSUs granted during fiscal 2024 was $32.66 per share. The weighted-average assumptions used in the Monte Carlo simulation included the expected volatility of 50%, risk-free interest rate of 4.43%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-24-098129:notes:233]
The weighted-average grant-date fair value of the MSUs granted during the year ended June 30, 2023 was $17.62 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 65%, risk-free rate of 3.27%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-24-098129:notes:234]
The weighted-average grant-date fair value of the MSUs granted during the year ended June 30, 2022 was $12.69 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-24-098129:notes:235]
The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-24-098129:notes:236]
The following table summarizes stock awards with market or performance-based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0000950170-24-098129:notes:237]
|  |  | Fiscal Year 2024 |  |  | Fiscal Year 2023 |  |  | Fiscal Year 2022 |  |
| Performance awards granted |  |  | 841 |  |  |  | 1,221 |  |  |  | 727 |  |
| Performance awards earned |  |  | 846 |  |  |  | 400 |  |  |  | 158 |  |

[0000950170-24-098129:notes:238]
2014 Employee Stock Purchase Plan

[0000950170-24-098129:notes:239]
On August 27, 2014, the Board approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. During the fiscal year ended June 30, 2022, the Board of Directors unanimously approved an amendment to the 2014 ESPP to increase the maximum number of shares that will be available for sale by 7.5 million shares, which was approved by the stockholders of the Company at the annual meeting of stockholders held on November 4, 2021. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period has a maximum duration of six months and the maximum shares issuable for each purchase period is 1.5 million shares. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period.

[0000950170-24-098129:notes:240]
During the fiscal years ended June 30, 2024 and 2023, there were 1.3 million and 1.5 million shares issued under the 2014 ESPP. As of June 30, 2024, there have been an aggregate 19.9 million shares issued under the 2014 ESPP.

[0000950170-24-098129:notes:241]
Share-Based Compensation Expense

[0000950170-24-098129:notes:242]
Share-based compensation expense recognized in the financial statements by line-item caption is as follows (in thousands):

[0000950170-24-098129:notes:243]
|  |  | Year Ended |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |
| Cost of product revenues |  | $ | 1,899 |  |  | $ | 1,856 |  |  | $ | 1,186 |  |
| Cost of subscription and support revenues |  |  | 2,994 |  |  |  | 3,513 |  |  |  | 1,421 |  |
| Research and development |  |  | 16,686 |  |  |  | 14,824 |  |  |  | 9,995 |  |
| Sales and marketing |  |  | 26,524 |  |  |  | 22,250 |  |  |  | 15,000 |  |
| General and administrative |  |  | 28,660 |  |  |  | 21,029 |  |  |  | 15,760 |  |
| Total share-based compensation expense |  | $ | 76,763 |  |  | $ | 63,472 |  |  | $ | 43,362 |  |

[0000950170-24-098129:notes:244]
The Company uses the straight-line method for expense attribution, other than for the PSUs and MSUs, which may use the accelerated attribution method. The Company does not estimate forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur.

[0000950170-24-098129:notes:245]
The fair value of each RSU grant with market-based vesting criteria under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0000950170-24-098129:notes:246]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP shares is the offering period for each purchase. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility of the Company’s stock.

[0000950170-24-098129:notes:247]
The weighted-average estimated per share fair value of shares under the 2014 ESPP in fiscal years 2024, 2023 and 2022, was $5.73, $4.87, $3.32, respectively.

[0000950170-24-098129:notes:248]
|  |  | Employee Stock Purchase Plan |  |  |
|  |  | Year Ended |  |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  |
| Risk-free interest rate |  |  | 5.42 | % |  |  | 3.84 | % |  |  | 0.33 | % |  |
| Volatility |  |  | 47 | % |  |  | 55 | % |  |  | 49 | % |  |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |

[0000950170-24-098129:notes:249]
401(k) Plan

[0000950170-24-098129:notes:250]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $23,000 for calendar year 2024. Employees aged 50 or over may elect to contribute an additional $7,500. The amount contributed to the Plan is on a pre-tax basis.

[0000950170-24-098129:notes:251]
The Company provides for discretionary matching contributions as determined by the Board for each calendar year. All matching contributions vest immediately. In addition, the Plan provides for discretionary contributions as determined by the Board each year. The program effective during fiscal 2024 was established to match $0.50 for every dollar contributed by the employee up to the first 6.0% of pay. The Company’s matching contributions to the Plan totaled $5.2 million, $5.2 million and $4.6 million, for fiscal years ended June 30, 2024, 2023 and 2022, respectively. No discretionary contributions were made in fiscal years ended June 30, 2024, 2023 and 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-24-098129:notes:252]
13. Information about Segments and Geographic Areas

[0000950170-24-098129:notes:253]
The Company operates in one segment, the development and marketing of network infrastructure equipment and related software. The Company conducts business globally and is managed geographically. Revenues are attributed to a geographical area based on the billing address of customers. The Company operates in three geographical areas: Americas, EMEA, and APAC. The Company’s chief operating decision maker, who is its Chief Executive Officer, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0000950170-24-098129:notes:254]
See Note 3, Revenues, for the Company’s revenues by geographic regions and channel based on the customers’ billing address.

[0000950170-24-098129:notes:255]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0000950170-24-098129:notes:256]
|  |  | June 30,2024 |  |  | June 30,2023 |  |
| Americas |  | $ | 136,745 |  |  | $ | 124,375 |  |
| EMEA |  |  | 33,715 |  |  |  | 35,175 |  |
| APAC |  |  | 11,499 |  |  |  | 11,244 |  |
| Total long-lived assets |  | $ | 181,959 |  |  | $ | 170,794 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-24-098129:notes:257]
14. Derivatives and Hedging

[0000950170-24-098129:notes:258]
Interest Rate Swaps

[0000950170-24-098129:notes:259]
The Company is exposed to interest rate risk on its debt. The Company may enter into interest rate swap contracts to effectively manage the impact of fluctuations of interest rate changes on its outstanding debt which has a floating interest rate. The Company does not enter into derivative contracts for trading or speculative purposes.

[0000950170-24-098129:notes:260]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815, Derivatives and Hedging, the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation of the respective cash flow hedge. In those circumstances, the net gain or loss remains in "Accumulated other comprehensive loss" and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0000950170-24-098129:notes:261]
During the fiscal years ended June 30, 2024 and 2023 the Company did not enter into any interest rate swap contracts.

[0000950170-24-098129:notes:262]
Foreign Exchange Forward Contracts

[0000950170-24-098129:notes:263]
The Company uses derivative financial instruments to manage exposures to foreign currency that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts primarily to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies.

[0000950170-24-098129:notes:264]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income, net” in the accompanying consolidated statements of operations. As of June 30, 2024 and 2023, foreign exchange forward currency contracts not designated as hedging instruments had the total notional amount of $31.3 million and $3.4 million, respectively. These contracts had maturities of less than 40 days. For the years ended June 30, 2024, 2023 and 2022 the net losses recorded in the consolidated statements of operations from these contracts were approximately $0.3 million, $0.4 million, and $1.4 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0000950170-24-098129:notes:265]
There were no foreign exchange forward currency contracts that were designated as hedging instruments at June 30, 2024 and 2023.

[0000950170-24-098129:notes:266]
For the fiscal year ended June 30, 2024, 2023 and 2022 the Company recorded a foreign currency transaction gains from operations of $0.6 million, $0.8 million and $1.7 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-24-098129:notes:267]
15. Restructuring and Related Charges

[0000950170-24-098129:notes:268]
During fiscal years ended June 30, 2024, 2023 and 2022, the Company recorded restructuring and related charges of $36.3 million, $2.9 million and $1.7 million, respectively. The charges are reflected in “Restructuring and related charges” in the consolidated statements of operations.

[0000950170-24-098129:notes:269]
2024 Restructuring

[0000950170-24-098129:notes:270]
During the fourth quarter of fiscal 2024, the Company continued to execute the "Q2 2024", "Q3 2024", and "2023" Plans. The Company incurred restructuring charges during the quarter related to severance and benefits costs for the "Q2 2024" and "Q3 2024" Plans. Additionally, as part of the "2023 Plan", the Company incurred restructuring charges related to the accelerated depreciation of leasehold improvements located in the labs at the Company's San Jose, California location, These leasehold improvements were determined to no longer provide economic benefits to the Company as a result of the lab move.

[0000950170-24-098129:notes:271]
During the third quarter of fiscal 2024, the Company executed a global reduction-in-force plan targeted towards the reorganization of the Company's research and development and sales and marketing functions to align the Company's workforce with its strategic priorities and to focus on specific geographies and industry segments with higher growth opportunities (the “Q3 2024 Plan”). During the fiscal year ended June 30, 2024, the Company recorded restructuring charges of approximately $11.0 million related to the Q3 2024 Plan, which primarily consisted of severance and benefits expenses.

[0000950170-24-098129:notes:272]
During the second quarter of fiscal 2024, the Company executed a global reduction-in-force plan to rebalance its workforce to create greater efficiency and improve execution, in alignment with the Company's business and strategic priorities, while reducing its ongoing operating expenses to address reduced revenue and macro-economic conditions (the “Q2 2024 Plan”). During the fiscal year ended June 30, 2024, the Company recorded restructuring charges of approximately $15.9 million related to the Q2 2024 Plan, which primarily consisted of employee severance and benefits expenses, legal and consulting fees.

[0000950170-24-098129:notes:273]
The Company expects to complete these ongoing restructuring plans by the end of calendar year 2024 and expects to incur about $1.0 million in additional charges for the Q2 2024 Plan and the Q3 2024 Plan.

[0000950170-24-098129:notes:274]
During the first quarter of fiscal 2024, the Company initiated a reduction-in-force plan to rebalance the workforce to create greater efficiency and improve execution in alignment with the Company's business and strategic priorities (the “Q1 2024 Plan”). It consisted primarily of workforce reduction to drive productivity in research and development, sales and marketing and provide efficiency across operations and general and administrative functions. During the fiscal year ended June 30, 2024, the Company incurred charges of approximately $2.9 million related to the Q1 2024 Plan. As of June 30, 2024, the plan was completed.

[0000950170-24-098129:notes:275]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform its business infrastructure and reduce its facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project, the Company is moving engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating the Company's labs. During the fiscal year ended June 30, 2024, the Company incurred restructuring charges of approximately $6.6 million primarily for moving costs and including accelerated depreciation on lab leasehold improvements of approximately $5.9 million. During the fiscal year ended June 30, 2023, the Company incurred restructuring charges of approximately $2.9 million related to primarily included additional facilities expenses related to previously impaired facilities. The Company expects that the project will take about 3 to 6 months from June 30, 2024 to complete, and expects to incur charges of approximately $2.8 million throughout this period, primarily for asset disposals, contractor costs, and other fees.

[0000950170-24-098129:notes:276]
As of June 30, 2024 the restructuring liability was approximately $11.5 million, which was recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. The Company did not have any restructuring liability as of June 30, 2023.

[0000950170-24-098129:notes:277]
The following table summarizes the activity related to the Company’s restructuring and related liabilities during the following periods (in thousands):

[0000950170-24-098129:notes:278]
|  |  | Year Ended |  |
|  |  | June 30, 2024 |  |
| Balance at beginning of period |  | $ | — |  |
| Period charges |  |  | 37,622 |  |
| Period reversals |  |  | (1,301 | ) |
| Period non-cash adjustments |  |  | (5,940 | ) |
| Period payments |  |  | (18,912 | ) |
| Balance at end of period |  | $ | 11,469 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-24-098129:notes:279]
16. Income Taxes

[0000950170-24-098129:notes:280]
Income (loss) before income taxes is as follows (in thousands):

[0000950170-24-098129:notes:281]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | (72,684 | ) |  | $ | (2,179 | ) |  | $ | (1,204 | ) |
| Foreign |  |  | (4,815 | ) |  |  | 96,285 |  |  |  | 53,398 |  |
| Income (loss) before income taxes |  | $ | (77,499 | ) |  | $ | 94,106 |  |  | $ | 52,194 |  |

[0000950170-24-098129:notes:282]
The provision for income taxes for the years ended June 30, 2024, 2023 and 2022 consisted of the following (in thousands):

[0000950170-24-098129:notes:283]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Current: |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 1,340 |  |  | $ | 3,221 |  |  | $ | — |  |
| State |  |  | 246 |  |  |  | 3,640 |  |  |  | 1,069 |  |
| Foreign |  |  | 6,843 |  |  |  | 9,086 |  |  |  | 6,460 |  |
| Total current |  |  | 8,429 |  |  |  | 15,947 |  |  |  | 7,529 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 404 |  |  |  | 368 |  |  |  | 396 |  |
| State |  |  | 252 |  |  |  | 433 |  |  |  | 227 |  |
| Foreign |  |  | (620 | ) |  |  | (716 | ) |  |  | (229 | ) |
| Total deferred |  |  | 36 |  |  |  | 85 |  |  |  | 394 |  |
| Provision for income taxes |  | $ | 8,465 |  |  | $ | 16,032 |  |  | $ | 7,923 |  |

[0000950170-24-098129:notes:284]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (21 percent) to income before income taxes is explained below (in thousands):

[0000950170-24-098129:notes:285]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2022 |  |
| Tax at federal statutory rate |  | $ | (16,275 | ) |  | $ | 19,762 |  |  | $ | 10,960 |  |
| State income tax, net of federal benefit |  |  | 194 |  |  |  | 3,003 |  |  |  | 844 |  |
| Global intangible low-taxed income |  |  | 10,595 |  |  |  | 22,721 |  |  |  | 15,470 |  |
| US valuation allowance change – deferred tax movement |  |  | 18,199 |  |  |  | (24,682 | ) |  |  | (15,264 | ) |
| Research and development credits |  |  | (7,746 | ) |  |  | (1,503 | ) |  |  | (3,122 | ) |
| Tax impact of foreign earnings |  |  | 4,399 |  |  |  | (5,627 | ) |  |  | (3,762 | ) |
| Foreign withholding taxes |  |  | 2,943 |  |  |  | 1,082 |  |  |  | 1,032 |  |
| Stock based compensation |  |  | (8,551 | ) |  |  | (1,980 | ) |  |  | (5,011 | ) |
| Goodwill amortization |  |  | 549 |  |  |  | 730 |  |  |  | 525 |  |
| Nondeductible officer compensation |  |  | 8,667 |  |  |  | 4,582 |  |  |  | 5,691 |  |
| Nondeductible meals and entertainment |  |  | 319 |  |  |  | 324 |  |  |  | 193 |  |
| Foreign tax credits |  |  | (4,828 | ) |  |  | (2,380 | ) |  |  | 367 |  |
| Provision for income taxes |  | $ | 8,465 |  |  | $ | 16,032 |  |  | $ | 7,923 |  |

[0000950170-24-098129:notes:286]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0000950170-24-098129:notes:287]
|  |  | June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 19,634 |  |  | $ | 21,553 |  |
| Tax credit carry-forwards |  |  | 62,936 |  |  |  | 57,841 |  |
| Depreciation |  |  | 3,477 |  |  |  | 1,899 |  |
| Intangible amortization |  |  | 19,846 |  |  |  | 20,652 |  |
| Deferred revenue |  |  | 25,171 |  |  |  | 19,698 |  |
| Inventory write-downs |  |  | 13,819 |  |  |  | 13,616 |  |
| Other allowances and accruals |  |  | 33,031 |  |  |  | 38,391 |  |
| Stock based compensation |  |  | 7,445 |  |  |  | 6,332 |  |
| Deferred intercompany gain |  |  | 3,690 |  |  |  | 3,693 |  |
| Ireland goodwill amortization |  |  | 4,142 |  |  |  | 4,862 |  |
| Capitalization of research and development |  |  | 37,912 |  |  |  | 19,062 |  |
| Operating lease liability |  |  | 8,560 |  |  |  | 6,303 |  |
| Other |  |  | 858 |  |  |  | 634 |  |
| Total deferred tax assets |  |  | 240,521 |  |  |  | 214,536 |  |
| Valuation allowance |  |  | (218,375 | ) |  |  | (195,297 | ) |
| Total net deferred tax assets |  |  | 22,146 |  |  |  | 19,239 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Goodwill amortization |  |  | (14,403 | ) |  |  | (12,471 | ) |
| Operating lease right of use asset |  |  | (6,906 | ) |  |  | (4,543 | ) |
| Prepaid commissions |  |  | (3,499 | ) |  |  | (4,899 | ) |
| Deferred tax liability on foreign withholdings |  |  | (854 | ) |  |  | (747 | ) |
| Total deferred tax liabilities |  |  | (25,662 | ) |  |  | (22,660 | ) |
| Net deferred tax liabilities |  | $ | (3,516 | ) |  | $ | (3,421 | ) |
| Recorded as: |  |  |  |  |  |  |
| Net non-current deferred tax assets |  |  | 4,462 |  |  |  | 4,326 |  |
| Net non-current deferred tax liabilities |  |  | (7,978 | ) |  |  | (7,747 | ) |
| Net deferred tax liabilities |  | $ | (3,516 | ) |  | $ | (3,421 | ) |

[0000950170-24-098129:notes:288]
The Company’s global valuation allowance increased by $23.1 million in the fiscal year ended June 30, 2024 and decreased by $14.4 million in the fiscal year ended June 30, 2023. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against certain non-U.S. deferred tax assets in Ireland and Brazil. The valuation allowance is determined by assessing both negative and positive available evidence to determine whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including historical losses, tax attributes expiring unutilized in recent years and the cyclical nature of the Company's business provides sufficient negative evidence that require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0000950170-24-098129:notes:289]
As of June 30, 2024, the Company had net operating loss carry-forwards (“NOLs”) for U.S. federal and state tax purposes of $16.2 million and $137.4 million, respectively. As of June 30, 2024, the Company also had foreign NOLs in Australia, Brazil, and Ireland of $5.2 million, $12.7 million, and $13.7 million respectively. As of June 30, 2024, the Company also had federal and state tax credit carry-forwards of $34.2 million and $36.4 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits. Of the $16.2 million U.S. federal NOLs carry-forwards, $2.8 million will begin to expire in the fiscal year ending June 30, 2037 and $13.4 million have an indefinite carryforward life. The state net operating losses of $137.4 million will begin to partially expire in the fiscal year ending June 30, 2025. The foreign net operating losses can generally be carried forward indefinitely. Federal research and development tax credits of $28.5 million will expire beginning in fiscal 2026, if not utilized and foreign tax credits of $5.7 million will expire beginning in fiscal 2025. North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2025, if not utilized. California state research and development tax credits of $35.6 million do not expire and can be carried forward indefinitely.

[0000950170-24-098129:notes:290]
In June 2024, the Company performed an analysis under Section 382 of the IRC with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of these U.S. tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2023, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes. The Company also performed, in June 2020, a separate IRC section 382 analysis with respect to the NOLs and tax credits acquired from Aerohive and have determined that while the Company will be subject to an annual limitation, the Company should not be limited on the full utilization of the losses and credits during the statutory allowable carryforward period for the NOLs and credits.

[0000950170-24-098129:notes:291]
As of June 30, 2024, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $41.7 million. It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the U.S. The Company has reviewed its prior position on the reinvestment of earnings of certain foreign subsidiaries and has recorded a deferred tax liability of $0.9 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential tax associated with repatriation of these earnings is $7.9 million.

[0000950170-24-098129:notes:292]
Most recently, the United States enacted the Inflation Reduction Act in 2022, which made a number of changes to the IRC, including adding a 1% excise tax on stock buybacks by publicly traded corporations and a corporate minimum tax on adjusted financial statement income of certain large companies. We do not anticipate this legislation will have a material impact for the Company.

[0000950170-24-098129:notes:293]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world. Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire, Texas and North Carolina. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years ended June 2004 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years ended June 2005 forward due to net operating losses. Statutes related to material foreign jurisdictions are generally open for fiscal years ended June 2020 forward for Ireland and for tax year ended March 2020 forward for India.

[0000950170-24-098129:notes:294]
The U.S. tax rules require U.S. tax on foreign earnings, known as Global Intangible Low Taxed Income (“GILTI”). Under U.S. Generally Accepted Accounting Principles, taxpayers are allowed to make an accounting policy election of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes. The Company has elected to account for GILTI tax as a component of tax expense in the period in which it is incurred under the period cost method.

[0000950170-24-098129:notes:295]
As of June 30, 2024, the Company had $18.2 million of unrecognized tax benefits. If fully recognized in the future, $0.2 million would impact the effective tax rate, and $18.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance. The Company does not reasonably expect the amount of unrealized tax benefits to materially decrease during the next twelve months.

[0000950170-24-098129:notes:296]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0000950170-24-098129:notes:297]
| Balance at June 30, 2022 |  | $ | 18,367 |  |
| Decrease related to prior year tax positions |  |  | (21 | ) |
| Increase related to prior year tax positions |  |  | 1 |  |
| Increase related to current year tax positions |  |  | 15 |  |
| Lapse of statute of limitations |  |  | (65 | ) |
| Balance at June 30, 2023 |  | $ | 18,297 |  |
| Decrease related to prior year tax positions |  |  | (25 | ) |
| Increase related to prior year tax positions |  |  | — |  |
| Increase related to current year tax positions |  |  | 20 |  |
| Lapse of statute of limitations |  |  | (75 | ) |
| Balance at June 30, 2024 |  | $ | 18,217 |  |

[0000950170-24-098129:notes:298]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of income tax expense in the consolidated statements of operations and totaled less than $0.1 million for each of the years ended 2024, 2023 and 2022.


## us-gaap:EarningsPerShareTextBlock

[0000950170-24-098129:notes:299]
17. Net Income (Loss) Per Share

[0000950170-24-098129:notes:300]
Basic net income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock outstanding during the period. Diluted income (loss) per share is calculated by dividing net income (loss) by the weighted average number of shares of common stock used in the basic net income (loss) per share calculation plus the dilutive effect of any shares subject to repurchase, options and unvested RSUs.

[0000950170-24-098129:notes:301]
The following table presents the calculation of basic and diluted net income (loss) per share (in thousands, except per share data):

[0000950170-24-098129:notes:302]
|  |  | Year Ended |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |
| Net income (loss) |  | $ | (85,964 | ) |  | $ | 78,074 |  |  | $ | 44,271 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 129,288 |  |  |  | 129,473 |  |  |  | 129,437 |  |
| Options to purchase common stock |  |  | — |  |  |  | 708 |  |  |  | 567 |  |
| Restricted stock units |  |  | — |  |  |  | 3,468 |  |  |  | 3,490 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 129,288 |  |  |  | 133,649 |  |  |  | 133,494 |  |
| Net income (loss) per share – basic and diluted |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share – basic |  | $ | (0.66 | ) |  | $ | 0.60 |  |  | $ | 0.34 |  |
| Net income (loss) per share – diluted |  | $ | (0.66 | ) |  | $ | 0.58 |  |  | $ | 0.33 |  |

[0000950170-24-098129:notes:303]
Potentially dilutive shares of common stock from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding RSUs, and the assumed issuance of common stock under the ESPP.

[0000950170-24-098129:notes:304]
The following securities were excluded from the computation of net income (loss) per diluted share of common stock for the periods presented as their effect would have been anti-dilutive (in thousands):

[0000950170-24-098129:notes:305]
|  |  |  |  |  | Year Ended |  |  |  |  |
|  |  | June 30,2024 |  |  | June 30,2023 |  |  | June 30, 2022 |  |
| Options to purchase common stock |  |  | 1,126 |  |  |  | — |  |  |  | — |  |
| Restricted stock units |  |  | 5,946 |  |  |  | 153 |  |  |  | 99 |  |
| Employee Stock Purchase Plan shares |  |  | 193 |  |  |  | 181 |  |  |  | 400 |  |
| Total shares excluded |  |  | 7,265 |  |  |  | 334 |  |  |  | 499 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-24-098129:notes:306]
18. Subsequent Events

[0000950170-24-098129:notes:307]
On August 13, 2024, a putative securities class action (the “Class Action”) was filed in the United States District Court for the Northern District of California captioned Steamfitters Local 449 Pension & Retirement Security Funds v. Extreme Networks, Inc., et al., Case No. 5:24-cv-05102-TLT, naming the Company and certain of our current and former executive officers as defendants.  The lawsuit is purportedly brought on behalf of purchasers of Extreme Networks securities between July 27, 2022 and January 30, 2024 (the “Class Period”).  The complaint alleges claims under Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 promulgated thereunder, based on allegedly false and misleading statements about our business and prospects during the Class Period.  The lawsuit seeks unspecified damages.  We intend to deny the allegations of wrongdoing and vigorously defend against the claims in the Class Action.

[0000950170-24-098129:notes:308]
Effective August 14th, 2024, the Company entered into an Amendment Number One to the 2023 Credit Agreement. Under the new amendment, the Company modified the definition of the consolidated EBITDA for the purposes of evaluating compliance with financial covenants under the 2023 Credit Agreement. The amended definition of consolidated EBITDA modifies the amount and type of add-backs that are allowable to better align with the Company's operations and activities. Further, the amendment provides a waiver for the Company's compliance with the consolidated interest charge coverage ratio for each of the quarters ended June 30, 2024, September 30, 2024, and December 31, 2024, as a perfunctory matter.
