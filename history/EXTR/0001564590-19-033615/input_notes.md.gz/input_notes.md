# EXTR notes — 0001564590-19-033615


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-19-033615:notes:1]
1. Description of Business and Basis of Presentation

[0001564590-19-033615:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or “the Company”) is a leader in providing software-driven networking solutions for enterprise customers.  The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0001564590-19-033615:notes:3]
Fiscal Year

[0001564590-19-033615:notes:4]
The Company uses a fiscal calendar year ending on June 30.  All references herein to “fiscal year ended 2019” or “2019”; “fiscal 2018” or “2018”; “fiscal 2017” or “2017” represent the fiscal years ending, respectively.

[0001564590-19-033615:notes:5]
Principles of Consolidation

[0001564590-19-033615:notes:6]
The consolidated financial statements include the accounts of Extreme Networks and its wholly-owned subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001564590-19-033615:notes:7]
The Company predominantly uses the United States Dollar as its functional currency. The functional currency for certain of its foreign subsidiaries is the local currency. For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.

[0001564590-19-033615:notes:8]
Accounting Estimates

[0001564590-19-033615:notes:9]
The preparation of financial statements and related disclosures in conformity with U.S. generally accepted accounting principles requires management to make estimates and assumptions that affect the amounts reported in the financial statements and accompanying notes. Actual results could differ materially from these estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-033615:notes:10]
2. Summary of Significant Accounting Policies

[0001564590-19-033615:notes:11]
Revenue Recognition

[0001564590-19-033615:notes:12]
The Company derives revenues primarily from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for the products. The Company recognizes revenues when control of promised goods or services is transferred to its customers, in an amount that reflects the consideration the Company expects to be entitled to in exchange for those goods or services.

[0001564590-19-033615:notes:13]
See Note 3. Revenues, for further discussion.

[0001564590-19-033615:notes:14]
Cash, Cash Equivalents and Marketable Securities

[0001564590-19-033615:notes:15]
The Company considers highly liquid investments with maturities of three months or less at the date of purchase to be cash equivalents. Marketable securities are recorded in “Prepaid expense and other current assets” in the accompanying consolidated balance sheet as these are publicly-traded equity securities with maturities of greater than three months, but less than one year at the balance sheet date. Marketable securities are classified as available-for-sale and reported at fair value with unrealized gains and losses included, net of tax, in accumulated other comprehensive loss, a component of stockholders’ equity. Realized gains and losses and declines in the value of available-for-sale securities determined to be other than temporary are included in other income (expense), net. The cost of securities sold is determined based on the specific identification method.

[0001564590-19-033615:notes:16]
Allowance for Product Returns

[0001564590-19-033615:notes:17]
The Company provides an allowance for product returns based on its historical returns, analysis of credit memo data and its return policies. The allowance includes the estimates for product allowances from end customers as well as stock rotations and other returns from the Company’s stocking distributors. The allowance for product returns is a reduction of accounts receivable. If the historical data that the Company uses to calculate the estimated product returns and allowances does not properly reflect actual levels of product returns, these estimates will be revised, resulting in an impact on net revenue. The allowance for product returns estimate is also impacted by the timing of the actual product return from the customer.

[0001564590-19-033615:notes:18]
Allowance for Doubtful Accounts

[0001564590-19-033615:notes:19]
The Company maintains an allowance for doubtful accounts which reflects its best estimate of potentially uncollectible trade receivables. The allowance consists of both specific and general reserves. The Company continually monitors and evaluates the collectability of its trade receivables based on a combination of factors. It records specific allowances for bad debts in general and administrative expense when it becomes aware of a specific customer’s inability to meet its financial obligation to the Company, such as in the case of bankruptcy filings or deterioration of financial position. Estimates are used in determining the allowances for all other customers based on factors such as current trends in the length of time the receivables are past due and historical collection experience. The Company mitigates some collection risk by requiring most of its customers in the Asia-Pacific region, excluding Japan and Australia, to pay cash in advance or secure letters of credit when placing an order with the Company.

[0001564590-19-033615:notes:20]
Inventories

[0001564590-19-033615:notes:21]
The Company values its inventory at lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company has established inventory allowances when conditions exist that suggest that inventory is obsolete or may be in excess of anticipated demand based upon assumptions about future demand. At the point of the loss recognition, a new, lower-cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. Previously written down or obsolete inventory subsequently sold has not had a material impact on gross margin for any of the periods presented.

[0001564590-19-033615:notes:22]
Long-Lived Assets

[0001564590-19-033615:notes:23]
Long-lived assets include (a) property and equipment, (b) goodwill and intangible assets, and (c) other assets. Property and equipment and definite-lived intangible assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets or asset groups may not be recoverable. If such facts and circumstances exist, the Company assesses the recoverability of these assets by comparing the projected undiscounted net cash flows associated with the related asset or group of assets over their remaining lives against their respective carrying amounts. Impairments, if any, are based on the excess of the carrying amount over the fair value of those assets.

[0001564590-19-033615:notes:24]
(a) Property and Equipment, Net

[0001564590-19-033615:notes:25]
Property and equipment are stated at cost less accumulated depreciation and amortization. Depreciation and amortization is computed using the straight-line method over the estimated useful lives of the assets. Estimated useful lives of one to four years are used for computer equipment and software. Estimated useful lives of three to seven years are used for office equipment, furniture and fixtures. Depreciation and amortization of leasehold improvements is computed using the lesser of the useful life or lease terms (ranging from two to ten years).

[0001564590-19-033615:notes:26]
(b) Goodwill and Intangible Assets

[0001564590-19-033615:notes:27]
Goodwill and intangible assets are generated as a result of business combinations and  are comprised of, among other things, developed technology, customer relationships, trade names, and licensing agreements. The Company reevaluates the estimated remaining useful life of acquired definite-lived intangible assets whenever events or changes in circumstances indicate a revision to the remaining period of amortization might be necessary. The carrying amounts of these assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable.

[0001564590-19-033615:notes:28]
Goodwill is calculated as the excess of the purchase price over the fair value of net tangible and identifiable intangible assets acquired. Goodwill is not amortized, but rather is tested for impairment at least annually or more frequently if indicators of impairment are present. The Company performs its annual goodwill impairment analysis as of the first day of the fourth quarter of each year. The Company adopted ASU 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment in fiscal 2018, which eliminated step two from the goodwill impairment test. In assessing impairment on goodwill, the Company bypasses the qualitative assessment and proceed directly to performing the quantitative evaluation of the fair value of the reporting unit, to compare against the carrying value of the reporting unit. A goodwill impairment charge is recognized for the amount by which the reporting unit’s fair value is less than its carrying value. Any loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. Based on the results of the goodwill impairment analyses, the Company determined that no impairment charge needed to be recorded for any periods presented.

[0001564590-19-033615:notes:29]
(c) Other Assets

[0001564590-19-033615:notes:30]
Other assets consist primarily of service parts and long-term deposits. The Company holds service parts to support customers who have purchased service contracts with a hardware replacement element, as well as to support its warranty program. The Company reduces the carrying value of service parts to net realizable value based on expected quantities needed to satisfy contractual service requirements of customers.

[0001564590-19-033615:notes:31]
Business Combinations

[0001564590-19-033615:notes:32]
The Company applies the acquisition method of accounting for business combinations. Under this method of accounting, all assets acquired and liabilities assumed are recorded at their respective fair values at the date of the acquisition. Determining the fair value of assets acquired and liabilities assumed requires management’s judgment and often involves the use of significant estimates and assumptions, including assumptions with respect to future cash inflows and outflows, discount rates, useful lives, among other items. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Market participants are assumed to be buyers and sellers in the principal (most advantageous) market for the asset or liability. Additionally, fair value measurements for an asset assume the highest and best use of that asset by market participants. As a result, the Company may be required to value the acquired assets at fair value measures that do not reflect its intended use of those assets. Use of different estimates and judgments could yield different results.

[0001564590-19-033615:notes:33]
Any excess of the purchase price over the fair value of the net assets acquired is recognized as goodwill. If the fair value of net assets acquired exceeds the fair value of the purchase price, a gain on bargain purchase is recognized within the consolidated statements of operations. Although the Company believes the assumptions and estimates it has made are reasonable and appropriate, they are based in part on historical experience and information that may be obtained from the management of the acquired company and are inherently uncertain. During the measurement period, which may be up to one year from the acquisition date, the Company may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill for facts and considerations that were known at the acquisition date. Upon the conclusion of the measurement period or final determination of the values of assets acquired or liabilities assumed, whichever comes first, any subsequent adjustments are recorded within the Company’s consolidated statements of operations.

[0001564590-19-033615:notes:34]
Deferred Revenue

[0001564590-19-033615:notes:35]
Deferred revenue represents amounts for (i) deferred maintenance and support revenue and (ii) other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0001564590-19-033615:notes:36]
Product Warranties and Guarantees

[0001564590-19-033615:notes:37]
Networking products may contain undetected hardware or software errors when new products or new versions or updates of existing products are released to the marketplace. The majority of the Company’s hardware products are shipped with either a one-year warranty or a limited lifetime warranty, and software products receive a 90-day warranty for media only. Upon shipment of products to its customers, the Company estimates expenses for the cost to repair or replace products that may be returned under warranty and accrues a liability in cost of product revenue for this amount. The determination of the Company’s warranty requirements is based on actual historical experience with the product or product family, estimates of repair and replacement costs and any product warranty problems that are identified after shipment. The Company estimates and adjusts these accruals at each balance sheet date in accordance with changes in these factors.

[0001564590-19-033615:notes:38]
In the normal course of business to facilitate sales of its products, the Company indemnifies its resellers and end-user customers with respect to certain matters. The Company has agreed to hold the customer harmless against losses arising from a breach of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. It is not possible to estimate the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material impact on its operating results or financial position.

[0001564590-19-033615:notes:39]
Stock-based Compensation

[0001564590-19-033615:notes:40]
The Company recognizes compensation expense related to stock-based awards, including stock options, restricted stock units (“RSUs”) and employee stock purchases related to its 2014 Employee Stock Purchase Plan (the “2014 ESPP”), based on the estimated fair value of the award on the grant date, over the requisite service period. The Company accounts for forfeitures as they occur. The Company calculates the fair value of stock options and share purchase options under the 2014 ESPP using the Black-Scholes-Merton option valuation model. The fair value of RSUs is based on the closing stock price of the Company’s common stock on the grant date.

[0001564590-19-033615:notes:41]
The Company grants certain employees performance-based stock options and RSUs. The performance metrics include company-wide financial performance and/or market conditions. For awards that include performance conditions, no compensation cost is recognized until the performance goals are probable of being met, at which time the cumulative compensation expense from the service inception date would be recognized. For awards that contain market conditions, compensation expense is measured using a Monte Carlo simulation model and recognized over the derived service period based on the expected market performance as of the grant date.

[0001564590-19-033615:notes:42]
Advertising

[0001564590-19-033615:notes:43]
Advertising costs are expensed as incurred. Advertising expenses were $0.3 million, $0.5 million and $0.4 million in fiscal years 2019, 2018 and 2017 respectively.

[0001564590-19-033615:notes:44]
Income Taxes

[0001564590-19-033615:notes:45]
The Company accounts for income taxes utilizing the liability method. Deferred income taxes are recorded to reflect consequences on future years of differences between financial reporting and the tax basis of assets and liabilities measured using the enacted statutory tax rates and tax laws applicable to the periods in which differences are expected to affect taxable earnings. A valuation allowance is recognized to the extent that it is more likely than not that the tax benefits will not be realized.

[0001564590-19-033615:notes:46]
The Company accounts for uncertainty in income taxes using a two-step approach to recognize and measure uncertain tax positions.  The first step is to evaluate the tax position by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.  For additional discussion, see Note 15. Income Taxes.

[0001564590-19-033615:notes:47]
Recently Issued Accounting Pronouncements

[0001564590-19-033615:notes:48]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors, and key disclosure information about leasing arrangements. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset (“ROU”) and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 also required lessors to classify leases as a sales-type, direct financing or operating lease.  A lease is a sales-type lease if any one of five criteria are met, each of which indicate that the lease, in effect, transfers control of the underlying asset to the lessee. If none of those five criteria are met, but two additional criteria are both met, indicating that the lessor has transferred substantially all of the risks and benefits to the lessee and a third party, the lease is a direct financing lease.  All leases that are not sales-type or direct financing leases are operating leases. The Company believes that substantially all of its leases continue to be classified as operating leases. In addition, Topic 842 was subsequently amended by ASU No 2018-10, Codification Improvements; ASU 2018-11, Targeted Improvements; ASU 2018-20 Narrow Scope Improvements; and ASU 2019-01 Codification Improvements.

[0001564590-19-033615:notes:49]
This guidance will become effective for the Company and the Company will adopt the new standards beginning with its fiscal year 2020, beginning on July 1, 2019. Topic 842 is applied on the modified retrospective method, applying the new standard to all leases existing as of July 1, 2019. We expect to adopt the new standard using the effective date as our date of initial application. Consequently, financial information will not be updated, and disclosures required under the new standard will not be provided for dates and periods before July 1, 2019.

[0001564590-19-033615:notes:50]
The new standard provides a number of optional practical expedients in transition. The Company expects to elect the “package of practical expedients” which permits the Company not to reassess under the new standard our prior conclusions about lease identification, lease classification, and initial direct costs. The new standard also provides practical expedients for ongoing accounting. The Company also currently expects to elect the short-term lease recognition exemption for all leases that qualify. This means, for those leases that qualify, the Company will not recognize right-of-use assets or lease liabilities, and this includes not recognizing ROU assets or lease liabilities for existing short-term leases of those assets in transition. In addition, the Company currently does not expect to elect the practical expedient to separate lease and non-lease components for leases. The Company expects that these new standards will have a material impact to the Company’s financial position.

[0001564590-19-033615:notes:51]
The Company expects to recognize ROU assets and lease liabilities on the consolidated balance sheets with corresponding ROU assets of approximately $68 to $78 million and lease liabilities of approximately $82 to $92 million based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases. The Company does not expect that the adoption of Topic 842 will have a material effect on operating income (loss) and net cash flows, however it will impact the classification between cash flows from operations and cash flows from financing activities.

[0001564590-19-033615:notes:52]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The Company does not believe it will have a material impact on the Company’s financial statements upon adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019. In addition, Topic 815 was subsequently amended by ASU 2019-04, Codification Improvements.

[0001564590-19-033615:notes:53]
In February 2018, the FASB issued ASU 2018-02, Income Statement - Reporting Comprehensive Income (Topic 220), this standard that allows the reclassification from AOCI to retained earnings for stranded tax effects resulting from the 2017 Tax Cuts and Jobs Act ("Tax Reform Act"). The amount of the reclassification is the effect of the change in the U.S. federal corporate income tax rate on the gross deferred tax amounts and related valuation allowances related to items remaining in AOCI. This standard is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  Early adoption is permitted, including adoption in any interim period, for reporting periods for which financial statements have not yet been issued.  The new standard is to be applied either in the period of adoption or retrospectively to each period (or periods) in which the effects of the change in the income tax rate in the Tax Reform Act are recognized. The Company does not believe it will have a material impact on the Company’s financial statements upon adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

[0001564590-19-033615:notes:54]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820), which removes, modifies and adds various disclosure requirements around the topic in order to clarify and improve the cost-benefit nature of disclosures. For example, disclosures around transfers between fair value hierarchy levels will be removed and further detail around changes in unrealized gains and losses for the period and unobservable inputs determining Level 3 fair value measurements will be added. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-19-033615:notes:55]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40), which aligns the requirements for capitalizing implementation costs incurred in a service contract hosting arrangement with those of developing or obtaining internal-use software. This standard is effective for interim and annual reporting periods beginning after December 15, 2019, and early adoption is permitted. The Company is currently evaluating the impact the new standard will have on its consolidated financial statements. This guidance is effective for the Company beginning with its fiscal year 2021, beginning on July 1, 2020.

[0001564590-19-033615:notes:56]
Recently Adopted Accounting Pronouncements

[0001564590-19-033615:notes:57]
In January 2016, the FASB issued ASU No. 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities, which provides guidance for the recognition, measurement, presentation, and disclosure of financial assets and liabilities. The guidance was adopted effective July 1, 2018 and the Company reclassified a $0.5 million unrealized gain, net of tax, related to its available-for-sale investments from accumulated other comprehensive loss to accumulated deficit as a cumulative-effect adjustment in the accompanying consolidated balance sheets.  Future changes in fair value will be included in earnings in each period.

[0001564590-19-033615:notes:58]
In August 2016, the FASB issued ASU 2016-15, Classification of Certain Cash Receipts and Cash Payments to provide guidance on the classification of eight cash flow issues in order to reduce diversity in practice.  The Company adopted the new guidance effective July 1, 2018. The amendments in this update have been applied on a retrospective transition method to each period presented. The adoption of this guidance did not have a material effect on the Company’s presentation of cash flows.

[0001564590-19-033615:notes:59]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740) - Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset other than inventory when the transfer occurs. Historically GAAP had prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset has been sold outside the consolidated group.  The new guidance is effective for interim and annual reporting periods beginning after December 15, 2017. The Company adopted ASU 2016-16 effective July 1, 2018 on a modified retrospective basis. The adoption of this guidance did not have a material effect on the Company’s financial statements.

[0001564590-19-033615:notes:60]
In May 2017, the FASB issued ASU 2017-09, Compensation—Stock Compensation (Topic 718): Scope of Modification Accounting, which amends the scope of modification accounting for share-based payment arrangements and provides guidance on the types of changes to the terms or conditions of share-based payment awards to which an entity would be required to apply modification accounting under Topic 718.  Specifically, an entity would not apply modification accounting if the fair value, vesting conditions, and classification of the awards are the same immediately before and after the modification. The Company adopted this guidance effective July 1, 2018, on a prospective basis.  The adoption of this guidance did not have a material effect on the Company’s financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001564590-19-033615:notes:61]
The Company accounts for revenue in accordance with ASU 2014-09 Revenue from Contracts with Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-19-033615:notes:62]
The Company considers customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, the Company considers the promise to transfer products and services, each of which are distinct, to be the identified performance obligations.  In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled.

[0001564590-19-033615:notes:63]
For all of the Company’s sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when the Company’s performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as the Company’s performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to value-added resellers of the Company, non-stocking distributors and end-user customers, the Company generally does not grant return privileges, except for defective products during the warranty period, nor does the Company grant pricing credits.  Sales taxes collected from customers are excluded from revenues.  Shipping costs are included in cost of product revenues. Sales incentives and other programs that the Company may make available to these customers are considered to be a form of variable consideration and the Company maintains estimated accruals and allowances using the expected value method. There were no material changes in the current period to the estimated transaction price for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-19-033615:notes:64]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of the Company’s products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are estimated using the expected value method based on historical return rates.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for the Company’s pre-approval prior to selling the product to a customer at the discounted price.  At the time the distributor invoices its customer or soon thereafter, the distributor submits a rebate claim to the Company to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After the Company verifies that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, the Company considers these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends. There were no material changes in the current period to the estimated variable consideration for performance obligations which were satisfied or partially satisfied during previous periods.

[0001564590-19-033615:notes:65]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of the Company’s contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, the Company allocates the contract’s transaction price to each performance obligation based on its relative standalone selling price. The stand-alone selling prices are determined based on the prices at which the Company separately sells these products.  For items that are not sold separately, the Company estimates the stand-alone selling prices using the best estimated selling price approach.

[0001564590-19-033615:notes:66]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product revenues as reflected on the consolidated statements of operations for the years ended 2019, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

[0001564590-19-033615:notes:67]
At June 30, 2019, the Company had $203.2 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 71 percent of its remaining performance obligations as revenue in fiscal 2020, an additional 16 percent by fiscal 2021 and 13 percent of the balance thereafter.

[0001564590-19-033615:notes:68]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under renewable support arrangements of the Company are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually) with the corresponding revenue recognized over time throughout the contractual service period. The Company sometimes receives payments from its customers in advance of other services being provided, resulting in deferred revenues until the underlying performance obligations are satisfied. These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period. See Note 4 for contract balance information for accounts receivable and deferred revenue.

[0001564590-19-033615:notes:69]
Revenue recognized for the years ended June 30, 2019 and 2018, that was included in the deferred revenue balance at the beginning of each period was $126.7 million and $76.6 million, respectively.

[0001564590-19-033615:notes:70]
Contract Costs.  The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals, in excess of one year, are recoverable and therefore the Company capitalized them as contract costs in the amount of $6.5 million and $4.3 million at June 30, 2019 and 2018, respectively, in “Other assets” in the accompanying consolidated balance sheets.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying consolidated statements of operations.  Amortization recognized during the years ended 2019, 2018 and 2017 was $3.0 million, $2.1 million and $1.5 million, respectively.

[0001564590-19-033615:notes:71]
Revenue by Category: The following tables set forth the Company’s revenue disaggregated by sales channel and geographic region based on the billing addresses of its customers (in thousands):

[0001564590-19-033615:notes:72]
|  |  | Year Ended June 30, 2019 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 259,873 |  |  | $ | 238,832 |  |  | $ | 498,705 |  |
| Other |  |  | 22,264 |  |  |  | 20,632 |  |  |  | 42,896 |  |
| Total Americas |  |  | 282,137 |  |  |  | 259,464 |  |  |  | 541,601 |  |
| EMEA: |  |  | 229,223 |  |  |  | 129,104 |  |  |  | 358,327 |  |
| APAC: |  |  | 14,598 |  |  |  | 81,263 |  |  |  | 95,861 |  |
| Total net revenues |  | $ | 525,958 |  |  | $ | 469,831 |  |  | $ | 995,789 |  |

[0001564590-19-033615:notes:73]
|  |  | Year Ended June 30, 2018 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 271,975 |  |  | $ | 219,642 |  |  | $ | 491,617 |  |
| Other |  |  | 19,414 |  |  |  | 25,274 |  |  |  | 44,688 |  |
| Total Americas |  |  | 291,389 |  |  |  | 244,916 |  |  |  | 536,305 |  |
| EMEA: |  |  | 218,682 |  |  |  | 136,064 |  |  |  | 354,746 |  |
| APAC: |  |  | 15,621 |  |  |  | 76,470 |  |  |  | 92,091 |  |
| Total net revenues |  | $ | 525,692 |  |  | $ | 457,450 |  |  | $ | 983,142 |  |

[0001564590-19-033615:notes:74]
|  |  | Year Ended June 30, 2017 |  |
| Net Revenues |  | Distributor |  |  | Direct |  |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 146,805 |  |  | $ | 161,175 |  |  | $ | 307,980 |  |
| Other |  |  | 11,861 |  |  |  | 13,022 |  |  |  | 24,883 |  |
| Total Americas |  |  | 158,666 |  |  |  | 174,197 |  |  |  | 332,863 |  |
| EMEA: |  |  | 135,414 |  |  |  | 84,658 |  |  |  | 220,072 |  |
| APAC: |  |  | 8,953 |  |  |  | 45,196 |  |  |  | 54,149 |  |
| Total net revenues |  | $ | 303,033 |  |  | $ | 304,051 |  |  | $ | 607,084 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-033615:notes:75]
3. Revenues

[0001564590-19-033615:notes:76]
Concentrations

[0001564590-19-033615:notes:77]
The Company may be subject to concentration of credit risk as a result of certain financial instruments consisting of accounts receivable and short-term investments. The Company performs ongoing credit evaluations of its customers and generally does not require collateral in exchange for credit.

[0001564590-19-033615:notes:78]
The following table sets forth major customers accounting for 10% or more of the Company’s net revenue:

[0001564590-19-033615:notes:79]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Tech Data Corporation |  | 18% |  |  | 14% |  |  | 16% |  |
| Jenne Corporation |  | 17% |  |  | 13% |  |  | 15% |  |
| Westcon Group Inc. |  | 12% |  |  | 13% |  |  | 12% |  |

[0001564590-19-033615:notes:80]
The following table sets forth major customers accounting for 10% or more of the Company’s accounts receivable balance:

[0001564590-19-033615:notes:81]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Tech Data Corporation |  |  | 12 | % |  |  | 17 | % |
| Jenne Corporation |  |  | 35 | % |  |  | 13 | % |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001564590-19-033615:notes:82]
4. Balance Sheet Components

[0001564590-19-033615:notes:83]
The following is a summary of cash and marketable securities (in thousands):

[0001564590-19-033615:notes:84]
|  |  | June 30, 2019 |  | June 30, 2018 |
| Cash |  | $169,607 |  | $121,139 |
| Marketable securities (consisting of available-for-sale securities) |  | — |  | 1,459 |
| Total cash and marketable securities |  | $169,607 |  | $122,598 |

[0001564590-19-033615:notes:85]
Marketable securities are recorded in “Prepaid expenses and other current assets” in the accompanying consolidated balance sheets.

[0001564590-19-033615:notes:86]
Accounts Receivable

[0001564590-19-033615:notes:87]
The following is a summary of Accounts receivable (in thousands):

[0001564590-19-033615:notes:88]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Accounts receivable |  | $ | 201,365 |  |  | $ | 225,167 |  |
| Allowance for doubtful accounts |  |  | (1,054 | ) |  |  | (1,478 | ) |
| Allowance for product returns |  |  | (25,897 | ) |  |  | (11,266 | ) |
| Accounts receivable, net |  | $ | 174,414 |  |  | $ | 212,423 |  |

[0001564590-19-033615:notes:89]
Accounts receivable, net decreased primarily due to strong collections during fiscal year 2019.

[0001564590-19-033615:notes:90]
The following table is a summary of the allowance for doubtful accounts (in thousands):

[0001564590-19-033615:notes:91]
| Description |  | Balance at beginning of period |  | Charges to bad debt expenses |  | Deductions (1) |  | Balance at end of period |
| Year Ended June 30, 2019: |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $1,478 |  | $1,407 |  | $(1,831) |  | $1,054 |
| Year Ended June 30, 2018: |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $1,190 |  | $1,687 |  | $(1,399) |  | $1,478 |
| Year Ended June 30, 2017: |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $1,648 |  | $323 |  | $(781) |  | $1,190 |

[0001564590-19-033615:notes:92]
|  | (1) | Uncollectible accounts written off, net of recoveries |

[0001564590-19-033615:notes:93]
The following table is a summary of the Company’s allowance for product returns (in thousands):

[0001564590-19-033615:notes:94]
| Description |  | Balance at beginning of period |  | Additions |  | Deductions |  | Balance at end of period |
| Year Ended June 30, 2019: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $11,266 |  | $85,190 |  | $(70,559) |  | $25,897 |
| Year Ended June 30, 2018: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $7,296 |  | $38,103 |  | $(34,133) |  | $11,266 |
| Year Ended June 30, 2017: |  |  |  |  |  |  |  |  |
| Allowance for product returns |  | $3,123 |  | $31,034 |  | $(26,861) |  | $7,296 |

[0001564590-19-033615:notes:95]
The following is a summary of the Company’s inventory by category (in thousands):

[0001564590-19-033615:notes:96]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Finished goods |  | $ | 49,492 |  |  | $ | 49,393 |  |
| Raw materials |  |  | 14,097 |  |  |  | 14,474 |  |
| Total Inventories |  | $ | 63,589 |  |  | $ | 63,867 |  |

[0001564590-19-033615:notes:97]
Property and Equipment, Net

[0001564590-19-033615:notes:98]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Computers and equipment |  | $ | 72,309 |  |  | $ | 60,677 |  |
| Purchased software |  |  | 29,126 |  |  |  | 21,389 |  |
| Office equipment, furniture and fixtures |  |  | 10,815 |  |  |  | 14,980 |  |
| Leasehold improvements |  |  | 51,245 |  |  |  | 50,070 |  |
| Total property and equipment |  |  | 163,495 |  |  |  | 147,116 |  |
| Less: accumulated depreciation and amortization |  |  | (89,941 | ) |  |  | (68,597 | ) |
| Property and equipment, net |  | $ | 73,554 |  |  | $ | 78,519 |  |

[0001564590-19-033615:notes:99]
The Company recognized depreciation expense of $26.9 million, $23.5 million, and $10.6 million related to property and equipment during the years ended 2019, 2018 and 2017, respectively.

[0001564590-19-033615:notes:100]
The following table summarizes contract liabilities which are shown as deferred revenue (in thousands):

[0001564590-19-033615:notes:101]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Deferred maintenance |  | $ | 192,955 |  |  | $ | 164,986 |  |
| Other deferred revenue |  |  | 10,287 |  |  |  | 9,539 |  |
| Total deferred revenue, net |  |  | 203,242 |  |  |  | 174,525 |  |
| Less: current portion |  |  | 144,230 |  |  |  | 130,865 |  |
| Non-current deferred revenue, net |  | $ | 59,012 |  |  | $ | 43,660 |  |

[0001564590-19-033615:notes:102]
Total deferred revenue increased primarily due to the extended duration period of new maintenance contracts during fiscal year 2019.

[0001564590-19-033615:notes:103]
Accrued Warranty

[0001564590-19-033615:notes:104]
The following table summarizes the activity related to the Company’s product warranty liability during the following periods (in thousands):

[0001564590-19-033615:notes:105]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Balance beginning of period |  | $ | 12,807 |  |  | $ | 10,584 |  |
| Warranties assumed due to acquisitions |  |  | — |  |  |  | 3,682 |  |
| New warranties issued |  |  | 22,919 |  |  |  | 10,491 |  |
| Warranty expenditures |  |  | (20,947 | ) |  |  | (11,950 | ) |
| Balance end of period |  | $ | 14,779 |  |  | $ | 12,807 |  |

[0001564590-19-033615:notes:106]
Other Long-term Liabilities

[0001564590-19-033615:notes:107]
The following is a summary of long-term liabilities (in thousands):

[0001564590-19-033615:notes:108]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Acquisition related deferred payments, less current portion |  | $ | 9,604 |  |  | $ | 13,251 |  |
| Contingent consideration obligations, less current portion |  |  | 2,688 |  |  |  | 4,898 |  |
| Other contractual obligations, less current portion |  |  | 26,261 |  |  |  | 31,200 |  |
| Other |  |  | 15,597 |  |  |  | 9,751 |  |
| Total other long-term liabilities |  | $ | 54,150 |  |  | $ | 59,100 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001564590-19-033615:notes:109]
5. Fair Value Measurements

[0001564590-19-033615:notes:110]
A three-tier fair value hierarchy is utilized to prioritize the inputs used in measuring fair value. The hierarchy gives the highest priority to quoted prices in active markets (Level 1) and the lowest priority to unobservable inputs (Level 3). The three levels are defined as follows:

[0001564590-19-033615:notes:111]
|  | • | Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities; |

[0001564590-19-033615:notes:112]
|  | • | Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0001564590-19-033615:notes:113]
|  | • | Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value. |

[0001564590-19-033615:notes:114]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis (in thousands):

[0001564590-19-033615:notes:115]
| June 30, 2019 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 6,298 |  |  | $ | 6,298 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 6,298 |  |  | $ | 6,298 |  |

[0001564590-19-033615:notes:116]
| June 30, 2018 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable securities |  | $ | 1,459 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,459 |  |
| Total assets measured at fair value |  | $ | 1,459 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,459 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration obligations |  | $ | — |  |  | $ | — |  |  | $ | 12,749 |  |  | $ | 12,749 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | — |  |  | $ | 12,749 |  |  | $ | 12,749 |  |

[0001564590-19-033615:notes:117]
Level 1 investments:

[0001564590-19-033615:notes:118]
The Company holds an investment in marketable equity securities at Level 1 as the investment has readily determinable fair value (see below, Level 3 investments). An unrealized holding gain on the investment of $0.5 million as of June 30, 2018 was reclassified from accumulated other comprehensive loss to accumulated deficit on July 1, 2018 upon an adoption of ASU 2016-01 (see Note 2).

[0001564590-19-033615:notes:119]
During fiscal 2015, the Company purchased a $3.0 million equity interest in a company that operated in the enterprise software platform industry.  In September 2017, the investee was acquired by a third party.  The Company received $6.8 million in consideration for its equity interest in the investee, including $5.4 million in cash and 65,937 shares of the third party’s publicly-traded common stock (the “Acquirer’s common stock”) with a market value of $1.4 million. During fiscal 2018, the Company received $5.8 million of the consideration, consisting of $4.9 million in cash and 41,685 shares with a market value of $0.9 million. A gain of $3.8 million related to the 2018 sale was recorded in Other expense for the year ended June 30, 2018.  During the fourth quarter of fiscal 2019, the shares were released from escrow and the Company sold the remaining shares of the Acquirer’s common stock and recorded a loss of $0.1 million.

[0001564590-19-033615:notes:120]
Level 2 investments:

[0001564590-19-033615:notes:121]
The Company includes U.S. government and sovereign obligations, most government agency securities, investment-grade corporate bonds, and state, municipal and provincial obligations for which quoted prices are available as Level 2. There were no transfers of assets or liabilities between Level 1 and Level 2 for the periods presented.

[0001564590-19-033615:notes:122]
The fair value of the borrowings under the Credit Agreement is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2.  Due to the short duration until maturity of the Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $180.5 million and $200.0 million as of June 30, 2019 and 2018, respectively.  Such differences are immaterial for all periods presented.

[0001564590-19-033615:notes:123]
Level 3 investments:

[0001564590-19-033615:notes:124]
Certain of the Company’s assets, including intangible assets and goodwill are measured at fair value on a non-recurring basis if impairment is indicated.

[0001564590-19-033615:notes:125]
During the year ended June 30, 2018, the Company recorded a liability for contingent consideration related to its acquisition of the CF Business. The fair value measurement of the contingent consideration obligations is determined using Level 3 inputs. The fair value of contingent consideration obligations is based on a discounted cash flow model.  These fair value measurements represent Level 3 measurements as they are based on significant inputs not observable in the market. Significant judgment is employed in determining the appropriateness of these assumptions as of the acquisition date and for each subsequent period.  Accordingly, changes in assumptions could have a material impact on the amount of contingent consideration expense the Company records in any given period.  Changes in the value of the contingent consideration obligations would be recorded in general and administrative expenses in the accompanying consolidated statements of operations.

[0001564590-19-033615:notes:126]
The change in the acquisition-related contingent consideration obligations is as follows (in thousands):

[0001564590-19-033615:notes:127]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |
| Beginning balance |  | $ | 12,749 |  |
| Payments |  |  | (6,506 | ) |
| Accretion on discount |  |  | 244 |  |
| Adjustments |  |  | (189 | ) |
| Ending balance |  | $ | 6,298 |  |

[0001564590-19-033615:notes:128]
There were no transfers of assets or liabilities between Level 2 and Level 3 during the year ended June 30, 2019 or 2018. There were no impairments recorded for the year ended June 30, 2019 or 2018.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-19-033615:notes:129]
6. Goodwill and Intangible Assets

[0001564590-19-033615:notes:130]
The following table reflects the changes in the carrying amount of goodwill (in thousands):

[0001564590-19-033615:notes:131]
|  |  | June 30, 2019 |  |
| Balance as of June 30, 2018 |  | $ | 139,082 |  |
| Changes due to additional property and equipment acquired (See Note 11) |  |  | (505 | ) |
| Balance at end of period |  | $ | 138,577 |  |

[0001564590-19-033615:notes:132]
The following tables summarize the components of gross and net intangible asset balances (in thousands, except years):

[0001564590-19-033615:notes:133]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 2.4 years |  | $ | 117,000 |  |  | $ | 77,449 |  |  | $ | 39,551 |  |
| Customer relationships |  | 2.0 years |  |  | 51,639 |  |  |  | 44,410 |  |  |  | 7,229 |  |
| Maintenance contracts |  | — years |  |  | 17,000 |  |  |  | 17,000 |  |  |  | — |  |
| Trade names |  | 2.4 years |  |  | 9,100 |  |  |  | 5,647 |  |  |  | 3,453 |  |
| License agreements |  | 5.4 years |  |  | 2,445 |  |  |  | 1,661 |  |  |  | 784 |  |
| Other intangibles |  | 0.6 years |  |  | 1,382 |  |  |  | 1,287 |  |  |  | 95 |  |
| Total intangibles, net |  |  |  | $ | 198,566 |  |  | $ | 147,454 |  |  | $ | 51,112 |  |

[0001564590-19-033615:notes:134]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 117,000 |  |  | $ | 58,299 |  |  | $ | 58,701 |  |
| Customer relationships |  | 3.0 years |  |  | 51,639 |  |  |  | 40,634 |  |  |  | 11,005 |  |
| Maintenance contracts |  | 0.3 years |  |  | 17,000 |  |  |  | 15,866 |  |  |  | 1,134 |  |
| Trade names |  | 3.4 years |  |  | 9,100 |  |  |  | 4,141 |  |  |  | 4,959 |  |
| Backlogs |  | — years |  |  | 1,800 |  |  |  | 1,800 |  |  |  | — |  |
| License agreements |  | 5.8 years |  |  | 2,445 |  |  |  | 1,390 |  |  |  | 1,055 |  |
| Other intangibles |  | 1.6 years |  |  | 1,382 |  |  |  | 1,144 |  |  |  | 238 |  |
| Total intangibles, net |  |  |  | $ | 200,366 |  |  | $ | 123,274 |  |  | $ | 77,092 |  |

[0001564590-19-033615:notes:135]
The following table summarizes the amortization expense of intangibles for the periods presented (in thousands):

[0001564590-19-033615:notes:136]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Amortization in “Cost of revenues: Product” |  | $ | 19,638 |  |  | $ | 16,870 |  |  | $ | 7,020 |  |
| Amortization of intangibles in "Operations" |  |  | 6,346 |  |  |  | 8,715 |  |  |  | 8,702 |  |
| Total amortization |  | $ | 25,984 |  |  | $ | 25,585 |  |  | $ | 15,722 |  |

[0001564590-19-033615:notes:137]
The amortization expense that is recognized in “Cost of revenues: Product” is comprised of amortization for developed technology, license agreements and other intangibles.

[0001564590-19-033615:notes:138]
The estimated future amortization expense to be recorded for each of the respective future fiscal years is as follows (in thousands):

[0001564590-19-033615:notes:139]
| For the fiscal year ending: |  |  |  |  |
| 2020 |  | $ | 22,898 |  |
| 2021 |  |  | 20,819 |  |
| 2022 |  |  | 6,271 |  |
| 2023 |  |  | 875 |  |
| 2024 |  |  | 71 |  |
| Thereafter, |  |  | 178 |  |
| Total |  | $ | 51,112 |  |


## us-gaap:DebtDisclosureTextBlock

[0001564590-19-033615:notes:140]
7. Debt

[0001564590-19-033615:notes:141]
Debt

[0001564590-19-033615:notes:142]
The Company’s debt is comprised of the following (in thousands):

[0001564590-19-033615:notes:143]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (489 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,011 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 171,000 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,261 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 169,739 |  |  |  | 188,749 |  |
| Total debt |  | $ | 178,750 |  |  | $ | 197,756 |  |

[0001564590-19-033615:notes:144]
On May 1, 2018, the Company entered into a Credit Agreement (the “2018 Credit Agreement”), by and among the Company, as borrower, BMO Harris Bank N.A., as an issuing lender and swingline lender, Bank of Montreal, as administrative and collateral agent, and the financial institutions or entities that are a party thereto as lenders.  The 2018 Credit Agreement provides for i) a $40 million five-year revolving credit facility (the “2018 Revolving Facility”), ii) a $190 million five-year term loan (the “2018 Term Loan”) and, iii) an uncommitted additional incremental loan facility in the principal amount of up to $100 million (“2018 Incremental Facility”).  On May 1, 2018, the Company borrowed $200 million under the 2018 Credit Agreement in order to pay off existing debt and for general corporate purposes.

[0001564590-19-033615:notes:145]
Borrowings under the 2018 Credit Agreement bear interest, at the Company’s election, as of May 1, 2018, at a rate per annum equal to LIBOR plus 1.50% to 2.75%, or the adjusted base rate plus 0.50% to 1.75%, based on the Company’s Consolidated Leverage Ratio.  In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.35%) on the unused portion of the 2018 Revolving Facility, also based on the Company’s consolidated leverage ratio.  Principal installments are payable on the 2018 Term Loan in varying percentages quarterly starting September 30, 2018 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2018 Credit Agreement is secured by substantially all of the Company’s assets.

[0001564590-19-033615:notes:146]
The 2018 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2018 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2018 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.  At June 30, 2019, we were in compliance with the covenants of the 2018 Credit Agreement.

[0001564590-19-033615:notes:147]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement.  During the year ended June 30, 2018, in conjunction with the 2018 Credit Agreement, as noted above, the Company recorded a loss from an extinguishment of debt of $1.2 million in “Interest expense” in the accompanying consolidated statements of operations and incurred $1.5 million of deferred financing costs.

[0001564590-19-033615:notes:148]
Amortization of deferred financing costs is included in “Interest expense” in the accompanying consolidated statements of operations, totaled $0.6 million, $0.7 million and $0.5 million in fiscal years 2019, 2018 and 2017, respectively.

[0001564590-19-033615:notes:149]
The Company had $35.5 million of availability under the 2018 Revolving Facility as of June 30, 2019.  The Company had $4.5 million of outstanding letters of credit as of June 30, 2019.

[0001564590-19-033615:notes:150]
The Company’s debt principal repayment schedule by period is as follows, excluding unamortized debt issuance costs (in thousands):

[0001564590-19-033615:notes:151]
| For the fiscal year ending: |  |  |  |  |
| 2020 |  | $ | 9,500 |  |
| 2021 |  |  | 14,250 |  |
| 2022 |  |  | 14,250 |  |
| 2023 |  |  | 142,500 |  |
| Total |  | $ | 180,500 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-033615:notes:152]
8. Commitments and Contingencies

[0001564590-19-033615:notes:153]
Leases

[0001564590-19-033615:notes:154]
The Company currently leases its current headquarters, research and development facilities and office spaces for its various United States and international operations. Certain leases contain rent escalation clauses and renewal options. As part of the Company’s existing leased facilities, the Company occasionally receives lease incentives payments from the landlord which are used to make leasehold improvements on the respective facility. The Company depreciates the leasehold improvements over the useful life of the assets or the lease term, whichever is shorter.  The lease incentives payments are deferred and amortized on a straight-line basis over the term of the lease as an offset to rent expense.

[0001564590-19-033615:notes:155]
Future annual minimum lease payments under all non-cancelable operating leases having initial or remaining lease terms in excess of one year at June 30, 2019, were as follows (in thousands):

[0001564590-19-033615:notes:156]
| For the fiscal year ending: |  | Future Lease Payments |  |
| 2020 |  | $ | 22,733 |  |
| 2021 |  |  | 21,174 |  |
| 2022 |  |  | 20,680 |  |
| 2023 |  |  | 17,828 |  |
| 2024 |  |  | 5,976 |  |
| Thereafter |  |  | 16,287 |  |
| Total minimum payments |  | $ | 104,678 |  |

[0001564590-19-033615:notes:157]
Rent expense was $13.3 million, $12.9 million and $9.4 million in fiscal years ended 2019, 2018 and 2017, respectively.

[0001564590-19-033615:notes:158]
Purchase Commitments

[0001564590-19-033615:notes:159]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. The arrangements allow them to procure long lead-time component inventory based upon a rolling production forecast provided by the Company.  The Company is obligated to the purchase of long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of June 30, 2019, the Company had non-cancelable commitments to purchase $51.2 million of such inventory, which will be received and consumed during the first half of fiscal 2020. The Company expects to utilize its non-cancelable purchase commitments in the normal ongoing operations.

[0001564590-19-033615:notes:160]
Legal Proceedings

[0001564590-19-033615:notes:161]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property and securities litigation in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0001564590-19-033615:notes:162]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred and the amount of loss can be reasonably estimated.  The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable.  When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual.  However, if the loss (or an additional loss in excess of any prior accrual) is at least a reasonable possibility and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made.  The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events.  Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  Accordingly, for current proceedings, except as noted below, the Company is currently unable to estimate any reasonably possible loss or range of possible loss.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0001564590-19-033615:notes:163]
Brazilian Tax Assessment Matters

[0001564590-19-033615:notes:164]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.9 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of June 30, 2019.

[0001564590-19-033615:notes:165]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017, decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 20.0 million (USD $5.2 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of June 30, 2019.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

[0001564590-19-033615:notes:166]
Based on the currently available information, the Company believes the ultimate outcome of the ICMS Tax Assessment litigation will not have a material adverse effect on the Company's financial position or overall results of operations. However, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserted, there can be no assurance of a favorable outcome for Enterasys Brasil, which recorded an accrual of BRL 9.4 million (USD $2.5 million) as of the date the Company acquired Enterasys Networks.

[0001564590-19-033615:notes:167]
The Company made a demand on April 11, 2014, for a defense from, and indemnification by, the former equity holder of Enterasys Networks, Inc. (“Seller”) in connection with the ICMS Tax Assessment. Seller agreed to assume the defense of the ICMS Tax Assessment on May 20, 2014. In addition, through the settlement of an indemnification-related lawsuit with the Seller on June 18, 2015, Seller agreed to continue to defend the Company with respect to the ICMS Tax Assessment and to indemnify the Company for losses related thereto subject to certain conditions. These conditions include the offsetting of foreign income tax benefits realized by the Company in connection with the acquisition of Enterasys.  Based upon current projections of the foreign income tax benefits to be realized, and the potential liability in the event of an adverse final judgment in the ICMS Tax Assessment litigation, the Company does not presently anticipate that any amounts under the indemnification will be due from the Seller in connection with the ICMS Tax Assessment.

[0001564590-19-033615:notes:168]
In re Extreme Networks, Inc. Securities Litigation

[0001564590-19-033615:notes:169]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013, through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018, Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties agreed to settle the litigation.   On November 30, 2018, plaintiffs filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition. The preliminary hearing took place on March 7, 2019, and the court approved the settlement amount at the final hearing which took place on June 20, 2019.

[0001564590-19-033615:notes:170]
XR Communications, LLC d/b/a Vivato Technologies, LLC v. Extreme Networks, Inc.

[0001564590-19-033615:notes:171]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date).  During a status conference on February 11, 2019, the Court continued the stay and set a status conference for December 2, 2019.  The Company believes the claims are without merit and intends to defend them vigorously.

[0001564590-19-033615:notes:172]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0001564590-19-033615:notes:173]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges direct and indirect infringement of the German portion of European Patent EP 1 958 364 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches equipped with the ExtremeXOS operating system.  Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit.  On May 3, 2018, Extreme Networks GmbH filed a separate nullity action in the Federal Patent Court in Munich, seeking to invalidate the asserted patents, and on May 4, 2018, the defendants answered the infringement complaint, denying any infringement and seeking a stay of the action pending the conclusion of the nullity action.  The District Court Düsseldorf scheduled a hearing in this case for January 28, 2020.

[0001564590-19-033615:notes:174]
On April 23, 2019, Orckit filed and extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of European Patent EP 3 068 077 B1 based on the offer, distribution, use, possession and/or importation into Germany of certain network switches.  Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit.  No hearing has been scheduled yet in this case, which was split from the original action involving the first patent in suit.

[0001564590-19-033615:notes:175]
The Company believes that all claims are without merit and defends them vigorously.

[0001564590-19-033615:notes:176]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co.

[0001564590-19-033615:notes:177]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six patent infringement lawsuits against the Company and its Chinese and Hong Kong subsidiaries and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1, ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2, and ZL200610060686.9.  Each patent was asserted in a separate law suit.  The filing date for the first case is January 18, 2019, and the filing date for the rest of the cases is January 23, 2019.  The trial for the first case is currently scheduled for January 15, 2020, and trials for the rest of the cases have not yet been scheduled.  The products at issue include the Summit X440-G2 series, X450-G2 series, X460-G2 series, X620 series, X670-G2 series, X770 series, X870 series, X690 series, and X590 series.  GIA is a U.S. entity established under the laws of Delaware with its principal office in Pasadena, California.  Extreme disputes GIA’s claims and intends to defend the matter vigorously.  Additionally, Extreme has filed invalidity challenges with the Chinese patent office to challenge the validity of each asserted patent.  Oral invalidity hearings were held in July and August 2019.  Given the uncertainty of litigation and the preliminary stage of the case, Extreme cannot estimate at this time the possible loss or range of loss that may result from this action.

[0001564590-19-033615:notes:178]
Indemnification Obligations

[0001564590-19-033615:notes:179]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of June 30, 2019, the Company has the outstanding indemnification claims described above.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-19-033615:notes:180]
9. Stockholders’ Equity

[0001564590-19-033615:notes:181]
Preferred Stock

[0001564590-19-033615:notes:182]
In April 2001, in connection with the entering into of the Company’s Rights Agreement, the Company authorized the issuance of preferred stock. The preferred stock may be issued from time to time in one or more series. The Board of Directors is authorized to provide for the rights, preferences and privileges of the shares of each series and any qualifications, limitations or restrictions on these shares. As of June 30, 2019, no shares of preferred stock were outstanding.

[0001564590-19-033615:notes:183]
Stockholders’ Rights Agreement

[0001564590-19-033615:notes:184]
On April 26, 2012, the Company entered into an Amended and Restated Rights Agreement between the Company and Computershare Shareholder Services LLC as the rights agent (the “Restated Rights Plan”). The Restated Rights Plan governs the terms of each right (“Right”) that has been issued with respect to each share of Common Stock of Extreme Networks. Each Right initially represents the right to purchase one one-thousandth of a share of the Company’s Preferred Stock. The Restated Rights Plan replaces in its entirety the Rights Agreement, dated as of April 27, 2001, as subsequently amended, between the Company and Mellon Investor Services LLC (the “Prior Rights Plan”).

[0001564590-19-033615:notes:185]
The Board adopted the Restated Rights Plan to preserve the value of deferred tax assets, including net operating loss carry forwards of the Company, with respect to its ability to fully use its tax benefits to offset future income which may be limited if the Company experiences an “ownership change” for purposes of Section 382 of the Internal Revenue Code of 1986 as a result of ordinary buying and selling of its common stock. Following its review of the terms of the plan, the Board decided it was necessary and in the best interests of the Company and its stockholders to enter into the Restated Rights Plan. The Restated Rights Plan incorporates the Prior Rights Plan and the amendments thereto into a single agreement and extended the term of the Prior Rights Plan to April 30, 2013.  Each year since 2013 the Board and shareholders have approved an amendment providing for a one-year extension of the term of the Restated Rights Plan.  Our Board of Directors unanimously approved an amendment to the Restated Plan on May 9, 2019 to extend the Restated Rights Plan through May 31, 2020, subject to ratification by a majority of the stockholders of the Company at the next annual shareholders meeting.

[0001564590-19-033615:notes:186]
Common Stock Repurchases

[0001564590-19-033615:notes:187]
On November 2, 2018, the Company announced that the Board had authorized management to repurchase up to $60.0 million of the Company’s common stock for two years from the date of authorization. Purchases may be made from time to time in the open market or in privately negotiated transactions.  A maximum of $35.0 million of the Company’s common stock may be repurchased in any calendar year.

[0001564590-19-033615:notes:188]
The following table summarizes the Company's shares repurchases under its stock repurchase program (in thousands, except per share amounts):

[0001564590-19-033615:notes:189]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |
| Total number of shares repurchased |  |  | 2,366 |  |
| Average price paid per share |  | $ | 6.34 |  |
| Dollar value of shares repurchased |  | $ | 15,000 |  |
| Dollar value of shares that may yet be repurchased under program |  | $ | 45,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-033615:notes:190]
10. Employee Benefit Plans

[0001564590-19-033615:notes:191]
As of June 30, 2019, the Company has the following share-based compensation plans:

[0001564590-19-033615:notes:192]
2013 Equity Incentive Plan

[0001564590-19-033615:notes:193]
The 2013 Equity Incentive Plan (the “2013 Plan”) was approved by stockholders on November 20, 2013. The 2013 Plan replaced the 2005 Equity Incentive Plan (the “2005 Plan”). Under the 2013 Plan, the Company may grant stock options, stock appreciation rights, restricted stock, restricted stock units, performance shares, performance units, and other share-based or cash-based awards to employees and consultants. The 2013 Plan also authorizes the grant of awards of stock options, stock appreciation rights, restricted stock and restricted stock units to non-employee members of the Board of Directors and deferred compensation awards to officers, directors and certain management or highly compensated employees. The 2013 Plan authorized the issuance of 9.0 million shares of the Company’s common stock. In addition, up to 12.7 million shares subject to stock options and awards available for issuance under the 2005 Plan may be transferred to the 2013 Stock Plan and would be added to the number of shares available for future grant under the 2013 Plan.  The 2013 Plan includes provisions upon the granting of certain awards defined by the 2013 Plan as Full Value Awards in which the shares available for grant under the 2013 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2013 Plan for future issuance as was applied upon granting.  During the fiscal years ended June 30, 2018 an additional 9.0 million shares were authorized and made available for grant under the 2013 Plan. As of June 30, 2019, total options and awards to acquire 9.7 million shares were outstanding under the 2013 Plan and 8.5 million shares are available for grant under the 2013 Plan. Options granted under this plan have a contractual term of seven years.

[0001564590-19-033615:notes:194]
Enterasys 2013 Stock Plan

[0001564590-19-033615:notes:195]
Pursuant to the acquisition of Enterasys on October 31, 2013, the Company assumed the Enterasys 2013 Stock Plan (the “Enterasys Plan”).  As of June 30, 2019, total options to acquire 0.7 million shares were outstanding under the Enterasys Plan. Options granted under this plan have a contractual term of seven years. No future grants may be made from the Enterasys Plan.

[0001564590-19-033615:notes:196]
2005 Equity Incentive Plan

[0001564590-19-033615:notes:197]
The 2005 Plan was adopted by the Company’s Board of Directors on October 20, 2005, and approved by stockholders on December 2, 2005. The 2005 Plan replaced the Amended 1996 Stock Option Plan (the “1996 Plan”), the 2000 Non-statutory Stock Option Plan and the 2001 Non-statutory Stock Option Plan. The 2005 Plan includes provisions upon the granting of certain awards defined by the 2005 Plan as Full Value Awards in which the shares available for grant under the 2005 Plan are decremented 1.5 shares for each such award granted. Upon forfeiture or cancellation of unvested awards, the same ratio is applied in returning shares to the 2005 Plan for future issuance as was applied upon granting. Effective November 20, 2013, the 2005 Plan was replaced with the 2013 Plan, and, as of June 30, 2019, total options to acquire 0.1 million shares were outstanding under the 2005 Plan.  No future grants may be made from the 2005 Plan, however, outstanding options and awards forfeited or canceled were allowed to be transferred to the 2013 Plan until December 2, 2015, at which time, no further shares may be transferred. A total of 6.6 million shares were transferred to the 2013 Plan.

[0001564590-19-033615:notes:198]
Shares Reserved for Issuance

[0001564590-19-033615:notes:199]
The following are shares reserved for issuance (in thousands):

[0001564590-19-033615:notes:200]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 8,462 |  |  |  | 9,957 |  |
| Employee stock options and awards outstanding |  |  | 10,455 |  |  |  | 12,060 |  |
| 2014 Employee Stock Purchase Plan |  |  | 10,085 |  |  |  | 5,365 |  |
| Total shares reserved for issuance |  |  | 29,002 |  |  |  | 27,382 |  |

[0001564590-19-033615:notes:201]
Stock Options

[0001564590-19-033615:notes:202]
The following table summarizes stock option activity under all plans (shares and intrinsic value in thousands):

[0001564590-19-033615:notes:203]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2018 |  |  | 2,193 |  |  | $ | 3.88 |  |  |  | 2.90 |  |  | $ | 8,996 |  |
| Granted |  |  | 852 |  |  |  | 6.40 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (252 | ) |  |  | 3.84 |  |  |  |  |  |  |  |  |  |
| Cancelled |  |  | (74 | ) |  |  | 6.01 |  |  |  |  |  |  |  |  |  |
| Options outstanding at June 30, 2019 |  |  | 2,719 |  |  | $ | 4.61 |  |  |  | 3.26 |  |  | $ | 5,070 |  |
| Vested and expected to vest at June 30, 2019 |  |  | 2,719 |  |  | $ | 4.61 |  |  |  | 3.26 |  |  | $ | 5,070 |  |
| Exercisable at June 30, 2019 |  |  | 1,939 |  |  | $ | 3.88 |  |  |  | 2.09 |  |  | $ | 5,016 |  |

[0001564590-19-033615:notes:204]
The total intrinsic value of options exercised in fiscal years 2019, 2018 and 2017 was $0.8 million, $6.3 million and $5.7 million, respectively.

[0001564590-19-033615:notes:205]
The weighted average estimated fair value of stock options granted in fiscal year 2019 was $2.62 per share. There were no stock options granted in fiscal 2018 or 2017.  As of June 30, 2019, there was $1.0 million of total unrecognized compensation cost related to unvested stock options that will be fully recognized in fiscal 2020.

[0001564590-19-033615:notes:206]
During the first quarter of fiscal 2019, the Company granted 851,700 Performance Stock Options (“PSOs”) to certain officers and executive vice presidents that will vest if the Company’s stock price achieves a price hurdle of $10.00 during the three-year performance period from August 29, 2018 through August 31, 2021. The price hurdle will be deemed to have been achieved if, at any time over the performance period, the Company’s stock maintains a price of $10.00 for 30 consecutive days.  If the price hurdle is achieved, the PSOs will vest as follows:

[0001564590-19-033615:notes:207]
If the price hurdle is met before or on August 31, 2019, one-third of the PSOs will vest on August 31, 2019 and the remainder will vest quarterly over two years.

[0001564590-19-033615:notes:208]
If the price hurdle is met after August 31, 2019, a number of the PSOs will vest (ratably calculated based upon the time elapsed between August 31, 2018 and the date the hurdle is met) and the remainder will vest quarterly through August 31, 2021.  The grant date fair value was $2.62.

[0001564590-19-033615:notes:209]
Stock Awards

[0001564590-19-033615:notes:210]
Stock awards may be granted under the 2013 Plan on terms approved by the Compensation Committee of the Board of Directors. Stock awards generally provide for the issuance of restricted stock units (“RSUs”), including performance or market-based restricted stock units (“PSUs”) which vest over a fixed period of time or based upon the satisfaction of certain performance criteria. The Company recognizes compensation expense on the awards over the vesting period based on the award’s intrinsic value as of the date of grant.

[0001564590-19-033615:notes:211]
The following table summarizes stock award activity (shares and market value in thousands):

[0001564590-19-033615:notes:212]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Market Value |  |
| Non-vested stock awards outstanding at June 30, 2018 |  |  | 7,764 |  |  | $ | 8.60 |  |  |  |  |  |
| Granted |  |  | 4,698 |  |  |  | 6.39 |  |  |  |  |  |
| Released |  |  | (3,637 | ) |  |  | 7.72 |  |  |  |  |  |
| Cancelled |  |  | (1,089 | ) |  |  | 8.58 |  |  |  |  |  |
| Non-vested stock awards outstanding at June 30, 2019 |  |  | 7,736 |  |  | $ | 7.67 |  |  | $ | 49,700 |  |
| Vested and expected to vest at June 30, 2019 |  |  | 7,406 |  |  | $ | 7.53 |  |  | $ | 47,568 |  |

[0001564590-19-033615:notes:213]
The aggregate fair value, as of the respective vesting dates of RSUs vested during the years ended 2019, 2018 and 2017 was $30.0 million, $51.2 million and $9.1 million, respectively.

[0001564590-19-033615:notes:214]
Fiscal 2019 PSU

[0001564590-19-033615:notes:215]
During fiscal 2019, the Company approved the grant of 0.9 million stock awards to its named executive officers and directors.  Of this amount, 0.2 million of these stock awards were in the form of PSUs and 0.7 million of the stock awards granted were in the form of service-based RSUs. In addition, approximately 0.4 million PSU’s were also granted to other vice president level employees for a total to all employees of 0.6 million PSU’s, all of which had a grant date fair value of $6.40. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-19-033615:notes:216]
The PSUs referenced in the preceding paragraph will be considered earned once the Company’s U.S. GAAP earnings aggregates at least $0.20 per share over two consecutive quarters (the “2019 Performance Threshold”).  Upon satisfying the 2019 Performance Threshold, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the 2019 Performance Threshold is not met by the third anniversary of the grant date, the award is canceled.  In addition, the 2019 Performance Threshold will be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $10.00 per share. During the year ended June 30, 2019, none of the PSU grants referenced above achieved their 2019 Performance Threshold.

[0001564590-19-033615:notes:217]
Fiscal 2018 PSU

[0001564590-19-033615:notes:218]
During fiscal 2018, the Company approved the grant of 1.2 million stock awards to its vice president level employees or above (“execs”), including 0.6 million stock awards to its named executive officers.  Fifty percent (50%) of the stock awards granted to the execs, except the chief executive officer, were in the form of PSUs and fifty percent (50%) of the stock awards granted were in the form of service-based RSUs.  The Company’s chief executive officer received sixty percent (60%) of his stock award grant in the form of PSUs, while forty percent (40%) of this award were in the form of RSUs. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-19-033615:notes:219]
The PSUs referenced in the preceding paragraph will be considered earned originally once the Company’s U.S. GAAP earnings aggregates at least $0.32 per share over two consecutive quarters (the Performance Threshold”). During the third quarter of fiscal 2019, the compensation committee of the Board of Directors modified the 2018 Performance Threshold of $0.32 earnings per share over two consecutive quarters for PSUs issued in fiscal 2018, to $0.20 earnings per share over two consecutive quarters. Upon satisfying the 2018 Performance Threshold, the PSUs will vest with respect to the same number of RSUs that have vested which were granted on the same date and thereafter, will vest on the same schedule as the RSUs, subject to continued service to the Company.  If the 2018 Performance Threshold is not met by the third anniversary of the grant date, the award is canceled.  In addition, the 2018 Performance Threshold will be deemed satisfied upon the closing of a Change in Control (within the meaning of the Company’s 2013 Equity Incentive Plan) in the event the per share consideration received by the Company’s stockholders equals or exceeds $16.00 per share; or, in the event the consideration is less than $16.00 per share, the number of PSUs deemed to be earned will be determined by multiplying the number of PSUs by the ratio of the aggregate earnings per share of the last two quarters prior to the Change of Control to the $0.32 Performance Threshold. The grant date fair value per share of the PSUs referenced above was $10.90. During the year ended June 30, 2019, none of the PSU grants referenced above achieved their 2018 Performance Threshold.

[0001564590-19-033615:notes:220]
During fiscal 2018, the Company approved the grant of 0.1 million stock awards with market-based vesting criteria to certain execs with grant date fair values per share ranging from $10.61 to $12.19 determined by using the Monte-Carlo simulation model.

[0001564590-19-033615:notes:221]
Fiscal 2017 PSU

[0001564590-19-033615:notes:222]
During fiscal 2017, the Company approved the grant of 1.5 million stock awards to its execs, including 0.7 million stock awards to its named executive officers.  Fifty percent (50%) of the stock awards granted to the execs were in the form of PSUs and fifty percent (50%) of the stock awards granted were in the form of RSUs. The RSUs vest from the original grant date as to one-third (1/3) on the one-year anniversary and one-twelfth (1/12) each quarter thereafter, subject to continued service to the Company.

[0001564590-19-033615:notes:223]
The PSUs referenced in the preceding paragraph were considered earned once the Company’s stock price equaled or exceeded $5.00 per share for 30 consecutive trading days after January 1, 2017 (the “2017 Performance Threshold”). The grant date fair values per share of the PSUs were determined by using the Monte-Carlo simulation model, ranging $3.02 to $3.09. The assumptions used in the Monte-Carlo simulation includes the expected volatility of 56%, risk-free rate of 0.9%, no expected divided yield, expected term of 3.0 years and possible future stock prices over the performance period based on historical stock and market prices. The assumptions used in the Monte-Carlo simulation includes the risk-free rate, expected divided yield, expected term, and possible future stock prices over the performance period based on historical stock and market prices. Once the 2017 Performance Threshold goal was attainted, the PSUs began to vest on the same schedule as the RSUs that were granted at the same time, subject to continued service to the Company.  During the year ended June 30, 2017, all of the PSUs referenced above achieved their 2017 Performance Threshold and as such, began vesting and will be released on the schedule as noted, subject to continued service to the Company.

[0001564590-19-033615:notes:224]
During fiscal 2017, the Company approved grants of 1.4 million stock awards in the form of PSUs to certain execs, including 0.9 million shares to its Executive Officers. Fifty percent (50%) of the PSUs are earned based on the Company’s stock price appreciation (the “Stock Price PSUs”) and fifty percent (50%) of the PSUs are earned based on the Company’s total stockholder return relative to the S&P Small Cap 600 Capped Information Technology Index (the “TSR PSUs”).

[0001564590-19-033615:notes:225]
The Stock Price PSUs represent the right to receive a number of shares of common stock up to one and one-third of the target number of Stock Price PSUs. They are earned, and vest as follows based on the average adjusted closing stock price of the Company’s common stock for the 90 days ending as of May 4, 2020, subject to the grantees’ continued service through the certification of performance:

[0001564590-19-033615:notes:226]
| Average adjusted closing stock price |  | Shares earned |
| at least $8.96 but less than $11.63 |  | One-third |
| at least $11.63 but less than $13.15 |  | Two-thirds |
| at least $13.15 but less than $16.56 |  | 100% |
| $16.56 or more |  | One and one-third |

[0001564590-19-033615:notes:227]
No PSUs are earned if such average adjusted closing stock price is less than $8.96.

[0001564590-19-033615:notes:228]
The TSR PSUs represent the right to receive a number of shares of common stock up to 130% of the target number of TSR PSUs. They are earned, and vest as follows based on the positive percentage point difference between the Company’s total stockholder return and the total stockholder return for the S&P Small Cap 600 Capped Information Technology Index over the performance period from May 4, 2017 to May 4, 2020, subject to the grantees’ continued service through the certification of performance:

[0001564590-19-033615:notes:229]
| Level |  | Percentage point differencebetween Company TSR andindex TSR |  |  | Shares earned |  |
| Threshold |  |  | 0 | % |  |  | 0 | % |
| Target |  |  | + 25 | % |  |  | 100 | % |
| Maximum |  |  | + 35 | % |  |  | 130 | % |

[0001564590-19-033615:notes:230]
Total stockholder return is calculated based on the 90-day average stock price at the beginning and end of the performance period. Linear interpolation is generally used to determine the number of shares earned for achievement between threshold and target levels and between target and maximum levels. However, if the Company’s total stockholder return over the performance period is negative, the number of shares earned will be capped at 100% of the target number of TSR PSUs.

[0001564590-19-033615:notes:231]
The grant date fair values per share of the Stock Price PSUs and the TSR PSUs were determined by using the Monte-Carlo simulation model, ranging $7.01 to $8.76, respectively. The assumptions used in the Monte-Carlo simulation includes the expected volatility of 54%, risk-free rate of 1.5%, no expected divided yield, expected term of 3.0 years and possible future stock prices over the performance period based on historical stock and market prices.

[0001564590-19-033615:notes:232]
For the fiscal years ended 2019, 2018 and 2017, the Company withheld an aggregate of 1.3 million shares, 1.0 million shares and 0.4 million shares, respectively, upon the vesting of RSUs, based upon the closing share price on the vesting date as settlement of the employees’ minimum statutory obligation for the applicable income and other employment taxes.

[0001564590-19-033615:notes:233]
For fiscal years ended 2019, 2018 and 2017, the Company remitted cash of $8.4 million, $11.3 million and $2.0 million, respectively, to the appropriate taxing authorities on behalf of the employees. The payment of the taxes by the Company reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital in the consolidated balance sheets and as a reduction of “Proceeds from issuance of common stock” in the financing activity within the consolidated statements of cash flows.

[0001564590-19-033615:notes:234]
As of June 30, 2019, there were $29.1 million in unrecognized compensation costs related to non-vested stock awards. This cost is expected to be recognized over a weighted-average period of 1.6 years

[0001564590-19-033615:notes:235]
Performance Grant Activity

[0001564590-19-033615:notes:236]
The following table summarizes PSU’s with market or performance based conditions granted and the number of awards that have satisfied the relevant market or performance criteria in each period (in thousands):

[0001564590-19-033615:notes:237]
|  |  | Fiscal year 2019 |  |  | Fiscal year 2018 |  |  | Fiscal year 2017 |  |
| Performance awards granted |  |  | 635 |  |  |  | 714 |  |  |  | 2,106 |  |
| Performance awards earned |  |  | 342 |  |  |  | 566 |  |  |  | 839 |  |

[0001564590-19-033615:notes:238]
2014 Employee Stock Purchase Plan

[0001564590-19-033615:notes:239]
In August 27, 2014, the Board of Directors approved the adoption of Extreme Network’s 2014 Employee Stock Purchase Plan (the “2014 ESPP”). On November 12, 2014, the stockholders approved the 2014 ESPP with the maximum number of shares of common stock that may be issued under the plan of 12.0 million shares. The Board of Directors unanimously approved an amendment to the 2014 ESPP to increase the maximum number of shares that will be available for sale by 7,500,000 shares which was ratified by the stockholders of the Company at the annual meeting of stockholders held on November 8, 2018. The 2014 ESPP replaced the 1999 Employee Stock Purchase Plan. The 2014 ESPP allows eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of total compensation, subject to the terms of the specific offering periods outstanding. Each purchase period had a maximum duration of six months. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. During fiscal 2018, the 2014 ESPP had offerings periods of either 6 months or 24 months, commonly referred to as “look back periods”. During the fiscal years ended June 30, 2019 and 2018 , there were 2.8 million and 2.4 million shares issued under the 2014 ESPP.  As of June 30, 2019, there have been 9.4 million shares issued under the 2014 ESPP.

[0001564590-19-033615:notes:240]
Effective with the offering period beginning on February 1, 2016, the Company amended the 2014 ESPP to increase the maximum shares issuable for each purchase period from 1.0 million shares to 1.5 million shares. Effective with the offering period beginning on August 1, 2016, the Company amended the 2014 ESPP so that all future offering periods are limited to six months and to make certain other changes to the 2014 ESPP including adding new contribution limits for each offering period. Existing open offering periods prior to the effective date of the changes were unaffected by the amendments to the 2014 ESPP.

[0001564590-19-033615:notes:241]
Share Based Compensation Expense

[0001564590-19-033615:notes:242]
Share-based compensation expense recognized in the financial statements by line item caption is as follows (in thousands):

[0001564590-19-033615:notes:243]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Cost of product revenue |  | $ | 844 |  |  | $ | 564 |  |  | $ | 333 |  |
| Cost of service revenue |  |  | 1,639 |  |  |  | 1,131 |  |  |  | 589 |  |
| Research and development |  |  | 10,443 |  |  |  | 7,642 |  |  |  | 3,312 |  |
| Sales and marketing |  |  | 11,747 |  |  |  | 9,843 |  |  |  | 4,253 |  |
| General and administrative |  |  | 8,224 |  |  |  | 8,453 |  |  |  | 4,146 |  |
| Total share-based compensation expense |  | $ | 32,897 |  |  | $ | 27,633 |  |  | $ | 12,633 |  |

[0001564590-19-033615:notes:244]
The amount of share-based compensation expense capitalized in inventory has been immaterial for each of the periods presented.

[0001564590-19-033615:notes:245]
The Company uses the straight-line method for expense attribution other than the PSUs using the accelerated attribution method. Beginning in fiscal 2017, the Company no longer estimates forfeitures, but rather recognizes expense for those shares expected to vest and recognizes forfeitures when they occur. The Company’s estimated forfeiture rate in fiscal 2016 based on the Company’s historical forfeiture experience was 13% for non-executives and 19% for executives.

[0001564590-19-033615:notes:246]
The fair value of each stock option grant under the Company’s 2013 Plan and 2005 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table.  The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free rate is based upon the estimated life of the option and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on a blended rate of the implied volatilities from traded options on the Company’s stock and historical volatility on the Company’s stock.

[0001564590-19-033615:notes:247]
The Company uses the simplified method to estimate the life of options and awards.  The Company uses the simplified method for all options and awards for all periods as it does not believe that historical exercise data provides a reasonable basis upon which to estimate the expected term.

[0001564590-19-033615:notes:248]
The fair value of each RSU grant with performance-based vesting criteria (“PSUs”) under the 2013 Plan is estimated on the date of grant using the Monte-Carlo simulation model to determine the fair value and the derived service period of stock awards with market conditions, on the date of the grant.

[0001564590-19-033615:notes:249]
The fair value of each share purchase option under the Company's 2014 ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the 2014 ESPP. The risk-free rate is based upon the estimated life and is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock.

[0001564590-19-033615:notes:250]
The weighted-average estimated per share fair value of shares purchased under the 2014 ESPP in fiscal years 2019, 2018 and 2017, was $2.71, $3.25 and $1.24, respectively.

[0001564590-19-033615:notes:251]
|  |  | Employee Stock Purchase Plan |  |
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Expected life |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  | 2.22%-2.46% |  |  | 1.64%-1.15% |  |  |  | 0.40 | % |
| Volatility |  |  | 70 | % |  |  | 42 | % |  | 46%-37% |  |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |

[0001564590-19-033615:notes:252]
401(k) Plan

[0001564590-19-033615:notes:253]
The Company provides a tax-qualified employee savings and retirement plan, commonly known as a 401(k) plan (the “Plan”), which covers the Company’s eligible employees. Pursuant to the Plan, employees may elect to reduce their current compensation up to the IRS annual contribution limit of $19,000 for calendar year 2019. Employees age 50 or over may elect to contribute an additional $6,000. The amount contributed to the Plan is on a pre-tax basis.

[0001564590-19-033615:notes:254]
The Company provides for discretionary matching contributions as determined by the Board of Directors for each calendar year. All matching contributions vest immediately.  In addition, the Plan provides for discretionary contributions as determined by the Board of Directors each year. The program during fiscal 2019 is to match $0.50 for every Dollar contributed by the employee up to the first 2.5% of pay.  The Company’s matching contributions to the Plan totaled $4.2 million, $3.3 million and $1.4 million, for fiscal years ended 2019, 2018 and 2017, respectively. No discretionary contributions were made in fiscal years ended 2019, 2018 and 2017.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-033615:notes:255]
11. Business Combinations

[0001564590-19-033615:notes:256]
The Company completed three acquisitions during the year ended June 30, 2018 and an acquisition during the year ended June 30, 2017. The acquisitions have been accounted for using the acquisition method of accounting. The purchase price of each acquisition has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. The fair value of working capital related items, such as other current assets and accrued liabilities, approximated their book values at the date of acquisition.  Inventories were valued at fair value using the net realizable value approach. The fair value of property and equipment was determined using a cost approach. The fair value of the acquired deferred revenue was estimated using the cost build-up approach. The cost build-up approach determines fair value using estimates of the costs required to provide the contracted deliverables plus an assumed profit. The total costs including the assumed profit were adjusted to present value using a discount rate considered appropriate. The resulting fair value approximates the amount the Company would be required to pay to a third party to assume the obligation. Valuations of the intangible assets were valued using income approaches based on management projections, which the Company considers to be Level 3 inputs. The Company also continues to analyze the tax implications of the acquisition of the intangible assets which may ultimately impact the overall level of goodwill associated with the acquisition.  Results of operations of the acquired entities are included in the Company’s operations beginning with the closing date of each acquisition.

[0001564590-19-033615:notes:257]
On August 9, 2019 the Company completed its acquisition of Aerohive Networks Inc. for approximately $264 million in cash consideration and acquired all Aerohive common shares at a price of $4.45 per share plus the assumption of certain employee equity awards. See Note 17 – Subsequent Events.

[0001564590-19-033615:notes:258]
Fiscal 2018 Acquisitions

[0001564590-19-033615:notes:259]
Data Center Business

[0001564590-19-033615:notes:260]
The Company completed its acquisition of the data center business (the “Data Center Business”) of Brocade Communication Systems, Inc.’s (“Brocade”) on October 27, 2017 (the “Data Center Closing Date”), pursuant to an Asset Purchase Agreement (the “Data Center Business APA”) dated as of October 3, 2017, by and between the Company and Brocade for an aggregate purchase consideration of $84.3 million. Under the terms and conditions of the Data Center Business APA, the Company acquired customers, employees, technology and other assets of the Data Center Business as well as assumed certain contracts and other liabilities of the Data Center Business.

[0001564590-19-033615:notes:261]
The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-19-033615:notes:262]
|  |  | Final Allocation |  |
| Accounts receivables |  | $ | 33,488 |  |
| Inventories |  |  | 19,934 |  |
| Prepaid expenses and other current assets |  |  | 988 |  |
| Property and equipment | (a) |  | 19,442 |  |
| Other assets |  |  | 4,734 |  |
| Accounts payable and accrued expenses |  |  | (16,494 | ) |
| Deferred revenue |  |  | (33,025 | ) |
| Net tangible assets acquired |  |  | 29,067 |  |
| Identifiable intangible assets |  |  | 32,800 |  |
| Goodwill | (a) |  | 22,470 |  |
| Total intangible assets acquired |  |  | 55,270 |  |
| Total net assets acquired |  | $ | 84,337 |  |

[0001564590-19-033615:notes:263]
|  | (a) | Includes an adjustment after the measurement period to record $0.5 million of additional property and equipment acquired at an international location. |

[0001564590-19-033615:notes:264]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the Data Center Business. The Company anticipates both the goodwill and intangible assets to be fully deductible for income tax purposes.

[0001564590-19-033615:notes:265]
Pursuant to negotiations regarding various contractual arrangements with Broadcom, in August 2018, the Company resolved its contingent consideration obligation related to the Data Center Business acquisition.  The outstanding balance was revalued to its final fair value as of June 30, 2018 resulting in a charge of $1.5 million which is included in “General and administrative” expense in the accompanying consolidated statements of operations.

[0001564590-19-033615:notes:266]
Campus Fabric Business

[0001564590-19-033615:notes:267]
The Company completed its acquisition of Avaya Inc.’s (“Avaya”) fabric-based secure networking solutions and network security solutions business (the “Campus Fabric Business”) on July 14, 2017, (the “Campus Fabric Business Closing Date”) pursuant to an Asset Purchase Agreement (the “Campus Fabric Business APA”) dated March 7, 2017.  Under the terms and conditions of the Campus Fabric Business APA, the Company acquired the customers, employees, technology and other assets of the Campus Fabric Business, as well as assumed certain contracts and other liabilities of the Campus Fabric Business, for total consideration of $79.4 million.

[0001564590-19-033615:notes:268]
|  | Final Allocation |  |
| Accounts receivables | $ | 19,527 |  |
| Inventories |  | 14,165 |  |
| Prepaid expenses and other current assets |  | 240 |  |
| Property and equipment |  | 5,406 |  |
| Other assets |  | 7,009 |  |
| Accounts payable and accrued expenses |  | (31,670 | ) |
| Deferred revenue |  | (8,994 | ) |
| Other long-term liabilities |  | (5,849 | ) |
| Net tangible assets acquired |  | (166 | ) |
| Identifiable intangible assets |  | 41,300 |  |
| In-process research and development |  | 2,400 |  |
| Goodwill |  | 35,892 |  |
| Total intangible assets acquired |  | 79,592 |  |
| Total net assets acquired | $ | 79,426 |  |

[0001564590-19-033615:notes:269]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” in the accompanying consolidated statement of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the Campus Fabric Business. The Company anticipates both the goodwill and intangible assets to be fully deductible for income tax purposes.

[0001564590-19-033615:notes:270]
The Company also acquired an indefinite lived asset of $2.4 million which represents the fair value of in-process research and development activities. During the three months ended March 31, 2018, the related research and development efforts were completed and the Company reclassified the in-process research and development of $2.4 million to developed technology and began recognizing amortization expense over its estimated useful life.

[0001564590-19-033615:notes:271]
Capital Financing Business

[0001564590-19-033615:notes:272]
On December 1, 2017, Company completed its acquisition of a capital financing business (the “CF Business”), pursuant to a Bill of Sale and Assignment and Assumption Agreement (the “Assumption Agreement”) between the Company and Broadcom.  Under the terms and conditions of the Assumption Agreement, the Company acquired customers, employees, contracts and lease equipment of the CF Business equal to the earn out payments to Broadcom of 90% of acquired financing receivables to be collected commencing at the closing date.

[0001564590-19-033615:notes:273]
Net assets acquired included financing receivables of $13.7 million, lease equipment of $3.5 million and identifiable intangible assets of $0.8 million, and the fair value of the contingent consideration was $13.0 million. As the preliminary fair value of the net assets acquired exceeded the fair value of the purchase consideration, the Company recorded a bargain purchase gain of $5.0 million.

[0001564590-19-033615:notes:274]
Fiscal 2017 Acquisition

[0001564590-19-033615:notes:275]
On October 28, 2016, the Company completed its acquisition of the wireless local area network business (“WLAN Business”) from Zebra Technologies Corporation. Under the terms of the WLAN Asset Purchase Agreement, the Company acquired customers, employees, technology and other assets as well as assumed certain contracts and other liabilities of the WLAN Business, for a net cash consideration of $49.5 million. The following table below summarizes the final allocation of the tangible and identifiable intangible assets acquired and liabilities assumed (in thousands):

[0001564590-19-033615:notes:276]
|  | Final Allocation |  |
| Accounts receivables, net | $ | 14,636 |  |
| Inventories |  | 13,593 |  |
| Other current assets |  | 808 |  |
| Property and equipment |  | 3,159 |  |
| Other assets |  | 7,634 |  |
| Deferred revenue |  | (14,159 | ) |
| Other liabilities |  | (7,201 | ) |
| Total tangible assets acquired and liabilities assumed |  | 18,470 |  |
| Identifiable intangible assets |  | 20,300 |  |
| In-process research and development |  | 1,400 |  |
| Goodwill |  | 9,339 |  |
| Total intangible assets acquired |  | 31,039 |  |
| Total net assets acquired | $ | 49,509 |  |

[0001564590-19-033615:notes:277]
The amortization for the developed technology is recorded in “Cost of revenues” for product and the amortization for the remaining intangibles is recorded in “Amortization of intangibles” on the consolidated statements of operations. The goodwill recognized is attributable primarily to expected synergies and the assembled workforce of the WLAN Business. The Company anticipates both the goodwill and intangible assets to be fully deductible for tax purposes.

[0001564590-19-033615:notes:278]
The Company also acquired an indefinite lived asset of $1.4 million which represents the fair value of in-process research and development activities. The in-process research and development was reclassified to developed technology upon completion of the project as of June 30, 2018 and is being amortized over its estimated useful life.

[0001564590-19-033615:notes:279]
Pro forma financial information

[0001564590-19-033615:notes:280]
The following unaudited pro forma results of operations are presented as though the acquisitions of the Data Center Business, CF Business and Campus Fabric Business had occurred as of the beginning of fiscal 2017, after giving effect to purchase accounting adjustments relating to inventories, deferred revenue, depreciation and amortization on acquired property and equipment and intangibles, acquisition costs, interest income and expense and related tax effects.

[0001564590-19-033615:notes:281]
The pro forma results of operations are not necessarily indicative of the combined results that would have occurred had the acquisition been consummated as of the beginning of fiscal 2017, nor are they necessarily indicative of future operating results. The unaudited pro forma results do not include the impact of synergies, nor any potential impacts on current or future market conditions which could alter the unaudited pro forma results.

[0001564590-19-033615:notes:282]
The unaudited pro forma financial information for the year ended June 30, 2018, combines the results for Extreme for the year ended June 30, 2018, which include the results of the Data Center Business, Campus Fabric Business and CF Business subsequent to their acquisition dates and their historical results up to the acquisition date.

[0001564590-19-033615:notes:283]
The unaudited pro forma financial information for the year ended June 30, 2017, combines the historical results for Extreme for those periods, as adjusted for the adoption of Topic 606, with the historical results of the Data Center Business, Campus Fabric Business, CF Business for the year ended June 30, 2017, as well as the historical results of the WLAN Business prior to the WLAN Business acquisition date.

[0001564590-19-033615:notes:284]
Pro forma results of operations from the Data Center Business, CF Business, Campus Fabric Business and WLAN Business acquisitions included in the pro forma results of operations have not been adjusted for the adoption of Topic 606 because the Company determined that it is impractical to estimate the impact of the adoption.

[0001564590-19-033615:notes:285]
The following table summarizes the unaudited pro forma financial information (in thousands, except per share amounts):

[0001564590-19-033615:notes:286]
|  |  | Year Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Net revenues |  | $ | 1,076,988 |  |  | $ | 1,205,696 |  |
| Net loss |  | $ | (27,007 | ) |  | $ | (143,835 | ) |
| Net loss per share - basic and diluted |  | $ | (0.24 | ) |  | $ | (1.33 | ) |
| Shares used in per share calculation - basic and diluted |  |  | 114,221 |  |  |  | 108,275 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-033615:notes:287]
12. Information about Segments of Geographic Areas

[0001564590-19-033615:notes:288]
The Company operates in one segment, the development and marketing of network infrastructure equipment.  Revenue is attributed to a geographical area based on the location of the customers.  The Company operates in three geographic theaters: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East and Africa; and APAC which includes Asia Pacific, China, South Asia and Japan.  The Company’s chief operating decision maker (“CODM”), who is its CEO, reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.

[0001564590-19-033615:notes:289]
See Note 3. Revenues for the Company’s revenues by geographic regions and channel based on the customers’ ship-to location.

[0001564590-19-033615:notes:290]
The Company’s long-lived assets are attributed to the geographic regions as follows (in thousands):

[0001564590-19-033615:notes:291]
| Long-lived Assets |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Americas |  | $ | 136,035 |  |  | $ | 178,251 |  |
| EMEA |  |  | 28,744 |  |  |  | 15,106 |  |
| APAC |  |  | 11,529 |  |  |  | 9,896 |  |
| Total long-lived assets |  | $ | 176,308 |  |  | $ | 203,253 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-033615:notes:292]
13. Foreign Exchange Forward Contracts

[0001564590-19-033615:notes:293]
The Company uses derivative financial instruments to manage exposures to foreign currency. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes.  The fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other (expense) income, net” in the accompanying consolidated statements of operations; the Company recognized total foreign currency gains of $0.1 million in fiscal 2019 and losses of $1.2 million and $0.7 million in fiscal 2018 and 2017, respectively, related to the change in fair value of foreign currency denominated assets and liabilities. The Company enters into foreign exchange forward contracts to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and remeasurement of certain assets and liabilities denominated in foreign currencies. These derivatives do not qualify as hedges. There were no gains and losses from hedging transactions in fiscal year ended June 30, 2019 and they were not material in fiscal years 2018 and 2017.

[0001564590-19-033615:notes:294]
At June 30, 2019  the Company did not have any forward foreign currency contracts.  At June 30, 2018, forward foreign currency contracts had a notional principal amount of $5.0 million. These contracts had maturities of less than 60 days.  Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-033615:notes:295]
14. Restructuring and Related Charges, Net of Reversals

[0001564590-19-033615:notes:296]
As of June 30, 2019, restructuring liabilities were $5.3 million which are recorded in “Other accrued liabilities” and “Other long-term liabilities” in the accompanying consolidated balance sheets.  The restructuring liabilities consist of obligations pertaining to the estimated future obligations for non-cancelable lease payments and severance and benefits obligations.  During years ended 2019, 2018 and 2017, the Company recorded restructuring charges, net of reversals, of $5.1 million, $8.1 million and $8.9 million, respectively. The restructuring charges net of reversals during fiscal 2019 were primarily associated with a reduction-in-force in the fourth quarter of fiscal 2019 and additional excess facilities obligations. The charges are reflected in “Restructuring and related charges, net of reversals” in the consolidated statements of operations.

[0001564590-19-033615:notes:297]
2019 Restructuring

[0001564590-19-033615:notes:298]
The Company recorded a total of $5.1 million in restructuring charges during the year ended June 30, 2019. A reduction-in-force in its fourth fiscal quarter of fiscal 2019 was announced to better align its work force and operating expenses. Costs associated with the 2019 Plan are primarily comprised of employee severance and benefits expenses, relocation of personnel and equipment and exit of excess facilities. The Company recorded $3.7 million related to employee severance and benefits expenses during the year ended June 30, 2019 under the 2019 Plan. Also, $1.1 million of additional charges related to continuation of earlier actions associated with a reduction-in-force in the fourth quarter of fiscal 2018. The Company also incurred charges of $0.3 million for changes to its estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of its excess facilities.  The amount and timing of the actual charges may vary due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions. The Company expects the severance and benefits will be substantially paid by December 2019, and the excess facilities obligations will continue through December 2027.

[0001564590-19-033615:notes:299]
2018 Restructuring

[0001564590-19-033615:notes:300]
The Company announced and executed a reduction-in-force in its third and fourth fiscal quarters of fiscal 2018 as a result of the acquisitions of the Campus Fabric Business and the Data Center Business. The Company recorded $7.9 million related to employee severance and benefits expenses during the year ended June 30, 2018.  The Company also incurred charges of $0.2 million for changes to its estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of its excess facilities.

[0001564590-19-033615:notes:301]
2017 Restructuring

[0001564590-19-033615:notes:302]
In conjunction with the Company’s restructuring activities noted below, the Company incurred $8.9 million of restructuring charges, net of reversals during fiscal 2017 which is reflected in “Restructuring and related charges, net of reversals” in the consolidated statements of operations.

[0001564590-19-033615:notes:303]
Pursuant with the WLAN Business acquisition from Zebra, the Company assumed a facility lease located at 6480 Via del Oro in San Jose, California (“Via del Oro”) and transferred the Company’s headquarters from Rio Robles Drive in San Jose, California (“Rio Robles”) to Via del Oro.  The Company consolidated its existing workforce with employees assumed from Zebra at the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to the Company’s move from the Rio Robles facility and abandonment of all leasehold improvements, it accelerated the amortization of the remaining leasehold improvements balance for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  The Company recorded accelerated amortization expense for the years ended June 30, 2019 and 2018 of $0.1 million and $2.6 million, respectively.

[0001564590-19-033615:notes:304]
The Company entered into a sublease agreement for its Rio Robles facility during the third quarter of fiscal 2017.  The sublease is for the remaining duration of the Company’s lease. The net charges incurred for the remaining lease payments, real estate commissions and other related costs, net of the future sublease payments resulted in additional charges of $2.0 million during fiscal 2017. The excess facilities payments will continue through fiscal year 2023.

[0001564590-19-033615:notes:305]
In anticipation of the acquisitions of the Campus Fabric and the Data Center Businesses, the Company reoccupied the majority of its exited space at its Salem, New Hampshire location during its fiscal fourth quarter to accommodate the growth in headcount and lab facility requirements.  This action resulted in a reversal of prior accruals of $1.3 million.

[0001564590-19-033615:notes:306]
In conjunction with the consolidation actions noted above, the Company announced a reduction-in-force affecting 90 employees.  The Company recorded $5.6 million in severance and benefits charges, net during the year ended June 30, 2017.

[0001564590-19-033615:notes:307]
Restructuring liabilities consist of (in thousands):

[0001564590-19-033615:notes:308]
|  |  | Excess Facilities |  |  | Severance Benefits |  |  | Other |  |  | Total |  |
| Balance as of June 30, 2016 |  |  | 4,644 |  |  |  | — |  |  |  | — |  |  |  | 4,644 |  |
| Period charges |  |  | 1,951 |  |  |  | 5,728 |  |  |  | 2,663 |  |  |  | 10,342 |  |
| Period reversals |  |  | (1,337 | ) |  |  | (109 | ) |  |  | — |  |  |  | (1,446 | ) |
| Non cash adjustments |  |  | — |  |  |  | — |  |  |  | (2,578 | ) |  |  | (2,578 | ) |
| Period payments |  |  | (3,074 | ) |  |  | (3,766 | ) |  |  | — |  |  |  | (6,840 | ) |
| Balance as of June 30, 2017 |  | $ | 2,184 |  |  | $ | 1,853 |  |  | $ | 85 |  |  | $ | 4,122 |  |
| Period charges |  |  | 207 |  |  |  | 7,945 |  |  |  | — |  |  |  | 8,152 |  |
| Period reversals |  |  | — |  |  |  | — |  |  |  | (12 | ) |  |  | (12 | ) |
| Period payments |  |  | (594 | ) |  |  | (5,140 | ) |  |  | (73 | ) |  |  | (5,807 | ) |
| Balance as of June 30, 2018 |  | $ | 1,797 |  |  | $ | 4,658 |  |  | $ | — |  |  | $ | 6,455 |  |
| Period charges |  |  | 254 |  |  |  | 5,274 |  |  |  | — |  |  |  | 5,528 |  |
| Period reversals |  |  | — |  |  |  | (438 | ) |  |  | — |  |  |  | (438 | ) |
| Period payments |  |  | (287 | ) |  |  | (5,935 | ) |  |  | — |  |  |  | (6,222 | ) |
| Balance as of June 30, 2019 |  | $ | 1,764 |  |  | $ | 3,559 |  |  | $ | — |  |  | $ | 5,323 |  |
| Less: current portion included in Other accrued liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4,010 |  |
| Restructuring accrual included in Other long-term liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,313 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-033615:notes:309]
15. Income Taxes

[0001564590-19-033615:notes:310]
Income before income taxes is as follows (in thousands):

[0001564590-19-033615:notes:311]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 22,330 |  |  | $ | (55,197 | ) |  | $ | (7,228 | ) |
| Foreign |  |  | (48,204 | ) |  |  | 8,550 |  |  |  | 9,824 |  |
| Total |  | $ | (25,874 | ) |  | $ | (46,647 | ) |  | $ | 2,596 |  |

[0001564590-19-033615:notes:312]
The provision for income taxes for the years ended 2019, 2018 and 2017 consisted of the following (in thousands):

[0001564590-19-033615:notes:313]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | — |  |  | $ | (155 | ) |  | $ | (155 | ) |
| State |  |  | 655 |  |  |  | 521 |  |  |  | 168 |  |
| Foreign |  |  | 5,100 |  |  |  | 4,456 |  |  |  | 2,332 |  |
| Total current |  |  | 5,755 |  |  |  | 4,822 |  |  |  | 2,345 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (3,691 | ) |  |  | (6,358 | ) |  |  | 3,063 |  |
| State |  |  | (488 | ) |  |  | 294 |  |  |  | 99 |  |
| Foreign |  |  | (1,597 | ) |  |  | 1,387 |  |  |  | (1,167 | ) |
| Total deferred |  |  | (5,776 | ) |  |  | (4,677 | ) |  |  | 1,995 |  |
| Provision for income taxes |  | $ | (21 | ) |  | $ | 145 |  |  | $ | 4,340 |  |

[0001564590-19-033615:notes:314]
The difference between the provision for income taxes and the amount computed by applying the federal statutory income tax rate (21 percent for fiscal 2019 pursuant to the recently enacted U.S. tax legislation) to income before taxes is explained below (in thousands):

[0001564590-19-033615:notes:315]
|  |  | Year Ended |  |
|  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Tax at federal statutory rate |  | $ | (5,433 | ) |  | $ | (13,061 | ) |  | $ | 909 |  |
| State income tax, net of federal benefit |  |  | 517 |  |  |  | 521 |  |  |  | 168 |  |
| Release of foreign valuation allowance |  |  | (2,794 | ) |  |  | — |  |  |  | — |  |
| Release of US valuation allowance – Tax reform |  |  | (4,680 | ) |  |  | — |  |  |  | — |  |
| Establishment of Irish valuation allowance |  |  | 8,642 |  |  |  | — |  |  |  | — |  |
| US valuation allowance change – deferred tax movement |  |  | (4,444 | ) |  |  | 25,302 |  |  |  | 3,246 |  |
| Research and development credits |  |  | (6,598 | ) |  |  | (7,311 | ) |  |  | (1,355 | ) |
| Foreign earnings taxed at other than U.S. rates |  |  | 10,562 |  |  |  | (1,065 | ) |  |  | (492 | ) |
| Stock based compensation |  |  | 2,436 |  |  |  | (5,901 | ) |  |  | (573 | ) |
| Goodwill amortization |  |  | 834 |  |  |  | 2,004 |  |  |  | 1,795 |  |
| Nondeductible officer compensation |  |  | 713 |  |  |  | 1,927 |  |  |  | 470 |  |
| Nondeductible meals and entertainment |  |  | 517 |  |  |  | 510 |  |  |  | 391 |  |
| AMT credit monetization |  |  | — |  |  |  | (155 | ) |  |  | (155 | ) |
| Deferred tax liability release - Tax reform |  |  | — |  |  |  | (2,482 | ) |  |  | — |  |
| Other |  |  | (293 | ) |  |  | (144 | ) |  |  | (64 | ) |
| Provision for income taxes |  | $ | (21 | ) |  | $ | 145 |  |  | $ | 4,340 |  |

[0001564590-19-033615:notes:316]
Significant components of the Company’s deferred tax assets are as follows (in thousands):

[0001564590-19-033615:notes:317]
|  |  | June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2017 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 36,514 |  |  | $ | 49,429 |  |  | $ | 109,170 |  |
| Tax credit carry-forwards |  |  | 54,745 |  |  |  | 48,093 |  |  |  | 34,444 |  |
| Depreciation |  |  | 2,168 |  |  |  | 1,422 |  |  |  | 1,312 |  |
| Intangible amortization |  |  | 36,882 |  |  |  | 35,107 |  |  |  | 32,919 |  |
| Deferred revenue, net |  |  | 1,887 |  |  |  | 159 |  |  |  | 3,320 |  |
| Inventory write-downs |  |  | 10,277 |  |  |  | 13,682 |  |  |  | 11,111 |  |
| Other allowances and accruals |  |  | 30,210 |  |  |  | 25,700 |  |  |  | 13,002 |  |
| Stock based compensation |  |  | 4,114 |  |  |  | 4,872 |  |  |  | 3,545 |  |
| Deferred intercompany gain |  |  | 3,693 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 673 |  |  |  | 3,219 |  |  |  | 4,270 |  |
| Total deferred tax assets |  |  | 181,163 |  |  |  | 181,683 |  |  |  | 213,093 |  |
| Valuation allowance |  |  | (169,343 | ) |  |  | (177,869 | ) |  |  | (212,111 | ) |
| Total net deferred tax assets |  |  | 11,820 |  |  |  | 3,814 |  |  |  | 982 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Goodwill amortization |  |  | (4,904 | ) |  |  | (3,363 | ) |  |  | (6,254 | ) |
| Prepaid commissions |  |  | (1,585 | ) |  |  | (1,034 | ) |  |  | — |  |
| Deferred tax liability on foreign withholdings |  |  | (505 | ) |  |  | (357 | ) |  |  | (321 | ) |
| Total deferred tax liabilities |  |  | (6,994 | ) |  |  | (4,754 | ) |  |  | (6,575 | ) |
| Net deferred tax assets (liabilities) |  | $ | 4,826 |  |  | $ | (940 | ) |  | $ | (5,593 | ) |
| Recorded as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net non-current deferred tax assets |  |  | 6,783 |  |  |  | 5,195 |  |  |  | 983 |  |
| Net non-current deferred tax liabilities |  |  | (1,957 | ) |  |  | (6,135 | ) |  |  | (6,576 | ) |
| Net deferred tax assets (liabilities) |  | $ | 4,826 |  |  | $ | (940 | ) |  | $ | (5,593 | ) |

[0001564590-19-033615:notes:318]
The Company’s global valuation allowance decreased by $8.5 million in the fiscal year ended June 30, 2019 and decreased by $34.2 million in the fiscal year ended June 30, 2018. The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets, as well as valuation allowances against certain non-U.S. deferred tax assets in Ireland and Brazil.  The valuation allowance is determined by assessing both negative and positive available evidence to assess whether it is more likely than not that the deferred tax assets will be recoverable. The Company's inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends as well as the cyclical nature of the Company's business provides sufficient negative evidence to require a full valuation allowance against its U.S. federal and state net deferred tax assets. The valuation allowance is evaluated periodically and can be reversed partially or in full if business results and the economic environment have sufficiently improved to support realization of the Company's deferred tax assets.

[0001564590-19-033615:notes:319]
As of June 30, 2019, the Company had net operating loss carry-forwards for U.S. federal and state tax purposes of $126.6 million and $56.7 million, respectively.  As of June 30, 2019, the Company also had foreign net operating loss carry-forwards in Ireland, Australia and Brazil of $36.9 million, $7.9 million and $0.4 million, respectively.  As of June 30, 2019, the Company also had federal and state tax credit carry-forwards of $37.3 million and $22.1 million, respectively. These credit carry-forwards consist of research and development tax credits as well as foreign tax credits.  The U.S. federal net operating loss carry-forwards of $126.6 million will begin to expire in the fiscal year ending June 30, 2024 and state net operating losses of $56.7 million began to partially expire in the fiscal year ending June 30, 2020. The foreign net operating losses can generally be carried forward indefinitely.  Federal research and development tax credits of $26.6 million will expire beginning in fiscal 2020, if not utilized and foreign tax credits of $10.7 million will expire beginning in fiscal 2020.  North Carolina state research and development tax credits of $0.9 million will expire beginning in the fiscal year ending June 30, 2024, if not utilized. California state research and development tax credits of $21.2 million do not expire and can be carried forward indefinitely.

[0001564590-19-033615:notes:320]
In January 2019, the Company performed an Internal Revenue Code section 382 analysis with respect to its net operating loss and credit carry-forwards to determine whether a potential ownership change had occurred that would place a limitation on the annual utilization of tax attributes. It was determined that no ownership change had occurred during the fiscal year ended June 30, 2018, however, it is possible a subsequent ownership change could limit the utilization of the Company's tax attributes.

[0001564590-19-033615:notes:321]
As of June 30, 2019, cumulative undistributed, indefinitely reinvested earnings of non-U.S. subsidiaries totaled $6.8 million.  It has been the Company’s historical policy to invest the earnings of certain foreign subsidiaries indefinitely outside the US.  The Company is reviewing its prior position on the reinvestment of earnings of certain foreign subsidiaries but has recorded a deferred tax liability of $0.5 million related to withholding taxes that may be incurred upon repatriation of earnings from jurisdictions where no indefinite reinvestment assertion is made. The Company continues to maintain an indefinite reinvestment assertion for earnings in certain of its foreign jurisdictions. The unrecorded deferred tax liability for potential withholding tax associated with repatriation of these earnings as well as the deemed repatriation related to Tax Reform is $3.4 million.

[0001564590-19-033615:notes:322]
The Company conducts business globally and as a result, most of its subsidiaries file income tax returns in various domestic and foreign jurisdictions.  In the normal course of business, the Company is subject to examination by taxing authorities throughout the world.  Its major tax jurisdictions are the U.S., Ireland, India, California, New Hampshire and North Carolina. In general, the Company's U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to net operating losses and the Company's state income tax returns are subject to examination for fiscal years 2000 forward due to net operating losses.

[0001564590-19-033615:notes:323]
On December 22, 2017, the President of the United States signed and enacted into law H.R. 1, the Tax Cuts and Jobs Act (“TCJA”), which, except for certain provisions, is effective for tax years beginning on or after January 1, 2018. As a fiscal year taxpayer, the provisions would impact the fiscal years ending June 30, 2019 and forward.The TCJA’s primary change was a reduction in the U.S. Federal statutory corporate tax rate from 35% to 21%, including a pro rata reduction from 35% to 28% for the Company in fiscal 2018.

[0001564590-19-033615:notes:324]
The TCJA moves the U.S. from a global taxation regime to a modified territorial regime.  Under the territorial regime, the company’s foreign earnings will generally not be subject to tax in the US.  As part of transitioning to this new regime, U.S. companies were required to pay tax on historical earnings generated offshore that have not been repatriated to the U.S. (“Transition Tax”).  The Company recognized no incremental tax provision relating to the Transition Tax given the Company’s ability to utilize existing tax attributes to offset the impact of the deemed repatriation.

[0001564590-19-033615:notes:325]
The TCJA made broad and complex changes to the U.S. tax code, and in certain instances, lacks clarity and is subject to interpretation until additional U.S. Treasury guidance is issued.  On December 22, 2017, the SEC issued guidance under Staff Accounting Bulletin (“SAB”) No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act (“SAB 118”), which allows registrants to record provisional amounts during a one year “measurement period” similar to that used when accounting for business combinations.  The measurement period was deemed to have ended earlier when the registrant had obtained, prepared and analyzed the information necessary to finalize its accounting.  During the measurement period, impacts of the law were expected to be recorded at the time a reasonable estimate for all or a portion of the effects can be made, and provisional amounts can be recognized and adjusted as information becomes available, prepared or analyzed. The measurement period ended in the Company’s second fiscal quarter of 2019 and the Company has finalized all related adjustments.

[0001564590-19-033615:notes:326]
Amounts recorded pursuant to Tax Reform and the provisions of SAB 118 relate to the reduction in the U.S. federal tax rate to 21 percent, which resulted in the Company reporting an income tax benefit of $2.5 million in the fiscal year ended June 30, 2018 to remeasure deferred tax liabilities associated with indefinitely lived intangible assets that will reverse at the new 21% rate. Absent this deferred tax liability, the Company has historically been in a net deferred tax asset position that is offset by a full valuation allowance.  The Transition Tax introduced by TCJA has been calculated to be zero for the Company given existing tax attributes that were utilized to offset the calculated liability. As discussed below, during the quarter ended December 31, 2018 the Company completed its evaluation of whether to treat global intangible low-taxed income (“GILTI”) as a component of tax expense in the period in which it is incurred or as a component of deferred income taxes.  In conjunction with this determination and the completion of scheduling the reversal of deferred tax assets and liabilities, the Company reduced the valuation allowance level by $4.7 million in the second quarter of fiscal 2019 to reflect the introduction of an indefinite carryforward period for NOLs expected to be generated in tax years beginning after December 31, 2017 once deferred tax assets reverse.

[0001564590-19-033615:notes:327]
With respect to provisions of the TCJA effective for the Company’s fiscal year ended 2019, the Company determined several new provisions potentially impact tax provisions in the current year including limitations on the deductibility of interest expense and certain executive compensation, a minimum tax on certain foreign earnings or GILTI, as well as a base-erosion and anti-abuse tax (“BEAT”).  The GILTI provisions require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary’s tangible assets. Based on the fiscal year ending 2019 financial results, the company determined there is no GILTI inclusion required in U.S. taxable income.  The Company has  elected to account for GILTI tax as a component of tax expense in the period in which it is incurred. The Base Erosion and Anti-Abuse Tax (“BEAT”) provisions in the Tax Reform Act eliminate the deduction of certain base-erosion payments made to related foreign corporations, and impose a minimum tax if greater than regular tax.  There is a reasonable amount of uncertainty surrounding the interpretation of this new provision, however, based on the Company’s assessment and a reasonable interpretation of the new provision, the Company has determined it will not be subject to the incremental U.S. tax on BEAT income during the fiscal year ended 2019 due to a realignment of the Company’s international structure.

[0001564590-19-033615:notes:328]
In the first quarter of fiscal 2019, the Company adopted ASU 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which requires an entity to recognize the income tax consequences of an intra-entity transfer of an asset at the time the transfer occurs.  Historically, U.S. GAAP has prohibited the recognition of current and deferred income taxes for an intra-entity asset transfer until the asset had been sold outside the consolidated group.  Effective as of July 1, 2018, the Company adopted ASU 2016-16 on a modified retrospective basis which requires an adjustment of the cumulative-effect of the adoption to retained earnings.  However, the adjustment was immaterial to the financial statements and no such adjustment was necessary.  As a result of adoption, the income tax consequences of future intra-entity transfer of assets will be recognized in earnings in each period rather than be deferred until the assets leave the consolidated group.  In the first quarter of fiscal 2019, the Company recognized a deferred tax asset relating to a transfer of certain assets from the U.S. parent company to its wholly-owned Irish subsidiary of $3.7 million, which was fully offset by the establishment of a valuation allowance resulting in no impact to the  Company’s consolidated statement of operations.

[0001564590-19-033615:notes:329]
During the fiscal year ended June 30, 2014, the Company acquired the stock of Enterasys Networks, Inc. and as such they became a wholly owned subsidiary of Extreme Networks.  With respect to this acquisition, the Company made an election under Internal Revenue Code section 338(h)(10) to treat the acquisition as an asset purchase from a tax perspective.  Under this election the tax basis of all assets is effectively reset to that of fair market value and therefore the transaction did not result in the recording of an opening net deferred tax position as the Company's tax basis in the acquired assets equaled its book basis. The resulting intangible assets and goodwill are being amortized for tax purposes over 15 years.

[0001564590-19-033615:notes:330]
Additionally, the Company completed the acquisitions of the Zebra WLAN Business, the Avaya Campus Fabric Business and the Brocade Data Center Business in October 2016, July 2017 and October 2017, respectively, and treats the acquisitions as an asset purchase from a tax perspective. The Company has estimated the value of the intangible assets from these transactions and is amortizing the amounts over 15 years for tax purposes.

[0001564590-19-033615:notes:331]
During the twelve months ended June 30, 2019, the Company deducted $7.7 million of tax amortization expense related to capitalized goodwill resulting from the above acquisitions.

[0001564590-19-033615:notes:332]
As of June 30, 2019, the Company had $17.2 million of unrecognized tax benefits.  If fully recognized in the future, there would be no impact to the effective tax rate, and $17.2 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance.  The Company does not reasonably expect the amount of unrealized tax benefits to decrease during the next twelve months. The decrease for fiscal year 2019 relates substantially to the expiration of unrealized R&D credits.

[0001564590-19-033615:notes:333]
A reconciliation of the beginning and ending amount of total unrecognized tax benefits is as follows (in thousands):

[0001564590-19-033615:notes:334]
| Balance at June 30, 2016 |  | $ | 11,653 |  |
| Increase related to prior year tax positions |  |  | 7,180 |  |
| Increase related to current year tax positions |  |  | 233 |  |
| Lapse of statute of limitations |  |  | (153 | ) |
| Balance at June 30, 2017 |  |  | 18,913 |  |
| Decrease related to prior year tax positions |  |  | (1,407 | ) |
| Balance at June 30, 2018 |  |  | 17,506 |  |
| Increase related to prior year tax positions |  |  | 26 |  |
| Lapse of statute of limitations |  |  | (364 | ) |
| Balance at June 30, 2019 |  | $ | 17,168 |  |

[0001564590-19-033615:notes:335]
Estimated interest and penalties related to the underpayment of income taxes, if any are classified as a component of tax expense in the consolidated statements of operations and totaled less than $0.1 million for each of the years ended 2019, 2018 and 2017.


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-033615:notes:336]
16. Net Loss Per Share

[0001564590-19-033615:notes:337]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, less shares subject to repurchase, and excludes any dilutive effects of options, warrants and unvested restricted stock. Dilutive earnings per share is calculated by dividing net income by the weighted average number of common shares used in the basic earnings per share calculation plus the dilutive effect of shares subject to options, warrants and unvested restricted stock.

[0001564590-19-033615:notes:338]
The following table presents the calculation of basic and diluted net loss per share (in thousands, except per share data):

[0001564590-19-033615:notes:339]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Net loss |  | $ | (25,853 | ) |  | $ | (46,792 | ) |  | $ | (1,744 | ) |
| Weighted-average shares used in per share calculation - basic and diluted |  |  | 117,954 |  |  |  | 114,221 |  |  |  | 108,273 |  |
| Net loss per share - basic and diluted |  | $ | (0.22 | ) |  | $ | (0.40 | ) |  | $ | (0.02 | ) |

[0001564590-19-033615:notes:340]
Potentially dilutive common shares from employee incentive plans are determined by applying the treasury stock method to the assumed exercise of outstanding stock options, the assumed vesting of outstanding restricted stock units, and the assumed issuance of common stock under the ESPP.  Weighted stock options outstanding with an exercise price higher than the Company's average stock price for the periods presented are excluded from the calculation of diluted net loss per share since the effect of including them would have been anti-dilutive due to the net loss position of the Company during the periods presented.

[0001564590-19-033615:notes:341]
The following securities were excluded from the computation of outstanding diluted earnings per common share because they would have been anti-dilutive (in thousands):

[0001564590-19-033615:notes:342]
|  |  |  |  |  |  | Year Ended |  |  |  |  |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Options to purchase common stock |  |  | 2,693 |  |  |  | 2,547 |  |  |  | — |  |
| Restricted stock units |  |  | 8,337 |  |  |  | 7,822 |  |  |  | 220 |  |
| Employee Stock Purchase Plan shares |  |  | 612 |  |  |  | 1,294 |  |  |  | — |  |
| Total shares excluded |  |  | 11,642 |  |  |  | 11,663 |  |  |  | 220 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-19-033615:notes:343]
17. Subsequent Event

[0001564590-19-033615:notes:344]
Aerohive Acquisition

[0001564590-19-033615:notes:345]
On August 9, 2019 (the “Closing Date”) the Company completed its acquisition of Aerohive Networks, Inc, (“Aerohive”) a publicly held network company for approximately $264 million in cash consideration and assumption of certain employee equity awards.

[0001564590-19-033615:notes:346]
The acquisition will be accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive will be recorded at their respective fair values and added to those of the Company including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of Aerohive will be included in the operations of the Company beginning with the Closing Date. As of the date of the filing of this Form 10-K, the initial purchase price allocation has not been prepared as there has not been sufficient time to complete the related activities.

[0001564590-19-033615:notes:347]
During the fiscal year ended June 30, 2019, the Company recognized related transaction costs of $0.8 million which is included in “Acquisition and integration costs” in the accompanying consolidated statements of operations.

[0001564590-19-033615:notes:348]
Borrowing Facility

[0001564590-19-033615:notes:349]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders,  BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0001564590-19-033615:notes:350]
The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”).  In addition, Extreme may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. In addition to funding a portion of the amount paid by the Company to acquire Aerohive, Extreme will use the proceeds of the 2019 Term Loan to pay off i) the Company’s existing 2018 Credit Agreement, ii) pay fees and expenses incurred in connection with the tender offer to acquire all of the outstanding shares of Aerohive’s common stock and iii) for working capital and general corporate purposes.
