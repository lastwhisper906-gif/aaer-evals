# EXTR note change history — 0001564590-19-001400 → 0001564590-19-018574


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-10):
[0001564590-19-018574:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2019, the Company had commitments to purchase $194.9 million of such inventory.  As of March 31, 2019, the Company had commitments to purchase $99.9 million of software and new product support services.
  (was, 2019-01-30, similarity 0.9823):
[0001564590-19-001400:note_history:1]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufactures to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the Company’s forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2018, the Company had commitments to purchase $172.6 million of such inventory.  As of December 31, 2018, the Company had commitments to purchase $111.6 million of software and new product support services.

- changed (2019-05-10):
[0001564590-19-018574:note_history:2]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.9 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of March 31, 2019.
  (was, 2019-01-30, similarity 0.9917):
[0001564590-19-001400:note_history:2]
On May 28, 2007, the Public Treasury Department of the State of Sao Paolo, Brazil (the “Tax Authority”) assessed the Company’s Brazilian subsidiary, Enterasys Networks do Brasil Ltda. (“Enterasys Brasil”), based on an alleged underpayment of taxes.  The Tax Authority also charged interest and penalties with respect to the assessment (collectively, the “ICMS Tax Assessment”).  The Tax Authority denied Enterasys Brasil the use of certain presumed tax credits granted by the State of Espirito Santo, Brazil under the terms of the FUNDAP program for the period from February 2003 to December 2004.  The value of the disallowed presumed tax credits is BRL 3.4 million (USD $0.8 million), excluding interest and penalties. All currency conversions in this Legal Proceedings section are as of December 31, 2018.

- changed (2019-05-10):
[0001564590-19-018574:note_history:3]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017, decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 19.9 million (USD $5.2 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of March 31, 2019.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.
  (was, 2019-01-30, similarity 0.9959):
[0001564590-19-001400:note_history:3]
Unable to resolve the matter at the administrative level, on October 1, 2014, Enterasys Brasil filed a lawsuit in the 11th Public Treasury Court of the Sao Paolo State Court of Justice (Judiciary District of Sao Paolo) to overturn or reduce the ICMS Tax Assessment. As part of this lawsuit, Enterasys Brasil requested a stay of execution, so that no tax foreclosure could be filed and no guarantee would be required until the court issued its final ruling.  On or about October 6, 2014, the court granted a preliminary injunction staying any execution on the assessment, but requiring that Enterasys Brasil deposit the assessed amount with the court.  Enterasys Brasil appealed this ruling and, on or about January 28, 2015, the appellate court ruled that no cash deposit (or guarantee) was required.  In a decision dated August 28, 2017, and published on October 3, 2017, the court validated the assessment and penalty imposed by the Tax Authority but ruled that the Tax Authority was charging an unlawfully high interest rate on the tax assessment and penalty amounts and ordered the interest rate reduced to the maximum Federal rate. The August 28, 2017 decision, were it to become final, would require Enterasys Brasil to pay a total of BRL 19.6 million (USD $4.8 million), which includes penalties, court costs, attorneys’ fees, and accrued interest as of December 31, 2018.  The Company believes the ICMS Tax Assessment against Enterasys Brasil is without merit and has appealed the lower court’s decision.  The appellate court ruled that no cash deposit (or guarantee) is required during the pendency of the appeal.

- changed (2019-05-10):
[0001564590-19-018574:note_history:4]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013, through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018, Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties have agreed to settle the litigation.   On November 30, 2018, plaintiffs filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition. The preliminary hearing took place on March 7, 2019, and the final hearing is scheduled for June 20, 2019.
  (was, 2019-01-30, similarity 0.9587):
[0001564590-19-001400:note_history:4]
On October 23 and 29, 2015, punitive class action complaints alleging violations of securities laws were filed in the U.S. District Court for the Northern District of California against the Company and three of its former officers (Charles W. Berger, Kenneth B. Arola, and John T. Kurtzweil).  Subsequently, the cases were consolidated (In re Extreme Networks, Inc. Securities Litigation, No. 3:15-CY-04883-BLF).  Plaintiffs allege that defendants violated the securities laws by disseminating materially false and misleading statements and concealing material adverse facts regarding the Company’s financial condition, business operations and growth prospects. Plaintiffs seek unspecified damages on behalf of a purported class of investors who purchased the Company’s common stock from September 12, 2013 through April 9, 2015.  On June 28, 2016, the Court appointed a lead plaintiff.  On September 26, 2016, the lead plaintiff filed a consolidated complaint. On November 10, 2016, defendants filed a motion to dismiss, which the Court granted with leave to amend on April 27, 2017.  On June 2, 2017, the lead plaintiff filed an amended complaint, which, on July 10, 2017, defendants again moved to dismiss.  In a March 21, 2018 Order (the “March 2018 Order”), the Court granted in part and denied in part the defendants’ motion. The March 2018 Order narrowed the scope of the case, but allowed certain claims to proceed.  The parties have agreed to settle the litigation.   On November 30, 2018, plaintiffs filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition.  The motion presently is set for hearing on April 25, 2019

- changed (2019-05-10):
[0001564590-19-018574:note_history:5]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended. The parties agreed to settle the litigation.  On May 3, 2019, the Court gave final approval to the settlement and entered judgment terminating the case.
  (was, 2019-01-30, similarity 0.7146):
[0001564590-19-001400:note_history:5]
On February 18, 2016, a shareholder derivative case was filed in the Superior Court of California, Santa Clara County (Shaffer v. Kispert et al., No. 16 CV 291726).  The complaint names current and former officers and directors as defendants, and seeks recovery on behalf of the Company based on substantially the same allegations as the securities class action litigation described above.  As a result of the March 2018 Order, the stipulated stay of the derivative litigation ended.  The parties have agreed to settle the litigation.  On November 26, 2018, plaintiff filed an unopposed motion for preliminary approval of the settlement, and on December 6, 2018, Extreme filed a statement of non-opposition. On January 18, 2019 the Court entered an order granting preliminary approval of the settlement and approving the notice to shareholders. The Court set the final approval hearing for May 3, 2019.

- changed (2019-05-10):
[0001564590-19-018574:note_history:6]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date). During a status conference on February 11, 2019, the Court continued the stay and set a status conference for December 2, 2019. The Company believes the claims are without merit and intends to defend them vigorously.
  (was, 2019-01-30, similarity 0.9905):
[0001564590-19-001400:note_history:6]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California (XR Communications, LLC, dba Vivato Technologies v. Extreme Networks, Inc., No. 2:17-cv-2953-AG).  The operative Second Amended Complaint asserts infringement of U.S. Patent Nos. 7,062,296, 7,729,728, and 6,611,231 based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees (but no injunction).  In orders dated April 10 and May 22, 2018, the Court stayed the case pending a resolution by the Patent Trial and Appeal Board (“PTAB”) of inter partes review (IPR) petitions filed by several defendants in other XR-related patent lawsuits challenging the validity of the asserted patents.  The PTAB has now instituted IPR proceedings as to all three patents and all patent claims asserted in the litigation. Given the stay, the Court took off calendar all previously scheduled events (including a Markman hearing and potential trial date). During a status conference on October 22, 2018, the Court continued the stay and set a status conference for February 11, 2019. The Company believes the claims are without merit and intends to defend them vigorously.

- added (2019-05-10):
[0001564590-19-018574:note_history:7]
Global Innovation Aggregators, LLC v. Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co., Ltd

- added (2019-05-10):
[0001564590-19-018574:note_history:8]
In January 2019, Global Innovation Aggregators, LLC (“GIA”) filed six lawsuits alleging patent infringement against Extreme Networks, Inc.; Extreme Networks China Limited; Extreme Networks Technology (Beijing) Co., Ltd.; and Shenzhen Yingzhixiang Technology Co., Ltd. in Shenzhen Intermediate People’s Court in China. The six patents at issue are ZL200610168028.1, ZL200510120823.9, ZL200410057124.X, ZL200410070933.4, ZL200510103486.2, and ZL200610060686.9. The products at issue include the Summit X440-G2 series, X450-G2 series, X460-G2 series, X620 series, X670-G2 series, X770 series, X870 series, X690 series, and X590 series. GIA is a U.S. entity established under the laws of Delaware with its principal office in Pasadena, California. Extreme disputes GIA’s claims and intends to defend them vigorously.

- changed (2019-05-10):
[0001564590-19-018574:note_history:9]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of March 31, 2019, the Company has the outstanding indemnification claims described above.
  (was, 2019-01-30, similarity 0.9955):
[0001564590-19-001400:note_history:9]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals' reasonable legal expenses and possibly damages and other liabilities incurred in connection with certain legal matters. For example, the Company currently is paying or reimbursing legal expenses being incurred by certain current and former officers and directors in connection with the shareholder litigation described above.  The Company also procures Directors and Officers insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these indemnification agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows. As of December 31, 2018, the Company has the outstanding indemnification claims described above.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-10):
[0001564590-19-018574:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2019. The results of operations for the three and nine months ended March 31, 2019 are not necessarily indicative of the results that may be expected for fiscal 2019 or any future periods.
  (was, 2019-01-30, similarity 0.9404):
[0001564590-19-001400:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2018. The results of operations for the three and six months ended December 31, 2018 are not necessarily indicative of the results that may be expected for fiscal 2019 or any future periods.

- changed (2019-05-10):
[0001564590-19-018574:note_history:11]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local functional currency environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.
  (was, 2019-01-30, similarity 0.9557):
[0001564590-19-001400:note_history:11]
The Company predominantly uses the United States Dollar as its functional currency.  The functional currency for certain of its foreign subsidiaries is the local currency.  For those subsidiaries that operate in a local currency functional environment, all assets and liabilities are translated to United States Dollars at current month end rates of exchange; and revenue and expenses are translated using the monthly average rate.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-05-10):
[0001564590-19-018574:note_history:12]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees and lessors. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. Topic 842 is applied on the modified retrospective method through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. In addition, in December 2018 and March 2019, the FASB issued ASU No. 2018-20, Leases (Topic 842) and ASU No. 2019-01, Leases (Topic 842), respectively, which includes narrow-scope improvements for lessors to increase transparency and comparability about leasing transactions and addresses lessor implementation issues and clarifies that lessees and lessors are exempt from certain interim disclosure requirements. This guidance will become effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019. The Company‘s evaluation of the new standards are underway, and significant changes from the current guidance have been identified. The Company expects to elect certain available transitional guidance. The Company also currently expects to elect the short-term lease recognition exemption for all leases that qualify. This means, for those leases that qualify, the Company will not recognize right-of-use (“ROU”) assets or lease liabilities, and this includes not recognizing ROU assets or lease liabilities for existing short-term leases of those assets in transition. In addition, the Company currently expects to elect the practical expedient to not separate lease and non-lease components for leases of vehicles and equipment. The Company has selected, and is in the process of implementing and testing a new lease accounting system and validating its results. While the Company continues to evaluate the effect of adopting Topic 842, it expects that these new standards will have a material impact to the Company’s financial position. The Company will recognize ROU assets and lease liabilities on the consolidated balance sheets with corresponding ROU assets at the same amount as the lease liability based on the present value of the remaining minimum rental payments under current leasing standards for existing operating leases. The Company does not expect that the adoption of Topic 842 will have a material effect on operating income (loss) and net cash flows, however it will impact the classification between cash flows from operations and cash flows from financing activities.

- changed (2019-05-10):
[0001564590-19-018574:note_history:13]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (“OIS”) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The Company is continuing to evaluate the accounting, transition and disclosure requirements of these standards, but does not believe it will have a material impact on the Company’s financial statements upon adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.
  (was, 2019-01-30, similarity 0.9969):
[0001564590-19-001400:note_history:13]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities, which is intended to allow companies to better align risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and the presentation of hedge results by expanding and refining hedge accounting for both nonfinancial and financial risk components and aligning the recognition and presentation of the effects of the hedging instrument and the hedged item in the financial statements. In addition, in October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815), which amends Topic 815 to add the overnight index swap (OIS) rate based on the secured overnight financing rate as a fifth U.S. benchmark interest rate. These standards are effective for interim and annual reporting periods beginning after December 15, 2018. The Company is continuing to evaluate the accounting, transition and disclosure requirements of these standards, but does not believe it will have a material impact on the Company’s financial statements upon adoption. This guidance is effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.

- removed (2019-05-10):
[0001564590-19-001400:note_history:14]
In February 2016, the FASB issued ASU No. 2016-02, Leases (Topic 842), which requires the identification of arrangements that should be accounted for as leases by lessees. In general, for lease arrangements exceeding a twelve-month term, these arrangements must now be recognized as assets and liabilities on the balance sheet of the lessee. Under Topic 842, a right-of-use asset and lease obligation will be recorded for all leases, whether operating or financing, while the statement of operations will reflect lease expense for operating leases and amortization/interest expense for financing leases. The balance sheet amount recorded for existing leases at the date of adoption of Topic 842 must be calculated using the applicable incremental borrowing rate at the date of adoption. In addition, Topic 842 is applied on the modified retrospective method through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company is currently assessing the impact that adopting this new accounting standard will have on its consolidated financial statements and footnote disclosures.  The Company believes that Topic 842 will have a material impact on its financial position, as a result of recognizing right-of-use assets and lease liabilities on its consolidated balance sheets. In addition, in December 2018, the FASB issued ASU No. 2018-20, Leases (Topic 842), which includes narrow-scope improvements for lessors to increase transparency and comparability about leasing transactions. The Company continues to evaluate the impact these new standards will have on its condensed consolidated statement of operations and statement of cash flows. This guidance will become effective for the Company beginning with its fiscal year 2020, beginning on July 1, 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-10):
[0001564590-19-018574:note_history:15]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 173,375 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,382 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 171,993 |  |  |  | 188,749 |  |
| Total debt |  | $ | 181,002 |  |  | $ | 197,756 |  |
  (was, 2019-01-30, similarity 0.9886):
[0001564590-19-001400:note_history:15]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 175,750 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,504 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 174,246 |  |  |  | 188,749 |  |
| Total debt |  | $ | 183,255 |  |  | $ | 197,756 |  |

- changed (2019-05-10):
[0001564590-19-018574:note_history:16]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the Credit Agreement.  Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.2 million for each of the three months ended March 31, 2019 and 2018 and totaled $0.5 million for each of the nine months ended March 31, 2019 and 2018, respectively.
  (was, 2019-01-30, similarity 0.9304):
[0001564590-19-001400:note_history:16]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the Credit Agreement.  Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations totaled $0.2 million for each of the three months ended December 31, 2018 and 2017 and totaled $0.3 million for each of the six months ended December 31, 2018 and 2017, respectively.

- changed (2019-05-10):
[0001564590-19-018574:note_history:17]
The Company had $35.5 million of availability under the New Revolving Facility as of March 31, 2019.  The Company had $4.5 million of outstanding letters of credit as of March 31, 2019.
  (was, 2019-01-30, similarity 0.9471):
[0001564590-19-001400:note_history:17]
The Company had $39.0 million of availability under the New Revolving Facility as of December 31, 2018.  The Company had $1.0 million of outstanding letters of credit as of December 31, 2018.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-10):
[0001564590-19-018574:note_history:18]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 173,375 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,382 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 171,993 |  |  |  | 188,749 |  |
| Total debt |  | $ | 181,002 |  |  | $ | 197,756 |  |
  (was, 2019-01-30, similarity 0.9886):
[0001564590-19-001400:note_history:18]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 9,500 |  |  | $ | 9,500 |  |
| Less: unamortized debt issuance costs |  |  | (491 | ) |  |  | (493 | ) |
| Current portion of long-term debt |  | $ | 9,009 |  |  | $ | 9,007 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 175,750 |  |  | $ | 180,500 |  |
| Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,504 | ) |  |  | (1,751 | ) |
| Total long-term debt, less current portion |  |  | 174,246 |  |  |  | 188,749 |  |
| Total debt |  | $ | 183,255 |  |  | $ | 197,756 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-10):
[0001564590-19-018574:note_history:19]
|  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |
| Other |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |
| Total Americas |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |
| EMEA |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |
| APAC |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |
| Total net revenues |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |
  (was, 2019-01-30, similarity 0.9665):
[0001564590-19-001400:note_history:19]
|  |  | Three Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |
| Other |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |
| Total Americas |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |
| EMEA |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |
| APAC |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |
| Total net revenues |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |

- changed (2019-05-10):
[0001564590-19-018574:note_history:20]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |
| Other |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |
| Total Americas |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |
| EMEA |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |
| APAC: |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |
| Total net revenues |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |
  (was, 2019-01-30, similarity 0.9242):
[0001564590-19-001400:note_history:20]
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |
| Other |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |
| Total Americas |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |
| EMEA |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |
| APAC: |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |
| Total net revenues |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-10):
[0001564590-19-018574:note_history:21]
The Company accounts for revenue in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606), which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

- changed (2019-05-10):
[0001564590-19-018574:note_history:22]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenue is recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2019-01-30, similarity 0.8509):
[0001564590-19-001400:note_history:22]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and six months ended December 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2019-05-10):
[0001564590-19-018574:note_history:23]
On March 31, 2019, the Company had $187.7 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 29 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 49 percent in fiscal 2020 and 22 percent of the balance thereafter.
  (was, 2019-01-30, similarity 0.9819):
[0001564590-19-001400:note_history:23]
On December 31, 2018, the Company had $186.1 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 48 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 35 percent in fiscal 2020 and 17 percent of the balance thereafter.

- changed (2019-05-10):
[0001564590-19-018574:note_history:24]
Revenue recognized for the three months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $54.8 million and $50.6 million, respectively. Revenue recognized for the nine months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $110.8 million and $66.7 million, respectively.
  (was, 2019-01-30, similarity 0.9194):
[0001564590-19-001400:note_history:24]
Revenue recognized for the three months ended December 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $59.9 million and $36.9 million, respectively. Revenue recognized for the six months ended December 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $88.8 million and $52.9 million, respectively.

- changed (2019-05-10):
[0001564590-19-018574:note_history:25]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $5.6 million and $4.3 million at March 31, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2019 and 2018, was $0.8 million and $0.5 million, respectively.  Amortization recognized during the nine months ended March 31, 2019 and 2018 was $2.2 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.
  (was, 2019-01-30, similarity 0.8867):
[0001564590-19-001400:note_history:25]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s capitalized balances in the amount of $5.3 million and $3.2 million at December 31, 2018 and 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended December 31, 2018 and 2017, was $0.7 million and $0.5 million, respectively.  Amortization recognized during the six months ended December 31, 2018 and 2017 was $1.4 million and $0.9 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2019-05-10):
[0001564590-19-018574:note_history:26]
|  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |
| Other |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |
| Total Americas |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |
| EMEA |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |
| APAC |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |
| Total net revenues |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |
  (was, 2019-01-30, similarity 0.9665):
[0001564590-19-001400:note_history:26]
|  |  | Three Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |
| Other |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |
| Total Americas |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |
| EMEA |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |
| APAC |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |
| Total net revenues |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |

- changed (2019-05-10):
[0001564590-19-018574:note_history:27]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |
| Other |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |
| Total Americas |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |
| EMEA |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |
| APAC: |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |
| Total net revenues |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |
  (was, 2019-01-30, similarity 0.9242):
[0001564590-19-001400:note_history:27]
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |
| Other |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |
| Total Americas |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |
| EMEA |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |
| APAC: |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |
| Total net revenues |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |

- changed (2019-05-10):
[0001564590-19-018574:note_history:28]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Tech Data Corporation |  | 14% |  |  | 14% |  |  | 17% |  |  | 13% |  |
| Westcon Group Inc. |  | 12% |  |  | 14% |  |  | 13% |  |  | 14% |  |
| Jenne Corporation |  | 21% |  |  | 13% |  |  | 15% |  |  | 11% |  |
  (was, 2019-01-30, similarity 0.7204):
[0001564590-19-001400:note_history:28]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Tech Data Corporation |  | 22% |  |  | 12% |  |  | 19% |  |  | 12% |  |
| Westcon Group Inc. |  | 15% |  |  | 14% |  |  | 14% |  |  | 15% |  |
| Jenne Corporation |  | 12% |  |  | * |  |  | 12% |  |  | 10% |  |

- changed (2019-05-10):
[0001564590-19-018574:note_history:29]
|  |  | March 31, 2019 |  |  | June 30, 2018 |  |
| Westcon Group Inc. |  | 10% |  |  | * |  |
| Tech Data Corporation |  | * |  |  | 17% |  |
| Jenne Corporation |  | 31% |  |  | 13% |  |
| * Less than 10% of accounts receivable |  |  |  |  |  |  |  |  |
  (was, 2019-01-30, similarity 0.7898):
[0001564590-19-001400:note_history:29]
|  |  | December 31, 2018 |  |  | June 30, 2018 |  |
| Westcon Group Inc. |  | 23% |  |  | * |  |
| Tech Data Corporation |  | 22% |  |  | 17% |  |
| Jenne Corporation |  | * |  |  | 13% |  |
| * Less than 10% of accounts receivable |  |  |  |  |  |  |  |  |

- removed (2019-05-10):
[0001564590-19-001400:note_history:30]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers, which the Company adopted on July 1, 2017, using the retrospective method.  The Company derives the majority of its revenue from sales of its networking equipment, with the remaining revenue generated from service fees primarily relating to maintenance contracts with additional revenues from professional services, and training for its products. The Company sells its products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-10):
[0001564590-19-018574:note_history:31]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenue is recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.
  (was, 2019-01-30, similarity 0.8509):
[0001564590-19-001400:note_history:31]
The Company’s performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of the Company’s product sales revenues as reflected on the condensed consolidated statements of operations for the three and six months ended December 31, 2018 and 2017 are recognized at a point in time. Substantially all of the Company’s service revenue is recognized over time.  For revenue recognized over time, the Company uses an input measure, days elapsed, to measure progress.

- changed (2019-05-10):
[0001564590-19-018574:note_history:32]
On March 31, 2019, the Company had $187.7 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 29 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 49 percent in fiscal 2020 and 22 percent of the balance thereafter.
  (was, 2019-01-30, similarity 0.9819):
[0001564590-19-001400:note_history:32]
On December 31, 2018, the Company had $186.1 million of remaining performance obligations, which is comprised of deferred maintenance revenue and services not yet delivered.  The Company expects to recognize approximately 48 percent of its remaining performance obligations as revenue in fiscal 2019, an additional 35 percent in fiscal 2020 and 17 percent of the balance thereafter.

- changed (2019-05-10):
[0001564590-19-018574:note_history:33]
Revenue recognized for the three months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $54.8 million and $50.6 million, respectively. Revenue recognized for the nine months ended March 31, 2019 and 2018 that was included in the deferred revenue balance at the beginning of each period was $110.8 million and $66.7 million, respectively.
  (was, 2019-01-30, similarity 0.9194):
[0001564590-19-001400:note_history:33]
Revenue recognized for the three months ended December 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $59.9 million and $36.9 million, respectively. Revenue recognized for the six months ended December 31, 2018 and 2017 that was included in the deferred revenue balance at the beginning of each period was $88.8 million and $52.9 million, respectively.

- changed (2019-05-10):
[0001564590-19-018574:note_history:34]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representatives as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s consolidated balance sheets included capitalized balances in the amount of $5.6 million and $4.3 million at March 31, 2019 and June 30, 2018, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended March 31, 2019 and 2018, was $0.8 million and $0.5 million, respectively.  Amortization recognized during the nine months ended March 31, 2019 and 2018 was $2.2 million and $1.4 million, respectively. There was no impairment loss in relation to the costs capitalized.
  (was, 2019-01-30, similarity 0.8867):
[0001564590-19-001400:note_history:34]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore the Company’s capitalized balances in the amount of $5.3 million and $3.2 million at December 31, 2018 and 2017, respectively.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations.  Amortization recognized during the three months ended December 31, 2018 and 2017, was $0.7 million and $0.5 million, respectively.  Amortization recognized during the six months ended December 31, 2018 and 2017 was $1.4 million and $0.9 million, respectively. There was no impairment loss in relation to the costs capitalized.

- changed (2019-05-10):
[0001564590-19-018574:note_history:35]
|  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 72,071 |  | $ | 56,096 |  | $ | 128,167 |  |  | $ | 76,392 |  | $ | 56,929 |  | $ | 133,321 |  |
| Other |  |  | 4,930 |  |  | 5,589 |  |  | 10,519 |  |  |  | 4,288 |  |  | 6,165 |  |  | 10,453 |  |
| Total Americas |  |  | 77,001 |  |  | 61,685 |  |  | 138,686 |  |  |  | 80,680 |  |  | 63,094 |  |  | 143,774 |  |
| EMEA |  |  | 48,834 |  |  | 35,076 |  |  | 83,910 |  |  |  | 58,668 |  |  | 36,120 |  |  | 94,788 |  |
| APAC |  |  | 4,850 |  |  | 23,418 |  |  | 28,268 |  |  |  | 3,085 |  |  | 20,357 |  |  | 23,442 |  |
| Total net revenues |  | $ | 130,685 |  | $ | 120,179 |  | $ | 250,864 |  |  | $ | 142,433 |  | $ | 119,571 |  | $ | 262,004 |  |
  (was, 2019-01-30, similarity 0.9665):
[0001564590-19-001400:note_history:35]
|  |  | Three Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 44,141 |  | $ | 55,326 |  | $ | 99,467 |  |  | $ | 56,269 |  | $ | 54,559 |  | $ | 110,828 |  |
| Other |  |  | 8,269 |  |  | 5,380 |  |  | 13,649 |  |  |  | 1,155 |  |  | 5,698 |  |  | 6,853 |  |
| Total Americas |  |  | 52,410 |  |  | 60,706 |  |  | 113,116 |  |  |  | 57,424 |  |  | 60,257 |  |  | 117,681 |  |
| EMEA |  |  | 79,876 |  |  | 32,773 |  |  | 112,649 |  |  |  | 55,956 |  |  | 33,624 |  |  | 89,580 |  |
| APAC |  |  | 4,767 |  |  | 22,148 |  |  | 26,915 |  |  |  | 5,131 |  |  | 18,731 |  |  | 23,862 |  |
| Total net revenues |  | $ | 137,053 |  | $ | 115,627 |  | $ | 252,680 |  |  | $ | 118,511 |  | $ | 112,612 |  | $ | 231,123 |  |

- changed (2019-05-10):
[0001564590-19-018574:note_history:36]
|  |  | Nine Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 172,752 |  | $ | 171,359 |  | $ | 344,111 |  |  | $ | 181,415 |  | $ | 160,484 |  | $ | 341,899 |  |
| Other |  |  | 17,893 |  |  | 16,494 |  |  | 34,387 |  |  |  | 13,417 |  |  | 20,252 |  |  | 33,669 |  |
| Total Americas |  |  | 190,645 |  |  | 187,853 |  |  | 378,498 |  |  |  | 194,832 |  |  | 180,736 |  |  | 375,568 |  |
| EMEA |  |  | 190,041 |  |  | 98,687 |  |  | 288,728 |  |  |  | 165,856 |  |  | 97,647 |  |  | 263,503 |  |
| APAC: |  |  | 11,967 |  |  | 64,237 |  |  | 76,204 |  |  |  | 11,480 |  |  | 54,291 |  |  | 65,771 |  |
| Total net revenues |  | $ | 392,653 |  | $ | 350,777 |  | $ | 743,430 |  |  | $ | 372,168 |  | $ | 332,674 |  | $ | 704,842 |  |
  (was, 2019-01-30, similarity 0.9242):
[0001564590-19-001400:note_history:36]
|  |  | Six Months Ended |  |
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 100,883 |  | $ | 115,262 |  | $ | 216,145 |  |  | $ | 98,661 |  | $ | 105,549 |  | $ | 204,210 |  |
| Other |  |  | 12,762 |  |  | 10,904 |  |  | 23,666 |  |  |  | 15,491 |  |  | 12,093 |  |  | 27,584 |  |
| Total Americas |  |  | 113,645 |  |  | 126,166 |  |  | 239,811 |  |  |  | 114,152 |  |  | 117,642 |  |  | 231,794 |  |
| EMEA |  |  | 141,207 |  |  | 63,611 |  |  | 204,818 |  |  |  | 107,188 |  |  | 61,527 |  |  | 168,715 |  |
| APAC: |  |  | 7,116 |  |  | 40,821 |  |  | 47,937 |  |  |  | 8,395 |  |  | 33,934 |  |  | 42,329 |  |
| Total net revenues |  | $ | 261,968 |  | $ | 230,598 |  | $ | 492,566 |  |  | $ | 229,735 |  | $ | 213,103 |  | $ | 442,838 |  |
