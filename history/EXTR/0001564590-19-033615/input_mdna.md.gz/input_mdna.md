# EXTR MD&A — 0001564590-19-033615


## mdna

[0001564590-19-033615:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001564590-19-033615:mdna:2]
Business Overview

[0001564590-19-033615:mdna:3]
The following discussion should be read with the Consolidated Financial Statements and the related notes in Item 8 of Part II of this Report.

[0001564590-19-033615:mdna:4]
The following discussion is based upon our Consolidated Financial Statements included elsewhere in this Report, which have been prepared in accordance with U.S. generally accepted accounting principles, or U.S. GAAP.  In the course of operating our business, we routinely make decisions as to the timing of the payment of invoices, the collection of receivables, the manufacturing and shipment of products, the fulfillment of orders, the purchase of supplies, and the building of inventory and service parts, among other matters. Each of these decisions has some impact on the financial results for any given period.  In making these decisions, we consider various factors including contractual obligations, customer satisfaction, competition, internal and external financial targets and expectations, and financial planning objectives. For further information about our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” section included in this “Management's Discussion and Analysis of Financial Condition and Results of Operations.”

[0001564590-19-033615:mdna:5]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” and as “we”, “us” and “our”) is a leading provider of networking software, hardware and services and offers related maintenance contracts for extended warranty and maintenance to our enterprise, data center and service provider customers.  We were incorporated in California in May 1996 and reincorporated in Delaware in March 1999.  Our corporate headquarters are located in San Jose, California.  We derive substantially all of our revenue from the sale of our networking software, hardware and services, and related maintenance contracts.

[0001564590-19-033615:mdna:6]
Extreme is a leader in providing software-driven networking solutions for enterprise customers. Providing a combined end-to-end solution from enterprise edge to the cloud, Extreme designs, develops and manufactures wired and wireless network infrastructure equipment and develops the software for network management, policy, analytics, security and access controls. Extreme gives customers and partners the power to mix and match this broad array of software, hardware, and services (including third-party applications) to tailor a solution that can be managed and automated from end-to-end, and calls this customizable portfolio Extreme ElementsTM.

[0001564590-19-033615:mdna:7]
Enterprise network administrators need to respond to the rapid digital transformational trends of cloud, mobility, big data, social business and the ever-present need for network security.  Accelerators such as Internet of Things (“IoT”), artificial intelligence (“AI”), bring your own device (“BYOD”), machine learning, cognitive computing, and robotics add complexity to challenge the capabilities of traditional networks. Technology advances have a profound effect across the entire enterprise network placing unprecedented demands on network administrators to enhance management capabilities, scalability, programmability, agility, and analytics of the enterprise networks they manage.

[0001564590-19-033615:mdna:8]
A trend affecting the Enterprise Network Equipment market is the continued adoption of the cloud-managed enterprise WLAN in the enterprise market. Hybrid cloud is a cloud computing environment which uses a mix of on-premises, private cloud, and third-party, public cloud services with orchestration between the two platforms. We introduced our Cloud offering in 2016 and in August 2019 acquired Aerohive Networks, Inc to enhance our Cloud strategy with a 3rd generation Cloud platform and to accelerate adoption of hybrid cloud networking solutions in the Enterprise. Extreme’s enhanced Cloud solution will be the only offering in the market that seamlessly integrates the cloud with on-premises infrastructures and enables visibility from the edge to everywhere. See Part 1, Item 1. Business, for additional discussion of our business.

[0001564590-19-033615:mdna:9]
Acquisition

[0001564590-19-033615:mdna:10]
Aerohive Networks, Inc

[0001564590-19-033615:mdna:11]
On August 9, 2019  (the “Closing Date”) the Company completed its acquisition of Aerohive, a publicly held network company, for approximately $264 million in cash consideration and assumption of certain employee equity awards.

[0001564590-19-033615:mdna:12]
The business combination was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Aerohive are recorded at their respective fair values and added to those of ours including an amount for goodwill representing the difference between the acquisition consideration and the fair value of the identifiable net assets.  Results of operations of Aerohive are included in our operations beginning with the Closing Date.

[0001564590-19-033615:mdna:13]
During the fiscal year ended June 30, 2019, the Company recognized related transaction costs of $0.8 million which is included in “Acquisition and integration costs” in the accompanying condensed consolidated statements of operations.

[0001564590-19-033615:mdna:14]
Results of Operations

[0001564590-19-033615:mdna:15]
Following is a summary of our results of operations during fiscal year ended June 30, 2019:

[0001564590-19-033615:mdna:16]
|  | • | Net revenue of $995.8 million, increased 1.3% from fiscal 2018 net revenue of $983.1 million. |

[0001564590-19-033615:mdna:17]
|  | • | Product revenue of $747.6 million, decreased 2.2% from fiscal 2018 product revenue of $764.5 million. |

[0001564590-19-033615:mdna:18]
|  | • | Service revenue of $248.2 million, increased 13.5% from fiscal 2018 service revenue of $218.7 million. |

[0001564590-19-033615:mdna:19]
|  | • | Total gross margin of 55.4% of net revenue in fiscal 2019, compared to 54.4% in fiscal 2018. |

[0001564590-19-033615:mdna:20]
|  | • | Operating loss of $14.7 million, compared to operating loss of $38.2 million in fiscal 2018. |

[0001564590-19-033615:mdna:21]
|  | • | Net loss was $25.9 million in fiscal 2019, compared to a net loss of $46.8 million in fiscal 2018. |

[0001564590-19-033615:mdna:22]
|  | • | Cash flow provided by operating activities of $104.9 million, compared to cash flow provided by operating activities of $19.0 million in fiscal 2018, an increase of $85.9 million. Cash was $169.6 million as of June 30, 2019, an increase of $48.5 million compared to the end of fiscal 2018. |

[0001564590-19-033615:mdna:23]
Net Revenues

[0001564590-19-033615:mdna:24]
The following table presents net product and service revenue for the fiscal year ended June 30, 2019 , 2018 and 2017 (dollars in thousands):

[0001564590-19-033615:mdna:25]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |
| Net Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 747,571 |  |  | $ | 764,455 |  |  | $ | (16,884 | ) |  |  | (2.2 | )% |  | $ | 764,455 |  |  | $ | 460,425 |  |  | $ | 304,030 |  |  |  | 66.0 | % |
| Percentage of net revenue |  |  | 75.1 | % |  |  | 77.8 | % |  |  |  |  |  |  |  |  |  |  | 77.8 | % |  |  | 75.8 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 248,218 |  |  |  | 218,687 |  |  |  | 29,531 |  |  |  | 13.5 | % |  |  | 218,687 |  |  |  | 146,659 |  |  |  | 72,028 |  |  |  | 49.1 | % |
| Percentage of net revenue |  |  | 24.9 | % |  |  | 22.2 | % |  |  |  |  |  |  |  |  |  |  | 22.2 | % |  |  | 24.2 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 995,789 |  |  | $ | 983,142 |  |  | $ | 12,647 |  |  |  | 1.3 | % |  | $ | 983,142 |  |  | $ | 607,084 |  |  | $ | 376,058 |  |  |  | 61.9 | % |

[0001564590-19-033615:mdna:26]
Product revenue decreased $16.9 million or 2.2% for the year ended June 30, 2019, compared to the corresponding period of fiscal 2018. The decrease in product revenues was driven primarily by a lower overall volume of sales in the Americas attributed to our Data Center Business, but with strengthening sales in our Federal and OEM Data Center sectors. To a lesser extent, there was a modest decrease in product revenue in APAC, and revenue remained consistent in the EMEA region.

[0001564590-19-033615:mdna:27]
Product revenue increased $304.0 million or 66.0% for the year ended June 30, 2018, compared to the corresponding period of fiscal 2017. The increase in product revenues was attributable to growth related to the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses and to a lesser extent, organic growth of legacy revenues.

[0001564590-19-033615:mdna:28]
Service revenue increased $29.5 million or 13.5% for the year ended June 30, 2019, compared to the corresponding period of fiscal 2018. The increase in service revenue was driven primarily by growth across all regions owing to a higher number of maintenance contracts related to the Data Center Business acquisition.

[0001564590-19-033615:mdna:29]
Service revenue increased $72.0 million or 49.1% for the year ended June 30, 2018, compared to the corresponding period of fiscal 2017. The increase in service revenue was due to the increased number of service contracts acquired as a result of the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses.

[0001564590-19-033615:mdna:30]
We operate in three regions: Americas, which includes the United States, Canada, Mexico, Central America and South America; EMEA, which includes Europe, Russia, Middle East, and Africa; and APAC which includes Asia Pacific, South Asia, Japan and Australia. The following table presents the total net revenue geographically for the fiscal years 2019, 2018 and 2017 (dollars in thousands):

[0001564590-19-033615:mdna:31]
|  |  | Year Ended |  |  | Year Ended |  |
| Net Revenues |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 498,705 |  |  | $ | 491,617 |  |  | $ | 7,088 |  |  |  | 1.4 | % |  | $ | 491,617 |  |  | $ | 307,980 |  |  | $ | 183,637 |  |  |  | 59.6 | % |
| Other |  |  | 42,896 |  |  |  | 44,688 |  |  |  | (1,792 | ) |  |  | (4.0 | )% |  |  | 44,688 |  |  |  | 24,883 |  |  |  | 19,805 |  |  |  | 79.6 | % |
| Total Americas |  |  | 541,601 |  |  |  | 536,305 |  |  |  | 5,296 |  |  |  | 1.0 | % |  |  | 536,305 |  |  |  | 332,863 |  |  |  | 203,442 |  |  |  | 61.1 | % |
| Percentage of net revenue |  |  | 54.4 | % |  |  | 54.6 | % |  |  |  |  |  |  |  |  |  |  | 54.6 | % |  |  | 54.8 | % |  |  |  |  |  |  |  |  |
| EMEA |  |  | 358,327 |  |  |  | 354,746 |  |  |  | 3,581 |  |  |  | 1.0 | % |  |  | 354,746 |  |  |  | 220,072 |  |  |  | 134,674 |  |  |  | 61.2 | % |
| Percentage of net revenue |  |  | 36.0 | % |  |  | 36.1 | % |  |  |  |  |  |  |  |  |  |  | 36.1 | % |  |  | 36.3 | % |  |  |  |  |  |  |  |  |
| APAC |  |  | 95,861 |  |  |  | 92,091 |  |  |  | 3,770 |  |  |  | 4.1 | % |  |  | 92,091 |  |  |  | 54,149 |  |  |  | 37,942 |  |  |  | 70.1 | % |
| Percentage of net revenue |  |  | 9.6 | % |  |  | 9.4 | % |  |  |  |  |  |  |  |  |  |  | 9.4 | % |  |  | 8.9 | % |  |  |  |  |  |  |  |  |
| Total net revenues |  | $ | 995,789 |  |  | $ | 983,142 |  |  | $ | 12,647 |  |  |  | 1.3 | % |  | $ | 983,142 |  |  | $ | 607,084 |  |  | $ | 376,058 |  |  |  | 61.9 | % |

[0001564590-19-033615:mdna:32]
We rely upon multiple channels of distribution, including distributors, direct resellers, OEMs and direct sales.  Revenue through our distributor channel was 70% of total product revenue in fiscal 2019, 69% of total product revenue in fiscal 2018 and 66% in fiscal 2017.

[0001564590-19-033615:mdna:33]
The level of sales to any one customer, including a distributor, may vary from period to period.

[0001564590-19-033615:mdna:34]
Cost of Revenues and Gross Profit

[0001564590-19-033615:mdna:35]
The following table presents the gross profit on product and service revenue and the gross profit percentage of net revenues for the fiscal years ended 2019, 2018 and 2017 (dollars in thousands):

[0001564590-19-033615:mdna:36]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 401,353 |  |  | $ | 407,393 |  |  | $ | (6,040 | ) |  |  | (1.5 | )% |  | $ | 407,393 |  |  | $ | 240,204 |  |  | $ | 167,189 |  |  |  | 69.6 | % |
| Percentage of product revenue |  |  | 53.7 | % |  |  | 53.3 | % |  |  |  |  |  |  |  |  |  |  | 53.3 | % |  |  | 52.2 | % |  |  |  |  |  |  |  |  |
| Service |  |  | 149,882 |  |  |  | 127,124 |  |  |  | 22,758 |  |  |  | 17.9 | % |  |  | 127,124 |  |  |  | 90,753 |  |  |  | 36,371 |  |  |  | 40.1 | % |
| Percentage of service revenue |  |  | 60.4 | % |  |  | 58.1 | % |  |  |  |  |  |  |  |  |  |  | 58.1 | % |  |  | 61.9 | % |  |  |  |  |  |  |  |  |
| Total gross profit |  | $ | 551,235 |  |  | $ | 534,517 |  |  | $ | 16,718 |  |  |  | 3.1 | % |  | $ | 534,517 |  |  | $ | 330,957 |  |  | $ | 203,560 |  |  |  | 61.5 | % |
| Percentage of net revenues |  |  | 55.4 | % |  |  | 54.4 | % |  |  |  |  |  |  |  |  |  |  | 54.4 | % |  |  | 54.5 | % |  |  |  |  |  |  |  |  |

[0001564590-19-033615:mdna:37]
Cost of product revenues includes costs of materials, amounts paid to third-party contract manufacturers, costs related to warranty obligations, charges for excess and obsolete inventory, scrap, distribution, product certification, amortization of developed technology intangibles, royalties under technology license agreements, and internal costs associated with manufacturing overhead, including management, manufacturing engineering, quality assurance, development of test plans, and document control. We outsource substantially all of our manufacturing. We conduct supply chain management, quality assurance, manufacturing, engineering and document control at our facilities in San Jose, California, Salem, New Hampshire, China, and Taiwan.

[0001564590-19-033615:mdna:38]
Product gross profit decreased to $401.4 million for the year ended June 30, 2019, from $407.4 million in the corresponding period of fiscal 2018, primarily due to lower product revenues, higher distribution costs of $10.9 million, warranty charges of $8.2 million, amortization of developed technology intangibles due to the acquisition of the Data Center Business of $2.8 million and additional operations costs of $4.7 million mainly driven by higher personnel costs due to additional headcount. These increases were partially offset by lower product costs due to cost reduction efforts as well as decreased integration costs from acquisitions of $9.5 million.

[0001564590-19-033615:mdna:39]
Product gross profit increased to $407.4 million for the year ended June 30, 2018, from $240.2 million in the corresponding period of fiscal 2017, primarily due to higher revenues attributed to the acquisitions of the WLAN, the Campus Fabric and the Data Center Businesses and lower production costs due to cost reduction efforts.  The increases in product gross profit were partially offset by increases in amortization of developed technology intangibles of $9.9 million, warranty charges of $7.2 million, royalty charges of $2.2 million and acquisition and integration related costs of $7.7 million including excess inventory charges related to the discontinuance of certain product lines due to the acquisitions of the Campus Fabric and the Data Center Businesses in excess of the same charges incurred related to the acquisition of the WLAN Business in the corresponding period in fiscal 2017.

[0001564590-19-033615:mdna:40]
Our cost of service revenue consists primarily of labor, overhead, repair and freight costs and the cost of service parts used in providing support under customer maintenance contracts.

[0001564590-19-033615:mdna:41]
Service gross profit increased to $149.9 million for the year ended June 30, 2019, from $127.1 million in the corresponding period of fiscal 2018, primarily due to the acquisition of the Data Center Business as a result of a higher number of maintenance contracts.

[0001564590-19-033615:mdna:42]
Service gross profit increased to $127.1 million for the year ended June 30, 2018, from $90.8 million in the corresponding period of fiscal 2017, primarily due to the acquisitions of the WLAN, Campus Fabric and Data Center Businesses as a result of a higher number of maintenance contracts.

[0001564590-19-033615:mdna:43]
Operating Expenses

[0001564590-19-033615:mdna:44]
The following table presents operating expenses and operating income (dollars in thousands):

[0001564590-19-033615:mdna:45]
|  |  | Year Ended |  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | $ Change |  |  | % Change |  |  | June 30, 2018 |  |  | June 30, 2017 |  |  | $ Change |  |  | % Change |  |
| Research and development |  | $ | 210,132 |  |  | $ | 183,877 |  |  | $ | 26,255 |  |  |  | 14.3 | % |  | $ | 183,877 |  |  | $ | 93,724 |  |  | $ | 90,153 |  |  |  | 96.2 | % |
| Sales and marketing |  |  | 285,326 |  |  |  | 267,107 |  |  |  | 18,219 |  |  |  | 6.8 | % |  |  | 267,107 |  |  |  | 162,626 |  |  |  | 104,481 |  |  |  | 64.2 | % |
| General and administrative |  |  | 55,623 |  |  |  | 50,988 |  |  |  | 4,635 |  |  |  | 9.1 | % |  |  | 50,988 |  |  |  | 37,864 |  |  |  | 13,124 |  |  |  | 34.7 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 3,444 |  |  |  | 53,900 |  |  |  | (50,456 | ) |  |  | (93.6 | )% |  |  | 53,900 |  |  |  | 13,105 |  |  |  | 40,795 |  |  |  | 311.3 | % |
| Restructuring charges, net of reversals |  |  | 5,090 |  |  |  | 8,140 |  |  |  | (3,050 | ) |  |  | (37.5 | )% |  |  | 8,140 |  |  |  | 8,896 |  |  |  | (756 | ) |  |  | (8.5 | )% |
| Amortization of intangibles |  |  | 6,346 |  |  |  | 8,715 |  |  |  | (2,369 | ) |  |  | (27.2 | )% |  |  | 8,715 |  |  |  | 8,702 |  |  |  | 13 |  |  |  | 0.1 | % |
| Total operating expenses |  | $ | 565,961 |  |  | $ | 572,727 |  |  | $ | (6,766 | ) |  |  | (1.2 | )% |  | $ | 572,727 |  |  | $ | 324,917 |  |  | $ | 247,810 |  |  |  | 76.3 | % |

[0001564590-19-033615:mdna:46]
The following table highlights our operating expenses and operating loss as a percentage of net revenues:

[0001564590-19-033615:mdna:47]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Research and development |  |  | 21.1 | % |  |  | 18.7 | % |  |  | 15.4 | % |
| Sales and marketing |  |  | 28.7 | % |  |  | 27.2 | % |  |  | 26.8 | % |
| General and administrative |  |  | 5.6 | % |  |  | 5.2 | % |  |  | 6.2 | % |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 0.3 | % |  |  | 5.5 | % |  |  | 2.2 | % |
| Restructuring charges, net of reversals |  |  | 0.5 | % |  |  | 0.8 | % |  |  | 1.5 | % |
| Amortization of intangibles |  |  | 0.6 | % |  |  | 0.9 | % |  |  | 1.4 | % |
| Total operating expenses |  |  | 56.8 | % |  |  | 58.3 | % |  |  | 53.5 | % |
| Operating (loss) income |  |  | (1.5 | )% |  |  | (3.9 | )% |  |  | 1.0 | % |

[0001564590-19-033615:mdna:48]
Research and Development Expenses

[0001564590-19-033615:mdna:49]
Research and development expenses consist primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), consultant fees and prototype expenses related to the design, development, and testing of our products.

[0001564590-19-033615:mdna:50]
Research and development expenses increased by $26.3 million or 14.3% for fiscal 2019 as compared to fiscal 2018. The increase in research and development expenses during fiscal 2019 was due to $13.4 million related to third-party design and engineering collaboration charges, a $10.8 million increase in personnel costs, $5.5 million in increased facility and information technology costs and $0.9 million in increased supplies and equipment costs offset by a $3.3 million decrease in contract labor and a $1.0 million decrease in travel, recruiting and other costs.

[0001564590-19-033615:mdna:51]
Research and development expenses increased by $90.2 million or 96.2% for fiscal 2018 as compared to fiscal 2017. The increase in research and development expenses during fiscal 2018 was due to higher personnel costs of $67.0 million due to increased headcount related to the acquisitions of the Campus Fabric and Data Center Businesses, $12.5 million in increased facility and information technology costs, $7.4 million in increased supplies and equipment costs and $3.2 million in increased travel and other costs.

[0001564590-19-033615:mdna:52]
Sales and Marketing Expenses

[0001564590-19-033615:mdna:53]
Sales and marketing expenses consist of personnel costs (which consists of compensation, benefits and stock-based compensation) and related expenses for personnel engaged in marketing and sales functions, as well as trade shows and promotional expenses.

[0001564590-19-033615:mdna:54]
Sales and marketing expenses increased by $18.2 million or 6.8% for the year ended June 30, 2019, as compared to the corresponding period of fiscal 2018. The increase in sales and marketing expenses during fiscal 2019 consisted of higher personnel costs of $15.2 million, $2.5 million in increased software, supplies and equipment costs, $1.1 million in increased travel, marketing, meeting and conference costs offset by a $0.6 million decrease in facility and information technology costs.

[0001564590-19-033615:mdna:55]
Sales and marketing expenses increased by $104.5 million or 64.2% for the year ended June 30, 2018, as compared to the corresponding period of fiscal 2017. The increase in sales and marketing expenses during fiscal 2018 was primarily a result of the acquisitions of the Campus Fabric and Data Center Businesses. The increase consisted of higher personnel costs of $74.7 million, $10.8 million in additional professional fees, $7.2 million in increased facility and information technology costs, $6.4 million in increased travel, meeting and conference costs and $5.4 million in supplies and equipment costs.

[0001564590-19-033615:mdna:56]
General and Administrative Expenses

[0001564590-19-033615:mdna:57]
General and administrative expense consists primarily of personnel costs (which consists of compensation, benefits and stock-based compensation), legal and professional service costs, travel and facilities and information technology costs.

[0001564590-19-033615:mdna:58]
General and administrative expenses increased by $4.6 million or 9.1% for the year ended June 30, 2019, as compared to the corresponding period of fiscal 2018.  The increase in general and administrative expenses during fiscal 2019 was primarily due to $2.4 million in higher personnel costs, $1.3 million in higher facility and information technology costs, a $1.3 million increase in lease termination costs and a $0.6 million increase in supplier contract termination costs partially offset by a $1.0 million reduction in travel, professional fees and other costs.

[0001564590-19-033615:mdna:59]
General and administrative expenses increased by $13.1 million or 34.7% for the year ended June 30, 2018, as compared to the corresponding period of fiscal 2017.  The increase in general and administrative expenses during fiscal 2018 was primarily due to $8.4 million in higher personnel costs, $3.2 million in higher professional fees, $1.4 million in higher bad debts provision and $0.8 million in higher travel and other costs, partially offset by $0.7 million in reduced facility and information technology costs.

[0001564590-19-033615:mdna:60]
Acquisition and Integration Costs, Net of Bargain Purchase Gain

[0001564590-19-033615:mdna:61]
As a result of our acquisitions of the Campus Fabric, Data Center and Capital Financing Businesses in fiscal 2018 and the WLAN Business in fiscal 2017, we incurred $3.4 million, $53.9 million and $13.1 million of acquisition and integration costs, net of bargain purchase gain in fiscal years ended 2019, 2018 and 2017, respectively.

[0001564590-19-033615:mdna:62]
For fiscal 2019, we incurred $3.4 million of operating integration costs related to the acquisitions of the Campus Fabric and Data Center Businesses along with initial costs of the Aerohive acquisition.  On August 9, 2019 we completed our acquisition of Aerohive for approximately $264 million in cash consideration and the assumption of certain employee equity awards. See Note 17 – Subsequent Events.

[0001564590-19-033615:mdna:63]
For fiscal 2018, we incurred $12.4 million of acquisition and $6.3 million of integration costs related to the acquisition of the Campus Fabric Business and $36.0 million of acquisition and $4.2 million of integration costs related to the acquisition of the Data Center Business. The Data Center Business acquisition costs includes a $25.0 million consent fee paid to Broadcom, to terminate a previous asset purchase agreement entered into by the Company to purchase the Data Center Business from Broadcom, in anticipation of Broadcom’s acquisition of Brocade. The fee was paid to Broadcom to allow the Company to buy the Data Center Business directly from Brocade. We also recorded a gain on bargain purchase of $5.0 million related to the acquisition of the Capital Financing Business.

[0001564590-19-033615:mdna:64]
For fiscal 2017, we incurred $2.1 million of acquisition and $6.6 million of integration costs related to the WLAN Business acquisition.  We also incurred acquisition costs of $2.2 million related to our anticipated acquisition of the Campus Fabric Business and $2.2 million for the anticipated acquisition of the Data Center Business.

[0001564590-19-033615:mdna:65]
Restructuring and Related Charges, Net of Reversals

[0001564590-19-033615:mdna:66]
As of June 30, 2019, restructuring liabilities were $5.3 million and consisted primarily of severance and benefits payments and estimated future obligations for non-cancelable lease payments for excess facilities. The restructuring liability is recorded in “Other accrued liabilities” and “Other long-term liabilities” on the consolidated balance sheets. During fiscal years ended 2019, 2018 and 2017, we recorded restructuring charges and related charges, net of reversals, of $5.1 million, $8.1 million and $8.9 million, respectively.

[0001564590-19-033615:mdna:67]
Fiscal year ended 2019

[0001564590-19-033615:mdna:68]
On June 25, 2019, we began executing a reduction-in-force plan (the 2019 Plan) to better align our work force and operating expenses. We recorded $3.7 million related to employee severance and benefits expenses during the year ended June 30, 2019 under the 2019 plan. We also incurred $1.1 million in additional charges related to continuation of earlier actions associated with a reduction-in-force in the fourth quarter of fiscal 2018. We also incurred charges of $0.3 million for changes to estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of excess facilities.

[0001564590-19-033615:mdna:69]
We estimate we will incur additional charges beginning in the fourth quarter of fiscal 2019 through the second quarter of fiscal 2020, inclusive. Costs associated with the 2019 Plan are primarily comprised of employee severance and benefits expenses, relocation of personnel and equipment and exit of excess facilities. The amount and timing of the actual charges are uncertain due to required consultation activities with certain employees as well as compliance with statutory severance requirements in local jurisdictions.

[0001564590-19-033615:mdna:70]
Fiscal year ended 2018

[0001564590-19-033615:mdna:71]
During fiscal 2018, we announced and began executing a reduction-in-force in our third and fourth fiscal quarters as a result of the acquisitions of the Campus Fabric and the Data Center Businesses. We recorded restructuring charges of $7.9 million related to employee severance and benefits expenses during fiscal 2018. We also incurred charges of $0.2 million for changes to our estimates for accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments of our excess facilities.

[0001564590-19-033615:mdna:72]
Fiscal year ended 2017

[0001564590-19-033615:mdna:73]
Pursuant to the WLAN Business acquisition from Zebra, we assumed a facility lease located at 6480 Via del Oro in San Jose, California (“Via del Oro”) and transferred our headquarters from Rio Robles Drive in San Jose, California (“Rio Robles”) to Via del Oro.  We consolidated our existing workforce from our previous headquarters with employees assumed from Zebra to the Via del Oro site and exited the Rio Robles site on January 31, 2017.  Due to our move from the Rio Robles facility and abandonment of all leasehold improvements, we accelerated the amortization of the remaining leasehold improvements for this site over the shortened service period such that the leasehold improvements were fully amortized on the cease-use date.  We recorded accelerated amortization expense for the year ended June 30, 2017 of $2.6 million which is reflected in “Restructuring and related charges, net of reversals” in the consolidated statements of operations.

[0001564590-19-033615:mdna:74]
We entered into a sublease agreement related to our Rio Robles facility during the third quarter of fiscal 2017 for the remaining duration of the lease. The sublease resulted in adjustments to the prior estimates for the amount of sublease payments, timing of sublease activities and real estate commissions associated with the sublease. The net adjustments, including modifications to our future obligations for non-cancellable lease payments and related future subleasing income resulted in additional charges of $2.0 million during fiscal 2017. The excess facilities payments will continue through fiscal year 2023.

[0001564590-19-033615:mdna:75]
In anticipation of the acquisitions of Campus Fabric Business and Data Center Business in fiscal 2018, we reoccupied the majority of the previously exited space at our Salem, New Hampshire location during our fiscal fourth quarter to accommodate the growth in headcount and lab facility requirements. This action resulted in a reversal of prior restructuring expense accruals of $1.3 million.

[0001564590-19-033615:mdna:76]
We also implemented a reduction-in-force which affected 90 employees.  We recorded severance and benefits charges of $5.6 million during the year ended June 30, 2017.  Cash payments of $3.8 million were made by June 30, 2017 with the remainder paid in fiscal 2018.

[0001564590-19-033615:mdna:77]
Amortization of Intangibles

[0001564590-19-033615:mdna:78]
During fiscal years ended 2019, 2018 and 2017, we recorded $6.3 million, $8.7 million and $8.7 million, respectively, of amortization expenses in operating expenses primarily for certain intangibles related to the acquisitions of the Campus Fabric, Data Center and WLAN Businesses and Enterasys.  The decrease in amortization expense of $2.4 million in fiscal 2019 from fiscal 2018 was mainly due to the acquired intangibles from the Enterasys acquisition becoming fully amortized.

[0001564590-19-033615:mdna:79]
Interest Income

[0001564590-19-033615:mdna:80]
Interest income was $2.2 million, $2.8 million and $0.7 million in fiscal years ended 2019, 2018 and 2017, respectively, representing a decrease of $0.6 million in fiscal 2019 from fiscal 2018 and an increase of $2.2 million in fiscal 2018 from fiscal 2017. The decrease in fiscal 2019 was due to a $1.6 million decrease in interest income from a long-term note receivable, offset by higher invested funds balances. The increase in fiscal 2018 was due to accretion of interest on a long-term note receivable acquired from the WLAN Business as well as increased interest income on cash balances due to rising market interest rates.

[0001564590-19-033615:mdna:81]
Interest Expense

[0001564590-19-033615:mdna:82]
We incurred $12.6 million, $13.9 million and $4.1 million of interest expense for fiscal 2019, 2018 and 2017, respectively. The decrease in interest expense in fiscal year ended June 30, 2019 was primarily due to lower imputed interest charges associated with various long-term contracts. The increase in interest expense in fiscal 2018 was primarily in connection with the increased balance of our Credit Facility due to the acquisitions of the WLAN, Campus Fabric and Data Center Businesses and accretion of interest expense of $3.1 million associated with the contingent consideration obligations. In addition, we recorded a loss from debt extinguishment of $1.2 million in fiscal 2018 in connection with our 2018 Credit Agreement entered on May 1, 2018.  Interest expense for fiscal 2017 was primarily related to borrowings to finance the WLAN business acquisition.

[0001564590-19-033615:mdna:83]
Other (Expense) Income, net

[0001564590-19-033615:mdna:84]
We incurred other expense of $0.8 million, other income of $2.6 million and other expense of less than $0.1 million in fiscal years ended 2019, 2018 and 2017, respectively. The other expense for fiscal 2019 was primarily due to losses on the sale of equity investments. The income for fiscal 2018 was primarily driven by a gain of $4.0 million due to the sale of equity investments, partially offset by foreign exchange losses.

[0001564590-19-033615:mdna:85]
(Benefit) Provision for Income Taxes

[0001564590-19-033615:mdna:86]
We are subject to income taxes in the United States and numerous foreign jurisdictions.  Our effective tax rate differs from the newly enacted U.S. federal statutory rate of 21% primarily due to the offsetting impact of i) state taxes, ii) foreign operations, iii) the full valuation of our deferred tax assets in the U.S. and certain foreign jurisdictions and for our fiscal year ended June 30, 2019, iv) the phase in of various provisions of the U.S. Tax Reform Act making our U.S. tax rate for this particular year 0%.  For the fiscal years ended 2019, 2018 and 2017, we recorded income tax (benefit) provisions of less than $(0.0) million, $0.1 million and $4.3 million, respectively.

[0001564590-19-033615:mdna:87]
For fiscal 2019, we recorded a tax benefit, offsetting the tax components detailed above, consisting of a $2.6 million release of a valuation allowance for our Australian Net Operating Loss (“NOL”) carryforwards given sufficient projected profitability for the subsidiary following the recent acquisitions of the Campus Fabric and Data Center businesses.  Additionally, a tax benefit of $4.7 million was recognized for the release of valuation allowances given changes introduced by recently enacted U.S. Tax Reform Act which allows for an indefinite carryforward period for U.S. NOLs generated in tax years beginning after December 31, 2017.

[0001564590-19-033615:mdna:88]
For fiscal 2018, our tax provision primarily related to taxes on our foreign operations offset by two significant tax benefits resulting from Tax Reform and restructuring of our foreign operations. Income tax provision of $6.7 million consisted of taxes on the income of our foreign subsidiaries as well as tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill.  Partially offsetting the tax provision is a tax benefit of $3.1 million resulting from the reduction of the U.S. Federal tax rate from 35% to 21% applied to our deferred tax liability related to amortizable goodwill as required by the recently enacted U.S. tax legislation as well as a tax benefit resulting from the impairment of a lease acquired from Avaya in Canada. Additionally, we recorded a tax benefit resulting from the restructuring of our foreign operations of $3.4 million.

[0001564590-19-033615:mdna:89]
For fiscal 2017 the majority of our tax provision related to taxes on our foreign operations as well as state taxes due to the full valuation allowance on our U.S. and certain foreign deferred tax assets.

[0001564590-19-033615:mdna:90]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate and for further explanation of our provisions for income taxes, see Note 15. Income Taxes, for additional information.

[0001564590-19-033615:mdna:91]
Critical Accounting Policies and Estimates

[0001564590-19-033615:mdna:92]
Our significant accounting policies are more fully described in Note 2 of Notes to Consolidated Financial Statements included in Item 8 of this Annual Report on Form 10-K. The preparation of consolidated financial statements in accordance with generally accepted accounting principles requires management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenue and expenses during the period reported. By their nature, these estimates, assumptions and judgments are subject to an inherent degree of uncertainty. We base our estimates, assumptions and judgments on historical experience, market trends and other factors that are believed to be reasonable under the circumstances. Estimates, assumptions and judgments are reviewed on an ongoing basis and the effects of revisions are reflected in the consolidated financial statements in the period they are determined to be necessary. Actual results may differ from these estimates under different assumptions or conditions. We believe the critical accounting policies stated below, among others, affect our more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001564590-19-033615:mdna:93]
Revenue Recognition

[0001564590-19-033615:mdna:94]
We account for revenue in accordance with Topic 606, Revenue from Contracts with Customers, which we adopted on July 1, 2017, using the retrospective method.  We derive the majority of our revenue from sales of our networking equipment, with the remaining revenue generated from service fees relating to maintenance contracts, professional services, and training for our products. We sell our products and maintenance contracts direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock our products and sell primarily to resellers.  The second tier of the distribution channel consists of a non-stocking distributors and value-added resellers that sell directly to end-users.  Products and services may be sold separately or in bundled packages.

[0001564590-19-033615:mdna:95]
We consider customer purchase orders, which in some cases are governed by master sales agreements, to be the contracts with a customer.  For each contract, we consider the promise to transfer products and services, each of which are distinct, to be the identified performance obligations. In determining the transaction price, we evaluate whether the price is subject to refund or adjustment to determine the net consideration to which we expect to be entitled.

[0001564590-19-033615:mdna:96]
For all of our sales and distribution channels, revenue is recognized when control of the product is transferred to the customer (i.e., when our performance obligation is satisfied), which typically occurs at shipment for product sales. Revenue from maintenance contracts is recognized over time as our performance obligations are satisfied. This is typically the contractual service period, which ranges from one to three years.  For product sales to our value-added resellers, non-stocking distributors and end-user customers, we generally do not grant return privileges, except for defective products during the warranty period, nor do we grant pricing credits.  Sales incentives and other programs that we may make available to these customers are considered to be a form of variable consideration and we maintain estimated accruals and allowances using the expected value method.

[0001564590-19-033615:mdna:97]
Sales to stocking distributors are made under terms allowing certain price adjustments and limited rights of return (known as “stock rotation”) of our products held in their inventory. Stock rotation rights grant the distributor the ability to return certain specified amounts of inventory. Stock rotation adjustments are an additional form of variable consideration and are estimated using the expected value method based on historical return rates.  Frequently, distributors need to sell at a price lower than the contractual distribution price in order to win business and submit rebate requests for Company pre-approval prior to selling the product through at the discounted price.  At the time the distributor invoices our customer or soon thereafter, the distributor submits a rebate claim to us to adjust the distributor’s cost from the contractual price to the pre-approved lower price. After we verify that the claim was pre-approved, a credit memo is issued to the distributor for the rebate claim. In determining the transaction price, we consider these rebate adjustments to be variable consideration. Such price adjustments are estimated using the expected value method based on an analysis of actual claims, at the distributor level over a period of time considered adequate to account for current pricing and business trends.

[0001564590-19-033615:mdna:98]
Performance Obligations. A performance obligation is a promise in a contract to transfer a distinct good or service to the customer and is the unit of account in Topic 606. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied.  Certain of our contracts have multiple performance obligations, as the promise to transfer individual goods or services is separately identifiable from other promises in the contracts and, therefore, is distinct.  For contracts with multiple performance obligations, we allocate the contract’s transaction price to each performance obligation based on our relative standalone selling price.  The stand-alone selling prices are determined based on the prices at which we separately sell these products.  For items that are not sold separately, we estimate the stand-alone selling prices using the best estimated selling price approach.

[0001564590-19-033615:mdna:99]
Our performance obligations are satisfied at a point in time or over time as work progresses.  Substantially all of our product sales revenues as reflected on the consolidated statements of operations for the years ended 2019, 2018 and 2017 are recognized at a point in time. Substantially all of our service revenue is recognized over time.  For revenue recognized over time, we use an input measure, days elapsed, to measure progress.

[0001564590-19-033615:mdna:100]
Contract Balances. The timing of revenue recognition, billings and cash collections results in billed accounts receivable and deferred revenue in the consolidated balance sheets. Services provided under our renewable support arrangements are billed in accordance with agreed-upon contractual terms, which are typically at periodic intervals (e.g., quarterly or annually).  We sometimes receive payments from our customers in advance of services being provided, resulting in deferred revenues.  These liabilities are reported on the consolidated balance sheets on a contract-by-contract basis at the end of each reporting period.

[0001564590-19-033615:mdna:101]
Contract Costs.  We recognize the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that we otherwise would have recognized is one year or less.  Management expects that commission fees paid to sales representative as a result of obtaining service contracts and contract renewals are recoverable and therefore we capitalized them as contract costs.  Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years and are included in “Sales and marketing” in the accompanying consolidated statements of operations.

[0001564590-19-033615:mdna:102]
Inventory Valuation and Purchase Commitments

[0001564590-19-033615:mdna:103]
We write down inventory and record purchase commitment liabilities for estimated excess and obsolete inventory equal to the difference between the cost of inventory and the estimated market value based upon the forecast of future product demand, product transition cycles, and market conditions. Any significant unanticipated changes in demand or technological development could have a significant impact on the value of our inventory and purchase commitments and our reported results. If actual market conditions are less favorable than those projected, additional inventory write-downs, purchase commitment liabilities, and charges against earnings may be required.

[0001564590-19-033615:mdna:104]
New Accounting Pronouncements

[0001564590-19-033615:mdna:105]
See Note 2. Summary of Significant Accounting Policies, in the accompanying consolidated financial statements for a full description of new accounting pronouncements, including the respective expected dates of adoption and effects on results of operations and financial condition.

[0001564590-19-033615:mdna:106]
Liquidity and Capital Resources

[0001564590-19-033615:mdna:107]
The following summarizes information regarding our cash, investments, and working capital (in thousands):

[0001564590-19-033615:mdna:108]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Cash |  | $ | 169,607 |  |  | $ | 121,139 |  |
| Marketable securities |  |  | — |  |  |  | 1,459 |  |
| Total cash and marketable securities |  | $ | 169,607 |  |  | $ | 122,598 |  |
| Working capital |  | $ | 85,960 |  |  | $ | 68,041 |  |

[0001564590-19-033615:mdna:109]
As of June 30, 2019, our principal sources of liquidity consisted of cash, and investments of $169.6 million, accounts receivable, net of $174.4 million and availability of borrowings from the 2018 Revolving Facility of $35.5 million.  We anticipate that our principal uses of cash for fiscal 2020 will be purchases of finished goods inventory from our contract manufacturers, payroll, repayments of debt and related interest, purchases of property and equipment, our stock repurchase program, and other operating expenses related to the development, and marketing of our products.  We believe that our cash, investments and cash flows from operations along with the availability of additional borrowings from our 2019 Credit Agreement (as defined below), will be sufficient to meet our working capital requirements for at least the next 12 months.

[0001564590-19-033615:mdna:110]
On August 9, 2019 we completed our acquisition of Aerohive for approximately $264 million in cash consideration and acquired all Aerohive common shares at a price of $4.45 per share plus the assumption of certain employee equity awards. See Note 17 – Subsequent Events.

[0001564590-19-033615:mdna:111]
On August 9, 2019, we entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among us, as borrower, several banks and other financial institutions as Lenders,  BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders, The 2019 Credit Agreement provides for a 5-year first lien term loan facility in an aggregate principal amount of $380 million (the “2019 Term Loan”) and a 5-year revolving loan facility in an aggregate principal amount of $75 million (the “2019 Revolving Facility”). In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. In addition to funding a portion of the amount paid by us to acquire Aerohive, we will use the proceeds of the 2019 Term Loan to pay off i) our existing 2018 Credit Agreement, ii) pay fees and expenses incurred in connection with the tender offer to acquire all of the outstanding shares of Aerohive’s common stock and iii) for working capital and general corporate purposes.

[0001564590-19-033615:mdna:112]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity.  The 2019 Credit Agreement also includes covenants and restrictions that limited, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets.  The 2019 Credit Agreement also includes customary events of default which could result in acceleration of the outstanding balance.

[0001564590-19-033615:mdna:113]
On November 2, 2018, our Board of Directors announced that it had authorized management to repurchase up to $60.0 million of its common stock for two years from the date of authorization.  Purchases may be made from time to time in the open market or in privately negotiated transactions. The manner, timing and amount of any future purchases will be determined by the Company's management based on their evaluation of market conditions, stock price, our ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate us to acquire any common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the year ended June 30, 2019, we repurchased 2.4 million shares at an aggregate cost of $15.0 million.

[0001564590-19-033615:mdna:114]
Key Components of Cash Flows and Liquidity

[0001564590-19-033615:mdna:115]
A summary of the sources and uses of cash is as follows (in thousands):

[0001564590-19-033615:mdna:116]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| Net cash provided by operating activities |  | $ | 104,945 |  |  | $ | 19,043 |  |  | $ | 59,283 |  |
| Net cash used in investing activities |  |  | (21,809 | ) |  |  | (132,471 | ) |  |  | (71,752 | ) |
| Net cash (used in) provided by financing activities |  |  | (34,442 | ) |  |  | 104,746 |  |  |  | 48,708 |  |
| Foreign currency effect on cash |  |  | (226 | ) |  |  | (629 | ) |  |  | 89 |  |
| Net increase (decrease) in cash |  | $ | 48,468 |  |  | $ | (9,311 | ) |  | $ | 36,328 |  |

[0001564590-19-033615:mdna:117]
Cash was $169.6 million at June 30, 2019, representing an increase of $48.5 million from $121.1 million at June 30, 2018. Cash increased primarily due to cash provided by operations of $104.9 million partially offset by cash used in investing activities of $21.8 million mainly for capital expenditures, and cash used in financing activities of $34.4 million mainly as a result of repayments of debt and repurchases of stock.

[0001564590-19-033615:mdna:118]
Cash was $121.1 million at June 30, 2018, representing a decrease of $9.3 million from $130.5 million at June 30, 2017. Cash and cash equivalents decreased primarily due to cash used in investing activities of $132.5 million mainly for the acquisitions of the Campus Fabric and Data Center Businesses and capital expenditures, partially offset by cash provided by financing activities of $104.7 million as a result of additional borrowings for the acquisitions and cash provided by operations of $19.0 million.

[0001564590-19-033615:mdna:119]
Net Cash Provided by Operating Activities

[0001564590-19-033615:mdna:120]
Cash provided by operating activities during fiscal year ended 2019 was $104.9 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2019 were non-cash expenses such as amortization of intangibles, stock-based compensation and depreciation, decreases in accounts receivable and increases in deferred revenue and accrued compensation and benefits.  These amounts were partially offset by our net loss of $25.9 million, decreases in accounts payable, other current and long-term liabilities, and non-cash deferred income tax liabilities and increases in prepaid expenses and other assets.

[0001564590-19-033615:mdna:121]
Cash provided by operating activities during fiscal 2018 was $19.0 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2018 were non-cash expenses such as stock-based compensation, amortization of intangibles, depreciation, a decrease in inventories, as well as increases in deferred revenue, accounts payable and accrued compensation and benefits, and other current and long-term liabilities. These sources were partially offset by net loss of $46.8 million, increases in accounts receivable, prepaid expenses and other assets, non-cash gain on bargain purchase and decreases in deferred income tax liabilities.

[0001564590-19-033615:mdna:122]
Cash provided by operating activities during fiscal 2017 was $59.3 million. Factors contributing to cash provided by operating activities for the year ended June 30, 2017 were decreases in inventory and prepaid expenses, and increases to accrued compensation and benefits, deferred revenues and other liabilities in addition to non-cash expenses such as amortization of intangibles, stock-based compensation, and depreciation.  These amounts were partially offset by an increase in accounts receivables and net loss of $1.7 million.

[0001564590-19-033615:mdna:123]
Net Cash Used in Investing Activities

[0001564590-19-033615:mdna:124]
Cash used in investing activities during fiscal year ended June 30, 2019 was $21.8 million mainly due to capital expenditures of $22.7 million.

[0001564590-19-033615:mdna:125]
Cash used in investing activities during fiscal 2018 was $132.5 million mainly due to our acquisitions of the Campus Fabric and Data Center Businesses of $97.6 million and capital expenditures of $40.4 million offset by proceeds from the sale of equity investment.

[0001564590-19-033615:mdna:126]
Cash used in investing activities during fiscal 2017 was $71.8 million mainly due to our acquisition of the WLAN Business of $51.1 million, deposits for future acquisitions of $10.2 million and capital expenditures of $10.4 million.

[0001564590-19-033615:mdna:127]
Net cash (Used in) Provided by Financing Activities

[0001564590-19-033615:mdna:128]
Cash used in financing activities during fiscal year ended June 30, 2019 was $34.4 million due primarily to repayments of debt totaling $19.9 million, contingent consideration of $6.5 million and $4.0 million of deferred payments on acquisitions. This was partially offset by $11.5 million of proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards.

[0001564590-19-033615:mdna:129]
Cash flows used in financing activities for the period also included repurchasing of our common shares valued at $15.0 million during fiscal year ended June 30, 2019, in accordance with our approved share repurchase plan. The share repurchases were executed through open market purchases, and future share repurchases may be completed through the combination of individually negotiated transactions, accelerated share buyback, and/or open market purchases. As of June 30, 2019, we have $45.0 million available under our share repurchase plan.

[0001564590-19-033615:mdna:130]
Cash provided by financing activities during fiscal 2018 was $104.7 million due primarily to additional borrowings of $100.0 million to fund our acquisitions of the Campus Fabric and Data Center Businesses, new borrowings of $200 million under the Credit Agreement to pay off the existing debt under the prior Credit Facility, $3.3 million of proceeds from issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”) and the exercise of stock options, net of taxes paid on vested and released stock awards, partially offset by repayments of debt totaling $193.7 million, $3.2 million of loan fees incurred in connection with the Second Amendment of our Credit Facility and the Credit Agreement and $1.7 million of contingent consideration and deferred payments on acquisitions.

[0001564590-19-033615:mdna:131]
Cash provided by financing activities during fiscal 2017 was $48.7 million due primarily to $48.3 million in borrowings of debt pursuant to our WLAN Business acquisition, $11.8 million in proceeds from the sale of our common stock, primarily through the exercise of stock options and our ESPP, partially offset by repayments of debt of $10.0 million.

[0001564590-19-033615:mdna:132]
Foreign Currency Effect on Cash

[0001564590-19-033615:mdna:133]
Foreign currency effect on cash decreased in 2019, primarily due to changes in exchange rates between the U.S. Dollar and Indian Rupee and the Euro.

[0001564590-19-033615:mdna:134]
Contractual Obligations

[0001564590-19-033615:mdna:135]
The following summarizes our contractual obligations at June 30, 2019, and the effect such obligations are expected to have on our liquidity and cash flow in future periods (in thousands):

[0001564590-19-033615:mdna:136]
|  |  | Total |  |  | Less than 1 Year |  |  |  |  | 1-3 years |  |  |  |  | 3-5 years |  |  | More than 5 years |  |
| Contractual Obligations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Debt obligations |  | $ | 180,500 |  |  | $ | 9,500 |  |  |  |  | $ | 28,500 |  |  |  |  | $ | 142,500 |  |  | $ | — |  |
| Interest on debt obligations |  |  | 25,582 |  |  |  | 8,333 |  |  |  |  |  | 14,952 |  |  |  |  |  | 2,297 |  |  |  | — |  |
| Inventory unconditional purchase obligations |  |  | 51,241 |  |  |  | 51,241 |  |  |  |  |  | — |  |  |  |  |  | — |  |  |  | — |  |
| Contractual commitments |  |  | 94,000 |  |  |  | 23,500 |  |  |  |  |  | 47,000 |  |  |  |  |  | 23,500 |  |  |  | — |  |
| Non-cancellable operating lease obligations |  |  | 104,678 |  |  |  | 22,733 |  |  |  |  |  | 41,854 |  |  |  |  |  | 23,804 |  |  |  | 16,287 |  |
| Deferred payments for an acquisition |  |  | 15,000 |  |  |  | 4,000 |  |  |  |  |  | 8,000 |  |  |  |  |  | 3,000 |  |  |  | — |  |
| Contingent consideration for an acquisition |  |  | 6,298 |  |  |  | 4,236 |  |  |  |  |  | 2,013 |  |  |  |  |  | 49 |  |  |  | — |  |
| Other liabilities |  |  | 379 |  |  |  | 124 |  |  |  |  |  | 249 |  |  |  |  |  | 6 |  |  |  | — |  |
| Total contractual cash obligations |  | $ | 477,678 |  |  | $ | 123,667 |  |  |  |  | $ | 142,568 |  |  |  |  | $ | 195,156 |  |  | $ | 16,287 |  |

[0001564590-19-033615:mdna:137]
The contractual obligations referenced above are more specifically defined as follows:

[0001564590-19-033615:mdna:138]
Debt obligations relate to amounts owed under our Credit Agreement.

[0001564590-19-033615:mdna:139]
Inventory unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast.  We expect to honor the inventory purchase commitments within the next 12 months.

[0001564590-19-033615:mdna:140]
Contractual commitments to suppliers for future services.

[0001564590-19-033615:mdna:141]
Deferred payments represent Data Center Business consideration obligation of $1.0 million per quarter.

[0001564590-19-033615:mdna:142]
Contingent consideration for the Capital Financing Business acquisition, at fair value.  Actual payments could be different.

[0001564590-19-033615:mdna:143]
Non-cancelable operating lease obligations represent base rents and operating expense obligations.

[0001564590-19-033615:mdna:144]
Other liabilities include our commitments towards debt related fees and specific arrangements other than inventory.

[0001564590-19-033615:mdna:145]
The amounts in the table above exclude immaterial income tax liabilities related to uncertain tax positions as we are unable to reasonably estimate the timing of the settlement.

[0001564590-19-033615:mdna:146]
We did not have any material commitments for capital expenditures as of June 30, 2019.

[0001564590-19-033615:mdna:147]
Off-Balance Sheet Arrangements

[0001564590-19-033615:mdna:148]
We did not have any off-balance sheet arrangements as of June 30, 2019.
