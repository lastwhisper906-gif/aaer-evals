# EXTR 8-K — 0001564590-19-027208 filed 2019-07-31

## item codes, every 8-K on or before 2019-08-29

- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2019-08-29

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-027208:8k_2_02:1]
EX-99.1
2
extr-ex991_6.htm
EX-99.1

[0001564590-19-027208:8k_2_02:2]
extr-ex991_6.htm

[0001564590-19-027208:8k_2_02:3]
Exhibit 99.1

[0001564590-19-027208:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001564590-19-027208:8k_2_02:5]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Christi Nicolacopoulos |
| 919/595-4196 |  |  |  | 603/952-5005 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0001564590-19-027208:8k_2_02:6]
Extreme Networks Reports Fourth Quarter Fiscal Year 2019 Financial Results

[0001564590-19-027208:8k_2_02:7]
Conference Call at 8:00 a.m. EDT

[0001564590-19-027208:8k_2_02:8]
SAN JOSE, Calif., July 31, 2019 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its fiscal fourth quarter ended June 30, 2019.

[0001564590-19-027208:8k_2_02:9]
Fiscal Fourth Quarter Results:

[0001564590-19-027208:8k_2_02:10]
|  | • | GAAP EPS ($0.14), down ($0.09) year-over-year and down ($0.08) quarter-over-quarter |

[0001564590-19-027208:8k_2_02:11]
|  | • | Non-GAAP EPS $0.06, down ($0.14) year-over-year and down ($0.02) quarter-over-quarter |

[0001564590-19-027208:8k_2_02:12]
|  | • | Revenue $252.4 million, down 9% year-over-year and up 1% quarter-over-quarter |

[0001564590-19-027208:8k_2_02:13]
|  | • | GAAP gross margin 55.1% compared to 54.0%, in Q4 last year |

[0001564590-19-027208:8k_2_02:14]
|  | • | Non-GAAP gross margin 59.2% compared to 57.6%, in Q4 last year |

[0001564590-19-027208:8k_2_02:15]
|  | • | GAAP operating margin (4.8)% compared to (1.2)%, in Q4 last year |

[0001564590-19-027208:8k_2_02:16]
|  | • | Non-GAAP operating margin 4.9%, compared to 9.8%, in Q4 last year |

[0001564590-19-027208:8k_2_02:17]
|  | • | Net cash provided by operating activities $25.4 million |

[0001564590-19-027208:8k_2_02:18]
|  | • | Free Cash Flow $18.9 million |

[0001564590-19-027208:8k_2_02:19]
“We reported revenue above the high-end of our guidance range, reflecting strength in our Americas business and early signs of demand for new products in our Smart OmniEdge switching portfolio. Our year-over-year and sequential improvement in gross margin put us towards the high-end of our guidance range, and close to our 60% target. Our gross margin performance was a function of several factors: lower standard costs, partly related to the improved profitability of our new products; higher mix of Services revenue; and mix shift owing to stronger demand in North America in Q4. We closed fiscal year 2019 at $1B in revenue and look forward to bringing exciting new solutions to our partners and customers once we have successfully closed the Aerohive acquisition,” stated Ed Meyercord, President and CEO of Extreme Networks.

[0001564590-19-027208:8k_2_02:20]
Meyercord added, “Looking ahead, we are expecting fiscal year 2020 organic revenue growth to be in the low single-digit range. Our outlook for Q1 reflects the normal seasonality of our business, ongoing economic challenges in EMEA, and conservatism around our wireless business as customers consider the alternative Smart OmniEdge solutions that will be available following the close of our Aerohive acquisition. With the cost savings actions we took at the end of Q4, we are on plan to achieve our goal of a 15% operating margin toward year-end fiscal year 2020, and to improve our cash flow generation throughout the year.”

[0001564590-19-027208:8k_2_02:21]
Recent Key Highlights:

[0001564590-19-027208:8k_2_02:22]
|  | • | In Q4, Extreme closed 23 deals of $1 million or more, up from 17 such deals in Q3, with particular strength in the Education, Government, and Healthcare verticals. During fiscal year 2019, 110 customers invested in more than $1 million worth of Extreme products and services. |

[0001564590-19-027208:8k_2_02:23]
|  | • | On June 26, Extreme announced it entered into a definitive agreement to acquire Aerohive Networks. The acquisition of Aerohive will add critical cloud management and edge capabilities to Extreme's portfolio of end-to-end, edge-to-cloud networking solutions. It will provide a strong subscription revenue stream. It will also solidify Extreme as the third largest player in enterprise wireless LAN with the number two cloud platform in one of the fastest growth segments of the market as the industry transitions to Wi-Fi 6. Extreme expects the deal to close shortly after the tender offer expires on August 8th. |

[0001564590-19-027208:8k_2_02:24]
|  | • | Leeds Beckett University, a top university in the UK, will upgrade its campus network with Extreme’s Smart OmniEdge™ solutions to enable delivery of advanced, tech-driven educational and extracurricular programming to 25,000 students and 3,000 staff. More than 2,000 ExtremeMobility™ Wi-Fi 6 access points will be deployed across its two main campuses, providing high-performance connectivity to 85 buildings, as well as its sports facilities. The new Wi-Fi 6 solutions will run over the University’s existing Extreme Automated Campus network, where Extreme Fabric Connect will enable automatic configuration of the new access points. The Extreme Management Center application (XMC) will provide single pane of glass management across the two networks. |

[0001564590-19-027208:8k_2_02:25]
|  | • | The Houston Dynamo of Major League Soccer and Houston Dash of the National Women’s Soccer League selected our Smart OmniEdge™ solution to provide high-density, professional-grade Wi-Fi connectivity in their home field, BBVA Stadium. With ExtremeMobility access points, Extreme Management Center and ExtremeAnalytics applications, BBVA Stadium is the first MLS stadium to deploy Wi-Fi 6. Its new network will enable mobile ticketing and improved social media connectivity for fans today and lay the groundwork for future innovations such as wireless food ordering and augmented and virtual reality that will bring fans even closer to the field. |

[0001564590-19-027208:8k_2_02:26]
|  | • | Naver, the largest news portal and search engine in Korea, selected Extreme’s Agile Data Center™ solutions to accommodate fast-growing data traffic, providing cloud service delivery across multiple data centers. Extreme’s Top-of-Rack (ToR) switches with 40G modules will enable Naver to deploy 10G/40G access in their high-density data center server farm in a cost-effective manner while they transition to a new, virtualized environment. |

[0001564590-19-027208:8k_2_02:27]
|  | • | The ITR Concession Company deployed Extreme’s Smart OmniEdge™ and Automated Campus solutions to power its Intelligent Transportation Systems (ITS) on the Indiana Toll Road, allowing for real-time updates on traffic patterns and enabling safer, more coordinated use of the roadway, while laying the foundation to deploy advanced transportation technology. As a result, the highway system has reduced traffic incidents by 30 percent. |

[0001564590-19-027208:8k_2_02:28]
|  | • | Extreme announced its ExtremeAI™ Security application, a new class of network security that leverages artificial intelligence and machine learning to identify and automatically remediate threats against IoT devices. Key capabilities include behavioral monitoring and baselining, unsupervised learning, insights and granular analytics, and multivendor interoperability and integration. GA is anticipated in October 2019. |

[0001564590-19-027208:8k_2_02:29]
|  | • | Extreme held its second annual Connect User Conference in Nashville in May. The event attracted twice as many attendees as in 2018, bringing together customers, partners, and industry leaders from around the world to participate in technology training, achieve certifications, network and collaborate with industry experts, and explore the future of networking. |

[0001564590-19-027208:8k_2_02:30]
|  | • | Extreme extended its popular ExtremeDojo™ training program to customers and added a technical training pathway for both customers and partners. Enterprise engineers can choose from free, online video training or from an extensive schedule of instructor-led classes delivered by Extreme's global ecosystem of Authorized Training Partners, or a blended mix of both. |

[0001564590-19-027208:8k_2_02:31]
|  | • | Bowen Center, a community behavioral health care provider in northern Indiana, deployed Extreme Smart OmniEdge solutions to overhaul its network infrastructure, simplify network management and lay the foundation for unified collaboration and telemedicine—ultimately delivering a better experience for medical staff and enhanced care for patients. Since moving over to Extreme, Bowen Center reports IT satisfaction scores as rated by its 1,300 staff members have increased by more than 20 points. |

[0001564590-19-027208:8k_2_02:32]
Fiscal Q4 2019 Financial Metrics:

[0001564590-19-027208:8k_2_02:33]
(in millions, except percentages and per share information)

[0001564590-19-027208:8k_2_02:34]
|  |  | Q4 FY'19 |  |  | Q4 FY'18 |  |  | Change |  |
| GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 189.6 |  |  | $ | 221.3 |  |  | $ | (31.7 | ) |  |  | (14 | )% |
| Service |  |  | 62.8 |  |  |  | 57.0 |  |  |  | 5.8 |  |  |  | 10 | % |
| Total Net Revenue |  | $ | 252.4 |  |  | $ | 278.3 |  |  | $ | (25.9 | ) |  |  | (9 | )% |
| Gross Margin |  |  | 55.1 | % |  |  | 54.0 | % |  | 110 bps |  |  | - |  |
| Operating Margin |  |  | (4.8 | )% |  |  | (1.2 | )% |  | -364 bps |  |  | - |  |
| Net Loss |  | $ | (17.1 | ) |  | $ | (5.6 | ) |  | $ | (11.5 | ) |  |  | (205 | )% |
| Loss per basic share |  | $ | (0.14 | ) |  | $ | (0.05 | ) |  | $ | (0.09 | ) |  |  | (180 | )% |
| Non-GAAP Results of Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 189.6 |  |  | $ | 221.3 |  |  | $ | (31.7 | ) |  |  | (14 | )% |
| Service |  |  | 62.8 |  |  |  | 57.0 |  |  |  | 5.8 |  |  |  | 10 | % |
| Total Net Revenue |  | $ | 252.4 |  |  | $ | 278.3 |  |  | $ | (25.9 | ) |  |  | (9 | )% |
| Gross Margin |  |  | 59.2 | % |  |  | 57.6 | % |  | 160 bps |  |  | - |  |
| Operating Margin |  |  | 4.9 | % |  |  | 9.8 | % |  | -490 bps |  |  | - |  |
| Net Income |  | $ | 7.6 |  |  | $ | 24.0 |  |  | $ | (16.4 | ) |  |  | (68 | )% |
| Income per diluted share |  | $ | 0.06 |  |  | $ | 0.20 |  |  | $ | (0.14 | ) |  |  | (70 | )% |

[0001564590-19-027208:8k_2_02:35]
|  | • | Q4 ending cash balance was $169.6 million, an increase of $12.8 million from Q3 and an increase of $48.5 million from Q4 last year, driven primarily by higher cash flow from operations. |

[0001564590-19-027208:8k_2_02:36]
|  | • | Accounts receivable balance ending Q4 was $174.4 million, with days sales outstanding of 63, an increase of 12 days from Q3 and a decrease of 6 days from Q4 last year. |

[0001564590-19-027208:8k_2_02:37]
|  | • | Q4 ending inventory was $63.6 million, an increase of $6.0 million from Q3 and a decrease of $0.3 million from Q4 last year. |

[0001564590-19-027208:8k_2_02:38]
|  | • | Q4 ending gross debt was $180.5 million, a decrease of $2.4 million from Q3 and a decrease of $19.5 million from Q4 last year. Net Debt* decreased to $9.1 million from $24.2 million in Q3. |

[0001564590-19-027208:8k_2_02:39]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP operating cash flows less purchases of property, plant and equipment. Extreme considers free cash flow as useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant, and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of the non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. As shown in the table below (in thousands):

[0001564590-19-027208:8k_2_02:40]
| Free Cash Flow | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Cash flow provided by (used in) operations | $ | 25,443 |  |  | $ | 20,773 |  |  | $ | 104,945 |  |  | $ | 19,043 |  |
| Less: PP&E CapEx spending |  | (6,549 | ) |  |  | (18,412 | ) |  |  | (22,730 | ) |  |  | (40,411 | ) |
| Total free cash flow | $ | 18,894 |  |  | $ | 2,361 |  |  | $ | 82,215 |  |  | $ | (21,368 | ) |

[0001564590-19-027208:8k_2_02:41]
*Net Debt is defined as gross debt minus loan fees minus cash: as shown in the table below (in millions):

[0001564590-19-027208:8k_2_02:42]
| Gross debt |  |  | Loan fees |  |  | Cash |  |  | Net debt |  |
| $ | 180.5 |  |  | $ | 1.8 |  |  | $ | 169.6 |  |  | $ | 9.1 |  |

[0001564590-19-027208:8k_2_02:43]
Business Outlook:

[0001564590-19-027208:8k_2_02:44]
For its first quarter of fiscal 2020, ending September 30, 2019, the Company is targeting:

[0001564590-19-027208:8k_2_02:45]
|  | Extreme Networks Standalone |  |  | Aerohive Pro-Rated |  |  | Combined Pending Completion of Merger |  |
| (in millions) | Low-end |  |  | High-End |  |  | Contribution |  |  | Low-end |  |  | High-End |  |
| FQ1’20 Guidance – GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 235.0 |  |  | $ | 245.0 |  |  | $ | 15.0 |  |  | $ | 250.0 |  |  | $ | 260.0 |  |
| Gross Margin |  | 55.1 | % |  |  | 57 | % |  |  | 68.6 | % |  |  | 55.9 | % |  |  | 57.9 | % |
| Operating Expenses | $ | 140.2 |  |  | $ | 145.8 |  |  | $ | 17.7 |  |  | $ | 157.9 |  |  | $ | 163.5 |  |
| Operating Margin |  | (4.6 | %) |  |  | (2.3 | %) |  |  | (49.2 | %) |  |  | (7.3 | %) |  |  | (5.0 | %) |
| Net Loss | $ | (15.8 | ) |  | $ | (10.6 | ) |  | $ | (9.2 | ) |  | $ | (24.9 | ) |  | $ | (19.7 | ) |
| Loss per basic share | $ | (0.13 | ) |  | $ | (0.09 | ) |  | $ | (0.08 | ) |  | $ | (0.21 | ) |  | $ | (0.17 | ) |
| Shares outstanding used in calculating GAAP EPS | 118.9 |  |  | 118.9 |  |  | NM |  |  | 118.9 |  |  | 118.9 |  |
| FQ1’20 Guidance – Non - GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Net Revenue | $ | 235.0 |  |  | $ | 245.0 |  |  | $ | 15.0 |  |  | $ | 250.0 |  |  | $ | 260.0 |  |
| Gross Margin |  | 57.5 | % |  |  | 59.5 | % |  |  | 68.6 | % |  |  | 58.1 | % |  |  | 60.1 | % |
| Operating Expenses | $ | 126.0 |  |  | $ | 131.6 |  |  | $ | 12.0 |  |  | $ | 138.0 |  |  | $ | 143.6 |  |
| Operating Margin |  | 3.8 | % |  |  | 5.8 | % |  |  | (11.4 | %) |  |  | 2.9 | % |  |  | 4.8 | % |
| Net Income (loss) | $ | 4.0 |  |  | $ | 9.2 |  |  | $ | (3.5 | ) |  | $ | 0.5 |  |  | $ | 5.7 |  |
| Income per diluted share | $ | 0.03 |  |  | $ | 0.07 |  |  | $ | (0.03 | ) |  | $ | 0.01 |  |  | $ | 0.05 |  |
| Shares outstanding used in calculating Non-GAAP EPS | 121.6 |  |  | 121.6 |  |  | NM |  |  | 121.6 |  |  | 121.6 |  |

[0001564590-19-027208:8k_2_02:46]
The following table shows the GAAP to non-GAAP reconciliation for Q1 FY’20 guidance pending completion of the Aerohive acquisition:

[0001564590-19-027208:8k_2_02:47]
|  | Gross Margin Rate |  |  | Operating Margin Rate |  |  | Earnings per Share |  |
| GAAP | 55.9% - 57.9% |  |  | (7.3)% - (5.0)% |  |  | ($0.21) - ($0.17) |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of product intangibles | 2.1% |  |  | 2.1% |  |  | $ | 0.04 |  |
| Stock based compensation | 0.1% |  |  | 3.0% |  |  | $ | 0.08 |  |
| Restructuring | - |  |  | 2.6% |  |  | $ | 0.05 |  |
| Acquisition | - |  |  | 1.2% |  |  | $ | 0.03 |  |
| Amortization of non product intangibles | - |  |  | 0.9% |  |  | $ | 0.02 |  |
| Non-GAAP | 58.1% - 60.1% |  |  | 2.9% - 4.8% |  |  | $0.01 - $0.05 |  |

[0001564590-19-027208:8k_2_02:48]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0001564590-19-027208:8k_2_02:49]
Conference Call:

[0001564590-19-027208:8k_2_02:50]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the fourth fiscal quarter results as well as the business outlook for first fiscal quarter ending September 30, 2019, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website through August 7, 2019. The conference call may also be heard by dialing 1(877) 303-9826 or international 1 (224) 357-2194. Supplemental financial information to be discussed during the conference call will be posted in the Investor Relations section of the Company's website www.extremenetworks.com including the non-GAAP reconciliation attached to this press release. The encore recording can be accessed by dialing 1 (855) 859-2056 or international 1 (404) 537-3406. Conference ID # 2459939. The encore recording will be available for 7 days following the call.

[0001564590-19-027208:8k_2_02:51]
About Extreme Networks:

[0001564590-19-027208:8k_2_02:52]
Extreme Networks, Inc. (EXTR) delivers software-driven solutions from the enterprise edge to the cloud that are agile, adaptive, and secure to enable digital transformation. Our 100% in-sourced services and support are number one in the industry. Even with 30,000 customers globally, including half of the Fortune 50 and some of the world's leading names in business, hospitality, retail, transportation and logistics, education, government, healthcare and manufacturing, we remain nimble and responsive to ensure customer and partner success. We call this Customer-Driven Networking™. Founded in 1996, Extreme is headquartered in San Jose, California. For more information, visit Extreme's website or call 1-888-257-3000.

[0001564590-19-027208:8k_2_02:53]
Extreme Networks and the Extreme Networks logo are either trademarks or registered trademarks of Extreme Networks, Inc. in the United States and/or other countries.

[0001564590-19-027208:8k_2_02:54]
Non-GAAP Financial Measures:

[0001564590-19-027208:8k_2_02:55]
Extreme provides all financial information required in accordance with generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margins, non-GAAP operating margins, non-GAAP operating expenses, non-GAAP net income and non-GAAP earnings per share. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, acquired inventory adjustments, amortization of acquired intangibles, inventory valuation adjustment, restructuring charges, gain on sale of equity investment, loss on lease contracts, income tax and free cash flow.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company's non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company's GAAP financial information.

[0001564590-19-027208:8k_2_02:56]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company's ongoing performance as a business. Extreme Networks uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0001564590-19-027208:8k_2_02:57]
Forward Looking Statements:

[0001564590-19-027208:8k_2_02:58]
More information about potential factors that could affect the Company's business and financial results are described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" and "Risk Factors" included in the Company’s Quarterly Report on Form 10-Q for the nine months ended March 31, 2019, and Annual Report on Form 10-K for the year ended June 30, 2018 and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme Networks disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0001564590-19-027208:8k_2_02:59]
###

[0001564590-19-027208:8k_2_02:60]
EXTREME NETWORKS, INC.

[0001564590-19-027208:8k_2_02:61]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001564590-19-027208:8k_2_02:62]
(In thousands)

[0001564590-19-027208:8k_2_02:63]
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash |  | $ | 169,607 |  |  | $ | 121,139 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1,054 and $1,478, respectively |  |  | 174,414 |  |  |  | 212,423 |  |
| Inventories |  |  | 63,589 |  |  |  | 63,867 |  |
| Prepaid expenses and other current assets |  |  | 34,379 |  |  |  | 30,484 |  |
| Total current assets |  |  | 441,989 |  |  |  | 427,913 |  |
| Property and equipment, net |  |  | 73,554 |  |  |  | 78,519 |  |
| Intangible assets, net |  |  | 51,112 |  |  |  | 77,092 |  |
| Goodwill |  |  | 138,577 |  |  |  | 139,082 |  |
| Other assets |  |  | 51,642 |  |  |  | 47,642 |  |
| Total assets |  | $ | 756,874 |  |  | $ | 770,248 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  | $ | 9,011 |  |  | $ | 9,007 |  |
| Accounts payable |  |  | 65,704 |  |  |  | 75,689 |  |
| Accrued compensation and benefits |  |  | 51,625 |  |  |  | 50,351 |  |
| Accrued warranty |  |  | 14,779 |  |  |  | 12,807 |  |
| Current portion, deferred revenue, net |  |  | 144,230 |  |  |  | 130,865 |  |
| Other accrued liabilities |  |  | 70,680 |  |  |  | 81,153 |  |
| Total current liabilities |  |  | 356,029 |  |  |  | 359,872 |  |
| Deferred revenue, less current portion |  |  | 59,012 |  |  |  | 43,660 |  |
| Long-term debt, less current portion |  |  | 169,739 |  |  |  | 188,749 |  |
| Deferred income taxes |  |  | 1,957 |  |  |  | 6,135 |  |
| Other long-term liabilities |  |  | 54,150 |  |  |  | 59,100 |  |
| Commitments and contingencies |  |  | — |  |  |  | — |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Convertible preferred stock, $.001 par value, issuable in series, 2,000 shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $.001 par value, 750,000 shares authorized; 121,035 and 116,124 shares issued, respectively; 119,172 and 116,124 shares outstanding, respectively |  |  | 122 |  |  |  | 116 |  |
| Additional paid-in-capital |  |  | 986,772 |  |  |  | 942,397 |  |
| Accumulated other comprehensive loss |  |  | (2,473 | ) |  |  | (1,703 | ) |
| Accumulated deficit |  |  | (853,434 | ) |  |  | (828,078 | ) |
| Treasury stock at cost: 2,366 and 0 shares, respectively |  |  | (15,000 | ) |  |  | — |  |
| Stockholders’ equity |  |  | 115,987 |  |  |  | 112,732 |  |
| Total liabilities and stockholders’ equity |  | $ | 756,874 |  |  | $ | 770,248 |  |

[0001564590-19-027208:8k_2_02:64]
EXTREME NETWORKS, INC.

[0001564590-19-027208:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-027208:8k_2_02:66]
(In thousands, except per share amounts)

[0001564590-19-027208:8k_2_02:67]
(Unaudited)

[0001564590-19-027208:8k_2_02:68]
|  |  | Three Months Ended |  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 189,544 |  |  | $ | 221,304 |  |  | $ | 747,571 |  |  | $ | 764,455 |  |
| Service |  |  | 62,815 |  |  |  | 56,996 |  |  |  | 248,218 |  |  |  | 218,687 |  |
| Total net revenues |  |  | 252,359 |  |  |  | 278,300 |  |  |  | 995,789 |  |  |  | 983,142 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 89,312 |  |  |  | 104,060 |  |  |  | 346,218 |  |  |  | 357,062 |  |
| Service |  |  | 24,101 |  |  |  | 24,073 |  |  |  | 98,336 |  |  |  | 91,563 |  |
| Total cost of revenues |  |  | 113,413 |  |  |  | 128,133 |  |  |  | 444,554 |  |  |  | 448,625 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 100,232 |  |  |  | 117,244 |  |  |  | 401,353 |  |  |  | 407,393 |  |
| Service |  |  | 38,714 |  |  |  | 32,923 |  |  |  | 149,882 |  |  |  | 127,124 |  |
| Total gross profit |  |  | 138,946 |  |  |  | 150,167 |  |  |  | 551,235 |  |  |  | 534,517 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 54,606 |  |  |  | 52,765 |  |  |  | 210,132 |  |  |  | 183,877 |  |
| Sales and marketing |  |  | 77,081 |  |  |  | 73,647 |  |  |  | 285,326 |  |  |  | 267,107 |  |
| General and administrative |  |  | 13,487 |  |  |  | 15,427 |  |  |  | 55,623 |  |  |  | 50,988 |  |
| Acquisition and integration costs, net of bargain purchase gain |  |  | 831 |  |  |  | 6,225 |  |  |  | 3,444 |  |  |  | 53,900 |  |
| Restructuring charges, net of reversals |  |  | 3,808 |  |  |  | 3,220 |  |  |  | 5,090 |  |  |  | 8,140 |  |
| Amortization of intangibles |  |  | 1,338 |  |  |  | 2,254 |  |  |  | 6,346 |  |  |  | 8,715 |  |
| Total operating expenses |  |  | 151,151 |  |  |  | 153,538 |  |  |  | 565,961 |  |  |  | 572,727 |  |
| Operating loss |  |  | (12,205 | ) |  |  | (3,371 | ) |  |  | (14,726 | ) |  |  | (38,210 | ) |
| Interest income |  |  | 567 |  |  |  | 743 |  |  |  | 2,232 |  |  |  | 2,847 |  |
| Interest expense |  |  | (3,009 | ) |  |  | (5,160 | ) |  |  | (12,597 | ) |  |  | (13,923 | ) |
| Other (expense) income, net |  |  | (438 | ) |  |  | 514 |  |  |  | (783 | ) |  |  | 2,639 |  |
| Loss before income taxes |  |  | (15,085 | ) |  |  | (7,274 | ) |  |  | (25,874 | ) |  |  | (46,647 | ) |
| Provision (benefit) for income taxes |  |  | 1,970 |  |  |  | (1,642 | ) |  |  | (21 | ) |  |  | 145 |  |
| Net loss |  | $ | (17,055 | ) |  | $ | (5,632 | ) |  | $ | (25,853 | ) |  | $ | (46,792 | ) |
| Basic and diluted net loss per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss per share - basic |  | $ | (0.14 | ) |  | $ | (0.05 | ) |  | $ | (0.22 | ) |  | $ | (0.41 | ) |
| Net loss per share - diluted |  | $ | (0.14 | ) |  | $ | (0.05 | ) |  | $ | (0.22 | ) |  | $ | (0.41 | ) |
| Shares used in per share calculation - basic |  |  | 118,961 |  |  |  | 115,962 |  |  |  | 117,954 |  |  |  | 114,221 |  |
| Shares used in per share calculation - diluted |  |  | 118,961 |  |  |  | 115,962 |  |  |  | 117,954 |  |  |  | 114,221 |  |

[0001564590-19-027208:8k_2_02:69]
EXTREME NETWORKS, INC.

[0001564590-19-027208:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001564590-19-027208:8k_2_02:71]
(In thousands)

[0001564590-19-027208:8k_2_02:72]
|  |  | Year Ended |  |
|  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (25,853 | ) |  | $ | (46,792 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 26,889 |  |  |  | 23,471 |  |
| Amortization of intangible assets |  |  | 25,984 |  |  |  | 25,585 |  |
| Provision for doubtful accounts |  |  | 1,407 |  |  |  | 1,687 |  |
| Stock-based compensation |  |  | 32,897 |  |  |  | 27,633 |  |
| Deferred income taxes |  |  | (5,788 | ) |  |  | (4,677 | ) |
| Unrealized/realized loss (gain) on equity investment |  |  | - |  |  |  | (3,967 | ) |
| Realized gain on bargain purchase |  |  | - |  |  |  | (5,030 | ) |
| Loss on extinguishment of debt |  |  | - |  |  |  | 1,173 |  |
| Non-cash interest |  |  | 3,022 |  |  |  | - |  |
| Other |  |  | 584 |  |  |  | 5,933 |  |
| Changes in operating assets and liabilities, net of acquisitions |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 36,331 |  |  |  | (69,518 | ) |
| Inventories |  |  | 278 |  |  |  | 17,343 |  |
| Prepaid expenses and other assets |  |  | (6,979 | ) |  |  | (8,014 | ) |
| Accounts payable |  |  | (9,850 | ) |  |  | 18,844 |  |
| Accrued compensation and benefits |  |  | 1,274 |  |  |  | 4,981 |  |
| Deferred revenue |  |  | 28,716 |  |  |  | 28,366 |  |
| Other current and long-term liabilities |  |  | (3,967 | ) |  |  | 2,025 |  |
| Net cash provided by operating activities |  |  | 104,945 |  |  |  | 19,043 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  | (22,730 | ) |  |  | (40,411 | ) |
| Business acquisitions |  |  | — |  |  |  | (97,581 | ) |
| Proceeds from sale of investment |  |  | 921 |  |  |  | 5,521 |  |
| Net cash used in investing activities |  |  | (21,809 | ) |  |  | (132,471 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Borrowings under Revolving Facility |  |  | — |  |  |  | 10,000 |  |
| Borrowings under Term Loan |  |  | — |  |  |  | 290,000 |  |
| Loan fees on borrowings |  |  | (545 | ) |  |  | (3,211 | ) |
| Repayments of debt |  |  | (19,875 | ) |  |  | (193,713 | ) |
| Repurchase of stock |  |  | (15,000 | ) |  |  | — |  |
| Proceeds from issuance of common stock, net of tax withholding |  |  | 11,484 |  |  |  | 3,341 |  |
| Contingent consideration obligations |  |  | (6,506 | ) |  |  | (671 | ) |
| Deferred payments on an acquisition |  |  | (4,000 | ) |  |  | (1,000 | ) |
| Net cash (used in) provided by financing activities |  |  | (34,442 | ) |  |  | 104,746 |  |
| Foreign currency effect on cash |  |  | (226 | ) |  |  | (629 | ) |
| Net increase (decrease) in cash |  |  | 48,468 |  |  |  | (9,311 | ) |
| Cash and cash equivalents at beginning of period |  |  | 121,139 |  |  |  | 130,450 |  |
| Cash and cash equivalents at end of period |  | $ | 169,607 |  |  | $ | 121,139 |  |

[0001564590-19-027208:8k_2_02:73]
Extreme Networks, Inc.

[0001564590-19-027208:8k_2_02:74]
Non-GAAP Measures of Financial Performance

[0001564590-19-027208:8k_2_02:75]
To supplement the Company's consolidated financial statements presented in accordance with generally accepted accounting principles, ("GAAP"), Extreme Networks uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP net income, non-GAAP gross margin, non-GAAP operating expenses non-GAAP earnings per diluted share and Free Cash Flow.

[0001564590-19-027208:8k_2_02:76]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.  In this press release, Extreme Networks also presents its target for non-GAAP expenses, which is expenses less share-based compensation expense, acquisition and integration costs, acquired inventory adjustments, restructuring charges, amortization of acquired intangibles, inventory valuation adjustments, gain on sale of equity investment, loss on lease contracts, income tax and free cash flow.

[0001564590-19-027208:8k_2_02:77]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme Networks' results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme Networks' results of operations in conjunction with the corresponding GAAP measures.

[0001564590-19-027208:8k_2_02:78]
Extreme believes these non-GAAP measures when shown in conjunction with the corresponding GAAP measures enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme Networks has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0001564590-19-027208:8k_2_02:79]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, acquired inventory adjustment, amortization of intangibles, inventory valuation adjustments, restructuring charges, gain on sale of equity investment, loss on lease contracts, income tax and free cash flow.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0001564590-19-027208:8k_2_02:80]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0001564590-19-027208:8k_2_02:81]
Stock-based compensation. This expense consists of expenses for stock options, restricted stock and employee stock purchases through its Employee Stock Purchase Plan.  Extreme Networks excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to operating results. Extreme Networks expects to incur share-based compensation expenses in future periods.

[0001564590-19-027208:8k_2_02:82]
Acquisition and integration costs. Acquisition and integration costs consist of legal and professional fees related to the acquisition of a) Campus Fabric business, b) Data Center business and c) the bargain purchase gain for the capital financing business; Extreme Networks excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0001564590-19-027208:8k_2_02:83]
Acquired inventory adjustments.   Purchase accounting adjustments relating to the mark up of acquired inventory to fair value less disposal costs.

[0001564590-19-027208:8k_2_02:84]
Amortization of acquired intangibles.  Amortization of acquired intangibles includes the monthly amortization expense of acquired intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology intangible is recorded in product cost of goods sold, while the amortization for the other intangibles are recorded in operating expenses.  Extreme Networks excludes these non-cash expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0001564590-19-027208:8k_2_02:85]
Inventory valuation adjustments.   Adjustments relating to the mark down of inventory due to end of life.

[0001564590-19-027208:8k_2_02:86]
Restructuring expenses. Restructuring expenses primarily consist of severance costs for employees which have no benefit to continuing operations and accrued lease costs pertaining to the estimated future obligations for non-cancelable lease payments related to excess facilities. Extreme Networks excludes restructuring expenses since they result from events that often occur outside of the ordinary course of continuing operations.

[0001564590-19-027208:8k_2_02:87]
Gain on sale of equity investment.  The gain on the sale of an equity investment refers to a third party acquisition that acquired a business entity in which the Company had an equity investment.

[0001564590-19-027208:8k_2_02:88]
Loss on lease contracts.  The loss on lease contracts refers to leased facilities to which the Company has a contractual obligation but will not receive a future financial benefit.

[0001564590-19-027208:8k_2_02:89]
Income tax.   Income tax adjustments relate to the tax impact of a reduced US tax rate applied to deferred tax items pursuant to the recently enacted US tax legislation, the tax benefit resulting from the impairment of a lease acquired from Avaya in Canada, the release of a deferred tax liability for amortizable goodwill given recently enacted US tax legislation, the release of a deferred tax liability related to a restructuring of our foreign operations, and the impact of the release of our Australian valuation allowance.

[0001564590-19-027208:8k_2_02:90]
We do not reflect a tax effect associated with the Non-GAAP operating adjustments as the adjustments are primarily related to the US entity which has a full valuation of various loss carryforward tax attributes.

[0001564590-19-027208:8k_2_02:91]
EXTREME NETWORKS, INC.

[0001564590-19-027208:8k_2_02:92]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001564590-19-027208:8k_2_02:93]
GAAP TO NON-GAAP RECONCILIATION

[0001564590-19-027208:8k_2_02:94]
(In thousands, except percentages and per share amounts)

[0001564590-19-027208:8k_2_02:95]
(Unaudited)

[0001564590-19-027208:8k_2_02:96]
| Non-GAAP Revenue | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Revenue - GAAP Basis | $ | 252,359 |  |  | $ | 278,300 |  |  | $ | 995,789 |  |  | $ | 983,142 |  |
| Revenue - Non-GAAP Basis | $ | 252,359 |  |  | $ | 278,300 |  |  | $ | 995,789 |  |  | $ | 983,142 |  |

[0001564590-19-027208:8k_2_02:97]
| Non-GAAP Gross Margin | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| Gross profit - GAAP Basis | $ | 138,946 |  |  | $ | 150,167 |  |  | $ | 551,235 |  |  | $ | 534,517 |  |
| Gross margin - GAAP Basis percentage |  | 55.1 | % |  |  | 54.0 | % |  |  | 55.4 | % |  |  | 54.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 195 |  |  |  | 523 |  |  |  | 2,483 |  |  |  | 1,695 |  |
| Acquired inventory adjustments |  | — |  |  |  | 494 |  |  |  | — |  |  |  | 5,278 |  |
| Acquisition and integration costs |  | — |  |  |  | 3,626 |  |  |  | 1,752 |  |  |  | 11,212 |  |
| Amortization of intangibles |  | 4,809 |  |  |  | 5,481 |  |  |  | 19,222 |  |  |  | 16,590 |  |
| Inventory valuation adjustments |  | 5,334 |  |  |  | — |  |  |  | 5,334 |  |  |  | — |  |
| Total adjustments to GAAP gross profit | $ | 10,338 |  |  | $ | 10,124 |  |  | $ | 28,791 |  |  | $ | 34,775 |  |
| Gross profit - Non-GAAP | $ | 149,284 |  |  | $ | 160,291 |  |  | $ | 580,026 |  |  | $ | 569,292 |  |
| Gross margin - Non-GAAP percentage |  | 59.2 | % |  |  | 57.6 | % |  |  | 58.2 | % |  |  | 57.9 | % |

[0001564590-19-027208:8k_2_02:98]
| Non-GAAP Operating Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| GAAP operating loss | $ | (12,205 | ) |  | $ | (3,371 | ) |  | $ | (14,726 | ) |  | $ | (38,210 | ) |
| GAAP operating loss percentage |  | (4.8 | )% |  |  | (1.2 | )% |  |  | (1.5 | )% |  |  | (3.9 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 195 |  |  |  | 523 |  |  |  | 2,483 |  |  |  | 1,695 |  |
| Stock based compensation expense, R&D |  | 2,490 |  |  |  | 2,395 |  |  |  | 10,443 |  |  |  | 7,642 |  |
| Stock based compensation expense, S&M |  | 3,218 |  |  |  | 2,766 |  |  |  | 11,747 |  |  |  | 9,843 |  |
| Stock based compensation expense, G&A |  | 2,655 |  |  |  | 2,303 |  |  |  | 8,224 |  |  |  | 8,453 |  |
| Inventory valuation adjustments |  | 5,334 |  |  |  | — |  |  |  | 5,334 |  |  |  | — |  |
| Acquisition and integration costs |  | 831 |  |  |  | 9,851 |  |  |  | 5,196 |  |  |  | 65,112 |  |
| Restructuring charge, net of reversal |  | 3,808 |  |  |  | 3,220 |  |  |  | 5,090 |  |  |  | 8,140 |  |
| Acquired inventory adjustments |  | — |  |  |  | 494 |  |  |  | — |  |  |  | 5,278 |  |
| Litigation |  | — |  |  |  | — |  |  |  | — |  |  |  | (158 | ) |
| Amortization of intangibles |  | 6,147 |  |  |  | 7,735 |  |  |  | 25,568 |  |  |  | 25,305 |  |
| Remeasurement of contingent consideration liability |  | — |  |  |  | 1,470 |  |  |  | — |  |  |  | 1,470 |  |
| Loss on lease contracts |  | — |  |  |  | — |  |  |  | 1,288 |  |  |  | — |  |
| Total adjustments to GAAP operating loss | $ | 24,678 |  |  | $ | 30,757 |  |  | $ | 75,373 |  |  | $ | 132,780 |  |
| Non-GAAP operating income | $ | 12,473 |  |  | $ | 27,386 |  |  | $ | 60,647 |  |  | $ | 94,570 |  |
| Non-GAAP operating income percentage |  | 4.9 | % |  |  | 9.8 | % |  |  | 6.1 | % |  |  | 9.6 | % |

[0001564590-19-027208:8k_2_02:99]
| Non-GAAP Net Income | Three Months Ended |  |  | Year Ended |  |
|  | June 30, 2019 |  |  | June 30, 2018 |  |  | June 30, 2019 |  |  | June 30, 2018 |  |
| GAAP net loss | $ | (17,055 | ) |  | $ | (5,632 | ) |  | $ | (25,853 | ) |  | $ | (46,792 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock based compensation expense |  | 8,558 |  |  |  | 7,987 |  |  |  | 32,897 |  |  |  | 27,633 |  |
| Inventory valuation adjustments |  | 5,334 |  |  |  | — |  |  |  | 5,334 |  |  |  | — |  |
| Acquisition and integration costs |  | 831 |  |  |  | 9,851 |  |  |  | 5,196 |  |  |  | 65,112 |  |
| Restructuring charge, net of reversal |  | 3,808 |  |  |  | 3,220 |  |  |  | 5,090 |  |  |  | 8,140 |  |
| Acquired inventory adjustments |  | — |  |  |  | 494 |  |  |  | — |  |  |  | 5,278 |  |
| Litigation |  | — |  |  |  | — |  |  |  | — |  |  |  | (158 | ) |
| Amortization of intangibles |  | 6,147 |  |  |  | 7,735 |  |  |  | 25,568 |  |  |  | 25,305 |  |
| Interest expense |  | — |  |  |  | 1,366 |  |  |  | — |  |  |  | 1,366 |  |
| Loss on extinguishment of debt |  | — |  |  |  | 1,173 |  |  |  | — |  |  |  | 1,173 |  |
| Gain on sale of equity investment |  | — |  |  |  | (210 | ) |  |  | — |  |  |  | (3,967 | ) |
| Remeasurement of contingent consideration liability |  | — |  |  |  | 1,470 |  |  |  | — |  |  |  | 1,470 |  |
| Loss on lease contracts |  | — |  |  |  | — |  |  |  | 1,288 |  |  |  | — |  |
| Income tax |  | — |  |  |  | (3,430 | ) |  |  | (7,770 | ) |  |  | (6,532 | ) |
| Total adjustments to GAAP net loss | $ | 24,678 |  |  | $ | 29,656 |  |  | $ | 67,603 |  |  | $ | 124,820 |  |
| Non-GAAP net income | $ | 7,623 |  |  | $ | 24,024 |  |  | $ | 41,750 |  |  | $ | 78,028 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share-diluted | $ | 0.06 |  |  | $ | 0.20 |  |  | $ | 0.35 |  |  | $ | 0.65 |  |
| Shares used in net income per share-diluted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP shares used |  | 122,226 |  |  |  | 120,361 |  |  |  | 120,714 |  |  |  | 119,781 |  |
