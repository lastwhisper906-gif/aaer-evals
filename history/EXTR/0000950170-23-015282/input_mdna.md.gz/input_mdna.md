# EXTR MD&A — 0000950170-23-015282


## mdna

[0000950170-23-015282:mdna:1]
[same as prior period, unchanged from 0001564590-23-000867:mdna:1]

[0000950170-23-015282:mdna:2]
[same as prior period, unchanged from 0001564590-23-000867:mdna:2]

[0000950170-23-015282:mdna:3]
[same as prior period, unchanged from 0001564590-23-000867:mdna:3]

[0000950170-23-015282:mdna:4]
[same as prior period, unchanged from 0001564590-23-000867:mdna:4]

[0000950170-23-015282:mdna:5]
[same as prior period, unchanged from 0001564590-23-000867:mdna:5]

[0000950170-23-015282:mdna:6]
[same as prior period, unchanged from 0001564590-23-000867:mdna:6]

[0000950170-23-015282:mdna:7]
[same as prior period, unchanged from 0001564590-23-000867:mdna:7]

[0000950170-23-015282:mdna:8]
[same as prior period, unchanged from 0001564590-23-000867:mdna:8]

[0000950170-23-015282:mdna:9]
[same as prior period, unchanged from 0001564590-23-000867:mdna:9]

[0000950170-23-015282:mdna:10]
[same as prior period, unchanged from 0001564590-23-000867:mdna:10]

[0000950170-23-015282:mdna:11]
[same as prior period, unchanged from 0001564590-23-000867:mdna:11]

[0000950170-23-015282:mdna:12]
[same as prior period, unchanged from 0001564590-23-000867:mdna:12]

[0000950170-23-015282:mdna:13]
[same as prior period, unchanged from 0001564590-23-000867:mdna:13]

[0000950170-23-015282:mdna:14]
We estimate the total addressable market for our Enterprise Networking solutions consisting of cloud networking, wireless local area networks (“WLAN”), data center networking, ethernet switching, campus local area networks (“LAN”), and SD-WAN solutions to be approximately $33 billion and growing at approximately 12% annually over the next three years. This comprises $22 billion for campus networking, $4.6 billion for 5G service available market in 5G and data centers, for which Extreme is targeting growing to approximately $50 - $100 million per year over the next three to five years, and a $2.2 billion SD-WAN market. We also participate in the $4 billion networking software market for solutions such as cloud-based network management, network automation, on-premises network management, and other networking related software.

[0000950170-23-015282:mdna:15]
[same as prior period, unchanged from 0001564590-23-000867:mdna:15]

[0000950170-23-015282:mdna:16]
[same as prior period, unchanged from 0001564590-23-000867:mdna:16]

[0000950170-23-015282:mdna:17]
[same as prior period, unchanged from 0001564590-23-000867:mdna:17]

[0000950170-23-015282:mdna:18]
•
Infinitely distributed connectivity is the enterprise-grade reliable connectivity that allows users to connect to anywhere, from anywhere. It is always present, available and assured, while being secure and manageable.

[0000950170-23-015282:mdna:19]
•
Scalable cloud allows administrators to harness the power of the cloud to efficiently onboard, manage, orchestrate, troubleshoot the network, and find data and insights of the distributed connectivity at their pace in their way.

[0000950170-23-015282:mdna:20]
•
Consumer-centric experience designed to deliver a best-in-class experience to users who consume network services.

[0000950170-23-015282:mdna:21]
[same as prior period, unchanged from 0001564590-23-000867:mdna:21]

[0000950170-23-015282:mdna:22]
[same as prior period, unchanged from 0001564590-23-000867:mdna:22]

[0000950170-23-015282:mdna:23]
•
Creating effortless networking solutions that allow all of us to advance.  We believe that progress is achieved when we connect—allowing us to learn, understand, create, and grow. We make connecting simple and easy with effortless networking experiences that enable all of us to advance how we live, work, and share.

[0000950170-23-015282:mdna:24]
•
Provide a differentiated end-to-end cloud architecture.  Cloud networking is estimated to be a $4.1 billion segment of the networking market comprised of cloud managed services and cloud-managed products, which are largely WLAN access points and ethernet switches, growing at a 13% over the next three years, according to data from 650 Group Market Research. Cloud management technology has evolved significantly over the past decade. We believe we deliver a combination of innovation, reliability, and security with the leading end-to-end cloud management platform powered by ML and AI that spans from the Internet of Things (“IoT”) edge to the enterprise data center. Key characteristics of our cloud architecture include:

[0000950170-23-015282:mdna:25]
o
A robust cloud management platform that delivers visibility, intelligence, and assurance from the IoT edge to the core.

[0000950170-23-015282:mdna:26]
o
Cloud Choice for customers: Our cloud networking solution is available on all major cloud providers (Amazon Web Services (“AWS”), Google Cloud Platform (“GCP”) and Microsoft Azure).

[0000950170-23-015282:mdna:27]
o
Enhanced Network Data plans to improve an organization’s ability to make smarter, more effective business decisions.

[0000950170-23-015282:mdna:28]
o
Consumption Flexibility: Offer a range of financing and network purchase options. Our value-based subscription tiers (including Connect, Navigator and Pilot) provide customers with flexibility to grow as they go, as well as offer pool-able and portable licenses that can be transferred between products (e.g., access points and switches) at one fixed price.

[0000950170-23-015282:mdna:29]
o
“No 9s” Reliability and Resiliency to ensure business continuity for our customers.

[0000950170-23-015282:mdna:30]
•
Offer customers choice: public or private cloud, or on-premises. We leverage the cloud where it makes sense for our customers and provide on-premises solutions where customers need them and also have a solution for those who want to harness the power of both. Our hybrid approach gives our customers options to adapt the technology to their business. At the same time, all of our solutions have visibility, control and strategic information built in, all tightly integrated with a single view across all of the installed products. Our customers can understand what is going on across their network and applications in real time – who, when, and what is connected to the network, which is critical for bring your own device (“BYOD”) and IoT usage.

[0000950170-23-015282:mdna:31]
•
Highest value of cloud management subscriptions. ExtremeCloud IQ Pilot provides our customers with four key applications enabling organizations to eliminate overlays.

[0000950170-23-015282:mdna:32]
o
Extreme AirDefense™ is a comprehensive wireless intrusion prevention system that simplifies the protection, monitoring and security of wireless networks. With the added Bluetooth and Bluetooth low energy intrusion prevention, network administrators can address growing threats against Bluetooth and low energy devices.

[0000950170-23-015282:mdna:33]
o
ExtremeLocation™ delivers proximity, presence and location-based services for advanced contact tracing in support of the location-intelligent enterprise.

[0000950170-23-015282:mdna:34]
o
ExtremeGuest™ is a comprehensive guest engagement solution that enables IT administrators to use analytical insights to engage visitors with personalized engagements.

[0000950170-23-015282:mdna:35]
o
Extreme IoT™ delivers simple and secure onboarding, profiling, segmentation and filtering of IoT devices on a production network.

[0000950170-23-015282:mdna:36]
•
Offers universal platforms for enterprise class switching and wireless infrastructure.  Extreme offers universal platforms which support multiple deployment use cases, providing flexibility and investment protection.

[0000950170-23-015282:mdna:37]
o
Universal switches (5720/5520/5420/5320) support fabric or traditional networking with a choice of cloud or on-premises (air-gapped or cloud connected) management.

[0000950170-23-015282:mdna:38]
o
Universal WiFi 6/6E APs (300/400, 5000 series) support campus or distributed deployments with a choice of cloud or on-premises (air-gapped or cloud connected) management.

[0000950170-23-015282:mdna:39]
o
Universal licensing with one portable management license for any device and for any type of management. For switches, operating system feature licenses are portable, and bulk activated through ExtremeCloud IQ.

[0000950170-23-015282:mdna:40]
•
Enable a common fabric to simplify and automate the network.  Fabric technologies virtualize the network infrastructure (decoupling network services from physical connectivity) which enables network services to be turned up faster, with lower likelihood of error. They make the underlying network much easier to design, implement, manage and troubleshoot.

[0000950170-23-015282:mdna:41]
•
End-to-End Portfolio. Our cloud-driven solutions provide visibility, control and strategic intelligence from the edge to the data center, across networks and applications. Our solutions include wired switching, wireless switching, wireless access points, WLAN controllers, routers, and an extensive portfolio of software applications that deliver AI-enhanced access control, network and application analytics, as well as network management. All can be managed, assessed and controlled from a single pane of glass on premises or from the cloud.

[0000950170-23-015282:mdna:42]
•
Provide high-quality “in-house” customer service and support. We seek to enhance customer satisfaction and build customer loyalty through high-quality service and support. This includes a wide range of standard support programs to the level of service our customers require, from standard business hours to global 24-hour-a-day, 365-days-a-year real-time responsive support.

[0000950170-23-015282:mdna:43]
•
Extend switching and routing technology leadership.  Our technological leadership is based on innovative switching, routing and wireless products, the depth and focus of our market experience and our operating systems - the software that runs on all of our networking products. Our products reduce operating expenses for our customers and enable a more flexible and dynamic network environment that will help them meet the upcoming demands of IoT, mobile, and cloud.

[0000950170-23-015282:mdna:44]
•
Expand Wi-Fi technology leadership.  Wireless is today’s network access method of choice and every business must deal with scale, density and BYOD challenges. The network edge landscape is changing as the explosion of mobile devices increases the demand for mobile, transparent, and always-on wired to wireless edge services. The unified access layer requires distributed intelligent components to ensure that access control and resiliency of business services are available across the entire infrastructure and manageable from a single console. We are at a technology inflection point with the pending migration from Wi-Fi 5 solutions to Wi-Fi 6 (802.11ax), focused on providing more efficient access to the broad array of connected devices. We believe we have the industry’s broadest Wi-Fi 6 wireless portfolio providing intelligence for the wired/wireless edge and enhanced by our cloud architecture with machine learning and AI-driven insights.

[0000950170-23-015282:mdna:45]
•
Offer a superior quality of experience. Our network-powered application analytics provide actionable business insights by capturing and analyzing context-based data about the network and applications to deliver meaningful intelligence about applications, users, locations and devices. With an easy to comprehend dashboard, our applications help businesses turn their network into a strategic business asset that helps executives make faster and more effective decisions.

[0000950170-23-015282:mdna:46]
•
Expand market penetration by targeting high-growth market segments.  Within the campus, we focus on the mobile user, leveraging our automation capabilities and tracking WLAN growth. Our data center approach leverages our product portfolio to address the needs of public and private cloud data center providers. We believe that the cloud networking compound annual growth rate will continue to outpace the compound annual growth rate for on-premises managed networking. Our focus is on expanding our technology foothold in the critical cloud networking segment to accelerate not only cloud management adoption, but also subscription-based licensing (SaaS) consumption.

[0000950170-23-015282:mdna:47]
•
Leverage and expand multiple distribution channels. We distribute our products through select distributors, a large number of resellers and system-integrators worldwide, as well as several large strategic partners. We maintain a field sales force to support our channel partners and to sell directly to certain strategic accounts. As an independent networking vendor, we seek to provide products that, when combined with the offerings of our channel partners, create compelling solutions for end-user customers.

[0000950170-23-015282:mdna:48]
•
Maintain and extend our strategic relationships. We have established strategic relationships with a number of industry-leading vendors to both, provide increased and enhanced routes to market, and collaboratively develop unique solutions.

[0000950170-23-015282:mdna:49]
•
Expand our reach with ExtremeCloud SD-WAN. ExtremeCloud SD-WAN is a software-defined wide area networks solution offered as an all-inclusive subscription, which includes hardware, the cloud-based SD-WAN service, support and maintenance, and customer success support. This helps customers reduce total cost of ownership as they deliver quality user experience for applications used in site-to-site and site-to-cloud environments. This solution detects and optimizes applications automatically and can apply performance-based dynamic WAN selection for quality and reliability. Included also are security options such as a built-in zone-based firewall, EdgeSentry (in partnership with Check Point) for cloud-based firewall as a service and other advanced security capabilities, and integration with Secure Web Gateway partners such as Palo Alto Networks, Zscaler, and Symantec.

[0000950170-23-015282:mdna:50]
[same as prior period, unchanged from 0001564590-23-000867:mdna:52]

[0000950170-23-015282:mdna:51]
During the third quarter of fiscal 2023, we achieved the following results:

[0000950170-23-015282:mdna:52]
•
Net revenues of $332.5 million compared to $285.5 million in the third quarter of fiscal 2022.

[0000950170-23-015282:mdna:53]
•
Product revenues of $241.1 million compared to $198.4 million in the third quarter of fiscal 2022.

[0000950170-23-015282:mdna:54]
•
Service and subscription revenues of $91.4 million compared to $87.1 million in the third quarter of fiscal 2022.

[0000950170-23-015282:mdna:55]
•
Total gross margin of 57.7% of net revenues compared to 56.5% of net revenues in the third quarter of fiscal 2022.

[0000950170-23-015282:mdna:56]
•
Operating income of  $29.6 million compared to $17.3 million in the third quarter of fiscal 2022.

[0000950170-23-015282:mdna:57]
•
Net income of $22.1 million compared to $12.8 million in the third quarter of fiscal 2022.

[0000950170-23-015282:mdna:58]
During the first nine months of fiscal 2023, we reflected the following results:

[0000950170-23-015282:mdna:59]
•
Cash flows provided by operating activities of $168.5 million compared to $64.1 million in the nine months ended March 31, 2022.

[0000950170-23-015282:mdna:60]
•
Cash of $203.0 million as of March 31, 2023 compared to $194.5 million as of June 30, 2022.

[0000950170-23-015282:mdna:61]
[same as prior period, unchanged from 0001564590-23-000867:mdna:63]

[0000950170-23-015282:mdna:62]
[same as prior period, unchanged from 0001564590-23-000867:mdna:64]

[0000950170-23-015282:mdna:63]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2023 |  | March 31,2022 |  | $Change |  | %Change |  | March 31,2023 |  | March 31,2022 |  | $Change |  | %Change |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $241,058 |  | $198,373 |  | $42,685 |  | 21.5 % |  | $670,779 |  | $574,636 |  | $96,143 |  | 16.7 % |
| Percentage of net revenues |  | 72.5% |  | 69.5% |  |  |  |  |  | 70.7% |  | 68.9% |  |  |  |  |
| Service and subscription |  | 91,449 |  | 87,135 |  | 4,314 |  | 5.0 % |  | 277,765 |  | 259,489 |  | 18,276 |  | 7.0 % |
| Percentage of net revenues |  | 27.5% |  | 30.5% |  |  |  |  |  | 29.3% |  | 31.1% |  |  |  |  |
| Total net revenues |  | $332,507 |  | $285,508 |  | $46,999 |  | 16.5 % |  | $948,544 |  | $834,125 |  | $114,419 |  | 13.7 % |

[0000950170-23-015282:mdna:64]
Product revenues increased $42.7 million or 21.5% for the three months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. Product revenues increased $96.1 million or 16.7% for the nine months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increases in product revenues were primarily due to strong demand for our products and higher shipments resulting from an easing in supply chain constraints which had impacted our ability to fulfill the demand for our products.

[0000950170-23-015282:mdna:65]
Service and subscription revenues increased $4.3 million or 5.0% for the three months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. Service and subscription revenues increased $18.3 million or 7.0% for the nine months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increases in service and subscription revenues were primarily due to the growth in our subscription business.

[0000950170-23-015282:mdna:66]
[same as prior period, unchanged from 0001564590-23-000867:mdna:68]

[0000950170-23-015282:mdna:67]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2023 |  | March 31,2022 |  | $Change |  | %Change |  | March 31,2023 |  | March 31,2022 |  | $Change |  | %Change |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $132,143 |  | $105,791 |  | $26,352 |  | 24.9 % |  | $358,514 |  | $310,177 |  | $48,337 |  | 15.6 % |
| Percentage of product revenues |  | 54.8% |  | 53.3% |  |  |  |  |  | 53.4% |  | 54.0% |  |  |  |  |
| Service and subscription |  | 59,795 |  | 55,567 |  | 4,228 |  | 7.6 % |  | 181,787 |  | 165,570 |  | 16,217 |  | 9.8 % |
| Percentage of service and subscription revenues |  | 65.4% |  | 63.8% |  |  |  |  |  | 65.4% |  | 63.8% |  |  |  |  |
| Total gross profit |  | $191,938 |  | $161,358 |  | $30,580 |  | 19.0 % |  | $540,301 |  | $475,747 |  | $64,554 |  | 13.6 % |
| Percentage of net revenues |  | 57.7% |  | 56.5% |  |  |  |  |  | 57.0% |  | 57.0% |  |  |  |  |

[0000950170-23-015282:mdna:68]
Product gross profit increased $26.4 million or 24.9% for the three months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in product gross profit was primarily due to increased product revenues along with lower amortization of intangibles due to certain intangibles being fully amortized, lower distribution costs due to easing of supply chain constraints, partially offset by higher product costs, higher overhead cost, higher warranty reserve, and higher excess and obsolete inventory.

[0000950170-23-015282:mdna:69]
Product gross profit increased $48.3 million or 15.6% for the nine months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in product gross profit was primarily due to increased product revenues along with lower amortization of intangibles due to certain intangibles being fully amortized, partially offset by higher product costs, higher overhead costs, higher warranty reserves and higher excess and obsolete inventory.

[0000950170-23-015282:mdna:70]
Service and subscription gross profit increased $4.2 million or 7.6% for the three months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. Service and subscription gross profit increased $16.2 million or 9.8% for the nine months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increases in service and subscription gross profits were primarily due to increased service, subscription revenues and lower professional services fees, partially offset by higher cloud services costs.

[0000950170-23-015282:mdna:71]
[same as prior period, unchanged from 0001564590-23-000867:mdna:73]

[0000950170-23-015282:mdna:72]
[same as prior period, unchanged from 0001564590-23-000867:mdna:74]

[0000950170-23-015282:mdna:73]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2023 |  | March 31,2022 |  | $Change |  | %Change |  | March 31,2023 |  | March 31,2022 |  | $Change |  | %Change |
| Research and development |  | $54,837 |  | $49,615 |  | $5,222 |  | 10.5 % |  | $158,444 |  | $145,461 |  | $12,983 |  | 8.9 % |
| Sales and marketing |  | 83,962 |  | 72,840 |  | 11,122 |  | 15.3 % |  | 242,882 |  | 213,932 |  | 28,950 |  | 13.5 % |
| General and administrative |  | 21,683 |  | 17,714 |  | 3,969 |  | 22.4 % |  | 64,315 |  | 52,594 |  | 11,721 |  | 22.3 % |
| Acquisition and integration costs |  | — |  | 2,833 |  | (2,833) |  | (100.0)% |  | 390 |  | 6,456 |  | (6,066) |  | (94.0)% |
| Restructuring and related charges |  | 1,363 |  | 407 |  | 956 |  | 234.9 % |  | 2,320 |  | 978 |  | 1,342 |  | 137.2 % |
| Amortization of intangibles |  | 510 |  | 638 |  | (128) |  | (20.1)% |  | 1,537 |  | 2,596 |  | (1,059) |  | (40.8)% |
| Total operating expenses |  | $162,355 |  | $144,047 |  | $18,308 |  | 12.7 % |  | $469,888 |  | $422,017 |  | $47,871 |  | 11.3 % |

[0000950170-23-015282:mdna:74]
[same as prior period, unchanged from 0001564590-23-000867:mdna:76]

[0000950170-23-015282:mdna:75]
[same as prior period, unchanged from 0001564590-23-000867:mdna:77]

[0000950170-23-015282:mdna:76]
Research and development expenses increased by $5.2 million or 10.5% for the three months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in research and development expenses was primarily due to a $3.4 million increase in personnel costs due to higher compensation costs primarily related to share-based compensation, a $0.8 million increase in consultant fees, a $0.4 million increase in software licenses and engineering project costs and a $0.6 million increase in other costs primarily related to travel expenses and equipment costs.

[0000950170-23-015282:mdna:77]
Research and development expenses increased by $13.0 million or 8.9% for the nine months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in research and development expenses was primarily due to a $6.7 million increase in personnel related costs due to higher compensation costs primarily related to share-based compensation, a $1.5 million increase in consultant fees, a $1.8 million increase in software licenses and engineering project costs, a $1.2 million increase in equipment related costs, a $0.8 increase in facility and information technology costs and a $1.0 million increase in other costs primarily related to travel and recruiting expenses.

[0000950170-23-015282:mdna:78]
[same as prior period, unchanged from 0001564590-23-000867:mdna:80]

[0000950170-23-015282:mdna:79]
[same as prior period, unchanged from 0001564590-23-000867:mdna:81]

[0000950170-23-015282:mdna:80]
Sales and marketing expenses increased by $11.1 million or 15.3% for the three months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in sales and marketing expenses was primarily due to a $8.2 million increase in personnel costs due to higher compensation and benefits costs primarily related to higher commissions and share-based compensation, a $1.8 million increase in travel costs and a $1.4 million increase in marketing costs, partially offset by a $0.6 million decrease in equipment and other expenses.

[0000950170-23-015282:mdna:81]
Sales and marketing expenses increased by $29.0 million or 13.5% for the nine months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in sales and marketing expenses was primarily due to a $20.0 million increase in personnel costs due to higher compensation and benefits costs primarily related to higher commission and share-based compensation, a $5.9 million increase in travel costs, a $2.0 million increase in marketing and other professional fees and a $1.0 million increase in other expenses primarily facility and information technology costs.

[0000950170-23-015282:mdna:82]
[same as prior period, unchanged from 0001564590-23-000867:mdna:84]

[0000950170-23-015282:mdna:83]
[same as prior period, unchanged from 0001564590-23-000867:mdna:85]

[0000950170-23-015282:mdna:84]
General and administrative expenses increased by $4.0 million or 22.4% for the three months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in general and administrative expenses was primarily due to a $1.2 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $1.7 million increase in legal expenses related to our litigation, a $0.7 million increase in professional service fees and a $0.4 million increase in system transition related costs.

[0000950170-23-015282:mdna:85]
General and administrative expenses increased by $11.7 or 22.3% for the nine months ended March 31, 2023 as compared to the corresponding period in fiscal 2022. The increase in general and administrative expenses was primarily due to a $5.7 million increase in personnel costs due to higher compensation and benefits costs primarily related to share-based compensation, a $1.7 million increase in legal expenses related to our litigation, a $1.6 million increase in professional service fees and a $0.4 million increase in system transition costs.

[0000950170-23-015282:mdna:86]
[same as prior period, unchanged from 0001564590-23-000867:mdna:88]

[0000950170-23-015282:mdna:87]
During the three months ended March 31, 2023, we did not incur any acquisition and integration costs. During the nine months ended March 31, 2023, we incurred acquisition and integration costs of $0.4 million, which primarily consisted of professional fees and certain compensation charges related to the acquisition of Ipanema.

[0000950170-23-015282:mdna:88]
During the three and nine months ended March 31, 2022, we incurred $2.8 million and $6.5 million, respectively, of acquisition and integration costs, which primarily consisted of professional fees for legal advisory services, system and product integrations and financial services related to the acquisition of Ipanema.

[0000950170-23-015282:mdna:89]
[same as prior period, unchanged from 0001564590-23-000867:mdna:91]

[0000950170-23-015282:mdna:90]
For the three and nine months ended March 31, 2023, we recorded restructuring and related charges of $1.4 million and $2.3 million, respectively, which primarily consisted of facility-related charges related to our previously impaired facilities and $0.8 million in charges associated with our restructuring plan initiated in the third quarter to transform our business and facilities infrastructure.

[0000950170-23-015282:mdna:91]
For the three and nine months ended March 31, 2022, we recorded restructuring charges of $0.4 million and $1.0 million, respectively, which primarily consisted of facility related charges related to our previously impaired facilities.

[0000950170-23-015282:mdna:92]
[same as prior period, unchanged from 0001564590-23-000867:mdna:94]

[0000950170-23-015282:mdna:93]
During the three months ended March 31, 2023 and 2022, we recorded $0.5 million and $0.6 million, respectively, of operating expenses for amortization of intangibles. During the nine months ended March 31, 2023 and 2022, we recorded $1.5 million and $2.6 million, respectively. The decreases were primarily due to lower amortization related to certain acquired intangibles from previous acquisitions becoming fully amortized.

[0000950170-23-015282:mdna:94]
[same as prior period, unchanged from 0001564590-23-000867:mdna:96]

[0000950170-23-015282:mdna:95]
During the three months ended March 31, 2023 and 2022, we recorded $3.9 million and $2.8 million, respectively, in interest expense. During the nine months ended March 31, 2023 and 2022, we recorded $11.7 million and 9.8 million, respectively, in interest expense. The increases in interest expense were primarily driven by rising interest rates on our 2019 Credit Agreement and partially offset by additional principal payment.

[0000950170-23-015282:mdna:96]
Other Income (Expense), Net

[0000950170-23-015282:mdna:97]
During the three months ended March 31, 2023 and 2022, we recorded other loss, net of $0.4 million and other income net of $0.1 million, respectively. During the nine months ended March 31, 2023 and 2022, we recorded other income, net of $0.1 million and $0.3 million, respectively. The changes for the three and nine months ended March 31, 2023 were primarily due to foreign exchange impact from the revaluation of certain assets and liabilities denominated in foreign currencies into U.S. Dollars.

[0000950170-23-015282:mdna:98]
[same as prior period, unchanged from 0001564590-23-000867:mdna:100]

[0000950170-23-015282:mdna:99]
For the three months ended March 31, 2023 and 2022, we recorded an income tax provision of $3.9 million and $1.9 million, respectively. For the nine months ended March 31, 2023 and 2022, we recorded an income tax provision of $8.3 million and $5.7 million, respectively.

[0000950170-23-015282:mdna:100]
The income tax provisions for the three and nine months ended March 31, 2023 and 2022 consisted of (1) taxes on the income of our foreign subsidiaries, (2) state taxes in jurisdictions where we have no remaining state net operating losses, (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the WLAN Business, the Campus Fabric Business and the Data Center Business.

[0000950170-23-015282:mdna:101]
[same as prior period, unchanged from 0001564590-23-000867:mdna:103]

[0000950170-23-015282:mdna:102]
[same as prior period, unchanged from 0001564590-23-000867:mdna:104]

[0000950170-23-015282:mdna:103]
As discussed in Part II, Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations” of our Annual Report on Form 10-K for the year ended June 30, 2022, we consider the following accounting policies to be the most critical in understanding the judgments that are involved in preparing our consolidated financial statements:

[0000950170-23-015282:mdna:104]
•
Revenue Recognition

[0000950170-23-015282:mdna:105]
•
Inventory Valuation and Purchase Commitments

[0000950170-23-015282:mdna:106]
[same as prior period, unchanged from 0001564590-23-000867:mdna:108]

[0000950170-23-015282:mdna:107]
[same as prior period, unchanged from 0001564590-23-000867:mdna:109]

[0000950170-23-015282:mdna:108]
[same as prior period, unchanged from 0001564590-23-000867:mdna:110]

[0000950170-23-015282:mdna:109]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Cash |  | $ | 202,996 |  |  | $ | 194,522 |  |

[0000950170-23-015282:mdna:110]
As of March 31, 2023, our principal sources of liquidity consisted of cash of $203.0 million, accounts receivable, net of $158.6 million, and available borrowings under our five-year 2019 Revolving Facility of $60.2 million. Our principal uses of cash include the purchase of finished goods inventory from our contract manufacturers, payroll and other operating expenses related to the development and marketing of our products, purchases of property and equipment, and repayments of debt and related interest. We believe that our $203.0 million of cash at March 31, 2023, our cash flow from operations and the availability of borrowings from the 2019 Revolving Facility will be sufficient to fund our planned operations for at least the next 12 months.

[0000950170-23-015282:mdna:111]
On May 18, 2022, our Board of Directors authorized management to repurchase up to $200.0 million shares of our common stock over a three-year period commencing July 1, 2022. A maximum of $25.0 million may be repurchased in any quarter. On November 17, 2022, the Board increased the authorization to repurchase in any quarter from $25.0 million per quarter to $50.0 million per quarter. Purchases may be made from time to time in the open market or pursuant to 10b5-1 plan. The manner, timing and amount of any future purchases will be determined by our management based on their evaluation of market conditions, stock price, Extreme’s ongoing determination that it is the best use of available cash and other factors. The repurchase program does not obligate Extreme to acquire any shares of its common stock, may be suspended or terminated at any time without prior notice and will be subject to regulatory considerations. During the three months ended March 31, 2023, the Company repurchased a total of 1,350,568 shares of its common stock on the open market at a total cost of $25.0 million with an average price of $18.51 per share. During the nine months ended March 31, 2023, the Company repurchased a total of 3,928,743 shares of its common stock on the open market at a total cost of $74.8 million with an average price of $19.04 per share. As of March 31, 2023, we have $125.2 million available under our share repurchase program.

[0000950170-23-015282:mdna:112]
On August 9, 2019, we entered into the 2019 Credit Agreement. The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (“2019 Revolving Facility”). In addition, we may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, we used the proceeds to partially fund the acquisition of Aerohive and for working capital and general corporate purposes.

[0000950170-23-015282:mdna:113]
[same as prior period, unchanged from 0001564590-23-000867:mdna:115]

[0000950170-23-015282:mdna:114]
The 2019 Credit Agreement requires us to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default, which may result in acceleration of the outstanding balance.

[0000950170-23-015282:mdna:115]
Financial covenants under the 2019 Credit Agreement require us to maintain a minimum consolidated fixed charge and consolidated leverage ratio at the end of each fiscal quarter through maturity. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, our ability to incur additional indebtedness, create liens upon any of our property, merge, consolidate or sell all or substantially all of our assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the outstanding balance.

[0000950170-23-015282:mdna:116]
On April 8, 2020, we entered into the First Amendment to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, we entered into a Second Amendment which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required us to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and we were restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until we came into compliance with the original covenants of the 2019 Credit Agreement. On November 3, 2020, we and our lenders entered into a Third Amendment to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, we and our lenders entered into a Fourth Amendment to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0000950170-23-015282:mdna:117]
The Second Amendment provided for us to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, our financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and as such we filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing our Quarterly Report on Form 10-Q for the period ended March 31, 2021. During the three and nine months ended March 31, 2023, we were in compliance with all the original terms and financial covenants under the 2019 Credit Agreement.

[0000950170-23-015282:mdna:118]
[same as prior period, unchanged from 0001564590-23-000867:mdna:120]

[0000950170-23-015282:mdna:119]
[same as prior period, unchanged from 0001564590-23-000867:mdna:121]

[0000950170-23-015282:mdna:120]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
| Net cash provided by operating activities |  | $ | 168,519 |  |  | $ | 64,055 |  |
| Net cash used in investing activities |  |  | (8,634 | ) |  |  | (80,647 | ) |
| Net cash used in financing activities |  |  | (151,117 | ) |  |  | (63,211 | ) |
| Foreign currency effect on cash |  |  | (294 | ) |  |  | (525 | ) |
| Net increase (decrease) in cash |  | $ | 8,474 |  |  | $ | (80,328 | ) |

[0000950170-23-015282:mdna:121]
[same as prior period, unchanged from 0001564590-23-000867:mdna:123]

[0000950170-23-015282:mdna:122]
Cash flows provided by operations in the nine months ended March 31, 2023, were $168.5 million, including our net income of $52.6 million and non-cash expenses of $77.5 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes, and interest. Other sources of cash for the period included a decrease in accounts receivable and increases in accounts payable and deferred revenue. This was partially offset by increases in inventories and decreases in accrued compensation, operating lease liabilities and other current and long-term liabilities.

[0000950170-23-015282:mdna:123]
Cash flows provided by operations in the nine months ended March 31, 2022 were $64.1 million, including our net income of $38.9 million and non-cash expenses of $79.1 million for items such as amortization of intangibles, share-based compensation, depreciation, reduction in carrying amount of right-of-use assets, deferred income taxes and interest. Other sources of cash for the period included increases in accounts payable, deferred revenue and other current and long-term liabilities. This was partially offset by increases in accounts receivable, inventories, prepaid expenses and other current assets and decreases in accrued compensation, and operating lease liabilities.

[0000950170-23-015282:mdna:124]
[same as prior period, unchanged from 0001564590-23-000867:mdna:126]

[0000950170-23-015282:mdna:125]
Cash flows used in investing activities in the nine months ended March 31, 2023 were $8.6 million for the purchases of property and equipment.

[0000950170-23-015282:mdna:126]
Cash flows used in investing activities in the nine months ended March 31, 2022 were $80.6 million primarily due to the payment of $69.5 million (net of cash acquired) for the acquisition of Ipanema and $11.1 million for the purchases of property and equipment.

[0000950170-23-015282:mdna:127]
[same as prior period, unchanged from 0001564590-23-000867:mdna:129]

[0000950170-23-015282:mdna:128]
Cash flows used in financing activities in the nine months ended March 31, 2023 were $151.1 million due primarily to debt repayments of $71.6 million, share repurchase of $74.8 million under our share repurchase program, $3.0 million for deferred payments on acquisitions and $1.7 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our Employee Stock Purchase Plan (“ESPP”).

[0000950170-23-015282:mdna:129]
Cash flows used in financing activities in the nine months ended March 31, 2022 were $63.2 million due primarily to debt repayments of $31.0 million, share repurchases of $25.0 million under our share repurchase program, payment of contingent consideration of $1.0 million, $3.0 million for deferred payments on acquisitions and $3.2 million for taxes paid on vested and released stock awards net of proceeds from the issuance of shares of our common stock under our ESPP and exercise of stock options.

[0000950170-23-015282:mdna:130]
[same as prior period, unchanged from 0001564590-23-000867:mdna:132]

[0000950170-23-015282:mdna:131]
Foreign currency effect on cash decreased in the nine months ended March 31, 2023, primarily due to changes in foreign currency exchange rates between the U.S. Dollar and particularly the Indian Rupee, the UK Pound and the EURO.

[0000950170-23-015282:mdna:132]
[same as prior period, unchanged from 0001564590-23-000867:mdna:134]

[0000950170-23-015282:mdna:133]
As of March 31, 2023, we had contractual obligations resulting from our debt arrangement, agreements to purchase goods and services in the ordinary course of business and obligations under our operating lease arrangements.

[0000950170-23-015282:mdna:134]
Our debt obligations relate to amounts owed under our 2019 Credit Agreement. As of March 31, 2023, we had $237.0 million of debt outstanding which are payable on quarterly installments through our fiscal year 2025. We are subject to interest rate on our debt obligations and unused commitment fee. See Note 8, Debt, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our debt obligations.

[0000950170-23-015282:mdna:135]
Our unconditional purchase obligations represent the purchase of long lead-time component inventory that our contract manufacturers procure in accordance with our forecast. We expect to honor the inventory purchase commitments within the next 12 months. As of March 31, 2023, we had non-cancelable commitments to purchase $56.8 million of inventory. See Note 9, Commitments and Contingencies, in the Notes to Condensed Consolidated Financial Statements for additional information regarding our purchase obligations.

[0000950170-23-015282:mdna:136]
We have contractual commitments to our suppliers which represent commitments for future services. As of March 31, 2023, we had contractual commitments of $39.6 million that are due through our fiscal year 2027.

[0000950170-23-015282:mdna:137]
We lease facilities under operating lease arrangements at various locations that expire at various dates through our fiscal year 2032. As of March 31, 2023, the value of our obligations under operating leases was $51.2 million.

[0000950170-23-015282:mdna:138]
[same as prior period, unchanged from 0001564590-23-000867:mdna:140]

[0000950170-23-015282:mdna:139]
We did not have any material commitments for capital expenditures as of March 31, 2023.

[0000950170-23-015282:mdna:140]
[same as prior period, unchanged from 0001564590-23-000867:mdna:142]

[0000950170-23-015282:mdna:141]
We did not have any off-balance sheet arrangements as of March 31, 2023.
