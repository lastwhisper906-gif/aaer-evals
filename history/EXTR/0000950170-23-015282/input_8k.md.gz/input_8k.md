# EXTR 8-K — 0000950170-23-014563 filed 2023-04-26

## item codes, every 8-K on or before 2023-04-27

- 2023-04-26 0000950170-23-014563 — 2.02, 9.01
- 2023-04-24 0001193125-23-113052 — 5.02, 9.01
- 2023-01-25 0001564590-23-000756 — 5.02, 9.01
- 2023-01-25 0001564590-23-000754 — 2.02, 9.01
- 2022-11-18 0001564590-22-038036 — 5.03, 5.07, 9.01
- 2022-10-27 0001564590-22-035354 — 2.02, 9.01
- 2022-10-12 0001193125-22-261213 — 8.01
- 2022-07-27 0001564590-22-026574 — 2.02, 9.01
- 2022-04-27 0001564590-22-015866 — 2.02, 9.01
- 2022-01-27 0001564590-22-002568 — 2.02, 9.01
- 2021-11-05 0001564590-21-054934 — 5.07
- 2021-11-02 0001564590-21-053306 — 2.02, 9.01
- 2021-09-22 0001564590-21-048585 — 4.01, 9.01
- 2021-08-10 0001564590-21-043098 — 1.01
- 2021-07-28 0001564590-21-038470 — 2.02, 9.01
- 2021-05-18 0001564590-21-028693 — 1.01, 3.03, 9.01
- 2021-04-28 0001564590-21-021102 — 2.02, 9.01
- 2021-02-09 0001564590-21-005000 — 2.02, 9.01
- 2021-01-27 0001564590-21-002633 — 2.02, 9.01
- 2020-11-06 0001564590-20-051993 — 5.07
- 2020-10-28 0001564590-20-048160 — 2.02, 9.01
- 2020-10-08 0001564590-20-046117 — 2.02, 9.01
- 2020-09-11 0001564590-20-043260 — 4.01, 9.01
- 2020-08-05 0001564590-20-036431 — 2.02, 9.01
- 2020-06-01 0001564590-20-027850 — 3.03, 9.01
- 2020-05-11 0001564590-20-024216 — 2.02, 9.01
- 2020-04-08 0001564590-20-015927 — 2.02, 8.01, 9.01
- 2020-02-25 0001193125-20-047202 — 8.01, 9.01
- 2020-01-29 0001564590-20-002375 — 2.02, 9.01
- 2020-01-29 0001193125-20-017673 — 5.02, 9.01
- 2019-11-08 0001193125-19-288358 — 5.07
- 2019-10-30 0001564590-19-038508 — 2.02, 9.01
- 2019-10-25 0001564590-19-037908 — 9.01 — amendment of 0001193125-19-217553
- 2019-10-18 0001193125-19-269734 — 7.01, 9.01
- 2019-08-30 0001193125-19-235271 — 5.02 — amendment of 0001193125-19-229280
- 2019-08-26 0001193125-19-229280 — 5.02, 9.01
- 2019-08-09 0001193125-19-217553 — 1.01, 2.01, 2.03, 9.01
- 2019-07-31 0001564590-19-027208 — 2.02, 9.01
- 2019-06-26 0001193125-19-181938 — 1.01, 2.05, 9.01
- 2019-05-01 0001564590-19-014567 — 2.02, 9.01
- 2019-01-29 0001564590-19-001270 — 2.02, 9.01
- 2019-01-25 0001564590-19-001157 — 8.01, 9.01
- 2018-11-20 0001193125-18-331450 — 5.02, 9.01
- 2018-11-15 0001564590-18-029683 — 5.07
- 2018-11-02 0001564590-18-026372 — 2.02, 8.01, 9.01
- 2018-09-19 0001193125-18-276766 — 5.02
- 2018-08-08 0001564590-18-020191 — 2.02, 9.01
- 2018-06-05 0001564590-18-015067 — 3.03, 9.01
- 2018-05-08 0001564590-18-011817 — 2.02, 9.01
- 2018-05-07 0001564590-18-011264 — 1.01, 1.02, 2.03, 9.01
- 2018-02-06 0001564590-18-001403 — 2.02, 2.05, 9.01
- 2018-02-01 0001564590-18-001166 — 5.02
- 2018-01-12 0001564590-18-000462 — 9.01 — amendment of 0001193125-17-323879
- 2017-11-15 0001564590-17-023847 — 5.07
- 2017-11-07 0001564590-17-022235 — 2.02, 9.01
- 2017-11-03 0001193125-17-332828 — 9.01 — amendment of 0001193125-17-323879
- 2017-10-30 0001193125-17-323879 — 1.01, 2.01, 7.01, 9.01
- 2017-10-03 0001193125-17-302411 — 1.01, 9.01
- 2017-10-03 0001193125-17-301597 — 1.01, 1.02, 7.01, 9.01
- 2017-09-29 0001564590-17-019099 — 9.01 — amendment, the index does not say of what
- 2017-08-14 0001564590-17-017659 — 2.02, 9.01
- 2017-08-02 0001564590-17-014950 — 5.02
- 2017-07-18 0001564590-17-013557 — 1.01, 2.01, 2.03, 9.01
- 2017-06-05 0001564590-17-012126 — 3.03, 9.01
- 2017-05-03 0001564590-17-008378 — 2.02, 9.01
- 2017-03-30 0001193125-17-102344 — 1.01, 9.01
- 2017-03-07 0001193125-17-073306 — 1.01, 9.01
- 2017-02-21 0001193125-17-048182 — 5.02
- 2017-02-01 0001564590-17-000835 — 2.02, 9.01
- 2017-01-06 0001564590-17-000138 — 2.05
- 2016-11-21 0001564590-16-029539 — 5.07
- 2016-11-01 0001564590-16-026732 — 2.02, 9.01
- 2016-10-31 0001193125-16-752557 — 1.01, 2.01, 2.03
- 2016-09-15 0001193125-16-711097 — 1.01, 9.01
- 2016-08-03 0001564590-16-022347 — 2.02, 9.01
- 2016-05-19 0001564590-16-019720 — 5.02, 9.01
- 2016-05-09 0001564590-16-018660 — 3.03, 9.01
- 2016-04-27 0001564590-16-016754 — 2.02, 9.01
- 2016-02-24 0001564590-16-013189 — 8.01
- 2016-02-09 0001564590-16-012469 — 8.01
- 2016-01-28 0001564590-16-012054 — 2.02, 9.01
- 2015-11-17 0001078271-15-000136 — 5.07
- 2015-10-29 0001078271-15-000125 — 2.02, 9.01
- 2015-08-31 0001078271-15-000111 — 8.01, 9.01
- 2015-08-11 0001078271-15-000096 — 5.02
- 2015-08-06 0001078271-15-000093 — 2.02, 9.01
- 2015-06-30 0001078271-15-000089 — 1.01, 9.01
- 2015-05-20 0001078271-15-000077 — 2.05, 9.01
- 2015-05-19 0001078271-15-000075 — 3.03, 9.01
- 2015-05-06 0001078271-15-000050 — 2.02, 9.01
- 2015-05-04 0001078271-15-000048 — 5.02, 9.01
- 2015-04-29 0001078271-15-000038 — 5.02, 9.01
- 2015-04-21 0001078271-15-000034 — 5.02, 9.01
- 2015-04-09 0001078271-15-000032 — 2.02, 5.02, 9.01
- 2015-02-18 0001078271-15-000021 — 8.01
- 2015-02-17 0001078271-15-000019 — 5.02
- 2015-01-28 0001078271-15-000004 — 2.02, 9.01
- 2014-12-18 0001078271-14-000081 — 5.02, 9.01
- 2014-12-17 0001078271-14-000079 — 5.02
- 2014-11-20 0001078271-14-000075 — 1.01, 9.01
- 2014-11-17 0001078271-14-000073 — 5.07
- 2014-10-28 0001078271-14-000062 — 2.02, 9.01
- 2014-10-15 0001078271-14-000060 — 2.02, 9.01
- 2014-10-02 0001078271-14-000057 — 5.02, 9.01
- 2014-08-14 0001078271-14-000047 — 2.02, 9.01
- 2014-07-21 0001078271-14-000042 — 2.02, 9.01
- 2014-05-23 0001078271-14-000036 — 5.02, 9.01
- 2014-05-20 0001078271-14-000034 — 3.03, 9.01
- 2014-05-12 0001078271-14-000030 — 5.02
- 2014-05-08 0001078271-14-000022 — 5.02, 9.01
- 2014-05-07 0001078271-14-000018 — 2.02, 9.01 — amendment, the index does not say of what
- 2014-05-06 0001078271-14-000016 — 2.02, 9.01
- 2014-02-20 0001078271-14-000014 — 5.02, 9.01
- 2014-02-18 0001078271-14-000010 — 5.02
- 2014-02-05 0001078271-14-000006 — 2.02, 9.01
- 2014-01-13 0001104659-14-002030 — 9.01 — amendment of 0001078271-13-000058
- 2013-11-25 0001078271-13-000081 — 5.07
- 2013-11-07 0001078271-13-000064 — 5.02, 9.01
- 2013-11-04 0001078271-13-000060 — 2.02, 9.01
- 2013-11-01 0001078271-13-000058 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2013-10-16 0001078271-13-000056 — 8.01, 9.01
- 2013-09-13 0001078271-13-000052 — 1.01, 8.01, 9.01
- 2013-08-23 0001078271-13-000044 — 5.02, 9.01
- 2013-08-02 0001078271-13-000042 — 5.02
- 2013-07-30 0001078271-13-000039 — 2.02, 9.01
- 2013-07-30 0001078271-13-000037 — 5.02, 9.01
- 2013-06-21 0001078271-13-000032 — 8.01
- 2013-05-01 0001078271-13-000018 — 5.02, 9.01
- 2013-04-30 0001078271-13-000015 — 2.02, 9.01
- 2013-03-01 0001078271-13-000010 — 8.01
- 2013-02-19 0001078271-13-000008 — 5.02
- 2013-01-30 0001078271-13-000004 — 2.02, 9.01
- 2013-01-07 0001078271-13-000002 — 1.01, 2.02, 2.03, 2.05, 9.01
- 2012-12-03 0001078271-12-000094 — 5.02, 5.07, 8.01
- 2012-10-31 0001078271-12-000071 — 2.02, 9.01
- 2012-10-19 0001078271-12-000069 — 1.01, 2.03, 9.01
- 2012-10-16 0001078271-12-000067 — 8.01
- 2012-10-01 0001193125-12-411392 — 5.02, 8.01, 9.01
- 2012-09-24 0001193125-12-401798 — 5.02, 9.01
- 2012-09-21 0001193125-12-399896 — 5.02, 9.01
- 2012-09-18 0001193125-12-394379 — 1.01, 5.02, 9.01
- 2012-09-12 0001193125-12-388591 — 8.01
- 2012-08-27 0001078271-12-000057 — 8.01
- 2012-08-03 0001078271-12-000041 — 7.01, 9.01
- 2012-08-01 0001078271-12-000039 — 2.02, 9.01
- 2012-07-25 0001078271-12-000037 — 8.01
- 2012-05-22 0001078271-12-000033 — 5.02, 9.01
- 2012-05-21 0001078271-12-000030 — 8.01
- 2012-05-09 0001078271-12-000028 — 5.02, 9.01
- 2012-05-02 0001078271-12-000023 — 2.02, 9.01
- 2012-04-30 0001078271-12-000020 — 3.03, 5.07, 9.01
- 2012-04-19 0001078271-12-000012 — 2.02, 5.02, 9.01
- 2012-03-12 0001078271-12-000010 — 5.02, 9.01
- 2012-02-24 0001078271-12-000008 — 8.01
- 2012-02-02 0001078271-12-000004 — 2.02, 9.01
- 2012-01-30 0001078271-12-000002 — 1.01
- 2011-12-01 0001078271-11-000104 — 8.01
- 2011-11-08 0001078271-11-000099 — 8.01
- 2011-11-02 0001078271-11-000094 — 2.02, 9.01
- 2011-10-24 0001078271-11-000089 — 8.01, 9.01
- 2011-10-11 0001078271-11-000085 — 8.01
- 2011-09-29 0001078271-11-000082 — 8.01
- 2011-09-15 0001078271-11-000070 — 5.02, 9.01
- 2011-08-11 0001078271-11-000058 — 8.01
- 2011-08-10 0001078271-11-000055 — 5.02
- 2011-08-08 0001078271-11-000045 — 5.02
- 2011-08-01 0001078271-11-000038 — 2.02, 9.01
- 2011-07-14 0001078271-11-000036 — 2.02, 2.05, 9.01
- 2011-07-12 0001078271-11-000034 — 8.01
- 2011-07-01 0001078271-11-000032 — 5.02
- 2011-06-16 0001078271-11-000030 — 8.01
- 2011-05-06 0001078271-11-000027 — 8.01, 9.01
- 2011-05-04 0001078271-11-000025 — 8.01
- 2011-04-28 0001078271-11-000020 — 2.02, 9.01
- 2011-04-27 0001078271-11-000018 — 3.03, 5.02, 5.03, 9.01
- 2011-04-11 0001078271-11-000016 — 2.02
- 2011-03-31 0001078271-11-000014 — 5.02, 5.03
- 2011-03-15 0001193125-11-066049 — 5.02, 9.01
- 2011-03-01 0001193125-11-052048 — 5.02, 9.01
- 2011-02-10 0001078271-11-000012 — 7.01, 9.01
- 2011-01-31 0001078271-11-000005 — 2.02, 5.02, 5.03, 9.01
- 2010-12-23 0001193125-10-287613 — 8.01
- 2010-12-17 0001193125-10-283495 — 5.03, 5.07, 8.01, 9.01
- 2010-11-10 0001193125-10-255861 — 4.01, 9.01
- 2010-11-01 0001193125-10-242706 — 2.02, 9.01
- 2010-10-14 0001193125-10-229518 — 1.01, 9.01
- 2010-10-06 0001193125-10-224863 — 5.02, 8.01
- 2010-09-29 0001193125-10-219705 — 1.01, 8.01
- 2010-09-08 0001193125-10-206782 — 5.02, 8.01, 9.01
- 2010-08-25 0001193125-10-196951 — 8.01
- 2010-08-09 0001193125-10-182573 — 7.01, 8.01, 9.01
- 2010-08-03 0001193125-10-175255 — 5.02, 8.01, 9.01
- 2010-08-02 0001193125-10-173697 — 2.02, 8.01, 9.01
- 2010-07-30 0001193125-10-172214 — 5.02, 8.01, 9.01
- 2010-07-22 0001193125-10-163896 — 8.01, 9.01
- 2010-07-20 0001193125-10-161832 — 5.02
- 2010-07-12 0001193125-10-157291 — 2.02, 9.01
- 2010-07-01 0001193125-10-152746 — 3.03, 9.01
- 2010-05-10 0001193125-10-114669 — 5.02, 9.01
- 2010-04-26 0001193125-10-093310 — 2.02, 9.01
- 2010-03-19 0001193125-10-061679 — 5.02, 9.01
- 2010-02-16 0001193125-10-032335 — 5.02
- 2010-02-01 0001193125-10-018202 — 2.02, 9.01
- 2010-01-29 0001193125-10-017165 — 5.02
- 2010-01-11 0001193125-10-004099 — 8.01
- 2009-10-26 0001193125-09-213846 — 2.02, 9.01 — amendment of 0001193125-09-213780
- 2009-10-26 0001193125-09-213780 — 2.02, 9.01
- 2009-10-23 0001193125-09-212871 — 2.05, 5.02, 8.01, 9.01
- 2009-10-05 0001193125-09-203522 — 2.02, 9.01
- 2009-08-04 0001193125-09-163799 — 5.02, 9.01
- 2009-07-31 0001193125-09-160772 — 5.02, 9.01
- 2009-07-30 0001193125-09-159578 — 2.02, 9.01
- 2009-07-20 0001193125-09-151500 — 5.02, 9.01
- 2009-07-08 0001193125-09-145840 — 5.02, 9.01
- 2009-05-12 0001193125-09-108340 — 5.02, 9.01
- 2009-04-23 0001193125-09-085849 — 2.02, 9.01
- 2009-03-26 0001193125-09-064502 — 2.05
- 2009-01-28 0001193125-09-013182 — 2.02, 9.01
- 2008-11-06 0001193125-08-227572 — 2.02, 9.01
- 2008-11-03 0001193125-08-222501 — 5.02
- 2008-08-11 0001193125-08-173590 — 5.02
- 2008-08-11 0001193125-08-172587 — 8.01, 9.01
- 2008-08-06 0001193125-08-167934 — 2.02, 9.01
- 2008-08-04 0001193125-08-164673 — 5.02, 9.01
- 2008-05-21 0001193125-08-119640 — 7.01, 9.01
- 2008-04-29 0001193125-08-095270 — 2.02, 9.01
- 2008-03-05 0001193125-08-047893 — 8.01
- 2008-02-19 0001193125-08-033702 — 5.02
- 2008-02-05 0001193125-08-019969 — 5.02
- 2008-01-30 0001193125-08-015378 — 2.02, 9.01
- 2007-12-27 0001193125-07-272178 — 5.03, 9.01
- 2007-10-29 0001193125-07-228368 — 2.02, 9.01
- 2007-10-25 0001193125-07-225906 — 5.02, 9.01
- 2007-10-19 0001193125-07-221578 — 5.02
- 2007-09-26 0001193125-07-207348 — 8.01
- 2007-08-07 0001193125-07-172810 — 2.02, 9.01
- 2007-08-06 0001193125-07-172147 — 5.02, 9.01
- 2007-08-06 0001193125-07-172134 — 3.01
- 2007-07-09 0001193125-07-151467 — 3.01, 9.01
- 2007-06-28 0001193125-07-145519 — 2.02, 9.01
- 2007-06-27 0001193125-07-143262 — 2.05, 3.01, 5.02
- 2007-05-18 0001193125-07-118804 — 3.01, 9.01
- 2007-05-02 0001193125-07-099280 — 2.02, 9.01
- 2007-03-29 0001193125-07-068815 — 5.02, 9.01
- 2007-02-22 0001193125-07-037181 — 3.01, 9.01
- 2007-02-08 0001193125-07-024194 — 5.02
- 2007-01-30 0001193125-07-016428 — 2.02, 9.01
- 2007-01-11 0001193125-07-004825 — 4.02, 9.01
- 2006-11-21 0001193125-06-240068 — 5.02, 9.01
- 2006-11-16 0001193125-06-237262 — 3.01, 9.01
- 2006-11-01 0001193125-06-220707 — 2.02, 9.01
- 2006-10-31 0001193125-06-219237 — 1.01, 1.02, 5.02, 5.03, 8.01, 9.01
- 2006-09-28 0001193125-06-198185 — 3.01, 9.01
- 2006-09-15 0001193125-06-191640 — 7.01, 9.01
- 2006-09-05 0001193125-06-185202 — 5.02, 9.01
- 2006-08-08 0001193125-06-165953 — 1.01, 2.02, 5.02, 9.01
- 2006-07-18 0001193125-06-148526 — 1.01
- 2006-07-10 0001193125-06-143989 — 5.02, 9.01
- 2006-05-16 0001193125-06-113698 — 5.02, 9.01
- 2006-05-01 0001193125-06-094919 — 2.02, 9.01
- 2006-04-26 0001193125-06-089397 — 1.01, 9.01
- 2006-04-07 0001193125-06-075723 — 2.02, 9.01
- 2006-02-13 0001193125-06-029073 — 1.01
- 2006-01-31 0001193125-06-016143 — 1.01
- 2006-01-30 0001193125-06-015165 — 2.02, 9.01
- 2005-12-08 0001193125-05-239157 — 1.01, 1.02, 9.01
- 2005-11-01 0001193125-05-213101 — 2.02, 9.01
- 2005-09-29 0001193125-05-193991 — 1.01, 2.02, 9.01 — amendment of 0001193125-05-162807
- 2005-08-09 0001193125-05-162807 — 1.01, 2.02, 9.01
- 2005-07-14 0001193125-05-142162 — 8.01
- 2005-06-28 0001193125-05-133050 — 1.01, 9.01
- 2005-04-18 0001193125-05-077946 — 2.02, 7.01, 9.01
- 2005-04-14 0001193125-05-076665 — 2.02, 7.01, 9.01
- 2005-01-25 0001193125-05-011466 — 2.02, 9.01
- 2004-12-07 0001193125-04-208693 — 3.01
- 2004-10-26 0001193125-04-178370 — 2.02, 9.01
- 2004-10-04 0001193125-04-166289 — 5.02, 9.01
- 2004-07-28 0001193125-04-126135 — 12, 7
- 2004-05-12 0001193125-04-086287 — 12
- 2004-04-21 0001193125-04-066557 — 12, 7
- 2004-01-22 0001193125-04-007359 — 12, 7
- 2003-12-18 0001193125-03-096351 — 5, 7
- 2003-11-04 0001193125-03-072069 — 5, 7
- 2003-10-24 0001193125-03-066551 — 12, 7
- 2003-07-25 0001193125-03-024087 — 7, 9
- 2003-04-11 0001012870-03-001706 — 7, 9
- 2003-04-08 0001021408-03-005743 — 7, 9
- 2003-01-07 0001012870-03-000039 — 5, 7
- 2002-04-29 0001012870-02-002003 — 5, 7
- 2002-02-20 0001012870-02-000792 — 5, 7
- 2001-12-13 0001012870-01-503160 — 5, 7
- 2001-11-30 0001012870-01-503010 — 5, 7
- 2001-11-02 0001012870-01-502580 — 5
- 2001-10-23 0001021408-01-508589 — 5, 7
- 2001-06-07 0001021408-01-501772 — 5, 7 — amendment of 0001021408-01-500975
- 2001-05-15 0001021408-01-501104 — 5 — amendment of 0001021408-01-500975
- 2001-05-14 0001021408-01-500975 — 5, 7
- 2001-04-06 0001012870-01-500065 — 5, 7

## late-filing notifications on or before 2023-04-27

- 2008-05-12 0001193125-08-111540 — NT 10-Q, for the period ended 2008-03-30
- 2007-05-10 0001193125-07-110075 — NT 10-Q, for the period ended 2007-04-01
- 2007-02-09 0001193125-07-025490 — NT 10-Q, for the period ended 2006-12-31
- 2006-11-13 0001193125-06-232090 — NT 10-Q, for the period ended 2006-10-01
- 2006-09-15 0001193125-06-191838 — NT 10-K, for the period ended 2006-07-02

## item 2.02 — earnings release, exhibit 99.1

[0000950170-23-014563:8k_2_02:1]
EX-99
2
extr-ex99_1.htm
EX-99.1

[0000950170-23-014563:8k_2_02:2]
EX-99

[0000950170-23-014563:8k_2_02:3]
Exhibit 99.1

[0000950170-23-014563:8k_2_02:4]
| For more information, contact: |  |  |  |  |  |  |
| Investor Relations |  |  |  | Media Contact |  |
| Stan Kovler |  |  |  | Amy Aylward |
| 919/595-4196 |  |  |  | 603/952-5138 |  |
| Investor_relations@extremenetworks.com |  |  |  | pr@extremenetworks.com |

[0000950170-23-014563:8k_2_02:5]
Extreme Networks Reports Third Quarter Fiscal Year 2023 Financial Results

[0000950170-23-014563:8k_2_02:6]
Delivers Record Revenue, Operating Margin, and EPS and Raises FY23 Outlook

[0000950170-23-014563:8k_2_02:7]
Morrisville, NC, April 26, 2023 -- Extreme Networks, Inc. (“Extreme”) (Nasdaq: EXTR) today released financial results for its third fiscal quarter ended March 31, 2023.

[0000950170-23-014563:8k_2_02:8]
Fiscal Third Quarter Results:

[0000950170-23-014563:8k_2_02:9]
•
Revenue $332.5 million, up 16% year-over-year, and up 4% quarter-over-quarter

[0000950170-23-014563:8k_2_02:10]
•
SaaS ARR* $117 million, up 22% year-over-year, and up 2% quarter-over-quarter

[0000950170-23-014563:8k_2_02:11]
•
GAAP diluted EPS $0.17, compared to $0.10 in Q3 last year and $0.13 last quarter

[0000950170-23-014563:8k_2_02:12]
•
Non-GAAP diluted EPS $0.29, compared to $0.21 in Q3 last year and $0.27 last quarter

[0000950170-23-014563:8k_2_02:13]
•
GAAP gross margin 57.7% compared to 56.5% in Q3 last year

[0000950170-23-014563:8k_2_02:14]
•
Non-GAAP gross margin 59.1% compared to 58.0% in Q3 last year

[0000950170-23-014563:8k_2_02:15]
•
GAAP operating margin 8.9 % compared to 6.1 % in Q3 last year

[0000950170-23-014563:8k_2_02:16]
•
Non-GAAP operating margin 15.6 % compared to 12.5% in Q3 last year

[0000950170-23-014563:8k_2_02:17]
•
Net cash provided by operating activities of $48.2 million

[0000950170-23-014563:8k_2_02:18]
•
Free cash flow of $45.8 million

[0000950170-23-014563:8k_2_02:19]
•
Repurchased 1.35 million shares for $25.0 million

[0000950170-23-014563:8k_2_02:20]
President and CEO Ed Meyercord stated: "Extreme delivered another quarter of record results punctuated by improving supply chain conditions, the strengthening of our competitive position, and solid execution.  Market share gains were highlighted by 20% growth in bookings from new customers during the quarter, which drove sequential product bookings growth of 6%. The combination of our enterprise cloud and fabric networking solutions deliver a simplified experience for customers and provide our team a competitive advantage in the field. Our funnel of opportunities is up double-digits and we expect higher sequential bookings growth as we head into Q4."

[0000950170-23-014563:8k_2_02:21]
"We believe the improving supply chain and cloud software subscription growth will support an over 20% year-over-year revenue increase in Q4. We also expect earnings to more than double year-over-year, on both a GAAP and Non-GAAP basis, driven by gross margin expansion and operating leverage," continued Meyercord.

[0000950170-23-014563:8k_2_02:22]
Interim CFO Cristina Tate noted: "Extreme's record quarterly revenue and operating profit resulted in another quarter of strong cash flow, which allowed us to repurchase $25 million of stock and reduce our debt by $25 million, lowering our net debt to $34 million. We've raised our full year FY23 revenue outlook to 16% year-over-year, which is the midpoint of our guidance. We remain committed to our long-term outlook of mid-teens topline growth and margin expansion through FY25."

[0000950170-23-014563:8k_2_02:23]
Recent Key Highlights:

[0000950170-23-014563:8k_2_02:24]
•
Extreme extended its industry-leading Fabric solution to the edge of the network, making it simple for customers to securely connect and manage distributed environments from a single platform: ExtremeCloud. As a result, customers can lower operating costs, automate IT workflows for efficiency and improve application performance across their organization.

[0000950170-23-014563:8k_2_02:25]
•
Extreme will host its annual user conference, Extreme Connect, from May 8-11, 2023, in Berlin, Germany. The event will include innovative new product introductions, expert guest speakers, hands-on demonstrations and more. Tune in virtually to a 60-minute live news broadcast from Extreme Connect Berlin starting at 3 p.m. CEST/9 a.m. ET on May 9 and 10 via Extreme’s LinkedIn or YouTube channel.

[0000950170-23-014563:8k_2_02:26]
•
Kroger selected Extreme as its partner to help drive impactful, engaging in-store experiences and streamline store operations as it creates the store of the future. Kroger will deploy ExtremeCloud IQ cloud management and Wi-Fi 6E access points to create optimized experiences for customers and associates with services including “scan-as-you-go,” inventory location and temperature sensing applications.

[0000950170-23-014563:8k_2_02:27]
•
In partnership with Comcast, Extreme deployed Wi-Fi 6E Access Points, ExtremeCloud IQ and Universal Switches at Oracle Park, home of the San Francisco Giants, making it the first major sports venue to be 100 percent Wi-Fi 6E ready. In partnership with Verizon, Extreme deployed the largest outdoor Wi-Fi 6 network in the U.S. at Daytona International Speedway.

[0000950170-23-014563:8k_2_02:28]
•
Global healthcare organizations are increasingly investing in Extreme solutions including Dr. Sulaiman Al Habib Medical Services Group (HMG), one of the largest providers of comprehensive healthcare services in Saudi Arabia, as well as Prima CARE in the US, West Suffolk NHS Foundation Trust in the UK and ASST Mantova in Italy. As a result, these organizations can support bandwidth-intensive medical applications, ensure security of devices and patient data, improve operational efficiency, and progress patient care.

[0000950170-23-014563:8k_2_02:29]
•
SK IE Technology Co., one of South Korea’s leading materials solutions providers and manufacturer of EV batteries, selected Extreme’s Universal wired and wireless solutions to support operations at their battery plants, enabling improved connectivity for operational needs including forklift monitoring and tracking key battery components.

[0000950170-23-014563:8k_2_02:30]
•
Kingston University, one of London’s leading higher education institutions, selected Extreme to deploy a new campuswide, cloud-managed and fabric-enabled Wi-Fi 6E network. The University can now more easily secure and manage its network and better support new, innovative classroom technology, including AR/VR, high-resolution video streaming, IoT devices used in classrooms and personal devices brought in by students and staff.

[0000950170-23-014563:8k_2_02:31]
•
Catawba College will deploy a new end-to-end network with a number of Extreme solutions, including ExtremeCloud IQ CoPilot. Catawba will leverage Machine Learning and AI featured in CoPilot to proactively detect network anomalies, improve network performance, reduce time consuming tasks for the IT team and streamline operations. Catawba will also offer Extreme Academy as part of its computer science curriculum, giving students a modern and foundational curriculum for a career in networking.

[0000950170-23-014563:8k_2_02:32]
•
Cedar Fair Entertainment Company, one of the largest regional amusement-resort operators in the world, selected Extreme to deploy Wi-Fi 6E-ready networks across its properties to provide high-speed connectivity and bandwidth for operational needs like digital signage and cashless payments as well as guest devices. In partnership with Comcast, the network is centrally managed from the cloud, reducing the time it takes for IT teams to identify and resolve issues and helping create better guest experiences.

[0000950170-23-014563:8k_2_02:33]
Fiscal Q3 2023 Financial Metrics:

[0000950170-23-014563:8k_2_02:34]
(in millions, except percentages and per share information)

[0000950170-23-014563:8k_2_02:35]
|  |  | GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | Change |  |
| Product |  | $ | 241.1 |  |  | $ | 198.4 |  |  | $ | 42.7 |  |  |  | 22 | % |
| Service and subscription |  |  | 91.4 |  |  |  | 87.1 |  |  |  | 4.3 |  |  |  | 5 | % |
| Total net revenue |  | $ | 332.5 |  |  | $ | 285.5 |  |  | $ | 47.0 |  |  |  | 16 | % |
| Gross margin |  |  | 57.7 | % |  |  | 56.5 | % |  |  | 1.2 | % |  |  | — |  |
| Operating margin |  |  | 8.9 | % |  |  | 6.1 | % |  |  | 2.8 | % |  |  | — |  |
| Net income |  | $ | 22.1 |  |  | $ | 12.8 |  |  | $ | 9.3 |  |  |  | 73 | % |
| Net income per diluted share |  | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.07 |  |  |  | 70 | % |

[0000950170-23-014563:8k_2_02:36]
|  |  | Non-GAAP Results |  |
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | Change |  |
| Product |  | $ | 241.1 |  |  | $ | 198.4 |  |  | $ | 42.7 |  |  |  | 22 | % |
| Service and subscription |  |  | 91.4 |  |  |  | 87.1 |  |  |  | 4.3 |  |  |  | 5 | % |
| Total net revenue |  | $ | 332.5 |  |  | $ | 285.5 |  |  | $ | 47.0 |  |  |  | 16 | % |
| Gross margin |  |  | 59.1 | % |  |  | 58.0 | % |  |  | 1.1 | % |  |  | — |  |
| Operating margin |  |  | 15.6 | % |  |  | 12.5 | % |  |  | 3.1 | % |  |  | — |  |
| Net income |  | $ | 38.8 |  |  | $ | 27.4 |  |  | $ | 11.4 |  |  |  | 42 | % |
| Net income per diluted share |  | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 0.08 |  |  |  | 38 | % |

[0000950170-23-014563:8k_2_02:37]
•
Q3 ending cash balance was $203.0 million, an increase of $0.5 million from the end of Q2. This was primarily driven by operating cash flow generation of $48.2 million, partially offset by cash usage of $45.5 million for financing activities primarily for payments against our term loan and stock repurchases and cash usage of $2.4 million for investing activities for capital expenditures.

[0000950170-23-014563:8k_2_02:38]
•
During Q3, we repurchased a total of 1.35 million shares of our common stock on the open market at a total cost of $25.0 million with a weighted average price of $18.51 per share.

[0000950170-23-014563:8k_2_02:39]
•
Q3 accounts receivable balance was $158.6 million, an increase of $6.5 million from the end of Q2 and a decrease of $4.4 million from Q3 last year. Days sales outstanding** was 43 days, a decrease of 1 day from Q2 and a decrease of 8 days from Q3 last year.

[0000950170-23-014563:8k_2_02:40]
•
Q3 ending inventory was $70.3 million, an increase of $6.5 million from Q2 and an increase of $32.6 million from Q3 last year. The quarter-over-quarter and year-over-year increases were primarily driven by an increase in finished goods inventory.

[0000950170-23-014563:8k_2_02:41]
•
Q3 ending gross debt*** was $237.0 million, a decrease of $25.0 million from the end of Q2 and decrease of $78.8 million from Q3 last year. The decrease from Q3 last year resulted primarily from principal payments on our term loan. Q3 ending net debt**** was $34.0 million, a decrease of $25.5 million from $59.5 million in Q2 and a decrease of $115.2 million from $149.2 from Q3 last year.

[0000950170-23-014563:8k_2_02:42]
Extreme uses the non-GAAP free cash flow metric as a measure of operating performance. Free cash flow represents GAAP net cash provided by operating activities, less purchases of property, plant and equipment.  Extreme considers free cash flow to be useful information for management and investors regarding the amount of cash generated by the business after the purchases of property, plant and equipment, which can then be used to, among other things, invest in Extreme’s business, make strategic acquisitions, and strengthen the balance sheet. A limitation of the utility of this non-GAAP free cash flow metric as a measure of financial performance is that it does not represent the total increase or decrease in the Company's cash balance for the period. The following table shows non-GAAP free cash flow calculation (in thousands):

[0000950170-23-014563:8k_2_02:43]
| Free Cash Flow | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Cash flow provided by operations | $ | 48,182 |  |  | $ | 1,573 |  |  | $ | 168,519 |  |  | $ | 64,055 |  |
| Less: Property and equipment capital expenditures |  | (2,363 | ) |  |  | (4,477 | ) |  |  | (8,634 | ) |  |  | (11,130 | ) |
| Total free cash flow | $ | 45,819 |  |  | $ | (2,904 | ) |  | $ | 159,885 |  |  | $ | 52,925 |  |

[0000950170-23-014563:8k_2_02:44]
*SaaS ARR: Extreme uses SaaS annual recurring revenue (“SaaS ARR”) to identify the annual recurring revenue of ExtremeCloud™ IQ (XIQ) and other subscription revenue, based on the annualized value of quarterly subscription revenue and term-based licenses. We believe that SaaS ARR is an important metric because it is driven by our ability to acquire new customers and to maintain and expand our relationships with existing customers. SaaS ARR should be viewed independently of revenue, deferred revenue and other U.S. GAAP accounting. SaaS ARR does not have a standardized meaning and therefore may not be comparable to similarly titled measures presented by other companies. SaaS ARR is not intended to be a replacement for forecasts of revenue.

[0000950170-23-014563:8k_2_02:45]
** Days Sales Outstanding (DSO): DSO is calculated by dividing accounts receivable, net at the end of the quarter by revenue recognized during the quarter, multiplied by the total days in the quarter.

[0000950170-23-014563:8k_2_02:46]
***Gross Debt: Gross debt is defined as long-term debt and the current portion of long-term debt as shown on the balance sheet plus unamortized debt issuance costs, if any.

[0000950170-23-014563:8k_2_02:47]
****Net Debt is defined as gross debt minus cash, as shown in the table below (in millions):

[0000950170-23-014563:8k_2_02:48]
| Gross debt |  |  | Cash |  |  | Net debt |  |
| $ | 237.0 |  |  | $ | 203.0 |  |  | $ | 34.0 |  |

[0000950170-23-014563:8k_2_02:49]
Business Outlook:

[0000950170-23-014563:8k_2_02:50]
For its fourth quarter of fiscal 2023, ending June 30, 2023, the Company is targeting:

[0000950170-23-014563:8k_2_02:51]
| (in millions, except percentages and per share information) | Low-End |  |  | High-End |  |
| FQ4'23 Guidance – GAAP |  |  |  |  |  |
| Total net revenue | $ | 340.0 |  |  | $ | 350.0 |  |
| Gross margin |  | 57.7 | % |  |  | 59.7 | % |
| Operating margin |  | 8.9 | % |  |  | 10.8 | % |
| Net income per diluted share | $ | 0.16 |  |  | $ | 0.22 |  |
| Shares outstanding used in calculating GAAP EPS |  | 133.2 |  |  |  | 133.2 |  |
| FQ4’23 Guidance – Non-GAAP |  |  |  |  |  |
| Total net revenue | $ | 340.0 |  |  | $ | 350.0 |  |
| Gross margin |  | 59.0 | % |  |  | 61.0 | % |
| Operating margin |  | 15.5 | % |  |  | 17.3 | % |
| Net income per diluted share | $ | 0.28 |  |  | $ | 0.34 |  |
| Shares outstanding used in calculating non-GAAP EPS |  | 133.2 |  |  |  | 133.2 |  |

[0000950170-23-014563:8k_2_02:52]
The following table shows the GAAP to non-GAAP reconciliation for Q4 FY’23 guidance:

[0000950170-23-014563:8k_2_02:53]
|  | Gross MarginRate |  | OperatingMargin Rate |  | Earnings perShare |
| GAAP | 57.7% - 59.7% |  | 8.9% - 10.8% |  | $0.16 - $0.22 |
| Estimated adjustments for: |  |  |  |  |  |
| Share-based compensation | 0.4% |  | 4.8% |  | 0.12 |
| Amortization of product intangibles | 0.7% |  | 0.7% |  | 0.02 |
| Amortization of non-product intangibles | 0.2% |  | 0.4% |  | 0.01 |
| Restructuring | — |  | 0.1% |  | 0.00 |
| Litigation charges | — |  | 0.3% |  | 0.01 |
| System transition cost | — |  | 0.3% |  | 0.01 |
| Tax adjustment | — |  | — |  | (0.05) |
| Non-GAAP | 59.0% - 61.0% |  | 15.5% - 17.3% |  | $0.28 - $0.34 |

[0000950170-23-014563:8k_2_02:54]
The total of percentage rate changes may not equal the total change in all cases due to rounding.

[0000950170-23-014563:8k_2_02:55]
Conference Call:

[0000950170-23-014563:8k_2_02:56]
Extreme will host a conference call at 8:00 a.m. Eastern (5:00 a.m. Pacific) today to review the third fiscal quarter results as well as the business outlook for the fourth quarter ending June 30, 2023, including significant factors and assumptions underlying the targets noted above. The conference call will be available to the public through a live audio web broadcast via the internet at http://investor.extremenetworks.com and a replay of the call will be available on the website for at least 7 days following the call. To access the call by phone, please go to this link (Extreme Networks Q3'23 Earnings Registration Link) and you will be provided with dial in details. To avoid delays, we encourage participants to dial into the conference call fifteen minutes ahead of the scheduled start time.

[0000950170-23-014563:8k_2_02:57]
About Extreme:

[0000950170-23-014563:8k_2_02:58]
Extreme Networks, Inc. (EXTR) creates networking experiences that enable all of us to advance. We push the boundaries of technology leveraging the powers of machine learning, artificial intelligence, analytics, and automation. Over 50,000 customers globally trust our end-to-end, cloud-driven networking solutions and rely on our top-rated services and support to accelerate their digital transformation efforts and deliver progress like never before. For more information, visit Extreme's website at https://www.extremenetworks.com/ or LinkedIn, YouTube, Twitter, Facebook or Instagram

[0000950170-23-014563:8k_2_02:59]
Extreme Networks, ExtremeCloud, and the Extreme Networks logo, are trademarks of Extreme Networks, Inc. or its subsidiaries in the United States and/or other countries. Other trademarks shown herein are the property of their respective owners.

[0000950170-23-014563:8k_2_02:60]
Non-GAAP Financial Measures:

[0000950170-23-014563:8k_2_02:61]
Extreme provides all financial information required in accordance with U.S. generally accepted accounting principles (“GAAP”). The Company is providing with this press release non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net debt and non-GAAP free cash flow. In preparing non-GAAP information, the Company has excluded, where applicable, the impact of share-based compensation, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges and the tax effect of non-GAAP adjustments.  The Company believes that excluding these items provides both management and investors with additional insight into its current operations, the trends affecting the Company, the Company's marketplace performance, and the Company's ability to generate cash from operations. Please note the Company’s non-GAAP measures may be different than those used by other companies. The additional non-GAAP financial information the Company presents should be considered in conjunction with, and not as a substitute for, the Company’s GAAP financial information.

[0000950170-23-014563:8k_2_02:62]
The Company has provided a non-GAAP reconciliation of the results for the periods presented in this release, which are adjusted to exclude certain items as indicated.  These measures should only be used to evaluate the Company's results of operations in conjunction with the corresponding GAAP measures for comparable financial information and understanding of the Company’s ongoing performance as a business. Extreme uses both GAAP and non-GAAP measures to evaluate and manage its operations.

[0000950170-23-014563:8k_2_02:63]
Forward-Looking Statements:

[0000950170-23-014563:8k_2_02:64]
More information about potential factors that could affect the Company's business and financial results are described in “Management's Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” included in the Company’s Annual Report on Form 10-K for the year ended June 30, 2022, Quarterly Reports on Form 10-Q for the quarter ended September 30, 2022 and December 31, 2022, and other documents of the Company on file with the Securities and Exchange Commission (available at www.sec.gov).  As a result of these risks and others, actual results could vary significantly from those anticipated in this press release, and the Company’s financial condition and results of operations could be materially adversely affected. Except as required under the U.S. federal securities laws and the rules and regulations of the U.S. Securities and Exchange Commission, Extreme disclaims any obligation to update any forward-looking statements after the date of this release, whether as a result of new information, future events, developments, changes in assumptions or otherwise.

[0000950170-23-014563:8k_2_02:65]
###

[0000950170-23-014563:8k_2_02:66]
EXTREME NETWORKS, INC.

[0000950170-23-014563:8k_2_02:67]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000950170-23-014563:8k_2_02:68]
(In thousands, except per share amounts)

[0000950170-23-014563:8k_2_02:69]
(Unaudited)

[0000950170-23-014563:8k_2_02:70]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| ASSETS |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash |  | $ | 202,996 |  |  | $ | 194,522 |  |
| Accounts receivable, net |  |  | 158,637 |  |  |  | 184,097 |  |
| Inventories |  |  | 70,310 |  |  |  | 49,231 |  |
| Prepaid expenses and other current assets |  |  | 70,129 |  |  |  | 61,239 |  |
| Total current assets |  |  | 502,072 |  |  |  | 489,089 |  |
| Property and equipment, net |  |  | 45,230 |  |  |  | 49,578 |  |
| Operating lease right-of-use assets, net |  |  | 36,311 |  |  |  | 36,454 |  |
| Intangible assets, net |  |  | 19,622 |  |  |  | 32,515 |  |
| Goodwill |  |  | 394,668 |  |  |  | 400,144 |  |
| Other assets |  |  | 70,496 |  |  |  | 60,730 |  |
| Total assets |  | $ | 1,068,399 |  |  | $ | 1,068,510 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |
| Current portion of long-term debt, net of unamortized debt issuance costs of $2,128 and $2,276, respectively |  | $ | 35,872 |  |  | $ | 33,349 |  |
| Accounts payable |  |  | 95,960 |  |  |  | 84,338 |  |
| Accrued compensation and benefits |  |  | 48,055 |  |  |  | 53,710 |  |
| Accrued warranty |  |  | 12,302 |  |  |  | 10,852 |  |
| Current portion, operating lease liabilities |  |  | 11,881 |  |  |  | 13,956 |  |
| Current portion, deferred revenue |  |  | 268,561 |  |  |  | 238,262 |  |
| Other accrued liabilities |  |  | 54,215 |  |  |  | 65,714 |  |
| Total current liabilities |  |  | 526,846 |  |  |  | 500,181 |  |
| Deferred revenue, less current portion |  |  | 195,675 |  |  |  | 163,357 |  |
| Long-term debt, less current portion, net of unamortized debt issuance costs of $812 and $2,430, respectively |  |  | 198,188 |  |  |  | 270,570 |  |
| Operating lease liabilities, less current portion |  |  | 33,446 |  |  |  | 33,256 |  |
| Deferred income taxes |  |  | 7,789 |  |  |  | 7,717 |  |
| Other long-term liabilities |  |  | 3,263 |  |  |  | 3,086 |  |
| Commitments and contingencies |  |  |  |  |  |  |
| Stockholders’ equity: |  |  |  |  |  |  |
| Convertible preferred stock, $0.001 par value, issuable in series, 2,000shares authorized; none issued |  |  | — |  |  |  | — |  |
| Common stock, $0.001 par value, 750,000 shares authorized; 143,296 and 139,742 shares issued, respectively; 128,888 and 129,263 shares outstanding, respectively |  |  | 143 |  |  |  | 140 |  |
| Additional paid-in-capital |  |  | 1,160,289 |  |  |  | 1,115,416 |  |
| Accumulated other comprehensive loss |  |  | (12,922 | ) |  |  | (3,055 | ) |
| Accumulated deficit |  |  | (881,425 | ) |  |  | (934,072 | ) |
| Treasury stock at cost, 14,408 and 10,479 shares, respectively |  |  | (162,893 | ) |  |  | (88,086 | ) |
| Total stockholders’ equity |  |  | 103,192 |  |  |  | 90,343 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,068,399 |  |  | $ | 1,068,510 |  |

[0000950170-23-014563:8k_2_02:71]
EXTREME NETWORKS, INC.

[0000950170-23-014563:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-014563:8k_2_02:73]
(In thousands, except per share amounts)

[0000950170-23-014563:8k_2_02:74]
(Unaudited)

[0000950170-23-014563:8k_2_02:75]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Net revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 241,058 |  |  | $ | 198,373 |  |  | $ | 670,779 |  |  | $ | 574,636 |  |
| Service and subscription |  |  | 91,449 |  |  |  | 87,135 |  |  |  | 277,765 |  |  |  | 259,489 |  |
| Total net revenues |  |  | 332,507 |  |  |  | 285,508 |  |  |  | 948,544 |  |  |  | 834,125 |  |
| Cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 108,915 |  |  |  | 92,582 |  |  |  | 312,265 |  |  |  | 264,459 |  |
| Service and subscription |  |  | 31,654 |  |  |  | 31,568 |  |  |  | 95,978 |  |  |  | 93,919 |  |
| Total cost of revenues |  |  | 140,569 |  |  |  | 124,150 |  |  |  | 408,243 |  |  |  | 358,378 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 132,143 |  |  |  | 105,791 |  |  |  | 358,514 |  |  |  | 310,177 |  |
| Service and subscription |  |  | 59,795 |  |  |  | 55,567 |  |  |  | 181,787 |  |  |  | 165,570 |  |
| Total gross profit |  |  | 191,938 |  |  |  | 161,358 |  |  |  | 540,301 |  |  |  | 475,747 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 54,837 |  |  |  | 49,615 |  |  |  | 158,444 |  |  |  | 145,461 |  |
| Sales and marketing |  |  | 83,962 |  |  |  | 72,840 |  |  |  | 242,882 |  |  |  | 213,932 |  |
| General and administrative |  |  | 21,683 |  |  |  | 17,714 |  |  |  | 64,315 |  |  |  | 52,594 |  |
| Acquisition and integration costs |  |  | — |  |  |  | 2,833 |  |  |  | 390 |  |  |  | 6,456 |  |
| Restructuring and related charges |  |  | 1,363 |  |  |  | 407 |  |  |  | 2,320 |  |  |  | 978 |  |
| Amortization of intangibles |  |  | 510 |  |  |  | 638 |  |  |  | 1,537 |  |  |  | 2,596 |  |
| Total operating expenses |  |  | 162,355 |  |  |  | 144,047 |  |  |  | 469,888 |  |  |  | 422,017 |  |
| Operating income |  |  | 29,583 |  |  |  | 17,311 |  |  |  | 70,413 |  |  |  | 53,730 |  |
| Interest income |  |  | 774 |  |  |  | 109 |  |  |  | 2,055 |  |  |  | 302 |  |
| Interest expense |  |  | (3,946 | ) |  |  | (2,794 | ) |  |  | (11,656 | ) |  |  | (9,750 | ) |
| Other income (expense), net |  |  | (367 | ) |  |  | 54 |  |  |  | 142 |  |  |  | 297 |  |
| Income before income taxes |  |  | 26,044 |  |  |  | 14,680 |  |  |  | 60,954 |  |  |  | 44,579 |  |
| Provision for income taxes |  |  | 3,913 |  |  |  | 1,856 |  |  |  | 8,307 |  |  |  | 5,718 |  |
| Net income |  | $ | 22,131 |  |  | $ | 12,824 |  |  | $ | 52,647 |  |  | $ | 38,861 |  |
| Basic and diluted income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.41 |  |  | $ | 0.30 |  |
| Net income per share – diluted |  | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.39 |  |  | $ | 0.29 |  |
| Shares used in per share calculation – basic |  |  | 128,816 |  |  |  | 129,913 |  |  |  | 129,864 |  |  |  | 129,321 |  |
| Shares used in per share calculation – diluted |  |  | 133,025 |  |  |  | 133,415 |  |  |  | 133,716 |  |  |  | 133,779 |  |

[0000950170-23-014563:8k_2_02:76]
EXTREME NETWORKS, INC.

[0000950170-23-014563:8k_2_02:77]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000950170-23-014563:8k_2_02:78]
(In thousands)

[0000950170-23-014563:8k_2_02:79]
(Unaudited)

[0000950170-23-014563:8k_2_02:80]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net Income |  | $ | 52,647 |  |  | $ | 38,861 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation |  |  | 15,014 |  |  |  | 15,324 |  |
| Amortization of intangible assets |  |  | 11,415 |  |  |  | 15,670 |  |
| Reduction in carrying amount of right-of-use asset |  |  | 9,274 |  |  |  | 11,641 |  |
| Provision for doubtful accounts |  |  | 245 |  |  |  | (3 | ) |
| Share-based compensation |  |  | 46,561 |  |  |  | 32,630 |  |
| Deferred income taxes |  |  | 338 |  |  |  | 228 |  |
| Non-cash interest expense |  |  | 756 |  |  |  | 3,611 |  |
| Other |  |  | (6,148 | ) |  |  | 41 |  |
| Changes in operating assets and liabilities, net of acquisition: |  |  |  |  |  |  |
| Accounts receivable |  |  | 25,216 |  |  |  | (5,068 | ) |
| Inventories |  |  | (21,989 | ) |  |  | (4,925 | ) |
| Prepaid expenses and other assets |  |  | 2,226 |  |  |  | (28,054 | ) |
| Accounts payable |  |  | 12,570 |  |  |  | 8,481 |  |
| Accrued compensation and benefits |  |  | (6,158 | ) |  |  | (28,227 | ) |
| Operating lease liabilities |  |  | (11,172 | ) |  |  | (14,524 | ) |
| Deferred revenue |  |  | 46,502 |  |  |  | 16,725 |  |
| Other current and long-term liabilities |  |  | (8,778 | ) |  |  | 1,644 |  |
| Net cash provided by operating activities |  |  | 168,519 |  |  |  | 64,055 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Capital expenditures |  |  | (8,634 | ) |  |  | (11,130 | ) |
| Business acquisition, net of cash acquired |  |  | — |  |  |  | (69,517 | ) |
| Net cash used in investing activities |  |  | (8,634 | ) |  |  | (80,647 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Payments on debt obligations |  |  | (71,625 | ) |  |  | (31,000 | ) |
| Repurchase of common stock |  |  | (74,807 | ) |  |  | (24,974 | ) |
| Payments for tax withholdings, net of proceeds from issuance of common stock |  |  | (1,685 | ) |  |  | (3,213 | ) |
| Payment of contingent consideration obligations |  |  | — |  |  |  | (1,024 | ) |
| Deferred payments on an acquisition |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Net cash used in financing activities |  |  | (151,117 | ) |  |  | (63,211 | ) |
| Foreign currency effect on cash |  |  | (294 | ) |  |  | (525 | ) |
| Net increase (decrease) in cash |  |  | 8,474 |  |  |  | (80,328 | ) |
| Cash at beginning of period |  |  | 194,522 |  |  |  | 246,894 |  |
| Cash at end of period |  | $ | 202,996 |  |  | $ | 166,566 |  |

[0000950170-23-014563:8k_2_02:81]
Extreme Networks, Inc.

[0000950170-23-014563:8k_2_02:82]
Non-GAAP Measures of Financial Performance

[0000950170-23-014563:8k_2_02:83]
To supplement the Company's consolidated financial statements presented in accordance with U.S. generally accepted accounting principles (“GAAP”), Extreme uses non-GAAP measures of certain components of financial performance.  These non-GAAP measures include non-GAAP gross margin, non-GAAP operating margin, non-GAAP operating income, non-GAAP net income, non-GAAP net income per diluted share, net debt and non-GAAP free cash flow.

[0000950170-23-014563:8k_2_02:84]
Reconciliation to the nearest GAAP measure of all historical non-GAAP measures included in this press release can be found in the tables included with this press release.

[0000950170-23-014563:8k_2_02:85]
Non-GAAP measures presented in this press release are not in accordance with or alternative measures prepared in accordance with GAAP and may be different from non-GAAP measures used by other companies.  In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles.  Non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Extreme’s results of operations as determined in accordance with GAAP.  These non-GAAP measures should only be used to evaluate Extreme’s results of operations in conjunction with the corresponding GAAP measures.

[0000950170-23-014563:8k_2_02:86]
Extreme believes these non-GAAP measures, when shown in conjunction with the corresponding GAAP measures, enhance investors' and management's overall understanding of the Company's current financial performance and the Company's prospects for the future, including cash flows available to pursue opportunities to enhance stockholder value.  In addition, because Extreme has historically reported certain non-GAAP results to investors, the Company believes the inclusion of non-GAAP measures provides consistency in the Company's financial reporting.

[0000950170-23-014563:8k_2_02:87]
For its internal planning process, and as discussed further below, Extreme's management uses financial statements that do not include share-based compensation expense, acquisition and integration costs, amortization of intangibles, restructuring charges, system transition costs, litigation charges, and the tax effect of non-GAAP adjustments.  Extreme’s management also uses non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the Company's financial results.

[0000950170-23-014563:8k_2_02:88]
As described above, Extreme excludes the following items from one or more of its non-GAAP measures when applicable.

[0000950170-23-014563:8k_2_02:89]
Share-based compensation. Consists of associated expenses for stock options, restricted stock awards and the Company’s Employee Stock Purchase Plan.  Extreme excludes share-based compensation expenses from its non-GAAP measures primarily because they are non-cash expenses that the Company does not believe are reflective of ongoing cash requirement related to its operating results. Extreme expects to incur share-based compensation expenses in future periods.

[0000950170-23-014563:8k_2_02:90]
Acquisition and integration costs. Acquisition and integration costs consist of specified compensation charges, software charges, and legal and professional fees related to the acquisition of Ipanema.  Extreme excludes these expenses since they result from an event that is outside the ordinary course of continuing operations.

[0000950170-23-014563:8k_2_02:91]
Amortization of intangibles. Amortization of intangibles includes the monthly amortization expense of intangible assets such as developed technology, customer relationships, trademarks and order backlog.  The amortization of the developed technology and order backlog are recorded in cost of goods sold, while the amortization for the other intangibles is recorded in operating expenses.  Extreme excludes these

[0000950170-23-014563:8k_2_02:92]
expenses since they result from an intangible asset and for which the period expense does not impact the operations of the business and are non-cash in nature.

[0000950170-23-014563:8k_2_02:93]
Restructuring charges. Restructuring charges consist of severance costs for employees, asset disposal costs and other charges related to excess facilities that do not provide economic benefit to our future operations. Extreme excludes restructuring expenses since they result from events that occur outside of the ordinary course of continuing operations.

[0000950170-23-014563:8k_2_02:94]
System transition costs. System transition costs consist of costs related to direct and incremental costs incurred in connection with our multi-phase transition of our customer relationship management solution. Extreme excludes these costs because we believe that these costs do not reflect future operating expenses and will be inconsistent in amount and frequency making it difficult to contribute to a meaningful evaluation of our operating performance.

[0000950170-23-014563:8k_2_02:95]
Litigation charges. Litigation charges consist of estimated settlement and related legal expenses for a non-recurring pending litigation.

[0000950170-23-014563:8k_2_02:96]
Tax effect of non-GAAP adjustments. We calculate our non-GAAP provision for income taxes in accordance with the SEC guidance on non-GAAP Financial Measures Compliance and Disclosure Interpretation.  We have assumed our U.S. federal and state net operating losses would have been fully consumed by the historical non-GAAP financial adjustments, eliminating the need for a full valuation allowance against our U.S. deferred tax assets which, consequently, enables our use of research and development tax credits.  The non-GAAP tax provision consists of current and deferred income tax expense commensurate with the non-GAAP measure of profitability using our blended U.S. statutory tax rate of 24.6%.

[0000950170-23-014563:8k_2_02:97]
Non-GAAP provision for income taxes may be higher or lower depending on the level and jurisdictional mix of pre-tax income and available U.S. research and development tax credits.  As of the tax year ended June 30, 2022, we had U.S. federal net operating loss carryforwards of $184.4 million, state net operating loss carryforwards of $162.8 million and net operating loss carryforwards for the Irish holding Company of $8.9 million.  These amounts were reflected in our requisite tax filings for each jurisdiction for the tax year ended June 30, 2022.

[0000950170-23-014563:8k_2_02:98]
Over the next year, our cash taxes will be driven by certain US state taxes and the tax expense of our foreign subsidiaries which amounts have not historically been significant, with the exception of the Company’s Indian subsidiary which performs research and development activities, as well as the Company’s Irish operating company which fully utilized available net operating loss carryforwards during the tax year ended June 30, 2021.

[0000950170-23-014563:8k_2_02:99]
EXTREME NETWORKS, INC.

[0000950170-23-014563:8k_2_02:100]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000950170-23-014563:8k_2_02:101]
GAAP TO NON-GAAP RECONCILIATION

[0000950170-23-014563:8k_2_02:102]
(In thousands, except percentages and per share amounts)

[0000950170-23-014563:8k_2_02:103]
(Unaudited)

[0000950170-23-014563:8k_2_02:104]
| Revenues | Three Months Ended | Nine Months Ended |
|  | March 31,2023 |  | March 31,2022 |  | March 31,2023 |  | March 31,2022 |
| Revenues – GAAP | $332,507 |  | $285,508 |  | $948,544 |  | $834,125 |

[0000950170-23-014563:8k_2_02:105]
| Non-GAAP Gross Margin | Three Months Ended | Nine Months Ended |  |
|  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Gross profit – GAAP | $ | 191,938 |  |  | $ | 161,358 |  |  | $ | 540,301 |  |  | $ | 475,747 |  |
| Gross margin – GAAP percentage |  | 57.7 | % |  |  | 56.5 | % |  |  | 57.0 | % |  |  | 57.0 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, Product |  | 492 |  |  |  | 291 |  |  |  | 1,365 |  |  |  | 904 |  |
| Share-based compensation expense, Services and subscription |  | 930 |  |  |  | 343 |  |  |  | 2,568 |  |  |  | 1,056 |  |
| Amortization of intangibles, Product |  | 2,220 |  |  |  | 2,805 |  |  |  | 7,381 |  |  |  | 10,576 |  |
| Amortization of intangibles, Service and subscription |  | 815 |  |  |  | 815 |  |  |  | 2,444 |  |  |  | 2,444 |  |
| Total adjustments to GAAP gross profit | $ | 4,457 |  |  | $ | 4,254 |  |  | $ | 13,758 |  |  | $ | 14,980 |  |
| Gross profit – non-GAAP | $ | 196,395 |  |  | $ | 165,612 |  |  | $ | 554,059 |  |  | $ | 490,727 |  |
| Gross margin – non-GAAP percentage |  | 59.1 | % |  |  | 58.0 | % |  |  | 58.4 | % |  |  | 58.8 | % |

[0000950170-23-014563:8k_2_02:106]
| Non-GAAP Operating Income | Three Months Ended | Nine Months Ended |  |
|  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| GAAP operating income | $ | 29,583 |  |  | $ | 17,311 |  |  | $ | 70,413 |  |  | $ | 53,730 |  |
| GAAP operating income percentage |  | 8.9 | % |  |  | 6.1 | % |  |  | 7.4 | % |  |  | 6.4 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense, cost of revenues |  | 1,422 |  |  |  | 634 |  |  |  | 3,933 |  |  |  | 1,960 |  |
| Share-based compensation expense, R&D |  | 3,883 |  |  |  | 2,446 |  |  |  | 10,935 |  |  |  | 7,568 |  |
| Share-based compensation expense, S&M |  | 5,777 |  |  |  | 3,832 |  |  |  | 16,326 |  |  |  | 11,267 |  |
| Share-based compensation expense, G&A |  | 4,294 |  |  |  | 3,941 |  |  |  | 15,367 |  |  |  | 11,835 |  |
| Acquisition and integration costs |  | — |  |  |  | 2,833 |  |  |  | 390 |  |  |  | 6,456 |  |
| Restructuring charges |  | 1,363 |  |  |  | 407 |  |  |  | 2,320 |  |  |  | 978 |  |
| Litigation charges |  | 1,680 |  |  |  | — |  |  |  | 4,003 |  |  |  | — |  |
| System transition costs |  | 490 |  |  |  | — |  |  |  | 490 |  |  |  | — |  |
| Amortization of intangibles |  | 3,545 |  |  |  | 4,258 |  |  |  | 11,362 |  |  |  | 15,616 |  |
| Total adjustments to GAAP operating income |  | 22,454 |  |  |  | 18,351 |  |  |  | 65,126 |  |  |  | 55,680 |  |
| Non-GAAP operating income | $ | 52,037 |  |  | $ | 35,662 |  |  | $ | 135,539 |  |  | $ | 109,410 |  |
| Non-GAAP operating income percentage |  | 15.6 | % |  |  | 12.5 | % |  |  | 14.3 | % |  |  | 13.1 | % |

[0000950170-23-014563:8k_2_02:107]
| Non-GAAP net income | Three Months Ended | Nine Months Ended |  |
|  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| GAAP net income | $ | 22,131 |  |  | $ | 12,824 |  |  | $ | 52,647 |  |  | $ | 38,861 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 15,376 |  |  |  | 10,853 |  |  |  | 46,561 |  |  |  | 32,630 |  |
| Acquisition and integration costs |  | — |  |  |  | 2,833 |  |  |  | 390 |  |  |  | 6,456 |  |
| Restructuring charge, net of reversal |  | 1,363 |  |  |  | 407 |  |  |  | 2,320 |  |  |  | 978 |  |
| Litigation charges |  | 1,680 |  |  |  | — |  |  |  | 4,003 |  |  |  | — |  |
| System transition costs |  | 490 |  |  |  | — |  |  |  | 490 |  |  |  | — |  |
| Amortization of intangibles |  | 3,545 |  |  |  | 4,258 |  |  |  | 11,362 |  |  |  | 15,616 |  |
| Tax effect of non-GAAP adjustments |  | (5,737 | ) |  |  | (3,760 | ) |  |  | (15,359 | ) |  |  | (10,740 | ) |
| Total adjustments to GAAP net income | $ | 16,717 |  |  | $ | 14,591 |  |  | $ | 49,767 |  |  | $ | 44,940 |  |
| Non-GAAP net income | $ | 38,848 |  |  | $ | 27,415 |  |  | $ | 102,414 |  |  | $ | 83,801 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share – diluted | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.39 |  |  | $ | 0.29 |  |
| Non-GAAP net income per share – diluted | $ | 0.29 |  |  | $ | 0.21 |  |  | $ | 0.77 |  |  | $ | 0.63 |  |
| Shares used in net income per share – diluted: |  |  |  |  |  |  |  |  |  |  |  |
| GAAP Shares used in per share calculation – basic |  | 128,816 |  |  |  | 129,913 |  |  |  | 129,864 |  |  |  | 129,321 |  |
| Potentially dilutive equity awards |  | 4,209 |  |  |  | 3,502 |  |  |  | 3,852 |  |  |  | 4,458 |  |
| GAAP and Non-GAAP shares used in per share calculation – diluted |  | 133,025 |  |  |  | 133,415 |  |  |  | 133,716 |  |  |  | 133,779 |  |
