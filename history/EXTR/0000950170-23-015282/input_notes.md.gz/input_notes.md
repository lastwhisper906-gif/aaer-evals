# EXTR notes — 0000950170-23-015282


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000950170-23-015282:notes:1]
1.
Description of Business and Basis of Presentation

[0000950170-23-015282:notes:2]
Extreme Networks, Inc., together with its subsidiaries (collectively referred to as “Extreme” or the “Company”), is a leader in providing software-driven networking solutions for enterprise customers. The Company conducts its sales and marketing activities on a worldwide basis through distributors, resellers and the Company’s field sales organization. Extreme was incorporated in California in 1996 and reincorporated in Delaware in 1999.

[0000950170-23-015282:notes:3]
The unaudited condensed consolidated financial statements of Extreme included herein have been prepared under the rules and regulations of the Securities and Exchange Commission (“SEC”). Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted under such rules and regulations. The condensed consolidated balance sheet at June 30, 2022 was derived from audited financial statements as of that date but does not include all disclosures required by generally accepted accounting principles for complete financial statements. These interim financial statements and notes should be read in conjunction with the Company’s audited consolidated financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022.

[0000950170-23-015282:notes:4]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2023. The results of operations for the three and nine months ended March 31, 2023 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.

[0000950170-23-015282:notes:5]
[same as prior period, unchanged from 0001564590-23-000867:notes:5]

[0000950170-23-015282:notes:6]
The Company uses a fiscal calendar year ending on June 30. All references herein to “fiscal 2023” represent the fiscal year ending June 30, 2023. All references herein to “fiscal 2022” represent the fiscal year ended June 30, 2022.

[0000950170-23-015282:notes:7]
[same as prior period, unchanged from 0001564590-23-000867:notes:7]

[0000950170-23-015282:notes:8]
[same as prior period, unchanged from 0001564590-23-000867:notes:8]

[0000950170-23-015282:notes:9]
[same as prior period, unchanged from 0001564590-23-000867:notes:9]

[0000950170-23-015282:notes:10]
[same as prior period, unchanged from 0001564590-23-000867:notes:10]

[0000950170-23-015282:notes:11]
[same as prior period, unchanged from 0001564590-23-000867:notes:11]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-23-015282:notes:12]
2.
Summary of Significant Accounting Policies

[0000950170-23-015282:notes:13]
For a description of significant accounting policies, see Note 2, Summary of Significant Accounting Policies, to the consolidated financial statements included in the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2022. There have been no material changes to the Company’s significant accounting policies since the filing of the Annual Report on Form 10-K.

[0000950170-23-015282:notes:14]
Recently Adopted Accounting Pronouncements

[0000950170-23-015282:notes:15]
In December 2022, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which extends the period of time entities can utilize the reference rate reform relief guidance under ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting from December 31, 2022 to December 31, 2024. Upon issuance of ASU 2020-04, the Company elected to apply certain of the optional expedients for contract modifications to its financial instruments impacted by the London Interbank Offered Rate (“LIBOR”) discontinuance. The Company expects to continue to elect various optional expedients for contract modifications to the Company’s financial instruments affected by the reference rate reform through the effective date of December 31, 2024, as extended by ASU 2022-06. The application of this guidance did not have any impact on our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-015282:notes:16]
3.
Revenues

[0000950170-23-015282:notes:17]
The Company accounts for revenues in accordance with ASU 2014-09, Revenue from Contracts from Customers (Topic 606). The Company derives the majority of its revenues from sales of its networking equipment, with the remaining revenues generated from sales of services and subscriptions, which primarily includes maintenance contracts and software subscriptions delivered as software as a service (“SaaS”) and additional revenues from professional services, and training for its products. The Company sells its products, maintenance contracts and SaaS direct to customers and to partners in two distribution channels, or tiers. The first tier consists of a limited number of independent distributors that stock its products and sell primarily to resellers. The second tier of the distribution channel consists of non-stocking distributors and value-added resellers that sell directly to end-users. Products and services may be sold separately or in bundled packages.

[0000950170-23-015282:notes:18]
[same as prior period, unchanged from 0001564590-23-000867:notes:19]

[0000950170-23-015282:notes:19]
[same as prior period, unchanged from 0001564590-23-000867:notes:20]

[0000950170-23-015282:notes:20]
[same as prior period, unchanged from 0001564590-23-000867:notes:21]

[0000950170-23-015282:notes:21]
On March 31, 2023, the Company had $464.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 20% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 44% in fiscal 2024 and 36% of the balance thereafter.

[0000950170-23-015282:notes:22]
[same as prior period, unchanged from 0001564590-23-000867:notes:23]

[0000950170-23-015282:notes:23]
Revenue recognized for the three months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $81.0 million and $77.3 million, respectively. Revenue recognized for the nine months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $193.7 million and $176.1 million, respectively.

[0000950170-23-015282:notes:24]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $18.2 million and $16.3 million at March 31, 2023 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2023 and 2022, was $2.3 million and $1.9 million, respectively. Amortization recognized during the nine months ended March 31, 2023 and 2022, was $6.7 million and $5.5 million, respectively.

[0000950170-23-015282:notes:25]
[same as prior period, unchanged from 0001564590-23-000867:notes:26]

[0000950170-23-015282:notes:26]
[same as prior period, unchanged from 0001564590-23-000867:notes:27]

[0000950170-23-015282:notes:27]
[same as prior period, unchanged from 0001564590-23-000867:notes:28]

[0000950170-23-015282:notes:28]
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |
| Other |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |
| Total Americas |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |
| EMEA |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |
| APAC |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |
| Total net revenues |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |

[0000950170-23-015282:notes:29]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |
| Other |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |
| Total Americas |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |
| EMEA |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |
| APAC |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |
| Total net revenues |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |

[0000950170-23-015282:notes:30]
For three and nine months ended March 31, 2023 the Company generated 17% and 12% of its revenues from the Netherlands, respectively. For the three and nine months ended March 31, 2022 the Company generated 18% and 12% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2023 and 2022.

[0000950170-23-015282:notes:31]
[same as prior period, unchanged from 0001564590-23-000867:notes:32]

[0000950170-23-015282:notes:32]
[same as prior period, unchanged from 0001564590-23-000867:notes:33]

[0000950170-23-015282:notes:33]
[same as prior period, unchanged from 0001564590-23-000867:notes:34]

[0000950170-23-015282:notes:34]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2023 |  | March 31,2022 |  | March 31,2023 |  | March 31,2022 |
| Westcon Group, Inc. |  | 25% |  | 25% |  | 20% |  | 18% |
| TD Synnex Corporation |  | 19% |  | 17% |  | 19% |  | 20% |
| Jenne, Inc. |  | 15% |  | 20% |  | 14% |  | 17% |

[0000950170-23-015282:notes:35]
[same as prior period, unchanged from 0001564590-23-000867:notes:36]

[0000950170-23-015282:notes:36]
|  |  | March 31,2023 |  | June 30,2022 |
| Jenne, Inc. |  | 25% |  | 28% |
| Westcon Group, Inc. |  | 21% |  | * |
| TD Synnex Corporation |  | * |  | 11% |
| * Less than 10% of accounts receivable. |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-015282:notes:37]
4.
Business Combination

[0000950170-23-015282:notes:38]
[same as prior period, unchanged from 0001564590-23-000867:notes:39]

[0000950170-23-015282:notes:39]
[same as prior period, unchanged from 0001564590-23-000867:notes:40]

[0000950170-23-015282:notes:40]
On September 14, 2021 (the “Acquisition Date”), the Company completed its acquisition (the “Acquisition”) of Ipanematech SAS (“Ipanema”), the cloud-native enterprise Software-Defined Wide Area Network (“SD-WAN”) business unit of Infovista pursuant to a Sale and Purchase Agreement. Under the terms of the Acquisition, the net consideration paid by Extreme to Ipanema stockholders was $70.9 million, which was funded through cash on hand. The primary reason for the acquisition was to acquire the talent and the technology to allow the Company to expand its portfolio with new cloud-managed SD-WAN and security offerings to support its enterprise customers.

[0000950170-23-015282:notes:41]
The Acquisition was accounted for using the acquisition method of accounting whereby the acquired assets and liabilities of Ipanema have been recorded at their respective fair values and added to those of the Company including an amount for goodwill calculated as the difference between the acquisition consideration and the fair value of the identifiable net assets. The purchase price has been allocated to tangible and identifiable intangible assets acquired and liabilities assumed. Of the total purchase consideration, $68.9 million was allocated to goodwill, $16.3 million to identifiable intangible assets and the remainder to net tangible liabilities assumed. All valuations were finalized as of June 30, 2022.

[0000950170-23-015282:notes:42]
[same as prior period, unchanged from 0001564590-23-000867:notes:43]

[0000950170-23-015282:notes:43]
[same as prior period, unchanged from 0001564590-23-000867:notes:44]

[0000950170-23-015282:notes:44]
The unaudited pro forma financial information for the three and nine months ended March 31, 2022 combines the historical results for Extreme for that period, which include the results of Ipanema subsequent to the Acquisition Date, and Ipanema’s historical results up to the Acquisition Date.

[0000950170-23-015282:notes:45]
[same as prior period, unchanged from 0001564590-23-000867:notes:46]

[0000950170-23-015282:notes:46]
|  | Three months ended |  | Nine Months Ended |  |
|  | March 31,2022* |  | March 31,2022* |  |
| Net revenues | $ | 285,508 |  | $ | 837,251 |  |
| Net income | $ | 15,657 |  | $ | 47,201 |  |
| Net income per share – basic | $ | 0.12 |  | $ | 0.36 |  |
| Net income per share – diluted | $ | 0.12 |  | $ | 0.35 |  |
| Shares used in per share calculation – basic |  | 129,913 |  |  | 129,321 |  |
| Shares used in per share calculation – diluted |  | 133,415 |  |  | 133,779 |  |

[0000950170-23-015282:notes:47]
*Amount reflects the adoption of ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which the Company early adopted the standard in the quarter ended December 31, 2021 and retrospectively applied to the fiscal year beginning July 1, 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000950170-23-015282:notes:48]
5.
Balance Sheet Accounts

[0000950170-23-015282:notes:49]
[same as prior period, unchanged from 0001564590-23-000867:notes:50]

[0000950170-23-015282:notes:50]
[same as prior period, unchanged from 0001564590-23-000867:notes:51]

[0000950170-23-015282:notes:51]
[same as prior period, unchanged from 0001564590-23-000867:notes:52]

[0000950170-23-015282:notes:52]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Finished goods |  | $ | 62,089 |  |  | $ | 40,733 |  |
| Raw materials |  |  | 8,221 |  |  |  | 8,498 |  |
| Total inventories |  | $ | 70,310 |  |  | $ | 49,231 |  |

[0000950170-23-015282:notes:53]
[same as prior period, unchanged from 0001564590-23-000867:notes:54]

[0000950170-23-015282:notes:54]
[same as prior period, unchanged from 0001564590-23-000867:notes:55]

[0000950170-23-015282:notes:55]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Computers and equipment |  | $ | 71,218 |  |  | $ | 75,387 |  |
| Purchased software |  |  | 50,306 |  |  |  | 47,161 |  |
| Office equipment, furniture and fixtures |  |  | 8,682 |  |  |  | 9,463 |  |
| Leasehold improvements |  |  | 52,104 |  |  |  | 52,564 |  |
| Total property and equipment |  |  | 182,310 |  |  |  | 184,575 |  |
| Less: accumulated depreciation and amortization |  |  | (137,080 | ) |  |  | (134,997 | ) |
| Property and equipment, net |  | $ | 45,230 |  |  | $ | 49,578 |  |

[0000950170-23-015282:notes:56]
[same as prior period, unchanged from 0001564590-23-000867:notes:57]

[0000950170-23-015282:notes:57]
Deferred revenue represents invoiced amounts for deferred maintenance, support, SaaS, and other deferred revenue including professional services and training when the revenue recognition criteria have not been met.

[0000950170-23-015282:notes:58]
[same as prior period, unchanged from 0001564590-23-000867:notes:59]

[0000950170-23-015282:notes:59]
[same as prior period, unchanged from 0001564590-23-000867:notes:60]

[0000950170-23-015282:notes:60]
The following table summarizes the activity related to the Company’s product warranty liability during the three and nine months ended March 31, 2023 and 2022 (in thousands):

[0000950170-23-015282:notes:61]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Balance beginning of period |  | $ | 11,820 |  |  | $ | 11,137 |  |  | $ | 10,852 |  |  | $ | 11,623 |  |
| Warranties assumed due to acquisition |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41 |  |
| New warranties issued |  |  | 4,161 |  |  |  | 3,104 |  |  |  | 11,976 |  |  |  | 9,636 |  |
| Warranty expenditures |  |  | (3,679 | ) |  |  | (3,665 | ) |  |  | (10,526 | ) |  |  | (10,724 | ) |
| Balance end of period |  | $ | 12,302 |  |  | $ | 10,576 |  |  | $ | 12,302 |  |  | $ | 10,576 |  |

[0000950170-23-015282:notes:62]
[same as prior period, unchanged from 0001564590-23-000867:notes:63]

[0000950170-23-015282:notes:63]
[same as prior period, unchanged from 0001564590-23-000867:notes:64]

[0000950170-23-015282:notes:64]
[same as prior period, unchanged from 0001564590-23-000867:notes:65]


## us-gaap:FairValueDisclosuresTextBlock

[0000950170-23-015282:notes:65]
6.
Fair Value Measurements

[0000950170-23-015282:notes:66]
[same as prior period, unchanged from 0001564590-23-000867:notes:67]

[0000950170-23-015282:notes:67]
•
Level 1 Inputs - unadjusted quoted prices in active markets for identical assets or liabilities;

[0000950170-23-015282:notes:68]
•
Level 2 Inputs - quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000950170-23-015282:notes:69]
•
Level 3 Inputs - unobservable inputs reflecting the Company’s own assumptions in measuring the asset or liability at fair value.

[0000950170-23-015282:notes:70]
The following table presents the Company’s fair value hierarchy for its financial assets and liabilities measured at fair value on a recurring basis at March 31, 2023 and June 30, 2022 (in thousands).

[0000950170-23-015282:notes:71]
| March 31, 2023 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Interest rate swaps |  |  | — |  |  |  | 92 |  |  |  | — |  |  |  | 92 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 127 |  |  | $ | — |  |  | $ | 127 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |

[0000950170-23-015282:notes:72]
| June 30, 2022 |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Total assets measured at fair value |  | $ | — |  |  | $ | 1,314 |  |  | $ | — |  |  | $ | 1,314 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |
| Total liabilities measured at fair value |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |

[0000950170-23-015282:notes:73]
[same as prior period, unchanged from 0001564590-23-000867:notes:74]

[0000950170-23-015282:notes:74]
[same as prior period, unchanged from 0001564590-23-000867:notes:75]

[0000950170-23-015282:notes:75]
As of March 31, 2023 and June 30, 2022, the Company had foreign exchange forward contracts that were not designated as hedging instruments with notional principal amounts of $11.2 million and $9.6 million, respectively. These contracts have maturities of 60 days or less. Changes in the fair value of these foreign exchange forward contracts not designated as hedging instruments are included in other income or expenses in the condensed consolidated statement of operations. For the three and nine months ended March 31, 2023, there were net gains of $0.1 million and net losses of $0.3 million, respectively. For the three and nine months ended March 31, 2022, there were net losses of $0.1 million and $0.4 million, respectively. As of March 31, 2023, the Company had foreign exchange forward contracts that were designated as hedging instruments with a notional principal amount of $5.4 million. These contracts have maturities of less than twelve months. Unrealized gains and losses arising from these contracts designated as hedging instruments are recorded as a component of accumulated other comprehensive loss in the condensed consolidated balance sheet. As of March 31, 2023, these contracts had an unrealized gain of less than $0.1 million. As of June 30, 2022, there were no outstanding foreign exchange forward contracts that were designated as hedging instruments. See Note 13, Derivatives and Hedging, for additional information.

[0000950170-23-015282:notes:76]
The fair values of the interest rate swaps are based upon inputs corroborated by observable market data which is considered Level 2. As of March 31, 2023 and June 30, 2022, the Company had interest rate swap contracts, designated as cash flow hedges, with the total notional amount of $75.0 million. Changes in the fair value of these contracts are recorded as a component of accumulated other comprehensive loss in the condensed consolidated balance sheet. As of March 31, 2023 and June 30, 2022, these contracts had unrealized gains of $0.1 million and $1.3 million, respectively. See Note 13, Derivatives and Hedging, for additional information.

[0000950170-23-015282:notes:77]
The fair value of borrowings under the 2019 Credit Agreement (as defined in Note 8) is estimated based on valuations provided by alternative pricing sources supported by observable inputs which is considered Level 2. Since the interest rate is variable for the 2019 Credit Agreement, the fair value approximates the face amount of the Company’s indebtedness of $237.0 million and $308.6 million as of March 31, 2023 and June 30, 2022, respectively.

[0000950170-23-015282:notes:78]
[same as prior period, unchanged from 0001564590-23-000867:notes:79]

[0000950170-23-015282:notes:79]
As of March 31, 2023 and June 30, 2022, the Company did not have any assets or liabilities that were considered Level 3. 
There were no transfers of assets or liabilities between Level 1, Level 2 and Level 3 during the three and nine months ended March 31, 2023 and 2022. There were no impairments recorded for the three and nine months ended March 31, 2023 and 2022.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-015282:notes:80]
7.
Intangible Assets and Goodwill

[0000950170-23-015282:notes:81]
[same as prior period, unchanged from 0001564590-23-000867:notes:83]

[0000950170-23-015282:notes:82]
[same as prior period, unchanged from 0001564590-23-000867:notes:84]

[0000950170-23-015282:notes:83]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| March 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.4 years |  | $ | 169,441 |  |  | $ | 156,541 |  |  | $ | 12,900 |  |
| Customer relationships |  | 3.4 years |  |  | 64,704 |  |  |  | 58,249 |  |  |  | 6,455 |  |
| Trade names |  | 0.0 years |  |  | 10,700 |  |  |  | 10,700 |  |  |  | — |  |
| License agreements |  | 3.7 years |  |  | 2,445 |  |  |  | 2,178 |  |  |  | 267 |  |
| Total intangibles, net* |  |  |  | $ | 247,290 |  |  | $ | 227,668 |  |  | $ | 19,622 |  |
| * Foreign intangible assets carrying amounts are affected by foreign currency translation. |  |  |  |  |

[0000950170-23-015282:notes:84]
|  |  | Weighted Average |  |  |  |  |  |  |  |  |  |
|  |  | Remaining Amortization |  | Gross Carrying |  |  | Accumulated |  |  | Net Carrying |  |
|  |  | Period |  | Amount |  |  | Amortization |  |  | Amount |  |
| June 30, 2022 |  |  |  |  |  |  |  |  |  |  |  |
| Developed technology |  | 3.3 years |  | $ | 170,600 |  |  | $ | 146,560 |  |  | $ | 24,040 |  |
| Customer relationships |  | 3.9 years |  |  | 64,839 |  |  |  | 56,704 |  |  |  | 8,135 |  |
| Trade names |  | 0.1 years |  |  | 10,700 |  |  |  | 10,680 |  |  |  | 20 |  |
| License agreements |  | 4.4 years |  |  | 2,445 |  |  |  | 2,125 |  |  |  | 320 |  |
| Total intangibles, net* |  |  |  | $ | 248,584 |  |  | $ | 216,069 |  |  | $ | 32,515 |  |
| * Foreign intangible assets carrying amounts are affected by foreign currency translation. |  |  |  |  |

[0000950170-23-015282:notes:85]
[same as prior period, unchanged from 0001564590-23-000867:notes:88]

[0000950170-23-015282:notes:86]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Amortization of intangibles in “Total cost of revenues” |  | $ | 3,052 |  |  | $ | 3,639 |  |  | $ | 9,878 |  |  | $ | 13,074 |  |
| Amortization of intangibles in “Total operating expenses” |  |  | 510 |  |  |  | 638 |  |  |  | 1,537 |  |  |  | 2,596 |  |
| Total amortization expense |  | $ | 3,562 |  |  | $ | 4,277 |  |  | $ | 11,415 |  |  | $ | 15,670 |  |

[0000950170-23-015282:notes:87]
[same as prior period, unchanged from 0001564590-23-000867:notes:90]

[0000950170-23-015282:notes:88]
[same as prior period, unchanged from 0001564590-23-000867:notes:91]

[0000950170-23-015282:notes:89]
| For the fiscal year ending: |  |  |  |
| 2023 (the remainder of fiscal 2023) |  | $ | 3,688 |  |
| 2024 |  |  | 5,250 |  |
| 2025 |  |  | 4,485 |  |
| 2026 |  |  | 3,214 |  |
| 2027 |  |  | 1,440 |  |
| Thereafter |  |  | 1,545 |  |
| Total |  | $ | 19,622 |  |

[0000950170-23-015282:notes:90]
[same as prior period, unchanged from 0001564590-23-000867:notes:93]

[0000950170-23-015282:notes:91]
The Company had Goodwill in the amount of $394.7 million and $400.1 million as of March 31, 2023 and June 30, 2022, respectively. The change in goodwill during the nine months ended March 31, 2023 is due to foreign currency translation adjustment that is recorded as a component of accumulated other comprehensive loss.


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-015282:notes:92]
8.
Debt

[0000950170-23-015282:notes:93]
The Company’s debt is comprised of the following (in thousands):

[0000950170-23-015282:notes:94]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,128 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,872 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 199,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (812 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 198,188 |  |  |  | 270,570 |  |
| Total debt |  | $ | 234,060 |  |  | $ | 303,919 |  |

[0000950170-23-015282:notes:95]
On August 9, 2019, the Company entered into an Amended and Restated Credit Agreement (the “2019 Credit Agreement”), by and among the Company, as borrower, several banks and other financial institutions as Lenders, BMO Harris Bank N.A., as an issuing lender and swingline lender, Silicon Valley Bank, as an Issuing Lender, and Bank of Montreal, as administrative agent and collateral agent for the Lenders.

[0000950170-23-015282:notes:96]
The 2019 Credit Agreement provides for a five-year first lien term loan facility in an aggregate principal amount of $380.0 million and a five-year revolving loan facility in an aggregate principal amount of $75.0 million (the “2019 Revolving Facility”). In addition, the Company may request incremental term loans and/or incremental revolving loan commitments in an aggregate amount not to exceed the sum of $100.0 million, plus an unlimited amount that is subject to pro forma compliance with certain financial tests. On August 9, 2019, the Company used the additional proceeds from the term loan to partially fund the acquisition of Aerohive Networks, Inc. and for working capital and general corporate purposes.

[0000950170-23-015282:notes:97]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly

[0000950170-23-015282:notes:98]
(currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

[0000950170-23-015282:notes:99]
The 2019 Credit Agreement requires the Company to maintain certain minimum financial ratios at the end of each fiscal quarter. The 2019 Credit Agreement also includes covenants and restrictions that limit, among other things, the Company’s ability to incur additional indebtedness, create liens upon any of its property, merge, consolidate or sell all or substantially all of its assets. The 2019 Credit Agreement also includes customary events of default which may result in acceleration of the payment of the outstanding balance.

[0000950170-23-015282:notes:100]
On April 8, 2020, the Company entered into an amendment to the 2019 Credit Agreement (the “First Amendment”) to waive certain terms and financial covenants of the 2019 Credit Agreement through July 31, 2020. On May 8, 2020, the Company entered into a second amendment to the 2019 Credit Agreement (the “Second Amendment”), which superseded the First Amendment and provided certain revised terms and financial covenants through March 31, 2021. The Second Amendment required the Company to maintain certain minimum cash requirement and financial metrics at the end of each fiscal quarter through March 31, 2021 and the Company was restricted from pursuing certain activities such as incurring additional debt, stock repurchases, making acquisitions or declaring a dividend, until the Company was in compliance with the original covenants of the 2019 Credit Agreement.

[0000950170-23-015282:notes:101]
On November 3, 2020, the Company and its lenders entered into a Third Amendment to the 2019 Credit Agreement (the “Third Amendment”), to increase the sublimit for letters of credit to $20.0 million. On December 8, 2020, the Company and its lenders entered into a fourth amendment to the 2019 Credit Agreement (the “Fourth Amendment”), to waive and amend certain terms and financial covenants within the 2019 Credit Agreement through March 31, 2021.

[0000950170-23-015282:notes:102]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three and nine months ended March 31, 2023, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.

[0000950170-23-015282:notes:103]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million each for the three months ended March 31, 2023 and 2022 and totaled $2.2 million and $2.3 million for the nine months ended March 31, 2023 and 2022, respectively. The interest rate as of March 31, 2023 was 5.97% and as of March 31, 2022 was 2.07%.

[0000950170-23-015282:notes:104]
As of March 31, 2023, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance. The Company had $60.2 million of availability under the 2019 Revolving Facility as of March 31, 2023. During the nine months ended March 31, 2023 and 2022, the Company made an additional payment of $45.5 million and $12.0 million, respectively, against its term loan facility, respectively.

[0000950170-23-015282:notes:105]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-015282:notes:106]
9.
Commitments and Contingencies

[0000950170-23-015282:notes:107]
Purchase Commitments

[0000950170-23-015282:notes:108]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2023, the Company had commitments to purchase $56.8 million of inventory.

[0000950170-23-015282:notes:109]
Legal Proceedings

[0000950170-23-015282:notes:110]
The Company may from time to time be party to litigation arising in the course of its business, including, without limitation, allegations relating to commercial transactions, business relationships or intellectual property rights. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Litigation in general, and intellectual property in particular, can be expensive and disruptive to normal business operations. Moreover, the results of legal proceedings are difficult to predict.

[0000950170-23-015282:notes:111]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The

[0000950170-23-015282:notes:112]
Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

[0000950170-23-015282:notes:113]
XR Communications, LLC d/b/a Vivato Technologies v. Extreme Networks, Inc.

[0000950170-23-015282:notes:114]
On April 19, 2017, XR Communications, LLC (“XR”) (d/b/a Vivato Technologies) filed a patent infringement lawsuit against the Company in the Central District of California. The operative Second Amended Complaint asserts infringement of certain U.S. Patents based on the Company’s manufacture, use, sale, offer for sale, and/or importation into the United States of certain access points and routers supporting multi-user, multiple-input, multiple-output technology. XR seeks unspecified damages, on-going royalties, pre- and post-judgment interest, and attorneys’ fees. The Court dismissed the case without prejudice on January 4, 2022 and on April 18, 2022, entered final judgment in favor of the Company. XR filed a notice of appeal on May 9, 2022 and the Company and other defendants filed a response brief on November 7, 2022.

[0000950170-23-015282:notes:115]
Orckit IP, LLC v. Extreme Networks, Inc., Extreme Networks Ireland Ltd., and Extreme Networks GmbH

[0000950170-23-015282:notes:116]
On February 1, 2018, Orckit IP, LLC (“Orckit”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. The lawsuit alleges direct and indirect infringement of the German portion of a patent (“EP ‘364”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that are equipped with the ExtremeXOS operating system. Orckit is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On January 28, 2020, the Court rendered a decision in the infringement case in favor of the Company. The matter is proceeding through the appellate process.

[0000950170-23-015282:notes:117]
On April 23, 2019, Orckit filed an extension of the patent infringement complaint against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany. With this extension, Orckit alleges infringement of the German portion of a second patent (“EP ‘077”) based on the offer, distribution, use, possession and/or importation into Germany of certain network switches that the Company no longer sells in Germany. Orckit is seeking injunctive relief, accounting and sales information, and a declaration of liability for damages as well as costs of the lawsuit. On October 13, 2020, the Court issued an infringement decision against the Company and granted Orckit the right to enforce the judgment against the Company, which Orckit has provided notification to the Company that it will enforce the judgment. In the rendering of account, Orckit was informed that the products at issue were in end of sale status prior to the filing of the EP ‘077 complaint. The Company has appealed the infringement decision, and the matter is proceeding through the appellate process.

[0000950170-23-015282:notes:118]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.

[0000950170-23-015282:notes:119]
SNMP Research, Inc. and SNMP Research International, Inc. v. Broadcom Inc., Brocade Communications Systems LLC, and Extreme Networks, Inc.

[0000950170-23-015282:notes:120]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.

[0000950170-23-015282:notes:121]
Mala Technologies Ltd. v. Extreme Networks GmbH, Extreme Networks Ireland Ops Ltd., and Extreme Networks, Inc.

[0000950170-23-015282:notes:122]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of

[0000950170-23-015282:notes:123]
a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal.

[0000950170-23-015282:notes:124]
The Company filed a nullity complaint against EP ‘498 with the German Federal Patent Court on September 24, 2021. This matter is still pending.

[0000950170-23-015282:notes:125]
Indemnification Obligations

[0000950170-23-015282:notes:126]
Subject to certain limitations, the Company may be obligated to indemnify its current and former directors, officers and employees. These obligations arise under the terms of its certificate of incorporation, its bylaws, applicable contracts, and applicable law. The obligation to indemnify, where applicable, generally means that the Company is required to pay or reimburse, and in certain circumstances the Company has paid or reimbursed, the individuals’ reasonable legal expenses and possible damages and other liabilities incurred in connection with certain legal matters. The Company also procures Directors and Officers liability insurance to help cover its defense and/or indemnification costs, although its ability to recover such costs through insurance is uncertain.  While it is not possible to estimate the maximum potential amount that could be owed under these governing documents and agreements due to the Company’s limited history with prior indemnification claims, indemnification (including defense) costs could, in the future, have a material adverse effect on the Company’s consolidated financial position, results of operations and cash flows.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-23-015282:notes:127]
10.
Stockholders’ Equity

[0000950170-23-015282:notes:128]
[same as prior period, unchanged from 0001564590-23-000867:notes:129]

[0000950170-23-015282:notes:129]
[same as prior period, unchanged from 0001564590-23-000867:notes:130]

[0000950170-23-015282:notes:130]
[same as prior period, unchanged from 0001564590-23-000867:notes:131]

[0000950170-23-015282:notes:131]
[same as prior period, unchanged from 0001564590-23-000867:notes:132]

[0000950170-23-015282:notes:132]
[same as prior period, unchanged from 0001564590-23-000867:notes:133]

[0000950170-23-015282:notes:133]
[same as prior period, unchanged from 0001564590-23-000867:notes:134]

[0000950170-23-015282:notes:134]
[same as prior period, unchanged from 0001564590-23-000867:notes:135]

[0000950170-23-015282:notes:135]
[same as prior period, unchanged from 0001564590-23-000867:notes:136]

[0000950170-23-015282:notes:136]
On May 18, 2022, the Company announced the Board had authorized management to repurchase up to $200.0 million shares of the Company’s common stock over a three-year period commencing July 1, 2022 (as amended, the “2022 Repurchase Program”). Initially, under the 2022 Repurchase program, a maximum of $25.0 million of shares was authorized to be repurchased in any quarter; however, on November 17, 2022, the Board increased the authorization to repurchase shares in any quarter from up to $25.0 million of shares per quarter to up to $50.0 million of shares per quarter. Purchases may be made from time to time in the open market or pursuant to a 10b5-1 plan.

[0000950170-23-015282:notes:137]
During the three months ended March 31, 2023, the Company repurchased a total of 1,350,568 shares of its common stock on the open market at a total cost of $25.0 million with an average price of $18.51 per share. During the nine months ended March 31, 2023, the Company repurchased a total of 3,928,743 shares of its common stock on the open market at a total cost of $74.8 million with an average price of $19.04 per share. During the nine months ended March 31, 2022, the Company repurchased a total of 1,829,333 shares of its common stock on the open market at total cost of $25.0 million with an average price of $13.65 per share pursuant to a share repurchase authorization that was replaced by the 2022 Repurchase Program. As of March 31, 2023, approximately $125.2 million remains available for share repurchases under the 2022 Repurchase Program.

[0000950170-23-015282:notes:138]
As a provision of the Inflation Reduction Act enacted in the U.S., the Company is subject to an excise tax on corporate stock repurchases, which is assessed as one percent of the fair market value of net corporate stock repurchases after December 31, 2022. The Company expects that the impact of the excise tax on net corporate stock repurchases will not be material for fiscal 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-015282:notes:139]
11.
Employee Benefit Plans

[0000950170-23-015282:notes:140]
[same as prior period, unchanged from 0001564590-23-000867:notes:140]

[0000950170-23-015282:notes:141]
[same as prior period, unchanged from 0001564590-23-000867:notes:141]

[0000950170-23-015282:notes:142]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| 2013 Equity Incentive Plan shares available for grant |  |  | 10,701 |  |  |  | 11,430 |  |
| Employee stock options and awards outstanding |  |  | 9,995 |  |  |  | 7,616 |  |
| 2014 Employee Stock Purchase Plan |  |  | 8,467 |  |  |  | 9,961 |  |
| Total shares reserved for issuance |  |  | 29,163 |  |  |  | 29,007 |  |

[0000950170-23-015282:notes:143]
[same as prior period, unchanged from 0001564590-23-000867:notes:143]

[0000950170-23-015282:notes:144]
[same as prior period, unchanged from 0001564590-23-000867:notes:144]

[0000950170-23-015282:notes:145]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Cost of product revenues |  | $ | 492 |  |  | $ | 291 |  |  | $ | 1,365 |  |  | $ | 904 |  |
| Cost of service and subscription revenues |  |  | 930 |  |  |  | 343 |  |  |  | 2,568 |  |  |  | 1,056 |  |
| Research and development |  |  | 3,883 |  |  |  | 2,446 |  |  |  | 10,935 |  |  |  | 7,568 |  |
| Sales and marketing |  |  | 5,777 |  |  |  | 3,832 |  |  |  | 16,326 |  |  |  | 11,267 |  |
| General and administrative |  |  | 4,294 |  |  |  | 3,941 |  |  |  | 15,367 |  |  |  | 11,835 |  |
| Total share-based compensation expense |  | $ | 15,376 |  |  | $ | 10,853 |  |  | $ | 46,561 |  |  | $ | 32,630 |  |

[0000950170-23-015282:notes:146]
[same as prior period, unchanged from 0001564590-23-000867:notes:146]

[0000950170-23-015282:notes:147]
The following table summarizes stock option activity for the nine months ended March 31, 2023 (in thousands, except per share and contractual term):

[0000950170-23-015282:notes:148]
|  |  | Number of Shares |  |  | Weighted-Average Exercise Price Per Share |  |  | Weighted-Average Remaining Contractual Term (years) |  |  | Aggregate Intrinsic Value |  |
| Options outstanding at June 30, 2022 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 3.70 |  |  | $ | 2,801 |  |
| Granted |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Exercised |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Canceled |  |  | — |  |  |  | — |  |  |  |  |  |  |  |
| Options outstanding at March 31, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.95 |  |  | $ | 14,909 |  |
| Vested and expected to vest at March 31, 2023 |  |  | 1,187 |  |  | $ | 6.56 |  |  |  | 2.95 |  |  | $ | 14,909 |  |
| Exercisable at March 31, 2023 |  |  | 1,108 |  |  | $ | 6.55 |  |  |  | 2.91 |  |  | $ | 13,921 |  |

[0000950170-23-015282:notes:149]
The fair value of each stock option grant under the 2013 Plan is estimated on the date of grant using the Black-Scholes-Merton option valuation model. The expected term of options granted is derived from historical data on employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based upon the estimated life of the option and the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s stock. There were no stock

[0000950170-23-015282:notes:150]
options granted during the three and nine months ended March 31, 2023 and 2022. There were no stock options exercised during the three and nine months ended March 31, 2023.

[0000950170-23-015282:notes:151]
[same as prior period, unchanged from 0001564590-23-000867:notes:150]

[0000950170-23-015282:notes:152]
[same as prior period, unchanged from 0001564590-23-000867:notes:151]

[0000950170-23-015282:notes:153]
The following table summarizes stock award activity for the nine months ended March 31, 2023 (in thousands, except grant date fair value):

[0000950170-23-015282:notes:154]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |  | Aggregate Fair Value |  |
| Non-vested stock awards outstanding at June 30, 2022 |  |  | 6,429 |  |  | $ | 9.57 |  |  |  |  |
| Granted |  |  | 6,400 |  |  |  | 14.65 |  |  |  |  |
| Released |  |  | (3,285 | ) |  |  | 8.42 |  |  |  |  |
| Canceled |  |  | (736 | ) |  |  | 12.70 |  |  |  |  |
| Non-vested stock awards outstanding at March 31, 2023 |  |  | 8,808 |  |  | $ | 13.43 |  |  | $ | 168,413 |  |
| Stock awards expected to vest at March 31, 2023 |  |  | 8,808 |  |  | $ | 13.43 |  |  | $ | 168,413 |  |

[0000950170-23-015282:notes:155]
The RSUs granted under the 2013 Plan vest over a period of time, generally one to three years, and are subject to participant's continued service to the Company. The stock awards granted during the nine months ended March 31, 2023 included 1.4 million RSUs including the market condition awards discussed below to named executive officers and directors.

[0000950170-23-015282:notes:156]
[same as prior period, unchanged from 0001564590-23-000867:notes:155]

[0000950170-23-015282:notes:157]
During the nine months ended March 31, 2023 and 2022, the Compensation Committee of the Board granted 1.0 million and 0.7 million RSUs, respectively, with vesting based on market conditions (“MSU”) to certain of the Company’s executive officers. These MSUs vest based on the Company’s total shareholder return (“TSR”) relative to the TSR of the Russell 2000 Index (“Index”). The MSU award represents the right to receive a target number of shares of common stock of up to 150% of the original grant, as indicated in the table below. The MSUs vest based on the Company’s TSR relative to the TSR of the Index over performance periods of three years from the grant date, subject to the grantees’ continued service through the certification of performance.

[0000950170-23-015282:notes:158]
| Level | Relative TSR | Shares Vested |
| Below Threshold | TSR is less than the Index by more than 37.5 percentage points | 0% |
| Threshold | TSR is less than the Index by 37.5 percentage points | 25% |
| Target | TSR equals the Index | 100% |
| Maximum | TSR is greater than the Index by 25 percentage points or more | 150% |

[0000950170-23-015282:notes:159]
[same as prior period, unchanged from 0001564590-23-000867:notes:158]

[0000950170-23-015282:notes:160]
The grant date fair value of each MSU was determined using the Monte Carlo simulation model. The weighted-average grant-date fair value of the MSUs granted during the nine months ended March 31, 2023 was $16.57 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 67%, risk-free interest rate of 3.12%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices. The Company recognizes the expense related to these MSUs on a graded-vesting method over the estimated term.

[0000950170-23-015282:notes:161]
The weighted-average grant-date fair value of the MSUs granted during the nine months ended March 31, 2022 was $12.69 per share. The assumptions used in the Monte Carlo simulation included the expected volatility of 66%, risk-free rate of 0.44%, no expected dividend yield, expected term of three years and possible future stock prices over the performance period based on the historical stock and market prices.

[0000950170-23-015282:notes:162]
The fair value of each share purchase option under the ESPP is estimated on the date of grant using the Black-Scholes-Merton option valuation model with the weighted average assumptions noted in the following table. The expected term of the ESPP represents the term of the offering period of each option. The risk-free interest rate is based upon the estimated life and on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility on the Company’s common stock.

[0000950170-23-015282:notes:163]
There were 0.8 million and 1.0 million shares issued under the ESPP during the three months ended March 31, 2023 and 2022, respectively. There were 1.5 million and 2.0 million shares issued under the ESPP during the nine months ended March 31, 2023 and 2022, respectively. The following assumptions were used to determine the grant-date fair values of the ESPP shares during the following periods:

[0000950170-23-015282:notes:164]
|  |  | Employee Stock Purchase Plan |  |  | Employee Stock Purchase Plan |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Risk-free interest rate |  |  | 4.98 | % |  |  | 0.67 | % |  |  | 3.84 | % |  |  | 0.33 | % |
| Volatility |  |  | 49 | % |  |  | 45 | % |  |  | 55 | % |  |  | 49 | % |
| Dividend yield |  |  | — | % |  |  | — | % |  |  | — | % |  |  | — | % |

[0000950170-23-015282:notes:165]
The weighted-average grant-date fair value of shares under the ESPP during the three months ended March 31, 2023 and 2022 was $5.63 and $3.49 per share, respectively. The weighted-average grant-date fair value of shares under the ESPP during the nine months ended March 31, 2023 and 2022 was $4.87 and $3.32 per share, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-015282:notes:166]
12.
Information about Segments and Geographic Areas

[0000950170-23-015282:notes:167]
[same as prior period, unchanged from 0001564590-23-000867:notes:166]

[0000950170-23-015282:notes:168]
[same as prior period, unchanged from 0001564590-23-000867:notes:167]

[0000950170-23-015282:notes:169]
[same as prior period, unchanged from 0001564590-23-000867:notes:168]

[0000950170-23-015282:notes:170]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Americas |  | $ | 123,937 |  |  | $ | 130,715 |  |
| EMEA |  |  | 36,064 |  |  |  | 36,792 |  |
| APAC |  |  | 11,658 |  |  |  | 11,770 |  |
| Total long-lived assets |  | $ | 171,659 |  |  | $ | 179,277 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-015282:notes:171]
13.
Derivatives and Hedging

[0000950170-23-015282:notes:172]
[same as prior period, unchanged from 0001564590-23-000867:notes:171]

[0000950170-23-015282:notes:173]
[same as prior period, unchanged from 0001564590-23-000867:notes:172]

[0000950170-23-015282:notes:174]
At the inception date of the derivative contract, the Company performs an assessment of these contracts and has designated these contracts as cash flow hedges. Interest rate swaps designated as cash flow hedges involve the receipt of variable-rate amounts from a counterparty in exchange for the Company making fixed-rate payments over the life of the agreement without exchange of the underlying notional amount. The Company also formally assesses, both at the hedge’s inception and on an ongoing basis, by performing qualitative and quantitative assessment, whether the derivatives that are used in hedging transactions are highly effective in offsetting changes in cash flow of hedged items. Changes in the fair value of a derivative that is qualified, designated and highly effective as a cash flow hedge are recorded in other comprehensive income (loss). When it is determined that a derivative is not highly effective as a hedge or that it has ceased to be a highly effective hedge, the Company discontinues hedge accounting prospectively. In accordance with ASC 815 “Derivatives and Hedging,” the Company may prospectively discontinue the hedge accounting for an existing hedge if the applicable criteria are no longer met, the derivative instrument expires, is sold, terminated or exercised or if the Company removes the designation

[0000950170-23-015282:notes:175]
of the respective cash flow hedge. In those circumstances, the net gain or loss remains in accumulated other comprehensive income (loss) and is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings, unless the forecasted transaction is no longer probable in which case the net gain or loss is reclassified into earnings immediately.

[0000950170-23-015282:notes:176]
During fiscal 2020, the Company entered into multiple interest rate swap contracts, designated as cash flow hedges, to hedge the variability of cash flows in interest payments associated with the Company’s various tranches of floating-rate debt. As of March 31, 2023 and 2022, the total notional amount of these interest rate swaps were $75.0 million and $200.0 million, respectively, and had maturity dates through April 2023. As of March 31, 2023 and 2022, these contracts had unrealized gains of $0.1 million and $0.8 million, respectively, and are recorded in “Accumulated other comprehensive loss” with the associated asset in “Prepaid expenses and other current assets”, in the condensed consolidated balance sheets. Cash flows associated with periodic settlements of interest rate swaps are classified as operating activities in the condensed consolidated statement of cash flows. Realized gains and losses are recognized as they accrue in interest expense. Amounts reported in accumulated other comprehensive loss related to these cash flow hedges are reclassified to interest expense over the life of the swap contracts. The Company estimates that $0.1 million will be reclassified to interest income over the next twelve months. The classification and fair value of these cash flow hedges are discussed in Note 6, Fair Value Measurements.

[0000950170-23-015282:notes:177]
[same as prior period, unchanged from 0001564590-23-000867:notes:175]

[0000950170-23-015282:notes:178]
The Company uses derivative financial instruments to manage exposures to foreign currency that may or may not be designated as hedging instruments. The Company’s objective for holding derivatives is to use the most effective methods to minimize the impact of these exposures. The Company does not enter into derivatives for speculative or trading purposes. The Company enters into foreign exchange forward contracts primarily to mitigate the effect of gains and losses generated by foreign currency transactions related to certain operating expenses and re-measurement of certain assets and liabilities denominated in foreign currencies.

[0000950170-23-015282:notes:179]
For foreign exchange forward contracts not designated as hedging instruments, the fair value of the Company’s derivatives in a gain position are recorded in “Prepaid expenses and other current assets” and derivatives in a loss position are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. Changes in the fair value of derivatives are recorded in “Other income, net” in the accompanying condensed consolidated statements of operations. As of March 31, 2023 and 2022, foreign exchange forward contracts not designated as hedging instruments had a total notional principal amounts of $11.2 million and $20.2 million, respectively. These contracts have maturities of 60 days or less. The net gains and losses recorded in the condensed consolidated statement of operations from these contracts during the three and nine months ended March 31, 2023 were net gain of $0.1 million and net loss of $0.3 million, respectively, and during the three and nine months ended March 31, 2022 there were net losses of $0.1 million and $0.4 million, respectively. Changes in the fair value of these foreign exchange forward contracts are offset largely by remeasurement of the underlying assets and liabilities.

[0000950170-23-015282:notes:180]
For foreign exchange forward contracts designated as hedging instruments. These contracts have maturities of less than twelve months, and unrealized gains and losses arising from these contracts are recorded as a component of “accumulated other comprehensive loss” on the condensed consolidated balance sheets. The hedging gains and losses in “accumulated other comprehensive loss” are subsequently reclassified to expenses, as applicable, in the condensed consolidated statements of operations in the same period in which the underlying transactions affect the Company’s earnings. As of March 31, 2023 and 2022, foreign exchange forward contracts designated as hedging instruments had the notional amount of $5.4 million and $0.2 million, respectively. As of  March 31, 2023 and 2022, these contracts had unrealized gains of less than $0.1 million each.  
For the three months ended March 31, 2023 and 2022, the Company recognized total foreign currency loss of $0.3 million and gains of $0.3 million, respectively, and for the nine months ended March 31, 2023 and 2022, the Company recognized total foreign currency gains of $0.5 million and $0.6 million, respectively, related to the change in fair value of foreign currency denominated assets and liabilities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-015282:notes:181]
14.
Restructuring and Related Charges

[0000950170-23-015282:notes:182]
The Company recorded $1.4 million and $2.3 million of restructuring and related charges during the three and nine months ended March 31, 2023, respectively, which primarily included additional facilities charges related to previously impaired facilities and a $0.8 million related to the fiscal 2023 restructuring plan as noted below.

[0000950170-23-015282:notes:183]
During the third quarter of fiscal 2023, the Company initiated a restructuring plan to transform our business infrastructure and reduce our facilities footprint and the facilities related charges (the “2023 Plan”). As part of this project the Company will move engineering labs from its San Jose, California location to its Salem, New Hampshire location. This move is expected to help reduce the cost of operating our labs. The Company expects that the project will take about 18 to 24 months for completion and expects to incur charges of approximately $10.0 million throughout this period primarily for asset disposals, contractor costs, severance, relocation and other non-recurring fees.

[0000950170-23-015282:notes:184]
The Company recorded $0.4 million and $1.0 million of restructuring and related charges during the three and nine months ended March 31, 2022 which primarily included additional facility related expenses related to previously impaired facilities. The Company had minimal activity related to the 2020 Plan during the three months ended March 31, 2022. Severance and benefit restructuring charges consisted primarily of employee severance and benefit expenses incurred under the reduction-in-force action initiated in the third quarter of fiscal 2020 (the “2020 Plan”) to reduce operating costs and enhance financial flexibility as a result of disruptions caused by the COVID-19 global pandemic. With the reduction and realignment of the headcount under the 2020 Plan, the Company relocated certain of its lab test equipment to third-party consulting companies. The Company incurred $9.6 million of charges under the 2020 Plan and completed the 2020 Plan in the fourth quarter of fiscal 2022. As of June 30, 2022, the Company has no restructuring liabilities related to the 2020 Plan in the accompanying condensed consolidated balance sheets.   
Restructuring liabilities are recorded in “Other accrued liabilities” in the accompanying condensed consolidated balance sheets. As of March 31, 2023 the restructuring liability was $0.4 million related to the 2023 Plan and as of March 31, 2022, the restructuring liability was less than $0.1 million.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-015282:notes:185]
15.
Income Taxes

[0000950170-23-015282:notes:186]
For the three months ended March 31, 2023 and 2022, the Company recorded an income tax provision of $3.9 million and $1.9 million, respectively. For the nine months ended March 31, 2023 and 2022, the Company recorded an income tax provision of $8.3 million and $5.7 million, respectively.

[0000950170-23-015282:notes:187]
The income tax provisions for the three and nine months ended March 31, 2023 and 2022, consisted of (1) taxes on the income of the Company’s foreign subsidiaries, (2) state taxes in jurisdictions where the Company has no remaining state net operating losses (“NOLs”), (3) foreign withholding taxes, and (4) tax expense associated with the establishment of a U.S. deferred tax liability for amortizable goodwill resulting from the acquisition of Enterasys Networks, Inc., the wireless local area network business from Zebra Technologies Corporation, the Campus Fabric Business from Avaya and the Data Center Business from Brocade. The interim income tax provisions for the three and nine months ended March 31, 2023 and 2022 were calculated using the discrete effective tax rate method as allowed by ASC 740-270-30-18, Income Taxes – Interim Reporting. The discrete method is applied when the application of the estimated annual effective tax rate is impractical because it is not possible to reliably estimate the annual effective tax rate. The discrete method treats the year-to-date period as if it was the annual period and determines the income tax expense or benefit on that basis.  The Company believes that, at this time, the use of this discrete method is more appropriate than the annual effective tax rate method as (i) the estimated annual effective tax rate method is not reliable due to the high degree of uncertainty in estimating annual pretax earnings on a jurisdictional basis and (ii) the Company’s ongoing assessment that the recoverability of certain U.S. and Irish deferred tax assets is not more likely than not.

[0000950170-23-015282:notes:188]
The Company has provided a full valuation allowance against all of its U.S. federal and state deferred tax assets as well as a portion of the deferred tax assets in Ireland. Significant judgment is required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, the Company considers all available positive and negative evidence to determine whether it is “more likely than not” that deferred tax assets are recoverable including past operating results, estimates of future taxable income, changes to enacted tax laws, and the feasibility of tax planning strategies; such assessment is required on a jurisdiction-by-jurisdiction basis. The Company’s inconsistent earnings in recent periods, including a cumulative loss over the last three years, coupled with its difficulty in forecasting future revenue trends by jurisdiction and the cyclical nature of its business represent sufficient negative evidence to require full valuation allowances against its U.S. federal and state net deferred tax assets as well as a portion of the deferred tax assets in Ireland.  These valuation allowances will be evaluated periodically and can be reversed partially or in whole if business results and the economic environment have sufficiently improved to support realization of some or all of the Company's deferred tax assets. In the event the Company changes its determination as to the amount of deferred tax assets that can be realized, it will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000950170-23-015282:notes:189]
On September 14, 2021, the Company completed its acquisition of Ipanema. This acquisition has been treated as a non-taxable stock acquisition and, therefore, Extreme will have carryover tax basis in the assets and liabilities acquired. A deferred tax liability has been established for the non-deductible amortization of the associated intangibles under U.S. GAAP.

[0000950170-23-015282:notes:190]
The Company had $18.3 million of unrecognized tax benefits as of March 31, 2023. If fully recognized in the future, $0.3 million would impact the effective tax rate and $18.0 million would result in adjustments to deferred tax assets and corresponding adjustments to the valuation allowance with no impact to the effective tax rate. The Company does not anticipate any events to occur during the next twelve months that would materially reduce the unrealized tax benefit as currently stated in the Company’s condensed consolidated balance sheets.

[0000950170-23-015282:notes:191]
[same as prior period, unchanged from 0001564590-23-000867:notes:192]

[0000950170-23-015282:notes:192]
In general, the Company’s U.S. federal income tax returns are subject to examination by tax authorities for fiscal years 2001 forward due to NOLs and the Company’s state income tax returns are subject to examination for fiscal years 2000 and forward due to NOLs. The Company is not currently under audit for income tax purposes in any material jurisdictions.


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-015282:notes:193]
16.
Net Income Per Share

[0000950170-23-015282:notes:194]
[same as prior period, unchanged from 0001564590-23-000867:notes:195]

[0000950170-23-015282:notes:195]
[same as prior period, unchanged from 0001564590-23-000867:notes:196]

[0000950170-23-015282:notes:196]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Net income |  | $ | 22,131 |  |  | $ | 12,824 |  |  | $ | 52,647 |  |  | $ | 38,861 |  |
| Weighted-average shares used in per share calculation – basic |  |  | 128,816 |  |  |  | 129,913 |  |  |  | 129,864 |  |  |  | 129,321 |  |
| Options to purchase common stock |  |  | 748 |  |  |  | 535 |  |  |  | 678 |  |  |  | 637 |  |
| Restricted stock units |  |  | 3,461 |  |  |  | 2,967 |  |  |  | 3,174 |  |  |  | 3,821 |  |
| Weighted-average shares used in per share calculation – diluted |  |  | 133,025 |  |  |  | 133,415 |  |  |  | 133,716 |  |  |  | 133,779 |  |
| Net income per share – basic and diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income per share – basic |  | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.41 |  |  | $ | 0.30 |  |
| Net income per share – diluted |  | $ | 0.17 |  |  | $ | 0.10 |  |  | $ | 0.39 |  |  | $ | 0.29 |  |

[0000950170-23-015282:notes:197]
[same as prior period, unchanged from 0001564590-23-000867:notes:198]

[0000950170-23-015282:notes:198]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |  | March 31,2023 |  |  | March 31,2022 |  |
| Restricted stock units |  |  | 143 |  |  |  | 118 |  |  |  | 116 |  |  |  | 57 |  |
| Employee Stock Purchase Plan shares |  |  | 238 |  |  |  | 386 |  |  |  | 78 |  |  |  | 127 |  |
| Total shares excluded |  |  | 381 |  |  |  | 504 |  |  |  | 194 |  |  |  | 184 |  |
