# EXTR note change history — 0001564590-23-000867 → 0000950170-23-015282


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:1]
9.
Commitments and Contingencies
  (was, 2023-01-27, similarity 0.9118):
[0001564590-23-000867:note_history:1]
| 9. | Commitments and Contingencies |

- changed (2023-04-27):
[0000950170-23-015282:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of March 31, 2023, the Company had commitments to purchase $56.8 million of inventory.
  (was, 2023-01-27, similarity 0.9893):
[0001564590-23-000867:note_history:2]
The Company currently has arrangements with contract manufacturers and suppliers for the manufacture of its products. Those arrangements allow the contract manufacturers to procure long lead-time component inventory based upon a rolling production forecast provided by the Company. The Company is obligated to purchase long lead-time component inventory that its contract manufacturer procures in accordance with the forecast, unless the Company gives notice of order cancellation outside of applicable component lead-times. As of December 31, 2022, the Company had commitments to purchase $57.1 million of inventory.

- added (2023-04-27):
[0000950170-23-015282:note_history:3]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The

- changed (2023-04-27):
[0000950170-23-015282:note_history:4]
Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.
  (was, 2023-01-27, similarity 0.9136):
[0001564590-23-000867:note_history:4]
In accordance with applicable accounting guidance, the Company records accruals for certain of its outstanding legal proceedings, investigations or claims when it is probable that a liability will be incurred, and the amount of loss can be reasonably estimated. The Company evaluates, at least on a quarterly basis, developments in legal proceedings, investigations or claims that could affect the amount of any accrual, as well as any developments that would result in a loss contingency to become both probable and reasonably estimable. When a loss contingency is not both probable and reasonably estimable, the Company does not record a loss accrual. However, if the loss (or an additional loss in excess of any prior accrual) is at least reasonably possible and material, then the Company would disclose an estimate of the possible loss or range of loss, if such estimate can be made, or disclose that an estimate cannot be made. The assessment whether a loss is probable or a reasonable possibility, and whether the loss or a range of loss is estimable, involves a series of complex judgments about future events. Even if a loss is reasonably possible, the Company may not be able to estimate a range of possible loss, particularly where (i) the damages sought are substantial or indeterminate, (ii) the proceedings are in the early stages, or (iii) the matters involve novel or unsettled legal theories or a large number of parties. In such cases, there is considerable uncertainty regarding the ultimate resolution of such matters, including the amount of any possible loss, fine or penalty.  However, an adverse resolution of one or more of such matters could have a material adverse effect on the Company's results of operations in a particular quarter or fiscal year.

- changed (2023-04-27):
[0000950170-23-015282:note_history:5]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company and Orckit have filed appeals.
  (was, 2023-01-27, similarity 0.9459):
[0001564590-23-000867:note_history:5]
The Company filed a nullity action related to the EP ‘364 patent on May 3, 2018, and one related to the EP ‘077 patent on October 31, 2019, both in the Federal Patent Court in Munich. The Federal Patent Court in Munich found the EP ‘364 patent to be valid and the Company has filed an appeal. On October 25, 2022, the Federal Patent Court in Munich issued an opinion partially invalidating the EP ‘077 patent and the Company has filed an appeal.

- changed (2023-04-27):
[0000950170-23-015282:note_history:6]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. On March 2, 2023, SNMP filed an amended complaint adding claims against Extreme on additional products for copyright infringement, breach of contract, and fraud. On March 16, 2023, the Company filed a motion to dismiss, challenging multiple claims from the amended complaint. On March 20, 2023, the Company filed a motion to refer questions to the US Copyright Office on the invalidity of SNMP’s copyrights. The trial date has been set for October 2024.
  (was, 2023-01-27, similarity 0.6434):
[0001564590-23-000867:note_history:6]
On October 26, 2020, SNMP Research, Inc. and SNMP Research International, Inc. (collectively, “SNMP”) filed a lawsuit against the Company in the Eastern District of Tennessee for copyright infringement, alleging that the Company was not properly licensed to use its software.  SNMP is seeking actual damages and profits attributed to the infringement, as well as equitable relief. The Company filed a motion to transfer the case to the Northern District of California. The motion to dismiss was denied in part and denied without prejudice in part. The Company also filed, and was granted, a motion to compel mediation. The parties conducted a  mediation from January 19 to January 26, 2023. The trial date set for February 2023 has been rescheduled to January 2024.

- added (2023-04-27):
[0000950170-23-015282:note_history:7]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of

- changed (2023-04-27):
[0000950170-23-015282:note_history:8]
a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal.
  (was, 2023-01-27, similarity 0.768):
[0001564590-23-000867:note_history:8]
On April 15, 2021, Mala Technologies Ltd. (“Mala”) filed a patent infringement lawsuit against the Company and its Irish and German subsidiaries in the District Court in Dusseldorf, Germany.  The lawsuit alleges indirect infringement of the German portion of a patent (“EP ‘498”) based on the offer and sale in Germany of certain network switches equipped with the ExtremeXOS operating system.  Mala is seeking injunctive relief, accounting, and an unspecified declaration of liability for damages and costs of the lawsuit. On December 20, 2022, the trial court ruled that the Company did not infringe the EP ‘498 patent and dismissed Mala’s complaint entirely. Mala has filed an appeal.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:9]
1.
Description of Business and Basis of Presentation
  (was, 2023-01-27, similarity 0.9444):
[0001564590-23-000867:note_history:9]
| 1. | Description of Business and Basis of Presentation |

- changed (2023-04-27):
[0000950170-23-015282:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at March 31, 2023. The results of operations for the three and nine months ended March 31, 2023 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.
  (was, 2023-01-27, similarity 0.9404):
[0001564590-23-000867:note_history:10]
The unaudited condensed consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments that, in the opinion of management, are necessary for a fair presentation of the results of operations and cash flows for the interim periods presented and the financial condition of Extreme at December 31, 2022. The results of operations for the three and six months ended December 31, 2022 are not necessarily indicative of the results that may be expected for fiscal 2023 or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:11]
2.
Summary of Significant Accounting Policies
  (was, 2023-01-27, similarity 0.9362):
[0001564590-23-000867:note_history:11]
| 2. | Summary of Significant Accounting Policies |

- changed (2023-04-27):
[0000950170-23-015282:note_history:12]
Recently Adopted Accounting Pronouncements
  (was, 2023-01-27, similarity 0.8077):
[0001564590-23-000867:note_history:12]
Recently Adopted and Recently Issued Accounting Pronouncements

- changed (2023-04-27):
[0000950170-23-015282:note_history:13]
In December 2022, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which extends the period of time entities can utilize the reference rate reform relief guidance under ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting from December 31, 2022 to December 31, 2024. Upon issuance of ASU 2020-04, the Company elected to apply certain of the optional expedients for contract modifications to its financial instruments impacted by the London Interbank Offered Rate (“LIBOR”) discontinuance. The Company expects to continue to elect various optional expedients for contract modifications to the Company’s financial instruments affected by the reference rate reform through the effective date of December 31, 2024, as extended by ASU 2022-06. The application of this guidance did not have any impact on our consolidated financial statements.
  (was, 2023-01-27, similarity 0.8513):
[0001564590-23-000867:note_history:13]
In December 2022, the Financial Accounting Standards Board (“FASB”) issued Accounting Standard Update (“ASU”) 2022-06, Reference Rate Reform (Topic 848): Deferral of the Sunset Date of Topic 848, which extends the period of time entities can utilize the reference rate reform relief guidance under ASU 2020-04, Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting from December 31, 2022 to December 31, 2024. Upon issuance of ASU 2020-04, the Company elected to apply certain of the optional expedients for contract modifications to its financial instruments impacted by the London Interbank Offered Rate (“LIBOR”) discontinuance. The Company expects to continue to elect various optional expedients for contract

- removed (2023-04-27):
[0001564590-23-000867:note_history:14]
modifications to the Company’s financial instruments affected by the reference rate reform through the effective date of December 31, 2024, as extended by ASU 2022-06. The application of this guidance did not have any impact on our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:15]
8.
Debt
  (was, 2023-01-27, similarity 0.6667):
[0001564590-23-000867:note_history:15]
| 8. | Debt |

- changed (2023-04-27):
[0000950170-23-015282:note_history:16]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,128 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,872 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 199,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (812 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 198,188 |  |  |  | 270,570 |  |
| Total debt |  | $ | 234,060 |  |  | $ | 303,919 |  |
  (was, 2023-01-27, similarity 0.9761):
[0001564590-23-000867:note_history:16]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,819 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 224,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,331 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 222,669 |  |  |  | 270,570 |  |
| Total debt |  | $ | 258,488 |  |  | $ | 303,919 |  |

- changed (2023-04-27):
[0000950170-23-015282:note_history:17]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly
  (was, 2023-01-27, similarity 0.7054):
[0001564590-23-000867:note_history:17]
At the Company’s election, the initial term loan under the 2019 Credit Agreement may be made as either base rate loans or Eurodollar loans. The applicable margin for base rate loans ranges from 0.25% to 2.50% per annum and the applicable margin for Eurodollar loans ranges from 1.25% to 3.50%, in each case based on Extreme’s consolidated leverage ratio. All Eurodollar loans are subject to a Base Rate of 0.00%. In addition, the Company is required to pay a commitment fee of between 0.25% and 0.40% quarterly (currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

- added (2023-04-27):
[0000950170-23-015282:note_history:18]
(currently 0.25%) on the unused portion of the 2019 Revolving Facility, also based on the Company’s consolidated leverage ratio. Principal installments are payable on the new term loan in varying percentages quarterly starting December 31, 2019 and to the extent not previously paid, all outstanding balances are to be paid at maturity. The 2019 Credit Agreement is secured by substantially all of the Company’s assets.

- changed (2023-04-27):
[0000950170-23-015282:note_history:19]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three and nine months ended March 31, 2023, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.
  (was, 2023-01-27, similarity 0.8613):
[0001564590-23-000867:note_history:19]
The Second Amendment provided for the Company to end the covenant Suspension Period early and revert to the covenants and interest rates per the original terms of the 2019 Credit Agreement dated August 9, 2019 by filing a Suspension Period Early Termination Notice and Covenant Certificate demonstrating compliance. For the twelve-month period ended March 31, 2021, the Company’s financial performance was in compliance with the original covenants defined in the 2019 Credit Agreement and, as such, the Company filed a Suspension Early Termination Notice and Covenant Certificate with the administration agent subsequent to filing the Company’s Quarterly Report on Form 10-Q for the period ended March 31, 2021. Returning to compliance, the original terms and

- changed (2023-04-27):
[0000950170-23-015282:note_history:20]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million each for the three months ended March 31, 2023 and 2022 and totaled $2.2 million and $2.3 million for the nine months ended March 31, 2023 and 2022, respectively. The interest rate as of March 31, 2023 was 5.97% and as of March 31, 2022 was 2.07%.
  (was, 2023-01-27, similarity 0.7369):
[0001564590-23-000867:note_history:20]
Financing costs incurred in connection with obtaining long-term financing are deferred and amortized over the term of the related indebtedness or credit agreement. Amortization of deferred financing costs included in “Interest expense” in the accompanying condensed consolidated statements of operations were $0.7 million for each of the three months ended December 31, 2022 and 2021 and totaled $1.5 million for each of the six months ended December 31, 2022 and 2021. The interest rate as of December 31, 2022 was 5.5% and as of December 31, 2021 was 1.86%.

- changed (2023-04-27):
[0000950170-23-015282:note_history:21]
As of March 31, 2023, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance. The Company had $60.2 million of availability under the 2019 Revolving Facility as of March 31, 2023. During the nine months ended March 31, 2023 and 2022, the Company made an additional payment of $45.5 million and $12.0 million, respectively, against its term loan facility, respectively.
  (was, 2023-01-27, similarity 0.8016):
[0001564590-23-000867:note_history:21]
As of December 31, 2022, the Company did not have any outstanding balance against its 2019 Revolving Facility’s outstanding balance. The Company had $60.2 million of availability under the 2019 Revolving Facility as of December 31, 2022. During the six months ended December 31, 2022 and 2021, the Company made an additional payment of $30.0 million and $12.0 million against its term loan facility, respectively.

- changed (2023-04-27):
[0000950170-23-015282:note_history:22]
The Company had $14.8 million of outstanding letters of credit as of March 31, 2023.
  (was, 2023-01-27, similarity 0.9412):
[0001564590-23-000867:note_history:22]
The Company had $14.8 million of outstanding letters of credit as of December 31, 2022.

- removed (2023-04-27):
[0001564590-23-000867:note_history:23]
financial covenants under the 2019 Credit Agreement dated August 9, 2019 resumed in effect. During the three and six months ended December 31, 2022, the Company was in compliance with all the terms and financial covenants under the 2019 Credit Agreement.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:24]
|  |  | March 31,2023 |  |  | June 30,2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,128 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,872 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |
| Term Loan |  | $ | 199,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (812 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 198,188 |  |  |  | 270,570 |  |
| Total debt |  | $ | 234,060 |  |  | $ | 303,919 |  |
  (was, 2023-01-27, similarity 0.9761):
[0001564590-23-000867:note_history:24]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Current portion of long-term debt: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 38,000 |  |  | $ | 35,625 |  |
| Less: unamortized debt issuance costs |  |  | (2,181 | ) |  |  | (2,276 | ) |
| Current portion of long-term debt |  | $ | 35,819 |  |  | $ | 33,349 |  |
| Long-term debt, less current portion: |  |  |  |  |  |  |  |  |
| Term Loan |  | $ | 224,000 |  |  | $ | 273,000 |  |
| Less: unamortized debt issuance costs |  |  | (1,331 | ) |  |  | (2,430 | ) |
| Total long-term debt, less current portion |  |  | 222,669 |  |  |  | 270,570 |  |
| Total debt |  | $ | 258,488 |  |  | $ | 303,919 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:25]
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |
| Other |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |
| Total Americas |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |
| EMEA |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |
| APAC |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |
| Total net revenues |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |
  (was, 2023-01-27, similarity 0.9564):
[0001564590-23-000867:note_history:25]
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |
| Other |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |
| Total Americas |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |
| EMEA |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |
| APAC |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |
| Total net revenues |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |

- changed (2023-04-27):
[0000950170-23-015282:note_history:26]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |
| Other |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |
| Total Americas |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |
| EMEA |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |
| APAC |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |
| Total net revenues |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |
  (was, 2023-01-27, similarity 0.9134):
[0001564590-23-000867:note_history:26]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |
| Other |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |
| Total Americas |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |
| EMEA |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |
| APAC |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |
| Total net revenues |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:27]
3.
Revenues
  (was, 2023-01-27, similarity 0.7143):
[0001564590-23-000867:note_history:27]
| 3. | Revenues |  |

- changed (2023-04-27):
[0000950170-23-015282:note_history:28]
On March 31, 2023, the Company had $464.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 20% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 44% in fiscal 2024 and 36% of the balance thereafter.
  (was, 2023-01-27, similarity 0.967):
[0001564590-23-000867:note_history:28]
On December 31, 2022, the Company had $445.6 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 36% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 34% in fiscal 2024 and 30% of the balance thereafter.

- changed (2023-04-27):
[0000950170-23-015282:note_history:29]
Revenue recognized for the three months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $81.0 million and $77.3 million, respectively. Revenue recognized for the nine months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $193.7 million and $176.1 million, respectively.
  (was, 2023-01-27, similarity 0.9194):
[0001564590-23-000867:note_history:29]
Revenue recognized for the three months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $83.9 million and $81.9 million, respectively. Revenue recognized for the six months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $145.7 million and $132.5 million, respectively.

- changed (2023-04-27):
[0000950170-23-015282:note_history:30]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $18.2 million and $16.3 million at March 31, 2023 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2023 and 2022, was $2.3 million and $1.9 million, respectively. Amortization recognized during the nine months ended March 31, 2023 and 2022, was $6.7 million and $5.5 million, respectively.
  (was, 2023-01-27, similarity 0.9676):
[0001564590-23-000867:note_history:30]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $17.5 million and $16.3 million at December 31, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2022 and 2021, was $ 2.2 million and $1.8 million, respectively. Amortization recognized during the six months ended December 31, 2022 and 2021, was $4.3 million and $3.6 million, respectively.

- changed (2023-04-27):
[0000950170-23-015282:note_history:31]
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |
| Other |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |
| Total Americas |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |
| EMEA |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |
| APAC |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |
| Total net revenues |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |
  (was, 2023-01-27, similarity 0.9564):
[0001564590-23-000867:note_history:31]
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |
| Other |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |
| Total Americas |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |
| EMEA |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |
| APAC |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |
| Total net revenues |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |

- changed (2023-04-27):
[0000950170-23-015282:note_history:32]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |
| Other |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |
| Total Americas |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |
| EMEA |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |
| APAC |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |
| Total net revenues |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |
  (was, 2023-01-27, similarity 0.9134):
[0001564590-23-000867:note_history:32]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |
| Other |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |
| Total Americas |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |
| EMEA |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |
| APAC |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |
| Total net revenues |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |

- changed (2023-04-27):
[0000950170-23-015282:note_history:33]
For three and nine months ended March 31, 2023 the Company generated 17% and 12% of its revenues from the Netherlands, respectively. For the three and nine months ended March 31, 2022 the Company generated 18% and 12% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2023 and 2022.
  (was, 2023-01-27, similarity 0.6325):
[0001564590-23-000867:note_history:33]
For three months ended December 31, 2022 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022 the Company generated 10% each of its revenues from the Netherlands and Germany. For the six months ended December 31, 2021 the Company generated 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2022 and 2021.

- added (2023-04-27):
[0000950170-23-015282:note_history:34]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2023 |  | March 31,2022 |  | March 31,2023 |  | March 31,2022 |
| Westcon Group, Inc. |  | 25% |  | 25% |  | 20% |  | 18% |
| TD Synnex Corporation |  | 19% |  | 17% |  | 19% |  | 20% |
| Jenne, Inc. |  | 15% |  | 20% |  | 14% |  | 17% |

- added (2023-04-27):
[0000950170-23-015282:note_history:35]
|  |  | March 31,2023 |  | June 30,2022 |
| Jenne, Inc. |  | 25% |  | 28% |
| Westcon Group, Inc. |  | 21% |  | * |
| TD Synnex Corporation |  | * |  | 11% |
| * Less than 10% of accounts receivable. |  |  |  |  |

- removed (2023-04-27):
[0001564590-23-000867:note_history:36]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Westcon Group, Inc. |  | 19% |  |  | 11% |  |  | 17% |  |  | 15% |  |
| TD Synnex Corporation |  | 17% |  |  | 21% |  |  | 18% |  |  | 22% |  |
| Jenne, Inc. |  | 13% |  |  | 18% |  |  | 13% |  |  | 16% |  |
| ScanSource, Inc. |  | 11% |  |  | * |  |  | * |  |  | * |  |
| * Less than 10% of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

- removed (2023-04-27):
[0001564590-23-000867:note_history:37]
|  |  | December 31, 2022 |  |  | June 30, 2022 |  |
| Jenne, Inc. |  | 16% |  |  | 28% |  |
| ScanSource, Inc. |  | 10% |  |  | * |  |
| TD Synnex Corporation |  | 10% |  |  | 11% |  |
| * Less than 10% of accounts receivable. |  |  |  |  |  |  |  |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-27):
[0000950170-23-015282:note_history:38]
On March 31, 2023, the Company had $464.2 million of remaining performance obligations, which are primarily comprised of deferred maintenance and deferred SaaS revenues. The Company expects to recognize approximately 20% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 44% in fiscal 2024 and 36% of the balance thereafter.
  (was, 2023-01-27, similarity 0.967):
[0001564590-23-000867:note_history:38]
On December 31, 2022, the Company had $445.6 million of remaining performance obligations, which are primarily comprised of deferred maintenance and SaaS revenues. The Company expects to recognize approximately 36% of its deferred revenue as revenue in the remainder of fiscal 2023, an additional 34% in fiscal 2024 and 30% of the balance thereafter.

- changed (2023-04-27):
[0000950170-23-015282:note_history:39]
Revenue recognized for the three months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $81.0 million and $77.3 million, respectively. Revenue recognized for the nine months ended March 31, 2023 and 2022 that was included in the deferred revenue balance at the beginning of each period was $193.7 million and $176.1 million, respectively.
  (was, 2023-01-27, similarity 0.9194):
[0001564590-23-000867:note_history:39]
Revenue recognized for the three months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $83.9 million and $81.9 million, respectively. Revenue recognized for the six months ended December 31, 2022 and 2021 that was included in the deferred revenue balance at the beginning of each period was $145.7 million and $132.5 million, respectively.

- changed (2023-04-27):
[0000950170-23-015282:note_history:40]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $18.2 million and $16.3 million at March 31, 2023 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended March 31, 2023 and 2022, was $2.3 million and $1.9 million, respectively. Amortization recognized during the nine months ended March 31, 2023 and 2022, was $6.7 million and $5.5 million, respectively.
  (was, 2023-01-27, similarity 0.9676):
[0001564590-23-000867:note_history:40]
Contract Costs. The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that the Company otherwise would have recognized is one year or less. Management expects that commission fees paid to sales representatives as a result of obtaining service and subscription contracts and contract renewals are recoverable and therefore the Company’s condensed consolidated balance sheets included capitalized balances in the amount of $17.5 million and $16.3 million at December 31, 2022 and June 30, 2022, respectively. Capitalized commissions are included within other assets in the condensed consolidated balance sheets. Capitalized commission fees are amortized on a straight-line basis over the average period of service contracts of approximately three years, and are included in “Sales and marketing” in the accompanying condensed consolidated statements of operations. Amortization recognized during the three months ended December 31, 2022 and 2021, was $ 2.2 million and $1.8 million, respectively. Amortization recognized during the six months ended December 31, 2022 and 2021, was $4.3 million and $3.6 million, respectively.

- changed (2023-04-27):
[0000950170-23-015282:note_history:41]
|  |  | Three Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 74,743 |  | $ | 64,337 |  | $ | 139,080 |  |  | $ | 59,582 |  | $ | 60,852 |  | $ | 120,434 |  |
| Other |  |  | 14,079 |  |  | 4,523 |  |  | 18,602 |  |  |  | 7,574 |  |  | 3,513 |  |  | 11,087 |  |
| Total Americas |  |  | 88,822 |  |  | 68,860 |  |  | 157,682 |  |  |  | 67,156 |  |  | 64,365 |  |  | 131,521 |  |
| EMEA |  |  | 111,664 |  |  | 40,326 |  |  | 151,990 |  |  |  | 101,980 |  |  | 36,844 |  |  | 138,824 |  |
| APAC |  |  | 5,186 |  |  | 17,649 |  |  | 22,835 |  |  |  | 40 |  |  | 15,123 |  |  | 15,163 |  |
| Total net revenues |  | $ | 205,672 |  | $ | 126,835 |  | $ | 332,507 |  |  | $ | 169,176 |  | $ | 116,332 |  | $ | 285,508 |  |
  (was, 2023-01-27, similarity 0.9564):
[0001564590-23-000867:note_history:41]
|  |  | Three Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 70,963 |  | $ | 66,630 |  | $ | 137,593 |  |  | $ | 68,565 |  | $ | 68,585 |  | $ | 137,150 |  |
| Other |  |  | 10,807 |  |  | 4,614 |  |  | 15,421 |  |  |  | 3,865 |  |  | 4,955 |  |  | 8,820 |  |
| Total Americas |  |  | 81,770 |  |  | 71,244 |  |  | 153,014 |  |  |  | 72,430 |  |  | 73,540 |  |  | 145,970 |  |
| EMEA |  |  | 97,147 |  |  | 40,903 |  |  | 138,050 |  |  |  | 68,934 |  |  | 42,128 |  |  | 111,062 |  |
| APAC |  |  | 7,403 |  |  | 19,881 |  |  | 27,284 |  |  |  | 5,034 |  |  | 18,867 |  |  | 23,901 |  |
| Total net revenues |  | $ | 186,320 |  | $ | 132,028 |  | $ | 318,348 |  |  | $ | 146,398 |  | $ | 134,535 |  | $ | 280,933 |  |

- changed (2023-04-27):
[0000950170-23-015282:note_history:42]
|  |  | Nine Months Ended |  |
|  |  | March 31,2023 |  |  | March 31,2022 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 245,852 |  | $ | 203,991 |  | $ | 449,843 |  |  | $ | 184,215 |  | $ | 196,768 |  | $ | 380,983 |  |
| Other |  |  | 14,080 |  |  | 4,523 |  |  | 18,603 |  |  |  | 19,238 |  |  | 11,835 |  |  | 31,073 |  |
| Total Americas |  |  | 259,932 |  |  | 208,514 |  |  | 468,446 |  |  |  | 203,453 |  |  | 208,603 |  |  | 412,056 |  |
| EMEA |  |  | 285,066 |  |  | 120,482 |  |  | 405,548 |  |  |  | 248,812 |  |  | 114,703 |  |  | 363,515 |  |
| APAC |  |  | 14,627 |  |  | 59,923 |  |  | 74,550 |  |  |  | 9,409 |  |  | 49,145 |  |  | 58,554 |  |
| Total net revenues |  | $ | 559,625 |  | $ | 388,919 |  | $ | 948,544 |  |  | $ | 461,674 |  | $ | 372,451 |  | $ | 834,125 |  |
  (was, 2023-01-27, similarity 0.9134):
[0001564590-23-000867:note_history:42]
|  |  | Six Months Ended |  |
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Distributor |  | Direct |  | Total |  |  | Distributor |  | Direct |  | Total |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 144,277 |  | $ | 130,942 |  | $ | 275,219 |  |  | $ | 124,633 |  | $ | 135,916 |  | $ | 260,549 |  |
| Other |  |  | 26,832 |  |  | 8,712 |  |  | 35,544 |  |  |  | 11,664 |  |  | 8,322 |  |  | 19,986 |  |
| Total Americas |  |  | 171,109 |  |  | 139,654 |  |  | 310,763 |  |  |  | 136,297 |  |  | 144,238 |  |  | 280,535 |  |
| EMEA |  |  | 173,403 |  |  | 80,156 |  |  | 253,559 |  |  |  | 146,832 |  |  | 77,859 |  |  | 224,691 |  |
| APAC |  |  | 9,441 |  |  | 42,274 |  |  | 51,715 |  |  |  | 9,369 |  |  | 34,022 |  |  | 43,391 |  |
| Total net revenues |  | $ | 353,953 |  | $ | 262,084 |  | $ | 616,037 |  |  | $ | 292,498 |  | $ | 256,119 |  | $ | 548,617 |  |

- changed (2023-04-27):
[0000950170-23-015282:note_history:43]
For three and nine months ended March 31, 2023 the Company generated 17% and 12% of its revenues from the Netherlands, respectively. For the three and nine months ended March 31, 2022 the Company generated 18% and 12% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and nine months ended March 31, 2023 and 2022.
  (was, 2023-01-27, similarity 0.6325):
[0001564590-23-000867:note_history:43]
For three months ended December 31, 2022 the Company generated 11% and 10% of its revenues from the Netherlands and Germany, respectively. For the six months ended December 31, 2022 the Company generated 10% each of its revenues from the Netherlands and Germany. For the six months ended December 31, 2021 the Company generated 10% of its revenues from the Netherlands. No other foreign country accounted for 10% or more of revenue for the three and six months ended December 31, 2022 and 2021.
